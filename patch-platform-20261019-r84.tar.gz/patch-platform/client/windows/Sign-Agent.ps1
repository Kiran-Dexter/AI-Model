<#
.SYNOPSIS
  Sign the PATCH-01 agent scripts once, before copying the folder to the servers.

.DESCRIPTION
  Run once, on the PC that holds your code-signing certificate (with its
  private key), in PowerShell, from the agent folder:

      .\Sign-Agent.ps1

  It lists your code-signing certificates and asks which to use, asks for a
  timestamp server (optional: press Enter to skip), signs every .ps1 in this
  folder with SHA-256, checks each signature, and saves the publisher
  certificate (public part only) as publisher-<thumbprint>.cer. On each
  server, Deploy-Agent.ps1 offers to trust that publisher for the computer,
  which the agent's SYSTEM task needs under AllSigned.

  Sign again after changing any script: a changed script's signature is no
  longer valid.

  If this PC itself runs AllSigned, this script cannot run before it is
  signed: sign it first by hand, once:
      $c = Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert | Select-Object -First 1
      Set-AuthenticodeSignature -FilePath .\Sign-Agent.ps1 -Certificate $c -HashAlgorithm SHA256
#>
[CmdletBinding()]
param()
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path

function Ok([string]$T) { Write-Host ("  ok    " + $T) -ForegroundColor Green }
function Warn([string]$T) { Write-Host ("  warn  " + $T) -ForegroundColor Yellow }
function Stop-Sign([string]$T) { Write-Host ""; Write-Host ("  STOP  " + $T) -ForegroundColor Red; Write-Host ""; exit 1 }

Write-Host ""; Write-Host "Sign the PATCH-01 agent scripts" -ForegroundColor Cyan; Write-Host ""

# Code-signing certificates with a private key, valid today, from the user's and the computer's store
$now = Get-Date
$certs = @(@(Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert -ErrorAction SilentlyContinue) +
           @(Get-ChildItem Cert:\LocalMachine\My -CodeSigningCert -ErrorAction SilentlyContinue) |
           Where-Object { $_ -and $_.HasPrivateKey -and $_.NotBefore -le $now -and $_.NotAfter -gt $now } |
           Sort-Object Thumbprint -Unique)
if ($certs.Count -eq 0) { Stop-Sign "No valid code-signing certificate with its private key on this PC (Cert:\CurrentUser\My or Cert:\LocalMachine\My)." }
for ($i = 0; $i -lt $certs.Count; $i++) {
    $c = $certs[$i]
    Write-Host ("  {0}. {1}" -f ($i + 1), $c.Subject)
    Write-Host ("     issued by {0}, valid until {1}, thumbprint {2}" -f $c.Issuer, $c.NotAfter.ToString("dd MMM yyyy"), $c.Thumbprint)
}
$n = 0
while ($n -lt 1 -or $n -gt $certs.Count) {
    $a = Read-Host ("  Which certificate? (1-" + $certs.Count + ") [1]")
    if ([string]::IsNullOrWhiteSpace($a)) { $a = "1" }
    $n = $a -as [int]; if ($null -eq $n) { $n = 0 }
}
$cert = $certs[$n - 1]
Ok ("Certificate: " + $cert.Subject)
if ($cert.NotAfter -lt $now.AddDays(60)) { Warn ("It expires on " + $cert.NotAfter.ToString("dd MMM yyyy") + ": use a timestamp server so the signatures outlive it") }

$tsa = Read-Host "  Timestamp server URL (optional; Enter to skip)"
$tsa = $tsa.Trim()
if ($tsa -and $tsa -notmatch '^https?://[A-Za-z0-9.-]+(:\d{1,5})?(/[A-Za-z0-9._~/-]*)?$') { Stop-Sign "That is not a timestamp server URL (http://name or https://name/path)." }
if (-not $tsa) { Warn ("No timestamp: the signatures stop being valid when the certificate expires (" + $cert.NotAfter.ToString("dd MMM yyyy") + "); sign again before then") }

$files = @(Get-ChildItem -Path $Here -Filter *.ps1 -File | Sort-Object Name)
Write-Host ""
$failed = @()
foreach ($f in $files) {
    $p = @{ FilePath = $f.FullName; Certificate = $cert; HashAlgorithm = "SHA256" }
    if ($tsa) { $p.TimestampServer = $tsa }
    try {
        $r = Set-AuthenticodeSignature @p
        if ([string]$r.Status -eq "Valid") { Ok ("signed  " + $f.Name) }
        else { $failed += $f.Name; Warn ($f.Name + ": " + [string]$r.Status + " " + [string]$r.StatusMessage) }
    } catch { $failed += $f.Name; Warn ($f.Name + ": " + $_.Exception.Message) }
}
# Check every file again from disk, as a server will
foreach ($f in $files) {
    $s = Get-AuthenticodeSignature -FilePath $f.FullName
    if ([string]$s.Status -ne "Valid" -or $s.SignerCertificate.Thumbprint -ne $cert.Thumbprint) {
        if ($failed -notcontains $f.Name) { $failed += $f.Name }
    }
}
if ($failed.Count -gt 0) { Stop-Sign ("Not signed: " + ($failed -join ", ") + ". If a timestamp server was given, check this PC can reach it.") }

# The publisher certificate, public part only, for the servers to trust
Get-ChildItem -Path $Here -Filter "publisher-*.cer" -File -ErrorAction SilentlyContinue | Remove-Item -Force
$cerPath = Join-Path $Here ("publisher-" + $cert.Thumbprint.Substring(0, 8).ToLowerInvariant() + ".cer")
[IO.File]::WriteAllBytes($cerPath, $cert.Export([Security.Cryptography.X509Certificates.X509ContentType]::Cert))
Ok ("Publisher certificate saved: " + (Split-Path -Leaf $cerPath) + " (public part only)")

Write-Host ""
Write-Host ("  DONE  " + $files.Count + " scripts signed. Copy this whole folder (with your CA .pem) to the servers or a share,") -ForegroundColor Green
Write-Host  "        then on each server, as administrator:  .\Deploy-Agent.ps1" -ForegroundColor Green
Write-Host ""
