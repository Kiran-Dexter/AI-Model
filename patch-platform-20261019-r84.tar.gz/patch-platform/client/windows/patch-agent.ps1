<#
.SYNOPSIS
  PATCH-01 agent for Windows Server (PowerShell 5.1, built in to Windows Server 2016 and later).

.DESCRIPTION
  Runs every 2 minutes as SYSTEM from a scheduled task. Patch jobs from
  PATCH-01 run through it: a precheck, installing the WSUS-approved updates
  the job names, a reboot when the job says so, and a postcheck. Each run checks in and
  picks up commands. Every 4 hours, or when PATCH-01 asks, it also reports:
    - the OS build (10.0.17763.6414), which PATCH-01 compares with Microsoft's
      Security Update Guide to know which CVEs are still open;
    - installed updates (KBs);
    - updates Windows Update says are missing, searched against the server's
      own WSUS, so they reflect your approvals;
    - whether a reboot is pending, uptime, and the hardware ID that links the
      server to its VM in vCenter.

  Patch jobs: the precheck restarts Windows Update, searches this server's
  WSUS for the job's updates and downloads them; the install installs them
  one by one (one failure does not stop the rest); after the reboot the
  postcheck confirms each update is installed and that the services running
  before are running again (a service that will not start is reported, it is
  not a failed patch).

  patch-agent.ps1 -SelfTest -Server https://patch01.example -Pin <sha256>
      checks every step and reports ok or failed; enrols nothing
  patch-agent.ps1 -Enroll -Server <url> -Token <token> -Pin <sha256>
  patch-agent.ps1 -Run            (what the scheduled task runs)
  patch-agent.ps1 -Inventory      (report now)
  patch-agent.ps1 -Check          (proves this file loads, reads its settings and token; prints
                                   "PATCH-01 agent <version> ready"; used to test an update)
  patch-agent.ps1 -UpdateCheck    (run by the previous version after an update: puts itself
                                   back if the new version has not answered PATCH-01's check
                                   job within 10 minutes; stops a new version that hangs)

  Updates from PATCH-01 (agent 1.8.0+): the new file is downloaded over the
  pinned connection, checked against the SHA-256 in the job, parsed, checked
  for its signature (always, when this agent is signed or the server runs
  AllSigned) and test-run with -Check before it replaces this file. The
  running version is kept as patch-agent.prev.ps1 and is what checks the
  new one, so a broken update cannot stop it from putting itself back.
#>
[CmdletBinding(DefaultParameterSetName = "Run")]
param(
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)][switch]$Enroll,
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][switch]$SelfTest,
    [Parameter(ParameterSetName = "Run")][switch]$Run,
    [Parameter(ParameterSetName = "Inventory", Mandatory = $true)][switch]$Inventory,
    [Parameter(ParameterSetName = "Check", Mandatory = $true)][switch]$Check,
    [Parameter(ParameterSetName = "UpdateCheck", Mandatory = $true)][switch]$UpdateCheck,
    [Parameter(ParameterSetName = "Identity", Mandatory = $true)][switch]$Identity,
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)]
    [Parameter(ParameterSetName = "Identity", Mandatory = $true)]
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][string]$Server,
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)][string]$Token,
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)]
    [Parameter(ParameterSetName = "Identity", Mandatory = $true)]
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][string]$Pin
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$AgentVersion = "1.9.2-win"
$DataDir = Join-Path $env:ProgramData "PatchAgent"
$ConfigFile = Join-Path $DataDir "agent.json"
$TokenFile = Join-Path $DataDir "token.bin"
$StateFile = Join-Path $DataDir "state.json"
$LogFile = Join-Path $DataDir "agent.log"
# Updates from PATCH-01: the new file is staged and checked here (inside the locked data folder)
$UpdateDir = Join-Path $DataDir "update"
$UpdateMarker = Join-Path $UpdateDir "pending.json"
# Written by the new version after each check-in: proves it starts and reaches PATCH-01
$UpdateCheckin = Join-Path $UpdateDir "checked-in.json"
# The previous version stops a new one that hangs before ever checking in, this long after the swap
$UpdateHardMinutes = 30
$UpdateTaskName = "PATCH-01 agent update check"
$AgentTaskName = "PATCH-01 agent"
$UpdateConfirmMinutes = 10
# Windows install: stop only after this long with no Windows Update activity at all, or at the hard
# cap (below PATCH-01's 8 hours, so the answer always arrives)
$InstallIdleMinutes = 45
$script:LocalAdminSids = $null          # Test-LocalAdminSid: this server's administrators, read once per run
$InstallHardMinutes = 465
$SelfPath = $PSCommandPath
$InventoryEveryHours = 4
$SearchTimeoutSec = 1800
# After a job step, keep asking PATCH-01 for the next one this long (it is queued within seconds)
$FollowUpSeconds = 120
# Script-wide state, declared up front: strict mode refuses to read a variable
# that has never been set, and Get-Config checks this before anything sets it
$script:Cfg = $null
# Where each run spends its time (sent to PATCH-01, shown on the Servers page)
$script:Phases = [ordered]@{}
$script:CommandCount = 0
$script:RunToken = $null
$script:Updated = $false

function Add-Phase([string]$Name, [datetime]$Since) {
    $secs = ((Get-Date) - $Since).TotalSeconds
    if ($script:Phases.Contains($Name)) { $script:Phases[$Name] = [double]$script:Phases[$Name] + $secs } else { $script:Phases[$Name] = $secs }
}

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
function Write-Log([string]$Message, [string]$Level = "INFO") {
    # Never throws: a log file held by an antivirus scan or a log reader must not break a job step.
    # The timestamp is always yyyy-MM-dd HH:mm:ss, whatever the server's regional settings.
    $line = "{0} {1} {2}" -f (Get-Date).ToString("yyyy-MM-dd HH:mm:ss", [Globalization.CultureInfo]::InvariantCulture), $Level, $Message
    Write-Verbose $line
    if (-not (Test-Path -LiteralPath $DataDir)) { return }
    for ($i = 0; $i -lt 3; $i++) {
        try {
            if ((Test-Path -LiteralPath $LogFile) -and ((Get-Item -LiteralPath $LogFile).Length -gt 1MB)) {
                try { Move-Item -LiteralPath $LogFile -Destination ($LogFile + ".1") -Force -ErrorAction Stop } catch { }
            }
            Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8 -ErrorAction Stop
            return
        } catch { Start-Sleep -Milliseconds 200 }
    }
}

# ---------------------------------------------------------------------------
# TLS: PATCH-01's certificate is pinned by its SHA-256 fingerprint. Compiled
# once, because a PowerShell script block used as a certificate callback can
# be called on a thread with no PowerShell runspace and fail.
# ---------------------------------------------------------------------------
if (-not ("PatchAgentPin" -as [type])) {
    Add-Type -TypeDefinition @"
using System;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
public static class PatchAgentPin {
    public static string Pin = "";
    public static string Seen = "";
    public static bool Check(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors errors) {
        if (cert == null) { return false; }
        using (SHA256 sha = SHA256.Create()) {
            Seen = BitConverter.ToString(sha.ComputeHash(cert.GetRawCertData())).Replace("-", "").ToLowerInvariant();
        }
        if (Pin == "system") { return errors == SslPolicyErrors.None; }
        // Several fingerprints, comma-separated, while a certificate is being replaced
        foreach (string one in Pin.Split(',')) { if (one.Length > 0 && Seen == one) { return true; } }
        return false;
    }
    public static void Use(string pin) {
        Pin = pin.Trim().ToLowerInvariant().Replace(":", "").Replace(" ", "");
        ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(Check);
    }
}
"@
}

function Initialize-Http([string]$PinValue) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [PatchAgentPin]::Use($PinValue)
    # PATCH-01 is internal: never send it through a proxy configured for the internet
    [Net.WebRequest]::DefaultWebProxy = $null
}

function Assert-Https([string]$Url) {
    # The certificate pin only applies to https: a plain http address would send the token in clear
    if ($Url -notmatch '^https://[A-Za-z0-9.-]+(:\d{1,5})?/?$') { throw ("PATCH-01's address must be https://<name>[:port]; '" + $Url + "' was refused") }
}

function Invoke-Api([string]$Method, [string]$Path, $Body = $null, [string]$Bearer = $null, [int]$Timeout = 60) {
    $cfg = Get-Config
    Assert-Https ([string]$cfg.server)
    $uri = $cfg.server.TrimEnd("/") + $Path
    $headers = @{ "User-Agent" = "patch-agent/$AgentVersion" }
    if ($Bearer) { $headers["Authorization"] = "Bearer " + $Bearer }
    $params = @{ Method = $Method; Uri = $uri; Headers = $headers; TimeoutSec = $Timeout; UseBasicParsing = $true }
    if ($null -ne $Body) {
        # -InputObject, not a pipe: piping unwraps one-element arrays in PowerShell 5.1
        $params["Body"] = [Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $Body -Depth 8 -Compress))
        $params["ContentType"] = "application/json; charset=utf-8"
    }
    try {
        return Invoke-RestMethod @params
    } catch {
        $detail = $_.Exception.Message
        # In PowerShell 5.1 Invoke-RestMethod has already read the error body:
        # it is in ErrorDetails, and the response stream is empty by now
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
            $code = ""
            if ($_.Exception.PSObject.Properties["Response"] -and $_.Exception.Response) { $code = "HTTP " + [int]$_.Exception.Response.StatusCode + ": " }
            $detail = $code + $_.ErrorDetails.Message
        }
        # Only web errors carry a response; asking others for one fails under strict mode
        elseif ($_.Exception.PSObject.Properties["Response"] -and $_.Exception.Response) {
            try {
                $sr = New-Object IO.StreamReader($_.Exception.Response.GetResponseStream())
                $detail = "HTTP " + [int]$_.Exception.Response.StatusCode + ": " + $sr.ReadToEnd()
            } catch { }
        }
        if ([PatchAgentPin]::Seen -and [PatchAgentPin]::Pin -ne "system" -and ([PatchAgentPin]::Pin.Split(",") -notcontains [PatchAgentPin]::Seen)) {
            $detail = "PATCH-01's certificate does not match the pin. It presented " + [PatchAgentPin]::Seen
        }
        throw "$Method $Path failed: $detail"
    }
}

function Get-IsoUtc([datetime]$When = (Get-Date)) {
    # Whole seconds: "o" writes seven decimal places, more than the API accepts
    return $When.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ", [Globalization.CultureInfo]::InvariantCulture)
}

# ---------------------------------------------------------------------------
# Configuration and the agent's token, encrypted for this machine only
# ---------------------------------------------------------------------------
function Get-Config {
    if ($script:Cfg) { return $script:Cfg }
    if (-not (Test-Path $ConfigFile)) { throw "Not enrolled: run install-agent.ps1 first." }
    $script:Cfg = Get-Content -Raw $ConfigFile | ConvertFrom-Json
    return $script:Cfg
}

function Save-Token([string]$Value) {
    Add-Type -AssemblyName System.Security
    $bytes = [Text.Encoding]::UTF8.GetBytes($Value)
    $enc = [Security.Cryptography.ProtectedData]::Protect($bytes, $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
    [IO.File]::WriteAllBytes($TokenFile, $enc)
}

function Get-Token {
    Add-Type -AssemblyName System.Security
    if (-not (Test-Path $TokenFile)) { throw "No agent token: enrol first." }
    $enc = [IO.File]::ReadAllBytes($TokenFile)
    $bytes = [Security.Cryptography.ProtectedData]::Unprotect($enc, $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
    return [Text.Encoding]::UTF8.GetString($bytes)
}

function Get-State {
    # A missing, empty or damaged state file starts afresh instead of breaking every later run
    try {
        if (Test-Path -LiteralPath $StateFile) {
            $raw = [IO.File]::ReadAllText($StateFile)
            if (-not [string]::IsNullOrWhiteSpace($raw)) {
                $st = ConvertFrom-Json -InputObject $raw
                if ($st -is [Management.Automation.PSCustomObject]) { return $st }
            }
        }
    } catch { }
    return [pscustomobject]@{ last_inventory = $null }
}

function Save-State($State) {
    # Written to a temporary file and swapped in, so a restart mid-write never leaves it empty
    $tmp = $StateFile + ".tmp"
    [IO.File]::WriteAllText($tmp, (ConvertTo-Json -InputObject $State -Depth 6), (New-Object Text.UTF8Encoding($false)))
    if (Test-Path -LiteralPath $StateFile) { [IO.File]::Replace($tmp, $StateFile, [NullString]::Value) } else { [IO.File]::Move($tmp, $StateFile) }
}

function Get-Prop($Object, [string]$Name) {
    <# A value that may be missing, without tripping strict mode. Works for
       objects (registry entries, JSON from PATCH-01) and for hashtables (what a
       background job returns): a hashtable's entries are not its properties. #>
    if ($null -eq $Object) { return $null }
    if ($Object -is [Collections.IDictionary]) {
        if ($Object.Contains($Name)) { return $Object[$Name] }
        return $null
    }
    if ($Object.PSObject.Properties[$Name]) { return $Object.$Name }
    return $null
}

# ---------------------------------------------------------------------------
# Facts about this server
# ---------------------------------------------------------------------------
function Get-Build {
    $cv = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion"
    $major = 10; $minor = 0
    if ($cv.PSObject.Properties["CurrentMajorVersionNumber"]) { $major = $cv.CurrentMajorVersionNumber }
    if ($cv.PSObject.Properties["CurrentMinorVersionNumber"]) { $minor = $cv.CurrentMinorVersionNumber }
    $ubr = 0
    if ($cv.PSObject.Properties["UBR"]) { $ubr = $cv.UBR }
    return [pscustomobject]@{
        Build   = "{0}.{1}.{2}.{3}" -f $major, $minor, $cv.CurrentBuildNumber, $ubr
        Number  = [int]$cv.CurrentBuildNumber
        Product = $cv.ProductName
    }
}

function Get-ServerVersion($BuildInfo) {
    # The Windows Server release, from the build number; the product name as a fallback
    switch ($BuildInfo.Number) {
        14393 { return "2016" } 17763 { return "2019" } 20348 { return "2022" } 26100 { return "2025" }
    }
    if ($BuildInfo.Product -match "(20\d\d)") { return $Matches[1] }
    return [string]$BuildInfo.Number
}

function Get-RebootState {
    $reasons = @()
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending") { $reasons += "component servicing" }
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") { $reasons += "Windows Update" }
    try { if ((New-Object -ComObject Microsoft.Update.SystemInfo).RebootRequired) { if ($reasons -notcontains "Windows Update") { $reasons += "Windows Update" } } } catch { }
    return [pscustomobject]@{ Required = ($reasons.Count -gt 0); Reason = ($reasons -join ", ") }
}

function Get-CachedFqdn {
    $short = $env:COMPUTERNAME.ToLowerInvariant()
    $st = Get-State
    try {
        if ($st.PSObject.Properties["fqdn"] -and $st.fqdn -and $st.PSObject.Properties["fqdn_at"] -and $st.fqdn_at -and
            ((Get-Date).ToUniversalTime() - ([datetime]$st.fqdn_at).ToUniversalTime()).TotalHours -lt 6) { return [string]$st.fqdn }
    } catch { }
    $fqdn = $short
    $t0 = Get-Date
    $found = $false
    try { $fqdn = ([Net.Dns]::GetHostEntry($env:COMPUTERNAME).HostName).ToLowerInvariant(); $found = $true } catch { }
    $secs = ((Get-Date) - $t0).TotalSeconds
    if ($secs -ge 5) { Write-Log ("DNS took " + [int]$secs + " s to name this server; the name is now kept for 6 hours") "WARN" }
    # A failed lookup is tried again after 30 minutes, not 6 hours
    $at = $(if ($found) { Get-IsoUtc } else { Get-IsoUtc ((Get-Date).AddHours(-5.5)) })
    try { Set-StateValue "fqdn" $fqdn; Set-StateValue "fqdn_at" $at } catch { }
    return $fqdn
}

function Get-Facts {
    $os = Get-CimInstance Win32_OperatingSystem
    $cs = Get-CimInstance Win32_ComputerSystemProduct
    $b = Get-Build
    # A DNS hiccup must not stop the check-in (and so every job step). The name is
    # looked up at most every 6 hours: a slow DNS server made every run wait for it.
    $fqdn = Get-CachedFqdn
    $uuid = $null
    if ($cs.UUID -and $cs.UUID -match "^[0-9A-Fa-f-]{32,36}$" -and $cs.UUID -notmatch "^[0F-]+$") { $uuid = $cs.UUID.ToLowerInvariant() }
    return [pscustomobject]@{
        Hostname = $env:COMPUTERNAME.ToLowerInvariant()
        Fqdn     = $fqdn
        Build    = $b.Build
        Version  = Get-ServerVersion $b
        Edition  = $b.Product
        Boot     = Get-IsoUtc $os.LastBootUpTime
        Uuid     = $uuid
        MachineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
    }
}

function Get-WsusSource {
    $wu = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
    $server = $null; $use = 0
    if (Test-Path $wu) {
        $p = Get-ItemProperty $wu
        if ($p.PSObject.Properties["WUServer"]) { $server = $p.WUServer }
        if (Test-Path "$wu\AU") {
            $au = Get-ItemProperty "$wu\AU"
            if ($au.PSObject.Properties["UseWUServer"]) { $use = $au.UseWUServer }
        }
    }
    if ($server -and $use -eq 1) { return [pscustomobject]@{ Source = "wsus"; Server = $server } }
    return [pscustomobject]@{ Source = "microsoft"; Server = $null }
}

function Get-InstalledSoftware {
    <# Programs and Features, from the registry both 64-bit and 32-bit programs
       write to. Updates and hidden system components are left out. #>
    $out = @(); $seen = @{}
    foreach ($src in @(@{ Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"; Arch = "64-bit" },
                       @{ Path = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"; Arch = "32-bit" })) {
        foreach ($e in @(Get-ItemProperty -Path $src.Path -ErrorAction SilentlyContinue)) {
            $name = Get-Prop $e "DisplayName"
            if (-not $name) { continue }
            if ((Get-Prop $e "SystemComponent") -eq 1) { continue }
            if (Get-Prop $e "ParentKeyName") { continue }
            $rt = [string](Get-Prop $e "ReleaseType")
            if ($rt -in @("Update", "Hotfix", "Security Update", "Update Rollup")) { continue }
            $ver = [string](Get-Prop $e "DisplayVersion")
            $key = ($name + "|" + $ver + "|" + $src.Arch).ToLowerInvariant()
            if ($seen.ContainsKey($key)) { continue }
            $seen[$key] = $true
            $size = Get-Prop $e "EstimatedSize"
            $item = @{ name = ([string]$name).Trim(); version = $ver.Trim(); arch = $src.Arch }
            $pub = Get-Prop $e "Publisher"; if ($pub) { $item["publisher"] = ([string]$pub).Trim() }
            $d = [string](Get-Prop $e "InstallDate"); if ($d -match "^\d{8}$") { $item["installed_on"] = $d }
            $kbSize = 0.0
            if ($size -and $size -isnot [array] -and [double]::TryParse([string]$size, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$kbSize) -and $kbSize -gt 0) {
                $item["size_mb"] = [int]($kbSize / 1024)
            }
            $out += $item
        }
    }
    return ,$out
}

function Search-MissingUpdates([switch]$Offline) {
    <# Asks Windows Update what is not installed. Against WSUS this returns
       what WSUS has approved for this computer. Run as a job so a search that
       hangs is abandoned instead of blocking every later run. -Offline reads
       the list from Windows' last check against WSUS (seconds, no network). #>
    $job = Start-Job -ArgumentList ([bool]$Offline) -ScriptBlock {
        param($offline)
        $ErrorActionPreference = "Stop"          # a failed search must fail, never look like "nothing missing"
        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = "PATCH-01"
        $searcher = $session.CreateUpdateSearcher()
        if ($offline) { $searcher.Online = $false }
        $result = $searcher.Search("IsInstalled=0 and IsHidden=0 and BrowseOnly=0 and Type='Software'")
        if ([int]$result.ResultCode -ne 2 -and [int]$result.ResultCode -ne 3) { throw ("Windows Update search ended with result " + [int]$result.ResultCode) }
        $out = @()
        foreach ($u in $result.Updates) {
          try {
            $kb = $null
            if ($u.KBArticleIDs.Count -gt 0) { $kb = "KB" + $u.KBArticleIDs.Item(0) }
            $cats = @(); foreach ($c in $u.Categories) { $cats += [string]$c.Name }
            $cves = @(); foreach ($c in $u.CveIDs) { $cves += [string]$c }
            $out += [pscustomobject]@{
                update_id = [string]$u.Identity.UpdateID
                kb = $kb
                title = [string]$u.Title
                severity = [string]$u.MsrcSeverity
                categories = $cats
                cves = $cves
                downloaded = [bool]$u.IsDownloaded
                reboot_behaviour = @("never", "always", "may")[[int]$u.InstallationBehavior.RebootBehavior]
                size_mb = [int]([double]$u.MaxDownloadSize / 1MB)
                pending_reboot = [bool]$u.RebootRequired
            }
          } catch { }                               # one unreadable update does not lose the rest
        }
        return @{ updates = $out }
    }
    if (-not (Wait-JobAlive $job $SearchTimeoutSec "Windows Update search for the inventory")) {
        Stop-Job $job; Remove-Job $job -Force
        throw "Windows Update search did not finish within $([int]($SearchTimeoutSec / 60)) minutes"
    }
    try { $r = Receive-JobResult $job "Windows Update search" } finally { Remove-Job $job -Force }
    $data = @(Get-Prop $r "updates")
    # Results come back deserialised: an empty list can arrive as $null, and
    # extra job properties ride along. Rebuild each update with exactly the
    # fields PATCH-01 expects.
    $clean = @()
    foreach ($u in @($data)) {
        if ($null -eq $u -or -not $u.PSObject.Properties["update_id"]) { continue }
        $sev = $null; if ($u.severity) { $sev = [string]$u.severity }
        $clean += @{
            update_id = [string]$u.update_id; kb = $u.kb; title = [string]$u.title; severity = $sev
            categories = @(@($u.categories) | Where-Object { $_ } | ForEach-Object { [string]$_ })
            cves = @(@($u.cves) | Where-Object { $_ } | ForEach-Object { [string]$_ })
            downloaded = [bool]$u.downloaded; reboot_behaviour = [string]$u.reboot_behaviour; size_mb = [int]$u.size_mb
            # installed, waiting for the restart: not "to install" (PATCH-01 1.9.0+)
            installed_pending_reboot = [bool]$u.pending_reboot
        }
    }
    return ,$clean
}

# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------
function Send-Checkin($Token) {
    $f = Get-Facts
    $r = Get-RebootState
    $body = @{ agent_version = $AgentVersion; kernel_running = $f.Build; reboot_required = $r.Required; boot_time = $f.Boot }
    if ($f.Uuid) { $body["hardware_uuid"] = $f.Uuid }
    Invoke-Api "POST" "/api/v1/agent/checkin" $body $Token | Out-Null
}

function Get-InstalledUpdates {
    <# The installed updates with their details, for the console: from the
       installed hotfix list (KB, type, date, by whom) and Windows Update's own
       history (title, date, result; also updates the hotfix list leaves out,
       such as .NET and Defender). Local only, seconds. Never fails the
       inventory: what cannot be read is left out. #>
    $items = @(); $seen = @{}
    $titles = @{}
    try {
        $s = New-Object -ComObject Microsoft.Update.Session
        $h = $s.CreateUpdateSearcher()
        $n = [int]$h.GetTotalHistoryCount()
        if ($n -gt 0) {
            foreach ($e in $h.QueryHistory(0, [math]::Min($n, 1000))) {
                if ([int]$e.Operation -ne 1) { continue }                  # installs only (not removals)
                $title = [string]$e.Title
                if (-not $title) { continue }
                $kb = $null
                if ($title -match '\((KB\d{4,8})\)') { $kb = $Matches[1].ToUpperInvariant() }
                $id = [string]$e.UpdateIdentity.UpdateID
                $key = $(if ($id) { $id } else { $title })
                if ($seen.ContainsKey($key)) { continue }                    # newest first: keep the newest attempt
                $seen[$key] = $true
                $res = @{ 0 = "Not started"; 1 = "In progress"; 2 = "Succeeded"; 3 = "Succeeded with errors"; 4 = "Failed"; 5 = "Aborted" }[[int]$e.ResultCode]
                $when = $null; try { $when = Get-IsoUtc ([datetime]$e.Date) } catch { }
                $title = $title.Substring(0, [math]::Min($title.Length, 500))      # PATCH-01 takes up to 500 characters
                if ($kb -and -not $titles.ContainsKey($kb) -and ([int]$e.ResultCode -eq 2 -or [int]$e.ResultCode -eq 3)) { $titles[$kb] = @{ title = $title; date = $when } }
                $items += @{ kb = $kb; title = $title; kind = $null
                             installed_on = $when; installed_by = $null; result = $res; source = "history" }
                if ($items.Count -ge 1500) { break }
            }
        }
    } catch { Write-Log ("Windows Update history could not be read: " + $_.Exception.Message) "WARN" }
    try {
        foreach ($x in @(Get-HotFix -ErrorAction SilentlyContinue)) {
            $kb = ([string]$x.HotFixID).ToUpperInvariant()
            if ($kb -notmatch '^KB\d{4,8}$') { continue }
            $when = $null
            try { if ($x.InstalledOn) { $when = Get-IsoUtc ([datetime]$x.InstalledOn) } } catch { }
            $t = $titles[$kb]
            if (-not $when -and $t) { $when = $t.date }
            $kind = [string]$x.Description; $kind = $kind.Substring(0, [math]::Min($kind.Length, 60))
            $items += @{ kb = $kb; title = $(if ($t) { [string]$t.title } else { $null }); kind = $kind
                         installed_on = $when; installed_by = ([string]$x.InstalledBy).Substring(0, [math]::Min(([string]$x.InstalledBy).Length, 120))
                         result = "Installed"; source = "hotfix" }
        }
    } catch { Write-Log ("installed hotfix list could not be read: " + $_.Exception.Message) "WARN" }
    return ,@($items | Select-Object -First 3000)
}

function Send-Inventory($Token) {
    $t0 = Get-Date
    $f = Get-Facts
    $r = Get-RebootState
    $packages = @(@{ name = "windows-os-build"; version = ($f.Build + "-0"); arch = "noarch" })
    $tp = Get-Date
    $hotfixes = @(Get-HotFix -ErrorAction SilentlyContinue)
    Add-Phase "inventory hotfixes" $tp
    foreach ($h in $hotfixes) {
        if ($h.HotFixID -match "^KB\d+$") {
            $packages += @{ name = $h.HotFixID.ToLowerInvariant(); version = "1-0"; arch = "noarch"; from_repo = [string]$h.Description }
        }
    }
    $body = @{
        collected_at = (Get-IsoUtc); kernel_running = $f.Build
        reboot_required = $r.Required; reboot_reason = $r.Reason; os_version = $f.Version
        agent_version = $AgentVersion; boot_time = $f.Boot; packages = $packages
        duration_ms = [int]((Get-Date) - $t0).TotalMilliseconds
    }
    if ($f.Uuid) { $body["hardware_uuid"] = $f.Uuid }
    Invoke-Api "POST" "/api/v1/agent/inventory" $body $Token -Timeout 120 | Out-Null
    Write-Log ("inventory sent: build {0}, {1} updates installed" -f $f.Build, ($packages.Count - 1))

    $tp = Get-Date
    try {
        $inst = Get-InstalledUpdates
        Invoke-Api "POST" "/api/v1/agent/windows/installed" @{ collected_at = (Get-IsoUtc); items = $inst } $Token -Timeout 120 | Out-Null
        Write-Log ("installed updates sent: {0}" -f $inst.Count)
    } catch { Write-Log ("installed updates not sent: " + $_.Exception.Message) "WARN" }
    Add-Phase "inventory installed updates" $tp

    $tp = Get-Date
    try {
        $sw = Get-InstalledSoftware
        Invoke-Api "POST" "/api/v1/agent/windows/software" @{ software = $sw } $Token -Timeout 120 | Out-Null
        Write-Log ("software sent: {0} programs" -f $sw.Count)
    } catch { Write-Log ("software inventory failed: " + $_.Exception.Message) }
    Add-Phase "inventory software" $tp

    $src = Get-WsusSource
    $report = @{ searched_at = (Get-IsoUtc); source = $src.Source; server = $src.Server
                 os_edition = $f.Edition; updates = @() }
    # Windows checks WSUS by itself (Automatic Updates): when it did within 24 hours, its own
    # list is read locally in seconds; otherwise (or if that fails) WSUS is searched, which
    # can take many minutes on 2016/2019 and holds up any job step waiting for this run
    $tp = Get-Date
    $age = Get-LastWsusCheckHours
    $how = "searched WSUS"
    try {
        $list = $null
        if ($null -ne $age -and $age -le 24) {
            try { $list = Search-MissingUpdates -Offline; $how = "Windows' own list, WSUS checked " + $age + " h ago"; $report["offline"] = $true }
            catch { Write-Log ("the local update list could not be read (" + $_.Exception.Message + "); searching WSUS") "WARN" }
        }
        if ($null -eq $list) {
            $list = Search-MissingUpdates
            $report["offline"] = $false                 # a full search: Windows Update is the authority
            Set-StateValue "last_online_search" (Get-IsoUtc)
        }
        $report["updates"] = $list
        Write-Log ("Windows Update ({0}, {1}): {2} missing in {3} s" -f $src.Source, $how, $report["updates"].Count, [int]((Get-Date) - $tp).TotalSeconds)
    } catch {
        $report["error"] = [string]$_.Exception.Message
        Write-Log ("Windows Update search failed: " + $report["error"]) "WARN"
    }
    Add-Phase $(if ($how -eq "searched WSUS") { "inventory WSUS search" } else { "inventory update list" }) $tp
    Invoke-Api "POST" "/api/v1/agent/windows/updates" $report $Token -Timeout 120 | Out-Null
}

# ---------------------------------------------------------------------------
# Windows Update helpers shared by the precheck and the install
# ---------------------------------------------------------------------------
$WuIdRe = '^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$'

function Get-ValidUpdateIds($Params) {
    return @(@(Get-Prop $Params "windows_updates") | ForEach-Object { [string]$_ } | Where-Object { $_ -match $WuIdRe })
}

function Test-Tcp([string]$HostName, [int]$Port, [int]$Ms = 5000) {
    # "" when it connects, otherwise the reason
    $c = New-Object Net.Sockets.TcpClient
    try {
        $iar = $c.BeginConnect($HostName, $Port, $null, $null)
        if (-not $iar.AsyncWaitHandle.WaitOne($Ms)) { return "no answer within " + [int]($Ms / 1000) + " s" }
        $c.EndConnect($iar); return ""
    } catch {
        $ex = $_.Exception
        if ($ex.PSObject.Properties["InnerException"] -and $ex.InnerException) { $ex = $ex.InnerException }
        return [string]$ex.Message
    }
    finally { $c.Close() }
}

function Get-WuActivity {
    <# Signs that Windows Update is doing something: bytes landing in its
       download folders (BITS and Delivery Optimization both write there) and
       CPU used by the servicing engine. Compared over time, they tell
       "slow" from "stuck". #>
    $bytes = [long]0
    foreach ($d in @("$env:SystemRoot\SoftwareDistribution\Download",
                     "$env:SystemRoot\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache")) {
        if (Test-Path $d) {
            # An empty folder gives no measurement at all ($null): counted as 0, never read as $null.Sum
            foreach ($fi in @(Get-ChildItem -Path $d -Recurse -Force -File -ErrorAction SilentlyContinue)) { $bytes += [long]$fi.Length }
        }
    }
    try { foreach ($b in @(Get-BitsTransfer -AllUsers -ErrorAction Stop)) { $bytes += [long]$b.BytesTransferred } } catch { }
    $cpu = 0.0
    foreach ($pr in @(Get-Process -Name TiWorker, TrustedInstaller -ErrorAction SilentlyContinue)) { if ($pr.CPU) { $cpu += [double]$pr.CPU } }
    return [pscustomobject]@{ Bytes = $bytes; Cpu = $cpu }
}

function Invoke-PreDownload([string[]]$Ids, $Token, [int]$StallMinutes, [int]$LimitMinutes, [int]$TotalMb) {
    <# Download the job's updates now, so the install window only installs.
       Progress every 30 s. If nothing moves for StallMinutes, stop and say so:
       nothing has been installed at this point, so stopping is safe. #>
    $job = Start-Job -ArgumentList (,$Ids) -ScriptBlock {
        param($ids)
        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = "PATCH-01"
        $ErrorActionPreference = "Stop"
        $ids = @($ids | ForEach-Object { $_ } | Where-Object { $_ })
        $crit = (($ids | ForEach-Object { "UpdateID='" + $_ + "'" }) -join " or ")
        $sr = $session.CreateUpdateSearcher()
        $found = $null
        try {                                     # this server's own list first (seconds), WSUS only if needed
            $sr.Online = $false; $found = $sr.Search($crit)
            $have = 0; foreach ($u in $found.Updates) { if ($ids -contains [string]$u.Identity.UpdateID) { $have++ } }
            if ($have -lt $ids.Count) { $found = $null }
        } catch { $found = $null }
        if (-not $found) { $sr.Online = $true; $found = $sr.Search($crit) }
        $coll = New-Object -ComObject Microsoft.Update.UpdateColl
        foreach ($u in $found.Updates) {
            if (($ids -contains [string]$u.Identity.UpdateID) -and -not $u.IsDownloaded -and -not $u.IsInstalled) {
                if (-not $u.EulaAccepted) { $u.AcceptEula() }
                [void]$coll.Add($u)
            }
        }
        if ($coll.Count -eq 0) { return @{ code = 2; done = @() } }
        $dl = $session.CreateUpdateDownloader()
        try { $dl.Priority = 4 } catch { try { $dl.Priority = 3 } catch { } }    # foreground download, not background BITS
        $dl.Updates = $coll
        $r = $dl.Download()
        $done = @(); for ($i = 0; $i -lt $coll.Count; $i++) { $done += @{ id = [string]$coll.Item($i).Identity.UpdateID; ok = [bool]$coll.Item($i).IsDownloaded } }
        return @{ code = [int]$r.ResultCode; hresult = ("0x{0:X8}" -f $r.HResult); done = $done }
    }
    $t0 = Get-Date; $a0 = Get-WuActivity; $lastBytes = $a0.Bytes; $lastMove = Get-Date
    while (-not (Wait-Job $job -Timeout 30)) {
        $a = Get-WuActivity
        $got = [int](([math]::Max(0, $a.Bytes - $a0.Bytes)) / 1MB)
        if ($a.Bytes -ne $lastBytes) { $lastBytes = $a.Bytes; $lastMove = Get-Date }
        $quiet = [int]((Get-Date) - $lastMove).TotalMinutes
        Write-Log ("pre-download: about " + $got + " of up to " + $TotalMb + " MB after " + [int]((Get-Date) - $t0).TotalMinutes + " min" +
                   $(if ($quiet -ge 2) { "; nothing has arrived for " + $quiet + " min" } else { "" }))
        Send-LogTail $Token
        if ($quiet -ge $StallMinutes) {
            Stop-Job $job; Remove-Job $job -Force
            return @{ ok = $false; stalled = $true
                      why = ("the download stalled: nothing arrived for " + $StallMinutes + " minutes (about " + $got + " of " + $TotalMb + " MB had arrived)") }
        }
        if (((Get-Date) - $t0).TotalMinutes -ge $LimitMinutes) {
            Stop-Job $job; Remove-Job $job -Force
            return @{ ok = $false; stalled = $false; why = ("the download did not finish within " + $LimitMinutes + " minutes (about " + $got + " MB arrived)") }
        }
    }
    try { $r = Receive-JobResult $job "pre-download" } finally { Remove-Job $job -Force }
    $all = @(@(Get-Prop $r "done") | Where-Object { $_ })
    $notDone = @($all | Where-Object { -not (Get-Prop $_ "ok") })
    $code = [int](Get-Prop $r "code")
    $mins = [int]((Get-Date) - $t0).TotalMinutes
    if ($code -eq 2 -and $notDone.Count -eq 0) { return @{ ok = $true; minutes = $mins } }
    if ($all.Count -gt 0 -and $notDone.Count -lt $all.Count) {
        # Some arrived: the install downloads the rest itself, one by one
        return @{ ok = $true; minutes = $mins; partial = $true
                  why = ([string]$notDone.Count + " of " + $all.Count + " update(s) did not download now (result " + $code + ", " + (Get-Prop $r "hresult") + "); the install will try them again") }
    }
    return @{ ok = $false; stalled = $false; why = ("Windows Update ended the download with result " + $code + " (" + (Get-Prop $r "hresult") + "); none of the " + $all.Count + " update(s) downloaded") }
}

$script:RunToken = $null
function Wait-JobAlive($Job, [int]$TimeoutSec, [string]$What) {
    <# Wait-Job in one-minute slices: every 2 minutes a log line goes to
       PATCH-01, so a long Windows Update search never makes this server look
       offline on the dashboard. True when the job finished in time. #>
    $t0 = Get-Date; $last = Get-Date
    while ($true) {
        if (Wait-Job $Job -Timeout 60) { return $true }
        $mins = [int]((Get-Date) - $t0).TotalMinutes
        if (((Get-Date) - $t0).TotalSeconds -ge $TimeoutSec) { return $false }
        if (((Get-Date) - $last).TotalSeconds -ge 115) {
            Write-Log ($What + ": still working (" + $mins + " min so far)")
            if ($script:RunToken) { Send-LogTail $script:RunToken }
            $last = Get-Date
        }
    }
}

function Receive-JobResult($Job, [string]$What) {
    <# A background job's answer. A stray error the job wrote along the way
       (a log line that could not be written, one update that could not be
       read) is logged, and never throws away the answer itself. #>
    $jerr = $null
    $r = Receive-Job $Job -ErrorAction SilentlyContinue -ErrorVariable jerr
    foreach ($x in @($jerr)) { if ($x) { Write-Log ($What + ": " + [string]$x) "WARN" } }
    $r = @($r | Where-Object { $_ -is [Collections.IDictionary] })
    if ($r.Count -eq 0) { throw ($What + " returned no answer" + $(if (@($jerr).Count) { ": " + [string]@($jerr)[0] } else { "" })) }
    return $r[$r.Count - 1]
}

function Format-Gb([double]$Value) {
    # "12.3 GB": always text, so it can be joined to other text (a number first
    # in "+" makes PowerShell try to turn the text into a number)
    return ([string]::Format([Globalization.CultureInfo]::InvariantCulture, "{0:0.0} GB", $Value))
}

function Set-StateValue([string]$Name, $Value) {
    $state = Get-State
    if ($state.PSObject.Properties[$Name]) { $state.$Name = $Value }
    else { $state | Add-Member -NotePropertyName $Name -NotePropertyValue $Value }
    Save-State $state
}

# ---------------------------------------------------------------------------
# The Windows Update service
# ---------------------------------------------------------------------------
function Restart-WindowsUpdate {
    <# Restart the Windows Update service (wuauserv) so the job starts with a
       clean client: a stuck search or download from earlier is dropped. If it
       does not stop within 60 seconds and runs in a process of its own, that
       process is ended; a process shared with other services is never ended. #>
    $t0 = Get-Date
    try {
        $svc = Get-Service -Name wuauserv -ErrorAction Stop
        if ([string]$svc.StartType -eq "Disabled") { return @{ ok = $false; detail = "Windows Update (wuauserv) is disabled" } }
        if ([string]$svc.Status -ne "Stopped") {
            # The service object's own Stop() returns at once; Stop-Service would wait for ever on a hung service
            try { $svc.Stop() } catch { Write-Log ("stopping wuauserv: " + $_.Exception.Message) "WARN" }
            try { $svc.WaitForStatus("Stopped", (New-TimeSpan -Seconds 60)) } catch { }
            $svc.Refresh()
            if ([string]$svc.Status -ne "Stopped") {
                $w = Get-CimInstance Win32_Service -Filter "Name='wuauserv'"
                $procId = [int]$w.ProcessId
                $sharing = @(Get-CimInstance Win32_Service -Filter ("ProcessId=" + $procId)).Count
                if ($procId -le 0 -or $sharing -ne 1) {
                    return @{ ok = $false; detail = "Windows Update did not stop within 60 s and shares its process with other services, so it was left running" }
                }
                Write-Log ("wuauserv did not stop within 60 s: ending its own process " + $procId) "WARN"
                Stop-Process -Id $procId -Force -ErrorAction Stop
                Start-Sleep -Seconds 5
            }
        }
        $svc.Refresh()
        if ([string]$svc.Status -ne "Running") { $svc.Start() }
        try { $svc.WaitForStatus("Running", (New-TimeSpan -Seconds 60)) }
        catch { return @{ ok = $false; detail = "Windows Update was restarted but did not report Running within 60 s; it starts on demand" } }
        return @{ ok = $true; detail = ("Windows Update service restarted in " + [int]((Get-Date) - $t0).TotalSeconds + " s") }
    } catch {
        return @{ ok = $false; detail = ("Windows Update service could not be restarted: " + $_.Exception.Message) }
    }
}

# ---------------------------------------------------------------------------
# Which updates this job installs, from a fresh search of this server's WSUS
# ---------------------------------------------------------------------------
function Get-JobSelection($Params) {
    <# What PATCH-01 asked for. Older PATCH-01 releases send only the update
       IDs; newer ones also say the job's mode (every approved update, or the
       ones for chosen advisories) with its KBs and CVEs. #>
    $kbs = @(@(Get-Prop $Params "windows_kbs") | Where-Object { $_ } | ForEach-Object { ([string]$_).ToUpperInvariant() } | Where-Object { $_ -match '^KB\d{5,8}$' })
    $cves = @(@(Get-Prop $Params "windows_cves") | Where-Object { $_ } | ForEach-Object { ([string]$_).ToUpperInvariant() } | Where-Object { $_ -match '^CVE-\d{4}-\d{4,7}$' })
    $mode = [string](Get-Prop $Params "windows_mode")
    if (@("all", "advisories") -notcontains $mode) { $mode = "" }
    return @{ ids = @(Get-ValidUpdateIds $Params); kbs = $kbs; cves = $cves; mode = $mode }
}

function Find-JobUpdates($Params, [int]$TimeoutSec = 1200, [switch]$Offline) {
    <# Ask WSUS now what this server is missing, and pick the job's updates
       from that: by update ID, then by KB (a re-released update keeps its KB),
       then by CVE for an advisory job, or everything approved for an "all"
       job. Updates that would wait for someone to click are skipped. Run as a
       background job so a hanging Windows Update cannot block the agent. #>
    $sel = Get-JobSelection $Params
    $job = Start-Job -ArgumentList $sel.ids, $sel.kbs, $sel.cves, $sel.mode, ([bool]$Offline) -ScriptBlock {
        param($ids, $kbs, $cves, $mode, $offline)
        $ErrorActionPreference = "Stop"          # a failed search must fail, never look like "nothing to install"
        $ids = @($ids | Where-Object { $_ }); $kbs = @($kbs | Where-Object { $_ }); $cves = @($cves | Where-Object { $_ })
        function KbOf($u) { if ($u.KBArticleIDs.Count -gt 0) { return "KB" + $u.KBArticleIDs.Item(0) }; return $null }
        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = "PATCH-01"
        $searcher = $session.CreateUpdateSearcher()
        # Offline: the list from Windows' last check against WSUS, read locally in seconds
        if ($offline) { $searcher.Online = $false }
        # BrowseOnly=0: never the optional or preview updates Windows Update only offers
        $missing = $searcher.Search("IsInstalled=0 and IsHidden=0 and BrowseOnly=0 and Type='Software'")
        if ([int]$missing.ResultCode -ne 2 -and [int]$missing.ResultCode -ne 3) { throw ("Windows Update search ended with result " + [int]$missing.ResultCode) }
        # The job's own IDs, installed or not, to tell "already installed" from "gone"
        $named = @{}
        if ($ids.Count -gt 0) {
            try {
                $byId = $searcher.Search((($ids | ForEach-Object { "UpdateID='" + $_ + "'" }) -join " or "))
                foreach ($u in $byId.Updates) { $named[[string]$u.Identity.UpdateID] = $u }
            } catch { }
        }
        $wantKb = @{}; foreach ($k in $kbs) { $wantKb[$k] = $true }
        $already = @()
        foreach ($k in @($named.Keys)) {
            $u = $named[$k]; $kb = KbOf $u
            if ($u.IsInstalled) { $already += @{ id = $k; kb = $kb; title = [string]$u.Title } }
            elseif ($kb) { $wantKb[$kb] = $true }
        }
        $all = @(); $chosen = @(); $skipped = @(); $seen = @{}
        foreach ($u in $missing.Updates) {
          try {
            $id = [string]$u.Identity.UpdateID; $kb = KbOf $u
            $seen[$id] = $true
            $ucves = @(); foreach ($c in $u.CveIDs) { $ucves += ([string]$c).ToUpperInvariant() }
            $why = $null
            if ($mode -eq "all") { $why = "approved in WSUS" }
            elseif ($ids -contains $id) { $why = "named by the job" }
            elseif ($kb -and $wantKb.ContainsKey($kb)) { $why = "same KB as the job's update" }
            elseif ($mode -eq "advisories" -and $cves.Count -gt 0 -and @($ucves | Where-Object { $cves -contains $_ }).Count -gt 0) { $why = "fixes a CVE of the chosen advisories" }
            $urls = @()
            try {                       # only for a reachability hint: never fails the search
                foreach ($dc in $u.DownloadContents) { $urls += [string]$dc.DownloadUrl }
                foreach ($b in $u.BundledUpdates) { foreach ($dc in $b.DownloadContents) { $urls += [string]$dc.DownloadUrl } }
            } catch { }
            $item = @{ id = $id; kb = $kb; title = [string]$u.Title; mb = [int]([double]$u.MaxDownloadSize / 1MB)
                       downloaded = [bool]$u.IsDownloaded; why = $why; urls = @($urls | Where-Object { $_ } | Select-Object -Unique) }
            $all += @{ id = $id; kb = $kb; title = [string]$u.Title }
            if (-not $why) { continue }
            if ($u.InstallationBehavior.CanRequestUserInput) { $skipped += @{ id = $id; kb = $kb; title = [string]$u.Title; why = "it asks for input while installing" }; continue }
            $chosen += $item
          } catch { }                               # one unreadable update does not lose the rest
        }
        $gone = @($ids | Where-Object { -not $named.ContainsKey($_) -and -not $seen.ContainsKey($_) })
        return @{ missing = $all; selected = $chosen; already = $already; skipped = $skipped; not_found = $gone }
    }
    if (-not (Wait-JobAlive $job $TimeoutSec "Windows Update search")) {
        Stop-Job $job; Remove-Job $job -Force
        throw ("Windows Update did not answer the search within " + [int]($TimeoutSec / 60) + " minutes")
    }
    try { $r = Receive-JobResult $job "Windows Update search" } finally { Remove-Job $job -Force }
    $out = @{}
    foreach ($k in @("missing", "selected", "already", "skipped", "not_found")) { $out[$k] = @(@(Get-Prop $r $k) | Where-Object { $_ }) }
    $out.mode = $sel.mode
    return $out
}

function Get-LastWsusCheckHours {
    <# How long ago this server last checked WSUS successfully: Windows' own
       automatic check, or the agent's own online search, whichever is newer.
       $null when neither is known. #>
    $when = @()
    try {
        $d = (New-Object -ComObject Microsoft.Update.AutoUpdate).Results.LastSearchSuccessDate
        if ($d -and ([datetime]$d).Year -gt 2000) { $when += ([datetime]$d).ToUniversalTime() }
    } catch { }
    $st = Get-State
    if ($st.PSObject.Properties["last_online_search"] -and $st.last_online_search) {
        try { $when += ([datetime]$st.last_online_search).ToUniversalTime() } catch { }
    }
    if ($when.Count -eq 0) { return $null }
    $newest = @($when | Sort-Object -Descending)[0]
    return [math]::Round(((Get-Date).ToUniversalTime() - $newest).TotalHours, 1)
}

function Find-JobUpdatesSmart($Params, [int]$TimeoutSec) {
    <# Updates WSUS has already pushed to this server come first: if Windows
       checked WSUS within the last 24 hours, its local list is read (seconds)
       and the job's updates waiting there are used. Only when nothing for the
       job is waiting, or the last check is old, WSUS is searched once. #>
    $age = Get-LastWsusCheckHours
    if ($null -ne $age -and $age -le 24) {
        try {
            $f = Find-JobUpdates $Params 300 -Offline
            if ($f.selected.Count -gt 0) {
                $ready = @($f.selected | Where-Object { Get-Prop $_ "downloaded" }).Count
                Write-Log ("updates waiting on this server (WSUS checked " + $age + " h ago): " + $f.selected.Count + " for this job, " + $ready + " already downloaded; no WSUS search needed")
                $f.source = "updates waiting on this server"
                return $f
            }
            Write-Log ("nothing for this job is waiting on this server (WSUS checked " + $age + " h ago); checking WSUS once")
        } catch { Write-Log ("the local update list could not be read (" + $_.Exception.Message + "); checking WSUS") "WARN" }
    } else {
        Write-Log ($(if ($null -eq $age) { "no record of a recent WSUS check" } else { "the last WSUS check was " + $age + " h ago" }) + "; checking WSUS once")
    }
    $f = Find-JobUpdatesTwice $Params $TimeoutSec
    $f.source = "WSUS"
    Set-StateValue "last_online_search" (Get-IsoUtc)
    return $f
}

function Find-JobUpdatesTwice($Params, [int]$TimeoutSec) {
    # A search that fails once is tried again after restarting Windows Update
    try { return Find-JobUpdates $Params $TimeoutSec }
    catch {
        Write-Log ("Windows Update search failed: " + $_.Exception.Message + "; restarting Windows Update and trying once more") "WARN"
        $rs = Restart-WindowsUpdate; Write-Log $rs.detail $(if ($rs.ok) { "INFO" } else { "WARN" })
        return Find-JobUpdates $Params $TimeoutSec
    }
}

# Services that stop by design (started on demand, by a trigger, or only for
# updates): never counted as "did not come back"
$TransientServices = @("TrustedInstaller", "wuauserv", "BITS", "UsoSvc", "WaaSMedicSvc", "DoSvc", "sppsvc", "RemoteRegistry",
                       "gupdate", "gupdatem", "edgeupdate", "edgeupdatem", "MapsBroker", "tiledatamodelsvc", "WbioSrvc",
                       "ShellHWDetection", "CDPSvc", "msiserver", "VSS", "swprv", "defragsvc", "WinHttpAutoProxySvc")

function Test-StopsByDesign([string]$Name) {
    if ($TransientServices -contains $Name) { return $true }
    $key = "HKLM:\SYSTEM\CurrentControlSet\Services\" + $Name
    if (Test-Path ($key + "\TriggerInfo")) { return $true }               # started by a trigger, stops by itself
    try {
        $type = [int](Get-ItemProperty -Path $key -Name Type -ErrorAction Stop).Type
        if (($type -band 0x40) -ne 0) { return $true }                    # a per-user service instance
    } catch { }
    return $false
}

function Get-BaselineServices {
    # The automatic services running now that are expected to keep running
    return @(Get-CimInstance Win32_Service -Filter "State='Running' AND StartMode='Auto'" |
             ForEach-Object { [string]$_.Name } | Where-Object { -not (Test-StopsByDesign $_) } | Sort-Object)
}

function Invoke-Precheck($Params, $Token) {
    <# Everything the job needs, checked before anything changes. Each check is
       logged as it runs, so ">_ Log" shows exactly which one failed and why.
       Then Windows Update is restarted, this server's WSUS is searched for the
       job's updates, and they are downloaded now, so the install only installs. #>
    function Note([string]$Name, [string]$State, [string]$Detail) {
        $script:pcChecks += @{ check = $Name; state = $State; detail = $Detail }
        Write-Log ("precheck " + $Name + ": " + $State.ToUpper() + " - " + $Detail) $(if ($State -eq "fail") { "ERROR" } elseif ($State -eq "warn") { "WARN" } else { "INFO" })
        if ($State -eq "fail") { $script:pcErrors += ($Name + ": " + $Detail) }
        if ($State -eq "warn") { $script:pcWarnings += ($Name + ": " + $Detail) }
    }
    $script:pcChecks = @(); $script:pcErrors = @(); $script:pcWarnings = @(); $script:pcJobWarnings = @()
    $pcStart = Get-Date
    # A restart-only job: only what matters for a restart (disk, a pending reboot, the services to compare)
    $restartOnly = [bool](Get-Prop $Params "restart_only")

    # 1. Disk: more than 1 GB free on C: is enough to go ahead
    $c = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
    $freeBytes = [double]$c.FreeSpace
    $freeGb = [math]::Round($freeBytes / 1GB, 1)
    if ($freeBytes -le 1GB -and $restartOnly) { Note "disk" "warn" ("only " + (Format-Gb $freeGb) + " free on C:") }
    elseif ($freeBytes -le 1GB) { Note "disk" "fail" ("only " + (Format-Gb $freeGb) + " free on C:; at least 1 GB is needed") }
    elseif ($freeGb -lt 5) { Note "disk" "warn" ((Format-Gb $freeGb) + " free on C:; a cumulative update can need more, watch the install") }
    else { Note "disk" "ok" ((Format-Gb $freeGb) + " free on C:") }

    # 2. Services Windows Update depends on: they may be stopped (they start on demand), never disabled
    $wuServices = @(@{ n = "wuauserv"; l = "Windows Update" }, @{ n = "BITS"; l = "Background Intelligent Transfer" },
                    @{ n = "CryptSvc"; l = "Cryptographic Services" }, @{ n = "TrustedInstaller"; l = "Windows Modules Installer" })
    if ($restartOnly) { $wuServices = @() }
    foreach ($sv in $wuServices) {
        $o = Get-Service -Name $sv.n -ErrorAction SilentlyContinue
        if (-not $o) { Note ("service " + $sv.n) "fail" ($sv.l + " is missing") }
        elseif ([string]$o.StartType -eq "Disabled") { Note ("service " + $sv.n) "fail" ($sv.l + " is disabled; updates cannot be installed") }
        else { Note ("service " + $sv.n) "ok" ($sv.l + " is " + [string]$o.Status + ", start " + [string]$o.StartType) }
    }

    # 3. A reboot already waiting can make cumulative updates fail
    $r = Get-RebootState
    if ($r.Required) { Note "reboot" "warn" ("a reboot was already pending before this change (" + $r.Reason + ")") }
    else { Note "reboot" "ok" "no reboot pending" }

    # 4. The update source
    $src = Get-WsusSource
    if ($restartOnly) { }
    elseif ($src.Source -eq "wsus") {
        try { $u = [Uri]$src.Server; $why = Test-Tcp $u.Host $u.Port } catch { $why = "the address '" + $src.Server + "' could not be read" }
        if ($why) { Note "wsus" "fail" ("WSUS at " + $src.Server + " cannot be reached: " + $why) } else { Note "wsus" "ok" ("WSUS at " + $src.Server + " answers") }
    } else { Note "wsus" "warn" "no WSUS policy found: this server uses Microsoft Update directly" }

    $res = @{ free_gb_c = $freeGb; update_source = $src.Source }
    $baseline = @()
    if ((Get-Prop $Params "capture_services") -ne $false) {
        $baseline = @(Get-BaselineServices)
        Write-Log ("services running before the change: " + $baseline.Count + " (kept to compare after)")
    }
    $res.running_services = $baseline

    # 5. Restart Windows Update, then search WSUS for the job's updates and download them
    if ($script:pcErrors.Count -eq 0 -and (Get-Prop $Params "restart_windows_update") -ne $false) {
        $rs = Restart-WindowsUpdate
        Note "windows update service" $(if ($rs.ok) { "ok" } else { "warn" }) $rs.detail
    }
    $sel = Get-JobSelection $Params
    if ($script:pcErrors.Count -eq 0 -and ($sel.ids.Count -gt 0 -or $sel.mode -or $sel.kbs.Count -gt 0)) {
        $t0 = Get-Date
        $f = $null
        try { $f = Find-JobUpdatesSmart $Params 1200 } catch { Note "search" "fail" ([string]$_.Exception.Message) }
        if ($f) {
            $todo = @($f.selected)
            Note "search" "ok" ("from " + [string](Get-Prop $f "source") + ": " + $f.missing.Count + " missing update(s) for this server; " + $todo.Count + " for this job, " +
                                $f.already.Count + " of the job's already installed (" + [int]((Get-Date) - $t0).TotalSeconds + " s)")
            foreach ($x in $todo) {
                Write-Log ("  " + (Get-Prop $x "kb") + " " + (Get-Prop $x "title") + ", up to " + (Get-Prop $x "mb") + " MB" +
                           $(if (Get-Prop $x "downloaded") { ", already downloaded" } else { "" }) + " (" + (Get-Prop $x "why") + ")")
            }
            foreach ($x in $f.skipped) {
                $t = (Get-Prop $x "kb") + " " + (Get-Prop $x "title") + " was skipped: " + (Get-Prop $x "why")
                Note "skipped" "warn" $t; $script:pcJobWarnings += $t
            }
            if ($f.not_found.Count -gt 0) {
                $t = [string]$f.not_found.Count + " of the job's updates are no longer offered by WSUS (replaced or declined)"
                Note "not offered" "warn" $t; $script:pcJobWarnings += $t
            }
            $res.windows_selected = @($todo | ForEach-Object { @{ id = (Get-Prop $_ "id"); kb = (Get-Prop $_ "kb"); title = (Get-Prop $_ "title") } })
            Set-StateValue "job_updates" @{ at = (Get-IsoUtc); key = (Get-JobKey $Params); selected = $res.windows_selected }
            $need = @($todo | Where-Object { -not (Get-Prop $_ "downloaded") })
            if ($todo.Count -eq 0) {
                Note "download" "ok" "nothing to download: every update of this job is installed"
            } elseif ($need.Count -eq 0) {
                Note "download" "ok" "all updates are already downloaded"
            } else {
                # Where the files come from: a warning only, the download itself decides
                $endpoints = @{}
                foreach ($x in $need) { foreach ($url in @(Get-Prop $x "urls")) {
                    try { $uu = [Uri]$url; $endpoints[$uu.Host + ":" + $uu.Port] = @{ h = $uu.Host; p = $uu.Port } } catch { }
                } }
                foreach ($k in $endpoints.Keys) {
                    $e = $endpoints[$k]; $why = Test-Tcp $e.h $e.p
                    if ($why) { Note "download source" "warn" ($k + " does not answer directly (" + $why + "); trying the download anyway") }
                    else { Write-Log ("  download source " + $k + " answers") }
                }
                $res.download_sources = @($endpoints.Keys)
                $total = 0; foreach ($x in $need) { $total += [int](Get-Prop $x "mb") }
                $stall = [int](Get-Prop $Params "stall_minutes"); if ($stall -lt 3 -or $stall -gt 60) { $stall = 10 }
                Write-Log ("pre-download: " + $need.Count + " update(s), up to " + $total + " MB")
                # PATCH-01 gives the whole precheck 130 minutes: the download gets what is left, keeping a margin
                $budget = [int][math]::Max(10, [math]::Min(80, 115 - ((Get-Date) - $pcStart).TotalMinutes))
                try { $d = Invoke-PreDownload @($need | ForEach-Object { [string](Get-Prop $_ "id") }) $Token $stall $budget $total }
                catch { $d = @{ ok = $false; why = ("the download could not run: " + $_.Exception.Message) } }
                if ($d.ok -and (Get-Prop $d "partial")) { Note "download" "warn" $d.why; $script:pcJobWarnings += $d.why }
                elseif ($d.ok) { Note "download" "ok" ("downloaded in " + $d.minutes + " min; the install will not need to download") }
                else {
                    $hint = ""
                    if ($src.Source -eq "wsus") { $hint = ". If WSUS sends servers to Microsoft for the files, set WSUS to store update files locally (Options, Update Files and Languages)" }
                    Note "download" "fail" ($d.why + ". Nothing was installed" + $hint)
                }
            }
        }
    } elseif ($script:pcErrors.Count -eq 0) {
        Note "updates" "ok" "this job names no Windows updates"
    }

    $res.checks = $script:pcChecks; $res.errors = $script:pcErrors; $res.warnings = $script:pcWarnings
    $res.job_warnings = $script:pcJobWarnings          # the ones PATCH-01 keeps on the server's result
    $ok = ($script:pcErrors.Count -eq 0)
    $msg = $(if ($ok) { "precheck passed" + $(if ($script:pcWarnings.Count) { "; " + ($script:pcWarnings -join "; ") } else { "" }) } else { $script:pcErrors -join "; " })
    return @{ ok = $ok; result = $res; message = $msg }
}

function Get-JobKey($Params) {
    # What identifies a job's selection, so the install can reuse its precheck's search
    $sel = Get-JobSelection $Params
    return ((@($sel.ids | Sort-Object) -join ",") + "|" + $sel.mode + "|" + (@($sel.kbs | Sort-Object) -join ",") + "|" + (@($sel.cves | Sort-Object) -join ","))
}

function Get-CachedSelection($Params) {
    <# The precheck's WSUS search for this same job, if under 2 hours old:
       the install then skips a second full search (minutes on 2016/2019). #>
    $st = Get-State
    if (-not $st.PSObject.Properties["job_updates"] -or -not $st.job_updates) { return $null }
    $j = $st.job_updates
    if ([string](Get-Prop $j "key") -ne (Get-JobKey $Params)) { return $null }
    $at = $null; try { $at = [datetime](Get-Prop $j "at") } catch { }
    if (-not $at) { return $null }
    $age = ((Get-Date).ToUniversalTime() - $at.ToUniversalTime()).TotalMinutes
    if ($age -lt 0 -or $age -gt 120) { return $null }
    $ids = @(@(Get-Prop $j "selected") | Where-Object { $_ } | ForEach-Object { [string](Get-Prop $_ "id") } | Where-Object { $_ -match $WuIdRe })
    if ($ids.Count -eq 0) { return $null }
    return @{ ids = $ids; minutes = [int]$age }
}

function Invoke-InstallUpdates($Params, $Token) {
    <# Install the job's updates: the servicing stack first on its own, then
       the rest downloaded and installed together in one Windows Update
       session (much faster than one by one; if that fails, one by one).
       The precheck's WSUS search is reused when it is recent. Progress goes
       to the agent's log (and so to PATCH-01) every 30 seconds. One update
       that fails does not stop the others; the job fails only when none of
       its updates could be installed. #>
    $cmdStart = Get-Date
    $sel = Get-JobSelection $Params
    if ($sel.ids.Count -eq 0 -and -not $sel.mode -and $sel.kbs.Count -eq 0) {
        return @{ ok = $false; message = "this job names no valid Windows updates"; result = @{} }
    }
    $cache = Get-CachedSelection $Params
    $out = $null; $wanted = @()
    if ($cache) {
        $wanted = $cache.ids
        Write-Log ("using the precheck's WSUS search from " + $cache.minutes + " min ago: " + $wanted.Count + " update(s); no second search")
        $out = Invoke-InstallJob $wanted $Token $cmdStart
        if (Get-Prop $out "lookup_empty") { Write-Log "the precheck's updates were not found again; searching WSUS afresh" "WARN"; $out = $null }
    }
    if (-not $out) {
        $rs = Restart-WindowsUpdate
        Write-Log $rs.detail $(if ($rs.ok) { "INFO" } else { "WARN" })
        $f = Find-JobUpdatesSmart $Params 1200
        $wanted = @($f.selected | ForEach-Object { [string](Get-Prop $_ "id") } | Where-Object { $_ -match $WuIdRe })
        Write-Log ("WSUS search: " + $f.missing.Count + " missing, " + $wanted.Count + " for this job, " + $f.already.Count + " of the job's already installed")
        if ($wanted.Count -eq 0) {
            $pending = (Get-RebootState).Required
            # Installed earlier but still waiting for a restart: not "nothing to do", PATCH-01 restarts it
            $res = @{ nothing_to_do = (-not $pending); installed = @(); errors = @(); reboot_required = $pending
                      already = @($f.already | ForEach-Object { @{ id = (Get-Prop $_ "id"); kb = (Get-Prop $_ "kb") } }) }
            $why = $(if ($f.already.Count -gt 0) { "the updates were already installed" } elseif ($f.not_found.Count -gt 0) { "WSUS no longer offers the job's updates (replaced or declined): nothing to install" } else { "nothing approved in WSUS is missing" })
            return @{ ok = $true; message = $why; result = $res }
        }
        $out = Invoke-InstallJob $wanted $Token $cmdStart
    }
    if (Get-Prop $out "final") { return $out.final }
    if (Get-Prop $out "lookup_empty") {
        return @{ ok = $false; result = @{ reboot_required = (Get-RebootState).Required }
                  message = ("WSUS listed " + $wanted.Count + " update(s) for this job, but Windows Update did not find them again to install; nothing was installed. Run the job again; if it repeats, check the server's Windows Update log") }
    }
    $r = $out.r
    $start = $out.started
    $installed = @(@(Get-Prop $r "installed") | Where-Object { $_ })
    $failed = @(@(Get-Prop $r "failed") | Where-Object { $_ })
    # Windows' own flag counts too: some updates only say so in the registry
    $reboot = [bool](Get-Prop $r "reboot_required") -or ($installed.Count -gt 0 -and (Get-RebootState).Required)
    $failText = @($failed | ForEach-Object { "{0} failed (result {1}, {2})" -f $(if ($_.kb) { $_.kb } else { $_.title }), $_.code, $_.hresult })
    $res = @{ nothing_to_do = [bool](Get-Prop $r "nothing_to_do"); reboot_required = $reboot
              installed = @($installed | ForEach-Object { @{ id = $_.id; kb = $_.kb; title = $_.title } })
              failed = @($failed | ForEach-Object { @{ id = $_.id; kb = $_.kb; title = $_.title } })
              errors = @(); warnings = $failText }
    Set-StateValue "last_install" @{ at = (Get-IsoUtc); installed = $res.installed; failed = $res.failed }
    if ($res.nothing_to_do) { return @{ ok = $true; message = "the updates were already installed"; result = $res } }
    $msg = "{0} installed in {1} min" -f $installed.Count, [int]((Get-Date) - $start).TotalMinutes
    if ($failed.Count) { $msg += ", {0} failed: {1}" -f $failed.Count, ($failText -join "; ") }
    if ($reboot) { $msg += "; a reboot is needed" }
    if ($installed.Count -eq 0) {
        # Nothing went in: that is a failed install
        $res.errors = $failText
        return @{ ok = $false; message = $msg; result = $res }
    }
    # Some or all went in: carry on to the reboot and the check after it
    return @{ ok = $true; message = $msg; result = $res }
}

function Invoke-InstallJob([string[]]$wanted, $Token, [datetime]$cmdStart) {
    <# Runs the install in a background job and follows it. Returns
       @{ r = the job's answer; started }, @{ lookup_empty = $true }, or
       @{ final = the step's result } when it had to stop early. #>
    $progress = Join-Path $DataDir ("wu-progress-" + [guid]::NewGuid().ToString("N") + ".log")
    # Two arguments: no (,$x) wrapping here, that is only for a single array argument
    $job = Start-Job -ArgumentList $wanted, $progress -ScriptBlock {
        param($ids, $pf)
        $ErrorActionPreference = "Stop"          # a failed lookup must fail, never look like "nothing to install"
        $ids = @($ids | ForEach-Object { $_ } | Where-Object { $_ })
        function P([string]$m, [string]$lvl = "INFO") {
            try { Add-Content -Path $pf -Value ((Get-Date).ToString("yyyy-MM-dd HH:mm:ss", [Globalization.CultureInfo]::InvariantCulture) + " " + $lvl + " " + $m) -Encoding UTF8 -ErrorAction Stop } catch { }
        }
        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = "PATCH-01"
        $searcher = $session.CreateUpdateSearcher()
        $t0 = Get-Date
        P ("looking up " + $ids.Count + " update(s) by their IDs")
        $crit = (($ids | ForEach-Object { "UpdateID='" + $_ + "'" }) -join " or ")
        # First on this server's own list (seconds); WSUS only if any are not there
        $found = $null
        try {
            $searcher.Online = $false
            $found = $searcher.Search($crit)
            $have = 0; foreach ($u in $found.Updates) { if ($ids -contains [string]$u.Identity.UpdateID) { $have++ } }
            if ($have -lt $ids.Count) { $found = $null }
        } catch { $found = $null }
        $searcher.Online = $true
        if (-not $found) {
            try { $found = $searcher.Search($crit) }
            catch {
                P ("the lookup by ID was refused (" + $_.Exception.Message + "); doing a full search instead") "WARN"
                $found = $searcher.Search("IsInstalled=0 and Type='Software'")
            }
        }
        $todo = @()
        foreach ($u in $found.Updates) {
            if (($ids -contains [string]$u.Identity.UpdateID) -and -not $u.IsInstalled) { $todo += $u }
        }
        P ("found " + $todo.Count + " to install in " + [int]((Get-Date) - $t0).TotalSeconds + " s")
        if ($todo.Count -eq 0) { return @{ nothing_to_do = $false; lookup_empty = $true; installed = @(); failed = @(); reboot_required = $false } }
        $acc = @{ ok = @(); bad = @(); reboot = $false; i = 0; n = $todo.Count }
        function KbOf($u) { if ($u.KBArticleIDs.Count -gt 0) { return "KB" + $u.KBArticleIDs.Item(0) }; return $null }
        function Label($u) { $k = KbOf $u; return $(if ($k) { $k } else { "update" }) + " " + [string]$u.Title }
        function Fast($dl) { try { $dl.Priority = 4 } catch { try { $dl.Priority = 3 } catch { } } }   # foreground download, not background BITS
        function Record($u, $code, [string]$hr, [int]$secs) {
            $acc.i++
            $e = @{ id = [string]$u.Identity.UpdateID; kb = (KbOf $u); title = [string]$u.Title; code = $code; hresult = $hr }
            if ($code -eq 2 -or $code -eq 3) { $acc.ok += $e; P ("installed " + $acc.i + " of " + $acc.n + " in " + [int]($secs / 60) + " min " + ($secs % 60) + " s: " + (Label $u)) }
            else { $acc.bad += $e; P ("FAILED " + $acc.i + " of " + $acc.n + " after " + $secs + " s: " + (Label $u) + " (result " + $code + ", " + $hr + ")") "ERROR" }
        }
        function One($u) {
            try {
                if (-not $u.EulaAccepted) { $u.AcceptEula() }
                $one = New-Object -ComObject Microsoft.Update.UpdateColl; [void]$one.Add($u)
                if (-not $u.IsDownloaded) {
                    P ("downloading " + (Label $u) + " (up to " + [int]([double]$u.MaxDownloadSize / 1MB) + " MB)")
                    $t1 = Get-Date; $dl = $session.CreateUpdateDownloader(); Fast $dl; $dl.Updates = $one; $dr = $dl.Download()
                    P ("downloaded in " + [int]((Get-Date) - $t1).TotalSeconds + " s (result " + [int]$dr.ResultCode + ")")
                }
                # A marker line: if this step is stopped mid-install, the update being installed is still known
                P ("batch: " + [string]$u.Identity.UpdateID + " kbs: " + [string](KbOf $u))
                P ("installing " + ($acc.i + 1) + " of " + $acc.n + ": " + (Label $u))
                $t2 = Get-Date; $inst = $session.CreateUpdateInstaller(); $inst.Updates = $one; $r = $inst.Install()
                Record $u ([int]$r.GetUpdateResult(0).ResultCode) ("0x{0:X8}" -f $r.GetUpdateResult(0).HResult) ([int]((Get-Date) - $t2).TotalSeconds)
                if ($r.RebootRequired) { $acc.reboot = $true }
            } catch {
                # One update that throws (corrupt download, refused) does not stop the rest
                Record $u ([int]-1) ([string]$_.Exception.Message) 0
            }
        }
        # Servicing stack updates first, on their own: Windows needs them before the cumulative update
        $ssu = @($todo | Where-Object { $_.Title -match "Servicing Stack" })
        $rest = @($todo | Where-Object { $_.Title -notmatch "Servicing Stack" })
        foreach ($u in $ssu) { One $u }
        if ($rest.Count -gt 1) {
            # The rest in one Windows Update session: one download, one install (much faster than one by one)
            try {
                $coll = New-Object -ComObject Microsoft.Update.UpdateColl
                $need = New-Object -ComObject Microsoft.Update.UpdateColl
                $mb = 0
                foreach ($u in $rest) {
                    if (-not $u.EulaAccepted) { $u.AcceptEula() }
                    [void]$coll.Add($u)
                    if (-not $u.IsDownloaded) { [void]$need.Add($u); $mb += [int]([double]$u.MaxDownloadSize / 1MB) }
                }
                $later = @()
                if ($need.Count -gt 0) {
                    P ("downloading " + $need.Count + " update(s) together (up to " + $mb + " MB)")
                    $t1 = Get-Date; $dl = $session.CreateUpdateDownloader(); Fast $dl; $dl.Updates = $need; $dr = $dl.Download()
                    P ("downloaded in " + [int]((Get-Date) - $t1).TotalSeconds + " s (result " + [int]$dr.ResultCode + ")")
                    # Any that did not download go one by one after the batch (each gets its own download try)
                    $later = @($rest | Where-Object { -not $_.IsDownloaded })
                    if ($later.Count -gt 0) {
                        P ([string]$later.Count + " update(s) did not download with the others; they will be tried one by one") "WARN"
                        $coll = New-Object -ComObject Microsoft.Update.UpdateColl
                        foreach ($u in $rest) { if ($u.IsDownloaded) { [void]$coll.Add($u) } }
                    }
                }
                if ($coll.Count -gt 0) {
                    $ids2 = @(); $kbs2 = @()
                    for ($j = 0; $j -lt $coll.Count; $j++) { $ids2 += [string]$coll.Item($j).Identity.UpdateID; $kbs2 += [string](KbOf $coll.Item($j)) }
                    # A marker line: if this step is stopped mid-install, the updates of this batch are still known
                    P ("batch: " + ($ids2 -join ",") + " kbs: " + ($kbs2 -join ","))
                    P ("installing " + $coll.Count + " update(s) together: " + ((@($rest | ForEach-Object { Label $_ }) | Select-Object -First 6) -join "; "))
                    $t2 = Get-Date; $inst = $session.CreateUpdateInstaller(); $inst.Updates = $coll; $r = $inst.Install()
                    $secs = [int]((Get-Date) - $t2).TotalSeconds
                    for ($j = 0; $j -lt $coll.Count; $j++) {
                        $ur = $r.GetUpdateResult($j)
                        Record $coll.Item($j) ([int]$ur.ResultCode) ("0x{0:X8}" -f $ur.HResult) $secs
                    }
                    if ($r.RebootRequired) { $acc.reboot = $true }
                }
                foreach ($u in $later) { One $u }
            } catch {
                P ("installing them together failed (" + $_.Exception.Message + "); one at a time instead") "WARN"
                $done = @($acc.ok + $acc.bad | ForEach-Object { $_.id })
                foreach ($u in $rest) { if ($done -notcontains [string]$u.Identity.UpdateID -and -not $u.IsInstalled) { One $u } }
            }
        } else {
            foreach ($u in $rest) { One $u }
        }
        $ok = $acc.ok; $bad = $acc.bad; $reboot = $acc.reboot
        return @{ nothing_to_do = $false; installed = $ok; failed = $bad; reboot_required = $reboot }
    }
    # While Windows works: copy its progress into the log, and say so when it is quiet
    $copied = 0; $start = Get-Date; $lastLine = "starting"; $lastNew = Get-Date
    # No fixed time limit while Windows is working: a large cumulative update on a slow server can
    # take hours, and stopping it half way leaves the server worse off. PATCH-01 keeps waiting while
    # this agent reports (every 30 s); the agent stops only when Windows has been idle for a long
    # time, or at the hard cap, which is below PATCH-01's (8 h), so this answer always arrives.
    $hardStop = $cmdStart.AddMinutes($InstallHardMinutes)
    $act = Get-WuActivity; $lastBytes = $act.Bytes; $lastCpu = $act.Cpu; $lastMove = Get-Date
    while ($true) {
        $finished = [bool](Wait-Job $job -Timeout 30)
        if (Test-Path $progress) {
            $lines = @(Get-Content -Path $progress -Encoding UTF8 -ErrorAction SilentlyContinue)
            for ($k = $copied; $k -lt $lines.Count; $k++) {
                if ($lines[$k] -match '^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d (INFO|WARN|ERROR) (.+)$') {
                    Write-Log ("windows update: " + $Matches[2]) $Matches[1]; $lastLine = $Matches[2]; $lastNew = Get-Date
                }
            }
            $copied = $lines.Count
        }
        if ($finished) { break }
        $act = Get-WuActivity
        $busy = ($act.Bytes -ne $lastBytes) -or (($act.Cpu - $lastCpu) -ge 1)
        if ($busy) { $lastMove = Get-Date }
        $lastBytes = $act.Bytes; $lastCpu = $act.Cpu
        $idle = [int]((Get-Date) - $lastMove).TotalMinutes
        if (((Get-Date) - $lastNew).TotalSeconds -ge 60) {
            Write-Log ("windows update: still working (" + [int]((Get-Date) - $start).TotalMinutes + " min so far): " + $lastLine + "; " +
                       $(if ($idle -lt 2) { "Windows is busy" } else { "no download or install activity for " + $idle + " min" })) $(if ($idle -ge 10) { "WARN" } else { "INFO" })
            $lastNew = Get-Date
        }
        # A download that has stopped moving is safe to stop: nothing of that update is installed yet
        $why = $null
        $stillBusy = $false
        if ($lastLine -like "downloading*" -and $idle -ge 15) { $why = "the download stalled: no activity for 15 minutes while " + $lastLine }
        elseif ($idle -ge $InstallIdleMinutes) { $why = "Windows Update showed no download or install activity for " + $idle + " minutes (" + $lastLine + ")" }
        elseif ((Get-Date) -gt $hardStop) {
            $why = "the install was still running after " + [int]($InstallHardMinutes / 60) + " h " + ($InstallHardMinutes % 60) + " min, the longest a job waits"
            $stillBusy = ($idle -lt 10)
        }
        if ($why) {
            Stop-Job $job; Remove-Job $job -Force
            return @{ final = (Complete-PartialInstall $progress $why $stillBusy) }
        }
        Send-LogTail $Token
    }
    try { $r = Receive-JobResult $job "the install" }
    catch {
        Remove-Job $job -Force
        # The answer was lost: what the progress file says went in still counts
        return @{ final = (Complete-PartialInstall $progress ([string]$_.Exception.Message) $false) }
    }
    Remove-Job $job -Force
    Remove-Item $progress -Force -ErrorAction SilentlyContinue
    if (Get-Prop $r "lookup_empty") { return @{ lookup_empty = $true } }
    return @{ r = $r; started = $start }
}

function Complete-PartialInstall([string]$Progress, [string]$Why, [bool]$StillBusy = $false) {
    <# The install stopped early (stall, time limit, lost answer). Updates the
       progress file shows as installed are in and need the restart: the job
       carries on to the reboot with a warning, instead of failing a server
       that is half patched and waiting to restart. #>
    $done = @(); $batch = @(); $batchOpen = $false
    if (Test-Path $Progress) {
        foreach ($l in @(Get-Content -Path $Progress -Encoding UTF8 -ErrorAction SilentlyContinue)) {
            if ($l -match ' INFO installed \d+ of \d+ in .*?: (KB\d+|update) (.+)$') { $done += @{ id = $null; kb = $(if ($Matches[1] -ne "update") { $Matches[1] } else { $null }); title = $Matches[2] }; $batchOpen = $false }
            elseif ($l -match ' ERROR FAILED \d+ of \d+ ') { $batchOpen = $false }
            elseif ($l -match ' INFO batch: ([0-9A-Fa-f,-]+) kbs: (.*)$') {
                $ids = $Matches[1].Split(","); $kbs = $Matches[2].Split(","); $batch = @(); $batchOpen = $true
                for ($q = 0; $q -lt $ids.Count; $q++) { $batch += @{ id = $ids[$q]; kb = $(if ($q -lt $kbs.Count -and $kbs[$q]) { $kbs[$q] } else { $null }); title = ("update " + $ids[$q]) } }
            }
        }
        Remove-Item $Progress -Force -ErrorAction SilentlyContinue
    }
    $pending = (Get-RebootState).Required
    if ($StillBusy) {
        # Windows is still installing: a restart now could damage the server. Not restarted; the
        # installed list so far is reported, and the server needs its restart once Windows finishes.
        # Only an update whose install started and has not ended is named (the last one may have finished)
        $busy = @(if ($batchOpen) { $batch })
        $busyKbs = @($busy | ForEach-Object { $(if ($_.kb) { $_.kb } else { $_.title }) })
        $what = $(if ($busyKbs.Count) { "Windows was still installing " + ($busyKbs -join ", ") } else { "Windows Update was still busy" })
        $note = $Why + "; " + $what + " at that moment, so the server was NOT restarted. " +
                "Let Windows finish, then restart it (Servers: Restart, admins) and check its updates"
        Set-StateValue "last_install" @{ at = (Get-IsoUtc); installed = $done; failed = @() }
        return @{ ok = $false; message = ($done.Count.ToString() + " installed so far; " + $note)
                  result = @{ nothing_to_do = $false; reboot_required = $true; installed = $done; failed = @(); still_installing = $busy
                              errors = @($note); warnings = @($note) } }
    }
    if ($batchOpen -and $pending) {
        # Stopped while a batch was installing and Windows now wants a restart: part or all of it went in.
        # Restart and let the check after it say exactly which ones are installed.
        $all = @($done + $batch)
        $note = $Why + " while installing " + $batch.Count + " update(s) together; Windows asks for a restart, so the server restarts and the check after it shows which are installed"
        Set-StateValue "last_install" @{ at = (Get-IsoUtc); installed = $all; failed = @() }
        return @{ ok = $true; message = $note
                  result = @{ nothing_to_do = $false; reboot_required = $true; installed = $all; failed = @(); errors = @(); warnings = @($note) } }
    }
    if ($done.Count -eq 0) {
        return @{ ok = $false; message = ($Why + ". Nothing was installed"); result = @{ reboot_required = $pending } }
    }
    $note = $Why + "; " + $done.Count + " update(s) installed before that, the rest were not"
    Set-StateValue "last_install" @{ at = (Get-IsoUtc); installed = $done; failed = @() }
    return @{ ok = $true; message = ($done.Count.ToString() + " installed; " + $note)
              result = @{ nothing_to_do = $false; reboot_required = $true; installed = $done; failed = @(); errors = @(); warnings = @($note) } }
}

function Invoke-Reboot($Params) {
    $delay = [int](Get-Prop $Params "delay_seconds"); if ($delay -lt 30) { $delay = 60 }
    # Scheduled, not immediate, so this result reaches PATCH-01 first
    & shutdown.exe /r /t $delay /d p:2:17 /c "PATCH-01 patch job: restarting to complete updates" | Out-Null
    $code = $LASTEXITCODE
    # 1190: a restart is already scheduled, which is what this step wants
    if ($code -eq 1190) { return @{ ok = $true; message = "a restart was already scheduled"; result = @{ delay_seconds = $delay } } }
    return @{ ok = ($code -eq 0); message = $(if ($code -eq 0) { "restart in $delay seconds" } else { "shutdown.exe refused the restart (code " + $code + ")" }); result = @{ delay_seconds = $delay } }
}

function Test-UpdatesInstalled($Updates) {
    <# For each update this job installed: is it installed now (after the
       restart)? From the installed hotfix list (KBs, what servicing really
       has) and Windows Update's own history; no WSUS search, so seconds. A
       history "succeeded" is trusted only when the KB is not a hotfix-listed
       package that has gone missing (rolled back). #>
    $hot = @(Get-HotFix -ErrorAction SilentlyContinue | ForEach-Object { ([string]$_.HotFixID).ToUpperInvariant() })
    $hist = @{}
    try {
        $s = New-Object -ComObject Microsoft.Update.Session
        $h = $s.CreateUpdateSearcher()
        $n = [int]$h.GetTotalHistoryCount()
        if ($n -gt 0) {
            foreach ($e in $h.QueryHistory(0, [math]::Min($n, 300))) {
                $id = [string]$e.UpdateIdentity.UpdateID
                if ($id -and -not $hist.ContainsKey($id)) { $hist[$id] = [int]$e.ResultCode }   # newest first
            }
        }
    } catch { Write-Log ("Windows Update history could not be read: " + $_.Exception.Message + "; using the installed hotfix list") "WARN" }
    $yes = @(); $no = @()
    foreach ($x in $Updates) {
        $id = [string](Get-Prop $x "id"); $kb = [string](Get-Prop $x "kb")
        $title = [string](Get-Prop $x "title")
        $inHot = ($kb -and ($hot -contains $kb.ToUpperInvariant()))
        $okHist = ($id -and $hist.ContainsKey($id) -and (@(2, 3) -contains $hist[$id]))
        # Cumulative and servicing stack updates are packages: they must be in the hotfix list
        # (.NET cumulative updates are listed in the hotfix list under other KBs: history decides for them)
        $package = ($title -notmatch '\.NET') -and ($title -match 'Cumulative Update for (Windows|Microsoft server operating system)|Servicing Stack|Security Monthly Quality Rollup|Security Only')
        $installed = $inHot -or ($okHist -and -not $package)
        $label = $(if ($kb) { $kb } else { $title })
        if ($installed) { $yes += $label } else { $no += $label }
    }
    return @{ installed = $yes; not_installed = $no }
}

function Invoke-Postcheck($Params) {
    <# After installing (and the reboot):
       - the job's updates are checked one by one: still not installed is reported;
       - the services that were running before are running again. Late starters
         are waited for; any still down is started once. A service that does
         not start is reported, but it is not a failed patch. #>
    $os = Get-CimInstance Win32_OperatingSystem
    $upMin = [int]((Get-Date) - $os.LastBootUpTime).TotalMinutes
    $warnings = @(); $errors = @()

    # 1. Services: wait for delayed starts after a fresh boot, then start what is still down
    $base = @(@(Get-Prop $Params "baseline_services") | Where-Object { $_ } | ForEach-Object { [string]$_ } | Where-Object { -not (Test-StopsByDesign $_) })
    $waitMin = $(if ($upMin -lt 15) { [math]::Min(8, 15 - $upMin) } else { 1 })
    $until = (Get-Date).AddMinutes($waitMin)
    do {
        $now = @(Get-CimInstance Win32_Service -Filter "State='Running'" | ForEach-Object { [string]$_.Name })
        $missing = @($base | Where-Object { $now -notcontains $_ })
        if ($missing.Count -eq 0) { break }
        Start-Sleep -Seconds 20
    } while ((Get-Date) -lt $until)
    $restarted = @(); $down = @()
    $startBy = (Get-Date).AddMinutes(6)
    foreach ($name in $missing) {
        $svc = Get-Service -Name $name -ErrorAction SilentlyContinue
        if (-not $svc) { $down += $name; continue }
        if ([string]$svc.StartType -eq "Disabled" -or (Get-Date) -gt $startBy) { $down += $name; continue }
        try {
            # Start() returns at once; Start-Service would wait for ever on a service stuck "starting"
            $svc.Start()
            $svc.WaitForStatus("Running", (New-TimeSpan -Seconds 60))
            $restarted += $name; Write-Log ("service " + $name + " was not running after the change: started it") "WARN"
        } catch {
            $down += $name; Write-Log ("service " + $name + " is not running and did not start: " + $_.Exception.Message) "WARN"
        }
    }

    # 2. The job's updates, installed now?
    $updates = @(@(Get-Prop $Params "windows_installed") | Where-Object { $_ })
    if ($updates.Count -eq 0) {
        # Older PATCH-01: what this agent installed for the job, if it was recent
        $st = Get-State
        if ($st.PSObject.Properties["last_install"] -and $st.last_install) {
            $at = $null; try { $at = [datetime]$st.last_install.at } catch { }
            if ($at -and ((Get-Date).ToUniversalTime() - $at.ToUniversalTime()).TotalHours -lt 12) { $updates = @(@($st.last_install.installed) | Where-Object { $_ }) }
        }
    }
    $check = @{ installed = @(); not_installed = @() }
    if ($updates.Count -gt 0) {
        $check = Test-UpdatesInstalled $updates
        Write-Log ("after the change: " + $check.installed.Count + " of " + $updates.Count + " update(s) installed" +
                   $(if ($check.not_installed.Count) { "; NOT installed: " + ($check.not_installed -join ", ") } else { "" }))
        if ($check.not_installed.Count -gt 0 -and $check.installed.Count -eq 0) {
            $errors += ("none of the job's updates is installed after the reboot (Windows may have rolled them back): " + ($check.not_installed -join ", "))
        } elseif ($check.not_installed.Count -gt 0) {
            $warnings += ("not installed after the reboot: " + ($check.not_installed -join ", "))
        }
    }
    $r = Get-RebootState
    if ($r.Required) { $warnings += ("Windows still reports a reboot pending (" + $r.Reason + "); another restart is needed") }
    if ($restarted.Count) { $warnings += ("started again after the change: " + ($restarted -join ", ")) }
    $build = (Get-Build).Build
    $res = @{ missing_services = $down; restarted_services = $restarted; updates_installed = $check.installed
              updates_not_installed = $check.not_installed; warnings = $warnings; build = $build; uptime_minutes = $upMin }
    if ($errors.Count) {
        $res.errors = $errors
        return @{ ok = $false; result = $res; message = ($errors -join "; ") }
    }
    if ($down.Count) {
        # Patched; only services are down. Reported in the form PATCH-01 shows as
        # "done, with warnings": a service is for the operator to start, not a failed patch.
        $res.errors = @("not running any more: " + ($down -join ", "))
        return @{ ok = $false; result = $res; message = ("patched, build " + $build + "; services not running: " + ($down -join ", ")) }
    }
    $res.errors = @()
    return @{ ok = $true; result = $res
              message = ("postcheck passed, build " + $build + $(if ($warnings.Count) { "; " + ($warnings -join "; ") } else { "" })) }
}

# ---------------------------------------------------------------------------
# Software from the catalog: install, upgrade or remove one approved installer
# ---------------------------------------------------------------------------
$SwUnc = '^\\\\([A-Za-z0-9][A-Za-z0-9.-]{0,252})\\([A-Za-z0-9$_.-]{1,80})((\\[A-Za-z0-9 _.()+-]{1,120}){1,12})$'
$SwArgs = '^[A-Za-z0-9 /\\_.:=,+()\-"]{0,300}$'
$SwGuid = '^\{[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}$'

function Get-InstalledProgram([string]$Name) {
    # Programs and Features entries whose name is, or starts with, the catalog's name
    $hits = @()
    foreach ($root in @("HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
                        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*")) {
        foreach ($e in @(Get-ItemProperty -Path $root -ErrorAction SilentlyContinue)) {
            $dn = [string](Get-Prop $e "DisplayName")
            if ($dn -and ($dn -eq $Name -or $dn.StartsWith($Name, [StringComparison]::OrdinalIgnoreCase))) {
                $hits += [pscustomobject]@{ Name = $dn; Version = [string](Get-Prop $e "DisplayVersion"); Key = [string]$e.PSChildName
                                            Uninstall = [string](Get-Prop $e "UninstallString"); Quiet = [string](Get-Prop $e "QuietUninstallString") }
            }
        }
    }
    return ,$hits
}

function Test-VersionMatch([string]$Have, [string]$Want) {
    if (-not $Have) { return $false }
    if ($Have -eq $Want) { return $true }
    # 23.01 and 23.01.00.0 are the same release
    return ($Have.StartsWith($Want + ".") -or $Want.StartsWith($Have + "."))
}

function Get-ShareCredential($Token, [string]$CommandId) {
    $r = Invoke-Api "GET" ("/api/v1/agent/commands/" + $CommandId + "/credential") $null $Token
    $sec = ConvertTo-SecureString ([string]$r.password) -AsPlainText -Force
    $r.password = $null
    return New-Object Management.Automation.PSCredential([string]$r.username, $sec)
}

# ---------------------------------------------------------------------------
# Packages uploaded to PATCH-01 (Deployment): downloaded by the agent itself
# ---------------------------------------------------------------------------
$PkgIdRe = '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
$PkgNameRe = '^[A-Za-z0-9][A-Za-z0-9 ._()+,-]{0,118}\.(msi|exe)$'

function Protect-Folder([string]$Path) {
    # Only SYSTEM and Administrators: nobody else can swap the file between its check and its run
    $acl = New-Object Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sid in @("S-1-5-18", "S-1-5-32-544")) {
        $id = New-Object Security.Principal.SecurityIdentifier($sid)
        $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($id, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")))
    }
    $acl.SetOwner((New-Object Security.Principal.SecurityIdentifier("S-1-5-32-544")))
    Set-Acl -LiteralPath $Path -AclObject $acl
}

function Test-Reparse([string]$Path) {
    $it = Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
    return ($it -and (($it.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0))
}

function Select-PackageFolder([long]$Size) {
    <# C:\tmp\PATCH01, or D:\tmp\PATCH01 when C: has too little room: the drive
       needs the file twice over (installers unpack themselves) plus 1 GB.
       \tmp is created when missing; PATCH01 inside it is locked down. #>
    $need = [double]$Size * 2 + 1GB
    $why = @()
    foreach ($d in @("C:", "D:")) {
        $disk = Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='" + $d + "'") -ErrorAction SilentlyContinue
        if (-not $disk) { $why += ($d + " does not exist"); continue }
        if ([int]$disk.DriveType -ne 3) { $why += ($d + " is not a local disk"); continue }
        if ([double]$disk.FreeSpace -lt $need) { $why += ($d + " has " + (Format-Gb ([double]$disk.FreeSpace / 1GB)) + " free, " + (Format-Gb ($need / 1GB)) + " needed"); continue }
        $tmp = $d + "\tmp"
        if (Test-Reparse $tmp) { $why += ($tmp + " is a link to somewhere else; not used"); continue }
        $created = $false
        if (-not (Test-Path -LiteralPath $tmp)) {
            New-Item -ItemType Directory -Path $tmp -Force | Out-Null
            # Made here, so it is made private: a folder at a drive's root inherits "users may change" rights,
            # and whoever can change \tmp can rename the package folder inside it and swap the installer
            Protect-Folder $tmp
            $created = $true
            Write-Log ("created " + $tmp)
        } elseif (-not (Test-AdminOnly $tmp -Only)) {
            # An existing \tmp that ordinary users can change (or own) is not used for an installer run as SYSTEM:
            # a private folder of the agent's own instead
            $tmp = $d + "\PATCH01-Packages"
            if (Test-Reparse $tmp) { $why += ($tmp + " is a link to somewhere else; not used"); continue }
            if (-not (Test-Path -LiteralPath $tmp)) { New-Item -ItemType Directory -Path $tmp -Force | Out-Null; Protect-Folder $tmp; $created = $true }
            elseif (-not (Test-AdminOnly $tmp -Only)) { $why += ($d + "\tmp and " + $tmp + " can be changed by users other than administrators; not used"); continue }
            Write-Log ($d + "\tmp can be changed by users other than administrators: using " + $tmp + " instead") "WARN"
        }
        $dir = Join-Path $tmp "PATCH01"
        if (Test-Reparse $dir) { [IO.Directory]::Delete($dir); Write-Log ("removed a link at " + $dir + " (a folder is made instead)") "WARN" }
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        Protect-Folder $dir
        return @{ dir = $dir; drive = $d; created = $created }
    }
    throw ("no room for the package: " + ($why -join "; "))
}

function Receive-PackagePiece([string]$Url, [string]$Bearer, [IO.Stream]$Out, [long]$Expect) {
    # One piece over the pinned HTTPS connection (the certificate check is set for the whole process)
    $req = [Net.HttpWebRequest]::Create($Url)
    $req.Method = "GET"; $req.Timeout = 120000; $req.ReadWriteTimeout = 120000; $req.Proxy = $null
    $req.UserAgent = "patch-agent/" + $AgentVersion
    $req.Headers["Authorization"] = "Bearer " + $Bearer
    try { $resp = $req.GetResponse() }
    catch {
        # Windows PowerShell 5.1 wraps the WebException in a MethodInvocationException: find it
        $ex = $_.Exception
        while ($ex -and -not ($ex -is [Net.WebException]) -and $ex.InnerException) { $ex = $ex.InnerException }
        $m = [string]$ex.Message
        $r = $null
        if ($ex -is [Net.WebException] -and $ex.PSObject.Properties["Response"]) { $r = $ex.Response }
        if ($r) {
            try { $sr = New-Object IO.StreamReader($r.GetResponseStream()); $m = "HTTP " + [int]$r.StatusCode + ": " + $sr.ReadToEnd() } catch { }
            try { $r.Close() } catch { }
        }
        if ([PatchAgentPin]::Seen -and [PatchAgentPin]::Pin -ne "system" -and ([PatchAgentPin]::Pin.Split(",") -notcontains [PatchAgentPin]::Seen)) {
            $m = "PATCH-01's certificate does not match the pin. It presented " + [PatchAgentPin]::Seen
        }
        throw $m
    }
    try {
        $s = $resp.GetResponseStream()
        $buf = New-Object byte[] 262144
        $total = [long]0
        while ($true) {
            $n = $s.Read($buf, 0, $buf.Length)
            if ($n -le 0) { break }
            $total += $n
            if ($total -gt $Expect) { throw "PATCH-01 sent more data than asked for" }
            $Out.Write($buf, 0, $n)
        }
        $Out.Flush()
        return $total
    } finally { $resp.Close() }
}

function Get-PackageFile($Params, $Token, [int]$MaxMinutes = 90) {
    $size = [long](Get-Prop $Params "size"); $sha = [string](Get-Prop $Params "sha256")
    $name = [string](Get-Prop $Params "file_name"); $dl = [string](Get-Prop $Params "download")
    $chunk = [long](Get-Prop $Params "chunk_bytes"); if ($chunk -lt 1MB -or $chunk -gt 32MB) { $chunk = 16MB }
    $where = Select-PackageFolder $size
    $file = Join-Path $where.dir $name
    $part = $file + ".part"
    Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue
    $cfg = Get-Config
    Assert-Https ([string]$cfg.server)
    $base = ([string]$cfg.server).TrimEnd("/") + $dl
    Write-Log ("downloading " + $name + " (" + [math]::Round($size / 1MB, 1) + " MB) from PATCH-01 to " + $where.dir)
    $t0 = Get-Date; $got = [long]0; $nextLog = [long]64MB
    $fs = [IO.File]::Open($part, [IO.FileMode]::Create, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        while ($got -lt $size) {
            $len = [long][math]::Min($chunk, $size - $got)
            $ok = $false; $err = ""
            for ($try = 1; $try -le 4 -and -not $ok; $try++) {
                try {
                    $n = Receive-PackagePiece ($base + "?offset=" + $got + "&length=" + $len) $Token $fs $len
                    if ($n -ne $len) { throw ("received " + $n + " of " + $len + " bytes") }
                    $ok = $true
                } catch {
                    $err = [string]$_.Exception.Message
                    $fs.SetLength($got); $fs.Position = $got
                    if ($err -match '^HTTP 4\d\d') { break }            # refused: trying again will not help
                    Write-Log ("download piece at " + [int]($got / 1MB) + " MB failed (try " + $try + " of 4): " + $err) "WARN"
                    Start-Sleep -Seconds (5 * $try)
                }
            }
            if (-not $ok) { throw ("the download stopped at " + [int]($got / 1MB) + " of " + [int]($size / 1MB) + " MB: " + $err) }
            $got += $len
            if ($got -ge $nextLog -or $got -eq $size) {
                Write-Log ("downloaded " + [int]($got / 1MB) + " of " + [int]($size / 1MB) + " MB")
                if ($script:RunToken) { Send-LogTail $script:RunToken }
                $nextLog = $got + 64MB
            }
            if (((Get-Date) - $t0).TotalMinutes -gt $MaxMinutes) { throw ("the download took longer than " + $MaxMinutes + " minutes and was stopped") }
        }
    } finally { $fs.Dispose() }
    Move-Item -LiteralPath $part -Destination $file -Force
    # Held open (others may read, nobody may change, rename or delete it, nor its folder) from
    # the SHA-256 check until the installer has finished: what was checked is what runs
    $lock = [IO.File]::Open($file, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    try {
        $sha256 = [Security.Cryptography.SHA256]::Create()
        try { $hash = (([BitConverter]::ToString($sha256.ComputeHash($lock))) -replace "-", "").ToLowerInvariant() } finally { $sha256.Dispose() }
        $lock.Position = 0
    } catch { $lock.Dispose(); throw }
    if ($hash -ne $sha) {
        $lock.Dispose()
        Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue
        throw ("the downloaded file's SHA-256 is " + $hash + ", not the package's: it was deleted and nothing was run")
    }
    $secs = [math]::Max(1, [int]((Get-Date) - $t0).TotalSeconds)
    Write-Log ("download complete in " + $secs + " s; SHA-256 matches; the file is held unchangeable until the install ends")
    return @{ path = $file; drive = $where.drive; created = $where.created; seconds = $secs; mb = [math]::Round($size / 1MB, 1); lock = $lock }
}

function Get-MsiProperties([string]$Path) {
    # ProductName, ProductVersion, ProductCode, Manufacturer from the MSI itself (read only)
    $out = @{}
    $inst = $null; $db = $null
    try {
        $inst = New-Object -ComObject WindowsInstaller.Installer
        $db = $inst.GetType().InvokeMember("OpenDatabase", "InvokeMethod", $null, $inst, @($Path, 0))
        foreach ($p in @("ProductName", "ProductVersion", "ProductCode", "Manufacturer")) {
            # Single quotes keep the backticks MSI SQL uses around names (in double quotes PowerShell eats them)
            $q = 'SELECT `Value` FROM `Property` WHERE `Property`=' + "'" + $p + "'"
            $view = $db.GetType().InvokeMember("OpenView", "InvokeMethod", $null, $db, @($q))
            try {
                [void]$view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)
                $rec = $view.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $view, $null)
                if ($rec) { $out[$p] = [string]$rec.GetType().InvokeMember("StringData", "GetProperty", $null, $rec, 1) }
            } finally {
                try { [void]$view.GetType().InvokeMember("Close", "InvokeMethod", $null, $view, $null) } catch { }
                [void][Runtime.InteropServices.Marshal]::ReleaseComObject($view)
            }
        }
    } catch {
        Write-Log ("the MSI's properties could not be read: " + $_.Exception.Message) "WARN"
    } finally {
        if ($db) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($db) }
        if ($inst) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($inst) }
        [GC]::Collect(); [GC]::WaitForPendingFinalizers()
    }
    return $out
}

function Get-InstalledByCode([string]$Code) {
    # The Programs and Features entry an MSI writes under its own product code
    foreach ($root in @("HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\")) {
        $e = Get-ItemProperty -LiteralPath ($root + $Code) -ErrorAction SilentlyContinue
        if ($e) { return [pscustomobject]@{ Name = [string](Get-Prop $e "DisplayName"); Version = [string](Get-Prop $e "DisplayVersion"); Key = $Code; Uninstall = [string](Get-Prop $e "UninstallString"); Quiet = [string](Get-Prop $e "QuietUninstallString") } }
    }
    return $null
}

function Get-MsiLogExcerpt([string]$Path) {
    <# The lines around the first "Return value 3" (where an MSI really failed),
       else the end of the log: the part an administrator needs to read. #>
    if (-not (Test-Path -LiteralPath $Path)) { return "" }
    try {
        $lines = @(Get-Content -LiteralPath $Path -ErrorAction Stop)
        $i = -1
        for ($k = 0; $k -lt $lines.Count; $k++) { if ($lines[$k] -match 'Return value 3') { $i = $k; break } }
        if ($i -ge 0) { $from = [math]::Max(0, $i - 25); $sel = $lines[$from..([math]::Min($lines.Count - 1, $i + 2))] }
        else { $sel = $lines[([math]::Max(0, $lines.Count - 30))..($lines.Count - 1)] }
        $text = (@($sel | Where-Object { $_ -and $_.Trim() }) -join "`n")
        if ($text.Length -gt 4000) { $text = $text.Substring($text.Length - 4000) }
        return $text
    } catch { return "" }
}

$InstallerCodes = @{
    1602 = "the installation was cancelled"; 1603 = "a fatal error during installation"
    1618 = "another installation is already in progress"; 1619 = "the installation package could not be opened"
    1625 = "the installation is forbidden by system policy"; 1633 = "this package is not supported on this processor type"
    1638 = "another version of this product is already installed"; 1639 = "the command-line options are not valid"
    1641 = "the installer started a restart"; 3010 = "a restart is needed to complete it"
}

# ---------------------------------------------------------------------------
# Deployment packages (agent 1.7.0): install, upgrade or remove, version-aware;
# portable programs are copied, never run
# ---------------------------------------------------------------------------
$PkgFolderRe = '^[A-Za-z0-9][A-Za-z0-9 ._()+-]{0,59}$'

function Compare-Version([string]$A, [string]$B) {
    # -1, 0 or 1 (A older, same, newer than B), on up to four numbers; $null when either has none
    $pa = @([regex]::Matches([string]$A, '\d{1,9}') | Select-Object -First 4 | ForEach-Object { [long]$_.Value })
    $pb = @([regex]::Matches([string]$B, '\d{1,9}') | Select-Object -First 4 | ForEach-Object { [long]$_.Value })
    if ($pa.Count -eq 0 -or $pb.Count -eq 0) { return $null }
    for ($i = 0; $i -lt 4; $i++) {
        $x = [long]0; if ($i -lt $pa.Count) { $x = $pa[$i] }
        $y = [long]0; if ($i -lt $pb.Count) { $y = $pb[$i] }
        if ($x -lt $y) { return -1 }
        if ($x -gt $y) { return 1 }
    }
    return 0
}

function Get-RelatedProducts([string]$UpgradeCode) {
    # Product codes installed for an MSI upgrade code (every version of the same product)
    $out = @()
    if ($UpgradeCode -notmatch $SwGuid) { return ,$out }
    $inst = $null
    try {
        $inst = New-Object -ComObject WindowsInstaller.Installer
        $list = $inst.GetType().InvokeMember("RelatedProducts", "GetProperty", $null, $inst, @($UpgradeCode))
        foreach ($c in $list) { if ([string]$c -match $SwGuid) { $out += [string]$c } }
    } catch { Write-Log ("installed products for upgrade code " + $UpgradeCode + " could not be read: " + $_.Exception.Message) "WARN" }
    finally { if ($inst) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($inst) } }
    return ,$out
}

function Get-PackageInstalled($P) {
    <# What is installed of this package now: by MSI product code, by MSI upgrade code
       (other versions of the same product), by name in Programs and Features, or for a
       portable program its file in Program Files\PATCH01-Apps. Newest first. #>
    $found = @()
    $P.ambiguous = $null
    if ($P.mode -eq "portable") {
        # The folder is the program's: its marker says which package and version put it there
        $m = Get-PortableMarker $P.app_dir
        if ($m) {
            $v = [string](Get-Prop $m "version")
            $exe = Join-Path $P.app_dir ([string](Get-Prop $m "file"))
            if (Test-Path -LiteralPath $exe) {
                $vi = (Get-Item -LiteralPath $exe).VersionInfo
                if ([string]$vi.ProductVersion -match '\d') { $v = [string]$vi.ProductVersion }
            }
            $found += [pscustomobject]@{ Name = [string](Get-Prop $m "name"); Version = $v; Key = ""; Uninstall = ""; Quiet = ""; Path = $exe }
        } elseif (Test-Path -LiteralPath $P.app_file) {
            $vi = (Get-Item -LiteralPath $P.app_file).VersionInfo
            $v = [string]$vi.ProductVersion; if (-not $v) { $v = [string]$vi.FileVersion }
            $found += [pscustomobject]@{ Name = $P.name; Version = $v; Key = ""; Uninstall = ""; Quiet = ""; Path = $P.app_file }
        }
        return ,$found
    }
    # An MSI is identified by its codes: the upgrade code finds every version of the same product.
    # A name is used only without them (or with only this version's product code and nothing found)
    $codes = @()
    if ($P.pcode) { $codes += $P.pcode }
    if ($P.ucode) { $codes += Get-RelatedProducts $P.ucode }
    foreach ($c in @($codes | Select-Object -Unique)) {
        $e = Get-InstalledByCode $c
        if ($e) { $found += $e }
    }
    if ($P.detect -and -not $P.ucode -and $found.Count -eq 0) {
        $byName = Get-InstalledProgram $P.detect
        # The exact name wins; several different programs that only start with it are not guessed between
        $exact = @($byName | Where-Object { $_.Name -eq $P.detect })
        if ($exact.Count -gt 0) { $byName = $exact }
        $names = @($byName | ForEach-Object { $_.Name } | Select-Object -Unique)
        if ($names.Count -gt 1) {
            $P.ambiguous = ($names.Count.ToString() + " different programs start with '" + $P.detect + "' (" + (($names | Select-Object -First 4) -join "; ") +
                            "): set the exact name in Programs and Features on the package")
            return ,@()
        }
        foreach ($e in $byName) { if (@($found | Where-Object { $_.Key -eq $e.Key }).Count -eq 0) { $found += $e } }
    }
    $sorted = @($found | Sort-Object -Property @{ Expression = { $v = $_.Version; $n = @([regex]::Matches([string]$v, '\d{1,9}') | Select-Object -First 4 | ForEach-Object { '{0:D9}' -f [long]$_.Value }); ($n + @('000000000') * 4)[0..3] -join '.' } } -Descending)
    return ,$sorted
}

function Stop-ProcessTree([int]$Id, $Since = $null) {
    # Only children started after their parent: Windows keeps a dead parent's id on old processes
    $me = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $Id) -ErrorAction SilentlyContinue
    $born = $Since; if ($me -and $me.CreationDate) { $born = $me.CreationDate }
    foreach ($k in @(Get-CimInstance Win32_Process -Filter ("ParentProcessId=" + $Id) -ErrorAction SilentlyContinue)) {
        if ($born -and $k.CreationDate -and $k.CreationDate -lt $born) { continue }
        Stop-ProcessTree ([int]$k.ProcessId) $born
    }
    Stop-Process -Id $Id -Force -ErrorAction SilentlyContinue
}

function Invoke-Installer([string]$Exe, [string]$ArgLine, [datetime]$Since, [int]$LimitMinutes, [string]$What) {
    <# Runs an installer or uninstaller (never through cmd) and waits, at most the package's
       time limit and never past PATCH-01's limit for the step. A hung one (waiting for a
       click, or a program that is not an installer at all) is stopped with all it started. #>
    $code = $null
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        $budget = [math]::Min([double]$LimitMinutes * 60000, 10200000 - ((Get-Date) - $Since).TotalMilliseconds)
        if ($budget -lt 60000) { $budget = 60000 }
        $sp = @{ FilePath = $Exe; PassThru = $true; WindowStyle = "Hidden" }
        if ($ArgLine) { $sp["ArgumentList"] = $ArgLine }
        $p = Start-Process @sp
        $null = $p.Handle          # PowerShell 5.1 loses the exit code of a -PassThru process unless its handle is held
        if (-not $p.WaitForExit([int]$budget)) {
            Stop-ProcessTree $p.Id
            return @{ timeout = $true; minutes = [int]($budget / 60000); code = $null }
        }
        $p.WaitForExit()
        $code = $p.ExitCode
        if ($null -eq $code) { return @{ timeout = $false; code = $null } }
        $code = [int]$code
        if ($code -ne 1618 -or $attempt -eq 3) { break }
        Write-Log ("another installation is in progress (1618): waiting 2 minutes, then trying again (" + $attempt + " of 2)") "WARN"
        if ($script:RunToken) { Send-LogTail $script:RunToken }
        Start-Sleep -Seconds 120
    }
    Write-Log ($What + " finished with code " + $code + $(if ($InstallerCodes.ContainsKey($code)) { " (" + $InstallerCodes[$code] + ")" } else { "" }))
    return @{ timeout = $false; code = $code }
}

function Get-UninstallCommand($Entry, [string]$Kind, [string]$UArgs, [string]$Log) {
    # How to remove one installed entry silently: @{ exe; args; how } or @{ why }
    $u = [string](Get-Prop $Entry "Uninstall"); $key = [string](Get-Prop $Entry "Key")
    $isMsi = ($key -match $SwGuid) -and ($u -match '(?i)msiexec' -or -not $u)
    if ($Kind -eq "msi" -or $isMsi) {
        if ($key -notmatch $SwGuid) { return @{ why = "its MSI product code was not found in Programs and Features" } }
        return @{ exe = (Join-Path $env:SystemRoot "System32\msiexec.exe"); args = ("/x " + $key + " /qn /norestart /l*v `"" + $Log + "`""); how = "msiexec /x" }
    }
    $q = [string](Get-Prop $Entry "Quiet")
    foreach ($cand in @(@{ s = $q; quiet = $true }, @{ s = $u; quiet = $false })) {
        $s = [string]$cand.s
        if (-not $s) { continue }
        if ($s -match '^\s*"([^"]+\.exe)"\s*(.*)$') { $exe = $Matches[1]; $rest = $Matches[2] }
        elseif ($s -match '^\s*(.+?\.exe)\s*(.*)$') { $exe = $Matches[1]; $rest = $Matches[2] }
        else { continue }
        if ((Split-Path -Leaf $exe) -ieq "msiexec.exe") {
            if ($key -match $SwGuid) { return @{ exe = (Join-Path $env:SystemRoot "System32\msiexec.exe"); args = ("/x " + $key + " /qn /norestart /l*v `"" + $Log + "`""); how = "msiexec /x" } }
            continue
        }
        if (-not (Test-Path -LiteralPath $exe)) { continue }
        if (-not (Test-AdminOnly $exe)) { return @{ why = ("its uninstaller " + $exe + " is in a folder that users other than administrators can change: not run as SYSTEM") } }
        if ($cand.quiet) { return @{ exe = $exe; args = $rest.Trim(); how = "its own quiet uninstall command" } }
        $leaf = Split-Path -Leaf $exe
        if ($UArgs) { return @{ exe = $exe; args = ($rest.Trim() + " " + $UArgs).Trim(); how = "its uninstaller with the package's silent options" } }
        if ($leaf -match '^(?i)unins\d{3}\.exe$') { return @{ exe = $exe; args = ($rest.Trim() + " /VERYSILENT /SUPPRESSMSGBOXES /NORESTART").Trim(); how = "its Inno Setup uninstaller, silent" } }
        if ($leaf -match '^(?i)(uninst|uninstall|uninstaller)\.exe$') { return @{ exe = $exe; args = ($rest.Trim() + " /S").Trim(); how = "its NSIS-style uninstaller, silent (/S)" } }
        return @{ why = ("its uninstaller " + $leaf + " has no known silent options: set 'silent uninstall options' on the package") }
    }
    return @{ why = "no uninstall command is registered for it" }
}

function Test-EntryPresent($Entry) {
    $key = [string](Get-Prop $Entry "Key")
    if ($key -match $SwGuid) { return [bool](Get-InstalledByCode $key) }
    $hits = Get-InstalledProgram ([string]$Entry.Name)      # assigned first: piped, the list would arrive as one item
    return (@($hits | Where-Object { $_.Key -eq $key }).Count -gt 0)
}

function Wait-Gone($Entries, [int]$Seconds) {
    # Some uninstallers hand over to a copy of themselves and return at once: wait until the
    # entries that were removed (only those) are gone from Programs and Features
    $t0 = Get-Date
    while ($true) {
        $left = @($Entries | Where-Object { Test-EntryPresent $_ })
        if ($left.Count -eq 0) { return $true }
        if (((Get-Date) - $t0).TotalSeconds -ge $Seconds) { return $false }
        Start-Sleep -Seconds 5
    }
}

function Get-PortableMarker([string]$Dir) {
    if (-not $Dir) { return $null }
    $f = Join-Path $Dir ".patch01-package.json"
    if (-not (Test-Path -LiteralPath $f)) { return $null }
    try { return (Get-Content -Raw -LiteralPath $f | ConvertFrom-Json) } catch { return $null }
}

function Test-NoLinks([string]$Dir) {
    # A folder to delete must hold no links (Windows PowerShell 5.1 follows them when deleting)
    if (Test-Reparse $Dir) { return $false }
    $links = @(Get-ChildItem -LiteralPath $Dir -Recurse -Force -Attributes ReparsePoint -ErrorAction SilentlyContinue)
    return ($links.Count -eq 0)
}

function Test-LocalAdminSid([string]$Sid) {
    <# An account in this server's Administrators group (an admin who installed the program owns
       its files): looked up once per run. #>
    if ($null -eq $script:LocalAdminSids) {
        $script:LocalAdminSids = @()
        try { $script:LocalAdminSids = @(Get-LocalGroupMember -SID "S-1-5-32-544" -ErrorAction Stop | ForEach-Object { [string]$_.SID.Value }) } catch { }
    }
    return ($script:LocalAdminSids -contains $Sid)
}

function Test-AdminOnly([string]$Path, [switch]$Only) {
    <# True when only SYSTEM, Administrators and TrustedInstaller (and the owner/creator) can change
       this file or its folder: an uninstaller run as SYSTEM from a folder ordinary users can write
       to would let them run anything as SYSTEM. #>
    $admins = @("S-1-5-18", "S-1-5-32-544", "S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464", "S-1-3-0")
    $write = [Security.AccessControl.FileSystemRights]"Write, Modify, FullControl, CreateFiles, AppendData, Delete, DeleteSubdirectoriesAndFiles, ChangePermissions, TakeOwnership, WriteData"
    $check = $(if ($Only) { @($Path) } else { @($Path, (Split-Path -Parent $Path)) })
    foreach ($p in $check) {
        try { $acl = Get-Acl -LiteralPath $p } catch { return $false }
        # The owner can always change the permissions: it must be one of these too
        try { $own = (New-Object Security.Principal.NTAccount($acl.Owner)).Translate([Security.Principal.SecurityIdentifier]).Value } catch { return $false }
        if (($admins | Where-Object { $_ -ne "S-1-3-0" }) -notcontains $own -and -not (Test-LocalAdminSid $own)) { return $false }
        foreach ($r in $acl.Access) {
            if ([string]$r.AccessControlType -ne "Allow") { continue }
            if (($r.FileSystemRights -band $write) -eq 0) { continue }
            try { $sid = $r.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value } catch { return $false }
            if ($admins -notcontains $sid) { return $false }
        }
    }
    return $true
}

function Invoke-PackageAction($Params, $Token, [string]$CommandId) {
    $action = [string](Get-Prop $Params "action"); $kind = [string](Get-Prop $Params "kind")
    $mode = [string](Get-Prop $Params "install_mode"); if (-not $mode) { $mode = "installer" }
    $want = [string](Get-Prop $Params "sha256"); $ver = [string](Get-Prop $Params "version")
    $name = [string](Get-Prop $Params "name"); $file = [string](Get-Prop $Params "file_name")
    $limit = [int](Get-Prop $Params "timeout_minutes"); if ($limit -lt 5 -or $limit -gt 160) { $limit = 30 }
    $P = @{ mode = $mode; name = $name; detect = [string](Get-Prop $Params "detect_name")
            pcode = [string](Get-Prop $Params "product_code"); ucode = [string](Get-Prop $Params "upgrade_code"); app_file = $null; app_dir = $null; ambiguous = $null }
    $iargs = [string](Get-Prop $Params "install_args"); $uargs = [string](Get-Prop $Params "uninstall_args")
    $folder = [string](Get-Prop $Params "app_folder")
    $res = @{ action = $action; before = $null; reboot_required = $false; nothing_to_do = $false; warnings = @(); mode = $mode }
    # Check again here what PATCH-01 sent: nothing reaches a command line unchecked
    if ($action -notin @("install", "upgrade", "uninstall")) { return @{ ok = $false; message = "unknown action"; result = $res } }
    if ($kind -notin @("msi", "exe") -or $mode -notin @("installer", "portable") -or ($mode -eq "portable" -and $kind -ne "exe")) { return @{ ok = $false; message = "unknown package type"; result = $res } }
    if ([string](Get-Prop $Params "package_id") -notmatch $PkgIdRe -or [string](Get-Prop $Params "download") -ne ("/api/v1/agent/packages/" + [string](Get-Prop $Params "package_id") + "/file")) { return @{ ok = $false; message = "the package id or download address was refused"; result = $res } }
    if ($file -notmatch $PkgNameRe -or -not $file.ToLowerInvariant().EndsWith("." + $kind)) { return @{ ok = $false; message = "the package's file name was refused"; result = $res } }
    if ($want -notmatch '^[0-9a-f]{64}$' -or [long](Get-Prop $Params "size") -le 0) { return @{ ok = $false; message = "the package's SHA-256 or size was refused"; result = $res } }
    if (($P.pcode -and $P.pcode -notmatch $SwGuid) -or ($P.ucode -and $P.ucode -notmatch $SwGuid)) { return @{ ok = $false; message = "the MSI codes were refused"; result = $res } }
    if ($iargs -notmatch $SwArgs -or $uargs -notmatch $SwArgs) { return @{ ok = $false; message = "the installer options were refused"; result = $res } }
    if ($mode -eq "installer" -and $kind -eq "exe" -and $action -ne "uninstall" -and -not $iargs) { return @{ ok = $false; message = "no silent install options for this EXE"; result = $res } }
    if ($mode -eq "portable") {
        if ($folder -notmatch $PkgFolderRe -or $folder.Contains("..")) { return @{ ok = $false; message = "the program's folder name was refused"; result = $res } }
        $appRoot = Join-Path $env:ProgramFiles "PATCH01-Apps"
        $P.app_dir = Join-Path $appRoot $folder
        $P.app_file = Join-Path $P.app_dir $file
    }
    if (-not $P.detect -and -not $P.pcode -and -not $P.ucode -and $mode -ne "portable") { $P.detect = $name }

    $actStart = Get-Date
    $log = Join-Path $DataDir ("pkg-" + ($CommandId -replace '[^0-9a-f-]', '') + ".log")
    Get-ChildItem -Path $DataDir -Filter "pkg-*.log" -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-30) } |
        Remove-Item -Force -ErrorAction SilentlyContinue
    $rb = Get-RebootState
    if ($rb.Required) { $res.warnings += ("a restart was already pending before this (" + $rb.Reason + ")") }

    # 1. What is here now decides what to do
    $now = Get-PackageInstalled $P
    if ($P.ambiguous) { return @{ ok = $false; message = ("nothing was changed: " + $P.ambiguous); result = $res } }
    $have = $null; if ($now.Count -gt 0) { $have = [string]$now[0].Version; $res.before = $have }
    $cmp = $null; if ($have) { $cmp = Compare-Version $have $ver }
    $label = $(if ($now.Count -gt 0) { [string]$now[0].Name + " " + $have } else { "" })
    Write-Log ($action + " " + $name + " " + $ver + ": installed here now: " + $(if ($label) { $label } else { "nothing" }))
    if ($action -eq "uninstall") {
        if ($now.Count -eq 0) { $res.nothing_to_do = $true; return @{ ok = $true; message = ("not installed: nothing to remove"); result = $res } }
    } elseif ($now.Count -gt 0) {
        $same = ($cmp -eq 0) -or ($null -eq $cmp -and (Test-VersionMatch $have $ver))
        if ($same) { $res.nothing_to_do = $true; return @{ ok = $true; message = ("already installed: " + $label); result = $res } }
        if ($cmp -eq 1) { $res.nothing_to_do = $true; return @{ ok = $true; message = ("a newer version is installed (" + $label + "): left as it is"); result = $res } }
    } elseif ($action -eq "upgrade") {
        $res.nothing_to_do = $true
        return @{ ok = $true; message = ("not installed here, so nothing to upgrade (" + $(if ($P.detect) { $P.detect } else { $name }) + ")"); result = $res }
    }

    # 2. Remove
    if ($action -eq "uninstall") {
        if ($mode -eq "portable") {
            $appRoot = Split-Path -Parent $P.app_dir
            if ((Test-Reparse $appRoot) -or -not (Test-NoLinks $P.app_dir)) { return @{ ok = $false; message = ($P.app_dir + " is, or holds, a link: not removed"); result = $res } }
            $mk = Get-PortableMarker $P.app_dir
            if ($mk -and [string](Get-Prop $mk "name") -ne $name) { return @{ ok = $false; message = ($P.app_dir + " belongs to " + [string](Get-Prop $mk "name") + ", not " + $name + ": not removed"); result = $res } }
            if ($mk) { $P.app_file = Join-Path $P.app_dir ([string](Get-Prop $mk "file")) }
            $running = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $P.app_file } catch { $false } })
            if ($running.Count -gt 0) { return @{ ok = $false; message = ($file + " is running (process " + $running[0].Id + "): close it, then remove it again"); result = $res } }
            try { Remove-Item -LiteralPath $P.app_dir -Recurse -Force -ErrorAction Stop }
            catch { return @{ ok = $false; message = ("could not remove " + $P.app_dir + ": " + $_.Exception.Message); result = $res } }
            return @{ ok = $true; message = ("removed " + $P.app_dir); result = $res }
        }
        foreach ($e in $now) {
            $c = Get-UninstallCommand $e $kind $uargs $log
            if (Get-Prop $c "why") { return @{ ok = $false; message = ("could not remove " + $e.Name + ": " + $c.why); result = $res } }
            Write-Log ("removing " + $e.Name + " " + $e.Version + " with " + $c.how)
            $r = Invoke-Installer $c.exe $c.args $actStart $limit ("uninstall of " + $e.Name)
            if ($r.timeout) { return @{ ok = $false; message = ("the uninstaller did not finish within " + $r.minutes + " minutes and was stopped: it is probably waiting for a click (its options are not silent)"); result = $res } }
            $res.exit_code = $r.code
            if ($r.code -eq 3010 -or $r.code -eq 1641) { $res.reboot_required = $true }
            elseif ($null -eq $r.code -or ($r.code -ne 0 -and $r.code -ne 1605)) {
                if ($c.how -eq "msiexec /x") { $res.log_excerpt = Get-MsiLogExcerpt $log }
                return @{ ok = $false; message = ("the uninstaller ended with code " + $r.code + $(if ($null -ne $r.code -and $InstallerCodes.ContainsKey([int]$r.code)) { ": " + $InstallerCodes[[int]$r.code] } else { "" })); result = $res }
            }
        }
        if (-not (Wait-Gone $now 120)) {
            if ($res.reboot_required) { return @{ ok = $true; message = ("removal finishes at the next restart (" + $label + " is still listed)"); result = $res } }
            return @{ ok = $false; message = ("the uninstaller finished but " + $label + " is still listed"); result = $res }
        }
        return @{ ok = $true; message = ("removed " + $label + $(if ($res.reboot_required) { "; a restart completes it" } else { "" })); result = $res }
    }

    # 3. Install or upgrade: copy the file here, checked and held unchangeable
    $pkgLock = $null; $local = $null; $succeeded = $false
    try {
        try { $got = Get-PackageFile $Params $Token 90 }
        catch { return @{ ok = $false; message = ("the package could not be copied to this server: " + $_.Exception.Message); result = $res } }
        $local = $got.path; $pkgLock = Get-Prop $got "lock"
        $res.target_path = $local; $res.drive = $got.drive; $res.folder_created = $got.created
        $res.downloaded_mb = $got.mb; $res.download_seconds = $got.seconds
        $sig = Get-AuthenticodeSignature -LiteralPath $local
        $res.signature = ([string]$sig.Status + $(if ($sig.SignerCertificate) { ", " + $sig.SignerCertificate.Subject } else { "" }))
        if ([bool](Get-Prop $Params "require_signature")) {
            if ([string]$sig.Status -ne "Valid") { return @{ ok = $false; message = ("the file's signature is " + $sig.Status + ": nothing was run"); result = $res } }
            $pub = [string](Get-Prop $Params "publisher")
            if ($pub -and $sig.SignerCertificate.Subject -ne $pub) { return @{ ok = $false; message = ("signed by '" + $sig.SignerCertificate.Subject + "', not the approved publisher: nothing was run"); result = $res } }
        }

        if ($mode -eq "portable") {
            # Copied, never run: a portable program waits for someone to use it
            $appRoot = Split-Path -Parent $P.app_dir
            $mk = Get-PortableMarker $P.app_dir
            if ($mk -and [string](Get-Prop $mk "name") -ne $name) { return @{ ok = $false; message = ($P.app_dir + " already holds " + [string](Get-Prop $mk "name") + ": choose another folder name for this package"); result = $res } }
            foreach ($d in @($appRoot, $P.app_dir)) {
                if (Test-Reparse $d) { return @{ ok = $false; message = ($d + " is a link: nothing was copied"); result = $res } }
                if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
            }
            $running = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $P.app_file } catch { $false } })
            if ($running.Count -gt 0) { return @{ ok = $false; message = ($file + " is running (process " + $running[0].Id + "): close it, then deploy again"); result = $res } }
            $tmpCopy = $P.app_file + ".new"
            $out = [IO.File]::Open($tmpCopy, [IO.FileMode]::Create, [IO.FileAccess]::Write, [IO.FileShare]::None)
            try { $pkgLock.Position = 0; $pkgLock.CopyTo($out) } finally { $out.Dispose() }
            $h = (Get-FileHash -Algorithm SHA256 -LiteralPath $tmpCopy).Hash.ToLowerInvariant()
            if ($h -ne $want) { Remove-Item -LiteralPath $tmpCopy -Force -ErrorAction SilentlyContinue; return @{ ok = $false; message = "the copy in Program Files did not match the package: removed"; result = $res } }
            Move-Item -LiteralPath $tmpCopy -Destination $P.app_file -Force
            # The marker says which package and version this folder holds; an older version's file goes
            $old = Get-PortableMarker $P.app_dir
            if ($old -and [string](Get-Prop $old "file") -and [string](Get-Prop $old "file") -ne $file) {
                Remove-Item -LiteralPath (Join-Path $P.app_dir ([string](Get-Prop $old "file"))) -Force -ErrorAction SilentlyContinue
            }
            ConvertTo-Json -InputObject @{ name = $name; version = $ver; file = $file; sha256 = $want; at = (Get-IsoUtc) } |
                Set-Content -LiteralPath (Join-Path $P.app_dir ".patch01-package.json") -Encoding UTF8
            $res.app_path = $P.app_file
            $succeeded = $true
            Write-Log ("copied " + $file + " to " + $P.app_dir + " (portable program: not run)")
            return @{ ok = $true; message = ($action + " done: " + $name + " " + $ver + " copied to " + $P.app_file + $(if ($have) { " (was " + $have + ")" } else { "" })); result = $res }
        }

        if ($kind -eq "msi") {
            # The MSI's own facts decide what to look for afterwards
            $mp = Get-MsiProperties $local
            if ($mp.ContainsKey("ProductCode") -and $mp["ProductCode"] -match $SwGuid) { $P.pcode = $mp["ProductCode"] }
            if ($mp.ContainsKey("ProductVersion") -and $mp["ProductVersion"]) { $ver = $mp["ProductVersion"] }
            if (-not $P.detect -and $mp.ContainsKey("ProductName")) { $P.detect = $mp["ProductName"] }
            # PATCH-01 may not have been able to read the MSI: check again with its own product code
            if ($P.pcode) {
                $byCode = Get-InstalledByCode $P.pcode
                if ($byCode -and (Compare-Version ([string]$byCode.Version) $ver) -ge 0) {
                    $res.nothing_to_do = $true; $succeeded = $true
                    return @{ ok = $true; message = ("already installed: " + $byCode.Name + " " + $byCode.Version); result = $res }
                }
            }
            $exe = Join-Path $env:SystemRoot "System32\msiexec.exe"
            $argline = "/i `"" + $local + "`" /qn /norestart /l*v `"" + $log + "`""
        } else { $exe = $local; $argline = $iargs }
        Write-Log ($action + " " + $name + " " + $ver + ": starting " + (Split-Path -Leaf $exe) + $(if ($kind -eq "exe") { " " + $argline } else { "" }) + " (time limit " + $limit + " min)")
        $r = Invoke-Installer $exe $argline $actStart $limit ("installer of " + $name)
        if ($r.timeout) {
            return @{ ok = $false; message = ("the installer did not finish within " + $r.minutes + " minutes and was stopped (with everything it started). " +
                     $(if ($kind -eq "msi") { "Windows Installer may still be finishing it in the background: a deployment right after may wait for it (1618). " } else { "" }) +
                     "It is most likely waiting for a click: its silent options are wrong, or the file is a portable program rather than an installer (mark it portable on the package)"); result = $res } }
        $code = $r.code
        if ($null -eq $code) { return @{ ok = $false; message = "the installer finished but Windows gave no exit code"; result = $res } }
        $res.exit_code = $code
        if ($code -eq 3010 -or $code -eq 1641) { $res.reboot_required = $true }
        elseif ($code -ne 0) {
            $meaning = $(if ($InstallerCodes.ContainsKey($code)) { ": " + $InstallerCodes[$code] } else { "" })
            if ($kind -eq "msi") {
                $res.log_excerpt = Get-MsiLogExcerpt $log
                foreach ($l in @(($res.log_excerpt -split "`n") | Select-Object -Last 15)) { if ($l.Trim()) { Write-Log ("msi log: " + $l.Trim()) "WARN" } }
            }
            return @{ ok = $false; message = ("the installer ended with code " + $code + $meaning + $(if ($kind -eq "msi") { " (MSI log on the server: " + $log + ")" } else { "" })); result = $res }
        }
        # Prove it: the program is there, in the expected version
        $after = Get-PackageInstalled $P
        $res.after = $null; if ($after.Count -gt 0) { $res.after = [string]$after[0].Version }
        if ($after.Count -eq 0) {
            if ($res.reboot_required) { $res.warnings += ("the installer asked for a restart; " + $name + " is not listed until then"); $succeeded = $true; return @{ ok = $true; message = "installed; a restart completes it"; result = $res } }
            return @{ ok = $false; message = ("the installer finished (code " + $code + ") but " + $name + " is not listed in Programs and Features: check the 'name in Programs and Features' on the package"); result = $res }
        }
        $c2 = Compare-Version $res.after $ver
        if ($c2 -eq -1) { $res.warnings += ($after[0].Name + " still reports version " + $res.after + ", older than " + $ver + ": the installer may not upgrade in place") }
        elseif ($null -eq $c2 -and -not (Test-VersionMatch $res.after $ver)) { $res.warnings += ($after[0].Name + " reports version " + $res.after + ", not " + $ver) }
        $succeeded = $true
        return @{ ok = $true; message = ($action + " done: " + $after[0].Name + " " + $res.after + $(if ($have) { " (was " + $have + ")" } else { "" }) + $(if ($res.reboot_required) { "; a restart is needed" } else { "" })); result = $res }
    } finally {
        if ($pkgLock) { $pkgLock.Dispose() }
        if ($local -and (Test-Path -LiteralPath $local)) {
            if ($succeeded) { Remove-Item -LiteralPath $local -Force -ErrorAction SilentlyContinue; Write-Log ("removed " + $local + " after the install") }
            else { Write-Log ("kept " + $local + " for checking (the next deployment replaces it)") }
        }
    }
}

function Invoke-SoftwareAction($Params, $Token, [string]$CommandId) {
    # Packages uploaded to PATCH-01 (Deployment) have their own, version-aware handling
    if ([string](Get-Prop $Params "source") -eq "package") { return Invoke-PackageAction $Params $Token $CommandId }
    $action = [string](Get-Prop $Params "action"); $kind = [string](Get-Prop $Params "kind")
    $source = [string](Get-Prop $Params "source")
    $unc = [string](Get-Prop $Params "unc_path"); $want = [string](Get-Prop $Params "sha256")
    $detect = [string](Get-Prop $Params "detect_name"); $ver = [string](Get-Prop $Params "version")
    $pcode = [string](Get-Prop $Params "product_code"); $iargs = [string](Get-Prop $Params "install_args")
    $uargs = [string](Get-Prop $Params "uninstall_args"); $pub = [string](Get-Prop $Params "publisher")
    $needSig = [bool](Get-Prop $Params "require_signature")
    $isPkg = ($source -eq "package")
    # Check again here what PATCH-01 sent: nothing reaches a command line unchecked
    if ($action -notin @("install", "upgrade", "uninstall")) { return @{ ok = $false; message = "unknown action"; result = @{} } }
    if ($isPkg -and $action -eq "uninstall") { return @{ ok = $false; message = "a package is installed or upgraded, not removed"; result = @{} } }
    if ($kind -notin @("msi", "exe")) { return @{ ok = $false; message = "unknown installer type"; result = @{} } }
    if ($isPkg) {
        if ([string](Get-Prop $Params "package_id") -notmatch $PkgIdRe) { return @{ ok = $false; message = "the package id was refused"; result = @{} } }
        if ([string](Get-Prop $Params "download") -ne ("/api/v1/agent/packages/" + [string](Get-Prop $Params "package_id") + "/file")) { return @{ ok = $false; message = "the download address was refused"; result = @{} } }
        if ([string](Get-Prop $Params "file_name") -notmatch $PkgNameRe -or -not ([string](Get-Prop $Params "file_name")).ToLowerInvariant().EndsWith("." + $kind)) { return @{ ok = $false; message = "the package's file name was refused"; result = @{} } }
        if ([long](Get-Prop $Params "size") -le 0) { return @{ ok = $false; message = "the package size was refused"; result = @{} } }
    } elseif ($unc -notmatch $SwUnc -or $unc.Contains("..")) { return @{ ok = $false; message = "the share path was refused"; result = @{} } }
    if ($want -notmatch '^[0-9a-f]{64}$') { return @{ ok = $false; message = "the SHA-256 was refused"; result = @{} } }
    if ($kind -eq "msi" -and $pcode -and $pcode -notmatch $SwGuid) { return @{ ok = $false; message = "the product code was refused"; result = @{} } }
    if ($kind -eq "msi" -and -not $pcode -and -not $isPkg) { return @{ ok = $false; message = "the product code was refused"; result = @{} } }
    if ($iargs -notmatch $SwArgs -or $uargs -notmatch $SwArgs) { return @{ ok = $false; message = "the installer options were refused"; result = @{} } }
    if (-not $detect -and -not ($isPkg -and $kind -eq "msi")) { return @{ ok = $false; message = "no name to recognise the program by"; result = @{} } }

    # Old installer logs are not kept for ever
    Get-ChildItem -Path $DataDir -Filter "pkg-*.log" -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-30) } |
        Remove-Item -Force -ErrorAction SilentlyContinue

    $res = @{ action = $action; before = $null; reboot_required = $false; nothing_to_do = $false; warnings = @() }
    $rb = Get-RebootState
    if ($rb.Required) { $res.warnings += ("a restart was already pending before this install (" + $rb.Reason + ")") }
    # Get-InstalledProgram returns its list whole: wrapping the call in @() would nest it (an empty
    # list would count as one entry), so it is assigned directly
    $before = @(); if ($detect) { $before = Get-InstalledProgram $detect }
    if ($pcode) { $byCode = Get-InstalledByCode $pcode; if ($byCode) { $before = @($byCode) + $before } }
    $have = $null; if ($before.Count -gt 0) { $have = $before[0].Version }
    $res.before = $have
    if ($action -eq "install" -and $before.Count -gt 0 -and (Test-VersionMatch $have $ver)) {
        $res.nothing_to_do = $true; return @{ ok = $true; message = ("already installed: " + $before[0].Name + " " + $have); result = $res } }
    if ($action -eq "upgrade" -and $before.Count -eq 0 -and $detect) {
        return @{ ok = $false; message = ("not installed here, so nothing to upgrade (deploy it with install): " + $detect); result = $res } }
    if ($action -eq "upgrade" -and $before.Count -gt 0 -and (Test-VersionMatch $have $ver)) {
        $res.nothing_to_do = $true; return @{ ok = $true; message = ("already on " + $have); result = $res } }
    if ($action -eq "uninstall" -and $before.Count -eq 0) {
        $res.nothing_to_do = $true; return @{ ok = $true; message = "not installed: nothing to remove"; result = $res } }

    $work = Join-Path $DataDir ("pkg\" + ($CommandId -replace '[^0-9a-f-]', ''))
    $log = Join-Path $DataDir ("pkg-" + ($CommandId -replace '[^0-9a-f-]', '') + ".log")
    $local = $null; $succeeded = $false; $pkgLock = $null
    $actStart = Get-Date              # PATCH-01 allows this step 3 hours from the claim: download and install share 2 h 50 min
    try {
        New-Item -ItemType Directory -Force -Path $work | Out-Null
        $needFile = -not ($action -eq "uninstall")
        if ($needFile -and $isPkg) {
            try { $got = Get-PackageFile $Params $Token 90 }
            catch { return @{ ok = $false; message = ("the package could not be copied to this server: " + $_.Exception.Message); result = $res } }
            $local = $got.path; $pkgLock = Get-Prop $got "lock"
            $res.target_path = $local; $res.drive = $got.drive; $res.folder_created = $got.created
            $res.downloaded_mb = $got.mb; $res.download_seconds = $got.seconds
        } elseif ($needFile) {
            # The share is reachable only with this job's credential, fetched once, kept in memory
            $null = $unc -match $SwUnc
            $root = "\\" + $Matches[1] + "\" + $Matches[2]; $rest = $Matches[3]
            $cred = Get-ShareCredential $Token $CommandId
            $drv = "PA" + ([guid]::NewGuid().ToString("N").Substring(0, 6))
            try {
                New-PSDrive -Name $drv -PSProvider FileSystem -Root $root -Credential $cred -ErrorAction Stop | Out-Null
                $local = Join-Path $work (Split-Path -Leaf $unc)
                Copy-Item -LiteralPath ($drv + ":" + $rest) -Destination $local -ErrorAction Stop
            } catch {
                return @{ ok = $false; message = ("could not copy the installer from the share: " + $_.Exception.Message); result = $res }
            } finally {
                Remove-PSDrive -Name $drv -Force -ErrorAction SilentlyContinue
                $cred = $null
            }
            $got = (Get-FileHash -Algorithm SHA256 -LiteralPath $local).Hash.ToLowerInvariant()
            if ($got -ne $want) {
                return @{ ok = $false; message = ("the installer's SHA-256 is " + $got + ", not the approved one: nothing was run"); result = $res } }
        }
        if ($needFile) {
            $sig = Get-AuthenticodeSignature -LiteralPath $local
            $res.signature = ([string]$sig.Status + $(if ($sig.SignerCertificate) { ", " + $sig.SignerCertificate.Subject } else { "" }))
            if ($needSig) {
                if ([string]$sig.Status -ne "Valid") {
                    return @{ ok = $false; message = ("the installer's signature is " + $sig.Status + ": nothing was run"); result = $res } }
                if ($pub -and $sig.SignerCertificate.Subject -ne $pub) {
                    return @{ ok = $false; message = ("signed by '" + $sig.SignerCertificate.Subject + "', not the approved publisher: nothing was run"); result = $res } }
            }
            if ($kind -eq "msi" -and $isPkg) {
                # The MSI's own facts decide what to look for afterwards
                $mp = Get-MsiProperties $local
                if ($mp.ContainsKey("ProductCode") -and $mp["ProductCode"] -match $SwGuid) { $pcode = $mp["ProductCode"] }
                if (-not $detect -and $mp.ContainsKey("ProductName")) { $detect = $mp["ProductName"] }
                if ($mp.ContainsKey("ProductVersion") -and $mp["ProductVersion"]) { $ver = $mp["ProductVersion"] }
                if ($pcode -and $action -eq "install") {
                    $now = Get-InstalledByCode $pcode
                    if ($now -and (Test-VersionMatch $now.Version $ver)) {
                        $res.nothing_to_do = $true; $succeeded = $true
                        return @{ ok = $true; message = ("already installed: " + $now.Name + " " + $now.Version); result = $res } }
                }
            }
        }
        # Fixed templates; started directly, never through cmd
        if ($kind -eq "msi") {
            $exe = Join-Path $env:SystemRoot "System32\msiexec.exe"
            if ($action -eq "uninstall") { $argline = "/x " + $pcode + " /qn /norestart /l*v `"" + $log + "`"" }
            else { $argline = "/i `"" + $local + "`" /qn /norestart /l*v `"" + $log + "`"" }
        } elseif ($action -eq "uninstall") {
            $u = $before[0].Uninstall
            if ($u -match '^"([^"]+\.exe)"') { $exe = $Matches[1] } elseif ($u -match '^(.+?\.exe)') { $exe = $Matches[1] } else { $exe = "" }
            # "MsiExec.exe /X{...}" names no path: an MSI-based program is removed by its product code
            $isMsi = ($exe -and (Split-Path -Leaf $exe) -ieq "msiexec.exe")
            if (-not $isMsi -and (-not $exe -or -not (Test-Path -LiteralPath $exe))) {
                return @{ ok = $false; message = "the program's own uninstaller was not found"; result = $res } }
            if ($isMsi) {
                $exe = Join-Path $env:SystemRoot "System32\msiexec.exe"
                $argline = "/x " + $before[0].Key + " /qn /norestart /l*v `"" + $log + "`""
                if ($before[0].Key -notmatch $SwGuid) { return @{ ok = $false; message = "the program's MSI code was not recognised"; result = $res } }
            } else {
                # The program's own uninstaller runs as SYSTEM: only from a folder ordinary users cannot change
                if (-not (Test-AdminOnly $exe)) {
                    return @{ ok = $false; message = ("its uninstaller " + $exe + " is in a folder that users other than administrators can change: not run as SYSTEM"); result = $res } }
                $argline = $uargs
            }
        } else {
            $exe = $local; $argline = $iargs
        }
        Write-Log ($action + " " + [string](Get-Prop $Params "name") + " " + $ver + ": starting " + (Split-Path -Leaf $exe) + $(if ($argline -and $kind -eq "exe") { " " + $argline } else { "" }))
        $code = $null
        $t0 = $actStart
        for ($attempt = 1; $attempt -le 3; $attempt++) {
            # Start-Process refuses an empty argument list, so options go in only when there are some
            $sp = @{ FilePath = $exe; PassThru = $true; WindowStyle = "Hidden" }
            if ($argline) { $sp["ArgumentList"] = $argline }
            $p = Start-Process @sp
            $null = $p.Handle          # PowerShell 5.1 loses the exit code of a -PassThru process unless its handle is held
            $left = [int][math]::Max(60000, 10200000 - ((Get-Date) - $t0).TotalMilliseconds)     # 2 h 50 min in all, under PATCH-01's limit
            if (-not $p.WaitForExit($left)) {
                try { $p.Kill() } catch { }
                return @{ ok = $false; message = "the installer did not finish within 2 h 50 min and was stopped"; result = $res }
            }
            $p.WaitForExit()           # the timed wait can return before the exit code is filled in
            $code = $p.ExitCode
            if ($null -eq $code) { return @{ ok = $false; message = "the installer finished but Windows gave no exit code; check the program and run the job again"; result = $res } }
            $code = [int]$code
            if ($code -ne 1618 -or $attempt -eq 3) { break }
            # Another installation (often Windows Update) holds the installer: wait and try again
            Write-Log ("another installation is in progress (1618): waiting 2 minutes, then trying again (" + $attempt + " of 2)") "WARN"
            if ($script:RunToken) { Send-LogTail $script:RunToken }
            Start-Sleep -Seconds 120
        }
        $res.exit_code = $code
        Write-Log ("installer finished with code " + $code + $(if ($InstallerCodes.ContainsKey($code)) { " (" + $InstallerCodes[$code] + ")" } else { "" }) + " (" + [int]((Get-Date) - $actStart).TotalSeconds + " s since this step started)")
        if ($code -eq 3010 -or $code -eq 1641) { $res.reboot_required = $true }
        elseif ($code -ne 0) {
            $meaning = $(if ($InstallerCodes.ContainsKey($code)) { ": " + $InstallerCodes[$code] } else { "" })
            if ($kind -eq "msi") {
                $res.log_excerpt = Get-MsiLogExcerpt $log
                foreach ($l in @(($res.log_excerpt -split "`n") | Select-Object -Last 15)) { if ($l.Trim()) { Write-Log ("msi log: " + $l.Trim()) "WARN" } }
            }
            return @{ ok = $false; message = ("the installer ended with code " + $code + $meaning + $(if ($kind -eq "msi") { " (MSI log on the server: " + $log + ")" } else { "" })); result = $res } }
        # Prove it: the program is there in the expected version, or gone
        $after = @(); if ($pcode) { $bc = Get-InstalledByCode $pcode; if ($bc) { $after += $bc } }
        if ($detect) { $after += Get-InstalledProgram $detect }
        $res.after = $null; if ($after.Count -gt 0) { $res.after = $after[0].Version }
        if ($action -eq "uninstall") {
            if ($after.Count -gt 0 -and -not $res.reboot_required) {
                return @{ ok = $false; message = ("the installer finished but " + $after[0].Name + " is still listed"); result = $res } }
            $succeeded = $true
            return @{ ok = $true; message = ("removed " + $detect + $(if ($res.reboot_required) { "; a reboot completes it" } else { "" })); result = $res }
        }
        if ($after.Count -eq 0) {
            if ($res.reboot_required) {
                $res.warnings += ("the installer asked for a restart; " + $detect + " is not listed in Programs and Features until then")
                $succeeded = $true
                return @{ ok = $true; message = "installed; a restart completes it"; result = $res }
            }
            return @{ ok = $false; message = ("the installer finished (code " + $code + ") but " + $detect + " is not listed in Programs and Features: check the name to recognise it by, or the program"); result = $res } }
        if (-not (Test-VersionMatch $after[0].Version $ver)) {
            if ($isPkg) {
                # Installed, but the program reports its version differently: say so, do not fail
                $res.warnings += ($after[0].Name + " reports version " + $after[0].Version + ", not " + $ver)
            } else {
                return @{ ok = $false; message = ("installed, but it reports version " + $after[0].Version + ", not " + $ver); result = $res } }
        }
        $succeeded = $true
        return @{ ok = $true; message = ($action + " done: " + $after[0].Name + " " + $after[0].Version + $(if ($res.reboot_required) { "; a reboot is needed" } else { "" })); result = $res }
    } finally {
        if ($pkgLock) { $pkgLock.Dispose() }
        Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
        if ($isPkg -and $local -and (Test-Path -LiteralPath $local)) {
            if ($succeeded) { Remove-Item -LiteralPath $local -Force -ErrorAction SilentlyContinue; Write-Log ("removed " + $local + " after the install") }
            else { Write-Log ("kept " + $local + " for checking (the next deployment replaces it)") }
        }
    }
}

function Send-LogTail($Token) {
    <# Sends the log lines written since the last send, so failures can be read
       in the console. Never lets a problem here break a run, and never logs
       about itself (that would feed its own output). #>
    try {
        if (-not (Test-Path $LogFile)) { return }
        $state = Get-State
        $off = [long]0
        if ($state.PSObject.Properties["log_offset"] -and $state.log_offset) { $off = [long]$state.log_offset }
        $len = (Get-Item $LogFile).Length
        if ($len -lt $off) { $off = 0 }                       # the log was rotated
        if ($len -eq $off) { return }
        if ($len - $off -gt 262144) { $off = $len - 262144 }  # at most the last 256 KB
        $fs = [IO.File]::Open($LogFile, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
        try {
            [void]$fs.Seek($off, [IO.SeekOrigin]::Begin)
            $text = (New-Object IO.StreamReader($fs, [Text.Encoding]::UTF8)).ReadToEnd()
        } finally { $fs.Dispose() }
        $lines = @()
        foreach ($l in ($text -split "`r?`n")) {
            if ($l -match '^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d) (?:(INFO|WARN|ERROR) )?(.+)$') {
                $at = [datetime]::ParseExact($Matches[1], "yyyy-MM-dd HH:mm:ss", [Globalization.CultureInfo]::InvariantCulture)
                $lvl = "INFO"; if ($Matches[2]) { $lvl = $Matches[2] }
                $msg = $Matches[3]; if ($msg.Length -gt 2000) { $msg = $msg.Substring(0, 2000) }
                $lines += @{ at = (Get-IsoUtc $at); level = $lvl; msg = $msg }
            }
        }
        if ($lines.Count -gt 500) { $lines = $lines[($lines.Count - 500)..($lines.Count - 1)] }
        if ($lines.Count -gt 0) { Invoke-Api "POST" "/api/v1/agent/log" @{ lines = $lines } $Token | Out-Null }
        $state = Get-State
        if ($state.PSObject.Properties["log_offset"]) { $state.log_offset = $len } else { $state | Add-Member -NotePropertyName log_offset -NotePropertyValue $len }
        Save-State $state
    } catch { Write-Verbose ("log send failed: " + $_.Exception.Message) }
}

function Send-Result($Token, [string]$CommandId, $Body) {
    # A lost result leaves PATCH-01 waiting: retry, and log if it still fails
    for ($i = 1; $i -le 3; $i++) {
        try { Invoke-Api "POST" ("/api/v1/agent/commands/" + $CommandId + "/result") $Body $Token | Out-Null; return $true }
        catch {
            # A retry after a reply lost on the way back: PATCH-01 already has this result
            if ($i -gt 1 -and $_.Exception.Message -match 'HTTP 404: .*no such pending command') { return $true }
            Write-Log ("sending the result of command " + $CommandId + " failed (try " + $i + " of 3): " + $_.Exception.Message) "ERROR"
            Start-Sleep -Seconds (5 * $i)
        }
    }
    return $false
}

function Invoke-Commands($Token) {
    # PowerShell 5.1 returns a JSON list from Invoke-RestMethod as ONE object
    # (the whole list), not one item per command. Sending it through the
    # pipeline unrolls it, whichever way it came back.
    $cmds = @(@(Invoke-Api "GET" "/api/v1/agent/commands" $null $Token) | ForEach-Object { $_ } | Where-Object { $null -ne $_ })
    # PATCH-01's check job after an update is answered first: nothing in the batch may hold it up
    $probes = @($cmds | Where-Object { $_.PSObject.Properties["verb"] -and $_.verb -eq "update_agent" -and (Get-Prop (Get-Prop $_ "params") "probe") })
    if ($probes.Count) { $cmds = @($probes) + @($cmds | Where-Object { $probes -notcontains $_ }) }
    $ranInventory = $false; $count = 0; $rebooting = $false
    if ($cmds.Count -gt 0) { Write-Log ("received " + $cmds.Count + " command(s) from PATCH-01") }
    foreach ($c in $cmds) {
        if (-not $c.PSObject.Properties["id"] -or -not $c.PSObject.Properties["verb"]) {
            # Never skip silently: say so, and answer if there is an id to answer to
            Write-Log ("a command could not be read and was not run: " + (ConvertTo-Json -InputObject $c -Compress -Depth 3)) "ERROR"
            if ($c.PSObject.Properties["id"]) {
                [void](Send-Result $Token ([string]$c.id) @{ ok = $false; message = "the Windows agent could not read this command"; result = @{} })
            }
            continue
        }
        $count++
        if ($script:Updated) {
            # This file was replaced a moment ago: the rest of this batch is left to the new version's next run
            [void](Send-Result $Token ([string]$c.id) @{ ok = $false; message = "not run: the agent was replaced by an update a moment ago; run it again"; result = @{ deferred = $true } })
            continue
        }
        if ($rebooting) {
            # A restart is under way: nothing else starts now (it would be cut off half way). PATCH-01 puts
            # these back in the queue, and the agent runs them after the restart.
            [void](Send-Result $Token ([string]$c.id) @{ ok = $false; message = "not run: the server is restarting; it runs after the restart"; result = @{ deferred = $true } })
            continue
        }
        $ok = $true; $msg = $null; $res = @{}
        $t0 = Get-Date
        Write-Log ("command " + $c.verb + " started (" + $c.id + ")")
        try {
            $params = Get-Prop $c "params"
            $out = $null
            switch ($c.verb) {
                "collect_inventory" { Send-Inventory $Token; $ranInventory = $true; $msg = "inventory sent" }
                "run_precheck"      { $out = Invoke-Precheck $params $Token }
                "install_packages"  { $out = Invoke-InstallUpdates $params $Token }
                "reboot_host"       { $out = Invoke-Reboot $params }
                "run_postcheck"     { $out = Invoke-Postcheck $params }
                "software_action"   { $out = Invoke-SoftwareAction $params $Token ([string]$c.id) }
                "update_agent"      { $out = Invoke-AgentUpdate $params $Token }
                default { $ok = $false; $msg = "'" + $c.verb + "' is not supported by the Windows agent" }
            }
            if ($null -ne $out) { $ok = [bool]$out.ok; $msg = [string]$out.message; $res = $out.result }
        } catch {
            $ok = $false
            $msg = [string]$_.Exception.Message
            $where = ""; if ($_.InvocationInfo) { $where = " (line " + $_.InvocationInfo.ScriptLineNumber + ")" }
            Write-Log ("command " + $c.verb + " threw: " + $msg + $where) "ERROR"
        }
        $secs = [int]((Get-Date) - $t0).TotalSeconds
        Write-Log ("command {0} {1} in {2} s: {3}" -f $c.verb, $(if ($ok) { "ok" } else { "failed" }), $secs, $msg) $(if ($ok) { "INFO" } else { "WARN" })
        $sent = Send-Result $Token ([string]$c.id) @{ ok = $ok; message = $msg; result = $res }
        # PATCH-01's check job after an update: answered and reported, so this version runs jobs. Confirmed.
        if ($sent -and $ok -and $c.verb -eq "update_agent" -and (Get-Prop $res "probe")) { Confirm-AgentUpdate }
        Send-LogTail $Token
        if ($c.verb -eq "reboot_host" -and $ok) { $rebooting = $true }
    }
    return @{ inventory = $ranInventory; count = $count; rebooting = $rebooting; updated = [bool]$script:Updated }
}

# ---------------------------------------------------------------------------
# Updates of this agent from PATCH-01 (update_agent)
# ---------------------------------------------------------------------------
function Get-FileSha256([string]$Path) {
    $fs = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    try {
        $h = [Security.Cryptography.SHA256]::Create()
        try { return (([BitConverter]::ToString($h.ComputeHash($fs))) -replace "-", "").ToLowerInvariant() } finally { $h.Dispose() }
    } finally { $fs.Dispose() }
}

function Get-BytesSha256([byte[]]$Bytes) {
    $h = [Security.Cryptography.SHA256]::Create()
    try { return (([BitConverter]::ToString($h.ComputeHash($Bytes))) -replace "-", "").ToLowerInvariant() } finally { $h.Dispose() }
}

function Get-InstalledAgentPath { return (Join-Path (Join-Path $env:ProgramFiles "PatchAgent") "patch-agent.ps1") }
function Get-PreviousAgentPath { return (Join-Path (Join-Path $env:ProgramFiles "PatchAgent") "patch-agent.prev.ps1") }

function Get-AgentPolicy {
    <# The execution policy the agent's task runs under: a machine Group Policy
       wins; otherwise the one the task gives its own process. #>
    $l = @(Get-ExecutionPolicy -List)
    $mp = [string](@($l | Where-Object { [string]$_.Scope -eq "MachinePolicy" })[0].ExecutionPolicy)
    if ($mp -and $mp -ne "Undefined") { return $mp }
    $t = Get-ScheduledTask -TaskName $AgentTaskName -ErrorAction SilentlyContinue
    if ($t) {
        foreach ($a in @($t.Actions)) {
            if ([string]$a.Arguments -match '-ExecutionPolicy\s+(AllSigned|RemoteSigned|Bypass|Unrestricted)\b') { return $Matches[1] }
        }
    }
    return "RemoteSigned"
}

function Test-TrustedSignature([string]$Path) {
    <# $null when the file is signed, the signature is valid and the signer is
       trusted for the whole computer (Trusted Publishers, and its root in the
       computer's Trusted Root store); otherwise why not. #>
    $sig = Get-AuthenticodeSignature -LiteralPath $Path
    if ([string]$sig.Status -ne "Valid") { return ("its signature is " + [string]$sig.Status) }
    $cert = $sig.SignerCertificate
    if (-not (Get-ChildItem -Path Cert:\LocalMachine\TrustedPublisher -ErrorAction SilentlyContinue | Where-Object { $_.Thumbprint -eq $cert.Thumbprint })) {
        return ("its publisher (" + $cert.Subject + ") is not in this computer's Trusted Publishers")
    }
    $chain = New-Object Security.Cryptography.X509Certificates.X509Chain($true)
    [void]$chain.Build($cert)
    $root = $chain.ChainElements[$chain.ChainElements.Count - 1].Certificate
    if (-not (Get-ChildItem -Path Cert:\LocalMachine\Root -ErrorAction SilentlyContinue | Where-Object { $_.Thumbprint -eq $root.Thumbprint })) {
        return ("its root CA (" + $root.Subject + ") is not in this computer's Trusted Root store")
    }
    return $null
}

function Test-RunningSigned([string]$Path) {
    # Any signature at all counts (also an expired or no longer trusted one): never from signed to unsigned
    $sig = Get-AuthenticodeSignature -LiteralPath $Path
    return ($null -ne $sig.SignerCertificate -or [string]$sig.Status -ne "NotSigned")
}

function Invoke-AgentTest([string]$Path, [string]$Policy, [string]$Version) {
    <# Runs the new file the way the task will (its execution policy, SYSTEM)
       with -Check: it must load, read the settings and the token, and name
       its version. Nothing else runs. #>
    if ($Policy -notmatch '^(AllSigned|RemoteSigned|Bypass|Unrestricted)$') { throw ("unexpected execution policy " + $Policy) }
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
    $psi.Arguments = '-NoProfile -NonInteractive -ExecutionPolicy ' + $Policy + ' -File "' + $Path + '" -Check'
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $p = [Diagnostics.Process]::Start($psi)
    try {
        $o = $p.StandardOutput.ReadToEndAsync(); $e = $p.StandardError.ReadToEndAsync()
        if (-not $p.WaitForExit(120000)) {
            try { $p.Kill() } catch { }
            throw "the new agent's test run did not finish within 2 minutes"
        }
        $p.WaitForExit()
        $out = [string]$o.Result; $err = [string]$e.Result
        $want = "PATCH-01 agent " + $Version + " ready"
        if ($p.ExitCode -ne 0 -or $out -notmatch [regex]::Escape($want)) {
            $why = (($err + " " + $out) -replace '\s+', ' ').Trim()
            if ($why.Length -gt 400) { $why = $why.Substring(0, 400) }
            throw ("the new agent's test run failed (exit " + $p.ExitCode + "): " + $why)
        }
        return $want
    } finally { $p.Dispose() }
}

function Read-UpdateMarker {
    try {
        if (Test-Path -LiteralPath $UpdateMarker) {
            $m = ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($UpdateMarker))
            if ($m -and (Get-Prop $m "to") -and (Get-Prop $m "sha_new")) { return $m }
        }
    } catch { }
    return $null
}

function Get-MarkerAgeMinutes($Marker) {
    try {
        $at = [datetime]::Parse([string](Get-Prop $Marker "at"), [Globalization.CultureInfo]::InvariantCulture,
                                [Globalization.DateTimeStyles]::AdjustToUniversal -bor [Globalization.DateTimeStyles]::AssumeUniversal)
        return ((Get-Date).ToUniversalTime() - $at).TotalMinutes
    } catch { return 1e6 }
}

function Remove-UpdateCheck {
    Unregister-ScheduledTask -TaskName $UpdateTaskName -Confirm:$false -ErrorAction SilentlyContinue
}

function Register-UpdateCheck([string]$Prev, [string]$Policy) {
    <# The previous version checks the new one: every 5 minutes from 10
       minutes after the swap (and after a restart), until the new one has
       checked in or it has been put back. #>
    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument ("-NoProfile -NonInteractive -ExecutionPolicy " + $Policy + " -File `"" + $Prev + "`" -UpdateCheck")
    $every = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes($UpdateConfirmMinutes + 1) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 1)
    $boot = New-ScheduledTaskTrigger -AtStartup
    $boot.Delay = "PT5M"
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
    $settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 10) -StartWhenAvailable
    Register-ScheduledTask -TaskName $UpdateTaskName -Action $action -Trigger @($every, $boot) -Principal $principal -Settings $settings -Force | Out-Null
}

function Set-AgentFile([string]$Target, [byte[]]$Bytes, [string]$Sha) {
    # Written beside it, then swapped in one step; the result is read back
    $tmp = $Target + ".new"
    Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    [IO.File]::WriteAllBytes($tmp, $Bytes)
    if ((Get-FileSha256 $tmp) -ne $Sha) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue; throw "the file written is not the one checked" }
    if (Test-Path -LiteralPath $Target) { [IO.File]::Replace($tmp, $Target, [NullString]::Value) } else { [IO.File]::Move($tmp, $Target) }
    if ((Get-FileSha256 $Target) -ne $Sha) { throw ("after the swap, " + $Target + " is not the expected file") }
}

function Invoke-AgentUpdate($Params, $Token) {
    $plat = [string](Get-Prop $Params "platform"); $ver = [string](Get-Prop $Params "version")
    $sha = ([string](Get-Prop $Params "sha256")).ToLowerInvariant(); $size = [long](Get-Prop $Params "size")
    $dl = [string](Get-Prop $Params "download")
    if ($plat -ne "windows") { throw ("this update is for " + $plat + " agents, not Windows") }
    if ($ver -notmatch '^\d{1,4}\.\d{1,4}\.\d{1,4}-win$') { throw ("the version '" + $ver + "' was refused") }
    if (Get-Prop $Params "probe") {
        # PATCH-01's check after an update: is the version it asked for the one running? Nothing is downloaded.
        if ((Compare-Version $ver $AgentVersion) -eq 0) {
            return @{ ok = $true; message = ("agent " + $AgentVersion + " is running and answers jobs"); result = @{ nothing_to_do = $true; probe = $true; version = $AgentVersion } }
        }
        throw ("this is agent " + $AgentVersion + ", not " + $ver + ": the update was put back")
    }
    if ($sha -notmatch '^[0-9a-f]{64}$') { throw "the job has no valid SHA-256 for the new agent" }
    if ($size -lt 1024 -or $size -gt 4MB) { throw ("the new agent's size (" + $size + " bytes) was refused") }
    if ($dl -ne "/api/v1/agent/update-file") { throw "the download address was refused" }
    $cmp = Compare-Version $ver $AgentVersion
    if ($cmp -eq 0) {
        return @{ ok = $true; message = ("already runs agent " + $AgentVersion); result = @{ nothing_to_do = $true; version = $AgentVersion } }
    }
    if ($cmp -lt 0) { throw ("this agent (" + $AgentVersion + ") is newer than " + $ver + ": agents are never downgraded from PATCH-01") }
    $installed = Get-InstalledAgentPath
    $prev = Get-PreviousAgentPath
    if (-not $SelfPath -or [IO.Path]::GetFullPath($SelfPath) -ne [IO.Path]::GetFullPath($installed)) {
        throw ("this agent runs from " + $SelfPath + ", not " + $installed + ": update it with install-agent.ps1 -Update")
    }
    $old = Read-UpdateMarker
    if ($old) {
        if ((Get-MarkerAgeMinutes $old) -lt 60) { throw ("an update to " + [string]$old.to + " is still waiting to be confirmed; try again later") }
        Remove-Item -LiteralPath $UpdateMarker -Force -ErrorAction SilentlyContinue
    }
    $checks = New-Object Collections.ArrayList

    # 1. The file, over the pinned connection, exactly the one the job names
    $cfg = Get-Config
    Assert-Https ([string]$cfg.server)
    $ms = New-Object IO.MemoryStream
    $n = Receive-PackagePiece (([string]$cfg.server).TrimEnd("/") + $dl) $Token $ms $size
    if ($n -ne $size) { throw ("received " + $n + " of " + $size + " bytes of the new agent; nothing was changed") }
    $bytes = $ms.ToArray()
    if ((Get-BytesSha256 $bytes) -ne $sha) { throw "the downloaded agent's SHA-256 does not match the job; nothing was changed" }
    [void]$checks.Add("SHA-256 matches")

    # 2. Staged in the locked data folder, held unchangeable while it is checked
    if (Test-Reparse $UpdateDir) { throw ($UpdateDir + " is a link: refused") }
    if (-not (Test-Path -LiteralPath $UpdateDir)) { New-Item -ItemType Directory -Path $UpdateDir -Force | Out-Null }
    Protect-Folder $UpdateDir
    Get-ChildItem -LiteralPath $UpdateDir -Filter "patch-agent-*.ps1" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    $staged = Join-Path $UpdateDir ("patch-agent-" + $ver + ".ps1")
    [IO.File]::WriteAllBytes($staged, $bytes)
    $policy = Get-AgentPolicy
    $lock = [IO.File]::Open($staged, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    try {
        if ((Get-FileSha256 $staged) -ne $sha) { throw "the staged file changed; nothing was changed" }
        $tk = $null; $errs = $null
        [void][Management.Automation.Language.Parser]::ParseFile($staged, [ref]$tk, [ref]$errs)
        if ($errs -and @($errs).Count -gt 0) {
            $e0 = @($errs)[0]
            throw ("the new agent does not parse (line " + $e0.Extent.StartLineNumber + ": " + $e0.Message + "); nothing was changed")
        }
        [void]$checks.Add("PowerShell parses it")
        $text = [Text.Encoding]::UTF8.GetString($bytes)
        # -match, not -notmatch: only -match fills $Matches
        if (-not ($text -match '(?m)^\$AgentVersion = "([^"]+)"') -or $Matches[1] -ne $ver) { throw ("the file is not agent " + $ver + "; nothing was changed") }
        [void]$checks.Add("it is agent " + $ver)
        # Never from signed to unsigned: a signed agent, or a server under AllSigned, needs a trusted signature
        if ($policy -eq "AllSigned" -or (Test-RunningSigned $installed)) {
            $why = Test-TrustedSignature $staged
            if ($why) { throw ("the new agent is refused: " + $why + ". This agent is signed (or the server runs AllSigned), so its update must be signed by a publisher this computer trusts: sign it (Sign-Agent.ps1) and publish it with phase12-agents.sh --windows. Nothing was changed.") }
            [void]$checks.Add("signature valid and trusted")
        } else {
            [void]$checks.Add("unsigned, like the running agent (" + $policy + " for its own task)")
        }
        $tested = Invoke-AgentTest $staged $policy $ver
        [void]$checks.Add("test run: " + $tested)
    } finally { $lock.Dispose() }

    # 3. Keep this version, arm the check, swap
    $prevSha = Get-FileSha256 $installed
    Copy-Item -LiteralPath $installed -Destination $prev -Force
    if ((Get-FileSha256 $prev) -ne $prevSha) { throw "could not keep a copy of the running agent; nothing was changed" }
    Remove-Item -LiteralPath $UpdateCheckin -Force -ErrorAction SilentlyContinue
    $marker = @{ from = $AgentVersion; to = $ver; sha_new = $sha; sha_prev = $prevSha; at = (Get-IsoUtc); confirm_minutes = $UpdateConfirmMinutes }
    [IO.File]::WriteAllText($UpdateMarker, (ConvertTo-Json -InputObject $marker -Compress), (New-Object Text.UTF8Encoding($false)))
    try {
        Register-UpdateCheck $prev $policy
        Set-AgentFile $installed $bytes $sha
    } catch {
        $why = $_.Exception.Message
        try { if ((Get-FileSha256 $installed) -ne $prevSha) { Set-AgentFile $installed ([IO.File]::ReadAllBytes($prev)) $prevSha } } catch { }
        Remove-Item -LiteralPath $UpdateMarker -Force -ErrorAction SilentlyContinue
        Remove-UpdateCheck
        throw ("the swap failed and the running version was kept: " + $why)
    }
    Remove-Item -LiteralPath $staged -Force -ErrorAction SilentlyContinue
    [void]$checks.Add("swapped; previous version kept")
    Write-Log ("agent updated " + $AgentVersion + " -> " + $ver + " (" + ($checks -join "; ") + "); the next run is the new version, which must check in and answer PATCH-01's check within " + $UpdateConfirmMinutes + " minutes or this version is put back")
    $script:Updated = $true
    return @{ ok = $true; message = ("agent " + $ver + " in place; waiting for it to check in"); result = @{ from = $AgentVersion; to = $ver; checks = @($checks); confirm_minutes = $UpdateConfirmMinutes } }
}

function Write-UpdateCheckin {
    # After each check-in of a version still waiting to be confirmed: it started and reached PATCH-01
    try {
        $m = Read-UpdateMarker
        if (-not $m -or [string]$m.to -ne $AgentVersion) { return }
        [IO.File]::WriteAllText($UpdateCheckin, (ConvertTo-Json -InputObject @{ version = $AgentVersion; at = (Get-IsoUtc) } -Compress), (New-Object Text.UTF8Encoding($false)))
    } catch { }
}

function Confirm-AgentUpdate {
    <# A new version that has answered PATCH-01's check job (and reported the
       answer) runs jobs: it is confirmed, and the previous version stops
       watching. Does nothing when nothing is pending. #>
    try {
        $m = Read-UpdateMarker
        if (-not $m) { return }
        if ([string]$m.to -ne $AgentVersion) { return }
        Remove-Item -LiteralPath $UpdateMarker -Force -ErrorAction Stop
        Remove-Item -LiteralPath $UpdateCheckin -Force -ErrorAction SilentlyContinue
        Remove-UpdateCheck
        Write-Log ("agent " + $AgentVersion + " answered PATCH-01's check after the update from " + [string]$m.from + ": update confirmed (the previous version is kept as patch-agent.prev.ps1)")
    } catch { Write-Log ("confirming the agent update failed (tried again next run): " + $_.Exception.Message) "WARN" }
}

function Test-NewVersionCheckedIn($Marker) {
    # The new version has checked in since the swap (the stamp it writes after each check-in)
    try {
        if (-not (Test-Path -LiteralPath $UpdateCheckin)) { return $false }
        $c = ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($UpdateCheckin))
        if ([string](Get-Prop $c "version") -ne [string]$Marker.to) { return $false }
        return ((Get-MarkerAgeMinutes $c) -lt (Get-MarkerAgeMinutes $Marker))
    } catch { return $false }
}

function Start-UpdateCheck {
    <# Run by the previous version (patch-agent.prev.ps1) from its own task. #>
    $installed = Get-InstalledAgentPath
    $prev = Get-PreviousAgentPath
    $m = Read-UpdateMarker
    if (-not $m) { Remove-UpdateCheck; return }
    $cur = $null
    try { $cur = Get-FileSha256 $installed } catch { }
    if ($cur -ne [string]$m.sha_new) {
        # Installed again by hand, never swapped, or already put back: nothing to watch
        Write-Log ("update check: " + $installed + " is not the file the update to " + [string]$m.to + " put in place; nothing to do")
        Remove-Item -LiteralPath $UpdateMarker -Force -ErrorAction SilentlyContinue
        Remove-UpdateCheck; return
    }
    $age = Get-MarkerAgeMinutes $m
    if ($age -lt $UpdateConfirmMinutes) { return }
    $mutex = New-Object Threading.Mutex($false, "Global\PatchAgentRun")
    $owned = $false
    try { $owned = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owned = $true }
    if (-not $owned) {
        # A run holds the agent. The new version's first run answers PATCH-01's check within
        # seconds, and no other job is sent to it until then: still unconfirmed this long after
        # the swap, it hangs. Stop it, then put the previous version back.
        if ($age -lt $UpdateHardMinutes) {
            $mutex.Dispose(); Write-Log "update check: an agent run is in progress; checking again in 5 minutes"; return
        }
        Write-Log ("update check: agent " + [string]$m.to + " is still unconfirmed " + [int]$age + " minutes after the update and holds the agent: stopping it") "ERROR"
        Stop-ScheduledTask -TaskName $AgentTaskName -ErrorAction SilentlyContinue
        try { $owned = $mutex.WaitOne(60000) } catch [Threading.AbandonedMutexException] { $owned = $true }
        if (-not $owned) { $mutex.Dispose(); Write-Log "update check: the agent could not be stopped; trying again in 5 minutes" "ERROR"; return }
    } elseif ((Test-NewVersionCheckedIn $m) -and $age -lt $UpdateHardMinutes) {
        # It starts and reaches PATCH-01, but PATCH-01's check job has not reached it yet (PATCH-01 busy):
        # it gets until the hard limit, not just the window
        $mutex.ReleaseMutex(); $mutex.Dispose()
        Write-Log ("update check: agent " + [string]$m.to + " checks in but has not had PATCH-01's check job yet; waiting")
        return
    }
    try {
        $m = Read-UpdateMarker
        if (-not $m) { Remove-UpdateCheck; return }
        try { $cur = Get-FileSha256 $installed } catch { $cur = $null }
        if ($cur -ne [string]$m.sha_new) { Remove-Item -LiteralPath $UpdateMarker -Force -ErrorAction SilentlyContinue; Remove-UpdateCheck; return }
        $back = [IO.File]::ReadAllBytes($prev)
        if ((Get-BytesSha256 $back) -ne [string]$m.sha_prev) {
            Write-Log ("update check: agent " + [string]$m.to + " has not checked in, but the kept copy of " + [string]$m.from + " has changed, so it was not put back. Reinstall the agent (Install-PatchAgent.bat).") "ERROR"
        } else {
            Set-AgentFile $installed $back ([string]$m.sha_prev)
            $why = $(if (Test-NewVersionCheckedIn $m) { "checked in but did not answer PATCH-01's check" } else { "did not check in" })
            Write-Log ("agent " + [string]$m.to + " " + $why + " within " + $UpdateConfirmMinutes + " minutes of the update: agent " + [string]$m.from + " was put back") "ERROR"
        }
        Remove-Item -LiteralPath $UpdateMarker -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $UpdateCheckin -Force -ErrorAction SilentlyContinue
    } finally {
        $mutex.ReleaseMutex(); $mutex.Dispose()
    }
    Remove-UpdateCheck
}

function Start-Check {
    $cfg = Get-Config
    Assert-Https ([string]$cfg.server)
    [void](Get-Token)
    Write-Output ("PATCH-01 agent " + $AgentVersion + " ready")
}

# ---------------------------------------------------------------------------
# Modes
# ---------------------------------------------------------------------------
function Send-RunStats($Token, [datetime]$Since) {
    <# How long this run took and where the time went. A slow part is named in
       the log (and on the Servers page), so "the agent is slow" has an answer. #>
    $total = ((Get-Date) - $Since).TotalSeconds
    $ph = @{}; $slow = $null; $max = 0.0
    foreach ($k in @($script:Phases.Keys)) {
        $v = [math]::Round([double]$script:Phases[$k], 1); $ph[$k] = $v
        if ($k -ne "waiting for the next step" -and $v -gt $max) { $max = $v; $slow = $k }
    }
    if ($total -ge 30) {
        $parts = @($script:Phases.Keys | ForEach-Object { $_ + " " + [int][double]$script:Phases[$_] + " s" })
        Write-Log ("run took " + [int]$total + " s: " + ($parts -join ", "))
    }
    try { Invoke-Api "POST" "/api/v1/agent/run-stats" @{ seconds = [math]::Round($total, 1); commands = [int]$script:CommandCount; phases = $ph; slowest = $slow } $Token -Timeout 20 | Out-Null }
    catch { Write-Verbose ("run stats not sent: " + $_.Exception.Message) }       # an older PATCH-01: ignored
}

function Start-Run {
    # One run at a time: a slow Windows Update search must not overlap the next
    $mutex = New-Object Threading.Mutex($false, "Global\PatchAgentRun")
    $owned = $false
    try { $owned = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owned = $true }   # the last run was killed
    if (-not $owned) {
        $mutex.Dispose()
        if ($Inventory) { throw "another agent run is in progress; try again in a few minutes" }
        Write-Log "previous run still busy; skipping"; return
    }
    $tok = $null
    $runStart = Get-Date
    $script:CommandCount = 0
    try {
        $cfg = Get-Config
        Initialize-Http $cfg.pin
        $tok = Get-Token
        $script:RunToken = $tok
        $tp = Get-Date
        Send-Checkin $tok
        Add-Phase "checkin" $tp
        Write-UpdateCheckin
        # PATCH-01 queues a job's next step within seconds of a result: after a step, keep
        # asking every 10 seconds for up to 2 minutes instead of waiting for the next run
        $done = $false; $lastCmd = $null; $skipInventory = $false
        # -Inventory (used by the installer to prove the agent works) only reports: it never
        # runs a queued job step in an administrator's window
        $rounds = 0
        while (-not $Inventory) {
            # Bounded: a run never holds the agent for ever, whatever PATCH-01 keeps sending
            if (++$rounds -gt 400 -or ((Get-Date) - $runStart).TotalHours -ge 11) { Write-Log "this run has worked long enough; the next run carries on" "WARN"; break }
            $tp = Get-Date
            $r = Invoke-Commands $tok
            Add-Phase "job steps" $tp
            $script:CommandCount += $r.count
            if ($r.inventory) { $done = $true }
            if ($r.rebooting) { break }
            # This file was just replaced: the next run is the new version, and nothing else holds it up
            # (no inventory now, so the new version's first run is not kept waiting)
            if (Get-Prop $r "updated") { $skipInventory = $true; break }
            if ($r.count -gt 0) { $lastCmd = Get-Date }
            if (-not $lastCmd -or ((Get-Date) - $lastCmd).TotalSeconds -ge $FollowUpSeconds) { break }
            $tp = Get-Date
            Start-Sleep -Seconds 10
            Add-Phase "waiting for the next step" $tp
        }
        $state = Get-State
        if (-not $state.PSObject.Properties["last_inventory"]) { $state | Add-Member -NotePropertyName last_inventory -NotePropertyValue $null }
        $due = $true
        if ($state.last_inventory) {
            $due = ((Get-Date) - [datetime]$state.last_inventory).TotalHours -ge $InventoryEveryHours
        }
        # While this version is waiting to be confirmed, nothing long holds the agent
        $um = Read-UpdateMarker
        if ($um -and [string]$um.to -eq $AgentVersion) { $skipInventory = $true }
        if ($Inventory -or ($due -and -not $done -and -not $skipInventory)) { $tp = Get-Date; Send-Inventory $tok; Add-Phase "inventory" $tp; $done = $true }
        if ($done) { $state = Get-State; if (-not $state.PSObject.Properties["last_inventory"]) { $state | Add-Member -NotePropertyName last_inventory -NotePropertyValue $null }; $state.last_inventory = (Get-Date).ToString("o"); Save-State $state }
    } catch {
        $where = ""; if ($_.InvocationInfo) { $where = " (line " + $_.InvocationInfo.ScriptLineNumber + ")" }
        Write-Log ("run failed: " + $_.Exception.Message + $where) "ERROR"
        throw
    } finally {
        # Whatever happened, the console gets this run's log lines and timings
        try { if ($tok) { Send-RunStats $tok $runStart } } catch { }
        try { if ($tok) { Send-LogTail $tok } } catch { }
        if ($owned) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}

function Start-Enroll {
    Assert-Https $Server
    if (-not (Test-Path $DataDir)) { New-Item -ItemType Directory -Path $DataDir | Out-Null }
    # Only SYSTEM and Administrators may read the agent's data (its token is written here next), also
    # when -Enroll is run by hand rather than through the installers
    $acl = New-Object Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sid in @("S-1-5-18", "S-1-5-32-544")) {
        $id = (New-Object Security.Principal.SecurityIdentifier($sid))
        $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($id, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")))
    }
    $acl.SetOwner((New-Object Security.Principal.SecurityIdentifier("S-1-5-32-544")))
    Set-Acl -Path $DataDir -AclObject $acl
    $script:Cfg = [pscustomobject]@{ server = $Server.TrimEnd("/"); pin = $Pin.Trim().ToLowerInvariant() }
    Initialize-Http $script:Cfg.pin
    $f = Get-Facts
    $body = @{ enrollment_token = $Token; machine_id = $f.MachineId; hostname = $f.Hostname; os_id = "windows"
               os_version = $f.Version; arch = "x86_64"; pkg_manager = "wua"; agent_version = $AgentVersion }
    if ($f.Fqdn -and $f.Fqdn -ne $f.Hostname) { $body["fqdn"] = $f.Fqdn }
    # The machine's BIOS UUID: PATCH-01 accepts a re-enrolment of an active server only from the same machine
    if ($f.Uuid) { $body["hardware_uuid"] = $f.Uuid }
    $resp = Invoke-Api "POST" "/api/v1/agent/enroll" $body
    ConvertTo-Json -InputObject @{ server = $script:Cfg.server; pin = $script:Cfg.pin; host_id = $resp.host_id } | Set-Content -Path $ConfigFile -Encoding UTF8
    Save-Token $resp.agent_token
    Write-Log ("enrolled as {0} ({1})" -f $f.Hostname, $resp.host_id)
    Write-Output ("Enrolled {0} with PATCH-01. Host id {1}." -f $f.Hostname, $resp.host_id)
}

function Start-Identity {
    <# For the installers, before an upgrade: does PATCH-01 still accept the agent
       identity saved on this server? A server removed or decommissioned on PATCH-01,
       or rebuilt or cloned (its saved token can no longer be read), needs a new
       enrolment, not an upgrade. Prints one line, "IDENTITY <state>":
         ok | none | unreadable | revoked | decommissioned | pin | unreachable
       Contacts PATCH-01 with an empty check-in: nothing else changes there, and
       nothing changes on this server. The token is never printed. #>
    Assert-Https $Server
    if (-not (Test-Path $ConfigFile) -or -not (Test-Path $TokenFile)) { Write-Output "IDENTITY none"; return }
    $tok = $null
    try { $tok = Get-Token } catch { Write-Output "IDENTITY unreadable"; return }
    if (-not $tok) { Write-Output "IDENTITY unreadable"; return }
    $script:Cfg = [pscustomobject]@{ server = $Server.TrimEnd("/"); pin = $Pin.Trim().ToLowerInvariant() }
    try {
        Initialize-Http $script:Cfg.pin
        Invoke-Api "POST" "/api/v1/agent/checkin" @{} $tok -Timeout 30 | Out-Null
        Write-Output "IDENTITY ok"
    } catch {
        $m = [string]$_.Exception.Message
        if ($m -match "does not match the pin") { Write-Output "IDENTITY pin" }
        elseif ($m -match "HTTP 401|unknown or revoked token") { Write-Output "IDENTITY revoked" }
        elseif ($m -match "HTTP 403|host is decommissioned") { Write-Output "IDENTITY decommissioned" }
        else {
            $first = ((($m -split "`n")[0]) -replace '[^\x20-\x7E]', '')
            if ($first.Length -gt 200) { $first = $first.Substring(0, 200) }
            Write-Output ("IDENTITY unreachable " + $first)
        }
    } finally { $tok = $null }
}

function Start-SelfTest {
    Assert-Https $Server
    $results = New-Object Collections.ArrayList
    function Step([string]$Name, [scriptblock]$Do) {
        try { $d = & $Do; [void]$results.Add([pscustomobject]@{ Step = $Name; Result = "ok"; Detail = [string]$d }) }
        catch { [void]$results.Add([pscustomobject]@{ Step = $Name; Result = "FAILED"; Detail = $_.Exception.Message }) }
    }
    $script:Cfg = [pscustomobject]@{ server = $Server.TrimEnd("/"); pin = $Pin.Trim().ToLowerInvariant() }
    Step "Run as administrator" { $id = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
                                  if (-not $id.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw "run PowerShell as administrator" }; "yes" }
    Step "PowerShell version" { if ($PSVersionTable.PSVersion.Major -lt 5) { throw ("5.1 needed, found " + $PSVersionTable.PSVersion) }; [string]$PSVersionTable.PSVersion }
    Step "Reach PATCH-01, certificate pin" { Initialize-Http $script:Cfg.pin; $h = Invoke-Api "GET" "/api/v1/health"; "reached; certificate " + [PatchAgentPin]::Seen.Substring(0, 16) + "... matches" }
    Step "OS build" { $b = Get-Build; "{0} ({1}), Windows Server {2}" -f $b.Build, $b.Product, (Get-ServerVersion $b) }
    Step "Reboot state" { $r = Get-RebootState; if ($r.Required) { "reboot pending: " + $r.Reason } else { "no reboot pending" } }
    Step "Hardware ID (links the VM)" { $f = Get-Facts; if ($f.Uuid) { $f.Uuid } else { throw "no usable UUID from Win32_ComputerSystemProduct" } }
    Step "Installed updates" { "{0} KBs" -f @(Get-HotFix -ErrorAction SilentlyContinue).Count }
    Step "Update source" { $s = Get-WsusSource; if ($s.Source -eq "wsus") { "WSUS at " + $s.Server } else { "Microsoft Update directly (no WSUS policy found)" } }
    Step "Windows Update" { $svc = Get-Service wuauserv; if ([string]$svc.StartType -eq "Disabled") { throw "the Windows Update service is disabled" }
                            $u = Search-MissingUpdates -Offline; "service " + [string]$svc.Status + "; " + $u.Count + " updates missing in Windows' own list (the first inventory asks WSUS)" }
    Step "Update source reachable" { $s = Get-WsusSource; if ($s.Source -ne "wsus") { "Microsoft Update (no WSUS policy)" } else { $u = [Uri]$s.Server; $why = Test-Tcp $u.Host $u.Port; if ($why) { throw ("WSUS at " + $s.Server + ": " + $why) }; "WSUS at " + $s.Server + " answers" } }
    $results | Format-Table -AutoSize -Wrap | Out-String -Width 200 | Write-Output
    $failed = @($results | Where-Object { $_.Result -ne "ok" }).Count
    if ($failed) { Write-Output "$failed step(s) failed: fix them before enrolling." } else { Write-Output "All steps passed: this server is ready to enrol." }
}

switch ($PSCmdlet.ParameterSetName) {
    "SelfTest"  { Start-SelfTest }
    "Enroll"    { Start-Enroll }
    "Inventory" { Start-Run }
    "Check"     { Start-Check }
    "UpdateCheck" { Start-UpdateCheck }
    "Identity"  { Start-Identity }
    default     { Start-Run }
}
