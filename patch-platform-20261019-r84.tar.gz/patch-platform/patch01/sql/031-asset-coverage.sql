-- ===========================================================================
-- PATCH-01 : schema 031 - Apex Central in the asset inventory; coverage gaps
--
-- Applied after 030. Idempotent.
--
-- Apex Central's agents become a fifth inventory source. Where Apex reports
-- the operating system (the agent list on some versions, or the Pattern
-- Update Status log), it is used for laptops and desktops, where it tells
-- Windows 10 from 11 better than WSUS.
--
-- Coverage: which machines are missing in WSUS or in Apex, with the evidence
-- for why, worked out on PATCH-01. AI-01 writes the summary and the order to
-- fix them in, from those figures only; each summary is kept with them.
--
-- Machines found in both WSUS and the uploaded sheet are approved
-- automatically, recorded as approved by "auto". A machine whose approval a
-- person took back is never approved automatically again.
-- ===========================================================================

ALTER TABLE av_agents ADD COLUMN IF NOT EXISTS os TEXT;     -- when the console's agent list says

CREATE TABLE IF NOT EXISTS asset_gap_summaries (
    id          BIGSERIAL PRIMARY KEY,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    facts       JSONB NOT NULL,
    text        TEXT NOT NULL,
    source      TEXT NOT NULL CHECK (source IN ('ai', 'facts')),
    model       TEXT,
    created_by  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_asset_gap_summaries ON asset_gap_summaries (created_at DESC);

-- The inventory reads each agent's OS from the Pattern Update Status log by console and short name
CREATE INDEX IF NOT EXISTS idx_av_pattern_status_short
    ON av_pattern_status (console_id, lower(split_part(host_name, '.', 1)), seen_at DESC);

INSERT INTO schema_version (version, description)
VALUES (31, 'Apex Central as an inventory source; WSUS and Apex coverage gaps; auto-approval (WSUS + sheet)')
ON CONFLICT (version) DO NOTHING;
