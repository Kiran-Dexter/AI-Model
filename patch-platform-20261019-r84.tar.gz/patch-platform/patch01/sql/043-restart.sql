-- ===========================================================================
-- PATCH-01 : schema 043 - restart-only jobs
--
-- Applied after 042. Idempotent.
--
-- restart   a change that restarts chosen servers and nothing else (admins only):
--           pre-check (running services), restart, wait for it to come back,
--           the post-check (the same services running) and an inventory report.
-- ===========================================================================

ALTER TYPE change_kind ADD VALUE IF NOT EXISTS 'restart';

INSERT INTO schema_version (version, description)
VALUES (43, 'Restart-only jobs')
ON CONFLICT (version) DO NOTHING;
