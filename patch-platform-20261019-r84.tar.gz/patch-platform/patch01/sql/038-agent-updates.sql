-- ===========================================================================
-- PATCH-01 : schema 038 - agent updates from PATCH-01
--
-- Applied after 037. Idempotent.
--
-- agent_update   a change that moves agents to a version published on PATCH-01
--                (scripts/phase12-agents.sh). Each server's agent downloads the
--                file over its pinned connection, checks its SHA-256 (and its
--                signature when the agent runs signed), tests it, swaps itself
--                and keeps the previous version; if the new one does not check
--                in, the previous version puts itself back.
-- update_agent   the agent verb for that step (agents 1.8.0 and later)
-- ===========================================================================

ALTER TYPE agent_verb ADD VALUE IF NOT EXISTS 'update_agent';
ALTER TYPE change_kind ADD VALUE IF NOT EXISTS 'agent_update';

INSERT INTO schema_version (version, description)
VALUES (38, 'Agent updates from PATCH-01')
ON CONFLICT (version) DO NOTHING;
