-- ===========================================================================
-- PATCH-01 : schema 035 - vCenter inventory every few minutes, and on request
--
-- Applied after 034. Idempotent.
--
-- The worker reads each vCenter every 5 minutes (VMWARE_SYNC_MINUTES), so a
-- new VM is linked to its server soon after the agent enrols. A patch job
-- that needs a snapshot of a server not linked yet asks for a read at once.
-- ===========================================================================

ALTER TABLE vcenters ADD COLUMN IF NOT EXISTS sync_requested_at TIMESTAMPTZ;

-- Servers tab "Last patched" and Patch Reports read a server's patch jobs by host
CREATE INDEX IF NOT EXISTS idx_ctargets_host ON change_targets (host_id, updated_at DESC);

INSERT INTO schema_version (version, description)
VALUES (35, 'vCenter inventory read every 5 minutes by the worker, and on request; patch history by server')
ON CONFLICT (version) DO NOTHING;
