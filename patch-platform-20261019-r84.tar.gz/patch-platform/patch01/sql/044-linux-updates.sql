-- ===========================================================================
-- PATCH-01 : schema 044 - patching from the servers' own word
--
-- Applied after 043. Idempotent.
--
-- linux_updates            what each Linux server's package manager would
--                          install now (dnf/yum check-update, apt-get -s
--                          upgrade), sent by agent 1.8.2 and later with each
--                          inventory. Replaced on every report. This, not the
--                          CVE feeds, is "to install" on the patching pages.
-- hosts.updates_checked_at when that list was last made, and the error if the
-- hosts.updates_error      package manager could not make it (repositories
--                          unreachable, for example).
-- linux_package_installs   every package version seen installed on a Linux
--                          server, with its install time (rpm INSTALLTIME,
--                          dpkg's file list time): the history behind the
--                          Installed patches report. Kept when the package is
--                          upgraded again; removed with the server.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS linux_updates (
    host_id      UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    name         TEXT NOT NULL,
    arch         TEXT NOT NULL DEFAULT 'noarch',
    installed    TEXT,
    available    TEXT NOT NULL,
    repo         TEXT,
    security     BOOLEAN,
    advisory     TEXT,          -- the repository's own update notice (e.g. ELSA-...), when it names one
    severity     TEXT,
    reported_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (host_id, name, arch)
);

ALTER TABLE hosts ADD COLUMN IF NOT EXISTS updates_checked_at TIMESTAMPTZ;
ALTER TABLE hosts ADD COLUMN IF NOT EXISTS updates_error TEXT;

CREATE TABLE IF NOT EXISTS linux_package_installs (
    host_id       UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    name          TEXT NOT NULL,
    arch          TEXT NOT NULL DEFAULT 'noarch',
    version       TEXT NOT NULL,          -- as the package manager reports it (epoch:version-release)
    installed_at  TIMESTAMPTZ,            -- the package manager's install time; NULL when it keeps none
    first_seen    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (host_id, name, arch, version)
);
CREATE INDEX IF NOT EXISTS idx_lpi_host_time ON linux_package_installs (host_id, installed_at DESC);
CREATE INDEX IF NOT EXISTS idx_lpi_time ON linux_package_installs (installed_at DESC);

-- One place for "to install" on the patching pages, from the servers' own word:
--   Windows  what Windows Update reports missing against WSUS
--   Linux    the package manager's security updates (an update whose kind it
--            cannot tell counts too); NULL until agent 1.8.2 reports
-- The CVE feeds (host_applicability) are the Vulnerabilities pages' business.
CREATE OR REPLACE VIEW v_host_patch AS
SELECT h.id AS host_id,
       CASE WHEN h.os_id = 'windows'
            THEN (SELECT count(*) FROM windows_updates wu WHERE wu.host_id = h.id)
            WHEN h.updates_checked_at IS NOT NULL
            THEN (SELECT count(*) FROM linux_updates lu WHERE lu.host_id = h.id AND lu.security IS NOT FALSE)
       END AS to_install,
       CASE WHEN h.os_id <> 'windows' AND h.updates_checked_at IS NOT NULL
            THEN (SELECT count(*) FROM linux_updates lu WHERE lu.host_id = h.id)
       END AS updates_available,
       h.updates_checked_at, h.updates_error
  FROM hosts h;

INSERT INTO schema_version (version, description)
VALUES (44, 'Linux updates from the package manager, package install history')
ON CONFLICT (version) DO NOTHING;
