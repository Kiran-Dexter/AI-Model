-- ===========================================================================
-- PATCH-01 : schema 036 - Deployment: packages uploaded to PATCH-01, and how
--            long each agent run takes
--
-- Applied after 035. Idempotent.
--
-- An MSI or EXE is uploaded in the console (Deployment), kept on PATCH-01
-- under its SHA-256, optionally scanned by ClamAV, described by AI-01, then
-- reviewed by an operator. Deploying it is an ordinary software change: each
-- server's agent downloads it from PATCH-01 over the pinned HTTPS connection,
-- checks the SHA-256 and installs it.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS deploy_packages (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_name          TEXT NOT NULL,
    kind               TEXT NOT NULL CHECK (kind IN ('msi', 'exe')),
    size_bytes         BIGINT NOT NULL CHECK (size_bytes > 0),
    sha256             TEXT NOT NULL CHECK (sha256 ~ '^[0-9a-f]{64}$'),
    uploaded_by        TEXT NOT NULL,
    uploaded_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    -- What PATCH-01 read from the file itself (version resource, MSI properties,
    -- installer technology, whether it carries a signature)
    meta               JSONB NOT NULL DEFAULT '{}'::jsonb,
    -- AI-01's description and suggestions (never used without review)
    ai                 JSONB,
    ai_state           TEXT NOT NULL DEFAULT 'pending'
                       CHECK (ai_state IN ('pending', 'done', 'failed', 'off')),
    ai_error           TEXT,
    ai_at              TIMESTAMPTZ,
    -- ClamAV on PATCH-01 (optional)
    scan_state         TEXT NOT NULL DEFAULT 'pending'
                       CHECK (scan_state IN ('pending', 'clean', 'infected', 'failed', 'off')),
    scan_result        TEXT,
    scanned_at         TIMESTAMPTZ,
    -- What a deployment uses, as reviewed and saved by an operator
    name               TEXT,
    version            TEXT,
    vendor             TEXT,
    detect_name        TEXT,
    install_args       TEXT,
    notes              TEXT,
    require_signature  BOOLEAN NOT NULL DEFAULT FALSE,
    publisher          TEXT,
    ready              BOOLEAN NOT NULL DEFAULT FALSE,
    reviewed_by        TEXT,
    reviewed_at        TIMESTAMPTZ,
    deleted_at         TIMESTAMPTZ,
    deleted_by         TEXT
);

-- One live copy of a file: uploading it again returns the existing package
CREATE UNIQUE INDEX IF NOT EXISTS uq_deploy_packages_sha
    ON deploy_packages (sha256) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_deploy_packages_work
    ON deploy_packages (scan_state, ai_state) WHERE deleted_at IS NULL;

-- An upload in progress (sent in pieces, so no size limit in the web proxy applies)
CREATE TABLE IF NOT EXISTS deploy_uploads (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_name    TEXT NOT NULL,
    kind         TEXT NOT NULL CHECK (kind IN ('msi', 'exe')),
    size_bytes   BIGINT NOT NULL CHECK (size_bytes > 0),
    received     BIGINT NOT NULL DEFAULT 0,
    started_by   TEXT NOT NULL,
    started_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- How long the agent's last run took, and which part (Servers page)
ALTER TABLE hosts ADD COLUMN IF NOT EXISTS agent_run JSONB;

INSERT INTO schema_version (version, description)
VALUES (36, 'Deployment: uploaded packages, ClamAV and AI-01; agent run timings')
ON CONFLICT (version) DO NOTHING;
