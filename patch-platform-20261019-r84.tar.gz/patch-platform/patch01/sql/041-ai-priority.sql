-- ===========================================================================
-- PATCH-01 : schema 041 - AI-01 shared fairly: people first
--
-- Applied after 040. Idempotent.
--
-- ai01_state   one row: until when a person is using AI-01 (a chat question,
--              an explanation). Background work (the 15-minute notes, failure
--              explanations, CVE briefs) does not start a new AI-01 request
--              before then, so the person is answered quickly. The API and the
--              worker are separate processes, so the mark is kept here.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS ai01_state (
    id                 SMALLINT PRIMARY KEY CHECK (id = 1),
    interactive_until  TIMESTAMPTZ NOT NULL DEFAULT now(),
    -- the last time background work used AI-01: it gets a turn at least every 10 minutes
    background_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE ai01_state ADD COLUMN IF NOT EXISTS background_at TIMESTAMPTZ NOT NULL DEFAULT now();
INSERT INTO ai01_state (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

INSERT INTO schema_version (version, description)
VALUES (41, 'AI-01 shared fairly: people before background work')
ON CONFLICT (version) DO NOTHING;
