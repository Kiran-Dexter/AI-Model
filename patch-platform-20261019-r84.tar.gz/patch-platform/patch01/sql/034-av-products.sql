-- ===========================================================================
-- PATCH-01 : schema 034 - the products each Apex Central manages
--
-- Applied after 033. Idempotent.
--
-- Apex Central's product servers (Apex One servers, Deep Security Managers,
-- email security products and others) are discovered per console. An admin
-- then ticks which to sync: once chosen, only the agents of the ticked
-- servers are kept. A Deep Security Manager can also be read directly with
-- its own API key (read-only), for each computer's status, OS and last
-- contact; its agents then come from the Manager, not from Apex Central.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS av_products (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    console_id      UUID NOT NULL REFERENCES av_consoles(id) ON DELETE CASCADE,
    entity_id       TEXT NOT NULL,
    product         TEXT,
    kind            TEXT NOT NULL DEFAULT 'other' CHECK (kind IN ('endpoint', 'deep_security', 'email', 'other')),
    host_name       TEXT,
    ad_domain       TEXT,
    ip_addresses    TEXT[] NOT NULL DEFAULT '{}',
    capabilities    TEXT[] NOT NULL DEFAULT '{}',
    selected        BOOLEAN,                          -- NULL until an admin chooses
    first_seen      TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen       TIMESTAMPTZ NOT NULL DEFAULT now(),
    -- A Deep Security Manager read directly (optional)
    dsm_url         TEXT,
    dsm_key_enc     TEXT,
    dsm_ca_pem      TEXT,
    dsm_pin_sha256  TEXT CHECK (dsm_pin_sha256 IS NULL OR dsm_pin_sha256 ~ '^[0-9a-f]{64}$'),
    dsm_pin_subject TEXT,
    dsm_use_proxy   BOOLEAN NOT NULL DEFAULT false,
    dsm_enabled     BOOLEAN NOT NULL DEFAULT false,
    dsm_set_by      TEXT,
    dsm_set_at      TIMESTAMPTZ,
    last_sync_at    TIMESTAMPTZ,
    last_sync_ok    BOOLEAN,
    last_sync_msg   TEXT,
    agents          INTEGER,
    sync_requested_at TIMESTAMPTZ,
    gone_at         TIMESTAMPTZ,                      -- no longer listed by Apex Central's last discovery
    UNIQUE (console_id, entity_id)
);
ALTER TABLE av_products ADD COLUMN IF NOT EXISTS gone_at TIMESTAMPTZ;

ALTER TABLE av_consoles ADD COLUMN IF NOT EXISTS products_chosen BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE av_consoles ADD COLUMN IF NOT EXISTS products_checked_at TIMESTAMPTZ;
-- Set for agents read straight from a Deep Security Manager
ALTER TABLE av_agents ADD COLUMN IF NOT EXISTS product_id UUID REFERENCES av_products(id) ON DELETE CASCADE;
CREATE INDEX IF NOT EXISTS idx_av_agents_product ON av_agents (product_id) WHERE product_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_av_agents_managing ON av_agents (console_id, managing_server_id);

-- Every agent with whether it is still listed by its source (Apex Central, or its Deep Security Manager)
DROP VIEW IF EXISTS v_av_agents;     -- a.* is fixed when the view is made: rebuilt on every run
CREATE VIEW v_av_agents AS
SELECT a.*, c.name AS console,
       (NOT c.enabled OR a.last_seen < now() - interval '48 hours'
        OR CASE WHEN a.product_id IS NULL
                THEN coalesce(c.last_sync_ok AND a.last_seen < c.last_sync_at - interval '1 minute', false)
                ELSE coalesce(p.last_sync_ok AND a.last_seen < p.last_sync_at - interval '1 minute', false) END) AS not_listed,
       p.host_name AS via_product
  FROM av_agents a JOIN av_consoles c ON c.id = a.console_id
  LEFT JOIN av_products p ON p.id = a.product_id;

INSERT INTO schema_version (version, description)
VALUES (34, 'Products managed by each Apex Central (discover, choose); Deep Security Managers read directly')
ON CONFLICT (version) DO NOTHING;
