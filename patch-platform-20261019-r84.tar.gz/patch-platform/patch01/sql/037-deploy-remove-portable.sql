-- ===========================================================================
-- PATCH-01 : schema 037 - Deployment: removal, portable programs, time limit
--
-- Applied after 036. Idempotent.
--
-- install_mode   installer: the file is run silently (MSI or EXE installer)
--                portable:  the file is a program that needs no installing; it
--                           is copied to C:\Program Files\PATCH01-Apps\<folder>
--                           and never run by the agent
-- uninstall_args silent options for the program's own uninstaller (EXE); empty
--                lets the agent use the program's QuietUninstallString or the
--                documented options of its installer technology
-- timeout_min    how long the installer may run before it is stopped: a hung
--                installer (waiting for input) is ended and reported
-- ===========================================================================

ALTER TABLE deploy_packages ADD COLUMN IF NOT EXISTS install_mode TEXT NOT NULL DEFAULT 'installer';
ALTER TABLE deploy_packages ADD COLUMN IF NOT EXISTS uninstall_args TEXT;
ALTER TABLE deploy_packages ADD COLUMN IF NOT EXISTS timeout_min INTEGER NOT NULL DEFAULT 30;
ALTER TABLE deploy_packages ADD COLUMN IF NOT EXISTS app_folder TEXT;

DO $$ BEGIN
    ALTER TABLE deploy_packages ADD CONSTRAINT chk_deploy_mode CHECK (install_mode IN ('installer', 'portable'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
    ALTER TABLE deploy_packages ADD CONSTRAINT chk_deploy_timeout CHECK (timeout_min BETWEEN 5 AND 160);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

INSERT INTO schema_version (version, description)
VALUES (37, 'Deployment: removal, portable programs, installer time limit')
ON CONFLICT (version) DO NOTHING;
