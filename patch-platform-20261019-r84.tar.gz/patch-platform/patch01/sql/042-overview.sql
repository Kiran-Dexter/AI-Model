-- ===========================================================================
-- PATCH-01 : schema 042 - the Overview's history
--
-- Applied after 041. Idempotent.
--
-- overview_daily   one row a day (written by the worker): servers, online,
--                  servers to patch, critical CVEs and patch success. The
--                  Overview shows each figure's change since a week ago; until
--                  a week of rows exists the change is shown as not known yet.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS overview_daily (
    day            DATE PRIMARY KEY,
    servers        INTEGER NOT NULL,
    online         INTEGER NOT NULL,
    to_patch       INTEGER NOT NULL,
    critical_cves  INTEGER,
    success_pct    NUMERIC(5,1),
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO schema_version (version, description)
VALUES (42, 'Overview history: one row a day')
ON CONFLICT (version) DO NOTHING;
