-- ===========================================================================
-- PATCH-01 : schema 033 - VM created date, VM templates
--
-- Applied after 032. Idempotent.
--
-- vCenter's own creation date for each VM (config.createDate, vSphere 6.7
-- and later), and the VM templates, kept in their own table: a template is
-- not a running machine, so it never reaches the VM list, power or snapshot
-- actions, patching or coverage.
-- ===========================================================================

ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS create_date TIMESTAMPTZ;

CREATE TABLE IF NOT EXISTS vm_templates (
    vcenter          TEXT NOT NULL REFERENCES vcenters(name) ON DELETE CASCADE,
    moref            TEXT NOT NULL,
    name             TEXT,
    guest_os         TEXT,
    folder_path      TEXT,
    datacenter       TEXT,
    cluster          TEXT,
    esxi_host        TEXT,
    num_cpu          INTEGER,
    memory_mb        INTEGER,
    storage_mb       BIGINT,
    hardware_version TEXT,
    annotation       TEXT,
    create_date      TIMESTAMPTZ,
    synced_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (vcenter, moref)
);

INSERT INTO schema_version (version, description)
VALUES (33, 'VM created date; VM templates in their own table')
ON CONFLICT (version) DO NOTHING;
