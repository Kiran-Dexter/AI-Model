-- ===========================================================================
-- PATCH-01 : schema 040 - Windows installed updates in full, honest "to install"
--
-- Applied after 039. Idempotent.
--
-- windows_installed_updates   what each Windows server has installed, with the
--                             details (title, type, date, by whom, result), sent
--                             by agent 1.9.0 and later. Older agents: the console
--                             shows the KBs from the inventory, as before.
-- (Updates in Windows' cached list whose KB is already installed are no
--  longer stored as "to install": the API filters each new report.)
-- ===========================================================================

CREATE TABLE IF NOT EXISTS windows_installed_updates (
    host_id       UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    kb            TEXT,
    title         TEXT,
    kind          TEXT,
    installed_on  TIMESTAMPTZ,
    installed_by  TEXT,
    result        TEXT,
    source        TEXT NOT NULL CHECK (source IN ('hotfix', 'history')),
    reported_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_win_installed_host ON windows_installed_updates (host_id, installed_on DESC);

INSERT INTO schema_version (version, description)
VALUES (40, 'Windows installed updates in full')
ON CONFLICT (version) DO NOTHING;
