-- ===========================================================================
-- PATCH-01 : schema 032 - asset device types, hardware details, type choices
--
-- Applied after 031. Idempotent.
--
-- Device types: server, client (laptop/desktop), esxi, appliance, network,
-- firewall, unknown. The type is decided in this order:
--   a person's choice ("Set type")      asset_type_overrides
--   vCenter's facts                     ESXi hosts, the vCenter appliance
--   the operating system                Windows, Linux distributions, FortiOS...
--   the uploaded sheet's device column  Firewall, Switch, Laptop...
--   the machine's name                  fw-, sw-, core-... (only when nothing else says)
--   AI-01                               asset_ai_class, checked to be one of the types
-- Only servers and laptops/desktops are expected in WSUS and Apex.
--
-- The uploaded sheet can now also carry the make and model (Hardware view).
-- ===========================================================================

ALTER TABLE manual_assets DROP CONSTRAINT IF EXISTS manual_assets_device_check;
ALTER TABLE manual_assets ADD CONSTRAINT manual_assets_device_check
    CHECK (device IN ('server', 'client', 'esxi', 'appliance', 'network', 'firewall', 'unknown'));
ALTER TABLE manual_assets ADD COLUMN IF NOT EXISTS manufacturer TEXT;
ALTER TABLE manual_assets ADD COLUMN IF NOT EXISTS model TEXT;

ALTER TABLE asset_ai_types DROP CONSTRAINT IF EXISTS asset_ai_types_device_check;
ALTER TABLE asset_ai_types ADD CONSTRAINT asset_ai_types_device_check
    CHECK (device IN ('server', 'client', 'esxi', 'appliance', 'network', 'firewall', 'unknown'));

ALTER TABLE asset_events DROP CONSTRAINT IF EXISTS asset_events_action_check;
ALTER TABLE asset_events ADD CONSTRAINT asset_events_action_check
    CHECK (action IN ('approved', 'decommissioned', 'revoked', 'uploaded', 'ai_type', 'type_set'));

-- A person's choice of device type; it wins over every rule and AI-01
CREATE TABLE IF NOT EXISTS asset_type_overrides (
    asset_key   TEXT PRIMARY KEY CHECK (asset_key ~ '^[a-z0-9:._-]{1,255}$'),
    device      TEXT NOT NULL CHECK (device IN ('server', 'client', 'esxi', 'appliance', 'network', 'firewall', 'unknown')),
    set_by      TEXT NOT NULL,
    set_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    reason      TEXT
);

-- AI-01's device type for one machine, with what it was shown (asked again when that changes)
CREATE TABLE IF NOT EXISTS asset_ai_class (
    asset_key   TEXT PRIMARY KEY CHECK (asset_key ~ '^[a-z0-9:._-]{1,255}$'),
    device      TEXT NOT NULL CHECK (device IN ('server', 'client', 'esxi', 'appliance', 'network', 'firewall', 'unknown')),
    reason      TEXT,
    features    TEXT NOT NULL,              -- sha256 of what AI-01 was shown
    model       TEXT,
    decided_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO schema_version (version, description)
VALUES (32, 'Asset device types (ESXi, network, firewall), hardware make/model, type choices, AI-01 per-asset type')
ON CONFLICT (version) DO NOTHING;
