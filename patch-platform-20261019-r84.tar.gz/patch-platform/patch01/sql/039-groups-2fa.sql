-- ===========================================================================
-- PATCH-01 : schema 039 - patch groups, two-factor sign-in, fresh "to install"
--
-- Applied after 038. Idempotent.
--
-- host_groups        the patch groups (existing table): SIT, UAT, PROD-1, PROD-2
--                    and Cluster Servers are added; admins add more in the
--                    console. A server's group is hosts.host_group, as before.
-- hosts.packages_changed_at
--                    when a server's package list last changed: the worker
--                    recomputes that server's advisories ("to install") soon
--                    after, instead of waiting for the nightly run
-- users.totp_*       two-factor sign-in (an authenticator app, RFC 6238). The
--                    secret is stored encrypted with a key only the API holds.
-- user_mfa_challenges
--                    the short-lived step between the password and the code
-- ===========================================================================

INSERT INTO host_groups (name, description, environment, max_concurrent, patch_order) VALUES
    ('SIT', 'System integration test', 'test', 10, 10),
    ('UAT', 'User acceptance test', 'staging', 10, 20),
    ('PROD-1', 'Production, first wave', 'prod', 5, 30),
    ('PROD-2', 'Production, second wave', 'prod', 5, 40),
    ('Cluster Servers', 'Clustered servers: one node at a time', 'prod', 1, 50)
ON CONFLICT (name) DO NOTHING;

ALTER TABLE hosts ADD COLUMN IF NOT EXISTS packages_changed_at TIMESTAMPTZ;

ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_secret_enc TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_pending_enc TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_enabled BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_last_step BIGINT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_recovery TEXT[] NOT NULL DEFAULT '{}';
ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_enabled_at TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_setup_fails INTEGER NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS user_mfa_challenges (
    token_hash  TEXT PRIMARY KEY,
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at  TIMESTAMPTZ NOT NULL,
    attempts    INTEGER NOT NULL DEFAULT 0,
    source_ip   INET
);
CREATE INDEX IF NOT EXISTS idx_mfa_expires ON user_mfa_challenges (expires_at);

INSERT INTO schema_version (version, description)
VALUES (39, 'Patch groups, two-factor sign-in, fresh to-install counts')
ON CONFLICT (version) DO NOTHING;
