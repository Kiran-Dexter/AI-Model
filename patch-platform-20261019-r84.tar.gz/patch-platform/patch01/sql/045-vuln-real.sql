-- ===========================================================================
-- PATCH-01 : schema 045 - Vulnerabilities from proof only, appliances apart,
--            a daily history for the graphs, and an on-demand scan
--
-- Applied after 044. Idempotent.
--
-- cve_impact.appliances       network devices, firewalls and appliances from
--                             the asset inventory that a CVE names, each
--                             "affected" (its firmware version is in NVD's
--                             affected range) or "check" (the device matches
--                             the product; its version is not recorded)
-- cve_impact.appliance_state  'affected', 'check' or NULL
-- cve_impact_daily            one row a day: how many CVEs affect our servers,
--                             0-day among them, machines, appliances (graphs)
-- cve_feed_settings.scan_*    an on-demand scan: every server sends its
--                             inventory, vCenter is read, every CVE checked again
-- ===========================================================================

ALTER TABLE cve_impact ADD COLUMN IF NOT EXISTS appliances JSONB NOT NULL DEFAULT '[]';
ALTER TABLE cve_impact ADD COLUMN IF NOT EXISTS appliance_state TEXT;
ALTER TABLE cve_impact DROP CONSTRAINT IF EXISTS cve_impact_appliance_state_check;
ALTER TABLE cve_impact ADD CONSTRAINT cve_impact_appliance_state_check
    CHECK (appliance_state IS NULL OR appliance_state IN ('affected', 'check'));

CREATE TABLE IF NOT EXISTS cve_impact_daily (
    day              DATE PRIMARY KEY,
    affected         INT NOT NULL DEFAULT 0,
    exploited        INT NOT NULL DEFAULT 0,
    critical         INT NOT NULL DEFAULT 0,
    high             INT NOT NULL DEFAULT 0,
    machines         INT NOT NULL DEFAULT 0,
    appliances       INT NOT NULL DEFAULT 0,
    checked          INT NOT NULL DEFAULT 0,
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE cve_feed_settings ADD COLUMN IF NOT EXISTS scan_requested_at TIMESTAMPTZ;
ALTER TABLE cve_feed_settings ADD COLUMN IF NOT EXISTS scan_requested_by TEXT;
ALTER TABLE cve_feed_settings ADD COLUMN IF NOT EXISTS scan_servers INT;

-- Verdicts made under the old rules ("possibly affected", "reboot needed", "not tracked")
-- are withdrawn; every CVE in the window is checked again under the new rules within minutes
UPDATE cve_impact SET verdict = 'not_found', matches = '[]', machines = 0, inventory_mark = NULL
 WHERE verdict IN ('potentially_affected', 'pending_reboot', 'not_tracked');
UPDATE cve_impact SET inventory_mark = NULL;

INSERT INTO schema_version (version, description)
VALUES (45, 'Vulnerabilities from proof only, appliances apart, daily history, on-demand scan')
ON CONFLICT (version) DO NOTHING;
