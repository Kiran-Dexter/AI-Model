-- ===========================================================================
-- PATCH-01 : schema 030 - asset approval, decommissioning, uploaded assets
--
-- Applied after 029. Idempotent.
--
-- Every machine in the merged inventory (agents, vCenter, WSUS, uploaded
-- sheet) has a status:
--
--   new              seen by a source, not yet approved (no row here)
--   approved         confirmed as an asset
--   decommissioned   moved to the Decommissioned page
--
-- Approve, Decom and Revoke are granted per user in Admin > Access (admins
-- always have them). Every decision is kept in asset_events with who, when
-- and why, and also in the audit log.
--
-- Uploaded sheets (Excel or CSV, admins only) are parsed on PATCH-01; AI-01
-- only suggests which column holds what, and every row is checked again
-- before it is saved. An upload is shown as a preview and saved only when an
-- admin applies it.
-- ===========================================================================

-- Who may approve, decommission and revoke (admins always may)
ALTER TABLE users ADD COLUMN IF NOT EXISTS asset_perms TEXT[] NOT NULL DEFAULT '{}';

CREATE TABLE IF NOT EXISTS asset_records (
    asset_key     TEXT PRIMARY KEY,          -- the merge key: short host name, lower case
    name          TEXT NOT NULL,             -- the name as last shown
    status        TEXT NOT NULL CHECK (status IN ('new', 'approved', 'decommissioned')),
    prev_status   TEXT CHECK (prev_status IN ('new', 'approved')),
    approved_by   TEXT,
    approved_at   TIMESTAMPTZ,
    decom_by      TEXT,
    decom_at      TIMESTAMPTZ,
    decom_reason  TEXT,
    snapshot      JSONB,                     -- what the asset looked like when decommissioned
    updated_by    TEXT NOT NULL,
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (asset_key ~ '^[a-z0-9:._-]{1,255}$')
);
CREATE INDEX IF NOT EXISTS idx_asset_records_status ON asset_records (status);

CREATE TABLE IF NOT EXISTS asset_events (
    id         BIGSERIAL PRIMARY KEY,
    asset_key  TEXT NOT NULL,
    action     TEXT NOT NULL CHECK (action IN ('approved', 'decommissioned', 'revoked', 'uploaded', 'ai_type')),
    from_status TEXT,
    to_status  TEXT,
    actor      TEXT NOT NULL,
    at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    reason     TEXT,
    detail     JSONB
);
CREATE INDEX IF NOT EXISTS idx_asset_events_key ON asset_events (asset_key, at DESC);

-- Assets from an uploaded sheet ("Manual")
CREATE TABLE IF NOT EXISTS manual_assets (
    asset_key   TEXT PRIMARY KEY CHECK (asset_key ~ '^[a-z0-9:._-]{1,255}$'),
    name        TEXT NOT NULL,
    ips         TEXT[] NOT NULL DEFAULT '{}',
    os          TEXT,
    device      TEXT CHECK (device IN ('server', 'client', 'appliance', 'unknown')),
    location    TEXT,
    serial      TEXT,
    owner       TEXT,
    notes       TEXT,
    upload_id   UUID,
    updated_by  TEXT NOT NULL,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS asset_uploads (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_name    TEXT NOT NULL,
    sha256       TEXT NOT NULL CHECK (sha256 ~ '^[0-9a-f]{64}$'),
    uploaded_by  TEXT NOT NULL,
    uploaded_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    sheet        TEXT,
    header_row   INTEGER,
    headers      JSONB NOT NULL DEFAULT '[]'::jsonb,
    mapping      JSONB NOT NULL DEFAULT '{}'::jsonb,   -- field -> column index
    mapped_by    TEXT NOT NULL DEFAULT 'rules' CHECK (mapped_by IN ('ai', 'rules', 'admin')),
    rows         JSONB NOT NULL DEFAULT '[]'::jsonb,   -- the sheet's cells (text), kept until applied or discarded
    status       TEXT NOT NULL DEFAULT 'preview' CHECK (status IN ('preview', 'applied', 'discarded')),
    applied_by   TEXT,
    applied_at   TIMESTAMPTZ,
    result       JSONB
);
CREATE INDEX IF NOT EXISTS idx_asset_uploads_at ON asset_uploads (uploaded_at DESC);

-- AI-01's device type for an operating system text the rules could not place
CREATE TABLE IF NOT EXISTS asset_ai_types (
    os_key      TEXT PRIMARY KEY,            -- the OS text, lower case, trimmed
    os_text     TEXT NOT NULL,
    device      TEXT NOT NULL CHECK (device IN ('server', 'client', 'appliance', 'unknown')),
    model       TEXT,
    decided_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO schema_version (version, description)
VALUES (30, 'Asset approval, decommissioning and history; uploaded assets; AI-01 device types')
ON CONFLICT (version) DO NOTHING;
