/* Cyber-Secure: the dashboard, the CVE news boards, the sign-in welcome and
 * the CVE feed settings.
 *
 * Everything shown is text from the API, written with textContent (the h()
 * helper); nothing is inserted as HTML. Links to CVE pages are built by the
 * API, always to the vendor's own site, and open with no referrer.
 */

/* ---- brand ---------------------------------------------------------------- */

const PORTAL = "Cyber-Secure";
let brandInfo = null;

async function loadBrand() {
  if (brandInfo) return brandInfo;
  try {
    const r = await fetch("/api/v1/public/brand", { headers: { Accept: "application/json" } });
    brandInfo = r.ok ? await r.json() : { has_logo: false, has_logo_white: false };
  } catch (e) { brandInfo = { has_logo: false, has_logo_white: false }; }
  return brandInfo;
}

function isDarkTheme() {
  const t = document.documentElement.getAttribute("data-theme");
  return t === "dark" || t === "hacker";
}

/* The logo for a dark background (the menu is dark in every theme). */
function logoImg(onDark, cls) {
  const b = brandInfo || {};
  if (!b.has_logo && !b.has_logo_white) return null;
  const variant = onDark && b.has_logo_white ? "white" : "main";
  const img = h("img", { class: cls + (onDark && !b.has_logo_white ? " logo-chip" : ""),
                         src: "/api/v1/public/logo?variant=" + variant, alt: "", decoding: "async" });
  img.addEventListener("error", () => img.remove());
  return img;
}

async function applyBrand() {
  await loadBrand();
  loadOrg();
  document.title = PORTAL;
  const a = document.querySelector(".side .brand");
  if (a && !a.dataset.branded) {
    a.dataset.branded = "1";
    const img = logoImg(true, "brand-logo-top");
    a.replaceChildren(...[img, h("span", { class: "brand-name" }, PORTAL)].filter(Boolean));
    a.classList.toggle("has-logo", !!img);
    a.title = PORTAL;
    a.setAttribute("aria-label", PORTAL + " dashboard");
  }
}

/* ---- donuts --------------------------------------------------------------- */

const SVGNS = "http://www.w3.org/2000/svg";
function svg(tag, attrs, ...kids) {
  const el = document.createElementNS(SVGNS, tag);
  Object.entries(attrs || {}).forEach(([k, v]) => { if (v !== null && v !== undefined) el.setAttribute(k, String(v)); });
  kids.flat().forEach(k => { if (k) el.append(k instanceof Node ? k : document.createTextNode(String(k))); });
  return el;
}

/* segs: [{label, value, cls, href?, note?}]. Each colour comes from a class,
 * so the theme decides it; the legend always names every segment, so colour
 * never carries meaning on its own. */
function donut(title, segs, opts = {}) {
  const total = segs.reduce((a, s) => a + (Number(s.value) || 0), 0);
  const R = 52, SW = 14, C = 2 * Math.PI * R, GAP = total && segs.filter(s => s.value > 0).length > 1 ? 2.5 : 0;
  const ring = svg("g", { transform: "rotate(-90 70 70)" },
    svg("circle", { cx: 70, cy: 70, r: R, class: "dn-track", "stroke-width": SW, fill: "none" }));
  const tip = h("div", { class: "dn-tip", role: "status", "aria-live": "polite" });
  let start = 0;
  const shown = [];
  segs.forEach((s, i) => {
    const v = Number(s.value) || 0;
    if (!total || v <= 0) return;
    const len = Math.max(0.8, (v / total) * C - GAP);
    const pct = Math.round((v / total) * 100);
    const arc = svg("circle", {
      cx: 70, cy: 70, r: R, fill: "none", "stroke-width": SW, class: "dn-seg " + s.cls,
      "stroke-dasharray": "0 " + C, "stroke-dashoffset": -start, "data-len": len, "data-c": C, tabindex: 0,
      role: "img", "aria-label": s.label + ": " + v + " (" + pct + "%)" },
      svg("title", null, s.label + ": " + v + " (" + pct + "%)"));
    const show = () => { tip.textContent = s.label + ": " + v + " (" + pct + "%)" + (s.note ? " · " + s.note : ""); };
    arc.addEventListener("mouseenter", show);
    arc.addEventListener("focus", show);
    arc.addEventListener("mouseleave", () => { tip.textContent = ""; });
    if (s.href) arc.addEventListener("click", () => { location.hash = s.href; });
    if (s.href) arc.classList.add("dn-link");
    ring.append(arc);
    shown.push(arc);
    start += (v / total) * C;
  });
  const centre = svg("text", { x: 70, y: 68, "text-anchor": "middle", class: "dn-total" },
    opts.centre !== undefined ? opts.centre : String(total));
  const sub = svg("text", { x: 70, y: 88, "text-anchor": "middle", class: "dn-sub" },
    opts.centreLabel || (total ? "total" : "no data yet"));
  const pic = svg("svg", { viewBox: "0 0 140 140", class: "dn-svg", "aria-hidden": "true", focusable: "false" }, ring, centre, sub);
  const legend = h("ul", { class: "dn-legend" }, segs.map(s => {
    const v = Number(s.value) || 0;
    const label = h("span", { class: "dn-l", title: s.label }, s.label);
    return h("li", { class: v ? null : "dn-zero" },
      h("span", { class: "dn-key " + s.cls, "aria-hidden": "true" }),
      s.href ? h("a", { href: s.href }, label) : label,
      h("span", { class: "dn-v" }, String(v)),
      h("span", { class: "dn-p" }, total ? Math.round((v / total) * 100) + "%" : ""));
  }));
  // Draw the arcs once they are in the page, so they sweep in
  requestAnimationFrame(() => requestAnimationFrame(() => shown.forEach(a => {
    a.setAttribute("stroke-dasharray", a.dataset.len + " " + (Number(a.dataset.c) - Number(a.dataset.len)));
  })));
  return h("section", { class: "dn-card", "aria-label": title + ": " + segs.map(s => s.label + " " + (s.value || 0)).join(", ") },
    h("h2", { class: "dn-h" }, title),
    opts.caption ? h("p", { class: "dn-cap" }, opts.caption) : null,
    h("div", { class: "dn-body" }, h("div", { class: "dn-pic" }, pic, tip), legend));
}

/* ---- news board ------------------------------------------------------------ */

const FEED_NAME = { nist: "NIST NVD", msrc: "Microsoft", redhat: "Red Hat" };
const SEV_CLASS = { critical: "sv-crit", high: "sv-high", important: "sv-high", medium: "sv-med", moderate: "sv-med", low: "sv-low" };

function sevChip(sev, cvss) {
  const s = (sev || "").toLowerCase();
  return h("span", { class: "sv " + (SEV_CLASS[s] || "sv-low") },
    (s ? s.charAt(0).toUpperCase() + s.slice(1) : "Unrated") + (cvss !== null && cvss !== undefined ? " " + Number(cvss).toFixed(1) : ""));
}

function safeVendorUrl(u) {
  // Only the three vendors' own sites, over HTTPS
  return /^https:\/\/(nvd\.nist\.gov|msrc\.microsoft\.com|access\.redhat\.com)\//.test(u || "") ? u : null;
}

function newsItem(it, opts = {}) {
  const url = safeVendorUrl(it.url);
  const id = url ? h("a", { href: url, target: "_blank", rel: "noopener noreferrer", class: "nw-id" }, it.cve_id)
                 : h("span", { class: "nw-id" }, it.cve_id);
  const when = it.published ? new Date(it.published) : null;
  return h("li", { class: "nw-item" + (it.exploited ? " nw-kev" : "") },
    h("div", { class: "nw-top" },
      sevChip(it.severity, it.cvss), id,
      opts.source ? h("span", { class: "nw-src" }, FEED_NAME[it.source] || it.source) : null,
      it.exploited ? h("span", { class: "nw-flag" }, "0-day") : null,
      h("time", { class: "nw-when", datetime: it.published || "" }, when ? when.toLocaleDateString(undefined, { day: "numeric", month: "short" }) : "")),
    h("p", { class: "nw-title" }, it.title || ""),
    (it.matched && it.matched.length) || it.servers_affected ? h("div", { class: "nw-tags" },
      (it.matched || []).map(m => h("span", { class: "nw-tag" }, m)),
      it.servers_affected ? h("span", { class: "nw-tag nw-hit" },
        it.servers_affected === 1 ? "1 of your servers" : it.servers_affected + " of your servers") : null) : null);
}

/* ---- the dashboard ---------------------------------------------------------- */

const OS_CLASSES = ["c-cat1", "c-cat2", "c-cat3", "c-cat4", "c-cat5", "c-cat6"];

/* ---- modules and who may open them ------------------------------------------ */

const MODULES = [
  { key: "patch", label: "Patch Dashboard", href: "#/dashboard",
    desc: "Servers, patches, CVEs, changes and hardening" },
  { key: "inventory", label: "Asset & Inventory", href: "#/assets",
    desc: "Every machine and its software, from agents, vCenter and WSUS" },
  { key: "lifecycle", label: "Software Lifecycle", href: "#/installers",
    desc: "Approved installers, software installs and removals" },
];
const ALL_MODULES = MODULES.map(m => m.key);

/* The console only shows and hides; the API refuses what a user may not
 * open, whatever the browser does. */
function myModules() {
  const a = getAuth();
  if (!a) return [];
  if (a.user.role === "admin") return ALL_MODULES.slice();
  return Array.isArray(a.user.modules) ? a.user.modules.filter(m => ALL_MODULES.includes(m)) : [];
}
function hasModule(...keys) { const mine = myModules(); return keys.some(k => mine.includes(k)); }

// Which modules each page belongs to (any one of them opens it)
const ROUTE_MODULES = {
  dashboard: ["patch"], impact: ["patch"], hosts: ["patch"], host: ["patch"], agents: ["patch"], "agent-updates": ["patch"],
  advisories: ["patch"], vulns: ["patch"], hardening: ["patch"], assess: ["patch"], wsus: ["patch"],
  vmware: ["patch", "inventory"], assets: ["inventory"], "assets-decom": ["inventory"], "assets-coverage": ["inventory"], "software-inventory": ["inventory"], software: ["inventory"],
  installers: ["lifecycle"], changes: ["patch", "lifecycle"], change: ["patch", "lifecycle"], "server-groups": ["patch"],
  activity: ["patch", "inventory", "lifecycle"], antivirus: ["inventory", "patch"], "patch-reports": ["patch"], deployment: ["lifecycle"],
  "installed-patches": ["patch"],
};

/* ---- Sections: seven menu items, each with its pages as tabs (the sub-bar) -------------
 * [route, label, modules (null: any), minimum role]. Old links keep working: every
 * route still opens the same page, now under its section. */
const SECTIONS = [
  { key: "overview", label: "Overview", tabs: [["dashboard", "Patch dashboard", ["patch"]]] },
  { key: "servers", label: "Servers", tabs: [["hosts", "Servers", ["patch"]], ["installed-patches", "Installed patches", ["patch"]], ["server-groups", "Patch groups", ["patch"]],
      ["vmware", "VMware", ["patch", "inventory"]], ["agent-updates", "Agent updates", ["patch"], "admin"]] },
  { key: "vulns", label: "Vulnerabilities", tabs: [["impact", "Detected CVEs", ["patch"]], ["vulns", "Advisories", ["patch"]],
      ["hardening", "Hardening", ["patch"]]] },
  { key: "patching", label: "Patching", tabs: [["changes", "Jobs", ["patch", "lifecycle"]], ["patch-reports", "Patch reports", ["patch"]],
      ["wsus", "Windows / WSUS", ["patch"]]] },
  { key: "software", label: "Software", tabs: [["deployment", "Deployment", ["lifecycle"]], ["installers", "Installers on a share", ["lifecycle"]]] },
  { key: "inventory", label: "Inventory", tabs: [["assets", "Assets", ["inventory"]], ["assets-coverage", "Coverage", ["inventory"]],
      ["assets-decom", "Decommissioned", ["inventory"]], ["software-inventory", "Software", ["inventory"]], ["antivirus", "Antivirus", ["inventory", "patch"]]] },
  { key: "admin", label: "Admin", tabs: [["users", "Users", null, "admin"], ["access", "Access", null, "admin"], ["mail", "Mail", null, "admin"],
      ["report-schedules", "Scheduled reports", null, "admin"], ["feeds", "CVE feeds", null, "admin"], ["av-consoles", "Antivirus consoles", null, "admin"],
      ["branding", "Branding", null, "admin"], ["certificate", "Certificate", null, "admin"], ["activity", "Activity", ["patch", "inventory", "lifecycle"]]] },
];
// Pages that are not tabs themselves, and the section (and tab) they belong to
const ROUTE_HOME = { host: ["servers", "hosts"], agents: ["servers", "hosts"], advisories: ["vulns", "vulns"], assess: ["vulns", "impact"],
  change: ["patching", "changes"], software: ["inventory", "software-inventory"] };
const NAV_ALIAS = { overview: "overview", hosts: "servers", vmware: "servers", vulns: "vulns", hardening: "vulns", changes: "patching",
  "patch-reports": "patching", "installed-patches": "servers", windows: "patching", inventory: "inventory", antivirus: "inventory", lifecycle: "software",
  deployment: "software", admin: "admin", users: "admin", mail: "admin", activity: "admin" };

function tabVisible(t) {
  return (!t[2] || hasModule(...t[2])) && (!t[3] || can(t[3]));
}
function sectionOf(first) {
  for (const sec of SECTIONS) {
    const t = sec.tabs.find(x => x[0] === first);
    if (t) return [sec, t[0]];
  }
  const home = ROUTE_HOME[first];
  if (home) return [SECTIONS.find(x => x.key === home[0]), home[1]];
  return [null, null];
}
/* Menu icons: simple line drawings, one per section */
const SECTION_ICONS = {
  overview: "M4 4h7v7H4zM13 4h7v4h-7zM13 10h7v10h-7zM4 13h7v7H4z",
  servers: "M4 4h16v6H4zM4 14h16v6H4zM7.5 7h.01M7.5 17h.01",
  vulns: "M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6zM9 12l2 2 4-4",
  patching: "M12 4v10M7.5 9.5L12 14l4.5-4.5M5 19h14",
  software: "M12 3l8 4.5v9L12 21l-8-4.5v-9zM4 7.5l8 4.5 8-4.5M12 12v9",
  inventory: "M8 4h8v3H8zM6 5.5H5v15h14v-15h-1M8 11h8M8 15h8",
  admin: "M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1",
};
function sectionIcon(key) {
  return svg("svg", { viewBox: "0 0 24 24", class: "side-ico", "aria-hidden": "true", focusable: "false" },
    svg("path", { d: SECTION_ICONS[key] || SECTION_ICONS.overview }));
}

/* The menu (seven sections), the open section's pages under it, and where you are in the top bar */
function sectionNav(first) {
  const nav = document.querySelector(".side nav");
  const sub = document.getElementById("subnav");
  const crumb = document.getElementById("crumb");
  const [sec, tab] = sectionOf(first || "");
  if (nav) {
    nav.replaceChildren(...SECTIONS.map(s => {
      const vis = s.tabs.filter(tabVisible);
      if (!vis.length) return null;
      const label = s.key === "admin" && !can("admin") ? "Activity" : s.label;
      const open = !!(sec && sec.key === s.key);
      const link = h("a", { href: "#/" + vis[0][0], class: "side-link", "data-nav": s.key, "aria-current": open ? "page" : null },
        sectionIcon(s.key), h("span", null, label));
      if (!open || vis.length < 2) return h("div", { class: "side-sec" }, link);
      return h("div", { class: "side-sec open" }, link,
        h("div", { class: "side-sub", role: "group", "aria-label": label },
          vis.map(t => h("a", { href: "#/" + t[0], class: "subtab", "aria-current": t[0] === tab ? "page" : null }, t[1]))));
    }).filter(Boolean));
  }
  // The pages are in the menu now; the old bar under the header stays empty
  if (sub) { sub.hidden = true; sub.replaceChildren(); }
  if (crumb) {
    const t = sec ? sec.tabs.find(x => x[0] === tab) : null;
    const secLabel = sec ? (sec.key === "admin" && !can("admin") ? "Activity" : sec.label) : "";
    const bits = [secLabel, t && t[1] !== secLabel && sec.tabs.filter(tabVisible).length > 1 ? t[1] : null].filter(Boolean);
    crumb.replaceChildren(...bits.flatMap((b, i) => [i ? h("span", { class: "crumb-sep", "aria-hidden": "true" }, "/") : null,
      h("span", { class: i === bits.length - 1 ? "crumb-here" : null }, b)]).filter(Boolean));
  }
}

/* A page's opening explanation folds behind a "?" next to its title: there when wanted, not in the way */
function tidyIntro(root) {
  (root || document).querySelectorAll("#view .page-head + p.muted:not([data-tidy])").forEach(p => {
    p.setAttribute("data-tidy", "1");
    if ((p.textContent || "").length < 70) return;
    const head = p.previousElementSibling;
    const h1 = head && head.querySelector("h1");
    if (!h1 || h1.querySelector(".help-q")) return;
    p.hidden = true;
    p.classList.add("page-help");
    const btn = h("button", { type: "button", class: "help-q", "aria-expanded": "false", title: "What is this page?",
      "aria-label": "What is this page?" }, "?");
    btn.addEventListener("click", () => { p.hidden = !p.hidden; btn.setAttribute("aria-expanded", String(!p.hidden)); });
    h1.append(btn);
  });
}
let tidyObserver = null;
function watchIntros() {
  const v = document.getElementById("view");
  if (!v || tidyObserver || typeof MutationObserver === "undefined") return;
  tidyObserver = new MutationObserver(() => tidyIntro());
  tidyObserver.observe(v, { childList: true, subtree: true });
}

function routeAllowed(first) {
  const need = ROUTE_MODULES[first];
  return !need || hasModule(...need);
}

function applyModuleNav() {
  document.querySelectorAll("nav a[data-modules]").forEach(el => {
    const need = el.dataset.modules.split(",");
    const allowed = hasModule(...need) && (!el.dataset.minRole || can(el.dataset.minRole));
    el.hidden = !allowed;
  });
}

let meCheckedAt = 0;
/* Pick up access an admin changed while this user is signed in. */
async function refreshMe(force) {
  const a = getAuth();
  if (!a || (!force && Date.now() - meCheckedAt < 60000 && Array.isArray(a.user.modules))) return;
  meCheckedAt = Date.now();
  try {
    const me = await api("/auth/me");
    const s = getAuth();
    if (!s) return;
    const changed = JSON.stringify(s.user.modules) !== JSON.stringify(me.modules) || s.user.role !== me.role;
    s.user.modules = me.modules; s.user.role = me.role;
    setSession(s);
    if (changed) applyModuleNav();
  } catch (e) { /* the next page load tries again */ }
}

function noAccess(first) {
  const mods = (ROUTE_MODULES[first] || []).map(k => (MODULES.find(m => m.key === k) || {}).label).filter(Boolean);
  render(h("div", { class: "empty" },
    h("h2", null, "No access"),
    h("p", null, "This page is part of " + mods.join(" or ") + ". Your account does not have access to it; "
      + "ask an admin to grant it under Admin, Access."),
    h("p", null, h("a", { href: "#/" }, "Back to the home page"))));
}

/* The three module buttons, small icons: lit when the user may open the
 * module, grey when not. Before sign-in they are all lit and lead to the
 * sign-in form. */
const MOD_ICONS = {
  // shield with a check: patching
  patch: [["path", { d: "M12 3l7 3v5c0 4.4-3 8.3-7 9.5C8 19.3 5 15.4 5 11V6z" }], ["path", { d: "M8.8 11.8l2.2 2.2 4.4-4.6" }]],
  // stacked boxes: assets
  inventory: [["rect", { x: "4", y: "4", width: "7", height: "7", rx: "1.2" }], ["rect", { x: "13", y: "4", width: "7", height: "7", rx: "1.2" }],
              ["rect", { x: "4", y: "13", width: "7", height: "7", rx: "1.2" }], ["rect", { x: "13", y: "13", width: "7", height: "7", rx: "1.2" }]],
  // circular arrows: lifecycle
  lifecycle: [["path", { d: "M19 12a7 7 0 0 1-12.2 4.7" }], ["path", { d: "M5 12a7 7 0 0 1 12.2-4.7" }],
              ["path", { d: "M17.5 3.8v3.7h-3.7" }], ["path", { d: "M6.5 20.2v-3.7h3.7" }]],
};
const MOD_SHORT = { patch: "Patch", inventory: "Assets", lifecycle: "Lifecycle" };

function modIcon(key) {
  return svg("svg", { viewBox: "0 0 24 24", class: "mod-ico", "aria-hidden": "true", focusable: "false" },
    (MOD_ICONS[key] || []).map(([tag, attrs]) => svg(tag, attrs)));
}

function moduleButtons(opts = {}) {
  const signedIn = !!getAuth();
  return h("div", { class: "mod-row", role: "group", "aria-label": "Modules" }, MODULES.map(m => {
    const ok = !signedIn || hasModule(m.key);
    const tip = ok ? m.label + ": " + m.desc : m.label + ": your account does not have access. Ask an admin.";
    if (!ok) {
      return h("span", { class: "mod-btn mod-off", role: "link", "aria-disabled": "true", "aria-label": tip, title: tip },
        modIcon(m.key), h("span", { class: "mod-t" }, MOD_SHORT[m.key]));
    }
    return h("a", { class: "mod-btn mod-on", href: signedIn ? m.href : "#/", "aria-label": m.label, title: tip,
                    on: signedIn ? null : { click: e => { e.preventDefault(); opts.onPick && opts.onPick(m); } } },
      modIcon(m.key), h("span", { class: "mod-t" }, MOD_SHORT[m.key]));
  }));
}

/* ---- the CVE scroller: critical, high and 0-day only ------------------------- */

let scrollerTimer = null;

function scrollerItem(it, hidden) {
  const url = safeVendorUrl(it.url);
  const attrs = hidden ? { tabindex: "-1" } : {};
  const id = url ? h("a", Object.assign({ href: url, target: "_blank", rel: "noopener noreferrer", class: "nw-id" }, attrs), it.cve_id)
                 : h("span", { class: "nw-id" }, it.cve_id);
  const when = it.published ? new Date(it.published) : null;
  return h("li", { class: "sc-item" + (it.exploited ? " nw-kev" : "") },
    h("div", { class: "nw-top" },
      it.exploited ? h("span", { class: "sv sv-crit sv-0day" }, "0-day") : sevChip(it.severity, it.cvss),
      id, h("span", { class: "nw-src" }, FEED_NAME[it.source] || it.source),
      h("time", { class: "nw-when", datetime: it.published || "" },
        when ? when.toLocaleDateString(undefined, { day: "numeric", month: "short" }) : "")),
    h("p", { class: "nw-title" }, it.title || ""));
}

function cveScroller() {
  const track = h("div", { class: "sc-track" });
  const box = h("div", { class: "sc-window", tabindex: "0", "aria-label": "Critical and 0-day CVEs; hover or focus to pause" }, track);
  const panel = h("section", { class: "signin-news sc-panel", "aria-labelledby": "sc-h" },
    h("div", { class: "sc-head" },
      h("h2", { id: "sc-h" }, "Critical & 0-day CVEs"),
      h("span", { class: "sc-live", "aria-hidden": "true" }, "LIVE")),
    h("p", { class: "muted small" }, "Just published by NIST, Microsoft and Red Hat"),
    box);
  async function load() {
    let d = null;
    try {
      const r = await fetch("/api/v1/public/news", { headers: { Accept: "application/json" } });
      d = r.ok ? await r.json() : null;
    } catch (e) { d = null; }
    if (!panel.isConnected) { clearInterval(scrollerTimer); return; }
    if (!d || !d.enabled) { panel.hidden = true; return; }
    const items = [];
    Object.entries(d.sources || {}).forEach(([src, rows]) => rows.forEach(r => items.push(Object.assign({ source: src }, r))));
    items.sort((a, b) => String(b.published).localeCompare(String(a.published)));
    if (!items.length) {
      track.replaceChildren(h("p", { class: "muted small" }, "No critical or 0-day CVEs in this period."));
      box.classList.add("sc-static");
      return;
    }
    const list = h("ul", { class: "sc-list" }, items.map(i => scrollerItem(i, false)));
    // A second copy follows the first, so the loop is seamless; screen readers skip it
    const copy = h("ul", { class: "sc-list", "aria-hidden": "true" }, items.map(i => scrollerItem(i, true)));
    track.replaceChildren(list, copy);
    track.style.setProperty("--sc-dur", Math.max(30, items.length * 4) + "s");
    box.classList.toggle("sc-static", items.length < 4);
    if (items.length < 4) copy.remove();
  }
  load();
  clearInterval(scrollerTimer);
  scrollerTimer = setInterval(load, 120000);
  return panel;
}

function welcomeBlock(extra) {
  return h("div", { class: "signin-welcome" },
    logoImg(isDarkTheme(), "signin-logo"),
    h("p", { class: "signin-kicker" }, "Welcome to the"),
    h("h1", { class: "signin-title", "data-cmd": "login" }, PORTAL + " Dashboard portal"),
    h("p", { class: "ai-badge" }, h("span", { class: "ai-dot", "aria-hidden": "true" }), "AI powered dashboard"),
    h("p", { class: "muted" }, "Patch, vulnerability, inventory and software lifecycle in one place, analysed by AI-01."),
    extra || null);
}

/* ---- sign-in page ------------------------------------------------------------ */

const AFTER_KEY = "cs.after";

/* The sign-in page's picture: the estate as a dotted globe, with servers, cloud,
 * software, PCs, people and sites joined to the shield in the middle. Drawn here
 * in SVG (no image file), coloured by the theme. */
const LG_NODE_ICONS = {
  server: "M5 5h14v5H5zM5 14h14v5H5zM8 7.5h.01M8 16.5h.01",
  cloud: "M7 18h10a4 4 0 0 0 .5-8 5.5 5.5 0 0 0-10.6 1.5A3.3 3.3 0 0 0 7 18z",
  box: "M12 3l8 4.5v9L12 21l-8-4.5v-9zM4 7.5l8 4.5 8-4.5M12 12v9",
  laptop: "M5 6h14v9H5zM3 18h18",
  users: "M9 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM3.5 19c.4-3 2.8-5 5.5-5s5.1 2 5.5 5M16 5.5a3 3 0 0 1 0 5.5M17.5 14c2 .6 3 2.3 3.2 5",
  site: "M5 20V5h9v15M14 9h5v11M8 8h3M8 12h3M8 16h3M3 20h18",
  shield: "M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z",
};
function signinGlobe() {
  const W = 640, H = 330, cx = 320, cy = 372, R = 330;
  const dots = svg("g", { class: "lg-dots" });
  for (let lat = 2; lat <= 78; lat += 4) {
    const r = R * Math.cos(lat * Math.PI / 180), yy = cy - R * Math.sin(lat * Math.PI / 180) * 0.7;
    for (let lon = -86; lon <= 86; lon += 3.5) {
      const x = cx + r * Math.sin(lon * Math.PI / 180);
      const depth = Math.cos(lon * Math.PI / 180);
      if (x < 4 || x > W - 4 || yy > H - 4) continue;
      dots.append(svg("circle", { cx: x.toFixed(1), cy: yy.toFixed(1), r: (0.5 + depth * 0.9).toFixed(2),
        opacity: (0.06 + depth * 0.38 * (1 - lat / 110)).toFixed(2) }));
    }
  }
  const centre = [320, 150];
  const nodes = [["server", 120, 108], ["cloud", 215, 38], ["box", 430, 52], ["laptop", 150, 200], ["users", 390, 222], ["site", 525, 200]];
  const links = svg("g", { class: "lg-links" });
  nodes.forEach(([, x, y], i) => {
    const mx = (x + centre[0]) / 2, my = Math.min(y, centre[1]) - 30 - (i % 2) * 18;
    links.append(svg("path", { d: `M${centre[0]} ${centre[1]}Q${mx} ${my} ${x} ${y}` }));
  });
  [[0, 3], [1, 2], [2, 5], [3, 4], [0, 1]].forEach(([a, b]) => {
    const [, x1, y1] = nodes[a], [, x2, y2] = nodes[b];
    links.append(svg("path", { class: "lg-link-2", d: `M${x1} ${y1}Q${(x1 + x2) / 2} ${Math.min(y1, y2) - 40} ${x2} ${y2}` }));
  });
  const spikes = svg("g", { class: "lg-spikes" }, [[60, 250, 40], [92, 160, 60], [255, 95, 45], [470, 120, 50], [585, 150, 70], [615, 270, 30], [300, 260, 25]]
    .map(([x, y, l], i) => [svg("line", { x1: x, x2: x, y1: y, y2: y + l }), svg("circle", { cx: x, cy: y, r: 2.2, class: "lg-tw lg-tw" + (i % 3) })]).flat());
  const node = (key, x, y, r) => svg("g", { class: "lg-node" + (key === "shield" ? " lg-core" : ""), transform: `translate(${x} ${y})` },
    svg("circle", { r, class: "lg-node-bg" }),
    svg("g", { transform: `translate(${-r * 0.55} ${-r * 0.55}) scale(${(r * 1.1 / 24).toFixed(3)})` },
      svg("path", { d: LG_NODE_ICONS[key], class: "lg-node-ico" })));
  return svg("svg", { viewBox: `0 0 ${W} ${H}`, class: "lg-globe", "aria-hidden": "true", focusable: "false" },
    dots, links, spikes,
    nodes.map(([k, x, y]) => node(k, x, y, 21)),
    svg("circle", { cx: centre[0], cy: centre[1], r: 46, class: "lg-halo" }),
    node("shield", centre[0], centre[1], 32));
}

async function signinDecor(formEl) {
  await loadBrand();
  if (!formEl.isConnected) return null;      // the user moved on (signed in) meanwhile
  const prevFocus = document.activeElement;  // moving the form into the layout drops focus
  const hint = h("p", { class: "mod-hint", role: "status" });
  const feats = h("div", { class: "lg-feats", role: "group", "aria-label": "Modules" }, MODULES.map(m =>
    h("button", { type: "button", class: "lg-feat", title: m.label + ": " + m.desc,
      on: { click: () => {
        try { sessionStorage.setItem(AFTER_KEY, m.key); } catch (e) { /* private mode */ }
        hint.textContent = "Sign in to open " + m.label + ".";
        const u = formEl.querySelector("input[name=user]");
        if (u) u.focus();
      } } },
      modIcon(m.key), h("span", null, m.label))));
  // The theme choice moves to the top bar
  const pick = formEl.querySelector(".theme-pick");
  let logo = logoImg(isDarkTheme(), "lg-logo");
  // The logo for the background: the white one on dark themes
  const sel = pick && pick.querySelector("select");
  if (sel) sel.addEventListener("change", () => {
    if (!logo || !logo.isConnected) return;
    const next = logoImg(isDarkTheme(), "lg-logo");
    if (next) { logo.replaceWith(next); logo = next; }
  });
  const top = h("header", { class: "lg-top" },
    h("div", { class: "lg-brand" }, logo, h("span", { class: "lg-name" }, PORTAL)),
    h("span", { class: "lg-tag" }, "Cybersecurity operations"),
    h("div", { class: "lg-links-top" },
      h("a", { href: "#lg-adv", on: { click: e => { e.preventDefault(); const a = document.getElementById("lg-adv"); if (a) a.scrollIntoView({ behavior: "smooth" }); } } },
        "Security advisories")),
    pick || null);
  const news = cveScroller();
  const page = h("div", { class: "lg" },
    top,
    h("div", { class: "lg-main" },
      h("div", { class: "lg-hero" },
        h("p", { class: "lg-kicker" }, "Unified security platform"),
        h("h1", { class: "lg-title" }, "Clarity across your ", h("span", null, "patch estate.")),
        h("p", { class: "lg-lead" }, "Patch, vulnerability, inventory and software lifecycle in one place, analysed by AI-01."),
        signinGlobe(),
        feats, hint),
      h("div", { class: "lg-card" }, formEl)),
    h("section", { class: "lg-adv", id: "lg-adv", "aria-label": "Security advisories" },
      h("div", { class: "lg-adv-h" }, h("h2", null, "Security advisories"),
        h("p", null, "Critical and 0-day CVEs, straight from NIST, Microsoft and Red Hat.")),
      news),
    h("footer", { class: "lg-foot" }, h("span", null, h("strong", null, PORTAL), " \u00b7 Cybersecurity operations"),
      h("span", null, "Access is monitored and logged.")));
  page.prevFocus = prevFocus;
  return page;
}

/* After sign-in: go where the user was heading, if they may. */
function takeAfterSignIn() {
  let k = null;
  try { k = sessionStorage.getItem(AFTER_KEY); sessionStorage.removeItem(AFTER_KEY); } catch (e) { k = null; }
  const m = MODULES.find(x => x.key === k);
  if (m && hasModule(m.key)) {
    if (location.hash === m.href) route(); else location.hash = m.href;
    return true;
  }
  return false;
}

/* ---- home: the same welcome, with this user's modules lit ---------------------- */

async function renderHome() {
  setNav("home");
  await loadBrand();
  await refreshMe(true);
  const a = getAuth();
  const name = (a && (a.user.display_name || a.user.username)) || "";
  const mine = myModules();
  render(h("div", { class: "signin-page home-page" },
    h("div", { class: "signin-left" },
      welcomeBlock(moduleButtons()),
      h("p", { class: "muted small home-who" }, "Signed in as " + name + ". "
        + (mine.length === ALL_MODULES.length ? "You can open every module."
          : mine.length ? "Greyed-out modules need an admin to grant access."
          : "Your account has no modules yet: ask an admin to grant access under Admin, Access."))),
    cveScroller()));
}

/* ---- the Patch Dashboard ----------------------------------------------------- */

async function renderCyberDashboard() {
  setNav("overview");
  applyBrand();
  const tz = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC"; } catch (e) { return "UTC"; } })();
  // The Overview's figures; an older API without them still shows the rest
  const ovGet = () => typeof drawOverviewTop === "function"
    ? api("/overview?tz=" + encodeURIComponent(tz)).catch(() => null) : Promise.resolve(null);
  const [d, imp, ov] = await Promise.all([api("/dashboard/summary"), api("/impact").catch(() => null), ovGet()]);
  const page = h("div", { class: "cy" });
  render(page);
  drawDashboard(page, d, imp, false, ov);
  setPageTimer(async () => {
    if (document.hidden) return;
    try {
      const [d2, i2, o2] = await Promise.all([api("/dashboard/summary"), api("/impact").catch(() => null), ovGet()]);
      if (!document.body.contains(page)) return;
      // Someone reading a chart with the keyboard keeps their place: try again next minute
      if (document.activeElement && document.activeElement.closest && document.activeElement.closest(".ov")) return;
      const y = window.scrollY;
      drawDashboard(page, d2, i2, true, o2);
      window.scrollTo(0, y);
    } catch (e) { /* keep the last figures; the next tick retries */ }
  }, 60000);
}

const VERDICT = {
  affected: ["Affected", "c-bad"], not_affected: ["Not affected (fixed)", "c-ok"],
  not_found: ["Not in our environment", "c-muted"],
  appliances_affected: ["Appliances affected", "c-warn"], appliances_check: ["Appliances to check", "c-mod"],
};

function impactCard(d, imp) {
  const ic = (d.feeds && d.feeds.impact) || (imp && imp.counts) || null;
  const days = (d.feeds && d.feeds.days) || (imp && imp.days) || 14;
  // Each CVE once, by what it means for our servers; appliances are a line of their own below
  const segs = ic ? ["affected", "not_affected", "not_found"].map(k =>
    ({ label: VERDICT[k][0], value: ic[k] || 0, cls: VERDICT[k][1], href: "#/impact" })) : [];
  const dn = donut("Impacted CVEs", segs, {
    caption: ic ? "New critical, high and 0-day CVEs (last " + days + " days): affected only when proven on a machine"
                : "Waiting for the first analysis: rebuild the API and worker (phase3b-api.sh)",
    centreLabel: ic ? "analysed" : "not yet" });
  const top = ((imp && imp.items) || []).filter(i => i.verdict === "affected").slice(0, 4);
  const list = h("ul", { class: "imp-top" }, top.length ? top.map(i => h("li", null,
    h("div", { class: "nw-top" },
      i.exploited ? h("span", { class: "sv sv-crit sv-0day" }, "0-day") : sevChip(i.severity, i.cvss),
      h("a", { href: "#/impact?cve=" + encodeURIComponent(i.cve_id), class: "nw-id" }, i.cve_id),
      h("span", { class: "imp-v " + (VERDICT[i.verdict] || ["", "c-muted"])[1] }, (VERDICT[i.verdict] || [i.verdict])[0]),
      h("span", { class: "nw-src" }, i.machines === 1 ? "1 machine" : i.machines + " machines")),
    h("p", { class: "imp-ai" + (i.ai_summary ? "" : " imp-wait") },
      i.ai_summary ? h("span", { class: "ai-tag" }, "AI") : null,
      i.ai_summary ? " " + i.ai_summary.split(/\n\s*\n/)[0] : (i.title || "") + " · AI-01 brief pending")))
    : [h("li", { class: "muted small" }, ic ? "Nothing new is affecting your machines." : "")]);
  return h("section", { class: "dn-card imp-card" },
    h("div", { class: "imp-grid" }, dn,
      h("div", { class: "imp-side" },
        h("h3", null, "Needs your attention", h("span", { class: "ai-badge ai-small" }, h("span", { class: "ai-dot" }), "AI analysed")),
        list,
        ic && (ic.appliances_affected || ic.appliances_check) ? h("p", { class: "small" },
          h("a", { href: "#/impact?tab=appliances" }, "Appliances: " + (ic.appliances_affected || 0) + " CVEs affect a device, "
            + (ic.appliances_check || 0) + " to check")) : null,
        h("a", { href: "#/impact", class: "small" }, "All CVEs affecting our machines, with the evidence and AI-01's briefs"))));
}

function drawDashboard(page, d, imp, quiet, ov) {
  const s = d.servers || {}, a = d.advisories || {}, sv = d.severity || {}, ag = d.agents || {};
  const f = (d.feeds && d.feeds.counts) || null;
  const ic = (d.feeds && d.feeds.impact) || null;
  const at = d.at ? new Date(d.at) : new Date();
  const hero = (n, label, cls, href) => h(href ? "a" : "div", { class: "cy-hero " + (cls || ""), href: href || null },
    h("span", { class: "cy-n" }, n === null || n === undefined ? "–" : String(n)), h("span", { class: "cy-l" }, label));

  const head = h("div", { class: "page-head cy-head" },
    h("div", null,
      h("h1", { "data-cmd": "cybersecure status" }, "Patch Dashboard"),
      h("p", { class: "muted small" }, "Live security posture · updated " + at.toLocaleTimeString() + " · refreshes every minute")),
    ov ? null : h("div", { class: "cy-heroes" },
      hero(d.compliance_pct === null ? null : d.compliance_pct + "%", "patch compliance", "cy-ok"),
      hero(s.total || 0, "servers", "", "#/hosts"),
      hero(sv.critical || 0, "critical updates outstanding", sv.critical ? "cy-bad" : "", "#/hosts?patch=needs_patch"),
      ic ? hero(ic.affected || 0, "CVEs affecting your machines", ic.affected ? "cy-bad" : "", "#/impact?verdict=affected") : null));

  if (!s.total) {
    page.replaceChildren(head, h("div", { class: "empty" },
      h("h2", null, "No servers have enrolled yet"),
      h("p", null, "Issue a token with ", h("code", null, "./scripts/phase3b-api.sh --token"),
        ", then install the agent on a server. It appears here within a minute.")));
    return;
  }

  // Patching: what the servers themselves report (WSUS, the package manager). CVEs are a separate section.
  const grid = h("div", { class: "cy-grid" },
    donut("Servers", [
      { label: "Patched", value: s.patched, cls: "c-ok", href: "#/hosts?patch=up_to_date" },
      { label: "Needs patches", value: s.needs_patch, cls: "c-bad", href: "#/hosts?patch=needs_patch" },
      { label: "Needs a reboot", value: s.needs_reboot, cls: "c-warn", href: "#/hosts?patch=needs_reboot" },
      { label: "Patch state unknown", value: s.unknown, cls: "c-mod", href: "#/hosts?patch=unknown", note: "Linux agent older than 1.8.2: update it" },
      { label: "Not reporting", value: s.not_reporting, cls: "c-muted", href: "#/hosts?agent=offline", note: "status unknown until it reports" },
    ], { caption: "Each server once, by its worst state" }),
    donut("Updates", [
      { label: "To install", value: (a.to_install || 0) + (a.windows_to_install || 0), cls: "c-bad",
        note: (a.to_install || 0) + " Linux (package manager), " + (a.windows_to_install || 0) + " Windows (WSUS)" },
      { label: "Installed, last 30 days", value: a.installed_30d, cls: "c-ok", href: "#/installed-patches?days=30" },
    ], { caption: "Per server and update" }),
    donut("Outstanding by severity", [
      { label: "Critical", value: sv.critical, cls: "c-bad" },
      { label: "Important", value: sv.important, cls: "c-warn" },
      { label: "Moderate", value: sv.moderate, cls: "c-mod" },
      { label: "Low or unrated", value: sv.low_or_unrated, cls: "c-muted" },
    ], { caption: "Distinct updates still to install, by the vendor's rating" }),
    donut("Operating systems", (d.os || []).map((o, i) => (
      { label: o.os, value: o.n, cls: o.os === "Other" ? "c-muted" : OS_CLASSES[i] || "c-muted" })),
      { caption: "Servers with an agent" }),
    donut("Agents", [
      { label: "Online", value: ag.online || 0, cls: "c-ok", href: "#/hosts?agent=online" },
      { label: "Offline", value: ag.offline || 0, cls: "c-warn", href: "#/hosts?agent=offline" },
      { label: "Not reporting", value: ag.not_reporting || 0, cls: "c-bad", href: "#/hosts?agent=not_reporting" },
      { label: "Never reported", value: ag.no_data || 0, cls: "c-muted", href: "#/hosts?agent=no_data" },
    ]));
  // Vulnerabilities: the CVE feeds matched against the inventory (not a patch list)
  const vgrid = h("div", { class: "cy-grid" },
    impactCard(d, imp),
    f ? donut("New CVEs (feeds)", [
      { label: "Critical", value: f.critical, cls: "c-bad" },
      { label: "High", value: f.high, cls: "c-warn" },
      { label: "Medium", value: f.medium, cls: "c-mod" },
      { label: "Low", value: f.low, cls: "c-muted" },
    ], { caption: (d.feeds.watch_list ? "Your watched software" : "All software (no watch list yet)")
                 + ", last " + d.feeds.days + " days · " + (f.exploited || 0) + " 0-day" })
      : donut("New CVEs (feeds)", [], { caption: "Feeds are not set up yet: Admin, CVE feeds", centreLabel: "not set up" }));

  const top = ov ? drawOverviewTop(ov) : null;
  page.replaceChildren(...[head, top, h("h2", { class: "ov-sec" }, "Patching"),
    h("p", { class: "muted small ov-sec-note" }, "What the servers report: Windows Update against WSUS, and each Linux server's package manager."),
    grid, h("h2", { class: "ov-sec" }, "Vulnerabilities (CVE)"),
    h("p", { class: "muted small ov-sec-note" }, "The CVE feeds matched against what is installed. A CVE here is not a missing patch: see Vulnerabilities for each one."),
    vgrid].filter(Boolean));
  if (quiet) page.querySelectorAll(".ov-goal-fill, .ov-ring-val").forEach(x => x.classList.add("dn-noanim"));
  if (quiet) page.querySelectorAll(".dn-seg").forEach(x => x.classList.add("dn-noanim"));
}

/* ---- Vulnerabilities: detected CVEs, advisories and assessments, one place ------ */

function vulnTabs(active) {
  setNav("vulns");
  const tabs = [["impact", "Detected CVEs", "New CVEs from NIST, Microsoft and Red Hat matched to our machines"],
                ["advisories", "Advisories", "Vendor security advisories (CVE) affecting servers"],
                ["assess", "Assess CVEs", "Check a given or uploaded list of CVEs"]];
  const el = h("div", { class: "filters vu-tabs", role: "group", "aria-label": "Vulnerabilities" },
    tabs.map(([k, label, tip]) => h("a", { class: "fbtn", href: "#/" + k, title: tip, "aria-pressed": String(k === active) }, label)));
  const view = document.getElementById("view");
  if (view && !view.querySelector(".vu-tabs")) view.prepend(el);
}

/* A table whose rows open with +. cols: [{label, num, cell}]; detail(row)
 * returns the content shown under an opened row (it may be async). */
function plusTable(cols, rows, detail, opts = {}) {
  // A paged list: sort the whole list by the chosen column, then take the page
  if (opts.paged) {
    const p = opts.paged;
    rows = sortItems(p.key, p.items, cols).slice((p.page - 1) * p.size, p.page * p.size);
    opts = Object.assign({}, opts, { sortKey: p.key, redraw: p.redraw });
  }
  const open = opts.open || new Set();
  const key = opts.key || (r => JSON.stringify(r).slice(0, 80));
  const tbody = h("tbody");
  rows.forEach(r => {
    const k = key(r);
    const isOpen = open.has(k);
    const btn = h("button", { type: "button", class: "srv-plus", "aria-expanded": String(isOpen),
                              "aria-label": (isOpen ? "Hide" : "Show") + " details" }, isOpen ? "−" : "+");
    const cell = h("td", { colspan: String(cols.length + 1) });
    const det = h("tr", { class: "vu-detail srv-detail", hidden: !isOpen }, cell);
    const fill = async () => {
      if (cell.firstChild) return;
      cell.append(h("p", { class: "muted small" }, "Loading"));
      try { const c = await detail(r); cell.replaceChildren(...[].concat(c).flat(3).filter(Boolean)); }
      catch (e) { cell.replaceChildren(h("p", { class: "hd-failed" }, e.message || "Could not load the details.")); }
    };
    if (isOpen) fill();
    btn.addEventListener("click", () => {
      const now = !open.has(k);
      now ? open.add(k) : open.delete(k);
      btn.textContent = now ? "−" : "+";
      btn.setAttribute("aria-expanded", String(now));
      btn.setAttribute("aria-label", (now ? "Hide" : "Show") + " details");
      det.hidden = !now;
      if (now) fill();
    });
    tbody.append(h("tr", { class: "srv-row" + (opts.rowClass ? " " + opts.rowClass(r) : ""), "data-key": opts.rowKey ? opts.rowKey(r) : null },
      h("td", { class: "srv-c-plus" }, btn),
      cols.map(c => h("td", { class: c.num ? "num" : null }, c.cell(r)))), det);
  });
  const own = !!(opts.onSort || opts.sortKey);
  const st = opts.sort || (opts.sortKey ? sortState(opts.sortKey) : null);
  const onSort = opts.onSort || (opts.sortKey ? i => { toggleSort(opts.sortKey, i); if (opts.redraw) opts.redraw(); } : null);
  return h("div", { class: "table-wrap" }, h("table", { class: "srv-table", "data-own-sort": own ? "1" : null },
    h("thead", null, h("tr", null, h("th", { scope: "col" }), cols.map((c, i) => sortHead(c, i, st, onSort)))),
    tbody));
}

/* A column heading that sorts the list when clicked (data sorted by the page, before paging) */
function sortHead(c, i, st, onSort) {
  const plain = !onSort || c.nosort || !(typeof c.label === "string" && c.label);
  const dir = st && st.i === i ? st.dir : 0;
  const th = h("th", { scope: "col", class: (c.num ? "num " : "") + (plain ? "" : "th-sort"),
    "aria-sort": plain ? null : dir === 1 ? "ascending" : dir === -1 ? "descending" : "none" }, c.label);
  if (!plain) {
    th.tabIndex = 0;
    th.title = "Sort by " + c.label;
    const go = () => onSort(i);
    th.addEventListener("click", go);
    th.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } });
  }
  return th;
}

/* ---- Sorting, selection, export and e-mail on every table ----------------------------
 * Paged lists sort their data before paging (sortItems + sortKey). Every other table in
 * a page is enhanced as it appears: headings sort the rows in place, and a tick box
 * column lets rows be selected for Export and E-mail ("selected rows"). */
const SORTS = new Map();
function sortState(k) { return SORTS.get(k) || null; }
function toggleSort(k, i) {
  const s = SORTS.get(k);
  const next = s && s.i === i ? (s.dir === 1 ? { i, dir: -1 } : null) : { i, dir: 1 };
  if (next) SORTS.set(k, next); else SORTS.delete(k);
}
function sortItems(k, items, cols) {
  const s = SORTS.get(k);
  if (!s || !cols[s.i]) return items;
  const c = cols[s.i];
  return items.map(x => [colSortValue(c, x), x]).sort((a, b) => s.dir * compareValues(a[0], b[0])).map(x => x[1]);
}

let pageSelection = null;
function setPageSelection(fn) { pageSelection = fn; }

const DETAIL_ROW = tr => tr.classList.contains("srv-detail") || tr.classList.contains("vu-detail") || tr.classList.contains("explain-row")
  || (tr.cells.length === 1 && tr.cells[0].colSpan > 1);
const SKIP_TABLES = ".inv-detail, .srv-detail, .vu-detail, .mw, .exp, .dn-card, .chat, .no-enh, .srv-det, .ov-recent";

function cellSortValue(td) {
  if (!td) return "";
  const t = td.querySelector("[data-sort]");
  if (t) { const v = t.getAttribute("data-sort"); return isNaN(v) ? v : Number(v); }
  const timed = td.querySelector("[title]");
  if (timed) { const ms = Date.parse(timed.getAttribute("title")); if (!isNaN(ms) && /\d{4}/.test(timed.getAttribute("title"))) return ms; }
  const txt = (td.textContent || "").trim();
  const ms = /\b(19|20)\d{2}\b/.test(txt) && /[A-Za-z]{3}/.test(txt) ? Date.parse(txt.replace(/ · .*$/, "")) : NaN;
  if (!isNaN(ms)) return ms;
  const num = txt.replace(/[,%\s]|GB|MB/g, "");
  return txt && !isNaN(num) && num !== "" ? Number(num) : txt;
}

function enhanceTable(t) {
  if (t.dataset.enh || t.closest(SKIP_TABLES) || !t.tHead || !t.tBodies[0]) return;
  t.dataset.enh = "1";
  const headRow = t.tHead.rows[t.tHead.rows.length - 1];
  const ownSelect = !!t.tHead.querySelector("input[type=checkbox]") || !!t.tBodies[0].querySelector("input[type=checkbox]") || t.dataset.noSelect;
  // Tick boxes for rows (only one header row: anything fancier is left alone)
  if (!ownSelect && t.tHead.rows.length === 1) {
    const all = h("input", { type: "checkbox", class: "tbl-tick-all", "aria-label": "Select every row shown" });
    all.addEventListener("click", e => e.stopPropagation());
    all.addEventListener("change", () => { t.querySelectorAll("tbody tr:not(.pg-off) input.tbl-tick").forEach(b => { b.checked = all.checked; b.closest("tr").classList.toggle("tbl-picked", all.checked); }); });
    headRow.insertBefore(h("th", { scope: "col", class: "tbl-c-tick" }, all), headRow.firstChild);
    [...t.tBodies[0].rows].forEach(tr => {
      if (DETAIL_ROW(tr)) { tr.cells[0].colSpan = (tr.cells[0].colSpan || 1) + 1; return; }
      const b = h("input", { type: "checkbox", class: "tbl-tick", "aria-label": "Select this row" });
      b.addEventListener("click", e => e.stopPropagation());
      b.addEventListener("change", () => {
        tr.classList.toggle("tbl-picked", b.checked);
        const boxes = [...t.querySelectorAll("tbody tr:not(.pg-off) input.tbl-tick")], on = boxes.filter(x => x.checked).length;
        all.checked = on === boxes.length; all.indeterminate = on > 0 && on < boxes.length;
      });
      tr.insertBefore(h("td", { class: "tbl-c-tick" }, b), tr.firstChild);
    });
  }
  // Sortable headings (tables whose page sorts its own data are left to it)
  if (t.dataset.ownSort) return;
  [...headRow.cells].forEach((th, i) => {
    const label = (th.textContent || "").trim();
    if (!label || th.querySelector("input,button,select,a") || th.classList.contains("th-sort")) return;
    th.classList.add("th-sort"); th.tabIndex = 0; th.setAttribute("aria-sort", "none"); th.title = "Sort by " + label;
    const go = () => {
      const dir = th.getAttribute("aria-sort") === "ascending" ? -1 : 1;
      headRow.querySelectorAll("th[aria-sort]").forEach(x => x.setAttribute("aria-sort", "none"));
      th.setAttribute("aria-sort", dir === 1 ? "ascending" : "descending");
      const body = t.tBodies[0];
      const groups = [];
      [...body.rows].forEach(tr => { if (DETAIL_ROW(tr) && groups.length) groups[groups.length - 1].push(tr); else groups.push([tr]); });
      groups.map(g => [cellSortValue(g[0].cells[i]), g]).sort((a, b) => dir * compareValues(a[0], b[0]))
        .forEach(([, g]) => g.forEach(tr => body.appendChild(tr)));
      t._pgPage = 1; t._pgSig = null; try { autoPage(t); } catch (e) { /* stays unpaged */ }
    };
    th.addEventListener("click", go);
    th.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } });
  });
}

/* 30 rows a page for any long table that the page does not page itself (the
 * servers of a group, installed updates, packages to install, users, ...). A
 * row's detail row stays with it. Sorting a column keeps the paging. */
const NO_PAGE = ".mw, .chat, .dn-card, .exp, [data-no-page]";
function rowGroups(t) {
  const groups = [];
  [...t.tBodies[0].rows].forEach(tr => { if (DETAIL_ROW(tr) && groups.length) groups[groups.length - 1].push(tr); else groups.push([tr]); });
  return groups;
}
function autoPage(t) {
  if (!t.tBodies[0] || t.dataset.paged || t.closest(NO_PAGE)) return;
  const groups = rowGroups(t);
  const pages = Math.max(1, Math.ceil(groups.length / PAGE_SIZE));
  const page = Math.min(Math.max(1, t._pgPage || 1), pages);
  const sig = groups.length + ":" + page + ":" + pages;
  // Show the page's rows (classes only: no change to the table's rows)
  groups.forEach((g, i) => { const off = pages > 1 && Math.floor(i / PAGE_SIZE) + 1 !== page; g.forEach(tr => tr.classList.toggle("pg-off", off)); });
  if (t._pgSig === sig && (pages <= 1 || (t._pgNav && t._pgNav.isConnected))) return;
  t._pgSig = sig; t._pgPage = page;
  // the table's own wrapper (a nested table's pager goes right under it, not under the outer list)
  const host = t.parentElement && t.parentElement.classList.contains("table-wrap") ? t.parentElement : t;
  if (t._pgNav && t._pgNav.isConnected) t._pgNav.remove();
  t._pgNav = null;
  if (pages <= 1) return;
  const go = n => { t._pgPage = n; t._pgSig = null; autoPage(t); (t._pgNav || host).scrollIntoView({ block: "nearest" }); };
  t._pgNav = pager(page, pages, groups.length, PAGE_SIZE, go);
  t._pgNav.classList.add("pg-auto");
  host.after(t._pgNav);
}

function enhanceTables() {
  const v = document.getElementById("view");
  if (!v) return;
  v.querySelectorAll("table").forEach(t => {
    enhanceTable(t);
    try { autoPage(t); } catch (e) { /* a table the pager does not understand stays as it is */ }
  });
}
(function watchTables() {
  let pending = false;
  const run = () => { pending = false; try { enhanceTables(); } catch (e) { /* a table the enhancer does not understand stays as it is */ } };
  const start = () => {
    const v = document.getElementById("view");
    if (!v) return;
    new MutationObserver(() => { if (!pending) { pending = true; requestAnimationFrame(run); } }).observe(v, { childList: true, subtree: true });
    run();
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();

/* The selected rows of the page, as {title, columns, rows}: the page's own selection when it
   keeps one (Assets), else the ticked rows of the table with most ticks. */
function selectedSpec() {
  if (pageSelection) { const s = pageSelection(); if (s && s.rows && s.rows.length) return s; }
  const tables = [...document.querySelectorAll("#view table")].filter(t => t.offsetParent !== null && !t.closest(".exp"));
  let best = null, most = 0;
  tables.forEach(t => { const n = t.querySelectorAll("tbody input.tbl-tick:checked").length; if (n > most) { most = n; best = t; } });
  if (!best) return null;
  const ths = [...best.tHead.rows[best.tHead.rows.length - 1].cells];
  const keep = ths.map((th, i) => (th.textContent || "").trim() ? i : -1).filter(i => i >= 0);
  const rows = [...best.tBodies[0].rows].filter(tr => !DETAIL_ROW(tr) && tr.querySelector("input.tbl-tick:checked"))
    .map(tr => keep.map(i => { const c = tr.cells[i]; if (!c) return ""; const l = c.querySelector(".light"); return l ? (l.getAttribute("aria-label") || "") : textOf(c); }));
  return { title: pageTitle(), columns: keep.map(i => textOf(ths[i])), rows };
}

function pager(page, pages, total, size, go) {
  if (pages <= 1) return document.createDocumentFragment();
  return h("nav", { class: "srv-pager", "aria-label": "Pages" },
    h("button", { type: "button", class: "btn btn-quiet", disabled: page <= 1, on: { click: () => go(page - 1) } }, "‹ Previous"),
    h("span", null, "Page " + page + " of " + pages + " · " + ((page - 1) * size + 1) + "–" + Math.min(total, page * size) + " of " + total),
    h("button", { type: "button", class: "btn btn-quiet", disabled: page >= pages, on: { click: () => go(page + 1) } }, "Next ›"));
}

/* Where a CVE was found: each machine with its own record (address, OS,
 * where it is known from), then the machines ruled out and why. */
function whereTable(lines, info = {}) {
  const ex = ((info.excluded || {}).machines || []);
  const notes = ((info.excluded || {}).notes || []);
  const out = [];
  if ((info.platforms || []).length) out.push(h("p", { class: "small vu-plat" }, h("strong", null, "Applies to: "),
    info.platforms.join(", "), h("span", { class: "muted" }, " · a machine counts only if it runs one of these")));
  out.push(lines.length ? h("div", { class: "cm-table" }, table([
    { label: "Machine", nowrap: true, cell: m => m.name ? h("strong", null, m.name) : "–" },
    { label: "Address", nowrap: true, cell: m => m.ip || h("span", { class: "muted" }, "–") },
    { label: "Operating system", cell: m => m.os ? [m.os, m.os_note ? h("span", { class: "muted small", title: m.os_note }, " ⚠") : null]
                                                 : h("span", { class: "muted" }, "unknown") },
    { label: "Found", cell: m => [m.version || m.product || "", h("div", { class: "muted small" }, m.where || m.kind || "")] },
    { label: "Certainty", nowrap: true, cell: m => String(m.certainty || "").replace(/_/g, " ") },
    { label: "Why", cell: m => [m.detail || "", m.basis ? h("div", { class: "muted small" }, "Source: " + m.basis) : null,
                                (m.sources || []).length ? h("div", { class: "muted small" }, "Known from: " + m.sources.join(", ")) : null] },
  ], lines)) : h("p", { class: "muted small" }, "Not found on any machine whose platform matches."));
  if (ex.length) {
    const judged = ex.filter(e => !e.not_judged), nj = ex.filter(e => e.not_judged);
    const det = h("details", { class: "vu-ex" }, h("summary", null,
      "Ruled out: " + judged.length + " machine" + (judged.length === 1 ? "" : "s")
      + (nj.length ? ", not judged: " + nj.length : "")),
      h("div", { class: "cm-table" }, table([
        { label: "Machine", nowrap: true, cell: e => e.name || "" },
        { label: "Address", nowrap: true, cell: e => e.ip || "–" },
        { label: "Operating system", cell: e => e.os || "unknown" },
        { label: "Product", cell: e => e.product || "" },
        { label: "Why not counted", cell: e => e.reason || "" },
      ], judged.concat(nj))));
    out.push(det);
  }
  notes.forEach(n => out.push(h("p", { class: "muted small" }, n)));
  return out;
}

const PIPELINE_STEPS = [
  ["CVE data", "NIST NVD, Microsoft and Red Hat: the affected products, versions and platforms"],
  ["Inventory", "From the servers (Linux packages, Windows programs and updates), vCenter (ESXi, vCenter) and the asset inventory (appliances)"],
  ["Version check", "Installed version against the vendor's fixed build or NVD's affected range; Windows Update's missing updates"],
  ["Proof only", "Affected only when proven on the machine; installed-but-not-comparable is not counted"],
  ["Every 4 hours", "Checked again every 4 hours and when the inventory changes; Scan now asks every server at once"],
  ["AI-01 brief", "Writes the summary; the verdict always comes from the data"]];
function pipeline() {
  return h("ol", { class: "vu-steps", "aria-label": "How a CVE is checked" },
    PIPELINE_STEPS.map(([t, d]) => h("li", { title: d }, h("strong", null, t), h("span", null, d))));
}

/* ---- Vulnerabilities: the new CVEs that really affect our environment -------------------- */

/* Horizontal bars, one series: a label, the bar, the number. For a handful of categories. */
function impBars(title, data, opts = {}) {
  const rows = (data || []).filter(x => x.n > 0);
  if (!rows.length) return ovCard("imp-g", title, [h("p", { class: "muted small imp-g-empty" }, opts.empty || "Nothing affected.")]);
  const W = 420, rowH = 26, L = Math.min(170, 14 + 7 * Math.max(...rows.map(r => String(r.label).length))), R = 40, H = rows.length * rowH + 6;
  const top = Math.max(...rows.map(r => r.n));
  const pic = svg("svg", { viewBox: `0 0 ${W} ${H}`, class: "ov-svg imp-bars", role: "img",
    "aria-label": title + ": " + rows.map(r => r.label + " " + r.n).join(", ") });
  rows.forEach((r, i) => {
    const y = 3 + i * rowH, bw = Math.max(2, (W - L - R) * r.n / top);
    const g = svg("g", { class: "ov-bar-g", tabindex: 0, role: "img", "aria-label": r.label + ": " + r.n });
    g.append(svg("title", null, r.label + ": " + r.n),
      svg("text", { x: L - 8, y: y + rowH / 2 + 4, "text-anchor": "end", class: "ov-ax imp-lbl" },
        String(r.label).length > 24 ? String(r.label).slice(0, 23) + "…" : String(r.label)),
      svg("rect", { x: L, y: y + 5, width: bw, height: rowH - 10, rx: 4, class: "ov-bar " + (opts.series || "s1") }),
      svg("text", { x: L + bw + 6, y: y + rowH / 2 + 4, class: "ov-ax imp-num" }, String(r.n)));
    if (opts.href) { g.style.cursor = "pointer"; g.addEventListener("click", () => opts.href(r)); }
    pic.append(g);
  });
  return ovCard("imp-g", title, [h("div", { class: "ov-plot" }, pic)], opts.extra || null);
}

/* The daily history: CVEs affecting us, and the exploited ones among them */
function impTrend(hist) {
  if (!hist || hist.length < 2) return ovCard("imp-g", "Affected CVEs, last 30 days",
    [h("p", { class: "muted small imp-g-empty" }, "The history starts with this version: one point a day from today.")]);
  const W = 420, H = 190, L = 34, R = 10, T = 10, B = 24;
  const n = hist.length, top = ovNice(Math.max(1, ...hist.map(x => x.affected)));
  const x = i => L + (i * (W - L - R)) / Math.max(1, n - 1), y = v => T + (H - T - B) * (1 - v / top);
  const path = key => hist.map((d, i) => (i ? "L" : "M") + x(i).toFixed(1) + " " + y(d[key] || 0).toFixed(1)).join(" ");
  const pic = svg("svg", { viewBox: `0 0 ${W} ${H}`, class: "ov-svg" });
  [0, 0.5, 1].forEach(f => pic.append(
    svg("line", { x1: L, x2: W - R, y1: y(top * f), y2: y(top * f), class: "ov-grid" + (f === 0 ? " ov-base" : "") }),
    svg("text", { x: L - 6, y: y(top * f) + 4, "text-anchor": "end", class: "ov-ax" }, ovNum(Math.round(top * f)))));
  [0, Math.floor((n - 1) / 2), n - 1].forEach(i => pic.append(
    svg("text", { x: x(i), y: H - 6, "text-anchor": i === 0 ? "start" : i === n - 1 ? "end" : "middle", class: "ov-ax" }, ovDate(hist[i].day))));
  pic.append(svg("path", { class: "ov-line s2 ov-dash", d: path("exploited") }), svg("path", { class: "ov-line s1", d: path("affected") }));
  const wrap = h("div", { class: "ov-plot" }, pic);
  const tip = ovTip(wrap);
  const cross = svg("line", { class: "ov-cross", x1: 0, x2: 0, y1: T, y2: H - B, visibility: "hidden" });
  const dot = svg("circle", { r: 4.5, class: "ov-dot s1", visibility: "hidden" });
  const hit = svg("rect", { x: L, y: T, width: W - L - R, height: H - T - B, class: "ov-hit", tabindex: 0, role: "img",
    "aria-label": "Affected CVEs per day; today " + hist[n - 1].affected + ". Use the arrow keys to read each day." });
  pic.append(cross, dot, hit);
  let cur = n - 1;
  const at = i => {
    cur = Math.max(0, Math.min(n - 1, i)); const d = hist[cur];
    cross.setAttribute("x1", x(cur)); cross.setAttribute("x2", x(cur)); cross.setAttribute("visibility", "visible");
    dot.setAttribute("cx", x(cur)); dot.setAttribute("cy", y(d.affected)); dot.setAttribute("visibility", "visible");
    tip.show([{ text: ovDate(d.day) }, { key: "s1", text: "Affected CVEs: " + d.affected }, { key: "s2", text: "Exploited: " + d.exploited },
      { text: "Machines: " + d.machines }], x(cur) * pic.clientWidth / W, y(d.affected) * pic.clientHeight / H);
  };
  const off = () => { tip.hide(); cross.setAttribute("visibility", "hidden"); dot.setAttribute("visibility", "hidden"); };
  hit.addEventListener("pointermove", e => { const r = pic.getBoundingClientRect();
    at(Math.round(((e.clientX - r.left) / (r.width / W) - L) / ((W - L - R) / Math.max(1, n - 1)))); });
  hit.addEventListener("pointerleave", off); hit.addEventListener("blur", off); hit.addEventListener("focus", () => at(cur));
  hit.addEventListener("keydown", e => { if (e.key === "ArrowLeft" || e.key === "ArrowRight") { e.preventDefault(); at(cur + (e.key === "ArrowLeft" ? -1 : 1)); } });
  return ovCard("imp-g", "Affected CVEs, last 30 days", [wrap], ovLegend([["s1", "Affected"], ["s2", "Exploited", true]]));
}

const IMP_SEV = i => i.exploited ? "0-day" : ((i.severity || "").toLowerCase() === "critical" || Number(i.cvss || 0) >= 9) ? "Critical"
  : (["high", "important"].includes((i.severity || "").toLowerCase()) || Number(i.cvss || 0) >= 7) ? "High" : "Medium or lower";
const IMP_CERT = { confirmed: "Vendor's fix missing", in_range: "Version in affected range", no_fix: "Vendor: affected, no fix yet",
                   pending_reboot: "Fix installed, restart needed" };

async function renderImpact(params) {
  const only = params.get("cve") || "";
  const host = params.get("host") || "";
  let tab = params.get("tab") === "appliances" ? "appliances" : "servers";
  const d = await api("/impact");
  const c = d.counts || {}, g = d.graphs || {};
  setMailParams({}, "impact");
  const page = h("div", { class: "imp" });
  let q = only, pg = 1, sev = "", plat = "";
  const open = new Set(only ? [only + "|servers", only + "|appliances"] : []);
  const shortName = x => String(x || "").toLowerCase().split(".")[0];
  const vendorUrl = i => i.sources && i.sources.includes("nist") ? "https://nvd.nist.gov/vuln/detail/" + i.cve_id
    : i.sources && i.sources.includes("msrc") ? "https://msrc.microsoft.com/update-guide/vulnerability/" + i.cve_id
    : "https://access.redhat.com/security/cve/" + i.cve_id.toLowerCase();

  // Downloads: the server builds them from every row (Excel: four sheets)
  const dl = (fmt, b) => async () => {
    b.disabled = true; const t = b.textContent; b.textContent = "Preparing…";
    try { await downloadFile("/impact/export?format=" + fmt, "vulnerabilities." + fmt); }
    catch (e) { alert(e.message || "The export failed."); }
    finally { b.disabled = false; b.textContent = t; }
  };
  const xl = h("button", { type: "button", class: "btn" }, "Download Excel"); xl.addEventListener("click", dl("xlsx", xl));
  const pdf = h("button", { type: "button", class: "btn btn-quiet" }, "PDF"); pdf.addEventListener("click", dl("pdf", pdf));
  setPageExport(() => ({ server: "/impact/export" }));
  const scanMsg = h("span", { class: "small muted", role: "status" });
  const scan = can("operator") ? h("button", { type: "button", class: "btn btn-quiet", title: "Every reporting server sends its inventory now, "
      + "vCenter is read again and every CVE is checked again as the answers come in" }, "Scan now") : null;
  if (scan) scan.addEventListener("click", async () => {
    scan.disabled = true;
    try { const r = await apiPost("/impact/scan", {}); scanMsg.textContent = "Scan started: " + r.servers + " servers asked for their inventory."; }
    catch (e) { scanMsg.textContent = e.message; scan.disabled = false; }
  });
  const s = d.scan;
  const scanLine = s && (Date.now() - Date.parse(s.at)) < 24 * 3600e3 ? h("p", { class: "small imp-scan" },
    h("strong", null, "Scan " + timeAgo(s.at) + " by " + (s.by || "someone") + ": "),
    (s.reported || 0) + " servers have reported since (" + (s.servers || 0) + " asked); " + (s.analysed || 0) + " of " + (s.total || 0)
      + " CVEs checked again." + ((s.analysed || 0) < (s.total || 0) ? " The list updates as they come in." : "")) : null;

  const tile = (n, label, cls, onClick) => h(onClick ? "button" : "div", { type: onClick ? "button" : null, class: "srv-tile " + (cls || ""),
    on: onClick ? { click: onClick } : null }, h("span", { class: "srv-tile-n" }, String(n || 0)), h("span", { class: "srv-tile-l" }, label));
  const tiles = h("div", { class: "srv-tiles" },
    tile(c.affected, "CVEs affecting our machines", c.affected ? "t-off" : "", () => { tab = "servers"; sev = ""; draw(); }),
    tile(g.machines, "Machines affected", ""),
    tile(c.exploited_impacting, "Exploited (0-day)", c.exploited_impacting ? "t-off" : "", () => { tab = "servers"; sev = "0-day"; pg = 1; draw(); }),
    tile((c.appliances_affected || 0) + (c.appliances_check || 0), "Appliance findings", c.appliances_affected ? "t-warn" : "", () => { tab = "appliances"; draw(); }),
    tile(c.checked, "CVEs checked", ""));
  const charts = h("div", { class: "imp-charts" },
    impTrend(g.history),
    impBars("By severity", g.severity, { href: r => { tab = "servers"; sev = r.label; pg = 1; draw(); } }),
    impBars("Machines by platform", g.platforms, { series: "s2", href: r => { tab = "servers"; plat = r.label; pg = 1; draw(); } }),
    impBars("Products on most machines", g.products, { empty: "No product is affected." }));

  const search = h("input", { type: "search", placeholder: "Search CVE, title, machine, address or product", "aria-label": "Search", value: q });
  let tq = null;
  search.addEventListener("input", () => { clearTimeout(tq); tq = setTimeout(() => { q = search.value.trim(); pg = 1; draw(); }, 250); });
  const tabsBox = h("div", { class: "filters imp-tabs", role: "tablist", "aria-label": "Show" });
  const chips = h("div", { class: "imp-chips" });
  const box = h("div");

  const machineTable = (lines) => h("div", { class: "cm-table" }, table([
    { label: "Machine", nowrap: true, cell: m => h("strong", null, m.name || "") },
    { label: "Address", nowrap: true, cell: m => m.ip || h("span", { class: "muted" }, "–") },
    { label: "Platform", cell: m => [m.platform || m.where || "", m.os ? h("div", { class: "muted small" }, m.os) : null] },
    { label: "Product", cell: m => m.product || "" },
    { label: "Installed", cell: m => h("span", { class: "mono" }, m.version || "") },
    { label: "Fixed in", cell: m => h("span", { class: "mono" }, m.fixed || "") },
    { label: "Evidence", cell: m => [h("span", { class: "imp-cert" }, IMP_CERT[m.certainty] || String(m.certainty || "").replace(/_/g, " ")),
      m.restart ? h("span", { class: "imp-restart" }, " restart only") : null, h("div", { class: "muted small" }, m.detail || "")] },
  ], lines));
  const fixedBox = i => {
    const fx = (((i.excluded || {}).machines) || []).filter(e => e.fixed);
    return fx.length ? h("details", { class: "vu-ex" }, h("summary", null, "Checked and not affected: " + fx.length + (fx.length === 1 ? " machine" : " machines")),
      h("div", { class: "cm-table" }, table([
        { label: "Machine", nowrap: true, cell: e => e.name || "" }, { label: "Product", cell: e => e.product || "" },
        { label: "Why", cell: e => e.reason || "" }], fx))) : null;
  };
  const brief = i => i.ai_summary ? h("div", { class: "imp-brief" }, h("span", { class: "ai-tag" }, "AI-01"), ...i.ai_summary.split(/\n\s*\n/).map(p => h("p", null, p)))
    : h("p", { class: "muted small" }, "AI-01's brief is being written; it appears within minutes.");

  function draw() {
    const all = tab === "servers" ? (d.items || []) : (d.appliances || []);
    const needle = q.toLowerCase();
    const onHost = i => !host || (i.matches || []).some(m => shortName(m.name) === shortName(host));
    const text = i => (i.cve_id + " " + (i.title || "") + " " + (tab === "servers" ? (i.matches || []) : (i.appliances || []))
      .map(m => [m.name, m.ip, m.product, m.os, m.device].join(" ")).join(" ")).toLowerCase();
    const items = all.filter(i => onHost(i) && (!needle || text(i).includes(needle)) && (!sev || IMP_SEV(i) === sev)
      && (!plat || (i.matches || []).some(m => (m.platform || m.where) === plat)));
    tabsBox.replaceChildren(
      ...[["servers", "Servers (" + (d.items || []).length + ")"], ["appliances", "Appliances (" + (d.appliances || []).length + ")"]].map(([k, l]) =>
        h("button", { type: "button", role: "tab", class: "fbtn", "aria-selected": String(tab === k), "aria-pressed": String(tab === k),
          on: { click: () => { tab = k; pg = 1; sev = ""; plat = ""; draw(); } } }, l)));
    chips.replaceChildren(...[sev ? ["Severity: " + sev, () => { sev = ""; }] : null, plat ? ["Platform: " + plat, () => { plat = ""; }] : null,
      host ? ["Only " + host, () => { location.hash = "#/impact"; }] : null].filter(Boolean).map(([t, clear]) =>
        h("button", { type: "button", class: "ip-chosen", on: { click: () => { clear(); pg = 1; draw(); } } }, t + "  ×")));
    const pages = Math.max(1, Math.ceil(items.length / PAGE_SIZE));
    pg = Math.min(pg, pages);
    const sevCol = { label: "Severity", sort: i => (i.exploited ? 100 : 0) + Number(i.cvss || 0),
      cell: i => i.exploited ? h("span", { class: "sv sv-crit sv-0day" }, "0-day") : sevChip(i.severity, i.cvss) };
    const cols = tab === "servers" ? [
      { label: "CVE", cell: i => h("strong", { class: "mono" }, i.cve_id) }, sevCol,
      { label: "Machines", num: true, sort: i => i.machines || 0, cell: i => String(i.machines || 0) },
      { label: "Platforms", cell: i => [...new Set((i.matches || []).map(m => m.platform || m.where).filter(Boolean))].join(", ") },
      { label: "Products", cell: i => [...new Set((i.matches || []).flatMap(m => m.products || [m.product]).filter(Boolean))].slice(0, 3).join(", ") },
      { label: "Published", sort: i => i.published ? Date.parse(i.published) : null, cell: i => i.published ? fmtDate(i.published) : "" },
      { label: "Title", cell: i => h("span", { class: "vu-title" }, i.title || "") },
    ] : [
      { label: "CVE", cell: i => h("strong", { class: "mono" }, i.cve_id) }, sevCol,
      { label: "State", cell: i => i.appliance_state === "affected" ? h("span", { class: "imp-v c-bad" }, "Affected")
          : h("span", { class: "imp-v c-mod", title: "The device matches; its firmware version is not recorded" }, "To check") },
      { label: "Devices", num: true, cell: i => String((i.appliances || []).length) },
      { label: "Published", sort: i => i.published ? Date.parse(i.published) : null, cell: i => i.published ? fmtDate(i.published) : "" },
      { label: "Title", cell: i => h("span", { class: "vu-title" }, i.title || "") },
    ];
    const detail = i => tab === "servers" ? [brief(i),
      h("p", { class: "small" }, h("a", { href: vendorUrl(i), target: "_blank", rel: "noopener noreferrer" }, "Vendor page for " + i.cve_id),
        " · checked " + timeAgo(i.analysed_at)),
      machineTable((i.matches || []).filter(m => !host || shortName(m.name) === shortName(host))), fixedBox(i)]
      : [h("p", { class: "small" }, h("a", { href: vendorUrl(i), target: "_blank", rel: "noopener noreferrer" }, "Vendor page for " + i.cve_id),
          " · checked " + timeAgo(i.analysed_at)),
        h("div", { class: "cm-table" }, table([
          { label: "Device", nowrap: true, cell: x => h("strong", null, x.name || "") },
          { label: "Address", nowrap: true, cell: x => x.ip || "–" },
          { label: "Type", cell: x => x.type || "" },
          { label: "Maker and model", cell: x => x.device || h("span", { class: "muted" }, "–") },
          { label: "Firmware", cell: x => x.version || h("span", { class: "muted" }, "not recorded") },
          { label: "State", cell: x => x.state === "affected" ? h("span", { class: "imp-v c-bad" }, "Affected") : h("span", { class: "imp-v c-mod" }, "To check") },
          { label: "Detail", cell: x => [x.product ? h("div", null, x.product) : null, h("div", { class: "muted small" }, x.detail || "")] },
        ], i.appliances || []))];
    box.replaceChildren(items.length ? plusTable(cols, items, detail, { open, key: i => i.cve_id + "|" + tab,
        rowClass: i => i.exploited ? "vu-kev" : "", paged: { key: "impact-" + tab, items, page: pg, size: PAGE_SIZE, redraw: () => draw() } })
      : h("div", { class: "empty" }, h("p", null, tab === "servers"
          ? (all.length ? "Nothing matches the filter." : "No new critical, high or exploited CVE is proven on our machines.")
          : (all.length ? "Nothing matches the filter." : "No CVE names an appliance in the asset inventory. Appliances come from Inventory > Assets "
             + "(type appliance, network or firewall); record the firmware version in the OS column to have it checked."))),
      pager(pg, pages, items.length, PAGE_SIZE, n => { pg = n; draw(); }));
  }
  draw();
  page.append(...[
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure vulns --detected" }, "Vulnerabilities"),
      h("span", { class: "head-actions" }, scan, xl, pdf)),
    h("p", { class: "muted small" }, "New critical, high and exploited CVEs of the last " + d.days + " days that are proven on our machines: "
      + "a version compared with the vendor's fixed build or NVD's affected range, or Windows Update reporting the fix missing. "
      + "Checked every " + (d.every_hours || 4) + " hours and when the inventory changes" + (c.analysed_at ? "; last check " + timeAgo(c.analysed_at) : "") + ". ",
      scanMsg),
    scanLine, tiles, charts, pipeline(),
    h("div", { class: "srv-bar" }, tabsBox, search), chips, box].filter(Boolean));
  render(page);
  vulnTabs("impact");
}

async function renderAdvisories() {
  const d = await api("/admin/advisories");
  const all = d.advisories || [];
  let q = "", sev = "", src = "", kevOnly = false, pg = 1;
  const open = new Set();
  const box = h("div");
  const cveCache = new Map();
  const draw = () => {
    const needle = q.toLowerCase();
    const items = all.filter(a => (!needle || (a.id + " " + (a.title || "") + " " + (a.cves || []).join(" ")).toLowerCase().includes(needle))
      && (!sev || (sev === "high" ? ["high", "important"].includes(a.severity) : sev === "medium" ? ["medium", "moderate"].includes(a.severity) : a.severity === sev))
      && (!src || a.source === src) && (!kevOnly || a.exploited));
    setMailParams(kevOnly ? { exploited_only: true } : {});
    setPageExport(() => ({ title: "Advisories affecting servers", filter: pageFilterText() + (kevOnly ? "; exploited only" : ""),
      columns: ["Advisory", "Kind", "Severity", "Worst CVSS", "Exploited", "Servers affected", "Reboot needed", "CVEs", "Issued", "Title"],
      rows: items.map(a => [a.id, a.source === "windows_update" ? "Windows update" : (a.os_id || a.vendor || ""), a.severity || "",
        a.max_cvss, a.exploited ? "yes" : "", a.servers_affected, a.servers_reboot, (a.cves || []).join(" "),
        a.issued_at ? fmtDate(a.issued_at) : "", a.title || ""]) }));
    const pages = Math.max(1, Math.ceil(items.length / PAGE_SIZE));
    pg = Math.min(pg, pages);
    const rows = items.slice((pg - 1) * PAGE_SIZE, pg * PAGE_SIZE);
    box.replaceChildren(rows.length ? plusTable([
      { label: "Advisory", cell: a => h("strong", { class: "mono" }, a.id) },
      { label: "Severity", sort: a => (a.exploited ? 100 : 0) + Number(a.max_cvss || 0), cell: a => a.exploited ? h("span", { class: "sv sv-crit sv-0day" }, "Exploited") : sevChip(a.severity, a.max_cvss) },
      { label: "Kind", cell: a => a.source === "windows_update" ? "Windows update" : (a.os_id ? a.os_id.toUpperCase() + (a.os_major ? " " + a.os_major : "") : a.vendor) },
      { label: "Affects", num: true, cell: a => String(a.servers_affected || 0) },
      { label: "Reboot", num: true, cell: a => a.servers_reboot ? String(a.servers_reboot) : "" },
      { label: "CVEs", num: true, cell: a => String((a.cves || []).length) },
      { label: "Issued", sort: a => a.issued_at ? Date.parse(a.issued_at) : null, cell: a => a.issued_at ? fmtDate(a.issued_at) : "" },
      { label: "Title", cell: a => h("span", { class: "vu-title" }, a.title || "") },
    ], rows, async a => {
      const [hs, cv] = await Promise.all([
        api("/admin/advisories/" + encodeURIComponent(a.id) + "/hosts"),
        a.source === "advisory" ? (cveCache.get(a.id) || api("/admin/advisories/" + encodeURIComponent(a.id) + "/cves")) : null]);
      if (cv) cveCache.set(a.id, cv);
      return [
        h("h4", { class: "vu-h" }, "Servers (" + (hs.hosts || []).length + ")"),
        (hs.hosts || []).length ? h("div", { class: "cm-table" }, table([
          { label: "", cell: x => srvLight(x.agent) },
          { label: "Server", cell: x => routeAllowed("host") ? h("a", { href: "#/host/" + x.host_id }, x.hostname) : x.hostname },
          { label: "State", cell: x => x.state === "affected" ? "affected" : "fixed, reboot needed" },
          { label: "Package", cell: x => x.package || "" },
          { label: "Installed", cell: x => x.installed || "" },
          { label: "Fixed in", cell: x => x.fixed_in || "" },
        ], hs.hosts)) : h("p", { class: "muted small" }, "No server needs it any more."),
        h("h4", { class: "vu-h" }, "CVEs (" + (a.cves || []).length + ")"),
        cv && (cv.cves || []).length ? h("div", { class: "cm-table" }, table([
          { label: "CVE", cell: x => h("a", { href: "https://nvd.nist.gov/vuln/detail/" + x.cve_id, target: "_blank", rel: "noopener noreferrer" }, x.cve_id) },
          { label: "CVSS", cell: x => x.cvss_score !== null && x.cvss_score !== undefined ? Number(x.cvss_score).toFixed(1) : "" },
          { label: "Exploited", cell: x => x.kev ? "yes" : "" },
          { label: "Attack type", cell: x => x.attack_class || "" },
          { label: "Description", cell: x => h("span", { class: "vu-title" }, x.description || "") },
        ], cv.cves)) : h("p", { class: "muted small" }, (a.cves || []).join(", ") || "No CVEs listed."),
        can("operator") && hasModule("patch") && a.source === "advisory" && (hs.hosts || []).some(x => x.state === "affected")
          ? h("div", { class: "cm-actions" }, h("a", { class: "btn", href: "#/changes/new?kind=patch&advisories=" + encodeURIComponent(a.id)
              + "&hosts=" + encodeURIComponent((hs.hosts || []).filter(x => x.state === "affected").map(x => x.host_id).join(",")) }, "Patch these servers")) : null];
    }, { open, key: a => a.id, rowClass: a => a.exploited ? "vu-kev" : "",
         paged: { key: "advisories", items, page: pg, size: PAGE_SIZE, redraw: () => draw() } })
      : h("div", { class: "empty" }, h("p", null, all.length ? "No advisories match." : "No advisory affects a server right now.")),
      pager(pg, pages, items.length, PAGE_SIZE, n => { pg = n; draw(); }));
  };
  const search = h("input", { type: "search", placeholder: "Search advisory, KB, CVE or title", "aria-label": "Search advisories" });
  let t = null;
  search.addEventListener("input", () => { clearTimeout(t); t = setTimeout(() => { q = search.value.trim(); pg = 1; draw(); }, 250); });
  const sel = (label, opts, set) => h("select", { "aria-label": label, on: { change: e => { set(e.target.value); pg = 1; draw(); } } },
    h("option", { value: "" }, label + ": all"), opts.map(([v, t2]) => h("option", { value: v }, t2)));
  const kev = h("input", { type: "checkbox" });
  kev.addEventListener("change", () => { kevOnly = kev.checked; pg = 1; draw(); });
  draw();
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure vulns --advisories" }, "Vulnerabilities"),
      h("span", { class: "muted small" }, all.length + " advisories and updates affecting servers")),
    h("div", { class: "srv-bar" }, search,
      sel("Severity", [["critical", "Critical"], ["high", "High / important"], ["medium", "Medium / moderate"], ["low", "Low"]], v => { sev = v; }),
      sel("Kind", [["advisory", "Vendor advisories"], ["windows_update", "Windows updates"]], v => { src = v; }),
      h("label", { class: "cm-check" }, kev, " Exploited only")),
    box);
  vulnTabs("advisories");
}

/* ---- admin: who may open which module ------------------------------------------ */

const ASSET_PERM_COLS = [{ key: "approve", label: "Approve" }, { key: "decom", label: "Decom" }, { key: "revoke", label: "Revoke" }];

async function renderAccess() {
  setNav("admin");
  const d = await api("/admin/users");
  const msg = h("p", { class: "cm-meta", role: "status" });
  const rows = d.users || [];
  const t = table([
    { label: "User", cell: u => h("span", null, h("strong", null, u.username), u.display_name ? " · " + u.display_name : "") },
    { label: "Role", cell: u => u.role },
    ...MODULES.map(m => ({ label: m.label, cell: u => {
      if (u.role === "admin") return h("span", { class: "muted small" }, "always");
      const box = h("input", { type: "checkbox", checked: (u.modules || []).includes(m.key), "data-user": u.username,
                               "data-mod": m.key, "aria-label": m.label + " for " + u.username });
      box.addEventListener("change", async () => {
        // The whole row is sent, read from its boxes, and locked until the server answers
        const row = [...document.querySelectorAll("input[data-user]")].filter(b => b.dataset.user === u.username);
        const want = row.filter(b => b.checked).map(b => b.dataset.mod);
        row.forEach(b => { b.disabled = true; });
        try {
          const r = await apiSend("PATCH", "/admin/users/" + encodeURIComponent(u.username), { modules: want });
          u.modules = Array.isArray(r.modules) ? r.modules : want;
          msg.textContent = u.username + ": " + (u.modules.length ? u.modules.map(k => MODULES.find(x => x.key === k).label).join(", ") : "no modules")
            + ". Applies at once, on their next click.";
        } catch (err) { msg.textContent = err.message; }
        row.forEach(b => { b.checked = (u.modules || []).includes(b.dataset.mod); b.disabled = false; });
      });
      return box;
    } })),
    ...ASSET_PERM_COLS.map(m => ({ label: m.label, cell: u => {
      if (u.role === "admin") return h("span", { class: "muted small" }, "always");
      if (!d.asset_perms_installed) return h("span", { class: "muted small" }, "–");
      const box = h("input", { type: "checkbox", checked: (u.asset_perms || []).includes(m.key), "data-puser": u.username,
                               "data-perm": m.key, "aria-label": m.label + " assets, for " + u.username });
      box.addEventListener("change", async () => {
        const row = [...document.querySelectorAll("input[data-puser]")].filter(b => b.dataset.puser === u.username);
        const want = row.filter(b => b.checked).map(b => b.dataset.perm);
        row.forEach(b => { b.disabled = true; });
        try {
          const r = await apiSend("PATCH", "/admin/users/" + encodeURIComponent(u.username), { asset_perms: want });
          u.asset_perms = Array.isArray(r.asset_perms) ? r.asset_perms : want;
          msg.textContent = u.username + ", assets: " + (u.asset_perms.length ? u.asset_perms.map(k => ASSET_PERM_COLS.find(x => x.key === k).label).join(", ") : "no actions")
            + ((u.modules || []).includes("inventory") ? "." : ". They also need Asset & Inventory ticked to open the page.");
        } catch (err) { msg.textContent = err.message; }
        row.forEach(b => { b.checked = (u.asset_perms || []).includes(b.dataset.perm); b.disabled = false; });
      });
      return box;
    } })),
    { label: "Active", cell: u => u.active ? "yes" : "no" },
  ], rows);
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure access" }, "Access")),
    h("p", { class: "muted" }, "Choose which modules each user may open. The home page lights the modules a user may open and greys "
      + "out the rest, and the API refuses the others whatever the browser does. Admins can always open everything. "
      + "Roles (viewer, operator, admin) still decide what a user may change inside a module: set them under Users. "
      + "Approve, Decom and Revoke decide who may approve assets, decommission them and take either back (Asset & Inventory > Assets); "
      + "every such action is recorded with the user and time."),
    t, msg);
  adminTabs("access");
}

/* ---- admin: CVE feeds ------------------------------------------------------- */


async function renderFeedsAdmin() {
  setNav("admin");
  const d = await api("/admin/feeds");
  const page = h("div", { class: "feeds-admin" });
  render(page);
  drawFeedsAdmin(page, d);
  adminTabs("feeds");
}

function drawFeedsAdmin(page, d) {
  const st = d.settings || {};
  const msg = h("p", { class: "cm-meta", role: "status" });
  const box = (k, label) => h("label", { class: "cm-check" }, h("input", { type: "checkbox", name: k, checked: !!st[k] }), " " + label);
  const num = (k, label, min, max, step) => h("label", null, h("span", null, label),
    h("input", { type: "number", name: k, value: st[k], min, max, step: step || 1, required: true }));
  const form = h("form", { class: "feeds-form", on: { submit: async e => {
    e.preventDefault();
    const fd = new FormData(form);
    const body = { nist: fd.has("nist"), msrc: fd.has("msrc"), redhat: fd.has("redhat"), signin_board: fd.has("signin_board"),
                   days_back: Number(fd.get("days_back")), min_cvss: Number(fd.get("min_cvss")),
                   interval_minutes: Number(fd.get("interval_minutes")), signin_min_cvss: Number(st.signin_min_cvss || 7) };
    try { const r = await apiSend("PUT", "/admin/feeds/settings", body); drawFeedsAdmin(page, r); }
    catch (err) { msg.textContent = err.message || "Could not save."; }
  } } },
    h("fieldset", null, h("legend", null, "Sources"), box("nist", "NIST NVD"), box("msrc", "Microsoft"), box("redhat", "Red Hat")),
    h("div", { class: "feeds-nums" },
      num("days_back", "Days to show", 1, 90), num("min_cvss", "Lowest CVSS on the dashboard", 0, 10, 0.1),
      num("interval_minutes", "Read every (minutes)", 15, 1440)),
    h("fieldset", null, h("legend", null, "Sign-in page"),
      box("signin_board", "Show the CVE scroller before sign-in"),
      h("p", { class: "muted small" }, "The sign-in scroller shows only critical, high and 0-day CVEs from the general feeds, "
        + "never your watch list, so it does not reveal what software you run.")),
    h("div", { class: "cm-actions" }, h("button", { type: "submit" }, "Save"), msg));

  const term = h("input", { type: "text", maxlength: "60", placeholder: "for example: openssl, apache tomcat, vmware vcenter",
                            "aria-label": "Software to follow", required: true });
  const kind = h("select", { "aria-label": "Kind" }, ["software", "vendor", "keyword"].map(k => h("option", { value: k }, k)));
  const addMsg = h("p", { class: "cm-meta", role: "status" });
  const add = async (t, k) => {
    try { const r = await apiPost("/admin/feeds/watch", { term: t, kind: k || "software" }); drawFeedsAdmin(page, r); }
    catch (err) { addMsg.textContent = err.message || "Could not add."; }
  };
  const addForm = h("form", { class: "feeds-add", on: { submit: e => { e.preventDefault(); add(term.value.trim(), kind.value); } } },
    term, kind, h("button", { type: "submit" }, "Add"));

  const watch = d.watch || [];
  const watchTable = watch.length ? table([
    { label: "Software", cell: w => w.term },
    { label: "Kind", cell: w => w.kind },
    { label: "Following", cell: w => h("input", { type: "checkbox", checked: !!w.enabled, "aria-label": "Follow " + w.term,
        on: { change: async e => { try { drawFeedsAdmin(page, await apiSend("PATCH", "/admin/feeds/watch/" + w.id, { enabled: e.target.checked })); }
                                   catch (err) { addMsg.textContent = err.message; } } } }) },
    { label: "Added", cell: w => (w.added_by || "") + ", " + timeAgo(w.added_at) },
    { label: "", cell: w => h("button", { type: "button", class: "btn-link", on: { click: async () => {
        try { drawFeedsAdmin(page, await apiSend("DELETE", "/admin/feeds/watch/" + w.id)); } catch (err) { addMsg.textContent = err.message; } } } }, "Remove") },
  ], watch) : h("p", { class: "muted" }, "Nothing on the watch list yet. Until you add software, the dashboard shows every CVE collected.");

  const sugBox = h("div", { class: "feeds-sug" }, h("p", { class: "muted small" }, "Loading what your servers run"));
  api("/admin/feeds/suggestions").then(sg => {
    const group = (title, rows) => rows.length ? h("div", null, h("h3", null, title),
      h("div", { class: "chips" }, rows.slice(0, 40).map(r => h("button", { type: "button", class: "chip",
        title: r.servers ? "On " + r.servers + " server(s): add to the watch list" : "Add to the watch list",
        on: { click: () => add(r.name, r.kind) } }, "+ " + r.name + (r.servers ? " (" + r.servers + ")" : ""))))) : null;
    sugBox.replaceChildren(...[group("Windows software on your servers", sg.windows || []),
      group("Linux software on your servers", sg.linux || []), group("Operating systems", sg.os || [])].filter(Boolean));
    if (!sugBox.childNodes.length) sugBox.replaceChildren(h("p", { class: "muted small" }, "Everything your servers report is already on the list."));
  }).catch(() => sugBox.replaceChildren(h("p", { class: "muted small" }, "Suggestions are not available.")));

  const state = d.state || [];
  const stored = {};
  (d.stored || []).forEach(r => { stored[r.source] = r; });
  const stateTable = table([
    { label: "Source", cell: r => FEED_NAME[r.source] || r.source },
    { label: "Last read", cell: r => r.last_ok ? timeAgo(r.last_ok) : "never" },
    { label: "Read last time", num: true, cell: r => r.items === null || r.items === undefined ? "" : r.items },
    { label: "Kept", num: true, cell: r => stored[r.source] ? stored[r.source].n : 0 },
    { label: "Problem", cell: r => r.error ? h("span", { class: "hd-failed" }, r.error) : "" },
  ], ["nist", "msrc", "redhat"].map(k => Object.assign({ source: k }, state.find(x => x.source === k) || {})));
  const syncMsg = h("span", { class: "cm-meta", role: "status" });
  const syncBtn = h("button", { type: "button", on: { click: async () => {
    syncBtn.disabled = true;
    try { await apiPost("/admin/feeds/sync", {}); syncMsg.textContent = "Asked the worker: it starts within a minute. NIST takes a few minutes"
          + (d.nvd_api_key ? "." : " without an NVD API key."); }
    catch (err) { syncMsg.textContent = err.message; syncBtn.disabled = false; }
  } } }, "Read the feeds now");

  page.replaceChildren(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure feeds" }, "CVE feeds")),
    h("p", { class: "muted" }, "New CVEs from NIST NVD, Microsoft and Red Hat, read through the proxy by PATCH-01's worker. "
      + "Choose the software to follow: the dashboard and its news then show only CVEs naming that software, "
      + "plus any CVE already found on your servers."),
    h("section", null, h("h2", null, "Software to follow"), addForm, addMsg, watchTable, sugBox),
    h("section", null, h("h2", null, "Settings"), form),
    h("section", null, h("h2", null, "Status"), stateTable, h("div", { class: "cm-actions" }, syncBtn, syncMsg),
      d.worker_seen ? null : h("p", { class: "hd-failed" }, "The worker has not started reading feeds yet: rebuild it with phase3b-api.sh."),
      d.nvd_api_key || !d.worker_seen ? null : h("p", { class: "muted small" }, "No NVD API key is set, so NIST is read slowly "
        + "(5 requests every 30 seconds). A free key from NIST raises that tenfold: save it in /patch/secrets/nvd-api-key "
        + "on PATCH-01 and run phase3b-api.sh.")));
}

/* ---- export heading (browser-made CSVs) ------------------------------------- */

let orgInfo = null;
async function loadOrg() {
  if (orgInfo || !getAuth()) return orgInfo;
  try { orgInfo = await api("/branding/info"); } catch (e) { orgInfo = null; }
  return orgInfo;
}

/* The heading every export carries: portal and title, organisation, when, by
 * whom, how many rows. (A CSV cannot hold a picture; the Excel exports carry
 * the logo.) */
function exportHeading(title, n, filterText) {
  const a = getAuth();
  const now = new Date();
  const when = now.toLocaleString(undefined, { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
  const lines = [[PORTAL + " — " + title]];
  if (orgInfo && orgInfo.company) lines.push(["Organisation", orgInfo.company]);
  lines.push(["Generated", when], ["By", a ? a.user.username : ""]);
  if (filterText) lines.push(["Filter", filterText]);
  lines.push(["Rows", String(n)], []);
  return lines;
}

async function downloadFile(path, fallbackName) {
  const res = await fetch("/api/v1" + path, { headers: { "X-Requested-With": "patch01-dashboard", ...authHeaders() } });
  if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
  if (!res.ok) {
    const d = await res.json().catch(() => ({}));
    throw new ApiError(res.status, d.detail || res.statusText);
  }
  const cd = res.headers.get("Content-Disposition") || "";
  const m = /filename="([A-Za-z0-9._-]+)"/.exec(cd);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = h("a", { href: url, download: m ? m[1] : fallbackName });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return res.headers.get("X-Rows");
}

/* ---- Servers: servers and their agents, in one list --------------------------- */

const SRV_AGENT = { online: "Online", offline: "Offline", not_reporting: "Not reporting", no_data: "Never reported" };
const SRV_PATCH = { needs_patch: "Needs patches", needs_reboot: "Needs a reboot", up_to_date: "Up to date", unknown: "Patch state unknown" };
const SRV_SORT = { agent: "Offline first", name: "Name", last_seen: "Last seen", patches: "Most patches", os: "Operating system" };
const SRV_KEYS = ["view", "q", "os", "group", "version", "agent", "patch", "sort", "page"];

function srvLight(agent, last) {
  const on = agent === "online";
  const label = on ? "Online" : (SRV_AGENT[agent] || "Offline") + (last ? ", last seen " + timeAgo(last) : ", never reported");
  return h("span", { class: "light " + (on ? "light-on" : "light-off"), role: "img", "aria-label": label, title: label });
}

function fmtDays(sec) {
  if (sec === null || sec === undefined) return "not reported";
  const d = Math.floor(sec / 86400), hr = Math.floor((sec % 86400) / 3600);
  return d ? d + " d " + hr + " h" : hr + " h";
}

const LAST_PATCH = { done: "Patched", done_with_warnings: "Patched, with warnings", failed: "Failed" };
const LAST_PATCH_CLS = { done: "lp-ok", done_with_warnings: "lp-warn", failed: "lp-bad" };
/* The last patch job on a server: its result and when, linking to Patch Reports for that job */
function lastPatchCell(r, long) {
  if (!r.last_patch_at) return long ? "no patch job yet" : h("span", { class: "muted" }, "never");
  const n = r.last_patch_count;
  const what = (LAST_PATCH[r.last_patch_state] || r.last_patch_state) + (n ? ", " + n + (n === 1 ? " update" : " updates") : "");
  const href = "#/patch-reports?change=" + encodeURIComponent(r.last_patch_ref || "") + "&q=" + encodeURIComponent(r.hostname || "") + "&days=365";
  return h("a", { href, class: "lp " + (LAST_PATCH_CLS[r.last_patch_state] || ""), title: what + " · " + fmtDateTime(r.last_patch_at) + " · " + (r.last_patch_ref || "") },
    long ? what + ", " + fmtDateTime(r.last_patch_at) + " (" + (r.last_patch_ref || "") + ")" : timeAgo(r.last_patch_at));
}

/* How long the agent's last run took and where the time went (Windows agent 1.6.0+) */
function agentRunText(a) {
  if (!a || typeof a.seconds !== "number") return null;
  const ph = Object.entries(a.phases || {}).filter(([k]) => k !== "waiting for the next step").sort((x, y) => y[1] - x[1]);
  const wait = (a.phases || {})["waiting for the next step"];
  const parts = ph.slice(0, 3).filter(([, v]) => v >= 1).map(([k, v]) => k + " " + Math.round(v) + " s");
  return Math.round(a.seconds) + " s" + (a.at ? ", " + timeAgo(a.at) : "") + (parts.length ? " (" + parts.join(", ") + ")" : "")
    + (wait ? "; then waited " + Math.round(wait) + " s for the job's next step" : "");
}

/* What a patch job would install on one server now, loaded when its row opens: from the
   server's own word (Windows Update against WSUS, the Linux package manager). CVEs are on
   the Vulnerabilities pages, never here. */
function srvPending(r) {
  const box = h("div", { class: "srv-pending" }, h("p", { class: "muted small" }, "Loading the patches to install…"));
  if (r.os_id !== "windows" && (r.to_install === null || r.to_install === undefined)) {
    box.replaceChildren(h("p", { class: "small" }, h("span", { class: "state st-unknown" }, "Not known yet"),
      " This server's agent does not report what its package manager would install. Send agent 1.8.2 from Servers > Update agents;"
      + " its next inventory lists the updates here."));
    return box;
  }
  if (!Number(r.to_install || 0) && !Number(r.updates_available || 0)) {
    box.replaceChildren(h("p", { class: "small" }, h("span", { class: "state st-fixed_active" }, "Up to date"),
      " Nothing to install" + (r.os_id === "windows" ? " (Windows' last search of WSUS" : " (the package manager's last check")
      + (r.os_id === "windows" ? (r.last_inventory ? ", " + timeAgo(r.last_inventory) : "") : (r.updates_checked_at ? ", " + timeAgo(r.updates_checked_at) : "")) + ")."));
    return box;
  }
  api("/servers/" + encodeURIComponent(r.host_id) + "/pending").then(p => {
    if (!box.isConnected && !box.parentNode) return;
    const items = p.items || [];
    if (!items.length) { box.replaceChildren(h("p", { class: "small" }, "Nothing to install.")); return; }
    const win = p.kind === "windows";
    const sec = win ? items : items.filter(i => i.security !== false), other = win ? [] : items.filter(i => i.security === false);
    const linTable = list => h("div", { class: "table-wrap" }, h("table", { class: "srv-table pr-inner no-enh" },
      h("thead", null, h("tr", null, ["Package", "Installed", "Updates to", "Notice", "From"].map(x => h("th", { scope: "col" }, x)))),
      h("tbody", null, list.map(i => h("tr", null, h("td", { class: "mono" }, i.name + (i.arch && i.arch !== "noarch" ? "." + i.arch : "")),
        h("td", { class: "mono" }, i.installed || ""), h("td", { class: "mono" }, i.to || ""),
        h("td", { class: "small" }, i.advisory ? i.advisory + (i.severity ? " (" + i.severity + ")" : "") : (i.security === null ? "kind not reported" : "")),
        h("td", { class: "small muted" }, i.repo || ""))))));
    box.replaceChildren(
      h("h3", { class: "srv-pend-h" }, win ? items.length + (items.length === 1 ? " Windows update" : " Windows updates") + " to install"
        : sec.length + (sec.length === 1 ? " security update" : " security updates") + " to install"),
      win ? h("table", { class: "srv-table pr-inner no-enh" },
          h("thead", null, h("tr", null, ["Update", "Title", "Severity"].map(x => h("th", { scope: "col" }, x)))),
          h("tbody", null, items.map(i => h("tr", null, h("td", { class: "mono" }, i.kb || "update"), h("td", null, i.title),
            h("td", null, i.severity || "")))))
        : sec.length ? linTable(sec) : h("p", { class: "small" }, "No security update is waiting."),
      other.length ? h("details", { class: "srv-other" }, h("summary", null, other.length + " other " + (other.length === 1 ? "update" : "updates")
        + " available (not security: a patch job leaves them)"), linTable(other)) : null,
      p.error ? h("p", { class: "form-warn small" }, "The last check failed: " + p.error + ". The list above is from the check before.") : null,
      h("p", { class: "muted small" }, "From " + (win ? "Windows' last search of WSUS" : "the package manager's last check")
        + (p.as_of ? ", " + timeAgo(p.as_of) : "") + "."));
  }).catch(e => box.replaceChildren(h("p", { class: "hd-failed small" }, e.message || "Could not load the patches.")));
  return box;
}

function srvDetail(r) {
  const kv = (k, v) => v === null || v === undefined || v === "" ? null : h("div", { class: "kv" }, h("dt", null, k), h("dd", null, v));
  const toInstall = Number(r.to_install || 0);
  return h("div", { class: "srv-detail-in" },
    srvPending(r),
    h("dl", { class: "srv-kv" },
      kv("Group", r.host_group || "(no group)"),
      kv("Agent", (SRV_AGENT[r.agent] || r.agent) + (r.agent_version ? ", version " + r.agent_version : "")),
      kv("Last seen", r.last_checkin ? fmtDateTime(r.last_checkin) + " (" + timeAgo(r.last_checkin) + ")" : "never"),
      kv("Last inventory", r.last_inventory ? timeAgo(r.last_inventory) : null),
      kv("Last agent run", agentRunText(r.agent_run)),
      kv("Address", r.agent_ip), kv("Full name", r.fqdn),
      kv("Operating system", r.os_edition || ((r.os_id || "") + " " + (r.os_version || "")).trim()),
      kv("Running kernel", r.kernel_running),
      kv("Uptime", fmtDays(r.uptime_seconds)),
      kv("Reboot", r.reboot_required ? "pending" + (r.reboot_reason ? " (" + r.reboot_reason + ")" : "") : "not needed"),
      kv("Last patched", lastPatchCell(r, true)),
      kv("Installed, reboot needed", r.pending_reboot ? String(r.pending_reboot) : null),
      kv("Hardening score", r.hardening_score !== null && r.hardening_score !== undefined ? r.hardening_score + "%" : null),
      kv("Antivirus", r.antivirus ? "Trend Micro agent (" + r.antivirus + ")"
        : r.av_active ? h("span", { class: "hd-failed" }, "no agent reported by the antivirus consoles") : null),
      kv("VMware", r.vcenter ? [r.vcenter, r.cluster, r.power].filter(Boolean).join(" · ") : null)),
    h("div", { class: "cm-actions" },
      h("a", { class: "btn", href: "#/host/" + encodeURIComponent(r.host_id) }, "Open server page"),
      can("operator") && hasModule("patch") && toInstall ? h("a", { class: "btn btn-quiet",
        href: "#/changes/new?kind=patch&hosts=" + encodeURIComponent(r.host_id) }, "Patch this server") : null));
}

const SRV_OPEN_KEY = "cs.srv.open";
function srvOpenGroups() {
  try { return new Set(JSON.parse(localStorage.getItem(SRV_OPEN_KEY) || "[]")); } catch (e) { return new Set(); }
}
function srvSaveGroups(set) {
  try { localStorage.setItem(SRV_OPEN_KEY, JSON.stringify([...set].slice(0, 50))); } catch (e) { /* private mode */ }
}

/* ---- Restart only (admins): choose servers, restart them, nothing installed ---------- */

function srvRestartInfo(r) {
  return { host_id: r.host_id, hostname: r.hostname, needs: !!(r.reboot_required || Number(r.pending_reboot)),
           online: r.agent === "online", os: r.os_label || "" };
}

/* hosts: the servers chosen on the page, or null: every server that needs a restart */
async function restartDialog(hosts) {
  const hostsChosen = !!hosts;
  if (!hosts) {
    const d = await api("/servers?view=groups&patch=needs_reboot").catch(e => { alert(e.message); return null; });
    if (!d) return;
    hosts = (d.groups || []).flatMap(g => g.rows || []).map(srvRestartInfo);
  }
  const dlg = h("dialog", { class: "rs-dlg", "aria-labelledby": "rs-dlg-h" });
  const close = () => { dlg.close(); dlg.remove(); };
  if (!hosts.length) {
    dlg.append(h("h2", { id: "rs-dlg-h" }, "Restart servers"),
      h("p", null, "No server reports that it needs a restart."),
      h("p", { class: "muted small" }, "To restart others, choose them on this page, then “Restart them…”."),
      h("div", { class: "rs-dlg-act" }, h("button", { type: "button", class: "btn", on: { click: close } }, "Close")));
    document.body.append(dlg); dlg.showModal(); return;
  }
  const boxes = hosts.map(x => {
    // An offline agent cannot take the restart (the job would wait, then fail it): not ticked unless chosen on the page
    const cb = h("input", { type: "checkbox", checked: x.online !== false || hostsChosen, value: x.host_id, "aria-label": "Restart " + x.hostname });
    return { x, cb, row: h("label", { class: "rs-host" }, cb, h("span", { class: "rs-name" }, x.hostname),
      h("span", { class: "muted small" }, [x.os, x.needs === true ? "needs a restart" : x.needs === false ? "does not report needing one" : "",
        x.online === false ? "agent offline: PATCH-01 cannot restart it until it reports" : ""].filter(Boolean).join(" \u00b7 "))) };
  });
  const all = on => () => { boxes.forEach(b => { b.cb.checked = on; }); setCount(); };
  const pickAll = h("span", { class: "rs-all small" }, h("button", { type: "button", class: "btn-link", on: { click: all(true) } }, "All"),
    " \u00b7 ", h("button", { type: "button", class: "btn-link", on: { click: all(false) } }, "None"));
  const count = h("strong");
  const setCount = () => { const n = boxes.filter(b => b.cb.checked).length; count.textContent = n + (n === 1 ? " server" : " servers"); go.disabled = !n; };
  boxes.forEach(b => b.cb.addEventListener("change", setCount));
  const whenNow = h("input", { type: "radio", name: "rs-when", checked: true, value: "now" });
  const whenAt = h("input", { type: "radio", name: "rs-when", value: "at" });
  const at = h("input", { type: "datetime-local", "aria-label": "Restart at", disabled: true });
  [whenNow, whenAt].forEach(r => r.addEventListener("change", () => { at.disabled = !whenAt.checked; if (whenAt.checked) at.focus(); }));
  const par = h("input", { type: "number", min: "1", max: "50", value: "5", "aria-label": "Servers at a time" });
  const svc = h("input", { type: "checkbox", checked: true });
  const why = h("input", { type: "text", maxlength: "300", placeholder: "e.g. pending restarts after the 17 Oct patching", "aria-label": "Reason" });
  const err = h("p", { class: "explain-error", hidden: true });
  const go = h("button", { type: "submit", class: "btn" }, "Restart");
  const form = h("form", { method: "dialog", on: { submit: async e => {
    e.preventDefault();
    const ids = boxes.filter(b => b.cb.checked).map(b => b.x.host_id);
    err.hidden = true;
    if (!ids.length) return;
    if ((why.value || "").trim().length < 3) { err.textContent = "Say why: it is kept in the job's record."; err.hidden = false; why.focus(); return; }
    let runAfter = null;
    if (whenAt.checked) {
      const t = at.value ? new Date(at.value) : null;
      if (!t || isNaN(t)) { err.textContent = "Choose the restart time."; err.hidden = false; at.focus(); return; }
      runAfter = t.toISOString();
    }
    if (!confirm("Restart " + ids.length + (ids.length === 1 ? " server" : " servers") + (runAfter ? " at " + fmtDateTime(runAfter) : " now") + "?")) return;
    go.disabled = true;
    try {
      const r = await apiPost("/changes", { kind: "restart", title: "", reason: why.value.trim(), targets: ids.map(id => ({ host_id: id })),
        params: { check_services: svc.checked }, run_after: runAfter, max_parallel: Math.max(1, Math.min(50, Number(par.value) || 5)) });
      close();
      location.hash = "#/change/" + encodeURIComponent(r.id);
    } catch (ex) { err.textContent = ex.message; err.hidden = false; go.disabled = false; }
  } } },
    h("h2", { id: "rs-dlg-h" }, "Restart servers"),
    h("p", { class: "muted small" }, "Restarts only: nothing is installed. Each server gets a quick pre-check, the restart, "
      + "a wait until it is back, and a check that the same services are running again."),
    h("div", { class: "rs-list" }, boxes.map(b => b.row)),
    h("p", { class: "rs-count" }, count, " will restart ", pickAll),
    h("fieldset", { class: "rs-when" }, h("legend", null, "When"),
      h("label", null, whenNow, " Now"), h("label", null, whenAt, " At ", at)),
    h("label", { class: "rs-field" }, h("span", null, "Servers at a time"), par),
    h("label", { class: "rs-check" }, svc, " Check that the same services are running after the restart"),
    h("label", { class: "rs-field" }, h("span", null, "Reason"), why),
    err,
    h("div", { class: "rs-dlg-act" }, h("button", { type: "button", class: "btn btn-quiet", on: { click: close } }, "Cancel"), go));
  dlg.append(form);
  dlg.addEventListener("cancel", e => { e.preventDefault(); close(); });
  document.body.append(dlg);
  setCount();
  dlg.showModal();
  why.focus();
}

async function renderServers(params, legacyAgents) {
  setNav("hosts");
  loadOrg();
  const st = {};
  SRV_KEYS.forEach(k => { const v = params.get(k); if (v) st[k] = v; });
  if (legacyAgents && !st.agent && params.get("state")) st.agent = params.get("state");
  if (!st.sort) st.sort = "agent";
  const open = new Set();
  const openGroups = srvOpenGroups();
  const picked = new Set();
  const pickedInfo = new Map();          // host_id -> { host_id, hostname, needs } for the restart dialog
  const page = h("div", { class: "srv" });
  render(page);
  let timer = null, seq = 0, groupsMeta = null;
  const grouped = () => st.view !== "list";

  const qs = () => SRV_KEYS.filter(k => st[k] && !(k === "page" && st[k] === "1") && !(k === "sort" && st[k] === "agent"))
    .map(k => k + "=" + encodeURIComponent(st[k])).join("&");
  const filterText = () => ["q", "os", "group", "version", "agent", "patch"].filter(k => st[k])
    .map(k => ({ q: "name contains", os: "OS", group: "group", version: "agent version", agent: "agent", patch: "patch" }[k]) + " "
      + ({ agent: SRV_AGENT, patch: SRV_PATCH }[k] ? ({ agent: SRV_AGENT, patch: SRV_PATCH }[k][st[k]] || st[k]) : st[k])).join("; ");

  async function load(keepFocus) {
    const my = ++seq;
    const q = qs();
    const d = await api("/servers" + (grouped() ? "?view=groups" + (q ? "&" + q : "") : (q ? "?" + q : "")));
    if (!groupsMeta && can("operator")) groupsMeta = await api("/server-groups").then(x => x.groups || []).catch(() => []);
    if (my !== seq || !page.isConnected) return;
    history.replaceState(null, "", "#/hosts" + (q ? "?" + q : ""));
    draw(d, keepFocus);
  }
  const set = (k, v, keepFocus) => { if (v) st[k] = v; else delete st[k]; if (k !== "page") delete st.page; load(keepFocus).catch(showError); };

  const rowFor = r => {
    const isOpen = open.has(r.host_id);
    const btn = h("button", { type: "button", class: "srv-plus", "aria-expanded": String(isOpen),
                              "aria-label": (isOpen ? "Hide" : "Show") + " details of " + r.hostname }, isOpen ? "−" : "+");
    const detail = h("tr", { class: "srv-detail", hidden: !isOpen }, h("td", { colspan: "11" }, isOpen ? srvDetail(r) : null));
    btn.addEventListener("click", () => {
      const now = !open.has(r.host_id);
      now ? open.add(r.host_id) : open.delete(r.host_id);
      btn.textContent = now ? "−" : "+";
      btn.setAttribute("aria-expanded", String(now));
      btn.setAttribute("aria-label", (now ? "Hide" : "Show") + " details of " + r.hostname);
      detail.hidden = !now;
      if (now && !detail.firstChild.firstChild) detail.firstChild.append(srvDetail(r));
    });
    const n = Number(r.to_install || 0), unknownPatch = r.to_install === null || r.to_install === undefined;
    const pick = can("operator") ? h("input", { type: "checkbox", "aria-label": "Choose " + r.hostname, checked: picked.has(r.host_id) }) : null;
    if (pick) pick.addEventListener("change", () => {
      if (pick.checked) { picked.add(r.host_id); pickedInfo.set(r.host_id, srvRestartInfo(r)); }
      else { picked.delete(r.host_id); pickedInfo.delete(r.host_id); }
      updatePicked();
    });
    return [h("tr", { class: "srv-row" + (r.agent === "online" ? "" : " srv-off") },
      h("td", { class: "srv-c-pick" }, pick),
      h("td", { class: "srv-c-plus" }, btn),
      h("td", { class: "srv-c-light" }, srvLight(r.agent, r.last_checkin)),
      h("td", null, h("a", { href: "#/host/" + encodeURIComponent(r.host_id), class: "srv-name" }, r.hostname)),
      h("td", null, r.os_label || ""),
      grouped() ? null : h("td", null, r.host_group || ""),
      h("td", { class: "mono" }, r.agent_version || "unknown"),
      h("td", { title: r.last_checkin ? fmtDateTime(r.last_checkin) : "" }, r.last_checkin ? timeAgo(r.last_checkin) : "never"),
      h("td", { class: "num" }, unknownPatch
        ? h("span", { class: "muted", title: "This Linux server's agent does not report its package manager's updates yet: send agent 1.8.2 (Servers > Update agents)" }, "\u2013")
        : n ? h("span", { class: "count st-affected", title: r.os_id === "windows"
          ? n + " Windows updates missing (WSUS)" : n + " security updates (package manager)"
            + (Number(r.updates_available || 0) > n ? "; " + r.updates_available + " updates available in all" : "") }, String(n)) : "0"),
      h("td", null, r.reboot_required || Number(r.pending_reboot) ? h("span", { class: "srv-reboot" }, "Reboot") : ""),
      h("td", null, lastPatchCell(r))), detail];
  };
  const tableOf = rows => h("div", { class: "table-wrap" }, h("table", { class: "srv-table no-enh" },
    h("thead", null, h("tr", null,
      ["", "", "", "Server", "Operating system", grouped() ? null : "Group", "Agent", "Last seen", "To install", "Reboot", "Last patched"]
        .filter(x => x !== null).map((t, i, a) => h("th", { scope: "col", class: t === "To install" ? "num" : null }, t)))),
    h("tbody", null, rows.map(rowFor))));

  // Choose servers, then move them to a group (operators) or patch them
  const pickedBar = h("div", { class: "srv-picked", hidden: true });
  function updatePicked() {
    if (!can("operator")) return;
    pickedBar.hidden = !picked.size;
    if (!picked.size) return pickedBar.replaceChildren();
    const sel = h("select", { "aria-label": "Move to group" }, h("option", { value: "" }, "Move to group…"),
      (groupsMeta || []).map(g => h("option", { value: g.name }, g.name)));
    sel.addEventListener("change", async () => {
      if (!sel.value) return;
      if (!confirm("Move " + picked.size + " server(s) to " + sel.value + "?")) { sel.value = ""; return; }
      try { await apiPost("/servers/move-group", { host_ids: [...picked], group: sel.value }); picked.clear(); groupsMeta = null; await load(); }
      catch (e) { alert(e.message); sel.value = ""; }
    });
    pickedBar.replaceChildren(h("strong", null, picked.size + (picked.size === 1 ? " server chosen" : " servers chosen")), sel,
      hasModule("patch") ? h("a", { class: "btn btn-quiet", href: "#/changes/new?kind=patch&hosts=" + encodeURIComponent([...picked].join(",")) }, "Patch them…") : null,
      h("a", { class: "btn btn-quiet", href: "#/installed-patches?days=30&hosts=" + encodeURIComponent([...picked].join(",")) }, "Installed patches"),
      can("admin") && hasModule("patch") ? h("button", { type: "button", class: "btn btn-quiet",
        on: { click: () => restartDialog([...picked].map(id => pickedInfo.get(id) || { host_id: id, hostname: id, needs: null })) } }, "Restart them…") : null,
      h("button", { type: "button", class: "btn-link", on: { click: () => { picked.clear(); pickedInfo.clear(); draw(lastData); } } }, "Clear"));
  }
  let lastData = null;

  function draw(d, keepFocus) {
    lastData = d;
    const fc = d.facets || { agent: {}, patch: {}, os: [], group: [], version: [] };
    const head = h("div", { class: "page-head" },
      h("h1", { "data-cmd": "cybersecure servers" }, "Servers"),
      h("span", { class: "head-actions" },
        h("span", { class: "muted small" }, d.total + (d.total === 1 ? " server" : " servers") + (filterText() ? " match" : "")),
        can("admin") ? h("a", { class: "btn btn-quiet", href: "#/server-groups" }, "Groups…") : null,
        can("operator") ? h("a", { class: "btn btn-quiet", href: "#/server-groups?import=1" }, "Move from a list…") : null,
        h("a", { class: "btn btn-quiet", title: "What each server installed and when, with Excel and PDF exports",
          href: "#/installed-patches?days=30" + (st.group ? "&group=" + encodeURIComponent(st.group) : "") }, "Installed patches"),
        can("admin") && hasModule("patch") ? h("button", { type: "button", class: "btn btn-quiet", title: "Restart servers that need it (admins)",
          on: { click: () => restartDialog(null) } }, "Restart…") : null,
        exportControl()));
    setPageExport(() => {
      const q = SRV_KEYS.filter(k => st[k] && k !== "page").map(k => k + "=" + encodeURIComponent(st[k])).join("&");
      return { server: "/servers/export" + (q ? "?" + q : "") };
    });
    setMailParams(Object.fromEntries(["q", "os", "group", "version", "agent", "patch"].filter(k => st[k]).map(k => [k, st[k]])));

    const tile = (key, label, n, cls, k2) => h("button", { type: "button", class: "srv-tile " + cls,
      "aria-pressed": String((st[k2 || "agent"] || "") === key && (key || !st.patch || k2 === "patch")),
      on: { click: () => set(k2 || "agent", key === (st[k2 || "agent"] || "") ? "" : key) } },
      k2 ? null : key ? srvLight(key === "online" ? "online" : "offline") : null,
      h("span", { class: "srv-tile-n" }, String(n)), h("span", { class: "srv-tile-l" }, label));
    const tiles = h("div", { class: "srv-tiles", role: "group", "aria-label": "Server state" },
      tile("", "All servers", fc.total || 0, ""), tile("online", "Online", fc.agent.online || 0, "t-on"),
      tile("offline", "Offline", fc.agent.offline || 0, "t-off"),
      tile("needs_patch", "To patch", (fc.patch || {}).needs_patch || 0, "t-warn", "patch"),
      tile("needs_reboot", "Need a reboot", (fc.patch || {}).needs_reboot || 0, "", "patch"));

    const sel = (k, label, options) => h("select", { "aria-label": label, on: { change: e => set(k, e.target.value) } },
      h("option", { value: "" }, label + ": all"),
      options.map(([v, t]) => h("option", { value: v, selected: st[k] === v }, t)));
    const search = h("input", { type: "search", placeholder: "Search name or address", value: st.q || "", maxlength: "80",
                                "aria-label": "Search servers" });
    search.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => set("q", search.value.trim(), true), 350); });
    const viewBtn = (key, label) => h("button", { type: "button", class: "fbtn", "aria-pressed": String((key === "groups") === grouped()),
      on: { click: () => set("view", key === "list" ? "list" : "") } }, label);
    const bar = h("div", { class: "srv-bar" },
      h("span", { class: "pr-tabs", role: "group", "aria-label": "View" }, viewBtn("groups", "By group"), viewBtn("list", "List")),
      search,
      sel("os", "OS", (fc.os || []).map(o => [o.value, o.value + " (" + o.n + ")"])),
      sel("group", "Group", (fc.group || []).map(o => [o.value, o.value + " (" + o.n + ")"])),
      sel("agent", "Agent", Object.entries(SRV_AGENT).map(([k, v]) => [k, v + " (" + (fc.agent[k] || 0) + ")"])),
      sel("patch", "Patches", Object.entries(SRV_PATCH).map(([k, v]) => [k, v + " (" + (fc.patch[k] || 0) + ")"])),
      sel("version", "Agent version", (fc.version || []).map(o => [o.value, o.value + " (" + o.n + ")"])),
      h("select", { "aria-label": "Sort", on: { change: e => set("sort", e.target.value) } },
        Object.entries(SRV_SORT).map(([k, v]) => h("option", { value: k, selected: (st.sort || "agent") === k }, "Sort: " + v))),
      filterText() ? h("button", { type: "button", class: "btn-link", on: { click: () => {
        ["q", "os", "group", "version", "agent", "patch", "page"].forEach(k => delete st[k]); load().catch(showError); } } }, "Clear filters") : null);

    let body, pager = null;
    if (grouped()) {
      // Groups with servers, in patch order; empty groups on one line, so the page stays short
      const groups = (d.groups || []).filter(g => g.servers);
      const empty = (d.groups || []).filter(g => !g.servers && g.known);
      body = groups.length ? h("div", { class: "srv-groups" }, groups.map(g => {
        const isOpen = openGroups.has(g.name) || (groups.length === 1);
        const inner = h("div", { class: "srv-group-body", hidden: !isOpen }, isOpen ? (g.rows.length ? tableOf(g.rows)
          : h("p", { class: "muted small" }, "No servers in this group yet. Choose servers and use “Move to group”.")) : null);
        const btn = h("button", { type: "button", class: "srv-plus", "aria-expanded": String(isOpen),
          "aria-label": (isOpen ? "Collapse " : "Expand ") + g.name }, isOpen ? "−" : "+");
        const toggle = () => {
          const now = inner.hidden;
          now ? openGroups.add(g.name) : openGroups.delete(g.name);
          srvSaveGroups(openGroups);
          inner.hidden = !now;
          btn.textContent = now ? "−" : "+";
          btn.setAttribute("aria-expanded", String(now));
          if (now && !inner.firstChild) inner.append(g.rows.length ? tableOf(g.rows)
            : h("p", { class: "muted small" }, "No servers in this group yet. Choose servers and use “Move to group”."));
        };
        btn.addEventListener("click", toggle);
        const ids = g.rows.filter(r => Number(r.to_install || 0)).map(r => r.host_id);
        return h("section", { class: "srv-group" + (g.known ? "" : " srv-group-unknown"), "aria-label": "Group " + g.name },
          h("div", { class: "srv-group-head" }, btn,
            h("button", { type: "button", class: "srv-group-name", on: { click: toggle } }, g.name),
            g.description ? h("span", { class: "muted small srv-group-desc" }, g.description) : null,
            h("span", { class: "srv-group-stats" },
              h("span", { class: "chip" }, g.servers + (g.servers === 1 ? " server" : " servers")),
              g.windows ? h("span", { class: "chip chip-win" }, g.windows + " Windows") : null,
              g.linux ? h("span", { class: "chip chip-lin" }, g.linux + " Linux") : null,
              g.servers ? h("span", { class: "chip " + (g.online === g.servers ? "chip-ok" : "chip-bad") }, g.online + " online") : null,
              g.to_install_servers ? h("span", { class: "chip chip-warn" }, g.to_install_servers + " to patch") : g.servers ? h("span", { class: "chip chip-ok" }, "up to date") : null,
              g.reboot ? h("span", { class: "chip chip-warn" }, g.reboot + " reboot") : null),
            can("operator") && hasModule("patch") && ids.length ? h("a", { class: "btn btn-quiet srv-group-act",
              href: "#/changes/new?kind=patch&hosts=" + encodeURIComponent(ids.join(",")) }, "Patch this group…") : null),
          inner);
      }), empty.length && !filterText() ? h("p", { class: "muted small srv-empty-groups" }, "Empty groups: " + empty.map(g => g.name).join(", ")
        + ". Choose servers below and use \u201cMove to group\u201d.") : null)
        : h("div", { class: "empty" }, h("p", null, d.total === 0 && !filterText() ? "No servers have enrolled yet." : "No servers match these filters."));
    } else {
      body = d.rows && d.rows.length ? tableOf(d.rows)
        : h("div", { class: "empty" }, h("p", null, d.total === 0 && !filterText() ? "No servers have enrolled yet." : "No servers match these filters."));
      pager = d.pages > 1 ? h("nav", { class: "srv-pager", "aria-label": "Pages" },
        h("button", { type: "button", class: "btn btn-quiet", disabled: d.page <= 1, on: { click: () => set("page", String(d.page - 1)) } }, "‹ Previous"),
        h("span", null, "Page " + d.page + " of " + d.pages + " · " + ((d.page - 1) * d.size + 1) + "–" + Math.min(d.total, d.page * d.size) + " of " + d.total),
        h("button", { type: "button", class: "btn btn-quiet", disabled: d.page >= d.pages, on: { click: () => set("page", String(d.page + 1)) } }, "Next ›"))
        : null;
    }
    page.replaceChildren(...[head, tiles, bar, pickedBar, body, pager].filter(Boolean));
    updatePicked();
    if (keepFocus) { const s2 = page.querySelector(".srv-bar input[type=search]"); if (s2) { s2.focus(); s2.setSelectionRange(s2.value.length, s2.value.length); } }
  }

  await load();
  setPageTimer(() => { if (!document.hidden && document.activeElement && !page.contains(document.activeElement)) load().catch(() => {}); }, 60000);
}

/* ---- Patch groups (admins): SIT, UAT, PROD-1, PROD-2, Cluster Servers and your own ---- */
/* Move servers from a list: a text file (or pasted text) of server names, one
 * per line (commas, spaces and # comments are fine). PATCH-01 says which it
 * found (by name, full name or short name), which it did not, and which are
 * ambiguous; nothing moves until a group is chosen and confirmed. */
const LIST_MAX_BYTES = 1024 * 1024, LIST_MAX_NAMES = 2000;
function listNames(text) {
  return String(text || "").split(/\r?\n/).map(l => l.replace(/#.*$/, "")).join("\n")
    .split(/[\s,;]+/).map(x => x.trim()).filter(Boolean);
}
function moveFromList(groups) {
  const file = h("input", { type: "file", accept: ".txt,.csv,.list,text/plain", "aria-label": "Text file with server names" });
  const text = h("textarea", { rows: "5", placeholder: "One server name per line\nweb01\napp02.example.internal", "aria-label": "Server names", spellcheck: "false" });
  const msg = h("div", { role: "status" });
  const out = h("div");
  file.addEventListener("change", () => {
    msg.replaceChildren();
    const f = file.files && file.files[0];
    if (!f) return;
    if (f.size > LIST_MAX_BYTES) { msg.replaceChildren(h("div", { class: "form-warn" }, "That file is larger than 1 MB: a list of server names is much smaller.")); file.value = ""; return; }
    const r = new FileReader();
    r.onload = () => { text.value = String(r.result || ""); check(); };
    r.onerror = () => msg.replaceChildren(h("div", { class: "form-warn" }, "The file could not be read."));
    r.readAsText(f);
  });
  async function check() {
    out.replaceChildren(); msg.replaceChildren();
    const names = listNames(text.value);
    if (!names.length) { msg.replaceChildren(h("div", { class: "form-warn" }, "No server names in the list.")); return; }
    if (names.length > LIST_MAX_NAMES) { msg.replaceChildren(h("div", { class: "form-warn" }, "The list has " + names.length + " names: at most " + LIST_MAX_NAMES + " at a time.")); return; }
    msg.replaceChildren(h("p", { class: "muted small" }, "Looking up " + names.length + (names.length === 1 ? " name" : " names") + "…"));
    let r;
    try { r = await apiPost("/servers/match-names", { names }); }
    catch (e) { msg.replaceChildren(h("div", { class: "form-warn" }, e.message)); return; }
    msg.replaceChildren();
    const ticks = new Map();
    const found = r.found || [];
    const sel = h("select", { "aria-label": "Group to move them to" }, h("option", { value: "" }, "Choose a group…"),
      groups.map(g => h("option", { value: g.name }, g.name + " (" + g.servers + (g.servers === 1 ? " server)" : " servers)"))));
    const count = h("span", { class: "muted small" });
    const go = h("button", { type: "button", class: "btn", disabled: true });
    const done = h("div", { role: "status" });
    const refresh = () => {
      const n = [...ticks.values()].filter(b => b.checked).length;
      count.textContent = n + " of " + found.length + " chosen";
      go.textContent = n ? "Move " + n + (n === 1 ? " server" : " servers") + (sel.value ? " to " + sel.value : "") : "Move";
      go.disabled = !n || !sel.value;
    };
    sel.addEventListener("change", refresh);
    go.addEventListener("click", async () => {
      const ids = [...ticks.entries()].filter(([, b]) => b.checked).map(([id]) => id);
      if (!ids.length || !sel.value) return;
      if (!confirm("Move " + ids.length + (ids.length === 1 ? " server" : " servers") + " to the group " + sel.value + "?")) return;
      go.disabled = true; done.replaceChildren(h("p", { class: "muted small" }, "Moving…"));
      let moved = 0;
      try {
        for (let i = 0; i < ids.length; i += 500) moved += (await apiPost("/servers/move-group", { host_ids: ids.slice(i, i + 500), group: sel.value })).moved || 0;
        done.replaceChildren(h("div", { class: "form-ok" }, moved + (moved === 1 ? " server" : " servers") + " moved to " + sel.value + ". ",
          h("a", { href: "#/hosts" }, "See the servers")));
      } catch (e) {
        done.replaceChildren(h("div", { class: "form-warn" }, (moved ? moved + " moved, then: " : "") + e.message)); go.disabled = false;
      }
    });
    const all = h("input", { type: "checkbox", checked: true, "aria-label": "Choose every server found" });
    all.addEventListener("change", () => { ticks.forEach(b => { b.checked = all.checked; }); refresh(); });
    const lines = [];
    if (found.length) lines.push(h("h3", null, "Found: " + found.length + " of " + r.listed),
      h("div", { class: "table-wrap mv-list-tbl" }, h("table", { class: "srv-table no-enh", "data-no-page": "1" },
        h("thead", null, h("tr", null, h("th", { scope: "col" }, all), ["Server", "Listed as", "Operating system", "Group now"].map(x => h("th", { scope: "col" }, x)))),
        h("tbody", null, found.map(x => {
          const b = h("input", { type: "checkbox", checked: true, "aria-label": "Move " + x.hostname });
          b.addEventListener("change", refresh); ticks.set(x.host_id, b);
          return h("tr", null, h("td", null, b), h("td", null, h("strong", null, x.hostname)),
            h("td", { class: "small" }, x.listed_as, x.matched_by !== "name" ? h("span", { class: "muted" }, " (by " + x.matched_by + ")") : null),
            h("td", { class: "small" }, ((x.os_id === "windows" ? "Windows " : (x.os_id || "") + " ") + (x.os_version || "")).trim()),
            h("td", null, x.host_group || h("span", { class: "muted" }, "(no group)")));
        })))),
      h("div", { class: "form-actions mv-list-act" }, sel, go, count), done);
    if ((r.ambiguous || []).length) lines.push(h("h3", null, "More than one server has this name (" + r.ambiguous.length + ")"),
      h("p", { class: "muted small" }, "Not moved. List them by their full name (FQDN) instead."),
      h("ul", { class: "small" }, r.ambiguous.map(a => h("li", null, h("strong", null, a.name), ": " + a.servers.join(", ")))));
    if ((r.not_found || []).length) lines.push(h("h3", null, "Not found (" + r.not_found.length + ")"),
      h("p", { class: "muted small" }, "PATCH-01 has no server with these names: not enrolled yet, decommissioned, or spelled differently."),
      h("p", { class: "small mono mv-list-nf" }, r.not_found.join(", ")));
    if ((r.invalid || []).length) lines.push(h("h3", null, "Not server names (" + r.invalid.length + ")"),
      h("p", { class: "small mono mv-list-nf" }, r.invalid.join(", ")));
    if (!found.length) lines.unshift(h("div", { class: "form-warn" }, "None of the " + r.listed + " names matched a server."));
    out.replaceChildren(...lines);
    refresh();
  }
  return h("section", { class: "form-sec", id: "move-from-list" },
    h("h2", null, "Move servers from a list"),
    h("p", { class: "muted small" }, "Upload a text file with server names, one per line, or paste them. PATCH-01 shows which servers it found; "
      + "you then choose the group. Nothing moves before you confirm."),
    h("div", { class: "mv-list-in" }, h("label", null, h("span", null, "Text file"), file), h("label", null, h("span", null, "Or paste the names"), text)),
    h("div", { class: "form-actions" }, h("button", { type: "button", class: "btn btn-quiet", on: { click: () => check() } }, "Find these servers")),
    msg, out);
}

async function renderServerGroups(params) {
  setNav("hosts");
  const d = await api("/server-groups");
  const admin = can("admin");
  const ENV = { test: "Test", staging: "Staging", prod: "Production", dev: "Development" };
  const rows = (d.groups || []).map(g => {
    const desc = h("input", { type: "text", value: g.description || "", maxlength: "200", "aria-label": "Description of " + g.name, disabled: !admin });
    const env = h("select", { "aria-label": "Environment of " + g.name, disabled: !admin }, Object.entries(ENV).map(([k, v]) => h("option", { value: k, selected: g.environment === k }, v)));
    const order = h("input", { type: "number", min: "0", max: "10000", value: String(g.patch_order), "aria-label": "Patch order of " + g.name, disabled: !admin, class: "num-in" });
    const maxc = h("input", { type: "number", min: "1", max: "50", value: String(g.max_concurrent), "aria-label": "At a time in " + g.name, disabled: !admin, class: "num-in" });
    const save = admin ? h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
      try { await apiSend("PUT", "/admin/server-groups/" + encodeURIComponent(g.name), { name: g.name, description: desc.value, environment: env.value,
        patch_order: Number(order.value), max_concurrent: Number(maxc.value) }); save.textContent = "Saved"; setTimeout(() => { save.textContent = "Save"; }, 1500); }
      catch (e) { alert(e.message); } } } }, "Save") : null;
    const del = admin && g.name !== "default" ? h("button", { type: "button", class: "btn-link", on: { click: async () => {
      if (!confirm("Remove the group " + g.name + "?")) return;
      try { await apiSend("DELETE", "/admin/server-groups/" + encodeURIComponent(g.name)); route(); } catch (e) { alert(e.message); } } } }, "Remove") : null;
    return h("tr", null, h("td", null, h("strong", null, g.name)), h("td", null, desc), h("td", null, env), h("td", null, order), h("td", null, maxc),
      h("td", { class: "num" }, String(g.servers)), h("td", { class: "small muted" }, g.windows + " Windows, " + g.linux + " Linux"), h("td", null, save, " ", del));
  });
  const name = h("input", { type: "text", maxlength: "40", placeholder: "e.g. PROD-3" });
  const ndesc = h("input", { type: "text", maxlength: "200", placeholder: "What these servers are" });
  const err = h("div", { role: "alert" });
  render(h("div", { class: "srv" },
    h("div", { class: "page-head" }, h("h1", null, "Patch groups"), h("span", { class: "head-actions" }, h("a", { href: "#/hosts", class: "small" }, "Servers"))),
    h("p", { class: "muted" }, "Servers are patched by group, in patch order (lowest first), with at most “at a time” servers of a group at once. Put servers in a group from the Servers page (choose them, then “Move to group”), or from a list below."),
    h("div", { class: "table-wrap" }, h("table", { class: "srv-table no-enh" },
      h("thead", null, h("tr", null, ["Group", "Description", "Environment", "Patch order", "At a time", "Servers", "", ""].map(x => h("th", { scope: "col" }, x)))),
      h("tbody", null, rows))),
    admin ? h("div", { class: "form-sec" }, h("h2", null, "Add a group"),
      h("label", null, h("span", null, "Name"), name), h("label", null, h("span", null, "Description"), ndesc),
      h("div", { class: "form-actions" }, h("button", { type: "button", class: "btn", on: { click: async () => {
        err.replaceChildren();
        try { await apiPost("/admin/server-groups", { name: name.value.trim(), description: ndesc.value, environment: "prod", patch_order: 100, max_concurrent: 5 }); route(); }
        catch (e) { err.replaceChildren(h("div", { class: "form-warn" }, e.message)); } } } }, "Add group")), err) : null,
    can("operator") ? moveFromList(d.groups || []) : null));
  if (params && params.get("import")) { const el = document.getElementById("move-from-list"); if (el) el.scrollIntoView({ block: "start" }); }
}

/* ---- Patch Reports: what each finished patch job installed, per server -----------------
 * Two views of the same jobs: Servers (one row per server per job) and Updates and
 * packages (one row per Windows KB or Linux package). Export gives every matching
 * row as PDF or CSV from the server; E-mail sends the server-built report (or the
 * rows shown or ticked) and can be scheduled. */
const PR_KEYS = ["view", "days", "os", "result", "q", "change", "group", "page"];
const PR_RESULT = { ok: "Patched", warnings: "Patched, with warnings", failed: "Failed", nothing: "Nothing to install" };
const PR_RESULT_CLS = { ok: "st-fixed_active", warnings: "st-warn", failed: "st-affected", nothing: "st-unknown" };
const PR_DAYS = { 1: "Last 24 hours", 7: "Last 7 days", 14: "Last 14 days", 30: "Last 30 days", 90: "Last 90 days", 180: "Last 6 months", 365: "Last 12 months" };
const PR_SIZE = PAGE_SIZE;

function prStatus(t) {
  const cls = t === "Installed" ? "st-fixed_active" : t === "Failed" ? "st-affected" : /restart|still installing/.test(t) ? "st-warn" : "st-unknown";
  return h("span", { class: "state " + cls }, t);
}

async function renderPatchReports(params) {
  setNav("patch-reports");
  loadOrg();
  const st = {};
  PR_KEYS.forEach(k => { const v = params.get(k); if (v) st[k] = v; });
  const open = new Set();
  const page = h("div", { class: "srv pr" });
  render(page);
  let timer = null, seq = 0;
  const VIEWS = ["jobs", "groups", "summary", "patches"];
  const view = () => VIEWS.includes(st.view) ? st.view : "jobs";
  const FILT = ["days", "os", "result", "q", "change", "group"];
  const filt = () => FILT.filter(k => st[k]);
  const qs = keys => keys.filter(k => st[k] && !(k === "page" && st[k] === "1") && !(k === "view" && st[k] === "jobs"))
    .map(k => k + "=" + encodeURIComponent(st[k])).join("&");

  async function load(keepFocus) {
    const my = ++seq;
    const q = qs(FILT);
    const d = await api("/patch-reports" + (q ? "?" + q : ""));
    if (my !== seq || !page.isConnected) return;
    const all = qs(PR_KEYS);
    history.replaceState(null, "", "#/patch-reports" + (all ? "?" + all : ""));
    draw(d, keepFocus);
  }
  const set = (k, v, keepFocus) => { if (v) st[k] = v; else delete st[k]; if (k !== "page") delete st.page; load(keepFocus).catch(showError); };

  const resultChip = r => h("span", { class: "state " + (PR_RESULT_CLS[r.result] || "st-unknown") }, r.result_label);
  const confirmed = p => p.status === "Installed" && p.confirmed ? h("span", { class: "pr-conf", title: "The server's own installed list has it" }, "✓ on the server")
    : p.status === "Installed" && p.confirmed === false ? h("span", { class: "pr-conf pr-conf-no", title: "The job reported it installed, but the server's list does not have it" }, "not on the server's list")
    : p.source === "server" ? h("span", { class: "pr-conf", title: "The job did not record it; the server's list has it" }, "found on the server") : null;
  const patchTable = (list, withJob) => h("table", { class: "srv-table pr-inner no-enh" },
    h("thead", null, h("tr", null, [withJob ? "Change" : null, "Update / package", "Description", "Update notice", "Status", "Installed on", "Server check"]
      .filter(Boolean).map(x => h("th", { scope: "col" }, x)))),
    h("tbody", null, list.map(p => h("tr", null,
      withJob ? h("td", null, h("a", { href: "#/change/" + encodeURIComponent(p.change_id), class: "mono" }, p.ref)) : null,
      h("td", { class: "mono" }, p.patch), h("td", null, p.description), h("td", null, p.advisories || ""),
      h("td", null, prStatus(p.status)), h("td", { class: "nowrap" }, p.installed_on ? fmtDateTime(p.installed_on) : ""),
      h("td", null, confirmed(p))))));
  const restartText = r => r.reboot + (r.restarted_at ? " " + fmtDateTime(r.restarted_at) : "")
    + (r.restart_planned && r.reboot !== "Restarted" ? " (planned " + fmtDateTime(r.restart_planned) + ")" : "");

  // One server in one job: what happened, and every update or package
  const serverJob = (d, r, first, label) => {
    const list = (d.patches || []).filter(p => p.ref === r.ref && (p.host_id || p.server) === (r.host_id || r.server));
    return h("details", { class: "pr-job", open: !!first },
      h("summary", { class: "pr-job-head" }, resultChip(r),
        label === "server" ? h("a", { href: "#/host/" + encodeURIComponent(r.host_id || ""), class: "srv-name" }, r.server)
                           : h("a", { href: "#/change/" + encodeURIComponent(r.change_id), class: "mono" }, r.ref),
        label === "server" ? h("span", { class: "muted small" }, r.group ? "group " + r.group : "") : h("strong", null, r.change_title || ""),
        h("span", { class: "muted small" }, fmtDateTime(r.finished_at) + " · " + r.installed + " installed"
          + (r.failed ? ", " + r.failed + " not" : "") + (r.confirmed ? " (" + r.confirmed + " confirmed on the server)" : "")
          + " · " + restartText(r) + (r.snapshot && r.snapshot !== "None" ? " · snapshot " + r.snapshot.toLowerCase() : "")
          + (r.minutes !== null && r.minutes !== undefined ? " · " + r.minutes + " min" : ""))),
      r.error ? h("p", { class: "hd-failed small" }, r.error) : null,
      r.notes && r.notes !== r.error ? h("p", { class: "muted small" }, r.notes) : null,
      (r.warnings || []).length ? h("ul", { class: "small pr-warn" }, r.warnings.map(w => h("li", null, w))) : null,
      r.result === "failed" || (r.warnings || []).length ? explainBox({ state: r.result === "failed" ? "failed" : "done_with_warnings",
        warnings: r.warnings, explain: r.explain, target_key: r.target_key }, r.change_id) : null,
      list.length ? patchTable(list, false)
        : h("p", { class: "muted small" }, r.result === "nothing" ? "Nothing needed installing." : "No update or package was recorded."));
  };
  // A list that shows 30 and then more on request
  const more = (items, make) => {
    const wrap = h("div", { class: "pr-jobs" }, items.slice(0, PAGE_SIZE).map((x, i) => make(x, i)));
    if (items.length > PAGE_SIZE) {
      let next = PAGE_SIZE;
      const b = h("button", { type: "button", class: "btn btn-quiet" });
      const label = () => { b.textContent = "Show " + Math.min(PAGE_SIZE, items.length - next) + " more of " + (items.length - next); };
      label();
      b.addEventListener("click", () => { items.slice(next, next + PAGE_SIZE).forEach((x, i) => wrap.insertBefore(make(x, next + i), b));
        next += PAGE_SIZE; if (next >= items.length) b.remove(); else label(); });
      wrap.append(b);
    }
    return wrap;
  };
  const badge = (n, cls) => n ? h("span", { class: "count " + cls }, String(n)) : "0";

  function draw(d, keepFocus) {
    const t = d.totals || {};
    const v = view();
    const head = h("div", { class: "page-head" },
      h("h1", { "data-cmd": "cybersecure patch reports" }, "Patch Reports"),
      h("span", { class: "head-actions" },
        h("span", { class: "muted small" }, (t.jobs || 0) + " jobs, " + (t.servers || 0) + " servers, " + (t.groups || 0) + " groups · " + (d.describe || "")),
        exportControl()));
    // Every matching row (all pages), built on the server, laid out for print
    setPageExport(() => {
      const q = qs(FILT);
      return { server: "/patch-reports/export?view=" + v + (q ? "&" + q : "") };
    });
    setMailParams(Object.fromEntries(["os", "result", "q", "change", "group"].filter(k => st[k]).map(k => [k, st[k]])
      .concat([["days", Number(st.days || 30)]])), { jobs: "patch_jobs", groups: "patch_groups", patches: "patch_details" }[v] || "patch_summary");

    const tile = (key, label, n, cls) => h("button", { type: "button", class: "srv-tile " + cls, "aria-pressed": String((st.result || "") === key),
      on: { click: () => set("result", key === (st.result || "") ? "" : key) } },
      h("span", { class: "srv-tile-n" }, String(n || 0)), h("span", { class: "srv-tile-l" }, label));
    const stat = (n, label, cls) => h("span", { class: "srv-tile pr-stat " + (cls || "") }, h("span", { class: "srv-tile-n" }, String(n || 0)),
      h("span", { class: "srv-tile-l" }, label));
    const tiles = h("div", { class: "srv-tiles", role: "group", "aria-label": "Result" },
      tile("", "Server results", (t.ok || 0) + (t.warnings || 0) + (t.failed || 0) + (t.nothing || 0), ""),
      tile("ok", "Patched", t.ok, "t-on"), tile("warnings", "With warnings", t.warnings, "t-warn"),
      tile("failed", "Failed", t.failed, "t-off"), tile("nothing", "Nothing to install", t.nothing, ""),
      stat(t.patches_installed, "updates and packages installed" + (t.patches_confirmed ? " (" + t.patches_confirmed + " confirmed on the servers)" : "")
        + (t.patches_problem ? ", " + t.patches_problem + " not" : "")),
      t.restart_needed ? stat(t.restart_needed, "servers still need a restart", "t-warn") : null);

    const sel = (k, label, options, allText) => h("select", { "aria-label": label, on: { change: e => set(k, e.target.value) } },
      allText === false ? null : h("option", { value: "" }, label + ": all"),
      options.map(([val, txt]) => h("option", { value: val, selected: String(st[k] || "") === String(val) }, txt)));
    const search = h("input", { type: "search", placeholder: "Search server, group, change or title", value: st.q || "", maxlength: "80",
                                "aria-label": "Search patch reports" });
    search.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => set("q", search.value.trim(), true), 350); });
    if (!st.days) st.days = "30";
    const tab = (key, label) => h("button", { type: "button", class: "fbtn", "aria-pressed": String(v === key),
      on: { click: () => { open.clear(); set("view", key === "jobs" ? "" : key); } } }, label);
    const bar = h("div", { class: "srv-bar" },
      h("span", { class: "pr-tabs", role: "group", "aria-label": "View" },
        tab("jobs", "By job"), tab("groups", "By patch group"), tab("summary", "By server"), tab("patches", "Updates and packages")),
      search,
      sel("days", "Period", (d.days || [1, 7, 14, 30, 90, 180, 365]).map(n => [String(n), PR_DAYS[n] || n + " days"]), false),
      sel("group", "Group", (d.group_names || []).map(g => [g, g])),
      sel("os", "OS", [["windows", "Windows"], ["linux", "Linux"]]),
      sel("result", "Result", Object.entries(PR_RESULT)),
      st.change ? h("button", { type: "button", class: "fbtn", "aria-pressed": "true", title: "Show every job",
        on: { click: () => set("change", "") } }, "Change " + st.change + " ✕") : null,
      filt().some(k => k !== "days") ? h("button", { type: "button", class: "btn-link", on: { click: () => {
        ["os", "result", "q", "change", "group", "page"].forEach(k => delete st[k]); load().catch(showError); } } }, "Clear filters") : null);

    const summary = d.summary || [];
    let items, cols, detail, key;
    if (v === "jobs") {
      items = d.jobs || [];
      key = j => "j:" + j.ref;
      cols = [
        { label: "Change", cell: j => h("a", { href: "#/change/" + encodeURIComponent(j.change_id), class: "mono" }, j.ref) },
        { label: "Title", cell: j => j.title || "" },
        { label: "Finished", cell: j => h("span", { class: "nowrap" }, fmtDateTime(j.finished_at)) },
        { label: "Servers", num: true, cell: j => String(j.servers) },
        { label: "Patched", num: true, cell: j => String(j.ok + j.warnings) },
        { label: "Failed", num: true, cell: j => badge(j.failed, "st-affected") },
        { label: "Installed", num: true, cell: j => String(j.installed) },
        { label: "Not installed", num: true, cell: j => badge(j.not_installed, "st-affected") },
        { label: "Restart needed", num: true, cell: j => badge(j.restart_needed, "st-warn") },
      ];
      detail = j => {
        const rows = summary.filter(r => r.ref === j.ref);
        return [h("p", { class: "muted small pr-sub" }, (j.requested_by ? "Requested by " + j.requested_by + " · " : "") + "started " + fmtDateTime(j.started_at)
            + " · " + j.servers + (j.servers === 1 ? " server: " : " servers: ") + j.ok + " patched, " + j.warnings + " with warnings, " + j.failed + " failed, " + j.nothing + " nothing to install",
          " · ", h("a", { href: "#/patch-reports?view=patches&change=" + encodeURIComponent(j.ref) }, "every update of this job")),
          more(rows, (r, i) => serverJob(d, r, i === 0, "server"))];
      };
    } else if (v === "groups") {
      items = d.groups || [];
      key = g => "g:" + g.key;
      cols = [
        { label: "Patch group", cell: g => g.key ? h("strong", null, g.key) : h("span", { class: "muted" }, "(no group)") },
        { label: "Jobs", num: true, cell: g => String(g.jobs) },
        { label: "Servers", num: true, cell: g => String(g.servers) },
        { label: "Patched", num: true, cell: g => String(g.ok + g.warnings) },
        { label: "Failed", num: true, cell: g => badge(g.failed, "st-affected") },
        { label: "Installed", num: true, cell: g => String(g.installed) },
        { label: "Not installed", num: true, cell: g => badge(g.not_installed, "st-affected") },
        { label: "Restart needed", num: true, cell: g => badge(g.restart_needed, "st-warn") },
        { label: "Last finished", cell: g => h("span", { class: "nowrap" }, fmtDateTime(g.finished_at)) },
      ];
      detail = g => {
        const rows = summary.filter(r => (r.group || "") === g.key);
        return [g.key ? h("p", { class: "muted small pr-sub" }, h("a", { href: "#/patch-reports?view=patches&group=" + encodeURIComponent(g.key) }, "every update in this group")) : null,
          more(rows, (r, i) => serverJob(d, r, false, "both"))];
      };
    } else {
      // By server, or every update: one row per server, its jobs (newest first) inside
      const src = v === "patches" ? (d.patches || []) : summary;
      const idx = new Map();
      items = [];
      src.forEach(r => {
        const k = r.host_id || r.server;
        if (!idx.has(k)) { idx.set(k, items.length); items.push({ key: k, server: r.server, host_id: r.host_id, os: r.os, group: r.group || "", rows: [] }); }
        items[idx.get(k)].rows.push(r);
      });
      key = g => g.key;
      const srv = { label: "Server", cell: g => g.host_id ? h("a", { href: "#/host/" + encodeURIComponent(g.host_id), class: "srv-name" }, g.server) : g.server };
      if (v === "summary") {
        const sum = (g, f) => g.rows.reduce((a, r) => a + Number(f(r) || 0), 0);
        cols = [srv,
          { label: "Operating system", cell: g => g.os },
          { label: "Group", cell: g => g.group },
          { label: "Last result", cell: g => resultChip(g.rows[0]) },
          { label: "Last finished", cell: g => h("span", { class: "nowrap" }, fmtDateTime(g.rows[0].finished_at)) },
          { label: "Jobs", num: true, cell: g => String(g.rows.length) },
          { label: "Installed", num: true, cell: g => String(sum(g, r => r.installed)) },
          { label: "Not installed", num: true, cell: g => badge(sum(g, r => r.failed), "st-affected") },
          { label: "Restart", cell: g => g.rows[0].reboot === "Restart needed" ? h("span", { class: "srv-reboot" }, "Needed") : g.rows[0].reboot },
        ];
        detail = g => more(g.rows, (r, i) => serverJob(d, r, i === 0, "job"));
      } else {
        cols = [srv,
          { label: "Operating system", cell: g => g.os },
          { label: "Group", cell: g => g.group },
          { label: "Updates and packages", num: true, cell: g => String(g.rows.length) },
          { label: "Installed", num: true, cell: g => String(g.rows.filter(p => p.status === "Installed").length) },
          { label: "Not installed", num: true, cell: g => badge(g.rows.filter(p => p.status !== "Installed").length, "st-affected") },
          { label: "Last finished", cell: g => h("span", { class: "nowrap" }, fmtDateTime(g.rows[0].finished_at)) },
        ];
        detail = g => [patchTable(g.rows, true)];
      }
    }
    const pg = Math.max(1, Number(st.page || 1)), pages = Math.max(1, Math.ceil(items.length / PR_SIZE));
    const shown = items.slice((Math.min(pg, pages) - 1) * PR_SIZE, Math.min(pg, pages) * PR_SIZE);
    const tableEl = !items.length ? h("div", { class: "empty" }, h("p", null, "No finished patch jobs match these filters."),
        h("p", { class: "muted small" }, "A job shows here once each server in it has finished (patched, with warnings, or failed)."))
      : plusTable(cols, shown, detail, { open, key,
          // Shaded when nothing was patched (a job or group where every server failed, or a server's last job failed)
          rowClass: x => (x.rows ? x.rows[0].result === "failed" : (x.failed && !x.ok && !x.warnings)) ? "pr-failed" : "" });
    const pagerEl = pager(Math.min(pg, pages), pages, items.length, PR_SIZE, n => {
      st.page = String(n); const all = qs(PR_KEYS);
      history.replaceState(null, "", "#/patch-reports" + (all ? "?" + all : "")); draw(d); window.scrollTo(0, 0); });
    const note = d.limited ? h("p", { class: "muted small" }, "Showing the newest jobs only: narrow the period or search to see older ones.") : null;
    const how = h("p", { class: "muted small pr-how" }, "Each update is checked against the server's own installed list: “✓ on the server” "
      + "confirms it; “found on the server” means it went in although the job did not record it (for example a very long install).");
    page.replaceChildren(...[head, tiles, bar, tableEl, pagerEl, note, how].filter(Boolean));
    if (keepFocus) { const s2 = page.querySelector(".srv-bar input[type=search]"); if (s2) { s2.focus(); s2.setSelectionRange(s2.value.length, s2.value.length); } }
  }

  await load();
  setPageTimer(() => { if (!document.hidden && document.activeElement && !page.contains(document.activeElement)) load().catch(() => {}); }, 120000);
}

/* ---- one Export button on every page: PDF report or CSV ------------------------
 * The page's own data when it gives it (setPageExport), otherwise the table the
 * page is showing, as it is filtered. PDF carries the logo; both carry the
 * organisation, date and time, user and filter. */

let pageExport = null;
function setPageExport(fn) { pageExport = fn; }

const NO_EXPORT = new Set(["password", "two-factor", "branding", "certificate", "mail", "av-consoles", "report-schedules"]);

function textOf(el) { return (el.textContent || "").replace(/\s+/g, " ").trim(); }

function pageFilterText() {
  const v = document.getElementById("view");
  const bits = [];
  v.querySelectorAll('.fbtn[aria-pressed="true"], .filters button[aria-pressed="true"], .srv-tile[aria-pressed="true"]').forEach(b => {
    const t = textOf(b).replace(/\s*\(\d+\)$/, "");
    if (t && !/^all\b/i.test(t)) bits.push(t);
  });
  v.querySelectorAll("select").forEach(s => {
    if (s.value && s.closest("#view") && !s.closest(".exp")) {
      const o = s.options[s.selectedIndex];
      if (o && !/: all$/i.test(o.text) && !/^sort:/i.test(o.text)) bits.push(o.text.replace(/\s*\(\d+\)$/, ""));
    }
  });
  v.querySelectorAll('input[type="search"]').forEach(i => { if (i.value.trim()) bits.push('"' + i.value.trim() + '"'); });
  return bits.join("; ");
}

function pageTitle() {
  const h1 = document.querySelector("#view h1");
  return h1 ? textOf(h1) : PORTAL;
}

/* The visible table with the most rows: its headings and cell text. */
function tableFromPage() {
  const tables = [...document.querySelectorAll("#view table")].filter(t => t.offsetParent !== null && !t.closest(".exp"));
  if (!tables.length) return null;
  const t = tables.sort((a, b) => b.tBodies[0]?.rows.length - a.tBodies[0]?.rows.length || 0)[0];
  const ths = [...t.querySelectorAll("thead th")];
  const keep = ths.map((th, i) => textOf(th) ? i : -1).filter(i => i >= 0);
  const rows = [];
  [...(t.tBodies[0] ? t.tBodies[0].rows : [])].forEach(tr => {
    if (tr.hidden || tr.classList.contains("srv-detail") || tr.classList.contains("explain-row") || tr.classList.contains("vu-detail")) return;
    const cells = [...tr.cells];
    if (cells.length < ths.length) return;
    rows.push(keep.map(i => {
      const c = cells[i];
      const light = c.querySelector(".light");
      return light ? (light.getAttribute("aria-label") || "") : textOf(c);
    }));
  });
  return { columns: keep.map(i => textOf(ths[i])), rows: rows.slice(0, 5000) };
}

function donutsFromPage() {
  const cards = [...document.querySelectorAll("#view .dn-card")];
  if (!cards.length) return null;
  const rows = [];
  cards.forEach(c => {
    const title = textOf(c.querySelector(".dn-h") || c);
    c.querySelectorAll(".dn-legend li").forEach(li => rows.push([title, textOf(li.querySelector(".dn-l")),
      textOf(li.querySelector(".dn-v")), textOf(li.querySelector(".dn-p"))]));
  });
  document.querySelectorAll("#view .cy-hero").forEach(x => rows.unshift(["Headline", textOf(x.querySelector(".cy-l")), textOf(x.querySelector(".cy-n")), ""]));
  return { columns: ["Section", "Measure", "Value", "Share"], rows };
}

async function postDownload(path, body) {
  const res = await fetch("/api/v1" + path, { method: "POST", body: JSON.stringify(body),
    headers: { "Content-Type": "application/json", "X-Requested-With": "patch01-dashboard", ...authHeaders() } });
  if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
  if (!res.ok) { const d = await res.json().catch(() => ({})); throw new ApiError(res.status, d.detail || res.statusText); }
  const cd = res.headers.get("Content-Disposition") || "";
  const m = /filename="([A-Za-z0-9._-]+)"/.exec(cd);
  const url = URL.createObjectURL(await res.blob());
  const a = h("a", { href: url, download: m ? m[1] : "report" });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return res.headers.get("X-Rows");
}

async function runExport(fmt, msg, selectedOnly) {
  let spec = selectedOnly ? selectedSpec() : pageExport ? await pageExport() : null;
  if (selectedOnly) {
    if (!spec || !spec.rows.length) { msg.textContent = "Tick the rows to export first."; return; }
    spec = Object.assign({}, spec, { title: spec.title + " (" + spec.rows.length + " selected)", filter: "selected rows" });
  }
  if (!spec) {
    const t = tableFromPage() || donutsFromPage();
    if (!t || !t.rows.length) { msg.textContent = "Nothing on this page to export."; return; }
    spec = Object.assign({ title: pageTitle(), filter: pageFilterText() }, t);
  }
  msg.textContent = "Preparing the " + fmt.toUpperCase();
  try {
    const n = spec.server
      ? await downloadFile(spec.server + (spec.server.includes("?") ? "&" : "?") + "format=" + fmt, "report." + fmt)
      : await postDownload("/export/table", { title: spec.title, filter: spec.filter || "", columns: spec.columns,
          rows: spec.rows.map(r => r.map(v => v === undefined ? null : v)), format: fmt });
    msg.textContent = "Downloaded " + fmt.toUpperCase() + " (" + n + (n === "1" ? " row)" : " rows)");
    setTimeout(() => { if (msg.textContent.startsWith("Downloaded")) msg.textContent = ""; }, 6000);
  } catch (err) { msg.textContent = "Export failed: " + (err.message || err.status); }
}

/* Reports the server can build (and mail) for each page */
const ROUTE_REPORTS = { hosts: ["servers"], "installed-patches": ["installed_patches"], "patch-reports": ["patch_jobs", "patch_groups", "patch_summary", "patch_details"], agents: ["servers"], impact: ["impact"], vulns: ["advisories"],
  advisories: ["advisories"], antivirus: ["av_threats", "av_health", "av_agents", "av_unprotected"], activity: ["activity"],
  "assets-coverage": ["asset_gaps"] };
let pageMailParams = {};
let pageMailFirst = null;
function setMailParams(p, first) { pageMailParams = p || {}; pageMailFirst = first || null; }
function routeReports() {
  const first = location.hash.replace(/^#\/?/, "").split(/[/?]/)[0] || "";
  const list = (ROUTE_REPORTS[first] || []).slice();
  if (pageMailFirst && list.includes(pageMailFirst)) list.sort((a, b) => (b === pageMailFirst) - (a === pageMailFirst));
  return list;
}

/* E-mail a report the server builds now (never the page's own rows), to the configured recipients */
/* The table a page shows (or its selected rows), for e-mail: {title, columns, rows, filter} */
async function tableSpecForMail(selectedOnly) {
  if (selectedOnly) { const s = selectedSpec(); return s && s.rows.length ? Object.assign({}, s, { filter: "selected rows" }) : null; }
  const spec = pageExport ? await pageExport() : null;
  if (spec && !spec.server && spec.rows) return spec;
  const t = tableFromPage();
  return t && t.rows.length ? Object.assign({ title: pageTitle(), filter: pageFilterText() }, t) : null;
}

async function mailPanel(panel, msg, close) {
  panel.replaceChildren(h("p", { class: "muted small" }, "Loading…"));
  let o;
  try { o = await api("/reports/email-options"); }
  catch (err) { panel.replaceChildren(h("p", { class: "hd-failed small" }, err.message)); return; }
  if (!o.mail_ready) { panel.replaceChildren(h("p", { class: "small" }, "Mail is not turned on. ",
    can("admin") ? h("a", { href: "#/mail" }, "Set it up in Admin › Mail") : "Ask an admin to set it up.")); return; }
  if (!(o.recipients || []).length) { panel.replaceChildren(h("p", { class: "small" }, "No recipients yet. ",
    can("admin") ? h("a", { href: "#/mail" }, "Add them in Admin › Mail") : "Ask an admin to add them.")); return; }
  // What can be sent: the server-built reports for this page, the table as shown, and the selected rows
  const reps = routeReports().map(k => (o.reports || []).find(r => r.key === k)).filter(Boolean);
  const sel = selectedSpec();
  const what = h("select", { "aria-label": "What to send" },
    reps.map(r => h("option", { value: "r:" + r.key }, r.title + " (built by the server)")),
    h("option", { value: "t:all" }, "This table, as shown"),
    sel && sel.rows.length ? h("option", { value: "t:sel" }, "Selected rows only (" + sel.rows.length + ")") : null);
  if (sel && sel.rows.length) what.value = "t:sel";
  const fmt = h("select", { "aria-label": "Format" }, h("option", { value: "pdf" }, "PDF"), h("option", { value: "csv" }, "CSV"));
  const boxes = o.recipients.map(r => h("label", { class: "cm-check" }, h("input", { type: "checkbox", value: r.address }),
    " " + (r.name ? r.name + " <" + r.address + ">" : r.address)));
  const note = h("p", { class: "muted small", role: "status" });
  const hint = h("p", { class: "muted small" });
  const setHint = () => { hint.textContent = what.value.startsWith("r:")
    ? "Built now on the server from its own data, in the branded mail, with the file attached."
    : "The rows as this page shows them, marked as sent by you, in the branded mail with the file attached."; };
  what.addEventListener("change", setHint); setHint();
  const send = h("button", { type: "button", class: "btn", on: { click: async () => {
    const to = boxes.map(b => b.querySelector("input")).filter(i => i.checked).map(i => i.value);
    if (!to.length) { note.textContent = "Tick at least one recipient."; return; }
    send.disabled = true; note.textContent = "Building the report…";
    try {
      let r;
      if (what.value.startsWith("r:")) {
        r = await apiPost("/reports/email", { report: what.value.slice(2), params: pageMailParams, format: fmt.value, recipients: to });
      } else {
        const spec = await tableSpecForMail(what.value === "t:sel");
        if (!spec) { note.textContent = what.value === "t:sel" ? "Tick the rows to send first." : "Nothing on this page to send."; send.disabled = false; return; }
        r = await apiPost("/reports/email-table", { title: spec.title, filter: spec.filter || "", columns: spec.columns,
          rows: spec.rows.slice(0, 5000).map(x => x.map(v => v === undefined ? null : v)), format: fmt.value, recipients: to, page: pageTitle() });
      }
      close(); msg.textContent = r.message || "Queued.";
      setTimeout(() => { if (msg.textContent === r.message) msg.textContent = ""; }, 8000);
    } catch (err) { note.textContent = err.message; send.disabled = false; }
  } } }, "Send now");
  const sched = o.can_schedule && reps.length ? h("a", { class: "btn btn-quiet", on: { click: e => {
    e.preventDefault();
    if (!what.value.startsWith("r:")) { note.textContent = "Only the server-built reports can be scheduled."; return; }
    close();
    location.hash = "#/report-schedules?new=" + encodeURIComponent(what.value.slice(2))
      + "&p=" + encodeURIComponent(JSON.stringify(pageMailParams || {}));
  } }, href: "#/report-schedules" }, "Schedule…") : null;
  panel.replaceChildren(
    h("p", { class: "small" }, h("strong", null, "E-mail")),
    h("div", { class: "exp-row" }, what, fmt), hint,
    h("fieldset", { class: "exp-to" }, h("legend", null, "To (recipients set in Admin › Mail)"), boxes),
    h("div", { class: "exp-row" }, send, sched), note);
}

function exportControl() {
  const msg = h("span", { class: "exp-msg", role: "status" });
  const menu = h("div", { class: "exp-menu", role: "menu", hidden: true });
  const panel = h("div", { class: "exp-mail", hidden: true, role: "dialog", "aria-label": "E-mail" });
  const btn = h("button", { type: "button", class: "btn btn-quiet exp-btn", "aria-haspopup": "menu", "aria-expanded": "false" },
    "Export ▾");
  const close = () => { menu.hidden = true; panel.hidden = true; btn.setAttribute("aria-expanded", "false"); };
  const item = (fmt, title, sub, selected) => h("button", { type: "button", role: "menuitem", class: selected ? "exp-sel" : null,
    on: { click: () => { close(); runExport(fmt, msg, selected); } } }, h("strong", null, title), h("span", null, sub));
  const selPdf = item("pdf", "PDF, selected rows", "", true), selCsv = item("csv", "CSV, selected rows", "", true);
  menu.append(item("pdf", "PDF report", "With the logo, for reading and sharing"),
              item("csv", "CSV", "For Excel; heading with organisation, date and time"), selPdf, selCsv);
  const mailItem = h("button", { type: "button", role: "menuitem", class: "exp-mail-item", on: { click: e => {
    e.stopPropagation(); menu.hidden = true; panel.hidden = false; mailPanel(panel, msg, close); } } },
    h("strong", null, "E-mail…"), h("span", null, "This table, selected rows, or a report the server builds"));
  menu.append(mailItem);
  btn.addEventListener("click", e => {
    e.stopPropagation();
    const sel = selectedSpec(), n = sel ? sel.rows.length : 0;
    [selPdf, selCsv].forEach(x => { x.hidden = !n; x.querySelector("span").textContent = n + " row" + (n === 1 ? "" : "s") + " ticked on this page"; });
    mailItem.hidden = !can("operator");
    const open = menu.hidden && panel.hidden;
    menu.hidden = !open; panel.hidden = true; btn.setAttribute("aria-expanded", String(open));
    if (open) menu.querySelector("button:not([hidden])").focus();
  });
  const wrap = h("span", { class: "exp" }, btn, menu, panel, msg);
  wrap._close = close;
  wrap.addEventListener("keydown", e => { if (e.key === "Escape") { close(); btn.focus(); } });
  return wrap;
}
// One listener for every Export control (pages redraw their control often): a click outside closes it
document.addEventListener("click", e => {
  document.querySelectorAll(".exp").forEach(w => { if (w._close && !w.contains(e.target)) w._close(); });
});

/* Called after every page renders: one Export button in the page heading. */
function attachExport(first, second) {
  if (NO_EXPORT.has(first) || second === "new") return;
  const head = document.querySelector("#view .page-head");
  // A page with its own formal report (Hardening: PDF or Word, CIS layout) keeps that one Export button.
  if (!head || head.querySelector(".exp, [data-own-export]")) return;
  head.append(exportControl());
}

/* ---- Antivirus: Trend Micro Apex Central, read-only ------------------------------ */

const AV_ICONS = {
  // stacked servers: product servers under Apex Central
  products: [["rect", { x: "4", y: "4", width: "16", height: "6", rx: "1" }], ["rect", { x: "4", y: "14", width: "16", height: "6", rx: "1" }],
             ["path", { d: "M8 7h.01M8 17h.01" }]],
  // shield: agents
  agents: [["path", { d: "M12 3l7 3v5c0 4.4-3 8.3-7 9.5C8 19.3 5 15.4 5 11V6z" }]],
  // link: matched to the inventory
  matched: [["path", { d: "M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1" }], ["path", { d: "M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1" }]],
  // question mark: not in the inventory
  unmatched: [["circle", { cx: "12", cy: "12", r: "8.5" }], ["path", { d: "M9.6 9.5a2.5 2.5 0 1 1 3.4 2.3c-.7.3-1 .8-1 1.5v.4" }], ["path", { d: "M12 16.8v.2" }]],
  // shield with a slash: no antivirus
  unprotected: [["path", { d: "M12 3l7 3v5c0 4.4-3 8.3-7 9.5C8 19.3 5 15.4 5 11V6z" }], ["path", { d: "M5 4l14 16" }]],
  // clock: outdated definitions
  outdated: [["circle", { cx: "12", cy: "12", r: "8.5" }], ["path", { d: "M12 7.5V12l3 2" }]],
  // bug: detections
  detections: [["rect", { x: "8", y: "8", width: "8", height: "11", rx: "4" }], ["path", { d: "M12 8V5.5M9.5 6.5l-1.5-2M14.5 6.5l1.5-2M8 12H4.5M19.5 12H16M8 16l-3 2M16 16l3 2" }]],
  // locked file: ransomware
  ransomware: [["path", { d: "M7 3.5h7l4 4V20a.5.5 0 0 1-.5.5h-10A.5.5 0 0 1 7 20z" }], ["rect", { x: "9.5", y: "13", width: "5", height: "4.5", rx: ".8" }], ["path", { d: "M10.5 13v-1.2a1.5 1.5 0 0 1 3 0V13" }]],
  // padlock: isolated
  isolated: [["rect", { x: "5.5", y: "10.5", width: "13", height: "9", rx: "1.5" }], ["path", { d: "M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" }]],
};
function avIcon(k) {
  return svg("svg", { viewBox: "0 0 24 24", class: "av-ico", "aria-hidden": "true", focusable: "false" },
    (AV_ICONS[k] || []).map(([tag, attrs]) => svg(tag, attrs)));
}
const LOG_WORD = { pattern_updated_status: "pattern status", pattern_update_status: "pattern status", officescan_virus: "virus/malware",
  spyware: "spyware", behavior_monitoring: "behaviour", predictive_machine_learning: "machine learning", c_and_c_callback: "C&C", web_security: "web" };
const AV_CAT = { malware: "Virus/malware", ransomware: "Ransomware", spyware: "Spyware/grayware", behaviour: "Behaviour monitoring",
  machine_learning: "Machine learning", c2: "C&C callback", web: "Web threat" };
const AV_ISO = s => { const v = String(s || "").toLowerCase(); return !v || v === "normal" || v === "none" ? "" : v.replace(/_/g, " "); };

async function renderAntivirus(params) {
  setNav("antivirus");
  const d = await api("/antivirus");
  const c = d.counts || {};
  let tab = ["unprotected", "detections", "products"].includes(params.get("tab")) ? params.get("tab") : "agents";
  let q = "", pg = 1, cons = "", prod = "", isoOnly = params.get("iso") === "1", match = params.get("match") || "";
  let outOnly = false, dcat = params.get("type") || "", dDays = 1, dBad = false;
  const isOut = a => a.definitions && (a.definitions.versions_old || 0) >= 2;
  const open = new Set();
  const box = h("div");
  const tile = (k, n, label, onClick, pressed) => h("button", { type: "button", class: "av-tile av-" + k, "aria-pressed": String(!!pressed),
      on: { click: onClick } }, avIcon(k), h("span", { class: "av-n" }, String(n || 0)), h("span", { class: "av-l" }, label));
  const tiles = h("div", { class: "av-tiles", role: "group", "aria-label": "Summary" });
  const search = h("input", { type: "search", placeholder: "Search name, address, domain", "aria-label": "Search" });
  const consSel = h("select", { "aria-label": "Console" }, h("option", { value: "" }, "Console: all"),
    (d.consoles || []).map(x => h("option", { value: x.name }, x.name)));
  const prods = [...new Set((d.agents || []).map(a => a.product_name))].sort();
  const prodSel = h("select", { "aria-label": "Product" }, h("option", { value: "" }, "Product: all"), prods.map(p => h("option", { value: p }, p)));
  const catSel = h("select", { "aria-label": "Type" }, h("option", { value: "" }, "Type: all"),
    Object.entries(AV_CAT).map(([k, v]) => h("option", { value: k }, v)));
  const daySel = h("select", { "aria-label": "Period" }, [[1, "Last 24 hours"], [7, "Last 7 days"]].map(([k, v]) => h("option", { value: k }, v)));
  const badBox = h("input", { type: "checkbox" });
  const dBar = h("span", { class: "av-dbar" }, catSel, daySel, h("label", { class: "cm-check" }, badBox, " Not cleaned only"));
  catSel.addEventListener("change", () => { dcat = catSel.value; pg = 1; draw(); });
  daySel.addEventListener("change", () => { dDays = Number(daySel.value); pg = 1; draw(); });
  badBox.addEventListener("change", () => { dBad = badBox.checked; pg = 1; draw(); });
  const bar = h("div", { class: "srv-bar" }, search, consSel, prodSel, dBar);

  const status = h("div", { class: "av-cons" }, (d.consoles || []).length ? (d.consoles || []).map(x =>
    h("span", { class: "av-con " + (x.last_sync_ok === false ? "bad" : x.last_sync_ok ? "ok" : "wait"),
                title: x.last_sync_msg || "" },
      h("span", { class: "light " + (x.last_sync_ok === false ? "light-off" : x.last_sync_ok ? "light-on" : "light-unk"), "aria-hidden": "true" }),
      x.name + " · " + (x.last_sync_at ? "read " + timeAgo(x.last_sync_at) : "not read yet")
        + (x.last_sync_ok === false ? " · problem" : x.agents !== null && x.agents !== undefined ? " · " + x.agents + " agents" : "")
        + (x.enabled ? "" : " · off")))
    : h("p", { class: "muted" }, can("admin") ? h("span", null, "No antivirus console yet. Add one in ", h("a", { href: "#/av-consoles" }, "Admin › Antivirus"), ".")
                                              : "No antivirus console has been added yet."));

  const draw = () => {
    const reset = () => { match = ""; isoOnly = false; outOnly = false; dBad = false; pg = 1; };   // tiles show all, so their counts match
    tiles.replaceChildren(
      tile("agents", c.agents, "Agents", () => { tab = "agents"; reset(); draw(); }, tab === "agents" && !match && !isoOnly && !outOnly),
      tile("outdated", c.outdated, "Outdated definitions", () => { tab = "agents"; reset(); outOnly = true; draw(); }, tab === "agents" && outOnly),
      tile("detections", c.detections_24h, "Detections, 24 h", () => { tab = "detections"; reset(); dcat = ""; dDays = 1; draw(); }, tab === "detections" && dcat !== "ransomware"),
      tile("ransomware", c.ransomware_24h, "Ransomware, 24 h", () => { tab = "detections"; reset(); dcat = "ransomware"; dDays = 1; draw(); }, tab === "detections" && dcat === "ransomware"),
      tile("unprotected", c.unprotected, "No antivirus", () => { tab = "unprotected"; reset(); draw(); }, tab === "unprotected"),
      tile("isolated", c.isolated, "Isolated", () => { tab = "agents"; reset(); isoOnly = true; draw(); }, tab === "agents" && isoOnly),
      tile("unmatched", c.unmatched, "Not in inventory", () => { tab = "agents"; reset(); match = "no"; draw(); }, tab === "agents" && match === "no"),
      tile("products", (d.products || []).filter(p => p.selected).length, "Product servers synced", () => { tab = "products"; reset(); draw(); }, tab === "products"));
    consSel.hidden = prodSel.hidden = tab !== "agents";
    dBar.hidden = tab !== "detections";
    const needle = q.toLowerCase();
    if (tab !== "detections") setMailParams({});
    if (tab === "agents") {
      const items = (d.agents || []).filter(a => (!cons || a.console === cons) && (!prod || a.product_name === prod)
        && (!isoOnly || AV_ISO(a.isolation_status)) && (match !== "yes" || a.asset) && (match !== "no" || !a.asset) && (!outOnly || isOut(a))
        && (!needle || [a.host_name, a.ad_domain, (a.ip_addresses || []).join(" "), a.asset && a.asset.os].join(" ").toLowerCase().includes(needle)));
      setPageExport(() => ({ title: "Antivirus agents", filter: pageFilterText(),
        columns: ["Name", "Address", "Domain", "Product", "Console", "Isolation", "In inventory", "Operating system", "Known from", "Last reported", "MAC"],
        rows: items.map(a => [a.host_name, (a.ip_addresses || []).join(" "), a.ad_domain || "", a.product_name, a.console,
          AV_ISO(a.isolation_status) || "normal", a.asset ? "yes" : "no", a.asset ? a.asset.os || "" : "",
          a.asset ? (a.asset.sources || []).join(", ") : "", a.not_reported ? "no longer listed, last " + fmtDateTime(a.last_seen) : fmtDateTime(a.last_seen),
          (a.mac_addresses || []).join(" ")]) }));
      const pages = Math.max(1, Math.ceil(items.length / PAGE_SIZE)); pg = Math.min(pg, pages);
      box.replaceChildren(items.length ? plusTable([
        { label: "Name", cell: a => h("strong", null, a.host_name || "–") },
        { label: "Address", cell: a => (a.ip_addresses || []).slice(0, 2).join(", ") || "–" },
        { label: "Product", cell: a => a.product_name },
        { label: "Console", cell: a => a.console },
        { label: "Definitions", cell: a => !a.definitions ? (a.pattern_version || h("span", { class: "muted" }, "–"))
            : (a.definitions.versions_old || 0) === 0 ? h("span", { title: a.definitions.pattern + " " + (a.definitions.version || "") }, "up to date")
            : h("span", { class: (a.definitions.versions_old >= 2 ? "sv sv-crit" : "sv"), title: a.definitions.pattern + " " + (a.definitions.version || "") },
                (a.definitions.versions_old >= 7 ? "7+" : a.definitions.versions_old) + " versions old") },
        { label: "Isolation", cell: a => AV_ISO(a.isolation_status) ? h("span", { class: "sv sv-crit" }, AV_ISO(a.isolation_status)) : "normal" },
        { label: "In inventory", cell: a => a.asset ? (a.asset.os || "yes") : h("span", { class: "muted" }, "not found") },
        { label: "Last reported", sort: a => a.last_seen ? Date.parse(a.last_seen) : null, cell: a => a.not_reported ? h("span", { class: "hd-failed", title: "The console's last read did not list it" }, "not listed, " + timeAgo(a.last_seen)) : timeAgo(a.last_seen) },
      ], items.slice((pg - 1) * PAGE_SIZE, pg * PAGE_SIZE), a => h("div", { class: "srv-det" }, h("dl", { class: "srv-kv" },
        ...[["Domain", a.ad_domain], ["Folder in Apex Central", a.folder_path], ["All addresses", (a.ip_addresses || []).join(", ")],
            ["MAC", (a.mac_addresses || []).join(", ")], ["Managing server", a.managing_server_id],
            ["Read from", a.via_product ? "Deep Security Manager " + a.via_product + " (directly)" : null],
            ["Operating system", a.os], ["Product code", a.product],
            ["Capabilities", (a.capabilities || []).join(", ")], ["First seen", fmtDateTime(a.first_seen)],
            ["In our inventory", a.asset ? a.asset.name + (a.asset.os ? " · " + a.asset.os : "") + " · known from " + (a.asset.sources || []).join(", ")
                                       : "No machine in the inventory has this name or address"]]
          .filter(([, v]) => v).map(([k, v]) => h("div", { class: "kv" }, h("dt", null, k), h("dd", null, v))))),
        { open, key: a => a.console + "/" + a.entity_id, rowClass: a => AV_ISO(a.isolation_status) ? "vu-kev" : "",
          paged: { key: "av-agents", items, page: pg, size: PAGE_SIZE, redraw: () => draw() } })
        : h("div", { class: "empty" }, h("p", null, (d.agents || []).length ? "No agent matches." : "No agents read yet.")),
        pager(pg, pages, items.length, PAGE_SIZE, n => { pg = n; draw(); }));
    } else if (tab === "detections") {
      catSel.value = dcat; daySel.value = String(dDays); badBox.checked = dBad;
      const since = Date.now() - dDays * 86400000;
      const items = (d.detections || []).filter(x => (!dcat || x.category === dcat) && (!dBad || x.unresolved)
        && x.occurred_at && new Date(x.occurred_at).getTime() >= since
        && (!needle || [x.host_name, x.ip, x.threat, x.user_name].join(" ").toLowerCase().includes(needle)));
      setMailParams({ days: dDays }, "av_threats");
      setPageExport(() => ({ title: "Antivirus detections", filter: pageFilterText(),
        columns: ["When", "Machine", "Address", "User", "Threat", "Type", "Action", "Result", "Not cleaned", "File", "SHA-1", "Console"],
        rows: items.map(x => [fmtDateTime(x.occurred_at), x.host_name || "", x.ip || "", x.user_name || "", x.threat || "",
          AV_CAT[x.category] || x.category, x.action || "", x.result || "", x.unresolved ? "yes" : "", x.file_path || "", x.sha1 || "", x.console]) }));
      const pages = Math.max(1, Math.ceil(items.length / PAGE_SIZE)); pg = Math.min(pg, pages);
      const sm = d.summary;
      box.replaceChildren(
        sm ? h("section", { class: "ai-card", "aria-label": "Threat summary" },
          h("div", { class: "ai-card-head" }, h("span", { class: "ai-badge ai-small" }, h("span", { class: "ai-dot", "aria-hidden": "true" }),
              sm.source === "ai" ? "AI-01 threat summary" : "Threat summary"),
            h("span", { class: "muted small" }, timeAgo(sm.created_at) + " · last " + (sm.days === 1 ? "24 hours" : sm.days + " days")
              + (sm.source === "ai" ? "" : " · figures only, AI-01 not used"))),
          sm.text.split(/\n\s*\n/).map(p => h("p", null, p)))
          : h("p", { class: "muted small" }, "The daily threat summary appears here after its first run (Admin › Scheduled reports › Send now)."),
        items.length ? plusTable([
          { label: "When", sort: x => x.occurred_at ? Date.parse(x.occurred_at) : null, cell: x => fmtDateTime(x.occurred_at) },
          { label: "Machine", cell: x => h("strong", null, x.host_name || "–") },
          { label: "Threat", cell: x => h("span", { class: "vu-title" }, x.threat || "") },
          { label: "Type", cell: x => x.category === "ransomware" ? h("span", { class: "sv sv-crit" }, "Ransomware") : (AV_CAT[x.category] || x.category) },
          { label: "Action", cell: x => x.action || "" },
          { label: "Cleaned", cell: x => x.unresolved ? h("span", { class: "hd-failed" }, "no") : "yes" },
        ], items.slice((pg - 1) * PAGE_SIZE, pg * PAGE_SIZE), x => h("div", { class: "srv-det" }, h("dl", { class: "srv-kv" },
          ...[["Address", x.ip], ["User", x.user_name], ["Result", x.result], ["File", x.file_path], ["SHA-1", x.sha1],
              ["Detections", x.count > 1 ? String(x.count) : null], ["Console", x.console]]
            .filter(([, v]) => v).map(([k, v]) => h("div", { class: "kv" }, h("dt", null, k), h("dd", null, v))))),
          { open, key: x => x.console + "/" + x.occurred_at + "/" + x.host_name + "/" + x.threat,
            rowClass: x => x.category === "ransomware" || x.unresolved ? "vu-kev" : "",
            paged: { key: "av-detections", items, page: pg, size: PAGE_SIZE, redraw: () => draw() } })
          : h("div", { class: "empty" }, h("p", null, (d.detections || []).length ? "No detection matches." : "No detection read yet. Detections come from Apex Central's logs, read every hour.")),
        pager(pg, pages, items.length, PAGE_SIZE, n => { pg = n; draw(); }));
    } else if (tab === "products") {
      const items = (d.products || []).filter(p => !needle || [p.host_name, (p.ip_addresses || []).join(" "), p.kind_label, p.product_label, p.console]
        .join(" ").toLowerCase().includes(needle));
      setPageExport(() => ({ title: "Antivirus product servers", filter: pageFilterText(),
        columns: ["Server", "Address", "Type", "Product", "Console", "Synced", "Agents", "Read directly", "Last read"],
        rows: items.map(p => [p.host_name || "", (p.ip_addresses || []).join(" "), p.kind_label, p.product_label, p.console,
          p.selected ? "yes" : p.selected === false ? "no" : "not chosen", String(p.dsm_agents || p.apex_agents || 0),
          p.dsm_enabled && p.selected ? "yes" : "no", p.dsm_enabled && p.selected ? fmtDateTime(p.last_sync_at) : ""]) }));
      const pages = Math.max(1, Math.ceil(items.length / PAGE_SIZE)); pg = Math.min(pg, pages);
      box.replaceChildren(
        h("p", { class: "muted small" }, "The servers each Apex Central manages: Apex One servers, Deep Security Managers and email security. "
          + "Admins choose which are synced in ", can("admin") ? h("a", { href: "#/av-consoles" }, "Admin › Antivirus") : "Admin › Antivirus",
          "; a Deep Security Manager can also be read directly with its own key."),
        items.length ? h("div", { class: "table-wrap" }, table([
          { label: "Server", cell: p => [h("strong", null, p.host_name || "–"), h("div", { class: "muted small" }, (p.ip_addresses || []).join(", "))] },
          { label: "Type", cell: p => [p.kind_label, h("div", { class: "muted small" }, p.product_label)] },
          { label: "Console", cell: p => p.console },
          { label: "Synced", cell: p => p.selected ? "yes" : p.selected === false ? h("span", { class: "muted" }, "no") : h("span", { class: "muted" }, "not chosen") },
          { label: "Agents", num: true, sort: p => p.dsm_agents || p.apex_agents || 0, cell: p => String(p.dsm_agents || p.apex_agents || 0) },
          { label: "Read", sort: p => p.last_sync_at ? Date.parse(p.last_sync_at) : null, cell: p => !(p.dsm_enabled && p.selected) ? h("span", { class: "muted small" }, "through Apex Central")
              : [h("span", { class: "light " + (p.last_sync_ok ? "light-on" : p.last_sync_ok === false ? "light-off" : "light-unk"), "aria-hidden": "true" }), " ",
                 "directly, " + (p.last_sync_at ? timeAgo(p.last_sync_at) : "waiting"),
                 p.last_sync_ok === false ? h("div", { class: "hd-failed small" }, p.last_sync_msg || "") : null] },
        ], null, { paged: { key: "av-products", items, page: pg, size: PAGE_SIZE, redraw: () => draw() } }))
          : h("div", { class: "empty" }, h("p", null, "No product server listed yet. An admin can discover them in Admin › Antivirus.")),
        pager(pg, pages, items.length, PAGE_SIZE, n => { pg = n; draw(); }));
    } else {
      const items = (d.unprotected || []).filter(m => !needle || [m.name, (m.ips || []).join(" "), m.os].join(" ").toLowerCase().includes(needle));
      setPageExport(() => ({ title: "Machines with no antivirus agent", filter: pageFilterText(),
        columns: ["Name", "Address", "Operating system", "Known from"],
        rows: items.map(m => [m.name, (m.ips || []).join(" "), m.os || "", (m.sources || []).join(", ")]) }));
      const pages = Math.max(1, Math.ceil(items.length / PAGE_SIZE)); pg = Math.min(pg, pages);
      box.replaceChildren(
        h("p", { class: "muted small" }, "Machines in the inventory (agents, WSUS, vCenter guests) that no antivirus console lists, "
          + "matched by address, then full name, then short name."),
        items.length ? h("div", { class: "table-wrap" }, table([
          { label: "Name", cell: m => h("strong", null, m.name) },
          { label: "Address", cell: m => (m.ips || []).join(", ") || "–" },
          { label: "Operating system", cell: m => m.os || h("span", { class: "muted" }, "unknown") },
          { label: "Known from", cell: m => (m.sources || []).join(", ") },
        ], null, { paged: { key: "av-unprotected", items, page: pg, size: PAGE_SIZE, redraw: () => draw() } })) : h("div", { class: "empty" }, h("p", null, (d.consoles || []).length ? "Every machine has an antivirus agent." : "Add a console first.")),
        pager(pg, pages, items.length, PAGE_SIZE, n => { pg = n; draw(); }));
    }
  };
  let t = null;
  search.addEventListener("input", () => { clearTimeout(t); t = setTimeout(() => { q = search.value.trim(); pg = 1; draw(); }, 250); });
  consSel.addEventListener("change", () => { cons = consSel.value; pg = 1; draw(); });
  prodSel.addEventListener("change", () => { prod = prodSel.value; pg = 1; draw(); });
  draw();
  render(h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure av --agents" }, "Antivirus")),
    h("p", { class: "muted small" }, "Security agents reported by Trend Micro Apex Central, read every hour, matched to the inventory."),
    status, tiles, bar, box);
}

/* Admin › Antivirus: consoles, their keys, a connection test */
async function renderAvConsoles() {
  setNav("admin");
  if (!can("admin")) return render(h("div", { class: "empty" }, h("p", null, "Antivirus settings need the admin role.")));
  const page = h("div", { class: "av-admin" });
  render(page);
  drawAvConsoles(page, await api("/admin/antivirus"));
  adminTabs("av-consoles");
}

function drawAvConsoles(page, d, editing) {
  const msg = h("p", { class: "cm-meta", role: "status" });
  const result = h("div", { class: "av-test", role: "status", "aria-live": "polite" });
  const ed = editing || null;
  const name = h("input", { type: "text", maxlength: "60", required: true, value: ed ? ed.name : "", placeholder: "Apex Central, head office" });
  const url = h("input", { type: "url", maxlength: "300", required: true, value: ed ? ed.url : "", placeholder: "https://apex-central.example.local",
                           autocomplete: "off", spellcheck: "false" });
  const appId = h("input", { type: "text", maxlength: "80", required: !ed, autocomplete: "off", spellcheck: "false",
                             placeholder: ed ? "saved (" + ed.app_id + "): leave blank to keep" : "Application ID" });
  const key = h("input", { type: "password", maxlength: "200", required: !ed, autocomplete: "new-password", spellcheck: "false",
                           placeholder: ed ? "saved: leave blank to keep" : "API key" });
  const ca = h("textarea", { rows: "5", maxlength: "20000", spellcheck: "false",
                             placeholder: "-----BEGIN CERTIFICATE-----\n(only when the console's certificate is from your own CA)" });
  const caRemove = ed && ed.has_ca ? h("label", { class: "cm-check" }, h("input", { type: "checkbox" }), " Remove the saved CA certificate") : null;
  const proxy = h("input", { type: "checkbox", checked: ed ? !!ed.use_proxy : false });
  // Self-signed console: fetch its certificate, compare the fingerprint on the server, trust exactly that one
  let pinPending = null;
  const certBox = h("div", { class: "av-cert", "aria-live": "polite" });
  const unpin = ed && ed.pin_sha256 ? h("label", { class: "cm-check" }, h("input", { type: "checkbox" }), " Stop trusting this certificate") : null;
  const pinnedNow = ed && ed.pin_sha256 ? h("div", { class: "av-res ok" }, h("strong", null, "Trusted certificate"),
    h("p", { class: "small" }, (ed.pin_subject || "") + (ed.pin_not_after ? " · valid until " + fmtDate(ed.pin_not_after) : "")
      + (ed.pinned_by ? " · trusted by " + ed.pinned_by + " " + timeAgo(ed.pinned_at) : "")),
    h("p", { class: "mono small av-fp" }, "SHA-256 " + ed.pin_sha256.toUpperCase().match(/../g).join(":")), unpin) : null;
  const getCert = h("button", { type: "button", class: "btn-quiet", on: { click: async () => {
    getCert.disabled = true; pinPending = null;
    certBox.replaceChildren(h("p", { class: "muted small" }, "Reading the certificate (handshake only, nothing is sent)…"));
    try {
      const b = { url: url.value.trim(), use_proxy: proxy.checked }; if (ed) b.id = ed.id;
      const c = await apiPost("/admin/antivirus/certificate", b);
      const ok = h("input", { type: "checkbox" });
      ok.addEventListener("change", () => { pinPending = ok.checked ? c.sha256 : null; });
      certBox.replaceChildren(h("div", { class: "av-res " + (c.expired ? "bad" : "ok") },
        h("strong", null, c.self_signed ? "Self-signed certificate" : "Certificate"),
        h("dl", { class: "srv-kv" }, ...[["Issued to", c.subject], ["Issued by", c.issuer],
            ["Names it covers", (c.names || []).join(", ") || "none listed (old-style certificate)"],
            ["Matches this URL", c.matches_host ? "yes" : "no: normal verification would fail, pinning works"],
            ["Valid", fmtDate(c.not_before) + " to " + fmtDate(c.not_after) + (c.expired ? " (EXPIRED)" : c.not_yet_valid ? " (not yet valid)" : "")]]
          .map(([k, v]) => h("div", { class: "kv" }, h("dt", null, k), h("dd", null, v)))),
        h("p", { class: "small" }, "SHA-256 fingerprint"), h("p", { class: "mono small av-fp" }, c.sha256_text),
        h("p", { class: "small" }, "SHA-1 (what Windows calls the Thumbprint)"), h("p", { class: "mono small av-fp" }, c.sha1_text),
        h("p", { class: "muted small" }, "Check it on the Apex Central server before trusting it: IIS Manager › Server Certificates › "
          + "open the certificate › Details › Thumbprint, or in PowerShell: Get-ChildItem Cert:\\LocalMachine\\My | Select Subject, Thumbprint. "
          + "It must be the same value."),
        c.expired ? h("p", { class: "hd-failed small" }, "This certificate has expired. It can still be trusted by its fingerprint, "
          + "but plan to renew it on the Apex Central server.") : null,
        c.pinned_now ? h("p", { class: "small" }, "This is the certificate already trusted for this console.") :
          h("label", { class: "cm-check" }, ok, " I have compared the fingerprint with the Apex Central server: trust exactly this certificate")));
    } catch (err) { certBox.replaceChildren(h("p", { class: "hd-failed small" }, err.message)); }
    getCert.disabled = false;
  } } }, "Get certificate");
  const enabled = h("input", { type: "checkbox", checked: ed ? !!ed.enabled : true });
  const body = () => {
    const b = { name: name.value.trim(), url: url.value.trim(), use_proxy: proxy.checked, enabled: enabled.checked };
    if (appId.value.trim()) b.app_id = appId.value.trim();
    if (key.value) b.api_key = key.value;
    if (ca.value.trim()) b.ca_pem = ca.value.trim();
    else if (caRemove && caRemove.querySelector("input").checked) b.ca_pem = "";
    if (pinPending) b.pin_sha256 = pinPending;
    else if (unpin && unpin.querySelector("input").checked) b.pin_sha256 = "";
    return b;
  };
  const showResult = r => result.replaceChildren(h("div", { class: "av-res " + (r.ok ? "ok" : "bad") },
    h("strong", null, r.ok ? "Connected" : "Not connected"), h("p", null, r.message),
    r.ok && (r.products || []).length ? h("p", { class: "small" }, "Products: " + r.products.map(([p, n]) => p + " (" + n + ")").join(", ")
      + (r.isolated ? " · " + r.isolated + " isolated" : "")) : null,
    r.ok && (r.sample || []).length ? h("p", { class: "small muted" }, "For example: " + r.sample.join(", ")) : null,
    r.ok && r.health ? h("p", { class: "small" }, "For the daily antivirus mail: definition versions reported for "
      + r.health.definitions + " of " + r.agents + " agents, connection times for " + r.health.connection + ".") : null,
    r.ok && (r.fields || []).length ? h("p", { class: "small muted" }, "Fields this console sends: " + r.fields.join(", ")) : null,
    r.ms ? h("p", { class: "small muted" }, "Answered in " + r.ms + " ms") : null));
  const test = h("button", { type: "button", class: "btn-quiet", on: { click: async () => {
    test.disabled = true; result.replaceChildren(h("p", { class: "muted" }, "Signing in to Apex Central and listing its agents…"));
    try {
      const b = body(); if (ed) b.id = ed.id;
      showResult(await apiPost("/admin/antivirus/test", b));
    } catch (err) { showResult({ ok: false, message: err.message || "Could not test." }); }
    test.disabled = false;
  } } }, "Test connection");
  const form = h("form", { class: "av-form", autocomplete: "off", on: { submit: async e => {
    e.preventDefault();
    try {
      const r = ed ? await apiSend("PUT", "/admin/antivirus/" + ed.id, body()) : await apiPost("/admin/antivirus", body());
      drawAvConsoles(page, r);
    } catch (err) { msg.textContent = err.message || "Could not save."; }
  } } },
    h("h2", null, ed ? "Edit " + ed.name : "Add an Apex Central console"),
    h("div", { class: "av-grid" },
      h("label", null, h("span", null, "Name"), name),
      h("label", null, h("span", null, "Console URL"), url),
      h("label", null, h("span", null, "Application ID"), appId),
      h("label", null, h("span", null, "API key"), key)),
    h("details", { class: "av-more", open: !!(ed && (ed.has_ca || ed.pin_sha256)) }, h("summary", null, "Certificate and network"),
      h("p", { class: "small" }, h("strong", null, "Self-signed certificate on Apex Central? "),
        "Get it, compare its fingerprint with the server, and trust that exact certificate."),
      pinnedNow, h("div", { class: "cm-actions" }, getCert), certBox,
      h("label", null, h("span", null, "Or: the CA certificate (PEM), when the console's certificate comes from your own CA"), ca),
      caRemove,
      h("label", { class: "cm-check" }, proxy, " Reach this console through the web proxy (only for a cloud console)"),
      h("p", { class: "muted small" }, "The certificate is always checked, by its CA or by its exact fingerprint; there is no option to turn that off.")),
    h("label", { class: "cm-check" }, enabled, " Read this console every hour"),
    h("div", { class: "cm-actions" }, test, h("button", { type: "submit" }, ed ? "Save changes" : "Save"),
      ed ? h("button", { type: "button", class: "btn-quiet", on: { click: () => drawAvConsoles(page, d) } }, "Cancel") : null, msg),
    result);

  const rows = d.consoles || [];
  const list = rows.length ? h("div", { class: "table-wrap" }, table([
    { label: "Console", cell: c => [h("strong", null, c.name), h("div", { class: "muted small" }, c.url)] },
    { label: "Application ID", cell: c => h("span", { class: "mono" }, c.app_id) },
    { label: "Certificate", cell: c => c.pin_sha256 ? [h("span", null, "trusted by fingerprint"),
        h("div", { class: "muted small", title: "SHA-256 " + c.pin_sha256 }, (c.pin_subject || "") + (c.pin_not_after ? " · until " + fmtDate(c.pin_not_after) : ""))]
        : c.has_ca ? "your CA" : "public CA" },
    { label: "Last read", cell: c => c.last_sync_at ? [h("span", { class: "light " + (c.last_sync_ok ? "light-on" : "light-off"), "aria-hidden": "true" }), " ",
        timeAgo(c.last_sync_at), h("div", { class: c.last_sync_ok ? "muted small" : "hd-failed small" }, c.last_sync_msg || "")] : "not yet" },
    { label: "Last test", cell: c => c.last_test_at ? [c.last_test_ok ? "passed " : "failed ", timeAgo(c.last_test_at),
        c.last_test_ok ? null : h("div", { class: "hd-failed small" }, c.last_test_msg || "")] : "–" },
    { label: "Agents", num: true, cell: c => c.agents === null || c.agents === undefined ? "–" : String(c.agents) },
    { label: "Logs", cell: c => !(c.logs || []).length ? h("span", { class: "muted" }, "not read yet") :
        h("span", { title: c.logs.map(l => l.log_type + ": " + (l.available ? "read" : l.available === false ? "not offered" : "not tried")
          + (l.error && !l.available ? " (" + l.error + ")" : "")).join("\n") },
          c.logs.filter(l => l.available).length + " of " + c.logs.length + " read",
          h("div", { class: "muted small" }, c.logs.filter(l => l.available).map(l => LOG_WORD[l.log_type] || l.log_type).join(", ") || "none")) },
    { label: "Health fields", cell: c => !c.fields_seen ? "–" : [
        /pattern/i.test(c.fields_seen.join(" ")) ? "definitions ✓" : h("span", { class: "muted" }, "no definitions"), " · ",
        /last.?(connect|contact|seen|online)|online/i.test(c.fields_seen.join(" ")) ? "connection ✓" : h("span", { class: "muted" }, "no connection time"),
        h("div", { class: "muted small", title: c.fields_seen.join(", ") }, c.fields_seen.length + " fields")] },
    { label: "", cell: c => h("span", { class: "row-actions" },
        h("button", { type: "button", class: "btn-link", on: { click: async e => {
          e.target.disabled = true;
          try { const r = await apiPost("/admin/antivirus/test", { id: c.id }); drawAvConsoles(page, await api("/admin/antivirus"));
                page.querySelector(".av-list-msg").textContent = c.name + ": " + r.message; }
          catch (err) { page.querySelector(".av-list-msg").textContent = err.message; e.target.disabled = false; } } } }, "Test"),
        h("button", { type: "button", class: "btn-link", disabled: !c.enabled, on: { click: async () => {
          try { drawAvConsoles(page, await apiPost("/admin/antivirus/" + c.id + "/sync", {}));
                page.querySelector(".av-list-msg").textContent = "The worker reads " + c.name + " within a minute."; }
          catch (err) { page.querySelector(".av-list-msg").textContent = err.message; } } } }, "Sync now"),
        h("button", { type: "button", class: "btn-link", on: { click: () => { drawAvConsoles(page, d, c); page.querySelector(".av-form input").focus(); } } }, "Edit"),
        h("button", { type: "button", class: "btn-link danger", on: { click: async () => {
          if (!confirm("Remove " + c.name + "? Its saved key and the agents read from it are deleted from PATCH-01.")) return;
          try { drawAvConsoles(page, await apiSend("DELETE", "/admin/antivirus/" + c.id)); }
          catch (err) { page.querySelector(".av-list-msg").textContent = err.message; } } } }, "Remove")) },
  ], rows)) : h("p", { class: "muted" }, "No console added yet.");

  page.replaceChildren(...[
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure av --consoles" }, "Antivirus consoles"),
      h("a", { class: "btn btn-quiet", href: "#/antivirus" }, "Open the Antivirus page")),
    d.key_ready ? null : h("p", { class: "hd-failed" }, "The key that protects saved API keys (av.key) is not on PATCH-01 yet: run phase3b-api.sh."),
    h("p", { class: "muted small" }, "PATCH-01 only reads from Apex Central: the security agents, their definition status and the detection logs. It never isolates, scans, updates, moves or uninstalls anything. "
      + "In Apex Central: Administration › Settings › Automation API Access Settings › Add, tick “Enable application integration”, "
      + "then copy the Application ID and API key here. Use an account with a read-only role. The key is encrypted on PATCH-01 and never shown again."),
    list, h("p", { class: "cm-meta av-list-msg", role: "status" }),
    d.products_ready === false ? h("p", { class: "muted small" }, "Product servers (other Apex One servers, Deep Security, email security) need schema 034: run phase3a-schema.sh.")
      : rows.map(c => avProductsPanel(page, c)),
    form].flat().filter(Boolean));
}

/* Products under one Apex Central: discover, tick which to sync, and read a
   Deep Security Manager directly with its own API key */
function avProductsPanel(page, c) {
  const items = c.products || [];
  const msg = h("p", { class: "cm-meta", role: "status", "aria-live": "polite" });
  const ticks = new Map();
  const dsmBox = h("div");
  const say = t => { msg.textContent = t; };
  const redraw = async r => { drawAvConsoles(page, r || await api("/admin/antivirus"));
    const p = page.querySelector('[data-console="' + c.id + '"] .cm-meta'); if (p) p.textContent = msg.textContent; };
  const discover = h("button", { type: "button", class: "btn-quiet", on: { click: async () => {
    discover.disabled = true; say("Asking Apex Central which product servers it manages…");
    try { const r = await apiPost("/admin/antivirus/" + c.id + "/products/discover", {});
          say((r.products || []).length + " product servers found. Tick the ones to sync, then Save."); await redraw(r); }
    catch (err) { say(err.message); discover.disabled = false; }
  } } }, items.length ? "Discover again" : "Discover products");
  const save = h("button", { type: "button", disabled: !items.length, on: { click: async () => {
    const sel = items.filter(p => ticks.get(p.id).checked).map(p => p.id);
    const off = items.filter(p => !ticks.get(p.id).checked && p.selected !== false);
    if (off.length && c.products_chosen && !confirm("Stop syncing " + off.map(p => p.host_name || p.entity_id).join(", ")
        + "? The agents read under them are removed from PATCH-01 now.")) return;
    save.disabled = true;
    try { const r = await apiSend("PUT", "/admin/antivirus/" + c.id + "/products", { selected: sel });
          say("Saved: " + r.result.selected + " synced" + (r.result.removed_agents ? ", " + r.result.removed_agents + " agents removed" : "")
            + ". The worker reads " + c.name + " again within a minute."); await redraw(r); }
    catch (err) { say(err.message); save.disabled = false; }
  } } }, "Save which to sync");
  const kindCls = { endpoint: "ok", deep_security: "info", email: "warn", other: "" };
  const tbl = items.length ? h("div", { class: "table-wrap" }, table([
    { label: "Sync", cell: p => { const b = h("input", { type: "checkbox", "aria-label": "Sync " + (p.host_name || p.entity_id),
        checked: p.selected === true || (p.selected === null && !c.products_chosen) });
        ticks.set(p.id, b); return b; } },
    { label: "Server", sort: p => (p.host_name || "").toLowerCase(), cell: p => [h("strong", null, p.host_name || p.entity_id),
        p.gone_at ? h("span", { class: "chip warn small", title: "Not in Apex Central's last list, " + fmtDateTime(p.gone_at) }, "no longer listed")
          : p.selected === null && c.products_chosen ? h("span", { class: "chip warn small" }, "new: not chosen yet") : null,
        h("div", { class: "muted small" }, (p.ip_addresses || []).join(", ") + (p.ad_domain ? " · " + p.ad_domain : ""))] },
    { label: "Type", sort: p => p.kind_label, cell: p => [h("span", { class: "chip " + (kindCls[p.kind] || "") }, p.kind_label),
        h("div", { class: "muted small" }, p.product_label)] },
    { label: "Agents", num: true, sort: p => (p.apex_agents || 0) + (p.dsm_agents || 0), cell: p => p.dsm_agents
        ? [String(p.dsm_agents), h("div", { class: "muted small" }, "read from the Manager")]
        : String(p.apex_agents || 0) },
    { label: "Read directly", cell: p => p.kind !== "deep_security" ? h("span", { class: "muted small" }, "through Apex Central")
        : !p.dsm_has_key ? h("span", { class: "muted small" }, "no — through Apex Central")
        : [h("span", { class: "light " + (p.last_sync_ok ? "light-on" : p.last_sync_ok === false ? "light-off" : "light-unk"), "aria-hidden": "true" }), " ",
           p.dsm_enabled ? (p.last_sync_at ? "read " + timeAgo(p.last_sync_at) : "waiting") : "turned off",
           h("div", { class: p.last_sync_ok === false ? "hd-failed small" : "muted small" }, p.last_sync_msg || "")] },
    { label: "", cell: p => p.kind !== "deep_security" ? null : h("span", { class: "row-actions" },
        h("button", { type: "button", class: "btn-link", on: { click: () => { dsmForm(p); } } }, p.dsm_has_key ? "Edit key" : "Add API key"),
        p.dsm_has_key ? h("button", { type: "button", class: "btn-link", disabled: !p.selected || !p.dsm_enabled, on: { click: async () => {
          try { await redraw(await apiPost("/admin/antivirus/products/" + p.id + "/sync", {})); say("The worker reads " + p.host_name + " within a minute."); }
          catch (err) { say(err.message); } } } }, "Sync now") : null) },
  ], items)) : h("p", { class: "muted small" }, "Not discovered yet. Apex Central can manage more Apex One servers, "
      + "Deep Security Managers and email security; Discover lists them so you can choose which to sync.");

  function dsmForm(p) {
    let pin = null;
    const url = h("input", { type: "url", maxlength: "300", value: p.dsm_url || ("https://" + (p.host_name || "") + ":4119"), autocomplete: "off", spellcheck: "false" });
    const key = h("input", { type: "password", maxlength: "300", autocomplete: "new-password", spellcheck: "false",
                             placeholder: p.dsm_has_key ? "saved: leave blank to keep" : "API secret key" });
    const ca = h("textarea", { rows: "4", maxlength: "20000", spellcheck: "false", placeholder: "-----BEGIN CERTIFICATE-----\n(only when the Manager's certificate is from your own CA)" });
    const proxy = h("input", { type: "checkbox", checked: !!p.dsm_use_proxy });
    const enabled = h("input", { type: "checkbox", checked: p.dsm_has_key ? !!p.dsm_enabled : true });
    const unpin = p.dsm_pin_sha256 ? h("input", { type: "checkbox" }) : null;
    const out = h("div", { role: "status", "aria-live": "polite" });
    const cert = h("div", { class: "av-cert" });
    const body = () => { const b = { url: url.value.trim(), use_proxy: proxy.checked, enabled: enabled.checked };
      if (key.value) b.api_key = key.value; if (ca.value.trim()) b.ca_pem = ca.value.trim();
      if (pin) b.pin_sha256 = pin; else if (unpin && unpin.checked) b.pin_sha256 = ""; return b; };
    const getCert = h("button", { type: "button", class: "btn-quiet", on: { click: async () => {
      getCert.disabled = true; pin = null; cert.replaceChildren(h("p", { class: "muted small" }, "Reading the certificate (handshake only, nothing is sent)…"));
      try {
        const r = await apiPost("/admin/antivirus/products/" + p.id + "/dsm/certificate", { url: url.value.trim(), use_proxy: proxy.checked });
        const ok = h("input", { type: "checkbox" }); ok.addEventListener("change", () => { pin = ok.checked ? r.sha256 : null; });
        const verdict = { expired: "Expired certificate: renew it on the Manager (it can still be trusted by its fingerprint)",
          public_ca: "Signed by a CA PATCH-01 already trusts: nothing more is needed",
          private_ca_saved: "Signed by your own CA, already saved here: nothing more is needed",
          self_signed: "Self-signed certificate: compare and trust it by its fingerprint",
          private_ca: "Signed by your own CA (" + (r.issuer || "unnamed") + "): paste that CA below, or trust this certificate by its fingerprint" }[r.trust]
          || "Certificate read";
        cert.replaceChildren(h("div", { class: "av-res " + (r.expired ? "bad" : "ok") }, h("strong", null, verdict),
          h("p", { class: "small" }, "Issued to " + (r.subject || "–") + " · by " + (r.issuer || "–") + " · valid until " + fmtDate(r.not_after)
            + (r.matches_host ? "" : " · not issued for this name")),
          h("p", { class: "mono small av-fp" }, "SHA-256 " + r.sha256_text),
          r.pinned_now ? h("p", { class: "small" }, "This is the certificate already trusted.") : r.trust === "public_ca" ? null :
            h("label", { class: "cm-check" }, ok, " I have compared the fingerprint on the Manager: trust exactly this certificate")));
      } catch (err) { cert.replaceChildren(h("p", { class: "hd-failed small" }, err.message)); }
      getCert.disabled = false;
    } } }, "Get certificate");
    const test = h("button", { type: "button", class: "btn-quiet", on: { click: async () => {
      test.disabled = true; out.replaceChildren(h("p", { class: "muted small" }, "Signing in to the Manager…"));
      try { const r = await apiPost("/admin/antivirus/products/" + p.id + "/dsm/test", body());
            out.replaceChildren(h("div", { class: "av-res " + (r.ok ? "ok" : "bad") }, h("strong", null, r.ok ? "Connected" : "Not connected"), h("p", null, r.message))); }
      catch (err) { out.replaceChildren(h("p", { class: "hd-failed small" }, err.message)); }
      test.disabled = false;
    } } }, "Test");
    const form = h("form", { class: "av-form", autocomplete: "off", on: { submit: async e => {
      e.preventDefault();
      try { await redraw(await apiSend("PUT", "/admin/antivirus/products/" + p.id + "/dsm", body())); say("Saved " + p.host_name + ": read directly from the next sync."); }
      catch (err) { out.replaceChildren(h("p", { class: "hd-failed small" }, err.message)); }
    } } },
      h("h3", null, "Read " + (p.host_name || "this Manager") + " directly"),
      h("p", { class: "muted small" }, "Apex Central shows only part of what a Deep Security Manager knows. With a read-only API key "
        + "(Deep Security › Administration › User Management › API Keys, role with “View computers” only), PATCH-01 reads its computers, "
        + "their status and pattern versions every hour. Only GET requests are made. The key is encrypted and never shown again."),
      h("div", { class: "av-grid" }, h("label", null, h("span", null, "Manager URL"), url), h("label", null, h("span", null, "API secret key"), key)),
      p.dsm_pin_sha256 ? h("p", { class: "small" }, "Trusted certificate: " + (p.dsm_pin_subject || "") + " ",
        h("label", { class: "cm-check" }, unpin, " Stop trusting it")) : null,
      h("div", { class: "cm-actions" }, getCert), cert,
      h("label", null, h("span", null, "Or: the CA certificate (PEM)"), ca),
      h("label", { class: "cm-check" }, proxy, " Through the web proxy (cloud Workload Security only)"),
      h("label", { class: "cm-check" }, enabled, " Read this Manager every hour"),
      h("div", { class: "cm-actions" }, test, h("button", { type: "submit" }, "Save"),
        p.dsm_has_key ? h("button", { type: "button", class: "btn-link danger", on: { click: async () => {
          if (!confirm("Forget the key for " + p.host_name + "? Its computers come from Apex Central again.")) return;
          try { await redraw(await apiSend("DELETE", "/admin/antivirus/products/" + p.id + "/dsm")); } catch (err) { say(err.message); } } } }, "Remove key") : null,
        h("button", { type: "button", class: "btn-quiet", on: { click: () => dsmBox.replaceChildren() } }, "Cancel")),
      out);
    dsmBox.replaceChildren(form);
    url.focus();
  }

  return h("section", { class: "av-products", "data-console": c.id },
    h("h2", null, "Products under " + c.name),
    h("p", { class: "muted small" }, c.products_checked_at ? "Listed " + timeAgo(c.products_checked_at) + ". " : "",
      c.products_chosen ? "Only the ticked servers' agents are synced; a server found later stays off until ticked. The list is read again every day."
                        : "Until you save a choice, every agent Apex Central lists is synced."),
    c.products_chosen ? null : items.length ? h("p", { class: "small" }, "Untick the servers you do not want, then Save: until then nothing is filtered.") : null,
    tbl, h("div", { class: "cm-actions" }, discover, save), msg, dsmBox);
}

/* ---- Admin › Scheduled reports ------------------------------------------------ */

const FREQ_WORD = { daily: "Every day", weekly: "Every week", monthly: "Every month" };
const DAY_WORD = { mon: "Monday", tue: "Tuesday", wed: "Wednesday", thu: "Thursday", fri: "Friday", sat: "Saturday", sun: "Sunday" };
function whenText(s) {
  return s.frequency === "weekly" ? "Every " + DAY_WORD[s.weekday] + " at " + s.at_time
    : s.frequency === "monthly" ? "Monthly on day " + s.monthday + " at " + s.at_time
    : "Every day at " + s.at_time;
}

async function renderReportSchedules(params) {
  setNav("admin");
  if (!can("admin")) return render(h("div", { class: "empty" }, h("p", null, "Scheduled reports need the admin role.")));
  const page = h("div", { class: "rs-admin" });
  render(page);
  const d = await api("/admin/report-schedules");
  let pre = null;
  if (params.get("new")) {
    let p = {};
    try { p = JSON.parse(params.get("p") || "{}"); } catch (e) { p = {}; }
    const r = (d.reports || []).find(x => x.key === params.get("new"));
    if (r) pre = { name: r.title + ", daily", report: r.key, params: p, format: "pdf", frequency: "daily", at_time: "08:00",
                   weekday: "mon", monthday: 1, recipients: null, skip_empty: false, enabled: true };
  }
  drawReportSchedules(page, d, pre);
  adminTabs("report-schedules");
}

function drawReportSchedules(page, d, editing) {
  const msg = h("p", { class: "cm-meta", role: "status" });
  const titleOf = k => ((d.reports || []).find(r => r.key === k) || {}).title || k;
  const list = (d.schedules || []).length ? h("div", { class: "table-wrap" }, table([
    { label: "Report", cell: s => [h("strong", null, s.name), h("div", { class: "muted small" }, titleOf(s.report) + " · " + s.format.toUpperCase())] },
    { label: "When (SGT)", cell: s => whenText(s) },
    { label: "To", cell: s => s.recipients ? s.recipients.join(", ")
        : "Daily digest recipients (" + (d.digest_recipients || []).length + ")" },
    { label: "Last sent", cell: s => s.last_run_at ? [h("span", { class: "light " + (s.last_ok ? "light-on" : "light-off"), "aria-hidden": "true" }), " ",
        timeAgo(s.last_run_at), h("div", { class: s.last_ok ? "muted small" : "hd-failed small" }, s.last_msg || "")] : "not yet" },
    { label: "On", cell: s => h("input", { type: "checkbox", checked: !!s.enabled, "aria-label": "Send " + s.name, on: { change: async e => {
        try { drawReportSchedules(page, await apiSend("PUT", "/admin/report-schedules/" + s.id, scheduleBody(Object.assign({}, s, { enabled: e.target.checked })))); }
        catch (err) { msg.textContent = err.message; e.target.checked = !e.target.checked; } } } }) },
    { label: "", cell: s => h("span", { class: "row-actions" },
        h("button", { type: "button", class: "btn-link", on: { click: async () => {
          try { drawReportSchedules(page, await apiPost("/admin/report-schedules/" + s.id + "/run", {}));
                page.querySelector(".rs-msg").textContent = s.name + ": it goes out within a minute."; }
          catch (err) { page.querySelector(".rs-msg").textContent = err.message; } } } }, "Send now"),
        h("button", { type: "button", class: "btn-link", on: { click: () => { drawReportSchedules(page, d, s); page.querySelector(".rs-form input").focus(); } } }, "Edit"),
        h("button", { type: "button", class: "btn-link danger", on: { click: async () => {
          if (!confirm("Stop and remove “" + s.name + "”?")) return;
          try { drawReportSchedules(page, await apiSend("DELETE", "/admin/report-schedules/" + s.id)); }
          catch (err) { page.querySelector(".rs-msg").textContent = err.message; } } } }, "Remove")) },
  ], d.schedules)) : h("p", { class: "muted" }, "No scheduled report yet.");

  const ed = editing || null;
  const name = h("input", { type: "text", maxlength: "80", required: true, value: ed ? ed.name : "" });
  const rep = h("select", null, (d.reports || []).map(r => h("option", { value: r.key, selected: ed && ed.report === r.key }, r.title)));
  const fmt = h("select", null, ["pdf", "csv"].map(f => h("option", { value: f, selected: ed && ed.format === f }, f.toUpperCase())));
  const freq = h("select", null, ["daily", "weekly", "monthly"].map(f => h("option", { value: f, selected: ed && ed.frequency === f }, FREQ_WORD[f])));
  const at = h("input", { type: "time", value: ed ? ed.at_time : "08:00", required: true, step: "60" });
  const wd = h("select", null, Object.keys(DAY_WORD).map(k => h("option", { value: k, selected: ed && ed.weekday === k }, DAY_WORD[k])));
  const md = h("input", { type: "number", min: "1", max: "28", value: ed ? ed.monthday : 1 });
  const wdL = h("label", null, h("span", null, "Day"), wd), mdL = h("label", null, h("span", null, "Day of month"), md);
  const syncWhen = () => { wdL.hidden = freq.value !== "weekly"; mdL.hidden = freq.value !== "monthly"; };
  freq.addEventListener("change", syncWhen); syncWhen();
  const digest = h("input", { type: "radio", name: "rs-to", checked: !ed || !ed.recipients });
  const pick = h("input", { type: "radio", name: "rs-to", checked: !!(ed && ed.recipients) });
  const boxes = (d.recipients || []).map(r => h("label", { class: "cm-check" },
    h("input", { type: "checkbox", value: r.address, checked: !!(ed && ed.recipients && ed.recipients.some(x => x.toLowerCase() === r.address.toLowerCase())) }),
    " " + (r.name ? r.name + " <" + r.address + ">" : r.address)));
  const pickBox = h("div", { class: "rs-pick" }, boxes);
  const syncTo = () => { pickBox.hidden = !pick.checked; };
  digest.addEventListener("change", syncTo); pick.addEventListener("change", syncTo); syncTo();
  const p = (ed && ed.params) || {};
  const offH = h("input", { type: "number", min: "1", max: "720", value: p.offline_hours || 24 });
  const behind = h("input", { type: "number", min: "1", max: "50", value: p.pattern_behind || 4 });
  const unprot = h("input", { type: "checkbox", checked: p.include_unprotected !== false });
  const avBox = h("fieldset", { class: "rs-av" }, h("legend", null, "Antivirus health"),
    h("label", null, h("span", null, "Offline after (hours without connecting)"), offH),
    h("label", null, h("span", null, "Definitions outdated when behind the newest by more than (releases)"), behind),
    h("label", { class: "cm-check" }, unprot, " Also list machines with no antivirus agent"));
  const days = h("input", { type: "number", min: "1", max: "31", value: p.days || 1 });
  const actBox = h("label", { class: "rs-act" }, h("span", null, "Days covered"), days);
  const syncRep = () => { avBox.hidden = rep.value !== "av_health"; actBox.hidden = !["activity", "av_threats"].includes(rep.value); };
  rep.addEventListener("change", syncRep); syncRep();
  const skip = h("input", { type: "checkbox", checked: !!(ed && ed.skip_empty) });
  const enabled = h("input", { type: "checkbox", checked: ed ? !!ed.enabled : true });
  const fmsg = h("p", { class: "cm-meta", role: "status" });
  const form = h("form", { class: "rs-form", on: { submit: async e => {
    e.preventDefault();
    let params = Object.assign({}, p);
    if (rep.value === "av_health") params = Object.assign(params, { offline_hours: Number(offH.value), pattern_behind: Number(behind.value), include_unprotected: unprot.checked });
    if (["activity", "av_threats"].includes(rep.value)) params = Object.assign(params, { days: Number(days.value) });
    const recipients = pick.checked ? boxes.map(b => b.querySelector("input")).filter(i => i.checked).map(i => i.value) : null;
    if (pick.checked && !recipients.length) { fmsg.textContent = "Tick at least one recipient."; return; }
    const body = scheduleBody({ name: name.value.trim(), report: rep.value, format: fmt.value, frequency: freq.value, at_time: at.value,
      weekday: wd.value, monthday: Number(md.value), recipients, params, skip_empty: skip.checked, enabled: enabled.checked });
    try {
      drawReportSchedules(page, ed && ed.id ? await apiSend("PUT", "/admin/report-schedules/" + ed.id, body)
                                            : await apiPost("/admin/report-schedules", body));
    } catch (err) { fmsg.textContent = err.message || "Could not save."; }
  } } },
    h("h2", null, ed && ed.id ? "Edit “" + ed.name + "”" : "Schedule a report"),
    h("div", { class: "av-grid" },
      h("label", null, h("span", null, "Name"), name), h("label", null, h("span", null, "Report"), rep),
      h("label", null, h("span", null, "File"), fmt), h("label", null, h("span", null, "How often"), freq),
      h("label", null, h("span", null, "Time (SGT)"), at), wdL, mdL),
    avBox, actBox,
    h("fieldset", { class: "rs-to" }, h("legend", null, "Send to"),
      h("label", { class: "cm-check" }, digest, " The daily digest recipients (" + (d.digest_recipients || []).length + ")"),
      h("label", { class: "cm-check" }, pick, " Chosen recipients"), pickBox,
      h("p", { class: "muted small" }, "Only the recipients set in Admin › Mail can receive reports.")),
    h("label", { class: "cm-check" }, skip, " Skip the mail when the report is empty"),
    h("label", { class: "cm-check" }, enabled, " On"),
    h("div", { class: "cm-actions" }, h("button", { type: "submit" }, ed && ed.id ? "Save changes" : "Save"),
      ed ? h("button", { type: "button", class: "btn-quiet", on: { click: () => drawReportSchedules(page, d) } }, "Cancel") : null, fmsg));

  page.replaceChildren(...[
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure reports --schedule" }, "Scheduled reports")),
    d.mail_ready ? null : h("p", { class: "hd-failed" }, "Mail is off: nothing is sent until it is turned on in ", h("a", { href: "#/mail" }, "Admin › Mail"), "."),
    h("p", { class: "muted small" }, "Each report is built on PATCH-01 when it is due and sent in the branded mail, with a summary and the "
      + "file attached (PDF or CSV). Times are Singapore time. Any page with Export › E-mail… can also send its report at once."),
    list, h("p", { class: "cm-meta rs-msg", role: "status" }), form].filter(Boolean));
}

function scheduleBody(s) {
  return { name: s.name, report: s.report, format: s.format, frequency: s.frequency, at_time: s.at_time, weekday: s.weekday,
           monthday: s.monthday, recipients: s.recipients || null, params: s.params || {}, skip_empty: !!s.skip_empty, enabled: !!s.enabled };
}

/* ---- Why a server failed: known error codes, then AI-01's reading -------------------
 * ex is change_targets.detail.explain (filled by the worker). Everything in it came
 * from a server or from AI-01: text nodes only. */
function explainBox(t, changeId) {
  const failedish = t.state === "failed" || (t.warnings && t.warnings.length) || t.state === "done_with_warnings";
  if (!failedish) return null;
  const ex = t.explain || null;
  const again = can("operator") && changeId && t.target_key ? h("button", { type: "button", class: "btn-link", on: { click: async e => {
    const b = e.currentTarget; b.disabled = true;
    try { await apiPost("/changes/" + encodeURIComponent(changeId) + "/targets/" + encodeURIComponent(t.target_key) + "/explain", {});
          b.replaceWith(h("span", { class: "muted small" }, "Asked: AI-01 answers within a minute or two (refresh)")); }
    catch (err) { b.disabled = false; b.textContent = err.message; }
  } } }, ex ? "Ask AI-01 again" : "Explain with AI-01") : null;
  if (ex && ex.state === "pending") {
    return h("div", { class: "xpl xpl-wait" }, h("span", { class: "ai-badge ai-small" }, h("span", { class: "ai-dot", "aria-hidden": "true" }), "AI-01"),
      " reading this failure (known error codes, then AI-01)…");
  }
  if (!ex) {
    // Not explained yet: the worker does recent failures by itself; older ones on request
    return h("div", { class: "xpl xpl-wait" }, "Not explained yet. ", again);
  }
  const known = (ex.known || []).map(k => h("li", null, h("strong", { class: "mono" }, k.code), k.name ? " " + k.name : " (not in PATCH-01's list of known codes)",
    k.meaning ? h("div", null, k.meaning) : null, k.fix ? h("div", { class: "xpl-fix" }, "Usually fixed by: " + k.fix) : null));
  const ai = ex.ai;
  return h("div", { class: "xpl" },
    known.length ? [h("div", { class: "xpl-h" }, "Error codes"), h("ul", { class: "xpl-known" }, known)] : null,
    ai ? [h("div", { class: "xpl-h" }, h("span", { class: "ai-badge ai-small" }, h("span", { class: "ai-dot", "aria-hidden": "true" }), "AI-01"),
            ai.confidence ? h("span", { class: "muted small" }, " confidence " + ai.confidence) : null, ex.reused ? h("span", { class: "muted small" }, " · same error as another server") : null),
          ai.summary ? h("p", null, ai.summary) : null,
          ai.likely_cause ? h("p", { class: "small" }, h("strong", null, "Likely cause: "), ai.likely_cause) : null,
          (ai.steps || []).length ? h("ol", { class: "small xpl-steps" }, ai.steps.map(s => h("li", null, s))) : null,
          ai.retry === true ? h("p", { class: "small" }, "Retrying after these steps is likely to work.") : ai.retry === false ? h("p", { class: "small" }, "Retrying alone is unlikely to help.") : null,
          h("p", { class: "muted small" }, "AI-01's reading of this server's error and log: check it before acting.")]
       : h("p", { class: "muted small" }, ex.state === "off" ? "AI-01 is not set up: only the known codes are shown."
            : ex.state === "rejected" ? (ex.error || "AI-01's answer named things that are not in this server's log, so it is not shown") + ". Ask again for a fresh reading."
            : "AI-01 could not explain it" + (ex.error ? " (" + ex.error + ")" : "") + "."),
    again);
}

/* ---- Installed patches: per server, with the date each went in ---------------------------
 * From each server's own records (Windows installed updates and history, Linux package install
 * times): never the CVE feeds. Export: Excel (summary, the period by server, everything
 * installed by server, a flat sheet for filtering) or PDF (the period by server). */
const IP_KEYS = ["days", "start", "end", "group", "os", "hosts", "q", "defs", "failed"];
async function renderInstalledPatches(params) {
  setNav("installed-patches");
  loadOrg();
  const st = {};
  IP_KEYS.forEach(k => { const v = params.get(k); if (v) st[k] = v; });
  const page = h("div", { class: "srv pr ip" });
  render(page);
  let seq = 0, openAll = null;
  const qs = keys => keys.filter(k => st[k]).map(k => k + "=" + encodeURIComponent(st[k])).join("&");
  async function load() {
    const my = ++seq;
    const q = qs(IP_KEYS);
    const d = await api("/installed-patches" + (q ? "?" + q : ""));
    if (my !== seq || !page.isConnected) return;
    history.replaceState(null, "", "#/installed-patches" + (q ? "?" + q : ""));
    draw(d);
  }
  const set = (k, v) => { if (v) st[k] = v; else delete st[k]; load().catch(showError); };
  const fileUrl = fmt => "/installed-patches/export?" + qs(IP_KEYS) + (qs(IP_KEYS) ? "&" : "") + "format=" + fmt;
  const dl = async (fmt, b) => {
    b.disabled = true; const t = b.textContent; b.textContent = "Preparing…";
    try { await downloadFile(fileUrl(fmt), "installed-patches." + fmt); }
    catch (e) { alert(e.message || "The export failed."); }
    finally { b.disabled = false; b.textContent = t; }
  };

  function draw(d) {
    const t = d.totals || {}, f = d.filters || {};
    const custom = !!(st.start || st.end);
    const period = h("select", { "aria-label": "Period" },
      (d.days || []).map(n => h("option", { value: String(n), selected: !custom && String(f.days) === String(n) },
        n === 1 ? "Last 24 hours" : n === 365 ? "Last 12 months" : "Last " + n + " days")),
      h("option", { value: "custom", selected: custom }, "Dates…"));
    const from = h("input", { type: "date", "aria-label": "From", value: f.start || "" });
    const to = h("input", { type: "date", "aria-label": "To", value: f.end || "" });
    const dates = h("span", { class: "ip-dates", hidden: !custom }, from, h("span", { class: "muted" }, " to "), to,
      h("button", { type: "button", class: "btn btn-quiet", on: { click: () => { delete st.days; st.start = from.value; st.end = to.value; load().catch(showError); } } }, "Show"));
    period.addEventListener("change", () => {
      if (period.value === "custom") { dates.hidden = false; from.focus(); return; }
      delete st.start; delete st.end; set("days", period.value);
    });
    const grp = h("select", { "aria-label": "Patch group", on: { change: e => set("group", e.target.value) } },
      h("option", { value: "" }, "Group: all"), (d.group_names || []).map(g => h("option", { value: g, selected: st.group === g }, g)));
    const osSel = h("select", { "aria-label": "Operating system", on: { change: e => set("os", e.target.value) } },
      [["", "OS: all"], ["windows", "Windows"], ["linux", "Linux"]].map(([v, l]) => h("option", { value: v, selected: (st.os || "") === v }, l)));
    const search = h("input", { type: "search", placeholder: "Server name contains", "aria-label": "Server name", value: st.q || "" });
    let tq = null;
    search.addEventListener("input", () => { clearTimeout(tq); tq = setTimeout(() => set("q", search.value.trim()), 400); });
    const chk = (k, label, tip) => h("label", { class: "ip-chk", title: tip },
      h("input", { type: "checkbox", checked: !!st[k], on: { change: e => set(k, e.target.checked ? "1" : "") } }), " " + label);
    const chosen = st.hosts ? st.hosts.split(",").filter(Boolean).length : 0;

    const xl = h("button", { type: "button", class: "btn" }, "Download Excel");
    xl.addEventListener("click", () => dl("xlsx", xl));
    const pdf = h("button", { type: "button", class: "btn btn-quiet" }, "PDF");
    pdf.addEventListener("click", () => dl("pdf", pdf));
    setPageExport(() => ({ server: "/installed-patches/export" + (qs(IP_KEYS) ? "?" + qs(IP_KEYS) : "") }));
    setMailParams(Object.fromEntries(["days", "start", "end", "group", "os", "q", "defs", "failed"].filter(k => st[k]).map(k => [k, k === "days" ? Number(st[k]) : st[k]])),
      "installed_patches");

    const tiles = h("div", { class: "srv-tiles" },
      [[t.servers || 0, "Servers"], [t.with_patches || 0, "Patched in the period"], [t.in_range || 0, "Patches installed"],
       [t.windows || 0, "Windows servers patched"], [t.linux || 0, "Linux servers patched"]]
        .map(([n, l]) => h("div", { class: "srv-tile" }, h("span", { class: "srv-tile-n" }, String(n)), h("span", { class: "srv-tile-l" }, l))));

    const servers = d.servers || [];
    const withAny = servers.filter(s => s.n_range);
    const quiet = servers.filter(s => !s.n_range);
    const itemTable = s => h("div", { class: "table-wrap" }, h("table", { class: "srv-table pr-inner no-enh" },
      h("thead", null, h("tr", null, [s.os_kind === "windows" ? "Update" : "Package", s.os_kind === "windows" ? "Title" : "Version",
        "Type", "Installed on", "Installed by", "Result"].map(x => h("th", { scope: "col" }, x)))),
      h("tbody", null, s.in_range.map(i => h("tr", null,
        h("td", { class: "mono nowrap" }, i.patch), h("td", null, i.detail || ""), h("td", { class: "small" }, i.kind || ""),
        h("td", { class: "nowrap" }, i.installed_on ? fmtDateTime(i.installed_on) : h("span", { class: "muted" }, "not recorded")),
        h("td", { class: "small" }, i.installed_by || ""), h("td", null, prStatus(i.result === "Succeeded" ? "Installed" : i.result || "Installed")))))));
    const block = (s, open) => h("details", { class: "pr-job ip-srv", open },
      h("summary", { class: "pr-job-head" },
        h("a", { href: "#/host/" + encodeURIComponent(s.host_id), class: "srv-name" }, s.hostname),
        h("span", { class: "muted small" }, [s.host_group || "(no group)", s.os_label].filter(Boolean).join(" · ")),
        h("strong", null, s.n_range + (s.n_range === 1 ? " installed" : " installed")),
        h("span", { class: "muted small" }, s.last_installed ? "last " + fmtDateTime(s.last_installed) : "")),
      itemTable(s),
      s.more ? h("p", { class: "muted small" }, s.more + " more in the export.") : null);
    const blocks = withAny.map((s, i) => block(s, withAny.length <= 8 || i < 3));
    openAll = on => page.querySelectorAll("details.ip-srv").forEach(x => { x.open = on; });

    page.replaceChildren(
      h("div", { class: "page-head" },
        h("h1", null, "Installed patches"),
        h("span", { class: "head-actions" }, xl, pdf)),
      h("p", { class: "muted small" }, "What each server installed and when, from its own records: Windows' installed-updates list and "
        + "Windows Update's history; each Linux package version with the package manager's install time (a server's first day of installs, "
        + "its build, is not counted). CVEs are under Vulnerabilities. The Excel file has a summary, the period by server, everything "
        + "installed by server, and a flat sheet for filtering."),
      h("div", { class: "pr-filters controls" }, period, dates, grp, osSel, search,
        chk("defs", "Antivirus definitions", "Defender's definition updates come several times a day: left out unless ticked"),
        chk("failed", "Failed attempts", "Also list updates Windows Update tried and could not install"),
        chosen ? h("span", { class: "ip-chosen" }, chosen + (chosen === 1 ? " chosen server" : " chosen servers"),
          h("button", { type: "button", class: "btn-link", on: { click: () => set("hosts", "") } }, "show all")) : null),
      tiles,
      h("p", { class: "muted small" }, d.describe || ""),
      withAny.length > 1 ? h("p", { class: "small" }, h("button", { type: "button", class: "btn-link", on: { click: () => openAll(true) } }, "Open all"),
        " · ", h("button", { type: "button", class: "btn-link", on: { click: () => openAll(false) } }, "Close all")) : null,
      withAny.length ? h("div", { class: "pr-jobs" }, blocks)
        : h("div", { class: "empty" }, h("p", null, "Nothing was installed on these servers in this period.")),
      quiet.length ? h("details", { class: "ip-quiet" },
        h("summary", null, quiet.length + (quiet.length === 1 ? " server" : " servers") + " with nothing installed in this period"),
        h("ul", { class: "ip-quiet-list" }, quiet.map(s => h("li", null,
          h("a", { href: "#/host/" + encodeURIComponent(s.host_id) }, s.hostname),
          h("span", { class: "muted small" }, " " + [s.host_group, s.os_label].filter(Boolean).join(" · ")
            + (s.last_installed ? " · last " + fmtDateTime(s.last_installed) : s.os_kind === "linux" && !s.dated ? " · install dates arrive with agent 1.8.2" : "")))))) : null);
  }
  await load();
}
