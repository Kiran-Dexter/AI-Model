/* PATCH-01 header gauges: the master's own CPU, memory and network as three
 * small tachometers, top right.
 *
 * Cheap by design:
 *  - one small request every 5 seconds (about 2 KB), only while the console is
 *    signed in and its tab is visible; nothing at all in a background tab;
 *  - the request does not extend the session (an unattended console still
 *    times out);
 *  - the needle, glow and smoke move with CSS transforms and opacity only, which
 *    the browser hands to the graphics card; "reduce motion" turns them off;
 *  - the numbers come from patch01-metrics.service on PATCH-01, which reads four
 *    small kernel files every 5 seconds.
 * Everything from the API is inserted as text or as numbers, never as HTML. */
(function () {
  "use strict";
  const POLL_MS = 5000, TIMEOUT_MS = 4000, HOT = 70, WARM = 50;
  const SWEEP = 240, FROM = -120;                         // dial: -120 deg (0%) to +120 deg (100%)
  const KINDS = [["cpu", "CPU"], ["mem", "MEM"], ["net", "NET"]];
  const NS = "http://www.w3.org/2000/svg";
  let root = null, gauges = {}, timer = null, inflight = null, last = null, pop = null, failures = 0;
  let denied = false, wasSignedIn = false;     // refused (401/403): wait for a fresh sign-in

  function s(tag, attrs, kids) {
    const el = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs || {})) el.setAttribute(k, String(v));
    (kids || []).forEach(c => el.append(c));
    return el;
  }
  function pt(r, deg) { const a = deg * Math.PI / 180; return [50 + r * Math.sin(a), 50 - r * Math.cos(a)]; }
  function arc(r, d0, d1) {
    const [x0, y0] = pt(r, d0), [x1, y1] = pt(r, d1);
    return `M${x0.toFixed(2)} ${y0.toFixed(2)} A${r} ${r} 0 ${d1 - d0 > 180 ? 1 : 0} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
  }
  const deg = p => FROM + SWEEP * Math.max(0, Math.min(100, p)) / 100;

  function buildGauge(key, label) {
    const ticks = [];
    for (let i = 0; i <= 10; i++) {
      const d = deg(i * 10), major = i % 5 === 0;
      const [x0, y0] = pt(major ? 30 : 32.5, d), [x1, y1] = pt(36, d);
      ticks.push(s("line", { x1: x0.toFixed(2), y1: y0.toFixed(2), x2: x1.toFixed(2), y2: y1.toFixed(2),
                             class: "hg-tick" + (major ? " hg-tick-major" : "") + (i * 10 >= HOT ? " hg-tick-red" : "") }));
    }
    const val = s("path", { d: arc(41, FROM, FROM + SWEEP), class: "hg-val", pathLength: 100, "stroke-dasharray": "0 100" });
    const needle = s("g", { class: "hg-needle" }, [
      s("path", { d: "M50 50 L48.6 52 L50 15 L51.4 52 Z", class: "hg-needle-body" }),
    ]);
    const num = s("text", { x: 50, y: 78, class: "hg-num", "text-anchor": "middle" }, [document.createTextNode("–")]);
    const svg = s("svg", { viewBox: "0 0 100 86", class: "hg-svg", "aria-hidden": "true", focusable: "false" }, [
      s("circle", { cx: 50, cy: 50, r: 47, class: "hg-face" }),
      s("path", { d: arc(41, FROM, FROM + SWEEP), class: "hg-track" }),
      s("path", { d: arc(41, deg(HOT), FROM + SWEEP), class: "hg-red" }),
      ...ticks, val,
      s("text", { x: 50, y: 37, class: "hg-lbl", "text-anchor": "middle" }, [document.createTextNode(label)]),
      needle,
      s("circle", { cx: 50, cy: 50, r: 5.5, class: "hg-hub" }),
      num,
    ]);
    const heat = document.createElement("span"); heat.className = "hg-heat"; heat.setAttribute("aria-hidden", "true");
    const smoke = document.createElement("span"); smoke.className = "hg-smoke"; smoke.setAttribute("aria-hidden", "true");
    for (let i = 0; i < 3; i++) { const p = document.createElement("i"); smoke.append(p); }
    const wrap = document.createElement("span");
    wrap.className = "hg-g lvl-off";
    wrap.setAttribute("role", "meter");
    wrap.setAttribute("aria-valuemin", "0"); wrap.setAttribute("aria-valuemax", "100");
    wrap.setAttribute("aria-label", label);
    wrap.append(heat, svg, smoke);
    gauges[key] = { wrap, val, needle, num, label };
    return wrap;
  }

  function setGauge(key, p, title) {
    const g = gauges[key];
    if (!g) return;
    const known = typeof p === "number" && isFinite(p);
    const v = known ? Math.max(0, Math.min(100, p)) : 0;
    g.val.setAttribute("stroke-dasharray", (known ? v : 0).toFixed(1) + " 100");
    g.needle.style.transform = "rotate(" + deg(v).toFixed(1) + "deg)";
    g.num.textContent = known ? Math.round(v) + "%" : "–";
    const lvl = !known ? "off" : v >= 90 ? "max" : v >= HOT ? "hot" : v >= WARM ? "warm" : "ok";
    g.wrap.className = "hg-g lvl-" + lvl;
    if (known) g.wrap.setAttribute("aria-valuenow", String(Math.round(v))); else g.wrap.removeAttribute("aria-valuenow");
    g.wrap.setAttribute("aria-valuetext", g.label + (known ? " " + Math.round(v) + " percent" : " not measured"));
    g.wrap.title = title || "";
  }

  const fmtBytes = b => {
    if (!(b >= 0)) return "–";
    const u = ["B", "KB", "MB", "GB", "TB"]; let i = 0;
    while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
    return (b >= 10 || i === 0 ? Math.round(b) : b.toFixed(1)) + " " + u[i];
  };
  const fmtBits = b => {
    if (!(b >= 0)) return "–";
    if (b >= 1e9) return (b / 1e9).toFixed(2) + " Gbit/s";
    if (b >= 1e6) return (b / 1e6).toFixed(1) + " Mbit/s";
    if (b >= 1e3) return Math.round(b / 1e3) + " kbit/s";
    return Math.round(b) + " bit/s";
  };

  function paint(d) {
    last = d;
    if (!d || !d.available) {
      KINDS.forEach(([k]) => setGauge(k, null, d && d.why ? d.why : "Not measured"));
      root.classList.add("hg-stale");
      return;
    }
    root.classList.toggle("hg-stale", !!d.stale);
    const old = d.stale ? " (not updated for a while: is patch01-metrics running?)" : "";
    const c = d.cpu || {}, m = d.mem || {}, n = d.net || {};
    setGauge("cpu", d.stale ? null : c.pct, "CPU " + (c.pct ?? "–") + "% of " + (c.cores || "?") + " cores · load "
      + (c.load || []).map(x => x == null ? "–" : x.toFixed(2)).join(" / ") + old);
    setGauge("mem", d.stale ? null : m.pct, "Memory " + (m.pct ?? "–") + "% · " + fmtBytes(m.used) + " of " + fmtBytes(m.total)
      + (m.swap_total ? " · swap " + m.swap_pct + "%" : "") + old);
    setGauge("net", d.stale ? null : n.pct, "Network in " + fmtBits(n.rx_bps) + ", out " + fmtBits(n.tx_bps) + " of "
      + (n.link_mbps ? n.link_mbps + " Mbit/s" : "1 Gbit/s (assumed: the card does not report its speed)") + old);
    if (pop && !pop.hidden) fillPop();
  }

  async function tick() {
    if (inflight || !visible()) return;
    const ctl = new AbortController();
    inflight = ctl;
    const t = setTimeout(() => ctl.abort(), TIMEOUT_MS);
    try {
      const res = await fetch("/api/v1/system/health", {
        headers: { "Accept": "application/json", "X-Requested-With": "patch01-dashboard",
                   ...(typeof authHeaders === "function" ? authHeaders() : {}) },
        cache: "no-store", signal: ctl.signal,
      });
      if (res.status === 401 || res.status === 403) { denied = true; stop(); root.hidden = true; closePop(); return; }
      if (!res.ok) throw new Error("HTTP " + res.status);
      failures = 0;
      paint(await res.json());
    } catch (e) {
      failures++;
      if (failures >= 2) paint({ available: false, why: "PATCH-01 did not answer the last measurements." });
    } finally {
      clearTimeout(t);
      inflight = null;
    }
  }

  const signedIn = () => document.body.classList.contains("signed-in") && typeof getAuth === "function" && !!getAuth();
  const visible = () => document.visibilityState === "visible";
  function start() {
    if (!root || timer) return;
    root.hidden = false;
    tick();
    timer = setInterval(tick, POLL_MS);
  }
  function stop() {
    if (timer) { clearInterval(timer); timer = null; }
    if (inflight) inflight.abort();
  }
  function sync() {
    const now = signedIn();
    if (now && !wasSignedIn) denied = false;     // a new sign-in may see the gauges again
    wasSignedIn = now;
    if (now && visible() && !denied) start(); else stop();
    if (!signedIn() && root) { root.hidden = true; closePop(); }
  }

  /* ---- details on click --------------------------------------------------- */
  function spark(hist, i, cls) {
    const pts = hist.map((x, j) => [j, x[i]]).filter(x => typeof x[1] === "number");
    const w = 220, ht = 34;
    if (pts.length < 2) return s("svg", { viewBox: `0 0 ${w} ${ht}`, class: "hg-spark" });
    const n = hist.length - 1 || 1;
    const d = pts.map(([j, v], k) => (k ? "L" : "M") + (j * w / n).toFixed(1) + " " + (ht - 2 - v * (ht - 4) / 100).toFixed(1)).join(" ");
    return s("svg", { viewBox: `0 0 ${w} ${ht}`, class: "hg-spark", preserveAspectRatio: "none", "aria-hidden": "true" }, [
      s("line", { x1: 0, x2: w, y1: (ht - 2 - HOT * (ht - 4) / 100).toFixed(1), y2: (ht - 2 - HOT * (ht - 4) / 100).toFixed(1), class: "hg-spark-hot" }),
      s("path", { d, class: "hg-spark-line " + cls }),
    ]);
  }
  function row(label, value, hist, i) {
    const r = document.createElement("div"); r.className = "hg-row";
    const a = document.createElement("div"); a.className = "hg-row-h";
    const b = document.createElement("strong"); b.textContent = label;
    const c = document.createElement("span"); c.textContent = value;
    a.append(b, c); r.append(a);
    if (hist) r.append(spark(hist, i, "hg-sl-" + i));
    return r;
  }
  function fillPop() {
    const d = last;
    const body = pop.querySelector(".hg-pop-body");
    body.replaceChildren();
    if (!d || !d.available) {
      const p = document.createElement("p"); p.textContent = d && d.why ? d.why : "Not measured yet."; body.append(p); return;
    }
    const c = d.cpu || {}, m = d.mem || {}, n = d.net || {}, h = d.history || [];
    body.append(
      row("CPU", (c.pct ?? "–") + "% · " + (c.cores || "?") + " cores · load " + (c.load || []).map(x => x == null ? "–" : x.toFixed(2)).join(" "), h, 1),
      row("Memory", (m.pct ?? "–") + "% · " + fmtBytes(m.used) + " of " + fmtBytes(m.total) + (m.swap_total ? " · swap " + m.swap_pct + "%" : " · no swap"), h, 2),
      row("Network", "in " + fmtBits(n.rx_bps) + " · out " + fmtBits(n.tx_bps) + " · link " + (n.link_mbps ? n.link_mbps + " Mbit/s" : "not reported (1 Gbit/s assumed)"), h, 3));
    const foot = document.createElement("p"); foot.className = "hg-foot";
    const col = d.collector || {};
    const up = col.since ? Math.max(1, Date.now() / 1000 - col.since) : null;
    const share = up && col.cpu_s != null ? (100 * col.cpu_s / up) : null;
    foot.textContent = "Last 10 minutes, every 5 s" + (d.stale ? " · NOT UPDATED: check patch01-metrics on PATCH-01" : "")
      + ". Measuring costs PATCH-01 " + (share == null ? "–" : share < 0.01 ? "under 0.01" : share.toFixed(2)) + "% of one CPU and "
      + (col.rss_kb ? Math.round(col.rss_kb / 1024) + " MB" : "–") + " of memory.";
    body.append(foot);
  }
  function openPop() {
    if (!pop) {
      pop = document.createElement("div");
      pop.className = "hg-pop"; pop.setAttribute("role", "dialog"); pop.setAttribute("aria-label", "PATCH-01 load");
      const head = document.createElement("div"); head.className = "hg-pop-head";
      const t = document.createElement("strong"); t.textContent = "PATCH-01 right now";
      const x = document.createElement("button"); x.type = "button"; x.className = "hg-x"; x.textContent = "×"; x.setAttribute("aria-label", "Close");
      x.addEventListener("click", closePop);
      head.append(t, x);
      const body = document.createElement("div"); body.className = "hg-pop-body";
      pop.append(head, body);
      document.body.append(pop);
    }
    const r = root.getBoundingClientRect();
    pop.style.top = Math.round(r.bottom + 8) + "px";
    pop.style.right = Math.max(8, Math.round(window.innerWidth - r.right)) + "px";
    pop.hidden = false;
    root.setAttribute("aria-expanded", "true");
    fillPop();
  }
  function closePop() {
    if (pop) pop.hidden = true;
    if (root) root.setAttribute("aria-expanded", "false");
  }

  function init() {
    const session = document.querySelector("header.top .session");
    if (!session || document.getElementById("hostgauge")) return;
    root = document.createElement("button");
    root.type = "button"; root.id = "hostgauge"; root.className = "hg hg-stale"; root.hidden = true;
    root.setAttribute("aria-haspopup", "dialog"); root.setAttribute("aria-expanded", "false");
    root.title = "PATCH-01: CPU, memory, network";
    KINDS.forEach(([k, l]) => root.append(buildGauge(k, l)));
    root.addEventListener("click", e => { e.stopPropagation(); pop && !pop.hidden ? closePop() : openPop(); });
    document.addEventListener("click", e => { if (pop && !pop.hidden && !pop.contains(e.target)) closePop(); });
    document.addEventListener("keydown", e => { if (e.key === "Escape") closePop(); });
    session.prepend(root);
    document.addEventListener("visibilitychange", sync);
    new MutationObserver(sync).observe(document.body, { attributes: true, attributeFilter: ["class"] });
    sync();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
