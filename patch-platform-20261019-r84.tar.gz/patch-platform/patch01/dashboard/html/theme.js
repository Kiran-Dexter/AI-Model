/* Applies the saved theme before the page paints, so there is no flash of
 * the wrong theme. Loaded without defer, ahead of the stylesheet. A separate
 * file rather than inline because the content security policy forbids
 * inline scripts.
 *
 * Three themes: Default (light) and Dark for everyone, B-Mode (neon) for
 * admins only. app.js moves a non-admin off B-Mode once the role is known.
 * Older saved choices carry over: System becomes Default.
 */
(function () {
  "use strict";
  var KEY = "patch01.theme";
  var DEFAULT = "light";
  var VALID = { light: 1, dark: 1, hacker: 1 };
  var OLD = { system: "light" };

  function pref() {
    try {
      var v = localStorage.getItem(KEY);
      var own = Object.prototype.hasOwnProperty;
      if (own.call(OLD, v)) v = OLD[v];
      return own.call(VALID, v) ? v : DEFAULT;
    } catch (e) { return DEFAULT; }
  }

  function apply(t) {
    var root = document.documentElement;
    root.setAttribute("data-theme", t);
    root.setAttribute("data-theme-pref", t);
  }

  apply(pref());

  window.PatchTheme = {
    get: pref,
    set: function (t) {
      if (!Object.prototype.hasOwnProperty.call(VALID, t)) return;
      try { localStorage.setItem(KEY, t); } catch (e) { /* private mode */ }
      apply(t);
    },
    options: [
      ["light", "Default"],
      ["dark", "Dark"],
      ["hacker", "B-Mode"],
    ],
  };
})();
