"""Checking that every number in AI-01's text is one of the figures it was
given. Shared by the threat summary and the coverage summary.

Only the numeric values of the figures count (never digits inside names,
which come from untrusted logs and sheets). Names, and product names with
versions ("Windows 11", "Server 2019"), are taken out of the text first. A
number is read whole ("1,250", "3.5", "37." at the end of a sentence), and
numbers written as words are refused.
"""

import re

_NUM = re.compile(r"(?<![A-Za-z0-9_-])\d+(?:[.,]\d+)*")
_PRODUCT = re.compile(r"\b(?:microsoft\s+)?(?:windows(?:\s+server)?|server|rhel|red\s+hat\s+enterprise\s+linux|oracle\s+linux|ubuntu|"
                      r"apex\s+one|deep\s+security)\s+\d+(?:\.\d+)*(?:\s+r2)?\b", re.I)
_WORDS = re.compile(r"\b(two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|"
                    r"seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|"
                    r"dozen|dozens|hundreds|thousands)\b", re.I)


def _values(x, out):
    if isinstance(x, bool) or x is None:
        return
    if isinstance(x, (int, float)):
        out.add(x)
    elif isinstance(x, dict):
        for v in x.values():
            _values(v, out)
    elif isinstance(x, (list, tuple, set)):
        for v in x:
            _values(v, out)


def numbers_ok(text, figures, names=(), extra=()):
    allowed = set()
    _values(figures, allowed)
    allowed |= set(extra)
    t = text or ""
    for n in sorted({str(x) for x in names if x}, key=len, reverse=True):
        t = t.replace(n, " ")
    t = _PRODUCT.sub(" ", t)
    if _WORDS.search(t):
        return False
    for m in _NUM.findall(t):
        v = m.rstrip(".,")
        try:
            num = float(v.replace(",", "")) if re.fullmatch(r"\d{1,3}(,\d{3})+", v) else float(v.replace(",", "."))
        except ValueError:
            return False
        if num not in allowed:
            return False
    return True
