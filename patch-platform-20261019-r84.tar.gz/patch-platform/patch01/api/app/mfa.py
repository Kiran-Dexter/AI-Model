"""
Two-factor sign-in with an authenticator app (TOTP, RFC 6238: SHA-1, 6 digits,
30 seconds), standard library only.

- The secret is encrypted at rest with a key only the API holds
  (TOTP_KEY_FILE, made by phase3b-api.sh); the database alone cannot be used
  to generate codes.
- A code is accepted once: the time step used is remembered, so a code seen
  over a shoulder or replayed is refused.
- One step either side is accepted (clock drift of up to 30 seconds).
- Recovery codes (shown once) are stored as scrypt hashes and are single use.
- The step between the password and the code is a short-lived ticket (5
  minutes, 5 tries); failed codes also count towards the account lock.
"""

import base64
import hashlib
import hmac
import os
import secrets
import struct
import time
from urllib.parse import quote

KEY_FILE = os.environ.get("TOTP_KEY_FILE", "/etc/patch01/totp.key")
REQUIRE_2FA = os.environ.get("REQUIRE_2FA", "false").lower() in ("1", "true", "yes")
ISSUER = "Cyber-Secure"
STEP = 30
DIGITS = 6
TICKET_MINUTES = 5
TICKET_TRIES = 5
RECOVERY_COUNT = 8


class MfaError(Exception):
    """For the user."""


def _fernet():
    from cryptography.fernet import Fernet
    try:
        with open(KEY_FILE, "rb") as fh:
            return Fernet(fh.read().strip())
    except FileNotFoundError:
        raise MfaError("Two-factor sign-in is not set up on PATCH-01 (its key is missing): run phase3b-api.sh.")
    except ValueError:
        raise MfaError("Two-factor sign-in's key on PATCH-01 is not valid: ask the administrator.")


def available():
    try:
        _fernet()
        return True
    except MfaError:
        return False


def encrypt(secret_b32):
    return _fernet().encrypt(secret_b32.encode()).decode()


def decrypt(token):
    from cryptography.fernet import InvalidToken
    try:
        return _fernet().decrypt(token.encode()).decode()
    except InvalidToken:
        raise MfaError("The stored two-factor secret cannot be read with this PATCH-01's key: ask an admin to reset it.")


def new_secret():
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")


def _code(secret_b32, step):
    key = base64.b32decode(secret_b32 + "=" * (-len(secret_b32) % 8), casefold=True)
    digest = hmac.new(key, struct.pack(">Q", step), hashlib.sha1).digest()
    o = digest[-1] & 0x0F
    n = (struct.unpack(">I", digest[o:o + 4])[0] & 0x7FFFFFFF) % (10 ** DIGITS)
    return str(n).zfill(DIGITS)


def check(secret_b32, code, last_step=None, now=None):
    """The time step the code belongs to, or None. A step at or before
    last_step (already used) is refused."""
    code = "".join(ch for ch in str(code or "") if ch.isdigit())
    if len(code) != DIGITS:
        return None
    cur = int((now if now is not None else time.time()) // STEP)
    found = None
    for st in (cur - 1, cur, cur + 1):
        if hmac.compare_digest(_code(secret_b32, st), code):
            found = st
    if found is None or (last_step is not None and found <= int(last_step)):
        return None
    return found


def uri(username, secret_b32):
    label = quote(f"{ISSUER}:{username}", safe=":")
    return (f"otpauth://totp/{label}?secret={secret_b32}&issuer={quote(ISSUER)}"
            f"&algorithm=SHA1&digits={DIGITS}&period={STEP}")


def new_recovery_codes():
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    codes = []
    for _ in range(RECOVERY_COUNT):
        raw = "".join(secrets.choice(alphabet) for _ in range(10))
        codes.append(raw[:5] + "-" + raw[5:])
    return codes


def norm_recovery(code):
    c = "".join(ch for ch in str(code or "").upper() if ch.isalnum())
    return c if len(c) == 10 else None


def ticket_hash(t):
    return hashlib.sha256(t.encode()).hexdigest()
