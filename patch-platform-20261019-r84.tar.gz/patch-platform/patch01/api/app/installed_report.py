"""Installed patches, per server, with the date each went in: the Servers page's
Installed patches report and its exports (Excel: summary, the date range by
server, everything installed by server, and a flat sheet for filtering; PDF:
the date range by server).

From the servers' own records only, never from the CVE feeds:
  Windows  the agent's installed-updates list and Windows Update's history
           (agent 1.9.0+; older agents: the KBs and the date Windows keeps)
  Linux    each package version with the package manager's install time
           (agent 1.8.2+). The packages of the server's first day of installs
           are its base system, not patches, and are left out.

Filters are validated here and passed as parameters: nothing from the request
is ever put into the SQL text.
"""

import re
from datetime import date, datetime, time, timedelta, timezone

MAX_HOSTS = 1000
MAX_ROWS = 200000                 # per sheet; a larger export says it was cut
DAY_CHOICES = (1, 7, 14, 30, 60, 90, 180, 365)
UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
NAME_RE = re.compile(r"^[A-Za-z0-9 ._()/+-]{1,80}$")
Q_RE = re.compile(r"^[A-Za-z0-9 ._:-]{1,80}$")
# Antivirus definition updates come several times a day: left out unless asked for
DEFS_RE = re.compile(r"(?i)security intelligence update|definition update|KB2267602|KB2461484|KB915597")
OK_RESULTS = ("Succeeded", "Installed", "Succeeded with errors")


class Invalid(ValueError):
    pass


def _day(v):
    if not v:
        return None
    try:
        return date.fromisoformat(str(v)[:10])
    except ValueError:
        raise Invalid("Dates are written like 2026-10-19.")


def clean_filters(days=None, start=None, end=None, group=None, os=None, hosts=None, q=None, defs=None, failed=None):
    """Validated filters. A date range (start..end, whole days, UTC) wins over days."""
    s, e = _day(start), _day(end)
    if s or e:
        e = e or datetime.now(timezone.utc).date()
        s = s or (e - timedelta(days=30))
        if s > e:
            s, e = e, s
        if (e - s).days > 3660:
            raise Invalid("Choose at most ten years.")
        d = None
    else:
        try:
            d = int(days or 30)
        except (TypeError, ValueError):
            d = 30
        d = d if d in DAY_CHOICES else 30
        e = datetime.now(timezone.utc).date()
        s = e - timedelta(days=d - 1)
    ids = []
    for x in str(hosts or "").split(","):
        x = x.strip().lower()
        if x and UUID_RE.match(x) and x not in ids:
            ids.append(x)
    if len(ids) > MAX_HOSTS:
        raise Invalid(f"Choose at most {MAX_HOSTS} servers.")
    group = (group or "").strip()
    q = (q or "").strip()
    return {"days": d, "start": s, "end": e,
            "since": datetime.combine(s, time.min, timezone.utc),
            "until": datetime.combine(e + timedelta(days=1), time.min, timezone.utc),
            "group": group if group and NAME_RE.match(group) else None,
            "os": os if os in ("windows", "linux") else None,
            "hosts": ids or None, "q": q if q and Q_RE.match(q) else None,
            "defs": str(defs).lower() in ("1", "true", "yes"),
            "failed": str(failed).lower() in ("1", "true", "yes")}


def describe(f):
    rng = f"last {f['days']} days" if f["days"] else f"{f['start']:%d %b %Y} to {f['end']:%d %b %Y}"
    parts = [rng]
    if f["group"]:
        parts.append(f"group {f['group']}")
    if f["os"]:
        parts.append("Windows" if f["os"] == "windows" else "Linux")
    if f["hosts"]:
        parts.append(f"{len(f['hosts'])} chosen server(s)")
    if f["q"]:
        parts.append(f"name contains {f['q']}")
    if f["defs"]:
        parts.append("with antivirus definition updates")
    if f["failed"]:
        parts.append("with failed attempts")
    return "; ".join(parts)


HOSTS_SQL = """
SELECT h.id::text AS host_id, h.hostname, coalesce(h.host_group, '') AS host_group, h.os_id,
       CASE WHEN h.os_id = 'windows' THEN coalesce(nullif(regexp_replace(h.os_edition, '^Microsoft ', ''), ''), 'Windows')
            WHEN h.os_id = 'rhel' THEN 'RHEL ' || coalesce(h.os_major::text, split_part(h.os_version, '.', 1))
            WHEN h.os_id = 'ol' THEN 'Oracle Linux ' || coalesce(h.os_major::text, split_part(h.os_version, '.', 1))
            WHEN h.os_id = 'ubuntu' THEN 'Ubuntu ' || coalesce(h.os_version, '')
            ELSE coalesce(h.os_id, 'unknown') || ' ' || coalesce(h.os_version, '') END AS os_label,
       h.agent_version, h.last_inventory
  FROM hosts h
 WHERE h.status <> 'decommissioned'
   AND (%(group)s::text IS NULL OR coalesce(h.host_group, '') = %(group)s::text)
   AND (%(os)s::text IS NULL OR (%(os)s::text = 'windows') = (h.os_id = 'windows'))
   AND (%(hosts)s::uuid[] IS NULL OR h.id = ANY(%(hosts)s::uuid[]))
   AND (%(q)s::text IS NULL OR strpos(lower(h.hostname || ' ' || coalesce(h.fqdn, '')), lower(%(q)s::text)) > 0)
 ORDER BY lower(h.hostname)
 LIMIT 5000"""

WIN_SQL = """SELECT host_id::text AS host_id, kb, title, kind, installed_on, installed_by, result, source
               FROM windows_installed_updates WHERE host_id = ANY(%(ids)s::uuid[])"""
WIN_OLD_SQL = """SELECT host_id::text AS host_id, upper(name) AS kb, from_repo AS kind, install_time AS installed_on
                   FROM host_packages WHERE host_id = ANY(%(ids)s::uuid[]) AND name LIKE 'kb%%'"""
# A Linux server's base system: its first day of installs (the build). What came after are patches.
LIN_SQL = """WITH base AS (
               SELECT host_id, min(installed_at) AS built FROM linux_package_installs
                WHERE host_id = ANY(%(ids)s::uuid[]) AND installed_at IS NOT NULL GROUP BY host_id)
             SELECT li.host_id::text AS host_id, li.name, li.arch, li.version, li.installed_at
               FROM linux_package_installs li JOIN base b ON b.host_id = li.host_id
              WHERE li.installed_at > b.built + interval '1 day'"""


def _ts(v):
    """A timestamp as an aware datetime (the driver gives one; text is read too)."""
    if v is None or isinstance(v, datetime):
        return v if v is None or v.tzinfo else v.replace(tzinfo=timezone.utc)
    try:
        d = datetime.fromisoformat(str(v).replace(" ", "T").replace("Z", "+00:00"))
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def _windows(rows_by_host, has_detail):
    """One row per installed update, as on the server page: the hotfix list joined with
    Windows Update's history; updates only in the history are listed with each result."""
    out = {}
    for hid, rows in rows_by_host.items():
        if not has_detail.get(hid):
            out[hid] = [{"patch": r["kb"], "detail": "", "kind": r["kind"] or "", "installed_on": r["installed_on"],
                         "installed_by": "", "result": "Installed"} for r in rows]
            continue
        hot = {r["kb"]: dict(r) for r in rows if r["source"] == "hotfix" and r["kb"]}
        items = list(hot.values())
        for r in rows:
            if r["source"] != "history":
                continue
            if r["kb"] and r["kb"] in hot:
                x = hot[r["kb"]]
                x["title"] = x["title"] or r["title"]
                x["installed_on"] = x["installed_on"] or r["installed_on"]
                x["result"] = x["result"] or r["result"]
                continue
            items.append(dict(r))
        out[hid] = [{"patch": i["kb"] or "update", "detail": i["title"] or "", "kind": i["kind"] or "",
                     "installed_on": i["installed_on"], "installed_by": i["installed_by"] or "",
                     "result": i["result"] or "Installed"} for i in items]
    return out


def collect(conn, f, full=False):
    """Servers in the filter, each with the patches installed in the date range (and,
    when full, everything installed), newest first."""
    hosts = [dict(r) for r in conn.execute(HOSTS_SQL, {k: f[k] for k in ("group", "os", "hosts", "q")}).fetchall()]
    ids = [h["host_id"] for h in hosts]
    win_ids = [h["host_id"] for h in hosts if h["os_id"] == "windows"]
    lin_ids = [h["host_id"] for h in hosts if h["os_id"] != "windows"]
    per = {i: [] for i in ids}
    if win_ids:
        detail = {}
        for r in conn.execute(WIN_SQL, {"ids": win_ids}).fetchall():
            per[r["host_id"]].append(dict(r))
            detail[r["host_id"]] = True
        old = [i for i in win_ids if not detail.get(i)]
        if old:
            for r in conn.execute(WIN_OLD_SQL, {"ids": old}).fetchall():
                per[r["host_id"]].append(dict(r))
        wins = _windows({i: per[i] for i in win_ids}, detail)
    else:
        wins = {}
    lins = {i: [] for i in lin_ids}
    if lin_ids:
        for r in conn.execute(LIN_SQL, {"ids": lin_ids}).fetchall():
            lins[r["host_id"]].append({"patch": r["name"] + ("." + r["arch"] if r["arch"] and r["arch"] not in ("noarch", "all") else ""),
                                       "detail": r["version"], "kind": "package", "installed_on": r["installed_at"],
                                       "installed_by": "", "result": "Installed"})
    since, until = f["since"], f["until"]
    totals = {"servers": len(hosts), "with_patches": 0, "in_range": 0, "all": 0, "windows": 0, "linux": 0}
    for h in hosts:
        items = wins.get(h["host_id"]) if h["os_id"] == "windows" else lins.get(h["host_id"])
        items = [dict(i, installed_on=_ts(i["installed_on"])) for i in (items or [])
                 if f["defs"] or not DEFS_RE.search(f"{i['patch']} {i['detail']}")]
        if not f["failed"]:
            items = [i for i in items if (i["result"] or "Installed") in OK_RESULTS]
        items.sort(key=lambda i: (i["installed_on"] is None, -(i["installed_on"].timestamp() if i["installed_on"] else 0), i["patch"]))
        rng = [i for i in items if i["installed_on"] and since <= i["installed_on"] < until]
        h["os_kind"] = "windows" if h["os_id"] == "windows" else "linux"
        h["in_range"] = rng
        h["all"] = items if full else None
        h["n_range"], h["n_all"] = len(rng), len(items)
        h["last_installed"] = next((i["installed_on"] for i in items if i["installed_on"]), None)
        h["dated"] = bool(items) or (h["os_kind"] == "windows")
        totals["in_range"] += len(rng)
        totals["all"] += len(items)
        if rng:
            totals["with_patches"] += 1
            totals["windows" if h["os_kind"] == "windows" else "linux"] += 1
    return hosts, totals


# ---- exports ------------------------------------------------------------------------------

ITEM_HEADERS = ["Server / patch", "Version or title", "Type", "Installed on", "Installed by", "Result"]
FLAT_HEADERS = ["Server", "Group", "Operating system", "Patch / package", "Version or title", "Type", "Installed on",
                "Installed by", "Result"]
SUMMARY_HEADERS = ["Server", "Group", "Operating system", "Installed in the period", "Installed, all recorded",
                   "Last installed", "Agent"]


def _when(v, tz):
    if not v:
        return "not recorded"
    if tz is not None and getattr(v, "tzinfo", None):
        v = v.astimezone(tz)
    return v.strftime("%Y-%m-%d %H:%M")


def grouped(hosts, key, tz, empty_note, quiet_last=False):
    """Rows for one server after another: a heading row per server (its name, group, OS,
    how many), then its patches. Returns (rows, indexes of the heading rows, cut).
    quiet_last: servers with nothing are not given a block each, but listed together at the end."""
    rows, heads, cut = [], [], False
    quiet = [h for h in hosts if not h[key]] if quiet_last else []
    for h in hosts:
        items = h[key] or []
        if quiet_last and not items:
            continue
        if len(rows) + len(items) + 1 > MAX_ROWS:
            cut = True
            break
        heads.append(len(rows))
        rows.append([h["hostname"], " · ".join(x for x in (h["host_group"] or "(no group)", h["os_label"]) if x),
                     f"{len(items)} installed", "", "", ""])
        if not items:
            rows.append(["", empty_note if h["dated"] else "No install dates yet: agent 1.8.2 sends them", "", "", "", ""])
        for i in items:
            rows.append(["    " + str(i["patch"]), i["detail"], i["kind"], _when(i["installed_on"], tz), i["installed_by"],
                         i["result"]])
    if quiet and not cut and len(rows) + len(quiet) + 1 <= MAX_ROWS:
        heads.append(len(rows))
        rows.append([f"{len(quiet)} servers with nothing installed in this period", "", "", "", "", ""])
        for h in quiet:
            rows.append(["    " + h["hostname"], " · ".join(x for x in (h["host_group"] or "(no group)", h["os_label"]) if x),
                         "", ("last installed " + _when(h["last_installed"], tz)) if h["last_installed"]
                         else ("" if h["dated"] else "no install dates yet (agent 1.8.2)"), "", ""])
    return rows, heads, cut


def flat(hosts, tz):
    rows = []
    for h in hosts:
        for i in h["in_range"]:
            if len(rows) >= MAX_ROWS:
                return rows, True
            rows.append([h["hostname"], h["host_group"], h["os_label"], i["patch"], i["detail"], i["kind"],
                         _when(i["installed_on"], tz), i["installed_by"], i["result"]])
    return rows, False


def summary_rows(hosts, tz):
    return [[h["hostname"], h["host_group"], h["os_label"], h["n_range"], h["n_all"],
             _when(h["last_installed"], tz) if h["last_installed"] else "", h["agent_version"] or ""] for h in hosts]


def render(conn, f, fmt, user):
    """(bytes, media type, extension, rows) of the export."""
    from . import exports as ex
    hosts, totals = collect(conn, f, full=(fmt == "xlsx"))
    title = "Installed patches"
    period = f"{f['start']:%d %b %Y} to {f['end']:%d %b %Y}"
    if fmt == "csv":
        rows, cut = flat(hosts, ex.TZ)
        m = ex.meta(title, user, describe(f), len(rows), ex.company_name(conn))
        return ex.csv_text(m, FLAT_HEADERS, rows).encode("utf-8"), "text/csv; charset=utf-8", "csv", len(rows)
    logo, cls, accent = ex.brand_bits(conn)
    rng, heads, cut = grouped(hosts, "in_range", ex.TZ, "Nothing installed in this period.", quiet_last=True)
    if fmt == "pdf":
        m = ex.meta(f"{title}, {period}", user, describe(f), totals["in_range"], ex.company_name(conn))
        return ex.pdf_bytes(m, ITEM_HEADERS, rng, logo, cls, accent, heads=heads), "application/pdf", "pdf", totals["in_range"]
    full, fheads, fcut = grouped(hosts, "all", ex.TZ, "Nothing recorded.")
    fl, flcut = flat(hosts, ex.TZ)
    m = ex.meta(title, user, describe(f), totals["in_range"], ex.company_name(conn))
    how = ("Windows: the installed-updates list and Windows Update's history. Linux: each package version with the package "
           "manager's install time; a server's first day of installs (its build) is not counted as patches.")
    sheets = [
        {"name": "Summary", "headers": SUMMARY_HEADERS, "rows": summary_rows(hosts, ex.TZ), "filter": True,
         "note": f"{totals['servers']} servers; {totals['in_range']} patches installed from {period} on {totals['with_patches']} of them. " + how},
        {"name": "Period, by server", "title": f"Installed {period}, by server", "headers": ITEM_HEADERS, "rows": rng, "heads": heads,
         "note": "Cut at %d rows: narrow the filter." % MAX_ROWS if cut else None},
        {"name": "All installed, by server", "title": "Everything installed (all recorded), by server", "headers": ITEM_HEADERS,
         "rows": full, "heads": fheads, "note": "Cut at %d rows: narrow the filter." % MAX_ROWS if fcut else None},
        {"name": "Period, flat", "title": f"Installed {period}: one row per patch, for filtering", "headers": FLAT_HEADERS,
         "rows": fl, "filter": True, "note": "Cut at %d rows: narrow the filter." % MAX_ROWS if flcut else None},
    ]
    return (ex.xlsx_workbook(m, sheets, logo), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx",
            totals["in_range"])
