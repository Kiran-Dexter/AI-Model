"""
A small QR Code encoder (ISO/IEC 18004), byte mode, error correction level M,
versions 1 to 10, rendered as SVG. Used for the two-factor sign-in setup, so
the authenticator app can scan the otpauth:// address. Standard library only:
PATCH-01 needs no extra package for it.

Follows the reference algorithm (data codewords, Reed-Solomon over GF(256),
interleaving, function patterns, the eight masks scored by the standard
penalty rules).
"""

# Level M: (total codewords, ecc codewords per block, blocks) for versions 1..10
_TABLE = {
    1: (26, 10, 1), 2: (44, 16, 1), 3: (70, 26, 1), 4: (100, 18, 2), 5: (134, 24, 2),
    6: (172, 16, 4), 7: (196, 18, 4), 8: (242, 22, 4), 9: (292, 22, 5), 10: (346, 26, 5),
}
_ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34],
          7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50]}
_ECL_M_BITS = 0  # format bits for level M


def _rs_generator(degree):
    # Coefficients of the generator polynomial, highest power first (excluding the leading 1)
    result = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            result[j] = _gf_mul(result[j], root)
            if j + 1 < degree:
                result[j] ^= result[j + 1]
        root = _gf_mul(root, 0x02)
    return result


def _gf_mul(x, y):
    z = 0
    for i in range(7, -1, -1):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z & 0xFF


def _rs_remainder(data, gen):
    result = [0] * len(gen)
    for b in data:
        factor = b ^ result.pop(0)
        result.append(0)
        for i, coef in enumerate(gen):
            result[i] ^= _gf_mul(coef, factor)
    return result


def _version_for(nbytes):
    for v in range(1, 11):
        total, ecc, blocks = _TABLE[v]
        data_cap = total - ecc * blocks
        count_bits = 8 if v < 10 else 16
        if 4 + count_bits + nbytes * 8 <= data_cap * 8:
            return v
    raise ValueError("text too long for a version 1-10 QR code")


def _codewords(data, version):
    total, ecc, nblocks = _TABLE[version]
    data_cap = total - ecc * nblocks
    count_bits = 8 if version < 10 else 16
    bits = []

    def put(val, n):
        for i in range(n - 1, -1, -1):
            bits.append((val >> i) & 1)
    put(0b0100, 4)
    put(len(data), count_bits)
    for b in data:
        put(b, 8)
    cap_bits = data_cap * 8
    put(0, min(4, cap_bits - len(bits)))
    put(0, (8 - len(bits) % 8) % 8)
    pad = 0xEC
    while len(bits) < cap_bits:
        put(pad, 8)
        pad ^= 0xEC ^ 0x11
    dcw = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    # Split into blocks (short blocks first), add ECC, interleave
    short_len = total // nblocks
    num_short = nblocks - total % nblocks
    gen = _rs_generator(ecc)
    blocks, k = [], 0
    for i in range(nblocks):
        dlen = short_len - ecc + (0 if i < num_short else 1)
        dat = dcw[k:k + dlen]
        k += dlen
        blocks.append((dat, _rs_remainder(dat, gen)))
    out = []
    maxd = max(len(b[0]) for b in blocks)
    for i in range(maxd):
        for dat, _ in blocks:
            if i < len(dat):
                out.append(dat[i])
    for i in range(ecc):
        for _, e in blocks:
            out.append(e[i])
    return out


class _Grid:
    def __init__(self, version):
        self.v = version
        self.n = version * 4 + 17
        self.m = [[False] * self.n for _ in range(self.n)]
        self.f = [[False] * self.n for _ in range(self.n)]   # function modules

    def set(self, x, y, dark, func=True):
        self.m[y][x] = dark
        if func:
            self.f[y][x] = True


def _draw_function(g):
    n = g.n
    for i in range(n):          # timing
        g.set(6, i, i % 2 == 0)
        g.set(i, 6, i % 2 == 0)
    for cx, cy in ((3, 3), (n - 4, 3), (3, n - 4)):   # finders with separators
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                x, y = cx + dx, cy + dy
                if 0 <= x < n and 0 <= y < n:
                    d = max(abs(dx), abs(dy))
                    g.set(x, y, d not in (2, 4))
    pos = _ALIGN[g.v]
    for i, a in enumerate(pos):
        for j, b in enumerate(pos):
            if (i == 0 and j == 0) or (i == 0 and j == len(pos) - 1) or (i == len(pos) - 1 and j == 0):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    g.set(a + dx, b + dy, max(abs(dx), abs(dy)) != 1)
    _draw_format(g, 0)          # reserve
    if g.v >= 7:
        rem = g.v
        for _ in range(12):
            rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
        bits = g.v << 12 | rem
        for i in range(18):
            bit = (bits >> i) & 1 == 1
            a, b = n - 11 + i % 3, i // 3
            g.set(a, b, bit)
            g.set(b, a, bit)


def _draw_format(g, mask):
    data = _ECL_M_BITS << 3 | mask
    rem = data
    for _ in range(10):
        rem = (rem << 1) ^ ((rem >> 9) * 0x537)
    bits = (data << 10 | rem) ^ 0x5412
    n = g.n
    for i in range(0, 6):
        g.set(8, i, (bits >> i) & 1 == 1)
    g.set(8, 7, (bits >> 6) & 1 == 1)
    g.set(8, 8, (bits >> 7) & 1 == 1)
    g.set(7, 8, (bits >> 8) & 1 == 1)
    for i in range(9, 15):
        g.set(14 - i, 8, (bits >> i) & 1 == 1)
    for i in range(0, 8):
        g.set(n - 1 - i, 8, (bits >> i) & 1 == 1)
    for i in range(8, 15):
        g.set(8, n - 15 + i, (bits >> i) & 1 == 1)
    g.set(8, n - 8, True)        # the dark module


def _draw_codewords(g, cw):
    n = g.n
    i = 0
    total_bits = len(cw) * 8
    right = n - 1
    while right >= 1:
        if right == 6:
            right = 5
        for vert in range(n):
            for j in range(2):
                x = right - j
                upward = ((right + 1) & 2) == 0
                y = n - 1 - vert if upward else vert
                if not g.f[y][x] and i < total_bits:
                    g.m[y][x] = (cw[i >> 3] >> (7 - (i & 7))) & 1 == 1
                    i += 1
        right -= 2


_MASKS = [
    lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0, lambda x, y: x % 3 == 0,
    lambda x, y: (x + y) % 3 == 0, lambda x, y: (x // 3 + y // 2) % 2 == 0,
    lambda x, y: x * y % 2 + x * y % 3 == 0, lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
    lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0,
]


def _apply_mask(g, k):
    fn = _MASKS[k]
    for y in range(g.n):
        for x in range(g.n):
            if not g.f[y][x] and fn(x, y):
                g.m[y][x] = not g.m[y][x]


def _penalty(g):
    n, m, score = g.n, g.m, 0
    for lines in (m, [list(c) for c in zip(*m)]):
        for row in lines:
            run, prev = 0, None
            for c in row:
                if c == prev:
                    run += 1
                    if run == 5:
                        score += 3
                    elif run > 5:
                        score += 1
                else:
                    run, prev = 1, c
            s = "".join("1" if c else "0" for c in row)
            for pat in ("10111010000", "00001011101"):
                score += 40 * s.count(pat)
    for y in range(n - 1):
        for x in range(n - 1):
            c = m[y][x]
            if c == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                score += 3
    dark = sum(sum(1 for c in row if c) for row in m)
    total = n * n
    k = (abs(dark * 20 - total * 10) + total - 1) // total - 1
    score += max(0, k) * 10
    return score


def matrix(text):
    data = text.encode("utf-8")
    v = _version_for(len(data))
    cw = _codewords(data, v)
    best, best_score = None, None
    for k in range(8):
        g = _Grid(v)
        _draw_function(g)
        _draw_codewords(g, cw)
        _apply_mask(g, k)
        _draw_format(g, k)
        s = _penalty(g)
        if best_score is None or s < best_score:
            best, best_score = g, s
    return best.m


def svg(text, scale=6, border=4):
    m = matrix(text)
    n = len(m)
    size = (n + 2 * border)
    parts = []
    for y in range(n):
        for x in range(n):
            if m[y][x]:
                parts.append(f"M{x + border},{y + border}h1v1h-1z")
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size}" width="{size * scale}" '
            f'height="{size * scale}" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/>'
            f'<path d="{"".join(parts)}" fill="#000"/></svg>')
