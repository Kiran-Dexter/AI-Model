"""The Vulnerabilities report: the new critical, high and exploited CVEs that really affect our
environment, with every machine and the evidence for it, and the appliances apart.

  Excel  Summary (figures, by severity, by platform, products), Affected CVEs, Affected machines
         (one row per CVE and machine), Appliances
  PDF    the affected CVEs, each with its machines; then the appliances
  CSV    one row per CVE and machine
"""

SEV_ORDER = ("0-day", "Critical", "High", "Medium or lower")
CVE_HEADERS = ["CVE", "Severity", "CVSS", "Exploited (0-day)", "Machines", "Platforms", "Products", "Published", "Title"]
MACHINE_HEADERS = ["CVE", "Severity", "Machine", "Address", "Platform", "Operating system", "Product", "Installed",
                   "Fixed in", "Evidence", "Restart only"]
APPL_HEADERS = ["CVE", "Severity", "Device", "Address", "Type", "Maker and model", "Firmware", "State", "Detail"]
PDF_HEADERS = ["Machine", "Address", "Platform", "Product", "Installed", "Fixed in", "Evidence"]


def _sev(i):
    from .cve_impact import _sev as s
    return s(i)


def _sev_text(i):
    s = _sev(i)
    return s + (f" {float(i['cvss']):.1f}" if i.get("cvss") is not None else "")


def _day(v, tz):
    if not v:
        return ""
    if hasattr(v, "astimezone") and getattr(v, "tzinfo", None):
        v = v.astimezone(tz)
    return v.strftime("%Y-%m-%d") if hasattr(v, "strftime") else str(v)[:10]


def _platforms(i):
    return ", ".join(sorted({m.get("platform") or m.get("where") or "" for m in i.get("matches") or []} - {""}))


def _products(i):
    out = []
    for m in i.get("matches") or []:
        for p in m.get("products") or [m.get("product")]:
            if p and p not in out:
                out.append(p)
    return ", ".join(out[:8])


def cve_rows(items, tz):
    return [[i["cve_id"], _sev(i), i.get("cvss"), "yes" if i.get("exploited") else "", i.get("machines") or 0,
             _platforms(i), _products(i), _day(i.get("published"), tz), i.get("title") or ""] for i in items]


def machine_rows(items):
    rows = []
    for i in items:
        for m in i.get("matches") or []:
            rows.append([i["cve_id"], _sev_text(i), m.get("name") or "", m.get("ip") or "", m.get("platform") or m.get("where") or "",
                         m.get("os") or "", m.get("product") or "", m.get("version") or "", m.get("fixed") or "",
                         m.get("detail") or "", "yes" if m.get("restart") else ""])
    return rows


def appliance_rows(appl):
    rows = []
    for i in appl:
        for x in i.get("appliances") or []:
            rows.append([i["cve_id"], _sev_text(i), x.get("name") or "", x.get("ip") or "", x.get("type") or "",
                         x.get("device") or "", x.get("version") or "",
                         "Affected" if x.get("state") == "affected" else "To check", x.get("detail") or ""])
    return rows


def render(conn, fmt, user, days, items, appl, counts, tz):
    """(bytes, media type, extension, rows)."""
    from . import cve_impact, exports as ex
    title = "Vulnerabilities in our environment"
    filt = (f"new critical, high and exploited CVEs of the last {days} days; only those proven on our machines "
            f"(and, apart, those naming an appliance)")
    mrows = machine_rows(items)
    if fmt == "csv":
        m = ex.meta(title, user, filt, len(mrows), ex.company_name(conn))
        return ex.csv_text(m, MACHINE_HEADERS, mrows).encode("utf-8"), "text/csv; charset=utf-8", "csv", len(mrows)
    logo, cls, accent = ex.brand_bits(conn)
    if fmt == "pdf":
        rows, heads = [], []
        for i in items:
            heads.append(len(rows))
            rows.append([i["cve_id"], _sev_text(i) + (" · exploited" if i.get("exploited") else ""),
                         f"{i.get('machines') or 0} machine(s)", (i.get("title") or "")[:140], "", "", ""])
            for mm in i.get("matches") or []:
                rows.append([mm.get("name") or "", mm.get("ip") or "", mm.get("platform") or mm.get("where") or "",
                             mm.get("product") or "", mm.get("version") or "", mm.get("fixed") or "",
                             (mm.get("detail") or "") + (" (restart only)" if mm.get("restart") else "")])
        ar = appliance_rows(appl)
        if ar:
            heads.append(len(rows))
            rows.append(["Appliances", f"{len(ar)} device finding(s)", "", "", "", "", ""])
            for r in ar:
                rows.append([r[2], r[3], r[4] + (" · " + r[5] if r[5] else ""), r[0] + " " + r[1], r[6], r[7], r[8]])
        m = ex.meta(title, user, filt, len(items), ex.company_name(conn))
        return ex.pdf_bytes(m, PDF_HEADERS, rows, logo, cls, accent, heads=heads), "application/pdf", "pdf", len(items)
    g = cve_impact.graphs(conn, days, items)
    summ = [["Affected CVEs", counts.get("affected") or 0], ["Exploited (0-day) among them", counts.get("exploited_impacting") or 0],
            ["Machines affected", g["machines"]], ["Appliance findings, affected", counts.get("appliances_affected") or 0],
            ["Appliance findings, to check", counts.get("appliances_check") or 0], ["CVEs checked", counts.get("checked") or 0],
            ["", ""], ["By severity", ""]] + [[x["label"], x["n"]] for x in g["severity"]] \
        + [["", ""], ["Machines by platform", ""]] + [[x["label"], x["n"]] for x in g["platforms"]] \
        + [["", ""], ["Products on most machines", ""]] + [[x["label"], x["n"]] for x in g["products"]]
    sheets = [
        {"name": "Summary", "headers": ["Figure", "Count"], "rows": summ,
         "note": "Only proven findings: a version compared with the vendor's fixed build or NVD's affected range, "
                 "a vendor's 'affected, no fix yet' for the machine's release, or Windows Update reporting the fix missing."},
        {"name": "Affected CVEs", "headers": CVE_HEADERS, "rows": cve_rows(items, tz), "filter": True},
        {"name": "Affected machines", "headers": MACHINE_HEADERS, "rows": mrows, "filter": True},
        {"name": "Appliances", "headers": APPL_HEADERS, "rows": appliance_rows(appl), "filter": True,
         "note": "Affected: the firmware version recorded for the device is in NVD's affected range. To check: the device "
                 "matches the product but its firmware version is not recorded in the inventory."},
    ]
    m = ex.meta(title, user, filt, len(items), ex.company_name(conn))
    return (ex.xlsx_workbook(m, sheets, logo), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx",
            len(items))
