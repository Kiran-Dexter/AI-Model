"""Patch Reports: what each finished patch job did on each server, checked
against what the server itself says is installed.

Four views of the same jobs:
  jobs     one row per patch job (CHG): servers, results, updates installed
  groups   one row per patch group: its servers' results over the period
  summary  one row per server per patch job (result, counts, restart, snapshot)
  patches  one row per Windows update (KB) or Linux package the job handled

Built from the change records (changes, change_targets, change_events) and
then checked against the server's own record: the Windows agents' installed
updates list (KB and date, schema 040) and the Linux package inventory. So an
update that went in although the job stopped waiting (a very long install, a
lost answer) shows as installed, marked "confirmed on the server", and an
update the job reported installed but the server no longer has is flagged.
"""

from datetime import datetime, timezone

from .servers import OS_LABEL

DAYS = (1, 7, 14, 30, 90, 180, 365)
RESULTS = ("ok", "warnings", "failed", "nothing")
VIEWS = ("jobs", "groups", "summary", "patches")
MAX_TARGETS = 3000

RESULT_LABEL = {"ok": "Patched", "warnings": "Patched, with warnings", "failed": "Failed",
                "nothing": "Nothing to install", "skipped": "Skipped", "cancelled": "Cancelled"}

# Patch statuses. "Installed" is the only good one; the others are counted as not installed.
INSTALLED = "Installed"
FAILED = "Failed"
NOT_INSTALLED = "Not installed"
GONE = "Not found after restart"
BUSY = "Was still installing"
ALREADY = "Already installed"        # before this job (WSUS, an earlier job, by hand): not a problem
PROBLEM = (FAILED, NOT_INSTALLED, GONE, BUSY)

_SQL = f"""
SELECT 'CHG-' || lpad(c.number::text, 6, '0') AS ref, c.number, c.id::text AS change_id, ct.host_id::text AS host_id, ct.target_key,
       c.title AS change_title, c.params, c.requested_by, c.started_at AS change_started,
       coalesce(c.finished_at, ct.updated_at) AS finished_at,
       ct.state, ct.label, ct.detail, ct.error, ct.snapshot_moref,
       h.hostname, h.os_id, h.host_group, h.pkg_manager::text AS pkg_manager, h.reboot_required AS needs_restart_now,
       {OS_LABEL} AS os_label,
       (SELECT min(e.at) FROM change_events e WHERE e.change_id = c.id AND e.target_key = ct.target_key) AS first_at,
       (SELECT max(e.at) FROM change_events e WHERE e.change_id = c.id AND e.target_key = ct.target_key) AS last_at,
       (SELECT max(e.at) FROM change_events e WHERE e.change_id = c.id AND e.target_key = ct.target_key
                  AND e.event = 'install' AND e.ok IS TRUE) AS installed_at,
       (SELECT max(e.at) FROM change_events e WHERE e.change_id = c.id AND e.target_key = ct.target_key
                  AND e.event = 'wait_boot' AND e.ok IS TRUE) AS back_at,
       EXISTS (SELECT 1 FROM change_events e WHERE e.change_id = c.id AND e.target_key = ct.target_key
                  AND e.event = 'snapshot_removed' AND e.ok IS TRUE) AS snapshot_removed,
       EXISTS (SELECT 1 FROM change_events e WHERE e.change_id = c.id AND e.target_key = ct.target_key
                  AND e.event = 'snapshot' AND e.ok IS TRUE) AS snapshot_taken
  FROM change_targets ct
  JOIN changes c ON c.id = ct.change_id
  LEFT JOIN hosts h ON h.id = ct.host_id
 WHERE c.kind = 'patch'
   AND ct.state IN ('done', 'done_with_warnings', 'failed')
   AND coalesce(c.finished_at, ct.updated_at) > now() - make_interval(days => %(days)s)
   AND (%(change)s::bigint IS NULL OR c.number = %(change)s::bigint)
   AND (%(grp)s::text IS NULL OR h.host_group = %(grp)s::text)
   AND (%(q)s::text IS NULL OR strpos(lower(ct.label || ' ' || coalesce(h.hostname, '') || ' ' || c.title || ' CHG-'
                                              || lpad(c.number::text, 6, '0') || ' ' || coalesce(h.host_group, '')), lower(%(q)s::text)) > 0)
 ORDER BY coalesce(c.finished_at, ct.updated_at) DESC, ct.label
 LIMIT {MAX_TARGETS}"""


def clean_filters(days=None, os=None, result=None, q=None, change=None, group=None):
    try:
        d = int(days) if days not in (None, "") else 30
    except (TypeError, ValueError):
        d = 30
    d = d if d in DAYS else 30
    os = os if os in ("windows", "linux") else None
    result = result if result in RESULTS else None
    q = (str(q).strip()[:100] or None) if q else None
    n = None
    if change:
        digits = "".join(ch for ch in str(change) if ch.isdigit())[:12]
        n = int(digits) if digits else None
    g = str(group).strip()[:60] if group else None
    return {"days": d, "os": os, "result": result, "q": q, "change": n, "group": g or None}


def describe(f):
    bits = [f"last {f['days']} day" + ("s" if f["days"] != 1 else "")]
    if f.get("group"):
        bits.append(f"group {f['group']}")
    if f.get("os"):
        bits.append("Windows" if f["os"] == "windows" else "Linux")
    if f.get("result"):
        bits.append(RESULT_LABEL[f["result"]].lower())
    if f.get("change"):
        bits.append(f"CHG-{f['change']:06d}")
    if f.get("q"):
        bits.append(f'"{f["q"]}"')
    return "; ".join(bits)


def _list(v):
    return [x for x in v if isinstance(x, dict)] if isinstance(v, list) else []


def _upper(v):
    return str(v or "").strip().upper()


def _ts(v):
    if isinstance(v, str):
        try:
            v = datetime.fromisoformat(v.replace(" ", "T").replace("Z", "+00:00"))
        except ValueError:
            return None
    if isinstance(v, datetime) and v.tzinfo is None:
        v = v.replace(tzinfo=timezone.utc)
    return v


def _minutes(a, b):
    a, b = _ts(a), _ts(b)
    if not a or not b:
        return None
    try:
        return max(0, int((b - a).total_seconds() // 60))
    except Exception:  # noqa: BLE001 - strings from a test shim
        return None


# ---------------------------------------------------------------------------
# What the servers themselves say is installed
# ---------------------------------------------------------------------------

def server_truth(conn, raw):
    """{host_id: {KB: installed_on}} for Windows, {host_id: {package: (e, v, r)}}
    for Linux, for the servers and packages in these rows."""
    win_hosts = sorted({r["host_id"] for r in raw if r["host_id"] and (r["os_id"] or "") == "windows"})
    lin = [r for r in raw if r["host_id"] and (r["os_id"] or "") != "windows"]
    win, linux = {}, {}
    if win_hosts:
        try:
            with conn.transaction():
                for x in conn.execute(
                        """SELECT host_id::text AS host_id, upper(kb) AS kb, max(installed_on) AS installed_on
                             FROM windows_installed_updates
                            WHERE host_id = ANY(%s::uuid[]) AND kb IS NOT NULL
                              AND coalesce(result, 'Succeeded') NOT ILIKE '%%fail%%'
                            GROUP BY 1, 2""", (win_hosts,)).fetchall():
                    win.setdefault(x["host_id"], {})[x["kb"]] = x["installed_on"] or True
        except Exception:  # noqa: BLE001 - schema 040 not applied: the job's own record only
            win = {}
        # Older agents: the KBs in the inventory (no dates)
        for x in conn.execute(
                """SELECT host_id::text AS host_id, upper(name) AS kb FROM host_packages
                    WHERE host_id = ANY(%s::uuid[]) AND name LIKE 'kb%%'""", (win_hosts,)).fetchall():
            win.setdefault(x["host_id"], {}).setdefault(x["kb"], True)
    if lin:
        hosts = sorted({r["host_id"] for r in lin})
        names = sorted({str(p.get("name")) for r in lin for p in _list((r["detail"] or {}).get("packages")) if p.get("name")})
        if names:
            for x in conn.execute(
                    """SELECT host_id::text AS host_id, name, epoch, version, release FROM host_packages
                        WHERE host_id = ANY(%s::uuid[]) AND name = ANY(%s)""", (hosts, names[:20000])).fetchall():
                cur = linux.setdefault(x["host_id"], {}).get(x["name"])
                v = (str(x["epoch"] or 0), x["version"], x["release"] or "")
                # Several architectures of one package: the lowest counts (all must be fixed)
                linux[x["host_id"]][x["name"]] = v if cur is None else min(cur, v)
    return win, linux


def _split_evr(evr):
    e, _, rest = evr.partition(":") if ":" in evr else ("0", "", evr)
    v, _, r = rest.rpartition("-") if "-" in rest else (rest, "", "")
    return (e or "0", v, r)


def _linux_has(have, wanted, pkg_manager):
    """Is the installed (e, v, r) at least the job's version?"""
    if not have or not wanted:
        return None
    from .evr import rpm_label_compare, deb_compare
    cmp = deb_compare if pkg_manager == "apt" else rpm_label_compare
    try:
        return cmp(*have, *_split_evr(str(wanted))) >= 0
    except Exception:  # noqa: BLE001 - an unparseable version: unknown, never a guess
        return None


def _result_key(state, installed, nothing):
    if state == "failed":
        return "failed"
    if nothing and not installed:
        return "nothing"
    return "warnings" if state == "done_with_warnings" else "ok"


def _restart(r, d, key):
    """How the restart went for this server in this job."""
    planned = (r["params"] or {}).get("reboot_at") if isinstance(r["params"], dict) else None
    asked = d.get("reboot_requested_at")
    if asked:
        return "Restarted", asked, planned
    inst = d.get("install") if isinstance(d.get("install"), dict) else {}
    late = d.get("late_result") if isinstance(d.get("late_result"), dict) else {}
    if inst.get("reboot_required") or late.get("reboot_required"):
        return ("Restart needed" if r["needs_restart_now"] is not False else "Restarted later"), None, planned
    if key == "nothing":
        return "Not needed", None, planned
    reboot = (r["params"] or {}).get("reboot") if isinstance(r["params"], dict) else None
    return ("Not restarted (job setting)" if reboot == "never" else "Not needed"), None, planned


def _target(r, win_truth, lin_truth):
    """One finished server of one job: the summary row and its patch rows."""
    d = r["detail"] or {}
    windows = (r["os_id"] or "") == "windows"
    inst = d.get("install") if isinstance(d.get("install"), dict) else {}
    post = d.get("postcheck") if isinstance(d.get("postcheck"), dict) else {}
    nothing = bool(d.get("nothing_to_do") or inst.get("nothing_to_do"))
    started = _ts(r["first_at"] or r["change_started"])
    patches = []
    if windows:
        truth = win_truth.get(r["host_id"], {})

        def before_job(kb):
            """The server had this KB before the job started."""
            if not kb or kb not in truth or truth[kb] is True or not started:
                return False
            when = _ts(truth[kb])
            return bool(when) and when.date() < started.date()

        def on_server(kb):
            """When the server says it installed this KB (during or after this job), else None."""
            if not kb or kb not in truth:
                return None
            when = truth[kb]
            if when is True:
                return True
            when = _ts(when)
            # Installed before this job started: it was not this job's doing
            return when if not started or not when or when.date() >= started.date() else None

        missing_after = {_upper(x) for x in (post.get("updates_not_installed") or []) if x}
        seen = set()

        def add(kb, title, status, src):
            k = kb or _upper(title)
            if k in seen:
                return
            seen.add(k)
            srv = on_server(kb)
            if status == NOT_INSTALLED and before_job(kb):
                status, src = ALREADY, "server"            # it was there before the job: nothing to do
            if status != INSTALLED and status != ALREADY and srv:
                status, src = INSTALLED, "server"          # the job lost track; the server has it
            confirmed = bool(srv) if kb and truth else None
            if status == INSTALLED and kb and truth and not srv and kb not in truth:
                confirmed = False                          # reported installed, the server's list lacks it
            patches.append({"patch": kb or "update", "description": str(title or ""), "status": status,
                            "installed_on": srv if isinstance(srv, datetime) else None,
                            "confirmed": confirmed, "source": src})

        for x in _list(inst.get("installed")):
            kb = _upper(x.get("kb")) or None
            gone = (kb and kb in missing_after) or _upper(x.get("title")) in missing_after
            add(kb, x.get("title") or x.get("id"), GONE if gone else INSTALLED, "job")
        for x in _list(inst.get("failed")):
            add(_upper(x.get("kb")) or None, x.get("title") or x.get("id"), FAILED, "job")
        for x in _list(inst.get("still_installing")):
            add(_upper(x.get("kb")) or None, x.get("title") or x.get("id"), BUSY, "job")
        for x in _list(inst.get("already")):
            add(_upper(x.get("kb")) or None, x.get("title") or x.get("id"), ALREADY, "job")
        # The job's planned updates the install never answered for (it stopped, timed out, failed early).
        # When the install did answer and the job did not fail, an update it left out was rightly
        # skipped (already there, replaced or declined in WSUS since): not listed as missing
        answered = bool(inst) or isinstance(d.get("late_result"), dict)
        if not nothing and (not answered or r["state"] == "failed"):
            for x in _list(d.get("windows_updates")):
                add(_upper(x.get("kb")) or None, x.get("title"), NOT_INSTALLED, "plan")
    else:
        adv = d.get("package_advisories") if isinstance(d.get("package_advisories"), dict) else {}
        truth = lin_truth.get(r["host_id"], {})
        for x in _list(d.get("packages")):
            name = str(x.get("name") or "")
            want = x.get("version")
            has = _linux_has(truth.get(name), want, r["pkg_manager"])
            if r["installed_at"]:
                status, src = INSTALLED, "job"
            elif has:
                status, src = INSTALLED, "server"
            else:
                status, src = NOT_INSTALLED, "job"
            patches.append({"patch": name, "description": "version " + str(want or "?"),
                            "advisories": ", ".join(adv.get(name) or []), "status": status,
                            "installed_on": r["installed_at"] if src == "job" else None,
                            "confirmed": has, "source": src})
    n_ok = sum(1 for p in patches if p["status"] == INSTALLED)
    n_bad = sum(1 for p in patches if p["status"] in PROBLEM)
    n_conf = sum(1 for p in patches if p["status"] == INSTALLED and p["confirmed"])
    key = _result_key(r["state"], n_ok, nothing)
    warnings = [str(w) for w in (d.get("warnings") or []) if w]
    late = d.get("late_result") if isinstance(d.get("late_result"), dict) else None
    notes = r["error"] or "; ".join(warnings[:6])
    if late:
        notes = (notes + "; " if notes else "") + f"the agent answered later: {late.get('installed', 0)} installed"
    if any(p["source"] == "server" for p in patches):
        notes = (notes + "; " if notes else "") + "some updates were found installed on the server although the job did not record them"
    if r["snapshot_moref"]:
        snap = "Kept"
    elif r["snapshot_removed"]:
        snap = "Taken, removed"
    elif r["snapshot_taken"]:
        snap = "Taken"
    else:
        snap = "None"
    restart, restarted_at, planned = _restart(r, d, key)
    summary = {
        "finished_at": r["finished_at"], "started_at": r["first_at"], "ref": r["ref"], "change_title": r["change_title"],
        "change_id": r["change_id"], "host_id": r["host_id"], "target_key": r["target_key"], "requested_by": r["requested_by"],
        "server": r["hostname"] or r["label"], "os": r["os_label"] or "", "os_kind": "windows" if windows else "linux",
        "group": r["host_group"] or "", "result": key, "result_label": RESULT_LABEL[key],
        "installed": n_ok, "failed": n_bad, "confirmed": n_conf,
        "reboot": restart, "restarted_at": restarted_at, "restart_planned": planned, "back_at": r["back_at"],
        "needs_restart_now": bool(r["needs_restart_now"]),
        "snapshot": snap, "minutes": _minutes(r["first_at"], r["last_at"]),
        "install_minutes": _minutes(r["first_at"], r["installed_at"]), "notes": notes or "",
        "warnings": warnings[:40], "error": r["error"] or "",
        "explain": d.get("explain") if isinstance(d.get("explain"), dict) else None,
    }
    rows = [dict(p, finished_at=r["finished_at"], ref=r["ref"], change_id=r["change_id"], server=summary["server"],
                 host_id=r["host_id"], os=summary["os"], os_kind=summary["os_kind"], group=summary["group"], result=key)
            for p in patches]
    return summary, rows


def collect(conn, f):
    """(summary rows, patch rows, info) for the filters, newest first. info has
    the totals before the result filter (so the result tiles keep their counts),
    the per-job and per-group roll-ups, and whether the newest-jobs limit cut the list."""
    raw = [dict(r) for r in conn.execute(_SQL, {"days": f["days"], "change": f["change"], "q": f["q"],
                                                 "grp": f.get("group")}).fetchall()]
    win, lin = server_truth(conn, raw)
    every_s, every_p = [], []
    for r in raw:
        s, p = _target(r, win, lin)
        if f["os"] and s["os_kind"] != f["os"]:
            continue
        every_s.append(s)
        every_p.extend(p)
    info = {"totals": totals(every_s, every_p), "limited": len(raw) >= MAX_TARGETS}
    if f["result"]:
        keep = {(s["ref"], s["server"]) for s in every_s if s["result"] == f["result"]}
        every_s = [s for s in every_s if (s["ref"], s["server"]) in keep]
        every_p = [p for p in every_p if (p["ref"], p["server"]) in keep]
    info["jobs"] = rollup(every_s, "ref")
    info["groups"] = rollup(every_s, "group")
    return every_s, every_p, info


def rollup(summary, by):
    """One row per job (by="ref") or per patch group (by="group")."""
    out, idx = [], {}
    for s in summary:
        k = s[by] or ""
        if k not in idx:
            idx[k] = len(out)
            out.append({"key": k, "ref": s["ref"] if by == "ref" else None, "change_id": s["change_id"] if by == "ref" else None,
                        "title": s["change_title"] if by == "ref" else None, "requested_by": s["requested_by"] if by == "ref" else None,
                        "group": k if by == "group" else None, "servers": 0, "ok": 0, "warnings": 0, "failed": 0, "nothing": 0,
                        "installed": 0, "not_installed": 0, "confirmed": 0, "restarted": 0, "restart_needed": 0,
                        "started_at": s["started_at"], "finished_at": s["finished_at"], "jobs": set(), "hosts": set()})
        o = out[idx[k]]
        o["hosts"].add(s["host_id"] or s["server"])
        o["jobs"].add(s["ref"])
        o[s["result"]] += 1
        o["installed"] += s["installed"]
        o["not_installed"] += s["failed"]
        o["confirmed"] += s["confirmed"]
        o["restarted"] += 1 if s["reboot"] == "Restarted" else 0
        o["restart_needed"] += 1 if s["reboot"] == "Restart needed" else 0
        if s["started_at"] and (not o["started_at"] or str(s["started_at"]) < str(o["started_at"])):
            o["started_at"] = s["started_at"]
        if s["finished_at"] and (not o["finished_at"] or str(s["finished_at"]) > str(o["finished_at"])):
            o["finished_at"] = s["finished_at"]
    for o in out:
        o["servers"] = len(o.pop("hosts"))
        o["jobs"] = len(o.pop("jobs"))
    if by == "group":
        out.sort(key=lambda o: (o["key"] == "", o["key"].lower()))
    return out


def totals(summary, patches):
    return {
        "servers": len({s["host_id"] or s["server"] for s in summary}),
        "jobs": len({s["ref"] for s in summary}),
        "groups": len({s["group"] for s in summary if s["group"]}),
        "ok": sum(1 for s in summary if s["result"] == "ok"),
        "warnings": sum(1 for s in summary if s["result"] == "warnings"),
        "failed": sum(1 for s in summary if s["result"] == "failed"),
        "nothing": sum(1 for s in summary if s["result"] == "nothing"),
        "patches_installed": sum(1 for p in patches if p["status"] == INSTALLED),
        "patches_problem": sum(1 for p in patches if p["status"] in PROBLEM),
        "patches_confirmed": sum(1 for p in patches if p["status"] == INSTALLED and p["confirmed"]),
        "restart_needed": sum(1 for s in summary if s["reboot"] == "Restart needed"),
        "windows": sum(1 for s in summary if s["os_kind"] == "windows"),
        "linux": sum(1 for s in summary if s["os_kind"] == "linux"),
    }


# ---------------------------------------------------------------------------
# Table form, for PDF, CSV, Excel and e-mail
# ---------------------------------------------------------------------------

SUMMARY_HEADERS = ["Finished", "Change", "Group", "Server", "Operating system", "Result", "Installed", "Not installed",
                   "Confirmed on server", "Restart", "Restarted at", "Snapshot", "Minutes", "Notes"]
PATCH_HEADERS = ["Finished", "Change", "Group", "Server", "Operating system", "Update / package", "Description",
                 "Update notice", "Status", "Installed on", "Confirmed on server"]
JOB_HEADERS = ["Change", "Title", "Requested by", "Started", "Finished", "Servers", "Patched", "With warnings",
               "Failed", "Nothing to install", "Updates installed", "Not installed", "Restarted", "Restart needed"]
GROUP_HEADERS = ["Patch group", "Jobs", "Servers", "Patched", "With warnings", "Failed", "Nothing to install",
                 "Updates installed", "Not installed", "Restart needed", "Last finished"]


def _when(v, tz):
    if v is None or v is True or v == "":
        return ""
    if isinstance(v, str):
        try:
            v = datetime.fromisoformat(v.replace(" ", "T").replace("Z", "+00:00"))
        except ValueError:
            return v[:16]
    if v.tzinfo is None:
        v = v.replace(tzinfo=timezone.utc)
    return v.astimezone(tz).strftime("%Y-%m-%d %H:%M")


def _yes(v):
    return "Yes" if v is True else "No" if v is False else ""


def summary_table(summary, tz):
    return SUMMARY_HEADERS, [[_when(s["finished_at"], tz), s["ref"], s["group"], s["server"], s["os"], s["result_label"],
                              s["installed"], s["failed"], s["confirmed"], s["reboot"], _when(s["restarted_at"], tz),
                              s["snapshot"], "" if s["minutes"] is None else s["minutes"], s["notes"][:600]] for s in summary]


def patch_table(patches, tz):
    return PATCH_HEADERS, [[_when(p["finished_at"], tz), p["ref"], p["group"], p["server"], p["os"], p["patch"],
                            p["description"][:300], p.get("advisories") or "", p["status"],
                            _when(p.get("installed_on"), tz), _yes(p.get("confirmed"))] for p in patches]


def job_table(jobs, tz):
    return JOB_HEADERS, [[j["ref"], j["title"] or "", j["requested_by"] or "", _when(j["started_at"], tz), _when(j["finished_at"], tz),
                          j["servers"], j["ok"], j["warnings"], j["failed"], j["nothing"], j["installed"], j["not_installed"],
                          j["restarted"], j["restart_needed"]] for j in jobs]


def group_table(groups, tz):
    return GROUP_HEADERS, [[g["key"] or "(no group)", g["jobs"], g["servers"], g["ok"], g["warnings"], g["failed"], g["nothing"],
                            g["installed"], g["not_installed"], g["restart_needed"], _when(g["finished_at"], tz)] for g in groups]


def table_for(view, summary, patches, info, tz):
    if view == "patches":
        return patch_table(patches, tz), "Patch report, installed updates and packages"
    if view == "jobs":
        return job_table(info["jobs"], tz), "Patch report, by job"
    if view == "groups":
        return group_table(info["groups"], tz), "Patch report, by patch group"
    return summary_table(summary, tz), "Patch report, servers"


def build_report(conn, params, tz, view):
    """For report_jobs: the server-built Patch report (e-mail now or on a schedule)."""
    f = clean_filters(params.get("days", 7), params.get("os"), params.get("result"), params.get("q"), params.get("change"),
                      params.get("group"))
    summary, patches, info = collect(conn, f)
    t = info["totals"]
    (headers, rows), title = table_for(view if view in VIEWS else "summary", summary, patches, info, tz)
    if view == "patches":
        preview = ([headers[3], headers[5], headers[6], headers[8]], [[r[3], r[5], r[6], r[8]] for r in rows])
    elif view == "jobs":
        preview = ([headers[0], headers[1], headers[5], headers[8], headers[10]], [[r[0], r[1], r[5], r[8], r[10]] for r in rows])
    elif view == "groups":
        preview = ([headers[0], headers[2], headers[5], headers[7]], [[r[0], r[2], r[5], r[7]] for r in rows])
    else:
        rank = {"Failed": 0, "Patched, with warnings": 1}
        rows = sorted(rows, key=lambda x: rank.get(x[5], 2))       # problems first (stable: newest first within)
        preview = ([headers[1], headers[3], headers[5], headers[6], headers[7]], [[r[1], r[3], r[5], r[6], r[7]] for r in rows])
    sev = "critical" if t["failed"] else "warning" if t["warnings"] else "ok" if summary else "info"
    intro = (f"Patching results for the {describe(f)}: {t['servers']} servers in {t['jobs']} patch jobs; "
             f"{t['ok']} patched, {t['warnings']} patched with warnings, {t['failed']} failed, "
             f"{t['nothing']} had nothing to install. {t['patches_installed']} updates or packages installed"
             + (f" ({t['patches_confirmed']} confirmed on the servers)" if t["patches_confirmed"] else "")
             + (f", {t['patches_problem']} not installed." if t["patches_problem"] else ".")
             + (f" {t['restart_needed']} server(s) still need a restart." if t["restart_needed"] else ""))
    return {"title": title, "headers": headers, "rows": rows, "filter": describe(f), "intro": intro,
            "action": "Review the failed servers and the updates not installed; each job's page has the step that stopped."
                      if t["failed"] or t["patches_problem"] else None,
            "stats": [("Patched", t["ok"], "ok"), ("With warnings", t["warnings"], "warning" if t["warnings"] else "ok"),
                      ("Failed", t["failed"], "critical" if t["failed"] else "ok"), ("Installed", t["patches_installed"], "info")],
            "severity": sev, "preview": preview}
