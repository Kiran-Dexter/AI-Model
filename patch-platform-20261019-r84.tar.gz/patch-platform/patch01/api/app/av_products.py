"""The products each Apex Central manages, and Deep Security Managers read
directly. Read-only, like the rest of the antivirus code.

Discovery: Apex Central's Automation API lists its product servers (GET
/WebApp/API/ServerResource/ProductServers): Apex One servers, Deep Security
Managers, email security products and others. An admin ticks which to sync;
from then on only the agents those servers manage are kept from Apex
Central's agent list.

Deep Security Manager (optional, per Manager): its own API (GET /api/computers,
headers api-secret-key and api-version: v1) gives each computer's status,
platform and last contact. When a Manager is read directly, its agents come
from the Manager and Apex Central's copies of them are left out, so nothing
is counted twice. The API key is encrypted like the Apex key, the address is
checked like an Apex console's (no loopback, link-local or metadata
addresses), and the certificate is verified (public CA, a pasted CA, or a
pinned self-signed certificate checked by its SHA-256 fingerprint).
"""

import json
import logging
import re
import time
import urllib.parse
from datetime import datetime, timezone

from . import antivirus as av

log = logging.getLogger("patchapi.av_products")

PRODUCTS_PATH = "/WebApp/API/ServerResource/ProductServers"
DSM_COMPUTERS = "/api/computers?expand=computerStatus&expand=securityUpdates"
DSM_KEY_RE = re.compile(r"^[A-Za-z0-9:+/=_.-]{20,300}$")
KINDS = (
    (re.compile(r"DEEP_?SECURITY|(?<![A-Z0-9])DSM(?![A-Z0-9])|WORKLOAD", re.I), "deep_security"),
    (re.compile(r"OFFICESCAN|APEX_?ONE|(?<![A-Z0-9])OSCE(?![A-Z0-9])|ENDPOINT_?ENCRYPTION|VULNERABILITY_?PROTECTION", re.I), "endpoint"),
    (re.compile(r"DDEI|IMSVA|IMSS|SCAN_?MAIL|SMEX|SMLD|EMAIL|MAIL|MESSAGING|(?<![A-Z0-9])CAS(?![A-Z0-9])|CLOUD_?APP", re.I), "email"),
)
KIND_LABEL = {"endpoint": "Apex One server", "deep_security": "Deep Security Manager", "email": "Email security", "other": "Other product"}


def kind_of(product):
    p = str(product or "")
    for rx, k in KINDS:
        if rx.search(p):
            return k
    return "other"


PRODUCT_NAMES = {"OFFICESCAN_CE": "Apex One (OfficeScan)", "APEX_ONE": "Apex One", "HEADLESS_DSM": "Deep Security",
                 "DEEPSECURITY": "Deep Security", "DEEP_SECURITY": "Deep Security", "IMSVA": "InterScan Messaging (IMSVA)",
                 "DDEI": "Deep Discovery Email Inspector", "SCANMAIL_EXCHANGE": "ScanMail for Exchange", "SMEX": "ScanMail for Exchange",
                 "CAS": "Cloud App Security"}


def product_label(product):
    """A readable name for a product code such as SLF_PRODUCT_DEEPSECURITY."""
    code = re.sub(r"^SLF_PRODUCT_", "", str(product or ""), flags=re.I).upper()
    if code in PRODUCT_NAMES:
        return PRODUCT_NAMES[code]
    p = re.sub(r"^SLF_PRODUCT_", "", str(product or ""), flags=re.I).replace("_", " ").strip()
    return (p.title() if p.isupper() else p)[:80] or "Unknown product"


def parse_products(doc):
    rc = doc.get("result_content") or []
    if not isinstance(rc, list):
        raise av.AvError("Apex Central's product list has an unexpected shape.")
    out = []
    for x in rc[:2000]:
        if not isinstance(x, dict) or not x.get("entity_id"):
            continue
        product = str(x.get("product") or "")[:120]
        out.append({"entity_id": str(x["entity_id"])[:120], "product": product, "kind": kind_of(product),
                    "host_name": str(x.get("host_name") or "")[:255] or None,
                    "ad_domain": str(x.get("ad_domain") or "")[:255] or None,
                    "ip_addresses": [ip for ip in av._strs(x.get("ip_address_list"), 16, 45) if av._is_ip(ip)],
                    "capabilities": av._strs(x.get("capabilities"), 40, 60)})
    return out


def discover(conn, cid):
    """Read the console's product servers and keep them (the admin's choices stay)."""
    c = conn.execute("SELECT * FROM av_consoles WHERE id = %s", (cid,)).fetchone()
    if not c:
        raise av.AvError("No such console.")
    c = dict(c)
    conn.commit()                                     # nothing held open while Apex Central answers
    items = parse_products(av._get(c, av.decrypt(c["api_key_enc"]), PRODUCTS_PATH))
    with conn.transaction():
        for p in items:
            conn.execute(
                """INSERT INTO av_products (console_id, entity_id, product, kind, host_name, ad_domain, ip_addresses, capabilities)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                   ON CONFLICT (console_id, entity_id) DO UPDATE SET product = EXCLUDED.product, kind = EXCLUDED.kind,
                       host_name = EXCLUDED.host_name, ad_domain = EXCLUDED.ad_domain, ip_addresses = EXCLUDED.ip_addresses,
                       capabilities = EXCLUDED.capabilities, last_seen = now(), gone_at = NULL""",
                (cid, p["entity_id"], p["product"], p["kind"], p["host_name"], p["ad_domain"], p["ip_addresses"], p["capabilities"]))
        # Servers Apex Central no longer lists: kept with their choice, but not shown as live assets
        if items:                                     # an empty answer marks nothing gone
            conn.execute("""UPDATE av_products SET gone_at = now() WHERE console_id = %s AND gone_at IS NULL
                               AND NOT (entity_id = ANY(%s))""", (cid, [p["entity_id"] for p in items]))
        conn.execute("UPDATE av_consoles SET products_checked_at = now() WHERE id = %s", (cid,))
    return listing(conn, cid)


DSM_VIEW = """p.id, p.console_id, p.entity_id, p.product, p.kind, p.host_name, p.ad_domain, p.ip_addresses, p.capabilities,
              p.selected, p.first_seen, p.last_seen, p.dsm_url, p.dsm_key_enc IS NOT NULL AS dsm_has_key,
              p.dsm_ca_pem IS NOT NULL AS dsm_has_ca, p.dsm_pin_sha256, p.dsm_pin_subject, p.dsm_use_proxy, p.dsm_enabled,
              p.dsm_set_by, p.dsm_set_at, p.last_sync_at, p.last_sync_ok, p.last_sync_msg, p.agents, p.gone_at"""


def listing(conn, cid=None):
    """Products (all consoles, or one), with how many agents Apex Central lists under each."""
    rows = [dict(r) for r in conn.execute(
        f"""SELECT {DSM_VIEW}, c.name AS console, c.products_chosen,
                   (SELECT count(*) FROM av_agents a WHERE a.console_id = p.console_id AND a.product_id IS NULL
                       AND a.managing_server_id = p.entity_id) AS apex_agents,
                   (SELECT count(*) FROM av_agents a WHERE a.product_id = p.id) AS dsm_agents
              FROM av_products p JOIN av_consoles c ON c.id = p.console_id
             WHERE %s::uuid IS NULL OR p.console_id = %s::uuid
             ORDER BY c.name, p.kind, lower(coalesce(p.host_name, p.entity_id))""", (cid, cid)).fetchall()]
    for r in rows:
        r["kind_label"] = KIND_LABEL.get(r["kind"], r["kind"])
        r["product_label"] = product_label(r["product"])
    return rows


def choose(conn, cid, selected_ids):
    """Tick the product servers to sync. Agents Apex Central reports under a
    server that is not ticked are removed at once."""
    with conn.transaction():
        ids = {str(r["id"]) for r in conn.execute("SELECT id FROM av_products WHERE console_id = %s", (cid,)).fetchall()}
        chosen = sorted(set(selected_ids) & ids)
        conn.execute("UPDATE av_products SET selected = (id::text = ANY(%s)) WHERE console_id = %s", (chosen, cid))
        conn.execute("UPDATE av_consoles SET products_chosen = true WHERE id = %s", (cid,))
        removed = len(conn.execute(
            """DELETE FROM av_agents a USING av_products p
                WHERE a.console_id = %s AND a.product_id IS NULL AND p.console_id = a.console_id
                  AND p.entity_id = a.managing_server_id AND p.selected IS NOT TRUE
            RETURNING a.entity_id""", (cid,)).fetchall())
        conn.execute("""DELETE FROM av_agents WHERE product_id IN
                          (SELECT id FROM av_products WHERE console_id = %s AND selected IS NOT TRUE)""", (cid,))
    return {"selected": len(chosen), "removed_agents": removed}


def apex_filter(conn, cid):
    """(keep(agent) -> bool) for Apex Central's agent list: only the ticked
    servers' agents once an admin has chosen, and never the agents of a
    Deep Security Manager that is read directly."""
    try:
        with conn.transaction():
            chosen = conn.execute("SELECT products_chosen FROM av_consoles WHERE id = %s", (cid,)).fetchone()
            prods = conn.execute("""SELECT entity_id, selected, kind, dsm_enabled, last_sync_ok, dsm_key_enc IS NOT NULL AS has_key
                                      FROM av_products WHERE console_id = %s""", (cid,)).fetchall()
    except Exception as e:  # noqa: BLE001 - schema 034 not applied yet: everything is kept
        if type(e).__name__ not in ("UndefinedTable", "UndefinedColumn"):
            raise
        return lambda a: True
    known = {p["entity_id"] for p in prods}
    allowed = {p["entity_id"] for p in prods if p["selected"]}
    # A Manager read directly replaces Apex Central's copy only while that read works:
    # with a wrong key or a changed certificate, Apex Central's list still counts
    direct = {p["entity_id"] for p in prods if p["selected"] and p["kind"] == "deep_security" and p["dsm_enabled"]
              and p["has_key"] and p["last_sync_ok"] is True}
    use_choice = bool(chosen and chosen["products_chosen"])

    def keep(a):
        m = a.get("managing_server_id")
        if m in direct:
            return False                          # read from the Manager itself
        if use_choice and m in known:
            return m in allowed
        return True                               # a server Apex Central did not list, or no choice made yet
    return keep


# ---------------------------------------------------------------------------
# Deep Security Manager, read directly
# ---------------------------------------------------------------------------

def clean_dsm_key(v):
    v = (v or "").strip()
    if not DSM_KEY_RE.match(v):
        raise av.AvError("That does not look like a Deep Security API key (the secret shown once when the key is created).")
    return v


SAVED = object()          # "use what is saved", as opposed to None ("none")


def target(p, url=SAVED, ca_pem=SAVED, pin=SAVED, use_proxy=SAVED):
    """The connection settings of a Manager, as the antivirus client expects
    them. Each value given (None included) is used as it is; only a value not
    given at all falls back to what is saved."""
    return {"url": av.clean_url(p["dsm_url"] if url is SAVED else url),
            "ca_pem": (p.get("dsm_ca_pem") if ca_pem is SAVED else ca_pem) or None,
            "pin_sha256": (p.get("dsm_pin_sha256") if pin is SAVED else pin) or None,
            "use_proxy": bool(p.get("dsm_use_proxy") if use_proxy is SAVED else use_proxy)}


def dsm_get(t, api_key, path):
    """One GET to a Deep Security Manager. Only GET exists here."""
    u = urllib.parse.urlsplit(t["url"])
    host, port = u.hostname, u.port or 443
    deadline = time.monotonic() + av.DEADLINE
    headers = {"api-secret-key": api_key, "api-version": "v1", "Accept": "application/json",
               "User-Agent": "PATCH-01 inventory (read-only)", "Host": u.netloc}
    try:
        conn = av._connection(t, host, port, av._context(t))
        try:
            conn.request("GET", path, headers=headers)
            r = conn.getresponse()
            if r.status in (301, 302, 303, 307, 308):
                raise av.AvError(f"The Manager answered with a redirect ({r.status}): use its own https address and port (usually 4119).")
            if r.status in (401, 403):
                raise av.AvError(f"The Manager refused the API key ({r.status}): check the key is active and its role can view computers.")
            if r.status == 404:
                raise av.AvError("No Deep Security API at this address (404): check the URL and port (usually 4119).")
            if r.status != 200:
                raise av.AvError(f"The Manager answered HTTP {r.status}.")
            chunks, size = [], 0
            while True:
                if time.monotonic() > deadline:
                    raise av.AvError(f"The Manager took longer than {av.DEADLINE} seconds to answer.")
                b = r.read(65536)
                if not b:
                    break
                size += len(b)
                if size > av.MAX_RESPONSE:
                    raise av.AvError(f"The Manager's answer is larger than {av.MAX_RESPONSE // 2 ** 20} MB.")
                chunks.append(b)
        finally:
            conn.close()
    except av.AvError:
        raise
    except Exception as e:  # noqa: BLE001 - one plain message, never the far end's text
        log.info("deep security: %s: %s", t.get("url"), type(e).__name__)
        raise av.AvError(av._fail_text(e).replace("console", "Manager").replace("Apex Central server", "Deep Security Manager"))
    try:
        doc = json.loads(b"".join(chunks).decode("utf-8-sig"))
    except Exception:  # noqa: BLE001
        raise av.AvError("The Manager's answer is not JSON: check the URL points at the Deep Security Manager.")
    if not isinstance(doc, dict):
        raise av.AvError("The Manager's answer has an unexpected shape.")
    return doc


def _ms(v):
    try:
        v = int(v)
        return datetime.fromtimestamp(v / 1000 if v > 10 ** 11 else v, tz=timezone.utc) if v > 0 else None
    except (TypeError, ValueError, OverflowError, OSError):
        return None


def parse_computers(doc, pid=""):
    comps = doc.get("computers")
    if not isinstance(comps, list):
        raise av.AvError("The Manager's computer list has an unexpected shape.")
    out = []
    for c in comps[:av.MAX_AGENTS]:
        if not isinstance(c, dict) or c.get("ID") in (None, ""):
            continue
        st = c.get("computerStatus") if isinstance(c.get("computerStatus"), dict) else {}
        status = str(st.get("agentStatus") or "").lower()[:20]
        msgs = av._strs(st.get("agentStatusMessages"), 5, 120)
        pattern = None
        su = c.get("securityUpdates") if isinstance(c.get("securityUpdates"), dict) else {}
        am = su.get("antiMalware")
        for x in (am if isinstance(am, list) else []):
            if isinstance(x, dict) and av.VERSION_RE.match(str(x.get("version") or "")):
                pattern = str(x["version"])[:30]
                break
        ip = str(c.get("lastIPUsed") or "").strip()
        # Computer IDs restart at 1 on every Manager: the product makes them unique within the console
        out.append({"entity_id": f"dsm:{pid}:" + str(c["ID"])[:40], "product": "SLF_PRODUCT_DEEPSECURITY",
                    "host_name": str(c.get("hostName") or c.get("displayName") or "")[:255],
                    "ip_addresses": [ip] if av._is_ip(ip) else [], "os": (str(c.get("platform") or "")[:120] or None),
                    "last_connected": _ms(c.get("lastAgentCommunication")),
                    "online": True if status in ("active", "warning") else False if status in ("offline", "inactive") else None,
                    "status": status or None, "messages": msgs, "pattern_version": pattern,
                    "agent_version": str(c.get("agentVersion") or "")[:40] or None})
    return out


def dsm_test(t, api_key):
    doc = dsm_get(t, api_key, "/api/computers?expand=none")
    comps = doc.get("computers")
    if not isinstance(comps, list):
        raise av.AvError("The Manager's answer has no computer list: check the URL points at the Deep Security Manager API.")
    return {"computers": len(comps)}


def _sync_failed(conn, pid, msg):
    conn.rollback()
    conn.execute("""UPDATE av_products SET last_sync_at = now(), last_sync_ok = false, last_sync_msg = %s,
                           sync_requested_at = NULL WHERE id = %s""", (msg[:400], pid))
    conn.commit()


def dsm_sync(conn, pid):
    p = conn.execute("SELECT * FROM av_products WHERE id = %s", (pid,)).fetchone()
    if not p or not p["dsm_enabled"] or not p["dsm_key_enc"] or not p["selected"]:
        conn.commit()
        return 0
    p = dict(p)
    conn.commit()                                     # nothing held open while the Manager answers
    try:
        comps = parse_computers(dsm_get(target(p), av.decrypt(p["dsm_key_enc"]), DSM_COMPUTERS), str(pid))
    except Exception as e:  # noqa: BLE001 - recorded on the product
        _sync_failed(conn, pid, str(e) if isinstance(e, av.AvError) else "The Manager's answer could not be read.")
        return 0
    rows = [(p["console_id"], c["entity_id"], c["product"], c["host_name"], None, None, c["ip_addresses"], [],
             p["entity_id"], None, ([c["status"]] if c["status"] else []) + c["messages"], c["pattern_version"],
             c["last_connected"], c["online"], c["os"], pid) for c in comps]
    try:
        with conn.transaction():
            # The admin may have changed, turned off, unticked or removed it while the Manager answered
            now = conn.execute("""SELECT dsm_enabled, selected, dsm_url, dsm_set_at, dsm_key_enc FROM av_products
                                   WHERE id = %s FOR UPDATE""", (pid,)).fetchone()
            if not now or not now["dsm_enabled"] or not now["selected"] or now["dsm_url"] != p["dsm_url"] \
                    or str(now["dsm_set_at"]) != str(p["dsm_set_at"]) or now["dsm_key_enc"] != p["dsm_key_enc"]:
                return 0
            conn.cursor().executemany(
                """INSERT INTO av_agents (console_id, entity_id, product, host_name, ad_domain, folder_path, ip_addresses, mac_addresses,
                                          managing_server_id, isolation_status, capabilities, pattern_version, last_connected, online, os,
                                          product_id, last_seen)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, now())
                   ON CONFLICT (console_id, entity_id) DO UPDATE SET product = EXCLUDED.product, host_name = EXCLUDED.host_name,
                       ip_addresses = EXCLUDED.ip_addresses, managing_server_id = EXCLUDED.managing_server_id,
                       capabilities = EXCLUDED.capabilities, pattern_version = EXCLUDED.pattern_version,
                       last_connected = EXCLUDED.last_connected, online = EXCLUDED.online, os = EXCLUDED.os,
                       product_id = EXCLUDED.product_id, last_seen = now()""", rows)
            conn.execute("DELETE FROM av_agents WHERE product_id = %s AND last_seen < now() - interval '7 days'", (pid,))
            # Apex Central's copies of this Manager's agents are left out from now on
            conn.execute("DELETE FROM av_agents WHERE console_id = %s AND product_id IS NULL AND managing_server_id = %s",
                         (p["console_id"], p["entity_id"]))
            conn.execute("""UPDATE av_products SET last_sync_at = now(), last_sync_ok = true, last_sync_msg = %s, agents = %s,
                                   sync_requested_at = NULL WHERE id = %s""", (f"{len(comps)} computers", len(comps), pid))
    except Exception as e:  # noqa: BLE001 - recorded, and not asked again every minute
        log.warning("deep security sync: %s", type(e).__name__)
        _sync_failed(conn, pid, "The Manager's computers could not be saved.")
        return 0
    conn.commit()
    return len(comps)


def dsm_due(conn, cid):
    try:
        with conn.transaction():
            return [r["id"] for r in conn.execute(
                """SELECT id FROM av_products WHERE console_id = %s AND selected AND kind = 'deep_security' AND dsm_enabled
                      AND dsm_key_enc IS NOT NULL""", (cid,)).fetchall()]
    except Exception as e:  # noqa: BLE001
        if type(e).__name__ not in ("UndefinedTable", "UndefinedColumn"):
            raise
        return []


def dsm_requested(conn):
    """Managers an admin asked to read now ("Sync now")."""
    try:
        with conn.transaction():
            return [r["id"] for r in conn.execute(
                """SELECT id FROM av_products WHERE sync_requested_at IS NOT NULL AND selected
                      AND kind = 'deep_security' AND dsm_enabled AND dsm_key_enc IS NOT NULL
                      AND console_id IN (SELECT id FROM av_consoles WHERE enabled)""").fetchall()]
    except Exception as e:  # noqa: BLE001
        if type(e).__name__ not in ("UndefinedTable", "UndefinedColumn"):
            raise
        return []


def rediscover_due(conn, cid):
    """Once a day, for a console whose products were discovered before: list
    them again, so new and removed servers show (choices are kept)."""
    try:
        with conn.transaction():
            r = conn.execute("""SELECT 1 FROM av_consoles WHERE id = %s AND enabled AND products_checked_at IS NOT NULL
                                   AND products_checked_at < now() - interval '24 hours'""", (cid,)).fetchone()
    except Exception as e:  # noqa: BLE001
        if type(e).__name__ not in ("UndefinedTable", "UndefinedColumn"):
            raise
        return False
    return bool(r)
