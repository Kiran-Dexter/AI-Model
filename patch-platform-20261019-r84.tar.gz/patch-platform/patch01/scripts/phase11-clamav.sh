#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 phase 11 : ClamAV for Deployment (optional)
#
# Runs ClamAV (clamd) in a container on the patchnet network, with no
# published port, and turns on scanning of every package uploaded in the
# console (Deployment). An infected package can then never be deployed; a
# scan that cannot run blocks the package until it is scanned again.
#
# The image is not pulled by this script: load or pull it first through your
# proxy (docker pull clamav/clamav:1.4), or name it with --image.
#
# Usage:
#   ./phase11-clamav.sh                      deploy, or update the settings
#   ./phase11-clamav.sh --image REPO:TAG     use this image
#   ./phase11-clamav.sh --proxy http://HOST:PORT
#                                            signature updates (freshclam) through a proxy
#   ./phase11-clamav.sh --no-updates         never contact the internet; the signatures
#                                            are those in the image (refresh the image)
#   ./phase11-clamav.sh --status             what runs, and the signature date
#   ./phase11-clamav.sh --down               stop scanning and remove the container
# ---------------------------------------------------------------------------
set -Eeuo pipefail
umask 027

PATCH_BASE="/patch"
LOG_DIR="/var/log/patch-platform"
CONTAINER="patch01-clamav"
VOLUME="patch01-clamav-db"
CONF_DIR="$PATCH_BASE/config/clamav"
PACKAGES_DIR="$PATCH_BASE/data/packages"
API_ENV="$PATCH_BASE/secrets/api.env"
API_COMPOSE="$PATCH_BASE/compose/docker-compose.api.yml"
IMAGE=""; PROXY=""; NO_UPDATES=no; MODE=deploy

while (($#)); do
  case "$1" in
    --image)      IMAGE="${2:-}"; shift ;;
    --proxy)      PROXY="${2:-}"; shift ;;
    --no-updates) NO_UPDATES=yes ;;
    --status)     MODE=status ;;
    --down)       MODE=down ;;
    -h|--help)    sed -n '2,24p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/phase11-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"
log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Run as root."
command -v docker >/dev/null || die "Docker is not installed."
[[ -f "$API_ENV" ]] || die "$API_ENV not found: run phase3b-api.sh first."
[[ -f "$API_COMPOSE" ]] || die "$API_COMPOSE not found: run phase3b-api.sh first."

# api.env holds CLAMAV_HOST for the API and the worker; the rest of it is left untouched
set_scanning() {
  local tmp; tmp="$(mktemp "$API_ENV.XXXX")"
  grep -v '^CLAMAV_HOST=' "$API_ENV" >"$tmp" || true
  [[ "$1" == on ]] && printf 'CLAMAV_HOST=%s\n' "$CONTAINER" >>"$tmp"
  chmod 0600 "$tmp"; chown root:root "$tmp"; mv -f "$tmp" "$API_ENV"
  # env_file changes recreate the API and the worker with the new setting
  docker compose -f "$API_COMPOSE" up -d >>"$LOG_FILE" 2>&1 || die "Could not restart the API and the worker (docker compose -f $API_COMPOSE up -d)."
}

if [[ "$MODE" == status ]]; then
  if docker ps --format '{{.Names}}' | grep -x "$CONTAINER" >/dev/null; then
    say "$CONTAINER: running ($(docker inspect -f '{{.Config.Image}}' "$CONTAINER"))"
    say "Engine and signatures: $(docker exec "$CONTAINER" clamdscan --version 2>/dev/null || echo 'clamd not answering yet')"
  else
    say "$CONTAINER: not running"
  fi
  grep '^CLAMAV_HOST=' "$API_ENV" >/dev/null && say "Scanning of uploads: ON" || say "Scanning of uploads: off"
  exit 0
fi

if [[ "$MODE" == down ]]; then
  set_scanning off
  docker rm -f "$CONTAINER" >>"$LOG_FILE" 2>&1 || true
  say "ClamAV removed; uploads are no longer scanned (the signature volume $VOLUME is kept: docker volume rm $VOLUME)."
  exit 0
fi

# ---------------------------------------------------------------------------
if [[ -z "$IMAGE" ]]; then
  IMAGE="$(docker images --format '{{.Repository}}:{{.Tag}}' | grep -iE '(^|/)clamav(/clamav)?:' | grep -v '<none>' | grep -v '_base' | head -1 || true)"
fi
[[ -n "$IMAGE" ]] || die "No ClamAV image on this host. Pull one through your proxy (docker pull clamav/clamav:1.4) or load it (docker load -i file.tar), then run again, or give --image."
docker image inspect "$IMAGE" >/dev/null 2>&1 || die "Image $IMAGE is not on this host."
[[ -d "$PACKAGES_DIR" ]] || die "$PACKAGES_DIR not found: run phase3b-api.sh of this release first."
if [[ -n "$PROXY" && ! "$PROXY" =~ ^https?://[A-Za-z0-9.-]+:[0-9]{1,5}/?$ ]]; then die "--proxy must be http://HOST:PORT"; fi
say "Image: $IMAGE"

# clamd runs as the image's own clamav user: it reads the packages through their group
CL_UID="$(docker run --rm --entrypoint id "$IMAGE" -u clamav 2>/dev/null || true)"
CL_GID="$(docker run --rm --entrypoint id "$IMAGE" -g clamav 2>/dev/null || true)"
[[ "$CL_UID" =~ ^[0-9]+$ && "$CL_GID" =~ ^[0-9]+$ ]] || die "Could not find the clamav user in $IMAGE (is it the official clamav/clamav image?)."
chgrp -R "$CL_GID" "$PACKAGES_DIR"
# setgid on every folder (also .incoming, if uploads came before ClamAV): new files get the group
find "$PACKAGES_DIR" -type d -exec chmod 2750 {} +
find "$PACKAGES_DIR" -type f -exec chmod 0640 {} +
say "Packages readable by ClamAV (group $CL_GID); the API still owns them"

mkdir -p "$CONF_DIR"; chmod 0755 "$CONF_DIR"
cat >"$CONF_DIR/clamd.conf" <<'EOF'
# PATCH-01: clamd for scanning uploaded packages (phase11-clamav.sh)
Foreground yes
LogTime yes
LogFile /dev/stdout
DatabaseDirectory /var/lib/clamav
LocalSocket /tmp/clamd.sock
TCPSocket 3310
TCPAddr 0.0.0.0
User clamav
# Installers are large: scan all of them, and flag (never silently pass) anything over a limit
MaxFileSize 4000M
MaxScanSize 4000M
MaxScanTime 1500000
MaxRecursion 20
MaxFiles 50000
AlertExceedsMax yes
ReadTimeout 1800
CommandReadTimeout 30
EOF
{
  echo "# PATCH-01: signature updates (phase11-clamav.sh)"
  echo "DatabaseDirectory /var/lib/clamav"
  echo "UpdateLogFile /dev/stdout"
  echo "LogTime yes"
  echo "DatabaseMirror database.clamav.net"
  echo "Checks 12"
  if [[ -n "$PROXY" ]]; then
    p="${PROXY#http://}"; p="${p#https://}"; p="${p%/}"
    echo "HTTPProxyServer ${p%:*}"
    echo "HTTPProxyPort ${p##*:}"
  fi
} >"$CONF_DIR/freshclam.conf"
chmod 0644 "$CONF_DIR/clamd.conf" "$CONF_DIR/freshclam.conf"

docker rm -f "$CONTAINER" >>"$LOG_FILE" 2>&1 || true
ENVS=()
[[ "$NO_UPDATES" == yes ]] && ENVS+=(-e CLAMAV_NO_FRESHCLAMD=true)
docker run -d --name "$CONTAINER" --restart unless-stopped --network patchnet \
  --security-opt no-new-privileges:true --memory 4g \
  -v "$VOLUME":/var/lib/clamav \
  -v "$PACKAGES_DIR":/packages:ro \
  -v "$CONF_DIR/clamd.conf":/etc/clamav/clamd.conf:ro \
  -v "$CONF_DIR/freshclam.conf":/etc/clamav/freshclam.conf:ro \
  ${ENVS[@]+"${ENVS[@]}"} "$IMAGE" >>"$LOG_FILE" 2>&1 || die "The ClamAV container did not start (see the log)."
say "Started $CONTAINER (no published port; the API reaches it on patchnet)"

say "Waiting for clamd to load its signatures (up to 5 minutes)..."
ok=no
for _ in $(seq 1 60); do
  if docker exec "$CONTAINER" clamdscan --no-summary /etc/hostname >/dev/null 2>&1; then ok=yes; break; fi
  sleep 5
done
[[ "$ok" == yes ]] || die "clamd did not answer within 5 minutes: docker logs $CONTAINER"
say "clamd answers: $(docker exec "$CONTAINER" clamdscan --version 2>/dev/null)"

set_scanning on
say "
ClamAV is on. New uploads are scanned before they can be deployed; for a package
uploaded before, use 'Scan again' on the Deployment page.
$( [[ "$NO_UPDATES" == yes ]] && echo "Signatures are not updated (--no-updates): refresh the image regularly." )"
