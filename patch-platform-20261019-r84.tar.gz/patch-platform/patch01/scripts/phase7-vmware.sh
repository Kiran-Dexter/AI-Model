#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 phase 7 : VMware vCenter inventory (read-only)
#
# Adds each vCenter, pins its certificate after you confirm the thumbprint,
# stores the service account password, and syncs VM inventory into PATCH-01.
# Several vCenters are supported; one failing never stops the others.
#
# The vCenter account needs the built-in Read-only role, assigned at the top
# of the inventory with "Propagate to children". Nothing here changes a VM.
#
# Usage:
#   ./phase7-vmware.sh --add vc01 --host vcenter01.corp.local [--user svc-patch01@vsphere.local]
#   ./phase7-vmware.sh --list
#   ./phase7-vmware.sh --test vc01
#   ./phase7-vmware.sh --sync [vc01]
#   ./phase7-vmware.sh --check
#   ./phase7-vmware.sh --remove vc01
#   ./phase7-vmware.sh --install-timer        sync every hour
#   ./phase7-vmware.sh --add-writer vc01      write account: snapshots and power
#   ./phase7-vmware.sh --remove-writer vc01
# ---------------------------------------------------------------------------

set -Eeuo pipefail

# grep that reads all of its input before answering. "cmd | grep -q" can stop
# reading at the first match; under pipefail the writer then fails (SIGPIPE)
# and a found match reads as "not found". Used for multi-line producers.
gq() { grep "$@" >/dev/null; }

umask 027

PATCH_BASE="/patch"
VC_DIR="$PATCH_BASE/secrets/vcenter"
CONTAINER="patch01-api"
LOG_DIR="/var/log/patch-platform"

MODE=""; NAME=""; HOST=""; PORT=443; USER_NAME=""

while (($#)); do
  case "$1" in
    --add)           MODE=add; NAME="${2:-}"; shift ;;
    --add-writer)    MODE=writer; NAME="${2:-}"; shift ;;
    --remove-writer) MODE=unwriter; NAME="${2:-}"; shift ;;
    --host)          HOST="${2:-}"; shift ;;
    --port)          PORT="${2:-443}"; shift ;;
    --user)          USER_NAME="${2:-}"; shift ;;
    --list)          MODE=list ;;
    --test)          MODE=test; NAME="${2:-}"; shift ;;
    --sync)          MODE=sync; if [[ "${2:-}" != "" && "${2:-}" != --* ]]; then NAME="$2"; shift; fi ;;
    --check)         MODE=check ;;
    --remove)        MODE=remove; NAME="${2:-}"; shift ;;
    --install-timer) MODE=timer ;;
    -h|--help)       sed -n '2,23p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/phase7-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"

say()  { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }
step() { printf '\n==> %s\n' "$*"; }
die()  { printf '\nERROR: %s\nLog: %s\n' "$*" "$LOG_FILE" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Run as root."
[[ -n "$MODE" ]] || { sed -n '2,21p' "$0"; exit 2; }
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

valid_name() { [[ "$1" =~ ^[a-z0-9][a-z0-9_-]{0,39}$ ]]; }
in_api() { docker exec "$CONTAINER" "$@"; }
psqlq() { docker exec -i patch01-postgres psql -U postgres -d patchdb -qtAX "$@"; }

# The API image must contain the VMware code and see the config directory.
ensure_api() {
  docker ps --format '{{.Names}}' | gq -x "$CONTAINER" || die "$CONTAINER is not running."
  if [[ "$(psqlq -c "SELECT count(*) FROM information_schema.tables WHERE table_name='vm_inventory'" 2>/dev/null)" != "1" ]]; then
    say "Applying the VMware database schema (004)..."
    "$SRC_DIR/scripts/phase3a-schema.sh" >>"$LOG_FILE" 2>&1 || { tail -15 "$LOG_FILE" >&2; die "Schema update failed."; }
  fi
  if ! in_api python -c "import app.vmware, pyVmomi" >/dev/null 2>&1 || ! in_api test -d /etc/vcenter; then
    say "Rebuilding the API with VMware support (this downloads pyVmomi through the proxy)..."
    "$SRC_DIR/scripts/phase3b-api.sh" >>"$LOG_FILE" 2>&1 || { tail -20 "$LOG_FILE" >&2; die "API rebuild failed."; }
    in_api python -c "import app.vmware, pyVmomi" >/dev/null 2>&1 || die "The rebuilt API still lacks pyVmomi."
  fi
}

# ---------------------------------------------------------------------------
case "$MODE" in
# ---------------------------------------------------------------------------

writer)
  valid_name "$NAME" || die "Give the vCenter name: --add-writer vc01"
  [[ -f "$VC_DIR/$NAME.env" ]] || die "Add the vCenter first with --add $NAME."
  step "Write account for $NAME"
  say "  This account carries out snapshots and power actions. Create it in"
  say "  vCenter with a custom role holding only these privileges:"
  say ""
  say "    Virtual machine > Snapshot management > Create snapshot"
  say "    Virtual machine > Snapshot management > Remove snapshot"
  say "    Virtual machine > Snapshot management > Revert to snapshot"
  say "    Virtual machine > Interaction > Power on"
  say "    Virtual machine > Interaction > Power off   (used for guest shutdown)"
  say "    Virtual machine > Interaction > Reset       (used for guest restart)"
  say ""
  say "  Assign it to the folders or clusters PATCH-01 may act on, with"
  say "  'Propagate to children'. Not the whole vCenter unless you mean it."
  say ""
  say "  The power privileges would also allow a hard power-off through the"
  say "  vCenter API. PATCH-01 never offers one; it only asks the guest OS to"
  say "  shut down or restart through VMware Tools."
  say ""
  ensure_api                  # before anything is written: a failure here leaves nothing behind
  read -r -p "  Write account user (e.g. svc-patch01-ops@vsphere.local): " WUSER
  [[ -n "$WUSER" ]] || die "A user is required."
  RO_USER="$(grep -E '^VC_USER=' "$VC_DIR/$NAME.env" | cut -d= -f2-)"
  [[ "${WUSER,,}" != "${RO_USER,,}" ]] || die "Use a different account from the read-only one ($RO_USER)."
  read -r -s -p "  Password (hidden): " PW; echo
  [[ -n "$PW" ]] || die "A password is required."
  # From here until the login is proven, any exit removes what was written
  WFILE="$VC_DIR/$NAME-write.env"; KEEP_WRITER=no
  trap '[[ "$KEEP_WRITER" == yes ]] || rm -f "$WFILE"' EXIT
  HOST_="$(grep -E '^VC_HOST=' "$VC_DIR/$NAME.env" | cut -d= -f2-)"
  PORT_="$(grep -E '^VC_PORT=' "$VC_DIR/$NAME.env" | cut -d= -f2-)"
  {
    echo "# Write account for vCenter $NAME, added $(date -Is). Snapshots and power only."
    echo "VC_HOST=$HOST_"
    echo "VC_PORT=${PORT_:-443}"
    echo "VC_USER=$WUSER"
    echo "VC_PASSWORD_B64=$(printf '%s' "$PW" | base64 -w0)"
  } > "$VC_DIR/$NAME-write.env"
  unset PW
  chown root:0 "$VC_DIR/$NAME-write.env"; chmod 0640 "$VC_DIR/$NAME-write.env"
  step "Testing the write account's login"
  OUT="$(in_api python -c "
import json,sys
from app import vmware
try:
    si = vmware.connect(vmware.load_writer('$NAME'))
    print(json.dumps({'ok': True, 'user': si.content.sessionManager.currentSession.userName}))
    vmware.disconnect(si)
except Exception as e:
    print(json.dumps({'ok': False, 'error': str(e)[:300]}))
" 2>&1 || true)"
  say "  $OUT"
  if ! printf '%s' "$OUT" | grep '"ok": true' >/dev/null; then
    die "The write account could not log in; nothing was kept."
  fi
  KEEP_WRITER=yes
  say ""
  say "Saved. Snapshot and power actions for $NAME are now offered in the console."
  say "Permissions are checked by vCenter when an action runs; a missing one"
  say "fails that action with vCenter's own message."
  exit 0 ;;

unwriter)
  valid_name "$NAME" || die "Give the vCenter name: --remove-writer vc01"
  rm -f "$VC_DIR/$NAME-write.env"
  say "Write account for $NAME removed. The inventory sync is unaffected."
  exit 0 ;;

list)
  step "Configured vCenters"
  shopt -s nullglob
  files=("$VC_DIR"/*.env)
  ((${#files[@]})) || { say "  none. Add one with --add NAME --host ADDRESS"; exit 0; }
  for f in "${files[@]}"; do
    [[ "$f" == *-write.env ]] && continue
    n="$(basename "$f" .env)"
    w="no"; [[ -f "$VC_DIR/$n-write.env" ]] && w="yes"
    h="$(grep -E '^VC_HOST=' "$f" | cut -d= -f2-)"
    u="$(grep -E '^VC_USER=' "$f" | cut -d= -f2-)"
    pin="no"; [[ -s "$VC_DIR/$n.crt" ]] && pin="yes"
    printf '  %-12s %-36s user %-32s pinned %-3s write account %s\n' "$n" "$h" "$u" "$pin" "$w"
  done
  exit 0 ;;

add)
  valid_name "$NAME" || die "Name must be lowercase letters, digits, - or _ (e.g. vc01)."
  [[ -n "$HOST" ]] || die "--host is required: the vCenter address, ideally its FQDN."
  [[ ! -f "$VC_DIR/$NAME.env" ]] || die "$NAME already exists. Remove it first with --remove $NAME."

  step "Reaching $HOST:$PORT"
  timeout 10 bash -c "</dev/tcp/$HOST/$PORT" 2>/dev/null || die "Cannot open a connection to $HOST:$PORT."
  say "Connected."

  step "Pinning the vCenter certificate"
  TMP="$(mktemp)"; trap 'rm -f "$TMP" "$TMP.chain"' EXIT
  echo | timeout 20 openssl s_client -connect "$HOST:$PORT" -servername "$HOST" -showcerts 2>/dev/null > "$TMP" || true
  # Keep every certificate vCenter presents. Trusting the whole chain means a
  # renewed vCenter certificate from the same CA still verifies.
  awk '/-----BEGIN CERTIFICATE-----/,/-----END CERTIFICATE-----/' "$TMP" > "$TMP.chain"
  [[ -s "$TMP.chain" ]] || die "Could not read the certificate from $HOST."
  NCERTS="$(grep -c 'BEGIN CERTIFICATE' "$TMP.chain")"
  LEAF="$(awk '/-----BEGIN CERTIFICATE-----/{n++} n==1' "$TMP.chain")"
  SUBJ="$(printf '%s\n' "$LEAF" | openssl x509 -noout -subject | sed 's/^subject=//')"
  ISSUER="$(printf '%s\n' "$LEAF" | openssl x509 -noout -issuer | sed 's/^issuer=//')"
  SAN="$(printf '%s\n' "$LEAF" | openssl x509 -noout -ext subjectAltName 2>/dev/null | tail -1 | xargs || true)"
  EXP="$(printf '%s\n' "$LEAF" | openssl x509 -noout -enddate | cut -d= -f2)"
  SHA1="$(printf '%s\n' "$LEAF" | openssl x509 -noout -fingerprint -sha1 | cut -d= -f2)"
  SHA256="$(printf '%s\n' "$LEAF" | openssl x509 -noout -fingerprint -sha256 | cut -d= -f2)"
  say "  Subject:  $SUBJ"
  say "  Issuer:   $ISSUER"
  say "  Names:    $SAN"
  say "  Expires:  $EXP"
  say "  Chain:    $NCERTS certificate(s)"
  say "  SHA-1:    $SHA1"
  say "  SHA-256:  $SHA256"
  say ""
  say "  Check this against vCenter itself. In the vSphere Client:"
  say "    Administration > Certificates > Certificate Management >"
  say "    Machine SSL Certificate > View details"
  say "  The thumbprint shown there must match the SHA-1 or SHA-256 above."
  say "  If it does not, something is intercepting the connection. Stop."
  if ! printf '%s' "$SAN" | grep -qiE "(DNS|IP Address):$HOST(,|$)"; then
    warn "'$HOST' is not among the certificate's names. The connection will"
    warn "fail the hostname check. Use one of the names listed above instead."
    die "Re-run with --host set to a name in the certificate."
  fi
  [[ -t 0 ]] || die "Run interactively so the thumbprint can be confirmed."
  read -r -p "  Does the thumbprint match? [y/N]: " ans || true
  [[ "${ans,,}" =~ ^(y|yes)$ ]] || die "Stopped: thumbprint not confirmed."

  step "Service account"
  [[ -n "$USER_NAME" ]] || read -r -p "  vCenter user (e.g. svc-patch01@vsphere.local): " USER_NAME
  [[ -n "$USER_NAME" ]] || die "A user is required."
  read -r -s -p "  Password (hidden): " PW; echo
  [[ -n "$PW" ]] || die "A password is required."

  mkdir -p "$VC_DIR"; chown root:0 "$VC_DIR"; chmod 0750 "$VC_DIR"
  cp -f "$TMP.chain" "$VC_DIR/$NAME.crt"
  # Base64 so any character in the password survives the env file intact
  {
    echo "# vCenter $NAME, added $(date -Is). Read-only account."
    echo "VC_HOST=$HOST"
    echo "VC_PORT=$PORT"
    echo "VC_USER=$USER_NAME"
    echo "VC_PASSWORD_B64=$(printf '%s' "$PW" | base64 -w0)"
  } > "$VC_DIR/$NAME.env"
  unset PW
  # The API runs as uid 1001 in group 0
  chown root:0 "$VC_DIR/$NAME.env" "$VC_DIR/$NAME.crt"
  chmod 0640 "$VC_DIR/$NAME.env" "$VC_DIR/$NAME.crt"
  say "Saved $VC_DIR/$NAME.env and the pinned certificate."

  step "Preparing the API"
  ensure_api

  step "Testing $NAME from inside the API container"
  OUT="$(in_api python -m app.vmware --test "$NAME" 2>&1 || true)"
  say "  $OUT"
  if ! printf '%s' "$OUT" | grep -q '"ok": true'; then
    printf '%s' "$OUT" | grep -qi 'incorrect user name or password\|InvalidLogin' && \
      warn "vCenter rejected the user or password."
    printf '%s' "$OUT" | grep -qi 'certificate' && \
      warn "The certificate did not verify. Check that --host is a name in the certificate."
    warn "The files are kept. Fix the cause, then: --remove $NAME and --add again."
    die "Test failed."
  fi

  step "First sync"
  in_api python -m app.vmware --sync "$NAME" 2>&1 | tee -a "$LOG_FILE"
  say ""
  say "Added $NAME. Open the VMware page in the console, or run --install-timer"
  say "to sync every hour."
  exit 0 ;;

test)
  valid_name "$NAME" || die "Give a vCenter name: --test vc01"
  ensure_api
  in_api python -m app.vmware --test "$NAME"
  exit $? ;;

sync)
  ensure_api
  step "Syncing ${NAME:-all vCenters}"
  set +e
  in_api python -m app.vmware --sync ${NAME:+"$NAME"} 2>&1 | tee -a "$LOG_FILE"
  RC=${PIPESTATUS[0]}
  set -e
  exit "$RC" ;;

check)
  step "vCenter status"
  psqlq -c "SELECT name || '  ' || host || '  ' ||
                   CASE WHEN last_ok THEN 'ok' WHEN last_ok IS FALSE THEN 'FAILED' ELSE 'never synced' END
                   || '  ' || coalesce(vm_count::text,'-') || ' VMs  last sync ' ||
                   coalesce(to_char(last_sync_at,'YYYY-MM-DD HH24:MI'),'never')
              FROM vcenters ORDER BY name" 2>/dev/null | sed 's/^/  /' || say "  no vCenter data yet"
  step "Inventory"
  psqlq -c "SELECT '  VMs: '||count(*)||'   Linux: '||count(*) FILTER (WHERE is_linux)||
                   '   linked to a server: '||count(*) FILTER (WHERE host_id IS NOT NULL)||
                   '   Linux without agent: '||count(*) FILTER (WHERE is_linux AND host_id IS NULL AND power_state='poweredOn')||
                   '   ambiguous: '||count(*) FILTER (WHERE match_method='ambiguous')
              FROM vm_inventory" 2>/dev/null || true
  step "Account permissions"
  say "  This integration only reads. If the account can do more than Read-only,"
  say "  consider narrowing it: snapshot rights are added later, with patch jobs."
  exit 0 ;;

remove)
  valid_name "$NAME" || die "Give a vCenter name: --remove vc01"
  [[ -f "$VC_DIR/$NAME.env" ]] || die "No vCenter named $NAME."
  read -r -p "Remove $NAME and its VM inventory from PATCH-01? [y/N]: " ans || true
  [[ "${ans,,}" =~ ^(y|yes)$ ]] || { say "Nothing changed."; exit 0; }
  rm -f "$VC_DIR/$NAME.env" "$VC_DIR/$NAME.crt"
  psqlq -v n="$NAME" <<'SQL' || true
DELETE FROM vcenters WHERE name = :'n';
SQL
  say "Removed $NAME. vCenter itself is unchanged."
  exit 0 ;;

timer)
  SELF="$(readlink -f "$0")"
  cat >/etc/systemd/system/patch01-vmware.service <<EOF
[Unit]
Description=Sync VMware vCenter inventory into PATCH-01
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
ExecStart=$SELF --sync
TimeoutStartSec=30min
EOF
  cat >/etc/systemd/system/patch01-vmware.timer <<'EOF'
[Unit]
Description=Hourly vCenter inventory sync (backup: the worker reads every 5 minutes)

[Timer]
OnCalendar=*-*-* *:15:00
RandomizedDelaySec=5min
Persistent=true

[Install]
WantedBy=timers.target
EOF
  systemctl daemon-reload
  systemctl enable --now patch01-vmware.timer
  say "Hourly backup sync installed (the worker also reads every 5 minutes)."
  systemctl list-timers patch01-vmware.timer --no-pager | sed -n '2p'
  exit 0 ;;
esac
