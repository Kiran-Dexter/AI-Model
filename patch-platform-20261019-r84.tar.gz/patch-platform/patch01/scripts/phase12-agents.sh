#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 phase 12 : agent versions for "Update agents"
#
# Publishes the agent files PATCH-01 may send to its servers (Servers page,
# "Update agents"). Only root on PATCH-01 can publish; the console can only
# choose among the published versions. Each server's agent (1.8.0 or later)
# downloads the chosen file over its pinned connection, checks its SHA-256
# (and its signature when the agent runs signed), tests it, swaps itself and
# keeps the previous version; if the new one does not check in, the previous
# version puts itself back.
#
# Usage:
#   ./phase12-agents.sh                  publish this bundle's Windows and Linux agents
#                                        (a version already published is kept as it is)
#   ./phase12-agents.sh --windows FILE   publish this patch-agent.ps1 (e.g. after signing
#                                        it with Sign-Agent.ps1); replaces the same version
#   ./phase12-agents.sh --linux FILE     publish this patch-agent.py
#   ./phase12-agents.sh --status         what is published
#   ./phase12-agents.sh --remove windows|linux VERSION
#
#   --bundle --quiet                     the same, without output (phase3b-api.sh)
# ---------------------------------------------------------------------------
set -Eeuo pipefail
umask 022

PATCH_BASE="/patch"
REL="$PATCH_BASE/data/agent-releases"
LOG_DIR="/var/log/patch-platform"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MAX_BYTES=$((4 * 1024 * 1024))
MODE=bundle; QUIET=no; FILE=""; PLAT=""; VER=""; KEEP=yes

while (($#)); do
  case "$1" in
    --bundle)  MODE=bundle ;;
    --quiet)   QUIET=yes ;;
    --windows) MODE=file; PLAT=windows; FILE="${2:-}"; shift ;;
    --linux)   MODE=file; PLAT=linux; FILE="${2:-}"; shift ;;
    --status)  MODE=status ;;
    --remove)  MODE=remove; PLAT="${2:-}"; VER="${3:-}"; shift 2 || true ;;
    -h|--help) sed -n '2,24p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1 (see --help)" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/phase12-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"
log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { [[ "$QUIET" == yes ]] || printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Run as root."

prepare() {
  local d
  for d in "$PATCH_BASE/data" "$REL" "$REL/windows" "$REL/linux"; do
    [[ -L "$d" ]] && die "$d is a link: refusing to publish through it."
    mkdir -p "$d"
  done
  chown root:root "$REL" "$REL/windows" "$REL/linux"
  chmod 0755 "$REL" "$REL/windows" "$REL/linux"
}

# version_of PLATFORM FILE -> the version written in the file, or nothing
version_of() {
  if [[ "$1" == windows ]]; then
    sed -n 's/^\$AgentVersion = "\([0-9]\{1,4\}\.[0-9]\{1,4\}\.[0-9]\{1,4\}-win\)"[[:space:]]*$/\1/p' "$2" | head -1
  else
    sed -n 's/^AGENT_VERSION = "\([0-9]\{1,4\}\.[0-9]\{1,4\}\.[0-9]\{1,4\}\)"[[:space:]]*$/\1/p' "$2" | head -1
  fi
}

name_of() { [[ "$1" == windows ]] && echo patch-agent.ps1 || echo patch-agent.py; }

# publish PLATFORM FILE KEEP(yes|no)
publish() {
  local plat="$1" src="$2" keep="$3" ver size dest tmp sha signed=""
  [[ -f "$src" && ! -L "$src" ]] || die "$src is not a file."
  size="$(stat -c %s "$src")"
  (( size > 0 && size <= MAX_BYTES )) || die "$src is $size bytes: an agent file is between 1 byte and 4 MB."
  ver="$(version_of "$plat" "$src")"
  [[ -n "$ver" ]] || die "$src does not look like the $plat agent (no version line found)."
  if [[ "$plat" == linux ]]; then
    head -1 "$src" | grep -q '^#!' || die "$src does not start with #!: not the Linux agent."
    if command -v python3 >/dev/null; then
      python3 -c 'import sys; compile(open(sys.argv[1], "rb").read(), sys.argv[1], "exec")' "$src" 2>>"$LOG_FILE" \
        || die "$src is not valid Python (see the log)."
    fi
  else
    grep -q 'PATCH-01 agent for Windows' "$src" || die "$src does not look like the Windows agent."
    grep -q '^# SIG # Begin signature block' "$src" && signed=" (signed)"
  fi
  dest="$REL/$plat/$ver"
  if [[ "$keep" == yes && -f "$dest/$(name_of "$plat")" ]]; then
    say "$plat agent $ver is already published; kept as it is (to replace it: --$plat FILE)"
    return 0
  fi
  [[ -L "$dest" ]] && die "$dest is a link: refusing."
  mkdir -p "$dest"; chown root:root "$dest"; chmod 0755 "$dest"
  tmp="$(mktemp "$dest/.new.XXXXXX")"
  cat "$src" >"$tmp"
  chown root:root "$tmp"; chmod 0644 "$tmp"
  mv -f "$tmp" "$dest/$(name_of "$plat")"
  command -v restorecon >/dev/null 2>&1 && restorecon -R "$dest" 2>/dev/null || true
  sha="$(sha256sum "$dest/$(name_of "$plat")" | cut -d' ' -f1)"
  say "Published $plat agent $ver$signed  SHA-256 $sha"
}

status() {
  local plat d f ver any=no
  for plat in windows linux; do
    for d in "$REL/$plat"/*/; do
      [[ -d "$d" ]] || continue
      f="$d$(name_of "$plat")"; [[ -f "$f" ]] || continue
      ver="$(version_of "$plat" "$f")"; any=yes
      printf '%-8s %-12s %s  %8s bytes  %s%s%s\n' "$plat" "$(basename "$d")" "$(sha256sum "$f" | cut -c1-16)..." \
        "$(stat -c %s "$f")" "$(date -r "$f" '+%F %R')" \
        "$( [[ "$plat" == windows ]] && grep -q '^# SIG # Begin signature block' "$f" && echo '  signed' || true)" \
        "$( [[ "$ver" != "$(basename "$d")" ]] && echo '  IGNORED: the version inside is '"${ver:-missing}" || true)"
    done
  done
  [[ "$any" == yes ]] || say "Nothing published yet: ./scripts/phase12-agents.sh"
}

case "$MODE" in
  status) status ;;
  remove)
    [[ "$PLAT" == windows || "$PLAT" == linux ]] || die "--remove windows|linux VERSION"
    [[ "$VER" =~ ^[0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4}(-win)?$ ]] || die "Give the version as published (see --status)."
    [[ -d "$REL/$PLAT/$VER" && ! -L "$REL/$PLAT/$VER" ]] || die "$PLAT $VER is not published."
    rm -rf -- "${REL:?}/$PLAT/$VER"
    say "Removed $PLAT $VER. Updates already scheduled with it fail on the servers not done yet." ;;
  file)
    [[ -n "$FILE" ]] || die "Give the file: --$PLAT FILE"
    prepare; publish "$PLAT" "$FILE" no
    say "Choose it on the Servers page: Update agents." ;;
  bundle)
    prepare
    publish windows "$SRC_DIR/agent/windows/patch-agent.ps1" "$KEEP"
    publish linux "$SRC_DIR/agent/patch-agent.py" "$KEEP"
    say "Choose them on the Servers page: Update agents." ;;
esac
