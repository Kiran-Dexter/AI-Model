#!/usr/bin/env python3
"""
patch01-metrics - PATCH-01's own CPU, memory and network, for the console's
header gauges.

Runs on the PATCH-01 host as the unprivileged user patch01m (systemd unit
patch01-metrics.service, made by phase3b-api.sh), sandboxed: no network, no
capabilities, read-only system, at most 48 MB of memory and 5% of one CPU.

Every 5 seconds it reads four small kernel files (/proc/stat, /proc/meminfo,
/proc/net/dev, /proc/loadavg) and writes one JSON snapshot, with the last ten
minutes of history, to /run/patch01-metrics/host.json (memory-backed). The API
reads that file; it never gets access to the host or to Docker.

Standard library only. Measures its own CPU time and memory and reports them
in the snapshot, so its cost is visible in the console.
"""

import json
import os
import resource
import signal
import sys
import time
from collections import deque

OUT_DIR = os.environ.get("PATCH01_METRICS_DIR", "/run/patch01-metrics")
OUT = os.path.join(OUT_DIR, "host.json")
INTERVAL = 5.0
HISTORY = 120                       # 10 minutes at 5 s
ASSUMED_LINK_MBPS = 1000            # when the network card does not say its speed (common on VMs)
PROC = os.environ.get("PATCH01_PROC", "/proc")
SYS_NET = os.environ.get("PATCH01_SYS_NET", "/sys/class/net")

_running = True


def _stop(*_):
    global _running
    _running = False


def read_cpu():
    """(busy, total) jiffies of all CPUs together."""
    with open(os.path.join(PROC, "stat"), "rb") as fh:
        first = fh.readline().split()
    vals = [int(x) for x in first[1:9]]          # user nice system idle iowait irq softirq steal
    idle = vals[3] + vals[4]
    total = sum(vals)
    return total - idle, total


def read_mem():
    want = {b"MemTotal:", b"MemAvailable:", b"SwapTotal:", b"SwapFree:"}
    got = {}
    with open(os.path.join(PROC, "meminfo"), "rb") as fh:
        for line in fh:
            parts = line.split()
            if parts and parts[0] in want:
                got[parts[0][:-1].decode()] = int(parts[1]) * 1024
            if len(got) == len(want):
                break
    return got


def physical_ifaces():
    """Network cards with a device behind them (physical or virtual NICs): not
    lo, docker0, bridges or the containers' veth pairs."""
    out = []
    try:
        for name in os.listdir(SYS_NET):
            if os.path.exists(os.path.join(SYS_NET, name, "device")):
                out.append(name)
    except OSError:
        pass
    return sorted(out)


def link_mbps(ifaces):
    total = 0
    for n in ifaces:
        try:
            with open(os.path.join(SYS_NET, n, "speed")) as fh:
                v = int(fh.read().strip())
            if 0 < v < 1_000_000:
                total += v
        except (OSError, ValueError):
            pass
    return total or None


def read_net(ifaces):
    """(rx_bytes, tx_bytes) summed over the given interfaces."""
    rx = tx = 0
    want = set(ifaces)
    with open(os.path.join(PROC, "net", "dev"), "rb") as fh:
        for line in fh.readlines()[2:]:
            name, _, rest = line.decode("ascii", "replace").partition(":")
            if name.strip() in want:
                f = rest.split()
                rx += int(f[0]); tx += int(f[8])
    return rx, tx


def read_load():
    with open(os.path.join(PROC, "loadavg")) as fh:
        a = fh.read().split()
    return float(a[0]), float(a[1]), float(a[2])


def write_atomic(data):
    tmp = OUT + ".tmp"
    with open(tmp, "w") as fh:
        json.dump(data, fh, separators=(",", ":"))
    os.chmod(tmp, 0o644)
    os.replace(tmp, OUT)


def pct(a, b):
    return round(100.0 * a / b, 1) if b else 0.0


def main():
    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)
    os.makedirs(OUT_DIR, exist_ok=True)
    cores = os.cpu_count() or 1
    hist = deque(maxlen=HISTORY)
    ifaces, iface_check = physical_ifaces(), 0
    link = link_mbps(ifaces)
    prev_cpu = read_cpu()
    prev_net = read_net(ifaces)
    prev_t = time.monotonic()
    last_err = 0.0
    next_tick = prev_t + INTERVAL
    while _running:
        time.sleep(max(0.0, next_tick - time.monotonic()))
        next_tick += INTERVAL
        if next_tick < time.monotonic():           # suspended or very late: do not catch up
            next_tick = time.monotonic() + INTERVAL
        try:
            now = time.monotonic()
            dt = max(0.5, now - prev_t)
            iface_check += 1
            if iface_check >= 60:                  # NICs added or removed: look again every 5 minutes
                iface_check = 0
                new = physical_ifaces()
                if new != ifaces:
                    ifaces, link = new, link_mbps(new)
                    prev_net = read_net(ifaces)
            busy, total = read_cpu()
            cpu = pct(busy - prev_cpu[0], total - prev_cpu[1])
            prev_cpu = (busy, total)
            m = read_mem()
            mt, ma = m.get("MemTotal", 0), m.get("MemAvailable", 0)
            st, sf = m.get("SwapTotal", 0), m.get("SwapFree", 0)
            rx, tx = read_net(ifaces)
            rx_bps = max(0, rx - prev_net[0]) * 8 / dt
            tx_bps = max(0, tx - prev_net[1]) * 8 / dt
            prev_net, prev_t = (rx, tx), now
            scale = (link or ASSUMED_LINK_MBPS) * 1e6
            net = min(100.0, round(100.0 * max(rx_bps, tx_bps) / scale, 1))
            l1, l5, l15 = read_load()
            mem = pct(mt - ma, mt)
            ts = int(time.time())
            hist.append([ts, cpu, mem, net])
            ru = resource.getrusage(resource.RUSAGE_SELF)
            write_atomic({
                "v": 1, "ts": ts, "interval": INTERVAL,
                "cpu": {"pct": cpu, "cores": cores, "load": [l1, l5, l15]},
                "mem": {"pct": mem, "used": mt - ma, "total": mt,
                        "swap_pct": pct(st - sf, st), "swap_total": st},
                "net": {"pct": net, "rx_bps": int(rx_bps), "tx_bps": int(tx_bps),
                        "link_mbps": link, "link_assumed": link is None, "nics": len(ifaces)},
                "history": list(hist),
                "collector": {"cpu_s": round(ru.ru_utime + ru.ru_stime, 2), "rss_kb": ru.ru_maxrss,
                              "since": _START_WALL},
            })
        except Exception as e:                     # keep measuring; say why at most once a minute
            if time.monotonic() - last_err > 60:
                last_err = time.monotonic()
                print("patch01-metrics: " + type(e).__name__ + ": " + str(e)[:200], file=sys.stderr, flush=True)
    return 0


_START_WALL = int(time.time())

if __name__ == "__main__":
    sys.exit(main())
