#!/usr/bin/env python3
"""
PATCH-01 phase 2 : repository definitions and sync

Reads config/repos.conf and, for each repository, creates the four Pulp
objects needed to mirror and serve it:

    remote        where to fetch from, with proxy and entitlement certs
    repository    the versioned container for content
    publication   an immutable snapshot of a repository version
    distribution  the URL clients download from

Written in Python rather than bash because the Pulp API needs real JSON
handling: entitlement certificates are multi-line PEM data that must be
embedded in request bodies, and every sync is an async task that has to be
polled to completion.

Idempotent. Re-running skips objects that already exist.

Usage:
    ./phase2-repos.py --dry-run          show the plan, change nothing
    ./phase2-repos.py --setup            create remotes and repositories
    ./phase2-repos.py --sync             sync all repositories
    ./phase2-repos.py --sync NAME        sync one repository
    ./phase2-repos.py --publish          publish and distribute
    ./phase2-repos.py --all              setup, sync, publish
    ./phase2-repos.py --status           show what exists and disk usage
    ./phase2-repos.py --test-entitlement check the RHEL certs work
"""

import argparse
import base64
import glob
import json
import os
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime

ETC_DIR = "/etc/patch-platform"
PATCH_BASE = "/patch"
SECRETS_DIR = f"{PATCH_BASE}/secrets"
LOG_DIR = "/var/log/patch-platform"

ENTITLEMENT_DIR = "/etc/pki/entitlement"
RHSM_CA = "/etc/rhsm/ca/redhat-uep.pem"

API_BASE = "https://127.0.0.1/pulp/api/v3"

# Pulp plugin endpoints differ by content type
ENDPOINTS = {
    "rpm": {
        "remote": "/remotes/rpm/rpm/",
        "repository": "/repositories/rpm/rpm/",
        "publication": "/publications/rpm/rpm/",
        "distribution": "/distributions/rpm/rpm/",
    },
    "deb": {
        "remote": "/remotes/deb/apt/",
        "repository": "/repositories/deb/apt/",
        "publication": "/publications/deb/apt/",
        "distribution": "/distributions/deb/apt/",
    },
}

log_lines = []


def log(msg):
    stamp = datetime.now().strftime("%F %T")
    log_lines.append(f"{stamp}  {msg}")


def say(msg):
    print(msg)
    log(msg)


def warn(msg):
    print(f"WARN: {msg}", file=sys.stderr)
    log(f"WARN: {msg}")


def step(msg):
    print(f"\n==> {msg}")
    log(f"STEP: {msg}")


def die(msg):
    log(f"FATAL: {msg}")
    flush_log()
    print(f"\nERROR: {msg}", file=sys.stderr)
    sys.exit(1)


LOG_FILE = os.path.join(LOG_DIR, f"phase2-{datetime.now().strftime('%Y%m%d-%H%M%S')}.log")


def flush_log():
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(LOG_FILE, "a") as fh:
            fh.write("\n".join(log_lines) + "\n")
        os.chmod(LOG_FILE, 0o600)
        log_lines.clear()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Config loading
# ---------------------------------------------------------------------------

def read_env_file(path):
    """Read KEY=VALUE lines without executing the file."""
    out = {}
    if not os.path.exists(path):
        return out
    with open(path) as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def load_repos(path):
    """Parse repos.conf into a list of dicts."""
    if not os.path.exists(path):
        die(f"Repository definition file not found: {path}")

    repos = []
    seen = set()
    with open(path) as fh:
        for lineno, raw in enumerate(fh, 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            parts = [p.strip() for p in line.split("|")]
            if len(parts) < 5:
                die(f"{path}:{lineno}: expected at least 5 pipe-separated fields, got {len(parts)}")

            name, rtype, url, policy, auth = parts[:5]
            extra = parts[5] if len(parts) > 5 else ""

            if not name:
                die(f"{path}:{lineno}: empty repository name")
            if name in seen:
                die(f"{path}:{lineno}: duplicate repository name '{name}'")
            seen.add(name)

            if rtype not in ENDPOINTS:
                die(f"{path}:{lineno}: type must be rpm or deb, got '{rtype}'")
            if policy not in ("immediate", "on_demand", "streamed"):
                die(f"{path}:{lineno}: policy must be immediate, on_demand or streamed")
            if auth not in ("none", "entitlement"):
                die(f"{path}:{lineno}: auth must be none or entitlement")
            if not url.startswith(("http://", "https://")):
                die(f"{path}:{lineno}: url must start with http:// or https://")

            # Parse the deb-specific extra field
            opts = {}
            if extra:
                for chunk in extra.split(";"):
                    if "=" in chunk:
                        k, _, v = chunk.partition("=")
                        opts[k.strip()] = v.strip()

            if rtype == "deb" and "distributions" not in opts:
                die(f"{path}:{lineno}: deb repositories need distributions=<pockets> in the extra field")

            repos.append({
                "name": name, "type": rtype, "url": url,
                "policy": policy, "auth": auth, "opts": opts,
            })
    return repos


# ---------------------------------------------------------------------------
# Entitlement certificates
# ---------------------------------------------------------------------------

def find_entitlement_certs():
    """Locate the Red Hat entitlement cert/key pair.

    The directory holds numerically-named files; the key is <serial>-key.pem
    and the certificate is <serial>.pem. Picks the newest pair.
    """
    if not os.path.isdir(ENTITLEMENT_DIR):
        return None, None, None

    keys = sorted(glob.glob(os.path.join(ENTITLEMENT_DIR, "*-key.pem")),
                  key=os.path.getmtime, reverse=True)
    for keypath in keys:
        certpath = keypath.replace("-key.pem", ".pem")
        if os.path.exists(certpath):
            ca = RHSM_CA if os.path.exists(RHSM_CA) else None
            return certpath, keypath, ca
    return None, None, None


def read_pem(path):
    with open(path) as fh:
        return fh.read()


def cert_expiry(certpath):
    """Return the notAfter date of a certificate, or None."""
    try:
        out = subprocess.run(
            ["openssl", "x509", "-enddate", "-noout", "-in", certpath],
            capture_output=True, text=True, timeout=10,
        )
        if out.returncode == 0:
            return out.stdout.strip().split("=", 1)[1]
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Pulp API client
# ---------------------------------------------------------------------------

class Pulp:
    def __init__(self, base, user, password):
        self.base = base.rstrip("/")
        token = base64.b64encode(f"{user}:{password}".encode()).decode()
        self.auth = f"Basic {token}"
        # NGINX serves a self-signed placeholder certificate, and this client
        # only ever talks to 127.0.0.1, so verification is skipped here.
        self.ctx = ssl.create_default_context()
        self.ctx.check_hostname = False
        self.ctx.verify_mode = ssl.CERT_NONE

    def _url(self, path):
        """Build an absolute URL from either a short path or a pulp_href.

        Pulp returns hrefs as absolute paths that already include the API
        prefix, so those must not have the base prepended again -- doing so
        yields /pulp/api/v3/pulp/api/v3/... and a 404.
        """
        if path.startswith("http"):
            return path
        if path.startswith("/pulp/api/v3"):
            # An href: join to the scheme+host only
            from urllib.parse import urlsplit
            parts = urlsplit(self.base)
            return f"{parts.scheme}://{parts.netloc}{path}"
        return self.base + path

    def request(self, method, path, body=None, timeout=120):
        url = self._url(path)
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Authorization", self.auth)
        req.add_header("Accept", "application/json")
        if data:
            req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, context=self.ctx, timeout=timeout) as resp:
                raw = resp.read().decode()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            detail = e.read().decode()[:2000]
            raise RuntimeError(f"HTTP {e.code} on {method} {url}\n{detail}") from None
        except urllib.error.URLError as e:
            raise RuntimeError(f"Cannot reach {url}: {e.reason}") from None

    def get(self, path, **kw):
        return self.request("GET", path, **kw)

    def post(self, path, body, **kw):
        return self.request("POST", path, body, **kw)

    def find_by_name(self, endpoint, name):
        """Return the href of an object with this exact name, or None."""
        res = self.get(f"{endpoint}?name={urllib.parse.quote(name)}")
        for item in res.get("results", []):
            if item.get("name") == name:
                return item["pulp_href"]
        return None

    def wait_task(self, task_href, label="task", poll=3, timeout=14400):
        """Poll an async task to completion. Sync tasks can run for hours."""
        start = time.time()
        last_state = None
        while True:
            t = self.get(task_href)
            state = t.get("state")

            if state != last_state:
                say(f"    {label}: {state}")
                last_state = state

            if state == "completed":
                return t
            if state in ("failed", "canceled"):
                err = t.get("error") or {}
                msg = err.get("description") or err.get("reason") or json.dumps(err)[:1500]
                raise RuntimeError(f"{label} {state}: {msg}")

            elapsed = int(time.time() - start)
            if elapsed > timeout:
                raise RuntimeError(f"{label} still {state} after {elapsed}s; giving up polling")

            # Show progress for long syncs
            for rep in t.get("progress_reports", []):
                done = rep.get("done")
                total = rep.get("total")
                if done and total:
                    pct = int(100 * done / total)
                    print(f"\r    {rep.get('message','working')}: {done}/{total} ({pct}%)   ",
                          end="", flush=True)
                elif done:
                    print(f"\r    {rep.get('message','working')}: {done}   ",
                          end="", flush=True)
            time.sleep(poll)


# ---------------------------------------------------------------------------
# Object creation
# ---------------------------------------------------------------------------

def build_remote_body(repo, proxy_url, certs):
    ep = ENDPOINTS[repo["type"]]
    body = {
        "name": f"{repo['name']}-remote",
        "url": repo["url"],
        "policy": repo["policy"],
        # Timeouts matched to what Red Hat Satellite uses for its own CDN
        # remotes. A 120s read timeout is not enough for a large repository
        # through a corporate proxy; Satellite uses an hour.
        "connect_timeout": 60.0,
        "sock_connect_timeout": 60.0,
        "sock_read_timeout": 3600.0,
        "total_timeout": 0.0,
        "download_concurrency": 5,
    }

    if proxy_url:
        body["proxy_url"] = proxy_url

    if repo["auth"] == "entitlement":
        certpath, keypath, ca = certs
        if not certpath:
            die(f"{repo['name']} needs entitlement certs but none were found in {ENTITLEMENT_DIR}")
        body["client_cert"] = read_pem(certpath)
        body["client_key"] = read_pem(keypath)
        if ca:
            body["ca_cert"] = read_pem(ca)

    if repo["type"] == "deb":
        opts = repo["opts"]
        body["distributions"] = opts["distributions"]
        if "components" in opts:
            body["components"] = opts["components"]
        if "architectures" in opts:
            body["architectures"] = opts["architectures"]
        # Ubuntu archives are signed; Pulp verifies the Release signature
        body["gpgkey"] = opts.get("gpgkey", "")
        if not body["gpgkey"]:
            del body["gpgkey"]
            body["ignore_missing_package_indices"] = True

    return ep["remote"], body


def build_repository_body(repo):
    ep = ENDPOINTS[repo["type"]]
    body = {"name": repo["name"]}
    if repo["type"] == "rpm":
        # 3, not 1. Setting this to 1 prunes older builds and makes a
        # downgrade impossible, which removes the only rollback path on
        # apt hosts and complicates it on RPM hosts.
        body["retain_package_versions"] = 3
    return ep["repository"], body


def ensure_objects(pulp, repos, proxy_url, certs, dry_run):
    """Create remotes and repositories that do not already exist."""
    created = {"remote": 0, "repository": 0}
    state = {}

    for repo in repos:
        name = repo["name"]
        ep = ENDPOINTS[repo["type"]]
        say(f"  {name}  ({repo['type']}, {repo['policy']}, auth={repo['auth']})")

        if dry_run:
            say(f"    [dry-run] would create remote and repository")
            continue

        # Remote
        rem_ep, rem_body = build_remote_body(repo, proxy_url, certs)
        rem_href = pulp.find_by_name(rem_ep, rem_body["name"])
        if rem_href:
            say(f"    remote exists")
        else:
            res = pulp.post(rem_ep, rem_body)
            rem_href = res["pulp_href"]
            created["remote"] += 1
            say(f"    remote created")

        # Repository
        rep_ep, rep_body = build_repository_body(repo)
        rep_href = pulp.find_by_name(rep_ep, name)
        if rep_href:
            say(f"    repository exists")
        else:
            res = pulp.post(rep_ep, rep_body)
            rep_href = res["pulp_href"]
            created["repository"] += 1
            say(f"    repository created")

        state[name] = {"remote": rem_href, "repository": rep_href, "repo": repo}

    if not dry_run:
        say(f"\n  created {created['remote']} remote(s), {created['repository']} repository(ies)")
    return state


def sync_repo(pulp, name, info):
    """Trigger a sync and wait for it."""
    repo = info["repo"]
    body = {"remote": info["remote"], "sync_policy": "mirror_content_only"}
    say(f"  syncing {name} ...")
    res = pulp.post(f"{info['repository']}sync/", body)
    task = res.get("task")
    if not task:
        raise RuntimeError(f"No task returned for {name}: {json.dumps(res)[:500]}")
    t = pulp.wait_task(task, label=f"sync {name}")
    print()
    return t


def publish_and_distribute(pulp, name, info):
    """Create a publication from the latest version and point a distribution at it."""
    repo = info["repo"]
    ep = ENDPOINTS[repo["type"]]

    # Latest repository version
    rep = pulp.get(info["repository"])
    version = rep.get("latest_version_href")
    if not version or version.endswith("/versions/0/"):
        warn(f"  {name}: no content yet (version 0); sync before publishing")
        return None

    say(f"  publishing {name} from {version.rstrip('/').split('/')[-1]}")
    pub_body = {"repository_version": version}
    if repo["type"] == "deb":
        # simple=True produces a flat structure most apt clients accept
        pub_body["simple"] = True
        pub_body["structured"] = True

    res = pulp.post(ep["publication"], pub_body)
    t = pulp.wait_task(res["task"], label=f"publish {name}")
    pub_href = None
    for r in t.get("created_resources", []):
        if "/publications/" in r:
            pub_href = r
            break
    if not pub_href:
        raise RuntimeError(f"Publication href not returned for {name}")

    # Distribution: the URL clients fetch from
    dist_name = name
    base_path = name
    existing = pulp.find_by_name(ep["distribution"], dist_name)
    if existing:
        say(f"    updating distribution")
        res = pulp.request("PATCH", existing, {"publication": pub_href})
        if "task" in res:
            pulp.wait_task(res["task"], label=f"distribute {name}")
    else:
        say(f"    creating distribution at /pulp/content/{base_path}/")
        res = pulp.post(ep["distribution"], {
            "name": dist_name,
            "base_path": base_path,
            "publication": pub_href,
        })
        if "task" in res:
            pulp.wait_task(res["task"], label=f"distribute {name}")

    print()
    return pub_href


# ---------------------------------------------------------------------------
# Entitlement test
# ---------------------------------------------------------------------------

def test_entitlement(certs, proxy_url):
    """Verify the entitlement certs can actually reach the Red Hat CDN.

    Done with curl before defining any remote, because an entitlement
    problem otherwise surfaces as a failed Pulp task with a 403 buried in
    the traceback.
    """
    certpath, keypath, ca = certs
    if not certpath:
        die(f"No entitlement certificate pair found in {ENTITLEMENT_DIR}")

    say(f"Certificate: {certpath}")
    say(f"Key:         {keypath}")
    say(f"CA:          {ca or 'not found (will use system trust)'}")
    exp = cert_expiry(certpath)
    if exp:
        say(f"Expires:     {exp}")

    urls = {
        "RHEL 8 BaseOS": "https://cdn.redhat.com/content/dist/rhel8/8/x86_64/baseos/os/repodata/repomd.xml",
        "RHEL 9 BaseOS": "https://cdn.redhat.com/content/dist/rhel9/9/x86_64/baseos/os/repodata/repomd.xml",
        "RHEL 10 BaseOS": "https://cdn.redhat.com/content/dist/rhel10/10/x86_64/baseos/os/repodata/repomd.xml",
    }

    results = {}
    for label, url in urls.items():
        cmd = ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
               "--max-time", "60",
               "--cert", certpath, "--key", keypath]
        if ca:
            cmd += ["--cacert", ca]
        if proxy_url:
            cmd += ["--proxy", proxy_url]
        cmd.append(url)

        try:
            out = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
            code = out.stdout.strip() or "000"
        except Exception as e:
            code = f"error: {e}"

        results[label] = code
        if code == "200":
            say(f"  {label:16} HTTP {code}  entitled")
        elif code in ("403", "401"):
            warn(f"  {label:16} HTTP {code}  NOT entitled by this certificate")
        elif code == "000":
            warn(f"  {label:16} no response - proxy or DNS problem")
        else:
            warn(f"  {label:16} HTTP {code}")

    entitled = [k for k, v in results.items() if v == "200"]
    if not entitled:
        warn("")
        warn("No RHEL content is reachable. Check:")
        warn("  - subscription-manager status")
        warn("  - the proxy allows cdn.redhat.com")
        warn("  - the entitlement certificate has not expired")
    else:
        say(f"\nEntitled: {', '.join(entitled)}")
    return results


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------

def show_status(pulp, repos):
    step("Pulp status")
    try:
        st = pulp.get("/status/")
        say(f"  workers online: {len(st.get('online_workers', []))}")
        say(f"  content apps:   {len(st.get('online_content_apps', []))}")
        db = st.get("database_connection", {}).get("connected")
        say(f"  database:       {'connected' if db else 'NOT CONNECTED'}")
    except Exception as e:
        warn(f"  could not read status: {e}")

    step("Repositories")
    for repo in repos:
        name = repo["name"]
        ep = ENDPOINTS[repo["type"]]
        try:
            href = pulp.find_by_name(ep["repository"], name)
            if not href:
                say(f"  {name:22} not created")
                continue
            r = pulp.get(href)
            vhref = r.get("latest_version_href") or ""
            ver = vhref.rstrip("/").split("/")[-1] if vhref else "0"
            counts = "not synced yet"
            if vhref:
                content = pulp.get(vhref)
                summary = content.get("content_summary", {}).get("present", {})
                if summary:
                    counts = ", ".join(f"{k.split('.')[-1]}={v.get('count',0)}"
                                       for k, v in list(summary.items())[:3])
                else:
                    counts = "empty"
            dist = pulp.find_by_name(ep["distribution"], name)
            say(f"  {name:22} v{ver:<4} {counts:40} {'distributed' if dist else 'not distributed'}")
        except Exception as e:
            warn(f"  {name:22} error: {str(e)[:80]}")

    step("Disk usage")
    try:
        out = subprocess.run(["df", "-Ph", f"{PATCH_BASE}/data/pulp"],
                             capture_output=True, text=True, timeout=10)
        for line in out.stdout.strip().split("\n")[1:]:
            f = line.split()
            say(f"  {f[1]} total, {f[2]} used, {f[3]} available ({f[4]} full)")
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--setup", action="store_true", help="create remotes and repositories")
    ap.add_argument("--sync", nargs="?", const="__ALL__", help="sync all, or one by name")
    ap.add_argument("--publish", action="store_true", help="publish and distribute")
    ap.add_argument("--all", action="store_true", help="setup, sync, publish")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--test-entitlement", action="store_true")
    ap.add_argument("--update-remotes", action="store_true",
                    help="PATCH existing remotes with current settings and certs")
    ap.add_argument("--config", default=None)
    args = ap.parse_args()

    if os.geteuid() != 0:
        die("Run as root (the entitlement certs and secrets are root-only).")

    # Config file lives beside the script, one level up
    script_dir = os.path.dirname(os.path.abspath(__file__))
    cfg = args.config or os.path.join(os.path.dirname(script_dir), "config", "repos.conf")

    step("Loading configuration")
    repos = load_repos(cfg)
    say(f"  {len(repos)} repository(ies) defined in {cfg}")
    by_type = {}
    for r in repos:
        by_type[r["type"]] = by_type.get(r["type"], 0) + 1
    say(f"  {by_type.get('rpm',0)} rpm, {by_type.get('deb',0)} deb")
    imm = sum(1 for r in repos if r["policy"] == "immediate")
    say(f"  {imm} immediate, {len(repos)-imm} on_demand")

    # Proxy
    proxy = read_env_file(f"{ETC_DIR}/proxy.env")
    proxy_url = proxy.get("HTTPS_PROXY") or proxy.get("https_proxy") or ""
    say(f"  proxy: {proxy_url or 'none configured'}")

    # Entitlement
    certs = find_entitlement_certs()
    needs_ent = any(r["auth"] == "entitlement" for r in repos)
    if needs_ent:
        if certs[0]:
            exp = cert_expiry(certs[0])
            say(f"  entitlement: {os.path.basename(certs[0])} (expires {exp or 'unknown'})")
        else:
            warn(f"  entitlement: NONE FOUND in {ENTITLEMENT_DIR}")
            warn("  RHEL repositories will fail. Run --test-entitlement for detail.")

    if args.test_entitlement:
        step("Testing entitlement against the Red Hat CDN")
        test_entitlement(certs, proxy_url)
        flush_log()
        return

    # Admin credentials
    admin_file = f"{SECRETS_DIR}/pulp-admin.txt"
    if not os.path.exists(admin_file):
        die(f"Missing {admin_file}. Run phase1c-pulp.sh --reset-admin")
    password = None
    with open(admin_file) as fh:
        for line in fh:
            if "password:" in line:
                password = line.split("password:", 1)[1].strip()
                break
    if not password:
        die(f"Could not read the admin password from {admin_file}")

    pulp = Pulp(API_BASE, "admin", password)

    # Confirm the API is reachable before doing anything
    if not args.dry_run:
        step("Checking the Pulp API")
        try:
            st = pulp.get("/status/")
            vers = ", ".join(f"{c['component']} {c['version']}"
                             for c in st.get("versions", [])[:4])
            say(f"  {vers}")
            nworkers = len(st.get("online_workers", []))
            if nworkers == 0:
                die("No online Pulp workers. Syncs would queue forever. "
                    "Check: docker logs patch01-pulp-worker")
            say(f"  {nworkers} worker(s) online")
        except RuntimeError as e:
            die(f"Pulp API unreachable: {e}")

    if args.status:
        show_status(pulp, repos)
        flush_log()
        return

    if args.update_remotes:
        # Remotes store settings and certificate content at creation time.
        # This re-applies the current values -- needed after raising a
        # timeout, changing the proxy, or refreshing entitlement certs.
        step("Updating existing remotes")
        n = 0
        for repo in repos:
            ep = ENDPOINTS[repo["type"]]
            rem_ep, rem_body = build_remote_body(repo, proxy_url, certs)
            href = pulp.find_by_name(rem_ep, rem_body["name"])
            if not href:
                say(f"  {repo['name']:22} no remote yet, skipping")
                continue
            body = {k: v for k, v in rem_body.items() if k != "name"}
            res = pulp.request("PATCH", href, body)
            if "task" in res:
                pulp.wait_task(res["task"], label=f"update {repo['name']}")
            say(f"  {repo['name']:22} updated")
            n += 1
        say(f"\n  {n} remote(s) updated")
        flush_log()
        return

    do_setup = args.setup or args.all or args.dry_run
    do_sync = args.sync is not None or args.all
    do_publish = args.publish or args.all

    if not (do_setup or do_sync or do_publish):
        say("\nNothing to do. Pick one of --setup, --sync, --publish, --all, --status.")
        say("Suggested first run:")
        say("  ./phase2-repos.py --test-entitlement")
        say("  ./phase2-repos.py --dry-run")
        say("  ./phase2-repos.py --setup")
        say("  ./phase2-repos.py --sync ol8-baseos     # prove one repo first")
        flush_log()
        return

    state = {}
    if do_setup:
        step("Creating remotes and repositories")
        state = ensure_objects(pulp, repos, proxy_url, certs, args.dry_run)

    if args.dry_run:
        step("Dry run complete")
        say("  Nothing was created. Re-run with --setup to proceed.")
        flush_log()
        return

    # Rebuild state for sync/publish-only invocations
    if not state:
        for repo in repos:
            ep = ENDPOINTS[repo["type"]]
            rem = pulp.find_by_name(ep["remote"], f"{repo['name']}-remote")
            rep = pulp.find_by_name(ep["repository"], repo["name"])
            if rem and rep:
                state[repo["name"]] = {"remote": rem, "repository": rep, "repo": repo}

    if do_sync:
        target = args.sync if args.sync and args.sync != "__ALL__" else None
        names = [target] if target else list(state.keys())
        if target and target not in state:
            die(f"Unknown repository '{target}'. Defined: {', '.join(state.keys())}")

        step(f"Syncing {len(names)} repository(ies)")
        say("  The first sync of a large repository can take a long time.")
        failed = []
        for name in names:
            try:
                sync_repo(pulp, name, state[name])
            except RuntimeError as e:
                warn(f"  {name} FAILED: {str(e)[:600]}")
                failed.append(name)
        if failed:
            warn(f"\n  {len(failed)} sync(s) failed: {', '.join(failed)}")
            if any(state[f]["repo"]["auth"] == "entitlement" for f in failed):
                warn("  For RHEL failures run: --test-entitlement")
        else:
            say(f"\n  all {len(names)} sync(s) completed")

    if do_publish:
        step("Publishing and distributing")
        for name in state:
            try:
                publish_and_distribute(pulp, name, state[name])
            except RuntimeError as e:
                warn(f"  {name} FAILED: {str(e)[:600]}")

    step("Summary")
    show_status(pulp, repos)

    print()
    print("================================================================")
    print(" PHASE 2")
    print("================================================================")
    print(f" Config: {cfg}")
    print(f" Log:    {LOG_FILE}")
    print()
    print(" Client repo URL pattern:")
    print("   https://<this-host>/pulp/content/<name>/")
    print()
    print(" Next: create a publication snapshot per environment, point test")
    print(" hosts at it, then promote the same snapshot to production.")
    flush_log()


if __name__ == "__main__":
    try:
        import urllib.parse  # noqa: F401  (used in find_by_name)
        main()
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        flush_log()
        sys.exit(130)
