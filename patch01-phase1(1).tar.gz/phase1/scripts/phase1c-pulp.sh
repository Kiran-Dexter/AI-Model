#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 phase 1c : Pulp (api, content, worker)
#
# Deploys the repository service against the PostgreSQL and Redis from
# phase 1b, behind the NGINX ingress from phase 1a.
#
# Everything image-specific is discovered, not assumed:
#   - the UID/GID Pulp runs as inside the image is read from the image
#     config, because a wrong guess produces a permission failure on the
#     600 GB artifact volume
#   - database and Redis details come from phase1b.env and the secrets file
#   - the image itself comes from images.env
#
# Usage:
#   ./phase1c-pulp.sh                deploy
#   ./phase1c-pulp.sh --dry-run      show the plan only
#   ./phase1c-pulp.sh --check        validate an existing deployment
#   ./phase1c-pulp.sh --down         stop (data is kept)
#   ./phase1c-pulp.sh --reset-admin  set a new admin password
#   ./phase1c-pulp.sh --logs         tail all Pulp logs
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 027

VERSION="1.0.0"
PATCH_BASE="/patch"
ETC_DIR="/etc/patch-platform"
LOG_DIR="/var/log/patch-platform"
IMAGES_MANIFEST="$ETC_DIR/images.env"
PHASE1B_ENV="$ETC_DIR/phase1b.env"

DRY_RUN=no
CHECK_ONLY=no
DO_DOWN=no
RESET_ADMIN=no
SHOW_LOGS=no

while (($#)); do
  case "$1" in
    --dry-run)     DRY_RUN=yes ;;
    --check)       CHECK_ONLY=yes ;;
    --down)        DO_DOWN=yes ;;
    --reset-admin) RESET_ADMIN=yes ;;
    --logs)        SHOW_LOGS=yes ;;
    --base)        PATCH_BASE="${2:-}"; shift ;;
    -h|--help)     sed -n '2,22p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/phase1c-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"

log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }

run() {
  if [[ "$DRY_RUN" == yes ]]; then printf '  [dry-run] %s\n' "$*"; return 0; fi
  log "EXEC: $*"
  "$@" </dev/null >>"$LOG_FILE" 2>&1
}

confirm() {
  local p="$1" d="${2:-y}" r hint="[y/N]"
  [[ "$d" == y ]] && hint="[Y/n]" || true
  [[ -t 0 ]] || { [[ "$d" == y ]]; return; }
  read -r -p "$p $hint: " r || true
  r="${r:-$d}"; [[ "${r,,}" =~ ^(y|yes)$ ]]
}

[[ $EUID -eq 0 ]] || die "Run as root."

COMPOSE_DIR="$PATCH_BASE/compose"
CONFIG_DIR="$PATCH_BASE/config"
SECRETS_DIR="$PATCH_BASE/secrets"
PULP_DATA_DIR="$PATCH_BASE/data/pulp"
COMPOSE_FILE="$COMPOSE_DIR/docker-compose.pulp.yml"

PULP_CONTAINERS=(patch01-pulp-api patch01-pulp-content patch01-pulp-worker)

# ---------------------------------------------------------------------------
# Simple modes
# ---------------------------------------------------------------------------
if [[ "$SHOW_LOGS" == yes ]]; then
  [[ -f "$COMPOSE_FILE" ]] || die "Not deployed yet."
  exec docker compose -f "$COMPOSE_FILE" logs -f --tail 50
fi

if [[ "$DO_DOWN" == yes ]]; then
  step "Stopping Pulp"
  if [[ -f "$COMPOSE_FILE" ]]; then
    (cd "$COMPOSE_DIR" && docker compose -f "$COMPOSE_FILE" down) \
      || warn "compose down reported errors"
  fi
  for c in "${PULP_CONTAINERS[@]}" patch01-pulp-migrate; do
    docker rm -f "$c" >/dev/null 2>&1 || true
  done
  say "Stopped. Artifacts in $PULP_DATA_DIR and the database are untouched."
  exit 0
fi

# ---------------------------------------------------------------------------
# Preconditions
# ---------------------------------------------------------------------------
step "Checking preconditions"

command -v docker >/dev/null 2>&1 || die "Docker is not installed."
docker info >/dev/null 2>&1 || die "The Docker daemon is not responding."
docker compose version >/dev/null 2>&1 || die "The docker compose plugin is missing."

[[ -f "$IMAGES_MANIFEST" ]] || die "No $IMAGES_MANIFEST. Run resolve-images.sh first."
[[ -f "$PHASE1B_ENV" ]]     || die "No $PHASE1B_ENV. Run phase1b-data.sh first."

# shellcheck disable=SC1090
source "$IMAGES_MANIFEST"
# shellcheck disable=SC1090
source "$PHASE1B_ENV"

PULP_IMAGE="${IMG_PULP:-}"
[[ -n "$PULP_IMAGE" ]] || die "The manifest has no pulp image. Re-run resolve-images.sh"
docker image inspect "$PULP_IMAGE" >/dev/null 2>&1 \
  || die "Manifest lists $PULP_IMAGE but it is not present. Re-run resolve-images.sh"

say "Pulp image: $PULP_IMAGE"
say "  pulpcore ${VER_PULPCORE:-unknown}"
say "  plugins  ${VER_PULP_PLUGINS:-unknown}"

# Both plugins are required for this project's four distro families
printf '%s' "${VER_PULP_PLUGINS:-}" | grep -qi 'pulp-rpm' \
  || warn "pulp_rpm not detected - RHEL and Oracle Linux mirroring will not work"
printf '%s' "${VER_PULP_PLUGINS:-}" | grep -qi 'pulp-deb' \
  || warn "pulp_deb not detected - Ubuntu mirroring will not work"

# Data plane must be up and healthy
for c in patch01-postgres patch01-redis; do
  docker ps --format '{{.Names}}' | grep -qx "$c" \
    || die "$c is not running. Run phase1b-data.sh first."
done
say "PostgreSQL and Redis are running."

if ! docker network inspect patchnet >/dev/null 2>&1; then
  die "The patchnet network is missing. Run phase1a-ingress.sh first."
fi

[[ -d "$PULP_DATA_DIR" ]] || die "Missing $PULP_DATA_DIR (run the phase 0 bootstrap)."

# Report the artifact volume size, since this is the one that fills
PULP_FS="$(df -Ph "$PULP_DATA_DIR" | awk 'NR==2{print $2" total, "$4" available"}')"
say "Artifact volume: $PULP_FS"

# ---------------------------------------------------------------------------
# Discover the UID Pulp runs as INSIDE the image
#
# Guessing this wrong is the failure mode that has bitten twice already, so
# read it from the image config rather than assuming.
# ---------------------------------------------------------------------------
step "Detecting the Pulp runtime user"

IMG_USER="$(docker image inspect "$PULP_IMAGE" --format '{{.Config.User}}' 2>/dev/null || echo "")"
log "image Config.User = '${IMG_USER:-<empty>}'"

PULP_UID=""; PULP_GID=""

if [[ "$IMG_USER" =~ ^([0-9]+):([0-9]+)$ ]]; then
  PULP_UID="${BASH_REMATCH[1]}"; PULP_GID="${BASH_REMATCH[2]}"
elif [[ "$IMG_USER" =~ ^([0-9]+)$ ]]; then
  PULP_UID="${BASH_REMATCH[1]}"; PULP_GID="0"
elif [[ -n "$IMG_USER" ]]; then
  # A username: resolve it inside the image
  RESOLVED="$(docker run --rm --network none --entrypoint "" "$PULP_IMAGE" \
    sh -c "id -u $IMG_USER 2>/dev/null; id -g $IMG_USER 2>/dev/null" 2>/dev/null || true)"
  PULP_UID="$(printf '%s\n' "$RESOLVED" | sed -n 1p)"
  PULP_GID="$(printf '%s\n' "$RESOLVED" | sed -n 2p)"
fi

# Fall back to whatever the image actually runs as by default
if [[ ! "$PULP_UID" =~ ^[0-9]+$ ]]; then
  RESOLVED="$(docker run --rm --network none --entrypoint "" "$PULP_IMAGE" \
    sh -c 'id -u; id -g' 2>/dev/null || true)"
  PULP_UID="$(printf '%s\n' "$RESOLVED" | sed -n 1p)"
  PULP_GID="$(printf '%s\n' "$RESOLVED" | sed -n 2p)"
fi

[[ "$PULP_UID" =~ ^[0-9]+$ ]] || die "Could not determine the Pulp UID from $PULP_IMAGE"
[[ "$PULP_GID" =~ ^[0-9]+$ ]] || PULP_GID=0

say "Pulp runs as uid $PULP_UID, gid $PULP_GID  (from image config: '${IMG_USER:-default}')"

# ---------------------------------------------------------------------------
# Artifact directory ownership
# ---------------------------------------------------------------------------
step "Checking the artifact directory"

CUR_UID="$(stat -c '%u' "$PULP_DATA_DIR")"
CUR_GID="$(stat -c '%g' "$PULP_DATA_DIR")"

if [[ "$CUR_UID" == "$PULP_UID" ]]; then
  say "$PULP_DATA_DIR owned by $CUR_UID:$CUR_GID - correct"
else
  warn "$PULP_DATA_DIR is $CUR_UID:$CUR_GID but Pulp runs as $PULP_UID:$PULP_GID"
  if [[ "$DRY_RUN" == yes ]]; then
    printf '  [dry-run] chown -R %s:%s %s\n' "$PULP_UID" "$PULP_GID" "$PULP_DATA_DIR"
  elif confirm "Fix ownership? (may take a moment on a large volume)" y; then
    chown -R "$PULP_UID":"$PULP_GID" "$PULP_DATA_DIR" || die "chown failed."
    chmod 0750 "$PULP_DATA_DIR"
    say "Ownership corrected."
  else
    die "Pulp cannot write artifacts without this."
  fi
fi

# ---------------------------------------------------------------------------
# Check mode
# ---------------------------------------------------------------------------
if [[ "$CHECK_ONLY" == yes ]]; then
  step "Validating the deployment"
  FAILS=0

  for c in "${PULP_CONTAINERS[@]}"; do
    if docker ps --format '{{.Names}}' | grep -qx "$c"; then
      st="$(docker inspect "$c" --format '{{.State.Health.Status}}' 2>/dev/null || echo none)"
      say "$c: running, health=$st"
      [[ "$st" == healthy || "$st" == none ]] || FAILS=$((FAILS+1))
    else
      warn "$c is not running"; FAILS=$((FAILS+1))
    fi
  done

  step "API status through NGINX"
  if curl -fsk --max-time 15 https://127.0.0.1/pulp/api/v3/status/ -o /tmp/pulpstatus.$$ 2>/dev/null; then
    say "Reachable via the ingress."
    if command -v python3 >/dev/null 2>&1; then
      python3 - <<'PYEOF' 2>/dev/null || warn "Could not parse the status response"
import json,sys,glob,os
f=sorted(glob.glob('/tmp/pulpstatus.*'))[-1]
d=json.load(open(f))
print("  versions:", ", ".join(f"{c['component']} {c['version']}" for c in d.get('versions',[])))
print("  database:", "connected" if d.get('database_connection',{}).get('connected') else "NOT CONNECTED")
print("  redis:   ", "connected" if d.get('redis_connection',{}).get('connected') else "NOT CONNECTED")
w=d.get('online_workers',[])
print(f"  workers:  {len(w)} online")
cw=d.get('online_content_apps',[])
print(f"  content:  {len(cw)} app(s) online")
if not w: print("  WARNING: no online workers - syncs will queue forever")
PYEOF
    fi
    rm -f /tmp/pulpstatus.$$
  else
    warn "Pulp API not reachable through https://127.0.0.1/pulp/api/v3/status/"
    FAILS=$((FAILS+1))
  fi

  step "Content app through NGINX"
  code="$(curl -sk -o /dev/null -w '%{http_code}' --max-time 10 https://127.0.0.1/pulp/content/ || echo 000)"
  [[ "$code" =~ ^(200|404)$ ]] \
    && say "Content app responding (HTTP $code)" \
    || { warn "Content app returned HTTP $code"; FAILS=$((FAILS+1)); }

  step "Exposure check"
  for c in "${PULP_CONTAINERS[@]}"; do
    pmap="$(docker port "$c" 2>/dev/null || true)"
    [[ -z "$pmap" ]] && say "$c publishes no host port - correct" \
      || { warn "$c publishes: $pmap"; FAILS=$((FAILS+1)); }
  done

  (( FAILS == 0 )) && say "All checks passed." || die "$FAILS check(s) failed."
  exit 0
fi

# ---------------------------------------------------------------------------
# Reset admin password
# ---------------------------------------------------------------------------
if [[ "$RESET_ADMIN" == yes ]]; then
  docker ps --format '{{.Names}}' | grep -qx patch01-pulp-api \
    || die "patch01-pulp-api is not running."
  NEW_PW="$(openssl rand -base64 24 | tr -d '/+=\n' | cut -c1-24)"
  docker exec patch01-pulp-api pulpcore-manager reset-admin-password --password "$NEW_PW" \
    >>"$LOG_FILE" 2>&1 || die "Password reset failed. See $LOG_FILE"
  # Update the stored copy
  if [[ -f "$SECRETS_DIR/pulp-admin.txt" ]]; then
    cp -a "$SECRETS_DIR/pulp-admin.txt" "$SECRETS_DIR/pulp-admin.txt.$(date +%Y%m%d-%H%M%S).bak"
  fi
  printf 'Pulp admin\n  user:     admin\n  password: %s\n  updated:  %s\n' \
    "$NEW_PW" "$(date -Is)" >"$SECRETS_DIR/pulp-admin.txt"
  chmod 0600 "$SECRETS_DIR/pulp-admin.txt"
  say "Admin password reset. Stored in $SECRETS_DIR/pulp-admin.txt"
  exit 0
fi

# ---------------------------------------------------------------------------
# Credentials and settings
# ---------------------------------------------------------------------------
step "Preparing the Pulp configuration"

PG_ENV_FILE="$SECRETS_DIR/postgres.env"
[[ -f "$PG_ENV_FILE" ]] || die "Missing $PG_ENV_FILE (phase 1b generates it)."
# shellcheck disable=SC1090
source "$PG_ENV_FILE"

PULP_DB_NAME="${PULP_DB_NAME:-pulp}"
PULP_DB_USER="${PULP_DB_USER:-pulp}"
[[ -n "${PULP_DB_PASSWORD:-}" ]] || die "PULP_DB_PASSWORD missing from $PG_ENV_FILE"

PULP_ENV_FILE="$SECRETS_DIR/pulp.env"

if [[ -f "$PULP_ENV_FILE" ]]; then
  say "Existing Pulp env found; reusing it."
  PULP_SECRET_KEY="$(grep -E '^PULP_SECRET_KEY=' "$PULP_ENV_FILE" | cut -d= -f2- | tr -d '"' || true)"
else
  PULP_SECRET_KEY="$(openssl rand -base64 50 | tr -d '\n' | tr -d '/+=' | cut -c1-50)"
fi
[[ -n "$PULP_SECRET_KEY" ]] || die "Could not obtain a Pulp secret key."

# The content origin is the URL agents use. It must match the certificate
# and the NGINX server name, or Pulp hands out unreachable download links.
FQDN="$(hostname -f 2>/dev/null || hostname)"
CONTENT_ORIGIN="https://$FQDN"
say "Content origin: $CONTENT_ORIGIN"
say "  This is the base URL Pulp puts in download links, so it must match"
say "  the name agents connect to and the certificate SAN."

# Worker counts scaled to the host, kept modest to leave room for Postgres
CPUS="$(nproc 2>/dev/null || echo 4)"
API_WORKERS=$(( CPUS / 4 )); (( API_WORKERS < 2 )) && API_WORKERS=2 || true
(( API_WORKERS > 4 )) && API_WORKERS=4 || true
CONTENT_WORKERS=$(( CPUS / 2 )); (( CONTENT_WORKERS < 2 )) && CONTENT_WORKERS=2 || true
(( CONTENT_WORKERS > 8 )) && CONTENT_WORKERS=8 || true
say "Workers: api=$API_WORKERS content=$CONTENT_WORKERS  (host has $CPUS cpu)"

if [[ "$DRY_RUN" != yes ]]; then
  cat >"$PULP_ENV_FILE" <<EOF
# PATCH-01 Pulp environment. Generated $(date -Is). Mode 0600.
PULP_SECRET_KEY=$PULP_SECRET_KEY
PULP_CONTENT_ORIGIN=$CONTENT_ORIGIN
PULP_CONTENT_PATH_PREFIX=/pulp/content/
PULP_API_ROOT=/pulp/
EOF
  chmod 0600 "$PULP_ENV_FILE"
  chown root:root "$PULP_ENV_FILE"
  say "Wrote $PULP_ENV_FILE"
fi

# ---------------------------------------------------------------------------
# settings.py
# ---------------------------------------------------------------------------
step "Writing settings.py"

PULP_CFG_DIR="$CONFIG_DIR/pulp"
run mkdir -p "$PULP_CFG_DIR"

if [[ "$DRY_RUN" != yes ]]; then
  [[ -f "$PULP_CFG_DIR/settings.py" ]] \
    && cp -a "$PULP_CFG_DIR/settings.py" "$PULP_CFG_DIR/settings.py.$(date +%Y%m%d-%H%M%S).bak" || true

  cat >"$PULP_CFG_DIR/settings.py" <<EOF
# PATCH-01 Pulp settings. Generated by phase1c-pulp.sh on $(date -Is).
# Regenerated on each run; edit the script, not this file.

SECRET_KEY = "$PULP_SECRET_KEY"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": "$PULP_DB_NAME",
        "USER": "$PULP_DB_USER",
        "PASSWORD": "$PULP_DB_PASSWORD",
        "HOST": "${PP_PG_HOST:-postgres}",
        "PORT": ${PP_PG_PORT:-5432},
        "CONN_MAX_AGE": 0,
    }
}

REDIS_HOST = "${PP_REDIS_HOST:-redis}"
REDIS_PORT = ${PP_REDIS_PORT:-6379}
REDIS_DB = 0

# Where artifacts live on disk. This is the mounted volume.
MEDIA_ROOT = "/var/lib/pulp/media"
WORKING_DIRECTORY = "/var/lib/pulp/tmp"
FILE_UPLOAD_TEMP_DIR = "/var/lib/pulp/tmp"

# URL layout. CONTENT_ORIGIN is what appears in download links handed to
# agents, so it must be the externally reachable name.
CONTENT_ORIGIN = "$CONTENT_ORIGIN"
CONTENT_PATH_PREFIX = "/pulp/content/"
API_ROOT = "/pulp/"

# NGINX terminates TLS and forwards; trust its forwarded proto so Pulp
# generates https:// links rather than http://.
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
USE_X_FORWARDED_HOST = True

ALLOWED_HOSTS = ["*"]

# Basic auth for the API. Agents will use their own mechanism later; this
# is for administrative access via pulp-cli and the browsable API.
REST_FRAMEWORK__DEFAULT_AUTHENTICATION_CLASSES = (
    "rest_framework.authentication.SessionAuthentication",
    "pulpcore.app.authentication.PulpRemoteUserAuthentication",
    "rest_framework.authentication.BasicAuthentication",
)

TELEMETRY = False

# Keep several package versions so a downgrade remains possible. Setting
# this to 1 makes rollback impossible on apt hosts, because the previous
# .deb is pruned from the repository.
# Configured per-repository at sync time; this is the project default.
DEFAULT_RETAIN_PACKAGE_VERSIONS = 3

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "simple": {"format": "pulp [%(asctime)s] %(levelname)s %(name)s: %(message)s"},
    },
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "simple"},
    },
    "root": {"handlers": ["console"], "level": "INFO"},
}
EOF

  # Readable by the Pulp UID. Group is set from the detected GID, not
  # assumed to be 0 -- that assumption broke PostgreSQL's init scripts.
  chown -R root:"$PULP_GID" "$PULP_CFG_DIR"
  chmod 0750 "$PULP_CFG_DIR"
  chmod 0640 "$PULP_CFG_DIR/settings.py"
  say "Wrote settings.py (group $PULP_GID)"

  # Prove the Pulp user can read it before deploying
  if ! docker run --rm --user "$PULP_UID:$PULP_GID" --network none \
        -v "$PULP_CFG_DIR/settings.py:/etc/pulp/settings.py:ro" \
        --entrypoint "" "$PULP_IMAGE" \
        sh -c 'cat /etc/pulp/settings.py >/dev/null' >>"$LOG_FILE" 2>&1; then
    warn "uid $PULP_UID:$PULP_GID cannot read $PULP_CFG_DIR/settings.py"
    ls -ldn "$PULP_CFG_DIR" "$PULP_CFG_DIR/settings.py" >&2
    warn "Fix with: chown -R root:$PULP_GID $PULP_CFG_DIR"
    die "Pulp would fail to start."
  fi
  say "Verified uid $PULP_UID can read settings.py"

  # Pulp needs these subdirectories on the artifact volume
  for d in media tmp; do
    mkdir -p "$PULP_DATA_DIR/$d"
    chown "$PULP_UID":"$PULP_GID" "$PULP_DATA_DIR/$d"
  done
  say "Prepared media/ and tmp/ on the artifact volume"

  # And prove it can write there -- this is the 600 GB volume
  if ! docker run --rm --user "$PULP_UID:$PULP_GID" --network none \
        -v "$PULP_DATA_DIR:/var/lib/pulp" --entrypoint "" "$PULP_IMAGE" \
        sh -c 'touch /var/lib/pulp/tmp/.writetest && rm -f /var/lib/pulp/tmp/.writetest' \
        >>"$LOG_FILE" 2>&1; then
    warn "uid $PULP_UID:$PULP_GID cannot write to $PULP_DATA_DIR/tmp"
    ls -ldn "$PULP_DATA_DIR" "$PULP_DATA_DIR/tmp" >&2
    die "Pulp cannot store artifacts."
  fi
  say "Verified uid $PULP_UID can write to the artifact volume"
fi

# ---------------------------------------------------------------------------
# Generate compose
# ---------------------------------------------------------------------------
step "Generating the compose file"

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMPL="$SRC_DIR/compose/docker-compose.pulp.yml.tmpl"
[[ -f "$TMPL" ]] || die "Template not found: $TMPL"

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] would generate $COMPOSE_FILE"
else
  [[ -f "$COMPOSE_FILE" ]] \
    && cp -a "$COMPOSE_FILE" "$COMPOSE_FILE.$(date +%Y%m%d-%H%M%S).bak" || true
  sed -e "s|@@PULP_IMAGE@@|$PULP_IMAGE|g" \
      -e "s|@@PULP_UID@@|$PULP_UID|g" \
      -e "s|@@PULP_GID@@|$PULP_GID|g" \
      -e "s|@@PULP_DATA_DIR@@|$PULP_DATA_DIR|g" \
      -e "s|@@CONFIG_DIR@@|$CONFIG_DIR|g" \
      -e "s|@@SECRETS_DIR@@|$SECRETS_DIR|g" \
      -e "s|@@API_WORKERS@@|$API_WORKERS|g" \
      -e "s|@@CONTENT_WORKERS@@|$CONTENT_WORKERS|g" \
      "$TMPL" >"$COMPOSE_FILE"
  chmod 0640 "$COMPOSE_FILE"

  grep -q '@@' "$COMPOSE_FILE" && {
    warn "Unfilled placeholders:"; grep -n '@@' "$COMPOSE_FILE" >&2
    die "Compose generation incomplete."
  } || true

  docker compose -f "$COMPOSE_FILE" config >/dev/null 2>>"$LOG_FILE" \
    || { warn "compose config failed:"; tail -20 "$LOG_FILE" >&2
         die "Generated compose file is invalid."; }
  say "Generated and validated $COMPOSE_FILE"
fi

# ---------------------------------------------------------------------------
# Migrations
# ---------------------------------------------------------------------------
step "Running database migrations"

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] docker compose up pulp-migrate, then the rest"
else
  say "This can take several minutes on a first run."
  if ! (cd "$COMPOSE_DIR" && docker compose -f "$COMPOSE_FILE" up pulp-migrate) \
       >>"$LOG_FILE" 2>&1; then
    warn "Migrations failed. Last 40 lines:"
    docker logs --tail 40 patch01-pulp-migrate 2>&1 >&2 || tail -40 "$LOG_FILE" >&2
    warn ""
    warn "Common causes:"
    warn "  - PostgreSQL version unsupported by this pulpcore release"
    warn "  - wrong database password in $PG_ENV_FILE"
    warn "  - the 'pulp' database or role missing (check phase1b --check)"
    die "Migrations did not complete. Nothing else was started."
  fi

  if docker logs patch01-pulp-migrate 2>&1 | grep -q 'MIGRATIONS COMPLETE'; then
    say "Migrations completed."
  else
    warn "Migration container exited without the completion marker."
    docker logs --tail 20 patch01-pulp-migrate 2>&1 >&2
    confirm "Continue anyway?" n || die "Stopped."
  fi
fi

# ---------------------------------------------------------------------------
# Deploy
# ---------------------------------------------------------------------------
step "Starting api, content and worker"

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] docker compose up -d"
else
  (cd "$COMPOSE_DIR" && docker compose -f "$COMPOSE_FILE" up -d) >>"$LOG_FILE" 2>&1 \
    || { warn "compose up failed:"; tail -30 "$LOG_FILE" >&2; die "Deployment failed."; }

  say "Waiting for the API (first start compiles and loads plugins)..."
  for i in $(seq 1 180); do
    st="$(docker inspect patch01-pulp-api --format '{{.State.Health.Status}}' 2>/dev/null || echo starting)"
    if [[ "$st" == healthy ]]; then say "pulp-api is healthy."; break; fi
    if ! docker ps --format '{{.Names}}' | grep -qx patch01-pulp-api; then
      warn "pulp-api exited. Last 40 lines:"
      docker logs --tail 40 patch01-pulp-api 2>&1 >&2
      die "pulp-api did not stay up."
    fi
    if (( i == 180 )); then
      warn "pulp-api not healthy after 180s. Last 40 lines:"
      docker logs --tail 40 patch01-pulp-api 2>&1 >&2
      die "Timed out."
    fi
    sleep 1
  done

  say "Waiting for the content app..."
  for i in $(seq 1 90); do
    st="$(docker inspect patch01-pulp-content --format '{{.State.Health.Status}}' 2>/dev/null || echo starting)"
    if [[ "$st" == healthy ]]; then say "pulp-content is healthy."; break; fi
    if (( i == 90 )); then
      warn "pulp-content not healthy. Last 30 lines:"
      docker logs --tail 30 patch01-pulp-content 2>&1 >&2
      warn "Continuing - the API is up, so this can be diagnosed separately."
      break
    fi
    sleep 1
  done

  # A worker that never registers means syncs queue forever with no error
  say "Waiting for a worker to register with the database..."
  for i in $(seq 1 60); do
    n="$(docker exec patch01-postgres psql -U postgres -d "$PULP_DB_NAME" -tAc \
      "SELECT count(*) FROM core_worker WHERE last_heartbeat > now() - interval '30 seconds'" \
      2>/dev/null | tr -d ' ' || echo 0)"
    if [[ "$n" =~ ^[0-9]+$ ]] && (( n > 0 )); then
      say "$n worker(s) registered and sending heartbeats."; break
    fi
    if (( i == 60 )); then
      warn "No worker heartbeat after 60s. Syncs would queue with no error."
      docker logs --tail 30 patch01-pulp-worker 2>&1 >&2
      warn "Continuing - check with --check once settled."
      break
    fi
    sleep 1
  done
fi

# ---------------------------------------------------------------------------
# Admin password
# ---------------------------------------------------------------------------
step "Admin account"

if [[ "$DRY_RUN" != yes ]]; then
  if [[ -f "$SECRETS_DIR/pulp-admin.txt" ]]; then
    say "Existing admin credentials kept ($SECRETS_DIR/pulp-admin.txt)"
  else
    ADMIN_PW="$(openssl rand -base64 24 | tr -d '/+=\n' | cut -c1-24)"
    if docker exec patch01-pulp-api pulpcore-manager reset-admin-password \
         --password "$ADMIN_PW" >>"$LOG_FILE" 2>&1; then
      printf 'Pulp admin\n  user:     admin\n  password: %s\n  created:  %s\n  api:      https://%s/pulp/api/v3/\n' \
        "$ADMIN_PW" "$(date -Is)" "$FQDN" >"$SECRETS_DIR/pulp-admin.txt"
      chmod 0600 "$SECRETS_DIR/pulp-admin.txt"
      say "Admin password set, stored in $SECRETS_DIR/pulp-admin.txt"
    else
      warn "Could not set the admin password. Set it later with --reset-admin"
    fi
  fi
fi

# ---------------------------------------------------------------------------
# Record state
# ---------------------------------------------------------------------------
if [[ "$DRY_RUN" != yes ]]; then
  cat >"$ETC_DIR/phase1c.env" <<EOF
# Generated by phase1c-pulp.sh v$VERSION on $(date -Is)
PP_PHASE1C_VERSION="$VERSION"
PP_PULP_IMAGE="$PULP_IMAGE"
PP_PULP_UID="$PULP_UID"
PP_PULP_GID="$PULP_GID"
PP_PULP_API_CONTAINER="patch01-pulp-api"
PP_PULP_CONTENT_CONTAINER="patch01-pulp-content"
PP_PULP_WORKER_CONTAINER="patch01-pulp-worker"
PP_PULP_API_HOST="pulp-api"
PP_PULP_API_PORT="24817"
PP_PULP_CONTENT_HOST="pulp-content"
PP_PULP_CONTENT_PORT="24816"
PP_CONTENT_ORIGIN="$CONTENT_ORIGIN"
PP_PULP_DATA_DIR="$PULP_DATA_DIR"
PP_PULP_SETTINGS="$PULP_CFG_DIR/settings.py"
PP_COMPOSE_PULP="$COMPOSE_FILE"
EOF
  chmod 0600 "$ETC_DIR/phase1c.env"
fi

echo
echo "================================================================"
echo " PHASE 1c COMPLETE - PULP"
echo "================================================================"
printf ' Image:     %s\n' "$PULP_IMAGE"
printf ' Runs as:   uid %s:%s\n' "$PULP_UID" "$PULP_GID"
printf ' Artifacts: %s\n' "$PULP_DATA_DIR"
printf ' Origin:    %s\n' "$CONTENT_ORIGIN"
printf ' Admin:     %s/pulp-admin.txt\n' "$SECRETS_DIR"
printf ' Log:       %s\n' "$LOG_FILE"
echo
echo " Test:"
echo "   curl -sk https://localhost/pulp/api/v3/status/ | python3 -m json.tool | head -30"
echo
echo " Validate:  ./scripts/phase1c-pulp.sh --check"
echo " Logs:      ./scripts/phase1c-pulp.sh --logs"
echo
echo " Next: phase 2 - repository definitions and the first sync."
echo " Start with ONE small repo to prove the proxy path before adding all"
echo " of RHEL 8/9/10, Oracle Linux 8/9/10 and Ubuntu."
