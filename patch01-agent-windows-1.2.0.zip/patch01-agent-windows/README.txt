PATCH-01 agent for Windows Server (agent 1.2.0-win)
===================================================

Extract this folder on the server, open PowerShell as administrator in it, and run:

    powershell -ExecutionPolicy Bypass -File .\Setup-Agent.ps1

It sets the execution policy to RemoteSigned for the current user and unblocks
these scripts, asks for PATCH-01's address (an upgrade offers the one the agent
already uses), finds any existing agent and upgrades it (keeping its identity,
no token), or self-tests and installs a new one (it asks for a token). It
works out how to trust PATCH-01's certificate: if Windows already trusts it,
the pin is "system" and renewals need nothing; otherwise it asks for your CA
chain file (PEM), checks PATCH-01's certificate chains to the root in it, and
pins that certificate. It ends with a check-in.

New in 1.2.0: software jobs from Windows > Installers. The agent copies the
installer from the share with the job's credential (fetched once, kept in
memory), checks its SHA-256 and signature before running it, installs with
fixed options only, confirms the result, and deletes its copy.

Unattended:  .\Setup-Agent.ps1 -Server https://<patch01 name> -CaFile C:\temp\corp-chain.pem -Token <token> -Yes
Many servers at once, over WinRM:  Get-Help .\push-agent.ps1
WSUS server summary:  Get-Help .\wsus-report.ps1
Tokens, on PATCH-01:  ./scripts/phase10-windows.sh --tokens <N> <group>
