#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 phase 1b : PostgreSQL + Redis
#
# Deploys the data plane. Neither service publishes a host port; both are
# reachable only from other containers on patchnet by name.
#
# Two databases on one PostgreSQL instance:
#     pulp      owned by pulp      -- Pulp's own schema
#     patchdb   owned by patchapi  -- inventory, jobs, CVE state, audit
#
# Everything about the images is read from /etc/patch-platform/images.env,
# which resolve-images.sh generates from the local image store. Nothing here
# is hardcoded to a particular image, UID or data path.
#
# Usage:
#   ./phase1b-data.sh              deploy
#   ./phase1b-data.sh --dry-run    show the plan only
#   ./phase1b-data.sh --check      validate an existing deployment
#   ./phase1b-data.sh --down       stop (data and secrets are kept)
#   ./phase1b-data.sh --show-creds print connection details
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 027

VERSION="1.0.0"
PATCH_BASE="/patch"
ETC_DIR="/etc/patch-platform"
LOG_DIR="/var/log/patch-platform"
IMAGES_MANIFEST="$ETC_DIR/images.env"

DRY_RUN=no
CHECK_ONLY=no
DO_DOWN=no
SHOW_CREDS=no

while (($#)); do
  case "$1" in
    --dry-run)    DRY_RUN=yes ;;
    --check)      CHECK_ONLY=yes ;;
    --down)       DO_DOWN=yes ;;
    --show-creds) SHOW_CREDS=yes ;;
    --base)       PATCH_BASE="${2:-}"; shift ;;
    -h|--help)    sed -n '2,22p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/phase1b-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"

log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }

run() {
  if [[ "$DRY_RUN" == yes ]]; then printf '  [dry-run] %s\n' "$*"; return 0; fi
  log "EXEC: $*"
  "$@" </dev/null >>"$LOG_FILE" 2>&1
}

confirm() {
  local p="$1" d="${2:-y}" r hint="[y/N]"
  [[ "$d" == y ]] && hint="[Y/n]" || true
  [[ -t 0 ]] || { [[ "$d" == y ]]; return; }
  read -r -p "$p $hint: " r || true
  r="${r:-$d}"; [[ "${r,,}" =~ ^(y|yes)$ ]]
}

[[ $EUID -eq 0 ]] || die "Run as root."

COMPOSE_DIR="$PATCH_BASE/compose"
CONFIG_DIR="$PATCH_BASE/config"
SECRETS_DIR="$PATCH_BASE/secrets"
COMPOSE_FILE="$COMPOSE_DIR/docker-compose.data.yml"

# ---------------------------------------------------------------------------
# Credentials display
# ---------------------------------------------------------------------------
if [[ "$SHOW_CREDS" == yes ]]; then
  [[ -f "$SECRETS_DIR/connection-info.txt" ]] \
    || die "No connection info yet. Deploy first."
  cat "$SECRETS_DIR/connection-info.txt"
  exit 0
fi

# ---------------------------------------------------------------------------
# Tear down
# ---------------------------------------------------------------------------
if [[ "$DO_DOWN" == yes ]]; then
  step "Stopping the data plane"
  if [[ -f "$COMPOSE_FILE" ]]; then
    (cd "$COMPOSE_DIR" && docker compose -f "$COMPOSE_FILE" down) \
      || warn "compose down reported errors"
  fi
  docker rm -f patch01-postgres patch01-redis >/dev/null 2>&1 || true
  say "Stopped. Data in $PATCH_BASE/data and secrets in $SECRETS_DIR are untouched."
  exit 0
fi

# ---------------------------------------------------------------------------
# Preconditions
# ---------------------------------------------------------------------------
step "Checking preconditions"

command -v docker >/dev/null 2>&1 || die "Docker is not installed."
docker info >/dev/null 2>&1 || die "The Docker daemon is not responding."
docker compose version >/dev/null 2>&1 || die "The docker compose plugin is missing."

[[ -f "$IMAGES_MANIFEST" ]] \
  || die "No image manifest. Run: ./scripts/resolve-images.sh --require postgres,redis"

# shellcheck disable=SC1090
source "$IMAGES_MANIFEST"

PG_IMAGE="${IMG_POSTGRES:-}"
REDIS_IMAGE="${IMG_REDIS:-}"
[[ -n "$PG_IMAGE" ]]    || die "The manifest has no postgres image. Re-run resolve-images.sh"
[[ -n "$REDIS_IMAGE" ]] || die "The manifest has no redis image. Re-run resolve-images.sh"

docker image inspect "$PG_IMAGE" >/dev/null 2>&1 \
  || die "Manifest lists $PG_IMAGE but it is not present. Re-run resolve-images.sh"
docker image inspect "$REDIS_IMAGE" >/dev/null 2>&1 \
  || die "Manifest lists $REDIS_IMAGE but it is not present. Re-run resolve-images.sh"

# Variant-derived conventions, with upstream defaults
PG_VARIANT="${IMG_POSTGRES_VARIANT:-upstream}"
PG_DATA_PATH="${PG_DATA_PATH:-/var/lib/postgresql/data}"
PG_DATA_SUBDIR="${PG_DATA_SUBDIR:-pgdata}"
PG_ENV_PREFIX="${PG_ENV_PREFIX:-POSTGRES}"
PG_UID="${PG_UID:-999}"
PG_GID="${PG_GID:-999}"
REDIS_UID="${REDIS_UID:-999}"
REDIS_GID="${REDIS_GID:-999}"
REDIS_DATA_PATH="${REDIS_DATA_PATH:-/data}"

PG_HOST_DIR="$PATCH_BASE/data/postgres"
REDIS_HOST_DIR="$PATCH_BASE/data/redis"

say "PostgreSQL: $PG_IMAGE"
say "  variant $PG_VARIANT, uid $PG_UID:$PG_GID, data $PG_DATA_PATH/$PG_DATA_SUBDIR"
say "  version ${VER_POSTGRES:-unknown}"
say "Redis:      $REDIS_IMAGE"
say "  uid $REDIS_UID:$REDIS_GID, data $REDIS_DATA_PATH"
say "  version ${VER_REDIS:-unknown}"

# patchnet must already exist from phase 1a
if ! docker network inspect patchnet >/dev/null 2>&1; then
  warn "The patchnet network does not exist (phase 1a creates it)."
  if confirm "Create it now?" y; then
    run docker network create --driver bridge --subnet 172.30.0.0/24 patchnet \
      || die "Could not create patchnet."
  else
    die "patchnet is required."
  fi
fi
say "Network patchnet present."

for d in "$PG_HOST_DIR" "$REDIS_HOST_DIR" "$SECRETS_DIR" "$CONFIG_DIR"; do
  [[ -d "$d" ]] || die "Missing directory: $d  (run the phase 0 bootstrap first)"
done

# ---------------------------------------------------------------------------
# Data directory ownership -- the most common first-run failure
# ---------------------------------------------------------------------------
step "Checking data directory ownership"

check_owner() {
  local dir="$1" want_uid="$2" want_gid="$3" name="$4"
  local cur_uid cur_gid
  cur_uid="$(stat -c '%u' "$dir")"
  cur_gid="$(stat -c '%g' "$dir")"
  if [[ "$cur_uid" == "$want_uid" ]]; then
    say "$name: $dir owned by $cur_uid:$cur_gid - correct"
    return 0
  fi
  warn "$name: $dir is owned by $cur_uid:$cur_gid but the container runs as $want_uid:$want_gid"
  if [[ "$DRY_RUN" == yes ]]; then
    printf '  [dry-run] chown -R %s:%s %s\n' "$want_uid" "$want_gid" "$dir"
    return 0
  fi
  if confirm "Fix ownership now?" y; then
    chown -R "$want_uid":"$want_gid" "$dir" || die "chown failed on $dir"
    chmod 0700 "$dir"
    say "$name: ownership corrected."
  else
    die "$name will fail to start without correct ownership."
  fi
}

check_owner "$PG_HOST_DIR"    "$PG_UID"    "$PG_GID"    "PostgreSQL"
check_owner "$REDIS_HOST_DIR" "$REDIS_UID" "$REDIS_GID" "Redis"

# ---------------------------------------------------------------------------
# Check mode
# ---------------------------------------------------------------------------
if [[ "$CHECK_ONLY" == yes ]]; then
  step "Validating the deployment"
  FAILS=0

  for c in patch01-postgres patch01-redis; do
    if docker ps --format '{{.Names}}' | grep -qx "$c"; then
      st="$(docker inspect "$c" --format '{{.State.Health.Status}}' 2>/dev/null || echo none)"
      say "$c: running, health=$st"
      [[ "$st" == healthy || "$st" == none ]] || FAILS=$((FAILS+1))
    else
      warn "$c is not running"; FAILS=$((FAILS+1))
    fi
  done

  if docker exec patch01-postgres psql -U postgres -tAc \
      "SELECT datname FROM pg_database WHERE datname IN ('pulp','patchdb') ORDER BY 1" 2>/dev/null \
      | tr '\n' ' ' | grep -q 'patchdb.*pulp'; then
    say "Both databases exist."
  else
    warn "Expected databases not found"; FAILS=$((FAILS+1))
  fi

  if docker exec patch01-redis redis-cli ping 2>/dev/null | grep -q PONG; then
    say "Redis responds to PING."
  else
    warn "Redis did not respond"; FAILS=$((FAILS+1))
  fi

  step "Exposure check"
  EXPOSED=0
  for c in patch01-postgres patch01-redis; do
    pmap="$(docker port "$c" 2>/dev/null || true)"
    if [[ -n "$pmap" ]]; then
      warn "$c publishes host ports:"; printf '%s\n' "$pmap" >&2
      EXPOSED=$((EXPOSED+1))
    else
      say "$c publishes no host port - correct"
    fi
  done
  if command -v ss >/dev/null 2>&1; then
    for p in 5432 6379; do
      hit="$(ss -ltnH 2>/dev/null | awk -v p=":$p" '$4 ~ p"$" {print $4}' || true)"
      [[ -z "$hit" ]] && say "Nothing listening on $p on the host - correct" \
        || { warn "Host is listening on $p: $hit"; EXPOSED=$((EXPOSED+1)); }
    done
  fi
  (( EXPOSED == 0 )) || FAILS=$((FAILS+1))

  (( FAILS == 0 )) && say "All checks passed." || die "$FAILS check(s) failed."
  exit 0
fi

# ---------------------------------------------------------------------------
# Secrets
# ---------------------------------------------------------------------------
step "Preparing secrets"

gen_pw() { openssl rand -base64 24 | tr -d '/+=\n' | cut -c1-24; }

PG_ENV_FILE="$SECRETS_DIR/postgres.env"

if [[ -f "$PG_ENV_FILE" ]]; then
  say "Existing credentials found; reusing them."
  # shellcheck disable=SC1090
  source "$PG_ENV_FILE"
  PG_SUPER_PW="${POSTGRES_PASSWORD:-}"
  PULP_PW="${PULP_DB_PASSWORD:-}"
  PATCHAPI_PW="${PATCHAPI_DB_PASSWORD:-}"
  [[ -n "$PG_SUPER_PW" && -n "$PULP_PW" && -n "$PATCHAPI_PW" ]] \
    || die "$PG_ENV_FILE is incomplete. Move it aside to regenerate."
else
  if [[ "$DRY_RUN" == yes ]]; then
    say "[dry-run] would generate credentials in $PG_ENV_FILE"
    PG_SUPER_PW="<generated>"; PULP_PW="<generated>"; PATCHAPI_PW="<generated>"
  else
    PG_SUPER_PW="$(gen_pw)"
    PULP_PW="$(gen_pw)"
    PATCHAPI_PW="$(gen_pw)"

    cat >"$PG_ENV_FILE" <<EOF
# PATCH-01 database credentials. Generated $(date -Is).
# Consumed by docker compose via env_file. Mode 0600, root only.
POSTGRES_USER=postgres
POSTGRES_PASSWORD=$PG_SUPER_PW
POSTGRES_DB=postgres
POSTGRES_INITDB_ARGS=--data-checksums

# Application roles, created by the init script on first start
PULP_DB_NAME=pulp
PULP_DB_USER=pulp
PULP_DB_PASSWORD=$PULP_PW
PATCHAPI_DB_NAME=patchdb
PATCHAPI_DB_USER=patchapi
PATCHAPI_DB_PASSWORD=$PATCHAPI_PW
EOF
    chmod 0600 "$PG_ENV_FILE"
    chown root:root "$PG_ENV_FILE"
    say "Generated credentials in $PG_ENV_FILE (0600)"
  fi
fi

# The env file is read by the Docker daemon (root), not by the container
# user, so it stays 0600 root-only.

# ---------------------------------------------------------------------------
# Init script -- runs only on an empty data directory
# ---------------------------------------------------------------------------
step "Writing the database init script"

INIT_DIR="$CONFIG_DIR/postgres/init"
run mkdir -p "$INIT_DIR"

if [[ "$DRY_RUN" != yes ]]; then
  cat >"$INIT_DIR/10-create-databases.sh" <<'INITEOF'
#!/bin/bash
# Runs once, on first initialisation of an empty data directory.
# Creates the two application databases and their owners.
set -e

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname postgres <<-SQL
    CREATE ROLE ${PULP_DB_USER} WITH LOGIN PASSWORD '${PULP_DB_PASSWORD}';
    CREATE DATABASE ${PULP_DB_NAME} OWNER ${PULP_DB_USER} ENCODING 'UTF8';

    CREATE ROLE ${PATCHAPI_DB_USER} WITH LOGIN PASSWORD '${PATCHAPI_DB_PASSWORD}';
    CREATE DATABASE ${PATCHAPI_DB_NAME} OWNER ${PATCHAPI_DB_USER} ENCODING 'UTF8';
SQL

# Pulp needs to create its own schema objects
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "${PULP_DB_NAME}" <<-SQL
    GRANT ALL ON SCHEMA public TO ${PULP_DB_USER};
SQL

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "${PATCHAPI_DB_NAME}" <<-SQL
    GRANT ALL ON SCHEMA public TO ${PATCHAPI_DB_USER};
SQL

echo "Created databases: ${PULP_DB_NAME}, ${PATCHAPI_DB_NAME}"
INITEOF
  chmod 0755 "$INIT_DIR/10-create-databases.sh"
  # Readable by the container user
  chown -R root:0 "$CONFIG_DIR/postgres"
  chmod 0750 "$CONFIG_DIR/postgres" "$INIT_DIR"
  say "Init script written."
fi

# Warn if the data directory is already initialised: the init script will
# NOT run, so a credential change here would not take effect.
PGDATA_HOST="$PG_HOST_DIR/$PG_DATA_SUBDIR"
if [[ -f "$PGDATA_HOST/PG_VERSION" ]]; then
  say "Existing cluster detected at $PGDATA_HOST (version $(cat "$PGDATA_HOST/PG_VERSION" 2>/dev/null || echo '?'))."
  say "The init script will not re-run; existing databases and roles are kept."
fi

# ---------------------------------------------------------------------------
# Generate compose
# ---------------------------------------------------------------------------
step "Generating the compose file"

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMPL="$SRC_DIR/compose/docker-compose.data.yml.tmpl"
[[ -f "$TMPL" ]] || die "Template not found: $TMPL"

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] would generate $COMPOSE_FILE"
else
  [[ -f "$COMPOSE_FILE" ]] \
    && cp -a "$COMPOSE_FILE" "$COMPOSE_FILE.$(date +%Y%m%d-%H%M%S).bak" || true
  sed -e "s|@@PG_IMAGE@@|$PG_IMAGE|g" \
      -e "s|@@PG_UID@@|$PG_UID|g" \
      -e "s|@@PG_GID@@|$PG_GID|g" \
      -e "s|@@PG_DATA_PATH@@|$PG_DATA_PATH|g" \
      -e "s|@@PG_DATA_SUBDIR@@|$PG_DATA_SUBDIR|g" \
      -e "s|@@PG_HOST_DIR@@|$PG_HOST_DIR|g" \
      -e "s|@@REDIS_IMAGE@@|$REDIS_IMAGE|g" \
      -e "s|@@REDIS_UID@@|$REDIS_UID|g" \
      -e "s|@@REDIS_GID@@|$REDIS_GID|g" \
      -e "s|@@REDIS_DATA_PATH@@|$REDIS_DATA_PATH|g" \
      -e "s|@@REDIS_HOST_DIR@@|$REDIS_HOST_DIR|g" \
      -e "s|@@SECRETS_DIR@@|$SECRETS_DIR|g" \
      -e "s|@@CONFIG_DIR@@|$CONFIG_DIR|g" \
      "$TMPL" >"$COMPOSE_FILE"
  chmod 0640 "$COMPOSE_FILE"

  grep -q '@@' "$COMPOSE_FILE" && {
    warn "Unfilled placeholders remain:"; grep -n '@@' "$COMPOSE_FILE" >&2
    die "Compose generation incomplete."
  } || true

  docker compose -f "$COMPOSE_FILE" config >/dev/null 2>>"$LOG_FILE" \
    || { warn "compose config validation failed:"; tail -20 "$LOG_FILE" >&2
         die "Generated compose file is invalid."; }
  say "Generated and validated $COMPOSE_FILE"
fi

# ---------------------------------------------------------------------------
# Deploy
# ---------------------------------------------------------------------------
step "Starting PostgreSQL and Redis"

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] docker compose -f $COMPOSE_FILE up -d"
else
  (cd "$COMPOSE_DIR" && docker compose -f "$COMPOSE_FILE" up -d) >>"$LOG_FILE" 2>&1 \
    || { warn "compose up failed:"; tail -30 "$LOG_FILE" >&2; die "Deployment failed."; }

  say "Waiting for PostgreSQL to become healthy (first start initialises the cluster)..."
  for i in $(seq 1 90); do
    st="$(docker inspect patch01-postgres --format '{{.State.Health.Status}}' 2>/dev/null || echo starting)"
    if [[ "$st" == healthy ]]; then say "PostgreSQL is healthy."; break; fi
    if [[ "$st" == unhealthy ]] || ! docker ps --format '{{.Names}}' | grep -qx patch01-postgres; then
      warn "PostgreSQL failed to start. Last 40 log lines:"
      docker logs --tail 40 patch01-postgres 2>&1 >&2
      die "PostgreSQL did not start."
    fi
    if (( i == 90 )); then
      warn "PostgreSQL still not healthy after 90s. Logs:"
      docker logs --tail 40 patch01-postgres 2>&1 >&2
      die "Timed out waiting for PostgreSQL."
    fi
    sleep 1
  done

  say "Waiting for Redis..."
  for i in $(seq 1 30); do
    if docker exec patch01-redis redis-cli ping 2>/dev/null | grep -q PONG; then
      say "Redis is responding."; break
    fi
    if (( i == 30 )); then
      warn "Redis did not respond. Logs:"; docker logs --tail 30 patch01-redis 2>&1 >&2
      die "Redis did not start."
    fi
    sleep 1
  done
fi

# ---------------------------------------------------------------------------
# Verify the databases
# ---------------------------------------------------------------------------
step "Verifying databases"

if [[ "$DRY_RUN" != yes ]]; then
  DBS="$(docker exec patch01-postgres psql -U postgres -tAc \
    "SELECT datname FROM pg_database WHERE datname IN ('pulp','patchdb') ORDER BY 1" 2>>"$LOG_FILE" || true)"
  say "Databases present: $(printf '%s' "$DBS" | tr '\n' ' ')"

  for db in pulp patchdb; do
    printf '%s\n' "$DBS" | grep -qx "$db" \
      || warn "Database '$db' is missing. If this is a pre-existing cluster, the init script did not re-run."
  done

  # Prove each application role can actually log in
  for pair in "pulp:$PULP_PW:pulp" "patchapi:$PATCHAPI_PW:patchdb"; do
    IFS=: read -r u p d <<<"$pair"
    if docker exec -e PGPASSWORD="$p" patch01-postgres \
        psql -U "$u" -d "$d" -h 127.0.0.1 -tAc 'SELECT 1' >/dev/null 2>>"$LOG_FILE"; then
      say "Role '$u' can connect to '$d'."
    else
      warn "Role '$u' could NOT connect to '$d'. See $LOG_FILE"
    fi
  done
fi

# ---------------------------------------------------------------------------
# Record connection details
# ---------------------------------------------------------------------------
if [[ "$DRY_RUN" != yes ]]; then
  cat >"$SECRETS_DIR/connection-info.txt" <<EOF
PATCH-01 data plane connection details
Generated $(date -Is)

Reachable ONLY from containers on the patchnet network. No host ports are
published, so these hostnames do not resolve from the host shell.

PostgreSQL
  host      postgres
  port      5432
  version   ${VER_POSTGRES:-unknown}

  Pulp:
    database  pulp
    user      pulp
    password  $PULP_PW

  Patch API:
    database  patchdb
    user      patchapi
    password  $PATCHAPI_PW

  Superuser:
    user      postgres
    password  $PG_SUPER_PW

Redis
  host      redis
  port      6379
  url       redis://redis:6379/0
  Pulp uses db 0; suggest db 1 for the patch API scheduler.

Shell access from the host:
  docker exec -it patch01-postgres psql -U postgres
  docker exec -it patch01-redis redis-cli
EOF
  chmod 0600 "$SECRETS_DIR/connection-info.txt"

  cat >"$ETC_DIR/phase1b.env" <<EOF
# Generated by phase1b-data.sh v$VERSION on $(date -Is)
PP_PHASE1B_VERSION="$VERSION"
PP_PG_CONTAINER="patch01-postgres"
PP_PG_IMAGE="$PG_IMAGE"
PP_PG_HOST="postgres"
PP_PG_PORT="5432"
PP_PULP_DB="pulp"
PP_PULP_DB_USER="pulp"
PP_PATCHAPI_DB="patchdb"
PP_PATCHAPI_DB_USER="patchapi"
PP_REDIS_CONTAINER="patch01-redis"
PP_REDIS_IMAGE="$REDIS_IMAGE"
PP_REDIS_HOST="redis"
PP_REDIS_PORT="6379"
PP_SECRETS_ENV="$PG_ENV_FILE"
PP_COMPOSE_DATA="$COMPOSE_FILE"
EOF
  chmod 0600 "$ETC_DIR/phase1b.env"
fi

echo
echo "================================================================"
echo " PHASE 1b COMPLETE - DATA PLANE"
echo "================================================================"
printf ' PostgreSQL: patch01-postgres  (%s)\n' "$PG_IMAGE"
printf ' Redis:      patch01-redis     (%s)\n' "$REDIS_IMAGE"
printf ' Network:    patchnet, no published host ports\n'
printf ' Databases:  pulp, patchdb\n'
printf ' Secrets:    %s\n' "$PG_ENV_FILE"
printf ' Details:    %s/connection-info.txt\n' "$SECRETS_DIR"
printf ' Log:        %s\n' "$LOG_FILE"
echo
echo " Credentials:  ./scripts/phase1b-data.sh --show-creds"
echo " Validate:     ./scripts/phase1b-data.sh --check"
echo
echo " Back up $PG_ENV_FILE somewhere safe. Pulp's artifacts on disk are"
echo " meaningless without the database that maps them."
echo
echo " Next: phase 1c - Pulp api, content and worker against these."
