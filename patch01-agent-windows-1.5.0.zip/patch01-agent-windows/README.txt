PATCH-01 agent for Windows Server 1.5.0-win: deployment kit
===========================================================

One folder, one script per server, for new installs and upgrades alike.
Your servers' policy (LocalMachine = Restricted) is never changed.

PREPARE THE FOLDER (once)
-------------------------
  1. Extract this zip. Put your CA chain (.pem, the CA that issued
     PATCH-01's certificate) in the same folder.
  2. Optional, for new servers: on PATCH-01 run
         ./scripts/phase10-windows.sh --tokens 50 <group> > tokens.txt
     and put tokens.txt in the folder. Each new server takes the next
     unused token by itself (valid 72 hours, one per server). Without it,
     the script asks you to paste a token.
  3. Optional, only once you have a code-signing certificate: run
     .\Sign-Agent.ps1 on the PC that holds it. Signed, the agent runs
     under AllSigned; unsigned, it runs under RemoteSigned (see below).
  4. Copy the folder to each server, or to a share only administrators
     can read.

ON EACH SERVER (PowerShell as administrator, in the folder)
-----------------------------------------------------------
     Set-ExecutionPolicy RemoteSigned -Scope Process -Force
     Get-ChildItem .\*.ps1 | Unblock-File
     .\Deploy-Agent.ps1

  Line 1 allows scripts in this PowerShell window only; it ends when the
  window closes (nothing permanent; no need for -Scope CurrentUser).
  Line 2 removes the "downloaded from the internet" mark from the scripts.

  Deploy-Agent.ps1 checks the server, finds an existing agent (UPGRADE,
  identity kept, no token) or not (NEW), asks for PATCH-01's address once
  (remembered in deploy-settings.json), picks up the .pem, shows a summary
  and changes nothing until you press Y. Then it installs or upgrades and
  proves it by running the agent's task as SYSTEM.

  Do not run it while a patch job is installing on that server (it checks).

HOW THE AGENT RUNS ON A "Restricted" SERVER
-------------------------------------------
  The server stays Restricted. Only the agent's own scheduled task gets a
  policy, for its own PowerShell process:
    - signed and trusted agent -> AllSigned (a changed file is refused)
    - unsigned agent           -> RemoteSigned (the agent file sits in
      C:\Program Files\PatchAgent, writable only by SYSTEM and Administrators)
  A policy set by Group Policy (MachinePolicy) always wins over this.

RECORDS
-------
  deploy-log.csv     one line per server: when, action, from/to version, result
  tokens-used.csv    which server took which token (a fingerprint only)
  C:\ProgramData\PatchAgent-Deploy\   the full log of each run on that server
  When done, delete tokens.txt from the share.

WHAT 1.5.0 FIXES
----------------
- Precheck crashed on every server with more than 5 GB free ("cannot
  convert ... GB free on C: to type System.Double").
- The install never found the job's updates, so nothing was patched.
- More than 1 GB free on C: is enough to go ahead (under 5 GB warns).
- Windows Update service restarted before searching; a failed search is
  retried once after another restart.
- Updates fetched by a fresh search of this server's WSUS at job time
  (optional/preview updates excluded), matched by update ID, then KB.
- Installed one by one; one failed update does not stop the others or fail
  the server. Only "nothing could be installed" fails.
- After the restart each update is checked again; any rolled back is
  reported. A reboot still pending is reported.
- Services running before are compared after; late starters are waited
  for, any still down is started once; one that will not start is a
  warning, not a patch failure.
