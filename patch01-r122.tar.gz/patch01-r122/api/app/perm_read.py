"""Access review (r120): reading an upload as it is, sheet by sheet, and cleaning its text.

What an upload can be (told by its bytes first, its name second):
  CSV / TSV / TXT     one sheet; UTF-8, UTF-16 (with or without a byte-order mark), Windows-1252,
                      or a mix (a UTF-8 file with a few Windows-1252 bytes)
  .xlsx               every sheet (openpyxl, streamed: a million rows is fine)
  .xls                every sheet (xlrd); an ".xls" that is really an HTML table or text (many web
                      tools export that) is read as what it really is

Why the junk characters before r120, and what is done now:
  * the encoding was told from the first 64 KB only: a Windows-1252 file whose first accented
    letter came later was read as UTF-8 and every such letter became "�"; a UTF-8 file with
    one stray byte early was read as Windows-1252 and every accented letter became two ("Ã©").
    Now the whole file is scanned first; a mixed file keeps its UTF-8 and reads only the stray
    bytes as Windows-1252.
  * invisible characters (zero-width spaces, byte-order marks inside a cell, direction marks,
    control characters), non-breaking spaces, line breaks inside a cell, and Excel's escapes
    (_x000D_) are made plain.
  * text a tool had already garbled (UTF-8 read as Windows-1252: "Ã©", "â€™") is repaired when
    the repair is exact.
  Every change is counted and a few examples kept, so an admin sees what was cleaned.
"""
import codecs
import csv
import html.parser
import io
import re

MAX_COLS = 80
MAX_CELL = 2000
HEAD_ROWS = 60
csv.field_size_limit(4 * 2 ** 20)


# ---- cleaning ------------------------------------------------------------------------------------------

INVISIBLE = re.compile("[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f­؜᠎​-‏‪-‮"
                       "⁠-⁤⁦-⁩﻿￹-￻]")
ODD_SPACE = re.compile("[   -     　]")
BREAKS = re.compile(r"[\t\r\n]+")
XESC = re.compile(r"_x([0-9A-Fa-f]{4})_")
# UTF-8 text that was read as Windows-1252 (or Latin-1): "Ã©" for é, "â€™" for ’, "Â " for a no-break space
MOJIBAKE = re.compile("[Â-ô][\u0080-¿ŒœŠšŸŽžƒˆ˜–—"
                      "‘-„†-•…‰‹›€™]")


def _unmangle(t):
    """The text before it was garbled, or None when no exact repair exists."""
    for enc in ("cp1252", "latin-1"):
        try:
            fixed = t.encode(enc).decode("utf-8")
        except (UnicodeEncodeError, UnicodeDecodeError):
            continue
        if fixed != t and not MOJIBAKE.search(fixed):
            return fixed
    return None


class Cleaner:
    """Cleans cells and counts what it changed."""
    KINDS = ("invisible", "spaces", "breaks", "excel_escapes", "repaired", "unreadable")

    def __init__(self):
        self.counts = dict.fromkeys(self.KINDS, 0)
        self.cells = 0
        self.examples = []

    def _note(self, before, after, kind):
        self.counts[kind] += 1
        self._kinds.append(kind)

    def __call__(self, v):
        if v is None:
            return ""
        t = v if isinstance(v, str) else str(v)
        if not t:
            return ""
        orig, changed = t, False
        self._kinds = []
        if "_x" in t and XESC.search(t):
            t2 = XESC.sub(lambda m: chr(int(m.group(1), 16)), t)
            if t2 != t:
                self._note(orig, t2, "excel_escapes")
                t, changed = t2, True
        if MOJIBAKE.search(t):
            fixed = _unmangle(t)
            if fixed is not None:
                self._note(orig, fixed, "repaired")
                t, changed = fixed, True
        if BREAKS.search(t.strip()):
            t2 = BREAKS.sub(" ", t)
            self._note(orig, t2.strip(), "breaks")
            t, changed = t2, True
        if INVISIBLE.search(t):
            t2 = INVISIBLE.sub("", t)
            self._note(orig, t2, "invisible")
            t, changed = t2, True
        if ODD_SPACE.search(t):
            t2 = ODD_SPACE.sub(" ", t)
            self._note(orig, t2, "spaces")
            t, changed = t2, True
        if "�" in t:
            self._note(orig, t, "unreadable")
        t = t.strip()
        if changed:
            self.cells += 1
            kind = self._kinds[0]
            if len(self.examples) < 10 and sum(1 for e in self.examples if e["kind"] == kind) < 3:
                self.examples.append({"kind": kind, "before": orig[:80], "after": t[:80]})     # as it is kept
        return t[:MAX_CELL]

    def report(self):
        return {"cells": self.cells, "counts": {k: v for k, v in self.counts.items() if v}, "examples": self.examples}


def plain(v):
    """A cell cleaned without counting (values already read)."""
    return Cleaner()(v)


# ---- encodings -------------------------------------------------------------------------------------------

_CP1252_UNDEFINED = {0x81, 0x8D, 0x8F, 0x90, 0x9D}
_stray = {"n": 0}


def _cp1252_fallback(e):
    """A byte that is not UTF-8, read as Windows-1252 (the 5 bytes it leaves undefined as Latin-1)."""
    bad = e.object[e.start:e.end]
    _stray["n"] += len(bad)
    return "".join(chr(b) if b in _CP1252_UNDEFINED else bytes([b]).decode("cp1252") for b in bad), e.end


codecs.register_error("perm-cp1252", _cp1252_fallback)


def bom_or_utf16(head):
    if head.startswith(codecs.BOM_UTF8):
        return "utf-8-sig"
    if head.startswith(codecs.BOM_UTF16_LE):
        return "utf-16-le-bom"
    if head.startswith(codecs.BOM_UTF16_BE):
        return "utf-16-be-bom"
    sample = head[:4096]
    if len(sample) >= 4:
        odd = sample[1::2]
        even = sample[0::2]
        odd_zero = sum(1 for b in odd if b == 0) / max(1, len(odd))
        even_zero = sum(1 for b in even if b == 0) / max(1, len(even))
        if odd_zero > 0.4 and even_zero < 0.05:
            return "utf-16-le"
        if even_zero > 0.4 and odd_zero < 0.05:
            return "utf-16-be"
    return None


def scan_encoding(pieces):
    """The encoding of the WHOLE text: 'utf-8', 'cp1252' or 'utf-8+cp1252' (UTF-8 with stray bytes).
    pieces: an iterable of bytes (the file from its start)."""
    dec = codecs.getincrementaldecoder("utf-8")(errors="perm-cp1252")
    _stray["n"] = 0
    multi = 0
    for b in pieces:
        t = dec.decode(b)
        multi += sum(1 for ch in t if ord(ch) > 0x7f)
    dec.decode(b"", final=True)
    stray = _stray["n"]
    if not stray:
        return "utf-8"
    valid = multi - stray
    if valid <= 0 or stray > 4 * valid:
        return "cp1252"
    return "utf-8+cp1252"


def decoder_for(encoding):
    """An incremental decoder for the encoding found; a BOM is skipped. UTF-8 never gives up on a
    stray byte: it is read as Windows-1252 (never as a "\ufffd")."""
    if encoding == "cp1252":
        return _Cp1252Decoder()
    if encoding in ("utf-8", "utf-8+cp1252", "utf-8-sig"):
        return codecs.getincrementaldecoder("utf-8-sig" if encoding == "utf-8-sig" else "utf-8")(errors="perm-cp1252")
    name = {"utf-16-le-bom": "utf-16", "utf-16-be-bom": "utf-16"}.get(encoding, encoding)
    return codecs.getincrementaldecoder(name)(errors="replace")


class _Cp1252Decoder:
    """Windows-1252, with its 5 undefined bytes kept as Latin-1 (then removed as control characters)."""
    def decode(self, b, final=False):
        if any(x in _CP1252_UNDEFINED for x in b):
            return "".join(chr(x) if x in _CP1252_UNDEFINED else bytes([x]).decode("cp1252") for x in b)
        return b.decode("cp1252")


ENCODING_TEXT = {"utf-8": "UTF-8", "utf-8-sig": "UTF-8 (with a byte-order mark)", "cp1252": "Windows-1252",
                 "utf-8+cp1252": "UTF-8 with some Windows-1252 bytes (read as such)", "utf-16-le": "UTF-16",
                 "utf-16-be": "UTF-16 (big-endian)", "utf-16-le-bom": "UTF-16", "utf-16-be-bom": "UTF-16 (big-endian)",
                 "xlsx": "Excel workbook (.xlsx)", "xls": "Excel 97-2003 workbook (.xls)", "html": "HTML table saved as .xls"}


# ---- CSV ------------------------------------------------------------------------------------------------

def sniff_delimiter(text):
    """The separator that splits the first lines into the same number of fields, most often."""
    lines = [ln for ln in text.splitlines()[:60] if ln.strip()]
    best, best_score = ",", -1
    for d in (",", ";", "\t", "|"):
        counts = [len(row) for row in csv.reader(lines, delimiter=d)]
        if not counts:
            continue
        common = max(set(counts), key=counts.count)
        if common < 2:
            continue
        score = counts.count(common) * common
        if score > best_score:
            best, best_score = d, score
    return best


def lines_from(pieces):
    """Lines (with their line ends) from decoded text pieces of any size; a line split between two
    pieces is joined, and so is a \\r\\n split between them."""
    rest = ""
    for t in pieces:
        if not t:
            continue
        rest += t
        parts = rest.splitlines(keepends=True)
        rest = ""
        if parts and not parts[-1].endswith(("\n", "\r")):
            rest = parts.pop()
        elif parts and parts[-1].endswith("\r"):
            rest = parts.pop()                     # maybe half of a \r\n
        for p in parts:
            yield p
    if rest:
        yield rest


def find_header(rows):
    """Which of the first rows is the header: the first with the number of fields most rows have,
    every field filled in, and not all numbers. A title or 'Report generated on ...' above it is skipped."""
    rows = [[c for c in r] for r in rows]
    if not rows:
        return 0
    lens = [len([c for c in r if c.strip()]) for r in rows]
    nonzero = [n for n in lens if n] or [0]
    common = max(set(nonzero), key=nonzero.count)
    for i, r in enumerate(rows[:40]):
        cells = [c.strip() for c in r]
        while cells and not cells[-1]:
            cells.pop()
        filled = [c for c in cells if c]
        if len(filled) >= max(2, common) and len(filled) == len(cells) and \
                not all(re.fullmatch(r"[\d.,:/ -]+", c) for c in filled):
            return i
    return 0


class Sheet:
    """One table of an upload: its name, and its rows as lists of text (not cleaned yet)."""
    def __init__(self, name, rows, hidden=False):
        self.name, self.rows, self.hidden = name, rows, hidden


def csv_sheet(name, first, pieces, encoding):
    """A CSV as one sheet. first: the bytes already read; pieces: the rest."""
    dec = decoder_for(encoding)
    head_text = decoder_for(encoding).decode(first[:262144])
    first_line = head_text.splitlines()[0] if head_text else ""
    m = re.match(r"^\s*sep=(.)\s*$", first_line.lstrip("﻿"))            # Excel's "sep=;" line
    delim = m.group(1) if m else sniff_delimiter(head_text)

    def text():
        yield dec.decode(first)
        for b in pieces:
            yield dec.decode(b)
        yield dec.decode(b"", final=True)

    def rows():
        it = csv.reader(lines_from(text()), delimiter=delim)
        if m:
            next(it, None)
        yield from it
    s = Sheet(name, rows())
    s.delimiter = delim
    s.offset = 1 if m else 0                 # the "sep=" line above the table
    return s


# ---- Excel ----------------------------------------------------------------------------------------------

def _cell_text(v):
    """An Excel value as the text a person sees: 12 not 12.0, a date as 2026-11-10, TRUE as True."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return "True" if v else "False"
    if isinstance(v, float):
        if v.is_integer() and abs(v) < 1e15:
            return str(int(v))
        return repr(v)
    if hasattr(v, "isoformat"):
        t = v.isoformat()
        return t[:-9] if t.endswith("T00:00:00") else t
    return str(v)


def _trimmed(row):
    row = [_cell_text(v) for v in row[:MAX_COLS * 2]]
    while row and not row[-1].strip():
        row.pop()
    return row


def xlsx_sheets(fileobj):
    """Every worksheet of an .xlsx (chart sheets have no rows). Streamed, never all in memory."""
    import openpyxl
    wb = openpyxl.load_workbook(fileobj, read_only=True, data_only=True)
    out = []
    for ws in wb.worksheets:
        def rows(ws=ws):
            for r in ws.iter_rows(values_only=True):
                yield _trimmed(list(r))
        out.append(Sheet(ws.title, rows(), hidden=ws.sheet_state != "visible"))
    return out, wb


def xls_sheets(data):
    """Every sheet of an Excel 97-2003 .xls (the format holds at most 65,536 rows a sheet)."""
    import xlrd
    book = xlrd.open_workbook(file_contents=data, on_demand=True)
    out = []
    for i in range(book.nsheets):
        sh = book.sheet_by_index(i)

        def rows(sh=sh):
            for r in range(sh.nrows):
                vals = []
                for c in range(min(sh.ncols, MAX_COLS * 2)):
                    cell = sh.cell(r, c)
                    if cell.ctype == xlrd.XL_CELL_DATE:
                        try:
                            vals.append(xlrd.xldate_as_datetime(cell.value, book.datemode))
                        except Exception:  # noqa: BLE001 - a broken date stays a number
                            vals.append(cell.value)
                    elif cell.ctype == xlrd.XL_CELL_BOOLEAN:
                        vals.append(bool(cell.value))
                    elif cell.ctype == xlrd.XL_CELL_ERROR:
                        vals.append("")
                    else:
                        vals.append(cell.value)
                yield _trimmed(vals)
        out.append(Sheet(sh.name, rows(), hidden=getattr(sh, "visibility", 0) != 0))
    return out, book


class _Tables(html.parser.HTMLParser):
    """The tables of an HTML page (what web tools often save as ".xls")."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tables, self.row, self.cell, self.depth = [], None, None, 0

    def handle_starttag(self, tag, attrs):
        if tag == "table":
            self.depth += 1
            if self.depth == 1:
                self.tables.append([])
        elif tag == "tr" and self.depth:
            self.row = []
        elif tag in ("td", "th") and self.row is not None:
            self.cell = []
        elif tag == "br" and self.cell is not None:
            self.cell.append(" ")

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self.cell is not None and self.row is not None:
            self.row.append("".join(self.cell))
            self.cell = None
        elif tag == "tr" and self.row is not None:
            if self.tables:
                self.tables[-1].append(self.row)
            self.row = None
        elif tag == "table" and self.depth:
            self.depth -= 1

    def handle_data(self, data):
        if self.cell is not None:
            self.cell.append(data)


def html_sheets(text, name):
    p = _Tables()
    p.feed(text)
    p.close()
    tables = [t for t in p.tables if len(t) >= 2]
    return [Sheet(name if len(tables) == 1 else f"{name} (table {i + 1})", iter(t)) for i, t in enumerate(tables)]


def kind_of(head, file_name):
    """What the upload really is, from its first bytes (its name only breaks a tie)."""
    if head.startswith(b"PK\x03\x04"):
        return "xlsx"
    if head.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
        return "xls"
    enc = bom_or_utf16(head)
    probe = head[:4096]
    try:
        t = probe.decode({"utf-16-le": "utf-16-le", "utf-16-be": "utf-16-be", "utf-16-le-bom": "utf-16",
                          "utf-16-be-bom": "utf-16"}.get(enc, "latin-1"), errors="ignore")
    except LookupError:
        t = ""
    if re.match(r"^\s*(<\?xml[^>]*>\s*)?(<!doctype html|<html|<table|<meta|<head|<style)", t.lstrip("﻿"), re.I):
        return "html"
    return "csv"


def split_head(sheet_rows):
    """(header index, the first rows) of a sheet, from its first rows."""
    first = []
    for r in sheet_rows:
        first.append(r)
        if len(first) >= HEAD_ROWS:
            break
    return find_header(first), first
