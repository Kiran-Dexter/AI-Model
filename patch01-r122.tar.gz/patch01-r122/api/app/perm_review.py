"""Access review (r119): file and folder permissions, and which application and team owns them.

An admin uploads a permissions report as CSV, from whichever tool made it (NTFS Permissions
Reporter, Netwrix, Varonis, ManageEngine, PowerShell Get-Acl, ...). Then:

  1. Reading:  the worker reads it as it is: its encoding (UTF-8, UTF-16, Windows-1252), its
               separator, and where the header row is (a title above it is skipped).
  2. Columns:  rules that know these tools' column names, then AI-01 for the rest, propose which
               column is the path, the account, the permissions, and so on. The admin confirms.
  3. Rows:     each row is made plain by rules, never by AI-01: server, share, folder, account,
               the kind of account, the access level (from words, letters or an access mask),
               allow or deny, inherited or not.
  4. Tagging:  AI-01 proposes the application and owning team of each folder (from its path,
               the groups on it, its sub-folders, and what the admin confirmed before). Nothing
               it proposes counts as confirmed until an admin says so; confirmed tags are kept
               for the next upload. A tag covers the folder and everything under it.
  5. Reports:  AI-01 recommends which reports fit this file; the admin chooses step by step;
               every figure is counted by PostgreSQL from the rows. AI-01 then writes a short
               summary from those figures only.

AI-01 only ever sees column names, a few sample values, folder names and group names: never the
whole file, and it never counts.
"""
import codecs
import csv
import io
import json
import logging
import re

log = logging.getLogger("patchapi.perm")

MAX_BYTES = 1024 * 2 ** 20          # 1 GB
MAX_ROWS = 3_000_000
MAX_COLS = 80
MAX_CELL = 2000
CHUNK = 16 * 2 ** 20
CHUNK_MAX = 32 * 2 ** 20
csv.field_size_limit(4 * 2 ** 20)

# ---- 1. reading (perm_read.py: CSV, .xlsx, .xls, HTML tables; encodings; cleaning) -------------------------

from .perm_read import (Cleaner, ENCODING_TEXT, bom_or_utf16, find_header, lines_from, plain,  # noqa: E402,F401
                        sniff_delimiter)


def clean_cell(v):
    return plain(v)


# ---- 2. columns ----------------------------------------------------------------------------------------

ROLES = [
    ("path", "Folder or file path", True),
    ("identity", "Account or group", True),
    ("rights", "Permissions (when missing: \u201cnot stated\u201d)", False),
    ("access_type", "Allow or deny", False),
    ("inherited", "Inherited", False),
    ("owner", "Owner of the folder", False),
    ("server", "Server", False),
    ("share", "Share", False),
    ("share_path", "The share's own folder (D:\\Shares\\Fin), when listed", False),
    ("domain", "Domain of the account, when in its own column", False),
    ("account_type", "Kind of account (user, group)", False),
    ("application", "Application (when the file has it)", False),
    ("team", "Owning team (when the file has it)", False),
]
ROLE_KEYS = [r[0] for r in ROLES]
REQUIRED = [r[0] for r in ROLES if r[2]]

# A sheet of drive information: the drive letters and where each points (r120)
DRIVE_ROLES = [
    ("drive", "Drive letter", True),
    ("target", "Where it points (\\\\server\\share)", False),
    ("server", "Server", False),
    ("label", "Label or description", False),
    ("owner", "Owner", False),
    ("application", "Application", False),
    ("team", "Owning team", False),
]
# A sheet of group members (per drive or not)
MEMBER_ROLES = [
    ("group", "Group", True),
    ("member", "Member", True),
    ("member_type", "Kind of member (user, group, computer)", False),
    ("drive", "Drive letter", False),
    ("department", "Department of the member", False),
]
# A sheet of people: user name and department (and title, manager...) (r122)
PEOPLE_ROLES = [
    ("person", "User name (the account)", True),
    ("department", "Department", True),
    ("display_name", "Full name", False),
    ("title", "Job title", False),
    ("manager", "Manager", False),
    ("location", "Location or office", False),
    ("email", "E-mail", False),
]
ROLESETS = {"permissions": ROLES, "drives": DRIVE_ROLES, "members": MEMBER_ROLES, "people": PEOPLE_ROLES}
SHEET_ROLE_TEXT = {"permissions": "Permissions", "drives": "Drive information", "members": "Group members",
                   "people": "People (user details)", "skip": "Not used"}
SHEET_NAME_ROLES = {"permissions": ("server", "share", "application", "team"), "drives": ("drive", "server", "label"),
                    "members": ("drive", "group", "department"), "people": ("department",)}

# Column names as these tools write them (lower case, letters and digits only)
SYNONYMS = {
    "path": ["path", "folderpath", "objectpath", "fullpath", "folder", "directory", "directorypath", "dir", "resource",
             "resourcepath", "location", "filepath", "sharepath", "uncpath", "object", "objectname", "foldername", "item",
             "itempath", "fullname", "filesystempath",
             "pfad", "ordner", "ordnerpfad", "chemin", "dossier", "ruta", "carpeta", "percorso", "cartella", "pad", "map"],
    "identity": ["account", "accountname", "identity", "identityreference", "trustee", "trusteename", "user", "username",
                 "principal", "principalname", "securityprincipal", "group", "groupname", "member", "accountdisplayname",
                 "samaccountname", "who", "name", "useraccount", "userorgroup", "usergroup", "accountorgroup",
                 "benutzer", "konto", "benutzergruppe", "utilisateur", "compte", "usuario", "cuenta", "utente", "gebruiker"],
    "rights": ["permissions", "permission", "rights", "accessrights", "filesystemrights", "access", "accessmask",
               "permissionlevel", "effectivepermissions", "accesslevel", "perms", "ntfspermissions", "folderpermissions",
               "permissionsgranted", "accesspermissions",
               "berechtigung", "berechtigungen", "rechte", "droits", "autorisations", "permisos", "permessi", "rechten", "machtigingen"],
    "access_type": ["accesscontroltype", "accesstype", "permissiontype", "allowdeny", "acetype", "type", "accesscontrol",
                    "allowordeny", "grantdeny"],
    "inherited": ["inherited", "isinherited", "inheritance", "inheritedfrom", "inherit", "inheritedpermission",
                  "explicitorinherited", "inheritancetype",
                  "vererbt", "geerbt", "herite", "heredado", "ereditato", "overgenomen"],
    "owner": ["owner", "folderowner", "objectowner", "fileowner"],
    "server": ["server", "servername", "host", "hostname", "computer", "computername", "fileserver", "machine", "device",
               "devicename", "nasname", "filer"],
    "share": ["share", "sharename", "sharedfolder", "netshare"],
    "share_path": ["sharelocalpath", "sharerootpath", "sharerootfolder", "localsharepath", "sharefolderpath", "sharedpath",
                   "sharelocation", "rootpath", "sharepathlocal"],
    "domain": ["domain", "domainname", "netbiosdomain", "accountdomain", "trusteedomain", "userdomain"],
    "account_type": ["accounttype", "objecttype", "objectclass", "principaltype", "trusteetype", "accountclass",
                     "identitytype", "usertype", "type"],
    "application": ["application", "app", "appname", "applicationname", "system", "service", "businessapplication"],
    "team": ["team", "ownerteam", "owningteam", "appowner", "applicationowner", "department", "businessowner",
             "dataowner", "supportteam", "resolvergroup"],
}


SYNONYMS_DRIVES = {
    "drive": ["drive", "driveletter", "letter", "drv", "mappeddrive", "mapdrive", "volume", "volumeletter", "mountpoint",
              "drivename", "localdrive", "networkdrive"],
    "target": ["target", "path", "uncpath", "unc", "mappedto", "mappedpath", "remotepath", "sharepath", "networkpath",
               "location", "pointsto", "share", "sharename", "providername", "remotename"],
    "server": SYNONYMS["server"],
    "label": ["label", "volumelabel", "description", "desc", "name", "drivelabel", "purpose", "comment", "displayname"],
    "owner": ["owner", "driveowner", "dataowner", "contact", "custodian"],
    "application": SYNONYMS["application"],
    "team": SYNONYMS["team"],
}
SYNONYMS_MEMBERS = {
    "group": ["group", "groupname", "adgroup", "securitygroup", "parentgroup", "groupsamaccountname", "memberof",
              "groupdisplayname", "distributiongroup", "role"],
    "member": ["member", "membername", "members", "user", "username", "account", "accountname", "samaccountname",
               "userprincipalname", "upn", "displayname", "employee", "login", "userid", "memberaccount"],
    "member_type": ["membertype", "objectclass", "objecttype", "type", "accounttype", "memberclass", "class", "kind"],
    "drive": SYNONYMS_DRIVES["drive"],
}
DEPT_WORDS = ["department", "dept", "departmentname", "deptname", "division", "businessunit", "bu", "orgunit", "organisation",
              "organization", "org", "function", "costcenter", "costcentre", "team", "teamname", "unit", "section", "group department",
              "abteilung", "departement", "departamento", "reparto", "afdeling", "service"]
SYNONYMS_MEMBERS["department"] = DEPT_WORDS
SYNONYMS_PEOPLE = {
    "person": ["username", "user", "samaccountname", "account", "accountname", "login", "loginname", "logonname", "userid",
               "userlogonname", "userprincipalname", "upn", "networkid", "windowsid", "adaccount", "userlogin", "member",
               "membername", "benutzer", "benutzername", "utilisateur", "usuario", "utente", "gebruiker"],
    "department": DEPT_WORDS,
    "display_name": ["displayname", "fullname", "name", "employeename", "employee", "cn", "commonname", "personname",
                     "staffname", "firstnamelastname"],
    "title": ["title", "jobtitle", "position", "designation", "role", "jobrole"],
    "manager": ["manager", "managername", "reportsto", "linemanager", "supervisor", "lead"],
    "location": ["location", "office", "site", "city", "country", "physicaldeliveryofficename", "building", "region"],
    "email": ["email", "mail", "emailaddress", "smtp", "smtpaddress", "primaryemail", "workemail"],
}
SYNONYMS_BY = {"permissions": SYNONYMS, "drives": SYNONYMS_DRIVES, "members": SYNONYMS_MEMBERS, "people": SYNONYMS_PEOPLE}
DRIVE_RE = re.compile(r"^\s*([A-Za-z]):?\\?\s*$")


def drive_of(text):
    """'H', 'h:', 'H:\\' -> 'H:'; also from a sheet's name: 'H Drive', 'Drive H', 'H-Drive members' -> 'H:'."""
    t = (text or "").strip()
    m = DRIVE_RE.match(t)
    if m:
        return m.group(1).upper() + ":"
    m = re.search(r"(?:^|[^a-z0-9])([a-z])(?::|\s*[-_ ]?\s*drive\b)", t, re.I) or re.search(r"\bdrive\s*[-_ ]?\s*([a-z])\b", t, re.I)
    return m.group(1).upper() + ":" if m else None


def _norm_header(h):
    return re.sub(r"[^a-z0-9]", "", (h or "").lower())


def _value_score(role, values):
    """How well a column's values fit a role: 0 none .. 3 sure."""
    vals = [v for v in values if v][:40]
    if not vals:
        return 0
    def share(pred):
        return sum(1 for v in vals if pred(v)) / len(vals)
    if role == "path":
        s = share(lambda v: bool(re.match(r"^(\\\\[^\\]+\\|[A-Za-z]:\\|/)", clean_path(v))))
        return 3 if s > 0.8 else 1 if s > 0.3 else 0
    if role == "share_path":
        s = share(lambda v: bool(re.match(r"^[A-Za-z]:\\|^/", clean_path(v))))
        return 3 if s > 0.8 else 0
    if role == "domain":
        s = share(lambda v: bool(re.fullmatch(r"[A-Za-z][\w.\- ]{0,62}", v)) and "\\" not in v)
        return 1 if s > 0.9 else 0
    if role == "identity":
        s = share(lambda v: bool(re.match(r"^([\w.\- ]+\\[\w.\-$ ]+|[\w.\-]+@[\w.\-]+|S-1-[\d-]+|everyone|authenticated users|"
                                          r"creator owner|system|[\w.\- $]{2,64})$", v, re.I)) and not re.match(r"^(\\\\|[A-Za-z]:\\)", v))
        return 2 if s > 0.8 else 0
    if role == "rights":
        s = share(lambda v: level_of(v) not in ("special", "none") or v.lower() in ("special", "special permissions"))
        return 3 if s > 0.7 else 1 if s > 0.3 else 0
    if role == "access_type":
        s = share(lambda v: v.strip().lower() in ("allow", "deny", "allowed", "denied", "grant", "granted"))
        return 3 if s > 0.9 else 0
    if role == "inherited":
        s = share(lambda v: bool_of(v) is not None)
        return 2 if s > 0.9 else 0
    if role == "drive":
        s = share(lambda v: bool(DRIVE_RE.match(v)))
        return 3 if s > 0.8 else 0
    if role == "target":
        s = share(lambda v: v.startswith("\\\\") or v.startswith("//"))
        return 3 if s > 0.8 else 0
    if role in ("group", "member"):
        s = share(lambda v: bool(re.match(r"^([\w.\- ]+\\[\w.\-$ ]+|[\w.\-]+@[\w.\-]+|[\w.\- $&()]{2,64})$", v))
                  and not re.match(r"^(\\\\|[A-Za-z]:\\?$)", v))
        if s <= 0.8:
            return 0
        distinct = len(set(v.lower() for v in vals)) / len(vals)
        if role == "group":
            return 2 if distinct < 0.7 else 1             # a group repeats down the sheet, once per member
        return 2
    if role == "person":
        s = share(lambda v: bool(re.match(r"^([\w.\- ]{1,64}\\[\w.\-$]{1,104}|[\w.\-]+@[\w.\-]+\.\w+|[\w.\-$]{2,64})$", v)))
        return 2 if s > 0.8 else 0                 # a person can be listed twice (two departments, two rows)
    if role == "department":
        s = share(lambda v: bool(re.fullmatch(r"[^\\/:@]{2,80}", v)) and not re.fullmatch(r"[\d.,]+", v))
        distinct = len(set(v.lower() for v in vals)) / len(vals)
        return 1 if s > 0.9 and (distinct < 0.7 or len(vals) < 4) else 0
    if role == "email":
        s = share(lambda v: bool(re.fullmatch(r"[\w.+\-']+@[\w\-]+(\.[\w\-]+)+", v)))
        return 3 if s > 0.8 else 0
    if role == "display_name":
        s = share(lambda v: bool(re.fullmatch(r"[^\\/@\d]{2,80}", v)) and " " in v.strip())
        return 1 if s > 0.7 else 0
    if role in ("account_type", "member_type"):
        s = share(lambda v: any(w in v.lower() for w in ("user", "group", "computer", "well-known", "wellknown", "alias")))
        return 2 if s > 0.8 else 0
    return 1


def rule_mapping(headers, rows, roleset="permissions"):
    """Which column is which, by the names these tools use and by what the values look like.
    {role: {"col": index, "score": n, "why": text}}; each column is used for one role at most."""
    cols = {i: [r[i] if i < len(r) else "" for r in rows] for i in range(len(headers))}
    syn = SYNONYMS_BY[roleset]
    cand = []
    for role in [r[0] for r in ROLESETS[roleset]]:
        for i, h in enumerate(headers):
            n = _norm_header(h)
            name = 3 if n in syn[role] else 2 if any(n.endswith(x) or n.startswith(x) for x in syn[role] if len(x) > 3) else 0
            vs = _value_score(role, cols[i])
            if role in ("path", "rights", "access_type", "inherited", "drive", "target", "share_path", "domain", "email",
                        "person", "department") and name and not vs:
                name = 0                              # a name alone is not enough when the values say otherwise
            score = name * 2 + vs
            if score >= 3:
                cand.append((score, role, i, f"column \"{h}\": " + ("its name" if name else "") +
                             (" and " if name and vs else "") + ("its values" if vs else "")))
    out, used = {}, set()
    for score, role, i, why in sorted(cand, key=lambda x: -x[0]):
        if role in out or i in used:
            continue
        out[role] = {"col": i, "score": score, "why": why}
        used.add(i)
    return out


def mapping_messages(headers, rows, roleset="permissions"):
    """What AI-01 is shown to map the columns: each column's name and five sample values."""
    cols = []
    for i, h in enumerate(headers[:MAX_COLS]):
        vals = []
        for r in rows:
            v = (r[i] if i < len(r) else "").strip()
            if v and v not in vals:
                vals.append(v[:60])
            if len(vals) >= 5:
                break
        cols.append({"column": h[:80], "samples": vals})
    roles = {k: label for k, label, _ in ROLESETS[roleset]}
    what = {"permissions": "a file and folder permissions report", "drives": "a sheet of drive information (drive letters)",
            "members": "a sheet of group members", "people": "a sheet of people (user name, department, ...)"}[roleset]
    return [
        {"role": "system", "content": f"You map the columns of {what} to fields. "
         "Answer only with JSON. For each field give the exact column name that holds it, or an empty string when no "
         "column does. Never invent a column name. Use a column for one field at most."},
        {"role": "user", "content": "Fields: " + json.dumps(roles) + "\nColumns with sample values: " + json.dumps(cols)},
    ]


def mapping_schema(headers, roleset="permissions"):
    names = [h[:80] for h in headers[:MAX_COLS]] + [""]
    keys = [r[0] for r in ROLESETS[roleset]]
    return {"type": "object", "properties": {k: {"type": "string", "enum": names} for k in keys}, "required": keys}


SHEET_SYSTEM = """You sort the sheets of a workbook exported by a file-permissions tool. For each sheet you are given its name,
its column names and a few sample rows. Say what the sheet holds:
  "permissions"  rows of who has access to which folder, file or drive (a path or drive, an account, maybe the rights)
  "drives"       information about drive letters: where each drive points, its label, owner (no accounts per row)
  "members"      group membership: a group and its members, one member per row (maybe per drive)
  "people"       details of people: a user name with a department (maybe title, manager, location, e-mail), no access rights
  "skip"         anything else: a summary, totals, charts, notes, settings
Answer only with JSON. Never invent a sheet."""
SHEET_SCHEMA = {"type": "object", "properties": {"role": {"type": "string", "enum": ["permissions", "drives", "members", "people", "skip"]},
                                                 "why": {"type": "string"}}, "required": ["role", "why"]}


def sheet_messages(name, headers, rows):
    cols = mapping_messages(headers, rows)[1]["content"].split("Columns with sample values: ", 1)[1]
    return [{"role": "system", "content": SHEET_SYSTEM},
            {"role": "user", "content": json.dumps({"sheet": name[:80]}) + "\nColumns with sample values: " + cols}]


def rule_role(name, headers, rows):
    """(role, sure, why, {roleset: rule mapping}) by the rules alone."""
    perm = rule_mapping(headers, rows, "permissions")
    drv = rule_mapping(headers, rows, "drives")
    mem = rule_mapping(headers, rows, "members")
    ppl = rule_mapping(headers, rows, "people")
    rules = {"permissions": perm, "drives": drv, "members": mem, "people": ppl}
    if "path" in perm and "identity" in perm:
        sure = perm["path"]["score"] >= 5 and perm["identity"]["score"] >= 4
        return "permissions", sure, "a path and an account on each row" + (" with the rights" if "rights" in perm else ""), rules
    if "group" in mem and "member" in mem:
        sure = mem["group"]["score"] >= 6 and mem["member"]["score"] >= 6
        return "members", sure, f"a group (\u201c{headers[mem['group']['col']]}\u201d) and its members on each row", rules
    if "person" in ppl and "department" in ppl:
        sure = ppl["person"]["score"] >= 6 and ppl["department"]["score"] >= 5
        return "people", sure, (f"a person (\u201c{headers[ppl['person']['col']]}\u201d) and a department "
                                f"(\u201c{headers[ppl['department']['col']]}\u201d) on each row"), rules
    if "drive" in drv and ("member" in mem or "identity" in perm):
        # a drive and an account on each row: who has the drive (a permissions list with the drive as the path)
        acc = mem.get("member") or perm.get("identity")
        rules["permissions"] = {"path": dict(drv["drive"], why=drv["drive"]["why"] + " (the drive is the path)"),
                                "identity": acc}
        for k in ("rights", "access_type", "inherited", "account_type", "server"):
            if k in perm and perm[k]["col"] not in (drv["drive"]["col"], acc["col"]):
                rules["permissions"][k] = perm[k]
        return "permissions", False, "a drive letter and an account on each row: who has access to each drive", rules
    if "drive" in drv:
        return "drives", drv["drive"]["score"] >= 6, "drive letters" + (" and where they point" if "target" in drv else ""), rules
    return "skip", False, "no path, account, drive letter or group found", rules


def merge_mapping(headers, rule, ai, roleset="permissions"):
    """The proposal: a sure rule wins; AI-01 fills what the rules could not tell, only with a
    column that exists and is not used yet. {role: {"col", "by", "why"}}."""
    out, used = {}, set()
    for role, r in rule.items():
        if r["score"] >= 5:
            out[role] = {"col": r["col"], "by": "rules", "why": r["why"]}
            used.add(r["col"])
    idx = {h[:80]: i for i, h in enumerate(headers)}
    for role in [r[0] for r in ROLESETS[roleset]]:
        if role in out:
            continue
        name = (ai if isinstance(ai, dict) else {}).get(role) or ""
        name = name if isinstance(name, str) else ""
        if name in idx and idx[name] not in used:
            out[role] = {"col": idx[name], "by": "AI-01", "why": f"AI-01 read column \"{name}\" as {role.replace('_', ' ')}"}
            used.add(idx[name])
        elif role in rule and rule[role]["col"] not in used:
            out[role] = {"col": rule[role]["col"], "by": "rules", "why": rule[role]["why"]}
            used.add(rule[role]["col"])
    return out


def check_mapping(mapping, headers, roleset="permissions", sheet=None):
    """An admin's mapping: {role: column index or None}; the index len(headers) is the sheet's own
    name (for the roles that can take it). Returns the clean mapping, or PermError."""
    if not isinstance(mapping, dict):
        raise PermError("The mapping must say which column holds what.")
    where = f"Sheet \u201c{sheet}\u201d: " if sheet else ""
    roles = ROLESETS[roleset]
    out, used = {}, {}
    for role in [r[0] for r in roles]:
        v = mapping.get(role)
        if v is None or v == "":
            continue
        try:
            i = int(v)
        except (TypeError, ValueError):
            raise PermError(f"{role}: not a column.")
        if i == len(headers) and role in SHEET_NAME_ROLES.get(roleset, ()):
            out[role] = i                            # the sheet's name
            continue
        if not 0 <= i < len(headers):
            raise PermError(f"{where}{role}: there is no column {i + 1}.")
        if i in used:
            raise PermError(f"{where}column \"{headers[i]}\" is chosen for both {used[i]} and {role}: one field per column.")
        used[i] = role
        out[role] = i
    missing = [label for k, label, req in roles if req and k not in out]
    if missing:
        raise PermError(where + "choose the column for: " + ", ".join(missing) + ".")
    return out


# ---- 3. rows made plain -----------------------------------------------------------------------------------

LEVELS = ["none", "unstated", "special", "list", "read", "read_execute", "write", "modify", "full"]
RANK = {lv: i for i, lv in enumerate(LEVELS)}
LEVEL_TEXT = {"full": "Full control", "modify": "Modify", "write": "Write", "read_execute": "Read & execute",
              "read": "Read", "list": "List folder", "special": "Special", "unstated": "Not stated in the file", "none": "None"}


def rank_sql(col):
    """SQL: an entry's level as its rank (LEVELS order), to take the highest with max()."""
    return "CASE " + col + " " + " ".join(f"WHEN '{lv}' THEN {i}" for i, lv in enumerate(LEVELS)) + " ELSE 0 END"
WRITE_LEVELS = ("write", "modify", "full")

WORDS = [  # (pattern on the squeezed text, level); the highest found wins
    (r"fullcontrol|^full$|^fullaccess$|^fc$|genericall|changepermissions|takeownership|writedac|writeowner", "full"),
    (r"modify|^change$", "modify"),
    (r"write|createfiles|createdirectories|appenddata|writedata|genericwrite|^delete", "write"),
    (r"readandexecute|read&execute|readexecute|executefile|traverse|genericexecute", "read_execute"),
    (r"read|genericread|readdata|readattributes|readpermissions", "read"),
    (r"list|listdirectory|listfolder", "list"),
    (r"special|synchronize", "special"),
    (r"^noaccess$|^none$|^noaccessrights$|^denyall$", "none"),
]
LETTERS = {"f": "full", "m": "modify", "w": "write", "x": "read_execute", "r": "read", "l": "list"}


def level_of_mask(m):
    if m & 0x10000000 or (m & 0x1F01FF) == 0x1F01FF or m & 0x40000 or m & 0x80000:
        return "full"                                  # all rights, or can change permissions or take ownership
    if m & 0x10000 and m & 0x2 and m & 0x1:
        return "modify"
    if m & (0x2 | 0x4 | 0x40000000):
        return "write"
    if (m & 0x20 and m & 0x1) or m & 0x20000000:
        return "read_execute"
    if m & (0x1 | 0x80000000):
        return "read"
    if m & 0x20:
        return "list"
    return "special" if m else "none"


# icacls letters (the inheritance flags OI CI IO NP I carry no rights)
ICACLS = {"F": "full", "GA": "full", "WDAC": "full", "WO": "full", "M": "modify", "RX": "read_execute", "GE": "read_execute",
          "X": "read_execute", "R": "read", "GR": "read", "RD": "read", "REA": "read", "RA": "read", "RC": "read", "S": "list",
          "W": "write", "GW": "write", "WD": "write", "AD": "write", "WEA": "write", "WA": "write", "D": "write", "DE": "write",
          "DC": "write", "N": "none"}


def level_of(text):
    """The access level of one entry, from the words, letters or access mask a tool writes."""
    t = (text or "").strip()
    if not t:
        return "none"
    if re.fullmatch(r"-?\d{1,10}", t):
        return level_of_mask(int(t) & 0xFFFFFFFF)
    if re.fullmatch(r"0x[0-9a-fA-F]{1,8}", t):
        return level_of_mask(int(t, 16))
    if re.fullmatch(r"(\([A-Z,]+\))+", t.replace(" ", "")):                     # icacls: (OI)(CI)(M), (I)(RX), (R,W)
        lv = None
        for tok in re.findall(r"[A-Z]+", t):
            got = ICACLS.get(tok)
            if got and (lv is None or RANK[got] > RANK[lv]):
                lv = got
        return lv or "special"
    if re.fullmatch(r"[FMRWXLfmrwxl]{1,6}", t) and t.isupper():
        return max((LETTERS[c.lower()] for c in t), key=lambda lv: RANK[lv])
    bits = [b.strip() for b in re.split(r"[,;|/+ ]+", t) if b.strip()]
    if bits and all(len(b) == 1 and b.isupper() and b.lower() in LETTERS for b in bits):     # R/W, R W X
        return max((LETTERS[b.lower()] for b in bits), key=lambda lv: RANK[lv])
    best = None
    for part in re.split(r"[,;|/+]", t):
        sq = re.sub(r"[\s_\-()]", "", part.lower())
        if not sq:
            continue
        for pat, lv in WORDS:
            if re.search(pat, sq):
                if best is None or RANK[lv] > RANK[best]:
                    best = lv
                break
    return best or "special"


def bool_of(v):
    t = (v or "").strip().strip("<>()[]").strip().lower()
    if t.startswith(("not inherited", "not-inherited", "noninherited", "non-inherited", "no inherit")):
        return False
    if t.startswith(("explicit", "direct", "this folder only", "this object only", "set directly", "set here")):
        return False
    if t.startswith("inherit") or t.startswith("parent") or t.endswith("(parent)"):
        return True
    if t in ("ja", "oui", "si", "s\u00ed", "wahr", "vrai", "verdadero", "vero", "waar", "geerbt", "vererbt", "h\u00e9rit\u00e9", "heredado"):
        return True
    if t in ("nein", "non", "falsch", "faux", "falso", "nee", "onwaar", "explizit", "explicite", "expl\u00edcito"):
        return False
    if t in ("true", "yes", "y", "1", "inherited", "inherit", "parent") or t.startswith("inherited from") or t.startswith("yes"):
        return True
    if t in ("false", "no", "n", "0", "explicit", "direct", "not inherited", "this folder only", "none", "explicitly assigned",
             "explicit permission"):
        return False
    if t.startswith("\\\\") or re.match(r"^[a-z]:\\", t):
        return True                                    # "inherited from" written as the parent's path
    return None


def allow_of(v):
    t = (v or "").strip().lower()
    if t.startswith("deny") or t.startswith("denied"):
        return False
    return True


SYSTEM_NAMES = {"system", "nt authority\\system", "creator owner", "creator group", "local system", "trustedinstaller",
                "nt service\\trustedinstaller", "owner rights", "nt authority\\local service", "nt authority\\network service"}
ADMIN_NAMES = {"administrators", "builtin\\administrators", "domain admins", "enterprise admins", "backup operators",
               "builtin\\backup operators", "server operators", "builtin\\server operators", "schema admins"}
BROAD_NAMES = {"everyone", "authenticated users", "nt authority\\authenticated users", "users", "builtin\\users",
               "domain users", "domain computers", "guests", "builtin\\guests", "domain guests", "anonymous logon",
               "nt authority\\anonymous logon", "network", "nt authority\\network", "interactive",
               "nt authority\\interactive", "all users", "world"}
GROUP_NAME_RE = re.compile(r"^(grp|gg|sg|dl|lg|ug|gs|gl|acl|fs|role|sec|app)[_\-. ]|[_\-. ](rw|ro|mod|modify|read|write|"
                           r"readonly|readwrite|full|fc|owners?|members?|users|admins|group|grp|team|editors|readers|viewers)$|"
                           r"\bgroup\b", re.I)


ACCOUNT_IN = r"(?:[\w.\- ]{1,64}\\[\w.\-$ ]{1,104}|[\w.\-]+@[\w.\-]+\.\w+)"


def norm_identity(v):
    """An account as tools write it -> the account: quotes and trailing punctuation off,
    "John Smith (CORP\\jsmith)" -> CORP\\jsmith, "CORP\\jsmith (John Smith)" -> CORP\\jsmith."""
    t = re.sub(r"\s+", " ", (v or "").strip()).strip('"').strip("'").strip().rstrip(";,").strip()
    m = re.fullmatch(r"[^()\\]{1,120}\((" + ACCOUNT_IN + r")\)", t)
    if m:
        return m.group(1).strip()[:300]
    m = re.fullmatch(r"(" + ACCOUNT_IN + r")\s+\([^()]{1,120}\)", t)
    if m and not re.search(r"S-1-\d", t):
        return m.group(1).strip()[:300]
    return t[:300]


def identity_kind(identity, account_type=None):
    """(kind, how it was told). Known built-in names first; then the file's own account type
    column; then a group's usual name; else 'unknown' (never a guess)."""
    low = identity.lower()
    short = low.split("\\", 1)[1] if "\\" in low else low
    if re.fullmatch(r"s-1-5-21(-\d+){3,5}", low) or "account unknown" in low or "unknown account" in low or \
            "(unresolved)" in low or "deleted account" in low:
        return "orphan", "rule"
    if low in SYSTEM_NAMES or low.startswith("nt service\\") or short in ("system", "creator owner", "creator group"):
        return "system", "rule"
    if low in ADMIN_NAMES or short in ADMIN_NAMES:
        return "admin", "rule"
    if low in BROAD_NAMES or short in ("everyone", "authenticated users", "domain users", "domain computers", "users",
                                       "guests", "domain guests", "anonymous logon"):
        return "broad", "rule"
    at = (account_type or "").strip().lower()
    if at:
        if "computer" in at or "machine" in at:
            return "computer", "column"
        if "group" in at or "alias" in at or "well" in at:
            return "group", "column"
        if "user" in at or "person" in at or "account" == at:
            return "user", "column"
    if low.endswith("$"):
        return "computer", "rule"
    if GROUP_NAME_RE.search(short):
        return "group", "name"
    return "unknown", "rule"


PROVIDER_RE = re.compile(r"^\s*(?:Microsoft\.PowerShell\.Core\\)?FileSystem::", re.I)


def clean_path(p):
    """A path as tools write it -> a plain path: PowerShell's provider prefix
    (Microsoft.PowerShell.Core\\FileSystem::\\\\fs\\a), file: URLs, quotes."""
    t = (p or "").strip().strip('"').strip("'")
    t = PROVIDER_RE.sub("", t)
    m = re.match(r"^file:/*(.*)$", t, re.I)
    if m:
        rest = m.group(1).replace("/", "\\")
        t = rest if re.match(r"^[A-Za-z]:", rest) else "\\\\" + rest.lstrip("\\")
    return t


def split_path(path, server_col=None, share_col=None):
    """(server, share, parts below the share, display path, style). UNC \\\\server\\share\\a\\b,
    a drive path D:\\a\\b (server from its column), or a Linux path /srv/a/b."""
    path = clean_path(path)
    p = path.replace("/", "\\") if not path.startswith("/") else path
    server, share = (server_col or "").strip() or None, (share_col or "").strip() or None
    if p.startswith("\\\\?\\UNC\\"):
        p = "\\\\" + p[8:]
    elif p.startswith("\\\\?\\"):
        p = p[4:]
    if p.startswith("\\\\"):
        bits = [b for b in p[2:].split("\\") if b]
        server = bits[0] if bits else server
        share = bits[1] if len(bits) > 1 else share
        parts = bits[2:]
        disp = "\\\\" + "\\".join(bits)
        style = "unc"
    elif re.match(r"^[A-Za-z]:\\?", p):
        bits = [b for b in p.split("\\") if b]
        share = bits[0].upper().rstrip("\\")
        parts = bits[1:]
        disp = ((server + " ") if server else "") + "\\".join([share] + parts)
        style = "drive"
    elif p.startswith("/"):
        bits = [b for b in p.split("/") if b]
        share = "/" + bits[0] if bits else "/"
        parts = bits[1:]
        disp = ((server + ":") if server else "") + p
        style = "posix"
    else:
        bits = [b for b in p.split("\\") if b]
        parts = bits
        disp = ((server + " ") if server else "") + p
        style = "plain"
    return server, share, parts, disp, style


def folder_key(server, share, parts, depth, style="unc"):
    """The unit tagged with an application: the share (or drive) and `depth` folder levels below
    it. (key in lower case, label as written). A tag on it covers everything under it."""
    below = list(parts[:depth])
    if style == "unc" and server:
        label = "\\\\" + "\\".join([server] + ([share] if share else []) + below)
    elif style == "drive":
        label = ((server + " ") if server else "") + "\\".join([share] + below) + ("" if below else "\\")
    elif style == "posix":
        label = ((server + ":") if server else "") + share + "".join("/" + b for b in below)
    else:
        label = ((server + " ") if server else "") + "\\".join(below or ["(no folder)"])
    return label.lower(), label


def ident_key(v):
    """An account's short name in lower case: CORP\\GG_X, gg_x@corp.com and GG_X are one account.
    (Two domains with the same short name would be taken as one: rare in one company's file servers.)"""
    t = (v or "").strip().strip('"').lower()
    if "\\" in t:
        t = t.rsplit("\\", 1)[1]
    if "@" in t and not t.startswith("@"):
        t = t.split("@", 1)[0]
    return t[:300]


class Context:
    """What the other sheets tell about the permission rows: where each drive letter points, which
    accounts are groups (they have members), and the kind of each member."""
    def __init__(self):
        self.targets = {}        # (server lower or "", "H:") -> set of targets (\\server\share\...)
        self.groups = set()      # short keys of the groups a members sheet lists
        self.member_kind = {}    # short key -> kind a members sheet states (from its type column)
        self.resolved = 0
        self.ambiguous = set()
        self.share_roots = {}    # (server lower, share lower) -> the share's own folder: [parts], from its column or the paths

    def target_for(self, server, drive):
        for key in ((server or "").lower(), ""):
            t = self.targets.get((key, drive))
            if t is not None:
                if len(t) == 1:
                    return next(iter(t))
                self.ambiguous.add(drive)
                return None
        return None


def entry_from(cells, m, depth, ctx=None, sheet_name=None):
    """One raw row -> a plain entry, or None (no path or no account: not an entry). The mapping's
    index len(cells) is the sheet's name."""
    def get(role):
        i = m.get(role)
        if i is None:
            return ""
        if i == m.get("_name_at", -1):
            return clean_cell(sheet_name)
        return clean_cell(cells[i]) if i < len(cells) else ""
    path_raw = get("path")
    path, ident = clean_path(path_raw), norm_identity(get("identity"))
    if not path or not ident:
        return None
    dom = get("domain")
    if dom and "\\" not in ident and "@" not in ident and not ident.upper().startswith("S-1-"):
        ident = dom + "\\" + ident                                # Varonis and others: CORP | jsmith -> CORP\jsmith
    server_col = get("server")
    share_col = get("share")
    if share_col and re.match(r"^[A-Za-z]:(\\|$)", path):
        # a local path with its share named: \\server\share\<the rest below the share's own folder>
        root = split_path(get("share_path"))[2] if get("share_path") else (ctx.share_roots.get(((server_col or "").lower(),
                                                                                                 share_col.lower())) if ctx else None)
        if root is not None and server_col:
            parts = [b for b in path.split("\\") if b]
            drive = parts[0].upper()
            rparts = [b for b in clean_path(get("share_path")).split("\\") if b] if get("share_path") else None
            rootp = [x.lower() for x in (rparts[1:] if rparts else root)]
            rdrive = (rparts[0].upper() if rparts else drive)
            low = [x.lower() for x in parts[1:]]
            if drive == rdrive and low[:len(rootp)] == rootp:
                path = "\\\\" + "\\".join([server_col, share_col] + parts[1 + len(rootp):])
                server_col = None
    if DRIVE_RE.match(path):
        path = path.strip().rstrip("\\").upper() + "\\"            # "H" or "h:" -> "H:\"
    if ctx and re.match(r"^[A-Za-z]:(\\|$)", path):
        target = ctx.target_for(server_col, path[:2].upper())
        if target:                                                 # H:\Finance -> \\FS01\Dept\Finance
            rest = path[2:].lstrip("\\")
            path = target.rstrip("\\") + ("\\" + rest if rest else "")
            server_col = None
            ctx.resolved += 1
    server, share, parts, disp, style = split_path(path, server_col, share_col)
    key, label = folder_key(server, share, parts, depth, style)
    kind, src = identity_kind(ident, get("account_type"))
    ik = ident_key(ident)
    if ctx and kind in ("unknown", "group", "user") and src != "column":
        if ik in ctx.groups:
            kind, src = "group", "members"                         # it has members: a group
        elif kind == "unknown" and ctx.member_kind.get(ik) in ("user", "group", "computer"):
            kind, src = ctx.member_kind[ik], "members"
    rights = get("rights")
    return {"server": server, "share": share, "path": disp[:1000], "path_raw": path_raw[:1000], "folder_key": key[:600],
            "folder_label": label[:600], "depth": len(parts), "identity": ident, "identity_key": ik, "identity_kind": kind,
            "kind_source": src, "rights_raw": rights[:300] or None,
            "level": level_of(rights) if rights else "unstated",
            "allow": allow_of(get("access_type")) if m.get("access_type") is not None else
            (False if re.search(r"\bdeny\b", rights, re.I) else True),
            "inherited": (bool_of(get("inherited")) if get("inherited") or not m.get("_inh_from") else False)
            if m.get("inherited") is not None else (True if re.search(r"\(I\)", rights) else
                                                      False if re.fullmatch(r"(\([A-Z,]+\))+", rights.replace(" ", "")) else None),
            "owner": get("owner")[:300] or None, "application": get("application")[:120] or None,
            "team": get("team")[:120] or None}


# ---- the upload (in pieces, as Deployment's) ------------------------------------------------------------

NAME_RE = re.compile(r"^[^\x00-\x1f<>]{1,120}$")
FILE_RE = re.compile(r"\.(csv|txt|tsv|xlsx|xlsm|xls)$", re.I)
MAX_XLS = 300 * 2 ** 20            # an .xls is read whole (the format holds 65,536 rows a sheet)


class PermError(ValueError):
    """Shown to the admin as it is."""


def start_upload(conn, user, file_name, size, name=None):
    fn = (file_name or "").replace("\\", "/").split("/")[-1].strip()[:200]
    if not fn or not FILE_RE.search(fn):
        raise PermError("Upload the report as a .csv, .xlsx or .xls file (or .txt / .tsv).")
    try:
        size = int(size)
    except (TypeError, ValueError):
        raise PermError("The file size is missing.")
    if size <= 0:
        raise PermError("The file is empty.")
    if size > MAX_BYTES:
        raise PermError(f"The file is larger than {MAX_BYTES // 2 ** 20} MB: export it in parts (for example per server).")
    if fn.lower().endswith(".xls") and size > MAX_XLS:
        raise PermError(f"An .xls file is read whole: at most {MAX_XLS // 2 ** 20} MB. Save it as .xlsx or .csv.")
    nm = (name or fn.rsplit(".", 1)[0]).strip()[:120]
    if not NAME_RE.match(nm):
        raise PermError("Give the upload a name without control characters.")
    r = conn.execute("""INSERT INTO perm_datasets (name, file_name, size_bytes, uploaded_by) VALUES (%s, %s, %s, %s)
                        RETURNING id::text AS id""", (nm, fn, size, user)).fetchone()
    return {"dataset_id": r["id"], "chunk_bytes": CHUNK, "size": size}


def remove(conn, ds_id):
    r = conn.execute("DELETE FROM perm_datasets WHERE id = %s RETURNING name", (ds_id,)).fetchone()
    if not r:
        raise PermError("That upload is not known.")
    return r["name"]


def put_chunk(conn, upload_id, offset, data):
    ds = conn.execute("SELECT state, size_bytes, received FROM perm_datasets WHERE id = %s FOR UPDATE",
                      (upload_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known (it may have been removed).")
    if ds["state"] != "uploading":
        raise PermError("That upload is finished already.")
    if len(data) > CHUNK_MAX or not data:
        raise PermError("A piece of the file is empty or too large.")
    if offset != ds["received"]:
        raise PermError(f"Piece out of order: expected the bytes from {ds['received']}.")
    if offset + len(data) > ds["size_bytes"]:
        raise PermError("The file is larger than announced.")
    seq = conn.execute("SELECT coalesce(max(seq), -1) + 1 AS n FROM perm_chunks WHERE dataset_id = %s", (upload_id,)).fetchone()["n"]
    conn.execute("INSERT INTO perm_chunks (dataset_id, seq, offset_b, data) VALUES (%s, %s, %s, %s)",
                 (upload_id, seq, offset, bytes(data)))
    conn.execute("UPDATE perm_datasets SET received = received + %s, updated_at = now() WHERE id = %s", (len(data), upload_id))
    return {"received": offset + len(data)}


def finish_upload(conn, upload_id):
    ds = conn.execute("SELECT state, size_bytes, received FROM perm_datasets WHERE id = %s FOR UPDATE", (upload_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known.")
    if ds["state"] != "uploading":
        raise PermError("That upload is finished already.")
    if ds["received"] != ds["size_bytes"]:
        raise PermError(f"Only {ds['received']} of {ds['size_bytes']} bytes arrived: upload it again.")
    conn.execute("UPDATE perm_datasets SET state = 'uploaded', progress = %s::jsonb, updated_at = now() WHERE id = %s",
                 (json.dumps({"step": "waiting", "note": "the worker reads it within a few seconds"}), upload_id))
    return {"ok": True}


# ---- reading the file (worker) ----------------------------------------------------------------------------

def _progress(conn, ds_id, **p):
    conn.execute("UPDATE perm_datasets SET progress = %s::jsonb, updated_at = now() WHERE id = %s", (json.dumps(p), ds_id))
    conn.commit()


def _pieces(conn, ds_id):
    n = conn.execute("SELECT count(*) AS n FROM perm_chunks WHERE dataset_id = %s", (ds_id,)).fetchone()["n"]
    for seq in range(n):
        r = conn.execute("SELECT data FROM perm_chunks WHERE dataset_id = %s AND seq = %s", (ds_id, seq)).fetchone()
        if r:
            yield bytes(r["data"])


class ChunkFile(io.RawIOBase):
    """The uploaded pieces as one seekable file, read from the database a piece at a time (an
    .xlsx is a zip: it is read from its end; the worker's /tmp is far too small for it)."""
    def __init__(self, conn, ds_id):
        super().__init__()
        self.conn, self.ds = conn, ds_id
        self.index = [(r["seq"], r["offset_b"], r["n"]) for r in conn.execute(
            "SELECT seq, offset_b, length(data) AS n FROM perm_chunks WHERE dataset_id = %s ORDER BY seq", (ds_id,)).fetchall()]
        self.size = sum(n for _, _, n in self.index)
        self.pos = 0
        self.cache = {}

    def readable(self):
        return True

    def seekable(self):
        return True

    def tell(self):
        return self.pos

    def seek(self, off, whence=0):
        self.pos = off if whence == 0 else self.pos + off if whence == 1 else self.size + off
        self.pos = max(0, self.pos)
        return self.pos

    def _piece(self, seq):
        if seq not in self.cache:
            if len(self.cache) >= 3:
                self.cache.pop(next(iter(self.cache)))
            self.cache[seq] = bytes(self.conn.execute("SELECT data FROM perm_chunks WHERE dataset_id = %s AND seq = %s",
                                                      (self.ds, seq)).fetchone()["data"])
        return self.cache[seq]

    def readinto(self, buf):
        want, got = len(buf), 0
        while got < want and self.pos < self.size:
            for seq, off, n in self.index:
                if off <= self.pos < off + n:
                    data = self._piece(seq)
                    take = data[self.pos - off:self.pos - off + (want - got)]
                    buf[got:got + len(take)] = take
                    got += len(take)
                    self.pos += len(take)
                    break
            else:
                break
        return got


def bulk_insert(conn, table, cols, rows, types=None):
    """COPY when the driver has it (psycopg 3), else plain inserts."""
    rows = list(rows)
    if not rows:
        return
    cur = conn.cursor()
    if hasattr(cur, "copy"):
        # text format: the server reads each value as its column's type (no binary type names needed)
        with cur.copy(f"COPY {table} ({', '.join(cols)}) FROM STDIN") as cp:
            for r in rows:
                cp.write_row(r)
    else:
        cur.executemany(f"INSERT INTO {table} ({', '.join(cols)}) VALUES ({', '.join(['%s'] * len(cols))})", rows)


def open_sheets(conn, ds_id, file_name):
    """(kind, encoding, delimiter, [Sheet]) of the upload, from its bytes."""
    from . import perm_read as rd
    first = b""
    for b in _pieces(conn, ds_id):
        first += b
        if len(first) >= 262144:
            break
    kind = rd.kind_of(first[:65536], file_name)
    base = re.sub(r"\.[A-Za-z0-9]{1,5}$", "", file_name)[:80] or "Sheet"
    if kind == "xlsx":
        try:
            sheets, _ = rd.xlsx_sheets(ChunkFile(conn, ds_id))
        except Exception as e:  # noqa: BLE001
            raise PermError("The .xlsx could not be opened (" + type(e).__name__ + ": " + str(e)[:120] +
                            "). Is it password-protected? Save it again without a password.")
        return kind, "xlsx", None, sheets
    if kind == "xls":
        try:
            import xlrd  # noqa: F401
        except ImportError:
            raise PermError("Reading .xls needs PATCH-01 r120's image: run phase3b-api.sh again (it installs xlrd), "
                            "or save the file as .xlsx.")
        data = b"".join(_pieces(conn, ds_id))
        try:
            sheets, _ = rd.xls_sheets(data)
        except Exception as e:  # noqa: BLE001
            raise PermError("The .xls could not be opened (" + type(e).__name__ + ": " + str(e)[:120] +
                            "). Save it again as .xlsx or .csv.")
        return kind, "xls", None, sheets
    enc = rd.bom_or_utf16(first[:65536]) or rd.scan_encoding(_pieces(conn, ds_id))
    if kind == "html":
        if sum(1 for _ in _pieces(conn, ds_id)) * CHUNK > MAX_XLS:
            raise PermError("An HTML table saved as .xls is read whole: at most 300 MB. Save it as .csv.")
        dec = rd.decoder_for(enc)
        text = "".join(dec.decode(b) for b in _pieces(conn, ds_id)) + dec.decode(b"", final=True)
        sheets = rd.html_sheets(text, base)
        if not sheets:
            raise PermError("The file is a web page without a table: is it the report?")
        return "html", enc, None, sheets
    pieces = _pieces(conn, ds_id)
    head = b""
    for b in pieces:
        head += b
        if len(head) >= 262144:
            break
    sh = rd.csv_sheet(base, head, pieces, enc)
    return "csv", enc, sh.delimiter, [sh]


def read_file(conn, ds_id, stop=lambda: False):
    """The uploaded bytes -> perm_raw rows, every sheet; each sheet's header and sample saved."""
    from . import perm_read as rd
    ds = conn.execute("SELECT file_name FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    conn.execute("UPDATE perm_datasets SET state = 'reading', error = NULL WHERE id = %s", (ds_id,))
    conn.execute("DELETE FROM perm_raw WHERE dataset_id = %s", (ds_id,))
    conn.execute("DELETE FROM perm_sheets WHERE dataset_id = %s", (ds_id,))
    conn.commit()
    kind, enc, delim, sheets = open_sheets(conn, ds_id, ds["file_name"])
    clean = Cleaner()
    rn, first_sheet = 0, None
    for sheet_no, sh in enumerate(sheets[:60]):
        it = iter(sh.rows)
        hdr_i, head_rows = rd.split_head(it)
        headers, batch, n, skipped, sample = None, [], 0, 0, []

        def rows_of():
            yield from head_rows
            yield from it
        for i, row in enumerate(rows_of()):
            if i < hdr_i:
                continue
            if headers is None:
                headers = [clean(c) or f"Column {j + 1}" for j, c in enumerate(row[:MAX_COLS])]
                continue
            cells = [clean(c) for c in row[:MAX_COLS]]
            if not any(cells):
                continue
            if len([c for c in cells if c]) < 2 and len(headers) >= 2:
                skipped += 1                   # a total line, a note under the table
                continue
            n += 1
            rn += 1
            if rn > MAX_ROWS:
                raise PermError(f"More than {MAX_ROWS:,} rows: export the report in parts (for example per server).")
            if len(sample) < 25:
                sample.append(cells)
            batch.append((ds_id, rn, sheet_no, cells))
            if len(batch) >= 5000:
                bulk_insert(conn, "perm_raw", ("dataset_id", "rn", "sheet_no", "cells"), batch)
                batch = []
                if rn % 50000 == 0:
                    _progress(conn, ds_id, step="reading", rows=rn, sheet=sh.name)
                    if stop():
                        raise PermError("Stopped: the worker was restarted.")
        bulk_insert(conn, "perm_raw", ("dataset_id", "rn", "sheet_no", "cells"), batch)
        headers = headers or []
        useful = n > 0 and len(headers) >= 2
        conn.execute("""INSERT INTO perm_sheets (dataset_id, sheet_no, name, hidden, header_row, headers, row_count, skipped,
                                                 sample, role)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb, %s)""",
                     (ds_id, sheet_no, clean_cell(sh.name)[:120] or f"Sheet {sheet_no + 1}", bool(sh.hidden),
                      hdr_i + 1 + getattr(sh, "offset", 0), headers, n, skipped,
                      json.dumps(sample), None if useful else "skip"))
        if useful and first_sheet is None:
            first_sheet = (headers, sample, hdr_i + 1 + getattr(sh, "offset", 0))
        conn.commit()
    if first_sheet is None:
        raise PermError("No table with rows found: the file has fewer than two columns or no rows under the header. "
                        "Is it a permissions report?")
    total_skipped = conn.execute("SELECT coalesce(sum(skipped), 0) AS n FROM perm_sheets WHERE dataset_id = %s",
                                 (ds_id,)).fetchone()["n"]
    conn.execute("""UPDATE perm_datasets SET encoding = %s, delimiter = %s, file_type = %s, header_row = %s, headers = %s,
                           sample = %s::jsonb, row_count = %s, skipped = %s, cleaning = %s::jsonb, state = 'mapping',
                           progress = NULL WHERE id = %s""",
                 (enc, {"\t": "tab"}.get(delim, delim) if delim else None, kind, first_sheet[2], first_sheet[0],
                  json.dumps(first_sheet[1]), rn, total_skipped, json.dumps(clean.report()), ds_id))
    conn.execute("DELETE FROM perm_chunks WHERE dataset_id = %s", (ds_id,))
    conn.commit()
    return {"rows": rn, "sheets": len(sheets), "encoding": enc, "delimiter": delim}


def sheets_of(conn, ds_id):
    return conn.execute("""SELECT sheet_no, name, hidden, header_row, headers, row_count, skipped, sample, proposal, role, mapping
                             FROM perm_sheets WHERE dataset_id = %s ORDER BY sheet_no""", (ds_id,)).fetchall()


def propose(conn, ds_id, ai=None):
    """For each sheet: what it holds and which column is which, by the rules and AI-01; the admin confirms."""
    sheets = sheets_of(conn, ds_id)
    notes, used_ai = [], False
    props = {}
    for sh in sheets:
        if sh["role"] == "skip" and not sh["row_count"]:
            props[sh["sheet_no"]] = {"role": "skip", "by": "rules", "why": "empty, or fewer than two columns", "roles": {}}
            continue
        headers, sample = sh["headers"], sh["sample"] or []
        role, sure, why, rules = rule_role(sh["name"], headers, sample)
        by = "rules"
        if ai and not sure:
            try:
                got = _json(ai(sheet_messages(sh["name"], headers, sample), SHEET_SCHEMA))
                if got.get("role") in SHEET_ROLE_TEXT and (got["role"] != role):
                    role, by = got["role"], "AI-01"
                    why = clean_tag_text(got.get("why"), 200) or "AI-01 read the sheet's columns and rows"
                    used_ai = True
                elif got.get("role") == role:
                    by = "rules and AI-01"
                    used_ai = True
            except Exception as e:  # noqa: BLE001 - the rules' proposal stands alone
                notes.append(f"AI-01 did not answer for sheet \u201c{sh['name']}\u201d (" + str(e)[:80] + ").")
        cols = {}
        if role in ROLESETS:
            ai_cols = None
            if ai:
                try:
                    ai_cols = _json(ai(mapping_messages(headers, sample, role), mapping_schema(headers, role)))
                    used_ai = True
                except Exception as e:  # noqa: BLE001
                    notes.append(f"AI-01 did not map the columns of \u201c{sh['name']}\u201d (" + str(e)[:80] + ").")
            cols = merge_mapping(headers, rules.get(role, {}), ai_cols, role)
        props[sh["sheet_no"]] = {"role": role, "by": by, "why": why, "roles": cols}
    # the sheet's own name, where it tells what no column says
    perms = [sh for sh in sheets if props[sh["sheet_no"]]["role"] == "permissions"]
    for sh in sheets:
        p = props[sh["sheet_no"]]
        nm_i = len(sh["headers"] or [])
        if p["role"] in ("drives", "members") and "drive" not in p["roles"] and drive_of(sh["name"]):
            p["roles"]["drive"] = {"col": nm_i, "by": "rules", "why": f"the sheet's name \u201c{sh['name']}\u201d is drive {drive_of(sh['name'])}"}
        if p["role"] == "permissions" and "server" not in p["roles"] and len(perms) > 1 and "path" in p["roles"]:
            vals = [r[p["roles"]["path"]["col"]] for r in (sh["sample"] or []) if p["roles"]["path"]["col"] < len(r)]
            names = {x["name"].lower() for x in perms}
            if vals and all(re.match(r"^[A-Za-z]:", v) for v in vals if v) and len(names) == len(perms) \
                    and not re.fullmatch(r"(sheet|tabelle|feuil|hoja|foglio)\s*\d+", sh["name"], re.I):
                p["roles"]["server"] = {"col": nm_i, "by": "rules", "why": "drive paths on several sheets and no server "
                                        f"column: the sheet's name \u201c{sh['name']}\u201d tells the servers apart"}
    for sh in sheets:
        conn.execute("UPDATE perm_sheets SET proposal = %s::jsonb WHERE dataset_id = %s AND sheet_no = %s",
                     (json.dumps(props[sh["sheet_no"]]), ds_id, sh["sheet_no"]))
    first = next((props[sh["sheet_no"]] for sh in perms), {"roles": {}})
    conn.execute("UPDATE perm_datasets SET proposal = %s::jsonb WHERE id = %s",
                 (json.dumps({"roles": first["roles"], "note": " ".join(notes) or None, "ai": used_ai, "sheets": len(sheets)}), ds_id))
    conn.commit()
    return props


def check_sheets(sheets, cfg):
    """An admin's choice per sheet: [{sheet_no, role, mapping}] -> {sheet_no: (role, mapping)}."""
    by_no = {sh["sheet_no"]: sh for sh in sheets}
    out = {}
    for c in cfg or []:
        try:
            no = int(c.get("sheet_no"))
        except (TypeError, ValueError, AttributeError):
            raise PermError("Each sheet's choice needs its number.")
        sh = by_no.get(no)
        if not sh:
            raise PermError(f"There is no sheet {no + 1}.")
        role = c.get("role")
        if role not in SHEET_ROLE_TEXT:
            raise PermError(f"Sheet \u201c{sh['name']}\u201d: say what it holds.")
        if role != "skip" and not sh["row_count"]:
            raise PermError(f"Sheet \u201c{sh['name']}\u201d has no rows: it can only be left out.")
        m = check_mapping(c.get("mapping") or {}, sh["headers"] or [], role, sh["name"]) if role in ROLESETS else {}
        out[no] = (role, m)
    for no, sh in by_no.items():
        out.setdefault(no, ("skip", {}))
    if not any(r == "permissions" for r, _ in out.values()):
        raise PermError("Choose at least one sheet of permissions (who has access to which folder or drive).")
    return out


def set_mapping(conn, ds_id, user, mapping=None, tag_depth=1, sheets=None):
    """An admin confirms what each sheet holds and which column is which (and how deep folders are
    tagged): the rows are made plain again. `mapping` alone is the one sheet of a CSV."""
    ds = conn.execute("SELECT state, headers FROM perm_datasets WHERE id = %s FOR UPDATE", (ds_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known.")
    if ds["state"] not in ("mapping", "ready", "failed") or not ds["headers"]:
        raise PermError("The file is still being read: wait a moment." if ds["state"] in ("uploaded", "reading", "normalising")
                        else "The file was not read: upload it again.")
    all_sheets = sheets_of(conn, ds_id)
    if sheets is None:
        first = next((sh for sh in all_sheets if sh["row_count"]), None)
        if first is None:
            raise PermError("The file has no rows.")
        sheets = [{"sheet_no": first["sheet_no"], "role": "permissions", "mapping": mapping}]
    chosen = check_sheets(all_sheets, sheets)
    try:
        tag_depth = int(tag_depth)
    except (TypeError, ValueError):
        raise PermError("The tag depth is a number from 0 to 4.")
    if not 0 <= tag_depth <= 4:
        raise PermError("The tag depth is a number from 0 to 4.")
    for no, (role, m) in chosen.items():
        conn.execute("UPDATE perm_sheets SET role = %s, mapping = %s::jsonb WHERE dataset_id = %s AND sheet_no = %s",
                     (role, json.dumps(m), ds_id, no))
    first = next(m for no, (r, m) in sorted(chosen.items()) if r == "permissions")
    conn.execute("""UPDATE perm_datasets SET mapping = %s::jsonb, mapping_by = %s, mapping_at = now(), tag_depth = %s,
                           state = 'normalising', error = NULL, advice = NULL, advice_at = NULL,
                           progress = %s::jsonb, updated_at = now() WHERE id = %s""",
                 (json.dumps(first), user, tag_depth, json.dumps({"step": "normalising", "rows": 0}), ds_id))
    return {str(no): {"role": r, "mapping": m} for no, (r, m) in chosen.items()}


def _with_name(m, headers):
    """A mapping with what the rows need to know about it: where the sheet's name is, and whether the
    inherited column is an "Inherited from" column (empty there means set on the folder itself)."""
    m = dict(m)
    m["_name_at"] = len(headers or [])
    i = m.get("inherited")
    if i is not None and i < len(headers or []) and "from" in _norm_header(headers[i]):
        m["_inh_from"] = True
    return m


def share_roots(rows, mm, sheet_name, ctx):
    """For a sheet with a share column and local paths (D:\\Shares\\Fin\\...): each share's own folder,
    the folder all its paths have in common (when no column lists it)."""
    if mm.get("share") is None or mm.get("share_path") is not None:
        return
    seen = {}
    for cells in rows:
        def get(role):
            i = mm.get(role)
            if i is None:
                return ""
            return clean_cell(sheet_name) if i == mm["_name_at"] else clean_cell(cells[i]) if i < len(cells) else ""
        path, share = clean_path(get("path")), get("share")
        if not share or not re.match(r"^[A-Za-z]:(\\|$)", path):
            continue
        parts = [b.lower() for b in path.split("\\") if b]
        key = (get("server").lower(), share.lower())
        cur = seen.get(key)
        if cur is None:
            seen[key] = parts
        else:
            n = 0
            while n < min(len(cur), len(parts)) and cur[n] == parts[n]:
                n += 1
            seen[key] = cur[:n]
    for key, parts in seen.items():
        if parts:                                            # the same drive: the common folder below it
            ctx.share_roots[key] = parts[1:]


def _drive_rows(conn, ds_id, chosen, sheets, limit=None):
    """The drive information sheets' rows as dicts."""
    out = []
    for sh in sheets:
        role, m = chosen.get(sh["sheet_no"], (None, None))
        if role != "drives":
            continue
        mm = _with_name(m, sh["headers"])
        q = "SELECT rn, cells FROM perm_raw WHERE dataset_id = %s AND sheet_no = %s ORDER BY rn" + (f" LIMIT {int(limit)}" if limit else "")
        for r in conn.execute(q, (ds_id, sh["sheet_no"])).fetchall():
            def get(role):
                i = mm.get(role)
                if i is None:
                    return ""
                return clean_cell(sh["name"]) if i == mm["_name_at"] else clean_cell(r["cells"][i]) if i < len(r["cells"]) else ""
            d = drive_of(get("drive"))
            if not d:
                continue
            tgt = get("target")
            tkey = None
            if tgt.startswith("\\\\") or tgt.startswith("//"):
                srv, shr, parts, _, st = split_path(tgt.replace("/", "\\"))
                tgt = "\\\\" + "\\".join([x for x in [srv, shr] + parts if x])
                tkey = folder_key(srv, shr, parts, len(parts), st)[0]
            else:
                tgt = ""
            out.append({"sheet_no": sh["sheet_no"], "rn": r["rn"], "drive": d, "server": get("server") or None, "target": tgt or None,
                        "target_key": tkey, "label": get("label")[:200] or None, "owner": get("owner")[:200] or None,
                        "application": get("application")[:120] or None, "team": get("team")[:120] or None})
    return out


def _member_rows(conn, ds_id, chosen, sheets, limit=None):
    out = []
    for sh in sheets:
        role, m = chosen.get(sh["sheet_no"], (None, None))
        if role != "members":
            continue
        mm = _with_name(m, sh["headers"])
        q = "SELECT rn, cells FROM perm_raw WHERE dataset_id = %s AND sheet_no = %s ORDER BY rn" + (f" LIMIT {int(limit)}" if limit else "")
        for r in conn.execute(q, (ds_id, sh["sheet_no"])).fetchall():
            def get(role):
                i = mm.get(role)
                if i is None:
                    return ""
                return clean_cell(sh["name"]) if i == mm["_name_at"] else clean_cell(r["cells"][i]) if i < len(r["cells"]) else ""
            g, mem = norm_identity(get("group")), norm_identity(get("member"))
            if not g or not mem:
                continue
            kind, src = identity_kind(mem, get("member_type"))
            out.append({"sheet_no": sh["sheet_no"], "rn": r["rn"], "group_name": g, "group_key": ident_key(g), "member": mem,
                        "member_key": ident_key(mem), "member_kind": kind, "kind_by_type": src == "column",
                        "drive": drive_of(get("drive")) if get("drive") else None,
                        "department": get("department")[:120] or None})
    return out


def _people_rows(conn, ds_id, chosen, sheets, members=()):
    """Every person with a department: from the people sheets, and from members sheets with a department
    column. One row per person; when rows disagree, the department most rows give (the others kept)."""
    rows = []
    for sh in sheets:
        role, m = chosen.get(sh["sheet_no"], (None, None))
        if role != "people":
            continue
        mm = _with_name(m, sh["headers"])
        for r in conn.execute("SELECT cells FROM perm_raw WHERE dataset_id = %s AND sheet_no = %s ORDER BY rn",
                              (ds_id, sh["sheet_no"])).fetchall():
            def get(role):
                i = mm.get(role)
                if i is None:
                    return ""
                return clean_cell(sh["name"]) if i == mm["_name_at"] else clean_cell(r["cells"][i]) if i < len(r["cells"]) else ""
            person = norm_identity(get("person"))
            if not person:
                continue
            rows.append({"person": person, "department": get("department")[:120] or None,
                         "display_name": get("display_name")[:120] or None, "title": get("title")[:120] or None,
                         "manager": norm_identity(get("manager"))[:120] or None, "location": get("location")[:120] or None,
                         "email": get("email")[:200] or None})
    for m in members:
        if m.get("department") and m["member_kind"] not in ("group",):
            rows.append({"person": m["member"], "department": m["department"], "display_name": None, "title": None,
                         "manager": None, "location": None, "email": None})
    people = {}
    for r in rows:
        keys = [ident_key(r["person"])]
        if r["email"] and "@" in r["email"]:
            keys.append(ident_key(r["email"]))                    # jwatson@corp.com is CORP\jwatson
        for k in dict.fromkeys(keys):
            if not k:
                continue
            p = people.setdefault(k, {"person": r["person"], "depts": {}, "sources": 0})
            p["sources"] += 1
            if r["department"]:
                d = r["department"].strip()
                p["depts"][d] = p["depts"].get(d, 0) + 1
            for f in ("display_name", "title", "manager", "location", "email"):
                if r[f] and not p.get(f):
                    p[f] = r[f]
    out = []
    for k, p in people.items():
        depts = sorted(p["depts"].items(), key=lambda x: (-x[1], x[0].lower()))
        # the same department written two ways ("IT", "it ") is one
        merged = {}
        for d, n in depts:
            merged.setdefault(d.lower(), [d, 0])[1] += n
        best = sorted(merged.values(), key=lambda x: -x[1])
        out.append({"person_key": k, "person": p["person"], "department": best[0][0] if best else None,
                    "conflicts": ", ".join(d for d, _ in best[1:])[:300] or None, "sources": p["sources"],
                    "display_name": p.get("display_name"), "title": p.get("title"), "manager": p.get("manager"),
                    "location": p.get("location"), "email": p.get("email")})
    return out


def build_context(drives, members, people=()):
    ctx = Context()
    for d in drives:
        if d["target"]:
            ctx.targets.setdefault(((d["server"] or "").lower(), d["drive"]), set()).add(d["target"])
    for m in members:
        ctx.groups.add(m["group_key"])
    for m in members:
        if m["kind_by_type"]:
            ctx.member_kind[m["member_key"]] = m["member_kind"]
    for p in people:                      # listed in a people sheet with a department: a person
        if p["department"] and p["person_key"] not in ctx.groups:
            ctx.member_kind.setdefault(p["person_key"], "user")
    return ctx


def open_groups(members, cap=200000):
    """Every group's accounts, nested groups opened up: [(group_key, member, member_key, kind, via)].
    A member that is itself a listed group is opened (cycles are stopped); what is left are the
    accounts behind the group."""
    direct = {}
    for m in members:
        direct.setdefault(m["group_key"], {}).setdefault(m["member_key"], m)
    out = []
    for g in direct:
        seen_groups, seen = {g}, set()
        stack = [(m, []) for m in direct[g].values()]
        while stack and len(seen) < cap:
            m, via = stack.pop()
            k = m["member_key"]
            if k in direct and k not in seen_groups:
                seen_groups.add(k)
                stack.extend((x, via + [m["member"]]) for x in direct[k].values())
                continue
            if k in direct or k in seen:
                continue
            seen.add(k)
            kind = m["member_kind"]
            if kind == "unknown" and not m["kind_by_type"]:
                kind = "unknown"
            out.append((g, m["member"], k, kind, " > ".join(via)[:300] or None))
    return out


ENTRY_COLS = ("dataset_id", "rn", "sheet_no", "server", "share", "path", "path_raw", "folder_key", "depth", "identity",
              "identity_key", "identity_kind", "kind_source", "rights_raw", "level", "allow", "inherited", "owner")


def depth_preview(conn, ds_id, mapping=None, tag_depth=1, sheets=None):
    """The folders a depth gives, from the first rows (before anything is saved), with the drive
    letters resolved as the drive sheets say."""
    ds = conn.execute("SELECT headers FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    if not ds or not ds["headers"]:
        raise PermError("The file is still being read.")
    all_sheets = sheets_of(conn, ds_id)
    if sheets is None:
        first = next(sh for sh in all_sheets if sh["row_count"])
        sheets = [{"sheet_no": first["sheet_no"], "role": "permissions", "mapping": mapping}]
    chosen = check_sheets(all_sheets, sheets)
    ctx = build_context(_drive_rows(conn, ds_id, chosen, all_sheets, 5000), _member_rows(conn, ds_id, chosen, all_sheets, 20000))
    rows = []
    for sh in all_sheets:
        role, m = chosen[sh["sheet_no"]]
        if role == "permissions":
            mm = _with_name(m, sh["headers"])
            for r in conn.execute("SELECT cells FROM perm_raw WHERE dataset_id = %s AND sheet_no = %s ORDER BY rn LIMIT 5000",
                                  (ds_id, sh["sheet_no"])).fetchall():
                rows.append((r["cells"], mm, sh["name"]))
    for name in {n for _, _, n in rows}:
        sel = [(c, mm) for c, mm, n in rows if n == name]
        if sel and sel[0][1].get("share") is not None:
            share_roots((c for c, _ in sel), sel[0][1], name, ctx)
    out = []
    for d in range(5):
        seen = {}
        ctx.resolved = 0
        for cells, mm, name in rows:
            e = entry_from(cells, mm, d, ctx, name)
            if e:
                seen[e["folder_key"]] = e["folder_label"]
        out.append({"depth": d, "folders": len(seen), "examples": sorted(seen.values())[:6]})
    return {"rows_looked_at": len(rows), "depths": out, "chosen": int(tag_depth) if str(tag_depth).isdigit() else 1,
            "drives_resolved": ctx.resolved, "drives_ambiguous": sorted(ctx.ambiguous)}


def normalise(conn, ds_id, stop=lambda: False):
    ds = conn.execute("SELECT tag_depth, row_count FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    depth = ds["tag_depth"]
    all_sheets = sheets_of(conn, ds_id)
    chosen = {sh["sheet_no"]: (sh["role"] or "skip", {k: int(v) for k, v in (sh["mapping"] or {}).items()}) for sh in all_sheets}
    if not any(r == "permissions" for r, _ in chosen.values()):
        raise PermError("No sheet of permissions was chosen: confirm the sheets again.")
    conn.execute("UPDATE perm_datasets SET state = 'normalising', error = NULL WHERE id = %s", (ds_id,))
    for t in ("perm_entries", "perm_folders", "perm_drives", "perm_members", "perm_access"):
        conn.execute(f"DELETE FROM {t} WHERE dataset_id = %s", (ds_id,))
    conn.commit()
    # 1. the drive information and the group members first: the permission rows use them
    drives = _drive_rows(conn, ds_id, chosen, all_sheets)
    members = _member_rows(conn, ds_id, chosen, all_sheets)
    bulk_insert(conn, "perm_drives", ("dataset_id", "sheet_no", "rn", "drive", "server", "target", "target_key", "label", "owner",
                                      "application", "team"),
                [(ds_id, d["sheet_no"], d["rn"], d["drive"], d["server"], d["target"], d["target_key"], d["label"], d["owner"],
                  d["application"], d["team"]) for d in drives])
    bulk_insert(conn, "perm_members", ("dataset_id", "sheet_no", "rn", "group_name", "group_key", "member", "member_key",
                                       "member_kind", "drive"),
                [(ds_id, m["sheet_no"], m["rn"], m["group_name"], m["group_key"], m["member"], m["member_key"], m["member_kind"],
                  m["drive"]) for m in members])
    opened = open_groups(members)
    conn.execute("DELETE FROM perm_people WHERE dataset_id = %s", (ds_id,))
    people = _people_rows(conn, ds_id, chosen, all_sheets, members)
    bulk_insert(conn, "perm_people", ("dataset_id", "person_key", "person", "display_name", "department", "title", "manager",
                                      "location", "email", "sources", "conflicts"),
                [(ds_id, p["person_key"], p["person"], p["display_name"], p["department"], p["title"], p["manager"], p["location"],
                  p["email"], p["sources"], p["conflicts"]) for p in people])
    conn.execute("""UPDATE perm_access a SET member_kind = 'user' FROM perm_people p
                     WHERE a.dataset_id = %s AND p.dataset_id = a.dataset_id AND p.person_key = a.member_key
                       AND a.member_kind = 'unknown' AND p.department IS NOT NULL""", (ds_id,))
    bulk_insert(conn, "perm_access", ("dataset_id", "group_key", "member", "member_key", "member_kind", "via"),
                [(ds_id,) + x for x in opened])
    conn.commit()
    ctx = build_context(drives, members, people)
    # 2. the permission rows, sheet by sheet
    labels, file_tags, skipped = {}, {}, 0
    total = sum(sh["row_count"] for sh in all_sheets if chosen[sh["sheet_no"]][0] == "permissions")
    done = 0
    for sh in all_sheets:
        role, m = chosen[sh["sheet_no"]]
        if role != "permissions":
            continue
        mm = _with_name(m, sh["headers"])
        if mm.get("share") is not None:
            share_roots((r["cells"] for r in conn.execute("SELECT cells FROM perm_raw WHERE dataset_id = %s AND sheet_no = %s",
                                                           (ds_id, sh["sheet_no"])).fetchall()), mm, sh["name"], ctx)
        last = 0
        while True:
            rows = conn.execute("""SELECT rn, cells FROM perm_raw WHERE dataset_id = %s AND sheet_no = %s AND rn > %s
                                    ORDER BY rn LIMIT 20000""", (ds_id, sh["sheet_no"], last)).fetchall()
            if not rows:
                break
            out = []
            for r in rows:
                last = r["rn"]
                e = entry_from(r["cells"], mm, depth, ctx, sh["name"])
                if not e:
                    skipped += 1
                    continue
                labels.setdefault(e["folder_key"], e["folder_label"])
                if e["application"] or e["team"]:
                    t = file_tags.setdefault(e["folder_key"], {})
                    t[(e["application"], e["team"])] = t.get((e["application"], e["team"]), 0) + 1
                out.append((ds_id, r["rn"], sh["sheet_no"], e["server"], e["share"], e["path"], e["path_raw"], e["folder_key"],
                            e["depth"], e["identity"], e["identity_key"], e["identity_kind"], e["kind_source"], e["rights_raw"],
                            e["level"], e["allow"], e["inherited"], e["owner"]))
            bulk_insert(conn, "perm_entries", ENTRY_COLS, out)
            conn.commit()
            done += len(rows)
            _progress(conn, ds_id, step="normalising", rows=done, total=total, sheet=sh["name"])
            if stop():
                raise PermError("Stopped: the worker was restarted. Confirm the columns again to go on.")
    if not labels:
        raise PermError("No row has both a path and an account with these columns: check the columns chosen.")
    conn.execute("""INSERT INTO perm_folders (dataset_id, folder_key, label, server, entries, paths, identities)
                    SELECT dataset_id, folder_key, '', min(server), count(*), count(DISTINCT lower(path)), count(DISTINCT lower(identity))
                      FROM perm_entries WHERE dataset_id = %s GROUP BY dataset_id, folder_key""", (ds_id,))
    for k, lab in labels.items():
        conn.execute("UPDATE perm_folders SET label = %s WHERE dataset_id = %s AND folder_key = %s", (lab, ds_id, k))
    # Application / team in the file itself (permission rows, or the drive sheet): suggestions an admin confirms
    for k, counts in file_tags.items():
        (app, team), n = max(counts.items(), key=lambda x: x[1])
        _file_tag(conn, k, labels.get(k, k), app, team, f"from the file's own columns ({n} rows say so)")
    for d in drives:
        if d["target_key"] and (d["application"] or d["team"]):
            _file_tag(conn, d["target_key"], d["target"], d["application"], d["team"],
                      f"from the drive sheet: drive {d['drive']}" + (f" \u201c{d['label']}\u201d" if d["label"] else ""))
    resolve_tags(conn, ds_id)
    links = {"drives": len(drives), "drive_targets": len({d["target"] for d in drives if d["target"]}),
             "paths_resolved": ctx.resolved, "ambiguous_drives": sorted(ctx.ambiguous),
             "groups_listed": len(ctx.groups), "member_rows": len(members), "accounts_behind": len({x[2] for x in opened}),
             "people_listed": len(people), "departments": len({p["department"].lower() for p in people if p["department"]}),
             "department_conflicts": sum(1 for p in people if p["conflicts"]),
             "kinds_from_members": conn.execute("SELECT count(*) AS n FROM perm_entries WHERE dataset_id = %s AND kind_source = 'members'",
                                                (ds_id,)).fetchone()["n"]}
    conn.execute("""UPDATE perm_datasets SET state = 'ready', skipped = %s, progress = NULL, profile = %s::jsonb, links = %s::jsonb
                     WHERE id = %s""",
                 (skipped + sum(sh["skipped"] for sh in all_sheets), json.dumps(profile(conn, ds_id)), json.dumps(links), ds_id))
    conn.commit()


def _file_tag(conn, key, label, app, team, reason):
    conn.execute("""INSERT INTO perm_tags (key_l, label, application, team, state, confidence, reason, suggested_by, suggested_at)
                    VALUES (%s, %s, %s, %s, 'suggested', 90, %s, 'file', now())
                    ON CONFLICT (key_l) DO UPDATE SET application = EXCLUDED.application, team = EXCLUDED.team,
                        confidence = 90, reason = EXCLUDED.reason, suggested_by = 'file', suggested_at = now()
                    WHERE perm_tags.state = 'suggested'""", (key, label or key, app, team, reason))


def parents(key):
    """A folder key and every parent of it that can carry a tag, longest first."""
    out = [key]
    k = key
    while True:
        cut = max(k.rfind("\\"), k.rfind("/"))
        if cut <= 2:
            break
        k = k[:cut]
        if k.endswith(":"):
            out.append(k + "\\")                     # a drive's root: "srv d:\\"
            break
        if k in ("\\", ""):
            break
        out.append(k)
    return out


def resolve_tags(conn, ds_id=None):
    """Each folder's tag in force: its own, else its nearest tagged parent; confirmed before suggested.
    For one upload, or (ds_id None) every upload (after an admin decides)."""
    tags = {r["key_l"]: r for r in conn.execute("""SELECT key_l, application, team, state FROM perm_tags
                                                     WHERE state <> 'rejected' AND (application IS NOT NULL OR team IS NOT NULL)""")}
    where, args = ("WHERE dataset_id = %s", (ds_id,)) if ds_id else ("", ())
    folders = conn.execute("SELECT dataset_id, folder_key, tag_key, application, team, tag_state FROM perm_folders " + where, args).fetchall()
    for f in folders:
        best = None
        for k in parents(f["folder_key"]):
            t = tags.get(k)
            if t and t["state"] == "confirmed":
                best = (k, t)
                break
            if t and best is None:
                best = (k, t)
        now = (best[0], best[1]["application"], best[1]["team"], best[1]["state"]) if best else (None, None, None, None)
        if now == (f["tag_key"], f["application"], f["team"], f["tag_state"]):
            continue                                       # unchanged: nothing written
        if best:
            k, t = best
            conn.execute("""UPDATE perm_folders SET tag_key = %s, application = %s, team = %s, tag_state = %s
                             WHERE dataset_id = %s AND folder_key = %s""",
                         (k, t["application"], t["team"], t["state"], f["dataset_id"], f["folder_key"]))
        else:
            conn.execute("""UPDATE perm_folders SET tag_key = NULL, application = NULL, team = NULL, tag_state = NULL
                             WHERE dataset_id = %s AND folder_key = %s AND tag_key IS NOT NULL""",
                         (f["dataset_id"], f["folder_key"]))
    conn.commit()


def profile(conn, ds_id):
    """What the file holds, counted: the facts AI-01 recommends reports from."""
    r = conn.execute("""SELECT count(*) AS entries, count(DISTINCT lower(path)) AS paths, count(DISTINCT lower(identity)) AS identities,
                               count(DISTINCT lower(server)) AS servers, count(DISTINCT lower(coalesce(server, '') || '\\' || coalesce(share, ''))) AS shares,
                               count(*) FILTER (WHERE identity_kind = 'broad' AND allow AND level IN ('write', 'modify', 'full')) AS broad_write,
                               count(*) FILTER (WHERE identity_kind = 'broad' AND allow) AS broad_any,
                               count(*) FILTER (WHERE identity_kind = 'user' AND allow AND inherited IS FALSE) AS explicit_users,
                               count(*) FILTER (WHERE identity_kind = 'user') AS users,
                               count(*) FILTER (WHERE identity_kind = 'unknown') AS kind_unknown,
                               count(*) FILTER (WHERE identity_kind = 'orphan') AS orphans,
                               count(*) FILTER (WHERE NOT allow) AS denies,
                               count(*) FILTER (WHERE level = 'full' AND allow AND identity_kind NOT IN ('admin', 'system')) AS full_nonadmin,
                               count(*) FILTER (WHERE inherited IS NULL) AS inherit_unknown,
                               count(*) FILTER (WHERE level = 'special') AS special
                          FROM perm_entries WHERE dataset_id = %s""", (ds_id,)).fetchone()
    x = conn.execute("""SELECT (SELECT count(DISTINCT group_key) FROM perm_access WHERE dataset_id = %s) AS groups_opened,
                               (SELECT count(DISTINCT member_key) FROM perm_access WHERE dataset_id = %s) AS accounts_behind,
                               (SELECT count(*) FROM perm_drives WHERE dataset_id = %s) AS drives,
                               (SELECT count(*) FROM perm_people WHERE dataset_id = %s AND department IS NOT NULL) AS people_listed,
                               (SELECT count(DISTINCT lower(department)) FROM perm_people WHERE dataset_id = %s) AS departments""",
                     (ds_id, ds_id, ds_id, ds_id, ds_id)).fetchone()
    return dict(r, **x, **folder_counts(conn, ds_id))


def folder_counts(conn, ds_id):
    """The tag counts, always as they are now (tags change after the rows are read)."""
    return conn.execute("""SELECT count(*) AS folders, count(*) FILTER (WHERE tag_state = 'confirmed') AS tagged,
                               count(*) FILTER (WHERE tag_state = 'suggested') AS suggested,
                               count(DISTINCT application) FILTER (WHERE tag_state = 'confirmed') AS applications,
                               count(DISTINCT team) FILTER (WHERE tag_state = 'confirmed') AS teams
                          FROM perm_folders WHERE dataset_id = %s""", (ds_id,)).fetchone()


# ---- tagging with AI-01 (worker) ------------------------------------------------------------------------

TAG_BATCH = 12


def folder_hints(conn, ds_id, key):
    """What AI-01 is shown about one folder: groups on it with their level, and sub-folder names."""
    groups = conn.execute(f"""SELECT identity, max({rank_sql('level')}) AS lv, count(*) AS n
                               FROM perm_entries WHERE dataset_id = %s AND folder_key = %s
                                AND identity_kind NOT IN ('system', 'admin', 'orphan')
                              GROUP BY identity ORDER BY count(*) DESC LIMIT 10""", (ds_id, key)).fetchall()
    subs = conn.execute("""SELECT DISTINCT path FROM perm_entries WHERE dataset_id = %s AND folder_key = %s LIMIT 400""",
                        (ds_id, key)).fetchall()
    names = []
    for s in subs:
        p = s["path"]
        rest = p[len(key):] if p.lower().startswith(key) else p
        bit = [b for b in re.split(r"[\\/]", rest) if b]
        if bit and bit[0] not in names:
            names.append(bit[0][:40])
        if len(names) >= 8:
            break
    drives = conn.execute("""SELECT drive, label, owner, application, team FROM perm_drives
                              WHERE dataset_id = %s AND target_key IS NOT NULL
                                AND (%s = target_key OR left(%s, length(target_key) + 1) = target_key || chr(92)
                                     OR left(target_key, length(%s) + 1) = %s || chr(92))
                              LIMIT 3""", (ds_id, key, key, key, key)).fetchall()
    out = {"groups": [{"name": g["identity"][:80], "level": LEVELS[g["lv"]]} for g in groups], "subfolders": names}
    if drives:
        out["drive_information"] = [{k: (v or "")[:80] for k, v in d.items() if v} for d in drives]
    depts = conn.execute("""SELECT p.department, count(DISTINCT p.person_key) AS people
                              FROM perm_entries e
                              LEFT JOIN perm_access a ON a.dataset_id = e.dataset_id AND a.group_key = e.identity_key
                              JOIN perm_people p ON p.dataset_id = e.dataset_id AND p.person_key = coalesce(a.member_key, e.identity_key)
                             WHERE e.dataset_id = %s AND e.folder_key = %s AND e.allow AND e.level IN ('write', 'modify', 'full')
                               AND e.identity_kind NOT IN ('admin', 'system', 'broad') AND p.department IS NOT NULL
                             GROUP BY p.department ORDER BY count(DISTINCT p.person_key) DESC LIMIT 4""", (ds_id, key)).fetchall()
    if depts:
        out["departments_of_people_who_can_change_it"] = [{"department": d["department"][:60], "people": d["people"]} for d in depts]
    return out


TAG_SYSTEM = """You tag file shares with the business application and the owning team they belong to, for an access review.
You are given folders (with the groups that have access and some sub-folder names) and examples an administrator confirmed.
For each folder answer: the application (a short name, e.g. "SAP Finance", "HR Records"), the owning team (e.g. "Finance IT",
"HR Systems"), a confidence from 0 to 100, and the reason in a few words from the evidence given.
When the departments of the people who can change a folder are given, the department most of them are in is
strong evidence for the owning team (say so in the reason, with the numbers given).
Reuse the exact application and team names of the confirmed examples when they fit. When the evidence does not show the
application, answer an empty application with a low confidence: never guess from nothing. Answer only with JSON."""

TAG_SCHEMA = {"type": "object", "properties": {"items": {"type": "array", "items": {"type": "object", "properties": {
    "folder": {"type": "string"}, "application": {"type": "string"}, "team": {"type": "string"},
    "confidence": {"type": "integer"}, "reason": {"type": "string"}},
    "required": ["folder", "application", "team", "confidence", "reason"]}}}, "required": ["items"]}


def tag_messages(folders, examples):
    data = {"confirmed_examples": examples[:15], "folders": folders}
    return [{"role": "system", "content": TAG_SYSTEM}, {"role": "user", "content": json.dumps(data)[:12000]}]


def clean_tag_text(v, limit=80):
    t = re.sub(r"[\x00-\x1f<>]", " ", str(v or "")).strip()
    return re.sub(r"\s+", " ", t)[:limit]


def suggest_batch(conn, ds_id, ai, by="AI-01"):
    """One batch of folders without a tag (biggest first) -> AI-01's suggestions. Returns how many."""
    rows = conn.execute("""SELECT f.folder_key, f.label, f.entries FROM perm_folders f
                            WHERE f.dataset_id = %s AND f.tag_key IS NULL
                              AND NOT EXISTS (SELECT 1 FROM perm_tags t WHERE t.key_l = f.folder_key)
                            ORDER BY f.entries DESC, f.folder_key LIMIT %s""", (ds_id, TAG_BATCH)).fetchall()
    if not rows:
        return 0
    examples = [{"folder": r["label"], "application": r["application"], "team": r["team"]} for r in conn.execute(
        """SELECT label, application, team FROM perm_tags WHERE state = 'confirmed' ORDER BY decided_at DESC LIMIT 15""")]
    folders = [dict({"folder": r["label"]}, **folder_hints(conn, ds_id, r["folder_key"])) for r in rows]
    conn.commit()                                          # nothing held open while AI-01 thinks
    out = ai(tag_messages(folders, examples), TAG_SCHEMA)
    by_label = {r["label"].lower(): r for r in rows}
    n = 0
    for it in (out or {}).get("items") or []:
        r = by_label.get(str(it.get("folder") or "").strip().lower())
        if not r:
            continue                                       # a folder AI-01 made up, or renamed: ignored
        app, team = clean_tag_text(it.get("application")), clean_tag_text(it.get("team"))
        try:
            conf = max(0, min(100, int(it.get("confidence") or 0)))
        except (TypeError, ValueError):
            conf = 0
        if not app and not team:
            conf = min(conf, 20)
        conn.execute("""INSERT INTO perm_tags (key_l, label, application, team, state, confidence, reason, suggested_by, suggested_at)
                        VALUES (%s, %s, %s, %s, 'suggested', %s, %s, %s, now()) ON CONFLICT (key_l) DO NOTHING""",
                     (r["folder_key"], r["label"], app or None, team or None, conf, clean_tag_text(it.get("reason"), 200) or None, by))
        n += 1
    # folders AI-01 skipped get an empty suggestion, so the next batch moves on
    for r in rows:
        conn.execute("""INSERT INTO perm_tags (key_l, label, state, confidence, reason, suggested_by, suggested_at)
                        VALUES (%s, %s, 'suggested', 0, 'AI-01 gave no answer for it', %s, now()) ON CONFLICT (key_l) DO NOTHING""",
                     (r["folder_key"], r["label"], by))
    resolve_tags(conn, ds_id)
    return len(rows)


def decide(conn, user, items):
    """An admin's decisions on tags: confirm (as proposed or edited), or reject. items:
    [{key, decision: confirm|reject|clear, application, team}]"""
    done = 0
    for it in items[:2000]:
        key = str(it.get("key") or "").strip().lower()[:600]
        if not key:
            continue
        d = it.get("decision")
        app, team = clean_tag_text(it.get("application")) or None, clean_tag_text(it.get("team")) or None
        if d == "confirm":
            if not app and not team:
                raise PermError(f"{key}: give the application or the team before confirming.")
            label = clean_tag_text(it.get("label"), 600) or key
            conn.execute("""INSERT INTO perm_tags (key_l, label, application, team, state, decided_by, decided_at)
                            VALUES (%s, %s, %s, %s, 'confirmed', %s, now())
                            ON CONFLICT (key_l) DO UPDATE SET application = EXCLUDED.application, team = EXCLUDED.team,
                                state = 'confirmed', decided_by = EXCLUDED.decided_by, decided_at = now()""",
                         (key, label, app, team, user))
        elif d == "reject":
            conn.execute("""UPDATE perm_tags SET state = 'rejected', decided_by = %s, decided_at = now() WHERE key_l = %s""",
                         (user, key))
        elif d == "clear":
            conn.execute("DELETE FROM perm_tags WHERE key_l = %s", (key,))
        else:
            raise PermError("Each decision is confirm, reject or clear.")
        done += 1
    resolve_tags(conn)
    return done


# ---- 5. reports ---------------------------------------------------------------------------------------------

KINDS = {
    "risk": ("Risky access overview", "Every kind of risky access in one view: open to everyone, people given rights "
             "directly, orphaned accounts, full control outside the admin groups, deny entries."),
    "by_app": ("Access by application and owning team", "For each application and team: their folders, who has access, "
               "and what is risky there."),
    "team_review": ("Access review pack per owning team", "What each owning team must confirm: their folders and every "
                    "account with write access or more, to keep or remove."),
    "broad": ("Folders open to everyone", "Folders where Everyone, Authenticated Users, Domain Users or similar broad "
              "groups can change or read data."),
    "explicit_users": ("People given rights directly", "Accounts of people added to folders directly instead of through "
                       "a group: hard to review and to remove when they leave."),
    "orphans": ("Orphaned accounts", "Deleted users or groups still listed on folders (shown as a SID): clean-up candidates."),
    "full_control": ("Full control outside the admin groups", "Accounts other than the admin and system accounts that can "
                     "change permissions and take ownership."),
    "untagged": ("Folders without an application or owner", "What still needs an application and an owning team before "
                 "it can be reviewed by its owner."),
    "by_department": ("Access by department (people grouped)", "Each department, its people, and every share and folder "
                      "each person reaches, directly or through groups: one line per person and folder, with every way in. "
                      "Shows who reaches folders owned by another team."),
    "effective": ("Who really has access (groups opened up)", "Every account that can change data, given rights directly or "
                  "through the groups it is in (nested groups opened up, from the members sheet), per folder and application."),
    "by_server": ("Summary by server and share", "For each server and share: how many folders and entries, and what is risky."),
}
CATS = {   # each finding's kind; an entry can be in more than one
    "broad_write": ("Open to everyone (change)", "e.identity_kind = 'broad' AND e.allow AND e.level = ANY(%(risky)s)"),
    "broad_read": ("Open to everyone (read)", "e.identity_kind = 'broad' AND e.allow AND NOT (e.level = ANY(%(risky)s)) AND e.level <> 'none'"),
    "explicit_user": ("Person given rights directly", "e.identity_kind = 'user' AND e.allow AND e.inherited IS FALSE"),
    "orphan": ("Orphaned account", "e.identity_kind = 'orphan'"),
    "full_nonadmin": ("Full control outside admins", "e.allow AND e.level = 'full' AND e.identity_kind NOT IN ('admin', 'system')"),
    "deny": ("Deny entry", "NOT e.allow"),
    "has_access": ("Has access", "e.allow AND e.level <> 'none' AND e.identity_kind NOT IN ('admin', 'system')"),
    "can_change": ("Can change data", "e.allow AND e.level = ANY(%(risky)s) AND e.identity_kind NOT IN ('admin', 'system')"),
}
KIND_CATS = {"risk": ["broad_write", "explicit_user", "orphan", "full_nonadmin", "deny"], "broad": ["broad_write", "broad_read"],
             "explicit_users": ["explicit_user"], "orphans": ["orphan"], "full_control": ["full_nonadmin"],
             "by_app": ["broad_write", "explicit_user", "orphan", "full_nonadmin"], "team_review": ["broad_write", "explicit_user", "orphan", "full_nonadmin"],
             "by_server": ["broad_write", "explicit_user", "orphan", "full_nonadmin"], "untagged": ["broad_write", "explicit_user", "orphan", "full_nonadmin"],
             "effective": ["can_change"], "by_department": ["has_access"]}
KIND_TEXT = {"user": "Person", "group": "Group", "computer": "Computer", "broad": "Everyone-type group", "admin": "Admin group",
             "system": "System account", "orphan": "Orphaned (SID)", "unknown": "Not stated in the file"}
TOP = 7


def clean_spec(conn, ds_id, spec):
    """An admin's choices, checked. Returns the clean spec."""
    if not isinstance(spec, dict):
        raise PermError("Say which report.")
    kind = spec.get("kind")
    if kind not in KINDS:
        raise PermError("Choose one of the reports.")
    sc = spec.get("scope") or {}
    op = spec.get("options") or {}
    def strs(v, n=500):
        return [clean_tag_text(x, 200) for x in (v or []) if clean_tag_text(x, 200)][:n] if isinstance(v, list) else []
    risky = [lv for lv in (op.get("risky_levels") or list(WRITE_LEVELS)) if lv in LEVELS]
    if not risky:
        raise PermError("Choose at least one access level that counts as risky.")
    tags = op.get("tags") if op.get("tags") in ("confirmed", "with_suggested") else "confirmed"
    title = clean_tag_text(spec.get("title"), 120) or KINDS[kind][0]
    return {"kind": kind, "title": title,
            "scope": {"servers": strs(sc.get("servers")), "applications": strs(sc.get("applications")), "teams": strs(sc.get("teams")),
                      "untagged": bool(sc.get("untagged", True))},
            "options": {"risky_levels": risky, "include_inherited": bool(op.get("include_inherited", True)), "tags": tags}}


def _base(spec):
    """The FROM and WHERE every figure of a report shares, and its parameters."""
    sc, op = spec["scope"], spec["options"]
    tagok = "f.tag_state = 'confirmed'" if op["tags"] == "confirmed" else "f.tag_state IS NOT NULL"
    app = f"CASE WHEN {tagok} THEN f.application END"
    team = f"CASE WHEN {tagok} THEN f.team END"
    where = ["e.dataset_id = %(ds)s"]
    if not op["include_inherited"]:
        where.append("e.inherited IS NOT TRUE")
    if sc["servers"]:
        where.append("lower(coalesce(e.server, '')) = ANY(%(servers)s)")
    tag_or = []
    if sc["applications"]:
        tag_or.append(f"{app} = ANY(%(apps)s)")
    if sc["teams"]:
        tag_or.append(f"{team} = ANY(%(teams)s)")
    if tag_or:
        if sc["untagged"]:
            tag_or.append(f"{app} IS NULL AND {team} IS NULL")
        where.append("(" + " OR ".join(tag_or) + ")")
    elif not sc["untagged"]:
        where.append(f"({app} IS NOT NULL OR {team} IS NOT NULL)")
    frm = " FROM perm_entries e JOIN perm_folders f ON f.dataset_id = e.dataset_id AND f.folder_key = e.folder_key "
    args = {"servers": [x.lower() for x in sc["servers"]], "apps": sc["applications"], "teams": sc["teams"],
            "risky": op["risky_levels"]}
    return frm + " WHERE " + " AND ".join(where), args, app, team


# a share as people write it: \\\\server\\share, "server D:\\" for a local drive, server:/srv for Linux
SHARE_SQL = ("CASE WHEN e.share ~ '^[A-Za-z]:$' THEN coalesce(e.server || ' ', '') || e.share || chr(92) "
             "WHEN e.share LIKE '/%%' THEN coalesce(e.server || ':', '') || e.share "
             "WHEN e.server IS NULL AND e.share IS NULL THEN '(no share)' "
             "ELSE chr(92) || chr(92) || coalesce(e.server, '') || chr(92) || coalesce(e.share, '') END")


def people_cte(base, app, cond, team="NULL::text"):
    """SQL (a WITH clause ending in 'allx'): every account reaching the entries that match cond, directly or
    through a group the members sheet lists (nested groups opened up). Everyone-type groups are not opened:
    they mean everyone."""
    return f"""WITH ent AS (SELECT e.identity, e.identity_key, e.identity_kind, e.folder_key, f.label AS folder,
                                {app} AS application, {team} AS team, {rank_sql('e.level')} AS lv, {SHARE_SQL} AS share {base} AND {cond}),
     via AS (SELECT a.member AS account, a.member_key AS key, a.member_kind AS kind, ent.identity AS through, ent.folder_key,
                    ent.folder, ent.application, ent.team, ent.lv, ent.share
               FROM ent JOIN perm_access a ON a.dataset_id = %(ds)s AND a.group_key = ent.identity_key
              WHERE ent.identity_kind <> 'broad'),
     direct AS (SELECT ent.identity AS account, ent.identity_key AS key, ent.identity_kind AS kind, NULL::text AS through,
                       ent.folder_key, ent.folder, ent.application, ent.team, ent.lv, ent.share
                  FROM ent WHERE ent.identity_kind = 'broad' OR NOT EXISTS
                       (SELECT 1 FROM perm_access a WHERE a.dataset_id = %(ds)s AND a.group_key = ent.identity_key)),
     allx AS (SELECT * FROM via UNION ALL SELECT * FROM direct)"""


NO_DEPT = "(department not in the file)"
PERSON_KINDS = "('user', 'unknown', 'computer')"
DEPT_TOP, DEPT_PEOPLE, PERSON_FOLDERS = 40, 150, 80


def person_info(conn, ds_id, keys):
    """Department, full name and title of people, by their short key."""
    out = {}
    for r in conn.execute("""SELECT person_key, department, display_name, title, conflicts FROM perm_people
                              WHERE dataset_id = %s AND person_key = ANY(%s)""", (ds_id, list(keys))).fetchall():
        out[r["person_key"]] = {"department": r["department"], "display_name": r["display_name"], "title": r["title"],
                                "dept_conflicts": r["conflicts"]}
    return out


def department_report(conn, ds_id, base, app, team, anycat, args, spec):
    """Department -> its people -> the shares and folders each reaches. One line per person and folder:
    the highest level and every way in (directly, through which groups). Counted by PostgreSQL."""
    risky = [RANK[x] for x in spec["options"]["risky_levels"]]
    cte = people_cte(base, app, anycat, team) + f""",
     px AS (SELECT allx.*, coalesce(p.department, %(nodept)s) AS dept FROM allx
              LEFT JOIN perm_people p ON p.dataset_id = %(ds)s AND p.person_key = allx.key
             WHERE p.person_key IS NOT NULL OR allx.kind IN {PERSON_KINDS})"""
    a = dict(args, nodept=NO_DEPT, risky_ranks=risky)
    q = lambda sql, x=None: conn.execute(cte + sql, x or a).fetchall()      # noqa: E731
    depts = q("""SELECT dept AS name, count(DISTINCT key) AS people, count(DISTINCT share) AS shares,
                        count(DISTINCT folder_key) AS folders,
                        count(DISTINCT key) FILTER (WHERE lv = ANY(%(risky_ranks)s)) AS can_change,
                        count(DISTINCT key) FILTER (WHERE lv = ANY(%(risky_ranks)s) AND team IS NOT NULL
                                                    AND lower(team) <> lower(dept) AND dept <> %(nodept)s) AS outside_people
                   FROM px GROUP BY dept ORDER BY count(DISTINCT key) DESC, dept""")
    per = q("""SELECT dept, key, min(account) AS account, min(kind) AS kind, count(DISTINCT share) AS shares,
                      count(DISTINCT folder_key) AS folders, max(lv) AS worst
                 FROM px GROUP BY dept, key ORDER BY dept, count(DISTINCT folder_key) DESC, key""")
    chosen, by_dept = [], {}
    for r in per:
        lst = by_dept.setdefault(r["dept"], [])
        if len(lst) < DEPT_PEOPLE:
            lst.append(r)
    top = [d["name"] for d in depts[:DEPT_TOP]]
    for d in top:
        chosen += [r["key"] for r in by_dept.get(d, [])]
    rows = q("""SELECT dept, key, share, folder, folder_key, min(application) AS application, min(team) AS team, max(lv) AS lv,
                       array_agg(DISTINCT coalesce(through, '')) AS routes
                  FROM px WHERE key = ANY(%(keys)s)
                 GROUP BY dept, key, share, folder, folder_key ORDER BY dept, key, share, folder""", dict(a, keys=chosen))
    folders = {}
    for r in rows:
        folders.setdefault((r["dept"], r["key"]), []).append(r)
    info = person_info(conn, ds_id, chosen)
    view = []
    for d in depts[:DEPT_TOP]:
        ppl = []
        for r in by_dept.get(d["name"], []):
            fl = folders.get((d["name"], r["key"]), [])
            shares = {}
            for f in fl:
                shares.setdefault(f["share"], []).append(f)
            share_list = []
            for sh, fs in sorted(shares.items(), key=lambda x: (-max(f["lv"] for f in x[1]), x[0].lower())):
                share_list.append({"share": sh, "level": LEVELS[max(f["lv"] for f in fs)],
                                   "folders": [{"folder": f["folder"], "level": LEVELS[f["lv"]], "application": f["application"],
                                                "team": f["team"], "direct": "" in f["routes"],
                                                "via": sorted(x for x in f["routes"] if x),
                                                "outside": bool(f["team"] and d["name"] != NO_DEPT and f["lv"] in risky
                                                                and f["team"].lower() != d["name"].lower())}
                                               for f in fs[:PERSON_FOLDERS]]})
            pi = info.get(r["key"], {})
            ppl.append({"account": r["account"], "key": r["key"], "kind": r["kind"], "shares": r["shares"], "folders": r["folders"],
                        "worst": LEVELS[r["worst"]], "display_name": pi.get("display_name"), "title": pi.get("title"),
                        "dept_conflicts": pi.get("dept_conflicts"), "share_list": share_list})
        view.append({"department": d["name"], "people": d["people"], "shown": len(ppl), "list": ppl})
    outside = q("""SELECT dept, min(account) AS account, key, folder, min(team) AS team, max(lv) AS lv,
                          array_agg(DISTINCT coalesce(through, '')) AS routes
                     FROM px WHERE lv = ANY(%(risky_ranks)s) AND team IS NOT NULL AND dept <> %(nodept)s AND lower(team) <> lower(dept)
                    GROUP BY dept, key, folder ORDER BY dept, key, folder LIMIT 500""")
    outside_total = q("""SELECT count(*) AS n FROM (SELECT DISTINCT key, folder_key FROM px WHERE lv = ANY(%(risky_ranks)s)
                           AND team IS NOT NULL AND dept <> %(nodept)s AND lower(team) <> lower(dept)) t""")[0]["n"]
    for o in outside:
        o["level"] = LEVELS[o.pop("lv")]
        o["direct"] = "" in o["routes"]
        o["via"] = sorted(x for x in o.pop("routes") if x)
    unopened = q("SELECT count(DISTINCT key) AS n FROM allx WHERE kind = 'group'")[0]["n"]
    return depts, {"view": view, "outside": outside, "outside_total": outside_total, "groups_not_opened": unopened,
                   "people_total": q("SELECT count(DISTINCT key) AS n FROM px")[0]["n"]}


def compute(conn, ds_id, spec):
    """Every figure of a report, counted from the rows."""
    base, args, app, team = _base(spec)
    args["ds"] = ds_id
    cats = KIND_CATS[spec["kind"]]
    anycat = "(" + " OR ".join("(" + CATS[c][1] + ")" for c in cats) + ")"
    if spec["kind"] == "untagged":
        anycat = f"({app} IS NULL AND {team} IS NULL)"
    q = lambda sql: conn.execute(sql, args).fetchall()      # noqa: E731
    k = q(f"""SELECT count(*) AS entries, count(DISTINCT e.folder_key) AS folders, count(DISTINCT lower(e.path)) AS paths,
                     count(DISTINCT lower(e.identity)) AS identities, count(*) FILTER (WHERE {anycat}) AS findings,
                     count(DISTINCT e.folder_key) FILTER (WHERE {anycat}) AS folders_with,
                     count(DISTINCT {app}) AS applications, count(DISTINCT {team}) AS teams,
                     count(*) FILTER (WHERE e.identity_kind = 'unknown') AS kind_unknown,
                     count(*) FILTER (WHERE e.inherited IS NULL) AS inherit_unknown
                {base}""")[0]
    cat_counts = q("SELECT " + ", ".join(f"count(*) FILTER (WHERE {CATS[c][1]}) AS {c}" for c in CATS) + base)[0]
    levels = {r["level"]: r["n"] for r in q(f"SELECT e.level, count(*) AS n {base} AND e.allow GROUP BY e.level")}
    kinds = {r["identity_kind"]: r["n"] for r in q(f"SELECT e.identity_kind, count(*) AS n {base} GROUP BY e.identity_kind")}

    def by(expr, label_null):
        rows = q(f"""SELECT {expr} AS name, count(*) AS entries, count(*) FILTER (WHERE {anycat}) AS findings,
                            count(DISTINCT e.folder_key) AS folders, count(DISTINCT lower(e.identity)) AS identities,
                            """ + ", ".join(f"count(*) FILTER (WHERE {CATS[c][1]}) AS {c}" for c in CATS) +
                 f" {base} GROUP BY 1 ORDER BY count(*) FILTER (WHERE {anycat}) DESC, count(*) DESC")
        for r in rows:
            r["name"] = r["name"] if r["name"] is not None else label_null
        return rows
    apps = by(app, "Not tagged")
    teams = by(team, "Not tagged")
    servers = by("coalesce(e.server, '(not in the file)') || CASE WHEN e.share IS NOT NULL THEN ' · ' || e.share ELSE '' END",
                 "(not in the file)")
    folders = q(f"""SELECT f.label AS folder, {app} AS application, {team} AS team, f.tag_state AS tag_state,
                           count(*) AS entries, count(*) FILTER (WHERE {anycat}) AS findings,
                           """ + ", ".join(f"count(*) FILTER (WHERE {CATS[c][1]}) AS {c}" for c in CATS) + f"""
                      {base} GROUP BY f.label, 2, 3, f.tag_state
                      ORDER BY count(*) FILTER (WHERE {anycat}) DESC, count(*) DESC, f.label LIMIT 200""")
    who = q(f"""SELECT e.identity, e.identity_kind, count(*) AS findings, count(DISTINCT e.folder_key) AS folders,
                       max({rank_sql('e.level')}) AS worst
                  {base} AND {anycat} GROUP BY e.identity, e.identity_kind
                  ORDER BY count(*) DESC, e.identity LIMIT 100""")
    has_members = bool(conn.execute("SELECT 1 FROM perm_access WHERE dataset_id = %s LIMIT 1", (ds_id,)).fetchone())
    behind = {}
    if has_members and who:
        behind = {r["group_key"]: r["n"] for r in conn.execute(
            """SELECT group_key, count(*) AS n FROM perm_access WHERE dataset_id = %s AND group_key = ANY(%s) GROUP BY group_key""",
            (ds_id, [ident_key(w["identity"]) for w in who])).fetchall()}
    for w in who:
        w["worst"] = LEVELS[w["worst"]]
        w["behind"] = behind.get(ident_key(w["identity"])) if w["identity_kind"] != "broad" else None
    people, people_total = [], None
    if has_members:
        k["accounts_behind"] = q(people_cte(base, app, "e.allow", team) + " SELECT count(DISTINCT key) AS n FROM via")[0]["n"]
    if spec["kind"] == "effective":
        cte = people_cte(base, app, anycat, team)
        people_total = q(cte + " SELECT count(DISTINCT key) AS n FROM allx")[0]["n"]
        people = q(cte + """ SELECT min(account) AS account, key, min(kind) AS kind, count(DISTINCT folder_key) AS folders,
                                     max(lv) AS worst, count(DISTINCT application) AS applications,
                                     (array_agg(DISTINCT through) FILTER (WHERE through IS NOT NULL))[1:4] AS through,
                                     bool_or(through IS NULL) AS direct
                                FROM allx GROUP BY key ORDER BY count(DISTINCT folder_key) DESC, max(lv) DESC, key LIMIT 300""")
        for r in people:
            r["worst"] = LEVELS[r["worst"]]
            r["through"] = r["through"] or []
    has_people = bool(conn.execute("SELECT 1 FROM perm_people WHERE dataset_id = %s LIMIT 1", (ds_id,)).fetchone())
    if has_people and people:
        info = person_info(conn, ds_id, [r["key"] for r in people])
        for r in people:
            r.update(info.get(r["key"], {"department": None}))
    departments = dept_view = None
    if spec["kind"] == "by_department":
        departments, dept_view = department_report(conn, ds_id, base, app, team, anycat, args, spec)
    _, find_sql, _ = compute_sql_only(ds_id, spec)
    findings = conn.execute(find_sql + " LIMIT 500", args).fetchall()
    for f in findings:
        f["why"] = [CATS[c][0] for c in CATS if f.pop(c) and c in cats]
    team_sections = []
    if spec["kind"] == "team_review":
        for t in teams[:40]:
            cond = f"{team} IS NULL" if t["name"] == "Not tagged" else f"{team} = %(t)s"
            rows = conn.execute(f"""SELECT f.label AS folder, e.identity, e.identity_kind, e.identity_key,
                                           max({rank_sql('e.level')}) AS lv,
                                           bool_or({anycat}) AS risky
                                      {base} AND {cond} AND e.allow AND e.level IN ('write', 'modify', 'full')
                                       AND e.identity_kind NOT IN ('system', 'admin')
                                     GROUP BY f.label, e.identity, e.identity_kind, e.identity_key ORDER BY f.label, lv DESC, e.identity LIMIT 400""",
                                dict(args, t=t["name"])).fetchall()
            members = {}
            gkeys = list({r["identity_key"] for r in rows if r["identity_kind"] != "broad" and r["identity_key"]})
            if has_members and gkeys:
                for g in conn.execute("""SELECT group_key, count(*) AS n, (array_agg(member ORDER BY member))[1:30] AS names
                                           FROM perm_access WHERE dataset_id = %s AND group_key = ANY(%s) GROUP BY group_key""",
                                      (ds_id, gkeys)).fetchall():
                    members[g["group_key"]] = {"n": g["n"], "names": g["names"]}
            team_sections.append({"team": t["name"], "rows": [{"folder": r["folder"], "identity": r["identity"],
                                  "kind": r["identity_kind"], "level": LEVELS[r["lv"]], "risky": r["risky"],
                                  "members": members.get(r["identity_key"])} for r in rows]})

    def donut_of(rows, key="findings"):
        rows = [r for r in rows if r[key]]
        named = [r for r in rows if r["name"] != "Not tagged"]
        top, rest = named[:TOP], named[TOP:]
        segs = [{"label": r["name"], "value": r[key]} for r in top]
        if rest:
            segs.append({"label": f"Other ({len(rest)})", "value": sum(r[key] for r in rest), "other": True})
        nt = [r for r in rows if r["name"] == "Not tagged"]
        if nt:
            segs.append({"label": "Not tagged", "value": nt[0][key], "untagged": True})
        return segs
    measure = "entries" if spec["kind"] in ("untagged", "by_server") else "findings"
    return {
        "kpis": k, "categories": {c: {"label": CATS[c][0], "n": cat_counts[c], "in_report": c in cats} for c in CATS},
        "levels": [{"level": lv, "label": LEVEL_TEXT[lv], "n": levels.get(lv, 0)} for lv in reversed(LEVELS) if levels.get(lv)],
        "kinds": [{"kind": kd, "label": KIND_TEXT[kd], "n": n} for kd, n in sorted(kinds.items(), key=lambda x: -x[1])],
        "donuts": {"applications": donut_of(apps, measure), "teams": donut_of(teams, measure),
                   "servers": [{"label": r["name"], "value": r[measure]} for r in servers[:TOP] if r[measure]] +
                              ([{"label": f"Other ({len(servers) - TOP})", "value": sum(r[measure] for r in servers[TOP:]), "other": True}]
                               if len(servers) > TOP and sum(r[measure] for r in servers[TOP:]) else [])},
        "measure": measure,
        "dept_donut": ([{"label": d["name"], "value": d["people"], "untagged": d["name"] == NO_DEPT}
                        for d in departments if d["name"] != NO_DEPT][:TOP] +
                       ([{"label": f"Other ({len([d for d in departments if d['name'] != NO_DEPT]) - TOP})",
                          "value": sum(d["people"] for d in [d for d in departments if d["name"] != NO_DEPT][TOP:]), "other": True}]
                        if len([d for d in departments if d["name"] != NO_DEPT]) > TOP else []) +
                       [{"label": "Department not in the file", "value": d["people"], "untagged": True}
                        for d in departments if d["name"] == NO_DEPT]) if departments else None,
        "applications": apps[:200], "teams": teams[:200], "servers": servers[:200], "folders": folders, "who": who,
        "findings": findings, "findings_total": k["findings"], "team_sections": team_sections,
        "people": people, "people_total": people_total, "has_members": has_members, "has_people": has_people,
        "departments": departments, "department_view": dept_view,
    }, find_sql, args


def make_report(conn, ds_id, spec, user):
    ds = conn.execute("SELECT state FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known.")
    if ds["state"] != "ready":
        raise PermError("The rows are not ready yet: confirm the columns first.")
    spec = clean_spec(conn, ds_id, spec)
    r = conn.execute("""INSERT INTO perm_reports (dataset_id, kind, title, spec, created_by)
                        VALUES (%s, %s, %s, %s::jsonb, %s) RETURNING id::text AS id""",
                     (ds_id, spec["kind"], spec["title"], json.dumps(spec), user)).fetchone()
    return r["id"]


def build_report(conn, report_id):
    """The worker counts a report's figures (a million rows take a few seconds: not in the web request)."""
    r = conn.execute("SELECT dataset_id::text AS ds, spec FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
    conn.execute("UPDATE perm_reports SET state = 'computing' WHERE id = %s", (report_id,))
    conn.commit()
    result, _, _ = compute(conn, r["ds"], r["spec"])
    conn.execute("UPDATE perm_reports SET result = %s::jsonb, state = 'ready', error = NULL WHERE id = %s",
                 (json.dumps(result, default=str), report_id))
    conn.commit()


CSV_COLS = ["Folder", "Path", "Account", "Kind of account", "Access level", "Rights as in the file", "Allow or deny", "Inherited",
            "Application", "Owning team", "Why it is in the report"]


def safe_csv(v):
    """A cell a spreadsheet will never run as a formula."""
    t = "" if v is None else str(v)
    return "'" + t if t[:1] in ("=", "+", "-", "@", "\t", "\r") else t


def findings_csv(conn, report_id):
    """Every finding of a report (not only the first 500), as CSV text, counted again from the rows."""
    rep = conn.execute("SELECT dataset_id::text AS ds, spec, state FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
    if not rep:
        raise PermError("That report is not known.")
    if rep["state"] != "ready":
        raise PermError("The report is still being counted.")
    spec = rep["spec"] if isinstance(rep["spec"], dict) else json.loads(rep["spec"])
    _, sql, args = compute_sql_only(rep["ds"], spec)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(CSV_COLS)
    cats = KIND_CATS[spec["kind"]]
    for f in conn.execute(sql, args):
        why = [CATS[c][0] for c in CATS if f.get(c) and c in cats]
        w.writerow([safe_csv(x) for x in (f["folder"], f["path"], f["identity"], KIND_TEXT.get(f["identity_kind"], f["identity_kind"]),
                                          LEVEL_TEXT.get(f["level"], f["level"]), f["rights_raw"], "Allow" if f["allow"] else "Deny",
                                          {True: "Yes", False: "No"}.get(f["inherited"], "Not in the file"),
                                          f["application"] or "", f["team"] or "", "; ".join(why) or "Not tagged")])
    return "﻿" + buf.getvalue()


PEOPLE_COLS = ["Department", "Account", "Full name", "Kind of account", "Share", "Folder", "Highest access level", "How",
               "Application", "Owning team"]


def people_csv(conn, report_id):
    """Every account and folder of a 'who really has access' or 'by department' report: one line per
    account and folder, the highest level and every way in."""
    rep = conn.execute("SELECT dataset_id::text AS ds, spec, state FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
    if not rep:
        raise PermError("That report is not known.")
    if rep["state"] != "ready":
        raise PermError("The report is still being counted.")
    spec = rep["spec"] if isinstance(rep["spec"], dict) else json.loads(rep["spec"])
    base, args, app, team = _base(spec)
    args["ds"] = rep["ds"]
    args["nodept"] = NO_DEPT
    cats = KIND_CATS[spec["kind"]]
    anycat = "(" + " OR ".join("(" + CATS[c][1] + ")" for c in cats) + ")"
    keep = f"WHERE p.person_key IS NOT NULL OR allx.kind IN {PERSON_KINDS}" if spec["kind"] == "by_department" else ""
    sql = people_cte(base, app, anycat, team) + f""" SELECT coalesce(min(p.department), %(nodept)s) AS dept, min(allx.account) AS account,
                                                            min(p.display_name) AS display_name, min(allx.kind) AS kind, allx.share,
                                                            allx.folder, max(allx.lv) AS lv,
                                                            array_agg(DISTINCT coalesce(allx.through, '')) AS routes,
                                                            min(allx.application) AS application, min(allx.team) AS team
                                                       FROM allx LEFT JOIN perm_people p ON p.dataset_id = %(ds)s AND p.person_key = allx.key
                                                      {keep}
                                                      GROUP BY allx.key, allx.share, allx.folder
                                                      ORDER BY 1, allx.key, allx.share, allx.folder"""
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(PEOPLE_COLS)
    for r in conn.execute(sql, args):
        how = "; ".join((["directly"] if "" in r["routes"] else []) + ["via " + x for x in sorted(x for x in r["routes"] if x)])
        w.writerow([safe_csv(x) for x in (r["dept"], r["account"], r["display_name"] or "", KIND_TEXT.get(r["kind"], r["kind"]),
                                          r["share"], r["folder"], LEVEL_TEXT.get(LEVELS[r["lv"]], ""), how,
                                          r["application"] or "", r["team"] or "")])
    return "\ufeff" + buf.getvalue()


def compute_sql_only(ds_id, spec):
    base, args, app, team = _base(spec)
    args["ds"] = ds_id
    cats = KIND_CATS[spec["kind"]]
    anycat = "(" + " OR ".join("(" + CATS[c][1] + ")" for c in cats) + ")"
    if spec["kind"] == "untagged":
        anycat = f"({app} IS NULL AND {team} IS NULL)"
    sql = (f"""SELECT e.path, e.identity, e.identity_kind, e.kind_source, e.level, e.rights_raw, e.allow, e.inherited,
                      {app} AS application, {team} AS team, f.label AS folder, """ +
           ", ".join(f"({CATS[c][1]}) AS {c}" for c in CATS) +
           f" {base} AND {anycat} ORDER BY CASE e.level WHEN 'full' THEN 0 WHEN 'modify' THEN 1 WHEN 'write' THEN 2 ELSE 3 END,"
           " lower(e.path), lower(e.identity), e.rn")
    return None, sql, args


# ---- AI-01: which reports fit, and the summary ----------------------------------------------------------------

ADVICE_SYSTEM = """You help an administrator choose access-review reports for a file and folder permissions export.
You are given counts from the file. Recommend up to four reports from the list, the most useful first, each with one
sentence of why, quoting only counts you were given. Never invent a count. Answer only with JSON."""


def advice_messages(prof):
    kinds = {k: v[0] for k, v in KINDS.items()}
    return [{"role": "system", "content": ADVICE_SYSTEM},
            {"role": "user", "content": "Reports: " + json.dumps(kinds) + "\nCounts from the file: " + json.dumps(prof, default=str)}]


ADVICE_SCHEMA = {"type": "object", "properties": {"recommended": {"type": "array", "items": {"type": "object", "properties": {
    "report": {"type": "string", "enum": list(KINDS)}, "why": {"type": "string"}}, "required": ["report", "why"]}}},
    "required": ["recommended"]}


def rule_advice(prof):
    """What the rules recommend from the counts (also when AI-01 cannot be asked)."""
    p = prof or {}
    out = []
    if p.get("broad_write"):
        out.append(("broad", f"{p['broad_write']} entries let Everyone-type groups change data."))
    if p.get("orphans"):
        out.append(("orphans", f"{p['orphans']} entries name accounts that no longer exist."))
    if p.get("explicit_users"):
        out.append(("explicit_users", f"{p['explicit_users']} entries give people rights directly, not through a group."))
    if p.get("full_nonadmin"):
        out.append(("full_control", f"{p['full_nonadmin']} entries give full control outside the admin groups."))
    if p.get("people_listed"):
        out.append(("by_department", f"The people sheet gives {p['people_listed']} people in {p['departments']} departments: "
                                     "see each department's people and the shares and folders they reach."))
    if p.get("accounts_behind"):
        out.append(("effective", f"The members sheet opens up {p['groups_opened']} groups into {p['accounts_behind']} accounts: "
                                 "see who really can change data."))
    if p.get("tagged"):
        out.append(("by_app", f"{p['tagged']} folders have a confirmed application and team."))
    if p.get("folders") and (p.get("tagged") or 0) < p["folders"]:
        out.append(("untagged", f"{p['folders'] - (p.get('tagged') or 0)} of {p['folders']} folders have no confirmed application yet."))
    out.append(("risk", "One view of every kind of risky access in the file."))
    seen, res = set(), []
    for k, why in out:
        if k not in seen:
            seen.add(k)
            res.append({"report": k, "why": why, "by": "rules"})
    return res[:4]


NUM_RE = re.compile(r"\d[\d,]*")


def numbers_in(doc):
    """Every number a report holds (counts, as integers), to check AI-01's text against."""
    out = set()
    def walk(x):
        if isinstance(x, bool):
            return
        if isinstance(x, (int, float)):
            out.add(int(x))
        elif isinstance(x, dict):
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
    walk(doc)
    return out


def grounded(text, allowed):
    """Keep only the sentences whose numbers are all figures of the report (AI-01 never counts)."""
    keep = []
    for sent in re.split(r"(?<=[.!?])\s+", (text or "").strip()):
        nums = [int(n.replace(",", "")) for n in NUM_RE.findall(sent) if n.replace(",", "").isdigit()]
        if all(n in allowed for n in nums):
            keep.append(sent)
    return " ".join(keep).strip()


SUMMARY_SYSTEM = """You write the summary of an access-review report for the owners of the data. You are given the report's
figures. Write a headline (one sentence), three to five key points, and up to three first actions. Quote only figures you are
given, exactly as given; never compute percentages or new totals; never name an account, folder or team that is not in the
figures. Plain words, no jargon. Answer only with JSON."""
SUMMARY_SCHEMA = {"type": "object", "properties": {"headline": {"type": "string"}, "points": {"type": "array", "items": {"type": "string"}},
                                                   "actions": {"type": "array", "items": {"type": "string"}}},
                  "required": ["headline", "points", "actions"]}


def summary_facts(title, result):
    k = result["kpis"]
    return {"report": title, "entries_in_scope": k["entries"], "folders": k["folders"], "accounts": k["identities"],
            "findings": k["findings"], "folders_with_findings": k["folders_with"],
            **({"findings_are": "entries that give access (this report groups people, it does not judge risk)",
                "departments": [{"department": d["name"], "people": d["people"], "can_change_data": d["can_change"],
                                 "outside_their_department": d["outside_people"]} for d in result["departments"][:8]],
                "people_outside_the_owning_department": result["department_view"]["outside_total"]}
               if result.get("department_view") else {}),
            "by_kind_of_risk": {v["label"]: v["n"] for v in result["categories"].values() if v["in_report"]},
            "top_applications": [{"application": r["name"], "findings": r["findings"], "entries": r["entries"]} for r in result["applications"][:6]],
            "top_teams": [{"team": r["name"], "findings": r["findings"]} for r in result["teams"][:6]],
            "top_folders": [{"folder": r["folder"], "findings": r["findings"]} for r in result["folders"][:5]],
            "top_accounts": [{"account": r["identity"], "findings": r["findings"], "folders": r["folders"]} for r in result["who"][:5]]}


def summary_messages(facts):
    return [{"role": "system", "content": SUMMARY_SYSTEM}, {"role": "user", "content": json.dumps(facts, default=str)[:9000]}]


def clean_summary(doc, facts):
    allowed = numbers_in(facts)
    head = grounded(clean_tag_text((doc or {}).get("headline"), 300), allowed)
    pts = [grounded(clean_tag_text(x, 300), allowed) for x in ((doc or {}).get("points") or [])[:5]]
    acts = [grounded(clean_tag_text(x, 300), allowed) for x in ((doc or {}).get("actions") or [])[:3]]
    pts, acts = [x for x in pts if x], [x for x in acts if x]
    if not head and not pts:
        return None
    return {"headline": head, "points": pts, "actions": acts}


# ---- what the console shows ----------------------------------------------------------------------------------

DS_COLS = """id::text AS id, name, file_name, size_bytes, received, uploaded_by, uploaded_at, state, error, encoding, delimiter,
             header_row, row_count, skipped, tag_depth, tag_ai, tag_ai_note, progress, mapping_by, mapping_at, updated_at"""


def datasets(conn):
    try:
        with conn.transaction():
            rows = conn.execute(f"""SELECT {DS_COLS}, (SELECT count(*) FROM perm_reports r WHERE r.dataset_id = d.id) AS reports
                                      FROM perm_datasets d ORDER BY uploaded_at DESC LIMIT 100""").fetchall()
    except Exception:  # noqa: BLE001 - schema 060 not applied yet
        return None
    return {"items": rows, "max_mb": MAX_BYTES // 2 ** 20, "max_rows": MAX_ROWS, "chunk_bytes": CHUNK,
            "roles": [{"key": k, "label": lab, "required": req} for k, lab, req in ROLES],
            "kinds": [{"key": k, "title": v[0], "about": v[1]} for k, v in KINDS.items()],
            "levels": [{"key": lv, "label": LEVEL_TEXT[lv]} for lv in reversed(LEVELS)]}


def dataset(conn, ds_id):
    d = conn.execute(f"""SELECT {DS_COLS}, headers, sample, mapping, proposal, profile, advice, advice_at, file_type, cleaning, links
                           FROM perm_datasets WHERE id = %s""", (ds_id,)).fetchone()
    if not d:
        raise PermError("That upload is not known (it may have been removed).")
    d["sheets"] = sheets_of(conn, ds_id)
    d["encoding_text"] = ENCODING_TEXT.get(d["encoding"] or "", d["encoding"])
    d["sheet_roles"] = {k: {"title": SHEET_ROLE_TEXT[k], "fields": [{"key": f, "label": lab, "required": req} for f, lab, req in v],
                            "name_roles": list(SHEET_NAME_ROLES.get(k, ()))} for k, v in ROLESETS.items()}
    d["sheet_roles"]["skip"] = {"title": SHEET_ROLE_TEXT["skip"], "fields": [], "name_roles": []}
    if d["profile"]:
        d["profile"] = dict(d["profile"], **folder_counts(conn, ds_id))
    d["roles"] = [{"key": k, "label": lab, "required": req} for k, lab, req in ROLES]
    d["kinds"] = [{"key": k, "title": v[0], "about": v[1]} for k, v in KINDS.items()]
    d["reports"] = conn.execute("""SELECT id::text AS id, kind, title, created_by, created_at, summary_state, state,
                                          (result->'kpis'->>'findings')::int AS findings
                                     FROM perm_reports WHERE dataset_id = %s ORDER BY created_at DESC LIMIT 50""", (ds_id,)).fetchall()
    if d["state"] == "ready":
        d["choices"] = {
            "servers": [r["s"] for r in conn.execute("""SELECT DISTINCT server AS s FROM perm_entries WHERE dataset_id = %s
                                                          AND server IS NOT NULL ORDER BY 1 LIMIT 300""", (ds_id,))],
            "applications": [r["a"] for r in conn.execute("""SELECT DISTINCT application AS a FROM perm_folders WHERE dataset_id = %s
                                                               AND application IS NOT NULL ORDER BY 1 LIMIT 500""", (ds_id,))],
            "teams": [r["t"] for r in conn.execute("""SELECT DISTINCT team AS t FROM perm_folders WHERE dataset_id = %s
                                                        AND team IS NOT NULL ORDER BY 1 LIMIT 500""", (ds_id,))],
            "confirmed_only_apps": [r["a"] for r in conn.execute("""SELECT DISTINCT application AS a FROM perm_folders
                                     WHERE dataset_id = %s AND tag_state = 'confirmed' AND application IS NOT NULL ORDER BY 1 LIMIT 500""", (ds_id,))],
        }
    return d


def tags_view(conn, ds_id, state=None, q=None, limit=500):
    """This upload's folders with the tag in force, and the suggestion waiting (biggest first)."""
    where, args = ["f.dataset_id = %s"], [ds_id]
    if state == "suggested":
        where.append("t.state = 'suggested' AND (t.application IS NOT NULL OR t.team IS NOT NULL)")
    elif state == "confirmed":
        where.append("f.tag_state = 'confirmed'")
    elif state == "untagged":
        where.append("f.tag_key IS NULL")
    elif state == "inherited":
        where.append("f.tag_key IS NOT NULL AND f.tag_key <> f.folder_key")
    if q:
        where.append("(strpos(lower(f.label), %s) > 0 OR strpos(lower(coalesce(f.application, '')), %s) > 0"
                     " OR strpos(lower(coalesce(f.team, '')), %s) > 0)")       # plain text: a backslash is a backslash
        args += [q.lower()] * 3
    rows = conn.execute(f"""SELECT f.folder_key AS key, f.label, f.server, f.entries, f.paths, f.identities,
                                   f.application, f.team, f.tag_state, f.tag_key,
                                   t.state AS own_state, t.application AS s_application, t.team AS s_team, t.confidence,
                                   t.reason, t.suggested_by, t.decided_by, t.decided_at
                              FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key
                             WHERE {' AND '.join(where)}
                             ORDER BY f.entries DESC, f.folder_key LIMIT %s""", args + [min(int(limit), 2000)]).fetchall()
    c = conn.execute("""SELECT count(*) AS folders, count(*) FILTER (WHERE f.tag_state = 'confirmed') AS confirmed,
                               count(*) FILTER (WHERE t.state = 'suggested' AND (t.application IS NOT NULL OR t.team IS NOT NULL)) AS suggested,
                               count(*) FILTER (WHERE f.tag_key IS NULL) AS untagged,
                               count(*) FILTER (WHERE t.state = 'rejected') AS rejected,
                               count(*) FILTER (WHERE t.key_l IS NULL) AS not_asked
                          FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key WHERE f.dataset_id = %s""",
                     (ds_id,)).fetchone()
    names = conn.execute("""SELECT array(SELECT DISTINCT application FROM perm_tags WHERE state = 'confirmed' AND application IS NOT NULL ORDER BY 1) AS apps,
                                   array(SELECT DISTINCT team FROM perm_tags WHERE state = 'confirmed' AND team IS NOT NULL ORDER BY 1) AS teams""").fetchone()
    st = conn.execute("SELECT tag_ai, tag_ai_note, progress FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone() or {}
    return {"items": rows, "counts": c, "known_applications": names["apps"] or [], "known_teams": names["teams"] or [],
            "tag_ai": st.get("tag_ai"), "tag_ai_note": st.get("tag_ai_note")}


def ask_tags(conn, ds_id, again=False):
    ds = conn.execute("SELECT state FROM perm_datasets WHERE id = %s FOR UPDATE", (ds_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known.")
    if ds["state"] != "ready":
        raise PermError("Confirm the columns first: AI-01 tags the folders once the rows are ready.")
    if again:     # suggestions nobody decided yet are asked again (confirmed and rejected stay)
        conn.execute("""DELETE FROM perm_tags t USING perm_folders f WHERE f.dataset_id = %s AND t.key_l = f.folder_key
                         AND t.state = 'suggested'""", (ds_id,))
        resolve_tags(conn, ds_id)
    conn.execute("UPDATE perm_datasets SET tag_ai = 'queued', tag_ai_note = NULL WHERE id = %s", (ds_id,))


def report_view(conn, report_id):
    r = conn.execute("""SELECT r.id::text AS id, r.dataset_id::text AS dataset_id, r.kind, r.title, r.spec, r.result, r.summary,
                               r.state, r.error,
                               r.summary_state, r.created_by, r.created_at, d.name AS dataset, d.file_name, d.uploaded_at
                          FROM perm_reports r JOIN perm_datasets d ON d.id = r.dataset_id WHERE r.id = %s""", (report_id,)).fetchone()
    if not r:
        raise PermError("That report is not known.")
    r["kind_title"], r["kind_about"] = KINDS.get(r["kind"], ("", ""))
    return r


# ---- the worker: one pass ---------------------------------------------------------------------------------------

def _json(text):
    """AI-01's answer as JSON (it may wrap it in words or a <think> block)."""
    if isinstance(text, dict):
        return text
    t = re.sub(r"<think>.*?</think>", "", str(text or ""), flags=re.S)
    a, b = t.find("{"), t.rfind("}")
    if a < 0 or b < a:
        raise ValueError("AI-01 gave no JSON")
    return json.loads(t[a:b + 1])


def make_advice(conn, ds_id, ai=None):
    prof = conn.execute("SELECT profile FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()["profile"] or {}
    rules = rule_advice(prof)
    items, by, note = [], "rules", None
    if ai:
        try:
            got = _json(ai(advice_messages(prof), ADVICE_SCHEMA))
            allowed = numbers_in(prof)
            for it in (got.get("recommended") or [])[:4]:
                k = it.get("report")
                why = grounded(clean_tag_text(it.get("why"), 300), allowed)
                if k in KINDS and k not in {x["report"] for x in items}:
                    items.append({"report": k, "why": why or next((r["why"] for r in rules if r["report"] == k), KINDS[k][1]),
                                  "by": "AI-01"})
            by = "AI-01" if items else "rules"
        except Exception as e:  # noqa: BLE001 - the rules' advice stands alone
            note = "AI-01 did not answer (" + str(e)[:100] + "): recommended by the rules from the counts."
    for r in rules:                                   # the rules fill in what AI-01 left out
        if len(items) >= 4:
            break
        if r["report"] not in {x["report"] for x in items}:
            items.append(r)
    conn.execute("UPDATE perm_datasets SET advice = %s::jsonb, advice_at = now() WHERE id = %s",
                 (json.dumps({"items": items, "by": by, "note": note}), ds_id))
    conn.commit()
    return items


def summarise(conn, report_id, ai):
    r = conn.execute("SELECT title, result FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
    facts = summary_facts(r["title"], r["result"])
    conn.execute("UPDATE perm_reports SET summary_state = 'running' WHERE id = %s", (report_id,))
    conn.commit()
    doc = clean_summary(_json(ai(summary_messages(facts), SUMMARY_SCHEMA)), facts)
    conn.execute("UPDATE perm_reports SET summary = %s::jsonb, summary_state = %s WHERE id = %s",
                 (json.dumps(doc) if doc else None, "done" if doc else "failed", report_id))
    conn.commit()


def _fail(conn, ds_id, msg):
    conn.rollback()
    conn.execute("UPDATE perm_datasets SET state = 'failed', error = %s, progress = NULL, updated_at = now() WHERE id = %s",
                 (str(msg)[:500], ds_id))
    conn.commit()


def run_once(conn, ai_for, stop=lambda: False, background_ok=lambda: True):
    """One pass of everything waiting. ai_for(kind) gives a function (messages, schema) -> dict, or None
    when AI-01 is not configured. Returns what it did (for the heartbeat and the tests)."""
    did = []
    # 1. files uploaded (or cut short while being read): read them, then propose the columns
    for d in conn.execute("SELECT id::text AS id, state FROM perm_datasets WHERE state IN ('uploaded', 'reading') ORDER BY uploaded_at").fetchall():
        if stop():
            return did
        try:
            read_file(conn, d["id"], stop)
        except Exception as e:  # noqa: BLE001
            if stop():
                return did             # left as it is: read again after the restart
            log.warning("access review: reading %s failed: %s", d["id"], e)
            _fail(conn, d["id"], e if isinstance(e, PermError) else
                  "The file could not be read as CSV (" + type(e).__name__ + ": " + str(e)[:160] + ").")
            continue
        did.append(("read", d["id"]))
    for d in conn.execute("SELECT id::text AS id FROM perm_datasets WHERE state = 'mapping' AND proposal IS NULL").fetchall():
        propose(conn, d["id"], ai_for("mapping"))
        did.append(("proposed", d["id"]))
    # 2. columns confirmed: make the rows plain, then recommend reports
    for d in conn.execute("SELECT id::text AS id FROM perm_datasets WHERE state = 'normalising' ORDER BY mapping_at").fetchall():
        if stop():
            return did
        try:
            normalise(conn, d["id"], stop)
        except Exception as e:  # noqa: BLE001
            if stop():
                return did
            log.warning("access review: rows of %s failed: %s", d["id"], e)
            _fail(conn, d["id"], e if isinstance(e, PermError) else "The rows could not be read with these columns (" + str(e)[:160] + ").")
            continue
        did.append(("normalised", d["id"]))
    for d in conn.execute("SELECT id::text AS id FROM perm_datasets WHERE state = 'ready' AND advice IS NULL").fetchall():
        make_advice(conn, d["id"], ai_for("advice"))
        did.append(("advice", d["id"]))
    # 3. tags asked of AI-01: a batch at a time, yielding to people using AI-01
    for d in conn.execute("""SELECT id::text AS id FROM perm_datasets WHERE state = 'ready' AND tag_ai IN ('queued', 'running')
                              ORDER BY updated_at""").fetchall():
        ai = ai_for("tags")
        if not ai:
            conn.execute("UPDATE perm_datasets SET tag_ai = 'failed', tag_ai_note = 'AI-01 is not configured on PATCH-01' WHERE id = %s", (d["id"],))
            conn.commit()
            continue
        conn.execute("UPDATE perm_datasets SET tag_ai = 'running' WHERE id = %s", (d["id"],))
        conn.commit()
        fails = batches = 0
        while not stop() and background_ok() and batches < 5:      # then the others get a turn; the next pass goes on
            batches += 1
            if conn.execute("SELECT tag_ai FROM perm_datasets WHERE id = %s", (d["id"],)).fetchone()["tag_ai"] != "running":
                break                                                # an admin pressed Stop
            try:
                n = suggest_batch(conn, d["id"], lambda msgs, sch: _json(ai(msgs, sch)))
            except Exception as e:  # noqa: BLE001 - AI-01 busy or slow: try again next pass, give up after 3 in a row
                conn.rollback()
                fails += 1
                log.info("access review: tag batch failed: %s", e)
                if fails >= 3:
                    conn.execute("UPDATE perm_datasets SET tag_ai = 'failed', tag_ai_note = %s WHERE id = %s",
                                 ("AI-01 did not answer three times (" + str(e)[:120] + "). Ask again later.", d["id"]))
                    conn.commit()
                    break
                continue
            fails = 0
            if not n:
                left = conn.execute("""SELECT count(*) FILTER (WHERE t.application IS NOT NULL OR t.team IS NOT NULL) AS s
                                         FROM perm_folders f JOIN perm_tags t ON t.key_l = f.folder_key
                                        WHERE f.dataset_id = %s AND t.state = 'suggested'""", (d["id"],)).fetchone()["s"]
                conn.execute("""UPDATE perm_datasets SET tag_ai = 'done', tag_ai_note = %s,
                                       profile = %s::jsonb WHERE id = %s""",
                             (f"{left} suggestions are waiting for your decision", json.dumps(profile(conn, d["id"])), d["id"]))
                conn.commit()
                did.append(("tagged", d["id"]))
                break
            c = conn.execute("""SELECT count(*) AS n, count(t.key_l) AS asked FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key
                                 WHERE f.dataset_id = %s""", (d["id"],)).fetchone()
            conn.execute("UPDATE perm_datasets SET tag_ai_note = %s WHERE id = %s AND tag_ai = 'running'",
                         (f"AI-01 has looked at {c['asked']} of {c['n']} folders (biggest first)", d["id"]))
            conn.commit()
            did.append(("tag_batch", d["id"]))
    # 4. reports asked for: count them, then AI-01's summary
    for r in conn.execute("SELECT id::text AS id FROM perm_reports WHERE state IN ('queued', 'computing') ORDER BY created_at").fetchall():
        if stop():
            return did
        try:
            build_report(conn, r["id"])
            did.append(("report", r["id"]))
        except Exception as e:  # noqa: BLE001
            log.warning("access review: report %s failed: %s", r["id"], e)
            conn.rollback()
            conn.execute("UPDATE perm_reports SET state = 'failed', error = %s, summary_state = 'off' WHERE id = %s",
                         ("The figures could not be counted (" + type(e).__name__ + ": " + str(e)[:160] + ").", r["id"]))
            conn.commit()
    for r in conn.execute("""SELECT id::text AS id FROM perm_reports WHERE state = 'ready' AND summary_state IN ('queued', 'running')
                              ORDER BY created_at""").fetchall():
        if stop() or not background_ok():
            break
        ai = ai_for("summary")
        if not ai:
            conn.execute("UPDATE perm_reports SET summary_state = 'off' WHERE id = %s", (r["id"],))
            conn.commit()
            continue
        try:
            summarise(conn, r["id"], ai)
            did.append(("summary", r["id"]))
        except Exception as e:  # noqa: BLE001
            conn.rollback()
            log.info("access review: summary failed: %s", e)
            conn.execute("UPDATE perm_reports SET summary_state = 'failed' WHERE id = %s", (r["id"],))
            conn.commit()
    return did
