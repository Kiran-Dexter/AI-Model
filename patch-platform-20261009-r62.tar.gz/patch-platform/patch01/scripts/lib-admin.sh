# shellcheck shell=bash
# ---------------------------------------------------------------------------
# PATCH-01 : signing the scripts in to the API as an admin
#
# Sourced by the phase scripts that call admin endpoints (enrollment tokens,
# AI-01 status). The first-start password in api.env (ADMIN_PASSWORD) only
# works until an admin changes it in the console, which they should. So:
#
#   1. the stored password is tried first;
#   2. if the API refuses it, and someone is at the terminal, it asks for an
#      admin's user name and password (not echoed, never stored, never on a
#      command line where `ps` could show it: curl reads it from a pipe);
#   3. if nobody is at the terminal, it says so and stops.
#
# Usage:   source "$(dirname "$0")/lib-admin.sh"
#          admin_login "$SECRETS_DIR/api.env" || die "..."
#          admin_curl -H 'Content-Type: application/json' -d '{...}' https://127.0.0.1/api/v1/...
# ---------------------------------------------------------------------------

_ADMIN_USER=""
_ADMIN_PW=""

# curl's config syntax: a quoted string, with \ and " escaped
_admin_cfg() {
  local u p
  u="${_ADMIN_USER//\\/\\\\}"; u="${u//\"/\\\"}"
  p="${_ADMIN_PW//\\/\\\\}";   p="${p//\"/\\\"}"
  printf 'user = "%s:%s"\n' "$u" "$p"
}

admin_curl() {
  _admin_cfg | curl -sk -K - "$@"
}

# HTTP status of /auth/me with the current user and password
_admin_probe() {
  admin_curl -o /dev/null -w '%{http_code}' --max-time 15 https://127.0.0.1/api/v1/auth/me 2>/dev/null || echo 000
}

# admin_login API_ENV [--no-prompt]
#   0 when signed in; 1 when refused (the reason is printed to stderr).
admin_login() {
  local env_file="$1" mode="${2:-}" code
  _ADMIN_USER="${PATCH01_ADMIN_USER:-admin}"
  _ADMIN_PW=""
  [[ -f "$env_file" ]] && _ADMIN_PW="$(grep -E '^ADMIN_PASSWORD=' "$env_file" | cut -d= -f2- || true)"
  if [[ -n "$_ADMIN_PW" ]]; then
    code="$(_admin_probe)"
    [[ "$code" == "200" ]] && return 0
    [[ "$code" == "401" || "$code" == "403" ]] || { echo "The API answered HTTP $code." >&2; return 1; }
  fi
  if [[ "$mode" == "--no-prompt" || ! -t 0 ]]; then
    echo "The first-start admin password no longer works (it was changed in the console, as it should be)." >&2
    [[ "$mode" == "--no-prompt" ]] || echo "Run this from a terminal to be asked for an admin's password." >&2
    return 1
  fi
  echo "The first-start admin password no longer works (changed in the console). Sign in as an admin:" >&2
  local tries=0
  while (( tries < 3 )); do
    tries=$((tries + 1))
    read -r -p "  Admin user [${_ADMIN_USER}]: " u </dev/tty || return 1
    [[ -n "$u" ]] && _ADMIN_USER="$u"
    read -r -s -p "  Password: " _ADMIN_PW </dev/tty || return 1
    echo >&2
    code="$(_admin_probe)"
    if [[ "$code" == "200" ]]; then
      # Must be an admin, not just any user
      if admin_curl --max-time 15 https://127.0.0.1/api/v1/auth/me 2>/dev/null | grep -q '"role": *"admin"'; then
        return 0
      fi
      echo "  ${_ADMIN_USER} is not an admin." >&2
    elif [[ "$code" == "403" ]]; then
      echo "  ${_ADMIN_USER} must change their password in the console first." >&2
    else
      echo "  Not accepted (HTTP $code). Too many failures lock the account for a while." >&2
    fi
  done
  _ADMIN_PW=""
  return 1
}

admin_logout() { _ADMIN_PW=""; _ADMIN_USER=""; }
