-- ===========================================================================
-- PATCH-01 : schema 023 - module access per user, and CVE impact analysis
--
-- Applied after 022. Idempotent.
--
-- 1. Each user may open some of the console's three modules:
--      patch       Patch Dashboard (servers, advisories, changes, hardening)
--      inventory   Asset & Inventory (assets, software, VMware)
--      lifecycle   Software Lifecycle (installers, software changes)
--    Admins always have all three. Existing users keep all three, so nobody
--    loses access when this is applied; an admin narrows it under Admin > Access.
--    The API enforces it on every request, not only the console.
--
-- 2. cve_impact: for each new critical, high or exploited CVE from the feeds,
--    where it matches the software and hardware inventory, with how sure,
--    and AI-01's brief.
-- ===========================================================================

ALTER TABLE users ADD COLUMN IF NOT EXISTS modules TEXT[] NOT NULL
    DEFAULT ARRAY['patch', 'inventory', 'lifecycle'];

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'users_modules_known') THEN
        ALTER TABLE users ADD CONSTRAINT users_modules_known
            CHECK (modules <@ ARRAY['patch', 'inventory', 'lifecycle']);
    END IF;
END $$;

-- The products NVD lists for a CVE (CPE names with version ranges), kept so
-- the impact analysis can compare versions without asking NVD again.
ALTER TABLE cve_feed_items ADD COLUMN IF NOT EXISTS cpes JSONB;

CREATE TABLE IF NOT EXISTS cve_impact (
    cve_id          TEXT PRIMARY KEY CHECK (cve_id ~ '^CVE-[0-9]{4}-[0-9]{4,7}$'),
    verdict         TEXT NOT NULL CHECK (verdict IN ('affected', 'potentially_affected', 'pending_reboot',
                                                     'patched', 'not_affected', 'not_found', 'not_tracked')),
    machines        INT NOT NULL DEFAULT 0,
    matches         JSONB NOT NULL DEFAULT '[]',
    title           TEXT,
    severity        TEXT,
    cvss            NUMERIC(3,1),
    exploited       BOOLEAN NOT NULL DEFAULT FALSE,
    sources         TEXT[] NOT NULL DEFAULT '{}',
    published       TIMESTAMPTZ,
    inventory_mark  TEXT,
    analysed_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    ai_summary      TEXT,
    ai_model        TEXT,
    ai_key          TEXT,
    ai_at           TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_cve_impact_verdict ON cve_impact (verdict, cvss DESC);

ALTER TABLE cve_feed_settings ADD COLUMN IF NOT EXISTS impact_requested_at TIMESTAMPTZ;

INSERT INTO schema_version (version, description)
VALUES (23, 'Module access per user; CVE impact analysis against the inventory')
ON CONFLICT (version) DO NOTHING;
