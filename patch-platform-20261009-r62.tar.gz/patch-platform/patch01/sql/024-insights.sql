-- ===========================================================================
-- PATCH-01 : schema 024 - AI-01's regular analysis of the fleet
--
-- Applied after 023. Idempotent.
--
-- Every 15 minutes the worker gathers the facts about the servers (agent
-- states, patch backlog, reboots, impacted CVEs, what changed since the last
-- time) and AI-01 writes a short analysis from them. The facts are stored with
-- the text, so every sentence can be checked against the figures it came from.
-- One day is kept.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS ai_insights (
    id          BIGSERIAL PRIMARY KEY,
    scope       TEXT NOT NULL CHECK (scope IN ('servers')),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    facts       JSONB NOT NULL,
    text        TEXT NOT NULL,
    source      TEXT NOT NULL CHECK (source IN ('ai', 'facts')),
    model       TEXT,
    duration_ms INT
);
CREATE INDEX IF NOT EXISTS idx_ai_insights_scope ON ai_insights (scope, created_at DESC);

INSERT INTO schema_version (version, description)
VALUES (24, 'AI-01 analysis of the fleet every 15 minutes')
ON CONFLICT (version) DO NOTHING;
