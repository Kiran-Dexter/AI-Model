-- ===========================================================================
-- PATCH-01 : schema 028 - pinning an antivirus console's own certificate
--
-- Applied after 027. Idempotent.
--
-- Apex Central often runs with a self-signed IIS certificate that names the
-- server differently from the address used, so normal verification fails.
-- Instead of turning verification off, the admin fetches the certificate,
-- compares its fingerprint with the one on the Apex Central server, and
-- trusts that exact certificate: every connection then checks the SHA-256
-- fingerprint before sending anything, and stops if the certificate changes.
-- ===========================================================================

ALTER TABLE av_consoles ADD COLUMN IF NOT EXISTS pin_sha256    TEXT CHECK (pin_sha256 ~ '^[0-9a-f]{64}$');
ALTER TABLE av_consoles ADD COLUMN IF NOT EXISTS pin_subject   TEXT;
ALTER TABLE av_consoles ADD COLUMN IF NOT EXISTS pin_not_after TIMESTAMPTZ;
ALTER TABLE av_consoles ADD COLUMN IF NOT EXISTS pinned_by     TEXT;
ALTER TABLE av_consoles ADD COLUMN IF NOT EXISTS pinned_at     TIMESTAMPTZ;

INSERT INTO schema_version (version, description)
VALUES (28, 'Antivirus consoles: trust a self-signed certificate by its fingerprint')
ON CONFLICT (version) DO NOTHING;
