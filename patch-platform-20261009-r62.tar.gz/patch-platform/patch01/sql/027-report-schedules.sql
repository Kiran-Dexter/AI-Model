-- ===========================================================================
-- PATCH-01 : schema 027 - reports by e-mail, on a schedule or at once
--
-- Applied after 026. Idempotent.
--
-- Any report the console can build on the server (Servers, Detected CVEs,
-- Advisories, Antivirus health, antivirus agents, machines without
-- antivirus, Activity) can be sent at once or on a schedule (daily, weekly
-- or monthly at a set time), as a PDF or CSV attachment inside the usual
-- branded mail. Recipients are always taken from Admin > Mail's recipient
-- list: a report can never be sent to an address outside it.
--
-- Antivirus health: definition versions, last-connected times and online
-- flags are kept when a console reports them (fields differ by Apex Central
-- version); the fields each console sends are recorded so the admin can see
-- what is available.
-- ===========================================================================

-- A queued mail can carry one attachment; it is dropped once the mail is sent
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS attachment_name TEXT;
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS attachment_mime TEXT;
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS attachment      BYTEA;

CREATE TABLE IF NOT EXISTS report_schedules (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name         TEXT NOT NULL,
    report       TEXT NOT NULL,                 -- a key of report_jobs.REPORTS
    format       TEXT NOT NULL DEFAULT 'pdf' CHECK (format IN ('pdf', 'csv')),
    frequency    TEXT NOT NULL DEFAULT 'daily' CHECK (frequency IN ('daily', 'weekly', 'monthly')),
    at_time      TEXT NOT NULL DEFAULT '08:00' CHECK (at_time ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'),
    weekday      TEXT NOT NULL DEFAULT 'mon' CHECK (weekday IN ('mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun')),
    monthday     INTEGER NOT NULL DEFAULT 1 CHECK (monthday BETWEEN 1 AND 28),
    recipients   TEXT[],                        -- NULL: the recipients ticked for the daily digest
    params       JSONB NOT NULL DEFAULT '{}'::jsonb,
    skip_empty   BOOLEAN NOT NULL DEFAULT false,  -- no mail when the report has no rows
    enabled      BOOLEAN NOT NULL DEFAULT true,
    builtin      BOOLEAN NOT NULL DEFAULT false,
    created_by   TEXT NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by   TEXT,
    updated_at   TIMESTAMPTZ,
    last_run_on  DATE,                          -- the local day it last ran
    last_run_at  TIMESTAMPTZ,
    last_ok      BOOLEAN,
    last_msg     TEXT,
    run_requested_at TIMESTAMPTZ
);

-- The daily antivirus mail, on by default (to the digest recipients)
INSERT INTO report_schedules (name, report, format, frequency, at_time, params, builtin, created_by)
SELECT 'Antivirus health, daily', 'av_health', 'pdf', 'daily', '08:00',
       '{"offline_hours": 24, "pattern_behind": 4}'::jsonb, true, 'system'
 WHERE NOT EXISTS (SELECT 1 FROM report_schedules WHERE builtin AND report = 'av_health');

-- What Apex Central reports beyond the documented agent fields, when it does
ALTER TABLE av_agents ADD COLUMN IF NOT EXISTS pattern_version TEXT;
ALTER TABLE av_agents ADD COLUMN IF NOT EXISTS last_connected  TIMESTAMPTZ;
ALTER TABLE av_agents ADD COLUMN IF NOT EXISTS online          BOOLEAN;
ALTER TABLE av_consoles ADD COLUMN IF NOT EXISTS fields_seen   TEXT[];

INSERT INTO schema_version (version, description)
VALUES (27, 'Reports by e-mail (scheduled or at once); antivirus health fields')
ON CONFLICT (version) DO NOTHING;
