-- ===========================================================================
-- PATCH-01 : schema 026 - antivirus consoles (Trend Micro Apex Central)
--
-- Applied after 025. Idempotent.
--
-- Each Apex Central console is added in Admin > Antivirus with its URL,
-- Application ID and API key. The key is encrypted with av.key (in the
-- secrets folder, never in the database's backups on its own) and is never
-- sent back to the browser. PATCH-01 only reads from Apex Central: it never
-- calls an action (isolate, uninstall, relocate).
--
-- The agents each console reports are kept in av_agents, refreshed every
-- hour and on "Sync now".
-- ===========================================================================

CREATE TABLE IF NOT EXISTS av_consoles (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name          TEXT NOT NULL UNIQUE,
    vendor        TEXT NOT NULL DEFAULT 'trendmicro_apex_central' CHECK (vendor IN ('trendmicro_apex_central')),
    url           TEXT NOT NULL,                  -- https://host[:port], no path
    app_id        TEXT NOT NULL,                  -- Apex Central "Application ID"
    api_key_enc   TEXT NOT NULL,                  -- Fernet token (av.key)
    ca_pem        TEXT,                           -- the console's CA certificate, when it is not publicly trusted
    use_proxy     BOOLEAN NOT NULL DEFAULT false, -- internal consoles are reached directly
    enabled       BOOLEAN NOT NULL DEFAULT true,
    created_by    TEXT NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by    TEXT,
    updated_at    TIMESTAMPTZ,
    last_test_at  TIMESTAMPTZ,
    last_test_ok  BOOLEAN,
    last_test_msg TEXT,
    last_sync_at  TIMESTAMPTZ,
    last_sync_ok  BOOLEAN,
    last_sync_msg TEXT,
    agents        INTEGER,
    sync_requested_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS av_agents (
    console_id         UUID NOT NULL REFERENCES av_consoles(id) ON DELETE CASCADE,
    entity_id          TEXT NOT NULL,
    product            TEXT,
    host_name          TEXT,
    ad_domain          TEXT,
    folder_path        TEXT,
    ip_addresses       TEXT[] NOT NULL DEFAULT '{}',
    mac_addresses      TEXT[] NOT NULL DEFAULT '{}',
    managing_server_id TEXT,
    isolation_status   TEXT,
    capabilities       TEXT[] NOT NULL DEFAULT '{}',
    first_seen         TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen          TIMESTAMPTZ NOT NULL DEFAULT now(),   -- last sync that listed it
    PRIMARY KEY (console_id, entity_id)
);
CREATE INDEX IF NOT EXISTS idx_av_agents_host ON av_agents (lower(host_name));

INSERT INTO schema_version (version, description)
VALUES (26, 'Antivirus consoles (Trend Micro Apex Central), read-only')
ON CONFLICT (version) DO NOTHING;
