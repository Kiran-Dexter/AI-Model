-- ===========================================================================
-- PATCH-01 : schema 025 - CVE matching that checks each machine's platform
--
-- Applied after 024. Idempotent.
--
-- A CVE is matched to a machine only when the machine's operating system is
-- one the vulnerable product runs on: a Windows-only CVE never lands on a Red
-- Hat server because a package there shares a name. Every match is tagged with
-- the machine's address, operating system and inventory sources, and the
-- machines that were considered but ruled out are kept with the reason, so an
-- answer can always be checked.
--
-- Red Hat's per-product state for a CVE (affected, not affected, fixed in a
-- given build for RHEL 8 or 9) is fetched once a day per CVE and cached here.
-- ===========================================================================

-- Red Hat: packages it shipped a fix in (products) vs components only named
-- in its description (components), which prove nothing on their own
ALTER TABLE cve_feed_items ADD COLUMN IF NOT EXISTS components TEXT[];

ALTER TABLE cve_impact ADD COLUMN IF NOT EXISTS platforms TEXT[];
ALTER TABLE cve_impact ADD COLUMN IF NOT EXISTS excluded  JSONB;

ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS platforms TEXT[];
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS excluded  JSONB;

-- Set when any machine's installed software changes (a version, not just a count),
-- so the impact analysis re-checks every CVE against what is installed now
ALTER TABLE cve_feed_settings ADD COLUMN IF NOT EXISTS inventory_changed_at TIMESTAMPTZ;

CREATE TABLE IF NOT EXISTS rh_cve_state (
    cve_id      TEXT PRIMARY KEY,
    fetched_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    found       BOOLEAN NOT NULL,                       -- Red Hat has a page for it
    states      JSONB NOT NULL DEFAULT '[]'::jsonb,     -- [{major, package, state}]
    fixed       JSONB NOT NULL DEFAULT '[]'::jsonb,     -- [{major, package, evr, advisory}]
    error       TEXT
);

INSERT INTO schema_version (version, description)
VALUES (25, 'CVE matching checks each machine''s platform; Red Hat per-product state')
ON CONFLICT (version) DO NOTHING;
