"""Branded exports: every CSV and Excel file the console produces carries the
portal's name, the organisation, when it was made, by whom, and what it was
filtered on; the Excel file carries the logo as well.

A CSV file is plain text and cannot hold a picture, so the logo is in the
Excel version; the CSV has the same heading lines as text, above the table.

Both are safe to open in a spreadsheet: CSV cells that would run as a
formula are neutralised, and the Excel file stores every value as a literal
(no formulas are ever written). The Excel file is built here with the
standard library (zip + XML), so nothing new has to be installed.
"""

import csv
import io
import re
import zipfile
from datetime import datetime, timedelta, timezone
from xml.sax.saxutils import escape

PORTAL = "Cyber-Secure"
TZ = timezone(timedelta(hours=8))           # the console's time zone, as the mails use
TZ_LABEL = "SGT"
_BAD_XML = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]")


def stamp(now=None):
    return (now or datetime.now(TZ)).astimezone(TZ).strftime("%d %b %Y %H:%M ") + TZ_LABEL


def meta(title, user, filters_text, n_rows, company=None, now=None):
    return {"title": f"{PORTAL} — {title}", "company": company or "", "generated": stamp(now),
            "by": user or "", "filter": filters_text or "", "rows": str(n_rows)}


def file_name(base, ext, now=None):
    t = (now or datetime.now(TZ)).astimezone(TZ).strftime("%Y%m%d-%H%M")
    return re.sub(r"[^A-Za-z0-9._-]+", "-", f"cyber-secure-{base}-{t}")[:90] + "." + ext


def company_name(conn):
    try:
        r = conn.execute("SELECT company FROM branding WHERE id = 1").fetchone()
        return ((r or {}).get("company") or "").strip()
    except Exception:  # noqa: BLE001 - older schema
        return ""


# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------

def safe_cell(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "yes" if v else "no"
    if isinstance(v, (list, tuple)):
        v = ", ".join(str(x) for x in v)
    s = _BAD_XML.sub(" ", str(v))
    if s[:1] in ("=", "+", "-", "@", "\t", "\r"):
        s = "'" + s                           # a spreadsheet would run it as a formula
    return s


def header_lines(m):
    lines = [[m["title"]]]
    if m.get("company"):
        lines.append(["Organisation", m["company"]])
    lines += [["Generated", m["generated"]], ["By", m["by"]], ["Filter", m["filter"]], ["Rows", str(m["rows"])], []]
    return lines


def csv_text(m, headers, rows):
    """The heading lines, a blank line, then the table. UTF-8 with a BOM so
    Excel reads accents correctly."""
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    for line in header_lines(m):
        w.writerow([safe_cell(x) for x in line])
    w.writerow([safe_cell(x) for x in headers])
    for r in rows:
        w.writerow([safe_cell(x) for x in r])
    return "﻿" + buf.getvalue()


# ---------------------------------------------------------------------------
# Excel (.xlsx), with the logo
# ---------------------------------------------------------------------------

def _col(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _x(v):
    return escape(_BAD_XML.sub(" ", str(v)), {'"': "&quot;"})


def _cell(ref, v, style=0):
    st = f' s="{style}"' if style else ""
    if isinstance(v, bool):
        v = "yes" if v else "no"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return f'<c r="{ref}"{st}><v>{v}</v></c>'
    if v is None or v == "":
        return f'<c r="{ref}"{st}/>' if style else ""
    return f'<c r="{ref}"{st} t="inlineStr"><is><t xml:space="preserve">{_x(v)[:32000]}</t></is></c>'


def _png_size(data):
    if data and data[:8] == b"\x89PNG\r\n\x1a\n" and len(data) > 24:
        return int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")
    return None


STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="4"><font><sz val="10"/><name val="Calibri"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
<font><b/><sz val="15"/><color rgb="FF0B1F3A"/><name val="Calibri"/></font><font><sz val="10"/><color rgb="FF555F66"/><name val="Calibri"/></font></fonts>
<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF0B1F3A"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="2"><border/><border><bottom style="thin"><color rgb="FFC9D1D6"/></bottom></border></borders>
<cellStyleXfs count="1"><xf/></cellStyleXfs>
<cellXfs count="5"><xf/><xf fontId="1" fillId="2" applyFont="1" applyFill="1"/><xf fontId="2" applyFont="1"/>
<xf fontId="3" applyFont="1"/><xf borderId="1" applyBorder="1"/></cellXfs>
</styleSheet>"""


def xlsx_bytes(m, headers, rows, logo_png=None, sheet="Report"):
    """One worksheet: logo, heading lines, then the table with a filter and
    the heading row frozen."""
    size = _png_size(logo_png) if logo_png else None
    lines = []                                # (row number, [cells])
    r = 1
    if size:
        r = 5                                 # the logo sits over rows 1 to 4
    lines.append((r, [_cell(f"A{r}", m["title"], 2)])); r += 1
    for k, label in (("company", "Organisation"), ("generated", "Generated"), ("by", "By"),
                     ("filter", "Filter"), ("rows", "Rows")):
        if k == "company" and not m.get(k):
            continue
        lines.append((r, [_cell(f"A{r}", label, 3), _cell(f"B{r}", m[k], 3)])); r += 1
    r += 1
    head_row = r
    lines.append((r, [_cell(f"{_col(i)}{r}", h, 1) for i, h in enumerate(headers)])); r += 1
    for row in rows:
        lines.append((r, [_cell(f"{_col(i)}{r}", v, 4) for i, v in enumerate(row)])); r += 1
    last = r - 1
    widths = []
    for i, h in enumerate(headers):
        longest = max([len(str(h))] + [len(str(x[i])) for x in rows[:500] if i < len(x) and x[i] is not None])
        widths.append(min(60, max(10, longest + 2)))
    cols = "".join(f'<col min="{i + 1}" max="{i + 1}" width="{w}" customWidth="1"/>' for i, w in enumerate(widths))
    sheet_rows = "".join(f'<row r="{n}">{"".join(c)}</row>' for n, c in lines)
    end_col = _col(max(0, len(headers) - 1))
    sheet_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f'<sheetViews><sheetView workbookViewId="0"><pane ySplit="{head_row}" topLeftCell="A{head_row + 1}" '
        'activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
        f'<cols>{cols}</cols><sheetData>{sheet_rows}</sheetData>'
        + (f'<autoFilter ref="A{head_row}:{end_col}{max(head_row, last)}"/>' if headers else "")
        + ('<drawing r:id="rId1"/>' if size else "") + '</worksheet>')
    files = {
        "[Content_Types].xml": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Default Extension="png" ContentType="image/png"/>'
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            + ('<Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>' if size else "")
            + '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
            '</Types>'),
        "_rels/.rels": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
            '</Relationships>'),
        "docProps/core.xml": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            f'<dc:title>{_x(m["title"])}</dc:title><dc:creator>{_x(PORTAL)}</dc:creator>'
            f'<dcterms:created xsi:type="dcterms:W3CDTF">{datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}</dcterms:created>'
            '</cp:coreProperties>'),
        "xl/workbook.xml": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            f'<sheets><sheet name="{_x(sheet[:31])}" sheetId="1" r:id="rId1"/></sheets>'
            + (f'<definedNames><definedName name="_xlnm._FilterDatabase" localSheetId="0" hidden="1">'
               f"'{_x(sheet[:31])}'!$A${head_row}:${end_col}${max(head_row, last)}</definedName></definedNames>" if headers else "")
            + '</workbook>'),
        "xl/_rels/workbook.xml.rels": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            '</Relationships>'),
        "xl/styles.xml": STYLES,
        "xl/worksheets/sheet1.xml": sheet_xml,
    }
    if size:
        w, h = size
        target_h = 64                         # pixels: about four rows
        target_w = max(1, round(w * target_h / max(1, h)))
        if target_w > 320:
            target_w, target_h = 320, max(1, round(h * 320 / w))
        emu = 9525
        files["xl/worksheets/_rels/sheet1.xml.rels"] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/>'
            '</Relationships>')
        files["xl/drawings/drawing1.xml"] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" '
            'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<xdr:oneCellAnchor><xdr:from><xdr:col>0</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>0</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>'
            f'<xdr:ext cx="{target_w * emu}" cy="{target_h * emu}"/>'
            '<xdr:pic><xdr:nvPicPr><xdr:cNvPr id="2" name="Logo"/><xdr:cNvPicPr><a:picLocks noChangeAspect="1"/></xdr:cNvPicPr></xdr:nvPicPr>'
            '<xdr:blipFill><a:blip r:embed="rId1"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill>'
            f'<xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{target_w * emu}" cy="{target_h * emu}"/></a:xfrm>'
            '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor></xdr:wsDr>')
        files["xl/drawings/_rels/drawing1.xml.rels"] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image1.png"/>'
            '</Relationships>')
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name, text in files.items():
            z.writestr(name, text.encode("utf-8"))
        if size:
            z.writestr("xl/media/image1.png", logo_png)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# PDF, with the logo: a report of one table
# ---------------------------------------------------------------------------

def _col_widths(headers, sample, usable):
    """Column widths for the PDF table, measured in the fonts used.

    Every column gets at least the width of its longest single word (so an
    ID such as CVE-2026-60001 or a heading such as CVSS never breaks across
    lines); the space left is shared in proportion to how much more each
    column would like, so long text columns take the slack."""
    from reportlab.pdfbase.pdfmetrics import stringWidth
    pad = 7.0
    def words(v):
        return str(v).split() if v not in (None, "") else []
    mins, wants = [], []
    for i, hd in enumerate(headers):
        vals = [r[i] for r in sample if i < len(r) and r[i] not in (None, "")]
        head_w = max([stringWidth(w, "Helvetica-Bold", 7.4) for w in words(hd)] or [10])
        word_w = max([stringWidth(w[:40], "Helvetica", 7.4) for v in vals for w in words(v)] or [0])
        full_w = max([stringWidth(str(v)[:160], "Helvetica", 7.4) for v in vals] or [0])
        lo = min(max(head_w, word_w) + pad, usable * 0.22)
        mins.append(lo)
        wants.append(max(lo, min(full_w + pad, usable * 0.45)))
    total_min = sum(mins)
    if total_min >= usable:
        return [usable * m / total_min for m in mins]
    extra = sum(w - m for w, m in zip(wants, mins))
    left = usable - total_min
    if extra <= 0:
        return [m + left / len(mins) for m in mins]
    if extra <= left:          # everything fits on one line; share what remains evenly
        return [w + (left - extra) / len(mins) for w in wants]
    return [m + left * (w - m) / extra for w, m in zip(wants, mins)]


def pdf_bytes(m, headers, rows, logo_png=None, classification="CONFIDENTIAL", accent="#0B1F3A"):
    """A landscape A4 report: logo, title, the heading facts, then the table
    (heading row repeated on every page), page numbers and the stamp in the
    footer. Every value is drawn as plain text: nothing from the data is ever
    read as markup."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import Image, LongTable, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    page_w, page_h = landscape(A4)
    margin = 12 * mm
    usable = page_w - 2 * margin
    try:
        accent_c = colors.HexColor(accent)
    except ValueError:
        accent_c = colors.HexColor("#0B1F3A")
    cell = ParagraphStyle("cell", fontName="Helvetica", fontSize=7.4, leading=9)
    head = ParagraphStyle("head", parent=cell, fontName="Helvetica-Bold", textColor=colors.white)
    title = ParagraphStyle("title", fontName="Helvetica-Bold", fontSize=15, leading=18, textColor=accent_c)
    small = ParagraphStyle("small", fontName="Helvetica", fontSize=8, leading=10, textColor=colors.HexColor("#4A5963"))

    def p(text, style):
        return Paragraph(escape(_BAD_XML.sub(" ", "" if text is None else str(text)))[:3000], style)

    story = []
    size = _png_size(logo_png) if logo_png else None
    if size:
        w, h = size
        lh = 14 * mm
        lw = min(70 * mm, w * lh / max(1, h))
        lh = h * lw / max(1, w)
        story += [Image(io.BytesIO(logo_png), width=lw, height=lh, hAlign="LEFT"), Spacer(1, 3 * mm)]
    story.append(p(m["title"], title))
    facts = [(k, m.get(key)) for k, key in (("Organisation", "company"), ("Generated", "generated"), ("By", "by"),
                                            ("Filter", "filter"), ("Rows", "rows")) if m.get(key)]
    if facts:
        ft = Table([[p(k, small), p(v, small)] for k, v in facts], colWidths=[28 * mm, usable - 28 * mm], hAlign="LEFT")
        ft.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0), ("TOPPADDING", (0, 0), (-1, -1), 0.5),
                                ("BOTTOMPADDING", (0, 0), (-1, -1), 0.5)]))
        story += [Spacer(1, 2 * mm), ft]
    story.append(Spacer(1, 5 * mm))
    if headers:
        widths = _col_widths(headers, rows[:300], usable)
        data = [[p(hd, head) for hd in headers]] + [[p(r[i] if i < len(r) else "", cell) for i in range(len(headers))]
                                                    for r in rows]
        t = LongTable(data, colWidths=widths, repeatRows=1)
        style = [("BACKGROUND", (0, 0), (-1, 0), accent_c), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                 ("LINEBELOW", (0, 0), (-1, -1), 0.25, colors.HexColor("#C9D1D6")),
                 ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3),
                 ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]
        for i in range(1, len(data)):
            if i % 2 == 0:
                style.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor("#F3F5F7")))
        t.setStyle(TableStyle(style))
        story.append(t)
    if not rows:
        story.append(p("No rows for this selection.", small))

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.HexColor("#4A5963"))
        left = f"{PORTAL} · {m.get('company') or ''} · generated {m.get('generated')} by {m.get('by')}".replace(" ·  ·", " ·")
        canvas.drawString(margin, 7 * mm, left[:150])
        canvas.drawRightString(page_w - margin, 7 * mm, f"{classification}   Page {doc.page}")
        canvas.setStrokeColor(accent_c)
        canvas.setLineWidth(0.6)
        canvas.line(margin, 10 * mm, page_w - margin, 10 * mm)
        canvas.restoreState()

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=margin, rightMargin=margin,
                            topMargin=margin, bottomMargin=15 * mm, title=m["title"], author=PORTAL)
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return buf.getvalue()


def brand_bits(conn):
    """Logo, classification and colour for a report, from the branding settings."""
    try:
        from . import branding as br
        b = br.settings(conn)
        return b.get("logo"), b.get("classification") or "CONFIDENTIAL", b.get("accent") or "#0B1F3A"
    except Exception:  # noqa: BLE001 - a report without the logo is still a report
        return None, "CONFIDENTIAL", "#0B1F3A"


def render(fmt, m, headers, rows, conn):
    """(bytes, media type, file extension) for csv, pdf or xlsx."""
    if fmt == "csv":
        return csv_text(m, headers, rows).encode("utf-8"), "text/csv; charset=utf-8", "csv"
    logo, cls, accent = brand_bits(conn)
    if fmt == "xlsx":
        return xlsx_bytes(m, headers, rows, logo), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx"
    return pdf_bytes(m, headers, rows, logo, cls, accent), "application/pdf", "pdf"
