"""Impacted CVEs: which new CVEs from the feeds touch our own machines.

For every critical, high or exploited ("0-day") CVE the feeds collected in
the dashboard's window, the worker looks for the affected products in the
software and hardware inventory:

  confirmed       the CVE engine's package check says a server is affected
  in_range        an installed version lies inside NVD's affected range
                  (Windows programs, ESXi, vCenter)
  release_match   the release matches but the exact build cannot be compared
  present         the product is installed or the OS matches; no version data
                  can decide (Windows editions, Red Hat components)
  not_tracked     a product PATCH-01 does not inventory (network gear)

and gives one verdict per CVE: affected, potentially affected, not found or
not tracked. Products come from NVD's CPE list (NIST items), Microsoft's
product names (MSRC items) and Red Hat's component names.

AI-01 then writes a short brief for the impacted ones, most serious first,
from the same facts the console shows. It never decides the verdict.

The analysis repeats when the inventory changes, and at least daily.
"""

import hashlib
import json
import logging
import re
from datetime import timedelta
from functools import cmp_to_key

log = logging.getLogger("patchapi.cve_impact")

BATCH = 150
RULES = "platform-2"        # changing it re-analyses every CVE with the current rules
AI_PER_PASS = 2
REANALYSE_HOURS = 24
STRONG = ("confirmed", "in_range")
WEAK = ("release_match", "present")

WIN_OS_RE = re.compile(r"windows (server )?(2008|2012|2016|2019|2022|2025|10|11|7|8\.1)( r2)?", re.I)
MS_NOISE = re.compile(r"\b(microsoft|for x64-based systems|for x86-based systems|for 32-bit systems|"
                      r"for arm64-based systems|\(server core installation\)|version \w+|\d{2}h\d|"
                      r"64-bit editions?|32-bit editions?|service pack \d|sp\d)\b", re.I)
STOP = {"the", "and", "for", "of", "server", "edition", "editions", "systems", "version", "based"}


# ---------------------------------------------------------------------------
# Inventory fingerprint: when it changes, everything is analysed again
# ---------------------------------------------------------------------------

def inventory_changed(conn):
    """Called when a machine's installed software really changed."""
    try:
        with conn.transaction():
            conn.execute("UPDATE cve_feed_settings SET inventory_changed_at = now() WHERE id = 1")
    except Exception:  # noqa: BLE001 - schema 025 not applied yet; the daily re-analysis still runs
        pass


def inventory_mark(conn):
    """Changes when machines, their OS or their installed versions change, not
    on every check-in (which would make every pass start again from the top)."""
    # Versions, not only counts: a package or program updated in place (curl -29 to -30,
    # Chrome 129 to 130) and an OS upgraded (Windows 10 to 11) change the mark too
    r = conn.execute(
        """SELECT (SELECT md5(coalesce(string_agg(hostname || '|' || coalesce(os_id, '') || '|' || coalesce(os_version, '')
                                                 || '|' || coalesce(os_edition, ''), ',' ORDER BY id), ''))
                     FROM hosts WHERE status <> 'decommissioned') AS h,
                  (SELECT count(*) FROM windows_software) AS w,
                  (SELECT count(*) FROM host_packages) AS p,
                  (SELECT count(*) FROM host_applicability WHERE state IN ('affected', 'fixed_pending_reboot')) AS a,
                  (SELECT count(*) || ':' || string_agg(DISTINCT coalesce(esxi_build, ''), ',') FROM esxi_hosts) AS e,
                  (SELECT md5(coalesce(string_agg(name || '|' || coalesce(os, ''), ',' ORDER BY name), '')) FROM wsus_computers) AS u,
                  (SELECT md5(coalesce(string_agg(name || '|' || coalesce(guest_os, '') || '|' || coalesce(guest_hostname, ''),
                                                  ',' ORDER BY name), '')) FROM vm_inventory) AS v""").fetchone()
    r = dict(r)
    try:
        with conn.transaction():
            c = conn.execute("SELECT inventory_changed_at FROM cve_feed_settings WHERE id = 1").fetchone()
        r["changed"] = c and c["inventory_changed_at"]
    except Exception:  # noqa: BLE001 - schema 025 not applied yet
        pass
    return hashlib.sha256(json.dumps([RULES, r], default=str, sort_keys=True).encode()).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Matching (each returns match dicts like exposure.find_in_inventory)
# ---------------------------------------------------------------------------

MAX_PRODUCTS = 30


class Inventory:
    """The parts of the inventory every CVE is compared with, read once per pass."""

    def __init__(self, conn):
        self.conn = conn
        self._win_sw = self._win_os = self._esxi = self._assets = None

    def win_software(self):
        if self._win_sw is None:
            self._win_sw = [dict(r) for r in self.conn.execute(
                """SELECT h.hostname, ws.name, ws.version
                     FROM windows_software ws JOIN hosts h ON h.id = ws.host_id AND h.status <> 'decommissioned'""").fetchall()]
        return self._win_sw

    def win_os(self):
        if self._win_os is None:
            self._win_os = [dict(r) for r in self.conn.execute(
                """SELECT hostname AS name, coalesce(os_edition, 'Windows') AS os, 'Windows server (agent)' AS where_
                     FROM hosts WHERE os_id = 'windows' AND status <> 'decommissioned'
                   UNION ALL SELECT name, os, 'WSUS computer' FROM wsus_computers
                   UNION ALL SELECT name, guest_os, 'VM guest OS' FROM vm_inventory
                    WHERE guest_os ILIKE '%windows%'""").fetchall()]
        return self._win_os

    def assets(self):
        """Every machine we know, from every source, by short name:
        {name, fqdn, ips, os, family, distro, major, sources}. The agent's own
        report of its OS wins over WSUS, and WSUS over the vCenter guest."""
        if self._assets is None:
            self._assets = build_assets(self.conn)
        return self._assets

    def esxi(self):
        if self._esxi is None:
            self._esxi = [dict(r) for r in self.conn.execute(
                "SELECT name, vcenter, vendor, model FROM esxi_hosts").fetchall()]
        return self._esxi


def _words(text):
    return [w for w in re.findall(r"[a-z0-9][a-z0-9.+#-]*", (text or "").lower()) if w not in STOP]


def _norm_os(text):
    """'Microsoft Windows Server 2019 Datacenter' -> 'windows server 2019'."""
    m = WIN_OS_RE.search(text or "")
    if not m:
        return None
    return ("windows " + ("server " if m.group(1) else "") + m.group(2) + (" r2" if m.group(3) else "")).lower()


def match_windows_os(inv, os_label, product):
    """Windows servers (agents), WSUS computers and VM guests running this OS."""
    out, seen = [], set()
    for r in inv.win_os():
        if _norm_os(r["os"]) != os_label:
            continue
        key = (r["name"] or "").lower().split(".")[0]
        if key in seen:
            continue
        seen.add(key)
        out.append({"product": product, "kind": "Operating system", "where": r["where_"], "name": r["name"],
                    "version": r["os"], "certainty": "present",
                    "detail": "the Windows version matches; whether this month's update is installed is shown "
                              "by the server's missing updates"})
        if len(out) >= 200:
            break
    return out


def match_windows_software(inv, product, ranges=None):
    """Windows programs whose name contains every significant word of the
    product name ('google chrome' matches 'Google Chrome')."""
    from . import exposure
    if not isinstance(product, str):
        return []
    words = _words(MS_NOISE.sub(" ", re.sub(r"\([^)]*\)", " ", product)))[:4]
    if not words or (len(words) == 1 and len(words[0]) < 4):
        return []
    pats = [re.compile(r"(^|[^a-z0-9])" + re.escape(w) + r"($|[^a-z0-9])") for w in words]
    rows, seen = [], set()
    for r in inv.win_software():
        name = (r["name"] or "").lower()
        if all(p.search(name) for p in pats) and (r["hostname"], r["name"]) not in seen:
            seen.add((r["hostname"], r["name"]))
            rows.append(r)
            if len(rows) >= 200:
                break
    out = []
    for r in rows:
        cert, why = ("present", "installed; no affected version range to compare")
        if ranges:
            cert, why = exposure.match_versioned(r["version"] or "", ranges)
            if cert == "outside":
                continue
        out.append({"product": product, "kind": "Application", "where": "Windows server", "name": r["hostname"],
                    "version": f"{r['name']} {r['version'] or ''}".strip(), "certainty": cert, "detail": why})
    return out


def match_hardware(inv, vendor, product):
    """ESXi hosts whose server model matches a hardware CPE."""
    want = re.sub(r"[^a-z0-9]", "", str(product or "").lower())
    if len(want) < 4:
        return []
    out = []
    for r in inv.esxi():
        model = re.sub(r"[^a-z0-9]", "", (r["model"] or "").lower())
        if model and (want in model or model in want):
            out.append({"product": f"{vendor} {product}".replace("_", " "), "kind": "Hardware or firmware",
                        "where": "Server hardware (ESXi host)", "name": r["name"],
                        "version": f"{r['vendor'] or ''} {r['model'] or ''}".strip(), "certainty": "present",
                        "detail": "the server model matches; firmware versions are not inventoried"})
    return out


def match_linux_packages(conn, names):
    from . import exposure
    pkgs = set()
    for n in names:
        if not isinstance(n, str):
            continue
        n = n.lower().strip()
        if re.fullmatch(r"[a-z0-9][a-z0-9._+-]{1,60}", n):
            pkgs.add(n)
            pkgs.update(exposure.PACKAGE_ALIASES.get(n, []))
    if not pkgs:
        return []
    rows = conn.execute(
        """SELECT DISTINCT ON (h.hostname) h.hostname, hp.name, hp.version, hp.release
             FROM host_packages hp JOIN hosts h ON h.id = hp.host_id AND h.status <> 'decommissioned'
            WHERE hp.name = ANY(%s) ORDER BY h.hostname LIMIT 200""", (sorted(pkgs),)).fetchall()
    return [{"product": r["name"], "kind": "Application", "where": "Linux server", "name": r["hostname"],
             "version": f"{r['name']} {r['version']}-{r['release']}" if r["release"] else f"{r['name']} {r['version']}",
             "certainty": "present",
             "detail": "installed; the vendor advisory decides whether this build is fixed"} for r in rows]


def match_confirmed(conn, cve_id):
    rows = conn.execute(
        """SELECT DISTINCT h.hostname, ha.state::text AS state, ha.package_name, ha.installed_evr, ha.fixed_evr
             FROM advisory_cves ac
             JOIN host_applicability ha ON ha.advisory_id = ac.advisory_id
             JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'
            WHERE ac.cve_id = %s AND ha.state IN ('affected', 'fixed_pending_reboot')
            LIMIT 200""", (cve_id,)).fetchall()
    return [{"product": r["package_name"], "kind": "Application", "where": "Linux server", "name": r["hostname"],
             "version": r["installed_evr"],
             "certainty": "confirmed" if r["state"] == "affected" else "pending_reboot",
             "detail": ("the vendor's fix " + (r["fixed_evr"] or "") + " is not installed") if r["state"] == "affected"
                       else "the fix is installed; a reboot is needed to run it"} for r in rows]


# ---------------------------------------------------------------------------
# Assets: one record per machine, merged from every inventory source
# ---------------------------------------------------------------------------

RPM_DISTROS = {"rhel", "ol", "centos", "rocky", "almalinux", "alma"}       # rebuilds of RHEL: Red Hat's data applies
LINUX_IDS = RPM_DISTROS | {"fedora", "ubuntu", "debian", "sles", "sled", "opensuse", "amzn", "linux"}
DISTRO_NAMES = {"rhel": "RHEL", "ol": "Oracle Linux", "centos": "CentOS", "rocky": "Rocky Linux",
                "almalinux": "AlmaLinux", "alma": "AlmaLinux", "fedora": "Fedora", "ubuntu": "Ubuntu",
                "debian": "Debian", "sles": "SUSE Linux", "sled": "SUSE Linux", "opensuse": "openSUSE",
                "amzn": "Amazon Linux"}
GUEST_DISTROS = ((re.compile(r"red hat enterprise linux|\brhel\b", re.I), "rhel"),
                 (re.compile(r"oracle linux", re.I), "ol"), (re.compile(r"rocky", re.I), "rocky"),
                 (re.compile(r"alma", re.I), "almalinux"), (re.compile(r"centos", re.I), "centos"),
                 (re.compile(r"fedora", re.I), "fedora"), (re.compile(r"ubuntu", re.I), "ubuntu"),
                 (re.compile(r"debian", re.I), "debian"), (re.compile(r"suse", re.I), "sles"))
SOURCE_RANK = {"agent": 3, "ESXi host": 3, "vCenter": 3, "WSUS": 2, "vCenter guest": 1}
WHERE_SOURCE = {"Linux server": "agent", "Windows server": "agent", "Windows server (agent)": "agent",
                "WSUS computer": "WSUS", "VM guest OS": "vCenter guest", "ESXi host": "ESXi host",
                "Server hardware (ESXi host)": "ESXi host", "vCenter": "vCenter"}
JUNK_NAMES = {"", "localhost", "localhost.localdomain", "localdomain", "unknown", "none"}
IP_RE = re.compile(r"^(\d{1,3}(\.\d{1,3}){3}|[0-9a-f:]{3,39})$", re.I)


def short(name):
    """'srv-01.corp.example' -> 'srv-01'; an address stays whole."""
    n = str(name or "").strip().lower().strip(".")
    if IP_RE.match(n):
        return n
    return n.split(".")[0]


def _linux_id(oid):
    oid = (oid or "").lower()
    if oid in LINUX_IDS:
        return oid
    for p in ("opensuse", "sles", "sled", "rhel", "ol", "rocky", "alma", "centos", "ubuntu", "debian", "amzn", "fedora"):
        if oid.startswith(p):
            return {"alma": "almalinux"}.get(p, p)
    return None


def _guest(os_text, family_hint=None, is_linux=None):
    t = os_text or ""
    if re.search(r"windows", t, re.I) or str(family_hint or "").lower().startswith("windows"):
        return "windows", None, None
    if is_linux or re.search(r"linux|ubuntu|debian|centos|rhel|suse|fedora", t, re.I) \
            or str(family_hint or "").lower().startswith("linux"):
        distro = next((d for rx, d in GUEST_DISTROS if rx.search(t)), None)
        m = re.search(r"\b(\d{1,2})(?:\.\d+)*\b(?!-bit)", t)
        return "linux", distro, (int(m.group(1)) if m and distro else None)
    return "unknown", None, None


class Assets:
    """Every machine we know, one record each, merged across the inventory
    sources only on evidence: the same full name, a shared address, or the
    same short name when that is unambiguous and the systems agree. Two
    machines with the same short name in different domains stay apart."""

    def __init__(self):
        self.items = []
        self.by_fqdn, self.by_short, self.by_ip = {}, {}, {}

    def _find(self, fqdn, sn, ips, family):
        if fqdn and fqdn in self.by_fqdn:
            return self.by_fqdn[fqdn]
        for ip in ips:
            if ip in self.by_ip:
                return self.by_ip[ip]
        cands = [a for a in self.by_short.get(sn, [])
                 if not (fqdn and a["fqdn"] and a["fqdn"] != fqdn)                 # different domains
                 and (family == "unknown" or a["family"] in ("unknown", family))]  # systems agree
        return cands[0] if len(cands) == 1 else None

    def add(self, name, src, family, os_label, ips=(), distro=None, major=None, extra=None):
        raw = str(name or "").strip().strip(".")
        if raw.lower() in JUNK_NAMES:
            return None
        fqdn = raw.lower() if "." in raw and not IP_RE.match(raw) else None
        sn = short(raw)
        if not sn:
            return None
        ips = [i for i in (str(x or "").strip() for x in ips or ())
               if IP_RE.match(i) and not i.startswith(("127.", "169.254.", "fe80")) and i != "::1"][:4]
        a = self._find(fqdn, sn, ips, family)
        if a is None:
            a = {"name": raw, "fqdn": fqdn, "ips": [], "os": None, "family": "unknown", "distro": None,
                 "major": None, "sources": [], "_rank": -1, "conflict": None}
            self.items.append(a)
            self.by_short.setdefault(sn, []).append(a)
        if src not in a["sources"]:
            a["sources"].append(src)
        if fqdn and not a["fqdn"]:
            a["fqdn"] = fqdn
        if fqdn:
            self.by_fqdn.setdefault(fqdn, a)
        for ip in ips:
            if ip not in a["ips"] and len(a["ips"]) < 4:
                a["ips"].append(ip)
            self.by_ip.setdefault(ip, a)
        if extra:
            a.update(extra)                  # what each source knows of the machine (seen, power)
        rank = SOURCE_RANK.get(src, 0)
        if family != "unknown" and a["family"] not in ("unknown", family):
            if rank <= a["_rank"]:
                a["conflict"] = f"{src} reports {os_label}"           # the better source is kept
                return a
            a["conflict"] = f"{', '.join(s for s in a['sources'] if s != src)} reported {a['os']}"
        if rank > a["_rank"] and (family != "unknown" or a["os"] is None):
            a.update(family=family, os=os_label or a["os"], distro=distro, major=major, _rank=rank)
            if src == "agent":
                a["name"] = raw
        return a

    def lookup(self, name, where=None):
        """The machine a match names. When a short name is shared, the one
        known from the match's own source is taken; still ambiguous: None."""
        raw = str(name or "").strip().strip(".").lower()
        if not raw:
            return None
        if raw in self.by_fqdn:
            return self.by_fqdn[raw]
        if raw in self.by_ip:
            return self.by_ip[raw]
        cands = self.by_short.get(short(raw), [])
        if len(cands) > 1 and where in WHERE_SOURCE:
            cands = [a for a in cands if WHERE_SOURCE[where] in a["sources"]] or cands
        return cands[0] if len(cands) == 1 else None


def build_assets(conn):
    out = Assets()
    for r in conn.execute(
            """SELECT hostname, fqdn, host(agent_ip) AS ip, os_id, os_version, os_major, os_edition,
                      agent_state(last_checkin, status) AS agent, last_checkin
                 FROM hosts WHERE status <> 'decommissioned'""").fetchall():
        oid, lid = (r["os_id"] or "").lower(), _linux_id(r["os_id"])
        if oid == "windows":
            fam, label, distro = "windows", r["os_edition"] or ("Windows " + (r["os_version"] or "")).strip(), None
        elif lid:
            fam, distro = "linux", lid
            label = f"{DISTRO_NAMES.get(lid, r['os_id'])} {r['os_version'] or ''}".strip()
        else:
            fam, distro = "unknown", None
            label = r["os_edition"] or " ".join(x for x in (r["os_id"], r["os_version"]) if x) or None
        a = out.add(r["fqdn"] or r["hostname"], "agent", fam, label, [r["ip"]], distro, r["os_major"],
                    {"agent": r["agent"], "agent_seen": r["last_checkin"]})
        if a and r["fqdn"] and r["hostname"] and short(r["hostname"]) != short(r["fqdn"]):
            out.by_short.setdefault(short(r["hostname"]), []).append(a)
        if a:
            a["name"] = r["hostname"]
    for r in conn.execute("SELECT name, ip, os, last_reported FROM wsus_computers").fetchall():
        fam, _, _ = _guest(r["os"])
        out.add(r["name"], "WSUS", fam if fam != "unknown" else "windows", r["os"] or "Windows", [r["ip"]],
                extra={"wsus_seen": r["last_reported"]})
    for r in conn.execute(
            """SELECT name, guest_hostname, guest_ips, guest_os, guest_family, is_linux, power_state
                 FROM vm_inventory""").fetchall():
        fam, distro, major = _guest(r["guest_os"], r["guest_family"], r["is_linux"])
        gh = r["guest_hostname"] if str(r["guest_hostname"] or "").strip().lower() not in JUNK_NAMES else None
        a = out.add(gh or r["name"], "vCenter guest", fam, r["guest_os"], r["guest_ips"] or [], distro, major,
                    {"power": r["power_state"]})
        if a and gh and r["name"] and short(r["name"]) != short(gh) and str(r["name"]).strip().lower() not in JUNK_NAMES:
            lst = out.by_short.setdefault(short(r["name"]), [])     # the VM's own name finds it too
            if a not in lst:
                lst.append(a)
    for r in conn.execute("SELECT name, esxi_version FROM esxi_hosts").fetchall():
        out.add(r["name"], "ESXi host", "esxi", ("ESXi " + (r["esxi_version"] or "")).strip(), [r["name"]])
    try:
        with conn.transaction():
            rows = conn.execute("SELECT host, version FROM vcenters").fetchall()
    except Exception:  # noqa: BLE001 - no vCenter table on a fresh install
        rows = []
    for r in rows:
        out.add(r["host"], "vCenter", "vcenter", ("vCenter " + (r["version"] or "")).strip(), [r["host"]])
    return out


def tag(m, asset, basis=None):
    """The machine's own record on the match: address, OS, where it is known from."""
    if asset:
        m["ip"] = ", ".join(asset["ips"]) or None
        m["os"] = asset["os"]
        m["os_family"] = asset["family"]
        m["sources"] = list(asset["sources"])
        if asset.get("conflict"):
            m["os_note"] = asset["conflict"]
    if basis:
        m["basis"] = basis
    return m


# ---------------------------------------------------------------------------
# Platforms: which operating systems a vulnerable product runs on
# ---------------------------------------------------------------------------

PLATFORM_NAMES = {"windows": "Windows", "linux": "Linux", "rpm": "RHEL family", "esxi": "VMware ESXi",
                  "vcenter": "VMware vCenter", "hardware": "Server hardware", "network": "Network devices"}
OTHER_OS = re.compile(r"mac_?os|macos|os_x|iphone|ipad|ios\b|android|chrome_?os|watchos|tvos|solaris|aix|hp-ux|freebsd", re.I)
TARGET_SW = {"windows": "windows", "linux": "linux", "linux_kernel": "linux"}
MS_NOT_OURS = re.compile(r"\b(cbl[- ]?mariner|azure linux|cbl2|azl3|for mac|macos|android|ios|iphone|ipad|xbox)\b", re.I)


def running_on(cpes):
    """For each NVD configuration, the platforms its vulnerable products run
    on ("running on" entries, which NVD marks as not vulnerable themselves):
    {cfg: {'windows'} / {'linux'} / {'other'}}. A configuration without such
    entries is absent: its products run anywhere."""
    from . import exposure
    out = {}
    for c in cpes:
        if c.get("vulnerable", True):
            continue
        p = exposure.parse_cpe(c.get("criteria"))
        if not p or p["part"] != "o":
            continue
        if p["vendor"] == "microsoft" and p["product"].startswith("windows"):
            fam = "windows"
        elif (p["vendor"], p["product"]) in exposure.LINUX_OS or p["product"] in ("linux_kernel", "linux", "debian_linux", "fedora"):
            fam = "linux"
        else:
            fam = "other"
        out.setdefault(c.get("cfg"), set()).add(fam)
    return out


# NVD target_sw values that are operating systems we do not run; any other
# value that is not windows or linux (node.js, python, wordpress, jenkins...)
# is an ecosystem, which runs on either
OTHER_TARGET = re.compile(r"^(mac_?os(_x)?|macos|os_x|iphone_os|ipados|ios|android|chrome_?os|watchos|tvos|"
                          r"visionos|solaris|aix|hp-ux|freebsd|openbsd|netbsd|z\/os|blackberry.*)$", re.I)
OTHER_LINUX_OS = {("debian", "debian_linux"): "debian", ("fedoraproject", "fedora"): "fedora",
                  ("suse", "linux_enterprise_server"): "sles", ("opensuse", "leap"): "opensuse",
                  ("rockylinux", "rocky_linux"): "rocky", ("almalinux", "almalinux"): "almalinux",
                  ("centos", "centos"): "centos", ("amazon", "linux"): "amzn", ("amazon", "linux_2"): "amzn"}
# Microsoft products that also run on Linux (their Linux builds are matched by package)
MS_CROSS = {".net", "dotnet", ".net_core", "asp.net_core", ".net_framework_core", "powershell", "visual_studio_code",
            "sql_server", "odbc_driver_for_sql_server", "ole_db_driver_for_sql_server", "azure_cli", "edge_chromium",
            "teams", "omi", "open_management_infrastructure", "system_center_operations_manager"}


def cpe_scope(p, on):
    """(platforms, why) for one NVD product; platforms None when it is not a
    platform we run (macOS, Android, a phone OS)."""
    from . import exposure
    v, prod, kind = p["vendor"], p["product"], p["kind"]
    name = f"{v} {prod}".replace("_", " ")
    if kind == "Hypervisor (ESXi)":
        return {"esxi"}, "NVD: VMware ESXi"
    if kind == "vCenter":
        return {"vcenter"}, "NVD: VMware vCenter"
    if kind == "Hardware or firmware":
        return {"hardware"}, f"NVD: hardware {name}"
    if kind == "Network device or appliance":
        return {"network"}, f"NVD: network device {name}"
    if p["part"] == "o":
        if v == "microsoft" and prod.startswith("windows"):
            return {"windows"}, f"NVD: {name}"
        if (v, prod) in exposure.LINUX_OS:
            return {"distro:" + exposure.LINUX_OS[(v, prod)]}, f"NVD: {name}"
        if (v, prod) in OTHER_LINUX_OS:
            return {"distro:" + OTHER_LINUX_OS[(v, prod)]}, f"NVD: {name}"
        if prod in ("linux_kernel", "linux"):
            return {"linux"}, "NVD: the Linux kernel"
        return None, f"NVD: {name} is an operating system we do not run"
    # 1. NVD's own platform field on the product's entries
    targets = [str(r.get("target_sw") or "*").lower() for r in p.get("ranges") or []]
    if targets and not any(t in ("*", "-", "") for t in targets):
        mapped, eco = set(), set()
        for t in set(targets):
            if t == "windows":
                mapped.add("windows")
            elif t in ("linux", "linux_kernel"):
                mapped.add("linux")
            elif not OTHER_TARGET.match(t):
                mapped |= {"windows", "linux"}          # an ecosystem (node.js, python...): either
                eco.add(t)
        if not mapped:
            return None, f"NVD: {name} for {', '.join(sorted(set(targets)))} only"
        if eco:
            return mapped, f"NVD: {name} for {', '.join(sorted(eco))} (any operating system)"
        return mapped, f"NVD: {name} for {', '.join(sorted(PLATFORM_NAMES[x] for x in mapped))}"
    # 2. "Running on" entries in the configurations this product is listed in
    cfgs = p.get("cfgs") or [None]
    if all(c in on for c in cfgs):
        fams = set().union(*(on[c] for c in cfgs))
        ours = fams - {"other"}
        if not ours:
            return None, f"NVD: {name} on platforms we do not run"
        return ours, f"NVD: {name} running on {', '.join(sorted(PLATFORM_NAMES[x] for x in ours))}"
    # 3. The vendor
    if v == "microsoft" and prod not in MS_CROSS:
        return {"windows"}, f"NVD: {name} (Microsoft product for Windows)"
    return {"windows", "linux"}, f"NVD: {name} (any platform)"


def fits(scope, asset_family, distro=None):
    if not scope:
        return False
    if asset_family in scope:
        return True
    if asset_family == "linux":
        if "rpm" in scope and distro in RPM_DISTROS:
            return True
        if distro and ("distro:" + distro) in scope:
            return True
    return False


def scope_words(scope):
    return " or ".join(sorted(PLATFORM_NAMES.get(x, x.replace("distro:", "").upper()) for x in scope))


# ---------------------------------------------------------------------------
# Red Hat: installed build against Red Hat's fixed build for that RHEL release
# ---------------------------------------------------------------------------

# Binary packages built from a source package: openssl -> openssl-libs, openssh -> openssh-server,
# curl -> curl-minimal, libcurl, libcurl-minimal; kernel -> kernel-core, kernel-modules...
SUBPKG = r"(-(libs|server|clients?|common|core|devel|minimal|modules(-core|-extra)?|utils|tools|headers|daemon|full|" \
         r"libs-[a-z0-9]+|client-libs|selinux|tui|langpack-[a-z]+))?"


def _source_of(binary, sources):
    """The Red Hat source package an installed binary package comes from, or None."""
    b = binary.lower()
    for src in sorted(sources, key=len, reverse=True):         # longest first: openssl-pkcs11 before openssl
        if re.fullmatch(r"(lib)?" + re.escape(src) + SUBPKG, b):
            return src
    return None


def match_redhat(conn, cve_id, fixed_names, comps):
    """(matches, excluded, notes, decided_hosts). Red Hat's answer for RHEL
    builds: the installed build of each package against Red Hat's fixed build
    for the machine's own release. Until Red Hat's per-release state has been
    read, only packages Red Hat shipped a fix in count, and only as 'present'.
    decided_hosts: the RHEL-family machines Red Hat's answer covers."""
    from . import evr, exposure, rh_state
    st = rh_state.get(conn, cve_id)
    have = bool(st and st.get("found"))
    sources = set()
    for n in list(fixed_names) + (list(comps) if have else []):
        if isinstance(n, str) and re.fullmatch(r"[a-z0-9][a-z0-9._+-]{1,60}", n.lower()):
            sources.add(n.lower())
            sources.update(exposure.PACKAGE_ALIASES.get(n.lower(), []))
    notes = []
    if comps and not have:
        why = ("Red Hat's per-release state could not be read; it is tried again daily" if st and st.get("error")
               else "Red Hat has no per-release state for this CVE" if st
               else "Red Hat's per-release state is being read")
        notes.append("Red Hat names " + ", ".join(sorted(comps)[:5]) + " in its title. " + why
                     + ", so those are not matched on the name alone")
    if have:
        sources.update(x["package"].lower() for x in st["states"] + st["fixed"])
    sources = {x for x in sources if re.fullmatch(r"[a-z0-9][a-z0-9._+-]{0,79}", x)}
    if not sources:
        return [], [], notes, set()
    like = []
    for src in sorted(sources)[:60]:
        like += [src + "%", "lib" + src + "%"]
    rows = conn.execute(
        """SELECT h.hostname, h.os_id, h.os_major, hp.name, hp.epoch, hp.version, hp.release
             FROM host_packages hp JOIN hosts h ON h.id = hp.host_id AND h.status <> 'decommissioned'
            WHERE lower(hp.name) LIKE ANY(%s) ORDER BY h.hostname, hp.name LIMIT 5000""", (like,)).fetchall()
    matches, excluded, decided = [], [], set()
    seen = set()
    fixed_set = {n.lower() for n in fixed_names}
    for r in rows:
        src = _source_of(r["name"], sources)
        if not src or (r["hostname"], src) in seen:
            continue                     # one line per machine and source package
        seen.add((r["hostname"], src))
        oid, major, pkg = _linux_id(r["os_id"]) or (r["os_id"] or "").lower(), r["os_major"], r["name"]
        installed = evr.evr_str(r["epoch"], r["version"], r["release"])
        label = pkg if pkg.lower() == src else f"{pkg} (from {src})"
        base = {"product": src, "kind": "Application", "where": "Linux server", "name": r["hostname"],
                "version": f"{label} {installed}"}
        if oid not in RPM_DISTROS:
            excluded.append({"name": r["hostname"], "product": src, "not_judged": True,
                             "reason": f"not judged by Red Hat's data, which covers RHEL builds only "
                                       f"(this machine runs {DISTRO_NAMES.get(oid, oid or 'an unknown OS')})"})
            continue
        via = "" if oid == "rhel" else f" ({DISTRO_NAMES.get(oid, oid)} follows RHEL {major})"
        if not have:
            if src in fixed_set:
                matches.append(dict(base, certainty="present",
                                    detail=f"Red Hat released a fixed {src}; its fixed build for RHEL {major} "
                                           f"is being read{via}"))
            continue
        decided.add(short(r["hostname"]))
        fx = [f for f in st["fixed"] if f["major"] == major and f["package"].lower() == src]
        sx = [x for x in st["states"] if x["major"] == major and x["package"].lower() == src]
        if fx:
            best = max(fx, key=cmp_to_key(lambda x, y: evr.rpm_label_compare(
                x["epoch"], x["version"], x["release"], y["epoch"], y["version"], y["release"])))
            fixed_s = evr.evr_str(best["epoch"], best["version"], best["release"])
            if evr.rpm_label_compare(r["epoch"], r["version"], r["release"], best["epoch"], best["version"], best["release"]) < 0:
                matches.append(dict(base, certainty="in_range",
                                    detail=f"installed {installed} is older than Red Hat's fixed build {fixed_s}"
                                           + (f" ({best['advisory']})" if best["advisory"] else "") + f" for RHEL {major}{via}"))
            else:
                excluded.append({"name": r["hostname"], "product": src,
                                 "reason": f"{label} {installed} is at Red Hat's fixed build {fixed_s} or newer"})
        elif any(x["state"] == "affected" for x in sx):
            word = next(x["word"] for x in sx if x["state"] == "affected")
            matches.append(dict(base, certainty="present",
                                detail=f"Red Hat: RHEL {major} {word}; no fixed build yet{via}"))
        elif sx:
            excluded.append({"name": r["hostname"], "product": src, "reason": f"Red Hat: not affected on RHEL {major}"})
        elif src in fixed_set:
            matches.append(dict(base, certainty="present",
                                detail=f"Red Hat fixed {src} for another release but gives no state for RHEL {major}{via}"))
        else:
            excluded.append({"name": r["hostname"], "product": src,
                             "reason": f"Red Hat gives no state for {src} on RHEL {major}"})
    return matches, excluded, notes, decided


# ---------------------------------------------------------------------------
# One CVE
# ---------------------------------------------------------------------------

RANK = {"confirmed": 6, "in_range": 5, "pending_reboot": 4, "release_match": 3, "present": 2, "not_tracked": 1}
WHERE_FAMILY = {"Linux server": "linux", "Windows server": "windows", "Windows server (agent)": "windows",
                "WSUS computer": "windows", "ESXi host": "esxi", "Server hardware (ESXi host)": "hardware",
                "vCenter": "vcenter"}


def analyse_one(conn, cve, inv=None):
    """Matches and verdict for one CVE, in order: the CVE database (NVD's
    products, Microsoft's and Red Hat's lists), each match's machine looked up
    in the assets (address, OS, sources), and the platform check: a match
    counts only when the machine runs a platform the vulnerable product runs
    on. Returns (verdict, machines, matches, info); info holds the platforms,
    the machines ruled out and why, and notes."""
    from . import exposure
    inv = inv or Inventory(conn)
    assets = inv.assets()
    cid = cve["cve_id"]
    cand = []                      # (match, scope, basis)
    excluded, notes, platforms = [], [], set()

    for m in match_confirmed(conn, cid):
        cand.append((m, {"linux"}, "vendor advisory, checked on the server"))

    cpes = [c for c in (cve.get("cpes") or []) if isinstance(c, dict)]
    on = running_on(cpes)
    products = exposure.products_from_cpes(cpes)[:MAX_PRODUCTS]
    for p in products:
        scope, why = cpe_scope(p, on)
        if scope is None:
            notes.append(why)
            continue
        platforms |= scope
        name = f"{p['vendor']} {p['product']}".replace("_", " ")
        found = exposure.find_in_inventory(conn, [p])
        if p["kind"] == "Hardware or firmware":
            hw = match_hardware(inv, p["vendor"], p["product"])
            found = hw or found            # our server models, else the "not inventoried" note
        elif p["vendor"] == "microsoft" and re.match(r"windows_(10|11|server_20\d\d)", p["product"]):
            label = _norm_os(re.match(r"windows_(10|11|server_20\d\d)", p["product"]).group(0).replace("_", " "))
            if label:
                known = p["product"] in exposure.WINDOWS_GUESTS
                found += [m for m in match_windows_os(inv, label, name) if not (known and m["where"] == "VM guest OS")]
        elif p["kind"] == "Application" and "windows" in scope:
            found += match_windows_software(inv, p["product"].replace("_", " "), p["ranges"])
        cand.extend((m, scope, why) for m in found)

    for prod in [x for x in (cve.get("ms_products") or []) if isinstance(x, str)][:MAX_PRODUCTS]:
        if MS_NOT_OURS.search(prod):
            notes.append(f"Microsoft: {prod} is not a platform we run")
            continue
        platforms.add("windows")
        label = _norm_os(prod)
        found = match_windows_os(inv, label, prod) if label else match_windows_software(inv, prod)
        cand.extend((m, {"windows"}, f"Microsoft lists {prod}") for m in found)

    rh_fixed = [x for x in (cve.get("rh_products") or []) if isinstance(x, str)][:MAX_PRODUCTS]
    rh_comps = [x for x in (cve.get("rh_components") or []) if isinstance(x, str)][:10]
    rh_decided = set()
    if rh_fixed or rh_comps:
        rm, rx, rn, rh_decided = match_redhat(conn, cid, rh_fixed, rh_comps)
        if rm or rh_fixed or rx:
            platforms.add("rpm")
        cand.extend((m, {"rpm"}, "Red Hat security data") for m in rm)
        excluded.extend(rx)
        notes.extend(rn)
    if rh_decided:
        # On RHEL builds Red Hat's per-release answer decides; NVD's "the package is
        # installed" (upstream versions, blind to backports) adds nothing there
        drop = [x for x in cand if x[0].get("where") == "Linux server" and x[0].get("certainty") == "present"
                and x[2] != "Red Hat security data" and short(x[0].get("name")) in rh_decided]
        cand = [x for x in cand if x not in drop]

    # Each match: the machine's own record, then the platform check
    kept = []
    for m, scope, basis in cand:
        if not m.get("name") or m.get("certainty") == "not_tracked":
            kept.append(tag(m, None, basis))
            continue
        a = assets.lookup(m["name"], m.get("where"))
        fam = a["family"] if a else WHERE_FAMILY.get(m.get("where") or "", "unknown")
        distro = a["distro"] if a else None
        tag(m, a, basis)
        if fits(scope, fam, distro) or ("hardware" in scope and m.get("where", "").startswith("Server hardware")):
            kept.append(m)
        elif fam == "unknown":
            # A package check made on the machine itself stands; a match by name is kept as a possibility
            if m["certainty"] not in ("confirmed", "pending_reboot") and RANK.get(m["certainty"], 0) > RANK["present"]:
                m["certainty"] = "present"
            m["detail"] = (m.get("detail") or "") + "; this machine's operating system is not known, so its platform could not be checked"
            kept.append(m)
        else:
            excluded.append({"name": m["name"], "ip": m.get("ip"), "os": m.get("os"), "product": m.get("product"),
                             "reason": f"the vulnerable product runs on {scope_words(scope)}; this machine runs "
                                       f"{m.get('os') or PLATFORM_NAMES.get(fam, fam)}"})

    # One line per machine and product, strongest certainty kept
    best = {}
    for m in kept:
        k = (short(m.get("name")), (m.get("product") or "").lower())
        if k not in best or RANK.get(m["certainty"], 0) > RANK.get(best[k]["certainty"], 0):
            best[k] = m
    matches = sorted(best.values(), key=lambda m: (-RANK.get(m["certainty"], 0), m.get("name") or ""))
    found_on = {short(m.get("name")) for m in matches if m.get("name")}
    seen_ex, ex = set(), []
    for e in excluded:
        k = (short(e.get("name")), (e.get("product") or "").lower())
        if k in seen_ex or short(e.get("name")) in found_on:
            continue
        seen_ex.add(k)
        a = assets.lookup(e.get("name"), "Linux server")
        if a:
            e.setdefault("ip", ", ".join(a["ips"]) or None)
            e.setdefault("os", a["os"])
        ex.append(e)
    certs = {m["certainty"] for m in matches}
    if certs & set(STRONG):
        verdict = "affected"
    elif "pending_reboot" in certs:
        verdict = "pending_reboot"
    elif certs & set(WEAK):
        verdict = "potentially_affected"
    elif certs == {"not_tracked"}:
        verdict = "not_tracked"
    else:
        verdict = "not_found"
    machines = len({short(m.get("name")) for m in matches if m.get("name") and m["certainty"] != "not_tracked"})
    plat = sorted(PLATFORM_NAMES.get(x, x.replace("distro:", "").upper()) for x in platforms)
    return verdict, machines, matches[:120], {"platforms": plat, "excluded": ex[:60], "notes": notes[:10]}


# ---------------------------------------------------------------------------
# The worker's pass
# ---------------------------------------------------------------------------

CANDIDATES = """
    SELECT i.cve_id,
           max(i.cvss) AS cvss,
           (array_agg(i.severity ORDER BY i.cvss DESC NULLS LAST))[1] AS severity,
           bool_or(i.exploited) AS exploited,
           min(i.published) AS published,
           (array_agg(i.title ORDER BY (i.source = 'nist') DESC))[1] AS title,
           (array_agg(i.summary ORDER BY (i.source = 'nist') DESC))[1] AS summary,
           array_agg(DISTINCT i.source) AS sources,
           (array_agg(i.cpes) FILTER (WHERE i.cpes IS NOT NULL))[1] AS cpes,
           (SELECT x.products FROM cve_feed_items x WHERE x.cve_id = i.cve_id AND x.source = 'msrc') AS ms_products,
           (SELECT x.products FROM cve_feed_items x WHERE x.cve_id = i.cve_id AND x.source = 'redhat') AS rh_products,
           (SELECT x.components FROM cve_feed_items x WHERE x.cve_id = i.cve_id AND x.source = 'redhat') AS rh_components
      FROM cve_feed_items i
     WHERE i.published >= now() - make_interval(days => %(days)s::int)
       AND (i.exploited OR coalesce(i.cvss, 0) >= 7
            OR lower(coalesce(i.severity, '')) IN ('critical', 'high', 'important'))
     GROUP BY i.cve_id"""


def analyse_pass(conn, limit=BATCH):
    """Analyse CVEs never analysed first, then those analysed before the
    inventory changed or more than a day ago, oldest first, so every CVE is
    reached. Returns how many were analysed."""
    from . import cve_feeds
    s = cve_feeds.settings(conn)
    mark = inventory_mark(conn)
    rows = conn.execute(
        f"""SELECT c.* FROM ({CANDIDATES}) c LEFT JOIN cve_impact x ON x.cve_id = c.cve_id
             WHERE x.cve_id IS NULL OR x.inventory_mark IS DISTINCT FROM %(mark)s
                OR x.analysed_at < now() - make_interval(hours => %(hours)s::int)
             ORDER BY (x.cve_id IS NULL) DESC, x.analysed_at NULLS FIRST,
                      c.exploited DESC, c.cvss DESC NULLS LAST, c.published DESC
             LIMIT %(limit)s::int""",
        {"days": int(s.get("days_back") or 14), "mark": mark, "hours": REANALYSE_HOURS,
         "limit": int(limit)}).fetchall()
    conn.commit()
    inv = Inventory(conn)
    n = 0
    for c in rows:
        c = dict(c)
        try:
            if isinstance(c.get("cpes"), str):
                c["cpes"] = json.loads(c["cpes"])
            if not isinstance(c.get("cpes"), list):
                c["cpes"] = []
            with conn.transaction():          # one bad CVE must not stop the others
                verdict, machines, matches, info = analyse_one(conn, c, inv)
        except Exception as e:  # noqa: BLE001 - recorded, and retried at the next re-analysis
            log.warning("impact: %s could not be analysed: %s", c.get("cve_id"), e)
            verdict, machines, matches = "not_found", 0, [{"certainty": "not_tracked", "kind": "Analysis",
                                                           "detail": "could not be analysed: " + str(e)[:160]}]
            info = {"platforms": [], "excluded": [], "notes": []}
        conn.execute(
            """INSERT INTO cve_impact (cve_id, verdict, machines, matches, title, severity, cvss, exploited, sources,
                                       published, inventory_mark, platforms, excluded, analysed_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, now())
               ON CONFLICT (cve_id) DO UPDATE SET verdict=EXCLUDED.verdict, machines=EXCLUDED.machines,
                 matches=EXCLUDED.matches, title=EXCLUDED.title, severity=EXCLUDED.severity, cvss=EXCLUDED.cvss,
                 exploited=EXCLUDED.exploited, sources=EXCLUDED.sources, published=EXCLUDED.published,
                 inventory_mark=EXCLUDED.inventory_mark, platforms=EXCLUDED.platforms, excluded=EXCLUDED.excluded,
                 -- a brief written from other findings is withdrawn until AI-01 rewrites it
                 ai_summary = CASE WHEN cve_impact.verdict = EXCLUDED.verdict AND cve_impact.matches = EXCLUDED.matches
                                   THEN cve_impact.ai_summary END,
                 ai_key = CASE WHEN cve_impact.verdict = EXCLUDED.verdict AND cve_impact.matches = EXCLUDED.matches
                               THEN cve_impact.ai_key END,
                 analysed_at=now()""",
            (c["cve_id"], verdict, machines, json.dumps(matches, default=str), (c.get("title") or "")[:300],
             c.get("severity"), c.get("cvss"), bool(c.get("exploited")), c.get("sources") or [],
             c.get("published"), mark, info["platforms"],
             json.dumps({"machines": info["excluded"], "notes": info["notes"]}, default=str)))
        n += 1
        if n % 25 == 0:
            conn.commit()
    conn.execute("DELETE FROM cve_impact WHERE coalesce(published, analysed_at) < now() - interval '120 days'")
    conn.commit()
    return n


def match_lines(matches, n=12):
    """What AI-01 is told about each match: where, machine, its OS, what was found, how sure."""
    return [f"{m.get('where') or m.get('kind')} {m.get('name') or ''}"
            + (f" [{m['os']}]" if m.get("os") else "")
            + f" {m.get('version') or ''} ({str(m.get('certainty')).replace('_', ' ')})"
            for m in matches if m.get("certainty") != "not_tracked"][:n]


def _ai_facts(conn, row):
    d = conn.execute("SELECT * FROM cve_details WHERE cve_id = %s", (row["cve_id"],)).fetchone() or {}
    f = conn.execute(
        """SELECT summary, title FROM cve_feed_items WHERE cve_id = %s
            ORDER BY (source = 'nist') DESC LIMIT 1""", (row["cve_id"],)).fetchone() or {}
    matches = row["matches"] if isinstance(row["matches"], list) else json.loads(row["matches"] or "[]")
    products = sorted({m.get("product") or "" for m in matches if m.get("product")})[:8]
    lines = match_lines(matches)
    word = {"affected": "affected", "pending_reboot": "pending_reboot",
            "potentially_affected": "potentially_affected"}.get(row["verdict"], "not_found")
    return {"cve_id": row["cve_id"], "cvss_score": row.get("cvss") or d.get("cvss_score"),
            "cvss_severity": row.get("severity") or d.get("cvss_severity"), "cvss_vector": d.get("cvss_vector"),
            "attack_class": d.get("attack_class"), "attack_class_basis": d.get("attack_class_basis"),
            "kev": bool(row.get("exploited") or d.get("kev")), "epss": d.get("epss"),
            "description": f.get("summary") or f.get("title") or row.get("title") or "",
            "exposure": word, "product_list": products, "match_lines": lines}


def ai_pass(conn, limit=AI_PER_PASS):
    """AI-01 briefs for impacted CVEs, most serious first. A brief is redone
    only when the facts it was written from change."""
    from . import llm
    if not llm.configured():
        return 0
    rows = conn.execute(
        """SELECT * FROM cve_impact WHERE verdict IN ('affected', 'pending_reboot', 'potentially_affected')
            ORDER BY (verdict = 'affected') DESC, exploited DESC, cvss DESC NULLS LAST, published DESC
            LIMIT 60""").fetchall()
    done = 0
    for r in rows:
        if done >= limit:
            break
        f = _ai_facts(conn, r)
        conn.commit()                         # no transaction held open while AI-01 writes
        key = hashlib.sha256(json.dumps([f["exposure"], f["match_lines"][:6], f["cvss_score"], f["kev"]],
                                        default=str).encode()).hexdigest()[:24]
        if r.get("ai_key") == key and r.get("ai_summary"):
            continue
        try:
            text, model = llm.summarise_cve(conn, f, wait=30)
        except Exception as e:  # noqa: BLE001 - the verdict stands without the brief
            log.info("impact: no AI brief for %s: %s", r["cve_id"], e)
            conn.rollback()
            break
        conn.execute("UPDATE cve_impact SET ai_summary=%s, ai_model=%s, ai_key=%s, ai_at=now() WHERE cve_id=%s",
                     (text, model, key, r["cve_id"]))
        conn.commit()
        done += 1
    return done


# ---------------------------------------------------------------------------
# Reading, for the console
# ---------------------------------------------------------------------------

def counts(conn, days):
    return conn.execute(
        """SELECT count(*) FILTER (WHERE verdict = 'affected') AS affected,
                  count(*) FILTER (WHERE verdict = 'pending_reboot') AS pending_reboot,
                  count(*) FILTER (WHERE verdict = 'potentially_affected') AS potentially_affected,
                  count(*) FILTER (WHERE verdict IN ('not_found', 'not_affected', 'patched')) AS not_found,
                  count(*) FILTER (WHERE verdict = 'not_tracked') AS not_tracked,
                  count(*) FILTER (WHERE verdict IN ('affected', 'potentially_affected') AND exploited) AS exploited_impacting,
                  max(analysed_at) AS analysed_at,
                  count(*) FILTER (WHERE ai_summary IS NOT NULL) AS ai_briefs
             FROM cve_impact WHERE published >= now() - make_interval(days => %s::int)""", (int(days),)).fetchone()


def listing(conn, days, verdict=None, limit=300):
    return conn.execute(
        """SELECT cve_id, verdict, machines, matches, title, severity, cvss, exploited, sources, published,
                  analysed_at, ai_summary, ai_model, ai_at, platforms, excluded
             FROM cve_impact
            WHERE published >= now() - make_interval(days => %s::int)
              AND (%s::text IS NULL OR verdict = %s::text)
            ORDER BY CASE verdict WHEN 'affected' THEN 0 WHEN 'pending_reboot' THEN 1
                                  WHEN 'potentially_affected' THEN 2 ELSE 3 END,
                     exploited DESC, cvss DESC NULLS LAST, published DESC
            LIMIT %s""", (int(days), verdict, verdict, int(limit))).fetchall()
