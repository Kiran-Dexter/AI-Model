"""Red Hat's own answer for one CVE, per RHEL release.

Red Hat's CVE list names a component in each title ("curl: ...") whether or
not RHEL is affected, so a component name alone proves nothing. Its per-CVE
page says, for each RHEL release and package:

    fixed          a build that contains the fix (with the RHSA)
    affected       affected, fix deferred or not planned
    not_affected   not affected

The worker reads it once a day for each serious CVE Red Hat tracks, and caches
it in rh_cve_state; the impact analysis then compares each Linux machine's
installed build with Red Hat's fixed build for that machine's release.

Only the Red Hat security data API is contacted (same host as the CVE feed).
Everything read from it is checked for shape and size before use.
"""

import json
import logging
import re

log = logging.getLogger("patchapi.rh_state")

URL = "https://access.redhat.com/hydra/rest/securitydata/cve/{}.json"
CVE_RE = re.compile(r"^CVE-\d{4}-\d{4,7}$")
FETCH_PER_PASS = 20
REFRESH_HOURS = 24
# The main RHEL releases only: "Red Hat Enterprise Linux 9", cpe:/o:redhat:enterprise_linux:9 or
# cpe:/a:redhat:enterprise_linux:9::appstream. Extended Update Support, AUS, TUS, E4S and SAP
# streams ("Red Hat Enterprise Linux 9.2 Extended Update Support", enterprise_linux_eus:9.2) have
# their own builds, which are not what a machine on the main release installs.
RHEL_PRODUCT = re.compile(r"^red hat enterprise linux (\d{1,2})$", re.I)
RHEL_CPE = re.compile(r"^cpe:/[ao]:redhat:enterprise_linux:(\d{1,2})(?:::[a-z_]+)?$", re.I)
AFFECTED_WORDS = {"affected", "fix deferred", "will not fix", "out of support scope", "under investigation", "new"}
NOT_AFFECTED_WORDS = {"not affected"}
MODULE_PKG = re.compile(r"^[a-z0-9._+-]{1,60}:[a-z0-9._+-]{1,40}/([a-z0-9._+-]{1,80})$", re.I)


def _major(product_name, cpe):
    m = RHEL_PRODUCT.match(str(product_name or "").strip()) or RHEL_CPE.match(str(cpe or "").strip())
    return int(m.group(1)) if m else None


def _split_nevra(nevra):
    """'curl-0:7.76.1-29.el9_4' -> ('curl', 0, '7.76.1', '29.el9_4')."""
    m = re.match(r"^(?P<n>[A-Za-z0-9][A-Za-z0-9._+-]*?)-(?:(?P<e>\d+):)?(?P<v>\d[^-]*)-(?P<r>[^-]+)$", str(nevra or "").strip())
    if not m:
        return None
    return m.group("n"), int(m.group("e") or 0), m.group("v"), m.group("r")


def parse(doc):
    """Red Hat's CVE document -> (states, fixed), both lists of small dicts."""
    states, fixed = [], []
    if not isinstance(doc, dict):
        return states, fixed
    for p in (doc.get("package_state") or [])[:300]:
        if not isinstance(p, dict):
            continue
        major = _major(p.get("product_name"), p.get("cpe"))
        pkg = str(p.get("package_name") or "").strip()
        word = str(p.get("fix_state") or "").strip().lower()
        mod = MODULE_PKG.match(pkg)
        if mod:
            pkg = mod.group(1)       # a RHEL 8 module stream, "nodejs:18/nodejs" -> nodejs
        if major is None or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._+-]{0,79}", pkg):
            continue           # containers ("rhel9/...") and other products are not machines we patch
        if word in NOT_AFFECTED_WORDS:
            states.append({"major": major, "package": pkg, "state": "not_affected", "word": word})
        elif word in AFFECTED_WORDS:
            states.append({"major": major, "package": pkg, "state": "affected", "word": word})
    for a in (doc.get("affected_release") or [])[:300]:
        if not isinstance(a, dict):
            continue
        major = _major(a.get("product_name"), a.get("cpe"))
        parts = _split_nevra(a.get("package"))
        if major is None or not parts:
            continue
        adv = str(a.get("advisory") or "")[:40]
        fixed.append({"major": major, "package": parts[0], "epoch": parts[1], "version": parts[2],
                      "release": parts[3], "advisory": adv if re.match(r"^RH[SBE]A-\d{4}:\d+$", adv) else ""})
    return states, fixed


def get(conn, cve_id):
    """The cached state, or None when it has not been read yet."""
    try:
        with conn.transaction():
            r = conn.execute("SELECT found, states, fixed, fetched_at, error FROM rh_cve_state WHERE cve_id = %s",
                             (cve_id,)).fetchone()
    except Exception:  # noqa: BLE001 - schema 025 not applied yet
        return None
    if not r:
        return None
    r = dict(r)
    for k in ("states", "fixed"):
        if isinstance(r[k], str):
            r[k] = json.loads(r[k])
    return r


def fetch_one(conn, cve_id):
    from .cve_intel import _get
    if not CVE_RE.match(cve_id or ""):
        return False
    try:
        doc = _get(URL.format(cve_id), tries=2)
        states, fixed = parse(doc)
        conn.execute(
            """INSERT INTO rh_cve_state (cve_id, fetched_at, found, states, fixed, error)
               VALUES (%s, now(), %s, %s, %s, NULL)
               ON CONFLICT (cve_id) DO UPDATE SET fetched_at = now(), found = EXCLUDED.found,
                 states = EXCLUDED.states, fixed = EXCLUDED.fixed, error = NULL""",
            (cve_id, doc is not None, json.dumps(states), json.dumps(fixed)))
        # The CVE is analysed again with Red Hat's answer
        conn.execute("UPDATE cve_impact SET inventory_mark = NULL WHERE cve_id = %s", (cve_id,))
        conn.commit()
        return True
    except Exception as e:  # noqa: BLE001 - kept as an error and retried next day
        conn.rollback()
        log.info("Red Hat state for %s not read: %s", cve_id, e)
        conn.execute(
            """INSERT INTO rh_cve_state (cve_id, fetched_at, found, error) VALUES (%s, now(), false, %s)
               ON CONFLICT (cve_id) DO UPDATE SET fetched_at = now(), error = EXCLUDED.error""",
            (cve_id, str(e)[:300]))
        conn.commit()
        return False


def refresh_pass(conn, days, limit=FETCH_PER_PASS):
    """Read Red Hat's state for the serious CVEs Red Hat tracks that have none,
    or one older than a day; most serious first."""
    rows = conn.execute(
        """SELECT i.cve_id FROM cve_feed_items i LEFT JOIN rh_cve_state s ON s.cve_id = i.cve_id
            WHERE i.source = 'redhat' AND i.published >= now() - make_interval(days => %s::int)
              AND (i.exploited OR coalesce(i.cvss, 0) >= 7
                   OR lower(coalesce(i.severity, '')) IN ('critical', 'high', 'important'))
              AND (s.cve_id IS NULL OR s.fetched_at < now() - make_interval(hours => %s::int))
            ORDER BY s.cve_id IS NULL DESC, i.cvss DESC NULLS LAST LIMIT %s::int""",
        (int(days), REFRESH_HOURS, int(limit))).fetchall()
    conn.commit()
    done = failed = 0
    for r in rows:
        if fetch_one(conn, r["cve_id"]):
            done, failed = done + 1, 0
        else:
            failed += 1
            if failed >= 3:                  # Red Hat unreachable: try again next pass
                break
    return done
