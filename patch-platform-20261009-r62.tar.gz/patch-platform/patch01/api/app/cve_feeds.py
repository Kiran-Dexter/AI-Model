"""CVE news feeds: what NIST, Microsoft and Red Hat have just published.

Three public sources, read through the corporate proxy by the worker:

  nist     NVD API 2.0. Two kinds of query:
             - one per watch-list entry ("openssl", "apache tomcat"), for CVEs
               published in the last N days that mention it;
             - the general feed: every CVE rated critical or high in that time.
  msrc     Microsoft Security Update Guide (CVRF): the monthly releases that
           fall in the window, read again only when Microsoft revises them.
  redhat   Red Hat security data API: CVEs Red Hat published in the window.

Only facts are kept (CVE number, date, title, severity, score, products,
link). Nothing is executed or rendered as HTML: titles are plain text and the
console shows them with textContent. Links are only ever built here, to the
three vendors' own sites, never taken from the feed.

    python -m app.cve_feeds sync          read all enabled sources now
    python -m app.cve_feeds status
"""

import json
import logging
import re
import sys
import time
import urllib.parse
from datetime import datetime, timedelta, timezone

log = logging.getLogger("patchapi.cve_feeds")

CVE_RE = re.compile(r"^CVE-\d{4}-\d{4,7}$")
TERM_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._+-]{1,59}$")
NVD_PAGE = 500
NVD_MAX_PER_QUERY = 4000
RH_URL = "https://access.redhat.com/hydra/rest/securitydata/cve.json"
RH_PAGE = 500
KEEP_DAYS = 120
SEV_RANK = {"critical": 4, "important": 3, "high": 3, "moderate": 2, "medium": 2, "low": 1}


def utcnow():
    return datetime.now(timezone.utc)


def _text(v, n):
    """Plain text, one line, bounded."""
    s = re.sub(r"\s+", " ", str(v or "")).strip()
    return s[:n]


def _float(v):
    try:
        f = float(v)
        return f if 0 <= f <= 10 else None
    except (TypeError, ValueError):
        return None


def _ts(v):
    if not v:
        return None
    s = str(v).strip().replace("Z", "+00:00")
    try:
        d = datetime.fromisoformat(s)
    except ValueError:
        try:
            d = datetime.strptime(s[:19], "%Y-%m-%dT%H:%M:%S")
        except ValueError:
            return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def severity_from_cvss(score):
    if score is None:
        return None
    return "critical" if score >= 9 else "high" if score >= 7 else "medium" if score >= 4 else "low" if score > 0 else None


# ---------------------------------------------------------------------------
# Watch-list terms (validated here; the API stores term and pattern)
# ---------------------------------------------------------------------------

def clean_term(term):
    t = re.sub(r"\s+", " ", (term or "").strip())
    if not TERM_RE.match(t):
        raise ValueError("Use 2 to 60 letters, digits, spaces and . _ + - (for example: openssl, apache tomcat).")
    return t


def term_pattern(term):
    """A PostgreSQL regular expression matching the term as whole words."""
    esc = re.sub(r"([.+\-])", r"\\\1", term.lower())
    esc = esc.replace(" ", "[^[:alnum:]]+")
    return "(^|[^[:alnum:]])" + esc + "($|[^[:alnum:]])"


def term_matches(term, text):
    """The same match in Python (tests, and the NVD keyword results)."""
    pat = term_pattern(term).replace("[:alnum:]", "a-z0-9")
    return re.search(pat, (text or "").lower()) is not None


# ---------------------------------------------------------------------------
# Parsers (pure: tested with sample documents)
# ---------------------------------------------------------------------------

def _cpe_product(criteria):
    p = (criteria or "").split(":")
    if len(p) > 4 and p[3] not in ("*", "-") and p[4] not in ("*", "-"):
        return (p[3] + " " + p[4]).replace("_", " ")
    return None


def parse_nvd_item(cve, general=False):
    from .cve_intel import parse_nvd
    d = parse_nvd(cve)
    if not CVE_RE.match(d.get("cve_id") or ""):
        return None
    products = []
    for c in d.get("cpes") or []:
        name = _cpe_product(c.get("criteria"))
        if name and name not in products:
            products.append(name)
        if len(products) >= 25:
            break
    score = _float(d.get("cvss_score"))
    sev = (d.get("cvss_severity") or "").lower() or severity_from_cvss(score)
    return {"source": "nist", "cve_id": d["cve_id"], "published": _ts(d.get("published")),
            "modified": _ts(d.get("last_modified")), "title": _text(d.get("description"), 300),
            "summary": _text(d.get("description"), 1500), "severity": sev, "cvss": score,
            "exploited": bool(d.get("kev_from_nvd")), "products": products,
            "cpes": (d.get("cpes") or [])[:400],
            "url": "https://nvd.nist.gov/vuln/detail/" + d["cve_id"], "general": general}


RPM_NEVRA = re.compile(r"^(?P<name>[A-Za-z0-9][A-Za-z0-9._+-]*?)-(?:\d+:)?\d[^-]*-[^-]+$")


def rpm_name(nevra):
    """'openssl-1:3.0.7-27.el9' -> 'openssl'; 'kernel-5.14.0-427.el9_4' -> 'kernel';
    'python3.11-3.11.7-1.el9' -> 'python3.11'. None if it is not a package build."""
    m = RPM_NEVRA.match(str(nevra or "").strip())
    if not m or "/" in m.group("name"):
        return None
    return m.group("name")[:80]


def parse_redhat(rows):
    out = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        cve = str(r.get("CVE") or "")
        if not CVE_RE.match(cve):
            continue
        # Packages Red Hat shipped a fix in: "openssl-1:3.0.7-27.el9", "kernel-5.14.0-427.13.1.el9_4"
        pkgs = []
        for p in r.get("affected_packages") or []:
            name = rpm_name(p)
            if name and name not in pkgs:
                pkgs.append(name)
            if len(pkgs) >= 25:
                break
        # Components only named in the title ("openssh: ...", "golang: net/http: ...") prove nothing on
        # their own: Red Hat lists CVEs it is not affected by too. Kept apart, and used only once
        # Red Hat's per-product state for the CVE has been read (rh_state).
        comps = []
        for comp in re.findall(r"(?:^|:\s)([a-z0-9][a-z0-9._+-]{1,40}):", str(r.get("bugzilla_description") or "").lower()):
            if "/" not in comp and comp not in pkgs and comp not in comps and len(comps) < 10:
                comps.append(comp)
        score = _float(r.get("cvss3_score"))
        out.append({"source": "redhat", "cve_id": cve, "published": _ts(r.get("public_date")), "modified": None,
                    "title": _text(r.get("bugzilla_description"), 300), "summary": None,
                    "severity": (str(r.get("severity") or "").lower() or severity_from_cvss(score)) or None,
                    "cvss": score, "exploited": False, "products": pkgs, "components": comps,
                    "url": "https://access.redhat.com/security/cve/" + cve.lower(), "general": True})
    return out


MSRC_NOT_AFFECTED = 2      # CVRF product status "Known Not Affected"


def _v(x):
    return x.get("Value") if isinstance(x, dict) else x


def parse_msrc(doc, since=None):
    """One monthly CVRF release -> items published since 'since'."""
    names = {}
    for p in ((doc or {}).get("ProductTree") or {}).get("FullProductName") or []:
        if p.get("ProductID"):
            names[p["ProductID"]] = _text(p.get("Value"), 100)
    doc_date = _ts(((doc or {}).get("DocumentTracking") or {}).get("InitialReleaseDate"))
    out = []
    for v in (doc or {}).get("Vulnerability") or []:
        cve = str(v.get("CVE") or "")
        if not CVE_RE.match(cve):
            continue
        sev, exploited = None, False
        for t in v.get("Threats") or []:
            desc = str(_v(t.get("Description")) or "").strip().lower()
            if t.get("Type") == 3 and SEV_RANK.get(desc, 0) > SEV_RANK.get(sev or "", 0):
                sev = desc
            elif t.get("Type") == 1 and "exploited:yes" in desc.replace(" ", ""):
                exploited = True
        score = None
        for sc in v.get("CVSSScoreSets") or []:
            f = _float(sc.get("BaseScore"))
            if f is not None and (score is None or f > score):
                score = f
        pids = []
        for st in v.get("ProductStatuses") or []:
            if st.get("Type") == MSRC_NOT_AFFECTED:      # listed only to say they are not affected
                continue
            pids.extend(st.get("ProductID") or [])
        products = []
        for pid in pids:
            n = names.get(pid)
            if n and n not in products:
                products.append(n)
            if len(products) >= 25:
                break
        revs = v.get("RevisionHistory") or []
        published = _ts(revs[0].get("Date")) if revs else None
        modified = _ts(revs[-1].get("Date")) if revs else None
        published = published or doc_date
        if since and published and published < since and not (modified and modified >= since):
            continue
        out.append({"source": "msrc", "cve_id": cve, "published": published, "modified": modified,
                    "title": _text(_v(v.get("Title")), 300), "summary": None,
                    "severity": sev or severity_from_cvss(score), "cvss": score, "exploited": exploited,
                    "products": products,
                    "url": "https://msrc.microsoft.com/update-guide/vulnerability/" + cve, "general": True})
    return out


def _release_month(rid):
    try:
        return datetime.strptime(str(rid), "%Y-%b").replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def msrc_releases_in_window(index, since, now=None):
    """Monthly security releases that can hold CVEs published since 'since':
    every month from the one before 'since' to now (a release can be revised
    later, so a revised older month is not mistaken for a new one)."""
    now = now or utcnow()
    first = (since.replace(day=1) - timedelta(days=1)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    out = []
    for r in index or []:
        title = str(r.get("DocumentTitle") or "")
        if "security update" not in title.lower():
            continue                         # e.g. the Mariner release notes
        init = _ts(r.get("InitialReleaseDate"))
        cur = _ts(r.get("CurrentReleaseDate"))
        if not re.fullmatch(r"\d{4}-[A-Z][a-z]{2}", str(r.get("ID") or "")):
            continue
        month = _release_month(r["ID"])
        if month and first <= month <= now:
            out.append({"id": r["ID"], "current": r.get("CurrentReleaseDate") or "", "month": month})
    out.sort(key=lambda x: x["month"])
    return [{"id": x["id"], "current": x["current"]} for x in out][-6:]


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

def settings(conn):
    return conn.execute("SELECT * FROM cve_feed_settings WHERE id = 1").fetchone() or {}


def save_items(conn, items):
    n = 0
    for it in items:
        if not it or it.get("published") is None:
            continue
        conn.execute(
            """INSERT INTO cve_feed_items (source, cve_id, published, modified, title, summary, severity, cvss,
                                           exploited, products, url, general, cpes, components, fetched_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, now())
               ON CONFLICT (source, cve_id) DO UPDATE SET
                 modified = EXCLUDED.modified, title = EXCLUDED.title,
                 summary = coalesce(EXCLUDED.summary, cve_feed_items.summary),
                 severity = EXCLUDED.severity, cvss = EXCLUDED.cvss,
                 exploited = cve_feed_items.exploited OR EXCLUDED.exploited,
                 products = EXCLUDED.products,
                 general = cve_feed_items.general OR EXCLUDED.general,
                 cpes = coalesce(EXCLUDED.cpes, cve_feed_items.cpes),
                 components = EXCLUDED.components, fetched_at = now()""",
            (it["source"], it["cve_id"], it["published"], it.get("modified"), it.get("title"), it.get("summary"),
             it.get("severity"), it.get("cvss"), bool(it.get("exploited")), it.get("products") or [],
             it.get("url"), bool(it.get("general")), json.dumps(it["cpes"]) if it.get("cpes") else None,
             it.get("components") if it.get("source") == "redhat" else None))
        n += 1
    return n


def _state(conn, source, ok, items=None, error=None, marker=None):
    conn.execute(
        """INSERT INTO cve_feed_state (source, last_run, last_ok, items, error, marker)
           VALUES (%s, now(), CASE WHEN %s THEN now() END, %s, %s, %s)
           ON CONFLICT (source) DO UPDATE SET last_run = now(),
             last_ok = CASE WHEN %s THEN now() ELSE cve_feed_state.last_ok END,
             items = coalesce(EXCLUDED.items, cve_feed_state.items),
             error = EXCLUDED.error, marker = coalesce(EXCLUDED.marker, cve_feed_state.marker)""",
        (source, ok, items, (error or None) and str(error)[:300], marker, ok))


def _marker(conn, source):
    r = conn.execute("SELECT marker FROM cve_feed_state WHERE source = %s", (source,)).fetchone()
    return (r or {}).get("marker")


# ---------------------------------------------------------------------------
# Fetching (through the proxy in the environment)
# ---------------------------------------------------------------------------

def _nvd_date(d):
    return d.strftime("%Y-%m-%dT%H:%M:%S.000")


def _nvd_query(params, general, stop, notes=None):
    """All pages of one NVD query. NVD lists the oldest first, so when there
    are more than NVD_MAX_PER_QUERY results the oldest are skipped (and noted)
    and the newest kept."""
    from . import cve_intel
    headers = {"apiKey": cve_intel.NVD_KEY} if cve_intel.NVD_KEY else {}
    start, items, fetched, total = 0, [], 0, None
    while fetched < NVD_MAX_PER_QUERY and not stop():
        q = dict(params, resultsPerPage=NVD_PAGE, startIndex=start)
        res = cve_intel._get(cve_intel.NVD_URL + "?" + urllib.parse.urlencode(q), headers) or {}
        for v in res.get("vulnerabilities") or []:
            it = parse_nvd_item(v.get("cve") or {}, general)
            if it:
                items.append(it)
        fetched += NVD_PAGE
        time.sleep(cve_intel.NVD_PAUSE)
        if total is None:
            total = int(res.get("totalResults") or 0)
            if total > NVD_MAX_PER_QUERY + NVD_PAGE:
                start = total - NVD_MAX_PER_QUERY
                if notes is not None:
                    notes.append(f"NVD returned {total} results for one query; only the newest "
                                 f"{NVD_MAX_PER_QUERY} were read (shorten 'Days to show')")
                continue
        start += NVD_PAGE
        if start >= total:
            break
    return items


def sync_nist(conn, s, stop=lambda: False, notes=None):
    end = utcnow()
    since = end - timedelta(days=int(s.get("days_back") or 14))
    window = {"pubStartDate": _nvd_date(since), "pubEndDate": _nvd_date(end)}
    total = 0
    for sev in ("CRITICAL", "HIGH"):
        items = _nvd_query(dict(window, cvssV3Severity=sev), True, stop, notes)
        total += save_items(conn, items)
        conn.commit()
    for w in conn.execute("SELECT term FROM cve_feed_watch WHERE enabled ORDER BY id").fetchall():
        if stop():
            break
        items = [it for it in _nvd_query(dict(window, keywordSearch=w["term"]), False, stop, notes)
                 if term_matches(w["term"], " ".join([it["title"] or "", it["summary"] or ""] + it["products"]))]
        total += save_items(conn, items)
        conn.commit()
    return total


def sync_redhat(conn, s, stop=lambda: False, notes=None):
    from . import cve_intel
    since = (utcnow() - timedelta(days=int(s.get("days_back") or 14))).strftime("%Y-%m-%d")
    total, page = 0, 1
    while page <= 20 and not stop():
        q = urllib.parse.urlencode({"after": since, "per_page": RH_PAGE, "page": page})
        rows = cve_intel._get(RH_URL + "?" + q) or []
        if not isinstance(rows, list):
            break
        total += save_items(conn, parse_redhat(rows))
        conn.commit()
        if len(rows) < RH_PAGE:
            break
        page += 1
        time.sleep(1)
    return total


def sync_msrc(conn, s, stop=lambda: False, notes=None):
    from . import msrc
    since = utcnow() - timedelta(days=int(s.get("days_back") or 14))
    index = msrc._get("/updates").get("value") or []
    seen = {}
    try:
        seen = json.loads(_marker(conn, "msrc") or "{}")
    except ValueError:
        seen = {}
    total = 0
    for rel in msrc_releases_in_window(index, since):
        if stop():
            break
        if seen.get(rel["id"]) == rel["current"]:
            continue                          # not revised since it was read
        doc = msrc._get("/cvrf/" + rel["id"], timeout=180)
        total += save_items(conn, parse_msrc(doc, since))
        seen[rel["id"]] = rel["current"]
        conn.commit()
    window = {r["id"] for r in msrc_releases_in_window(index, since)}
    seen = {k: v for k, v in seen.items() if k in window}
    _state(conn, "msrc", True, None, None, json.dumps(seen))
    return total


SOURCES = (("nist", sync_nist), ("msrc", sync_msrc), ("redhat", sync_redhat))


def sync_all(conn, stop=lambda: False):
    s = settings(conn)
    done = {}
    for name, fn in SOURCES:
        if not s.get(name) or stop():
            continue
        try:
            notes = []
            n = fn(conn, s, stop, notes)
            conn.commit()
            _state(conn, name, True, n, "; ".join(notes) or None)
            done[name] = n
            log.info("feeds: %s %d items", name, n)
        except Exception as e:  # noqa: BLE001 - one source failing must not stop the others
            conn.rollback()
            log.warning("feeds: %s failed: %s", name, e)
            _state(conn, name, False, None, e)
            done[name] = str(e)[:200]
        conn.commit()
    conn.execute("DELETE FROM cve_feed_items WHERE published < now() - make_interval(days => %s)", (KEEP_DAYS,))
    conn.execute("UPDATE cve_feed_settings SET run_requested_at = NULL WHERE id = 1")
    conn.commit()
    return done


def due(conn):
    """Whether the worker should read the feeds now."""
    s = settings(conn)
    if not s or not (s.get("nist") or s.get("msrc") or s.get("redhat")):
        return False
    if s.get("run_requested_at"):
        return True
    enabled = [k for k in ("nist", "msrc", "redhat") if s.get(k)]
    runs = {r["source"]: r["last_run"] for r in conn.execute(
        "SELECT source, last_run FROM cve_feed_state WHERE source = ANY(%s)", (enabled,)).fetchall()}
    if any(not runs.get(k) for k in enabled):
        return True
    oldest = min(_ts(v) if isinstance(v, str) else v for v in runs.values())
    return oldest < utcnow() - timedelta(minutes=int(s.get("interval_minutes") or 60))


# ---------------------------------------------------------------------------
# Reading, for the console
# ---------------------------------------------------------------------------

# The watch terms and their patterns are passed as parameters, the patterns
# rebuilt here from the validated terms (never read back from the table).
MATCHED = """ARRAY(SELECT w.term FROM unnest(%(terms)s::text[], %(pats)s::text[]) AS w(term, pat)
                    WHERE lower(coalesce(i.title,'') || ' ' || coalesce(i.summary,'') || ' '
                                || array_to_string(i.products, ' ')) ~ w.pat
                    ORDER BY w.term)"""

AFFECTING = """(SELECT count(DISTINCT ha.host_id) FROM advisory_cves ac
                  JOIN host_applicability ha ON ha.advisory_id = ac.advisory_id AND ha.state = 'affected'
                  JOIN hosts hh ON hh.id = ha.host_id AND hh.status <> 'decommissioned'
                 WHERE ac.cve_id = i.cve_id)"""

# Above the dashboard's lowest score, or unscored but rated serious by the vendor
SCORE_OK = """(i.cvss >= %(min)s::numeric
               OR (i.cvss IS NULL AND (%(min)s::numeric = 0
                   OR lower(coalesce(i.severity, '')) IN ('critical', 'important', 'high'))))"""


def _watch(conn):
    terms = []
    for r in conn.execute("SELECT term FROM cve_feed_watch WHERE enabled ORDER BY id").fetchall():
        try:
            terms.append(clean_term(r["term"]))
        except ValueError:
            continue
    return terms, [term_pattern(t) for t in terms]


def news(conn, source=None, watched_only=True, days=None, min_cvss=None, limit=200):
    s = settings(conn)
    days = int(days or s.get("days_back") or 14)
    min_cvss = float(min_cvss if min_cvss is not None else (s.get("min_cvss") or 0))
    terms, pats = _watch(conn)
    has_watch = bool(terms)
    rows = conn.execute(
        f"""SELECT * FROM (
              SELECT i.source, i.cve_id, i.published, i.title, i.severity, i.cvss,
                     (i.exploited OR coalesce(cd.kev, false)) AS exploited, i.products[1:6] AS products, i.url,
                     {MATCHED} AS matched, {AFFECTING} AS servers_affected
                FROM cve_feed_items i LEFT JOIN cve_details cd ON cd.cve_id = i.cve_id
               WHERE i.published >= now() - make_interval(days => %(days)s::int)
                 AND (%(source)s::text IS NULL OR i.source = %(source)s::text)
                 AND {SCORE_OK}
            ) x
            WHERE NOT %(watched)s::boolean OR cardinality(matched) > 0 OR servers_affected > 0
            ORDER BY published DESC LIMIT %(limit)s::int""",
        {"days": days, "source": source, "min": min_cvss, "watched": bool(watched_only and has_watch),
         "limit": int(limit), "terms": terms, "pats": pats}).fetchall()
    return {"items": rows, "days": days, "watch_list": has_watch}


def public_news(conn, per_source=25):
    """For the sign-in page: the general feed only, never the watch list."""
    s = settings(conn)
    if not s.get("signin_board"):
        return {"enabled": False, "sources": {}}
    out = {}
    for src in ("nist", "msrc", "redhat"):
        # Every column is always present, so the page does not show which
        # sources are switched on here
        if not s.get(src):
            out[src] = []
            continue
        out[src] = conn.execute(
            """SELECT cve_id, published, left(title, 180) AS title, severity, cvss, exploited, url
                 FROM cve_feed_items i
                WHERE source = %s AND general
                  AND published >= now() - make_interval(days => %s::int)
                  AND (exploited OR coalesce(cvss, 0) >= 7
                       OR lower(coalesce(severity, '')) IN ('critical', 'high', 'important'))
                ORDER BY published DESC LIMIT %s""",
            (src, int(s.get("days_back") or 14), per_source)).fetchall()
    return {"enabled": True, "sources": out}


def summary(conn):
    """Counts for the dashboard: watched CVEs in the window, by severity, one
    count per CVE whichever sources reported it."""
    s = settings(conn)
    terms, pats = _watch(conn)
    r = conn.execute(
        f"""WITH per_source AS (
              SELECT i.cve_id, lower(coalesce(i.severity, '')) AS sev, i.cvss,
                     (i.exploited OR coalesce(cd.kev, false)) AS exploited,
                     cardinality({MATCHED}) AS m, {AFFECTING} AS a
                FROM cve_feed_items i LEFT JOIN cve_details cd ON cd.cve_id = i.cve_id
               WHERE i.published >= now() - make_interval(days => %(days)s::int)
                 AND {SCORE_OK}),
            x AS (
              SELECT cve_id,
                     max(CASE WHEN sev = 'critical' OR cvss >= 9 THEN 4
                              WHEN sev IN ('high', 'important') OR cvss >= 7 THEN 3
                              WHEN sev IN ('medium', 'moderate') OR cvss >= 4 THEN 2 ELSE 1 END) AS rank,
                     bool_or(exploited) AS exploited, bool_or(m > 0) AS watched, max(a) AS a
                FROM per_source GROUP BY cve_id)
            SELECT count(*) FILTER (WHERE rank = 4) AS critical,
                   count(*) FILTER (WHERE rank = 3) AS high,
                   count(*) FILTER (WHERE rank = 2) AS medium,
                   count(*) FILTER (WHERE rank = 1) AS low,
                   count(*) FILTER (WHERE exploited) AS exploited,
                   count(*) FILTER (WHERE a > 0) AS affecting
              FROM x WHERE NOT %(watched)s::boolean OR watched OR a > 0""",
        {"days": int(s.get("days_back") or 14), "min": float(s.get("min_cvss") or 0), "watched": bool(terms),
         "terms": terms, "pats": pats}).fetchone()
    state = conn.execute("SELECT source, last_run, last_ok, items, error FROM cve_feed_state ORDER BY source").fetchall()
    return {"counts": r, "days": int(s.get("days_back") or 14), "watch_list": bool(terms), "state": state}


# ---------------------------------------------------------------------------

def main(argv=None):
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    argv = argv if argv is not None else sys.argv[1:]
    from .hardening import _db
    with _db() as conn:
        if argv and argv[0] == "sync":
            print(json.dumps(sync_all(conn), indent=1, default=str))
            return 0
        for r in conn.execute("SELECT * FROM cve_feed_state ORDER BY source").fetchall():
            print(f"  {r['source']:7} last ok {r['last_ok']}  items {r['items']}  error {r['error'] or '-'}")
        n = conn.execute("SELECT source, count(*) AS n FROM cve_feed_items GROUP BY 1 ORDER BY 1").fetchall()
        print("  stored: " + ", ".join(f"{x['source']} {x['n']}" for x in n))
    return 0


if __name__ == "__main__":
    sys.exit(main())
