/* Cyber-Secure: the dashboard, the CVE news boards, the sign-in welcome and
 * the CVE feed settings.
 *
 * Everything shown is text from the API, written with textContent (the h()
 * helper); nothing is inserted as HTML. Links to CVE pages are built by the
 * API, always to the vendor's own site, and open with no referrer.
 */

/* ---- brand ---------------------------------------------------------------- */

const PORTAL = "Cyber-Secure";
let brandInfo = null;

async function loadBrand() {
  if (brandInfo) return brandInfo;
  try {
    const r = await fetch("/api/v1/public/brand", { headers: { Accept: "application/json" } });
    brandInfo = r.ok ? await r.json() : { has_logo: false, has_logo_white: false };
  } catch (e) { brandInfo = { has_logo: false, has_logo_white: false }; }
  return brandInfo;
}

function isDarkTheme() {
  const t = document.documentElement.getAttribute("data-theme");
  return t === "dark" || t === "hacker";
}

/* The logo for a dark background (the top bar is dark in every theme). */
function logoImg(onDark, cls) {
  const b = brandInfo || {};
  if (!b.has_logo && !b.has_logo_white) return null;
  const variant = onDark && b.has_logo_white ? "white" : "main";
  const img = h("img", { class: cls + (onDark && !b.has_logo_white ? " logo-chip" : ""),
                         src: "/api/v1/public/logo?variant=" + variant, alt: "", decoding: "async" });
  img.addEventListener("error", () => img.remove());
  return img;
}

async function applyBrand() {
  await loadBrand();
  loadOrg();
  document.title = PORTAL;
  const a = document.querySelector(".top .brand");
  if (a && !a.dataset.branded) {
    a.dataset.branded = "1";
    const img = logoImg(true, "brand-logo-top");
    a.replaceChildren(...[img, h("span", { class: "brand-name" }, PORTAL)].filter(Boolean));
    a.classList.toggle("has-logo", !!img);
    a.title = PORTAL;
    a.setAttribute("aria-label", PORTAL + " dashboard");
  }
}

/* ---- donuts --------------------------------------------------------------- */

const SVGNS = "http://www.w3.org/2000/svg";
function svg(tag, attrs, ...kids) {
  const el = document.createElementNS(SVGNS, tag);
  Object.entries(attrs || {}).forEach(([k, v]) => { if (v !== null && v !== undefined) el.setAttribute(k, String(v)); });
  kids.flat().forEach(k => { if (k) el.append(k instanceof Node ? k : document.createTextNode(String(k))); });
  return el;
}

/* segs: [{label, value, cls, href?, note?}]. Each colour comes from a class,
 * so the theme decides it; the legend always names every segment, so colour
 * never carries meaning on its own. */
function donut(title, segs, opts = {}) {
  const total = segs.reduce((a, s) => a + (Number(s.value) || 0), 0);
  const R = 52, SW = 14, C = 2 * Math.PI * R, GAP = total && segs.filter(s => s.value > 0).length > 1 ? 2.5 : 0;
  const ring = svg("g", { transform: "rotate(-90 70 70)" },
    svg("circle", { cx: 70, cy: 70, r: R, class: "dn-track", "stroke-width": SW, fill: "none" }));
  const tip = h("div", { class: "dn-tip", role: "status", "aria-live": "polite" });
  let start = 0;
  const shown = [];
  segs.forEach((s, i) => {
    const v = Number(s.value) || 0;
    if (!total || v <= 0) return;
    const len = Math.max(0.8, (v / total) * C - GAP);
    const pct = Math.round((v / total) * 100);
    const arc = svg("circle", {
      cx: 70, cy: 70, r: R, fill: "none", "stroke-width": SW, class: "dn-seg " + s.cls,
      "stroke-dasharray": "0 " + C, "stroke-dashoffset": -start, "data-len": len, "data-c": C, tabindex: 0,
      role: "img", "aria-label": s.label + ": " + v + " (" + pct + "%)" },
      svg("title", null, s.label + ": " + v + " (" + pct + "%)"));
    const show = () => { tip.textContent = s.label + ": " + v + " (" + pct + "%)" + (s.note ? " · " + s.note : ""); };
    arc.addEventListener("mouseenter", show);
    arc.addEventListener("focus", show);
    arc.addEventListener("mouseleave", () => { tip.textContent = ""; });
    if (s.href) arc.addEventListener("click", () => { location.hash = s.href; });
    if (s.href) arc.classList.add("dn-link");
    ring.append(arc);
    shown.push(arc);
    start += (v / total) * C;
  });
  const centre = svg("text", { x: 70, y: 68, "text-anchor": "middle", class: "dn-total" },
    opts.centre !== undefined ? opts.centre : String(total));
  const sub = svg("text", { x: 70, y: 88, "text-anchor": "middle", class: "dn-sub" },
    opts.centreLabel || (total ? "total" : "no data yet"));
  const pic = svg("svg", { viewBox: "0 0 140 140", class: "dn-svg", "aria-hidden": "true", focusable: "false" }, ring, centre, sub);
  const legend = h("ul", { class: "dn-legend" }, segs.map(s => {
    const v = Number(s.value) || 0;
    const label = h("span", { class: "dn-l", title: s.label }, s.label);
    return h("li", { class: v ? null : "dn-zero" },
      h("span", { class: "dn-key " + s.cls, "aria-hidden": "true" }),
      s.href ? h("a", { href: s.href }, label) : label,
      h("span", { class: "dn-v" }, String(v)),
      h("span", { class: "dn-p" }, total ? Math.round((v / total) * 100) + "%" : ""));
  }));
  // Draw the arcs once they are in the page, so they sweep in
  requestAnimationFrame(() => requestAnimationFrame(() => shown.forEach(a => {
    a.setAttribute("stroke-dasharray", a.dataset.len + " " + (Number(a.dataset.c) - Number(a.dataset.len)));
  })));
  return h("section", { class: "dn-card", "aria-label": title + ": " + segs.map(s => s.label + " " + (s.value || 0)).join(", ") },
    h("h2", { class: "dn-h" }, title),
    opts.caption ? h("p", { class: "dn-cap" }, opts.caption) : null,
    h("div", { class: "dn-body" }, h("div", { class: "dn-pic" }, pic, tip), legend));
}

/* ---- news board ------------------------------------------------------------ */

const FEED_NAME = { nist: "NIST NVD", msrc: "Microsoft", redhat: "Red Hat" };
const SEV_CLASS = { critical: "sv-crit", high: "sv-high", important: "sv-high", medium: "sv-med", moderate: "sv-med", low: "sv-low" };

function sevChip(sev, cvss) {
  const s = (sev || "").toLowerCase();
  return h("span", { class: "sv " + (SEV_CLASS[s] || "sv-low") },
    (s ? s.charAt(0).toUpperCase() + s.slice(1) : "Unrated") + (cvss !== null && cvss !== undefined ? " " + Number(cvss).toFixed(1) : ""));
}

function safeVendorUrl(u) {
  // Only the three vendors' own sites, over HTTPS
  return /^https:\/\/(nvd\.nist\.gov|msrc\.microsoft\.com|access\.redhat\.com)\//.test(u || "") ? u : null;
}

function newsItem(it, opts = {}) {
  const url = safeVendorUrl(it.url);
  const id = url ? h("a", { href: url, target: "_blank", rel: "noopener noreferrer", class: "nw-id" }, it.cve_id)
                 : h("span", { class: "nw-id" }, it.cve_id);
  const when = it.published ? new Date(it.published) : null;
  return h("li", { class: "nw-item" + (it.exploited ? " nw-kev" : "") },
    h("div", { class: "nw-top" },
      sevChip(it.severity, it.cvss), id,
      opts.source ? h("span", { class: "nw-src" }, FEED_NAME[it.source] || it.source) : null,
      it.exploited ? h("span", { class: "nw-flag" }, "0-day") : null,
      h("time", { class: "nw-when", datetime: it.published || "" }, when ? when.toLocaleDateString(undefined, { day: "numeric", month: "short" }) : "")),
    h("p", { class: "nw-title" }, it.title || ""),
    (it.matched && it.matched.length) || it.servers_affected ? h("div", { class: "nw-tags" },
      (it.matched || []).map(m => h("span", { class: "nw-tag" }, m)),
      it.servers_affected ? h("span", { class: "nw-tag nw-hit" },
        it.servers_affected === 1 ? "1 of your servers" : it.servers_affected + " of your servers") : null) : null);
}

/* ---- the dashboard ---------------------------------------------------------- */

const OS_CLASSES = ["c-cat1", "c-cat2", "c-cat3", "c-cat4", "c-cat5", "c-cat6"];

/* ---- modules and who may open them ------------------------------------------ */

const MODULES = [
  { key: "patch", label: "Patch Dashboard", href: "#/dashboard",
    desc: "Servers, patches, CVEs, changes and hardening" },
  { key: "inventory", label: "Asset & Inventory", href: "#/assets",
    desc: "Every machine and its software, from agents, vCenter and WSUS" },
  { key: "lifecycle", label: "Software Lifecycle", href: "#/installers",
    desc: "Approved installers, software installs and removals" },
];
const ALL_MODULES = MODULES.map(m => m.key);

/* The console only shows and hides; the API refuses what a user may not
 * open, whatever the browser does. */
function myModules() {
  const a = getAuth();
  if (!a) return [];
  if (a.user.role === "admin") return ALL_MODULES.slice();
  return Array.isArray(a.user.modules) ? a.user.modules.filter(m => ALL_MODULES.includes(m)) : [];
}
function hasModule(...keys) { const mine = myModules(); return keys.some(k => mine.includes(k)); }

// Which modules each page belongs to (any one of them opens it)
const ROUTE_MODULES = {
  dashboard: ["patch"], impact: ["patch"], hosts: ["patch"], host: ["patch"], agents: ["patch"],
  advisories: ["patch"], vulns: ["patch"], hardening: ["patch"], assess: ["patch"], wsus: ["patch"],
  vmware: ["patch", "inventory"], assets: ["inventory"], "software-inventory": ["inventory"], software: ["inventory"],
  installers: ["lifecycle"], changes: ["patch", "lifecycle"], change: ["patch", "lifecycle"],
  activity: ["patch", "inventory", "lifecycle"], antivirus: ["inventory", "patch"],
};

function routeAllowed(first) {
  const need = ROUTE_MODULES[first];
  return !need || hasModule(...need);
}

function applyModuleNav() {
  document.querySelectorAll("nav a[data-modules]").forEach(el => {
    const need = el.dataset.modules.split(",");
    const allowed = hasModule(...need) && (!el.dataset.minRole || can(el.dataset.minRole));
    el.hidden = !allowed;
  });
}

let meCheckedAt = 0;
/* Pick up access an admin changed while this user is signed in. */
async function refreshMe(force) {
  const a = getAuth();
  if (!a || (!force && Date.now() - meCheckedAt < 60000 && Array.isArray(a.user.modules))) return;
  meCheckedAt = Date.now();
  try {
    const me = await api("/auth/me");
    const s = getAuth();
    if (!s) return;
    const changed = JSON.stringify(s.user.modules) !== JSON.stringify(me.modules) || s.user.role !== me.role;
    s.user.modules = me.modules; s.user.role = me.role;
    setSession(s);
    if (changed) applyModuleNav();
  } catch (e) { /* the next page load tries again */ }
}

function noAccess(first) {
  const mods = (ROUTE_MODULES[first] || []).map(k => (MODULES.find(m => m.key === k) || {}).label).filter(Boolean);
  render(h("div", { class: "empty" },
    h("h2", null, "No access"),
    h("p", null, "This page is part of " + mods.join(" or ") + ". Your account does not have access to it; "
      + "ask an admin to grant it under Admin, Access."),
    h("p", null, h("a", { href: "#/" }, "Back to the home page"))));
}

/* The three module buttons, small icons: lit when the user may open the
 * module, grey when not. Before sign-in they are all lit and lead to the
 * sign-in form. */
const MOD_ICONS = {
  // shield with a check: patching
  patch: [["path", { d: "M12 3l7 3v5c0 4.4-3 8.3-7 9.5C8 19.3 5 15.4 5 11V6z" }], ["path", { d: "M8.8 11.8l2.2 2.2 4.4-4.6" }]],
  // stacked boxes: assets
  inventory: [["rect", { x: "4", y: "4", width: "7", height: "7", rx: "1.2" }], ["rect", { x: "13", y: "4", width: "7", height: "7", rx: "1.2" }],
              ["rect", { x: "4", y: "13", width: "7", height: "7", rx: "1.2" }], ["rect", { x: "13", y: "13", width: "7", height: "7", rx: "1.2" }]],
  // circular arrows: lifecycle
  lifecycle: [["path", { d: "M19 12a7 7 0 0 1-12.2 4.7" }], ["path", { d: "M5 12a7 7 0 0 1 12.2-4.7" }],
              ["path", { d: "M17.5 3.8v3.7h-3.7" }], ["path", { d: "M6.5 20.2v-3.7h3.7" }]],
};
const MOD_SHORT = { patch: "Patch", inventory: "Assets", lifecycle: "Lifecycle" };

function modIcon(key) {
  return svg("svg", { viewBox: "0 0 24 24", class: "mod-ico", "aria-hidden": "true", focusable: "false" },
    (MOD_ICONS[key] || []).map(([tag, attrs]) => svg(tag, attrs)));
}

function moduleButtons(opts = {}) {
  const signedIn = !!getAuth();
  return h("div", { class: "mod-row", role: "group", "aria-label": "Modules" }, MODULES.map(m => {
    const ok = !signedIn || hasModule(m.key);
    const tip = ok ? m.label + ": " + m.desc : m.label + ": your account does not have access. Ask an admin.";
    if (!ok) {
      return h("span", { class: "mod-btn mod-off", role: "link", "aria-disabled": "true", "aria-label": tip, title: tip },
        modIcon(m.key), h("span", { class: "mod-t" }, MOD_SHORT[m.key]));
    }
    return h("a", { class: "mod-btn mod-on", href: signedIn ? m.href : "#/", "aria-label": m.label, title: tip,
                    on: signedIn ? null : { click: e => { e.preventDefault(); opts.onPick && opts.onPick(m); } } },
      modIcon(m.key), h("span", { class: "mod-t" }, MOD_SHORT[m.key]));
  }));
}

/* ---- the CVE scroller: critical, high and 0-day only ------------------------- */

let scrollerTimer = null;

function scrollerItem(it, hidden) {
  const url = safeVendorUrl(it.url);
  const attrs = hidden ? { tabindex: "-1" } : {};
  const id = url ? h("a", Object.assign({ href: url, target: "_blank", rel: "noopener noreferrer", class: "nw-id" }, attrs), it.cve_id)
                 : h("span", { class: "nw-id" }, it.cve_id);
  const when = it.published ? new Date(it.published) : null;
  return h("li", { class: "sc-item" + (it.exploited ? " nw-kev" : "") },
    h("div", { class: "nw-top" },
      it.exploited ? h("span", { class: "sv sv-crit sv-0day" }, "0-day") : sevChip(it.severity, it.cvss),
      id, h("span", { class: "nw-src" }, FEED_NAME[it.source] || it.source),
      h("time", { class: "nw-when", datetime: it.published || "" },
        when ? when.toLocaleDateString(undefined, { day: "numeric", month: "short" }) : "")),
    h("p", { class: "nw-title" }, it.title || ""));
}

function cveScroller() {
  const track = h("div", { class: "sc-track" });
  const box = h("div", { class: "sc-window", tabindex: "0", "aria-label": "Critical, high and 0-day CVEs; hover or focus to pause" }, track);
  const panel = h("section", { class: "signin-news sc-panel", "aria-labelledby": "sc-h" },
    h("div", { class: "sc-head" },
      h("h2", { id: "sc-h" }, "Critical, High & 0-day CVEs"),
      h("span", { class: "sc-live", "aria-hidden": "true" }, "LIVE")),
    h("p", { class: "muted small" }, "Just published by NIST, Microsoft and Red Hat"),
    box);
  async function load() {
    let d = null;
    try {
      const r = await fetch("/api/v1/public/news", { headers: { Accept: "application/json" } });
      d = r.ok ? await r.json() : null;
    } catch (e) { d = null; }
    if (!panel.isConnected) { clearInterval(scrollerTimer); return; }
    if (!d || !d.enabled) { panel.hidden = true; return; }
    const items = [];
    Object.entries(d.sources || {}).forEach(([src, rows]) => rows.forEach(r => items.push(Object.assign({ source: src }, r))));
    items.sort((a, b) => String(b.published).localeCompare(String(a.published)));
    if (!items.length) {
      track.replaceChildren(h("p", { class: "muted small" }, "No critical, high or 0-day CVEs in this period."));
      box.classList.add("sc-static");
      return;
    }
    const list = h("ul", { class: "sc-list" }, items.map(i => scrollerItem(i, false)));
    // A second copy follows the first, so the loop is seamless; screen readers skip it
    const copy = h("ul", { class: "sc-list", "aria-hidden": "true" }, items.map(i => scrollerItem(i, true)));
    track.replaceChildren(list, copy);
    track.style.setProperty("--sc-dur", Math.max(30, items.length * 4) + "s");
    box.classList.toggle("sc-static", items.length < 4);
    if (items.length < 4) copy.remove();
  }
  load();
  clearInterval(scrollerTimer);
  scrollerTimer = setInterval(load, 120000);
  return panel;
}

function welcomeBlock(extra) {
  return h("div", { class: "signin-welcome" },
    logoImg(isDarkTheme(), "signin-logo"),
    h("p", { class: "signin-kicker" }, "Welcome to the"),
    h("h1", { class: "signin-title", "data-cmd": "login" }, PORTAL + " Dashboard portal"),
    h("p", { class: "ai-badge" }, h("span", { class: "ai-dot", "aria-hidden": "true" }), "AI powered dashboard"),
    h("p", { class: "muted" }, "Patch, vulnerability, inventory and software lifecycle in one place, analysed by AI-01."),
    extra || null);
}

/* ---- sign-in page ------------------------------------------------------------ */

const AFTER_KEY = "cs.after";

async function signinDecor(formEl) {
  await loadBrand();
  if (!formEl.isConnected) return null;      // the user moved on (signed in) meanwhile
  const prevFocus = document.activeElement;  // moving the form into the layout drops focus
  const hint = h("p", { class: "mod-hint", role: "status" });
  const buttons = moduleButtons({ onPick: m => {
    try { sessionStorage.setItem(AFTER_KEY, m.key); } catch (e) { /* private mode */ }
    hint.textContent = "Sign in to open " + m.label + ".";
    const u = formEl.querySelector("input[name=user]");
    if (u) u.focus();
  } });
  const wrap = h("div", { class: "signin-page" },
    h("div", { class: "signin-left" }, welcomeBlock(buttons), hint, formEl), cveScroller());
  wrap.prevFocus = prevFocus;
  return wrap;
}

/* After sign-in: go where the user was heading, if they may. */
function takeAfterSignIn() {
  let k = null;
  try { k = sessionStorage.getItem(AFTER_KEY); sessionStorage.removeItem(AFTER_KEY); } catch (e) { k = null; }
  const m = MODULES.find(x => x.key === k);
  if (m && hasModule(m.key)) {
    if (location.hash === m.href) route(); else location.hash = m.href;
    return true;
  }
  return false;
}

/* ---- home: the same welcome, with this user's modules lit ---------------------- */

async function renderHome() {
  setNav("home");
  await loadBrand();
  await refreshMe(true);
  const a = getAuth();
  const name = (a && (a.user.display_name || a.user.username)) || "";
  const mine = myModules();
  render(h("div", { class: "signin-page home-page" },
    h("div", { class: "signin-left" },
      welcomeBlock(moduleButtons()),
      h("p", { class: "muted small home-who" }, "Signed in as " + name + ". "
        + (mine.length === ALL_MODULES.length ? "You can open every module."
          : mine.length ? "Greyed-out modules need an admin to grant access."
          : "Your account has no modules yet: ask an admin to grant access under Admin, Access."))),
    cveScroller()));
}

/* ---- the Patch Dashboard ----------------------------------------------------- */

async function renderCyberDashboard() {
  setNav("overview");
  applyBrand();
  const [d, imp] = await Promise.all([api("/dashboard/summary"), api("/impact").catch(() => null)]);
  const page = h("div", { class: "cy" });
  render(page);
  drawDashboard(page, d, imp);
  setPageTimer(async () => {
    if (document.hidden) return;
    try {
      const [d2, i2] = await Promise.all([api("/dashboard/summary"), api("/impact").catch(() => null)]);
      if (!document.body.contains(page)) return;
      const y = window.scrollY;
      drawDashboard(page, d2, i2, true);
      window.scrollTo(0, y);
    } catch (e) { /* keep the last figures; the next tick retries */ }
  }, 60000);
}

const VERDICT = {
  affected: ["Affected", "c-bad"], pending_reboot: ["Fixed, reboot needed", "c-warn"],
  potentially_affected: ["Possibly affected", "c-mod"], not_found: ["Not in inventory", "c-muted"],
  not_tracked: ["Not inventoried (e.g. network gear)", "c-cat6"],
};

function impactCard(d, imp) {
  const ic = (d.feeds && d.feeds.impact) || (imp && imp.counts) || null;
  const days = (d.feeds && d.feeds.days) || (imp && imp.days) || 14;
  const segs = ic ? ["affected", "pending_reboot", "potentially_affected", "not_found", "not_tracked"].map(k =>
    ({ label: VERDICT[k][0], value: ic[k] || 0, cls: VERDICT[k][1], href: "#/impact?verdict=" + k })) : [];
  const dn = donut("Impacted CVEs", segs, {
    caption: ic ? "New critical, high and 0-day CVEs (last " + days + " days) matched to your software and hardware"
                : "Waiting for the first analysis: rebuild the API and worker (phase3b-api.sh)",
    centreLabel: ic ? "analysed" : "not yet" });
  const top = ((imp && imp.items) || []).filter(i => ["affected", "pending_reboot", "potentially_affected"].includes(i.verdict)).slice(0, 4);
  const list = h("ul", { class: "imp-top" }, top.length ? top.map(i => h("li", null,
    h("div", { class: "nw-top" },
      i.exploited ? h("span", { class: "sv sv-crit sv-0day" }, "0-day") : sevChip(i.severity, i.cvss),
      h("a", { href: "#/impact?cve=" + encodeURIComponent(i.cve_id), class: "nw-id" }, i.cve_id),
      h("span", { class: "imp-v " + VERDICT[i.verdict][1] }, VERDICT[i.verdict][0]),
      h("span", { class: "nw-src" }, i.machines === 1 ? "1 machine" : i.machines + " machines")),
    h("p", { class: "imp-ai" + (i.ai_summary ? "" : " imp-wait") },
      i.ai_summary ? h("span", { class: "ai-tag" }, "AI") : null,
      i.ai_summary ? " " + i.ai_summary.split(/\n\s*\n/)[0] : (i.title || "") + " · AI-01 brief pending")))
    : [h("li", { class: "muted small" }, ic ? "Nothing new is affecting your machines." : "")]);
  return h("section", { class: "dn-card imp-card" },
    h("div", { class: "imp-grid" }, dn,
      h("div", { class: "imp-side" },
        h("h3", null, "Needs your attention", h("span", { class: "ai-badge ai-small" }, h("span", { class: "ai-dot" }), "AI analysed")),
        list,
        h("a", { href: "#/impact", class: "small" }, "All impacted CVEs, where they were found, and AI-01's briefs"))));
}

function drawDashboard(page, d, imp, quiet) {
  const s = d.servers || {}, a = d.advisories || {}, sv = d.severity || {}, ag = d.agents || {};
  const f = (d.feeds && d.feeds.counts) || null;
  const ic = (d.feeds && d.feeds.impact) || null;
  const at = d.at ? new Date(d.at) : new Date();
  const hero = (n, label, cls, href) => h(href ? "a" : "div", { class: "cy-hero " + (cls || ""), href: href || null },
    h("span", { class: "cy-n" }, n === null || n === undefined ? "–" : String(n)), h("span", { class: "cy-l" }, label));

  const head = h("div", { class: "page-head cy-head" },
    h("div", null,
      h("h1", { "data-cmd": "cybersecure status" }, "Patch Dashboard"),
      h("p", { class: "muted small" }, "Live security posture · updated " + at.toLocaleTimeString() + " · refreshes every minute")),
    h("div", { class: "cy-heroes" },
      hero(d.compliance_pct === null ? null : d.compliance_pct + "%", "patch compliance", "cy-ok"),
      hero(s.total || 0, "servers", "", "#/hosts"),
      hero(sv.critical || 0, "critical updates outstanding", sv.critical ? "cy-bad" : "", "#/advisories?state=affected"),
      ic ? hero(ic.affected || 0, "CVEs affecting your machines", ic.affected ? "cy-bad" : "", "#/impact?verdict=affected") : null));

  if (!s.total) {
    page.replaceChildren(head, h("div", { class: "empty" },
      h("h2", null, "No servers have enrolled yet"),
      h("p", null, "Issue a token with ", h("code", null, "./scripts/phase3b-api.sh --token"),
        ", then install the agent on a server. It appears here within a minute.")));
    return;
  }

  const grid = h("div", { class: "cy-grid" },
    impactCard(d, imp),
    donut("Servers", [
      { label: "Patched", value: s.patched, cls: "c-ok", href: "#/hosts" },
      { label: "Needs patches", value: s.needs_patch, cls: "c-bad", href: "#/advisories?state=affected" },
      { label: "Needs a reboot", value: s.needs_reboot, cls: "c-warn", href: "#/advisories?state=fixed_pending_reboot" },
      { label: "Not reporting", value: s.not_reporting, cls: "c-muted", href: "#/hosts?agent=offline", note: "status unknown until it reports" },
    ], { caption: "Each server once, by its worst state" }),
    donut("Updates", [
      { label: "To install", value: (a.to_install || 0) + (a.windows_to_install || 0), cls: "c-bad",
        note: (a.to_install || 0) + " Linux advisories, " + (a.windows_to_install || 0) + " Windows updates" },
      { label: "Installed, reboot needed", value: a.awaiting_reboot, cls: "c-warn" },
      { label: "Installed", value: a.installed, cls: "c-ok" },
    ], { caption: "Per server and update" }),
    donut("Outstanding by severity", [
      { label: "Critical", value: sv.critical, cls: "c-bad" },
      { label: "Important", value: sv.important, cls: "c-warn" },
      { label: "Moderate", value: sv.moderate, cls: "c-mod" },
      { label: "Low or unrated", value: sv.low_or_unrated, cls: "c-muted" },
    ], { caption: "Distinct advisories and updates still to install" }),
    donut("Operating systems", (d.os || []).map((o, i) => (
      { label: o.os, value: o.n, cls: o.os === "Other" ? "c-muted" : OS_CLASSES[i] || "c-muted" })),
      { caption: "Servers with an agent" }),
    donut("Agents", [
      { label: "Online", value: ag.online || 0, cls: "c-ok", href: "#/hosts?agent=online" },
      { label: "Offline", value: ag.offline || 0, cls: "c-warn", href: "#/hosts?agent=offline" },
      { label: "Not reporting", value: ag.not_reporting || 0, cls: "c-bad", href: "#/hosts?agent=not_reporting" },
      { label: "Never reported", value: ag.no_data || 0, cls: "c-muted", href: "#/hosts?agent=no_data" },
    ]),
    f ? donut("New CVEs (feeds)", [
      { label: "Critical", value: f.critical, cls: "c-bad" },
      { label: "High", value: f.high, cls: "c-warn" },
      { label: "Medium", value: f.medium, cls: "c-mod" },
      { label: "Low", value: f.low, cls: "c-muted" },
    ], { caption: (d.feeds.watch_list ? "Your watched software" : "All software (no watch list yet)")
                 + ", last " + d.feeds.days + " days · " + (f.exploited || 0) + " 0-day" })
      : donut("New CVEs (feeds)", [], { caption: "Feeds are not set up yet: Admin, CVE feeds", centreLabel: "not set up" }));

  page.replaceChildren(head, grid);
  if (quiet) page.querySelectorAll(".dn-seg").forEach(x => x.classList.add("dn-noanim"));
}

/* ---- Vulnerabilities: detected CVEs, advisories and assessments, one place ------ */

function vulnTabs(active) {
  setNav("vulns");
  const tabs = [["impact", "Detected CVEs", "New CVEs from NIST, Microsoft and Red Hat matched to our machines"],
                ["advisories", "Advisories", "Vendor advisories and Windows updates still to install"],
                ["assess", "Assess CVEs", "Check a given or uploaded list of CVEs"]];
  const el = h("div", { class: "filters vu-tabs", role: "group", "aria-label": "Vulnerabilities" },
    tabs.map(([k, label, tip]) => h("a", { class: "fbtn", href: "#/" + k, title: tip, "aria-pressed": String(k === active) }, label)));
  const view = document.getElementById("view");
  if (view && !view.querySelector(".vu-tabs")) view.prepend(el);
}

/* A table whose rows open with +. cols: [{label, num, cell}]; detail(row)
 * returns the content shown under an opened row (it may be async). */
function plusTable(cols, rows, detail, opts = {}) {
  const open = opts.open || new Set();
  const key = opts.key || (r => JSON.stringify(r).slice(0, 80));
  const tbody = h("tbody");
  rows.forEach(r => {
    const k = key(r);
    const isOpen = open.has(k);
    const btn = h("button", { type: "button", class: "srv-plus", "aria-expanded": String(isOpen),
                              "aria-label": (isOpen ? "Hide" : "Show") + " details" }, isOpen ? "−" : "+");
    const cell = h("td", { colspan: String(cols.length + 1) });
    const det = h("tr", { class: "vu-detail srv-detail", hidden: !isOpen }, cell);
    const fill = async () => {
      if (cell.firstChild) return;
      cell.append(h("p", { class: "muted small" }, "Loading"));
      try { const c = await detail(r); cell.replaceChildren(...[].concat(c).flat(3).filter(Boolean)); }
      catch (e) { cell.replaceChildren(h("p", { class: "hd-failed" }, e.message || "Could not load the details.")); }
    };
    if (isOpen) fill();
    btn.addEventListener("click", () => {
      const now = !open.has(k);
      now ? open.add(k) : open.delete(k);
      btn.textContent = now ? "−" : "+";
      btn.setAttribute("aria-expanded", String(now));
      btn.setAttribute("aria-label", (now ? "Hide" : "Show") + " details");
      det.hidden = !now;
      if (now) fill();
    });
    tbody.append(h("tr", { class: "srv-row" + (opts.rowClass ? " " + opts.rowClass(r) : "") },
      h("td", { class: "srv-c-plus" }, btn),
      cols.map(c => h("td", { class: c.num ? "num" : null }, c.cell(r)))), det);
  });
  return h("div", { class: "table-wrap" }, h("table", { class: "srv-table" },
    h("thead", null, h("tr", null, h("th", { scope: "col" }), cols.map(c => h("th", { scope: "col", class: c.num ? "num" : null }, c.label)))),
    tbody));
}

function pager(page, pages, total, size, go) {
  if (pages <= 1) return document.createDocumentFragment();
  return h("nav", { class: "srv-pager", "aria-label": "Pages" },
    h("button", { type: "button", class: "btn btn-quiet", disabled: page <= 1, on: { click: () => go(page - 1) } }, "‹ Previous"),
    h("span", null, "Page " + page + " of " + pages + " · " + ((page - 1) * size + 1) + "–" + Math.min(total, page * size) + " of " + total),
    h("button", { type: "button", class: "btn btn-quiet", disabled: page >= pages, on: { click: () => go(page + 1) } }, "Next ›"));
}

/* Where a CVE was found: each machine with its own record (address, OS,
 * where it is known from), then the machines ruled out and why. */
function whereTable(lines, info = {}) {
  const ex = ((info.excluded || {}).machines || []);
  const notes = ((info.excluded || {}).notes || []);
  const out = [];
  if ((info.platforms || []).length) out.push(h("p", { class: "small vu-plat" }, h("strong", null, "Applies to: "),
    info.platforms.join(", "), h("span", { class: "muted" }, " · a machine counts only if it runs one of these")));
  out.push(lines.length ? h("div", { class: "cm-table" }, table([
    { label: "Machine", nowrap: true, cell: m => m.name ? h("strong", null, m.name) : "–" },
    { label: "Address", nowrap: true, cell: m => m.ip || h("span", { class: "muted" }, "–") },
    { label: "Operating system", cell: m => m.os ? [m.os, m.os_note ? h("span", { class: "muted small", title: m.os_note }, " ⚠") : null]
                                                 : h("span", { class: "muted" }, "unknown") },
    { label: "Found", cell: m => [m.version || m.product || "", h("div", { class: "muted small" }, m.where || m.kind || "")] },
    { label: "Certainty", nowrap: true, cell: m => String(m.certainty || "").replace(/_/g, " ") },
    { label: "Why", cell: m => [m.detail || "", m.basis ? h("div", { class: "muted small" }, "Source: " + m.basis) : null,
                                (m.sources || []).length ? h("div", { class: "muted small" }, "Known from: " + m.sources.join(", ")) : null] },
  ], lines)) : h("p", { class: "muted small" }, "Not found on any machine whose platform matches."));
  if (ex.length) {
    const judged = ex.filter(e => !e.not_judged), nj = ex.filter(e => e.not_judged);
    const det = h("details", { class: "vu-ex" }, h("summary", null,
      "Ruled out: " + judged.length + " machine" + (judged.length === 1 ? "" : "s")
      + (nj.length ? ", not judged: " + nj.length : "")),
      h("div", { class: "cm-table" }, table([
        { label: "Machine", nowrap: true, cell: e => e.name || "" },
        { label: "Address", nowrap: true, cell: e => e.ip || "–" },
        { label: "Operating system", cell: e => e.os || "unknown" },
        { label: "Product", cell: e => e.product || "" },
        { label: "Why not counted", cell: e => e.reason || "" },
      ], judged.concat(nj))));
    out.push(det);
  }
  notes.forEach(n => out.push(h("p", { class: "muted small" }, n)));
  return out;
}

const PIPELINE_STEPS = [
  ["CVE database", "NIST NVD, Microsoft, Red Hat: what is vulnerable, and on which platform"],
  ["Assets", "Every machine from agents, WSUS and vCenter: name, address, operating system"],
  ["Software", "Linux packages against Red Hat's fixed builds; Windows programs against NVD's ranges"],
  ["Operating systems", "Windows 10 Pro or Server 2019 counts even without an agent"],
  ["Hardware", "Server models, ESXi and vCenter versions"],
  ["Platform check", "A Windows-only CVE never counts on a Linux server; ruled-out machines are listed"],
  ["AI-01 brief", "Writes the summary; the verdict always comes from the data"]];
function pipeline() {
  return h("ol", { class: "vu-steps", "aria-label": "How a CVE is checked" },
    PIPELINE_STEPS.map(([t, d]) => h("li", { title: d }, h("strong", null, t), h("span", null, d))));
}

async function renderImpact(params) {
  const verdict = params.get("verdict") || "";
  const only = params.get("cve") || "";
  setMailParams(verdict ? { verdict } : {});
  const host = params.get("host") || "";
  const d = await api("/impact" + (verdict ? "?verdict=" + encodeURIComponent(verdict) : ""));
  const c = d.counts || {};
  const page = h("div");
  let q = "", pg = 1;
  const open = new Set(only ? [only] : []);
  const filters = h("div", { class: "filters", role: "group", "aria-label": "Verdict" },
    [["", "All"], ["affected", "Affected"], ["pending_reboot", "Reboot needed"], ["potentially_affected", "Possibly affected"],
     ["not_found", "Not in inventory"], ["not_tracked", "Not inventoried"]].map(([k, label]) =>
      h("a", { class: "fbtn", href: "#/impact" + (k ? "?verdict=" + k : ""), "aria-pressed": String(k === verdict) },
        label + (k && c[k] !== undefined ? " (" + c[k] + ")" : ""))));
  const search = h("input", { type: "search", placeholder: "Search CVE, title, machine or address", "aria-label": "Search CVEs", value: only });
  const box = h("div");
  const draw = () => {
    const needle = q.toLowerCase();
    const shortName = x => String(x || "").toLowerCase().split(".")[0];
    const onHost = i => !host || (i.matches || []).some(m => m.name && shortName(m.name) === shortName(host) && m.certainty !== "not_tracked");
    const items = (d.items || []).filter(i => onHost(i) && (!needle || (i.cve_id + " " + (i.title || "") + " "
      + (i.matches || []).map(m => (m.name || "") + " " + (m.ip || "")).join(" ")).toLowerCase().includes(needle)));
    setPageExport(() => ({ title: "Detected CVEs" + (host ? " on " + host : ""), filter: pageFilterText(),
      columns: ["CVE", "Severity", "CVSS", "0-day", "Verdict", "Machines", "Applies to", "Where found (machine, address, OS, certainty)",
                "Ruled out", "From", "Published", "Title", "AI-01 brief"],
      rows: items.map(i => [i.cve_id, i.severity || "", i.cvss, i.exploited ? "yes" : "", (VERDICT[i.verdict] || [i.verdict])[0], i.machines,
        (i.platforms || []).join(", "),
        (i.matches || []).filter(m => m.name).slice(0, 12).map(m => m.name + (m.ip ? " " + m.ip : "") + (m.os ? " [" + m.os + "]" : "")
          + " (" + String(m.certainty).replace(/_/g, " ") + ")").join("; "),
        (((i.excluded || {}).machines) || []).filter(e => !e.not_judged).slice(0, 12).map(e => e.name + ": " + e.reason).join("; "),
        (i.sources || []).map(x => FEED_NAME[x] || x).join(", "), i.published ? fmtDate(i.published) : "", i.title || "",
        (i.ai_summary || "").replace(/\s+/g, " ")]) }));
    const pages = Math.max(1, Math.ceil(items.length / 20));
    pg = Math.min(pg, pages);
    const rows = items.slice((pg - 1) * 20, pg * 20);
    box.replaceChildren(rows.length ? plusTable([
      { label: "CVE", cell: i => h("strong", { class: "mono" }, i.cve_id) },
      { label: "Severity", cell: i => i.exploited ? h("span", { class: "sv sv-crit sv-0day" }, "0-day") : sevChip(i.severity, i.cvss) },
      { label: "Verdict", cell: i => h("span", { class: "imp-v " + (VERDICT[i.verdict] || ["", "c-muted"])[1] }, (VERDICT[i.verdict] || [i.verdict])[0]) },
      { label: "Machines", num: true, cell: i => String(i.machines || 0) },
      { label: "Applies to", cell: i => (i.platforms || []).join(", ") },
      { label: "AI-01", cell: i => i.ai_summary ? h("span", { class: "ai-tag" }, "brief") : "" },
      { label: "From", cell: i => (i.sources || []).map(s => FEED_NAME[s] || s).join(", ") },
      { label: "Published", cell: i => i.published ? fmtDate(i.published) : "" },
      { label: "Title", cell: i => h("span", { class: "vu-title" }, i.title || "") },
    ], rows, i => {
      const url = i.sources && i.sources.includes("nist") ? "https://nvd.nist.gov/vuln/detail/" + i.cve_id
        : i.sources && i.sources.includes("msrc") ? "https://msrc.microsoft.com/update-guide/vulnerability/" + i.cve_id
        : "https://access.redhat.com/security/cve/" + i.cve_id.toLowerCase();
      const lines = (i.matches || []).filter(m => m.certainty !== "not_tracked" || !(i.matches || []).some(x => x.certainty !== "not_tracked"));
      return [
        i.ai_summary ? h("div", { class: "imp-brief" }, h("span", { class: "ai-tag" }, "AI-01"), ...i.ai_summary.split(/\n\s*\n/).map(p => h("p", null, p)))
          : ["affected", "pending_reboot", "potentially_affected"].includes(i.verdict)
            ? h("p", { class: "muted small" }, "AI-01's brief is being written; it appears within minutes.") : null,
        h("p", { class: "small" }, h("a", { href: url, target: "_blank", rel: "noopener noreferrer" }, "Vendor page for " + i.cve_id),
          " · checked " + timeAgo(i.analysed_at)),
        whereTable(lines, i)];
    }, { open, key: i => i.cve_id, rowClass: i => i.exploited ? "vu-kev" : "" })
      : h("div", { class: "empty" }, h("p", null, "Nothing here.")),
      pager(pg, pages, items.length, 20, n => { pg = n; draw(); }));
  };
  let t = null;
  search.addEventListener("input", () => { clearTimeout(t); t = setTimeout(() => { q = search.value.trim(); pg = 1; draw(); }, 250); });
  q = only;
  draw();
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure vulns --detected" }, "Vulnerabilities"),
      can("admin") ? h("button", { type: "button", class: "btn btn-quiet", on: { click: async e => {
        e.target.disabled = true;
        try { await apiPost("/admin/impact/reanalyse", {}); e.target.textContent = "Re-analysis requested"; }
        catch (err) { e.target.textContent = err.message; }
      } } }, "Analyse again now") : null),
    h("p", { class: "muted small" }, "New critical, high and 0-day CVEs from the last " + d.days + " days, matched to our machines."), pipeline(),
    host ? h("p", { class: "small vu-plat" }, h("strong", null, "Only CVEs found on " + host + ". "),
      h("a", { href: "#/impact" }, "Show all")) : null,
    h("div", { class: "srv-bar" }, search, filters), box);
  vulnTabs("impact");
}

async function renderAdvisories() {
  const d = await api("/admin/advisories");
  const all = d.advisories || [];
  let q = "", sev = "", src = "", kevOnly = false, pg = 1;
  const open = new Set();
  const box = h("div");
  const cveCache = new Map();
  const draw = () => {
    const needle = q.toLowerCase();
    const items = all.filter(a => (!needle || (a.id + " " + (a.title || "") + " " + (a.cves || []).join(" ")).toLowerCase().includes(needle))
      && (!sev || (sev === "high" ? ["high", "important"].includes(a.severity) : sev === "medium" ? ["medium", "moderate"].includes(a.severity) : a.severity === sev))
      && (!src || a.source === src) && (!kevOnly || a.exploited));
    setMailParams(kevOnly ? { exploited_only: true } : {});
    setPageExport(() => ({ title: "Advisories to install", filter: pageFilterText() + (kevOnly ? "; exploited only" : ""),
      columns: ["Advisory", "Kind", "Severity", "Worst CVSS", "Exploited", "Servers to install", "Reboot needed", "CVEs", "Issued", "Title"],
      rows: items.map(a => [a.id, a.source === "windows_update" ? "Windows update" : (a.os_id || a.vendor || ""), a.severity || "",
        a.max_cvss, a.exploited ? "yes" : "", a.servers_affected, a.servers_reboot, (a.cves || []).join(" "),
        a.issued_at ? fmtDate(a.issued_at) : "", a.title || ""]) }));
    const pages = Math.max(1, Math.ceil(items.length / 20));
    pg = Math.min(pg, pages);
    const rows = items.slice((pg - 1) * 20, pg * 20);
    box.replaceChildren(rows.length ? plusTable([
      { label: "Advisory", cell: a => h("strong", { class: "mono" }, a.id) },
      { label: "Severity", cell: a => a.exploited ? h("span", { class: "sv sv-crit sv-0day" }, "Exploited") : sevChip(a.severity, a.max_cvss) },
      { label: "Kind", cell: a => a.source === "windows_update" ? "Windows update" : (a.os_id ? a.os_id.toUpperCase() + (a.os_major ? " " + a.os_major : "") : a.vendor) },
      { label: "To install on", num: true, cell: a => String(a.servers_affected || 0) },
      { label: "Reboot", num: true, cell: a => a.servers_reboot ? String(a.servers_reboot) : "" },
      { label: "CVEs", num: true, cell: a => String((a.cves || []).length) },
      { label: "Issued", cell: a => a.issued_at ? fmtDate(a.issued_at) : "" },
      { label: "Title", cell: a => h("span", { class: "vu-title" }, a.title || "") },
    ], rows, async a => {
      const [hs, cv] = await Promise.all([
        api("/admin/advisories/" + encodeURIComponent(a.id) + "/hosts"),
        a.source === "advisory" ? (cveCache.get(a.id) || api("/admin/advisories/" + encodeURIComponent(a.id) + "/cves")) : null]);
      if (cv) cveCache.set(a.id, cv);
      return [
        h("h4", { class: "vu-h" }, "Servers (" + (hs.hosts || []).length + ")"),
        (hs.hosts || []).length ? h("div", { class: "cm-table" }, table([
          { label: "", cell: x => srvLight(x.agent) },
          { label: "Server", cell: x => routeAllowed("host") ? h("a", { href: "#/host/" + x.host_id }, x.hostname) : x.hostname },
          { label: "State", cell: x => x.state === "affected" ? "to install" : "installed, reboot needed" },
          { label: "Package", cell: x => x.package || "" },
          { label: "Installed", cell: x => x.installed || "" },
          { label: "Fixed in", cell: x => x.fixed_in || "" },
        ], hs.hosts)) : h("p", { class: "muted small" }, "No server needs it any more."),
        h("h4", { class: "vu-h" }, "CVEs (" + (a.cves || []).length + ")"),
        cv && (cv.cves || []).length ? h("div", { class: "cm-table" }, table([
          { label: "CVE", cell: x => h("a", { href: "https://nvd.nist.gov/vuln/detail/" + x.cve_id, target: "_blank", rel: "noopener noreferrer" }, x.cve_id) },
          { label: "CVSS", cell: x => x.cvss_score !== null && x.cvss_score !== undefined ? Number(x.cvss_score).toFixed(1) : "" },
          { label: "Exploited", cell: x => x.kev ? "yes" : "" },
          { label: "Attack type", cell: x => x.attack_class || "" },
          { label: "Description", cell: x => h("span", { class: "vu-title" }, x.description || "") },
        ], cv.cves)) : h("p", { class: "muted small" }, (a.cves || []).join(", ") || "No CVEs listed."),
        can("operator") && hasModule("patch") && a.source === "advisory" && (hs.hosts || []).some(x => x.state === "affected")
          ? h("div", { class: "cm-actions" }, h("a", { class: "btn", href: "#/changes/new?kind=patch&advisories=" + encodeURIComponent(a.id)
              + "&hosts=" + encodeURIComponent((hs.hosts || []).filter(x => x.state === "affected").map(x => x.host_id).join(",")) }, "Patch these servers")) : null];
    }, { open, key: a => a.id, rowClass: a => a.exploited ? "vu-kev" : "" })
      : h("div", { class: "empty" }, h("p", null, all.length ? "No advisories match." : "No server needs a patch right now.")),
      pager(pg, pages, items.length, 20, n => { pg = n; draw(); }));
  };
  const search = h("input", { type: "search", placeholder: "Search advisory, KB, CVE or title", "aria-label": "Search advisories" });
  let t = null;
  search.addEventListener("input", () => { clearTimeout(t); t = setTimeout(() => { q = search.value.trim(); pg = 1; draw(); }, 250); });
  const sel = (label, opts, set) => h("select", { "aria-label": label, on: { change: e => { set(e.target.value); pg = 1; draw(); } } },
    h("option", { value: "" }, label + ": all"), opts.map(([v, t2]) => h("option", { value: v }, t2)));
  const kev = h("input", { type: "checkbox" });
  kev.addEventListener("change", () => { kevOnly = kev.checked; pg = 1; draw(); });
  draw();
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure vulns --advisories" }, "Vulnerabilities"),
      h("span", { class: "muted small" }, all.length + " advisories and updates still to install")),
    h("div", { class: "srv-bar" }, search,
      sel("Severity", [["critical", "Critical"], ["high", "High / important"], ["medium", "Medium / moderate"], ["low", "Low"]], v => { sev = v; }),
      sel("Kind", [["advisory", "Vendor advisories"], ["windows_update", "Windows updates"]], v => { src = v; }),
      h("label", { class: "cm-check" }, kev, " Exploited only")),
    box);
  vulnTabs("advisories");
}

/* ---- admin: who may open which module ------------------------------------------ */

async function renderAccess() {
  setNav("admin");
  const d = await api("/admin/users");
  const msg = h("p", { class: "cm-meta", role: "status" });
  const rows = d.users || [];
  const t = table([
    { label: "User", cell: u => h("span", null, h("strong", null, u.username), u.display_name ? " · " + u.display_name : "") },
    { label: "Role", cell: u => u.role },
    ...MODULES.map(m => ({ label: m.label, cell: u => {
      if (u.role === "admin") return h("span", { class: "muted small" }, "always");
      const box = h("input", { type: "checkbox", checked: (u.modules || []).includes(m.key), "data-user": u.username,
                               "data-mod": m.key, "aria-label": m.label + " for " + u.username });
      box.addEventListener("change", async () => {
        // The whole row is sent, read from its boxes, and locked until the server answers
        const row = [...document.querySelectorAll("input[data-user]")].filter(b => b.dataset.user === u.username);
        const want = row.filter(b => b.checked).map(b => b.dataset.mod);
        row.forEach(b => { b.disabled = true; });
        try {
          const r = await apiSend("PATCH", "/admin/users/" + encodeURIComponent(u.username), { modules: want });
          u.modules = Array.isArray(r.modules) ? r.modules : want;
          msg.textContent = u.username + ": " + (u.modules.length ? u.modules.map(k => MODULES.find(x => x.key === k).label).join(", ") : "no modules")
            + ". Applies at once, on their next click.";
        } catch (err) { msg.textContent = err.message; }
        row.forEach(b => { b.checked = (u.modules || []).includes(b.dataset.mod); b.disabled = false; });
      });
      return box;
    } })),
    { label: "Active", cell: u => u.active ? "yes" : "no" },
  ], rows);
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure access" }, "Access")),
    h("p", { class: "muted" }, "Choose which modules each user may open. The home page lights the modules a user may open and greys "
      + "out the rest, and the API refuses the others whatever the browser does. Admins can always open everything. "
      + "Roles (viewer, operator, admin) still decide what a user may change inside a module: set them under Users."),
    t, msg);
  adminTabs("access");
}

/* ---- admin: CVE feeds ------------------------------------------------------- */


async function renderFeedsAdmin() {
  setNav("admin");
  const d = await api("/admin/feeds");
  const page = h("div", { class: "feeds-admin" });
  render(page);
  drawFeedsAdmin(page, d);
  adminTabs("feeds");
}

function drawFeedsAdmin(page, d) {
  const st = d.settings || {};
  const msg = h("p", { class: "cm-meta", role: "status" });
  const box = (k, label) => h("label", { class: "cm-check" }, h("input", { type: "checkbox", name: k, checked: !!st[k] }), " " + label);
  const num = (k, label, min, max, step) => h("label", null, h("span", null, label),
    h("input", { type: "number", name: k, value: st[k], min, max, step: step || 1, required: true }));
  const form = h("form", { class: "feeds-form", on: { submit: async e => {
    e.preventDefault();
    const fd = new FormData(form);
    const body = { nist: fd.has("nist"), msrc: fd.has("msrc"), redhat: fd.has("redhat"), signin_board: fd.has("signin_board"),
                   days_back: Number(fd.get("days_back")), min_cvss: Number(fd.get("min_cvss")),
                   interval_minutes: Number(fd.get("interval_minutes")), signin_min_cvss: Number(st.signin_min_cvss || 7) };
    try { const r = await apiSend("PUT", "/admin/feeds/settings", body); drawFeedsAdmin(page, r); }
    catch (err) { msg.textContent = err.message || "Could not save."; }
  } } },
    h("fieldset", null, h("legend", null, "Sources"), box("nist", "NIST NVD"), box("msrc", "Microsoft"), box("redhat", "Red Hat")),
    h("div", { class: "feeds-nums" },
      num("days_back", "Days to show", 1, 90), num("min_cvss", "Lowest CVSS on the dashboard", 0, 10, 0.1),
      num("interval_minutes", "Read every (minutes)", 15, 1440)),
    h("fieldset", null, h("legend", null, "Sign-in page"),
      box("signin_board", "Show the CVE scroller before sign-in"),
      h("p", { class: "muted small" }, "The sign-in scroller shows only critical, high and 0-day CVEs from the general feeds, "
        + "never your watch list, so it does not reveal what software you run.")),
    h("div", { class: "cm-actions" }, h("button", { type: "submit" }, "Save"), msg));

  const term = h("input", { type: "text", maxlength: "60", placeholder: "for example: openssl, apache tomcat, vmware vcenter",
                            "aria-label": "Software to follow", required: true });
  const kind = h("select", { "aria-label": "Kind" }, ["software", "vendor", "keyword"].map(k => h("option", { value: k }, k)));
  const addMsg = h("p", { class: "cm-meta", role: "status" });
  const add = async (t, k) => {
    try { const r = await apiPost("/admin/feeds/watch", { term: t, kind: k || "software" }); drawFeedsAdmin(page, r); }
    catch (err) { addMsg.textContent = err.message || "Could not add."; }
  };
  const addForm = h("form", { class: "feeds-add", on: { submit: e => { e.preventDefault(); add(term.value.trim(), kind.value); } } },
    term, kind, h("button", { type: "submit" }, "Add"));

  const watch = d.watch || [];
  const watchTable = watch.length ? table([
    { label: "Software", cell: w => w.term },
    { label: "Kind", cell: w => w.kind },
    { label: "Following", cell: w => h("input", { type: "checkbox", checked: !!w.enabled, "aria-label": "Follow " + w.term,
        on: { change: async e => { try { drawFeedsAdmin(page, await apiSend("PATCH", "/admin/feeds/watch/" + w.id, { enabled: e.target.checked })); }
                                   catch (err) { addMsg.textContent = err.message; } } } }) },
    { label: "Added", cell: w => (w.added_by || "") + ", " + timeAgo(w.added_at) },
    { label: "", cell: w => h("button", { type: "button", class: "btn-link", on: { click: async () => {
        try { drawFeedsAdmin(page, await apiSend("DELETE", "/admin/feeds/watch/" + w.id)); } catch (err) { addMsg.textContent = err.message; } } } }, "Remove") },
  ], watch) : h("p", { class: "muted" }, "Nothing on the watch list yet. Until you add software, the dashboard shows every CVE collected.");

  const sugBox = h("div", { class: "feeds-sug" }, h("p", { class: "muted small" }, "Loading what your servers run"));
  api("/admin/feeds/suggestions").then(sg => {
    const group = (title, rows) => rows.length ? h("div", null, h("h3", null, title),
      h("div", { class: "chips" }, rows.slice(0, 40).map(r => h("button", { type: "button", class: "chip",
        title: r.servers ? "On " + r.servers + " server(s): add to the watch list" : "Add to the watch list",
        on: { click: () => add(r.name, r.kind) } }, "+ " + r.name + (r.servers ? " (" + r.servers + ")" : ""))))) : null;
    sugBox.replaceChildren(...[group("Windows software on your servers", sg.windows || []),
      group("Linux software on your servers", sg.linux || []), group("Operating systems", sg.os || [])].filter(Boolean));
    if (!sugBox.childNodes.length) sugBox.replaceChildren(h("p", { class: "muted small" }, "Everything your servers report is already on the list."));
  }).catch(() => sugBox.replaceChildren(h("p", { class: "muted small" }, "Suggestions are not available.")));

  const state = d.state || [];
  const stored = {};
  (d.stored || []).forEach(r => { stored[r.source] = r; });
  const stateTable = table([
    { label: "Source", cell: r => FEED_NAME[r.source] || r.source },
    { label: "Last read", cell: r => r.last_ok ? timeAgo(r.last_ok) : "never" },
    { label: "Read last time", num: true, cell: r => r.items === null || r.items === undefined ? "" : r.items },
    { label: "Kept", num: true, cell: r => stored[r.source] ? stored[r.source].n : 0 },
    { label: "Problem", cell: r => r.error ? h("span", { class: "hd-failed" }, r.error) : "" },
  ], ["nist", "msrc", "redhat"].map(k => Object.assign({ source: k }, state.find(x => x.source === k) || {})));
  const syncMsg = h("span", { class: "cm-meta", role: "status" });
  const syncBtn = h("button", { type: "button", on: { click: async () => {
    syncBtn.disabled = true;
    try { await apiPost("/admin/feeds/sync", {}); syncMsg.textContent = "Asked the worker: it starts within a minute. NIST takes a few minutes"
          + (d.nvd_api_key ? "." : " without an NVD API key."); }
    catch (err) { syncMsg.textContent = err.message; syncBtn.disabled = false; }
  } } }, "Read the feeds now");

  page.replaceChildren(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure feeds" }, "CVE feeds")),
    h("p", { class: "muted" }, "New CVEs from NIST NVD, Microsoft and Red Hat, read through the proxy by PATCH-01's worker. "
      + "Choose the software to follow: the dashboard and its news then show only CVEs naming that software, "
      + "plus any CVE already found on your servers."),
    h("section", null, h("h2", null, "Software to follow"), addForm, addMsg, watchTable, sugBox),
    h("section", null, h("h2", null, "Settings"), form),
    h("section", null, h("h2", null, "Status"), stateTable, h("div", { class: "cm-actions" }, syncBtn, syncMsg),
      d.worker_seen ? null : h("p", { class: "hd-failed" }, "The worker has not started reading feeds yet: rebuild it with phase3b-api.sh."),
      d.nvd_api_key || !d.worker_seen ? null : h("p", { class: "muted small" }, "No NVD API key is set, so NIST is read slowly "
        + "(5 requests every 30 seconds). A free key from NIST raises that tenfold: save it in /patch/secrets/nvd-api-key "
        + "on PATCH-01 and run phase3b-api.sh.")));
}

/* ---- export heading (browser-made CSVs) ------------------------------------- */

let orgInfo = null;
async function loadOrg() {
  if (orgInfo || !getAuth()) return orgInfo;
  try { orgInfo = await api("/branding/info"); } catch (e) { orgInfo = null; }
  return orgInfo;
}

/* The heading every export carries: portal and title, organisation, when, by
 * whom, how many rows. (A CSV cannot hold a picture; the Excel exports carry
 * the logo.) */
function exportHeading(title, n, filterText) {
  const a = getAuth();
  const now = new Date();
  const when = now.toLocaleString(undefined, { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
  const lines = [[PORTAL + " — " + title]];
  if (orgInfo && orgInfo.company) lines.push(["Organisation", orgInfo.company]);
  lines.push(["Generated", when], ["By", a ? a.user.username : ""]);
  if (filterText) lines.push(["Filter", filterText]);
  lines.push(["Rows", String(n)], []);
  return lines;
}

async function downloadFile(path, fallbackName) {
  const res = await fetch("/api/v1" + path, { headers: { "X-Requested-With": "patch01-dashboard", ...authHeaders() } });
  if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
  if (!res.ok) {
    const d = await res.json().catch(() => ({}));
    throw new ApiError(res.status, d.detail || res.statusText);
  }
  const cd = res.headers.get("Content-Disposition") || "";
  const m = /filename="([A-Za-z0-9._-]+)"/.exec(cd);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = h("a", { href: url, download: m ? m[1] : fallbackName });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return res.headers.get("X-Rows");
}

/* ---- Servers: servers and their agents, in one list --------------------------- */

const SRV_AGENT = { online: "Online", offline: "Offline", not_reporting: "Not reporting", no_data: "Never reported" };
const SRV_PATCH = { needs_patch: "Needs patches", needs_reboot: "Needs a reboot", up_to_date: "Up to date" };
const SRV_SORT = { agent: "Offline first", name: "Name", last_seen: "Last seen", patches: "Most patches", os: "Operating system" };
const SRV_KEYS = ["q", "os", "group", "version", "agent", "patch", "sort", "page"];

function srvLight(agent, last) {
  const on = agent === "online";
  const label = on ? "Online" : (SRV_AGENT[agent] || "Offline") + (last ? ", last seen " + timeAgo(last) : ", never reported");
  return h("span", { class: "light " + (on ? "light-on" : "light-off"), role: "img", "aria-label": label, title: label });
}

function fmtDays(sec) {
  if (sec === null || sec === undefined) return "not reported";
  const d = Math.floor(sec / 86400), hr = Math.floor((sec % 86400) / 3600);
  return d ? d + " d " + hr + " h" : hr + " h";
}

function srvDetail(r) {
  const kv = (k, v) => v === null || v === undefined || v === "" ? null : h("div", { class: "kv" }, h("dt", null, k), h("dd", null, v));
  const toInstall = Number(r.needs_patch || 0) + Number(r.windows_updates_missing || 0);
  return h("div", { class: "srv-detail-in" },
    h("dl", { class: "srv-kv" },
      kv("Agent", (SRV_AGENT[r.agent] || r.agent) + (r.agent_version ? ", version " + r.agent_version : "")),
      kv("Last seen", r.last_checkin ? fmtDateTime(r.last_checkin) + " (" + timeAgo(r.last_checkin) + ")" : "never"),
      kv("Last inventory", r.last_inventory ? timeAgo(r.last_inventory) : null),
      kv("Enrolled", r.enrolled_at ? fmtDateTime(r.enrolled_at) : null),
      kv("Address", r.agent_ip), kv("Full name", r.fqdn),
      kv("Operating system", r.os_edition || ((r.os_id || "") + " " + (r.os_version || "")).trim()),
      kv("Running kernel", r.kernel_running),
      kv("Uptime", fmtDays(r.uptime_seconds)),
      kv("Reboot", r.reboot_required ? "pending" + (r.reboot_reason ? " (" + r.reboot_reason + ")" : "") : "not needed"),
      kv("To install", toInstall ? r.needs_patch + " advisories, " + r.windows_updates_missing + " Windows updates" : "nothing"),
      kv("Installed, reboot needed", r.pending_reboot ? String(r.pending_reboot) : null),
      kv("Worst CVSS", r.worst_cvss !== null && r.worst_cvss !== undefined ? Number(r.worst_cvss).toFixed(1) + (r.exploited ? ", exploited in the wild" : "") : null),
      kv("Hardening score", r.hardening_score !== null && r.hardening_score !== undefined ? r.hardening_score + "%" : null),
      kv("Antivirus", r.antivirus ? "Trend Micro agent (" + r.antivirus + ")"
        : r.av_active ? h("span", { class: "hd-failed" }, "no agent reported by the antivirus consoles") : null),
      kv("Detected CVEs", r.cves_detected ? h("a", { href: "#/impact?host=" + encodeURIComponent(r.hostname) },
        r.cves_detected + (r.cves_affected ? " (" + r.cves_affected + " confirmed)" : "") + (r.cves_zero_day ? ", includes a 0-day" : "")) : "none"),
      kv("Windows updates from", r.wu_source ? r.wu_source + (r.wu_searched_at ? ", checked " + timeAgo(r.wu_searched_at) : "") : null),
      kv("VMware", r.vcenter ? [r.vcenter, r.cluster, r.power].filter(Boolean).join(" · ") : null)),
    h("div", { class: "cm-actions" },
      h("a", { class: "btn", href: "#/host/" + encodeURIComponent(r.host_id) }, "Open server page"),
      can("operator") && hasModule("patch") && toInstall ? h("a", { class: "btn btn-quiet",
        href: "#/changes/new?kind=patch&hosts=" + encodeURIComponent(r.host_id) }, "Patch this server") : null));
}

async function renderServers(params, legacyAgents) {
  setNav("hosts");
  loadOrg();
  const st = {};
  SRV_KEYS.forEach(k => { const v = params.get(k); if (v) st[k] = v; });
  if (legacyAgents && !st.agent && params.get("state")) st.agent = params.get("state");
  if (!st.sort) st.sort = "agent";
  const open = new Set();
  const page = h("div", { class: "srv" });
  render(page);
  let timer = null, seq = 0;

  const qs = () => SRV_KEYS.filter(k => st[k] && !(k === "page" && st[k] === "1") && !(k === "sort" && st[k] === "agent"))
    .map(k => k + "=" + encodeURIComponent(st[k])).join("&");
  const filterText = () => ["q", "os", "group", "version", "agent", "patch"].filter(k => st[k])
    .map(k => ({ q: "name contains", os: "OS", group: "group", version: "agent version", agent: "agent", patch: "patch" }[k]) + " "
      + ({ agent: SRV_AGENT, patch: SRV_PATCH }[k] ? ({ agent: SRV_AGENT, patch: SRV_PATCH }[k][st[k]] || st[k]) : st[k])).join("; ");

  async function load(keepFocus) {
    const my = ++seq;
    const d = await api("/servers" + (qs() ? "?" + qs() : ""));
    if (my !== seq || !page.isConnected) return;
    history.replaceState(null, "", "#/hosts" + (qs() ? "?" + qs() : ""));
    draw(d, keepFocus);
  }
  const set = (k, v, keepFocus) => { if (v) st[k] = v; else delete st[k]; if (k !== "page") delete st.page; load(keepFocus).catch(showError); };

  function draw(d, keepFocus) {
    const fc = d.facets || { agent: {}, patch: {}, os: [], group: [], version: [] };
    const ins = d.insight;
    const head = h("div", { class: "page-head" },
      h("h1", { "data-cmd": "cybersecure servers" }, "Servers"),
      h("span", { class: "head-actions" },
        h("span", { class: "muted small" }, d.total + (d.total === 1 ? " server" : " servers") + (filterText() ? " match" : "")),
        exportControl()));
    // Every server matching the filters (all pages), made on the server
    setPageExport(() => {
      const q = SRV_KEYS.filter(k => st[k] && k !== "page").map(k => k + "=" + encodeURIComponent(st[k])).join("&");
      return { server: "/servers/export" + (q ? "?" + q : "") };
    });
    setMailParams(Object.fromEntries(["q", "os", "group", "version", "agent", "patch"].filter(k => st[k]).map(k => [k, st[k]])));

    const insight = h("section", { class: "ai-card", "aria-label": "AI-01 analysis" },
      h("div", { class: "ai-card-head" },
        h("span", { class: "ai-badge ai-small" }, h("span", { class: "ai-dot", "aria-hidden": "true" }),
          ins && ins.source === "ai" ? "AI-01 analysis" : "Analysis"),
        h("span", { class: "muted small" }, ins ? "updated " + new Date(ins.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
          + " · every 15 minutes" + (ins.source === "ai" ? "" : " · AI-01 unavailable, figures only") : "the first analysis runs within 15 minutes")),
      ins ? ins.text.split(/\n\s*\n/).map(p => h("p", null, p)) : h("p", { class: "muted" }, "Waiting for the worker (rebuild it with phase3b-api.sh if this stays empty)."));

    const tile = (key, label, n, cls) => h("button", { type: "button", class: "srv-tile " + cls, "aria-pressed": String((st.agent || "") === key),
      on: { click: () => set("agent", key === (st.agent || "") ? "" : key) } },
      key ? srvLight(key === "online" ? "online" : "offline") : null,
      h("span", { class: "srv-tile-n" }, String(n)), h("span", { class: "srv-tile-l" }, label));
    const tiles = h("div", { class: "srv-tiles", role: "group", "aria-label": "Agent state" },
      tile("", "All servers", fc.total || 0, ""), tile("online", "Online", fc.agent.online || 0, "t-on"),
      tile("offline", "Offline", fc.agent.offline || 0, "t-off"));

    const sel = (k, label, options) => {
      const s = h("select", { "aria-label": label, on: { change: e => set(k, e.target.value) } },
        h("option", { value: "" }, label + ": all"),
        options.map(([v, t]) => h("option", { value: v, selected: st[k] === v }, t)));
      return s;
    };
    const search = h("input", { type: "search", placeholder: "Search name or address", value: st.q || "", maxlength: "80",
                                "aria-label": "Search servers" });
    search.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => set("q", search.value.trim(), true), 350); });
    const bar = h("div", { class: "srv-bar" }, search,
      sel("os", "OS", (fc.os || []).map(o => [o.value, o.value + " (" + o.n + ")"])),
      sel("agent", "Agent", Object.entries(SRV_AGENT).map(([k, v]) => [k, v + " (" + (fc.agent[k] || 0) + ")"])),
      sel("patch", "Patches", Object.entries(SRV_PATCH).map(([k, v]) => [k, v + " (" + (fc.patch[k] || 0) + ")"])),
      sel("group", "Group", (fc.group || []).map(o => [o.value, o.value + " (" + o.n + ")"])),
      sel("version", "Agent version", (fc.version || []).map(o => [o.value, o.value + " (" + o.n + ")"])),
      h("select", { "aria-label": "Sort", on: { change: e => set("sort", e.target.value) } },
        Object.entries(SRV_SORT).map(([k, v]) => h("option", { value: k, selected: (st.sort || "agent") === k }, "Sort: " + v))),
      filterText() ? h("button", { type: "button", class: "btn-link", on: { click: () => {
        ["q", "os", "group", "version", "agent", "patch", "page"].forEach(k => delete st[k]); load().catch(showError); } } }, "Clear filters") : null);

    const tbody = h("tbody");
    (d.rows || []).forEach(r => {
      const toInstall = Number(r.needs_patch || 0) + Number(r.windows_updates_missing || 0);
      const isOpen = open.has(r.host_id);
      const btn = h("button", { type: "button", class: "srv-plus", "aria-expanded": String(isOpen),
                                "aria-label": (isOpen ? "Hide" : "Show") + " details of " + r.hostname }, isOpen ? "−" : "+");
      const detail = h("tr", { class: "srv-detail", hidden: !isOpen }, h("td", { colspan: "10" }, isOpen ? srvDetail(r) : null));
      btn.addEventListener("click", () => {
        const now = !open.has(r.host_id);
        now ? open.add(r.host_id) : open.delete(r.host_id);
        btn.textContent = now ? "−" : "+";
        btn.setAttribute("aria-expanded", String(now));
        btn.setAttribute("aria-label", (now ? "Hide" : "Show") + " details of " + r.hostname);
        detail.hidden = !now;
        if (now && !detail.firstChild.firstChild) detail.firstChild.append(srvDetail(r));
      });
      tbody.append(h("tr", { class: "srv-row" + (r.agent === "online" ? "" : " srv-off") },
        h("td", { class: "srv-c-plus" }, btn),
        h("td", { class: "srv-c-light" }, srvLight(r.agent, r.last_checkin)),
        h("td", null, h("a", { href: "#/host/" + encodeURIComponent(r.host_id), class: "srv-name" }, r.hostname)),
        h("td", null, r.os_label || ""),
        h("td", null, r.host_group || ""),
        h("td", { class: "mono" }, r.agent_version || "unknown"),
        h("td", { title: r.last_checkin ? fmtDateTime(r.last_checkin) : "" }, r.last_checkin ? timeAgo(r.last_checkin) : "never"),
        h("td", { class: "num" }, toInstall ? h("span", { class: "count st-affected" + (r.exploited ? " srv-kev" : ""),
          title: r.needs_patch + " advisories, " + r.windows_updates_missing + " Windows updates" + (r.exploited ? "; one fixes an exploited CVE" : "") }, String(toInstall)) : "0"),
        h("td", null, r.reboot_required || Number(r.pending_reboot) ? h("span", { class: "srv-reboot" }, "Reboot") : ""),
        h("td", { class: "mono" }, r.agent_ip || "")));
      tbody.append(detail);
    });
    const tableEl = d.rows && d.rows.length ? h("div", { class: "table-wrap" }, h("table", { class: "srv-table" },
      h("thead", null, h("tr", null,
        ["", "", "Server", "Operating system", "Group", "Agent", "Last seen", "To install", "Reboot", "Address"].map((t, i) =>
          h("th", { scope: "col", class: i === 7 ? "num" : null }, t)))), tbody))
      : h("div", { class: "empty" }, h("p", null, d.total === 0 && !filterText() ? "No servers have enrolled yet." : "No servers match these filters."));

    const pager = d.pages > 1 ? h("nav", { class: "srv-pager", "aria-label": "Pages" },
      h("button", { type: "button", class: "btn btn-quiet", disabled: d.page <= 1, on: { click: () => set("page", String(d.page - 1)) } }, "‹ Previous"),
      h("span", null, "Page " + d.page + " of " + d.pages + " · " + ((d.page - 1) * d.size + 1) + "–" + Math.min(d.total, d.page * d.size) + " of " + d.total),
      h("button", { type: "button", class: "btn btn-quiet", disabled: d.page >= d.pages, on: { click: () => set("page", String(d.page + 1)) } }, "Next ›"))
      : null;

    page.replaceChildren(head, insight, tiles, bar, tableEl, pager);
    if (keepFocus) { const s2 = page.querySelector(".srv-bar input[type=search]"); if (s2) { s2.focus(); s2.setSelectionRange(s2.value.length, s2.value.length); } }
  }

  await load();
  setPageTimer(() => { if (!document.hidden && document.activeElement && !page.contains(document.activeElement)) load().catch(() => {}); }, 60000);
}

/* ---- one Export button on every page: PDF report or CSV ------------------------
 * The page's own data when it gives it (setPageExport), otherwise the table the
 * page is showing, as it is filtered. PDF carries the logo; both carry the
 * organisation, date and time, user and filter. */

let pageExport = null;
function setPageExport(fn) { pageExport = fn; }

const NO_EXPORT = new Set(["password", "branding", "certificate", "mail", "av-consoles", "report-schedules"]);

function textOf(el) { return (el.textContent || "").replace(/\s+/g, " ").trim(); }

function pageFilterText() {
  const v = document.getElementById("view");
  const bits = [];
  v.querySelectorAll('.fbtn[aria-pressed="true"], .filters button[aria-pressed="true"], .srv-tile[aria-pressed="true"]').forEach(b => {
    const t = textOf(b).replace(/\s*\(\d+\)$/, "");
    if (t && !/^all\b/i.test(t)) bits.push(t);
  });
  v.querySelectorAll("select").forEach(s => {
    if (s.value && s.closest("#view") && !s.closest(".exp")) {
      const o = s.options[s.selectedIndex];
      if (o && !/: all$/i.test(o.text) && !/^sort:/i.test(o.text)) bits.push(o.text.replace(/\s*\(\d+\)$/, ""));
    }
  });
  v.querySelectorAll('input[type="search"]').forEach(i => { if (i.value.trim()) bits.push('"' + i.value.trim() + '"'); });
  return bits.join("; ");
}

function pageTitle() {
  const h1 = document.querySelector("#view h1");
  return h1 ? textOf(h1) : PORTAL;
}

/* The visible table with the most rows: its headings and cell text. */
function tableFromPage() {
  const tables = [...document.querySelectorAll("#view table")].filter(t => t.offsetParent !== null && !t.closest(".exp"));
  if (!tables.length) return null;
  const t = tables.sort((a, b) => b.tBodies[0]?.rows.length - a.tBodies[0]?.rows.length || 0)[0];
  const ths = [...t.querySelectorAll("thead th")];
  const keep = ths.map((th, i) => textOf(th) ? i : -1).filter(i => i >= 0);
  const rows = [];
  [...(t.tBodies[0] ? t.tBodies[0].rows : [])].forEach(tr => {
    if (tr.hidden || tr.classList.contains("srv-detail") || tr.classList.contains("explain-row") || tr.classList.contains("vu-detail")) return;
    const cells = [...tr.cells];
    if (cells.length < ths.length) return;
    rows.push(keep.map(i => {
      const c = cells[i];
      const light = c.querySelector(".light");
      return light ? (light.getAttribute("aria-label") || "") : textOf(c);
    }));
  });
  return { columns: keep.map(i => textOf(ths[i])), rows: rows.slice(0, 5000) };
}

function donutsFromPage() {
  const cards = [...document.querySelectorAll("#view .dn-card")];
  if (!cards.length) return null;
  const rows = [];
  cards.forEach(c => {
    const title = textOf(c.querySelector(".dn-h") || c);
    c.querySelectorAll(".dn-legend li").forEach(li => rows.push([title, textOf(li.querySelector(".dn-l")),
      textOf(li.querySelector(".dn-v")), textOf(li.querySelector(".dn-p"))]));
  });
  document.querySelectorAll("#view .cy-hero").forEach(x => rows.unshift(["Headline", textOf(x.querySelector(".cy-l")), textOf(x.querySelector(".cy-n")), ""]));
  return { columns: ["Section", "Measure", "Value", "Share"], rows };
}

async function postDownload(path, body) {
  const res = await fetch("/api/v1" + path, { method: "POST", body: JSON.stringify(body),
    headers: { "Content-Type": "application/json", "X-Requested-With": "patch01-dashboard", ...authHeaders() } });
  if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
  if (!res.ok) { const d = await res.json().catch(() => ({})); throw new ApiError(res.status, d.detail || res.statusText); }
  const cd = res.headers.get("Content-Disposition") || "";
  const m = /filename="([A-Za-z0-9._-]+)"/.exec(cd);
  const url = URL.createObjectURL(await res.blob());
  const a = h("a", { href: url, download: m ? m[1] : "report" });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return res.headers.get("X-Rows");
}

async function runExport(fmt, msg) {
  let spec = pageExport ? await pageExport() : null;
  if (!spec) {
    const t = tableFromPage() || donutsFromPage();
    if (!t || !t.rows.length) { msg.textContent = "Nothing on this page to export."; return; }
    spec = Object.assign({ title: pageTitle(), filter: pageFilterText() }, t);
  }
  msg.textContent = "Preparing the " + fmt.toUpperCase();
  try {
    const n = spec.server
      ? await downloadFile(spec.server + (spec.server.includes("?") ? "&" : "?") + "format=" + fmt, "report." + fmt)
      : await postDownload("/export/table", { title: spec.title, filter: spec.filter || "", columns: spec.columns,
          rows: spec.rows.map(r => r.map(v => v === undefined ? null : v)), format: fmt });
    msg.textContent = "Downloaded " + fmt.toUpperCase() + " (" + n + (n === "1" ? " row)" : " rows)");
    setTimeout(() => { if (msg.textContent.startsWith("Downloaded")) msg.textContent = ""; }, 6000);
  } catch (err) { msg.textContent = "Export failed: " + (err.message || err.status); }
}

/* Reports the server can build (and mail) for each page */
const ROUTE_REPORTS = { hosts: ["servers"], agents: ["servers"], impact: ["impact"], vulns: ["advisories"],
  advisories: ["advisories"], antivirus: ["av_health", "av_agents", "av_unprotected"], activity: ["activity"] };
let pageMailParams = {};
let pageMailFirst = null;
function setMailParams(p, first) { pageMailParams = p || {}; pageMailFirst = first || null; }
function routeReports() {
  const first = location.hash.replace(/^#\/?/, "").split(/[/?]/)[0] || "";
  const list = (ROUTE_REPORTS[first] || []).slice();
  if (pageMailFirst && list.includes(pageMailFirst)) list.sort((a, b) => (b === pageMailFirst) - (a === pageMailFirst));
  return list;
}

/* E-mail a report the server builds now (never the page's own rows), to the configured recipients */
async function mailPanel(panel, msg, close) {
  panel.replaceChildren(h("p", { class: "muted small" }, "Loading…"));
  let o;
  try { o = await api("/reports/email-options"); }
  catch (err) { panel.replaceChildren(h("p", { class: "hd-failed small" }, err.message)); return; }
  const want = routeReports();
  const reps = want.map(k => (o.reports || []).find(r => r.key === k)).filter(Boolean);
  if (!reps.length) { panel.replaceChildren(h("p", { class: "muted small" }, "Your account cannot e-mail this report.")); return; }
  if (!o.mail_ready) { panel.replaceChildren(h("p", { class: "small" }, "Mail is not turned on. ",
    can("admin") ? h("a", { href: "#/mail" }, "Set it up in Admin › Mail") : "Ask an admin to set it up.")); return; }
  if (!(o.recipients || []).length) { panel.replaceChildren(h("p", { class: "small" }, "No recipients yet. ",
    can("admin") ? h("a", { href: "#/mail" }, "Add them in Admin › Mail") : "Ask an admin to add them.")); return; }
  const rep = h("select", { "aria-label": "Report" }, reps.map(r => h("option", { value: r.key }, r.title)));
  const fmt = h("select", { "aria-label": "Format" }, h("option", { value: "pdf" }, "PDF"), h("option", { value: "csv" }, "CSV"));
  const boxes = o.recipients.map(r => h("label", { class: "cm-check" }, h("input", { type: "checkbox", value: r.address }),
    " " + (r.name ? r.name + " <" + r.address + ">" : r.address)));
  const note = h("p", { class: "muted small", role: "status" });
  const send = h("button", { type: "button", class: "btn", on: { click: async () => {
    const to = boxes.map(b => b.querySelector("input")).filter(i => i.checked).map(i => i.value);
    if (!to.length) { note.textContent = "Tick at least one recipient."; return; }
    send.disabled = true; note.textContent = "Building the report…";
    try {
      const r = await apiPost("/reports/email", { report: rep.value, params: pageMailParams, format: fmt.value, recipients: to });
      close(); msg.textContent = r.message || "Queued.";
      setTimeout(() => { if (msg.textContent === r.message) msg.textContent = ""; }, 8000);
    } catch (err) { note.textContent = err.message; send.disabled = false; }
  } } }, "Send now");
  const sched = o.can_schedule ? h("a", { class: "btn btn-quiet", on: { click: e => {
    e.preventDefault(); close();
    location.hash = "#/report-schedules?new=" + encodeURIComponent(rep.value)
      + "&p=" + encodeURIComponent(JSON.stringify(pageMailParams || {}));
  } }, href: "#/report-schedules" }, "Schedule…") : null;
  panel.replaceChildren(
    h("p", { class: "small" }, h("strong", null, "E-mail a report"), h("span", { class: "muted" }, " · built now on the server, in the branded mail, with the file attached")),
    h("div", { class: "exp-row" }, reps.length > 1 ? rep : h("span", null, reps[0].title), fmt),
    h("fieldset", { class: "exp-to" }, h("legend", null, "To (recipients set in Admin › Mail)"), boxes),
    h("div", { class: "exp-row" }, send, sched), note);
  if (reps.length === 1) rep.value = reps[0].key;
}

function exportControl() {
  const msg = h("span", { class: "exp-msg", role: "status" });
  const menu = h("div", { class: "exp-menu", role: "menu", hidden: true });
  const panel = h("div", { class: "exp-mail", hidden: true, role: "dialog", "aria-label": "E-mail a report" });
  const btn = h("button", { type: "button", class: "btn btn-quiet exp-btn", "aria-haspopup": "menu", "aria-expanded": "false" },
    "Export ▾");
  const close = () => { menu.hidden = true; panel.hidden = true; btn.setAttribute("aria-expanded", "false"); };
  const item = (fmt, title, sub) => h("button", { type: "button", role: "menuitem",
    on: { click: () => { close(); runExport(fmt, msg); } } }, h("strong", null, title), h("span", null, sub));
  menu.append(item("pdf", "PDF report", "With the logo, for reading and sharing"),
              item("csv", "CSV", "For Excel; heading with organisation, date and time"));
  const mailItem = h("button", { type: "button", role: "menuitem", class: "exp-mail-item", on: { click: e => {
    e.stopPropagation(); menu.hidden = true; panel.hidden = false; mailPanel(panel, msg, close); } } },
    h("strong", null, "E-mail…"), h("span", null, "Send now, or on a schedule (admins)"));
  menu.append(mailItem);
  btn.addEventListener("click", e => {
    e.stopPropagation();
    mailItem.hidden = !(routeReports().length && can("operator"));
    const open = menu.hidden && panel.hidden;
    menu.hidden = !open; panel.hidden = true; btn.setAttribute("aria-expanded", String(open));
    if (open) menu.querySelector("button").focus();
  });
  document.addEventListener("click", e => { if (!wrap.contains(e.target)) close(); });
  const wrap = h("span", { class: "exp" }, btn, menu, panel, msg);
  wrap.addEventListener("keydown", e => { if (e.key === "Escape") { close(); btn.focus(); } });
  return wrap;
}

/* Called after every page renders: one Export button in the page heading. */
function attachExport(first, second) {
  if (NO_EXPORT.has(first) || second === "new") return;
  const head = document.querySelector("#view .page-head");
  // A page with its own formal report (Hardening: PDF or Word, CIS layout) keeps that one Export button.
  if (!head || head.querySelector(".exp, [data-own-export]")) return;
  head.append(exportControl());
}

/* ---- Antivirus: Trend Micro Apex Central, read-only ------------------------------ */

const AV_ICONS = {
  // shield: agents
  agents: [["path", { d: "M12 3l7 3v5c0 4.4-3 8.3-7 9.5C8 19.3 5 15.4 5 11V6z" }]],
  // link: matched to the inventory
  matched: [["path", { d: "M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1" }], ["path", { d: "M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1" }]],
  // question mark: not in the inventory
  unmatched: [["circle", { cx: "12", cy: "12", r: "8.5" }], ["path", { d: "M9.6 9.5a2.5 2.5 0 1 1 3.4 2.3c-.7.3-1 .8-1 1.5v.4" }], ["path", { d: "M12 16.8v.2" }]],
  // shield with a slash: no antivirus
  unprotected: [["path", { d: "M12 3l7 3v5c0 4.4-3 8.3-7 9.5C8 19.3 5 15.4 5 11V6z" }], ["path", { d: "M5 4l14 16" }]],
  // padlock: isolated
  isolated: [["rect", { x: "5.5", y: "10.5", width: "13", height: "9", rx: "1.5" }], ["path", { d: "M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" }]],
};
function avIcon(k) {
  return svg("svg", { viewBox: "0 0 24 24", class: "av-ico", "aria-hidden": "true", focusable: "false" },
    (AV_ICONS[k] || []).map(([tag, attrs]) => svg(tag, attrs)));
}
const AV_ISO = s => { const v = String(s || "").toLowerCase(); return !v || v === "normal" || v === "none" ? "" : v.replace(/_/g, " "); };

async function renderAntivirus(params) {
  setNav("antivirus");
  const d = await api("/antivirus");
  const c = d.counts || {};
  let tab = params.get("tab") === "unprotected" ? "unprotected" : "agents";
  let q = "", pg = 1, cons = "", prod = "", isoOnly = params.get("iso") === "1", match = params.get("match") || "";
  const open = new Set();
  const box = h("div");
  const tile = (k, n, label, onClick, pressed) => h("button", { type: "button", class: "av-tile av-" + k, "aria-pressed": String(!!pressed),
      on: { click: onClick } }, avIcon(k), h("span", { class: "av-n" }, String(n || 0)), h("span", { class: "av-l" }, label));
  const tiles = h("div", { class: "av-tiles", role: "group", "aria-label": "Summary" });
  const search = h("input", { type: "search", placeholder: "Search name, address, domain", "aria-label": "Search" });
  const consSel = h("select", { "aria-label": "Console" }, h("option", { value: "" }, "Console: all"),
    (d.consoles || []).map(x => h("option", { value: x.name }, x.name)));
  const prods = [...new Set((d.agents || []).map(a => a.product_name))].sort();
  const prodSel = h("select", { "aria-label": "Product" }, h("option", { value: "" }, "Product: all"), prods.map(p => h("option", { value: p }, p)));
  const bar = h("div", { class: "srv-bar" }, search, consSel, prodSel);

  const status = h("div", { class: "av-cons" }, (d.consoles || []).length ? (d.consoles || []).map(x =>
    h("span", { class: "av-con " + (x.last_sync_ok === false ? "bad" : x.last_sync_ok ? "ok" : "wait"),
                title: x.last_sync_msg || "" },
      h("span", { class: "light " + (x.last_sync_ok === false ? "light-off" : x.last_sync_ok ? "light-on" : "light-unk"), "aria-hidden": "true" }),
      x.name + " · " + (x.last_sync_at ? "read " + timeAgo(x.last_sync_at) : "not read yet")
        + (x.last_sync_ok === false ? " · problem" : x.agents !== null && x.agents !== undefined ? " · " + x.agents + " agents" : "")
        + (x.enabled ? "" : " · off")))
    : h("p", { class: "muted" }, can("admin") ? h("span", null, "No antivirus console yet. Add one in ", h("a", { href: "#/av-consoles" }, "Admin › Antivirus"), ".")
                                              : "No antivirus console has been added yet."));

  const draw = () => {
    tiles.replaceChildren(
      tile("agents", c.agents, "Agents", () => { tab = "agents"; match = ""; isoOnly = false; pg = 1; draw(); }, tab === "agents" && !match && !isoOnly),
      tile("matched", c.matched, "In inventory", () => { tab = "agents"; match = "yes"; isoOnly = false; pg = 1; draw(); }, tab === "agents" && match === "yes"),
      tile("unmatched", c.unmatched, "Not in inventory", () => { tab = "agents"; match = "no"; isoOnly = false; pg = 1; draw(); }, tab === "agents" && match === "no"),
      tile("unprotected", c.unprotected, "No antivirus", () => { tab = "unprotected"; pg = 1; draw(); }, tab === "unprotected"),
      tile("isolated", c.isolated, "Isolated", () => { tab = "agents"; isoOnly = true; match = ""; pg = 1; draw(); }, tab === "agents" && isoOnly));
    consSel.hidden = prodSel.hidden = tab !== "agents";
    const needle = q.toLowerCase();
    if (tab === "agents") {
      const items = (d.agents || []).filter(a => (!cons || a.console === cons) && (!prod || a.product_name === prod)
        && (!isoOnly || AV_ISO(a.isolation_status)) && (match !== "yes" || a.asset) && (match !== "no" || !a.asset)
        && (!needle || [a.host_name, a.ad_domain, (a.ip_addresses || []).join(" "), a.asset && a.asset.os].join(" ").toLowerCase().includes(needle)));
      setPageExport(() => ({ title: "Antivirus agents", filter: pageFilterText(),
        columns: ["Name", "Address", "Domain", "Product", "Console", "Isolation", "In inventory", "Operating system", "Known from", "Last reported", "MAC"],
        rows: items.map(a => [a.host_name, (a.ip_addresses || []).join(" "), a.ad_domain || "", a.product_name, a.console,
          AV_ISO(a.isolation_status) || "normal", a.asset ? "yes" : "no", a.asset ? a.asset.os || "" : "",
          a.asset ? (a.asset.sources || []).join(", ") : "", a.not_reported ? "no longer listed, last " + fmtDateTime(a.last_seen) : fmtDateTime(a.last_seen),
          (a.mac_addresses || []).join(" ")]) }));
      const pages = Math.max(1, Math.ceil(items.length / 20)); pg = Math.min(pg, pages);
      box.replaceChildren(items.length ? plusTable([
        { label: "Name", cell: a => h("strong", null, a.host_name || "–") },
        { label: "Address", cell: a => (a.ip_addresses || []).slice(0, 2).join(", ") || "–" },
        { label: "Product", cell: a => a.product_name },
        { label: "Console", cell: a => a.console },
        { label: "Isolation", cell: a => AV_ISO(a.isolation_status) ? h("span", { class: "sv sv-crit" }, AV_ISO(a.isolation_status)) : "normal" },
        { label: "In inventory", cell: a => a.asset ? (a.asset.os || "yes") : h("span", { class: "muted" }, "not found") },
        { label: "Last reported", cell: a => a.not_reported ? h("span", { class: "hd-failed", title: "The console's last read did not list it" }, "not listed, " + timeAgo(a.last_seen)) : timeAgo(a.last_seen) },
      ], items.slice((pg - 1) * 20, pg * 20), a => h("div", { class: "srv-det" }, h("dl", { class: "srv-kv" },
        ...[["Domain", a.ad_domain], ["Folder in Apex Central", a.folder_path], ["All addresses", (a.ip_addresses || []).join(", ")],
            ["MAC", (a.mac_addresses || []).join(", ")], ["Managing server", a.managing_server_id], ["Product code", a.product],
            ["Capabilities", (a.capabilities || []).join(", ")], ["First seen", fmtDateTime(a.first_seen)],
            ["In our inventory", a.asset ? a.asset.name + (a.asset.os ? " · " + a.asset.os : "") + " · known from " + (a.asset.sources || []).join(", ")
                                       : "No machine in the inventory has this name or address"]]
          .filter(([, v]) => v).map(([k, v]) => h("div", { class: "kv" }, h("dt", null, k), h("dd", null, v))))),
        { open, key: a => a.console + "/" + a.entity_id, rowClass: a => AV_ISO(a.isolation_status) ? "vu-kev" : "" })
        : h("div", { class: "empty" }, h("p", null, (d.agents || []).length ? "No agent matches." : "No agents read yet.")),
        pager(pg, pages, items.length, 20, n => { pg = n; draw(); }));
    } else {
      const items = (d.unprotected || []).filter(m => !needle || [m.name, (m.ips || []).join(" "), m.os].join(" ").toLowerCase().includes(needle));
      setPageExport(() => ({ title: "Machines with no antivirus agent", filter: pageFilterText(),
        columns: ["Name", "Address", "Operating system", "Known from"],
        rows: items.map(m => [m.name, (m.ips || []).join(" "), m.os || "", (m.sources || []).join(", ")]) }));
      const pages = Math.max(1, Math.ceil(items.length / 20)); pg = Math.min(pg, pages);
      box.replaceChildren(
        h("p", { class: "muted small" }, "Machines in the inventory (agents, WSUS, vCenter guests) that no antivirus console lists, "
          + "matched by address, then full name, then short name."),
        items.length ? h("div", { class: "table-wrap" }, table([
          { label: "Name", cell: m => h("strong", null, m.name) },
          { label: "Address", cell: m => (m.ips || []).join(", ") || "–" },
          { label: "Operating system", cell: m => m.os || h("span", { class: "muted" }, "unknown") },
          { label: "Known from", cell: m => (m.sources || []).join(", ") },
        ], items.slice((pg - 1) * 20, pg * 20))) : h("div", { class: "empty" }, h("p", null, (d.consoles || []).length ? "Every machine has an antivirus agent." : "Add a console first.")),
        pager(pg, pages, items.length, 20, n => { pg = n; draw(); }));
    }
  };
  let t = null;
  search.addEventListener("input", () => { clearTimeout(t); t = setTimeout(() => { q = search.value.trim(); pg = 1; draw(); }, 250); });
  consSel.addEventListener("change", () => { cons = consSel.value; pg = 1; draw(); });
  prodSel.addEventListener("change", () => { prod = prodSel.value; pg = 1; draw(); });
  draw();
  render(h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure av --agents" }, "Antivirus")),
    h("p", { class: "muted small" }, "Security agents reported by Trend Micro Apex Central, read every hour, matched to the inventory."),
    status, tiles, bar, box);
}

/* Admin › Antivirus: consoles, their keys, a connection test */
async function renderAvConsoles() {
  setNav("admin");
  if (!can("admin")) return render(h("div", { class: "empty" }, h("p", null, "Antivirus settings need the admin role.")));
  const page = h("div", { class: "av-admin" });
  render(page);
  drawAvConsoles(page, await api("/admin/antivirus"));
  adminTabs("av-consoles");
}

function drawAvConsoles(page, d, editing) {
  const msg = h("p", { class: "cm-meta", role: "status" });
  const result = h("div", { class: "av-test", role: "status", "aria-live": "polite" });
  const ed = editing || null;
  const name = h("input", { type: "text", maxlength: "60", required: true, value: ed ? ed.name : "", placeholder: "Apex Central, head office" });
  const url = h("input", { type: "url", maxlength: "300", required: true, value: ed ? ed.url : "", placeholder: "https://apex-central.example.local",
                           autocomplete: "off", spellcheck: "false" });
  const appId = h("input", { type: "text", maxlength: "80", required: !ed, autocomplete: "off", spellcheck: "false",
                             placeholder: ed ? "saved (" + ed.app_id + "): leave blank to keep" : "Application ID" });
  const key = h("input", { type: "password", maxlength: "200", required: !ed, autocomplete: "new-password", spellcheck: "false",
                           placeholder: ed ? "saved: leave blank to keep" : "API key" });
  const ca = h("textarea", { rows: "5", maxlength: "20000", spellcheck: "false",
                             placeholder: "-----BEGIN CERTIFICATE-----\n(only when the console's certificate is from your own CA)" });
  const caRemove = ed && ed.has_ca ? h("label", { class: "cm-check" }, h("input", { type: "checkbox" }), " Remove the saved CA certificate") : null;
  const proxy = h("input", { type: "checkbox", checked: ed ? !!ed.use_proxy : false });
  // Self-signed console: fetch its certificate, compare the fingerprint on the server, trust exactly that one
  let pinPending = null;
  const certBox = h("div", { class: "av-cert", "aria-live": "polite" });
  const unpin = ed && ed.pin_sha256 ? h("label", { class: "cm-check" }, h("input", { type: "checkbox" }), " Stop trusting this certificate") : null;
  const pinnedNow = ed && ed.pin_sha256 ? h("div", { class: "av-res ok" }, h("strong", null, "Trusted certificate"),
    h("p", { class: "small" }, (ed.pin_subject || "") + (ed.pin_not_after ? " · valid until " + fmtDate(ed.pin_not_after) : "")
      + (ed.pinned_by ? " · trusted by " + ed.pinned_by + " " + timeAgo(ed.pinned_at) : "")),
    h("p", { class: "mono small av-fp" }, "SHA-256 " + ed.pin_sha256.toUpperCase().match(/../g).join(":")), unpin) : null;
  const getCert = h("button", { type: "button", class: "btn-quiet", on: { click: async () => {
    getCert.disabled = true; pinPending = null;
    certBox.replaceChildren(h("p", { class: "muted small" }, "Reading the certificate (handshake only, nothing is sent)…"));
    try {
      const b = { url: url.value.trim(), use_proxy: proxy.checked }; if (ed) b.id = ed.id;
      const c = await apiPost("/admin/antivirus/certificate", b);
      const ok = h("input", { type: "checkbox" });
      ok.addEventListener("change", () => { pinPending = ok.checked ? c.sha256 : null; });
      certBox.replaceChildren(h("div", { class: "av-res " + (c.expired ? "bad" : "ok") },
        h("strong", null, c.self_signed ? "Self-signed certificate" : "Certificate"),
        h("dl", { class: "srv-kv" }, ...[["Issued to", c.subject], ["Issued by", c.issuer],
            ["Names it covers", (c.names || []).join(", ") || "none listed (old-style certificate)"],
            ["Matches this URL", c.matches_host ? "yes" : "no: normal verification would fail, pinning works"],
            ["Valid", fmtDate(c.not_before) + " to " + fmtDate(c.not_after) + (c.expired ? " (EXPIRED)" : c.not_yet_valid ? " (not yet valid)" : "")]]
          .map(([k, v]) => h("div", { class: "kv" }, h("dt", null, k), h("dd", null, v)))),
        h("p", { class: "small" }, "SHA-256 fingerprint"), h("p", { class: "mono small av-fp" }, c.sha256_text),
        h("p", { class: "small" }, "SHA-1 (what Windows calls the Thumbprint)"), h("p", { class: "mono small av-fp" }, c.sha1_text),
        h("p", { class: "muted small" }, "Check it on the Apex Central server before trusting it: IIS Manager › Server Certificates › "
          + "open the certificate › Details › Thumbprint, or in PowerShell: Get-ChildItem Cert:\\LocalMachine\\My | Select Subject, Thumbprint. "
          + "It must be the same value."),
        c.expired ? h("p", { class: "hd-failed small" }, "This certificate has expired. It can still be trusted by its fingerprint, "
          + "but plan to renew it on the Apex Central server.") : null,
        c.pinned_now ? h("p", { class: "small" }, "This is the certificate already trusted for this console.") :
          h("label", { class: "cm-check" }, ok, " I have compared the fingerprint with the Apex Central server: trust exactly this certificate")));
    } catch (err) { certBox.replaceChildren(h("p", { class: "hd-failed small" }, err.message)); }
    getCert.disabled = false;
  } } }, "Get certificate");
  const enabled = h("input", { type: "checkbox", checked: ed ? !!ed.enabled : true });
  const body = () => {
    const b = { name: name.value.trim(), url: url.value.trim(), use_proxy: proxy.checked, enabled: enabled.checked };
    if (appId.value.trim()) b.app_id = appId.value.trim();
    if (key.value) b.api_key = key.value;
    if (ca.value.trim()) b.ca_pem = ca.value.trim();
    else if (caRemove && caRemove.querySelector("input").checked) b.ca_pem = "";
    if (pinPending) b.pin_sha256 = pinPending;
    else if (unpin && unpin.querySelector("input").checked) b.pin_sha256 = "";
    return b;
  };
  const showResult = r => result.replaceChildren(h("div", { class: "av-res " + (r.ok ? "ok" : "bad") },
    h("strong", null, r.ok ? "Connected" : "Not connected"), h("p", null, r.message),
    r.ok && (r.products || []).length ? h("p", { class: "small" }, "Products: " + r.products.map(([p, n]) => p + " (" + n + ")").join(", ")
      + (r.isolated ? " · " + r.isolated + " isolated" : "")) : null,
    r.ok && (r.sample || []).length ? h("p", { class: "small muted" }, "For example: " + r.sample.join(", ")) : null,
    r.ok && r.health ? h("p", { class: "small" }, "For the daily antivirus mail: definition versions reported for "
      + r.health.definitions + " of " + r.agents + " agents, connection times for " + r.health.connection + ".") : null,
    r.ok && (r.fields || []).length ? h("p", { class: "small muted" }, "Fields this console sends: " + r.fields.join(", ")) : null,
    r.ms ? h("p", { class: "small muted" }, "Answered in " + r.ms + " ms") : null));
  const test = h("button", { type: "button", class: "btn-quiet", on: { click: async () => {
    test.disabled = true; result.replaceChildren(h("p", { class: "muted" }, "Signing in to Apex Central and listing its agents…"));
    try {
      const b = body(); if (ed) b.id = ed.id;
      showResult(await apiPost("/admin/antivirus/test", b));
    } catch (err) { showResult({ ok: false, message: err.message || "Could not test." }); }
    test.disabled = false;
  } } }, "Test connection");
  const form = h("form", { class: "av-form", autocomplete: "off", on: { submit: async e => {
    e.preventDefault();
    try {
      const r = ed ? await apiSend("PUT", "/admin/antivirus/" + ed.id, body()) : await apiPost("/admin/antivirus", body());
      drawAvConsoles(page, r);
    } catch (err) { msg.textContent = err.message || "Could not save."; }
  } } },
    h("h2", null, ed ? "Edit " + ed.name : "Add an Apex Central console"),
    h("div", { class: "av-grid" },
      h("label", null, h("span", null, "Name"), name),
      h("label", null, h("span", null, "Console URL"), url),
      h("label", null, h("span", null, "Application ID"), appId),
      h("label", null, h("span", null, "API key"), key)),
    h("details", { class: "av-more", open: !!(ed && (ed.has_ca || ed.pin_sha256)) }, h("summary", null, "Certificate and network"),
      h("p", { class: "small" }, h("strong", null, "Self-signed certificate on Apex Central? "),
        "Get it, compare its fingerprint with the server, and trust that exact certificate."),
      pinnedNow, h("div", { class: "cm-actions" }, getCert), certBox,
      h("label", null, h("span", null, "Or: the CA certificate (PEM), when the console's certificate comes from your own CA"), ca),
      caRemove,
      h("label", { class: "cm-check" }, proxy, " Reach this console through the web proxy (only for a cloud console)"),
      h("p", { class: "muted small" }, "The certificate is always checked, by its CA or by its exact fingerprint; there is no option to turn that off.")),
    h("label", { class: "cm-check" }, enabled, " Read this console every hour"),
    h("div", { class: "cm-actions" }, test, h("button", { type: "submit" }, ed ? "Save changes" : "Save"),
      ed ? h("button", { type: "button", class: "btn-quiet", on: { click: () => drawAvConsoles(page, d) } }, "Cancel") : null, msg),
    result);

  const rows = d.consoles || [];
  const list = rows.length ? h("div", { class: "table-wrap" }, table([
    { label: "Console", cell: c => [h("strong", null, c.name), h("div", { class: "muted small" }, c.url)] },
    { label: "Application ID", cell: c => h("span", { class: "mono" }, c.app_id) },
    { label: "Certificate", cell: c => c.pin_sha256 ? [h("span", null, "trusted by fingerprint"),
        h("div", { class: "muted small", title: "SHA-256 " + c.pin_sha256 }, (c.pin_subject || "") + (c.pin_not_after ? " · until " + fmtDate(c.pin_not_after) : ""))]
        : c.has_ca ? "your CA" : "public CA" },
    { label: "Last read", cell: c => c.last_sync_at ? [h("span", { class: "light " + (c.last_sync_ok ? "light-on" : "light-off"), "aria-hidden": "true" }), " ",
        timeAgo(c.last_sync_at), h("div", { class: c.last_sync_ok ? "muted small" : "hd-failed small" }, c.last_sync_msg || "")] : "not yet" },
    { label: "Last test", cell: c => c.last_test_at ? [c.last_test_ok ? "passed " : "failed ", timeAgo(c.last_test_at),
        c.last_test_ok ? null : h("div", { class: "hd-failed small" }, c.last_test_msg || "")] : "–" },
    { label: "Agents", num: true, cell: c => c.agents === null || c.agents === undefined ? "–" : String(c.agents) },
    { label: "Health fields", cell: c => !c.fields_seen ? "–" : [
        /pattern/i.test(c.fields_seen.join(" ")) ? "definitions ✓" : h("span", { class: "muted" }, "no definitions"), " · ",
        /last.?(connect|contact|seen|online)|online/i.test(c.fields_seen.join(" ")) ? "connection ✓" : h("span", { class: "muted" }, "no connection time"),
        h("div", { class: "muted small", title: c.fields_seen.join(", ") }, c.fields_seen.length + " fields")] },
    { label: "", cell: c => h("span", { class: "row-actions" },
        h("button", { type: "button", class: "btn-link", on: { click: async e => {
          e.target.disabled = true;
          try { const r = await apiPost("/admin/antivirus/test", { id: c.id }); drawAvConsoles(page, await api("/admin/antivirus"));
                page.querySelector(".av-list-msg").textContent = c.name + ": " + r.message; }
          catch (err) { page.querySelector(".av-list-msg").textContent = err.message; e.target.disabled = false; } } } }, "Test"),
        h("button", { type: "button", class: "btn-link", disabled: !c.enabled, on: { click: async () => {
          try { drawAvConsoles(page, await apiPost("/admin/antivirus/" + c.id + "/sync", {}));
                page.querySelector(".av-list-msg").textContent = "The worker reads " + c.name + " within a minute."; }
          catch (err) { page.querySelector(".av-list-msg").textContent = err.message; } } } }, "Sync now"),
        h("button", { type: "button", class: "btn-link", on: { click: () => { drawAvConsoles(page, d, c); page.querySelector(".av-form input").focus(); } } }, "Edit"),
        h("button", { type: "button", class: "btn-link danger", on: { click: async () => {
          if (!confirm("Remove " + c.name + "? Its saved key and the agents read from it are deleted from PATCH-01.")) return;
          try { drawAvConsoles(page, await apiSend("DELETE", "/admin/antivirus/" + c.id)); }
          catch (err) { page.querySelector(".av-list-msg").textContent = err.message; } } } }, "Remove")) },
  ], rows)) : h("p", { class: "muted" }, "No console added yet.");

  page.replaceChildren(...[
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure av --consoles" }, "Antivirus consoles"),
      h("a", { class: "btn btn-quiet", href: "#/antivirus" }, "Open the Antivirus page")),
    d.key_ready ? null : h("p", { class: "hd-failed" }, "The key that protects saved API keys (av.key) is not on PATCH-01 yet: run phase3b-api.sh."),
    h("p", { class: "muted small" }, "PATCH-01 only reads the list of security agents; it never isolates, moves or uninstalls anything. "
      + "In Apex Central: Administration › Settings › Automation API Access Settings › Add, tick “Enable application integration”, "
      + "then copy the Application ID and API key here. Use an account with a read-only role. The key is encrypted on PATCH-01 and never shown again."),
    list, h("p", { class: "cm-meta av-list-msg", role: "status" }), form].filter(Boolean));
}

/* ---- Admin › Scheduled reports ------------------------------------------------ */

const FREQ_WORD = { daily: "Every day", weekly: "Every week", monthly: "Every month" };
const DAY_WORD = { mon: "Monday", tue: "Tuesday", wed: "Wednesday", thu: "Thursday", fri: "Friday", sat: "Saturday", sun: "Sunday" };
function whenText(s) {
  return s.frequency === "weekly" ? "Every " + DAY_WORD[s.weekday] + " at " + s.at_time
    : s.frequency === "monthly" ? "Monthly on day " + s.monthday + " at " + s.at_time
    : "Every day at " + s.at_time;
}

async function renderReportSchedules(params) {
  setNav("admin");
  if (!can("admin")) return render(h("div", { class: "empty" }, h("p", null, "Scheduled reports need the admin role.")));
  const page = h("div", { class: "rs-admin" });
  render(page);
  const d = await api("/admin/report-schedules");
  let pre = null;
  if (params.get("new")) {
    let p = {};
    try { p = JSON.parse(params.get("p") || "{}"); } catch (e) { p = {}; }
    const r = (d.reports || []).find(x => x.key === params.get("new"));
    if (r) pre = { name: r.title + ", daily", report: r.key, params: p, format: "pdf", frequency: "daily", at_time: "08:00",
                   weekday: "mon", monthday: 1, recipients: null, skip_empty: false, enabled: true };
  }
  drawReportSchedules(page, d, pre);
  adminTabs("report-schedules");
}

function drawReportSchedules(page, d, editing) {
  const msg = h("p", { class: "cm-meta", role: "status" });
  const titleOf = k => ((d.reports || []).find(r => r.key === k) || {}).title || k;
  const list = (d.schedules || []).length ? h("div", { class: "table-wrap" }, table([
    { label: "Report", cell: s => [h("strong", null, s.name), h("div", { class: "muted small" }, titleOf(s.report) + " · " + s.format.toUpperCase())] },
    { label: "When (SGT)", cell: s => whenText(s) },
    { label: "To", cell: s => s.recipients ? s.recipients.join(", ")
        : "Daily digest recipients (" + (d.digest_recipients || []).length + ")" },
    { label: "Last sent", cell: s => s.last_run_at ? [h("span", { class: "light " + (s.last_ok ? "light-on" : "light-off"), "aria-hidden": "true" }), " ",
        timeAgo(s.last_run_at), h("div", { class: s.last_ok ? "muted small" : "hd-failed small" }, s.last_msg || "")] : "not yet" },
    { label: "On", cell: s => h("input", { type: "checkbox", checked: !!s.enabled, "aria-label": "Send " + s.name, on: { change: async e => {
        try { drawReportSchedules(page, await apiSend("PUT", "/admin/report-schedules/" + s.id, scheduleBody(Object.assign({}, s, { enabled: e.target.checked })))); }
        catch (err) { msg.textContent = err.message; e.target.checked = !e.target.checked; } } } }) },
    { label: "", cell: s => h("span", { class: "row-actions" },
        h("button", { type: "button", class: "btn-link", on: { click: async () => {
          try { drawReportSchedules(page, await apiPost("/admin/report-schedules/" + s.id + "/run", {}));
                page.querySelector(".rs-msg").textContent = s.name + ": it goes out within a minute."; }
          catch (err) { page.querySelector(".rs-msg").textContent = err.message; } } } }, "Send now"),
        h("button", { type: "button", class: "btn-link", on: { click: () => { drawReportSchedules(page, d, s); page.querySelector(".rs-form input").focus(); } } }, "Edit"),
        h("button", { type: "button", class: "btn-link danger", on: { click: async () => {
          if (!confirm("Stop and remove “" + s.name + "”?")) return;
          try { drawReportSchedules(page, await apiSend("DELETE", "/admin/report-schedules/" + s.id)); }
          catch (err) { page.querySelector(".rs-msg").textContent = err.message; } } } }, "Remove")) },
  ], d.schedules)) : h("p", { class: "muted" }, "No scheduled report yet.");

  const ed = editing || null;
  const name = h("input", { type: "text", maxlength: "80", required: true, value: ed ? ed.name : "" });
  const rep = h("select", null, (d.reports || []).map(r => h("option", { value: r.key, selected: ed && ed.report === r.key }, r.title)));
  const fmt = h("select", null, ["pdf", "csv"].map(f => h("option", { value: f, selected: ed && ed.format === f }, f.toUpperCase())));
  const freq = h("select", null, ["daily", "weekly", "monthly"].map(f => h("option", { value: f, selected: ed && ed.frequency === f }, FREQ_WORD[f])));
  const at = h("input", { type: "time", value: ed ? ed.at_time : "08:00", required: true, step: "60" });
  const wd = h("select", null, Object.keys(DAY_WORD).map(k => h("option", { value: k, selected: ed && ed.weekday === k }, DAY_WORD[k])));
  const md = h("input", { type: "number", min: "1", max: "28", value: ed ? ed.monthday : 1 });
  const wdL = h("label", null, h("span", null, "Day"), wd), mdL = h("label", null, h("span", null, "Day of month"), md);
  const syncWhen = () => { wdL.hidden = freq.value !== "weekly"; mdL.hidden = freq.value !== "monthly"; };
  freq.addEventListener("change", syncWhen); syncWhen();
  const digest = h("input", { type: "radio", name: "rs-to", checked: !ed || !ed.recipients });
  const pick = h("input", { type: "radio", name: "rs-to", checked: !!(ed && ed.recipients) });
  const boxes = (d.recipients || []).map(r => h("label", { class: "cm-check" },
    h("input", { type: "checkbox", value: r.address, checked: !!(ed && ed.recipients && ed.recipients.some(x => x.toLowerCase() === r.address.toLowerCase())) }),
    " " + (r.name ? r.name + " <" + r.address + ">" : r.address)));
  const pickBox = h("div", { class: "rs-pick" }, boxes);
  const syncTo = () => { pickBox.hidden = !pick.checked; };
  digest.addEventListener("change", syncTo); pick.addEventListener("change", syncTo); syncTo();
  const p = (ed && ed.params) || {};
  const offH = h("input", { type: "number", min: "1", max: "720", value: p.offline_hours || 24 });
  const behind = h("input", { type: "number", min: "1", max: "50", value: p.pattern_behind || 4 });
  const unprot = h("input", { type: "checkbox", checked: p.include_unprotected !== false });
  const avBox = h("fieldset", { class: "rs-av" }, h("legend", null, "Antivirus health"),
    h("label", null, h("span", null, "Offline after (hours without connecting)"), offH),
    h("label", null, h("span", null, "Definitions outdated when behind the newest by more than (releases)"), behind),
    h("label", { class: "cm-check" }, unprot, " Also list machines with no antivirus agent"));
  const days = h("input", { type: "number", min: "1", max: "31", value: p.days || 1 });
  const actBox = h("label", { class: "rs-act" }, h("span", null, "Activity of the last (days)"), days);
  const syncRep = () => { avBox.hidden = rep.value !== "av_health"; actBox.hidden = rep.value !== "activity"; };
  rep.addEventListener("change", syncRep); syncRep();
  const skip = h("input", { type: "checkbox", checked: !!(ed && ed.skip_empty) });
  const enabled = h("input", { type: "checkbox", checked: ed ? !!ed.enabled : true });
  const fmsg = h("p", { class: "cm-meta", role: "status" });
  const form = h("form", { class: "rs-form", on: { submit: async e => {
    e.preventDefault();
    let params = Object.assign({}, p);
    if (rep.value === "av_health") params = Object.assign(params, { offline_hours: Number(offH.value), pattern_behind: Number(behind.value), include_unprotected: unprot.checked });
    if (rep.value === "activity") params = Object.assign(params, { days: Number(days.value) });
    const recipients = pick.checked ? boxes.map(b => b.querySelector("input")).filter(i => i.checked).map(i => i.value) : null;
    if (pick.checked && !recipients.length) { fmsg.textContent = "Tick at least one recipient."; return; }
    const body = scheduleBody({ name: name.value.trim(), report: rep.value, format: fmt.value, frequency: freq.value, at_time: at.value,
      weekday: wd.value, monthday: Number(md.value), recipients, params, skip_empty: skip.checked, enabled: enabled.checked });
    try {
      drawReportSchedules(page, ed && ed.id ? await apiSend("PUT", "/admin/report-schedules/" + ed.id, body)
                                            : await apiPost("/admin/report-schedules", body));
    } catch (err) { fmsg.textContent = err.message || "Could not save."; }
  } } },
    h("h2", null, ed && ed.id ? "Edit “" + ed.name + "”" : "Schedule a report"),
    h("div", { class: "av-grid" },
      h("label", null, h("span", null, "Name"), name), h("label", null, h("span", null, "Report"), rep),
      h("label", null, h("span", null, "File"), fmt), h("label", null, h("span", null, "How often"), freq),
      h("label", null, h("span", null, "Time (SGT)"), at), wdL, mdL),
    avBox, actBox,
    h("fieldset", { class: "rs-to" }, h("legend", null, "Send to"),
      h("label", { class: "cm-check" }, digest, " The daily digest recipients (" + (d.digest_recipients || []).length + ")"),
      h("label", { class: "cm-check" }, pick, " Chosen recipients"), pickBox,
      h("p", { class: "muted small" }, "Only the recipients set in Admin › Mail can receive reports.")),
    h("label", { class: "cm-check" }, skip, " Skip the mail when the report is empty"),
    h("label", { class: "cm-check" }, enabled, " On"),
    h("div", { class: "cm-actions" }, h("button", { type: "submit" }, ed && ed.id ? "Save changes" : "Save"),
      ed ? h("button", { type: "button", class: "btn-quiet", on: { click: () => drawReportSchedules(page, d) } }, "Cancel") : null, fmsg));

  page.replaceChildren(...[
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure reports --schedule" }, "Scheduled reports")),
    d.mail_ready ? null : h("p", { class: "hd-failed" }, "Mail is off: nothing is sent until it is turned on in ", h("a", { href: "#/mail" }, "Admin › Mail"), "."),
    h("p", { class: "muted small" }, "Each report is built on PATCH-01 when it is due and sent in the branded mail, with a summary and the "
      + "file attached (PDF or CSV). Times are Singapore time. Any page with Export › E-mail… can also send its report at once."),
    list, h("p", { class: "cm-meta rs-msg", role: "status" }), form].filter(Boolean));
}

function scheduleBody(s) {
  return { name: s.name, report: s.report, format: s.format, frequency: s.frequency, at_time: s.at_time, weekday: s.weekday,
           monthday: s.monthday, recipients: s.recipients || null, params: s.params || {}, skip_empty: !!s.skip_empty, enabled: !!s.enabled };
}
