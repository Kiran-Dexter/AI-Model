# Patch Platform

A self-hosted patch and vulnerability management platform for an estate of
about 200 Linux servers running RHEL 8/9, Oracle Linux 8 and Ubuntu.

It mirrors vendor patches, tracks which servers are exposed to which
security advisories, explains each verdict in plain language using a local
language model, and shows it all on a web console.

Nothing here reaches the internet except PATCH-01's repository syncs, which go
through the corporate proxy. AI-01 has no internet access at all.


## Architecture

```
                vendor repos (Red Hat CDN, Oracle, Ubuntu)
                               |
                         corporate proxy
                               |
+----------------------------- | -------------------------------------+
| PATCH-01  (RHEL 9, Docker)   v                                       |
|                                                                      |
|  NGINX :443  ── the only port open on this host                      |
|    /                 -> dashboard     static web console             |
|    /api/             -> patch-api     FastAPI: agents, admin, CVEs   |
|    /pulp/api/v3/     -> pulp-api      repository management          |
|    /pulp/content/    -> pulp-content  package downloads              |
|                                                                      |
|  pulp-worker   syncs and publishes repositories                      |
|  postgres      two databases: pulp, patchdb                          |
|  redis         job queue and cache                                   |
|                                                                      |
|  Every service except NGINX publishes NO host port. They talk over   |
|  the internal Docker network "patchnet" by container name.           |
+---------------------------|-----------------------------|------------+
                            | HTTPS 443                   | HTTPS 443
                            v                             v
        ~200 managed servers (agents)          AI-01 (RHEL 9, no internet)
        pull-only: check in, send               NGINX :443, allows PATCH-01 only
        inventory, poll for commands            llama-server on 127.0.0.1:8080
                                                Qwen3-8B Q4_K_M
```

Design rules that run through everything:

- **The verdict comes from a version check, never from the model.** The CVE
  engine decides; AI-01 only explains. Every explanation is labelled as
  advisory in the console.
- **Five applicability states**, stored as a database enum so every screen and
  report reads the same values: `affected`, `fixed_pending_reboot`,
  `fixed_active`, `unknown`, and `not_affected` (implied by absence). Only
  `fixed_active` counts as remediated. A server with the fixed kernel
  installed but not yet booted is **not** remediated.
- **A server that stops reporting shows as "unknown", never as zero.** Silence
  fails toward attention.
- **Agents accept a closed set of eight commands.** None takes a shell string,
  so a compromised PATCH-01 can install signed packages but cannot run
  arbitrary commands as root across the fleet.
- **The audit trail cannot be edited.** A database trigger rejects UPDATE and
  DELETE on the audit log and job events, for every role.
- **Scripts discover what is installed rather than assuming it.** Image names,
  user IDs, data paths, binary locations and supported options are all
  detected at run time.


## What is in this bundle

```
patch-platform/
├── README.md                 this file
├── MANIFEST.sha256           checksums of every file
├── patch01/                  everything for the master server
│   ├── scripts/              run these, in the order below
│   ├── compose/              templates; filled in by the scripts
│   ├── nginx/                ingress configuration
│   ├── sql/                  database schema, applied in order
│   ├── api/                  patch API, CVE engine, AI-01 client
│   ├── dashboard/            web console
│   ├── config/repos.conf     which repositories to mirror
│   └── agent/                copy of the client agent
├── client/                   copy these two files to each managed server
│   ├── patch-agent.py
│   └── install-agent.sh
├── ai01/
│   └── ai01-setup.sh         run on AI-01
└── docs/
    └── proxy-allowlist.txt   for the network team
```


## PATCH-01: build order

Run as root from `patch01/`. Each script has `--dry-run`, and most have
`--check`, which you should run after each step.

| Step | Command | What it does |
|------|---------|--------------|
| 0 | `scripts/phase0-bootstrap.sh` | Packages, LVM volumes, `/patch` tree |
| 1 | `scripts/resolve-images.sh` | Finds which local images fill each role |
| 1a | `scripts/phase1a-ingress.sh` | NGINX and TLS on 443 |
| 1b | `scripts/phase1b-data.sh` | PostgreSQL and Redis |
| 1c | `scripts/phase1c-pulp.sh` | Pulp api, content, worker |
| 2 | `scripts/phase2-repos.py --setup`, `--sync`, `--publish` | Mirror the repositories |
| 3a | `scripts/phase3a-schema.sh` | Patch platform database schema |
| 3b | `scripts/phase3b-api.sh` | Build and run the patch API |
| 4 | `scripts/phase4-cve.sh` | Import advisories, compute verdicts |
| 5 | `scripts/phase5-dashboard.sh` | Web console |
| 6 | `scripts/phase6-llm.sh --ai01 <AI-01 IP>` | Connect to AI-01 |
| 7 | `scripts/phase7-vmware.sh --add <name> --host <vcenter>` | Read VM inventory from each vCenter |
| 8 | `scripts/phase4-cve.sh --set-nvd-key` then `--intel` | Fetch published CVE data |
| 9 | `scripts/phase7-vmware.sh --add-writer <name>` | Optional: write account for snapshots and power |

Step 3b runs two containers from the same image: the API, and the **worker**
that carries out scheduled changes and fills in CVE assessments. On its first
start the API creates the user `admin` from the `ADMIN_PASSWORD` already in
`/patch/secrets/api.env`, so the password you used before still signs in.

The **Assess** page and the chat need no setup beyond the API rebuild: they use
data the platform already holds.

Later schema changes are new files in `sql/` (`001`, `002`, `003`, ...).
Re-running `phase3a-schema.sh` applies any that are missing; it is safe to
run again at any time.

Before step 2, the corporate proxy must be recorded in
`/etc/patch-platform/proxy.env` (`HTTP_PROXY`, `HTTPS_PROXY`, `NO_PROXY`).
Step 2 reads it from there, not from your shell.

**Note on phase 0:** it was written when the plan was Podman, before Docker was
chosen. It installs Podman and moves Podman's image store onto `/patch`, which
is harmless but does not apply to Docker. Docker's own storage location is not
handled by phase 0; phase 1a detects if Docker is still storing images on the
root filesystem and prints the steps to move it.


## Upgrading from r11

```bash
./scripts/phase3a-schema.sh            # schema 009: users, sessions, changes
./scripts/phase3b-api.sh               # API and the new worker; creates 'admin'
./scripts/phase3b-api.sh --check       # confirms the worker is beating
./scripts/phase5-dashboard.sh          # sign-in page, Changes, Users
./scripts/phase7-vmware.sh --add-writer vc-uat   # only for snapshots and power
```

From r15, also run `./scripts/phase8-hardening.sh --fetch <version>` and
update agents to 1.4.0 for hardening scans.

From r14, also run `./scripts/phase7-vmware.sh --sync` once after
`phase3b-api.sh`, so health, alarms and application groups are filled in
before the map is first opened.

Then sign in as `admin` with the old password, open **Users** and create an
account for each person. Update the agents to 1.3.0 before scheduling the
first patch job (see Updating agents). Hard-refresh the browser once
(Ctrl+F5) so it loads the new console.


## The live VMware map

**VMware > Live map** draws the whole estate from vCenter: port groups on the
left, clusters with their ESXi hosts and VMs in the middle, datastores on the
right. Switch to **Applications** to group VMs by application instead.

| Colour | Means |
|--------|-------|
| Neon red | Host down or not responding; datastore 90%+ full or inaccessible; red vCenter alarm; exploited CVEs to patch; host CPU or memory 95%+ |
| Amber | Patches or a reboot due; maintenance mode; yellow alarm; VMware Tools not running; snapshot 7+ days old; datastore 80%+ full or over-provisioned; HA off |
| Green | Running, nothing to act on |
| Grey | Powered off |

A dashed ring round a VM means no patch agent, so its patch state is unknown.

**Blast radius.** Click a host, datastore or port group:

- **Host:** every VM on it, and whether HA restarts it. A VM stays down if the
  cluster has HA off, the host is standalone, a disk is on storage only that
  host sees, or the other hosts lack the memory. VMs are placed largest
  first, the way capacity actually runs out.
- **Datastore:** every VM with any disk on it goes down. HA cannot help.
- **Port group:** VMs with no other network are isolated; the rest degraded.

Each shows the applications hit. Click a VM to trace its host, datastores and
networks.

**Live updates.** The worker holds a change stream open to each vCenter with
the read-only account, and records vMotions, power changes, host failures,
maintenance mode and alarms as they happen. The page checks every 5 seconds;
changed objects ripple, and the side panel shows a live feed. The LIVE light
is green while every vCenter is streaming, amber if one is reconnecting.

**Application groups** come from a vSphere tag in a category called
Application (or App, Service, Workload, System), else the VM's folder. The
**Coverage** tab lists what is ungrouped, and which VMs are on standard
switches only (which cannot export flow records for dependency lines later).

The hourly `phase7-vmware.sh` sync still runs: it refreshes everything the
stream does not carry, such as disks, performance and tags.


## Hardening

Each server is compared with the CIS benchmark as published in the SCAP
Security Guide (ComplianceAsCode): CIS-aligned, not the licensed CIS-CAT
tool. One release is pinned on PATCH-01 and served to every agent, so every
server is judged by exactly the same rules.

**Setting up**

```bash
./scripts/phase8-hardening.sh --fetch 0.1.NN      # release number from the ComplianceAsCode
                                                  # GitHub releases page
./scripts/phase8-hardening.sh --status            # products, rules, CIS levels found
```

The proxy must allow github.com, objects.githubusercontent.com and
release-assets.githubusercontent.com. Without internet on PATCH-01, download
`scap-security-guide-0.1.NN.zip` and its `.sha512` elsewhere, copy both over,
and run `--import-zip scap-security-guide-0.1.NN.zip`.

On every server: agent 1.4.0 (`client/install-agent.sh`) and the OpenSCAP
scanner, from a mirrored repository:

| OS | Package |
|----|---------|
| RHEL 8/9, Oracle Linux 8/9 | `openscap-scanner` (AppStream) |
| Oracle Linux 7 | `openscap-scanner` (`yum`) |
| Ubuntu 24.04 | `openscap-scanner` (universe) |
| Ubuntu 20.04, 22.04 | `libopenscap8` (universe) |

A server without the scanner shows "last scan failed" with the install
command. Then scan from the console, or `./scripts/phase8-hardening.sh --scan`.

**What is scored.** Score = passed rules / (passed + failed). Not applicable
and not checked rules do not count either way. A product whose content has
no CIS profile at the chosen level shows "no L1 profile" rather than a score:
nothing is labelled CIS that is not.

**Evidence.** Every scan's full result file is kept in
`/patch/data/hardening/evidence`, with its SHA-256 shown in the console.

**Custom profiles.** A profile built from your own document checks only
the settings it lists. On the Hardening page, open the profile list and
choose *New or manage custom profiles*: name it, choose the benchmark its CIS
numbers follow (CIS numbering differs between RHEL 8, RHEL 9 and Ubuntu),
and upload the file or paste the list. Every line is shown with the check it
matched and how (CIS number, title, AI-01, or chosen by you). Lines marked
**?** matched by number but read differently, often a sign the document
follows another benchmark version; confirm them. Process items (access
reviews, backups) stay as manual checks and appear in reports as such. Scans
with a custom profile need agent 1.6.0.

**Risky rules** (SSH, PAM and passwords, firewall, sudo, audit, mount
options, boot loader, kernel modules) are marked: fixing them can cut off
access or stop services. Fixes arrive in increment 5, one server first.


## Rolling out agents

**Linux**, from PATCH-01 or a jump host with SSH keys to the servers:
```bash
cd client
./push-linux.sh -H servers.txt -s https://patch01.example --ca corp-ca.pem -u root --test-only
../patch01/scripts/phase10-windows.sh --tokens <N> <group> > tokens.txt     # N from the test run
./push-linux.sh -H servers.txt -s https://patch01.example --ca corp-ca.pem -u root -t tokens.txt
```
**Windows**, from a jump host with WinRM:
```powershell
.\push-agent.ps1 -Computers servers.txt -Server https://patch01.example -Pin system -TestOnly
.\push-agent.ps1 -Computers servers.txt -Tokens tokens.txt -Server https://patch01.example -Pin system
```
`-Pin system` trusts PATCH-01 through Windows' own certificate store, which
needs your CA there (usually by Group Policy); certificate renewals then need
no re-pin. Otherwise use the pin from Admin › Certificate.
Tokens last 72 hours: make them per batch.


## Windows servers

On PATCH-01:
```bash
./scripts/phase10-windows.sh --msrc          # Microsoft's CVE data, 24 months (proxy: api.msrc.microsoft.com)
./scripts/phase10-windows.sh --pin           # the certificate pin for the agents
./scripts/phase10-windows.sh --tokens 1      # one enrolment token (or 50 for push-agent.ps1)
```

On a Windows server, as administrator, from `client/windows`:
```powershell
.\install-agent.ps1 -Server https://patch01.example -Pin <pin> -SelfTest     # checks every step, installs nothing
.\install-agent.ps1 -Server https://patch01.example -Pin <pin> -Token <token>
```
For many servers, from a jump host with WinRM access (each server runs the
self-test first and is only enrolled if it passes):
```powershell
.\push-agent.ps1 -Computers servers.txt -Server https://patch01.example -Pin <pin> -TestOnly
.\push-agent.ps1 -Computers servers.txt -Tokens tokens.txt -Server https://patch01.example -Pin <pin>
```
The pin changes when PATCH-01's certificate is replaced (for example by the
CA-signed one): re-run `install-agent.ps1 -Update` after setting the new pin,
or reinstall. With a CA-signed certificate the pin can be `system`.

**Two views of what is missing.** The advisories come from the OS build and
Microsoft's data, so they include fixes WSUS has not approved. The Windows
Update section shows what WSUS has approved but the server has not installed.
Fixes that are not part of the OS build (.NET, SQL Server) appear only in the
second.


## Reports and branding

**Logo.** Copy a PNG to `/patch/data/branding/logo.png` on PATCH-01 (any
size; a transparent background looks best). Optionally add
`logo-white.png` for dark backgrounds. There is nothing to configure:
PATCH-01 trims, sizes and caches it, and uses the new file as soon as it
changes. **Admin › Branding** shows what it made of it, and any advice (for
example, if the logo is too small to print sharply).

**Company details** on the same page: name, the copyright line for every
footer, and the classification (CONFIDENTIAL, INTERNAL, RESTRICTED, PUBLIC).

**Making a report.** Hardening › **Export report**: choose the report type
(*Management summary*, or *Technical detail* with how to fix each finding),
the scope, an optional cover title, then **PDF** or **Word**. It is built
from each server's latest scan, downloads at once, and stays in the
**Reports** list below with its SHA-256, so a copy given to an auditor can
be matched to the original. Files are kept in `/patch/data/hardening/reports`.

**E-mailing it.** **Email this report** (or **Email** in the Reports list)
opens a window with the report's key figures and a draft from AI-01, which
takes up to a minute on AI-01's hardware. Edit it, add recipients, and send:
the report goes as an attachment, with the signature from Admin › Mail.
Mail must be set up under Admin › Mail first.

The Word version opens with an offer to update fields: say yes, and the
contents gain their page numbers.


## Mail alerts

Set up on the admin **Mail** page:

1. **Relay:** host, port and encryption (STARTTLS on 587 or 25, TLS on 465, or
   none for a plain internal relay). For a mailbox, give its login and
   password. If the relay's certificate comes from an internal CA, paste
   that CA under *Certificate checks*.
2. **Sender:** the mailbox address, and the name recipients see.
3. **Test connection.** Each step is shown, and a failure says what to fix.
4. **What to send** and **when**, then **Save settings**.
5. **Recipients:** add addresses and tick the kinds of mail each receives;
   use **Test** beside each. Then tick *Send mail alerts* and save.

SMTP goes straight from PATCH-01 to the relay, not through the web proxy:
the firewall must allow PATCH-01 to reach the relay's port.

| Mail | When |
|------|------|
| Critical | Within a minute: exploited CVE on a server, ESXi host not connected, vCenter unreachable, datastore at 90% (cleared below 85%), failed change, high-severity hardening drift, worker stopped |
| Task | A change starts or finishes; a scan someone requested completes |
| Daily digest | At the chosen time (Singapore): fleet state and the last 24 hours |
| Weekly summary | The chosen day: the week, and the servers with most to patch |

The relay password is write-only: the console can replace it but never shows
it. It is stored encrypted with `/patch/secrets/mail.key`, which exists only
on PATCH-01. If that key is lost, enter the password again.

From PATCH-01 itself: `./scripts/phase9-mail.sh --status`, `--check`,
`--test ADDRESS`, `--off`, `--on`.


## Users and roles

Everyone signs in with their own account, so the Activity log and every
change record name a person rather than a shared login.

| Role | Can |
|------|-----|
| Viewer | See every dashboard, server, advisory, VMware page, past assessment and change record. Changes nothing. |
| Operator | Everything a viewer can, plus schedule patch jobs and VMware actions, cancel them, run CVE assessments, use the chat and AI explanations. |
| Admin | Everything, plus users, enrolment tokens, decommissioning, and the BOT-MODE theme. |

Viewers and operators choose between System, Light and Dark. BOT-MODE is the
admin's theme only.

Accounts are created on the **Users** page with a temporary password; the
person must choose their own at first sign-in. Passwords need 12 or more
characters from at least three of: lower case, upper case, digits, symbols,
and may not contain the username. Five wrong passwords lock an account for 15
minutes; an admin can unlock it sooner. Sessions last 12 hours of activity and
end when the browser tab closes. The last active admin cannot be disabled or
demoted, so the platform can never be left without one.

Enforcement is in the API, not the console: hiding a button is convenience,
and a viewer calling an operator endpoint directly is refused.


## Patch jobs and VMware actions

Every action that changes something goes through **Changes**. Each change
has a number (`CHG-000042`), a required reason, a window, and a timeline of
every step with who did it. The record cannot be edited afterwards.

Operators do not need approval. If your change process later requires it, set
`REQUIRE_APPROVAL=true` in `/patch/secrets/api.env` and re-run
`phase3b-api.sh`; every change then waits until an admin other than the
requester approves it.

**A patch job** is created from **Changes > New patch job**, or from a
server's page with **Patch this server**. For each job you choose:

- What to install: all outstanding security fixes, or only named advisories.
- Reboot: never (the server is flagged instead), only if required, or always.
- VM snapshot: none, take one and keep it, or take one and remove it if
  patching succeeds. Needs the server to be linked to its VM and a write
  account for that vCenter.
- Whether services running before must still be running afterwards.
- The window, and how many servers run at once.

**Preview** shows the exact packages each server will install before anything
is scheduled. Each server then goes through the same steps, and stops at the
first failure without touching the rest:

pre-check (disk space, repositories, running services), snapshot, install,
reboot and wait for it to return, post-check, fresh inventory, snapshot
clean-up. Verdicts are recomputed straight after, so the dashboard reflects
the result at once. A server that fails keeps its snapshot for rollback.

**Cancelling** stops servers that have not started. A server part way through
finishes its current step and stops before installing.

**VMware actions**: take, remove or revert a snapshot; power on; shut down or
restart the guest cleanly through VMware Tools. There is no hard power-off:
PATCH-01 never pulls the power. Only actions valid for the VM's state are
offered.

**Reverting** discards everything since the snapshot. It requires typing the
VM's name, and PATCH-01 first takes a snapshot of the current state, so a
revert can itself be undone.

**Write account.** Syncing uses the read-only account. Snapshots and power use
a separate account per vCenter, added with `--add-writer`, which prints the
exact privileges its role needs and tests the login. Without one, the console
shows VMware actions as unavailable for that vCenter.

The worker must be running for anything to start. The Changes page shows a
warning if it has stopped; `phase3b-api.sh --check` reports it.


## Client servers

Copy `client/` to the server, then as root:

```bash
# On PATCH-01, get a single-use token
./scripts/phase3b-api.sh --token

# On the server
./install-agent.sh --server https://patch01.example --token <token> --insecure
```

The installer checks it can reach PATCH-01, tests inventory collection before
contacting it, enrolls, and installs a systemd timer that checks in every five
minutes. `--insecure` is only for while PATCH-01 has its self-signed
placeholder certificate; use `--ca <file>` once the CA-signed certificate is in
place.

Works on RHEL 8 (it uses the system Python 3.6), RHEL 9, Oracle Linux and
Ubuntu. The agent never routes its traffic to PATCH-01 through a proxy, even
if one is set in the environment.


## AI-01

1. Place the model and llama.cpp under `/llm`:
   `/llm/models/*.gguf` and `/llm/bin/llama.cpp-<tag>/`
2. If llama.cpp is source code, build it on AI-01. The compilers come from
   PATCH-01's own mirror, since AI-01 has no internet:

   ```bash
   # /etc/yum.repos.d/patch01.repo pointing at
   #   https://<PATCH-01>/pulp/content/rhel9-baseos/
   #   https://<PATCH-01>/pulp/content/rhel9-appstream/
   dnf --disablerepo='*' --enablerepo='patch01-*' install -y gcc-c++ cmake make nginx
   cd /llm/bin/llama.cpp-<tag>
   cmake -B build -DGGML_NATIVE=ON -DLLAMA_CURL=OFF -DCMAKE_BUILD_TYPE=Release
   cmake --build build -j"$(nproc)" --target llama-server
   ```
3. Run the setup, giving PATCH-01's address as the only allowed client:

   ```bash
   ./ai01-setup.sh --patch01-ip <PATCH-01 IP>
   ./ai01-setup.sh --check
   ./ai01-setup.sh --show-key
   ```
4. On PATCH-01, run step 6 and paste that key when asked.


## VMware vCenter

Read-only. PATCH-01 reads each vCenter's VMs and snapshots and links every
server to the VM it runs in. Nothing is changed in vCenter.

**Account.** Create a dedicated account, for example
`svc-patch01@vsphere.local`, in each vCenter, and give it the built-in
**Read-only** role at the top of the inventory with **Propagate to children**
ticked. That is all this needs. Snapshot rights are added only later, when
patch jobs take snapshots before patching.

**Add each vCenter** from `patch01/`:

```bash
./scripts/phase7-vmware.sh --add vc-sg01 --host vcenter01.corp.local
./scripts/phase7-vmware.sh --add vc-sg02 --host vcenter02.corp.local
./scripts/phase7-vmware.sh --install-timer        # sync every hour
```

`--add` shows vCenter's certificate thumbprint. Compare it with the one in
the vSphere Client under **Administration > Certificates > Certificate
Management > Machine SSL Certificate** before confirming. Use the vCenter's
name as it appears in its certificate, normally its FQDN, or the connection
is refused. The first `--add` also applies schema 004 and rebuilds the API
with VMware's Python library, which it downloads through the proxy.

**How servers are linked to VMs.** By hardware ID, which VMware sets as the
VM's BIOS UUID and the server reads from its firmware. That needs agent 1.2.0
or later. Older agents are linked by hostname or IP address instead, which is
weaker, and the console shows which method linked each one. A VM that shares
its hardware ID with another, usually a clone, is marked ambiguous rather
than guessed.

**Infrastructure and the map.** The VMware page has a **Map** tab showing
vCenter > datacenter > cluster > ESXi host > VM as an expandable tree, with
each VM marked by its patch and agent state, and a datastore summary. Separate
tabs list ESXi hosts (hardware, CPU model, ESXi version and build, connection
state, maintenance mode, uptime, CPU and memory load, VM count), datastores
(type, capacity, used, free, provisioned beyond capacity, hosts, VMs),
networks and clusters (DRS, HA, totals). Each VM also records its ESXi host,
folder path, datastores, networks, disks with sizes and thin provisioning,
hardware version, Tools version, boot time and provisioned storage.

**What the VMware page shows:** every VM across all vCenters, Windows
included, with a filter box for name, server, cluster or OS; Linux VMs running
without an agent; VMs with snapshots and their age; and ambiguous links.
Windows VMs appear as "not managed", since the Linux agent does not cover
them. Each server page
shows its VM, cluster, ESXi host, size and any snapshots.


## CVE intelligence

Advisories say which package to update; they rarely say what the flaw is.
These four sources fill that in, and every fact is shown with its source:

| Source | What it gives |
|--------|---------------|
| NIST NVD | Description, CVSS score and vector, weakness type (CWE) |
| CISA KEV | Whether the CVE is being exploited in the wild |
| FIRST EPSS | Probability of exploitation in the next 30 days |
| Red Hat | Red Hat's own severity, score and statement for RHEL |

**Get a free NVD API key** first. It raises the limit from 5 to 50 requests
every 30 seconds, and the first import is one request per CVE:

```bash
./scripts/phase4-cve.sh --set-nvd-key      # from nvd.nist.gov/developers/request-an-api-key
./scripts/phase4-cve.sh --estimate         # how long the first import will take
./scripts/phase4-cve.sh --intel
```

A few thousand CVEs takes roughly 30 to 40 minutes with a key, and several
hours without. Afterwards only new and changed CVEs are fetched, so the
nightly run is quick. This is the only part of the platform that reaches the
internet besides repository syncs; it needs four proxy allowlist entries,
listed in `docs/proxy-allowlist.txt`.

**Attack types are derived, not claimed.** "Remote code execution, no login
needed" comes from combining the weakness type with the CVSS vector, and the
console always shows what it was derived from, for example "CWE-362; attack
vector network, no login". Where the published data does not support a
label, it says "Unclassified" rather than guessing.

**This is what makes explanations specific.** Before, every CVE produced
roughly the same answer, because the model was only given an advisory title
such as "kernel security update". It now receives the score, how the flaw is
reached, whether it is exploited in the wild, and the CVE description.
Cached explanations are regenerated automatically when NVD rescores a CVE or
CISA adds it to the exploited list.


## Assessing a CVE list from outside

When a SOC, an auditor or a vendor sends a list of CVEs, the **Assess** page
answers which of your servers are affected. Paste the list or upload a text
or CSV file; the parser takes CVE numbers out of any text, including the en
dashes and stray spaces that survive a copy from a document.

Each CVE is then worked through in the background, so a long list does not
hold up the page, which shows progress as it goes:

1. Looked up in NVD, even when no advisory in the mirrors mentions it:
   description, CVSS score and vector, attack type (remote code execution,
   privilege escalation and so on), CISA KEV and EPSS.
2. Classified by what it affects, from NVD's product data: operating system,
   application, ESXi, vCenter, network device, or hardware and firmware.
3. Checked against the inventory: package verdicts on the Linux servers,
   ESXi hosts and vCenters by version, and VM guest operating systems.
4. Given a short brief by AI-01, written from those facts.

| Exposure | Meaning |
|----------|---------|
| Affected | A version check confirms it: a server needs the package fix, or a host's version is inside the affected range |
| Possibly affected | The product is present, but its exact patch level could not be compared (an ESXi build, a Windows guest) |
| Needs reboot | Fixed, awaiting a reboot |
| Not in our inventory | Network devices and firmware: check with their owners |
| Not found | Nothing matching is in the inventory |
| Patched | Found and already fixed |
| Not affected | The package exists but not at a vulnerable version |

"Possibly affected" is deliberately not "affected". Windows guests are known
only by their OS name until the Windows work is done, and ESXi build-level
comparison is not always possible from NVD data, so those are flagged for a
person to confirm rather than asserted.

The brief is advisory; the exposure comes from version checks, not from the
model.

Each assessment is saved, so the answer can be reopened later, and exported as
CSV to send back to whoever asked. That also records that the question was
asked and answered on a date.


## The assistant

The icon at the bottom right of the console opens the assistant. It is a
floating window: drag it by its title bar, resize it from the bottom-right
corner, enlarge it (⤢) or send it back to the corner (↵). Its place and size
are remembered in this browser.

Ask in plain words about servers, patches pending or installed on a server,
CVEs, Windows updates and KBs, WSUS, changes (CHG numbers), hardening scores,
VMs, ESXi hosts, datastores, installed software, agents, and the asset
inventory. Every answer shows the rows it came from.

- **Export**: add "export" or "csv" to a question, say "export that" after an
  answer, or press **Export CSV**. The server re-runs the same query with up to
  5000 rows; formula-like cells are neutralised.
- **E-mail**: add "email to ops team" or an address, or press **E-mail**. The
  assistant shows a draft (to, cc, subject, message, CSV attached) and
  **nothing is sent until you press Send**. It may mail only the configured
  mail recipients and addresses at their mail domains (and the sender's), at
  most ten mails an hour per user; each mail is in the audit log and the mail
  history. The server re-reads the data itself: the browser cannot change
  what is attached.
- **Speaking**: tick **Read answers aloud**, or press **Read** on an answer.
  Only the computer's offline voices are offered (on Windows, the installed
  Windows voices); voices that would send text to an online service are never
  used. Typing is the only input: browser voice input sends audio to an
  online service, so it is not offered.

It is **read-only**. Patching, snapshots, power and software actions go
through the approval flow, never from a sentence typed into the assistant.

How it answers, and why it can be trusted:

- AI-01 only chooses **which prepared query to run**, from a fixed list. It
  never writes database queries, never sees a row of data, and never supplies
  a figure that appears in an answer. Text stored in the database (a server
  name, a program name, a CVE description) therefore cannot instruct it.
- Parameters are rebuilt against a type and range before use, so a confused or
  manipulated model cannot widen a query.
- Export and e-mail are recognised by PATCH-01's own code, not by the model.
- If AI-01 is unreachable, keywords choose the query and it still works.

Operators and admins.


## Keeping the dashboard truthful

The console can only be as current as the last repository sync. If the mirror
is behind, the platform will report a server as patched because the newer
advisory is not in the mirror yet, while `dnf` talking to the vendor directly
sees it. Sync, import, then compute, in that order:

```bash
./scripts/phase2-repos.py --sync --publish
./scripts/phase4-cve.sh --import
./scripts/phase4-cve.sh --compute
```

`phase4-cve.sh --install-timer` runs the import and compute nightly; schedule
the repository sync a couple of hours earlier so the engine has fresh
advisories to read.


## Everyday operations

| Task | Where | Command |
|------|-------|---------|
| Open the console | browser | `https://patch01.example/` |
| Issue an enrollment token | PATCH-01 | `scripts/phase3b-api.sh --token` |
| Sync repositories | PATCH-01 | `scripts/phase2-repos.py --sync` then `--publish` |
| Recompute verdicts now | PATCH-01 | `scripts/phase4-cve.sh` |
| Verdicts for one server | PATCH-01 | `scripts/phase4-cve.sh --host <name>` |
| Fleet report in the terminal | PATCH-01 | `scripts/phase4-cve.sh --report` |
| Pre-generate explanations | PATCH-01 | `scripts/phase6-llm.sh --warm 20` |
| Nightly CVE run and explanations | PATCH-01 | `phase4-cve.sh --install-timer`, `phase6-llm.sh --install-timer` |
| After a Red Hat certificate refresh | PATCH-01 | `subscription-manager refresh`, then `phase2-repos.py --update-remotes` |
| Health of the whole stack | PATCH-01 | each script's `--check` |
| Agent status, one server | client | `install-agent.sh --status` |
| Agent status, whole fleet | browser | **Agents** page |
| Model server status and speed | AI-01 | `ai01-setup.sh --check`, `--bench` |
| vCenter status | PATCH-01 | `scripts/phase7-vmware.sh --check` |
| Refresh CVE data | PATCH-01 | `scripts/phase4-cve.sh --intel` |
| What is exploited in the wild | PATCH-01 | `scripts/phase4-cve.sh --report` |
| Sync vCenters now | PATCH-01 | `scripts/phase7-vmware.sh --sync` |


## Updating agents

Re-run the installer on the server with the new `client/` files. It keeps the
server's existing identity, so no new token is needed:

```bash
./install-agent.sh --server https://patch01.example --insecure
```

The **Agents** page lists any server still on an older version. The current
agent is **1.5.0**, which patch jobs need: it installs exact versions,
records running services before patching so they can be checked afterwards,
and carries out a job's steps in sequence.

Agent states:

| State | Meaning |
|-------|---------|
| Online | Checked in within 15 minutes |
| Offline | Missed several check-ins, but under 24 hours |
| Not reporting | Silent over 24 hours; its verdicts show as unknown |
| No data yet | Enrolled but never checked in |

Agent 1.1.0 and later report boot time, from which uptime is shown. Older
agents keep working but show uptime as "not reported".


## Change log

**r51: the assistant: floating, speaks, exports, e-mails, answers far more**
- The chat is now a **floating window**: drag, resize, enlarge, back to the
  corner; remembered per browser.
- It answers far more (29 prepared, read-only queries, up from 9): fleet
  overview; server list; one server's detail, **patches pending**, **patches
  installed** and installed software; where a program is installed; agents
  by state and version; servers waiting for a reboot; servers needing patches
  (Windows included); CVEs (one, exploited, most serious); recent advisories;
  Windows servers missing updates; servers missing a KB; WSUS computers
  needing attention; recent changes and one change in detail (warnings
  included); hardening scores; VMs by name or power state; old snapshots; VMs
  without an agent; ESXi hosts; datastores low on space; the asset inventory.
- Follow-ups refer back: "export that", "email it to the ops team".
- **Export CSV** and **E-mail** (draft, sent only when you press Send, to
  allowed recipients only, rate-limited, audited). See "The assistant".
- **Reads answers aloud** with offline voices only.
- Rebuild the API and dashboard: `phase3b-api.sh`, then `phase5-dashboard.sh`.
  No schema change.

**r50: service warnings, Inventory pages**
- **A service that does not come back after patching no longer fails the
  patch.** When the postcheck's only problem is services that were running
  before and are not now, the updates count as installed, the server ends as
  **Done, with warnings**, the services are named, and the snapshot is kept
  (even with "remove if it succeeds"). Any other postcheck problem still fails.
- A failure reported by the Linux agent kept its message: it was dropped, so
  failures read "the agent reported a failure".
- **Inventory** menu, two pages:
  - **Assets**: every machine from agents, vCenter (VMs, ESXi hosts, the
    vCenters) and WSUS, merged by name, each typed as server, client or
    appliance from its OS (hover the type for the reason), with where it runs,
    power, agent state, last seen; filters, search, and "without an agent".
  - **Software**: Windows programs and Linux packages by program and version,
    for servers or clients, with the machines that have each. Software comes
    only from agents (vCenter and WSUS do not report installed software).
  - Both export CSV; cells that a spreadsheet would run as formulas are
    neutralised. Windows > Software moved here.
- The top menu now tightens on narrower screens as intended (its narrow-screen
  rules were being overridden).

**r49: Windows agent 1.4.0-win: everything checked, and downloaded, before installing**
- PATCH-01 now chooses a Windows job's updates at the **precheck** and sends
  them with it. The precheck logs every check as it runs (disk; the Windows
  Update, BITS, Cryptographic and Modules Installer services; a pending
  reboot; WSUS reachable), looks the updates up by ID, tests **the exact
  address each update file downloads from**, and names it if it cannot be
  reached (with the usual cause: WSUS approving updates without storing their
  files). Then it **downloads the updates during the precheck**, with
  progress every 30 seconds, and stops with a clear reason if nothing arrives
  for 10 minutes. Nothing is installed in the precheck, so stopping is safe.
- The install step reports whether Windows is busy or idle, and stops a
  download that has not moved for 15 minutes.
- The Windows precheck may take up to 110 minutes (it includes the download).

**r48: Windows agent 1.3.2-win: visible, quicker installs**
- Updates install one at a time (servicing stack first), and every step is
  logged: looking up, downloading N of M, installing N of M, installed in
  X min, or FAILED with its result code. While Windows works, the agent copies
  this into its log and sends it to PATCH-01 every 30 seconds, with a "still
  working (N min so far)" line when Windows is quiet, so ">_ Log" shows where
  a long cumulative update is.
- The install looks up only the job's own updates by ID (seconds) instead of
  repeating a full Windows Update search (minutes); a full search is the
  fallback if the lookup by ID is refused.

**r47: Windows agent 1.3.1-win: commands were skipped**
- On PowerShell 5.1, Invoke-RestMethod returns a JSON list as one object.
  The agent wrapped it in another list, found no command id on it, and
  skipped every command without a word: PATCH-01 saw the step taken and
  never answered. The list is now unrolled whichever way it comes back; the
  agent logs how many commands it received; a command it cannot read is
  logged as an error and answered as failed instead of skipped.

**r46: fail-fast fix**
- The fail-fast check used the last check-in time, which an inventory report
  also moves: a Windows inventory step (its Windows Update search can take
  minutes) could have been failed while still running. It now uses the time
  the agent last started a run (`hosts.last_run_at`, set only by check-ins).
  Run phase3a (schema 21 gains the column) and phase3b.

**r45: visible, fast failures (agents 1.7.0 and 1.3.0-win)**
- **Live log** (`>_ Log` in the top bar): a small floating terminal with
  agent log lines and change steps as they happen; it follows the page (a
  change, a server, or everything), can be moved and resized, and stays open.
  Lines are shown as plain text only.
- **Agents send their log lines to PATCH-01** after every command and at the
  end of every run, including a run that crashed. PATCH-01 keeps the newest
  3000 lines per server for 14 days and masks anything that looks like a
  secret as it arrives.
- **Fail fast:** when an agent took a step and its run ended without
  answering, the step fails within minutes, quoting the agent's last log
  lines, instead of after the 30-minute limit. A timeout quotes them too.
- **Windows jobs no longer wait 5 minutes between steps:** the agent asks for
  the next step straight after finishing one, as the Linux agent does.
- Results are retried three times; a failed send is logged.
- The "worker is not running" banner was wrong for 58 minutes of every hour
  (the hardening thread reports hourly): each thread is now judged on its own
  pace, and the banner shows only when the change runner has stopped.
- Schema `021-agent-logs.sql`. Run phase3a, phase3b, phase5; update agents.

**r44: Windows software from a share (S2)**
- **Windows > Installers**: a catalog of approved installers (MSI, or EXE with
  reviewed silent options) on a share: path, SHA-256, the publisher whose
  Authenticode signature it must carry, the MSI product code or EXE uninstall
  options, and its name in Programs and Features. A different admin must
  approve each entry (enforced by the API and the database).
- **Software jobs** (Changes > New software job): install, upgrade or remove
  on Windows servers, through precheck, snapshot, install, reboot, postcheck
  and inventory. They always need a second person's approval.
- **The share credential is entered at run time** on the job's page: the job
  waits until then. It is kept encrypted in memory-backed storage on PATCH-01
  (`/run/patch01-vault`, emptied at boot), never in the database, logs or on
  disk; each server fetches it once; it is gone when the job ends (6 hours at
  most). Only the API holds its key.
- **Windows agent 1.2.0-win**: re-checks everything it is sent, copies the
  installer with the job's credential, verifies its SHA-256 and signature
  before anything runs, installs with fixed templates (never through a
  shell), confirms the result, and always deletes its copy.
- Windows patch jobs with "chosen advisories" now accept KB numbers.
- Schema `020-software.sql`. Run phase3a, phase3b (makes `run.key` and the
  memory-backed folder) and phase5; update Windows agents to 1.2.0-win.

**r43: no site host names**
- Examples and documents use the placeholder `patch01.example`; the setup
  scripts have no built-in address and ask for it (an upgrade offers the
  address the existing agent uses). Nothing site-specific is shipped.

**r42: one guided script per OS for installing or upgrading the agent**
- `client/setup-agent.sh` (Linux) and `client/windows/Setup-Agent.ps1`
  (Windows): find any existing agent, upgrade it in place keeping its
  identity, or install and enrol a new one; check DNS and the port; work out
  how to trust PATCH-01's certificate (the existing setting, the system's own
  trust, or your CA chain file, verified the way the agent verifies) before
  changing anything; then prove it with a check-in. Windows also sets the
  execution policy to RemoteSigned for the current user and unblocks the
  scripts. Both run unattended with --yes / -Yes.
- install-agent.sh no longer stops with "are the same file" when re-run with
  the CA it already has.

**r41: Linux precheck fix (agent 1.6.1)**
- Patch jobs on RHEL and Oracle Linux stopped at the precheck with
  "previous package transaction did not complete cleanly" on healthy
  servers: the check searched `dnf history` for "E", which is also the
  letter for Erase and appears after every kernel update. It now runs the
  package manager's own consistency check (`dnf check` / `yum check`) and
  stops only on real problems, naming the package; a failed last transaction
  is shown as a warning, since with dnf it does not block the next one.
  Update the agent with install-agent.sh (no token: the enrolment is kept).

**r40: vCenter write account fix**
- `phase7-vmware.sh --add-writer NAME` did nothing: an earlier edit had put
  the add-writer and remove-writer code inside the option-reading loop
  instead of the mode section, and swallowed `--install-timer`. All three
  work again. A failed or interrupted --add-writer now never leaves
  credentials on disk (the API is prepared first, and the file is removed
  on any exit before the login is proven). `--list` shows whether each
  vCenter has a write account.

**r39: rolling the agent out to many Linux servers**
- `client/push-linux.sh`: over SSH (keys, root or passwordless sudo), checks
  every server first (SSH, sudo, Python, and that the server can reach
  PATCH-01 and verify its certificate with your CA), then installs on those
  that passed: servers already enrolled switch to verified TLS and keep their
  identity; new ones get a token. Tokens go only to servers that passed and
  are not enrolled. `--test-only` checks without changing anything and says
  how many tokens are needed. Results in a CSV.

**r38: certificate install fix**
- Installing a certificate from the console rolled back with "cannot load
  certificate key ... Permission denied": the helper wrote the key as
  root-only (0600), but nginx runs as uid 1001 in group 0 and reads it
  through its group, as phase1a-ingress.sh sets it (root:0, 0640). The
  helper now overwrites the files in place, keeping their owner, group, mode
  and SELinux label. The rollback itself worked as designed.

**r37: PATCH-01's certificate from the console**
- **Admin › Certificate** shows the certificate nginx serves now (names,
  issuer, expiry, pin), takes an upload (certificate and key files, a DER
  .cer, or a .pfx with its password), and checks it before anything changes:
  the key matches, it is in date, it names the short name and FQDN, it is for
  TLS servers, the key is strong enough, and the chain is complete (put in
  order automatically). It gives the new pin and the exact Windows re-pin
  commands, and only installs once you confirm those were run.
- The console never installs anything itself. A root helper on PATCH-01
  (`patch01-cert-apply`, started by `patch01-cert.path`) checks the files
  again, installs them, restarts nginx, proves nginx serves exactly that
  certificate, and puts the previous one back if not. The private key is
  deleted from the hand-over folder once installed; it is never stored in
  the database. The five previous certificates are kept; **Roll back** goes
  to the one before the last change.
- `phase3b-api.sh` installs the helper. Log: `/var/log/patch01-cert.log`.
  `patch01-reip --cert` remains as the command-line way.

**r36: worker health check**
- The worker was always shown "unhealthy": it uses the API's image, whose
  built-in health check asks the API's web server, which the worker does not
  run. It now has its own check (`python -m app.health worker`): healthy when
  its main loop has reported within 3 minutes. Nothing was wrong with the
  worker itself; tools that rely on health (patch01ctl) now see it correctly.

**r35: certificate and IP change-over**
- Windows agents and the WSUS report accept **two pins** during a certificate
  change, so they keep working before and after the swap.
- `install-agent.ps1 -Repin -Pin <old>,<new>` and `push-agent.ps1 ... -Repin`
  change the pin without re-enrolling; they also bring the agent up to date
  (older agents accept only one pin), and test the new setting before keeping it. `wsus-report.ps1 -Repin` does the same for WSUS servers.
- `phase10-windows.sh --pin --cert FILE` gives a new certificate's pin before
  it is installed, with the exact re-pin commands.
- `docs/CHANGE-IP-AND-CERTIFICATE.md`: the steps, in order.

**r34: several WSUS servers**
- With more than one WSUS reporting, Windows › WSUS shows each with its own
  cards and adds a **WSUS** column to the computer list. A computer listed by
  two WSUS servers (usually reporting roll-up from a downstream WSUS) is
  marked rather than hidden. Each WSUS needs its own token:
  `phase10-windows.sh --wsus-token NAME`, once per server.

**r33: Windows patching (W3), WSUS view (W2), software inventory**
- **Patch jobs for Windows servers**, through the same change engine:
  precheck (disk, Windows Update service, running services), VM snapshot,
  install, reboot per the job's choice, postcheck (services back, no reboot
  pending), inventory. Only updates WSUS has approved can be installed: the
  agent installs from the server's own WSUS search. *All approved updates*
  installs everything WSUS approved that the server lacks; *chosen
  advisories* installs the approved updates with those KBs or that fix their
  CVEs (Windows updates are cumulative, so this month's update covers last
  month's). Installs may take up to 3 hours.
- **Software inventory:** every Windows server reports Programs and Features
  (name, version, publisher, install date, size). Each server's page lists
  it; **Windows › Software** shows every program across servers, the
  versions in use and which servers have each.
- **Windows › WSUS:** sync health, security updates not approved, and every
  computer WSUS knows with when it last reported and how many approved
  updates it still needs. Computers not reporting for 7 days, computers not
  in PATCH-01, and PATCH-01 servers unknown to WSUS are called out.
  `client/windows/wsus-report.ps1` runs on the WSUS server (read-only), every
  6 hours; `phase10-windows.sh --wsus-token NAME` makes its token (one per
  WSUS server; the same pin as the agents).
- Windows agent **1.1.0-win**; its scheduled task may now run 4 hours.
  Schema `019-windows-software-wsus.sql`.

**r32: Windows inventory accepted**
- Windows inventories were refused with "only 23 packages reported ...
  (minimum 50)": that safety check is for Linux, where fewer than 50
  packages means a broken collector. A Windows server reports its OS build
  and installed KBs, often fewer. For Windows servers (by their recorded OS)
  the check is now one well-formed OS build entry; Linux keeps its minimum.
  Because the inventory failed first, the Windows Update results were never
  sent either; both now arrive.

**r31: Windows agent fix**
- After enrolling, the Windows agent stopped with "The variable
  '$script:Cfg' cannot be retrieved because it has not been set": under
  strict mode it read its settings variable before anything had set it, so
  inventory and the scheduled runs failed. It is now declared up front.
  Update an installed agent with `install-agent.ps1 -Update`.

**r30: Windows enrolment fix**
- Windows enrolment failed with HTTP 422: the enrolment check still allowed
  only dnf, yum and apt. It now accepts wua (Windows Update).
- The Windows agent now shows PATCH-01's reason for any refusal (PowerShell
  5.1 keeps it in ErrorDetails, not in the response stream).
- Patch jobs refuse Windows servers with a clear reason until Windows
  patching (W3) exists, instead of failing on the server.

**r29: Windows token fix**
- `phase10-windows.sh --tokens` failed with "unknown host_group 'windows'":
  tokens must name an existing group, and `windows` was not one. It is now
  created the first time it is used (and by schema 018 on new installs); any
  other group that does not exist is refused with the list of those that do.

**r28: Windows servers (W1)**
- **Windows agent** (PowerShell 5.1, built in to Windows Server): enrols like
  the Linux agent, checks in every 5 minutes as SYSTEM, and every 4 hours
  reports the OS build, installed KBs, reboot state, the hardware ID that
  links it to its VM, and the updates Windows Update says are missing,
  searched against the server's WSUS. Read-only. The PATCH-01 certificate is
  pinned; the agent's token is encrypted for that machine only.
- **CVEs by build:** Microsoft's Security Update Guide is imported
  (`phase10-windows.sh --msrc`). Each cumulative update is an advisory for its
  Windows Server version, so Windows servers get verdicts, KEV and EPSS, and
  appear on the Overview, Advisories, Assess and in reports like Linux ones.
- **Windows Update** section on each Windows server's page.
- `client/windows/`: `install-agent.ps1` (with `-SelfTest`), `patch-agent.ps1`,
  and `push-agent.ps1` to install on a list of servers over WinRM.
- `phase10-windows.sh`: `--msrc`, `--pin`, `--tokens N`, `--status`.
  Proxy: allow `api.msrc.microsoft.com`. Schema `018-windows.sql`.

**r27: script reliability**
- `phase5-dashboard.sh` reported "Timed out" after r26 although the console
  was deployed: its final check looked for `src="app.js"`, which the new
  version stamp changes to `src="app.js?v=..."`. Both checks now accept it.
- Every script checked running containers with `docker ps | grep -q`. Under
  the scripts' strict error settings that can wrongly report a running
  container as stopped (grep stops reading early, and docker's unfinished
  write then fails the check). In testing it happened in 45 of 200 runs.
  25 such checks in nine scripts now read the whole output first.
- `phase5-dashboard.sh` was run end to end ten times against stand-ins: all
  succeeded.

**r26: fresh console after every update**
- `phase5-dashboard.sh` stamps each console file with its fingerprint, so
  browsers load the new version straight after an update, with no need for
  Ctrl+F5. (A browser still running an old copy explains, for example, the
  custom-profile option looking greyed out after moving to r25.)

**r25: custom profiles (H3), check boxes, cleaner report e-mail**
- **Custom profiles:** Hardening › profile list › *New or manage custom
  profiles*. Upload a .txt, .csv or .docx (your standard, an auditor's
  checklist). Each line is matched to benchmark checks, by CIS number first,
  then by wording; AI-01 can suggest a match for a line, choosing only from
  real rules. Review the matches, mark headings as "not a check", and choose
  **Use this profile**. It then appears in the profile list beside CIS L1 and
  L2; scans check only its settings, and reports list its results plus the
  requirements no scan can check as **Not checked automatically**. Editing a
  profile in use makes a new version.
- **Results by check** use drawn tick and cross boxes, with passed checks
  first and failed checks after, in both PDF and Word.
- **Report e-mail:** a white header with the logo, four figures (servers,
  checks passed, checks failed, score), three short sentences and the
  signature. Ready at once; **Polish with AI-01** rewrites it on request.
- Agent **1.6.0** is needed for custom-profile scans. Schema
  `017-custom-profiles.sql`.

**r24: management reports, report e-mails, signature**
- **Report type:** *Management summary* (no fixes: a pass/fail result for
  every check, as a grid for up to 6 servers, and each server's failed checks
  as evidence) or *Technical detail* (findings with how to fix them).
- The cover lists the servers in scope with their IP addresses; the server
  table has an IP column.
- **E-mail a report** from the console (operators and admins): a window with
  the report at a glance, a draft written by AI-01 from the report's own
  figures, To/Cc with quick picks, and the report attached. A draft that
  states any figure not in the report is discarded for a structured one; if
  AI-01 is unavailable the structured draft is used. Sent mail is recorded in
  Activity and in the mail history.
- **Signature:** one signature, set under Admin › Mail, added to every mail:
  alerts, digests and reports.
- Schema `016-signature.sql`.

**r23: schema re-run fix**
- Re-running `phase3a-schema.sh` stopped at 011 with "cannot change name of
  view column": the `v_hardening_latest` view was built on `s.*`, which
  PostgreSQL fixes at creation, and schema 012 added columns to the table
  underneath. The view now lists its columns and is recreated each run.
  012 to 015 had not been applied; nothing was lost. Builds now also refuse
  any view defined with `*`.

**r22: branded reports (H4)**
- **Export report** on the Hardening page: PDF or Word, for all servers, a
  host group, or the servers below 85%, with the findings in detail you
  choose. Both formats have a cover, contents, executive summary, results by
  server, findings with how to fix them, evidence, and method; every page
  carries the logo, title and classification in the header, and the
  copyright line and "Page X of Y" in the footer.
- Every report is kept in an archive with its SHA-256, and generating or
  downloading one is recorded in Activity. Viewers can export reports too.
- **Logo:** drop a PNG in `/patch/data/branding` on PATCH-01. PATCH-01 picks
  `logo.png`, or the largest PNG there; trims the margins; scales it for
  print; checks whether it is light or dark (a dark logo sits on a white
  plate on the navy cover); and takes the accent colour from it.
  `logo-white.png`, if present, is used on dark backgrounds.
- **Admin › Branding:** company name, copyright line, classification, and an
  optional accent colour, with a preview of the processed logo.
- Users, Mail and Branding are now tabs under one **Admin** menu item.
- Mail uses the same company name and, where it suits the navy header, logo.
- The image now includes reportlab, python-docx and Pillow (installed through
  the proxy at build time) and bundles its fonts. Schema `015-branding-reports.sql`.

**r21: mail set up in the console**
- The admin **Mail** page now holds everything: relay, port, encryption,
  mailbox login and password, the relay's CA certificate (pasted in), From
  address and name, what to send, and when.
- **Test connection** walks through name lookup, connection, TLS (showing
  the certificate), login and sender acceptance, using the values in the
  form before they are saved. It sends nothing.
- **Recipients** per kind of mail (critical, tasks, daily digest, weekly),
  each with its own test button. Every change is in Activity.
- The password is write-only in the console and stored encrypted, with a key
  kept only in `/patch/secrets/mail.key` (made by `phase3b-api.sh`). Keep that
  file in backups with the other secrets.
- `phase9-mail.sh` now only checks from the command line (`--status`,
  `--check`, `--test`, `--on`/`--off`). Schema `014-mail-settings.sql`.

**r20: mail alerts**
- Critical alerts within a minute: an exploited CVE newly affecting a server,
  an ESXi host not connected, a vCenter unreachable, a datastore 90% full, a
  change that failed or partly succeeded, hardening drift on a high-severity
  rule, and the worker stopping (checked from the host every 5 minutes).
- Task mails when changes start and finish and when requested scans complete.
- Daily digest at 07:00 SGT and a weekly summary on Mondays.
- Mail is queued and retried (1, 5, 15, 60, 240 minutes), so a relay outage
  delays it rather than losing it. Each alert is sent once; a condition that
  clears and returns alerts again. Several at once arrive as one mail.
- Turning mail on records what is already known without mailing it.
- `phase9-mail.sh`; admin page **Mail**; schema `013-notifications.sql`.

**r19: live scan progress (H1)**
- The Hardening page shows where each scan is, refreshing every 5 seconds:
  waiting for the agent's check-in, downloading the benchmark, scanning with
  rules done out of total, uploading, processing. A scan not picked up after
  two check-ins is flagged with the command to check the agent's timer.
- Agent **1.5.0** reports progress, and stops a hung scan together with any
  helper processes it started. Agents on 1.4.0 still scan; they just show
  "scanning" without figures.
- Schema `012-scan-progress.sql`.

**r18: hardening import, second fix**
- The import stopped with "No module named 'lxml'": the benchmark parser used
  a library that is not in the API image. It now uses Python's built-in XML
  parser, so nothing extra is installed. Tested in a Python without that
  library, and against hostile XML (entity expansion, local file entities),
  which is refused. Needs `phase3b-api.sh` to rebuild the image.

**r17: hardening import fix**
- `phase8-hardening.sh` stopped with "$2: unbound variable" just before
  importing, on both `--fetch` and `--import-zip`, so no content ever reached
  the database. The import step now runs; the script was also run end to
  end, not only syntax-checked.

**r16: two script fixes**
- `phase3b-api.sh --check` reported "worker running but not reporting" on a
  healthy worker. It judged the oldest heartbeat of all the worker's threads
  against two minutes, and the hardening schedule reports hourly by design.
  Each thread is now judged against its own interval.
- `phase8-hardening.sh --import-zip` stopped with "are the same file" when
  given the copy already kept in `/patch/data/hardening/releases`. The copy
  is now skipped in that case.

**r15: hardening, increment 1 (scan and see)**
- **Hardening** page: fleet score and trend, the most widely failing rules,
  per-server scores, and per-rule and per-server detail with what each check
  does and why it matters. Profile dropdown: CIS Level 1 Server, CIS Level 2
  Server (Custom arrives in increment 3).
- `phase8-hardening.sh`: downloads one pinned SCAP Security Guide release
  through the proxy, verifies its SHA-512, and imports the data streams for
  RHEL 8/9/10, Oracle Linux 7/8/9 and Ubuntu 20.04/22.04/24.04.
- Agent 1.4.0 scans with OpenSCAP (read-only, low priority) and uploads the
  full result, kept on PATCH-01 as audit evidence with its SHA-256.
- Weekly CIS Level 1 scan per server by the worker (`HARDENING_SCAN_DAYS`,
  0 turns it off), spread across the day.
- Schema `011-hardening.sql`.

**r14: live VMware map and blast radius**
- **Live map** is now the first VMware tab: networks, clusters, ESXi hosts,
  VMs and datastores on one canvas, graded neon red, amber, green or grey,
  with the legend below. Infrastructure and Applications layouts.
- **Blast radius**: click a host, datastore or port group to see what it
  takes down. For a host, whether HA can restart each VM: HA on, disks not
  on local storage, enough spare memory on the surviving hosts.
- **Live**: the worker follows each vCenter's change stream and events
  (vMotions, HA restarts, host failures, alarms); the map updates within 5
  seconds and the side panel shows a live feed.
- Application groups from vSphere tags (categories named Application, App,
  Service, Workload or System; override with `VMWARE_APP_CATEGORIES`), else
  from the VM folder.
- **Coverage** tab: Distributed vs standard switching, tagged vs ungrouped.
- Schema `010-vmware-live.sql`. Read-only vCenter account throughout;
  nothing is collected from inside a VM.

**r13: schema re-run fix**
- Re-running `phase3a-schema.sh` stopped at 007 with "cannot drop columns
  from view", so 009 (users and changes) was never applied. 007 still defined
  `v_vm_map` with its original, narrower column list, and on a re-run tried to
  replace the wider view 008 had created. The view is now defined in 008 only.
- Nothing was lost: each migration is its own transaction, and 007 rolled
  back cleanly. Re-run `phase3a-schema.sh`.

**r12: users and roles, changes, patch jobs, VMware actions, CVE assessment**
- Individual sign-in with viewer, operator and admin roles, enforced by the
  API; forced password change on first sign-in; lockout after five failures.
  BOT-MODE (formerly Hacker) is admin only.
- Change engine: every patch job and VMware action has a number, reason,
  window and a tamper-proof timeline. Approval optional
  (`REQUIRE_APPROVAL`), off by default.
- Background worker container: runs changes on schedule, recomputes verdicts
  after patching, and enriches assessments.
- Patch jobs with preview, per-job reboot choice, optional VM snapshot and a
  service check. Agent 1.3.0.
- VMware snapshots, revert (with typed confirmation and a safety snapshot),
  power on, guest shutdown and restart, using a separate write account.
- Assess looks up every CVE in NVD, classifies what it affects, checks ESXi,
  vCenter and VM guests as well as packages, adds an AI brief, and exports it
  all to CSV.
- Schema `009-users-changes.sql`.

**Advisory to CVE mapping fix**
- CVEs are linked to advisories through each advisory's reference list. Only
  one of the two field namings Pulp uses was handled, so on some versions no
  CVEs were recorded at all and every advisory appeared to have none.
- Both namings are now accepted, with fallbacks for a CVE that appears only
  in a reference link, is filed under another reference type, or is named in
  the advisory text. The import warns if an advisory set yields no CVEs.
- `./scripts/phase4-cve.sh --diagnose` prints the counts and one advisory
  exactly as your Pulp returns it, so the field names can be confirmed.
- To apply: `./scripts/phase4-cve.sh --import` then `--intel`.

**Fix: VMware page returned HTTP 500**
- The map endpoint asked `v_vm_map` for `esxi_moref`, which groups VMs under
  their ESXi host, but the view did not expose it. Schema
  `008-fix-vm-map.sql` recreates the view with that column and the remaining
  per-VM detail.
- Apply with `./scripts/phase3a-schema.sh`; no re-sync needed, since the data
  was already collected.

**VMware infrastructure map**
- Map tab: vCenter, datacenter, cluster, ESXi host and VM as an expandable
  tree, each VM coloured by patch and agent state.
- ESXi hosts, datastores, networks and clusters, with hardware, versions,
  state and load. Over-provisioned datastores and unresponsive hosts flagged.
- Per VM: ESXi host, folder, datastores, networks, disks, hardware version,
  Tools version, boot time and storage.
- Schema `007-vmware-infra.sql`. Needs a re-sync to populate:
  `./scripts/phase7-vmware.sh --sync`.

**Fixes**
- Agents page returned HTTP 500: its query selected `host_id` and
  `host_status` from the `hosts` table, where those columns are `id` and
  `status`. It now reads the `v_agents` view.
- Chat returned HTTP 500 on filtered questions such as "which rhel servers
  need patches": an untyped NULL filter makes PostgreSQL refuse the query
  ("could not determine data type of parameter"). Every placeholder now
  carries an explicit type.
- `phase4-cve.sh --diagnose` also reports verdict counts and table sizes, so
  an empty dashboard can be traced to a missing sync, import or compute.

**Assess a CVE list, and admin chat**
- New Assess page: paste or upload a CVE list from a SOC or auditor and get a
  per-CVE verdict across the fleet, saved and exportable as CSV.
- New chat, read-only, behind the icon at the bottom right. The model picks
  which prepared query to run; the database supplies every figure and the rows
  are always shown.
- Schema `006-assessments.sql`; `python-multipart` added to the API image.

**CVE intelligence**
- NVD, CISA KEV, FIRST EPSS and Red Hat data per CVE, with the attack type
  derived from the weakness and the CVSS vector.
- The console shows CVSS, an "Exploited" marker, how the flaw is reached, the
  exploitation probability and the CVE description, with sources.
- AI explanations now use these facts instead of an advisory title, which was
  why every CVE produced a similar answer.
- `phase4-cve.sh --intel`, `--set-nvd-key`, `--estimate`; schema
  `005-cve-intel.sql`; nightly timer now refreshes CVE data too.

**VMware, part 1: inventory**
- New VMware page: each vCenter's status, Linux VMs without an agent, VM
  snapshots and their age, and ambiguous links.
- Each server page shows its VM, cluster, ESXi host, size and snapshots.
- Agent 1.2.0 reports the hardware ID used to link servers to VMs.
- `phase7-vmware.sh`, schema `004-vmware.sql`, and pyVmomi 8.0.3.0.1 in the
  API image. Several vCenters are supported and one failing does not stop
  the others.

**Step 7: agent status**
- New Agents page: online, offline, not reporting, uptime, boot time, agent
  version and address for every server.
- Agent 1.1.0 reports boot time. Compatible both ways with older versions.
- "Hosts" is now "Servers". The Servers list has an Agent column, and each
  server page shows uptime.
- Schema `003-agent-status.sql`.

To apply on an existing PATCH-01:

```bash
./scripts/phase3a-schema.sh      # adds schema 003
./scripts/phase3b-api.sh         # API with boot time and the agents endpoint
./scripts/phase5-dashboard.sh    # Agents page
```

then update agents as above.


## Back these up, off both servers

These cannot be recreated. Losing them loses the data they protect.

| File | Why |
|------|-----|
| `/patch/secrets/postgres.env` | Database passwords. Pulp's 600 GB of packages are unnamed files without the database that maps them. |
| `/patch/config/pulp/certs/database_fields.symmetric.key` | Encrypts sensitive database fields. Without it they are unreadable. |
| `/patch/secrets/pulp-admin.txt` | Pulp admin password. |
| `/patch/secrets/api.env` | Console admin password and the AI-01 key. |
| `/etc/patch-platform/images.env` | Exact image digests this build was made from. |
| `/llm/config/api-key` on AI-01 | The key PATCH-01 uses. |
| `/patch/secrets/vcenter/` | vCenter accounts and pinned certificates. |


## Lessons already built into the scripts

Problems met during the first build, each now detected or prevented by the
script that caused it:

- A config value containing a space broke when the file was sourced. All
  generated values are quoted and the file is test-sourced before use.
- Containers running as non-root users could not read certificates, init
  scripts or keys in `0700` directories. Scripts now set the group to match
  each image's own user and prove access from inside a throwaway container
  before starting the real one.
- `lvcreate` waited forever on a hidden prompt. Commands now run with no
  input, so anything that prompts fails at once with a visible error.
- Pulp would not start without a database encryption key. It is generated,
  validated and mounted before migrations run.
- A build under a hardened `umask 077` left llama-server runnable by root
  only. The AI-01 script fixes permissions and runs the binary as the
  service user before starting the service.
- Pulp rejects keeping old package versions with a "mirror" sync. Syncs are
  additive, which also preserves the ability to downgrade.


## Not built yet

- **Reports** with your logo, exported to PDF.
- **Hardening dashboard** using OpenSCAP with CIS-aligned profiles.
- **Windows Server**: WSUS reporting, CVE assessment by build number, then a
  PowerShell agent and hardening.
- **Oracle Linux and Ubuntu advisories.** Verdicts currently come from Red Hat
  advisories synced into Pulp. Oracle's public repositories often omit errata
  data, so Oracle servers need the Oracle OVAL feed; Ubuntu needs the USN feed.
  Until then those servers show no advisories, and the engine's log says so.
- **RHEL 8 modular packages** are skipped and counted rather than compared, to
  avoid false results across module streams.
- **CA-signed certificates and agent mTLS.** PATCH-01 and AI-01 still use
  self-signed placeholders. Replace PATCH-01's before enrolling the full fleet,
  since agents trust the certificate present when they enroll.
- **Single sign-on** (Active Directory or SAML) in place of local accounts.
- **Hardening fixes through the change engine**, once the OpenSCAP dashboard
  exists.
- **Trend Micro.** Apex One protects Windows and macOS, so it adds little to a
  Linux platform. Worth integrating only if the Linux servers appear in Apex
  Central, or if Trend's server product (Server & Workload Protection) is in use.
- **Read-only MCP query layer.** (Step 12.)
