<#
.SYNOPSIS
  PATCH-01 agent for Windows Server (PowerShell 5.1, built in to Windows Server 2016 and later).

.DESCRIPTION
  Runs every 5 minutes as SYSTEM from a scheduled task. Each run checks in and
  picks up commands. Every 4 hours, or when PATCH-01 asks, it also reports:
    - the OS build (10.0.17763.6414), which PATCH-01 compares with Microsoft's
      Security Update Guide to know which CVEs are still open;
    - installed updates (KBs);
    - updates Windows Update says are missing, searched against the server's
      own WSUS, so they reflect your approvals;
    - whether a reboot is pending, uptime, and the hardware ID that links the
      server to its VM in vCenter.

  Read-only in this version: it installs nothing and changes no settings.

  patch-agent.ps1 -SelfTest -Server https://SGPINFAPPXU01 -Pin <sha256>
      checks every step and reports ok or failed; enrols nothing
  patch-agent.ps1 -Enroll -Server <url> -Token <token> -Pin <sha256>
  patch-agent.ps1 -Run            (what the scheduled task runs)
  patch-agent.ps1 -Inventory      (report now)
#>
[CmdletBinding(DefaultParameterSetName = "Run")]
param(
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)][switch]$Enroll,
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][switch]$SelfTest,
    [Parameter(ParameterSetName = "Run")][switch]$Run,
    [Parameter(ParameterSetName = "Inventory", Mandatory = $true)][switch]$Inventory,
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)]
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][string]$Server,
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)][string]$Token,
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)]
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][string]$Pin
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$AgentVersion = "1.0.0-win"
$DataDir = Join-Path $env:ProgramData "PatchAgent"
$ConfigFile = Join-Path $DataDir "agent.json"
$TokenFile = Join-Path $DataDir "token.bin"
$StateFile = Join-Path $DataDir "state.json"
$LogFile = Join-Path $DataDir "agent.log"
$InventoryEveryHours = 4
$SearchTimeoutSec = 1800
# Script-wide state, declared up front: strict mode refuses to read a variable
# that has never been set, and Get-Config checks this before anything sets it
$script:Cfg = $null

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
function Write-Log([string]$Message) {
    $line = "{0} {1}" -f (Get-Date).ToString("yyyy-MM-dd HH:mm:ss"), $Message
    if (Test-Path $DataDir) {
        if ((Test-Path $LogFile) -and ((Get-Item $LogFile).Length -gt 1MB)) {
            Move-Item -Force $LogFile ($LogFile + ".1")
        }
        Add-Content -Path $LogFile -Value $line -Encoding UTF8
    }
    Write-Verbose $line
}

# ---------------------------------------------------------------------------
# TLS: PATCH-01's certificate is pinned by its SHA-256 fingerprint. Compiled
# once, because a PowerShell script block used as a certificate callback can
# be called on a thread with no PowerShell runspace and fail.
# ---------------------------------------------------------------------------
if (-not ("PatchAgentPin" -as [type])) {
    Add-Type -TypeDefinition @"
using System;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
public static class PatchAgentPin {
    public static string Pin = "";
    public static string Seen = "";
    public static bool Check(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors errors) {
        if (cert == null) { return false; }
        using (SHA256 sha = SHA256.Create()) {
            Seen = BitConverter.ToString(sha.ComputeHash(cert.GetRawCertData())).Replace("-", "").ToLowerInvariant();
        }
        if (Pin == "system") { return errors == SslPolicyErrors.None; }
        return Seen == Pin;
    }
    public static void Use(string pin) {
        Pin = pin.Trim().ToLowerInvariant().Replace(":", "").Replace(" ", "");
        ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(Check);
    }
}
"@
}

function Initialize-Http([string]$PinValue) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [PatchAgentPin]::Use($PinValue)
    # PATCH-01 is internal: never send it through a proxy configured for the internet
    [Net.WebRequest]::DefaultWebProxy = $null
}

function Invoke-Api([string]$Method, [string]$Path, $Body = $null, [string]$Bearer = $null, [int]$Timeout = 60) {
    $cfg = Get-Config
    $uri = $cfg.server.TrimEnd("/") + $Path
    $headers = @{ "User-Agent" = "patch-agent/$AgentVersion" }
    if ($Bearer) { $headers["Authorization"] = "Bearer " + $Bearer }
    $params = @{ Method = $Method; Uri = $uri; Headers = $headers; TimeoutSec = $Timeout; UseBasicParsing = $true }
    if ($null -ne $Body) {
        # -InputObject, not a pipe: piping unwraps one-element arrays in PowerShell 5.1
        $params["Body"] = [Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $Body -Depth 8 -Compress))
        $params["ContentType"] = "application/json; charset=utf-8"
    }
    try {
        return Invoke-RestMethod @params
    } catch {
        $detail = $_.Exception.Message
        # In PowerShell 5.1 Invoke-RestMethod has already read the error body:
        # it is in ErrorDetails, and the response stream is empty by now
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
            $code = ""
            if ($_.Exception.PSObject.Properties["Response"] -and $_.Exception.Response) { $code = "HTTP " + [int]$_.Exception.Response.StatusCode + ": " }
            $detail = $code + $_.ErrorDetails.Message
        }
        # Only web errors carry a response; asking others for one fails under strict mode
        elseif ($_.Exception.PSObject.Properties["Response"] -and $_.Exception.Response) {
            try {
                $sr = New-Object IO.StreamReader($_.Exception.Response.GetResponseStream())
                $detail = "HTTP " + [int]$_.Exception.Response.StatusCode + ": " + $sr.ReadToEnd()
            } catch { }
        }
        if ([PatchAgentPin]::Seen -and [PatchAgentPin]::Pin -ne "system" -and [PatchAgentPin]::Seen -ne [PatchAgentPin]::Pin) {
            $detail = "PATCH-01's certificate does not match the pin. It presented " + [PatchAgentPin]::Seen
        }
        throw "$Method $Path failed: $detail"
    }
}

function Get-IsoUtc([datetime]$When = (Get-Date)) {
    # Whole seconds: "o" writes seven decimal places, more than the API accepts
    return $When.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ", [Globalization.CultureInfo]::InvariantCulture)
}

# ---------------------------------------------------------------------------
# Configuration and the agent's token, encrypted for this machine only
# ---------------------------------------------------------------------------
function Get-Config {
    if ($script:Cfg) { return $script:Cfg }
    if (-not (Test-Path $ConfigFile)) { throw "Not enrolled: run install-agent.ps1 first." }
    $script:Cfg = Get-Content -Raw $ConfigFile | ConvertFrom-Json
    return $script:Cfg
}

function Save-Token([string]$Value) {
    Add-Type -AssemblyName System.Security
    $bytes = [Text.Encoding]::UTF8.GetBytes($Value)
    $enc = [Security.Cryptography.ProtectedData]::Protect($bytes, $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
    [IO.File]::WriteAllBytes($TokenFile, $enc)
}

function Get-Token {
    Add-Type -AssemblyName System.Security
    if (-not (Test-Path $TokenFile)) { throw "No agent token: enrol first." }
    $enc = [IO.File]::ReadAllBytes($TokenFile)
    $bytes = [Security.Cryptography.ProtectedData]::Unprotect($enc, $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
    return [Text.Encoding]::UTF8.GetString($bytes)
}

function Get-State {
    if (Test-Path $StateFile) { try { return Get-Content -Raw $StateFile | ConvertFrom-Json } catch { } }
    return [pscustomobject]@{ last_inventory = $null }
}

function Save-State($State) { ConvertTo-Json -InputObject $State | Set-Content -Path $StateFile -Encoding UTF8 }

# ---------------------------------------------------------------------------
# Facts about this server
# ---------------------------------------------------------------------------
function Get-Build {
    $cv = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion"
    $major = 10; $minor = 0
    if ($cv.PSObject.Properties["CurrentMajorVersionNumber"]) { $major = $cv.CurrentMajorVersionNumber }
    if ($cv.PSObject.Properties["CurrentMinorVersionNumber"]) { $minor = $cv.CurrentMinorVersionNumber }
    $ubr = 0
    if ($cv.PSObject.Properties["UBR"]) { $ubr = $cv.UBR }
    return [pscustomobject]@{
        Build   = "{0}.{1}.{2}.{3}" -f $major, $minor, $cv.CurrentBuildNumber, $ubr
        Number  = [int]$cv.CurrentBuildNumber
        Product = $cv.ProductName
    }
}

function Get-ServerVersion($BuildInfo) {
    # The Windows Server release, from the build number; the product name as a fallback
    switch ($BuildInfo.Number) {
        14393 { return "2016" } 17763 { return "2019" } 20348 { return "2022" } 26100 { return "2025" }
    }
    if ($BuildInfo.Product -match "(20\d\d)") { return $Matches[1] }
    return [string]$BuildInfo.Number
}

function Get-RebootState {
    $reasons = @()
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending") { $reasons += "component servicing" }
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") { $reasons += "Windows Update" }
    try { if ((New-Object -ComObject Microsoft.Update.SystemInfo).RebootRequired) { if ($reasons -notcontains "Windows Update") { $reasons += "Windows Update" } } } catch { }
    return [pscustomobject]@{ Required = ($reasons.Count -gt 0); Reason = ($reasons -join ", ") }
}

function Get-Facts {
    $os = Get-CimInstance Win32_OperatingSystem
    $cs = Get-CimInstance Win32_ComputerSystemProduct
    $b = Get-Build
    $uuid = $null
    if ($cs.UUID -and $cs.UUID -match "^[0-9A-Fa-f-]{32,36}$" -and $cs.UUID -notmatch "^[0F-]+$") { $uuid = $cs.UUID.ToLowerInvariant() }
    return [pscustomobject]@{
        Hostname = $env:COMPUTERNAME.ToLowerInvariant()
        Fqdn     = ([Net.Dns]::GetHostEntry($env:COMPUTERNAME).HostName).ToLowerInvariant()
        Build    = $b.Build
        Version  = Get-ServerVersion $b
        Edition  = $b.Product
        Boot     = Get-IsoUtc $os.LastBootUpTime
        Uuid     = $uuid
        MachineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
    }
}

function Get-WsusSource {
    $wu = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
    $server = $null; $use = 0
    if (Test-Path $wu) {
        $p = Get-ItemProperty $wu
        if ($p.PSObject.Properties["WUServer"]) { $server = $p.WUServer }
        if (Test-Path "$wu\AU") {
            $au = Get-ItemProperty "$wu\AU"
            if ($au.PSObject.Properties["UseWUServer"]) { $use = $au.UseWUServer }
        }
    }
    if ($server -and $use -eq 1) { return [pscustomobject]@{ Source = "wsus"; Server = $server } }
    return [pscustomobject]@{ Source = "microsoft"; Server = $null }
}

function Search-MissingUpdates {
    <# Asks Windows Update what is not installed. Against WSUS this returns
       what WSUS has approved for this computer. Run as a job so a search that
       hangs is abandoned instead of blocking every later run. #>
    $job = Start-Job -ScriptBlock {
        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = "PATCH-01"
        $searcher = $session.CreateUpdateSearcher()
        $result = $searcher.Search("IsInstalled=0 and IsHidden=0 and Type='Software'")
        $out = @()
        foreach ($u in $result.Updates) {
            $kb = $null
            if ($u.KBArticleIDs.Count -gt 0) { $kb = "KB" + $u.KBArticleIDs.Item(0) }
            $cats = @(); foreach ($c in $u.Categories) { $cats += [string]$c.Name }
            $cves = @(); foreach ($c in $u.CveIDs) { $cves += [string]$c }
            $out += [pscustomobject]@{
                update_id = [string]$u.Identity.UpdateID
                kb = $kb
                title = [string]$u.Title
                severity = [string]$u.MsrcSeverity
                categories = $cats
                cves = $cves
                downloaded = [bool]$u.IsDownloaded
                reboot_behaviour = @("never", "always", "may")[[int]$u.InstallationBehavior.RebootBehavior]
                size_mb = [int]([double]$u.MaxDownloadSize / 1MB)
            }
        }
        return ,$out
    }
    if (-not (Wait-Job $job -Timeout $SearchTimeoutSec)) {
        Stop-Job $job; Remove-Job $job -Force
        throw "Windows Update search did not finish within $([int]($SearchTimeoutSec / 60)) minutes"
    }
    $data = Receive-Job $job -ErrorAction Stop
    Remove-Job $job -Force
    # Results come back deserialised: an empty list can arrive as $null, and
    # extra job properties ride along. Rebuild each update with exactly the
    # fields PATCH-01 expects.
    $clean = @()
    foreach ($u in @($data)) {
        if ($null -eq $u -or -not $u.PSObject.Properties["update_id"]) { continue }
        $sev = $null; if ($u.severity) { $sev = [string]$u.severity }
        $clean += @{
            update_id = [string]$u.update_id; kb = $u.kb; title = [string]$u.title; severity = $sev
            categories = @(@($u.categories) | Where-Object { $_ } | ForEach-Object { [string]$_ })
            cves = @(@($u.cves) | Where-Object { $_ } | ForEach-Object { [string]$_ })
            downloaded = [bool]$u.downloaded; reboot_behaviour = [string]$u.reboot_behaviour; size_mb = [int]$u.size_mb
        }
    }
    return ,$clean
}

# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------
function Send-Checkin($Token) {
    $f = Get-Facts
    $r = Get-RebootState
    $body = @{ agent_version = $AgentVersion; kernel_running = $f.Build; reboot_required = $r.Required; boot_time = $f.Boot }
    if ($f.Uuid) { $body["hardware_uuid"] = $f.Uuid }
    Invoke-Api "POST" "/api/v1/agent/checkin" $body $Token | Out-Null
}

function Send-Inventory($Token) {
    $t0 = Get-Date
    $f = Get-Facts
    $r = Get-RebootState
    $packages = @(@{ name = "windows-os-build"; version = ($f.Build + "-0"); arch = "noarch" })
    foreach ($h in (Get-HotFix -ErrorAction SilentlyContinue)) {
        if ($h.HotFixID -match "^KB\d+$") {
            $packages += @{ name = $h.HotFixID.ToLowerInvariant(); version = "1-0"; arch = "noarch"; from_repo = [string]$h.Description }
        }
    }
    $body = @{
        collected_at = (Get-IsoUtc); kernel_running = $f.Build
        reboot_required = $r.Required; reboot_reason = $r.Reason; os_version = $f.Version
        agent_version = $AgentVersion; boot_time = $f.Boot; packages = $packages
        duration_ms = [int]((Get-Date) - $t0).TotalMilliseconds
    }
    if ($f.Uuid) { $body["hardware_uuid"] = $f.Uuid }
    Invoke-Api "POST" "/api/v1/agent/inventory" $body $Token -Timeout 120 | Out-Null
    Write-Log ("inventory sent: build {0}, {1} updates installed" -f $f.Build, ($packages.Count - 1))

    $src = Get-WsusSource
    $report = @{ searched_at = (Get-IsoUtc); source = $src.Source; server = $src.Server
                 os_edition = $f.Edition; updates = @() }
    try {
        $report["updates"] = Search-MissingUpdates
        Write-Log ("Windows Update ({0}): {1} missing" -f $src.Source, $report["updates"].Count)
    } catch {
        $report["error"] = [string]$_.Exception.Message
        Write-Log ("Windows Update search failed: " + $report["error"])
    }
    Invoke-Api "POST" "/api/v1/agent/windows/updates" $report $Token -Timeout 120 | Out-Null
}

function Invoke-Commands($Token) {
    $cmds = @(Invoke-Api "GET" "/api/v1/agent/commands" $null $Token)
    $ranInventory = $false
    foreach ($c in $cmds) {
        if ($null -eq $c -or -not $c.PSObject.Properties["id"]) { continue }
        $ok = $true; $msg = $null; $res = @{}
        try {
            switch ($c.verb) {
                "collect_inventory" { Send-Inventory $Token; $ranInventory = $true; $msg = "inventory sent" }
                default { $ok = $false; $msg = "'" + $c.verb + "' is not supported by the Windows agent yet" }
            }
        } catch { $ok = $false; $msg = [string]$_.Exception.Message }
        Invoke-Api "POST" ("/api/v1/agent/commands/" + $c.id + "/result") @{ ok = $ok; message = $msg; result = $res } $Token | Out-Null
        Write-Log ("command {0} {1}: {2}" -f $c.verb, $(if ($ok) { "ok" } else { "failed" }), $msg)
    }
    return $ranInventory
}

# ---------------------------------------------------------------------------
# Modes
# ---------------------------------------------------------------------------
function Start-Run {
    # One run at a time: a slow Windows Update search must not overlap the next
    $mutex = New-Object Threading.Mutex($false, "Global\PatchAgentRun")
    if (-not $mutex.WaitOne(0)) { Write-Log "previous run still busy; skipping"; return }
    try {
        $cfg = Get-Config
        Initialize-Http $cfg.pin
        $tok = Get-Token
        Send-Checkin $tok
        $done = Invoke-Commands $tok
        $state = Get-State
        if (-not $state.PSObject.Properties["last_inventory"]) { $state | Add-Member -NotePropertyName last_inventory -NotePropertyValue $null }
        $due = $true
        if ($state.last_inventory) {
            $due = ((Get-Date) - [datetime]$state.last_inventory).TotalHours -ge $InventoryEveryHours
        }
        if ($Inventory -or ($due -and -not $done)) { Send-Inventory $tok; $done = $true }
        if ($done) { $state.last_inventory = (Get-Date).ToString("o"); Save-State $state }
    } catch {
        Write-Log ("run failed: " + $_.Exception.Message)
        throw
    } finally {
        $mutex.ReleaseMutex(); $mutex.Dispose()
    }
}

function Start-Enroll {
    if (-not (Test-Path $DataDir)) { New-Item -ItemType Directory -Path $DataDir | Out-Null }
    $script:Cfg = [pscustomobject]@{ server = $Server.TrimEnd("/"); pin = $Pin.Trim().ToLowerInvariant() }
    Initialize-Http $script:Cfg.pin
    $f = Get-Facts
    $body = @{ enrollment_token = $Token; machine_id = $f.MachineId; hostname = $f.Hostname; os_id = "windows"
               os_version = $f.Version; arch = "x86_64"; pkg_manager = "wua"; agent_version = $AgentVersion }
    if ($f.Fqdn -and $f.Fqdn -ne $f.Hostname) { $body["fqdn"] = $f.Fqdn }
    $resp = Invoke-Api "POST" "/api/v1/agent/enroll" $body
    ConvertTo-Json -InputObject @{ server = $script:Cfg.server; pin = $script:Cfg.pin; host_id = $resp.host_id } | Set-Content -Path $ConfigFile -Encoding UTF8
    Save-Token $resp.agent_token
    Write-Log ("enrolled as {0} ({1})" -f $f.Hostname, $resp.host_id)
    Write-Output ("Enrolled {0} with PATCH-01. Host id {1}." -f $f.Hostname, $resp.host_id)
}

function Start-SelfTest {
    $results = New-Object Collections.ArrayList
    function Step([string]$Name, [scriptblock]$Do) {
        try { $d = & $Do; [void]$results.Add([pscustomobject]@{ Step = $Name; Result = "ok"; Detail = [string]$d }) }
        catch { [void]$results.Add([pscustomobject]@{ Step = $Name; Result = "FAILED"; Detail = $_.Exception.Message }) }
    }
    $script:Cfg = [pscustomobject]@{ server = $Server.TrimEnd("/"); pin = $Pin.Trim().ToLowerInvariant() }
    Step "Run as administrator" { $id = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
                                  if (-not $id.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw "run PowerShell as administrator" }; "yes" }
    Step "PowerShell version" { if ($PSVersionTable.PSVersion.Major -lt 5) { throw ("5.1 needed, found " + $PSVersionTable.PSVersion) }; [string]$PSVersionTable.PSVersion }
    Step "Reach PATCH-01, certificate pin" { Initialize-Http $script:Cfg.pin; $h = Invoke-Api "GET" "/api/v1/health"; "reached; certificate " + [PatchAgentPin]::Seen.Substring(0, 16) + "... matches" }
    Step "OS build" { $b = Get-Build; "{0} ({1}), Windows Server {2}" -f $b.Build, $b.Product, (Get-ServerVersion $b) }
    Step "Reboot state" { $r = Get-RebootState; if ($r.Required) { "reboot pending: " + $r.Reason } else { "no reboot pending" } }
    Step "Hardware ID (links the VM)" { $f = Get-Facts; if ($f.Uuid) { $f.Uuid } else { throw "no usable UUID from Win32_ComputerSystemProduct" } }
    Step "Installed updates" { "{0} KBs" -f @(Get-HotFix -ErrorAction SilentlyContinue).Count }
    Step "Update source" { $s = Get-WsusSource; if ($s.Source -eq "wsus") { "WSUS at " + $s.Server } else { "Microsoft Update directly (no WSUS policy found)" } }
    Step "Windows Update search" { $u = Search-MissingUpdates; "{0} updates missing" -f $u.Count }
    $results | Format-Table -AutoSize -Wrap | Out-String -Width 200 | Write-Output
    $failed = @($results | Where-Object { $_.Result -ne "ok" }).Count
    if ($failed) { Write-Output "$failed step(s) failed: fix them before enrolling." } else { Write-Output "All steps passed: this server is ready to enrol." }
}

switch ($PSCmdlet.ParameterSetName) {
    "SelfTest"  { Start-SelfTest }
    "Enroll"    { Start-Enroll }
    "Inventory" { Start-Run }
    default     { Start-Run }
}
