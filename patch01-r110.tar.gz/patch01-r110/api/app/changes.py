"""
PATCH-01 : the change engine

Every action that alters a server or a VM is a change. This module turns a
request into a validated, recorded change; app.worker carries it out.

Validation happens here, before anything is scheduled, so a mistake is
refused while the operator is still looking at the form rather than
discovered at 2am in a maintenance window.

Kinds
  patch                 install outstanding security fixes on servers
  vm_snapshot_create    take a snapshot of VMs
  vm_snapshot_remove    delete one snapshot
  vm_snapshot_cleanup   delete snapshots chosen by name and/or age, across
                        many VMs (snapshot_cleanup.py: search, checks, plan)
  vm_snapshot_revert    return a VM to a snapshot (a safety snapshot of the
                        current state is taken first, so a revert is undoable)
  vm_power_on
  vm_guest_shutdown     a clean OS shutdown through VMware Tools, never a
                        hard power-off
  vm_guest_restart      a clean OS restart through VMware Tools
  agent_update          move servers' agents to a version published on PATCH-01
  restart               restart chosen servers and nothing else (admins only):
                        pre-check, restart, wait for boot, post-check, inventory

Approval is off by default. If REQUIRE_APPROVAL is set, every change waits
for someone other than the requester to approve it.
"""

import json
import os
import re
from datetime import datetime, timedelta, timezone

REQUIRE_APPROVAL = os.environ.get("REQUIRE_APPROVAL", "false").lower() in ("1", "true", "yes")
# Deployment packages go out as soon as they are scheduled (the operator who deploys has
# reviewed them); set DEPLOY_REQUIRE_APPROVAL=true to need a second person
DEPLOY_REQUIRE_APPROVAL = os.environ.get("DEPLOY_REQUIRE_APPROVAL", "false").lower() in ("1", "true", "yes")
# Agent updates are made by an admin and go out when scheduled; AGENT_UPDATE_REQUIRE_APPROVAL=true
# needs a second admin to approve each one
AGENT_UPDATE_REQUIRE_APPROVAL = os.environ.get("AGENT_UPDATE_REQUIRE_APPROVAL", "false").lower() in ("1", "true", "yes")
# Removing snapshots in bulk goes out when scheduled (the operator saw the list and typed
# its count); SNAPSHOT_CLEANUP_REQUIRE_APPROVAL=true needs a second person to approve each one
SNAPSHOT_CLEANUP_REQUIRE_APPROVAL = os.environ.get("SNAPSHOT_CLEANUP_REQUIRE_APPROVAL", "false").lower() in ("1", "true", "yes")

KINDS = {
    "patch":              {"target": "host", "label": "Patch servers"},
    "software":           {"target": "host", "label": "Install, upgrade or remove software"},
    "agent_update":       {"target": "host", "label": "Update agents"},
    "restart":            {"target": "host", "label": "Restart servers"},
    "vm_snapshot_create": {"target": "vm",   "label": "Take VM snapshot"},
    "vm_snapshot_remove": {"target": "vm",   "label": "Remove VM snapshot"},
    "vm_snapshot_cleanup": {"target": "vm",  "label": "Remove VM snapshots by name or age"},
    "vm_snapshot_revert": {"target": "vm",   "label": "Revert VM to snapshot"},
    "vm_power_on":        {"target": "vm",   "label": "Power on VM"},
    "vm_guest_shutdown":  {"target": "vm",   "label": "Shut down guest OS"},
    "vm_guest_restart":   {"target": "vm",   "label": "Restart guest OS"},
}

# One snapshot or revert targets one VM: a revert across many VMs at once is
# how a mistake becomes an outage.
SINGLE_VM = {"vm_snapshot_remove", "vm_snapshot_revert"}

MAX_TARGETS = 500
ALWAYS_APPROVE = {"software"}
SNAP_NAME_RE = re.compile(r"^[A-Za-z0-9 _.:()/+-]{1,80}$")
MOREF_RE = re.compile(r"^[a-z]+-\d+$")
# Vendor advisories (RHSA-2026:4417, ELSA-2026-1234) and Microsoft updates (KB5044277)
ADVISORY_RE = re.compile(r"^(?:[A-Z]{2,6}-\d{4}[-:]\d{1,6}|KB\d{6,8})$")

PATCH_MODES = ("security", "advisories")
REBOOT = ("never", "if_required", "always")
SNAPSHOT = ("none", "keep", "remove_on_success")


class Invalid(ValueError):
    """A request that must not become a change. The message is for the operator."""


def _parse_time(v, name):
    if v in (None, ""):
        return None
    try:
        t = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except ValueError:
        raise Invalid(f"{name} is not a valid date and time.")
    if t.tzinfo is None:
        raise Invalid(f"{name} needs a time zone.")
    return t


def validate(conn, kind, raw_targets, raw_params, run_after=None, run_before=None,
             max_parallel=5):
    """Check a request against the inventory and the rules.

    Returns (targets, params, run_after, run_before, max_parallel), all
    normalised, or raises Invalid with a reason written for the operator.
    """
    if kind not in KINDS:
        raise Invalid("Unknown kind of change.")
    params = dict(raw_params or {})
    now = datetime.now(timezone.utc)

    ra = _parse_time(run_after, "Start") or now
    rb = _parse_time(run_before, "End of window")
    if ra < now - timedelta(minutes=5):
        raise Invalid("The start time is in the past.")
    if rb and rb <= ra:
        raise Invalid("The window must end after it starts.")
    if rb and rb - ra < timedelta(minutes=15):
        raise Invalid("Allow at least 15 minutes between start and end.")
    try:
        mp = int(max_parallel)
    except (TypeError, ValueError):
        raise Invalid("Parallel servers must be a number.")
    if not 1 <= mp <= 50:
        raise Invalid("Run between 1 and 50 servers at a time.")

    if not isinstance(raw_targets, list) or not raw_targets:
        raise Invalid("Choose at least one target.")
    if len(raw_targets) > MAX_TARGETS:
        raise Invalid(f"At most {MAX_TARGETS} targets in one change.")

    if KINDS[kind]["target"] == "host":
        targets = _validate_hosts(conn, raw_targets)
        if kind == "software":
            params = _validate_software(conn, params, targets)
        elif kind == "restart":
            params = {"restart_only": True, "check_services": bool(params.get("check_services", True))}
            # Never restart a server in the middle of another job's step
            busy = conn.execute(
                """SELECT DISTINCT ct.label FROM change_targets ct JOIN changes c ON c.id = ct.change_id
                    WHERE c.state = 'running' AND ct.host_id = ANY(%s::uuid[])
                      AND ct.state NOT IN ('queued', 'done', 'done_with_warnings', 'failed', 'skipped', 'cancelled')""",
                ([t["host_id"] for t in targets],)).fetchall()
            if busy:
                raise Invalid("These servers are in a running job right now: " + ", ".join(r["label"] for r in busy[:10])
                              + ". Restart them after it finishes.")
        elif kind == "agent_update":
            from . import agent_updates
            try:
                params = agent_updates.validate(conn, params, targets)
            except agent_updates.Invalid as e:
                raise Invalid(str(e))
        else:
            params = _validate_patch(conn, params, targets)
            if kind == "patch":
                params = _validate_reboot_time(params, raw_params or {}, ra)
    else:
        if kind in SINGLE_VM and len(raw_targets) != 1:
            raise Invalid("Choose exactly one VM for this action.")
        targets = _validate_vms(conn, raw_targets)
        if kind == "vm_snapshot_cleanup":
            from . import snapshot_cleanup, vmware
            try:
                params = snapshot_cleanup.validate(conn, params, targets, vmware.writer_names())
            except snapshot_cleanup.FilterError as e:
                raise Invalid(str(e))
        else:
            params = _validate_vm_action(kind, params, targets, conn)
    return targets, params, ra, rb, mp


# When more than one VM is linked to a server (a replica or clone that kept its
# hardware UUID and name), the one that is the running server: powered on,
# carrying the agent's address, most recently seen. Never an arbitrary one.
VM_PICK = """ORDER BY (v.power_state = 'poweredOn') IS TRUE DESC,
                      (h.agent_ip IS NOT NULL AND host(h.agent_ip) = ANY(coalesce(v.guest_ips, '{}'))) IS TRUE DESC,
                      v.synced_at DESC NULLS LAST, v.moref"""


def _validate_hosts(conn, raw):
    ids = []
    for t in raw:
        hid = t.get("host_id") if isinstance(t, dict) else t
        if not isinstance(hid, str) or not re.match(r"^[0-9a-f-]{36}$", hid):
            raise Invalid("A server id was not recognised.")
        ids.append(hid)
    rows = conn.execute(
        f"""SELECT h.id::text AS id, h.hostname, h.status, h.os_id,
                  (SELECT v.vcenter FROM vm_inventory v WHERE v.host_id = h.id {VM_PICK} LIMIT 1) AS vcenter,
                  (SELECT v.moref FROM vm_inventory v WHERE v.host_id = h.id {VM_PICK} LIMIT 1) AS vm_moref
             FROM hosts h WHERE h.id::text = ANY(%s)""", (ids,)).fetchall()
    found = {r["id"]: r for r in rows}
    missing = [i for i in ids if i not in found]
    if missing:
        raise Invalid(f"{len(missing)} selected server(s) no longer exist.")
    retired = [found[i]["hostname"] for i in ids if found[i]["status"] == "decommissioned"]
    if retired:
        raise Invalid("Retired servers cannot be patched: " + ", ".join(retired[:5]))
    seen, out = set(), []
    for i in ids:
        if i in seen:
            continue
        seen.add(i)
        r = found[i]
        out.append({"target_key": i, "host_id": i, "label": r["hostname"], "os_id": r["os_id"],
                    "vcenter": r["vcenter"], "vm_moref": r["vm_moref"]})
    return out


def _validate_patch(conn, p, targets):
    mode = p.get("mode", "security")
    if mode not in PATCH_MODES:
        raise Invalid("Patch mode must be all security fixes, or chosen advisories.")
    advisories = []
    if mode == "advisories":
        advisories = [a for a in (p.get("advisories") or []) if isinstance(a, str)]
        bad = [a for a in advisories if not ADVISORY_RE.match(a)]
        if not advisories or bad:
            raise Invalid("List the advisories to install, for example RHSA-2026:4417.")
    reboot = p.get("reboot", "if_required")
    if reboot not in REBOOT:
        raise Invalid("Reboot must be never, if required, or always.")
    snapshot = p.get("snapshot", "none")
    if snapshot not in SNAPSHOT:
        raise Invalid("Snapshot must be none, keep, or remove on success.")
    if snapshot != "none":
        unlinked = [t["label"] for t in targets if not t["vm_moref"]]
        if unlinked:
            # A new VM is linked at the next vCenter read: ask for one now (the worker reads within a minute)
            try:
                conn.execute("UPDATE vcenters SET sync_requested_at = now()")
                conn.commit()              # kept although this request is refused
            except Exception:  # noqa: BLE001 - schema 035 not applied: the 5-minute read still links it
                conn.rollback()
            raise Invalid("A snapshot needs each server linked to its VM, and these are not linked yet: "
                          + ", ".join(unlinked[:5])
                          + ". A vCenter read has been started now; try again in a minute or two. "
                            "If it still fails, check the server's agent has reported (its hardware ID links it to the VM).")
    return {"mode": mode, "advisories": advisories, "reboot": reboot,
            "snapshot": snapshot, "check_services": bool(p.get("check_services", True))}


REBOOT_AT_MAX = timedelta(days=14)
SNAPSHOT_WAIT_MAX = timedelta(hours=24)


def _validate_reboot_time(params, raw, ra):
    """A restart at a set time, separate from the patching: the servers install
    from the start time, then wait and restart at reboot_at (several at a time
    as the job allows). Without reboot_at they restart right after installing."""
    when = raw.get("reboot_when") or "after_install"
    if when not in ("after_install", "at"):
        raise Invalid("Restart must be right after installing, or at a set time.")
    if when == "after_install" or params["reboot"] == "never":
        params.pop("reboot_at", None)
        return params
    at = _parse_time(raw.get("reboot_at"), "Restart time")
    if not at:
        raise Invalid("Choose the restart time.")
    if at < ra + timedelta(minutes=10):
        raise Invalid("The restart time must be at least 10 minutes after the start, so the servers have installed first.")
    if at - ra > REBOOT_AT_MAX:
        raise Invalid("The restart time must be within 14 days of the start.")
    if params.get("snapshot", "none") != "none" and at - ra > SNAPSHOT_WAIT_MAX:
        raise Invalid("With a VM snapshot, restart within 24 hours of the start: a snapshot grows on the datastore "
                      "while the servers wait. Choose an earlier restart time, or no snapshot.")
    params["reboot_at"] = at.isoformat()
    return params


def _validate_package(conn, p, targets):
    """A deployment of a package uploaded to PATCH-01 (Deployment page)."""
    from . import deploy
    try:
        pkg = deploy.view(deploy.get(conn, str(p.get("package_id") or "")))
    except deploy.NotFound as e:
        raise Invalid(str(e))
    action = p.get("action")
    if action not in deploy.DEPLOY_ACTIONS:
        raise Invalid("Choose install, upgrade, remove and install, or remove.")
    if action == "replace":
        if (pkg.get("install_mode") or "installer") == "portable":
            raise Invalid("A portable program is copied, not installed: deploy it with Install (it replaces the copy).")
        from . import agent_updates
        ver = {r["id"]: r["agent_version"] for r in conn.execute(
            "SELECT id::text AS id, agent_version FROM hosts WHERE id::text = ANY(%s)",
            ([t["host_id"] for t in targets],)).fetchall()}
        old = [t["label"] for t in targets if t.get("os_id") == "windows"
               and (agent_updates.version_tuple(ver.get(t["host_id"])) or (0, 0, 0)) < REMOVAL_AGENT]
        if old:
            raise Invalid("Remove and install needs Windows agent 1.9.3 or later. Update the agent first on: "
                          + ", ".join(old[:5]) + (f" and {len(old) - 5} more" if len(old) > 5 else ""))
    if action == "uninstall":
        # The same rule as removing an installed program: never critical software, only listed tools
        from . import sw_policy
        try:
            sw_policy.check(conn, pkg.get("detect_name") or pkg.get("name"), pkg.get("vendor"))
        except sw_policy.Refused as e:
            raise Invalid(str(e))
    why = deploy.deploy_blocker(pkg, "install" if action == "replace" else action)
    if why:
        raise Invalid(f"This package cannot be deployed yet: {why}.")
    other = [t["label"] for t in targets if t.get("os_id") != "windows"]
    if other:
        raise Invalid("Packages install on Windows servers only. Not Windows: " + ", ".join(other[:5]))
    base = _validate_patch(conn, {"mode": "security", "reboot": p.get("reboot", "never"),
                                  "snapshot": p.get("snapshot", "none"),
                                  "check_services": p.get("check_services", True)}, targets)
    return {"source": "package", "package_id": str(pkg["id"]),
            "action": action, "software": f"{pkg['name']} {pkg['version']}", "file_name": pkg["file_name"],
            "install_mode": pkg.get("install_mode") or "installer",
            # The package as reviewed now: edits after this never change this deployment
            "package": deploy.frozen(pkg),
            "reboot": base["reboot"], "snapshot": base["snapshot"], "check_services": base["check_services"]}


REMOVAL_AGENT = (1, 9, 3)              # Windows agents that report uninstall keys and remove by them


def _validate_installed(conn, p, targets):
    """Removing a program already installed (Software › Installed software). Admins only (checked
    by the API). Only programs on the removable tools list, never critical software, only where
    the server's agent reported a silent way to remove that exact entry."""
    from . import agent_updates, sw_policy
    prog = p.get("program") if isinstance(p.get("program"), dict) else {}
    name = str(prog.get("name") or "").strip()
    version = str(prog.get("version") or "").strip()
    arch = str(prog.get("arch") or "")
    if not name or len(name) > 300 or re.search(r"[\x00-\x1f]", name) or len(version) > 120 or re.search(r"[\x00-\x1f]", version):
        raise Invalid("Choose the program to remove.")
    if arch not in ("64-bit", "32-bit"):
        raise Invalid("Choose the program to remove (its 64-bit or 32-bit entry).")
    try:
        allowed = sw_policy.check(conn, name)
    except sw_policy.Refused as e:
        raise Invalid(str(e))
    other = [t["label"] for t in targets if t.get("os_id") != "windows"]
    if other:
        raise Invalid("Programs are removed from Windows servers only. Not Windows: " + ", ".join(other[:5]))
    rows = {r["host_id"]: r for r in conn.execute(
        """SELECT ws.host_id::text AS host_id, ws.publisher, ws.uninstall_key, ws.uninstall_how, h.agent_version
             FROM windows_software ws JOIN hosts h ON h.id = ws.host_id
            WHERE ws.host_id::text = ANY(%s) AND ws.name = %s AND ws.version = %s AND ws.arch = %s""",
        ([t["host_id"] for t in targets], name, version, arch)).fetchall()}
    keys, problems = {}, []
    for t in targets:
        r = rows.get(t["host_id"])
        if not r:
            problems.append(f"{t['label']} (not installed there)")
        elif sw_policy.critical(name, r["publisher"]):
            problems.append(f"{t['label']} (critical software)")
        elif (agent_updates.version_tuple(r["agent_version"]) or (0, 0, 0)) < REMOVAL_AGENT:
            problems.append(f"{t['label']} (agent {r['agent_version'] or 'unknown'}: update it to 1.9.3 or later first)")
        elif not r["uninstall_key"] or r["uninstall_how"] not in sw_policy.HOW:
            problems.append(f"{t['label']} (no silent uninstaller registered)")
        else:
            keys[t["host_id"]] = {"key": r["uninstall_key"], "how": r["uninstall_how"]}
    if problems:
        raise Invalid(f"{name} {version} cannot be removed from: " + "; ".join(problems[:10])
                      + (f" and {len(problems) - 10} more" if len(problems) > 10 else "") + ". Untick those servers.")
    base = _validate_patch(conn, {"mode": "security", "reboot": p.get("reboot", "never"), "snapshot": "none",
                                  "check_services": p.get("check_services", True)}, targets)
    return {"source": "installed", "action": "uninstall", "software": f"{name} {version}".strip(),
            "program": {"name": name, "version": version, "arch": arch},
            "keys": keys, "allowed": allowed,
            "reboot": base["reboot"], "snapshot": "none", "check_services": base["check_services"]}


def _validate_software(conn, p, targets):
    """A software job: a Deployment package (install or upgrade), or removing a listed tool already
    installed. Installers on a share are retired: Deployment holds the installers now."""
    if p.get("source") == "package":
        return _validate_package(conn, p, targets)
    if p.get("source") == "installed":
        return _validate_installed(conn, p, targets)
    raise Invalid("Choose a package from Deployment.")


def _validate_vms(conn, raw):
    out = []
    for t in raw:
        if not isinstance(t, dict):
            raise Invalid("A VM was not recognised.")
        vc, moref = str(t.get("vcenter") or ""), str(t.get("moref") or "")
        if not MOREF_RE.match(moref):
            raise Invalid("A VM was not recognised.")
        row = conn.execute(
            """SELECT name, power_state, tools_running, snapshots, host_id::text AS host_id
                 FROM vm_inventory WHERE vcenter=%s AND moref=%s""", (vc, moref)).fetchone()
        if not row:
            raise Invalid("A selected VM is no longer in the inventory. Re-sync the vCenter.")
        out.append({"target_key": f"{vc}|{moref}", "vcenter": vc, "vm_moref": moref,
                    "host_id": row["host_id"], "label": row["name"],
                    "_power": row["power_state"], "_tools": row["tools_running"],
                    "_snapshots": row["snapshots"] or []})
    keys = [o["target_key"] for o in out]
    if len(set(keys)) != len(keys):
        raise Invalid("The same VM was chosen twice.")
    return out


def _validate_vm_action(kind, p, targets, conn=None):
    if kind == "vm_snapshot_create":
        name = str(p.get("name") or "").strip()
        if not SNAP_NAME_RE.match(name):
            raise Invalid("Give the snapshot a name: letters, digits and simple punctuation, up to 80.")
        return {"name": name, "description": str(p.get("description") or "")[:500],
                "memory": bool(p.get("memory", False)), "quiesce": bool(p.get("quiesce", False))}

    if kind in ("vm_snapshot_remove", "vm_snapshot_revert"):
        t = targets[0]
        snap = str(p.get("snapshot_moref") or "")
        known = {s.get("moref"): s for s in t["_snapshots"] if isinstance(s, dict)}
        if snap not in known:
            raise Invalid("That snapshot is not on this VM. Re-sync the vCenter if it is new.")
        if conn is not None:
            from . import snapshot_cleanup
            other = snapshot_cleanup.in_use(conn).get((t["vcenter"], snap))
            if other:
                raise Invalid(f"'{known[snap].get('name')}' is in use by {other}, which has not finished. "
                              f"Wait for it, or cancel it first.")
        out = {"snapshot_moref": snap, "snapshot_name": known[snap].get("name")}
        if kind == "vm_snapshot_remove":
            out["remove_children"] = bool(p.get("remove_children", False))
            return out
        # Revert discards everything since the snapshot. The operator types
        # the VM's name, so it cannot be done by a slip of the mouse.
        if str(p.get("confirm_name") or "").strip() != t["label"]:
            raise Invalid(f"To revert, type the VM name exactly: {t['label']}")
        out["safety_snapshot"] = True     # always, not optional
        return out

    if kind == "vm_power_on":
        on = [t["label"] for t in targets if t["_power"] == "poweredOn"]
        if on:
            raise Invalid("Already powered on: " + ", ".join(on[:5]))
        return {}

    if kind in ("vm_guest_shutdown", "vm_guest_restart"):
        # A clean guest operation needs VMware Tools. Without it the only way
        # is a hard power-off, which this platform deliberately does not offer.
        no_tools = [t["label"] for t in targets if t["_tools"] != "guestToolsRunning"]
        if no_tools:
            raise Invalid("VMware Tools is not running on: " + ", ".join(no_tools[:5])
                          + ". A clean shutdown or restart needs it.")
        off = [t["label"] for t in targets if t["_power"] != "poweredOn"]
        if off:
            raise Invalid("Not powered on: " + ", ".join(off[:5]))
        return {}
    return {}


def create(conn, kind, title, reason, targets, params, run_after, run_before,
           max_parallel, user, role):
    """Record a validated change. Returns its id and number."""
    reason = (reason or "").strip()
    if len(reason) < 3:
        raise Invalid("Say why this change is being made. It is kept in the record.")
    title = (title or "").strip()[:200] or KINDS[kind]["label"]
    # Installing software as SYSTEM always needs a second person's approval,
    # whatever the global setting says
    # A package uploaded in Deployment is deployed by whoever reviewed it (no second person needed)
    # Removing a listed tool is an admin's own decision (admins only, no second person)
    needs_approval = (REQUIRE_APPROVAL or (kind in ALWAYS_APPROVE and params.get("source") != "installed"
                                           and (params.get("source") != "package" or DEPLOY_REQUIRE_APPROVAL))
                      or (kind == "agent_update" and AGENT_UPDATE_REQUIRE_APPROVAL)
                      or (kind == "vm_snapshot_cleanup" and SNAPSHOT_CLEANUP_REQUIRE_APPROVAL))
    state = "pending_approval" if needs_approval else "scheduled"
    row = conn.execute(
        """INSERT INTO changes (kind, title, reason, state, params, requested_by, requested_role,
                                approval_required, run_after, run_before, max_parallel)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id::text AS id, number""",
        (kind, title, reason[:2000], state, json.dumps(params), user, role,
         needs_approval, run_after, run_before, max_parallel)).fetchone()
    with conn.cursor() as cur:
        cur.executemany(
            """INSERT INTO change_targets (change_id, target_key, host_id, vcenter, vm_moref, label)
               VALUES (%s,%s,%s,%s,%s,%s)""",
            [(row["id"], t["target_key"], t.get("host_id"), t.get("vcenter"),
              t.get("vm_moref"), t["label"]) for t in targets])
    what = (f"{params.get('total')} snapshot(s) on {len(targets)} VM(s): {params.get('described')}"
            if kind == "vm_snapshot_cleanup" else f"{len(targets)} target(s)")
    event(conn, row["id"], None, user, "requested", True,
          f"{KINDS[kind]['label']}: {what}",
          {"params": params, "run_after": run_after.isoformat(),
           "run_before": run_before.isoformat() if run_before else None})
    return row["id"], row["number"]


def event(conn, change_id, target_key, actor, what, ok=None, message=None, detail=None):
    conn.execute(
        """INSERT INTO change_events (change_id, target_key, actor, event, ok, message, detail)
           VALUES (%s,%s,%s,%s,%s,%s,%s)""",
        (change_id, target_key, actor, what, ok, (message or "")[:2000] or None,
         json.dumps(detail or {}, default=str)))


def ref(number):
    return f"CHG-{int(number):06d}"
