"""Is this installed program the product of that uploaded package? (r105)

Before r105 a package matched an installed program when the program's name started
with the name typed on the package. That missed "Mozilla Firefox (x64 en-US)" for
"Firefox", and matched "Java 8 Update 401" for an unrelated "Java" from another
vendor. Here the decision uses every piece of evidence both sides carry:

  package (pkginfo + the review)        installed program (the agent's inventory)
  MSI ProductCode                   ->  its Programs and Features key (an MSI's key IS its ProductCode)
  product names (typed, MSI, EXE)   ->  DisplayName
  vendor (typed, Manufacturer,      ->  Publisher
          CompanyName)
  32/64-bit (MSI platform, or        ->  "x64"/"x86" in DisplayName, else the registry view
          "x64" in its name)
  version (and a version in a name) ->  DisplayVersion (and a version in DisplayName)

Names are compared after removing what is not the product: versions, architecture
("x64", "(64-bit)"), languages ("en-US"), marks (®, ™), filler ("Setup", "for
Windows") and the vendor's own name ("Mozilla Firefox" -> "firefox" when the vendor
is Mozilla). Publishers are compared after removing company forms (Inc., Corp., Ltd).

A version written in a program's NAME is not always just a version: Python 3.11 and
3.12, .NET 6 and 8, Java 17 and 21 are separate products installed side by side,
while 7-Zip 23.01 is upgraded in place to 24.08. The names alone cannot tell which,
so a program whose name carries another version line (the first two numbers) than
the package is "possible" until someone says, once per package, which it is ("the
same product, upgraded in place" or "a separate product"), or AI-01 is asked.

Each match has a level, a score and its reasons in words:
  exact      the same MSI ProductCode
  confirmed  an operator said it is the same product
  high       the same product name, and the same (or an unstated) publisher
  ai         AI-01 judged it the same product (never enough on its own to REMOVE)
  possible   something points to it, not enough to act on: shown, for a person or AI-01
A program an operator (or AI-01) called a different product never matches.

Pure: no database. deploy.py, worker.py and api_inventory.py feed it.
"""
import re
import unicodedata
from functools import lru_cache

DEFINITE = ("exact", "confirmed", "high", "ai")
REMOVABLE = ("exact", "confirmed", "high")          # what a removal may act on: never AI-01 alone
FAMILY = "family:"                                   # a verdict for every version line of a product

_MARKS = re.compile(r"[®™©]|\((?:r|tm|c)\)", re.I)
_VERSION = re.compile(r"\bv?\d+(?:[._]\d+){1,4}[a-z]?\b|\bv\d+\b|\bbuild\s*\d+\b"
                      r"|\bupdate\s+\d+\b|\bservice\s+pack\s+\d+\b|\bsp\d+\b", re.I)
_ARCH = re.compile(r"\b(?:x64|x86|amd64|arm64|ia64|win64|win32|x86[_-]64|64[- ]?bits?|32[- ]?bits?)\b", re.I)
_A64 = re.compile(r"\b(?:x64|amd64|win64|x86[_-]64|64[- ]?bits?)\b", re.I)
_A32 = re.compile(r"\b(?:x86|win32|32[- ]?bits?)\b", re.I)
_LANG = re.compile(r"\b[a-z]{2}[-_][a-z]{2}\b", re.I)
_TOKEN = re.compile(r"[a-z0-9]+(?:\+\+|#)?")
_NAMEVER = re.compile(r"(?<![\w.])v?(\d+(?:\.\d+)+)(?![\w.])", re.I)
_CUT = re.compile(r"[\s(\[-]+v?\d+(?:[._]\d+)+.*$|\s+(?:update|release|build|version)\s+\d.*$", re.I)
_NOISE = {"setup", "installer", "install", "edition", "version", "ver", "release", "the", "for", "windows",
          "win", "msi", "exe", "bit", "and", "package",
          # languages a product names itself with ("Acrobat Reader - English", "... MUI")
          "english", "german", "french", "spanish", "italian", "japanese", "chinese", "multilingual", "mui"}
_FORMS = {"inc", "incorporated", "corp", "corporation", "co", "company", "ltd", "limited", "llc", "gmbh", "ag",
          "sa", "bv", "oy", "ab", "plc", "pty", "srl", "kg", "the", "and", "spa", "sas", "as", "nv", "kk"}
_GUID = re.compile(r"^\{[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\}$", re.I)


def _plain(text):
    t = unicodedata.normalize("NFKC", str(text or ""))
    t = re.sub("[​-‏⁠﻿]", "", t)            # invisible format characters
    return _MARKS.sub(" ", t).replace("&", " and ").lower()


@lru_cache(maxsize=65536)
def vendor_key(vendor):
    """'Microsoft Corporation' -> ('microsoft',); '' -> ()"""
    return tuple(t for t in _TOKEN.findall(_plain(vendor)) if t not in _FORMS)


@lru_cache(maxsize=65536)
def name_key(name, vendor=None):
    """The product's own words: 'Mozilla Firefox (x64 en-US) 131.0' with vendor Mozilla -> ('firefox',)."""
    t = _plain(name)
    t = _VERSION.sub(" ", t)
    t = _ARCH.sub(" ", t)
    t = _LANG.sub(" ", t)
    toks = [x for x in _TOKEN.findall(t) if x not in _NOISE]
    # A version left as separate numbers at the end ("Notepad++ 8 6 9"): not the product's name
    while len(toks) > 1 and toks[-1].isdigit() and len(toks[-1]) < 4 and toks[-2].isdigit():
        toks.pop()
    v = set(vendor_key(vendor or ""))
    if v:
        rest = [x for x in toks if x not in v]
        if rest:                                   # never strip a name down to nothing ("Zoom" by Zoom)
            toks = rest
    return tuple(toks)


@lru_cache(maxsize=65536)
def name_version(name):
    """A version written in the name ('Python 3.11.7 (64-bit)' -> (3, 11, 7)), or None."""
    m = _NAMEVER.search(_ARCH.sub(" ", _plain(name)))
    return tuple(int(x) for x in m.group(1).split(".")[:4]) if m else None


@lru_cache(maxsize=65536)
def name_arch(name):
    """'64-bit' / '32-bit' when the name says so ('... Redistributable (x86)'), else None."""
    t = _plain(name)
    if _A64.search(t):
        return "64-bit"
    if _A32.search(t):
        return "32-bit"
    return None


def stable_name(name, keep_line=True):
    """The name as a prefix the agent can find before AND after an upgrade.
    keep_line: up to the version line, so an upgrade within it is found and another line is not:
        'Python 3.12.0 (64-bit)' -> 'Python 3.12'   (never 'Python', which is also 3.11)
    not keep_line (every version line confirmed the same product): without the version:
        '7-Zip 23.01 (x64)' -> '7-Zip'
    The whole name when it carries no version, or too little would be left."""
    name = str(name or "")
    m = re.search(r"v?(\d+)\.(\d+)(?:[._]\d+)*", name)
    if m and keep_line:
        cut = name[:m.start()] + m.group(1) + "." + m.group(2)
    else:
        cut = _CUT.sub("", name).rstrip(" -_,(")
    return cut if len(cut) >= 3 else name


def family_key(name, publisher=""):
    return FAMILY + " ".join(name_key(name, publisher or None))


def arch_of_package(facts):
    """'64-bit' / '32-bit' for an MSI (its platform), None when not known (an EXE's own
    bitness says little about what it installs)."""
    tpl = ((facts or {}).get("summary") or {}).get("template") or ""
    plat = tpl.split(";", 1)[0].strip().lower()
    if plat in ("x64", "amd64", "intel64", "arm64"):
        return "64-bit"
    if plat in ("intel", "x86"):
        return "32-bit"
    return None


def version_tuple(v):
    parts = [int(x) for x in re.findall(r"\d+", str(v or ""))[:4]]
    return tuple(parts + [0] * (4 - len(parts))) if parts else None


def compare_versions(a, b):
    ta, tb = version_tuple(a), version_tuple(b)
    if ta is None or tb is None:
        return None
    return (ta > tb) - (ta < tb)


class Identity:
    """What a package says it is."""

    def __init__(self, names, vendors, version=None, product_code=None, arch=None):
        self.names = list(dict.fromkeys(x.strip() for x in names if x and x.strip()))
        self.vendors = list(dict.fromkeys(x.strip() for x in vendors if x and x.strip()))
        self.version = version
        self.product_code = (product_code or "").upper() or None
        self.arch = arch or next((name_arch(n) for n in self.names if name_arch(n)), None)
        self.vendor_keys = [k for k in (vendor_key(v) for v in self.vendors) if k]
        self.name_keys = []
        for n in self.names:
            for v in self.vendors + [None]:              # with the vendor's words removed, and as written
                k = name_key(n, v)
                if k and k not in self.name_keys:
                    self.name_keys.append(k)
        self.raw_keys = {name_key(n, None) for n in self.names} - {()}
        self.words = set(t for k in self.name_keys for t in k)           # for a quick "nothing in common"
        # The version line this package is: from a version in its names, else its version
        nv = next((name_version(n) for n in self.names if name_version(n)), None)
        vt = version_tuple(version)
        self.line = (nv or vt or ())[:2] or None

    @classmethod
    def of_package(cls, p):
        meta = p.get("meta") or {}
        pr, vi, sm = meta.get("properties") or {}, meta.get("version_info") or {}, meta.get("summary") or {}
        names = [p.get("detect_name"), p.get("name"), pr.get("ProductName"), vi.get("ProductName"), sm.get("subject")]
        vendors = [p.get("vendor"), pr.get("Manufacturer"), vi.get("CompanyName")]
        code = p.get("product_code") or pr.get("ProductCode")
        return cls(names, vendors, p.get("version"), code if code and _GUID.match(code) else None, arch_of_package(meta))


def _vendor_relation(ident, publisher):
    pk = vendor_key(publisher)
    if not pk or not ident.vendor_keys:
        return "unknown"
    ps = set(pk)
    for vk in ident.vendor_keys:
        vs = set(vk)
        if vs == ps or vs <= ps or ps <= vs:
            return "same"
    return "different"


def _distinct(tokens):
    """Enough of a name to stand on its own: not just one short or generic word."""
    return any(len(t) >= 4 or any(c.isdigit() for c in t) or t.endswith("++") for t in tokens)


def _line(v):
    return tuple(list(v[:2]) + [0] * (2 - len(v[:2])))


def match(ident, prog, verdicts=None):
    """How well an installed program {name, publisher, version, arch, uninstall_key} matches.
    Returns None (not this product) or {level, score, reasons, arch_differs, line_differs}."""
    name, publisher = prog.get("name") or "", prog.get("publisher") or ""
    verdicts = verdicts or {}
    v = verdicts.get((name, publisher)) or {}
    fam = verdicts.get((family_key(name, publisher), publisher)) or {}
    if v.get("operator") == "different":
        return None
    # The registry view (64/32-bit) says how the program registered, not what it is: Google's own
    # installer, a 32-bit program, registers 64-bit Chrome in the 32-bit view. It counts only for an
    # MSI (its view follows the MSI's platform); else only "x64"/"x86" in the name counts (r109)
    p_arch = name_arch(name) or (prog.get("arch") if _GUID.match(prog.get("uninstall_key") or "") else None)
    arch_differs = bool(ident.arch and p_arch and ident.arch != p_arch)
    key = (prog.get("uninstall_key") or "").upper()
    if ident.product_code and key == ident.product_code:
        return {"level": "exact", "score": 1.0, "reasons": ["the same MSI product code"], "arch_differs": False,
                "line_differs": False}
    if v.get("operator") == "same":
        return {"level": "confirmed", "score": 0.99, "reasons": ["confirmed the same product by %s" % (v.get("by") or "an operator")],
                "arch_differs": arch_differs, "line_differs": False}

    # Most programs share no word with the package at all: settled without the full comparison
    if not v.get("ai") and not fam and ident.words.isdisjoint(name_key(name, None)):
        return None
    vrel = _vendor_relation(ident, publisher)
    prog_keys = {name_key(name, publisher or None), name_key(name, None)} | {name_key(name, x) for x in ident.vendors}
    prog_keys.discard(())
    score, how, best = 0.0, None, None
    for pk in ident.name_keys:
        for ik in prog_keys:
            if pk == ik:
                s, h = 1.0, "equal"
            elif set(pk) < set(ik) and _distinct(pk):
                s, h = (0.75 if len(set(ik) - set(pk)) == 1 else 0.6), "package name inside"
            elif set(ik) < set(pk) and _distinct(ik):
                s, h = 0.6, "program name inside"
            else:
                inter, union = set(pk) & set(ik), set(pk) | set(ik)
                j = len(inter) / len(union) if union else 0
                s, h = (j * 0.7, "similar") if j >= 0.5 and _distinct(inter) else (0, None)
            if s > score:
                score, how, best = s, h, (pk, ik)
    if not how:
        if v.get("ai") == "same":
            return {"level": "ai", "score": 0.8, "reasons": ["AI-01: " + (v.get("ai_reason") or "the same product")],
                    "arch_differs": arch_differs, "line_differs": False}
        return None
    pk, ik = best
    words = lambda t: "'" + " ".join(t) + "'"
    reasons = []
    if how == "equal":
        reasons.append("the same product name (%s)" % words(pk))
    elif how == "package name inside":
        reasons.append("the program's name %s contains the package's %s" % (words(ik), words(pk)))
    elif how == "program name inside":
        reasons.append("the package's name %s contains the program's %s" % (words(pk), words(ik)))
    else:
        reasons.append("similar names (%s and %s)" % (words(pk), words(ik)))
    if vrel == "same":
        reasons.append("the same publisher")
    elif vrel == "different":
        reasons.append("a different publisher (%s)" % (publisher or "?"))
    else:
        reasons.append("publisher not stated on one side")

    if how == "equal" and vrel == "same":
        level, score = "high", 0.95
    elif how == "equal" and vrel == "unknown" and _distinct(pk) and name_key(name, None) in ident.raw_keys:
        # Without a publisher to back it, only the whole name, written the same, is enough
        level, score = "high", 0.85
    elif how == "equal" and vrel == "unknown":
        level, score = "possible", 0.6
        reasons.append("a short name without a publisher to back it")
    elif how == "equal":                         # same words, another vendor: often another product
        level, score = "possible", 0.45
    elif vrel == "same":
        level, score = "possible", round(0.4 + score * 0.4, 2)
    elif vrel == "unknown":
        level, score = "possible", round(0.3 + score * 0.3, 2)
    else:
        return None                                  # partly the same words, and another vendor

    # Another version line in the program's NAME: an upgrade in place, or a separate product?
    pv = name_version(name)
    line_differs = bool(pv and ident.line and _line(pv) != _line(ident.line))
    if line_differs:
        shown = ".".join(str(x) for x in pv)
        if fam.get("operator") == "same":
            reasons.append("version %s in its name: every version is the same product (%s)" % (shown, fam.get("by") or "operator"))
            level, score = ("confirmed", 0.97) if level in ("high", "possible") else (level, score)
        elif fam.get("operator") == "different":
            return None
        elif level == "high":
            level, score = "possible", 0.7
            reasons.append("version %s in its name, the package is %s: the same product upgraded in place, "
                           "or a separate one installed side by side? Decide once for every version"
                           % (shown, ".".join(str(x) for x in ident.line)))
    if arch_differs:
        reasons.append("another architecture (%s installed, the package is %s)" % (p_arch, ident.arch))
    # A person, or AI-01, has the last word on what the evidence leaves open
    ai_v = v.get("ai") or (fam.get("ai") if line_differs else None)
    ai_r = v.get("ai_reason") or fam.get("ai_reason")
    if level == "possible" and ai_v == "same":
        level, score = "ai", 0.8
        reasons.append("AI-01: " + (ai_r or "the same product"))
    elif ai_v == "different" and level not in ("high", "confirmed"):
        return None
    elif ai_v == "different":
        reasons.append("AI-01 thinks it is a different product: " + (ai_r or ""))
    return {"level": level, "score": score, "reasons": reasons, "arch_differs": arch_differs, "line_differs": line_differs}


def verdict_map(rows):
    """deploy_match rows -> {(name, publisher): {"operator": .., "by": .., "ai": .., "ai_reason": ..}}
    (a name starting "family:" is a verdict for every version line of that product)"""
    out = {}
    for r in rows or []:
        d = out.setdefault((r["prog_name"], r["prog_publisher"] or ""), {})
        if r["source"] == "operator":
            d["operator"], d["by"] = r["verdict"], r.get("decided_by")
        elif r["source"] == "ai" and (r.get("confidence") is None or r["confidence"] >= 0.7):
            d["ai"], d["ai_reason"] = r["verdict"], r.get("reason")
    return out


def _cached_match(ident, pr, verdicts, cache):
    if cache is None:
        return match(ident, pr, verdicts)
    k = (pr.get("name"), pr.get("publisher") or "", pr.get("arch"), pr.get("uninstall_key"))
    if k not in cache:
        cache[k] = match(ident, pr, verdicts)
    return cache[k]


def server_state(ident, progs, verdicts=None, cache=None):
    """One server: what it has of this product.
    {status, installed, match, possible: [...], others: [...]}, status one of
    absent | older | same | newer | unknown | other_arch | possible | ambiguous.
    `installed` is set only when it is one program, of this architecture: what may be acted on."""
    definite, possible = [], []
    for pr in progs or []:
        m = _cached_match(ident, pr, verdicts, cache)
        if not m:
            continue
        item = dict(pr, match=m)
        (definite if m["level"] in DEFINITE else possible).append(item)
    out = {"installed": None, "match": None, "possible": [_brief(x) for x in possible][:5], "others": []}
    if not definite:
        out["status"] = "possible" if possible else "absent"
        return out
    same_arch = [d for d in definite if not d["match"]["arch_differs"]]
    if not same_arch:
        out["status"] = "other_arch"
        out["others"] = [_brief(d) for d in definite][:5]
        return out
    # An EXE installer's entry in the other registry view is kept, but only when nothing registered in
    # this view fits (both 32-bit and 64-bit 7-Zip installed: the 64-bit one is compared) (r109)
    in_view = [d for d in same_arch if not (ident.arch and d.get("arch") and d["arch"] != ident.arch
                                             and not name_arch(d.get("name") or "") and not is_msi(d))]
    same_arch = in_view or same_arch
    # The strongest evidence, then the newest version
    same_arch.sort(key=lambda d: (d["match"]["score"], version_tuple(d.get("version")) or (0,) * 4), reverse=True)
    best = same_arch[0]
    names = {d["name"] for d in same_arch if d["match"]["score"] >= best["match"]["score"] - 0.05}
    out["others"] = [_brief(d) for d in definite if d is not best][:5]
    if len(names) > 1 and best["match"]["level"] != "exact":
        # Several different programs fit: none of them is chosen for anyone
        out["status"] = "ambiguous"
        out["others"] = [_brief(d) for d in same_arch][:5]
        return out
    out["installed"] = _brief(best)
    out["match"] = best["match"]
    c = compare_versions(best.get("version"), ident.version)
    out["status"] = "unknown" if c is None else {-1: "older", 0: "same", 1: "newer"}[c]
    return out


def _brief(p):
    return {"name": p.get("name"), "version": p.get("version"), "publisher": p.get("publisher"),
            "arch": p.get("arch"), "uninstall_key": p.get("uninstall_key"), "msi": is_msi(p),
            "match": p.get("match")}


def is_msi(p):
    """Registered by Windows Installer (its Programs and Features key is its MSI ProductCode)."""
    return bool(_GUID.match((p or {}).get("uninstall_key") or ""))


def best_package(packages, prog, verdicts_by_pkg=None):
    """The deployable package a program (as the Software page lists it) belongs to, or None.
    Only definite matches: the Software page offers upgrades from it."""
    best, key = None, None
    for p in packages:
        if p.get("install_mode") == "portable":
            continue
        ident = p.get("_ident") or Identity.of_package(p)
        m = match(ident, prog, (verdicts_by_pkg or {}).get(str(p.get("id"))))
        if not m or m["level"] not in DEFINITE or m.get("arch_differs"):
            continue
        k = (m["score"], version_tuple(p.get("version")) or (0,) * 4)
        if key is None or k > key:
            best, key = dict(p, _match=m), k
    return best
