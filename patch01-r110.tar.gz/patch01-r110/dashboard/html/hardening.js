/* PATCH-01 hardening pages: CIS-aligned OpenSCAP results.
 * Uses the console's shared helpers from app.js (h, api, render, table ...).
 */
"use strict";

/* Rows per page in every list of the console */
const PAGE_SIZE = 30;

const HRESULT = {
  pass: ["Pass", "hr-pass"], fail: ["Fail", "hr-fail"], error: ["Error", "hr-error"],
  notapplicable: ["Not applicable", "hr-na"], notchecked: ["Not checked", "hr-na"],
  unknown: ["Unknown", "hr-na"], informational: ["Info", "hr-na"], fixed: ["Fixed", "hr-pass"],
};

function hLevel(params) {
  const l = params.get("level") || localStorage.getItem("patch01.hardening.level") || "l1";
  return ["l1", "l2"].includes(l) || /^custom:[0-9a-f-]{36}$/.test(l) ? l : "l1";
}

let CUSTOMS = [];            // active custom profiles, for the picker
async function loadCustoms() {
  try { CUSTOMS = ((await api("/hardening/custom")).profiles || []).filter(p => p.status === "active"); } catch (e) { CUSTOMS = []; }
  return CUSTOMS;
}
function levelName(level) {
  if (level === "l1") return "CIS Level 1 Server";
  if (level === "l2") return "CIS Level 2 Server";
  const p = CUSTOMS.find(x => "custom:" + x.id === level);
  return p ? p.name : "Custom profile";
}

function levelPicker(level, onChange) {
  const sel = h("select", { "aria-label": "Benchmark profile", class: "hd-level" },
    h("option", { value: "l1", selected: level === "l1" }, "CIS Level 1 Server"),
    h("option", { value: "l2", selected: level === "l2" }, "CIS Level 2 Server"),
    CUSTOMS.length ? h("optgroup", { label: "Custom profiles" },
      CUSTOMS.map(p => h("option", { value: "custom:" + p.id, selected: level === "custom:" + p.id }, p.name))) : null,
    h("option", { value: "__manage" }, can("operator") ? "\uFF0B New or manage custom profiles\u2026" : "Custom profiles\u2026"));
  sel.addEventListener("change", () => {
    if (sel.value === "__manage") { location.hash = "#/hardening/custom"; return; }
    localStorage.setItem("patch01.hardening.level", sel.value); onChange(sel.value);
  });
  return sel;
}

function scoreBadge(score) {
  if (score === null || score === undefined) return h("span", { class: "muted" }, "not scanned");
  const n = Number(score);
  const cls = n >= 85 ? "hd-good" : n >= 70 ? "hd-fair" : "hd-poor";
  return h("span", { class: "hd-score " + cls }, n.toFixed(n % 1 ? 1 : 0) + "%");
}

function scoreBar(score) {
  if (score === null || score === undefined) return h("span", { class: "muted" }, "\u2013");
  const n = Math.max(0, Math.min(100, Number(score)));
  const bar = h("span", { class: "hd-bar " + (n >= 85 ? "hd-good" : n >= 70 ? "hd-fair" : "hd-poor") },
    h("span", { class: "hd-bar-fill" }));
  bar.firstChild.style.width = n + "%";
  return h("span", { class: "hd-bar-cell" }, bar, scoreBadge(n));
}


function resultChip(r) {
  const [label, cls] = HRESULT[r] || [r, "hr-na"];
  return h("span", { class: "hd-res " + cls }, label);
}

const CHECKIN_MIN = 5;   // the agent's timer: install-agent.sh --interval

// Where an in-flight scan is, in words, with a bar while rules are checked
function scanProgress(row) {
  const st = row.last_state, stage = row.stage;
  if (st === "queued") {
    // Past two check-ins, the agent is not calling in: say so plainly
    const mins = row.last_requested ? (Date.now() - new Date(row.last_requested).getTime()) / 60000 : 0;
    if (mins > 2 * CHECKIN_MIN + 2) {
      return h("span", { class: "hd-prog hd-failed" },
        "Not picked up after " + Math.round(mins) + " min: the agent is not checking in. "
        + "On the server: systemctl status patch-agent.timer");
    }
    return h("span", { class: "hd-prog" }, h("span", { class: "hd-pulse" }),
      h("span", null, "Waiting for the agent's next check-in ",
        h("span", { class: "muted" }, "(every " + CHECKIN_MIN + " min; queued " + timeAgo(row.last_requested) + ")")));
  }
  const labels = { picked_up: "Starting", downloading: "Downloading benchmark",
                   uploading: "Uploading results", processing: "Processing results" };
  if (stage === "scanning") {
    const done = Number(row.progress_done || 0), total = Number(row.progress_total || 0);
    const pct = total ? Math.min(100, Math.round(100 * done / total)) : null;
    const bar = h("span", { class: "hd-pbar" }, h("span", { class: "hd-pbar-fill" }));
    bar.firstChild.style.width = (pct === null ? 100 : pct) + "%";
    if (pct === null) bar.classList.add("hd-pbar-indet");
    return h("span", { class: "hd-prog" }, bar,
      h("span", null, "Scanning " + (total ? done + " / " + total + " rules (" + pct + "%)" : done + " rules")));
  }
  if (stage && labels[stage]) {
    const old = stage === "picked_up" && row.agent_version && versionBelow(row.agent_version, "1.5.0");
    return h("span", { class: "hd-prog" }, h("span", { class: "hd-pulse" }),
      h("span", null, old ? "Scanning " : labels[stage] + "\u2026 ",
        old ? h("span", { class: "muted" }, "(agent " + row.agent_version + " does not report progress; 1.5.0 does)") : null));
  }
  return h("span", { class: "hd-prog" }, h("span", { class: "hd-pulse" }), "Scanning\u2026");
}

// Numeric version comparison: "1.10.0" is newer than "1.5.0"
function versionBelow(v, than) {
  const a = String(v || "0").split(".").map(Number), b = String(than).split(".").map(Number);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const x = a[i] || 0, y = b[i] || 0;
    if (x !== y) return x < y;
  }
  return false;
}

function inFlight(row) { return row.last_state === "queued" || row.last_state === "running"; }

function scanState(row) {
  if (inFlight(row)) return scanProgress(row);
  if (row.last_state === "failed") return h("span", { class: "hd-failed", title: row.last_error || "" },
    "last scan failed: " + (row.last_error || "unknown").slice(0, 80));
  return row.finished_at ? timeAgo(row.finished_at) : h("span", { class: "muted" }, "never");
}

function trendSvg(points) {
  if (!points || points.length < 2) return null;
  const W = 260, H = 54, xs = points.map((_, i) => 6 + i * (W - 12) / (points.length - 1));
  // Scaled to the data's own range, padded, so a real improvement is visible
  const vals = points.map(p => Number(p.score));
  const lo = Math.max(0, Math.min(...vals) - 5), hi = Math.min(100, Math.max(...vals) + 5);
  const span = Math.max(1, hi - lo);
  const ys = vals.map(v => H - 6 - ((v - lo) / span) * (H - 12));
  const NS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("viewBox", "0 0 " + W + " " + H); svg.setAttribute("class", "hd-trend");
  svg.setAttribute("role", "img"); svg.setAttribute("aria-label", "Fleet score over the last 90 days");
  const path = document.createElementNS(NS, "path");
  path.setAttribute("d", xs.map((x, i) => (i ? "L" : "M") + x.toFixed(1) + "," + ys[i].toFixed(1)).join(""));
  svg.append(path);
  const dot = document.createElementNS(NS, "circle");
  dot.setAttribute("cx", xs[xs.length - 1]); dot.setAttribute("cy", ys[ys.length - 1]); dot.setAttribute("r", 3);
  svg.append(dot);
  return svg;
}

async function queueScans(level, hostIds, btn, onDone) {
  btn.disabled = true;
  const was = btn.textContent;
  btn.textContent = "Queuing\u2026";
  try {
    const r = await apiPost("/hardening/scans", { level, host_ids: hostIds || null });
    btn.textContent = r.queued.length + " queued" + (r.skipped.length ? ", " + r.skipped.length + " skipped" : "");
    if (r.skipped.length) btn.title = r.skipped.map(x => x.hostname + ": " + x.reason).join("\n");
    setTimeout(() => { btn.textContent = was; btn.disabled = false; onDone && onDone(); }, 2500);
  } catch (err) {
    btn.textContent = was; btn.disabled = false;
    alert(err.message);
  }
}

// ---- fleet page ----------------------------------------------------------
async function renderHardening(params) {
  setNav("hardening");
  await loadCustoms();
  let level = hLevel(params);
  if (level.startsWith("custom:") && !CUSTOMS.find(p => "custom:" + p.id === level)) level = "l1";
  const enc = encodeURIComponent(level);
  const [sum, list] = await Promise.all([api("/hardening/summary?level=" + enc), api("/hardening/hosts?level=" + enc)]);
  const reload = l => { location.hash = "#/hardening?level=" + encodeURIComponent(l); };
  const scanAll = can("operator")
    ? h("button", { type: "button", class: "btn", on: { click: e => queueScans(level, null, e.target, () => renderHardening(params)) } },
        "Scan all servers") : null;

  const content = sum.content || [];
  const noContent = !content.length;
  const head = h("div", { class: "page-head" },
    h("h1", { "data-cmd": "patchctl harden --report" }, "Hardening"),
    h("div", { class: "head-actions" }, levelPicker(level, reload),
      h("button", { type: "button", class: "btn btn-quiet", "data-own-export": "", "aria-haspopup": "dialog", on: { click: () => {
        const p = document.querySelector(".rep-panel"); if (p) { p.hidden = !p.hidden; if (!p.hidden) p.scrollIntoView({ block: "nearest" }); }
      } } }, "Export \u25be"), scanAll));

  if (noContent) {
    render(head, h("div", { class: "empty" },
      h("p", null, "No benchmark content has been imported yet."),
      h("p", { class: "muted" }, "On PATCH-01: ./scripts/phase8-hardening.sh --fetch <version>, with the release number from "
        + "the ComplianceAsCode releases page. Then update agents to 1.4.0 and install the OpenSCAP scanner on each server.")));
    return;
  }

  const levelsOf = new Map(content.map(c => [c.product, c.levels || []]));
  const cards = h("div", { class: "hd-cards" },
    h("div", { class: "hd-card hd-card-main" },
      h("div", { class: "hd-card-l" }, "Fleet score"),
      h("div", { class: "hd-card-n" }, sum.fleet_score === null ? "\u2013" : scoreBadge(sum.fleet_score)),
      h("div", { class: "muted small" }, "Average of the latest scan per server: passed rules out of passed plus failed."),
      trendSvg(sum.trend)),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Servers scanned"),
      h("div", { class: "hd-card-n" }, String(sum.scanned), h("span", { class: "muted" }, " / " + sum.servers)),
      sum.no_content ? h("div", { class: "muted small" }, sum.no_content + " have no benchmark content for their OS") : null),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "By score"),
      h("div", { class: "hd-bands" },
        h("span", { class: "hd-good" }, sum.bands.good, h("small", null, "85%+")),
        h("span", { class: "hd-fair" }, sum.bands.fair, h("small", null, "70\u201384%")),
        h("span", { class: "hd-poor" }, sum.bands.poor, h("small", null, "under 70%")))),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Failed checks"),
      h("div", { class: "hd-card-n" }, sum.failed_rules_total),
      h("div", { class: "muted small" }, "across all servers' latest scans")));

  const contentLine = h("p", { class: "muted small" }, "Benchmark: SCAP Security Guide " + content[0].content_version + ". "
    + content.map(c => c.product + " (" + ((c.levels || []).map(x => x.toUpperCase()).join(", ") || "no CIS server profile") + ")").join(", ") + ".");

  const top = sum.top_failing || [];
  const topTable = top.length ? table([
    { label: "Rule", cell: r => h("a", { href: "#/hardening/rule/" + encodeURIComponent(r.rule_id) + "?level=" + level }, r.title || r.rule_id) },
    { label: "CIS", nowrap: true, cell: r => r.cis_ref || h("span", { class: "muted" }, "\u2013") },
    { label: "Severity", nowrap: true, cell: r => sevChip(r.severity) },
    { label: "Servers failing", num: true, cell: r => h("strong", null, r.servers) },
    { label: "", nowrap: true, cell: r => r.risky ? h("span", { class: "hd-risky", title: "Fixing this can cut off access or break services. Test on one server first." }, "risky to fix") : "" },
  ], top) : h("div", { class: "empty" }, h("p", null, "Nothing failing in the latest scans."));

  const hosts = list.hosts || [];
  const hostTable = table([
    { label: "Server", nowrap: true, cell: r => h("a", { href: "#/hardening/host/" + r.id + "?level=" + level }, r.hostname) },
    { label: "Benchmark", nowrap: true, cell: r => {
        if (!r.product) return h("span", { class: "muted" }, "no content for " + r.os_id + " " + r.os_version);
        const lv = levelsOf.get(r.product);
        if (!lv) return h("span", { class: "muted" }, r.product + ": not imported");
        if (level.startsWith("custom:")) return r.product;
        return lv.includes(level) ? r.product : h("span", { class: "muted" }, r.product + ": no " + level.toUpperCase() + " profile");
      } },
    { label: "Score", nowrap: true, cell: r => scoreBar(r.score) },
    { label: "Failed", num: true, cell: r => r.failed === null || r.failed === undefined ? "" :
        h("span", null, r.failed, Number(r.high_failed) ? h("span", { class: "hd-high" }, " (" + r.high_failed + " high)") : null) },
    { label: "Last scan", nowrap: true, cell: r => scanState(r) },
    can("operator") ? { label: "", nowrap: true, cell: r => h("button", { type: "button", class: "btn-link",
        on: { click: e => { e.stopPropagation(); queueScans(level, [r.id], e.target, () => renderHardening(params)); } } }, "Scan") } : null,
  ].filter(Boolean), hosts);

  const exportPanel = reportPanel(level, hosts);
  const archive = h("div");
  loadArchive(archive);
  render(head,
    exportPanel,
    h("p", { class: "muted" }, "How each server's configuration compares with the CIS benchmark: SSH, logins, "
      + "auditing, file permissions, services and kernel settings. Scans are read-only; they change nothing."),
    cards, contentLine,
    h("h2", null, "Most widely failing rules"),
    h("p", { class: "muted small" }, "Fixing one of these lifts every server listed against it."),
    topTable,
    h("h2", null, "Servers (" + hosts.length + ")"),
    hostTable,
    h("h2", null, "Reports"),
    archive);

  // While scans are in flight, redraw every 5 s so progress moves on its own
  if (hosts.some(inFlight)) {
    setPageTimer(async () => {
      if (!location.hash.startsWith("#/hardening") || location.hash.includes("/host/")
          || location.hash.includes("/rule/")) return clearPageTimer();
      const y = window.scrollY;
      await renderHardening(params);
      window.scrollTo(0, y);
    }, 5000);
  } else {
    clearPageTimer();
  }
}

// ---- one server ------------------------------------------------------------
async function renderHardeningHost(hostId, params) {
  setNav("hardening");
  const level = hLevel(params);
  await loadCustoms();
  const d = await api("/hardening/hosts/" + hostId + "?level=" + encodeURIComponent(level));
  const s = d.scan;
  let filter = params.get("show") || "fail";
  const body = h("div");
  const counts = { fail: 0, pass: 0, na: 0, error: 0 };
  (d.results || []).forEach(r => {
    if (r.result === "fail") counts.fail++; else if (r.result === "pass") counts.pass++;
    else if (r.result === "error") counts.error++; else counts.na++;
  });
  const tabs = [["fail", "Failed", counts.fail], ["error", "Errors", counts.error], ["pass", "Passed", counts.pass],
                ["na", "Not applicable", counts.na], ["all", "All", (d.results || []).length]];
  const tabBtns = tabs.map(([k, label, n]) => h("button", { type: "button", "data-k": k,
    on: { click: () => { filter = k; paint(); } } }, label + " (" + n + ")"));

  function detail(r) {
    return h("div", { class: "hd-detail" },
      r.description ? h("p", null, r.description) : null,
      r.rationale ? h("p", null, h("strong", null, "Why it matters: "), r.rationale) : null,
      h("p", { class: "muted small" },
        (r.cis_ref ? "CIS " + r.cis_ref + " \u00b7 " : "") + "Rule " + r.rule_id.replace("xccdf_org.ssgproject.content_rule_", "")
        + " \u00b7 " + (r.fix_available ? "an automated fix exists" : "no automated fix; fix by hand")),
      r.risky && r.result === "fail" ? h("p", { class: "hd-risky-note" },
        "Changing this can lock out logins, cut network access or stop services. Test the fix on one server first.") : null);
  }

  function paint() {
    tabBtns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === filter)));
    const rows = (d.results || []).filter(r => filter === "all" || r.result === filter
      || (filter === "na" && !["pass", "fail", "error"].includes(r.result)));
    if (!rows.length) { body.replaceChildren(h("div", { class: "empty" }, h("p", null, "Nothing here."))); return; }
    const t = table([
      { label: "Result", nowrap: true, cell: r => resultChip(r.result) },
      { label: "Rule", cell: r => r.title || r.rule_id },
      { label: "CIS", nowrap: true, cell: r => r.cis_ref || "" },
      { label: "Severity", nowrap: true, cell: r => sevChip(r.severity) },
      { label: "", nowrap: true, cell: r => r.risky && r.result === "fail" ? h("span", { class: "hd-risky" }, "risky to fix") : "" },
    ], rows, { onRow: (r, tr) => {
      const next = tr.nextElementSibling;
      if (next && next.classList.contains("hd-detail-row")) { next.remove(); return; }
      const td = h("td", { colspan: "5" }, detail(r));
      tr.after(h("tr", { class: "hd-detail-row" }, td));
    } });
    body.replaceChildren(h("p", { class: "muted small" }, "Click a rule for what it checks and why."), t);
  }

  const hist = (d.history || []).slice().reverse().filter(x => x.state === "done");
  const live = (d.history || [])[0];
  const liveRow = live && (live.state === "queued" || live.state === "running")
    ? Object.assign({}, live, { last_state: live.state, last_requested: live.requested_at }) : null;
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl harden --host " + d.host.hostname }, d.host.hostname),
      h("div", { class: "head-actions" },
        levelPicker(level, l => { location.hash = "#/hardening/host/" + hostId + "?level=" + encodeURIComponent(l); }),
        can("operator") ? h("button", { type: "button", class: "btn",
          on: { click: e => queueScans(level, [hostId], e.target, () => renderHardeningHost(hostId, params)) } }, "Scan now") : null,
        h("a", { href: "#/hardening?level=" + level }, "All servers"))),
    liveRow ? h("div", { class: "hd-live" }, h("span", { class: "hd-card-l" }, "Scan in progress"), scanProgress(liveRow)) : null,
    s ? h("div", { class: "hd-cards" },
      h("div", { class: "hd-card hd-card-main" }, h("div", { class: "hd-card-l" }, "Score"),
        h("div", { class: "hd-card-n" }, scoreBadge(s.score)),
        h("div", { class: "muted small" }, s.passed + " passed, " + s.failed + " failed, " + s.not_applicable + " not applicable"),
        trendSvg(hist.map(x => ({ score: x.score })))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Scanned"),
        h("div", null, fmtDateTime(s.finished_at)), h("div", { class: "muted small" }, timeAgo(s.finished_at)
          + (s.requested_by ? ", requested by " + s.requested_by : ""))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Benchmark"),
        h("div", null, s.product + " \u00b7 SSG " + s.content_version),
        h("div", { class: "muted small" }, s.profile_id.replace("xccdf_org.ssgproject.content_profile_", "") + ", oscap " + (s.oscap_version || "?"))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Evidence"),
        h("div", { class: "muted small hd-hash", title: "SHA-256 of the full result file kept on PATCH-01" },
          "SHA-256 " + (s.evidence_sha256 || "").slice(0, 16) + "\u2026"),
        h("div", { class: "muted small" }, "Full result file kept for audit.")))
      : h("div", { class: "empty" }, h("p", null, "No completed " + level.toUpperCase() + " scan for this server yet."),
          (d.history || [])[0] && d.history[0].state === "failed" ? h("p", { class: "hd-failed" }, "Last attempt failed: " + d.history[0].error) : null),
    s ? h("div", { class: "filters", role: "group", "aria-label": "Show" }, tabBtns) : null,
    s ? body : null);
  if (s) paint();
  if (liveRow) {
    setPageTimer(async () => {
      if (!location.hash.startsWith("#/hardening/host/" + hostId)) return clearPageTimer();
      const y = window.scrollY;
      await renderHardeningHost(hostId, params);
      window.scrollTo(0, y);
    }, 5000);
  } else if (location.hash.startsWith("#/hardening/host/")) {
    clearPageTimer();
  }
}

// ---- one rule --------------------------------------------------------------
async function renderHardeningRule(ruleId, params) {
  setNav("hardening");
  const level = hLevel(params);
  const d = await api("/hardening/rules/" + encodeURIComponent(ruleId) + "?level=" + encodeURIComponent(level));
  const r = d.rule;
  const failing = d.servers.filter(x => x.result === "fail");
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl harden --rule" }, r.title || r.rule_id),
      h("a", { href: "#/hardening?level=" + level }, "All rules")),
    h("div", { class: "hd-rule-meta" }, sevChip(r.severity), r.cis_ref ? h("span", null, "CIS " + r.cis_ref) : null,
      r.risky ? h("span", { class: "hd-risky" }, "risky to fix") : null,
      h("span", { class: "muted" }, r.fix_available ? "automated fix available" : "fix by hand")),
    r.description ? h("p", null, r.description) : null,
    r.rationale ? h("p", null, h("strong", null, "Why it matters: "), r.rationale) : null,
    r.risky ? h("p", { class: "hd-risky-note" }, "Fixing this can lock out logins, cut network access or stop services. "
      + "Test on one server first.") : null,
    h("h2", null, "Servers (" + failing.length + " failing of " + d.servers.length + ")"),
    d.servers.length ? table([
      { label: "Server", cell: x => h("a", { href: "#/hardening/host/" + x.host_id + "?level=" + level }, x.hostname) },
      { label: "Result", nowrap: true, cell: x => resultChip(x.result) },
      { label: "Benchmark", nowrap: true, cell: x => x.product },
      { label: "Scanned", nowrap: true, cell: x => timeAgo(x.finished_at) },
    ], d.servers) : h("div", { class: "empty" }, h("p", null, "No server's latest scan includes this rule.")));
}

// ---- mail alerts (admin) ---------------------------------------------------
async function renderMail(params) {
  setNav("mail");
  let d = await api("/admin/mail");
  const c = d.settings;
  const f = {};                                   // form fields by name
  const inp = (name, attrs) => (f[name] = h("input", Object.assign({ name }, attrs)));
  const chk = (name, on, label) => h("label", { class: "check" },
    (f[name] = h("input", { type: "checkbox", name, checked: on })), h("span", null, label));
  const field = (label, el, hint) => h("label", null, h("span", null, label), el, hint ? h("span", { class: "muted small" }, hint) : null);

  inp("host", { type: "text", value: c.host || "", placeholder: "smtp-relay.corp.local" });
  inp("port", { type: "number", min: "1", max: "65535", value: String(c.port || 25) });
  f.tls = h("select", { name: "tls" }, [["starttls", "STARTTLS (port 587, or 25)"], ["tls", "TLS from the start (port 465)"],
    ["none", "None (plain internal relay)"]].map(([v, l]) => h("option", { value: v, selected: c.tls === v }, l)));
  inp("username", { type: "text", value: c.user || "", placeholder: "Blank if the relay accepts PATCH-01 by address",
                    autocomplete: "off" });
  inp("password", { type: "password", autocomplete: "new-password",
                    placeholder: c.password_set ? "Saved. Leave blank to keep it" : "Mailbox password" });
  const clearPw = c.password_set ? chk("clear_password", false, "Remove the saved password") : null;
  f.ca_pem = h("textarea", { name: "ca_pem", rows: "5", placeholder: "-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----" },
               c.ca_pem || "");
  inp("from_addr", { type: "text", value: c.from || "", placeholder: "patch01-alerts@corp.example" });
  inp("from_name", { type: "text", value: c.from_name || "", placeholder: "PATCH-01 Alerts" });
  inp("digest_time", { type: "text", value: c.digest_time || "07:00", pattern: "\\d{2}:\\d{2}" });
  f.weekly_day = h("select", { name: "weekly_day" }, ["mon", "tue", "wed", "thu", "fri", "sat", "sun"].map(v =>
    h("option", { value: v, selected: c.weekly_day === v }, v[0].toUpperCase() + v.slice(1))));
  inp("console_url", { type: "text", value: c.console || "", placeholder: "https://patch01.example" });
  inp("company", { type: "text", value: c.company === "PATCH-01" ? "" : (c.company || ""), placeholder: "Your Company Pte Ltd" });
  f.signature = h("textarea", { name: "signature", rows: "5", maxlength: "2000",
    placeholder: "Security Operations\nYour Company Pte Ltd\n+65 6000 0000 | secops@corp.example" }, c.signature || "");

  const values = () => {
    const pw = f.password.value;
    return {
      enabled: f.enabled.checked, host: f.host.value.trim(), port: Number(f.port.value || 25), tls: f.tls.value,
      verify: f.verify.checked, ca_pem: f.ca_pem.value.trim() || null, username: f.username.value.trim(),
      password: pw ? pw : (f.clear_password && f.clear_password.checked ? "" : null),
      from_addr: f.from_addr.value.trim(), from_name: f.from_name.value.trim(),
      send_critical: f.send_critical.checked, send_tasks: f.send_tasks.checked,
      send_digest: f.send_digest.checked, send_weekly: f.send_weekly.checked,
      digest_time: f.digest_time.value.trim(), weekly_day: f.weekly_day.value,
      console_url: f.console_url.value.trim(), company: f.company.value.trim(),
      signature: f.signature.value,
    };
  };

  // Test connection: step by step, with the values in the form, saved or not
  const steps = h("ol", { class: "mail-steps" });
  const checkBtn = h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
    checkBtn.disabled = true; steps.replaceChildren(h("li", { class: "muted" }, "Testing\u2026"));
    try {
      const r = await apiPost("/admin/mail/check", values());
      steps.replaceChildren(...r.steps.map(st => h("li", { class: st.ok ? "ms-ok" : "ms-bad" },
        h("strong", null, st.step), " ", st.detail)));
      if (r.ok) steps.append(h("li", { class: "ms-ok ms-final" }, h("strong", null, "Ready."),
        " The relay accepts mail from PATCH-01. Save, then send a test mail."));
    } catch (e) { steps.replaceChildren(h("li", { class: "ms-bad" }, e.message)); }
    checkBtn.disabled = false;
  } } }, "Test connection");

  const saveMsg = h("span", { class: "small" });
  const saveBtn = h("button", { type: "button", class: "btn", on: { click: async () => {
    saveBtn.disabled = true; saveMsg.className = "muted small"; saveMsg.textContent = "Saving\u2026";
    try {
      d = await apiSend("PUT", "/admin/mail", values());
      saveMsg.className = "hd-good small"; saveMsg.textContent = "Saved.";
      setTimeout(() => renderMail(params), 700);
    } catch (e) { saveMsg.className = "hd-failed"; saveMsg.textContent = e.message; }
    saveBtn.disabled = false;
  } } }, "Save settings");

  // Recipients
  const KINDS = [["critical", "Critical"], ["tasks", "Tasks"], ["digest", "Daily digest"], ["weekly", "Weekly"]];
  const rmsg = h("span", { class: "small" });
  const recTable = () => (d.recipients || []).length ? table([
    { label: "Address", cell: r => h("span", null, h("strong", null, r.address), r.name ? h("span", { class: "muted" }, " \u00b7 " + r.name) : null) },
    ...KINDS.map(([k, label]) => ({ label, nowrap: true, cell: r => {
      const cb = h("input", { type: "checkbox", checked: r[k], "aria-label": label + " for " + r.address });
      cb.addEventListener("change", async () => {
        try { d = await apiSend("PATCH", "/admin/mail/recipients/" + r.id, { [k]: cb.checked }); }
        catch (e) { cb.checked = !cb.checked; rmsg.className = "hd-failed"; rmsg.textContent = e.message; }
      });
      return cb;
    } })),
    { label: "", nowrap: true, cell: r => h("span", { class: "row-actions" },
        h("button", { type: "button", class: "btn-link", on: { click: async e => {
          const b = e.target; b.disabled = true; b.textContent = "Sending\u2026";
          try { await apiPost("/admin/mail/test", { to: r.address }); b.textContent = "Sent \u2713"; }
          catch (err) { b.textContent = "Test"; rmsg.className = "hd-failed"; rmsg.textContent = err.message; }
          setTimeout(() => { b.disabled = false; b.textContent = "Test"; }, 3000);
        } } }, "Test"),
        h("button", { type: "button", class: "btn-link", on: { click: async () => {
          if (!confirm("Stop sending mail to " + r.address + "?")) return;
          try { d = await apiSend("DELETE", "/admin/mail/recipients/" + r.id); showRecipients();
                rmsg.className = "muted small"; rmsg.textContent = r.address + " removed."; }
          catch (err) { rmsg.className = "hd-failed"; rmsg.textContent = err.message; }
        } } }, "Remove")) },
  ], d.recipients) : h("div", { class: "empty" }, h("p", null, "No recipients yet. Add at least one to turn mail on."));
  const recBox = h("div");
  const showRecipients = () => recBox.replaceChildren(recTable());
  const newAddr = h("input", { type: "text", placeholder: "name@corp.example", "aria-label": "New recipient address" });
  const newName = h("input", { type: "text", placeholder: "Name or team (optional)", "aria-label": "New recipient name" });
  const newKinds = KINDS.map(([k, label]) => h("label", { class: "check" }, h("input", { type: "checkbox", checked: true, "data-k": k }), h("span", null, label)));
  const addBtn = h("button", { type: "button", class: "btn", on: { click: async () => {
    const body = { address: newAddr.value.trim(), name: newName.value.trim() };
    newKinds.forEach(l => { const cb = l.querySelector("input"); body[cb.dataset.k] = cb.checked; });
    try {
      d = await apiPost("/admin/mail/recipients", body);
      showRecipients(); newAddr.value = ""; newName.value = ""; rmsg.className = "hd-good small";
      rmsg.textContent = body.address + " added.";
    } catch (e) { rmsg.className = "hd-failed"; rmsg.textContent = e.message; }
  } } }, "Add recipient");

  const w = d.worker;
  const STATE = { sent: ["Sent", "hr-pass"], queued: ["Queued", "hr-na"], failed: ["Failed", "hr-fail"] };
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl mail --setup" }, "Mail alerts"),
      h("span", { class: "muted small" }, c.updated_by ? "Last changed by " + c.updated_by + ", " + timeAgo(c.updated_at) : "")),
    !c.key_present ? h("div", { class: "form-warn" }, h("strong", null, "The mail key is missing. "),
      "A password cannot be saved until phase3b-api.sh has run on PATCH-01.") : null,
    h("div", { class: "form-sec" },
      h("label", { class: "check mail-enable" }, (f.enabled = h("input", { type: "checkbox", name: "enabled", checked: c.enabled })),
        h("span", null, h("strong", null, "Send mail alerts"), h("span", { class: "muted small" },
          c.enabled ? " \u00b7 on" : " \u00b7 off: nothing is sent until this is ticked and saved")))),
    h("div", { class: "form-sec" }, h("h2", null, "1. Relay"),
      h("div", { class: "af-row" }, field("Relay host", f.host), field("Port", f.port), field("Encryption", f.tls)),
      h("div", { class: "af-row" }, field("Login (the mailbox)", f.username), field("Password", f.password,
        "Stored encrypted on PATCH-01; never shown again.")),
      clearPw,
      h("details", { class: "mail-adv", open: !!c.ca_pem || c.verify === false },
        h("summary", null, "Certificate checks"),
        chk("verify", c.verify !== false, "Check the relay's certificate (recommended)"),
        field("CA certificate, if the relay's certificate comes from an internal CA", f.ca_pem,
          "Paste the PEM text. Leave blank for a publicly trusted certificate."))),
    h("div", { class: "form-sec" }, h("h2", null, "2. Sender"),
      h("div", { class: "af-row" }, field("From address (the mailbox)", f.from_addr), field("From name", f.from_name),
        field("Company name in mail", f.company)),
      field("Console address, for links in mail", f.console_url),
      field("Signature, added to every mail: alerts, digests and reports", f.signature)),
    h("div", { class: "form-actions" }, checkBtn, h("span", { class: "muted small" }, "Uses the values above, saved or not. Sends nothing.")),
    steps,
    h("div", { class: "form-sec" }, h("h2", null, "3. What to send"),
      chk("send_critical", c.critical, "Critical alerts, within a minute"),
      chk("send_tasks", c.tasks, "Task updates: changes started and finished, scans completed"),
      chk("send_digest", c.digest, "Daily digest"),
      chk("send_weekly", c.weekly, "Weekly summary"),
      h("div", { class: "af-row" }, field("Digest time (Singapore, 24-hour)", f.digest_time), field("Weekly summary day", f.weekly_day))),
    h("div", { class: "form-actions" }, saveBtn, saveMsg),
    h("h2", null, "4. Recipients"),
    h("p", { class: "muted small" }, "Choose who gets each kind of mail. Changes apply at once and are recorded in Activity."),
    recBox,
    h("div", { class: "mail-add" }, newAddr, newName, h("span", { class: "mail-kinds" }, newKinds), addBtn),
    rmsg,
    h("h2", null, "Recent mail"),
    h("p", { class: "muted small" }, (d.counts_7d.sent || 0) + " sent, " + (d.counts_7d.queued || 0) + " queued, "
      + (d.counts_7d.failed || 0) + " failed in the last 7 days"
      + (w ? " \u00b7 the worker last checked " + timeAgo(w.beat_at) : "")),
    (d.recent || []).length ? table([
      { label: "When", nowrap: true, cell: n => fmtDateTime(n.created_at) },
      { label: "Kind", nowrap: true, cell: n => ({ critical: "Critical", task: "Task", digest: "Daily digest", weekly: "Weekly",
                                                   system: "System", test: "Test" })[n.category] || n.category },
      { label: "Subject", cell: n => n.subject.replace("[PATCH-01] ", "") },
      { label: "State", nowrap: true, cell: n => { const [l, cls] = STATE[n.state] || [n.state, "hr-na"];
          return h("span", { class: "hd-res " + cls }, l + (n.state === "queued" && n.attempts ? " (retry " + n.attempts + ")" : "")); } },
      { label: "Problem", cell: n => n.last_error ? h("span", { class: "hd-failed" }, n.last_error) : "" },
    ], d.recent) : h("div", { class: "empty" }, h("p", null, "No mail sent yet.")));
  showRecipients();
}


// ---- reports ------------------------------------------------------------------
function fmtAge(iso) {
  const m = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  return m < 2 ? "just now" : m < 120 ? m + " min ago" : m < 2880 ? Math.round(m / 60) + " h ago" : Math.round(m / 1440) + " days ago";
}
function fmtBytes(n) { return n >= 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB"; }

async function downloadReport(id, btn) {
  // A link cannot carry the sign-in token, so fetch the file and hand it over
  const was = btn ? btn.textContent : null;
  if (btn) { btn.disabled = true; btn.textContent = "Downloading\u2026"; }
  try {
    const res = await fetch("/api/v1/reports/" + id + "/download", { headers: { ...authHeaders(), "X-Requested-With": "patch01-dashboard" } });
    if (!res.ok) { let d = ""; try { d = detailText((await res.json()).detail); } catch (e) { /* not JSON */ } throw new Error(d || res.statusText); }
    const cd = res.headers.get("Content-Disposition") || "";
    const m = /filename="?([^";]+)"?/.exec(cd);
    const blob = await res.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = m ? m[1] : "report";
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 30000);
  } catch (e) { alert(e.message); }
  if (btn) { btn.disabled = false; btn.textContent = was; }
}

function reportPanel(level, hosts) {
  let detailWrap;
  const groups = [...new Set(hosts.map(x => x.host_group).filter(Boolean))].sort();
  const scope = h("select", { "aria-label": "Report scope" },
    h("option", { value: "all" }, "All servers"),
    ...groups.map(g => h("option", { value: "g:" + g }, "Group: " + g)),
    h("option", { value: "attention" }, "Servers below 85%"));
  const style = h("select", { "aria-label": "Report type" },
    h("option", { value: "management" }, "Management summary: pass and fail, no fixes"),
    h("option", { value: "technical" }, "Technical detail: findings with how to fix"));
  const detail = h("select", { "aria-label": "Findings to include" },
    h("option", { value: "high_medium" }, "High and medium findings in detail"),
    h("option", { value: "all" }, "Every finding in detail"),
    h("option", { value: "high" }, "High findings only in detail"));
  const label = h("input", { type: "text", placeholder: "Title for the cover, e.g. Production Linux fleet", maxlength: "80" });
  const out = h("div", { class: "rep-out" });
  const go = fmt => async e => {
    const btn = e.target; btn.disabled = true; const was = btn.textContent; btn.textContent = "Building\u2026";
    out.replaceChildren(h("span", { class: "muted small" }, "Building the report from the latest scans\u2026"));
    const body = { level, format: fmt, detail: detail.value, style: style.value, scope_label: label.value.trim() || null };
    if (scope.value.startsWith("g:")) body.host_group = scope.value.slice(2);
    if (scope.value === "attention") {
      body.host_ids = hosts.filter(x => x.score !== null && Number(x.score) < 85).map(x => x.id);
      body.scope_label = body.scope_label || "Servers below 85%";
      if (!body.host_ids.length) { out.replaceChildren(h("span", { class: "hd-good small" }, "No scanned server is below 85%.")); btn.disabled = false; btn.textContent = was; return; }
    }
    try {
      const r = await apiPost("/reports/hardening", body);
      const dl = h("button", { type: "button", class: "btn", on: { click: ev => downloadReport(r.id, ev.target) } }, "Download " + (fmt === "pdf" ? "PDF" : "Word"));
      out.replaceChildren(h("div", { class: "rep-ready" },
        h("strong", null, r.report_id), " \u00b7 " + r.servers + " server" + (r.servers === 1 ? "" : "s")
          + (r.pages ? " \u00b7 " + r.pages + " pages" : "") + " \u00b7 " + fmtBytes(r.size_bytes), dl,
        can("operator") ? h("button", { type: "button", class: "btn btn-quiet", on: { click: () => emailReport(r.id) } }, "Email this report") : null,
        h("div", { class: "muted small hd-hash" }, "SHA-256 " + r.sha256)));
      downloadReport(r.id);
      const arch = document.querySelector(".rep-archive"); if (arch) loadArchive(arch.parentNode);
    } catch (err) { out.replaceChildren(h("span", { class: "hd-failed" }, err.message)); }
    btn.disabled = false; btn.textContent = was;
  };
  const panel = h("div", { class: "rep-panel", hidden: true },
    h("div", { class: "rep-row" },
      h("label", null, h("span", null, "Report type"), style),
      h("label", null, h("span", null, "Scope"), scope),
      (detailWrap = h("label", { hidden: true }, h("span", null, "Findings in detail"), detail)),
      h("label", { class: "rep-wide" }, h("span", null, "Cover title (optional)"), label)),
    h("div", { class: "rep-row" },
      h("button", { type: "button", class: "btn", on: { click: go("pdf") } }, "PDF"),
      h("button", { type: "button", class: "btn btn-quiet", on: { click: go("docx") } }, "Word"),
      h("button", { type: "button", class: "btn btn-quiet", title: "The server list on this page, with the logo heading",
                    on: { click: () => runExport("csv", out) } }, "CSV"),
      h("span", { class: "muted small" }, levelName(level)
        + ", from each server's latest scan. The logo and company details come from Admin \u203a Branding.")),
    out);
  style.addEventListener("change", () => { detailWrap.hidden = style.value !== "technical"; });
  return panel;
}

async function loadArchive(box) {
  try {
    const d = await api("/reports");
    const rows = (d.reports || []).slice(0, 15);
    box.replaceChildren(rows.length ? h("div", { class: "rep-archive" }, table([
      { label: "Report", nowrap: true, cell: r => h("strong", null, r.report_ref || ("#" + r.number)) },
      { label: "Type", nowrap: true, cell: r => r.style === "technical" ? "Technical" : "Management" },
      { label: "Title", cell: r => (r.title || "").replace("CIS Hardening Report, ", "").replace(/(Management summary|Technical detail), /, "") },
      { label: "Format", nowrap: true, cell: r => r.format === "pdf" ? "PDF" : "Word" },
      { label: "Servers", num: true, cell: r => r.servers },
      { label: "Score", num: true, cell: r => r.score === null ? "\u2013" : Number(r.score).toFixed(1) + "%" },
      { label: "By", nowrap: true, cell: r => r.generated_by },
      { label: "When", nowrap: true, cell: r => timeAgo(r.generated_at) },
      { label: "", nowrap: true, cell: r => h("span", { class: "row-actions" },
          h("button", { type: "button", class: "btn-link", on: { click: e => downloadReport(r.id, e.target) } }, "Download"),
          can("operator") && r.report_ref ? h("button", { type: "button", class: "btn-link", on: { click: () => emailReport(r.id) } }, "Email") : null) },
    ], rows)) : h("div", { class: "empty rep-archive" }, h("p", null, "No reports yet. Use Export above.")));
  } catch (e) { box.replaceChildren(h("p", { class: "hd-failed" }, e.message)); }
}

// ---- admin: tabs, branding ------------------------------------------------------
function adminTabs(active) {
  // The section's pages are tabs in the sub-bar under the menu (sectionNav): nothing to add here
  if (typeof sectionNav === "function") sectionNav(active);
}

async function renderBranding(params) {
  setNav("admin");
  const d = await api("/admin/branding");
  const e = d.effective, sv = d.saved || {};
  const m = e.logo_meta;
  const company = h("input", { type: "text", value: sv.company || "", placeholder: "Your Company Pte Ltd", maxlength: "120" });
  const copy = h("input", { type: "text", value: sv.copyright || "", placeholder: e.copyright, maxlength: "200" });
  const CLS = ["CONFIDENTIAL", "INTERNAL", "RESTRICTED", "PUBLIC"];
  const cls = h("select", null, CLS.map(c => h("option", { value: c, selected: (sv.classification || "CONFIDENTIAL") === c }, c)));
  const own = h("input", { type: "checkbox", checked: !!sv.accent });
  const colour = h("input", { type: "color", value: sv.accent || e.accent || "#1F5AA6", disabled: !sv.accent });
  own.addEventListener("change", () => { colour.disabled = !own.checked; });
  const img = h("img", { class: "brand-logo", alt: "Processed logo" });
  const imgW = h("img", { class: "brand-logo brand-dark", alt: "Logo on a dark background" });
  async function loadImg(el, variant) {
    try {
      const res = await fetch("/api/v1/branding/logo?variant=" + variant, { headers: authHeaders() });
      if (res.ok) el.src = URL.createObjectURL(await res.blob()); else el.remove();
    } catch (err) { el.remove(); }
  }
  const msg = h("span", { class: "small" });
  const save = h("button", { type: "button", class: "btn", on: { click: async () => {
    save.disabled = true;
    try {
      await apiSend("PUT", "/admin/branding", { company: company.value.trim(), copyright: copy.value.trim(),
        classification: cls.value, accent: own.checked ? colour.value.toUpperCase() : null });
      msg.className = "hd-good small"; msg.textContent = "Saved. New reports use it at once.";
      setTimeout(() => renderBranding(params), 800);
    } catch (err) { msg.className = "hd-failed"; msg.textContent = err.message; }
    save.disabled = false;
  } } }, "Save");
  const fact = (k, v) => h("div", { class: "brand-fact" }, h("span", { class: "muted small" }, k), h("span", null, v));
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl branding" }, "Branding")),
    h("h2", null, "Logo"),
    m ? h("div", { class: "brand-grid" },
      h("div", { class: "brand-previews" },
        h("div", { class: "brand-light" }, img),
        h("div", { class: "brand-navy" }, e.has_logo_white || !m.dark ? imgW
          : h("div", { class: "brand-plate" }, h("img", { class: "brand-logo", alt: "", src: "" }))),
        h("p", { class: "muted small" }, e.has_logo_white ? "On dark backgrounds: " + e.logo_white_file
          : (m.dark ? "Dark logo: on the navy cover it sits on a white plate so it stays visible."
                    : "Light logo: used directly on dark backgrounds."))),
      h("div", null,
        fact("File", e.logo_file), fact("Original", m.original[0] + " \u00d7 " + m.original[1] + " px, " + fmtBytes(m.bytes_in)),
        fact("As used", m.size[0] + " \u00d7 " + m.size[1] + " px, " + fmtBytes(m.bytes_out) + " (margins trimmed)"),
        fact("Background", m.transparent ? "transparent" : "solid"),
        fact("Main colour", m.accent ? h("span", null, h("span", { class: "brand-swatch", style: null, "data-c": m.accent }), " " + m.accent) : "none found"),
        ...(m.warnings || []).map(w => h("p", { class: "hd-risky-note" }, w))))
      : h("div", { class: "empty" }, h("p", null, e.logo_problem || "No logo yet."),
          h("p", { class: "muted" }, "Copy a PNG to " + d.folder + "/logo.png on PATCH-01. Any size works: PATCH-01 "
            + "trims the margins and scales it. For dark backgrounds you can add logo-white.png as well.")),
    m ? h("p", { class: "muted small" }, "To change it, replace the file in " + d.folder
      + " on PATCH-01. It is picked up the next time a report is made.") : null,
    h("div", { class: "form-sec" }, h("h2", null, "Company"),
      h("label", null, h("span", null, "Company name"), company),
      h("label", null, h("span", null, "Copyright line (footer of every page)"), copy),
      h("label", null, h("span", null, "Classification (header, footer and cover)"), cls),
      h("label", { class: "check" }, own, h("span", null, "Choose the accent colour myself")),
      h("label", null, h("span", null, "Accent colour " + (e.accent_source === "logo" ? "(now taken from the logo: " + e.accent + ")" : "")), colour)),
    h("div", { class: "form-actions" }, save, msg));
  if (m) {
    loadImg(img, "main");
    if (e.has_logo_white || !m.dark) loadImg(imgW, e.has_logo_white ? "white" : "main");
    else loadImg(document.querySelector(".brand-plate img"), "main");
    document.querySelectorAll(".brand-swatch").forEach(x => { x.style.background = x.dataset.c; });
  }
}


// ---- e-mailing a report ---------------------------------------------------------------
async function emailReport(reportId) {
  document.querySelectorAll(".mw-back").forEach(x => x.remove());
  const close = () => back.remove();
  const status = h("p", { class: "mw-status" }, "Loading\u2026");
  const summaryBox = h("div", { class: "mw-summary" }, h("p", { class: "muted small" }, "Loading the report\u2026"));
  const to = h("input", { type: "text", placeholder: "name@corp.example, another@corp.example", list: "mw-recips" });
  const cc = h("input", { type: "text", placeholder: "Optional", list: "mw-recips" });
  const subject = h("input", { type: "text", maxlength: "200" });
  const text = h("textarea", { rows: "9", placeholder: "The message appears here." });
  const sig = h("pre", { class: "mw-sig" });
  const att = h("div", { class: "mw-att" });
  const recips = h("datalist", { id: "mw-recips" });
  const picks = h("div", { class: "mw-picks" });
  const msg = h("div", { class: "small" });
  const send = h("button", { type: "button", class: "btn", disabled: true }, "Send with report attached");
  const redraft = h("button", { type: "button", class: "btn btn-quiet", disabled: true,
    title: "AI-01 rewrites the message from the report's figures; it can take up to a minute" }, "Polish with AI-01");
  const box = h("div", { class: "mw", role: "dialog", "aria-modal": "true", "aria-label": "E-mail this report" },
    h("div", { class: "mw-head" }, h("h2", null, "E-mail this report"),
      h("button", { type: "button", class: "btn-link", on: { click: close } }, "Close")),
    h("div", { class: "mw-grid" },
      h("div", null, h("h3", null, "Report at a glance"), summaryBox, att),
      h("div", null,
        h("label", null, h("span", null, "To"), to), picks,
        h("label", null, h("span", null, "Cc"), cc),
        h("label", null, h("span", null, "Subject"), subject),
        status,
        h("label", null, h("span", null, "Message"), text),
        h("div", { class: "mw-sigwrap" }, h("span", { class: "muted small" }, "Signature, added automatically (Admin \u203a Mail)"), sig),
        h("div", { class: "form-actions" }, send, redraft), msg)),
    recips);
  const back = h("div", { class: "mw-back", on: { click: e => { if (e.target === back) close(); } } }, box);
  document.body.append(back);
  document.addEventListener("keydown", function esc(e) { if (e.key === "Escape") { close(); document.removeEventListener("keydown", esc); } });

  api("/mail/recipients").then(r => {
    (r.recipients || []).forEach(x => recips.append(h("option", { value: x.address }, x.name || "")));
    picks.replaceChildren(...(r.recipients || []).slice(0, 8).map(x => h("button", { type: "button", class: "mw-chip",
      on: { click: () => { const cur = to.value.split(/[,;]/).map(v => v.trim()).filter(Boolean);
                           if (!cur.includes(x.address)) cur.push(x.address); to.value = cur.join(", "); } } },
      "+ " + (x.name ? x.name : x.address))));
  }).catch(() => {});

  async function polish() {
    redraft.disabled = true; send.disabled = true;
    status.className = "mw-status"; status.replaceChildren(h("span", { class: "hd-pulse" }),
      " AI-01 is rewriting the message from the report's figures. On this hardware that can take up to a minute.");
    try {
      const d = await apiPost("/reports/" + reportId + "/email/polish", {});
      subject.value = d.subject; text.value = d.body;
      status.className = "mw-status " + (d.source === "ai" ? "mw-ai" : "mw-tpl"); status.replaceChildren(d.note);
    } catch (e) { status.className = "mw-status hd-failed"; status.replaceChildren(e.message); }
    redraft.disabled = false; send.disabled = false;
  }

  async function loadDraft() {
    status.hidden = false; redraft.disabled = true; send.disabled = true;
    try {
      const d = await apiPost("/reports/" + reportId + "/email/draft", {});
      summaryBox.replaceChildren(...d.summary.map(([k, v]) => h("div", { class: "mw-fact" },
        h("span", { class: "muted small" }, k), h("strong", null, v))));
      att.replaceChildren(h("span", { class: "muted small" }, "Attached: "), h("strong", null, d.attachment.file),
        " (" + fmtBytes(d.attachment.size_bytes) + ")");
      subject.value = d.subject; text.value = d.body;
      sig.textContent = d.signature || "No signature set yet.";
      status.hidden = false;
      status.className = "mw-status " + (d.source === "ai" ? "mw-ai" : "mw-tpl");
      status.replaceChildren(d.note);
      if (!d.ready) { msg.className = "hd-failed"; msg.textContent = "Mail is not set up yet: an admin can do it under Admin \u203a Mail."; }
      send.disabled = !d.ready;
    } catch (e) { status.className = "mw-status hd-failed"; status.replaceChildren(e.message); }
    redraft.disabled = false;
  }
  redraft.addEventListener("click", polish);
  send.addEventListener("click", async () => {
    const list = v => v.split(/[,;]/).map(x => x.trim()).filter(Boolean);
    if (!list(to.value).length) { msg.className = "hd-failed"; msg.textContent = "Add at least one recipient."; return; }
    send.disabled = true; send.textContent = "Sending\u2026";
    try {
      const r = await apiPost("/reports/" + reportId + "/email", { to: list(to.value), cc: list(cc.value),
                                                                 subject: subject.value.trim(), body: text.value });
      msg.className = "hd-good"; msg.textContent = "Sent to " + r.to.concat(r.cc).join(", ") + ". Recorded in Activity.";
      send.textContent = "Sent \u2713";
      setTimeout(close, 2500);
    } catch (e) { msg.className = "hd-failed"; msg.textContent = e.message; send.disabled = false; send.textContent = "Send with report attached"; }
  });
  to.focus();
  loadDraft();
}


// ---- custom profiles ---------------------------------------------------------------
const CP_HOW = { cis: ["CIS number", "cp-cis"], title: ["Title match", "cp-title"], ai: ["AI-01", "cp-ai"],
                 manual: ["Chosen", "cp-manual"], none: ["Manual check", "cp-none"], skipped: ["Not a check", "cp-skip"] };
const CP_PRODUCTS = [["rhel9", "RHEL 9"], ["rhel8", "RHEL 8"], ["rhel10", "RHEL 10"], ["ubuntu2204", "Ubuntu 22.04"],
                     ["ubuntu2404", "Ubuntu 24.04"]];

async function renderCustomList() {
  setNav("hardening");
  const d = await api("/hardening/custom");
  const rows = d.profiles || [];
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl harden --custom" }, "Custom profiles"),
      h("div", { class: "head-actions" },
        can("operator") ? h("a", { class: "btn", href: "#/hardening/custom/new" }, "New from a document") : null,
        h("a", { href: "#/hardening" }, "Hardening"))),
    h("p", { class: "muted" }, "A custom profile checks exactly the settings in a document you provide, such as your own "
      + "hardening standard or an auditor's checklist, instead of the whole CIS benchmark. Reports list its results in "
      + "the document's terms, and anything no scan can check is listed as a manual check."),
    rows.length ? table([
      { label: "Profile", cell: p => h("a", { href: "#/hardening/custom/" + p.id }, h("strong", null, p.name)) },
      { label: "State", nowrap: true, cell: p => h("span", { class: "hd-res " + (p.status === "active" ? "hr-pass" : "hr-na") },
          p.status === "active" ? "In use" : "Draft") },
      { label: "From", cell: p => p.source_file || "" },
      { label: "Lines", num: true, cell: p => p.lines },
      { label: "Matched", num: true, cell: p => p.matched },
      { label: "Version", num: true, cell: p => p.version },
      { label: "Changed", nowrap: true, cell: p => timeAgo(p.updated_at) + (p.updated_by ? ", " + p.updated_by : "") },
    ], rows) : h("div", { class: "empty" }, h("p", null, "No custom profiles yet.")));
}

async function renderCustomNew() {
  setNav("hardening");
  const name = h("input", { type: "text", maxlength: "120", placeholder: "Company Linux Standard v2" });
  const product = h("select", null, CP_PRODUCTS.map(([v, l]) => h("option", { value: v }, l)));
  const file = h("input", { type: "file", accept: ".txt,.csv,.docx" });
  const text = h("textarea", { rows: "8", placeholder: "Or paste the list here, one requirement per line:\n5.1.20 Ensure SSH root login is disabled\nPasswords must be at least 14 characters" });
  const msg = h("div", { class: "small" });
  const go = h("button", { type: "button", class: "btn", on: { click: async () => {
    if (!name.value.trim()) { msg.className = "hd-failed"; msg.textContent = "Give the profile a name."; return; }
    const fd = new FormData();
    fd.append("name", name.value.trim()); fd.append("product", product.value);
    if (file.files.length) fd.append("file", file.files[0]); else fd.append("text", text.value);
    go.disabled = true; msg.className = "muted small"; msg.textContent = "Reading the document and matching each line\u2026";
    try {
      const res = await fetch("/api/v1/hardening/custom", { method: "POST", body: fd,
        headers: { ...authHeaders(), "X-Requested-With": "patch01-dashboard" } });
      const dd = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(dd.detail) || res.statusText);
      location.hash = "#/hardening/custom/" + dd.id;
    } catch (e) { msg.className = "hd-failed"; msg.textContent = e.message; go.disabled = false; }
  } } }, "Read and match");
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl harden --custom --new" }, "New custom profile"),
      h("a", { href: "#/hardening/custom" }, "Custom profiles")),
    h("div", { class: "form-sec" },
      h("label", null, h("span", null, "Profile name"), name),
      h("label", null, h("span", null, "Benchmark the document's CIS numbers follow"), product,
        h("span", { class: "muted small" }, "CIS numbers differ between benchmarks, so this decides what 5.2.4 means.")),
      h("label", null, h("span", null, "Document (.txt, .csv or .docx)"), file),
      h("label", null, h("span", null, "Or paste the list"), text)),
    h("p", { class: "muted small" }, "Each line is matched to benchmark checks: by its CIS number first, then by its "
      + "wording. You review every match before the profile is used."),
    h("div", { class: "form-actions" }, go, msg));
}

async function renderCustomReview(pid) {
  setNav("hardening");
  let d = await api("/hardening/custom/" + pid);
  const canEdit = can("operator");
  let edit = canEdit && d.profile.status !== "active";
  const body = h("div");
  let filter = "all";
  const msg = h("div", { class: "small" });

  async function change(bodyObj, itemId) {
    try { d = await apiSend("PATCH", "/hardening/custom/" + pid + "/items/" + itemId, bodyObj); msg.textContent = ""; paint(); }
    catch (e) { msg.className = "hd-failed"; msg.textContent = e.message; }
  }
  function ruleLine(r) {
    return h("div", { class: "cp-rule" }, h("span", null, r.title), r.cis_ref ? h("span", { class: "muted small" }, " \u00b7 CIS " + r.cis_ref) : null);
  }
  function picker(it, cell) {
    const q = h("input", { type: "search", placeholder: "Search checks by words or CIS number", value: "" });
    const list = h("div", { class: "cp-results" });
    let timer = null;
    q.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(async () => {
      if (q.value.trim().length < 2) { list.replaceChildren(); return; }
      let r;
      try { r = await api("/hardening/custom/" + pid + "/search?q=" + encodeURIComponent(q.value.trim())); }
      catch (e) { list.replaceChildren(h("p", { class: "hd-failed" }, e.message)); return; }
      list.replaceChildren(...(r.rules || []).slice(0, 10).map(x => h("button", { type: "button", class: "cp-pick",
        on: { click: () => change({ rule_ids: [x.rule_id] }, it.id) } },
        x.title, x.cis_ref ? h("span", { class: "muted small" }, " \u00b7 CIS " + x.cis_ref) : null)));
      if (!(r.rules || []).length) list.replaceChildren(h("p", { class: "muted small" }, "No check matches those words."));
    }, 250); });
    cell.replaceChildren(q, list); q.focus();
  }

  function paint() {
    edit = canEdit && d.profile.status !== "active";
    const c = d.counts;
    counts.replaceChildren(...[
      h("span", null, h("strong", null, c.lines), " lines"),
      h("span", { class: "hr-pass" }, h("strong", null, c.matched), " matched to " + c.checks + " checks"),
      h("span", { class: "hr-error" }, h("strong", null, c.to_review), " to review"),
      h("span", { class: "muted" }, h("strong", null, c.manual), " manual checks"),
      c.skipped ? h("span", { class: "muted" }, h("strong", null, c.skipped), " not checks") : null].filter(Boolean));
    tabs.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === filter)));
    const items = d.items.filter(it => filter === "all" || (filter === "review" && ["low", "medium"].includes(it.confidence) && it.rule_ids.length)
      || (filter === "manual" && !it.rule_ids.length && it.matched_by !== "skipped") || (filter === "matched" && it.rule_ids.length));
    body.replaceChildren(items.length ? table([
      { label: "#", num: true, cell: it => it.line_no },
      { label: "Requirement in the document", cell: it => h("span", { class: it.matched_by === "skipped" ? "muted" : null }, it.source_text) },
      { label: "Checked by", cell: it => {
          const cell = h("div", null, it.rules.length ? it.rules.map(ruleLine) : h("span", { class: "muted small" },
            it.matched_by === "skipped" ? "\u2013" : "Nothing automatic: listed in reports as a manual check"),
            it.note && (it.confidence === "low" || it.matched_by === "ai") ? h("div", { class: "hd-risky-note small" }, it.note) : null);
          cell.dataset.item = it.id;
          return cell; } },
      { label: "How", nowrap: true, cell: it => { const [l, cls] = CP_HOW[it.matched_by] || [it.matched_by, "cp-none"];
          return h("span", { class: "cp-how " + cls + (it.confidence === "low" ? " cp-low" : "") }, l + (it.confidence === "low" ? " ?" : "")); } },
      edit ? { label: "", nowrap: true, cell: it => h("span", { class: "row-actions" },
          h("button", { type: "button", class: "btn-link", on: { click: e => picker(it, e.target.closest("tr").querySelector("[data-item]")) } },
            it.rule_ids.length ? "Change" : "Pick check"),
          !it.rule_ids.length && it.matched_by !== "skipped" ? h("button", { type: "button", class: "btn-link", on: { click: async e => {
            const b = e.target; b.disabled = true; b.textContent = "AI-01\u2026";
            try { const r = await apiPost("/hardening/custom/" + pid + "/items/" + it.id + "/suggest", {});
                  d = r.view; msg.className = r.ok ? "hd-good small" : "muted small"; msg.textContent = r.note; paint(); }
            catch (err) { msg.className = "hd-failed"; msg.textContent = err.message; b.disabled = false; b.textContent = "Ask AI-01"; }
          } } }, "Ask AI-01") : null,
          it.rule_ids.length ? h("button", { type: "button", class: "btn-link", on: { click: () => change({ rule_ids: [] }, it.id) } }, "Clear") : null,
          h("button", { type: "button", class: "btn-link", on: { click: () => change({ skip: it.matched_by !== "skipped" }, it.id) } },
            it.matched_by === "skipped" ? "It is a check" : "Not a check")) } : null,
    ].filter(Boolean), items) : h("div", { class: "empty" }, h("p", null, "Nothing here.")));
    const p = d.profile;
    state.replaceChildren(h("span", { class: "hd-res " + (p.status === "active" ? "hr-pass" : "hr-na") },
      p.status === "active" ? "In use, version " + p.version : "Draft, not used yet"));
    act.replaceChildren(canEdit ? (p.status === "active"
      ? h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
          try { d = await apiPost("/hardening/custom/" + pid + "/state", { status: "draft" }); paint(); }
          catch (e) { msg.className = "hd-failed"; msg.textContent = e.message; } } } }, "Edit (back to draft)")
      : h("button", { type: "button", class: "btn", on: { click: async () => {
          try { d = await apiPost("/hardening/custom/" + pid + "/state", { status: "active" }); await loadCustoms(); paint();
                msg.className = "hd-good small"; msg.textContent = "In use. Choose it from the profile list on the Hardening page to scan with it."; }
          catch (e) { msg.className = "hd-failed"; msg.textContent = e.message; } } } }, "Use this profile")) : null,
      p.status === "active" ? h("a", { class: "btn btn-quiet", href: "#/hardening?level=" + encodeURIComponent("custom:" + p.id) }, "Scan with it") : null);
  }
  const counts = h("div", { class: "cp-counts" });
  const state = h("span");
  const act = h("div", { class: "head-actions" });
  const tabs = [["all", "All"], ["review", "To review"], ["matched", "Matched"], ["manual", "Manual checks"]].map(([k, l]) =>
    h("button", { type: "button", "data-k": k, on: { click: () => { filter = k; paint(); } } }, l));
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl harden --custom --review" }, d.profile.name),
      h("a", { href: "#/hardening/custom" }, "Custom profiles")),
    h("p", { class: "muted" }, "From " + (d.profile.source_file || "pasted text") + " \u00b7 CIS numbers read as " + d.product_name
      + ". Check each match, then use the profile. Lines marked with ? matched by number but read differently: confirm them."),
    h("div", { class: "cp-bar" }, counts, state, act), msg,
    h("div", { class: "filters", role: "group", "aria-label": "Show" }, tabs),
    body);
  paint();
}


// ---- Windows servers: installed updates, in full -----------------------------------
function winInstalled(d) {
  const all = d.installed || [];
  if (!all.length) return null;
  const RES = { "Succeeded": "hr-pass", "Installed": "hr-pass", "Succeeded with errors": "hr-na", "Failed": "hr-fail", "Aborted": "hr-error" };
  const q = h("input", { type: "search", placeholder: "Filter: KB, title, type, who", "aria-label": "Filter the installed updates", class: "win-inst-q" });
  const box = h("div");
  const paint = () => {
    const words = q.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
    const shown = words.length ? all.filter(u => { const t = [u.kb, u.title, u.kind, u.installed_by, u.result].join(" ").toLowerCase(); return words.every(w => t.includes(w)); }) : all;
    box.replaceChildren(shown.length ? table([
      { label: "Update", cell: u => h("span", null, u.kb ? h("strong", { class: "mono" }, u.kb) : null, u.kb && u.title ? " " : null,
                                         u.title ? u.title : (u.kb ? null : h("span", { class: "muted" }, "\u2013"))) },
      { label: "Type", cell: u => u.kind || h("span", { class: "muted" }, "\u2013") },
      { label: "Installed on", nowrap: true, cell: u => u.installed_on ? h("span", { title: fmtDateTime(u.installed_on) }, fmtDateTime(u.installed_on)) : h("span", { class: "muted" }, "not recorded") },
      { label: "Installed by", cell: u => u.installed_by || h("span", { class: "muted" }, "\u2013") },
      { label: "Result", nowrap: true, cell: u => u.result ? h("span", { class: "hd-res " + (RES[u.result] || "hr-na") }, u.result) : "" },
    ], shown) : h("p", { class: "muted small" }, "No installed update matches."));
  };
  q.addEventListener("input", paint);
  paint();
  return h("details", { class: "win-kbs", open: true },
    h("summary", null, "Installed updates (" + all.length + ")"),
    d.installed_detailed ? h("p", { class: "muted small" }, "From the server's installed-updates list and Windows Update's history (newest first). "
        + "Updates Windows Update tried but could not install are listed with their result.")
      : h("p", { class: "form-warn small" }, "This server's agent reports the update numbers (KBs) only. Agent 1.9.0 also reports each update's title, "
        + "date, who installed it and the result: send it from Servers > Update agents."),
    q, box);
}

// ---- Windows servers: build, update source, missing updates -------------------------
async function windowsPanel(hostId) {
  let d;
  try { d = await api("/admin/hosts/" + encodeURIComponent(hostId) + "/windows"); } catch (e) { return; }   // not Windows
  const h_ = d.host, miss = d.missing || [];
  const SEV = { Critical: "hr-fail", Important: "hr-error", Moderate: "hr-na", Low: "hr-na" };
  const panel = h("section", { class: "win-panel" },
    h("h2", null, "Patches (Windows Update)"),
    h("div", { class: "hd-cards" },
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "OS build"), h("div", { class: "hd-card-v" }, h_.build || "\u2013"),
        h("div", { class: "muted small" }, h_.os_edition || "")),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Updates from"),
        h("div", null, h_.wu_source === "wsus" ? "WSUS" : h_.wu_source === "microsoft" ? "Microsoft Update" : "\u2013"),
        h("div", { class: "muted small" }, h_.wu_server || "")),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Missing updates"),
        h("div", { class: "hd-card-v" + (miss.length ? " hd-failed" : "") }, String(miss.length)),
        h("div", { class: "muted small" }, h_.wu_searched_at ? "searched " + timeAgo(h_.wu_searched_at) : "not searched yet")),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Reboot"),
        h("div", null, h_.reboot_required ? "Pending" : "Not needed"))),
    h_.wu_error ? h("div", { class: "form-warn" }, h("strong", null, "Last Windows Update search failed: "), h_.wu_error) : null,
    h("p", { class: "muted small" }, "Missing updates are what Windows Update reports against "
      + (h_.wu_source === "wsus" ? "your WSUS, so they are the updates WSUS has approved for this server." : "Microsoft Update.")
      + " They are what a patch job installs. CVEs are under Vulnerabilities below: they come from the OS build compared "
      + "with Microsoft's Security Update Guide, so they can name updates WSUS has not approved yet."),
    miss.length ? table([
      { label: "Update", cell: u => h("span", null, h("strong", null, u.kb || ""), " ", u.title) },
      { label: "Severity", nowrap: true, cell: u => u.severity ? h("span", { class: "hd-res " + (SEV[u.severity] || "hr-na") }, u.severity) : h("span", { class: "muted" }, "\u2013") },
      { label: "CVEs", num: true, cell: u => (u.cves || []).length || "" },
      { label: "Reboot", nowrap: true, cell: u => ({ always: "Yes", may: "Maybe", never: "No" })[u.reboot_behaviour] || "" },
      { label: "Size", num: true, cell: u => u.size_mb ? u.size_mb + " MB" : "" },
      { label: "Downloaded", nowrap: true, cell: u => u.downloaded ? "Yes" : "No" },
    ], miss) : h("div", { class: "empty" }, h("p", null, h_.wu_searched_at ? "Nothing missing." : "The agent has not reported yet.")),
    winInstalled(d));
  // Installed software, with a filter
  let sw = [];
  try { sw = (await api("/admin/hosts/" + encodeURIComponent(hostId) + "/software")).software || []; } catch (e) { sw = []; }
  if (sw.length) {
    const box = h("div");
    const filt = h("input", { type: "search", placeholder: "Filter by name or publisher", "aria-label": "Filter software" });
    const paintSw = () => {
      const q = filt.value.trim().toLowerCase();
      const rows = sw.filter(x => !q || x.name.toLowerCase().includes(q) || (x.publisher || "").toLowerCase().includes(q));
      box.replaceChildren(table([
        { label: "Program", cell: x => h("strong", null, x.name) },
        { label: "Version", nowrap: true, cell: x => x.version || "\u2013" },
        { label: "Publisher", cell: x => x.publisher || "" },
        { label: "Installed", nowrap: true, cell: x => x.installed_on ? dayLabel(x.installed_on) : "" },
        { label: "Size", num: true, cell: x => x.size_mb ? x.size_mb + " MB" : "" },
        { label: "", nowrap: true, cell: x => h("span", { class: "muted small" }, x.arch || "") },
      ], rows));
    };
    filt.addEventListener("input", paintSw);
    panel.append(h("h2", null, "Installed software (" + sw.length + ")"),
      h("div", { class: "win-swbar" }, filt, h("a", { href: "#/software" }, "Across all Windows servers")), box);
    paintSw();
  }
  hostPatchPlace(panel, hostId, miss.length);
}

/* The server page's Patches section (Windows or Linux) and its "Patch this server" button */
function hostPatchPlace(panel, hostId, toInstall) {
  const slot = document.getElementById("host-patch");
  if (slot) slot.replaceChildren(panel);
  else {
    const view = document.getElementById("view");
    const anchor = view.querySelector(".page-head");
    if (anchor && anchor.nextSibling) anchor.parentNode.insertBefore(panel, anchor.nextSibling.nextSibling || null);
    else view.append(panel);
  }
  const acts = document.getElementById("host-actions");
  if (acts && toInstall && can("operator") && hasModule("patch") && !acts.querySelector(".host-patch-btn"))
    acts.prepend(h("a", { class: "btn host-patch-btn", href: "#/changes/new?kind=patch&hosts=" + encodeURIComponent(hostId) }, "Patch this server"));
}

// ---- Linux servers: the package manager's updates and recent installs (agent 1.8.2+) -------
async function linuxPanel(hostId) {
  let d;
  try { d = await api("/admin/hosts/" + encodeURIComponent(hostId) + "/linux"); } catch (e) { return; }   // not Linux
  const p = d.pending || {}, items = p.items || [];
  const sec = items.filter(i => i.security !== false), other = items.filter(i => i.security === false);
  const upTable = list => table([
    { label: "Package", cell: i => h("span", { class: "mono" }, i.name + (i.arch && i.arch !== "noarch" ? "." + i.arch : "")) },
    { label: "Installed", cell: i => h("span", { class: "mono ver-old" }, i.installed || "\u2013") },
    { label: "Updates to", cell: i => h("span", { class: "mono ver-new" }, i.to || "") },
    { label: "Notice", cell: i => i.advisory ? i.advisory + (i.severity ? " (" + i.severity + ")" : "") : h("span", { class: "muted" }, i.security === null ? "kind not reported" : "\u2013") },
    { label: "Repository", cell: i => h("span", { class: "muted small" }, i.repo || "") },
  ], list);
  const inst = d.installed || [];
  const panel = h("section", { class: "win-panel" },
    h("h2", null, "Patches (package manager)"),
    !p.known ? h("div", { class: "form-warn" }, h("strong", null, "Not known yet. "),
        "This server's agent does not report what its package manager would install. Send agent 1.8.2 from Servers > Update agents; "
        + "its next inventory lists the updates here.")
      : h("div", { class: "hd-cards" },
          h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Security updates"),
            h("div", { class: "hd-card-v" + (sec.length ? " hd-failed" : "") }, String(sec.length)),
            h("div", { class: "muted small" }, p.as_of ? "checked " + timeAgo(p.as_of) : "")),
          h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Other updates"), h("div", { class: "hd-card-v" }, String(other.length)),
            h("div", { class: "muted small" }, "a patch job leaves these")),
          h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Installed, last " + d.days + " days"), h("div", { class: "hd-card-v" }, String(inst.length)),
            h("div", { class: "muted small" }, h("a", { href: "#/installed-patches?hosts=" + encodeURIComponent(hostId) + "&days=" + d.days }, "Installed patches report")))),
    p.error ? h("div", { class: "form-warn" }, h("strong", null, "The last check failed: "), p.error, ". The list is from the check before.") : null,
    p.known ? h("p", { class: "muted small" }, "What this server's package manager would install now (" + (items.length ? "dnf/yum check-update or apt" : "nothing waiting")
      + "). A patch job installs the security updates. CVEs are under Vulnerabilities below.") : null,
    p.known && sec.length ? upTable(sec) : p.known ? h("div", { class: "empty" }, h("p", null, "No security update is waiting.")) : null,
    other.length ? h("details", { class: "win-kbs" }, h("summary", null, "Other updates (" + other.length + ")"), upTable(other)) : null,
    h("details", { class: "win-kbs", open: !!inst.length },
      h("summary", null, "Installed in the last " + d.days + " days (" + inst.length + ")"),
      inst.length ? table([
        { label: "Package", cell: x => h("span", { class: "mono" }, x.name + (x.arch && x.arch !== "noarch" ? "." + x.arch : "")) },
        { label: "Version", cell: x => h("span", { class: "mono" }, x.version) },
        { label: "Installed on", nowrap: true, cell: x => x.installed_at ? fmtDateTime(x.installed_at) : h("span", { class: "muted" }, "not recorded") },
      ], inst) : h("p", { class: "muted small" }, d.dated ? "Nothing installed in this period." : "Install dates arrive with agent 1.8.2.")));
  // An older agent: the job still works (from the advisories), so the button stays
  hostPatchPlace(panel, hostId, p.known ? sec.length : 1);
}

// A calendar date (2024-03-11) as "11 Mar 2024", without shifting it by time zone
function dayLabel(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || "");
  if (!m) return iso || "";
  return Number(m[3]) + " " + ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][Number(m[2]) - 1] + " " + m[1];
}

function windowsTabs(active) {
  // The section's pages are tabs in the sub-bar under the menu (sectionNav): nothing to add here
  if (typeof sectionNav === "function") sectionNav(active);
}


async function renderWsus(params) {
  const d = await api("/wsus");
  const srcs = d.sources || [], comps = d.computers || [];
  const STALE_DAYS = 7;
  const stale = c => !c.last_reported || (Date.now() - new Date(c.last_reported).getTime()) > STALE_DAYS * 86400000;
  const seenBy = {};
  comps.forEach(c => { (seenBy[c.name] = seenBy[c.name] || new Set()).add(c.source); });
  let filter = params.get("show") || "all";
  const body = h("div");
  const tabs = [["all", "All computers"], ["needs", "Needing updates"], ["stale", "Not reporting (" + STALE_DAYS + "+ days)"],
                ["errors", "With errors"], ["unenrolled", "Not in PATCH-01"]].map(([k, l]) =>
    h("button", { type: "button", "data-k": k, on: { click: () => { filter = k; paint(); } } }, l));
  function paint() {
    tabs.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === filter)));
    const rows = comps.filter(c => filter === "all" || (filter === "needs" && c.needed > 0) || (filter === "stale" && stale(c))
      || (filter === "errors" && c.failed > 0) || (filter === "unenrolled" && !c.host_id));
    body.replaceChildren(rows.length ? table([
      { label: "Computer", cell: c => h("span", null,
          c.host_id ? h("a", { href: "#/host/" + c.host_id }, h("strong", null, c.name)) : h("strong", null, c.name),
          c.host_id ? null : h("span", { class: "muted small" }, " \u00b7 not in PATCH-01"),
          seenBy[c.name].size > 1 ? h("span", { class: "muted small", title: "Listed by " + [...seenBy[c.name]].join(" and ")
            + ": usually reporting roll-up from a downstream WSUS" }, " \u00b7 also on another WSUS") : null) },
      srcs.length > 1 ? { label: "WSUS", nowrap: true, cell: c => c.source } : null,
      { label: "Groups", cell: c => (c.groups || []).join(", ") },
      { label: "Last reported", nowrap: true, cell: c => h("span", { class: stale(c) ? "hd-failed" : null }, c.last_reported ? timeAgo(c.last_reported) : "never") },
      { label: "Needed", num: true, cell: c => c.needed == null ? "" : h("span", { class: c.needed ? "hd-failed" : null }, String(c.needed)) },
      { label: "Failed", num: true, cell: c => c.failed ? h("span", { class: "hd-failed" }, String(c.failed)) : (c.failed == null ? "" : "0") },
      { label: "Pending reboot", num: true, cell: c => c.pending_reboot || (c.pending_reboot == null ? "" : "0") },
      { label: "OS", cell: c => h("span", { class: "muted small" }, c.os || "") },
    ].filter(Boolean), rows) : h("div", { class: "empty" }, h("p", null, "Nothing here.")));
  }
  const cards = srcs.map(s_ => {
    const r = s_.report || {}, sy = r.sync || {}, up = r.updates || {}, cm = r.computers || {};
    const ok = (sy.result || "").toLowerCase() === "succeeded";
    return h("div", { class: "hd-cards" },
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "WSUS"), h("div", { class: "hd-card-v" }, s_.name),
        h("div", { class: "muted small" }, (r.version ? "version " + r.version + " \u00b7 " : "") + (s_.reported_at ? "reported " + timeAgo(s_.reported_at) : "has not reported"))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Last sync"),
        h("div", { class: ok ? "hd-good" : "hd-failed" }, sy.result || "\u2013"),
        h("div", { class: "muted small" }, (sy.last_end ? timeAgo(sy.last_end) : "") + (sy.error ? " \u00b7 " + sy.error : ""))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Security updates not approved"),
        h("div", { class: "hd-card-v" + (up.security_not_approved ? " hd-failed" : "") }, String(up.security_not_approved ?? "\u2013")),
        h("div", { class: "muted small" }, (up.approved ?? 0) + " approved in total")),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Computers needing updates"),
        h("div", { class: "hd-card-v" }, String(cm.needing_updates ?? "\u2013")),
        h("div", { class: "muted small" }, (cm.total ?? 0) + " computers \u00b7 " + (cm.with_errors ?? 0) + " with errors")),
      s_.error ? h("div", { class: "form-warn" }, h("strong", null, "The last report failed on the WSUS server: "), s_.error) : null);
  });
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl wsus" }, "WSUS")),
    srcs.length ? cards : h("div", { class: "empty" }, h("p", null, "No WSUS server reports yet."),
      h("p", { class: "muted" }, "On PATCH-01: ./scripts/phase10-windows.sh --wsus-token <wsus name>. On the WSUS server, as administrator: "
        + ".\\wsus-report.ps1 -Server https://patch01.example -Pin <pin> -Token <token> -Install")),
    (d.not_in_wsus || []).length ? h("div", { class: "form-warn" }, h("strong", null, (d.not_in_wsus.length) + " Windows server(s) in PATCH-01 are unknown to WSUS: "),
      d.not_in_wsus.map(x => x.hostname).join(", "), ". They cannot receive approved updates.") : null,
    comps.length ? h("div", { class: "filters", role: "group", "aria-label": "Show" }, tabs) : null,
    comps.length ? body : null);
  if (comps.length) paint();
  windowsTabs("wsus");
}


// ---- PATCH-01's certificate ------------------------------------------------------------
async function renderCertificate(params) {
  setNav("admin");
  const d = await api("/admin/certificate");
  const cur = d.served || {};
  const certCard = (c, title) => c.error ? h("div", { class: "form-warn" }, c.error) : h("div", { class: "hd-cards" },
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, title), h("div", { class: "hd-card-v" }, c.subject),
      h("div", { class: "muted small" }, "issued by " + c.issuer + (c.self_signed ? " (self-signed)" : ""))),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Valid until"),
      h("div", { class: c.days_left < 30 ? "hd-failed" : null }, dayLabel(c.not_after)),
      h("div", { class: "muted small" }, c.days_left + " days left")),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Names"),
      h("div", { class: "small" }, (c.dns_names || []).concat(c.ip_names || []).join(", ") || "none")),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Pin (SHA-256)"),
      h("code", { class: "cert-pin" }, c.pin)));
  const lastBox = h("div");
  const showLast = st => {
    if (!st || !st.last) { lastBox.replaceChildren(); return; }
    const l = st.last;
    const cls = l.state === "ok" ? "cert-ok" : l.state === "rolled_back" ? "cert-rb" : "cert-bad";
    lastBox.replaceChildren(h("div", { class: "cert-result " + cls },
      h("strong", null, { ok: "Done", rolled_back: "Rolled back", failed: "Not changed" }[l.state] || l.state), ": ",
      l.message, h("div", { class: "muted small" }, (l.action === "rollback" ? "Rollback" : "Install") + " by " + l.by + ", " + timeAgo(l.at))));
  };
  showLast(d.status);

  // upload
  const mode = h("select", { "aria-label": "What your CA gave you" },
    h("option", { value: "pem" }, "Certificate and key files (.crt / .pem / .cer and .key)"),
    h("option", { value: "pfx" }, "One .pfx / .p12 file with a password"));
  const fCert = h("input", { type: "file", accept: ".crt,.pem,.cer,.der" });
  const fKey = h("input", { type: "file", accept: ".key,.pem" });
  const fChain = h("input", { type: "file", accept: ".crt,.pem,.cer" });
  const fPfx = h("input", { type: "file", accept: ".pfx,.p12" });
  const pw = h("input", { type: "password", autocomplete: "off", placeholder: "Password of the .pfx, or of the key if it has one" });
  const pemBox = h("div", null,
    h("label", null, h("span", null, "Certificate"), fCert),
    h("label", null, h("span", null, "Private key"), fKey),
    h("label", null, h("span", null, "Intermediate CA (optional, if not inside the certificate file)"), fChain));
  const pfxBox = h("div", { hidden: true }, h("label", null, h("span", null, ".pfx / .p12 file"), fPfx));
  mode.addEventListener("change", () => { pemBox.hidden = mode.value !== "pem"; pfxBox.hidden = mode.value !== "pfx"; });
  const report = h("div");
  const checkBtn = h("button", { type: "button", class: "btn", on: { click: async () => {
    const fd = new FormData();
    if (mode.value === "pfx") { if (fPfx.files[0]) fd.append("pfx", fPfx.files[0]); }
    else { if (fCert.files[0]) fd.append("cert", fCert.files[0]); if (fKey.files[0]) fd.append("key", fKey.files[0]);
           if (fChain.files[0]) fd.append("chain", fChain.files[0]); }
    if (pw.value) fd.append("password", pw.value);
    checkBtn.disabled = true; report.replaceChildren(h("p", { class: "muted small" }, "Checking\u2026"));
    try {
      const res = await fetch("/api/v1/admin/certificate/check", { method: "POST", body: fd,
        headers: { ...authHeaders(), "X-Requested-With": "patch01-dashboard" } });
      const r = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(r.detail) || res.statusText);
      showCheck(r);
    } catch (e) { report.replaceChildren(h("div", { class: "form-warn" }, e.message)); }
    checkBtn.disabled = false;
  } } }, "Check");

  function showCheck(r) {
    const parts = [];
    if (r.errors && r.errors.length) parts.push(h("div", { class: "cert-result cert-bad" }, h("strong", null, "Cannot be used: "),
      h("ul", null, r.errors.map(e => h("li", null, e)))));
    if (r.warnings && r.warnings.length) parts.push(h("div", { class: "cert-result cert-rb" }, h("strong", null, "Note: "),
      h("ul", null, r.warnings.map(e => h("li", null, e)))));
    if (r.certificate) parts.push(certCard(r.certificate, "Uploaded certificate"),
      r.chain && r.chain.length ? h("p", { class: "muted small" }, "Chain: " + r.chain.map(c => c.subject).join(" \u2192 ")) : null);
    if (r.ok) {
      const old = r.pins.old || "<current pin>";
      const both = old + "," + r.pins.new;
      const short = d.names.short;
      const cmds = h("pre", { class: "cert-cmds" },
        ".\\push-agent.ps1 -Computers servers.txt -Server https://" + short + " -Pin " + both + " -Repin\n"
        + ".\\wsus-report.ps1 -Repin -Pin " + both);
      const copy = h("button", { type: "button", class: "btn-link", on: { click: () => { navigator.clipboard && navigator.clipboard.writeText(cmds.textContent); copy.textContent = "Copied"; } } }, "Copy");
      const ack = h("input", { type: "checkbox" });
      const go = h("button", { type: "button", class: "btn", disabled: true }, "Install this certificate");
      ack.addEventListener("change", () => { go.disabled = !ack.checked; });
      go.addEventListener("click", async () => {
        go.disabled = true; go.textContent = "Installing\u2026";
        try {
          const a = await apiPost("/admin/certificate/apply", { id: r.id, windows_repinned: ack.checked });
          await waitResult(a.request);
        } catch (e) { report.append(h("div", { class: "form-warn" }, e.message)); go.disabled = false; go.textContent = "Install this certificate"; }
      });
      parts.push(h("h3", null, "Before installing: Windows agents and WSUS"),
        h("p", { class: "small" }, "Windows agents and the WSUS reports trust only the current certificate. Give them both pins first, "
          + "from the jump host and on each WSUS server, so they keep working before and after the change:"),
        h("div", { class: "cert-cmdbox" }, cmds, copy),
        h("label", { class: "check" }, ack, h("span", null, "The Windows agents and WSUS servers have been given both pins")),
        h("div", { class: "form-actions" }, go,
          h("span", { class: "muted small" }, "PATCH-01 installs it, restarts its web front, checks it is served, and puts the old one back if not.")));
    }
    report.replaceChildren(...parts.filter(Boolean));
  }

  async function waitResult(reqId) {
    const t0 = Date.now();
    report.append(h("p", { class: "muted small cert-wait" }, "Waiting for PATCH-01 to install it (the console may blink while its web front restarts)\u2026"));
    while (Date.now() - t0 < 180000) {
      await new Promise(r => setTimeout(r, 3000));
      try {
        const st = await api("/admin/certificate");
        if (st.status && st.status.last && st.status.last.id === reqId) { renderCertificate(params).then(() => adminTabs("certificate")); return; }
      } catch (e) { /* the web front is restarting */ }
    }
    report.append(h("div", { class: "form-warn" }, "No answer after 3 minutes: see /var/log/patch01-cert.log on PATCH-01."));
  }

  const rb = h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
    if (!confirm("Go back to the certificate PATCH-01 used before the last change?")) return;
    try { const a = await apiPost("/admin/certificate/rollback", {}); rb.disabled = true; await waitResult(a.request); }
    catch (e) { lastBox.replaceChildren(h("div", { class: "form-warn" }, e.message)); }
  } } }, "Roll back to the previous certificate");

  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl cert" }, "Certificate")),
    !d.status.helper_ready ? h("div", { class: "form-warn" }, h("strong", null, "The certificate helper is not installed. "),
      "Run phase3b-api.sh on PATCH-01 once; until then certificates can be checked here but not installed.") : null,
    h("h2", null, "Served now"), certCard(cur, "Certificate"), lastBox,
    h("h2", null, "Install a new certificate"),
    h("p", { class: "muted small" }, "Upload what your CA issued. It is checked first: the key matches, it is in date, it names "
      + d.names.short + " and " + d.names.fqdn + ", and the chain is complete. Nothing changes until you install it."),
    h("div", { class: "form-sec" }, h("label", null, h("span", null, "What your CA gave you"), mode), pemBox, pfxBox,
      h("label", null, h("span", null, "Password (only if needed)"), pw)),
    h("div", { class: "form-actions" }, checkBtn), report,
    h("h2", null, "Undo"), h("div", { class: "form-actions" }, rb,
      h("span", { class: "muted small" }, "The five previous certificates are kept on PATCH-01.")));
}


// ---- Live log: a small floating terminal with agent output and change steps --------
// Lines come from servers, so they are untrusted text: inserted with textContent
// only, never as HTML.
const LiveLog = (() => {
  const KEY = "patch01.livelog";
  let el = null, body = null, scopeEl = null, timer = null, paused = false;
  let afterLog = 0, afterEvent = 0, scopeKey = "";
  const MAX_LINES = 800;
  const pad = n => String(n).padStart(2, "0");
  const hhmmss = iso => { const d = new Date(iso); return pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds()); };
  function scope() {
    const m = /^#\/(change|host)\/([0-9a-f-]{36})/.exec(location.hash || "");
    return m ? { kind: m[1], id: m[2] } : null;
  }
  function line(cls, parts) {
    const row = document.createElement("div"); row.className = "ll-row " + cls;
    parts.forEach(([c, text]) => { const sp = document.createElement("span"); sp.className = c; sp.textContent = text; row.append(sp); });
    body.append(row);
    while (body.childNodes.length > MAX_LINES) body.removeChild(body.firstChild);
  }
  async function poll() {
    if (!el || paused || !getAuth()) return;
    const sc = scope(); const key = sc ? sc.kind + ":" + sc.id : "all";
    if (key !== scopeKey) {                   // a new page: start that page's view afresh
      scopeKey = key; afterLog = 0; afterEvent = 0; body.replaceChildren();
      scopeEl.textContent = sc ? (sc.kind === "change" ? "this change" : "this server") : "all servers and changes";
    }
    let q = "/console/stream?after_log=" + afterLog + "&after_event=" + afterEvent;
    if (sc) q += "&" + sc.kind + "=" + sc.id;
    let d;
    try { d = await api(q); } catch (e) { return; }
    const items = [];
    (d.logs || []).forEach(l => { items.push({ at: l.at, kind: "log", l }); afterLog = Math.max(afterLog, l.id); });
    (d.events || []).forEach(e => { items.push({ at: e.at, kind: "ev", e }); afterEvent = Math.max(afterEvent, e.id); });
    items.sort((a, b) => new Date(a.at) - new Date(b.at));
    const stick = body.scrollTop + body.clientHeight >= body.scrollHeight - 8;
    items.forEach(it => {
      if (it.kind === "log") {
        const lv = (it.l.level || "INFO").toUpperCase();
        line("ll-" + lv.toLowerCase(), [["ll-t", hhmmss(it.at) + " "], ["ll-h", it.l.hostname + " "], ["ll-lv", lv.padEnd(5) + " "], ["ll-m", it.l.line]]);
      } else {
        const ok = it.e.ok === true ? "ll-ok" : it.e.ok === false ? "ll-error" : "ll-info";
        line(ok, [["ll-t", hhmmss(it.at) + " "], ["ll-h", "CHG-" + String(it.e.number).padStart(6, "0") + " "], ["ll-lv", (it.e.actor || "").padEnd(5) + " "], ["ll-m", it.e.message || it.e.event]]);
      }
    });
    if (stick) body.scrollTop = body.scrollHeight;
  }
  function drag(handle) {
    handle.addEventListener("mousedown", ev => {
      if (ev.target.tagName === "BUTTON") return;
      const r = el.getBoundingClientRect(), dx = ev.clientX - r.left, dy = ev.clientY - r.top;
      const move = m => { el.style.left = Math.max(0, Math.min(window.innerWidth - 80, m.clientX - dx)) + "px";
                          el.style.top = Math.max(0, Math.min(window.innerHeight - 40, m.clientY - dy)) + "px";
                          el.style.right = "auto"; el.style.bottom = "auto"; };
      const up = () => { document.removeEventListener("mousemove", move); document.removeEventListener("mouseup", up); };
      document.addEventListener("mousemove", move); document.addEventListener("mouseup", up); ev.preventDefault();
    });
  }
  function open() {
    if (el) return;
    el = document.createElement("section"); el.className = "livelog"; el.setAttribute("aria-label", "Live log");
    const head = document.createElement("div"); head.className = "ll-head";
    const title = document.createElement("strong"); title.textContent = ">_ Live log";
    scopeEl = document.createElement("span"); scopeEl.className = "ll-scope";
    const pauseB = document.createElement("button"); pauseB.type = "button"; pauseB.textContent = "Pause";
    pauseB.onclick = () => { paused = !paused; pauseB.textContent = paused ? "Resume" : "Pause"; if (!paused) poll(); };
    const clearB = document.createElement("button"); clearB.type = "button"; clearB.textContent = "Clear";
    clearB.onclick = () => body.replaceChildren();
    const closeB = document.createElement("button"); closeB.type = "button"; closeB.textContent = "\u00d7"; closeB.title = "Close";
    closeB.onclick = close;
    head.append(title, scopeEl, pauseB, clearB, closeB);
    body = document.createElement("div"); body.className = "ll-body"; body.setAttribute("role", "log"); body.setAttribute("aria-live", "polite");
    el.append(head, body); document.body.append(el); drag(head);
    scopeKey = ""; poll(); timer = setInterval(poll, 3000);
    sessionStorage.setItem(KEY, "open"); setBtn(true);
  }
  function close() {
    if (!el) return;
    clearInterval(timer); el.remove(); el = null; sessionStorage.removeItem(KEY); setBtn(false);
  }
  function setBtn(on) { const b = document.getElementById("logbtn"); if (b) b.setAttribute("aria-pressed", String(on)); }
  function init() {
    const b = document.getElementById("logbtn"); if (!b || b.dataset.wired) return;
    b.dataset.wired = "1"; b.addEventListener("click", () => (el ? close() : open()));
    if (sessionStorage.getItem(KEY) === "open") open();
    window.addEventListener("hashchange", () => { if (el) poll(); });
  }
  return { init, open, close };
})();
document.addEventListener("DOMContentLoaded", () => setTimeout(() => LiveLog.init(), 0));


// ---- Inventory: Assets, Decommissioned, Software ------------------------------------
const INV_CAT = { server: "Servers", client: "Laptop/Desktop", esxi: "ESXi", appliance: "Appliances", network: "Network",
  firewall: "Firewalls", unknown: "Unknown" };
const INV_DEV = { server: "Server", client: "Laptop/Desktop", esxi: "ESXi host", appliance: "Appliance", network: "Network",
  firewall: "Firewall", unknown: "Unknown" };
// Donut colours follow the type (never its rank); unknown is neutral
const INV_COL = { server: "c-cat1", client: "c-cat2", esxi: "c-cat3", appliance: "c-cat4", network: "c-cat5", firewall: "c-cat6", unknown: "c-muted" };
const INV_FROM = { person: "set by a person", vcenter: "from vCenter", rules: "from the OS", manual: "from the sheet", name: "from the name",
  ai: "by AI-01", snapshot: "as last recorded" };
const INV_SRC = { agent: "Agent", virtual: "Virtual", vcenter: "vCenter", wsus: "WSUS", apex: "Apex", manual: "Manual" };
const INV_STATUS = { new: "New", approved: "Approved", decommissioned: "Decommissioned" };
const INV_ACT = { new: "New", update: "Update", known: "Already found", skip: "Skipped" };
const INV_ICONS = {
  server: [["rect", { x: "4", y: "4", width: "16", height: "6", rx: "1.5" }], ["rect", { x: "4", y: "14", width: "16", height: "6", rx: "1.5" }], ["path", { d: "M8 7h.01M8 17h.01" }]],
  client: [["rect", { x: "5", y: "5", width: "14", height: "10", rx: "1.5" }], ["path", { d: "M3 19h18" }]],
  appliance: [["rect", { x: "3", y: "10", width: "18", height: "7", rx: "1.5" }], ["path", { d: "M7 13.5h.01M10.5 13.5h.01M8 10L6.5 6M16 10l1.5-4" }]],
  unknown: [["circle", { cx: "12", cy: "12", r: "8.5" }], ["path", { d: "M9.6 9.5a2.5 2.5 0 1 1 3.4 2.3c-.7.3-1 .8-1 1.5v.4" }], ["path", { d: "M12 16.8v.2" }]],
  new: [["circle", { cx: "12", cy: "12", r: "8.5" }], ["path", { d: "M12 8v8M8 12h8" }]],
  approved: [["circle", { cx: "12", cy: "12", r: "8.5" }], ["path", { d: "M8.5 12.5l2.5 2.5 4.5-5" }]],
  decom: [["rect", { x: "4", y: "5", width: "16", height: "4", rx: "1" }], ["path", { d: "M5.5 9v9a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1V9M10 13h4" }]],
  upload: [["path", { d: "M12 16V5M8 9l4-4 4 4" }], ["path", { d: "M5 15v3a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3" }]],
  ai: [["path", { d: "M12 4l1.8 4.6L18.5 10l-4.7 1.4L12 16l-1.8-4.6L5.5 10l4.7-1.4z" }], ["path", { d: "M18 16l.7 1.8 1.8.7-1.8.7L18 21l-.7-1.8-1.8-.7 1.8-.7z" }]],
  revoke: [["path", { d: "M9 7L5 11l4 4" }], ["path", { d: "M5 11h9a5 5 0 0 1 0 10h-2" }]],
  esxi: [["rect", { x: "3", y: "5", width: "18", height: "11", rx: "1.5" }], ["path", { d: "M7 9h4v3H7zM13 9h4v3h-4zM8 20h8M12 16v4" }]],
  network: [["rect", { x: "3", y: "9", width: "18", height: "6", rx: "1.5" }], ["path", { d: "M6.5 12h.01M9.5 12h.01M12.5 12h.01M15.5 12h.01M12 9V5M9 5h6" }]],
  firewall: [["rect", { x: "3", y: "5", width: "18", height: "14", rx: "1" }], ["path", { d: "M3 9.7h18M3 14.3h18M9 5v4.7M15 9.7v4.6M9 14.3V19" }]],
  hardware: [["rect", { x: "6", y: "6", width: "12", height: "12", rx: "1.5" }], ["path", { d: "M9 9h6v6H9zM9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3" }]],
  export: [["path", { d: "M12 4v11M8 11l4 4 4-4" }], ["path", { d: "M5 19h14" }]],
  off: [["path", { d: "M12 4v7" }], ["path", { d: "M7.5 7.2a7 7 0 1 0 9 0" }]],
  template: [["rect", { x: "4", y: "4", width: "16", height: "16", rx: "2", "stroke-dasharray": "3 2.2" }], ["path", { d: "M8 9h8M8 13h5" }]],
  master: [["rect", { x: "4", y: "4", width: "7", height: "7", rx: "1" }], ["rect", { x: "13", y: "4", width: "7", height: "7", rx: "1" }],
           ["rect", { x: "4", y: "13", width: "7", height: "7", rx: "1" }], ["rect", { x: "13", y: "13", width: "7", height: "7", rx: "1" }]],
  wsus: [["path", { d: "M12 4v10M8 10l4 4 4-4" }], ["path", { d: "M5 18h14" }], ["path", { d: "M17 6.5A7 7 0 0 1 19 12" }]],
  shield: [["path", { d: "M12 3l7 3v5c0 4.4-3 8.3-7 9.5C8 19.3 5 15.4 5 11V6z" }], ["path", { d: "M9.5 12l2 2 3.5-4" }]],
  silent: [["path", { d: "M12 3l7 3v5c0 4.4-3 8.3-7 9.5C8 19.3 5 15.4 5 11V6z" }], ["path", { d: "M12 8v4M12 15.5v.2" }]],
  gap: [["circle", { cx: "12", cy: "12", r: "8.5" }], ["path", { d: "M8 12h8" }]],
};
function invIcon(k) {
  return svg("svg", { viewBox: "0 0 24 24", class: "av-ico", "aria-hidden": "true", focusable: "false" },
    (INV_ICONS[k] || []).map(([tag, attrs]) => svg(tag, attrs)));
}

function invTabs(active) {
  // The section's pages are tabs in the sub-bar under the menu (sectionNav): nothing to add here
  if (typeof sectionNav === "function") sectionNav(active);
}


// A small dialog for a reason or note. Resolves to the text, or null when cancelled.
function invAsk(title, intro, required, okLabel) {
  return new Promise(resolve => {
    const ta = h("textarea", { rows: "3", maxlength: "500", "aria-label": required ? "Reason" : "Note" });
    const err = h("p", { class: "hd-failed small", hidden: true });
    let back = null;
    const done = v => { if (back) back.remove(); document.removeEventListener("keydown", esc); resolve(v); };
    function esc(e) { if (e.key === "Escape") done(null); }
    const ok = h("button", { type: "button", class: "btn" }, okLabel);
    ok.addEventListener("click", () => {
      const v = ta.value.trim();
      if (required && v.length < 3) { err.textContent = "Give a reason (at least 3 characters)."; err.hidden = false; ta.focus(); return; }
      done(v);
    });
    const box = h("div", { class: "mw inv-ask", role: "dialog", "aria-modal": "true", "aria-label": title },
      h("div", { class: "mw-head" }, h("h2", null, title), h("button", { type: "button", class: "btn-link", on: { click: () => done(null) } }, "Cancel")),
      h("div", { class: "inv-ask-b" }, h("p", null, intro),
        h("label", null, h("span", null, required ? "Reason (required, kept in the audit)" : "Note (optional, kept in the audit)"), ta), err,
        h("div", { class: "form-actions" }, ok, h("button", { type: "button", class: "btn btn-quiet", on: { click: () => done(null) } }, "Cancel"))));
    back = h("div", { class: "mw-back", on: { click: e => { if (e.target === back) done(null); } } }, box);
    document.addEventListener("keydown", esc);
    document.body.append(back);
    ta.focus();
  });
}

function invStatus(a) {
  const b = h("span", { class: "inv-st inv-st-" + a.status }, INV_STATUS[a.status] || a.status);
  return a.gone ? [b, h("span", { class: "muted small", title: "No agent, vCenter, WSUS or sheet reports it now" }, " · not detected now")] : b;
}

function invDetected(a) {
  return a.sources.length ? h("span", { class: "inv-srcs" }, a.sources.map(x => h("span", { class: "inv-src inv-" + x }, INV_SRC[x] || x)))
    : h("span", { class: "muted small" }, "none now");
}

const invIps = a => a.ips.length ? a.ips.slice(0, 2).join(", ") + (a.ips.length > 2 ? " +" + (a.ips.length - 2) : "") : "–";

// The expanded row: every source's view of the machine, then its history
async function invDetail(a) {
  if (a.tpl) {                                     // a VM template: what vCenter says about it, no history
    const t = a.tpl;
    const rows = [["vCenter", a.location], ["Datacenter", t.datacenter], ["Cluster", t.cluster], ["Registered on", t.esxi_host], ["Folder", t.folder_path],
      ["Hardware version", t.hardware_version], ["Created", t.create_date ? fmtDateTime(t.create_date) : null], ["Notes", t.annotation],
      ["Last read", t.synced_at ? fmtDateTime(t.synced_at) : null]].filter(r => r[1]);
    return h("div", { class: "inv-detail" }, h("div", null, h("h4", null, "Template"),
      h("dl", { class: "inv-dl" }, rows.map(([k, v]) => [h("dt", null, k), h("dd", null, v)]).flat())));
  }
  const dl = (pairs) => h("dl", { class: "inv-dl" }, pairs.filter(p => p[1] != null && p[1] !== "" && !(Array.isArray(p[1]) && !p[1].length))
    .map(([k, v]) => [h("dt", null, k), h("dd", null, Array.isArray(v) ? v.join(", ") : v)]).flat());
  const parts = [];
  const osBy = Object.entries(a.os_by || {}).map(([k, v]) => k + ": " + v);
  const hwd = a.hardware || {};
  if (hwd.manufacturer || hwd.model || hwd.serial || hwd.cpu || hwd.memory_gb) parts.push(h("div", null, h("h4", null, "Hardware"),
    dl([["Make", hwd.manufacturer], ["Model", hwd.model], ["Serial", hwd.serial], ["CPU", hwd.cpu], ["Memory", hwd.memory_gb ? hwd.memory_gb + " GB" : null]])));
  parts.push(h("div", null, h("h4", null, "Machine"), dl([["Device", INV_DEV[a.device] + " (" + a.device_reason + ")"],
    ["Type decided", INV_FROM[a.device_from] || a.device_from],
    ["Operating system by source", osBy], ["All addresses", a.ips], ["Location", a.location],
    ["Agent", a.agent_version ? "version " + a.agent_version : null]])));
  if (a.vm) parts.push(h("div", null, h("h4", null, "vCenter"), dl([["vCenter", a.vm.vcenter], ["VM name", a.vm.name], ["Cluster", a.vm.cluster],
    ["ESXi host", a.vm.esxi], ["Power", POWER_WORD[a.vm.power] || a.vm.power], ["Folder", a.vm.folder],
    ["Created", a.vm.created ? fmtDateTime(a.vm.created) : null]])));
  if (a.esxi) parts.push(h("div", null, h("h4", null, "ESXi host"), dl([["vCenter", a.esxi.vcenter], ["Cluster", a.esxi.cluster],
    ["Model", a.esxi.model], ["Version", a.esxi.version]])));
  if (a.wsus) parts.push(h("div", null, h("h4", null, "WSUS"), dl([["WSUS server", a.wsus.server], ["Groups", a.wsus.groups || []],
    ["Last report", a.wsus.last_reported ? fmtDateTime(a.wsus.last_reported) : null]])));
  if (a.apex) parts.push(h("div", null, h("h4", null, "Apex Central"), dl([["Console", a.apex.console], ["Product", a.apex.product],
    ["OS reported", a.apex.os], ["Reporting", a.apex.not_reported ? "no, not for 2 days" : "yes"],
    ["Last connected", a.apex.last_connected ? fmtDateTime(a.apex.last_connected) : null]])));
  if (a.apex_product) parts.push(h("div", null, h("h4", null, "Apex Central product server"),
    dl([["Role", a.apex_product.label], ["Console", a.apex_product.console]])));
  if (a.sheet) parts.push(h("div", null, h("h4", null, "Uploaded sheet"), dl([["Location", a.sheet.location], ["Serial", a.sheet.serial],
    ["Owner", a.sheet.owner], ["Notes", a.sheet.notes],
    ["Uploaded", (a.sheet.updated_by || "") + (a.sheet.updated_at ? " · " + fmtDateTime(a.sheet.updated_at) : "")]])));
  let hist;
  try {
    const r = await api("/inventory/assets/" + encodeURIComponent(a.key) + "/history");
    const WORD = { approved: "Approved", decommissioned: "Decommissioned", revoked: "Revoked", uploaded: "Added from a sheet", ai_type: "Device type by AI-01",
      type_set: "Device type set" };
    hist = (r.events || []).length ? h("ol", { class: "inv-hist" }, r.events.map(e => h("li", null,
      h("strong", null, WORD[e.action] || e.action), " by ", e.actor, " · ", fmtDateTime(e.at),
      e.from_status && e.to_status ? h("span", { class: "muted" }, " (" + (INV_STATUS[e.from_status] || e.from_status) + " → " + (INV_STATUS[e.to_status] || e.to_status) + ")") : null,
      e.action === "type_set" && e.detail ? h("span", { class: "muted" }, " (" + (INV_DEV[e.detail.from] || e.detail.from || "?") + " → "
        + (e.detail.to === "auto" ? "automatic" : INV_DEV[e.detail.to] || e.detail.to) + ")") : null,
      e.reason ? h("div", { class: "small" }, "“" + e.reason + "”") : null)))
      : h("p", { class: "muted small" }, "No decisions yet.");
  } catch (e) { hist = h("p", { class: "muted small" }, e.message); }
  parts.push(h("div", null, h("h4", null, "History (audit)"), hist));
  return h("div", { class: "inv-detail" }, parts);
}

// A list page of assets: tiles, filters, 20 a page, tick boxes, and the action buttons
const SEL_MAX = 2000;

// A column's value for sorting: its own sort function, else the text the cell shows
function colSortValue(c, row) {
  if (c.sort) return c.sort(row);
  const n = c.cell(row);
  return (n instanceof Node ? n.textContent : Array.isArray(n) ? n.map(x => x instanceof Node ? x.textContent : String(x ?? "")).join(" ") : String(n ?? "")).trim();
}
// dir 1 ascending, -1 descending. Pass dir here rather than multiplying the result:
// empty values stay last in BOTH directions, and two empties are equal (a consistent comparator).
const isEmptySortValue = v => v === "" || v === "–" || v === null || v === undefined || (typeof v === "number" && isNaN(v));
function compareValues(a, b, dir = 1) {
  const ea = isEmptySortValue(a), eb = isEmptySortValue(b);
  if (ea || eb) return ea && eb ? 0 : ea ? 1 : -1;
  const na = typeof a === "number" || !isNaN(a), nb = typeof b === "number" || !isNaN(b);
  const v = na && nb ? Number(a) - Number(b) : String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: "base" });
  return (dir < 0 ? -v : v) || 0;
}

function invList(opts) {
  const SIZE = PAGE_SIZE;
  // The selection is kept while filters change: what an action or export uses is the selection
  // that is visible under the current filter (eff), and the rest is reported as hidden, never dropped.
  const st = { q: "", src: "any", page: 1, sel: new Set(), open: new Set(), filter: opts.filter || (() => true), sort: null, busy: false };
  const search = h("input", { type: "search", placeholder: "Host name, OS, IP or location", "aria-label": "Search assets" });
  const srcSel = h("select", { "aria-label": "Detected by" }, h("option", { value: "any" }, "Detected by any"),
    Object.entries(INV_SRC).map(([k, l]) => h("option", { value: k }, "Detected: " + l)));
  const box = h("div"), selInfo = h("span", { class: "small inv-selinfo", role: "status" });
  const msg = h("p", { class: "cm-meta inv-msg", role: "status" });
  let typing = null;
  search.addEventListener("input", () => { clearTimeout(typing); typing = setTimeout(() => { st.q = search.value.trim().toLowerCase(); st.page = 1; paint(); }, 150); });
  srcSel.addEventListener("change", () => { st.src = srcSel.value; st.page = 1; paint(); });
  let shown = [], pageRows = [], headBox = null;
  const eff = () => shown.filter(a => st.sel.has(a.key));
  st.eff = () => eff().map(a => a.key);
  const add = k => { if (st.sel.size < SEL_MAX) st.sel.add(k); };
  const btns = opts.actions.filter(a => opts.perms.has(a.perm)).map(a => {
    const b = h("button", { type: "button", class: "btn inv-act inv-act-" + a.perm, disabled: true, title: a.title, "aria-label": a.label },
      invIcon(a.icon), h("span", null, a.label));
    b.addEventListener("click", async () => {
      if (st.busy) return;
      const rows = eff();
      const keys = rows.map(x => x.key);
      if (!keys.length) return;
      const names = rows.map(x => x.name);
      const note = await invAsk(a.label + " " + keys.length + " asset" + (keys.length === 1 ? "" : "s"),
        a.ask(keys.length) + " " + names.slice(0, 8).join(", ") + (names.length > 8 ? " and " + (names.length - 8) + " more." : "."), a.perm === "decom", a.label);
      if (note === null) return;
      st.busy = true; refreshSel();
      msg.textContent = "Saving…";
      try {
        const r = await apiPost("/inventory/assets/action", { action: a.perm, keys, reason: note || null });
        msg.textContent = a.done(r.done) + (r.skipped ? " " + r.skipped + " skipped: " + r.skipped_why.join("; ") : "");
        keys.forEach(k => st.sel.delete(k));          // only what was sent; ticks made meanwhile stay
        await opts.reload();
      } catch (e) { msg.textContent = e.message; }
      st.busy = false;
      paint();
    });
    return b;
  });
  function matches(a) {
    const q = st.q;
    return st.filter(a) && (st.src === "any" || (a.sources || []).includes(st.src))
      && (!q || a.name.toLowerCase().includes(q) || (a.os || "").toLowerCase().includes(q) || (a.location || "").toLowerCase().includes(q)
          || (a.ips || []).some(ip => ip.includes(q)));
  }
  // Selection changes update the counts, buttons and row marks in place: the table is not rebuilt,
  // so focus stays on the box that was ticked and fast clicks are never lost
  function refreshSel() {
    const allow = opts.allowActions ? opts.allowActions() : true;
    const n = eff().length, hidden = st.sel.size - n;
    btns.forEach(b => { b.disabled = st.busy || !n; b.hidden = !allow; });
    if (toolsEl) { toolsEl.hidden = !allow; toolsEl.disabled = st.busy; }
    expBtns.forEach(b => { b.disabled = !n; });
    if (headBox) {
      const on = pageRows.filter(a => st.sel.has(a.key)).length;
      headBox.checked = pageRows.length > 0 && on === pageRows.length;
      headBox.indeterminate = on > 0 && on < pageRows.length;
    }
    box.querySelectorAll("tr.srv-row[data-key]").forEach(tr => {
      const on = st.sel.has(tr.dataset.key);
      tr.classList.toggle("inv-picked", on);
      const c = tr.querySelector("input.inv-tick"); if (c) { c.checked = on; c.disabled = st.busy; }
    });
    const allMatch = shown.length && shown.every(a => st.sel.has(a.key));
    selInfo.replaceChildren(...[
      n ? h("strong", null, n + " selected") : h("span", { class: "muted" }, shown.length + " of " + opts.rows().length),
      hidden > 0 ? h("span", { class: "muted", title: "Ticked rows the current filter hides are kept, but actions and exports use only the visible ones" },
        " (+" + hidden + " hidden by the filter)") : null,
      shown.length > pageRows.length && !allMatch && shown.length ? h("button", { type: "button", class: "btn-link", on: { click: () => {
        shown.forEach(a => add(a.key));
        if (shown.length > SEL_MAX) msg.textContent = "At most " + SEL_MAX + " can be selected at once: narrow the filter for the rest.";
        refreshSel(); } } }, " · Select all " + Math.min(shown.length, SEL_MAX) + " matching") : null,
      st.sel.size ? h("button", { type: "button", class: "btn-link", on: { click: () => { st.sel.clear(); refreshSel(); } } }, " · Clear") : null].filter(Boolean));
  }
  function paint() {
    const all = opts.rows();
    const colsData = typeof opts.columns === "function" ? opts.columns() : opts.columns;
    shown = all.filter(matches);
    if (st.sort && colsData[st.sort.i]) {
      const c = colsData[st.sort.i], dir = st.sort.dir;
      const keyed = shown.map(a => [colSortValue(c, a), a]);
      keyed.sort((x, y) => compareValues(x[0], y[0], dir));
      shown = keyed.map(x => x[1]);
    }
    const pages = Math.max(1, Math.ceil(shown.length / SIZE));
    if (st.page > pages) st.page = pages;
    pageRows = shown.slice((st.page - 1) * SIZE, st.page * SIZE);
    headBox = h("input", { type: "checkbox", class: "inv-tick-all", "aria-label": "Select every asset on this page" });
    headBox.addEventListener("change", () => {
      pageRows.forEach(a => headBox.checked ? add(a.key) : st.sel.delete(a.key));
      if (headBox.checked && st.sel.size >= SEL_MAX) msg.textContent = "At most " + SEL_MAX + " can be selected at once.";
      refreshSel();
    });
    const cols = [{ label: headBox, nosort: true, cell: a => {
      const c = h("input", { type: "checkbox", class: "inv-tick", checked: st.sel.has(a.key), "aria-label": "Select " + a.name });
      c.addEventListener("change", () => {
        if (c.checked) { add(a.key); if (!st.sel.has(a.key)) { c.checked = false; msg.textContent = "At most " + SEL_MAX + " can be selected at once."; } }
        else st.sel.delete(a.key);
        refreshSel();
      });
      return c;
    } }].concat(colsData);
    box.replaceChildren(shown.length
      ? plusTable(cols, pageRows, invDetail, { open: st.open, key: a => a.key, rowClass: a => st.sel.has(a.key) ? "inv-picked" : "",
          rowKey: a => a.key, sort: st.sort ? { i: st.sort.i + 1, dir: st.sort.dir } : null,
          onSort: i => { const j = i - 1; st.sort = st.sort && st.sort.i === j ? (st.sort.dir === 1 ? { i: j, dir: -1 } : null) : { i: j, dir: 1 }; st.page = 1; paint(); } })
      : h("div", { class: "empty" }, h("p", null, opts.empty)),
      pager(st.page, pages, shown.length, SIZE, p => { st.page = p; paint(); window.scrollTo({ top: 0 }); }));
    refreshSel();
    if (opts.onPaint) opts.onPaint();
  }
  // Export only the ticked (and visible) rows, as the page's export would (PDF with the logo, or CSV)
  const expBtns = ["pdf", "csv"].map(fmt => {
    const b = h("button", { type: "button", class: "btn btn-quiet inv-act inv-exp", disabled: true,
      title: "Export the selected rows as " + fmt.toUpperCase() }, fmt === "pdf" ? invIcon("export") : null, h("span", null, fmt.toUpperCase()));
    b.addEventListener("click", async () => {
      const rows = eff();
      if (!rows.length || !opts.exportSpec) { msg.textContent = "Nothing selected to export."; return; }
      const spec = opts.exportSpec(rows);
      msg.textContent = "Preparing the " + fmt.toUpperCase() + "…";
      try {
        const n = await postDownload("/export/table", { title: spec.title + " (" + rows.length + " selected)", filter: "selected rows",
          columns: spec.columns, rows: spec.rows.map(r => r.map(v => v === undefined ? null : v)), format: fmt });
        msg.textContent = "Downloaded " + fmt.toUpperCase() + " (" + n + " row" + (n === "1" ? ")" : "s)");
      } catch (e) { msg.textContent = "Export failed: " + (e.message || e.status); }
    });
    return b;
  });
  const bar = h("div", { class: "inv-bar" }, search, srcSel);
  const toolsEl = opts.tools ? opts.tools(st, msg, () => paint()) : null;
  const actBar = h("div", { class: "inv-actbar" }, btns, toolsEl,
    h("span", { class: "inv-exp-l small muted" }, "Export selected:"), expBtns, selInfo);
  // The page's own selection, so the portal-wide Export and E-mail can offer "selected rows"
  const api_ = { bar, actBar, box, msg, paint, state: st, shown: () => shown, selected: eff, exportSpecSet: fn => { opts.exportSpec = fn; } };
  setPageSelection(() => { const rows = eff(); return rows.length && opts.exportSpec ? opts.exportSpec(rows) : null; });
  return api_;
}

function invFindings(list) {
  if (!list || !list.length) return h("p", { class: "muted small inv-ok" }, invIcon("approved"), " AI-01 check: the sources agree; nothing to look at.");
  return h("details", { class: "inv-find" },
    h("summary", null, invIcon("ai"), " AI-01 check: " + list.length + " thing" + (list.length === 1 ? "" : "s") + " to look at"),
    list.map(f => h("div", { class: "inv-f inv-f-" + f.level },
      h("strong", null, f.title), h("p", { class: "small" }, f.text),
      h("ul", { class: "small" }, f.items.slice(0, 10).map(x => h("li", null, x)),
        f.items.length > 10 ? h("li", { class: "muted" }, "and " + (f.items.length - 10) + " more") : null))));
}

// A small donut (part of the whole, by type) and small rings (one share against the whole)
function miniDonut(title, segs, onPick, picked) {
  const total = segs.reduce((a, x) => a + (x.value || 0), 0);
  const R = 30, SW = 9, C = 2 * Math.PI * R, live = segs.filter(x => x.value > 0), GAP = live.length > 1 ? 2 : 0;
  const ring = svg("g", { transform: "rotate(-90 40 40)" }, svg("circle", { cx: 40, cy: 40, r: R, class: "dn-track", "stroke-width": SW, fill: "none" }));
  let start = 0;
  live.forEach(x => {
    const len = Math.max(0.8, (x.value / total) * C - GAP);
    const arc = svg("circle", { cx: 40, cy: 40, r: R, fill: "none", "stroke-width": SW, class: "dn-seg dn-link " + x.cls + (picked && picked !== x.key ? " inv-dim" : ""),
      "stroke-dasharray": len + " " + (C - len), "stroke-dashoffset": -start },
      svg("title", null, x.label + ": " + x.value + " (" + Math.round(100 * x.value / total) + "%)"));
    arc.addEventListener("click", () => onPick(x.key));            // the legend's buttons do the same from the keyboard
    ring.append(arc);
    start += (x.value / total) * C;
  });
  const pic = svg("svg", { viewBox: "0 0 80 80", class: "inv-dn-svg", "aria-hidden": "true", focusable: "false" }, ring,
    svg("text", { x: 40, y: 44, "text-anchor": "middle", class: "inv-dn-n" }, String(total)));
  return h("section", { class: "inv-dn", "aria-label": title }, h("h3", { class: "inv-dn-h" }, title),
    h("div", { class: "inv-dn-b" }, pic, h("ul", { class: "inv-dn-leg" }, segs.map(x => h("li", { class: (x.value ? "" : "dn-zero") + (picked === x.key ? " inv-on" : "") },
      h("button", { type: "button", class: "btn-link", on: { click: () => onPick(x.key) } },
        h("span", { class: "dn-key " + x.cls, "aria-hidden": "true" }), h("span", null, x.label)), h("span", { class: "dn-v" }, String(x.value)))))));
}

function miniRing(title, n, total, cls, note, href) {
  const pct = total ? Math.floor(100 * n / total) : null;
  const R = 30, SW = 9, C = 2 * Math.PI * R, len = pct === null ? 0 : Math.max(pct ? 0.8 : 0, C * n / total);
  const pic = svg("svg", { viewBox: "0 0 80 80", class: "inv-dn-svg", "aria-hidden": "true", focusable: "false" },
    svg("g", { transform: "rotate(-90 40 40)" }, svg("circle", { cx: 40, cy: 40, r: R, class: "dn-track", "stroke-width": SW, fill: "none" }),
      len ? svg("circle", { cx: 40, cy: 40, r: R, fill: "none", "stroke-width": SW, class: "dn-seg " + cls, "stroke-dasharray": len + " " + (C - len) }) : null),
    svg("text", { x: 40, y: 44, "text-anchor": "middle", class: "inv-dn-n" }, pct === null ? "–" : pct + "%"));
  const body = h("div", { class: "inv-dn-b" }, pic, h("p", { class: "inv-dn-note" }, h("strong", null, String(n)), " of " + total, h("br"), h("span", { class: "muted" }, note)));
  return h(href ? "a" : "section", Object.assign({ class: "inv-dn inv-ring", "aria-label": title + ": " + (pct === null ? "none" : pct + "%") }, href ? { href } : {}),
    h("h3", { class: "inv-dn-h" }, title), body);
}

const INV_TYPES = [["all", "Master", "master"], ["server", "Servers", "server"], ["client", "Laptop/Desktop", "client"], ["esxi", "ESXi", "esxi"],
  ["appliance", "Appliances", "appliance"], ["network", "Network", "network"], ["firewall", "Firewalls", "firewall"], ["unknown", "Unknown", "unknown"],
  ["off", "Powered off", "off"], ["templates", "Templates", "template"], ["hardware", "Hardware", "hardware"]];
const POWER_WORD = { poweredOff: "Powered off", suspended: "Suspended", poweredOn: "Powered on" };

// The Hardware tab: physical machines that some source describes (make, model, serial, CPU or memory),
// one row per physical box: two names with the same serial number are the same box, shown once.
function hardwareRows(assets) {
  const hasHw = a => { const x = a.hardware || {}; return x.physical && (x.manufacturer || x.model || x.serial || x.cpu || x.memory_gb); };
  const out = [], bySerial = new Map();
  assets.filter(a => hasHw(a) && !a.powered_off).forEach(a => {
    const serial = String((a.hardware || {}).serial || "").trim().toUpperCase();
    if (serial && bySerial.has(serial)) {
      // The same box under another name: one row, with what either record knows
      const row = bySerial.get(serial);
      row.aka.push(a.name);
      if (!row.location && a.location) row.location = a.location;
      const x = row.hardware, y = a.hardware || {};
      row.hardware = Object.assign({}, x, ...["manufacturer", "model", "cpu", "memory_gb"].filter(k => !x[k] && y[k]).map(k => ({ [k]: y[k] })));
      return;
    }
    const row = Object.assign({}, a, { aka: [], hardware: Object.assign({}, a.hardware) });
    if (serial) bySerial.set(serial, row);
    out.push(row);
  });
  return out;
}

async function renderAssets(params) {
  let d = await api("/inventory/assets?view=active");
  const perms = new Set(d.perms || []);
  const want = params.get("type") || params.get("cat");
  let type = INV_TYPES.some(t => t[0] === want) ? want : "all";
  let status = params.get("status") || "all";
  const donuts = h("div", { class: "inv-dns", role: "group", "aria-label": "Overview" });
  const tabs = h("div", { class: "inv-types", role: "tablist", "aria-label": "Asset types" });
  const tiles = h("div", { class: "av-tiles", role: "group", "aria-label": "Status" });
  const findBox = h("div");
  const isHw = () => type === "hardware";
  const isOff = () => type === "off";
  const isTpl = () => type === "templates";
  const tplRows = () => (d.templates || []).map(t => ({ key: "tpl-" + t.vcenter + "-" + t.moref, name: t.name || t.moref, os: t.guest_os, ips: [],
    sources: ["vcenter"], detected: ["vCenter"], location: t.vcenter_host, device: "unknown", status: "new", tpl: t }));
  const created = a => (a.vm && a.vm.created) || (a.tpl && a.tpl.create_date) || null;
  const createdCell = a => created(a) ? h("span", { title: fmtDateTime(created(a)) }, fmtDateTime(created(a)).replace(/,? \d{1,2}:\d{2}.*$/, "")) : h("span", { class: "muted" }, "–");
  const setType = k => {
    type = type === k && k !== "all" ? "all" : k; list.state.page = 1;
    try { history.replaceState(null, "", "#/assets" + (type === "all" ? "" : "?type=" + type)); } catch (e) { /* the hash stays */ }
    list.paint();
  };
  const devCell = a => h("span", { class: "inv-dev", title: a.device_reason + " (" + (INV_FROM[a.device_from] || "") + ")" }, invIcon(a.device), INV_DEV[a.device],
    a.device_from === "ai" ? h("span", { class: "inv-ai", title: "Placed by AI-01: " + a.device_reason }, "AI") : null,
    a.device_from === "person" ? h("span", { class: "inv-ai inv-person", title: "Set by a person" }, "set") : null);
  const nameCell = a => a.host_id && routeAllowed("host") ? h("a", { href: "#/host/" + a.host_id }, h("strong", null, a.name)) : h("strong", null, a.name);
  const hw = a => a.hardware || {};
  const list = invList({
    perms, rows: () => isTpl() ? tplRows() : isHw() ? hardwareRows(d.assets || []) : (d.assets || []),
    // Powered-off VMs and templates are kept apart: never in Master or a type tab
    filter: a => isTpl() || (isOff() ? a.powered_off : !a.powered_off && (type === "all" || isHw() || a.device === type))
      && (isTpl() || status === "all" || a.status === status),
    allowActions: () => !isTpl(),
    empty: "No assets match.",
    reload: async () => { d = await api("/inventory/assets?view=active"); findBox.replaceChildren(invFindings(d.findings)); },
    actions: [
      { perm: "approve", icon: "approved", label: "Approve", title: "Confirm the selected machines as assets",
        ask: n => "The " + (n === 1 ? "machine is" : n + " machines are") + " marked Approved, with your name and the time.",
        done: n => n + " approved." },
      { perm: "decom", icon: "decom", label: "Decom", title: "Move the selected machines to the Decommissioned page",
        ask: n => "The " + (n === 1 ? "machine moves" : n + " machines move") + " to the Decommissioned page, with your name, the time and this reason. Revoke there brings "
          + (n === 1 ? "it" : "them") + " back.", done: n => n + " moved to Decommissioned." },
      { perm: "revoke", icon: "revoke", label: "Revoke", title: "Take back the approval of the selected machines",
        ask: n => "The approval of " + (n === 1 ? "this machine" : "these " + n + " machines") + " is taken back: " + (n === 1 ? "it goes" : "they go") + " back to New.",
        done: n => n + " back to New." },
    ],
    // A person corrects the type of the ticked machines (Approve permission); "Automatic" hands them back to the rules and AI-01
    tools: (st, msg, repaint) => {
      if (!perms.has("approve")) return null;
      const sel = h("select", { class: "inv-settype", "aria-label": "Set the device type of the selected machines" },
        h("option", { value: "" }, "Set type…"), Object.entries(INV_DEV).filter(([k]) => k !== "unknown").map(([k, l]) => h("option", { value: k }, l)),
        h("option", { value: "auto" }, "Automatic (rules and AI-01)"));
      sel.addEventListener("change", async () => {
        const v = sel.value; sel.value = "";
        const keys = st.eff();
        if (!v || !keys.length) { if (!keys.length) msg.textContent = "Tick the machines first."; return; }
        const label = v === "auto" ? "automatic" : INV_DEV[v];
        const note = await invAsk("Set " + keys.length + " to " + label, v === "auto"
          ? "The rules and AI-01 decide the type again." : "This type wins over the rules and AI-01 until someone sets it back to Automatic."
            + (["server", "client"].includes(v) ? "" : " A server or PC given this type is still checked for WSUS and Apex."),
          !["auto", "server", "client"].includes(v), "Set type");
        if (note === null) return;
        try {
          const r = await apiPost("/inventory/assets/type", { keys, device: v, reason: note || null });
          msg.textContent = r.done + " set to " + label + ".";
          keys.forEach(k => st.sel.delete(k)); await list.reload(); repaint();
        } catch (e) { msg.textContent = e.message; }
      });
      return sel;
    },
    columns: () => isTpl() ? [
      { label: "Template", cell: a => h("strong", null, a.name) },
      { label: "Operating system", cell: a => a.os || h("span", { class: "muted" }, "–") },
      { label: "vCenter", cell: a => h("span", { class: "small" }, a.location || "–") },
      { label: "Folder", cell: a => h("span", { class: "small" }, a.tpl.folder_path || "–") },
      { label: "CPU", cell: a => a.tpl.num_cpu ? String(a.tpl.num_cpu) : "–" },
      { label: "Memory", cell: a => a.tpl.memory_mb ? Math.round(a.tpl.memory_mb / 1024) + " GB" : "–" },
      { label: "Disk", cell: a => a.tpl.storage_mb ? Math.round(a.tpl.storage_mb / 1024) + " GB" : "–" },
      { label: "Created", sort: a => created(a) ? Date.parse(created(a)) : 0, cell: createdCell },
      { label: "Notes", cell: a => a.tpl.annotation ? h("span", { class: "small inv-why", title: a.tpl.annotation }, a.tpl.annotation.slice(0, 80)) : h("span", { class: "muted" }, "–") },
    ] : isOff() ? [
      { label: "Hostname", cell: nameCell },
      { label: "Device", cell: devCell },
      { label: "Operating system", cell: a => a.os || h("span", { class: "muted" }, "–") },
      { label: "IP", cell: a => h("span", { class: "mono" }, invIps(a)) },
      { label: "vCenter", cell: a => h("span", { class: "small" }, (a.vm || {}).vcenter || "–") },
      { label: "Folder", cell: a => h("span", { class: "small" }, (a.vm || {}).folder || "–") },
      { label: "Power", cell: a => h("span", { class: "inv-st inv-st-off" }, POWER_WORD[(a.vm || {}).power] || "Powered off") },
      { label: "VM created", sort: a => created(a) ? Date.parse(created(a)) : 0, cell: createdCell },
      { label: "Approval", cell: invStatus },
      { label: "Last detected", sort: a => a.last_detected ? Date.parse(a.last_detected) : null, cell: a => a.last_detected ? h("span", { title: fmtDateTime(a.last_detected) }, timeAgo(a.last_detected)) : h("span", { class: "muted" }, "–") },
    ] : isHw() ? [
      { label: "Hostname", cell: a => [nameCell(a), a.aka.length ? h("div", { class: "muted small", title: "Same serial number" }, "also " + a.aka.join(", ")) : null] },
      { label: "Type", cell: devCell },
      { label: "Make", cell: a => hw(a).manufacturer || h("span", { class: "muted" }, "–") },
      { label: "Model", cell: a => hw(a).model || h("span", { class: "muted" }, "–") },
      { label: "Serial", cell: a => hw(a).serial ? h("span", { class: "mono" }, hw(a).serial) : h("span", { class: "muted" }, "–") },
      { label: "CPU", cell: a => hw(a).cpu ? h("span", { class: "small" }, hw(a).cpu) : h("span", { class: "muted" }, "–") },
      { label: "Memory", cell: a => hw(a).memory_gb ? hw(a).memory_gb + " GB" : h("span", { class: "muted" }, "–") },
      { label: "Location", cell: a => a.location ? h("span", { class: "small" }, a.location) : h("span", { class: "muted" }, "–") },
    ] : [
      { label: "Hostname", cell: nameCell },
      { label: "Device", cell: devCell },
      { label: "Operating system", cell: a => a.os || h("span", { class: "muted" }, "–") },
      { label: "IP", cell: a => h("span", { class: "mono", title: a.ips.join(", ") }, invIps(a)) },
      { label: "Detected", cell: invDetected },
      { label: "Location", cell: a => a.location ? h("span", { class: "small inv-loc inv-loc-" + a.location_kind,
          title: a.location_kind === "physical" ? "Not in any vCenter PATCH-01 reads: told apart by its type" : a.location_kind === "virtual" ? "The vCenter that runs this VM" : null }, a.location) : h("span", { class: "muted" }, "–") },
      { label: "Status", cell: invStatus },
      { label: "VM created", sort: a => created(a) ? Date.parse(created(a)) : 0, cell: createdCell },
      { label: "Last detected", sort: a => a.last_detected ? Date.parse(a.last_detected) : null, cell: a => a.last_detected ? h("span", { title: fmtDateTime(a.last_detected) }, timeAgo(a.last_detected)) : h("span", { class: "muted" }, "–") },
    ],
    exportSpec: rows => exportOf(rows),
    onPaint: () => {
      let s = d.summary || {}, c = d.status || {}, cov = d.coverage || {};
      const live = (d.assets || []).filter(a => !a.powered_off);
      const active = live.length;
      donuts.replaceChildren(
        miniDonut("Assets by type", Object.keys(INV_DEV).map(k => ({ key: k, label: INV_CAT[k], value: (s[k] || {}).total || 0, cls: INV_COL[k] }))
          .filter(x => x.value || x.key !== "unknown"), setType, type !== "all" && type !== "hardware" ? type : null),
        miniRing("Approved", c.approved || 0, (d.assets || []).length, "c-ok", (c.new || 0) + " awaiting approval"),
        miniRing("Windows in WSUS", cov.windows_in_wsus || 0, cov.windows || 0, "c-cat1", "servers and PCs", "#/assets-coverage?missing=wsus"),
        miniRing("Windows in Apex", cov.windows_in_apex || 0, cov.windows || 0, "c-cat3", "antivirus agent", "#/assets-coverage?missing=apex"));
      const count = k => k === "all" ? active : k === "hardware" ? hardwareRows(d.assets || []).length : k === "off" ? (d.assets || []).length - active
        : k === "templates" ? (d.templates || []).length : ((s[k] || {}).total || 0);
      tabs.replaceChildren(...INV_TYPES.filter(([k]) => !["unknown", "templates", "off"].includes(k) || count(k)).map(([k, l, icon]) =>
        h("button", { type: "button", role: "tab", class: "inv-type", "aria-selected": String(type === k), on: { click: () => setType(k) } },
          invIcon(icon), h("span", null, l), h("span", { class: "inv-type-n" }, String(count(k))))));
      const t = (k, n, label, icon, on, pressed, href) => h(href ? "a" : "button", href ? { class: "av-tile inv-t-" + k, href }
        : { type: "button", class: "av-tile inv-t-" + k, "aria-pressed": String(!!pressed), on: { click: on } },
        invIcon(icon), h("span", { class: "av-n" }, String(n || 0)), h("span", { class: "av-l" }, label));
      // Status counts follow the tab's rows: Master never counts the powered-off VMs it hides
      const base = isOff() ? (d.assets || []).filter(a => a.powered_off) : live;
      c = Object.assign({}, c, { new: base.filter(a => a.status === "new").length, approved: base.filter(a => a.status === "approved").length });
      tiles.replaceChildren(
        t("new", c.new, "Awaiting approval", "new", () => { status = status === "new" ? "all" : "new"; list.state.page = 1; list.paint(); }, status === "new"),
        t("approved", c.approved, "Approved", "approved", () => { status = status === "approved" ? "all" : "approved"; list.state.page = 1; list.paint(); }, status === "approved"),
        t("decom", c.decommissioned, "Decommissioned", "decom", null, false, "#/assets-decom"),
        t("gap", d.gaps, "Coverage gaps", "gap", null, false, "#/assets-coverage"));
    },
  });
  function exportOf(rows) {
    if (isTpl()) return { title: "VM templates", columns: ["Template", "Operating system", "vCenter", "Folder", "CPU", "Memory (GB)", "Disk (GB)", "Created", "Notes"],
      rows: rows.map(a => [a.name, a.os || "", a.location || "", a.tpl.folder_path || "", a.tpl.num_cpu || "", a.tpl.memory_mb ? Math.round(a.tpl.memory_mb / 1024) : "",
        a.tpl.storage_mb ? Math.round(a.tpl.storage_mb / 1024) : "", created(a) ? fmtDateTime(created(a)) : "", a.tpl.annotation || ""]) };
    if (isOff()) return { title: "Powered-off VMs", columns: ["Hostname", "Device", "Operating system", "IP addresses", "vCenter", "Folder", "Power", "VM created",
        "Approval", "Last detected"],
      rows: rows.map(a => [a.name, INV_DEV[a.device], a.os || "", a.ips.join(" "), (a.vm || {}).vcenter || "", (a.vm || {}).folder || "",
        POWER_WORD[(a.vm || {}).power] || "Powered off", created(a) ? fmtDateTime(created(a)) : "", INV_STATUS[a.status], a.last_detected ? fmtDateTime(a.last_detected) : ""]) };
    if (isHw()) return { title: "Hardware assets", columns: ["Hostname", "Also named", "Type", "Make", "Model", "Serial", "CPU", "Memory (GB)", "Location"],
      rows: rows.map(a => [a.name, (a.aka || []).join(" "), INV_DEV[a.device], hw(a).manufacturer || "", hw(a).model || "", hw(a).serial || "", hw(a).cpu || "",
        hw(a).memory_gb || "", a.location]) };
    return { title: type === "all" ? "Master assets" : INV_CAT[type] + " assets",
      columns: ["Hostname", "Device", "Why this device", "Operating system", "IP addresses", "Detected", "Location", "Make", "Model", "Serial", "Status",
        "Approved by", "Approved at", "VM created", "Last detected"],
      rows: rows.map(a => [a.name, INV_DEV[a.device], a.device_reason, a.os, a.ips.join(" "), a.detected.join(" "), a.location, hw(a).manufacturer || "",
        hw(a).model || "", hw(a).serial || "", INV_STATUS[a.status], a.approved_by || "", a.approved_at ? fmtDateTime(a.approved_at) : "",
        created(a) ? fmtDateTime(created(a)) : "", a.last_detected ? fmtDateTime(a.last_detected) : ""]) };
  }
  list.reload = async () => { d = await api("/inventory/assets?view=active"); findBox.replaceChildren(invFindings(d.findings)); };
  findBox.replaceChildren(invFindings(d.findings));
  const tools = [];
  if (perms.size) {
    const chk = h("button", { type: "button", class: "btn btn-quiet inv-tool", title: "AI-01 sorts the machines the rules cannot place, then the sources are checked against each other" },
      invIcon("ai"), h("span", null, "Check with AI-01"));
    chk.addEventListener("click", async () => {
      chk.disabled = true; list.msg.textContent = "AI-01 is checking the inventory. On this hardware it can take a minute…";
      try {
        const r = await apiPost("/inventory/check", {});
        list.msg.textContent = r.error ? "AI-01 could not answer (" + r.error + "); the types below are from the rules."
          : r.asked ? "AI-01 placed " + r.decided + " of " + r.asked + " machine" + (r.asked === 1 ? "" : "s") + " the rules could not." : "Checked. Nothing new for AI-01 to place.";
        d = await api("/inventory/assets?view=active"); findBox.replaceChildren(invFindings(d.findings)); list.paint();
      } catch (e) { list.msg.textContent = e.message; }
      chk.disabled = false;
    });
    tools.push(chk);
  }
  let upPanel = null;
  if (d.is_admin) {
    const up = h("button", { type: "button", class: "btn btn-quiet inv-tool", "aria-expanded": "false" }, invIcon("upload"), h("span", null, "Upload sheet"));
    upPanel = h("section", { class: "inv-up", hidden: true, "aria-label": "Upload an asset sheet" });
    up.addEventListener("click", () => {
      upPanel.hidden = !upPanel.hidden; up.setAttribute("aria-expanded", String(!upPanel.hidden));
      if (!upPanel.hidden && !upPanel.firstChild) invUploadPanel(upPanel, async () => { d = await api("/inventory/assets?view=active"); findBox.replaceChildren(invFindings(d.findings)); list.paint(); });
    });
    tools.push(up);
  }
  setPageExport(() => Object.assign({ filter: pageFilterText() }, exportOf(list.shown())));
  const sc = d.sources || {};
  const lu = d.last_upload;
  render(h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl inventory assets" }, "Master assets"), h("div", { class: "inv-tools" }, tools)),
    h("p", { class: "muted small" }, "Every machine, merged by host name from " + sc.agents + " agents, " + sc.vms + " VMs and " + sc.esxi
      + " ESXi hosts in vCenter, " + sc.wsus + " WSUS computers, " + (sc.apex || 0) + " Apex agents and " + (sc.manual || 0) + " rows of the uploaded sheet"
      + (lu ? " (" + lu.file_name + ", " + fmtDateTime(lu.applied_at) + ")" : "") + ". Each tab is a view of this one list. Hover a type for how it was decided."),
    donuts, tabs, tiles, upPanel, findBox, list.bar, list.actBar, list.msg, list.box);
  list.paint();
  invTabs("assets");
}

async function renderAssetsDecom(params) {
  let d = await api("/inventory/assets?view=decommissioned");
  const perms = new Set(d.perms || []);
  const still = a => !a.gone && a.last_detected && a.decom_at && new Date(a.last_detected) > new Date(a.decom_at) && a.sources.some(s => s !== "manual");
  const list = invList({
    perms, rows: () => d.assets || [], empty: "Nothing has been decommissioned.",
    reload: async () => { d = await api("/inventory/assets?view=decommissioned"); },
    actions: [{ perm: "revoke", icon: "revoke", label: "Revoke", title: "Bring the selected machines back to Assets",
      ask: n => (n === 1 ? "The machine goes" : "The " + n + " machines go") + " back to Assets, with the status " + (n === 1 ? "it" : "they") + " had before (Approved or New).",
      done: n => n + " back in Assets." }],
    columns: [
      { label: "Hostname", cell: a => h("strong", null, a.name) },
      { label: "Device", cell: a => h("span", { class: "inv-dev" }, invIcon(a.device), INV_DEV[a.device]) },
      { label: "Operating system", cell: a => a.os || "–" },
      { label: "IP", cell: a => h("span", { class: "mono" }, invIps(a)) },
      { label: "Location", cell: a => a.location || "–" },
      { label: "Decommissioned by", cell: a => h("strong", null, a.decom_by || "–") },
      { label: "Date and time", sort: a => a.decom_at ? Date.parse(a.decom_at) : null, cell: a => a.decom_at ? fmtDateTime(a.decom_at) : "–" },
      { label: "Reason", cell: a => h("span", { class: "small inv-reason", title: a.decom_reason || "" }, a.decom_reason || "–") },
      { label: "Approved by", cell: a => a.approved_by ? h("span", { class: "small" }, a.approved_by + " · " + fmtDateTime(a.approved_at)) : h("span", { class: "muted small" }, "never approved") },
      { label: "Now", cell: a => still(a) ? h("span", { class: "inv-st inv-st-warn", title: "Detected by " + a.detected.join(", ") + " after it was decommissioned" }, "still detected " + timeAgo(a.last_detected))
          : h("span", { class: "muted small" }, a.gone ? "not detected" : "–") },
    ],
  });
  const decomExport = rows => ({ title: "Decommissioned assets",
    columns: ["Hostname", "Device", "Operating system", "IP addresses", "Location", "Decommissioned by", "Decommissioned at", "Reason", "Approved by", "Approved at", "Still detected"],
    rows: rows.map(a => [a.name, INV_DEV[a.device], a.os, a.ips.join(" "), a.location, a.decom_by, a.decom_at ? fmtDateTime(a.decom_at) : "",
      a.decom_reason, a.approved_by || "", a.approved_at ? fmtDateTime(a.approved_at) : "", still(a) ? "yes" : ""]) });
  list.exportSpecSet && list.exportSpecSet(decomExport);
  setPageExport(() => Object.assign({ filter: pageFilterText() }, decomExport(list.shown())));
  render(h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl inventory decommissioned" }, "Decommissioned assets")),
    h("p", { class: "muted small" }, "Machines taken out of the inventory, with who did it, when and why. Each one's + shows the full history. "
      + "A machine still detected after its decommission date is flagged: it is still running, or its name was reused."),
    list.bar, list.actBar, list.msg, list.box);
  list.paint();
  invTabs("assets-decom");
}

const GAP_SRC = { wsus: "WSUS", apex: "Apex" };
const GAP_PRI = { high: "High", medium: "Medium", low: "Low" };

async function renderAssetsCoverage(params) {
  let d = await api("/inventory/coverage");
  const perms = new Set(d.perms || []);
  let miss = params.get("missing") || "all", pri = "all", reason = "all", q = "", page = 1;
  const SIZE = PAGE_SIZE;
  const tiles = h("div", { class: "av-tiles", role: "group", "aria-label": "Coverage" });
  const sumBox = h("div"), box = h("div"), msg = h("p", { class: "cm-meta inv-msg", role: "status" });
  const search = h("input", { type: "search", placeholder: "Machine, OS, location or reason", "aria-label": "Search gaps" });
  const priSel = h("select", { "aria-label": "Priority" }, h("option", { value: "all" }, "Any priority"),
    Object.entries(GAP_PRI).map(([k, l]) => h("option", { value: k }, l + " priority")));
  const reaSel = h("select", { "aria-label": "Reason" });
  search.addEventListener("input", () => { q = search.value.trim().toLowerCase(); page = 1; paint(); });
  priSel.addEventListener("change", () => { pri = priSel.value; page = 1; paint(); });
  reaSel.addEventListener("change", () => { reason = reaSel.value; page = 1; paint(); });
  let shown = [];
  function summary() {
    const s = d.summary;
    const run = perms.size ? h("button", { type: "button", class: "btn btn-quiet inv-tool" }, invIcon("ai"), h("span", null, s ? "Analyse again" : "Analyse with AI-01")) : null;
    if (run) run.addEventListener("click", async () => {
      run.disabled = true;
      msg.replaceChildren(h("span", { class: "hd-pulse" }), " AI-01 is reading the gaps. On this hardware it can take up to a minute…");
      try {
        const r = await apiPost("/inventory/coverage/analyse", {});
        d.summary = { text: r.text, source: r.source, created_at: new Date().toISOString(), created_by: "you" };
        msg.textContent = r.source === "ai" ? "" : "AI-01 did not answer, or used a number it was not given; the figures are shown instead.";
        summary();
      } catch (e) { msg.textContent = e.message; }
      run.disabled = false;
    });
    sumBox.replaceChildren(h("section", { class: "ai-card", "aria-label": "Coverage analysis" },
      h("div", { class: "ai-card-head" },
        h("span", { class: "ai-badge ai-small" }, h("span", { class: "ai-dot", "aria-hidden": "true" }),
          s && s.source === "ai" ? "AI-01 coverage analysis" : "Coverage summary"),
        h("span", { class: "muted small" }, s ? timeAgo(s.created_at) + (s.created_by ? " · " + s.created_by : "") + (s.source === "ai" ? "" : " · figures only, AI-01 not used") : "not analysed yet"),
        run),
      s ? s.text.split(/\n\s*\n/).map(p => h("p", null, p)) : h("p", { class: "muted small" },
        "Press Analyse: AI-01 writes the patterns and what to fix first from the counts below. Every number it uses is checked against them.")));
  }
  function paint() {
    const f = d.facts || {}, rows = d.rows || [];
    const cnt = k => rows.filter(r => r.missing === k && r.reason !== "apex_silent").length;
    const t = (k, n, label, icon, on, pressed) => h("button", { type: "button", class: "av-tile inv-t-" + k, "aria-pressed": String(!!pressed), on: { click: on } },
      invIcon(icon), h("span", { class: "av-n" }, String(n)), h("span", { class: "av-l" }, label));
    const toggle = k => () => { miss = miss === k ? "all" : k; page = 1; paint(); };
    setMailParams(["wsus", "apex", "silent"].includes(miss) ? { missing: miss } : {}, "asset_gaps");     // the e-mailed report matches the page
    tiles.replaceChildren(
      h("span", { class: "av-tile inv-t-cov" }, invIcon("wsus"), h("span", { class: "av-n" }, (f.windows_in_wsus_pct == null ? "–" : f.windows_in_wsus_pct + "%")), h("span", { class: "av-l" }, "of Windows in WSUS")),
      h("span", { class: "av-tile inv-t-cov" }, invIcon("shield"), h("span", { class: "av-n" }, (f.windows_in_apex_pct == null ? "–" : f.windows_in_apex_pct + "%")), h("span", { class: "av-l" }, "of Windows in Apex")),
      h("span", { class: "inv-sep", "aria-hidden": "true" }),
      t("mw", cnt("wsus"), "Missing in WSUS", "wsus", toggle("wsus"), miss === "wsus"),
      t("ma", cnt("apex"), "Missing in Apex", "gap", toggle("apex"), miss === "apex"),
      t("ms", rows.filter(r => r.reason === "apex_silent").length, "Apex not reporting", "silent", toggle("silent"), miss === "silent"),
      t("hi", f.high || 0, "High priority", "unknown", () => { pri = pri === "high" ? "all" : "high"; priSel.value = pri; page = 1; paint(); }, pri === "high"));
    const reasons = [...new Set(rows.map(r => r.reason))];
    if (reaSel.options.length !== reasons.length + 1) {
      reaSel.replaceChildren(h("option", { value: "all" }, "Any reason"), reasons.map(k => h("option", { value: k }, (d.reasons || {})[k] || k)));
      reaSel.value = reasons.includes(reason) ? reason : "all";
    }
    shown = rows.filter(r => (miss === "all" || (miss === "silent" ? r.reason === "apex_silent" : r.missing === miss && r.reason !== "apex_silent"))
      && (pri === "all" || r.priority === pri) && (reason === "all" || r.reason === reason)
      && (!q || [r.name, r.os, r.location, r.why].some(x => (x || "").toLowerCase().includes(q))));
    const pages = Math.max(1, Math.ceil(shown.length / SIZE));
    if (page > pages) page = pages;
    box.replaceChildren(shown.length ? table([
      { label: "Priority", nowrap: true, sort: r => ["high", "medium", "low"].indexOf(r.priority), cell: r => h("span", { class: "inv-st inv-pri-" + r.priority }, GAP_PRI[r.priority]) },
      { label: "Machine", nowrap: true, cell: r => h("strong", null, r.name) },
      { label: "Device", nowrap: true, cell: r => h("span", { class: "inv-dev" }, invIcon(r.device), INV_DEV[r.device]) },
      { label: "Operating system", cell: r => r.os || "–" },
      { label: "Detected by", cell: r => h("span", { class: "inv-srcs" }, r.detected.map(x => h("span", { class: "inv-src inv-" + x }, INV_SRC[x] || x))) },
      { label: "Missing in", nowrap: true, cell: r => h("span", { class: "inv-st inv-miss-" + r.missing }, r.reason === "apex_silent" ? "Apex (silent)" : GAP_SRC[r.missing]) },
      { label: "Why", cell: r => h("span", { class: "small inv-why" }, r.why) },
      { label: "What to do", cell: r => h("span", { class: "small inv-why" }, r.fix) },
      { label: "Location", cell: r => h("span", { class: "small" }, r.location || "–") },
    ], null, { paged: { key: "coverage", items: shown, page, size: SIZE, redraw: () => paint() } })
      : h("div", { class: "empty" }, h("p", null, rows.length ? "No gap matches." : "No gaps: every Windows machine is in WSUS and Apex.")),
    pager(page, pages, shown.length, SIZE, p => { page = p; paint(); window.scrollTo({ top: 0 }); }));
  }
  setMailParams(["wsus", "apex", "silent"].includes(miss) ? { missing: miss } : {}, "asset_gaps");
  setPageExport(() => ({ title: "Asset coverage gaps", filter: pageFilterText(),
    columns: ["Priority", "Machine", "Device", "Operating system", "IP", "Location", "Detected by", "Missing in", "Why", "What to do"],
    rows: shown.map(r => [GAP_PRI[r.priority], r.name, INV_DEV[r.device], r.os || "", r.ips.join(" "), r.location || "",
      r.detected.map(x => INV_SRC[x] || x).join(" "), r.reason === "apex_silent" ? "Apex (not reporting)" : GAP_SRC[r.missing], r.why, r.fix]) }));
  render(h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl inventory coverage" }, "Coverage")),
    h("p", { class: "muted small" }, "Which machines are missing in WSUS or in Apex Central, why, and what to do. A Windows machine should be in both; "
      + "a Linux machine in Apex once Apex covers any Linux machine. The reason comes from what the other sources show; AI-01 writes the summary from the counts. "
      + (d.apex_agents ? "" : "No Apex agent has been read yet (Admin > Antivirus), so every Windows machine shows as missing in Apex.")),
    tiles, sumBox, msg, h("div", { class: "inv-bar" }, search, priSel, reaSel), box);
  summary(); paint();
  invTabs("assets-coverage");
}

// ---- Uploading an asset sheet (admins) ------------------------------------------------
function invUploadPanel(panel, onApplied) {
  const file = h("input", { type: "file", accept: ".xlsx,.csv", "aria-label": "Asset sheet" });
  const go = h("button", { type: "button", class: "btn" }, "Upload and preview");
  const out = h("div", { class: "inv-up-out" });
  const recent = h("div", { class: "inv-up-recent" });
  panel.replaceChildren(h("h2", null, "Upload an asset sheet"),
    h("p", { class: "muted small" }, "Excel (.xlsx) or CSV, up to 5 MB and 5,000 rows. AI-01 reads the column headings and a few rows to work out which "
      + "column is the host name, IP, OS, device type, location, serial, owner and notes; its choice is checked against the cells. Every row is then "
      + "checked and tidied. You see the preview and can change the columns; nothing is saved until you press Apply. Rows become Manual assets, "
      + "matched to the other sources by host name, and wait for approval like any new machine."),
    h("div", { class: "inv-up-pick" }, file, go), out, recent);
  async function loadRecent() {
    try {
      const r = await api("/inventory/uploads");
      const rows = r.uploads || [];
      recent.replaceChildren(rows.length ? h("details", null, h("summary", { class: "small" }, "Earlier uploads (" + rows.length + ")"),
        h("ul", { class: "small" }, rows.map(u => h("li", null, u.file_name, " · ", u.uploaded_by, " · ", fmtDateTime(u.uploaded_at), " · ",
          u.status === "applied" ? "applied by " + u.applied_by + " (" + ((u.result || {}).saved || 0) + " saved)"
          : u.status === "preview" ? h("button", { type: "button", class: "btn-link", on: { click: async () => show(await api("/inventory/uploads/" + u.id)) } }, "open the preview")
          : u.status)))) : "");
    } catch (e) { recent.replaceChildren(h("p", { class: "muted small" }, e.message)); }
  }
  go.addEventListener("click", async () => {
    if (!file.files.length) { out.replaceChildren(h("p", { class: "hd-failed small" }, "Choose a file first.")); return; }
    const f = file.files[0];
    if (!/\.(xlsx|csv)$/i.test(f.name)) { out.replaceChildren(h("p", { class: "hd-failed small" }, "Choose an Excel (.xlsx) or CSV file.")); return; }
    if (f.size > 5 * 1024 * 1024) { out.replaceChildren(h("p", { class: "hd-failed small" }, "The file is over 5 MB.")); return; }
    go.disabled = true;
    out.replaceChildren(h("p", { class: "mw-status" }, h("span", { class: "hd-pulse" }), " Reading the sheet; AI-01 is working out the columns. This can take up to a minute."));
    const fd = new FormData(); fd.append("file", f);
    try {
      const res = await fetch("/api/v1/inventory/uploads", { method: "POST", headers: { "X-Requested-With": "patch01-dashboard", ...authHeaders() }, body: fd });
      if (res.status === 401) { clearAuth(); return renderSignIn("Your session has ended."); }
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new ApiError(res.status, detailText(data.detail) || httpReason(res));
      show(data);
      loadRecent();
    } catch (e) { out.replaceChildren(h("p", { class: "hd-failed" }, e.message)); }
    go.disabled = false;
  });
  function show(v) {
    if (v.status !== "preview") { out.replaceChildren(h("p", { class: "small" }, "This upload was " + v.status + ".")); return; }
    const BY = { ai: "AI-01 (checked against the cells)", rules: "the column headings", admin: "you" };
    const colOpt = (i) => {
      const sample = (v.samples || []).map(r => r[i]).filter(Boolean)[0];
      return (v.headers[i] || "(column " + (i + 1) + ")") + (sample ? " — e.g. " + String(sample).slice(0, 30) : "");
    };
    const grid = h("div", { class: "inv-map" }, v.fields.map(f => {
      const s = h("select", { "aria-label": "Column for " + f.label }, h("option", { value: "" }, "— not in the sheet —"),
        v.headers.map((x, i) => h("option", { value: String(i), selected: v.mapping[f.key] === i }, colOpt(i))));
      s.addEventListener("change", async () => {
        const m = {};
        grid.querySelectorAll("select").forEach((x, j) => { m[v.fields[j].key] = x.value === "" ? null : Number(x.value); });
        try { show(await apiSend("PATCH", "/inventory/uploads/" + v.id, { mapping: m })); }
        catch (e) { msg.textContent = e.message; }
      });
      return h("label", { class: f.key === "hostname" ? "inv-map-need" : null }, h("span", null, f.label + (f.key === "hostname" ? " (needed)" : "")), s);
    }));
    const c = v.counts || {};
    const replace = h("input", { type: "checkbox", disabled: !v.replace_allowed || !v.would_remove });
    const apply = h("button", { type: "button", class: "btn", disabled: v.need_hostname || !c.valid }, "Apply: save " + (c.valid || 0) + " row" + (c.valid === 1 ? "" : "s"));
    const discard = h("button", { type: "button", class: "btn btn-quiet" }, "Discard");
    const msg = h("p", { class: "cm-meta", role: "status" });
    apply.addEventListener("click", async () => {
      apply.disabled = true; discard.disabled = true; msg.textContent = "Saving…";
      try {
        const r = await apiPost("/inventory/uploads/" + v.id + "/apply", { replace: replace.checked });
        out.replaceChildren(h("p", { class: "inv-up-done" }, invIcon("approved"), " Saved " + r.saved + " row" + (r.saved === 1 ? "" : "s") + " from " + v.file_name + ": "
          + r.new + " new, " + r.known + " already found by a source, " + r.update + " updated"
          + (r.removed ? ", " + r.removed + " earlier Manual asset" + (r.removed === 1 ? "" : "s") + " removed" : "") + ". New machines wait for approval."));
        loadRecent(); onApplied();
      } catch (e) { msg.textContent = e.message; apply.disabled = false; discard.disabled = false; }
    });
    discard.addEventListener("click", async () => {
      try { await apiPost("/inventory/uploads/" + v.id + "/discard", {}); out.replaceChildren(h("p", { class: "small" }, "Discarded. Nothing was saved.")); loadRecent(); }
      catch (e) { msg.textContent = e.message; }
    });
    const tileC = (k, n, l) => h("span", { class: "av-tile inv-c-" + k }, h("span", { class: "av-n" }, String(n || 0)), h("span", { class: "av-l" }, l));
    out.replaceChildren(...[
      h("p", { class: "small" }, h("strong", null, v.file_name), " · sheet " + v.sheet + " · headings on row " + v.header_row + " · columns chosen by " + (BY[v.mapped_by] || v.mapped_by)),
      (v.notes || []).length ? h("ul", { class: "small hd-failed" }, v.notes.map(n => h("li", null, n))) : null,
      grid,
      v.need_hostname ? h("p", { class: "hd-failed small" }, "Choose the column that holds the host name.") : h("div", { class: "av-tiles" },
        tileC("rows", c.rows, "rows"), tileC("new", c.new, "new machines"), tileC("known", c.known, "already found by a source"),
        tileC("update", c.update, "update earlier upload"), tileC("fixed", c.fixed, "tidied"), tileC("skip", c.problems, "skipped (problems)")),
      v.need_hostname ? null : table([
        { label: "Row", num: true, cell: r => String(r.row) },
        { label: "Host name", cell: r => r.name ? h("strong", null, r.name) : h("span", { class: "muted" }, "–") },
        { label: "What happens", nowrap: true, cell: r => h("span", { class: "inv-st inv-act-" + r.action }, INV_ACT[r.action]) },
        { label: "IP", mono: true, cell: r => (r.ips || []).join(", ") || "–" },
        { label: "OS", cell: r => r.os || "–" },
        { label: "Device", cell: r => r.device ? INV_DEV[r.device] : "–" },
        { label: "Location", cell: r => r.location || "–" },
        { label: "Checks", cell: r => h("div", { class: "small inv-checks" },
            (r.problems || []).map(x => h("div", { class: "hd-failed" }, "✕ " + x)),
            (r.compare || []).map(x => h("div", { class: "inv-warn" }, "⚠ " + x)),
            (r.fixes || []).map(x => h("div", { class: "muted" }, "✓ " + x))) },
      ], v.rows || []),
      (v.rows || []).length < (c.rows || 0) ? h("p", { class: "muted small" }, "The first " + v.rows.length + " rows are shown: problems and changes first.") : null,
      h("label", { class: "check" }, replace, h("span", null, "Also remove Manual assets from earlier sheets that are not in this one"
        + (!v.would_remove ? " (none would be removed)" : !v.replace_allowed ? " (not offered: fewer than half the rows passed the checks)"
          : ": removes " + v.would_remove + " (" + v.would_remove_names.join(", ") + (v.would_remove > v.would_remove_names.length ? ", …" : "") + ")"))),
      h("div", { class: "form-actions" }, apply, discard), msg].filter(Boolean));
  }
  loadRecent();
}

// ---- Software › Windows software / Linux packages: each program, its versions, the servers that have it ----
// Names, versions and publishers come from the servers: only ever inserted as text (h()).
const SW_SUPPORT = { eol: ["End of life", "sw-sp-eol"], eos: ["End of support", "sw-sp-eos"], eol_soon: ["End of life soon", "sw-sp-soon"],
                     supported: ["Supported", "sw-sp-ok"] };
const SW_SHOW = { "": "Show: all", upgrade: "Upgrade available", support: "Past end of support or life", multi: "Several versions" };

function swSupport(s, short) {
  if (!s) return h("span", { class: "muted" }, "–");
  const [t, cls] = SW_SUPPORT[s.state] || [s.text, ""];
  const when = s.state === "eol" || s.state === "eol_soon" ? s.eol : s.eos || s.eol;
  return h("span", { class: "sw-sp " + cls, title: [s.eos ? "End of support " + fmtDate(s.eos) : "", s.eol ? "End of life " + fmtDate(s.eol) : "",
    s.note || ""].filter(Boolean).join(" · ") }, t + (when && !short && s.state !== "supported" ? " " + fmtDate(when) : ""));
}

async function renderSoftwareInventory(params, platformIn) {
  const platform = platformIn === "linux" ? "linux" : "windows";
  const win = platform === "windows";
  let cat = params.get("cat") || "server", q = params.get("q") || "", hostQ = params.get("host") || "";
  let show = Object.keys(SW_SHOW).includes(params.get("show") || "") ? params.get("show") || "" : "", pg = 1;
  const open = new Set();
  const box = h("div", { class: "sw-list" }), head = h("p", { class: "muted small" }), tiles = h("div", { class: "srv-tiles" });
  const say = h("p", { class: "cm-meta sw-msg", role: "status", "aria-live": "polite" });
  const tell = (t, bad) => { say.replaceChildren(...[].concat(t)); say.classList.toggle("hd-failed", !!bad); };
  const catBtns = [["server", "Servers"], ["client", "Clients"], ["all", "All"]].map(([k, l]) =>
    h("button", { type: "button", class: "fbtn", "data-k": k, on: { click: () => { cat = k; pg = 1; load(); } } }, l));
  const search = h("input", { type: "search", value: q, placeholder: win ? "Program or publisher" : "Package", "aria-label": "Search software" });
  const hostIn = h("input", { type: "search", value: hostQ, placeholder: "Server name", "aria-label": "Only on servers named" });
  const showSel = h("select", { "aria-label": "Show", on: { change: e => { show = e.target.value; pg = 1; draw(); } } },
    Object.entries(SW_SHOW).filter(([k]) => win || k !== "upgrade").map(([k, t]) => h("option", { value: k }, t)));
  showSel.value = show;
  let timer = null, last = null;
  const later = fn => { clearTimeout(timer); timer = setTimeout(fn, 350); };
  search.addEventListener("input", () => later(() => { q = search.value.trim(); pg = 1; load(); }));
  hostIn.addEventListener("input", () => later(() => { hostQ = hostIn.value.trim(); pg = 1; load(); }));

  const shown = () => (last ? last.programs : []).filter(p => !show
    || (show === "upgrade" && p.upgrade_servers > 0) || (show === "support" && (p.support === "eol" || p.support === "eos"))
    || (show === "multi" && p.versions.length > 1));

  setPageExport(() => {
    if (!last) return null;
    const rows = [];
    shown().forEach(p => p.versions.forEach(v => v.hosts.forEach(x => rows.push([p.name, p.publisher || "", v.version, x.arch || "",
      x.name, x.group || "", x.ip || "", x.installed_on || "",
      p.package ? p.package.version + (v.vs_package === "older" ? " (upgrade available)" : "") : "",
      v.support ? v.support.text + (v.support.eol ? " " + v.support.eol : v.support.eos ? " " + v.support.eos : "") : ""]))));
    return { title: (win ? "Windows software" : "Linux packages") + " (" + (cat === "all" ? "all machines" : INV_CAT[cat]) + ")",
             filter: [q ? '"' + q + '"' : "", hostQ ? "servers named " + hostQ : "", show ? SW_SHOW[show] : ""].filter(Boolean).join("; "),
             columns: [win ? "Program" : "Package", "Publisher", "Version", "64/32-bit", "Server", "Patch group", "Address", "Installed on",
                       "In Deployment", "Support"], rows };
  });

  // One version of a program: its servers (by 64/32-bit); tick servers, then choose what to do
  function versionBlock(p, v) {
    const byArch = new Map();
    v.hosts.forEach(x => { const a = x.arch || ""; if (!byArch.has(a)) byArch.set(a, []); byArch.get(a).push(x); });
    return [...byArch.entries()].map(([arch, hostsA]) => {
      const canAct = win && ((can("operator") && hasModule("lifecycle") && !!p.package) || (can("admin") && p.state === "removable"));
      const ticks = new Map();
      const actBtn = canAct ? h("button", { type: "button", class: "btn btn-quiet sw-act", disabled: true }, "Choose action…") : null;
      const sync = () => { if (actBtn) { const n = [...ticks.values()].filter(b => b.checked).length;
        actBtn.disabled = !n; actBtn.textContent = n ? "Choose action for " + n + " server" + (n === 1 ? "" : "s") + "…" : "Choose action…"; } };
      const cols = [
        canAct ? { label: "", cell: x => { const b = h("input", { type: "checkbox", "aria-label": "Choose " + x.name, on: { change: sync } });
          ticks.set(x.id, b); return b; } } : null,
        { label: "Server", nowrap: true, cell: x => routeAllowed("host") ? h("a", { href: "#/host/" + x.id }, x.name) : x.name },
        { label: "Patch group", cell: x => x.group || h("span", { class: "muted" }, "–") },
        { label: "Address", nowrap: true, cell: x => x.ip || h("span", { class: "muted" }, "–") },
        { label: "Installed on", nowrap: true, cell: x => x.installed_on ? fmtDate(x.installed_on) : h("span", { class: "muted" }, "–") },
      ].filter(Boolean);
      const tbl = table(cols, hostsA);
      const all = ticks.size ? h("button", { type: "button", class: "btn-link", on: { click: () => {
        const on = [...ticks.values()].some(b => !b.checked); ticks.forEach(b => { b.checked = on; }); sync(); } } }, "Tick all / none") : null;
      if (actBtn) actBtn.addEventListener("click", () => swActionDialog(p, v, arch,
        hostsA.filter(x => ticks.get(x.id) && ticks.get(x.id).checked), tell,
        () => { ticks.forEach(b => { b.checked = false; }); sync(); load().catch(() => {}); }));
      const vsPkg = p.package && v.vs_package === "older" ? h("span", { class: "sw-upg" }, "older than " + p.package.version + " in Deployment")
        : p.package && v.vs_package === "same" ? h("span", { class: "muted small" }, "same as Deployment") : null;
      return h("div", { class: "sw-vblock" + (v.vs_package === "older" ? " older" : "") },
        h("div", { class: "sw-vhead" }, h("strong", { class: "mono" }, v.version || "no version"),
          arch ? h("span", { class: "muted small" }, " · " + arch) : null,
          h("span", { class: "muted small" }, " · " + hostsA.length + " server" + (hostsA.length === 1 ? "" : "s")
            + (v.machines >= 500 ? " (the first 500 are shown: narrow with the server name filter)" : "")),
          vsPkg, v.support ? swSupport(v.support) : null,
          h("span", { class: "row-actions" }, all, ticks.size ? actBtn : null)),
        h("div", { class: "table-wrap" }, tbl));
    });
  }

  function programHead(p) {
    if (!win || !p.package || !can("operator") || !hasModule("lifecycle")) return null;
    const older = p.versions.filter(v => v.vs_package === "older").flatMap(v => v.hosts.map(x => x.id));
    const base = "#/deployment?tab=new&package=" + encodeURIComponent(p.package.id);
    return h("p", { class: "small sw-phead" }, h("span", null, "In Deployment: ", h("strong", null, p.package.name + " " + p.package.version), " "),
      older.length ? h("a", { class: "btn btn-quiet sw-act", href: base + "&action=upgrade&hosts=" + encodeURIComponent(older.slice(0, 500).join(",")) },
        "Upgrade " + older.length + " older server" + (older.length === 1 ? "" : "s") + "…") : null, " ",
      h("a", { class: "btn-link", href: base + "&action=install" }, "Install on more servers…"));
  }

  function draw() {
    const items = shown();
    const pages = Math.max(1, Math.ceil(items.length / PAGE_SIZE));
    pg = Math.min(pg, pages);
    const cols = [
      { label: win ? "Program" : "Package", sort: p => (p.name || "").toLowerCase(),
        cell: p => [h("strong", null, p.name), p.publisher ? h("div", { class: "muted small" }, p.publisher) : null] },
      { label: "Versions", sort: p => p.versions.length, cell: p => h("div", { class: "sw-vchips" },
          p.versions.slice(0, 6).map(v => h("span", { class: "sw-vchip" + (v.vs_package === "older" ? " older" : p.versions.length > 1 ? " multi" : ""),
            title: v.machines + " server(s)" + (v.vs_package === "older" ? " · older than Deployment" : "") }, (v.version || "no version") + " · " + v.machines)),
          p.versions.length > 6 ? h("span", { class: "muted small" }, "+" + (p.versions.length - 6) + " more") : null) },
      { label: "Servers", num: true, sort: p => p.machines, cell: p => [String(p.machines), h("span", { class: "sw-m-lbl" }, " server" + (p.machines === 1 ? "" : "s"))] },
      win ? { label: "Deployment", sort: p => p.upgrade_servers || (p.package ? 0.5 : 0), cell: p => !p.package ? h("span", { class: "muted" }, "–")
          : p.upgrade_servers ? h("span", { class: "sw-upg", title: p.package.name + " " + p.package.version + " is in Deployment" },
              p.package.version + " · upgrade " + p.upgrade_servers)
          : h("span", { class: "sw-sp sw-sp-ok", title: p.package.name + " " + p.package.version + " is in Deployment" }, p.package.version + " · up to date") } : null,
      { label: "Support", sort: p => ({ eol: 4, eos: 3, eol_soon: 2, supported: 1 })[p.support] || 0,
        cell: p => { const v = p.versions.find(x => x.support && x.support.state === p.support); return swSupport(v && v.support, true); } },
    ].filter(Boolean);
    box.replaceChildren(...[items.length ? plusTable(cols, items, p => [programHead(p), ...p.versions.flatMap(v => versionBlock(p, v))],
        { open, key: p => p.name, rowClass: p => (p.upgrade_servers ? "sw-row-upg" : "") + (p.support === "eol" ? " sw-row-eol" : ""),
          paged: { key: "sw-inv-" + platform, items, page: pg, size: PAGE_SIZE, redraw: () => draw() } })
      : h("div", { class: "empty" }, h("p", null, (last && last.programs.length) ? "Nothing matches the filter."
          : q || hostQ ? "Nothing matches." : "No software reported yet.")),
      pager(pg, pages, items.length, PAGE_SIZE, n => { pg = n; draw(); })].filter(Boolean));
  }

  async function load() {
    catBtns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === cat)));
    let d;
    try { d = await api("/inventory/software?platform=" + platform + "&category=" + cat + "&q=" + encodeURIComponent(q)
                        + "&host=" + encodeURIComponent(hostQ)); }
    catch (e) { if (e instanceof StaleRoute) throw e; box.replaceChildren(h("div", { class: "form-warn" }, e.message)); return; }
    last = d;
    const tile = (n, label, cls, key) => h(key !== undefined ? "button" : "div", { type: key !== undefined ? "button" : null,
      class: "srv-tile " + (cls || ""), "aria-pressed": key !== undefined ? String(show === key) : null,
      on: key !== undefined ? { click: () => { show = show === key ? "" : key; showSel.value = show; pg = 1; load(); } } : null },
      h("span", { class: "srv-tile-n" }, String(n || 0)), h("span", { class: "srv-tile-l" }, label));
    tiles.replaceChildren(...[
      tile(d.programs.length, win ? "Programs" : "Packages"),
      tile(d.machines, "Machines with an agent"),
      tile(d.multi_version, "With several versions", d.multi_version ? "t-warn" : "", "multi"),
      win ? tile(d.upgradable, "Upgrade available", d.upgradable ? "t-warn" : "", "upgrade") : null,
      tile(d.past_support, "Past end of support", d.past_support ? "t-off" : "", "support"),
    ].filter(Boolean));
    head.textContent = (cat === "all" ? "All machines" : INV_CAT[cat]) + " with an agent, from each one's own inventory. Open a program with + "
      + "to see each version and the servers that have it." + (win ? (d.packages ? " Compared with the " + d.packages + " package"
      + (d.packages === 1 ? "" : "s") + " in Deployment." : " Upload a package in Deployment to see which servers can be upgraded.") : "")
      + (d.lifecycle_rules ? "" : " Support dates come from Admin › Software rules.")
      + (d.truncated ? " The list is cut: search to narrow it." : "");
    draw();
  }

  render(h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl software " + platform }, win ? "Windows software" : "Linux packages")),
    h("div", { class: "inv-bar" }, h("div", { class: "filters", role: "group", "aria-label": "Type" }, catBtns)),
    h("div", { class: "srv-bar" }, search, hostIn, showSel),
    head, tiles, say, box);
  await load();
  invTabs(win ? "software-inventory" : "software-linux");
}

// The ticked servers of one version: upgrade or install from Deployment, or remove (admins)
function swActionDialog(p, v, arch, hosts, tell, done) {
  if (!hosts.length) return;
  const dlg = h("dialog", { class: "sw-dlg", "aria-label": p.name });
  const close = () => { if (dlg.open) dlg.close(); dlg.remove(); };
  dlg.addEventListener("close", () => dlg.remove());
  const ids = hosts.map(x => x.id).join(",");
  const choices = [];
  if (p.package && hasModule("lifecycle")) {
    const base = "#/deployment?tab=new&package=" + encodeURIComponent(p.package.id) + "&hosts=" + encodeURIComponent(ids);
    if (v.vs_package === "older") choices.push(["upgrade", "Upgrade to " + p.package.version, "From the package in Deployment", base + "&action=upgrade"]);
    choices.push(["install", "Install " + p.package.name + " " + p.package.version, "From the package in Deployment (never downgrades)", base + "&action=install"]);
  }
  const removable = can("admin") && p.state === "removable" && !!arch && hosts.some(x => x.how && x.agent_ok);
  if (removable) choices.push(["remove", "Remove " + v.version, "With the program's own silent uninstaller", null]);
  const pick = h("div", { class: "sw-choices", role: "radiogroup", "aria-label": "Action" });
  let chosen = null;
  const removeBox = h("div", { hidden: chosen !== "remove" });
  choices.forEach(([k, label, sub]) => {
    const r = h("input", { type: "radio", name: "sw-act", value: k, checked: k === chosen });
    r.addEventListener("change", () => { chosen = k; removeBox.hidden = k !== "remove"; go.disabled = false;
      go.textContent = k === "remove" ? "Remove" : "Continue in Deployment"; });
    pick.append(h("label", { class: "sw-choice" }, r, h("span", null, h("strong", null, label), h("span", { class: "muted small" }, " · " + sub))));
  });
  const reason = h("textarea", { rows: "2", maxlength: "2000", placeholder: "Why (kept in the job's record)" });
  const reboot = h("select", { "aria-label": "Restart" }, h("option", { value: "never" }, "Never restart (a restart may be needed later)"),
    h("option", { value: "if_required" }, "Restart if the uninstaller asks for it"));
  const when = h("input", { type: "datetime-local", "aria-label": "Start at (empty: now)" });
  removeBox.append(h("label", { class: "ns-wide" }, h("span", null, "Reason"), reason),
    h("div", { class: "av-grid" }, h("label", null, h("span", null, "Restart"), reboot), h("label", null, h("span", null, "Start at (empty: now)"), when)));
  const msg = h("p", { class: "cm-meta", role: "status" });
  const go = h("button", { type: "submit", class: "btn", disabled: true }, "Continue");
  dlg.append(h("form", { method: "dialog", on: { submit: async e => {
    e.preventDefault();
    const c = choices.find(x => x[0] === chosen);
    if (!c) return;
    if (c[3]) { close(); location.hash = c[3]; return; }
    if (reason.value.trim().length < 3) { msg.textContent = "Say why (at least 3 characters): it is kept in the record."; return; }
    go.disabled = true; msg.textContent = "Creating the job…";
    try {
      const body = { name: p.name, version: v.version, arch: arch, host_ids: hosts.map(x => x.id), reason: reason.value.trim(), reboot: reboot.value };
      if (when.value) body.run_after = new Date(when.value).toISOString();
      const r = await apiPost("/software/remove", body);
      close();
      if (done) done();
      tell(["Job ", h("a", { href: "#/change/" + r.id }, r.ref), " removes " + p.name + " " + v.version + " from " + r.servers
        + " server" + (r.servers === 1 ? "" : "s") + (when.value ? " at the chosen time." : " now.")]);
    } catch (err) { msg.textContent = err.message; go.disabled = false; }
  } } },
    h("h2", null, p.name),
    h("p", null, h("strong", { class: "mono" }, v.version || "no version"), (arch ? " · " + arch : "") + " · " + hosts.map(x => x.name).join(", ")),
    choices.length ? pick : h("p", { class: "muted" }, "Nothing can be done from here for this program yet: upload its installer in Deployment to upgrade or install it."),
    removeBox,
    h("div", { class: "cm-actions" }, go, h("button", { type: "button", class: "btn-quiet", on: { click: close } }, "Cancel"), msg)));
  document.body.append(dlg);
  dlg.showModal();
}

// ---- Admin › Software rules: the removable tools list, and end of support / end of life ----
async function renderSoftwareRules() {
  setNav("admin");
  if (!can("admin")) return render(h("div", { class: "empty" }, h("p", null, "Software rules need the admin role.")));
  const page = h("div", { class: "sw-tools" });
  render(page);
  const [tools, lc] = await Promise.all([api("/software/removable"), api("/software/lifecycle")]);
  const drawAll = (t, l) => {
    const msg = h("p", { class: "cm-meta", role: "status", "aria-live": "polite" });
    const input = h("input", { type: "text", maxlength: "80", placeholder: "Program name as it starts, e.g. Wireshark", "aria-label": "Tool name" });
    const add = h("form", { class: "sw-add", on: { submit: async e => {
      e.preventDefault();
      try {
        const r = await apiPost("/software/removable", { pattern: input.value.trim() });
        t = r; drawAll(t, l);
        const m = page.querySelector(".sw-add .cm-meta");
        if (m) m.textContent = "Added “" + r.added + "”. " + ((r.now_removable || []).length ? "It covers: " + r.now_removable.join(", ")
          + (r.now_removable.length >= 30 ? "…" : "") + "." : "No installed program matches it yet.");
      } catch (err) { msg.textContent = err.message; msg.classList.add("hd-failed"); }
    } } }, input, h("button", { type: "submit" }, "Add"), msg);
    // Lifecycle rule form
    const lmsg = h("p", { class: "cm-meta", role: "status", "aria-live": "polite" });
    const f = { platform: h("select", { "aria-label": "Platform" }, h("option", { value: "windows" }, "Windows"), h("option", { value: "linux" }, "Linux")),
      name_prefix: h("input", { type: "text", maxlength: "80", placeholder: "Product as it starts, e.g. Microsoft SQL Server", "aria-label": "Product" }),
      version_prefix: h("input", { type: "text", maxlength: "40", placeholder: "Version line (optional), e.g. 2016", "aria-label": "Version line" }),
      eos: h("input", { type: "date", "aria-label": "End of support" }), eol: h("input", { type: "date", "aria-label": "End of life" }),
      note: h("input", { type: "text", maxlength: "300", placeholder: "Note or source link (optional)", "aria-label": "Note" }) };
    let editing = null;
    const lsave = h("button", { type: "submit" }, "Add rule");
    const lform = h("form", { class: "sw-lcform", on: { submit: async e => {
      e.preventDefault();
      const body = Object.fromEntries(Object.entries(f).map(([k, el]) => [k, el.value.trim() || null]));
      body.version_prefix = body.version_prefix || "";
      try { const r = editing ? await apiSend("PUT", "/software/lifecycle/" + editing, body) : await apiPost("/software/lifecycle", body); l = r; drawAll(t, l); }
      catch (err) { lmsg.textContent = err.message; lmsg.classList.add("hd-failed"); }
    } } },
      h("div", { class: "av-grid" }, ...[["Platform", "platform"], ["Product", "name_prefix"], ["Version line", "version_prefix"],
        ["End of support", "eos"], ["End of life", "eol"], ["Note", "note"]].map(([lab, k]) => h("label", null, h("span", null, lab), f[k]))),
      h("div", { class: "cm-actions" }, lsave, lmsg));
    page.replaceChildren(
      h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl admin software-rules" }, "Software rules")),
      h("h2", null, "End of support and end of life"),
      h("p", { class: "muted small" }, "Each rule names a product as its name starts (and optionally a version line). Windows software and Linux packages show "
        + "every version's support state from the most specific rule: End of life, End of support, End of life soon (within 180 days) or Supported."),
      (l.rules || []).length ? h("div", { class: "table-wrap" }, table([
        { label: "Product", cell: r => [h("strong", null, r.name_prefix), r.version_prefix ? h("span", { class: "mono" }, " " + r.version_prefix) : null,
            h("div", { class: "muted small" }, r.platform === "linux" ? "Linux" : "Windows")] },
        { label: "End of support", nowrap: true, cell: r => r.eos ? fmtDate(r.eos) : "–" },
        { label: "End of life", nowrap: true, cell: r => r.eol ? fmtDate(r.eol) : "–" },
        { label: "Note", cell: r => r.note || "" },
        { label: "", cell: r => h("span", { class: "row-actions" },
          h("button", { type: "button", class: "btn-link", on: { click: () => {
            editing = r.id; Object.entries(f).forEach(([k, el]) => { el.value = r[k] ? String(r[k]).slice(0, k === "eos" || k === "eol" ? 10 : 300) : ""; });
            lsave.textContent = "Save rule"; f.name_prefix.focus(); } } }, "Edit"),
          h("button", { type: "button", class: "btn-link danger", on: { click: async () => {
            if (!confirm("Delete the rule for " + r.name_prefix + (r.version_prefix ? " " + r.version_prefix : "") + "?")) return;
            try { l = await apiSend("DELETE", "/software/lifecycle/" + r.id); drawAll(t, l); } catch (err) { alert(err.message); } } } }, "Delete")) },
      ], l.rules)) : h("p", { class: "muted" }, "No rules yet."),
      lform,
      h("h2", null, "Programs that may be removed"),
      h("p", { class: "muted small" }, "A Windows program can be removed from Windows software only when its name starts with an entry here (as a whole word), "
        + "and the server registered a silent uninstaller. Critical software is never removed, whatever this list says: "
        + (t.critical_examples || []).join(", ") + "."),
      add,
      h("div", { class: "table-wrap" }, table([
        { label: "Program name starts with", cell: x => h("strong", null, x.pattern) },
        { label: "Added", cell: x => x.builtin ? h("span", { class: "muted" }, "PATCH-01's starting list") : [x.created_by || "", " ", x.created_at ? timeAgo(x.created_at) : ""] },
        { label: "", cell: x => h("button", { type: "button", class: "btn-link danger", on: { click: async () => {
          if (!confirm("Take " + x.pattern + " off the list? Removals of it that no server has started yet are withdrawn.")) return;
          try { t = await apiPost("/software/removable/delete", { pattern: x.pattern }); drawAll(t, l); } catch (err) { alert(err.message); } } } }, "Take off") },
      ], t.tools || [])));
  };
  drawAll(tools, lc);
  adminTabs("software-rules");
}

// ---- Deployment: upload an MSI or EXE to PATCH-01, review it, install it on Windows servers ----
// Everything shown here that came from a file, AI-01 or a server is untrusted text:
// it is only ever inserted as text (h() uses text nodes), never as HTML.
const DEP_SCAN = { pending: ["Scanning", "st-running"], clean: ["Clean", "st-fixed_active"], infected: ["Malware found", "st-affected"],
                   failed: ["Scan failed", "st-warn"], off: ["Not scanned", "st-unknown"] };
const DEP_AI = { pending: "AI-01 is reading it", done: "described by AI-01", failed: "AI-01 could not describe it", off: "AI-01 not set up" };
const DEP_RUNNING = new Set(["pending_approval", "scheduled", "running"]);
let depUpload = null;            // the upload in progress: kept while the page redraws
const depOpen = new Set();       // packages and jobs opened with +
const depDirty = new Set();      // review forms with unsaved edits

function depMb(n) { return n >= 1073741824 ? (n / 1073741824).toFixed(2) + " GB" : (n / 1048576).toFixed(1) + " MB"; }
function depMark(map, k) { const [t, c] = map[k] || [k, "st-plain"]; return h("span", { class: "state " + c }, t); }

async function renderDeployment(params) {
  setNav("deployment");
  const tab = ["packages", "new", "jobs"].includes(params.get("tab")) ? params.get("tab") : "packages";
  const page = h("div", { class: "dep" });
  const [st, pk] = await Promise.all([api("/deploy/status"), api("/deploy/packages")]);
  const tabBtn = (k, label) => h("a", { class: "fbtn", href: "#/deployment?tab=" + k, "aria-pressed": String(tab === k) }, label);
  const facts = [];
  facts.push(st.available ? "storage: " + (st.free_gb === null ? "?" : st.free_gb + " GB free") + ", files up to " + st.max_mb + " MB"
                          : "package storage is not set up on PATCH-01 (run phase3b-api.sh of this release)");
  facts.push(!st.clamav.configured ? "ClamAV: not set up (optional: phase11-clamav.sh)"
             : st.clamav.reachable ? "ClamAV: " + (st.clamav.version || "on") : "ClamAV: NOT reachable (" + (st.clamav.error || "") + ")");
  facts.push(st.ai.configured ? "AI-01: on" : "AI-01: not set up");
  page.append(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure deployment" }, "Deployment"),
      h("span", { class: "head-actions" }, h("span", { class: "muted small" }, facts.join(" \u00b7 ")))),
    h("p", { class: "muted" }, "Upload an MSI or EXE, check what PATCH-01 and AI-01 read from it, save it, then install or upgrade it on Windows servers. "
      + "Each server's agent downloads it from PATCH-01 over its pinned connection, checks the SHA-256, saves it under C:\\tmp\\PATCH01 "
      + "(D:\\tmp\\PATCH01 when C: is short of space; \\tmp is created when missing) and installs it silently."),
    h("div", { class: "filters dep-tabs", role: "group", "aria-label": "Deployment" },
      tabBtn("packages", "Packages (" + (pk.items || []).length + ")"), tabBtn("new", "New deployment"), tabBtn("jobs", "Deployments")));
  render(page);
  if (tab === "packages") await depPackages(page, st, pk.items || [], params);
  else if (tab === "new") await depNew(page, pk.items || [], params);
  else await depJobs(page, params);
}

/* -- Packages ------------------------------------------------------------------------- */

async function depPackages(page, st, items, params) {
  const body = h("div");
  page.append(can("operator") ? depUploadBox(st) : null, body);
  const draw = list => {
    const cols = [
      { label: "Package", cell: p => h("span", null, h("strong", null, (p.name || "(not named yet)") + " " + (p.version || "")),
          h("div", { class: "muted small" }, p.file_name)) },
      { label: "Type", cell: p => h("span", null, p.kind.toUpperCase() + (p.install_mode === "portable" ? ", portable program" : ""),
          h("div", { class: "muted small" }, p.install_mode === "portable" ? "copied to Program Files\\PATCH01-Apps, never run"
            : (p.meta && p.meta.installer_label) || (p.app_type === "portable" ? "looks like a portable program: check it" : "installer not recognised"))) },
      { label: "Size", num: true, cell: p => depMb(Number(p.size_bytes)) },
      { label: "Antivirus", cell: p => h("span", { title: p.scan_result || "" }, depMark(DEP_SCAN, p.scan_state)) },
      { label: "AI-01", cell: p => h("span", { class: "muted small" }, DEP_AI[p.ai_state] || p.ai_state) },
      { label: "Status", cell: p => p.blocker ? h("span", { class: "dep-block" }, p.blocker) : h("span", { class: "state st-fixed_active" }, "Ready") },
      { label: "Deployed", cell: p => Number(p.jobs) ? h("span", null, p.jobs + (Number(p.jobs) === 1 ? " job" : " jobs"),
          h("div", { class: "muted small" }, (p.servers_ok || 0) + " ok, " + (p.servers_failed || 0) + " failed")) : h("span", { class: "muted" }, "not yet") },
      { label: "", nosort: true, cell: p => h("span", { class: "dep-acts" },
          !p.blocker && can("operator") ? h("a", { class: "btn btn-quiet", href: "#/deployment?tab=new&package=" + p.id }, "Deploy\u2026") : null,
          p.ready && can("admin") ? h("a", { class: "btn-link", href: "#/deployment?tab=new&action=uninstall&package=" + p.id }, "Remove from servers\u2026") : null) },
    ];
    body.replaceChildren(list.length
      ? plusTable(cols, list, p => depDetail(p, () => reload()), { open: depOpen, key: p => p.id, rowClass: p => p.scan_state === "infected" ? "pr-failed" : "" })
      : h("div", { class: "empty" }, h("p", null, "No packages yet."), h("p", { class: "muted small" }, "Upload an .msi or .exe above.")));
  };
  const reload = async () => { const d = await api("/deploy/packages"); if (page.isConnected) draw(d.items || []); };
  if (params.get("package")) depOpen.add(params.get("package"));
  draw(items);
  // While a scan or AI-01 is working, the list refreshes itself (never under someone's typing)
  setPageTimer(async () => {
    if (document.hidden || depUpload || depDirty.size || (document.activeElement && page.contains(document.activeElement) && document.activeElement.tagName !== "BODY")) return;
    const d = await api("/deploy/packages").catch(() => null);
    if (d && page.isConnected && (d.items || []).some(p => p.scan_state === "pending" || p.ai_state === "pending" || items.length !== d.items.length
        || items.some((q, i) => !d.items[i] || q.scan_state !== d.items[i].scan_state || q.ai_state !== d.items[i].ai_state))) {
      items = d.items || []; draw(items);
    }
  }, 10000);
}

function depUploadBox(st) {
  const file = h("input", { type: "file", accept: ".msi,.exe", "aria-label": "Installer file" });
  const bar = h("progress", { max: "100", value: "0", hidden: true });
  const msg = h("p", { class: "small", role: "status" });
  const cancel = h("button", { type: "button", class: "btn-link", hidden: !depUpload, on: { click: () => { if (depUpload) depUpload.cancel = true; } } }, "Cancel upload");
  const go = h("button", { type: "button", class: "btn", disabled: !st.available, on: { click: async () => {
    const f = file.files && file.files[0];
    if (depUpload) { msg.textContent = "An upload is already running: wait for it, or cancel it."; return; }
    if (!f) { msg.textContent = "Choose an .msi or .exe first."; return; }
    if (!/\.(msi|exe)$/i.test(f.name)) { msg.textContent = "Only .msi and .exe files can be deployed."; return; }
    if (f.size > st.max_mb * 1048576) { msg.textContent = "This file is larger than PATCH-01's limit of " + st.max_mb + " MB."; return; }
    go.disabled = true; file.disabled = true; bar.hidden = false; cancel.hidden = false; bar.value = 0;
    const mine = { id: null, cancel: false };
    depUpload = mine;
    try {
      const r = await depSendFile(f, mine, (done, total) => {
        bar.value = Math.floor(done * 100 / total);
        msg.textContent = "Uploading " + f.name + ": " + depMb(done) + " of " + depMb(total);
      }, t => { msg.textContent = t; });
      depOpen.add(r.package.id);
      msg.textContent = r.duplicate ? "This file is already on PATCH-01: opened below." : "Uploaded. Check its details below, then save them.";
      setTimeout(() => route(), 600);
    } catch (e) {
      msg.textContent = "Upload failed: " + (e.message || e);
    } finally {
      if (depUpload === mine) depUpload = null;
      go.disabled = false; file.disabled = false; cancel.hidden = true;
    }
  } } }, "Upload");
  return h("section", { class: "form-sec dep-up" }, h("h2", null, "Upload a package"),
    h("div", { class: "dep-up-row" }, file, go, cancel), bar, msg,
    h("p", { class: "muted small" }, "Sent in 16 MB pieces (no proxy size limit; an interrupted piece is sent again). "
      + "PATCH-01 keeps it under its SHA-256 and " + ["reads its version and installer type"]
        .concat(st.clamav.configured ? ["scans it with ClamAV"] : [], st.ai.configured ? ["asks AI-01 what it is and how to install it silently"] : [])
        .join(", ").replace(/, ([^,]*)$/, " and $1")
      + ". Nothing is installed anywhere until you deploy it."));
}

async function depSendFile(file, me, progress, status) {
  const start = await apiPost("/deploy/uploads", { file_name: file.name, size: file.size });
  const id = start.upload_id, chunk = start.chunk_bytes || 16777216;
  me.id = id;
  let off = 0, tries = 0;
  progress(0, file.size);
  while (off < file.size) {
    if (me.cancel) {
      await apiSend("DELETE", "/deploy/uploads/" + encodeURIComponent(id)).catch(() => {});
      throw new Error("cancelled; nothing was kept");
    }
    let res = null, detail = "";
    try {
      res = await fetch("/api/v1/deploy/uploads/" + encodeURIComponent(id) + "?offset=" + off, {
        method: "PUT", body: file.slice(off, Math.min(file.size, off + chunk)), cache: "no-store",
        headers: { "Content-Type": "application/octet-stream", "X-Requested-With": "patch01-dashboard", ...authHeaders() } });
    } catch (e) { res = null; detail = "the network connection dropped"; }
    if (res && res.ok) { const d = await res.json(); off = d.received; tries = 0; progress(off, file.size); continue; }
    if (res) { try { detail = detailText((await res.json()).detail); } catch (e) { detail = httpReason(res); } }
    if (res && res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
    const m = /expected the piece at (\d+)/.exec(detail);
    if (res && res.status === 409 && m) { off = Number(m[1]); progress(off, file.size); continue; }       // resume where PATCH-01 is
    const retry = !res || res.status >= 500 || res.status === 408 || res.status === 429;
    if (!retry || ++tries > 4) throw new Error(detail || "the upload stopped");
    status("A piece did not arrive (" + detail + "); sending it again (" + tries + " of 4)\u2026");
    await new Promise(r => setTimeout(r, 2000 * tries));
  }
  status("Checking the file on PATCH-01 (SHA-256, type, version)\u2026");
  return apiPost("/deploy/uploads/" + encodeURIComponent(id) + "/complete", {});
}

function depDetail(p, reload) {
  const m = p.meta || {};
  const kv = (k, v) => v === null || v === undefined || v === "" ? null : h("div", { class: "kv" }, h("dt", null, k), h("dd", null, v));
  const vi = m.version_info || {}, pr = m.properties || {};
  const factsEl = h("dl", { class: "srv-kv" },
    kv("File", p.file_name + " \u00b7 " + depMb(Number(p.size_bytes))),
    kv("SHA-256", h("span", { class: "mono" }, p.sha256)),
    kv("Uploaded", fmtDateTime(p.uploaded_at) + " by " + p.uploaded_by),
    kv("Installer", (m.installer_label || "not recognised") + (m.silent_args ? " \u00b7 silent options " + m.silent_args : "")),
    kv("File check", m.app_type ? (m.app_type === "portable" ? "looks like a portable program: " : "looks like an installer: ") + (m.app_type_reasons || []).join("; ") : null),
    p.kind === "exe" ? kv("Signature", m.signed ? "present (each server checks it is valid before running)" : "none") : null,
    kv("Product (from the file)", vi.ProductName || pr.ProductName || (m.summary || {}).subject),
    kv("Version (from the file)", vi.ProductVersion || pr.ProductVersion),
    kv("Vendor (from the file)", vi.CompanyName || pr.Manufacturer || (m.summary || {}).author),
    kv("MSI product code", pr.ProductCode),
    kv("Antivirus", (DEP_SCAN[p.scan_state] || [p.scan_state])[0] + (p.scan_result ? ": " + p.scan_result : "") + (p.scanned_at ? " (" + fmtDateTime(p.scanned_at) + ")" : "")),
    m.error ? kv("Could not read", m.error) : null);
  const ai = p.ai || {};
  const aiEl = h("div", { class: "ai-card dep-ai" },
    h("div", { class: "ai-card-head" }, h("span", { class: "ai-badge ai-small" }, h("span", { class: "ai-dot", "aria-hidden": "true" }), "AI-01"),
      h("span", { class: "muted small" }, DEP_AI[p.ai_state] || p.ai_state)),
    p.ai_state === "done" ? [
      ai.description ? h("p", null, ai.description) : null,
      h("p", { class: "small" }, [ai.product ? "Product: " + ai.product : null, ai.vendor ? "vendor: " + ai.vendor : null,
        ai.version ? "version: " + ai.version : null, ai.detect_name ? "listed as: " + ai.detect_name : null,
        ai.silent_install ? "silent options: " + ai.silent_install : null,
        ai.reboot_likely === true ? "may need a restart" : null].filter(Boolean).join(" \u00b7 ")),
      ai.notes ? h("p", { class: "small" }, h("strong", null, "Note: "), ai.notes) : null,
      h("p", { class: "muted small" }, "Suggestions only: check them against the vendor's documentation before saving.")]
    : p.ai_state === "failed" ? h("p", { class: "small" }, p.ai_error || "No answer.") : null);
  const msg = h("div", { role: "status" });
  const act = async (fn, ok) => { try { await fn(); msg.replaceChildren(h("p", { class: "small" }, ok)); reload(); } catch (e) { msg.replaceChildren(h("div", { class: "form-warn" }, e.message)); } };
  const again = h("span", { class: "dep-acts" },
    can("operator") && (p.scan_state === "failed" || p.scan_state === "clean") ? h("button", { type: "button", class: "btn-link", on: { click: () => act(() => apiPost("/deploy/packages/" + p.id + "/scan", {}), "Scan requested.") } }, "Scan again") : null,
    can("operator") && (p.ai_state === "failed" || p.ai_state === "done") ? h("button", { type: "button", class: "btn-link", on: { click: () => act(() => apiPost("/deploy/packages/" + p.id + "/ai", {}), "Asked AI-01 again.") } }, "Ask AI-01 again") : null,
    can("operator") ? h("button", { type: "button", class: "btn-link dep-danger", on: { click: () => {
      if (confirm("Remove " + p.file_name + " from PATCH-01? Deployments already done are not affected.")) act(() => apiSend("DELETE", "/deploy/packages/" + p.id), "Removed.");
    } } }, "Remove package") : null);
  return [h("div", { class: "dep-cols" }, factsEl, aiEl), can("operator") && p.scan_state !== "infected" ? depReview(p, reload) : null, again, msg];
}

function depReview(p, reload) {
  const f = {};
  const field = (k, label, ph, max) => h("label", null, h("span", null, label),
    (f[k] = h("input", { type: "text", value: p[k] || "", placeholder: ph || "", maxlength: String(max || 120) })));
  const isExe = p.kind === "exe";
  const modeSel = h("select", { "aria-label": "What the file is", disabled: !isExe },
    h("option", { value: "installer", selected: (p.install_mode || "installer") === "installer" }, "An installer: run it silently"),
    isExe ? h("option", { value: "portable", selected: p.install_mode === "portable" }, "A portable program: copy it, never run it") : null);
  const sig = h("input", { type: "checkbox", checked: !!p.require_signature, disabled: isExe && !(p.meta || {}).signed });
  const pub = h("input", { type: "text", value: p.publisher || "", placeholder: "optional: CN=Vendor Ltd, O=Vendor Ltd, C=GB", maxlength: "200" });
  const notes = h("textarea", { rows: "2", maxlength: "500" }, p.notes || "");
  const timeout = h("input", { type: "number", min: "5", max: "160", value: String(p.timeout_min || 30) });
  const msg = h("div", { role: "status" });
  const installerOnly = h("div", null,
    isExe ? field("install_args", "Silent install options", "/S   or   /VERYSILENT /NORESTART", 300)
          : h("p", { class: "muted small" }, "MSI: installed with msiexec /i <file> /qn /norestart and a full log, found afterwards by its product code; removed with msiexec /x."),
    isExe ? field("uninstall_args", "Silent uninstall options (optional: else the program's own quiet uninstall command, or its installer type's)", "/S   or   /VERYSILENT", 300) : null,
    field("detect_name", "Name in Programs and Features (or its start)" + (p.kind === "msi" ? "; empty: the MSI's own name" : ""), "Contoso Agent", 120),
    h("label", null, h("span", null, "Time limit for the installer (minutes): a hung one is stopped and reported"), timeout));
  const portableOnly = h("div", null,
    field("app_folder", "Folder under C:\\Program Files\\PATCH01-Apps", "Contoso Tool", 60),
    h("p", { class: "muted small" }, "The file is copied there (only administrators can change it) and never run by the agent. "
      + "Upgrade replaces it when the copy there is older; Remove deletes the folder."));
  const syncMode = () => { const port = modeSel.value === "portable"; installerOnly.hidden = port; portableOnly.hidden = !port; };
  modeSel.addEventListener("change", () => { syncMode(); depDirty.add(p.id); });
  if (!p.app_folder && f.app_folder) f.app_folder.value = ((p.meta || {}).suggested || {}).app_folder || p.name || "";
  syncMode();
  const looks = p.app_type ? h("p", { class: "small dep-looks" }, h("strong", null, "The file looks like " + (p.app_type === "portable" ? "a portable program" : "an installer") + ": "),
    (p.app_type_reasons || []).join("; ") + "." + (p.ai && p.ai.app_type ? " AI-01: " + (p.ai.app_type === "portable" ? "portable program" : "installer")
      + (p.ai.app_type_reason ? " (" + p.ai.app_type_reason + ")" : "") + "." : "")) : null;
  const form = h("div", { class: "form-sec dep-review" },
    h("h3", null, p.ready ? "Details (saved by " + p.reviewed_by + ")" : "Check and save before deploying"),
    looks,
    h("label", null, h("span", null, "What the file is"), modeSel),
    h("div", { class: "af-row" }, field("name", "Name", "Contoso Agent", 80), field("version", "Version", "4.2.17", 40), field("vendor", "Vendor", "Contoso Ltd", 120)),
    installerOnly, portableOnly,
    h("label", { class: "check" }, sig, h("span", null, "Each server must find a valid signature before using it")),
    h("label", null, h("span", null, "Publisher it must be signed by (certificate subject, optional)"), pub),
    h("label", null, h("span", null, "Notes"), notes),
    h("div", { class: "form-actions" },
      p.ai && p.ai_state === "done" ? h("button", { type: "button", class: "btn btn-quiet", on: { click: () => {
        const a = p.ai;
        if (a.product) f.name.value = a.product.slice(0, 80);
        if (a.version) f.version.value = a.version;
        if (a.vendor) f.vendor.value = a.vendor;
        if (a.detect_name) f.detect_name.value = a.detect_name;
        if (a.app_type && isExe) { modeSel.value = a.app_type; syncMode(); }
        if (a.silent_install && f.install_args) f.install_args.value = a.silent_install;
        if (a.silent_uninstall && f.uninstall_args) f.uninstall_args.value = a.silent_uninstall;
        if (a.notes && !notes.value) notes.value = a.notes.slice(0, 500);
        depDirty.add(p.id);
      } } }, "Use AI-01's suggestions") : null,
      h("button", { type: "button", class: "btn", on: { click: async () => {
        const body = { install_mode: modeSel.value, require_signature: sig.checked, publisher: pub.value.trim() || null,
                       notes: notes.value.trim() || null, timeout_min: Number(timeout.value) || 30 };
        Object.keys(f).forEach(k => { body[k] = f[k].value.trim() || null; });
        if (body.install_mode === "portable") { body.install_args = null; body.uninstall_args = null; }
        else body.app_folder = null;
        try { await apiSend("PUT", "/deploy/packages/" + p.id, body); depDirty.delete(p.id); msg.replaceChildren(h("p", { class: "small" }, "Saved: ready to deploy.")); reload(); }
        catch (e) { msg.replaceChildren(h("div", { class: "form-warn" }, e.message)); }
      } } }, p.ready ? "Save changes" : "Save")), msg);
  form.addEventListener("input", () => depDirty.add(p.id));
  return form;
}

/* -- New deployment --------------------------------------------------------------------- */

const DEP_HAVE = { absent: ["not installed", "st-unknown"], older: ["older", "st-warn"], same: ["this version", "st-fixed_active"],
                   newer: ["newer", "st-plain"], unknown: ["not known", "st-unknown"],
                   possible: ["maybe: decide under Matching", "st-warn"],
                   other_arch: ["other 32/64-bit build", "st-warn"],
                   ambiguous: ["several programs match: decide under Matching", "st-affected"] };
const DEP_LEVEL = { exact: "certain (MSI product code)", confirmed: "confirmed by a person", high: "sure",
                    ai: "AI-01 judged it", possible: "not sure" };

// What PATCH-01 recognises as this package's product, and the programs it is not sure about (r105)
function depMatchPanel(d, reload) {
  const P = d.package, box = h("details", { class: "dep-match", open: (d.unsure || []).length ? "" : null });
  const ask = async (name, publisher, verdict, family) => {
    try { await apiPost("/deploy/packages/" + encodeURIComponent(P.id) + "/match", { name, publisher, verdict, family: !!family }); reload(); }
    catch (e) { alert(e.message); }
  };
  const btn = (label, fn, cls) => can("operator") ? h("button", { type: "button", class: "btn " + (cls || "btn-quiet"), on: { click: fn } }, label) : null;
  const aiState = P.match_ai_state === "pending" ? "AI-01 is checking them\u2026"
    : P.match_ai_state === "failed" ? "AI-01 could not check them: " + (P.match_ai_error || "") : "";
  // Rows that wrap (a phone gets them stacked), not a wide table
  const ROW = { display: "flex", "flex-wrap": "wrap", gap: "6px 14px", "align-items": "center", padding: "8px 0",
                "border-top": "1px solid rgba(127,127,127,.25)", "overflow-wrap": "anywhere" };
  const cell = (grow, ...kids) => h("div", { style: { flex: grow + " 1 12em", "min-width": "0" } }, ...kids);
  const unsure = (d.unsure || []).map(u => h("div", { class: "dep-mrow", style: ROW },
    cell(1, h("strong", null, u.family ? (u.names || [u.name]).join(", ") : u.name), h("div", { class: "muted small" }, u.publisher || "publisher not stated")),
    cell(1, h("span", { class: "small" }, u.servers + " server(s)" + (u.versions.filter(Boolean).length ? " \u00b7 " + u.versions.filter(Boolean).join(", ") : ""))),
    cell(2, h("span", { class: "small" }, (u.reasons || []).join("; "))),
    u.family
      ? h("div", null, btn("Same product, upgraded in place", () => ask(u.name, u.publisher, "same", true), "btn"), " ",
          btn("Separate product", () => ask(u.name, u.publisher, "different", true)))
      : h("div", null, btn("Same product", () => ask(u.name, u.publisher, "same"), "btn"), " ",
          btn("Different", () => ask(u.name, u.publisher, "different")))));
  const decided = (d.decided || []).map(x => h("div", { class: "dep-mrow", style: ROW },
    cell(1, x.label || x.name, h("div", { class: "muted small" }, x.publisher || "")),
    cell(2, h("span", { class: "small" }, x.operator ? (x.operator === "same" ? "the same product" : "a different product") + " (" + (x.by || "operator") + ")"
      : x.ai ? "AI-01: " + (x.ai === "same" ? "the same product" : "a different product") + (x.ai_reason ? " \u2013 " + x.ai_reason : "") : "")),
    h("div", null, x.operator ? btn("Undo", () => ask(x.name, x.publisher, "clear", x.family))
      : [btn("Same product", () => ask(x.name, x.publisher, "same", x.family)), " ",
         btn(x.family ? "Separate product" : "Different", () => ask(x.name, x.publisher, "different", x.family))])));
  box.append(...[      // (append() would print a null as the word "null")
    h("summary", null, "Matching: how PATCH-01 recognises " + P.name + ((d.unsure || []).length ? " \u2013 " + d.unsure.length + " program(s) to decide" : "")),
    h("p", { class: "small" }, "Recognised by: ",
      h("strong", null, (P.names || []).join(" / ") || P.name),
      (P.vendors || []).length ? " from " + P.vendors.join(" / ") : " (publisher not stated: add the vendor on the package for surer matches)",
      P.product_code ? ", MSI product code " + P.product_code : "", P.arch ? ", " + P.arch : "",
      ". Versions, 32/64-bit words, languages and the maker's own name are ignored when names are compared."),
    unsure.length ? h("div", null,
      h("h3", null, "Not sure about"),
      h("p", { class: "muted small" }, "Programs that look like this product, but the evidence is not enough to act on. Until you decide, they are not ticked and not upgraded."),
      h("div", null, unsure),
      h("div", { class: "form-actions" },
        P.match_ai_state === "pending" ? null : btn("Ask AI-01 about these", async () => {
          try { await apiPost("/deploy/packages/" + encodeURIComponent(P.id) + "/match-ai", {}); reload(); } catch (e) { alert(e.message); } }),
        aiState ? h("span", { class: "muted small" }, " " + aiState) : null))
      : h("p", { class: "muted small" }, "Nothing to decide: every program found is clearly this product or clearly not."),
    decided.length ? h("div", null, h("h3", null, "Decided"), decided) : null].filter(Boolean));
  return box;
}

async function depNew(page, items, params) {
  if (!can("operator")) { page.append(h("div", { class: "empty" }, h("p", null, "Deploying needs the operator role."))); return; }
  const usable = items.filter(p => !p.deleted_at && p.ready);
  if (!usable.length) { page.append(h("div", { class: "empty" }, h("p", null, "No package is ready to deploy."), h("p", { class: "muted small" }, "Upload one and save its details on the Packages tab."))); return; }
  const pkg = h("select", { "aria-label": "Package" }, usable.map(p => h("option", { value: p.id },
    p.name + " " + p.version + " (" + p.file_name + (p.install_mode === "portable" ? ", portable" : "") + ")" + (p.blocker ? " \u2013 remove only: " + p.blocker : ""))));
  const askedPkg = params.get("package");
  const pkgGone = !!askedPkg && !usable.some(p => p.id === askedPkg);
  if (askedPkg && !pkgGone) pkg.value = askedPkg;
  if (pkgGone) page.append(h("div", { class: "form-warn" }, "The package chosen is no longer ready to deploy: choose one below (no server was ticked for you)."));
  const action = h("select", { "aria-label": "Action" },
    h("option", { value: "install" }, "Install: where it is missing or older (never downgrades)"),
    h("option", { value: "upgrade" }, "Upgrade: only where an older version is installed"),
    can("admin") ? h("option", { value: "replace" }, "Remove and install: remove the installed one with its own uninstaller, then install this") : null,
    can("admin") ? h("option", { value: "uninstall" }, "Remove: where it is installed") : null);
  if (["install", "upgrade", "uninstall", "replace"].includes(params.get("action"))) action.value = params.get("action");
  const p0 = () => usable.find(p => p.id === pkg.value) || usable[0];
  // Servers chosen in Windows software (only on the first load: changing the package picks again)
  const wantHosts = new Set(pkgGone ? [] : (params.get("hosts") || "").split(",").filter(x => /^[0-9a-f-]{36}$/.test(x)).slice(0, 500));
  const listBox = h("div", { class: "pick-list" });
  const counter = h("span", { class: "muted small" });
  const search = h("input", { type: "search", placeholder: "Filter servers by name or group", "aria-label": "Filter servers" });
  const note = h("p", { class: "muted small" });
  const matchBox = h("div");
  let rows = [], boxes = new Map(), aiPoll = null;
  const recount = () => { counter.textContent = [...boxes.values()].filter(b => b.checked).length + " of " + rows.length + " Windows servers chosen"; };
  const pick = test => { rows.forEach(r => { const b = r.querySelector("input"); b.checked = !r.hidden && test(r.dataset.status); }); recount(); };
  const pickDefault = () => pick(s => action.value === "install" ? (s === "absent" || s === "older")
                                    : action.value === "upgrade" || action.value === "replace" ? s === "older"
                                    : (s === "older" || s === "same" || s === "newer"));
  // A fresh list of installed programs from the chosen servers (else sent every 4 hours) (r109)
  const refreshNote = h("span", { class: "muted small", role: "status" });
  const refresh = h("button", { type: "button", class: "btn btn-quiet", title: "The agents send their installed programs every 4 hours. "
      + "This asks the chosen servers (or every server listed, if none is chosen) to send them at their next check-in, within about 5 minutes.",
    on: { click: async () => {
      const chosen = [...boxes.entries()].filter(([, cb]) => cb.checked).map(([id]) => id);
      const ids = chosen.length ? chosen : [...boxes.keys()];
      if (!ids.length) return;
      refresh.disabled = true;
      try {
        const r = await apiPost("/deploy/inventory-refresh", { host_ids: ids });
        refreshNote.textContent = "Asked " + r.servers + " server(s) for a fresh list: they send it within about 5 minutes. This page checks again in 6 minutes, or reload it.";
        clearTimeout(refreshTimer);
        refreshTimer = setTimeout(() => { if (listBox.isConnected) loadServers(); }, 360000);
      } catch (e) { refreshNote.textContent = e.message; }
      refresh.disabled = false;
    } } }, "Refresh installed programs");
  let refreshTimer = null;
  async function loadServers() {
    listBox.replaceChildren(h("p", { class: "muted small" }, "Checking what each server has installed\u2026"));
    let d;
    try { d = await api("/deploy/packages/" + encodeURIComponent(pkg.value) + "/servers"); }
    catch (e) { listBox.replaceChildren(h("div", { class: "form-warn" }, e.message)); return; }
    boxes = new Map();
    matchBox.replaceChildren(d.package.install_mode === "portable" ? "" : depMatchPanel(d, loadServers));
    clearTimeout(aiPoll);
    if (d.package.match_ai_state === "pending") aiPoll = setTimeout(() => { if (listBox.isConnected) loadServers(); }, 10000);
    rows = (d.servers || []).map(x => {
      const cb = h("input", { type: "checkbox", value: x.host_id, on: { change: recount } }); boxes.set(x.host_id, cb);
      const [txt, cls] = DEP_HAVE[x.status] || [x.status, "st-plain"];
      const m = x.match;
      const asked = x.inventory_wanted_at && (!x.last_inventory || x.inventory_wanted_at > x.last_inventory);
      const why = [x.inventory_at ? "From its software inventory of " + fmtDateTime(x.inventory_at) + "." : "No software inventory yet."];
      if (asked) why.push("A fresh list was asked for at " + fmtDateTime(x.inventory_wanted_at) + ": not received yet.");
      if (x.installed && m) why.push("Matched '" + x.installed.name + "' (" + (x.installed.publisher || "publisher not stated") + "), "
                                     + (DEP_LEVEL[m.level] || m.level) + ": " + m.reasons.join("; ") + ".");
      (x.possible || []).forEach(c => why.push("Maybe '" + c.name + "' (" + (c.publisher || "?") + "): " + c.match.reasons.join("; ") + "."));
      return h("label", { class: "pick", "data-name": (x.hostname + " " + (x.host_group || "")).toLowerCase(), "data-status": x.status }, cb,
        h("span", { class: "pick-name" }, x.hostname), h("span", { class: "muted small" }, x.host_group || ""),
        h("span", { class: "state " + cls, title: why.join("\n") },
          txt + (x.installed ? " (" + x.installed.version + ")" : "")),
        x.installed ? h("span", { class: "muted small", title: why.join("\n") }, x.installed.name + (m && m.level !== "high" ? " \u00b7 " + (DEP_LEVEL[m.level] || m.level) : "")) : null,
        h("span", { class: "muted small", title: why.join("\n") }, asked ? "fresh list asked for" : x.inventory_at ? "listed " + fmtAge(x.inventory_at) : "not listed yet"),
        agentMark(x.agent));
    });
    listBox.replaceChildren(...(rows.length ? rows : [h("p", { class: "muted" }, "No Windows servers enrolled.")]));
    note.textContent = d.package.install_mode === "portable"
      ? "Portable programs are not listed in Programs and Features, so what each server has is checked by the agent itself when the job runs."
      : "From each server's software inventory, matched by product code, name and publisher (hover a server for why). "
        + "The agent checks again on the server, by the program matched there, before doing anything: "
        + "it never downgrades, skips servers already on this version, and an upgrade skips servers without it.";
    search.dispatchEvent(new Event("input"));
    pickDefault();
    if (wantHosts.size) { boxes.forEach((cb, id) => { cb.checked = wantHosts.has(id); }); wantHosts.clear(); recount(); }
  }
  search.addEventListener("input", () => { const q = search.value.trim().toLowerCase(); rows.forEach(r => { r.hidden = !!q && !r.dataset.name.includes(q); }); });
  const quick = (label, test) => h("button", { type: "button", class: "btn btn-quiet", on: { click: () => pick(test) } }, label);
  const reboot = h("select", { "aria-label": "Restart" }, h("option", { value: "never" }, "Never: report that a restart is needed"),
    h("option", { value: "if_required" }, "Only if the installer asks for one"), h("option", { value: "always" }, "Always"));
  const snap = h("select", { "aria-label": "Snapshot" }, h("option", { value: "none" }, "No snapshot"),
    h("option", { value: "remove_on_success" }, "Snapshot first, remove it if it succeeds"), h("option", { value: "keep" }, "Snapshot first, keep it"));
  const win = windowFields();
  const title = h("input", { type: "text", maxlength: "200" });
  const VERB = { install: "Install ", upgrade: "Upgrade to ", replace: "Remove and install ", uninstall: "Remove " };
  const replaceNote = h("p", { class: "form-warn", hidden: true },
    "Remove and install: on each server, the program PATCH-01 matched there (shown below) is first removed with its own silent uninstaller, "
    + "whatever installed it, then this package is installed. For a program this package cannot upgrade, e.g. Chrome installed from google.com "
    + "and an MSI from Google. Only where the match is certain, sure or confirmed by a person (not AI-01 alone), never critical software. "
    + "If the removal fails, nothing is installed. The program is missing for a few minutes in between.");
  const setTitle = () => { title.placeholder = VERB[action.value] + p0().name + (action.value === "uninstall" ? "" : " " + p0().version);
                           replaceNote.hidden = action.value !== "replace"; };
  pkg.addEventListener("change", () => { setTitle(); loadServers(); });
  action.addEventListener("change", () => { setTitle(); pickDefault(); });
  setTitle();
  const reason = h("textarea", { rows: "2", placeholder: "Why (kept in the record), e.g. a ticket number", maxlength: "2000" });
  const err = h("div", { role: "alert" });
  const go = h("button", { type: "button", class: "btn", on: { click: async () => {
    err.replaceChildren();
    const targets = [...boxes.entries()].filter(([, cb]) => cb.checked).map(([id]) => ({ host_id: id }));
    if (!targets.length) { err.replaceChildren(h("div", { class: "form-warn" }, "Choose at least one server.")); return; }
    if (reason.value.trim().length < 3) { err.replaceChildren(h("div", { class: "form-warn" }, "Say why (at least 3 characters): it is kept in the record.")); return; }
    const verb = ({ install: "Install ", upgrade: "Upgrade to ", replace: "REMOVE the installed one, then install ", uninstall: "REMOVE " })[action.value];
    if (!confirm(verb + p0().name + (action.value === "uninstall" ? "" : " " + p0().version) + " on " + targets.length + " server(s)?")) return;
    go.disabled = true;
    try {
      const r = await apiPost("/changes", { kind: "software", title: title.value.trim() || title.placeholder, reason: reason.value.trim(), targets,
        params: { source: "package", package_id: pkg.value, action: action.value, reboot: reboot.value, snapshot: snap.value, check_services: true },
        ...win.get() });
      depOpen.add(r.id);
      location.hash = "#/deployment?tab=jobs&job=" + encodeURIComponent(r.id);
    } catch (e) { err.replaceChildren(h("div", { class: "form-warn" }, e.message)); go.disabled = false; }
  } } }, "Deploy");
  page.append(
    h("div", { class: "form-sec" }, h("label", null, h("span", null, "Package"), pkg), h("label", null, h("span", null, "Action"), action)),
    replaceNote,
    h("h2", null, "Servers"),
    h("div", { class: "dep-up-row" }, refresh, refreshNote),
    h("div", { class: "dep-up-row" }, search,
      quick("Without it", s => s === "absent"), quick("Older version", s => s === "older"),
      quick("Have it", s => s === "older" || s === "same" || s === "newer"), quick("All shown", () => true),
      h("button", { type: "button", class: "btn-link", on: { click: () => pick(() => false) } }, "Clear"), counter),
    note, matchBox, listBox,
    h("div", { class: "form-sec" }, h("label", null, h("span", null, "Restart"), reboot), h("label", null, h("span", null, "Snapshot (VMs linked in vCenter)"), snap)),
    win.el,
    h("div", { class: "form-sec" }, h("label", null, h("span", null, "Title"), title), h("label", null, h("span", null, "Reason"), reason)),
    h("p", { class: "muted small" }, "Each server: precheck (disk, services), then the agent checks what is installed and only then downloads (SHA-256 checked) "
      + "and installs, copies (portable) or removes. One server failing never stops the others; each one's result, the reason for a failure "
      + "(error codes and AI-01's reading) and its agent log are on the Deployments tab."),
    h("div", { class: "form-actions" }, go), err);
  await loadServers();
}

/* -- Deployments: each server's result and agent log ----------------------------------- */

async function depJobs(page, params) {
  const body = h("div");
  page.append(body);
  if (params.get("job")) depOpen.add(params.get("job"));
  const draw = items => {
    const cols = [
      { label: "Requested", cell: j => h("span", { title: fmtDateTime(j.requested_at) }, fmtDateTime(j.requested_at)) },
      { label: "Change", cell: j => h("a", { href: "#/change/" + encodeURIComponent(j.change_id), class: "mono" }, j.ref) },
      { label: "Package", cell: j => h("span", null, (j.params || {}).software || "", h("div", { class: "muted small" }, (({ install: "install", upgrade: "upgrade", uninstall: "remove", replace: "remove and install" })[(j.params || {}).action] || "") + " \u00b7 " + ((j.params || {}).file_name || ""))) },
      { label: "State", cell: j => changeMark(j.state, depSummary(j)) },
      { label: "Servers", cell: j => {
          const t = j.targets || [], fin = t.filter(x => x.state === "done" || x.state === "done_with_warnings");
          const same = fin.filter(x => (x.result || {}).nothing_to_do).length, ok = fin.length - same;
          const bad = t.filter(x => x.state === "failed").length;
          return h("span", null, ok + " changed", same ? h("span", { class: "dep-warn" }, ", " + same + " unchanged") : null,
            bad ? h("span", { class: "dep-bad" }, ", " + bad + " failed") : null, h("span", { class: "muted small" }, " of " + t.length));
        } },
      { label: "By", cell: j => j.requested_by },
    ];
    body.replaceChildren(items.length ? plusTable(cols, items, j => depJobDetail(j), { open: depOpen, key: j => j.change_id })
      : h("div", { class: "empty" }, h("p", null, "No deployments in the last 30 days.")));
  };
  let items = (await api("/deploy/jobs?days=30")).items || [];
  draw(items);
  setPageTimer(async () => {
    if (document.hidden || !items.some(j => DEP_RUNNING.has(j.state))) return;
    if (document.activeElement && page.contains(document.activeElement) && document.activeElement.tagName !== "BODY") return;
    const d = await api("/deploy/jobs?days=30").catch(() => null);
    if (d && page.isConnected) { items = d.items || []; draw(items); }
  }, 15000);
}

function depSummary(j) {
  // As finish_if_done counts it, from each server's own result (also for jobs finished before r101)
  const t = j.targets || [], s = {};
  t.forEach(x => { s[x.state] = (s[x.state] || 0) + 1; });
  s.unchanged = t.filter(x => (x.state === "done" || x.state === "done_with_warnings") && (x.result || {}).nothing_to_do).length;
  return s;
}

function depJobDetail(j) {
  const rows = (j.targets || []).map(t => {
    const r = t.result || {};
    const logBox = h("pre", { class: "dep-log", hidden: true });
    const logBtn = h("button", { type: "button", class: "btn-link", on: { click: async () => {
      if (!logBox.hidden) { logBox.hidden = true; return; }
      logBox.hidden = false; logBox.textContent = "Loading\u2026";
      try {
        const d = await api("/deploy/jobs/" + encodeURIComponent(j.change_id) + "/log?target_key=" + encodeURIComponent(t.target_key));
        logBox.textContent = (d.lines || []).length ? d.lines.map(l => new Date(l.at).toLocaleString([], { month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" }) + "  " + (l.level || "") + "  " + l.line).join("\n")
          : (d.note || "No log lines from this server for this deployment yet.");
      } catch (e) { logBox.textContent = e.message; }
    } } }, "Agent log");
    const where = r.app_path ? "program at " + r.app_path : r.target_path ? r.target_path + (r.folder_created ? " (folder created)" : "") : null;
    const dl = r.downloaded_mb ? r.downloaded_mb + " MB in " + r.download_seconds + " s" : null;
    const warns = [].concat(t.warnings || [], r.warnings || []).filter(Boolean);
    return [h("tr", null,
      h("td", null, t.host_id ? h("a", { href: "#/host/" + encodeURIComponent(t.host_id) }, t.label) : t.label),
      h("td", null, r.nothing_to_do && (t.state === "done" || t.state === "done_with_warnings")
        ? h("span", { class: "state st-warn" }, "Nothing changed") : targetMark(t.state, j.params, t.detail)),
      h("td", null, t.error ? h("span", { class: t.state === "failed" ? "dep-bad" : "dep-warn" }, t.error) : (r.message || ""),
        warns.length ? h("ul", { class: "small pr-warn" }, [...new Set(warns)].map(w => h("li", null, w))) : null,
        r.log_excerpt ? h("details", null, h("summary", { class: "small" }, "Installer log (where it failed)"), h("pre", { class: "dep-log" }, r.log_excerpt)) : null,
        explainBox({ state: t.state, warnings: warns, explain: t.explain, target_key: t.target_key }, j.change_id)),
      h("td", { class: "small" }, [where, dl, r.exit_code !== undefined && r.exit_code !== null ? "exit code " + r.exit_code : null,
        r.reboot_required ? "restart needed" : null, r.before ? "before: " + r.before : null, r.after ? "now: " + r.after : null].filter(Boolean).join(" \u00b7 ")),
      h("td", null, logBtn)), h("tr", { class: "dep-log-row" }, h("td", { colspan: "5" }, logBox))];
  });
  return [h("p", { class: "small" }, h("strong", null, j.title), " \u00b7 requested by " + j.requested_by
      + (j.started_at ? " \u00b7 started " + fmtDateTime(j.started_at) : " \u00b7 starts " + fmtDateTime(j.run_after))
      + (j.finished_at ? " \u00b7 finished " + fmtDateTime(j.finished_at) : "")),
    h("table", { class: "srv-table pr-inner no-enh" },
      h("thead", null, h("tr", null, ["Server", "Step", "Result", "Details", ""].map(x => h("th", { scope: "col" }, x)))),
      h("tbody", null, rows)),
    h("div", { class: "cm-actions" }, h("a", { class: "btn btn-quiet", href: "#/change/" + encodeURIComponent(j.change_id) }, "Open the change (live log)"))];
}

/* ---- Agent updates (Servers > Update agents) ------------------------------------------ */

const AU_STAND = {
  current: ["Up to date", "st-fixed_active"], older: ["Older", "st-warn"], manual: ["Older: install once by hand", "st-affected"],
  newer: ["Newer than published", "st-plain"], unknown: ["Version unknown", "st-unknown"], no_release: ["Nothing published", "st-unknown"],
};
function auVer(v) { const m = /^(\d+)\.(\d+)\.(\d+)/.exec(String(v || "")); return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null; }
function auCmp(a, b) { for (let i = 0; i < 3; i++) { if (a[i] !== b[i]) return a[i] < b[i] ? -1 : 1; } return 0; }

async function renderAgentUpdates(params) {
  setNav("hosts");
  const d = await api("/admin/agent-updates");
  const admin = can("admin");
  const page = h("div", { class: "dep au" });
  const plats = [["windows", "Windows"], ["linux", "Linux"]];
  const chosen = {};
  const selects = {};
  const relBox = h("div", { class: "au-rels" });
  plats.forEach(([p, label]) => {
    const list = (d.releases || {})[p] || [];
    if (!list.length) {
      relBox.append(h("div", { class: "au-rel" }, h("strong", null, label + " agent"),
        h("div", { class: "muted small" }, "Nothing published. On PATCH-01: ./scripts/phase12-agents.sh")));
      return;
    }
    chosen[p] = list[0];
    const sel = h("select", { "aria-label": label + " agent version" }, list.map((r, i) =>
      h("option", { value: r.version }, r.version + (i === 0 ? " (newest)" : ""))));
    const meta = h("div", { class: "muted small mono" });
    const showMeta = () => {
      const r = list.find(x => x.version === sel.value) || list[0];
      chosen[p] = r;
      meta.textContent = "SHA-256 " + r.sha256.slice(0, 16) + "… · " + Math.round(r.size / 1024) + " KB · "
        + (p === "windows" ? (r.signed ? "signed (the agent checks the signature)" : "not signed") + " · " : "")
        + "published " + fmtDateTime(new Date(r.published_at * 1000).toISOString());
    };
    sel.addEventListener("change", () => { showMeta(); draw(); pickDefault(); });
    selects[p] = sel;
    showMeta();
    relBox.append(h("div", { class: "au-rel" }, h("label", null, h("span", null, label + " agent"), sel), meta));
  });

  const boxes = new Map();
  const rowsBox = h("div", { class: "pick-list" });
  const counter = h("span", { class: "muted small" });
  const summary = h("p", { class: "muted small" });
  const search = h("input", { type: "search", placeholder: "Search name or group", maxlength: "80", "aria-label": "Search servers" });
  const platSel = h("select", { "aria-label": "Platform" }, h("option", { value: "" }, "Windows and Linux"),
    h("option", { value: "windows" }, "Windows only"), h("option", { value: "linux" }, "Linux only"));
  const from = d.self_update_from;
  // Where a server stands against the version chosen above (not only the newest)
  const standing = s => {
    const r = chosen[s.platform], have = auVer(s.agent_version);
    if (!r) return "no_release";
    if (!have) return "unknown";
    const c = auCmp(have, auVer(r.version));
    if (c === 0) return "current";
    if (c > 0) return "newer";
    return s.self_update ? "older" : "manual";
  };
  const eligible = s => admin && standing(s) === "older" && !s.updating;
  const update = () => {
    const n = [...boxes.values()].filter(cb => cb.checked && !cb.disabled).length;
    counter.textContent = n + (n === 1 ? " server" : " servers") + " chosen";
    go.textContent = "Update " + n + (n === 1 ? " agent" : " agents");
    go.disabled = !n || !admin;
  };
  function draw() {
    const kept = new Set([...boxes.entries()].filter(([, cb]) => cb.checked).map(([id]) => id));
    boxes.clear();
    const q = search.value.trim().toLowerCase(), pf = platSel.value;
    const tally = {};
    const rows = (d.servers || []).filter(s => (!pf || s.platform === pf)
        && (!q || (s.hostname + " " + (s.host_group || "")).toLowerCase().includes(q))).map(s => {
      const st = standing(s);
      tally[st] = (tally[st] || 0) + 1;
      const cb = h("input", { type: "checkbox", value: s.host_id, disabled: !eligible(s), "aria-label": "Update " + s.hostname });
      cb.checked = eligible(s) && kept.has(s.host_id);
      cb.addEventListener("change", update);
      boxes.set(s.host_id, cb);
      const [txt, cls] = AU_STAND[st] || [st, "st-plain"];
      return h("label", { class: "pick", "data-st": st, "data-agent": s.agent }, cb,
        h("span", { class: "pick-name" }, s.hostname), h("span", { class: "muted small" }, osLabel(s.os_id, s.os_version)),
        h("span", { class: "muted small" }, s.host_group || ""),
        h("span", { class: "mono small" }, s.agent_version || "unknown"),
        h("span", { class: "state " + cls, title: st === "manual" ? "Agents older than " + from + " cannot update themselves: run Install-PatchAgent.bat or setup-agent.sh on it once" : "" },
          s.updating ? "Update in progress" : txt),
        agentMark(s.agent));
    });
    rowsBox.replaceChildren(...(rows.length ? rows : [h("p", { class: "muted" }, "No servers match.")]));
    summary.textContent = Object.entries(tally).map(([k, n]) => n + " " + (AU_STAND[k] ? AU_STAND[k][0].toLowerCase() : k)).join(" · ");
    update();
  }
  const pick = test => { (d.servers || []).forEach(s => { const cb = boxes.get(s.host_id); if (cb && !cb.disabled) cb.checked = test(s); }); update(); };
  const pickDefault = () => pick(s => s.agent === "online");
  search.addEventListener("input", draw);
  platSel.addEventListener("change", () => { draw(); });

  const win = windowFields();
  const reason = h("textarea", { rows: "2", placeholder: "Why (kept in the record), e.g. a ticket number", maxlength: "2000" });
  const err = h("div", { role: "alert" });
  const go = h("button", { type: "button", class: "btn", on: { click: async () => {
    err.replaceChildren();
    const ids = [...boxes.entries()].filter(([, cb]) => cb.checked && !cb.disabled).map(([id]) => id);
    if (!ids.length) { err.replaceChildren(h("div", { class: "form-warn" }, "Choose at least one server.")); return; }
    if (reason.value.trim().length < 3) { err.replaceChildren(h("div", { class: "form-warn" }, "Say why (at least 3 characters): it is kept in the record.")); return; }
    const which = plats.filter(([p]) => (d.servers || []).some(s => s.platform === p && ids.includes(s.host_id))).map(([p, l]) => l + " " + chosen[p].version);
    if (!confirm("Update the agent on " + ids.length + " server(s) to " + which.join(" and ") + "?\n\nEach agent checks the file (SHA-256"
        + (which.some(w => w.startsWith("Windows")) ? ", and its signature when the agent is signed" : "") + "), tests it, swaps itself and puts its previous version back if the new one does not check in.")) return;
    go.disabled = true;
    const p = {};
    plats.forEach(([k]) => { if (chosen[k]) p[k] = chosen[k].version; });
    try {
      const r = await apiPost("/changes", { kind: "agent_update", title: "Update agents to " + which.join(", "), reason: reason.value.trim(),
        targets: ids.map(id => ({ host_id: id })), params: p, ...win.get() });
      location.hash = "#/change/" + encodeURIComponent(r.id);
    } catch (e) { err.replaceChildren(h("div", { class: "form-warn" }, e.message)); go.disabled = false; }
  } } }, "Update agents");
  const quick = (label, test) => h("button", { type: "button", class: "btn btn-quiet", on: { click: () => pick(test) } }, label);
  page.append(...[
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure agents update" }, "Agent updates"),
      h("span", { class: "head-actions" }, h("a", { href: "#/hosts", class: "small" }, "Servers"))),
    h("p", { class: "muted" }, "Move agents to a version published on PATCH-01, without visiting the servers. Each agent downloads the file over its pinned "
      + "connection, checks its SHA-256 (and, on Windows, its signature when the agent runs signed), test-runs it, swaps itself and keeps "
      + "the previous version, which puts itself back if the new one has not checked in and read its commands within 10 minutes "
      + "(Linux: the agent's interval plus 5, also after a restart). PATCH-01 then sends the new one a check job before calling it done. "
      + "Agents are never downgraded, and a Linux agent that does not verify PATCH-01's certificate is never updated. "
      + "Servers on agents older than " + from + " need the new agent installed once by hand; after that, every update is done from here."),
    d.release_dir_ok ? null : h("div", { class: "hs-alert st-unknown" }, "The agent release folder is not mounted: run phase3b-api.sh of this release."),
    relBox,
    h("h2", null, "Servers"),
    h("div", { class: "dep-up-row" }, search, platSel,
      quick("Online, older", s => s.agent === "online"), quick("All older", () => true),
      h("button", { type: "button", class: "btn-link", on: { click: () => pick(() => false) } }, "Clear"), counter),
    summary, rowsBox,
    admin ? h("div", null, win.el,
      h("div", { class: "form-sec" }, h("label", null, h("span", null, "Reason"), reason)),
      h("p", { class: "muted small" }, "A server busy with another job (a patch job between steps) is updated after it. Offline servers fail after 30 minutes "
        + "without picking up the update; run it again for them later."),
      h("div", { class: "form-actions" }, go), err)
      : h("p", { class: "muted" }, "Updating agents needs the admin role.")].filter(Boolean));
  render(page);
  draw();
  pickDefault();
}
