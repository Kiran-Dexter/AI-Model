-- ---------------------------------------------------------------------------
-- PATCH-01 : schema 055 - asking a server for its installed programs now (r109)
--
-- An agent sends its installed programs every 4 hours. When an operator asks
-- for a fresh list (Deployment > New deployment, or a server's page), or when
-- a deployment finds the list and the server disagree, the time is kept here;
-- the agent sends its list at its next check-in (within 5 minutes).
-- ---------------------------------------------------------------------------

ALTER TABLE hosts ADD COLUMN IF NOT EXISTS inventory_wanted_at TIMESTAMPTZ;

-- 'replace' (remove the installed program with its own uninstaller, then install the package)
-- is a software action: deployment params are JSON, so there is no constraint to change here.

INSERT INTO schema_version (version, description)
VALUES (55, 'Asking a server for its installed programs now (hosts.inventory_wanted_at)')
ON CONFLICT (version) DO NOTHING;
