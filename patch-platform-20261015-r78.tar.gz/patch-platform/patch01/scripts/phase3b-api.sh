#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 phase 3b : patch API
#
# Builds the API image from the local UBI Python base and deploys it behind
# the existing NGINX ingress. No host port is published: NGINX reaches it by
# container name on patchnet and routes /api/ to it.
#
# Usage:
#   ./phase3b-api.sh --dry-run     show the plan
#   ./phase3b-api.sh               build and deploy
#   ./phase3b-api.sh --build-only  build the image, do not deploy
#   ./phase3b-api.sh --check       validate a running deployment
#   ./phase3b-api.sh --down        stop the API
#   ./phase3b-api.sh --logs        tail the API log
#   ./phase3b-api.sh --token       issue an enrollment token
# ---------------------------------------------------------------------------

set -Eeuo pipefail

# grep that reads all of its input before answering. "cmd | grep -q" can stop
# reading at the first match; under pipefail the writer then fails (SIGPIPE)
# and a found match reads as "not found". Used for multi-line producers.
gq() { grep "$@" >/dev/null; }

umask 027

VERSION="1.0.0"
PATCH_BASE="/patch"
ETC_DIR="/etc/patch-platform"
LOG_DIR="/var/log/patch-platform"
IMAGES_MANIFEST="$ETC_DIR/images.env"
API_IMAGE="patch01/api:$VERSION"
CONTAINER="patch01-api"

DRY_RUN=no; CHECK_ONLY=no; DO_DOWN=no; BUILD_ONLY=no; SHOW_LOGS=no; MAKE_TOKEN=no
TOKEN_GROUP="default"; TOKEN_TTL=24

while (($#)); do
  case "$1" in
    --dry-run)    DRY_RUN=yes ;;
    --check)      CHECK_ONLY=yes ;;
    --down)       DO_DOWN=yes ;;
    --build-only) BUILD_ONLY=yes ;;
    --logs)       SHOW_LOGS=yes ;;
    --token)      MAKE_TOKEN=yes ;;
    --group)      TOKEN_GROUP="${2:-default}"; shift ;;
    --ttl)        TOKEN_TTL="${2:-24}"; shift ;;
    -h|--help)    sed -n '2,18p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/phase3b-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"

log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Run as root."

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
COMPOSE_DIR="$PATCH_BASE/compose"
SECRETS_DIR="$PATCH_BASE/secrets"
# Benchmark content and scan evidence. Written by the API (uid 1001, group 0).
HARDENING_DIR="$PATCH_BASE/data/hardening"
# Packages uploaded in the console (Deployment), kept under their SHA-256
PACKAGES_DIR="$PATCH_BASE/data/packages"
# Agent versions the agents can be updated to (owned by root, read-only in the API)
AGENT_RELEASES_DIR="$PATCH_BASE/data/agent-releases"
# Logo (logo.png, logo-white.png) and branding.conf for reports and mail
BRANDING_DIR="$PATCH_BASE/data/branding"
COMPOSE_FILE="$COMPOSE_DIR/docker-compose.api.yml"

# ---------------------------------------------------------------------------
# Simple modes
# ---------------------------------------------------------------------------
if [[ "$SHOW_LOGS" == yes ]]; then
  exec docker logs -f --tail 50 "$CONTAINER"
fi

if [[ "$DO_DOWN" == yes ]]; then
  step "Stopping the API"
  [[ -f "$COMPOSE_FILE" ]] && \
    (cd "$COMPOSE_DIR" && docker compose -f "$COMPOSE_FILE" down) || true
  docker rm -f "$CONTAINER" >/dev/null 2>&1 || true
  say "Stopped. Data is untouched."
  exit 0
fi

# ---------------------------------------------------------------------------
# Issue an enrollment token
# ---------------------------------------------------------------------------
if [[ "$MAKE_TOKEN" == yes ]]; then
  step "Issuing an enrollment token"
  docker ps --format '{{.Names}}' | gq -x "$CONTAINER" \
    || die "$CONTAINER is not running."
  [[ -f "$SECRETS_DIR/api.env" ]] || die "Missing $SECRETS_DIR/api.env"
  # shellcheck source=lib-admin.sh
  source "$SRC_DIR/scripts/lib-admin.sh"
  admin_login "$SECRETS_DIR/api.env" || die "Could not sign in as an admin."

  RESP="$(admin_curl \
    -H 'Content-Type: application/json' \
    -d "{\"host_group\":\"$TOKEN_GROUP\",\"ttl_hours\":$TOKEN_TTL}" \
    "https://127.0.0.1/api/v1/admin/enrollment-tokens" 2>>"$LOG_FILE" || true)"

  TOKEN="$(printf '%s' "$RESP" | python3 -c \
    'import json,sys
try: print(json.load(sys.stdin)["enrollment_token"])
except Exception: pass' 2>/dev/null || true)"

  if [[ -z "$TOKEN" ]]; then
    warn "Could not obtain a token. Response:"
    printf '%s\n' "$RESP" >&2
    die "Token creation failed."
  fi

  echo
  echo "================================================================"
  echo " ENROLLMENT TOKEN  (shown once)"
  echo "================================================================"
  printf ' group:   %s\n ttl:     %s hours\n\n token:   %s\n\n' \
    "$TOKEN_GROUP" "$TOKEN_TTL" "$TOKEN"
  echo " On the managed host:"
  echo "   patch-agent enroll --token $TOKEN"
  echo
  exit 0
fi

# ---------------------------------------------------------------------------
# Preconditions
# ---------------------------------------------------------------------------
step "Checking preconditions"

command -v docker >/dev/null 2>&1 || die "Docker is not installed."
docker info >/dev/null 2>&1 || die "The Docker daemon is not responding."

[[ -f "$IMAGES_MANIFEST" ]] || die "No $IMAGES_MANIFEST. Run resolve-images.sh"
# shellcheck disable=SC1090
source "$IMAGES_MANIFEST"

PY_IMAGE="${IMG_PYTHON:-}"
[[ -n "$PY_IMAGE" ]] || die "The manifest has no python image. Re-run resolve-images.sh"
docker image inspect "$PY_IMAGE" >/dev/null 2>&1 \
  || die "$PY_IMAGE is not present locally."
say "Build base: $PY_IMAGE (${VER_PYTHON:-unknown})"

docker ps --format '{{.Names}}' | gq -x patch01-postgres \
  || die "patch01-postgres is not running. Run phase1b-data.sh first."
docker network inspect patchnet >/dev/null 2>&1 \
  || die "The patchnet network is missing. Run phase1a-ingress.sh first."

# The schema must exist, or the API starts and fails on every query
PG_ENV="$SECRETS_DIR/postgres.env"
[[ -f "$PG_ENV" ]] || die "Missing $PG_ENV"
# shellcheck disable=SC1090
source "$PG_ENV"
PATCHDB_NAME="${PATCHAPI_DB_NAME:-patchdb}"
PATCHDB_USER="${PATCHAPI_DB_USER:-patchapi}"

SCHEMA_OK="$(docker exec patch01-postgres psql -U postgres -d "$PATCHDB_NAME" -qtAX \
  -c "SELECT count(*) FROM information_schema.tables
       WHERE table_schema='public' AND table_name='hosts'" 2>/dev/null || echo 0)"
[[ "$SCHEMA_OK" == "1" ]] \
  || die "The 'hosts' table is missing. Run phase3a-schema.sh first."
say "Schema present in $PATCHDB_NAME"

# ---------------------------------------------------------------------------
# Check mode
# ---------------------------------------------------------------------------
if [[ "$CHECK_ONLY" == yes ]]; then
  step "Validating the deployment"
  FAILS=0

  if docker ps --format '{{.Names}}' | gq -x "$CONTAINER"; then
    st="$(docker inspect "$CONTAINER" --format '{{.State.Health.Status}}' 2>/dev/null || echo none)"
    say "$CONTAINER: running, health=$st"
    [[ "$st" == healthy || "$st" == none ]] || FAILS=$((FAILS+1))
  else
    warn "$CONTAINER is not running"; FAILS=$((FAILS+1))
  fi

  step "API through the ingress"
  CODE="$(curl -sk -o /tmp/apihealth.$$ -w '%{http_code}' --max-time 15 \
    https://127.0.0.1/api/v1/health 2>/dev/null || echo 000)"
  if [[ "$CODE" == "200" ]]; then
    say "health: $(cat /tmp/apihealth.$$)"
  else
    warn "health returned HTTP $CODE"; FAILS=$((FAILS+1))
  fi
  rm -f /tmp/apihealth.$$

  step "Admin authentication"
  if [[ -f "$SECRETS_DIR/api.env" ]]; then
    # The first-start password stops working once an admin changes it in the
    # console, which is expected: then sign-in is checked with a wrong password
    # instead (it must be refused), and nothing counts as a failure.
    # shellcheck source=lib-admin.sh
    source "$SRC_DIR/scripts/lib-admin.sh"
    if admin_login "$SECRETS_DIR/api.env" --no-prompt 2>/dev/null; then
      CODE="$(admin_curl -o /dev/null -w '%{http_code}' --max-time 15 \
        https://127.0.0.1/api/v1/admin/fleet-summary || echo 000)"
      [[ "$CODE" == "200" ]] && say "admin auth ok" \
        || { warn "admin auth returned HTTP $CODE"; FAILS=$((FAILS+1)); }
    else
      say "the first-start admin password was changed in the console (expected): it is refused, correctly"
    fi
    admin_logout

    # An unauthenticated admin call must be refused
    CODE="$(curl -sk -o /dev/null -w '%{http_code}' --max-time 15 \
      https://127.0.0.1/api/v1/admin/hosts || echo 000)"
    [[ "$CODE" == "401" ]] && say "unauthenticated admin access correctly refused" \
      || { warn "unauthenticated admin call returned HTTP $CODE, expected 401"
           FAILS=$((FAILS+1)); }
  fi

  step "Agent endpoint authentication"
  CODE="$(curl -sk -o /dev/null -w '%{http_code}' --max-time 15 \
    -X POST https://127.0.0.1/api/v1/agent/checkin \
    -H 'Content-Type: application/json' -d '{}' || echo 000)"
  [[ "$CODE" == "401" ]] && say "unauthenticated agent call correctly refused" \
    || { warn "unauthenticated agent call returned HTTP $CODE, expected 401"
         FAILS=$((FAILS+1)); }

  step "Exposure"
  pmap="$(docker port "$CONTAINER" 2>/dev/null || true)"
  [[ -z "$pmap" ]] && say "$CONTAINER publishes no host port - correct" \
    || { warn "$CONTAINER publishes: $pmap"; FAILS=$((FAILS+1)); }

  # The worker carries out changes; if it is down they simply never start.
  # Each thread reports at its own pace, so each is judged against its own
  # interval: the hardening schedule reports hourly, the rest every minute.
  if docker ps --format '{{.Names}}' | gq -x patch01-worker; then
    BEATS="$(docker exec -i patch01-postgres psql -U postgres -d patchdb -qtAX -F '|' -c \
      "SELECT name, extract(epoch FROM now()-beat_at)::int FROM worker_heartbeat ORDER BY name" 2>/dev/null || true)"
    if [[ -z "$BEATS" ]]; then
      warn "patch01-worker is running but has never reported: docker logs patch01-worker"
      FAILS=$((FAILS+1))
    else
      while IFS='|' read -r NAME AGE; do
        [[ -n "$NAME" ]] || continue
        case "$NAME" in
          hardening) LIMIT=4000 ;;
          vmware_sync) LIMIT=1500 ;;   # a large vCenter read can take several minutes
          deploy)      LIMIT=2400 ;;   # a ClamAV scan of a large package
          *)         LIMIT=180 ;;
        esac
        if [[ "$AGE" =~ ^[0-9]+$ ]] && (( AGE < LIMIT )); then
          say "patch01-worker $NAME: reported ${AGE}s ago"
        elif [[ "$NAME" == changes ]]; then
          warn "patch01-worker changes: last report ${AGE}s ago; scheduled changes may not start: docker logs patch01-worker"
          FAILS=$((FAILS+1))
        else
          warn "patch01-worker $NAME: last report ${AGE}s ago (expected under ${LIMIT}s): docker logs patch01-worker"
        fi
      done <<<"$BEATS"
    fi
  else
    warn "patch01-worker is not running: scheduled changes will not start"
    FAILS=$((FAILS+1))
  fi

  (( FAILS == 0 )) && say "
All checks passed." || die "$FAILS check(s) failed."
  exit 0
fi

# ---------------------------------------------------------------------------
# Secrets
# ---------------------------------------------------------------------------
step "Preparing secrets"

API_ENV="$SECRETS_DIR/api.env"
if [[ -f "$API_ENV" ]]; then
  say "Existing $API_ENV found; reusing it."
else
  if [[ "$DRY_RUN" == yes ]]; then
    say "[dry-run] would generate $API_ENV"
  else
    ADMIN_PW="$(openssl rand -base64 24 | tr -d '/+=\n' | cut -c1-24)"
    cat >"$API_ENV" <<EOF
# PATCH-01 API credentials. Generated $(date -Is). Mode 0600.
ADMIN_USER=admin
ADMIN_PASSWORD=$ADMIN_PW
PATCHDB_PASSWORD=${PATCHAPI_DB_PASSWORD:-}
EOF
    chmod 0600 "$API_ENV"; chown root:root "$API_ENV"
    say "Generated $API_ENV"
  fi
fi

if [[ "$DRY_RUN" != yes ]]; then
  # The key that encrypts the relay password saved in the console. Made once
  # and kept: replacing it makes a saved password unreadable (re-enter it).
  if [[ ! -s "$SECRETS_DIR/mail.key" ]]; then
    ( umask 077; openssl rand -base64 32 | tr '+/' '-_' >"$SECRETS_DIR/mail.key" )
    say "Generated $SECRETS_DIR/mail.key (keep it with the other secrets in backups)"
  fi
  chown root:0 "$SECRETS_DIR/mail.key"; chmod 0640 "$SECRETS_DIR/mail.key"
  # The key that encrypts the antivirus consoles' API keys (Trend Micro Apex
  # Central). Made once and kept: replacing it means entering the keys again.
  if [[ ! -s "$SECRETS_DIR/av.key" ]]; then
    ( umask 077; openssl rand -base64 32 | tr '+/' '-_' >"$SECRETS_DIR/av.key" )
    say "Generated $SECRETS_DIR/av.key (keep it with the other secrets in backups)"
  fi
  chown root:0 "$SECRETS_DIR/av.key"; chmod 0640 "$SECRETS_DIR/av.key"
  # Key for run-time credentials (software jobs). Made once; mounted into the
  # API only, never the worker.
  if [[ ! -s "$SECRETS_DIR/run.key" ]]; then
    ( umask 077; openssl rand -base64 32 | tr '+/' '-_' >"$SECRETS_DIR/run.key" )
    say "Generated $SECRETS_DIR/run.key"
  fi
  chown root:0 "$SECRETS_DIR/run.key"; chmod 0640 "$SECRETS_DIR/run.key"
  # Key for the two-factor sign-in secrets. Made once and kept: replacing it means
  # every user sets up two-factor sign-in again. Mounted into the API only.
  if [[ ! -s "$SECRETS_DIR/totp.key" ]]; then
    ( umask 077; openssl rand -base64 32 | tr '+/' '-_' >"$SECRETS_DIR/totp.key" )
    say "Generated $SECRETS_DIR/totp.key (keep it with the other secrets in backups)"
  fi
  chown root:0 "$SECRETS_DIR/totp.key"; chmod 0640 "$SECRETS_DIR/totp.key"
  # The credential folder lives in /run (memory-backed, emptied at boot), so
  # systemd recreates it at every boot, before Docker starts the containers
  printf 'd /run/patch01-vault 0700 1001 0 -\n' >/etc/tmpfiles.d/patch01-vault.conf
  systemd-tmpfiles --create /etc/tmpfiles.d/patch01-vault.conf
  [[ "$(stat -c %u /run/patch01-vault)" == 1001 ]] || die "Could not prepare /run/patch01-vault."
  findmnt -no FSTYPE --target /run/patch01-vault | grep -E '^tmpfs$' >/dev/null \
    || die "/run/patch01-vault is not memory-backed: refusing to keep credentials there."
  mkdir -p "$BRANDING_DIR"
  chmod 0755 "$BRANDING_DIR"
  mkdir -p "$HARDENING_DIR/content" "$HARDENING_DIR/evidence"
  chown -R 1001:0 "$HARDENING_DIR"; chmod -R u+rwX,g+rwX,o-rwx "$HARDENING_DIR"
  command -v restorecon >/dev/null 2>&1 && restorecon -R "$HARDENING_DIR" 2>/dev/null || true
  # Deployment packages: written by the API (uid 1001). The group is left as it is
  # once made: phase11-clamav.sh gives ClamAV's group read access
  if [[ ! -d "$PACKAGES_DIR" ]]; then
    mkdir -p "$PACKAGES_DIR"; chown 1001:0 "$PACKAGES_DIR"; chmod 0750 "$PACKAGES_DIR"
  else
    chown 1001 "$PACKAGES_DIR"
  fi
  command -v restorecon >/dev/null 2>&1 && restorecon -R "$PACKAGES_DIR" 2>/dev/null || true
  # The agents of this bundle, published for "Update agents" (a version already published is kept,
  # so a signed copy published with phase12-agents.sh --windows is not replaced by the unsigned one)
  "$SRC_DIR/scripts/phase12-agents.sh" --bundle --quiet || warn "Publishing the bundle's agents failed: run ./scripts/phase12-agents.sh"
fi

# PATCH-01's certificate from the console: the API checks uploads and writes
# a request into this folder; this root helper installs, proves nginx serves
# it, and rolls back if not. The API itself never touches nginx or Docker.
if [[ "$DRY_RUN" != yes ]]; then
  STAGE="$PATCH_BASE/certs-staging"
  mkdir -p "$STAGE"; chown root:0 "$STAGE"; chmod 0770 "$STAGE"
  install -m 0750 "$SRC_DIR/scripts/patch01-cert-apply.sh" /usr/local/sbin/patch01-cert-apply
  cat >/etc/systemd/system/patch01-cert.service <<UNIT
[Unit]
Description=PATCH-01: install a certificate handed over by the console
After=docker.service

[Service]
Type=oneshot
Environment=PATCH_BASE=$PATCH_BASE
ExecStart=/usr/local/sbin/patch01-cert-apply
TimeoutStartSec=5min
UNIT
  cat >/etc/systemd/system/patch01-cert.path <<UNIT
[Unit]
Description=PATCH-01: watch for a certificate change requested in the console

[Path]
PathExists=$STAGE/request.json
Unit=patch01-cert.service

[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload
  systemctl enable --now patch01-cert.path >/dev/null 2>&1 || warn "Could not enable patch01-cert.path"
  touch "$STAGE/.helper-ready"; chmod 0640 "$STAGE/.helper-ready"
fi

# PATCH-01's own CPU, memory and network for the console's header gauges. A
# small sandboxed collector (no network, no capabilities, read-only system,
# 48 MB / 5% CPU at most) reads /proc every 5 s and writes one snapshot to a
# memory-backed folder that the API reads. The API gets no access to the host.
if [[ "$DRY_RUN" != yes ]]; then
  METRICS_PY=""
  for c in /usr/libexec/platform-python /usr/bin/python3; do [[ -x "$c" ]] && { METRICS_PY="$c"; break; }; done
  if [[ -z "$METRICS_PY" ]]; then
    warn "No Python on PATCH-01: the header gauges stay empty (install python3, then run this again)"
  else
    id patch01m >/dev/null 2>&1 || useradd -r -M -d / -s /sbin/nologin -c "PATCH-01 metrics" patch01m
    install -d -m 0755 /usr/local/libexec
    install -m 0755 "$SRC_DIR/scripts/patch01-metrics.py" /usr/local/libexec/patch01-metrics.py
    printf 'd /run/patch01-metrics 0755 patch01m patch01m -\n' >/etc/tmpfiles.d/patch01-metrics.conf
    # SELinux: the API container may read this folder (the same label as PATCH-01's other mounts)
    if command -v semanage >/dev/null 2>&1 && [[ "$(getenforce 2>/dev/null || echo Disabled)" != Disabled ]]; then
      semanage fcontext -a -t container_file_t '/run/patch01-metrics(/.*)?' 2>/dev/null \
        || semanage fcontext -m -t container_file_t '/run/patch01-metrics(/.*)?' 2>/dev/null || true
    fi
    systemd-tmpfiles --create /etc/tmpfiles.d/patch01-metrics.conf
    command -v restorecon >/dev/null 2>&1 && restorecon -R /run/patch01-metrics 2>/dev/null || true
    cat >/etc/systemd/system/patch01-metrics.service <<UNIT
[Unit]
Description=PATCH-01: CPU, memory and network for the console's gauges
After=systemd-tmpfiles-setup.service

[Service]
User=patch01m
Group=patch01m
ExecStart=$METRICS_PY -I -s /usr/local/libexec/patch01-metrics.py
Restart=always
RestartSec=5
Nice=10
MemoryMax=48M
CPUQuota=5%
TasksMax=4
UMask=0022
NoNewPrivileges=yes
CapabilityBoundingSet=
AmbientCapabilities=
ProtectSystem=strict
ReadWritePaths=/run/patch01-metrics
ProtectHome=yes
PrivateTmp=yes
PrivateDevices=yes
ProtectKernelModules=yes
ProtectKernelLogs=yes
ProtectControlGroups=yes
ProtectClock=yes
ProtectHostname=yes
RestrictAddressFamilies=AF_UNIX
IPAddressDeny=any
RestrictNamespaces=yes
RestrictRealtime=yes
RestrictSUIDSGID=yes
LockPersonality=yes
MemoryDenyWriteExecute=yes
SystemCallArchitectures=native
SystemCallFilter=@system-service
SystemCallFilter=~@privileged

[Install]
WantedBy=multi-user.target
UNIT
    systemctl daemon-reload
    systemctl enable patch01-metrics.service >/dev/null 2>&1 || warn "Could not enable patch01-metrics.service"
    systemctl restart patch01-metrics.service || warn "patch01-metrics.service did not start: journalctl -u patch01-metrics"
  fi
fi

# Worker watchdog: every 5 minutes the host asks the API container whether the
# worker is alive, and a mail goes out if not (only when mail is turned on).
if [[ "$DRY_RUN" != yes ]]; then
  cat >/etc/systemd/system/patch01-mail-watchdog.service <<'UNIT'
[Unit]
Description=PATCH-01: mail an alert if the worker stops
After=docker.service

[Service]
Type=oneshot
ExecStart=/usr/bin/docker exec patch01-api python -m app.notify watchdog
UNIT
  cat >/etc/systemd/system/patch01-mail-watchdog.timer <<'UNIT'
[Unit]
Description=PATCH-01: check the worker every 5 minutes

[Timer]
OnBootSec=5min
OnUnitActiveSec=5min

[Install]
WantedBy=timers.target
UNIT
  systemctl daemon-reload && systemctl enable --now patch01-mail-watchdog.timer >/dev/null 2>&1 || \
    warn "Could not enable patch01-mail-watchdog.timer"
fi

# AI-01 certificate directory, mounted read-only into the API container.
# Created empty if absent so the mount exists; phase6-llm.sh fills it. The
# API runs as uid 1001 in group 0, so group-root read is what it needs.
if [[ "$DRY_RUN" != yes ]]; then
  for d in ai01 vcenter; do
    mkdir -p "$SECRETS_DIR/$d"
    chown root:0 "$SECRETS_DIR/$d"
    chmod 0750 "$SECRETS_DIR/$d"
  done
fi

# Worker environment: the corporate proxy (for NVD, CISA and FIRST) and the
# NVD key. Internal names are always excluded from the proxy, whatever
# proxy.env says, so database and AI-01 traffic never leaves the host.
if [[ "$DRY_RUN" != yes ]]; then
  WENV="$SECRETS_DIR/worker.env"
  INTERNAL="localhost,127.0.0.1,postgres,redis,patch01-postgres,patch01-redis,patch01-api,pulp-api,pulp-content,patch01-pulp-api,patch01-pulp-content"
  {
    echo "# Generated by phase3b-api.sh. Do not edit; edit /etc/patch-platform/proxy.env"
    if [[ -f "$ETC_DIR/proxy.env" ]]; then
      for k in HTTP_PROXY HTTPS_PROXY; do
        v="$(grep -E "^$k=" "$ETC_DIR/proxy.env" | cut -d= -f2- | tr -d '"' || true)"
        [[ -n "$v" ]] && { echo "$k=$v"; echo "${k,,}=$v"; }
      done
      np="$(grep -E '^NO_PROXY=' "$ETC_DIR/proxy.env" | cut -d= -f2- | tr -d '"' || true)"
    else
      np=""
    fi
    echo "NO_PROXY=$INTERNAL${np:+,$np}"
    echo "no_proxy=$INTERNAL${np:+,$np}"
    for kf in "$SECRETS_DIR/nvd-api-key" "$SECRETS_DIR/intel/nvd-api-key"; do
      if [[ -s "$kf" ]]; then echo "NVD_API_KEY=$(tr -d '[:space:]' < "$kf")"; break; fi
    done
  } > "$WENV"
  chmod 0600 "$WENV"
fi

# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------
step "Building $API_IMAGE"

PROXY_ARGS=()
if [[ -f "$ETC_DIR/proxy.env" ]]; then
  P_HTTP="$(grep -E '^HTTP_PROXY=' "$ETC_DIR/proxy.env" | cut -d= -f2- || true)"
  P_HTTPS="$(grep -E '^HTTPS_PROXY=' "$ETC_DIR/proxy.env" | cut -d= -f2- || true)"
  P_NO="$(grep -E '^NO_PROXY=' "$ETC_DIR/proxy.env" | cut -d= -f2- || true)"
  [[ -n "$P_HTTP"  ]] && PROXY_ARGS+=(--build-arg "HTTP_PROXY=$P_HTTP")   || true
  [[ -n "$P_HTTPS" ]] && PROXY_ARGS+=(--build-arg "HTTPS_PROXY=$P_HTTPS") || true
  [[ -n "$P_NO"    ]] && PROXY_ARGS+=(--build-arg "NO_PROXY=$P_NO")       || true
  say "Using the corporate proxy for pip during the build."
else
  warn "No proxy configured; pip will need direct internet access."
fi

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] docker build -t $API_IMAGE --build-arg BASE_IMAGE=$PY_IMAGE $SRC_DIR/api"
else
  if docker build -t "$API_IMAGE" \
      --build-arg "BASE_IMAGE=$PY_IMAGE" \
      "${PROXY_ARGS[@]}" \
      "$SRC_DIR/api" >>"$LOG_FILE" 2>&1; then
    say "Built $API_IMAGE"
  else
    warn "Build failed. Last 40 lines:"
    tail -40 "$LOG_FILE" >&2
    die "Image build failed."
  fi
fi

[[ "$BUILD_ONLY" == yes ]] && { say "Built only, as requested."; exit 0; } || true

# ---------------------------------------------------------------------------
# Generate compose
# ---------------------------------------------------------------------------
step "Generating the compose file"

TMPL="$SRC_DIR/compose/docker-compose.api.yml.tmpl"
[[ -f "$TMPL" ]] || die "Template not found: $TMPL"

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] would generate $COMPOSE_FILE"
else
  [[ -f "$COMPOSE_FILE" ]] && \
    cp -a "$COMPOSE_FILE" "$COMPOSE_FILE.$(date +%Y%m%d-%H%M%S).bak" || true
  sed -e "s|@@API_IMAGE@@|$API_IMAGE|g" \
      -e "s|@@HARDENING_DIR@@|$HARDENING_DIR|g" \
      -e "s|@@PACKAGES_DIR@@|$PACKAGES_DIR|g" \
      -e "s|@@AGENT_RELEASES_DIR@@|$AGENT_RELEASES_DIR|g" \
      -e "s|@@PATCH_BASE@@|$PATCH_BASE|g" \
      -e "s|@@FQDN@@|$(hostname -f 2>/dev/null || hostname)|g" \
      -e "s|@@SHORT@@|$(hostname -s 2>/dev/null || hostname)|g" \
      -e "s|@@BRANDING_DIR@@|$BRANDING_DIR|g" \
      -e "s|@@SECRETS_DIR@@|$SECRETS_DIR|g" \
      -e "s|@@PG_HOST@@|postgres|g" \
      -e "s|@@PG_PORT@@|5432|g" \
      -e "s|@@PATCHDB_NAME@@|$PATCHDB_NAME|g" \
      -e "s|@@PATCHDB_USER@@|$PATCHDB_USER|g" \
      "$TMPL" >"$COMPOSE_FILE"
  chmod 0640 "$COMPOSE_FILE"

  grep -q '@@' "$COMPOSE_FILE" && {
    warn "Unfilled placeholders:"; grep -n '@@' "$COMPOSE_FILE" >&2
    die "Compose generation incomplete."
  } || true

  docker compose -f "$COMPOSE_FILE" config >/dev/null 2>>"$LOG_FILE" \
    || { tail -20 "$LOG_FILE" >&2; die "Generated compose file is invalid."; }
  say "Generated and validated $COMPOSE_FILE"
fi

# ---------------------------------------------------------------------------
# Deploy
# ---------------------------------------------------------------------------
step "Starting the API"

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] docker compose up -d"
else
  (cd "$COMPOSE_DIR" && docker compose -f "$COMPOSE_FILE" up -d) >>"$LOG_FILE" 2>&1 \
    || { tail -30 "$LOG_FILE" >&2; die "Deployment failed."; }

  say "Waiting for health..."
  for i in $(seq 1 60); do
    st="$(docker inspect "$CONTAINER" --format '{{.State.Health.Status}}' 2>/dev/null || echo starting)"
    if [[ "$st" == healthy ]]; then say "API is healthy."; break; fi
    if ! docker ps --format '{{.Names}}' | gq -x "$CONTAINER"; then
      warn "Container exited. Last 40 lines:"
      docker logs --tail 40 "$CONTAINER" 2>&1 >&2
      die "The API did not stay up."
    fi
    if (( i == 60 )); then
      warn "Not healthy after 60s. Last 40 lines:"
      docker logs --tail 40 "$CONTAINER" 2>&1 >&2
      die "Timed out."
    fi
    sleep 1
  done

  # Reach it the way an agent will, through NGINX
  CODE="$(curl -sk -o /dev/null -w '%{http_code}' --max-time 15 \
    https://127.0.0.1/api/v1/health || echo 000)"
  if [[ "$CODE" == "200" ]]; then
    say "Reachable through the ingress at /api/v1/health"
  else
    warn "Through the ingress returned HTTP $CODE."
    warn "Check that NGINX routes /api/ to patch-api:8000."
  fi
fi

# ---------------------------------------------------------------------------
# Record and summarise
# ---------------------------------------------------------------------------
if [[ "$DRY_RUN" != yes ]]; then
  cat >"$ETC_DIR/phase3b.env" <<EOF
# Generated by phase3b-api.sh v$VERSION on $(date -Is)
PP_API_IMAGE="$API_IMAGE"
PP_API_CONTAINER="$CONTAINER"
PP_API_HOST="patch-api"
PP_API_PORT="8000"
PP_API_SECRETS="$API_ENV"
PP_COMPOSE_API="$COMPOSE_FILE"
EOF
  chmod 0600 "$ETC_DIR/phase3b.env"
fi

FQDN="$(hostname -f 2>/dev/null || hostname)"

echo
echo "================================================================"
echo " PHASE 3b COMPLETE - PATCH API"
echo "================================================================"
printf ' Image:     %s\n' "$API_IMAGE"
printf ' Container: %s  (no host port)\n' "$CONTAINER"
printf ' Health:    https://%s/api/v1/health\n' "$FQDN"
printf ' Docs:      https://%s/api/v1/docs\n' "$FQDN"
printf ' Secrets:   %s\n' "$API_ENV"
printf ' Log:       %s\n' "$LOG_FILE"
echo
echo " Enrol the first host:"
echo "   1. On PATCH-01:   ./scripts/phase3b-api.sh --token"
echo "   2. Copy agent/patch-agent.py to the managed host as /usr/local/bin/patch-agent"
echo "   3. On that host:  patch-agent enroll --token <token>"
echo "                     patch-agent inventory"
echo
echo " Then:  ./scripts/phase3b-api.sh --check"
