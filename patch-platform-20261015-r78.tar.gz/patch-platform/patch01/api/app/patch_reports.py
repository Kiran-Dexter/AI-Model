"""Patch Reports: what each finished patch job did on each server.

Two views of the same jobs:
  summary  one row per server per patch job (result, counts, reboot, snapshot)
  patches  one row per Windows update (KB) or Linux package the job handled

Built from the change records (changes, change_targets, change_events), so a
report shows what the job itself recorded: the updates the Windows agent
reported installed or failed, the ones not found after the restart, and the
exact package versions installed on Linux.
"""

from datetime import datetime, timezone

from .servers import OS_LABEL

DAYS = (1, 7, 14, 30, 90, 180, 365)
RESULTS = ("ok", "warnings", "failed", "nothing")
MAX_TARGETS = 3000

RESULT_LABEL = {"ok": "Patched", "warnings": "Patched, with warnings", "failed": "Failed",
                "nothing": "Nothing to install", "skipped": "Skipped", "cancelled": "Cancelled"}

_SQL = f"""
SELECT 'CHG-' || lpad(c.number::text, 6, '0') AS ref, c.number, c.id::text AS change_id, ct.host_id::text AS host_id, ct.target_key, c.title AS change_title, c.params,
       c.started_at AS change_started, coalesce(c.finished_at, ct.updated_at) AS finished_at,
       ct.state, ct.label, ct.detail, ct.error, ct.snapshot_moref,
       h.hostname, h.os_id, h.host_group, {OS_LABEL} AS os_label,
       (SELECT min(e.at) FROM change_events e WHERE e.change_id = c.id AND e.target_key = ct.target_key) AS first_at,
       (SELECT max(e.at) FROM change_events e WHERE e.change_id = c.id AND e.target_key = ct.target_key) AS last_at,
       EXISTS (SELECT 1 FROM change_events e WHERE e.change_id = c.id AND e.target_key = ct.target_key
                  AND e.event = 'install' AND e.ok IS TRUE) AS install_ok,
       EXISTS (SELECT 1 FROM change_events e WHERE e.change_id = c.id AND e.target_key = ct.target_key
                  AND e.event = 'snapshot_removed' AND e.ok IS TRUE) AS snapshot_removed,
       EXISTS (SELECT 1 FROM change_events e WHERE e.change_id = c.id AND e.target_key = ct.target_key
                  AND e.event = 'snapshot' AND e.ok IS TRUE) AS snapshot_taken
  FROM change_targets ct
  JOIN changes c ON c.id = ct.change_id
  LEFT JOIN hosts h ON h.id = ct.host_id
 WHERE c.kind = 'patch'
   AND ct.state IN ('done', 'done_with_warnings', 'failed')
   AND coalesce(c.finished_at, ct.updated_at) > now() - make_interval(days => %(days)s)
   AND (%(change)s::bigint IS NULL OR c.number = %(change)s::bigint)
   AND (%(q)s::text IS NULL OR strpos(lower(ct.label || ' ' || coalesce(h.hostname, '') || ' ' || c.title || ' CHG-'
                                              || lpad(c.number::text, 6, '0')), lower(%(q)s::text)) > 0)
 ORDER BY coalesce(c.finished_at, ct.updated_at) DESC, ct.label
 LIMIT {MAX_TARGETS}"""


def clean_filters(days=None, os=None, result=None, q=None, change=None):
    try:
        d = int(days) if days not in (None, "") else 30
    except (TypeError, ValueError):
        d = 30
    d = d if d in DAYS else 30
    os = os if os in ("windows", "linux") else None
    result = result if result in RESULTS else None
    q = (str(q).strip()[:100] or None) if q else None
    n = None
    if change:
        digits = "".join(ch for ch in str(change) if ch.isdigit())[:12]
        n = int(digits) if digits else None
    return {"days": d, "os": os, "result": result, "q": q, "change": n}


def describe(f):
    bits = [f"last {f['days']} day" + ("s" if f["days"] != 1 else "")]
    if f.get("os"):
        bits.append("Windows" if f["os"] == "windows" else "Linux")
    if f.get("result"):
        bits.append(RESULT_LABEL[f["result"]].lower())
    if f.get("change"):
        bits.append(f"CHG-{f['change']:06d}")
    if f.get("q"):
        bits.append(f'"{f["q"]}"')
    return "; ".join(bits)


def _list(v):
    return [x for x in v if isinstance(x, dict)] if isinstance(v, list) else []


def _upper(v):
    return str(v or "").strip().upper()


def _ts(v):
    if isinstance(v, str):
        try:
            return datetime.fromisoformat(v.replace(" ", "T"))
        except ValueError:
            return None
    return v


def _minutes(a, b):
    a, b = _ts(a), _ts(b)
    if not a or not b:
        return None
    try:
        return max(0, int((b - a).total_seconds() // 60))
    except Exception:  # noqa: BLE001 - strings from a test shim
        return None


def _result_key(r, installed, nothing):
    if r["state"] == "failed":
        return "failed"
    if nothing and not installed:
        return "nothing"
    return "warnings" if r["state"] == "done_with_warnings" else "ok"


def _target(r):
    """One finished server of one job: the summary row and its patch rows."""
    d = r["detail"] or {}
    windows = (r["os_id"] or "") == "windows" or "install" in d and isinstance(d.get("install"), dict) and "installed" in d["install"]
    inst = d.get("install") if isinstance(d.get("install"), dict) else {}
    post = d.get("postcheck") if isinstance(d.get("postcheck"), dict) else {}
    nothing = bool(d.get("nothing_to_do") or inst.get("nothing_to_do"))
    patches = []
    if windows:
        missing_after = {_upper(x) for x in (post.get("updates_not_installed") or []) if x}
        for x in _list(inst.get("installed")):
            kb = _upper(x.get("kb")) or None
            gone = (kb and kb in missing_after) or _upper(x.get("title")) in missing_after
            patches.append({"patch": kb or "update", "description": str(x.get("title") or x.get("id") or ""),
                            "status": "Not found after restart" if gone else "Installed"})
        for x in _list(inst.get("failed")):
            patches.append({"patch": _upper(x.get("kb")) or "update", "description": str(x.get("title") or x.get("id") or ""),
                            "status": "Failed"})
    else:
        adv = d.get("package_advisories") if isinstance(d.get("package_advisories"), dict) else {}
        status = "Installed" if r["install_ok"] else "Not installed (the job stopped)"
        for x in _list(d.get("packages")):
            name = str(x.get("name") or "")
            patches.append({"patch": name, "description": "version " + str(x.get("version") or "?"),
                            "advisories": ", ".join(adv.get(name) or []), "status": status})
    n_ok = sum(1 for p in patches if p["status"] == "Installed")
    n_bad = sum(1 for p in patches if p["status"] != "Installed")
    key = _result_key(r, n_ok, nothing)
    warnings = [str(w) for w in (d.get("warnings") or []) if w]
    notes = r["error"] or "; ".join(warnings[:6])
    if r["snapshot_moref"]:
        snap = "Kept"
    elif r["snapshot_removed"]:
        snap = "Taken, removed"
    elif r["snapshot_taken"]:
        snap = "Taken"
    else:
        snap = "None"
    summary = {
        "finished_at": r["finished_at"], "ref": r["ref"], "change_title": r["change_title"],
        "change_id": r["change_id"], "host_id": r["host_id"], "target_key": r["target_key"],
        "server": r["hostname"] or r["label"], "os": r["os_label"] or "", "os_kind": "windows" if windows else "linux",
        "group": r["host_group"] or "", "result": key, "result_label": RESULT_LABEL[key],
        "installed": n_ok, "failed": n_bad,
        "reboot": "Restarted" if d.get("reboot_requested_at") else "No restart",
        "snapshot": snap, "minutes": _minutes(r["first_at"], r["last_at"]), "notes": notes or "",
        "warnings": warnings[:40], "error": r["error"] or "",
        "explain": d.get("explain") if isinstance(d.get("explain"), dict) else None,
    }
    rows = [dict(p, finished_at=r["finished_at"], ref=r["ref"], change_id=r["change_id"], server=summary["server"], os=summary["os"],
                 os_kind=summary["os_kind"], result=key) for p in patches]
    return summary, rows


def collect(conn, f):
    """(summary rows, patch rows, info) for the filters, newest first. info has
    the totals before the result filter (so the result tiles keep their counts)
    and whether the newest-jobs limit cut the list."""
    raw = conn.execute(_SQL, {"days": f["days"], "change": f["change"], "q": f["q"]}).fetchall()
    every_s, every_p = [], []
    for r in raw:
        s, p = _target(dict(r))
        if f["os"] and s["os_kind"] != f["os"]:
            continue
        every_s.append(s)
        every_p.extend(p)
    info = {"totals": totals(every_s, every_p), "limited": len(raw) >= MAX_TARGETS}
    if not f["result"]:
        return every_s, every_p, info
    keep = {(s["ref"], s["server"]) for s in every_s if s["result"] == f["result"]}
    return ([s for s in every_s if (s["ref"], s["server"]) in keep],
            [p for p in every_p if (p["ref"], p["server"]) in keep], info)


def totals(summary, patches):
    return {
        "servers": len({s["server"] for s in summary}),
        "jobs": len({s["ref"] for s in summary}),
        "ok": sum(1 for s in summary if s["result"] == "ok"),
        "warnings": sum(1 for s in summary if s["result"] == "warnings"),
        "failed": sum(1 for s in summary if s["result"] == "failed"),
        "nothing": sum(1 for s in summary if s["result"] == "nothing"),
        "patches_installed": sum(1 for p in patches if p["status"] == "Installed"),
        "patches_problem": sum(1 for p in patches if p["status"] != "Installed"),
        "windows": sum(1 for s in summary if s["os_kind"] == "windows"),
        "linux": sum(1 for s in summary if s["os_kind"] == "linux"),
    }


# ---------------------------------------------------------------------------
# Table form, for PDF, CSV and e-mail
# ---------------------------------------------------------------------------

SUMMARY_HEADERS = ["Finished", "Change", "Server", "Operating system", "Result", "Installed", "Not installed",
                   "Restart", "Snapshot", "Minutes", "Notes"]
PATCH_HEADERS = ["Finished", "Change", "Server", "Operating system", "Update / package", "Description",
                 "Advisories", "Status"]


def _when(v, tz):
    if v is None:
        return ""
    if isinstance(v, str):
        try:
            v = datetime.fromisoformat(v.replace(" ", "T"))
        except ValueError:
            return v[:16]
    if v.tzinfo is None:
        v = v.replace(tzinfo=timezone.utc)
    return v.astimezone(tz).strftime("%Y-%m-%d %H:%M")


def summary_table(summary, tz):
    return SUMMARY_HEADERS, [[_when(s["finished_at"], tz), s["ref"], s["server"], s["os"], s["result_label"],
                              s["installed"], s["failed"], s["reboot"], s["snapshot"],
                              "" if s["minutes"] is None else s["minutes"], s["notes"][:600]] for s in summary]


def patch_table(patches, tz):
    return PATCH_HEADERS, [[_when(p["finished_at"], tz), p["ref"], p["server"], p["os"], p["patch"],
                            p["description"][:300], p.get("advisories") or "", p["status"]] for p in patches]


def build_report(conn, params, tz, view):
    """For report_jobs: the server-built Patch report (e-mail now or on a schedule)."""
    f = clean_filters(params.get("days", 7), params.get("os"), params.get("result"), params.get("q"), params.get("change"))
    summary, patches, _ = collect(conn, f)
    t = totals(summary, patches)
    if view == "patches":
        headers, rows = patch_table(patches, tz)
        title = "Patch report, installed updates and packages"
        preview = ([headers[2], headers[4], headers[5], headers[7]], [[r[2], r[4], r[5], r[7]] for r in rows])
    else:
        headers, rows = summary_table(summary, tz)
        title = "Patch report, servers"
        rank = {"Failed": 0, "Patched, with warnings": 1}
        rows = sorted(rows, key=lambda x: rank.get(x[4], 2))       # problems first (stable: newest first within)
        preview = ([headers[1], headers[2], headers[4], headers[5], headers[6]], [[r[1], r[2], r[4], r[5], r[6]] for r in rows])
    sev = "critical" if t["failed"] else "warning" if t["warnings"] else "ok" if summary else "info"
    intro = (f"Patching results for the {describe(f)}: {t['servers']} servers in {t['jobs']} patch jobs; "
             f"{t['ok']} patched, {t['warnings']} patched with warnings, {t['failed']} failed, "
             f"{t['nothing']} had nothing to install. {t['patches_installed']} updates or packages installed"
             + (f", {t['patches_problem']} not installed." if t["patches_problem"] else "."))
    return {"title": title, "headers": headers, "rows": rows, "filter": describe(f), "intro": intro,
            "action": "Review the failed servers and the updates not installed; each job's page has the step that stopped."
                      if t["failed"] or t["patches_problem"] else None,
            "stats": [("Patched", t["ok"], "ok"), ("With warnings", t["warnings"], "warning" if t["warnings"] else "ok"),
                      ("Failed", t["failed"], "critical" if t["failed"] else "ok"), ("Installed", t["patches_installed"], "info")],
            "severity": sev, "preview": preview}
