<#
.SYNOPSIS
  Install or upgrade the PATCH-01 agent on this server: one interactive script
  for every server (new and existing).

.DESCRIPTION
  Run on each server, in PowerShell as administrator, from the agent folder
  (copied to the server, or on a share):

      .\Deploy-Agent.ps1

  The folder holds the signed agent scripts, your CA chain (.pem) and, made
  by Sign-Agent.ps1, the publisher certificate (publisher-*.cer). Optional:
  tokens.txt with one enrolment token per line for new servers
  (phase10-windows.sh --tokens N on PATCH-01).

  It works out what this server needs and asks only for that:
    1. this server: administrator, PowerShell 5.1, no patch job running
    2. script signing: the execution policy the agent will run under, the
       signatures, and trusting your publisher for this computer (asked)
    3. the agent already here: upgrade (identity kept, no token) or new
    4. PATCH-01's address (remembered in deploy-settings.json), the CA file
    5. new servers only: an enrolment token (next one from tokens.txt, or typed)
    6. a summary to confirm, then Setup-Agent.ps1 does the work and proves
       it by running the agent's scheduled task as SYSTEM
  Each run is recorded in deploy-log.csv in this folder (when writable) and
  in a full log under C:\ProgramData\PatchAgent-Deploy.

  Nothing is changed before you confirm the summary.

  Install-PatchAgent.bat runs this for you: it unzips the agent to this
  server, unblocks the files and starts this script with -AllowUnsigned and
  -SharedFolder (the folder the .bat is in), where PATCH-01's pin and address
  are remembered for the next server and every result goes to deploy-log.csv.
#>
[CmdletBinding()]
param(
    # Unsigned scripts are expected (no code-signing certificate): warn, do not ask
    [switch]$AllowUnsigned,
    # The folder the .bat runs from: settings and the central deploy log are kept there
    [string]$SharedFolder
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDir = Join-Path $env:ProgramFiles "PatchAgent"
$DataDir = Join-Path $env:ProgramData "PatchAgent"
$LogDir = Join-Path $env:ProgramData "PatchAgent-Deploy"
$TaskName = "PATCH-01 agent"
$Shared = $Here
if ($SharedFolder -and (Test-Path -LiteralPath $SharedFolder -PathType Container)) { $Shared = (Resolve-Path -LiteralPath $SharedFolder).ProviderPath }
$SettingsFile = Join-Path $Shared "deploy-settings.json"
$TokensFile = Join-Path $Shared "tokens.txt"
$TokensUsed = Join-Path $Shared "tokens-used.csv"
$DeployLog = Join-Path $Shared "deploy-log.csv"
$Computer = $env:COMPUTERNAME

function Title([string]$T) { Write-Host ""; Write-Host $T -ForegroundColor Cyan }
function Step([string]$N, [string]$T) { Write-Host ""; Write-Host ("[" + $N + "] " + $T) -ForegroundColor White }
function Ok([string]$T) { Write-Host ("  ok    " + $T) -ForegroundColor Green }
function Info([string]$T) { Write-Host ("        " + $T) }
function Warn([string]$T) { Write-Host ("  warn  " + $T) -ForegroundColor Yellow }
function Stop-Deploy([string]$T) {
    Write-Host ""; Write-Host ("  STOP  " + $T) -ForegroundColor Red
    Write-Host "        Nothing was changed by this step." -ForegroundColor Red; Write-Host ""
    Write-DeployLog "stopped" $T
    exit 1
}
function Ask([string]$Q, [string]$Default) {
    $p = "  " + $Q
    if ($Default) { $p += " [" + $Default + "]" }
    $a = Read-Host $p
    if ([string]::IsNullOrWhiteSpace($a)) { return $Default }
    return $a.Trim()
}
function Confirm([string]$Q, [bool]$DefaultYes = $true) {
    $a = Read-Host ("  " + $Q + $(if ($DefaultYes) { " [Y/n]" } else { " [y/N]" }))
    if ([string]::IsNullOrWhiteSpace($a)) { return $DefaultYes }
    return ($a.Trim() -match '^(y|yes)$')
}
function Get-VersionIn([string]$Path) {
    if (-not (Test-Path $Path)) { return $null }
    $m = Select-String -Path $Path -Pattern '^\$AgentVersion\s*=\s*"([^"]+)"' | Select-Object -First 1
    if ($m) { return $m.Matches[0].Groups[1].Value }
    return $null
}

# A short exclusive lock on a file in this folder, so servers deploying at the
# same time from a share never take the same token or garble the log
function Invoke-Locked([string]$Name, [scriptblock]$Do) {
    $lockPath = Join-Path $Shared ($Name + ".lock")
    $fs = $null
    for ($i = 0; $i -lt 60 -and -not $fs; $i++) {
        try { $fs = [IO.File]::Open($lockPath, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None) }
        catch [UnauthorizedAccessException] { throw ("no write access to " + $Shared) }       # a read-only folder: say so at once
        catch { Start-Sleep -Milliseconds (200 + (Get-Random -Maximum 300)) }
    }
    if (-not $fs) { throw ("could not lock " + $lockPath + " (another server holds it)") }
    try { return (& $Do) } finally { $fs.Dispose() }
}

$script:Mode = "-"; $script:FromVer = "-"; $script:ToVer = "-"
function Write-DeployLog([string]$Result, [string]$Detail) {
    $line = '"{0}","{1}","{2}","{3}","{4}","{5}","{6}"' -f (Get-Date).ToString("yyyy-MM-dd HH:mm:ss"), $Computer, $script:Mode,
        $script:FromVer, $script:ToVer, $Result, (($Detail -replace '"', "'") -replace "[\r\n]+", " ")
    try {
        Invoke-Locked "deploy-log" {
            if (-not (Test-Path $DeployLog)) { Set-Content -Path $DeployLog -Value '"When","Server","Action","From","To","Result","Detail"' -Encoding UTF8 }
            Add-Content -Path $DeployLog -Value $line -Encoding UTF8
        } | Out-Null
    } catch { }      # a read-only folder: the local log below still has it
    try {
        if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }
        Add-Content -Path (Join-Path $LogDir "deploy-log.csv") -Value $line -Encoding UTF8
    } catch { }
}

Title ("PATCH-01 agent deployment on " + $Computer + "   " + (Get-Date).ToString("dd MMM yyyy HH:mm"))

# ---------------------------------------------------------------------------
Step "1/6" "This server"
$me = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { Stop-Deploy "Run PowerShell as administrator (right-click, Run as administrator)." }
Ok ("Administrator: " + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
if ($PSVersionTable.PSVersion.Major -lt 5) { Stop-Deploy ("PowerShell 5.1 is needed (found " + $PSVersionTable.PSVersion + ").") }
$os = Get-CimInstance Win32_OperatingSystem
Ok ($os.Caption + " (build " + $os.BuildNumber + ")")
foreach ($f in @("Setup-Agent.ps1", "install-agent.ps1", "patch-agent.ps1")) {
    if (-not (Test-Path (Join-Path $Here $f))) { Stop-Deploy ($f + " is missing from " + $Here + ": copy the whole agent folder.") }
}
$NewVer = Get-VersionIn (Join-Path $Here "patch-agent.ps1")
$script:ToVer = $NewVer
Ok ("Agent in this folder: " + $NewVer)
# A patch job installing right now must not be interrupted by an upgrade
# (the install writes a progress file; a long cumulative update can keep it unchanged for an hour)
$busy = @(Get-ChildItem -Path $DataDir -Filter "wu-progress-*.log" -ErrorAction SilentlyContinue |
          Where-Object { $_.LastWriteTime -gt (Get-Date).AddHours(-3) })
if ($busy.Count -gt 0) { Stop-Deploy "A patch job is installing updates on this server right now. Run this again after it finishes." }
$taskNow = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($taskNow -and [string]$taskNow.State -eq "Running") { Info "The agent is busy right now; the upgrade waits for it to finish (up to 10 minutes)" }
Ok "No patch job installing right now"

# ---------------------------------------------------------------------------
Step "2/6" "Script signing"
$list = @(Get-ExecutionPolicy -List)
function Get-PolicyAt([string]$Scope) { return [string](@($list | Where-Object { [string]$_.Scope -eq $Scope })[0].ExecutionPolicy) }
$SysPolicy = "RemoteSigned"; $SysFrom = "Windows default"
foreach ($sc in @("MachinePolicy", "LocalMachine")) {
    $v = Get-PolicyAt $sc
    if ($v -and $v -ne "Undefined") { $SysPolicy = $v; $SysFrom = $sc; break }
}
Ok ("Server policy: " + $SysPolicy + " (from " + $SysFrom + "); it is left as it is")
$Gpo = ((Get-PolicyAt "MachinePolicy") -notin @("", "Undefined"))
if (-not $Gpo) { Info "The agent's task sets its own policy for its own process only: AllSigned when signed, else RemoteSigned" }
$cu = Get-PolicyAt "CurrentUser"
$sigFiles = @("Deploy-Agent.ps1", "Setup-Agent.ps1", "install-agent.ps1", "patch-agent.ps1")
$bad = @(); $signer = $null
foreach ($f in $sigFiles) {
    $s = Get-AuthenticodeSignature -FilePath (Join-Path $Here $f)
    if ([string]$s.Status -ne "Valid") { $bad += ($f + " (" + [string]$s.Status + ")") }
    elseif (-not $signer) { $signer = $s.SignerCertificate }
    elseif ($s.SignerCertificate.Thumbprint -ne $signer.Thumbprint) { $bad += ($f + " (signed by a different certificate)") }
}
$TaskPolicy = "RemoteSigned"
if ($bad.Count -gt 0) {
    if ($SysPolicy -eq "AllSigned") {
        Stop-Deploy ("This server runs scripts under AllSigned and these are not validly signed: " + ($bad -join ", ") +
                     ". Run Sign-Agent.ps1 once on the PC that has your code-signing certificate, then copy the folder again.")
    }
    if ($Gpo -and $SysPolicy -eq "Restricted") { Stop-Deploy "Group Policy sets Restricted for the computer: no script can run as SYSTEM. Ask for the GPO to allow AllSigned (and sign) or RemoteSigned." }
    Warn ("Not signed: " + ($bad -join ", ") + ". The agent's task will run under RemoteSigned for its own process; the rest of the server stays " + $SysPolicy + ".")
    if (-not $AllowUnsigned -and -not (Confirm "Continue with unsigned scripts?" $false)) { Stop-Deploy "Stopped at your request." }
} else {
    Ok ("Scripts signed by " + $signer.Subject + " (valid until " + $signer.NotAfter.ToString("dd MMM yyyy") + ")")
    $TaskPolicy = "AllSigned"
    # The SYSTEM task cannot answer "trust this publisher?": it must be trusted for the computer
    $trusted = @(Get-ChildItem Cert:\LocalMachine\TrustedPublisher -ErrorAction SilentlyContinue | Where-Object { $_.Thumbprint -eq $signer.Thumbprint }).Count -gt 0
    if ($trusted) { Ok "Publisher trusted for this computer" }
    else {
        $cer = @(Get-ChildItem -Path $Here -Filter "publisher-*.cer" -ErrorAction SilentlyContinue | Where-Object {
            try { (New-Object Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList $_.FullName).Thumbprint -eq $signer.Thumbprint } catch { $false } })
        if ($cer.Count -eq 0) {
            if ($SysPolicy -eq "AllSigned") { Stop-Deploy "The publisher is not trusted for this computer and no matching publisher-*.cer is in the folder (Sign-Agent.ps1 makes it)." }
            Warn "Publisher not in this computer's Trusted Publishers (not needed under RemoteSigned)"
        } else {
            Info ("Publisher certificate in the folder: " + $cer[0].Name + ", thumbprint " + $signer.Thumbprint)
            if (Confirm ("Trust this publisher for this computer (Trusted Publishers, local machine)?") $true) {
                Import-Certificate -FilePath $cer[0].FullName -CertStoreLocation Cert:\LocalMachine\TrustedPublisher | Out-Null
                Ok "Publisher trusted for this computer"
            } elseif ($SysPolicy -eq "AllSigned") { Stop-Deploy "Under AllSigned the agent's task cannot run without it." }
        }
    }
    $chain = New-Object Security.Cryptography.X509Certificates.X509Chain($true)
    [void]$chain.Build($signer)
    $root = $chain.ChainElements[$chain.ChainElements.Count - 1].Certificate
    if (@(Get-ChildItem Cert:\LocalMachine\Root | Where-Object { $_.Thumbprint -eq $root.Thumbprint }).Count -gt 0) { Ok ("Root CA trusted: " + $root.Subject) }
    elseif ($SysPolicy -eq "AllSigned") { Stop-Deploy ("The signing certificate's root CA (" + $root.Subject + ") is not in this computer's Trusted Root store. Deploy it by Group Policy first.") }
    else { Warn ("The signing certificate's root CA is not trusted here (" + $root.Subject + ")") }
}

# ---------------------------------------------------------------------------
Step "3/6" "Agent already on this server"
$CfgFile = Join-Path $DataDir "agent.json"
$Enrolled = (Test-Path $CfgFile) -and (Test-Path (Join-Path $DataDir "token.bin"))
$OldVer = Get-VersionIn (Join-Path $InstallDir "patch-agent.ps1")
$OldCfg = $null
if ($Enrolled) {
    $OldCfg = Get-Content -Raw $CfgFile | ConvertFrom-Json
    $script:FromVer = $(if ($OldVer) { $OldVer } else { "unknown" })
    $script:Mode = $(if ($OldVer -eq $NewVer) { "refresh" } else { "upgrade" })
    Ok ("Installed and enrolled: version " + $script:FromVer)
    Ok $(if ($script:Mode -eq "refresh") { "Already " + $NewVer + ": its files, task and settings will be refreshed" } else { "Will upgrade " + $script:FromVer + " -> " + $NewVer + ", keeping its identity (no token)" })
} else {
    $script:Mode = "new"
    if ($OldVer) { Warn ("Agent files (" + $OldVer + ") are here but it never enrolled: it will be installed as new") } else { Ok "None: this is a new install" }
}

# ---------------------------------------------------------------------------
Step "4/6" "PATCH-01's certificate pin and address"
$saved = $null
if (Test-Path $SettingsFile) { try { $saved = Get-Content -Raw $SettingsFile | ConvertFrom-Json } catch { } }
# The pin: SHA-256 of PATCH-01's certificate (not a secret). On PATCH-01: ./scripts/phase10-windows.sh --pin
# The pin remembered in the shared folder first (after a certificate renewal it is the new one), else this agent's own
$defPin = ""
if ($saved -and $saved.PSObject.Properties["pin"] -and $saved.pin) { $defPin = [string]$saved.pin }
elseif ($OldCfg -and $OldCfg.PSObject.Properties["pin"] -and $OldCfg.pin -and [string]$OldCfg.pin -ne "system") { $defPin = [string]$OldCfg.pin }
$PinIn = $null
while ($null -eq $PinIn) {
    $a = Ask "Certificate pin (paste it; on PATCH-01: ./scripts/phase10-windows.sh --pin; Enter for none: use the CA .pem)" $defPin
    $norm = ((([string]$a).ToLowerInvariant() -replace '[:\s"]', '').Split(",") | Where-Object { $_ }) -join ","
    if (-not $norm) { $PinIn = "" }
    elseif ($norm -match '^[0-9a-f]{64}(,[0-9a-f]{64})?$') { $PinIn = $norm }
    else { Warn "A pin is 64 hexadecimal characters (0-9, a-f), as phase10-windows.sh --pin prints it. Paste it again." }
}
if ($PinIn) { Ok ("Pin: " + $PinIn.Substring(0, 16) + "..." + $(if ($PinIn.Contains(",")) { " (two pins)" } else { "" })) }
else { Info "No pin: PATCH-01's certificate is trusted through the CA .pem in this folder, or Windows' own trust" }
$def = ""
if ($OldCfg -and $OldCfg.PSObject.Properties["server"] -and $OldCfg.server) { $def = [string]$OldCfg.server }
elseif ($saved -and $saved.PSObject.Properties["server"] -and $saved.server) { $def = [string]$saved.server }
$Server = ""
while (-not $Server) {
    $a = Ask "PATCH-01 address (https://name)" $def
    if ($a -match '^https://[A-Za-z0-9.-]+(:\d{1,5})?/?$') { $Server = $a.TrimEnd("/") }
    else { Warn "Give it as https://<name> or https://<name>:<port>" }
}
Ok ("PATCH-01: " + $Server)
$savedServer = ""
if ($saved -and $saved.PSObject.Properties["server"]) { $savedServer = [string]$saved.server }
$savedPin = ""
if ($saved -and $saved.PSObject.Properties["pin"]) { $savedPin = [string]$saved.pin }
if ($savedServer -ne $Server -or ($PinIn -and $savedPin -ne $PinIn)) {
    # Only the address and the pin (neither is a secret); never a token
    $keep = @{ server = $Server }; if ($PinIn) { $keep.pin = $PinIn } elseif ($savedPin) { $keep.pin = $savedPin }
    try { Invoke-Locked "deploy-settings" { ConvertTo-Json -InputObject $keep | Set-Content -Path $SettingsFile -Encoding UTF8 } | Out-Null
          Info ("Remembered in " + $SettingsFile + " for the next servers (press Enter to reuse)") } catch { }
}
# The CA chain: .pem/.crt files in the folder (the publisher certificate is not one)
$cas = @(Get-ChildItem -Path $Here -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in @(".pem", ".crt") -or ($_.Extension -eq ".cer" -and $_.Name -notlike "publisher-*") } | Sort-Object Name)
$CaFile = $null
if ($PinIn) { $cas = @() }          # the pin decides; a .pem in the folder is not needed
if ($cas.Count -eq 1) { $CaFile = $cas[0].FullName; Ok ("CA chain: " + $cas[0].Name) }
elseif ($cas.Count -gt 1) {
    for ($i = 0; $i -lt $cas.Count; $i++) { Info ("{0}. {1}" -f ($i + 1), $cas[$i].Name) }
    $n = 0
    while ($n -lt 1 -or $n -gt $cas.Count) {
        $n = (Ask ("Which is your CA chain? (1-" + $cas.Count + ")") "1") -as [int]
        if ($null -eq $n) { $n = 0 }
    }
    $CaFile = $cas[$n - 1].FullName; Ok ("CA chain: " + $cas[$n - 1].Name)
} elseif (-not $PinIn) {
    Warn "No .pem in the folder: fine if Windows already trusts PATCH-01's certificate; setup will say if it does not"
}

# ---------------------------------------------------------------------------
Step "5/6" "Enrolment token"
$Token = $null; $TokenFromFile = $false; $script:TokenTag = ""; $UseTokenFile = $false
function Test-OnShare {
    if ($Shared.StartsWith("\\")) { return $true }
    try { return ((New-Object IO.DriveInfo($Shared.Substring(0, 1))).DriveType -eq [IO.DriveType]::Network) } catch { return $false }
}
function Get-NextToken {
    # Called only after the summary is confirmed; the token is marked as taken (by fingerprint) under a lock
    return (Invoke-Locked "tokens" {
                $used = @{}
                if (Test-Path $TokensUsed) { foreach ($l in @(Get-Content $TokensUsed)) { $p = $l.Split(","); if ($p.Count -ge 1) { $used[$p[0].Trim('"')] = $true } } }
                $sha = [Security.Cryptography.SHA256]::Create()
                $pick = $null
                foreach ($t in @(Get-Content $TokensFile | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith("#") })) {
                    $tag = ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($t))) -replace "-", "").Substring(0, 16).ToLowerInvariant()
                    if (-not $used.ContainsKey($tag)) {
                        # Only a fingerprint of the token is written, never the token itself
                        if (-not (Test-Path $TokensUsed)) { Set-Content -Path $TokensUsed -Value '"TokenTag","Server","When"' -Encoding UTF8 }
                        Add-Content -Path $TokensUsed -Value ('"{0}","{1}","{2}"' -f $tag, $Computer, (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")) -Encoding UTF8
                        $pick = $t; $script:TokenTag = $tag; break
                    }
                }
                $sha.Dispose()
                return $pick
            })
}
function Undo-TokenTaken([string]$Tag) {
    # The enrolment did not happen: the token is still good, give it back for the next server
    try {
        Invoke-Locked "tokens" {
            $keep = @(Get-Content $TokensUsed | Where-Object { $_ -notlike ('"' + $Tag + '",*') })
            Set-Content -Path $TokensUsed -Value $keep -Encoding UTF8
        } | Out-Null
    } catch { }
}
if ($script:Mode -ne "new") { Ok "Not needed: an existing agent keeps its identity" }
else {
    if (Test-Path $TokensFile) {
        if (-not (Test-OnShare)) {
            # On a local copy every server would see its own list and take the same token
            Stop-Deploy "tokens.txt only works from a shared folder (\\server\share). In a local copy, every server would take the same token and all unused tokens would stay on this server. Delete tokens.txt here and run again (you will be asked for a token)."
        }
        $UseTokenFile = $true
        Ok "A token from tokens.txt will be taken after you confirm the summary"
    }
    while (-not $UseTokenFile -and -not $Token) {
        $sec = Read-Host "  Enrolment token (PATCH-01: ./scripts/phase10-windows.sh --tokens 1 <group>; hidden while typing)" -AsSecureString
        $a = [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
        if ($a -and $a.Trim() -match '^[A-Za-z0-9._~+/=-]{16,200}$') { $Token = $a.Trim() } else { Warn "That does not look like an enrolment token" }
        $a = $null
    }
}

# ---------------------------------------------------------------------------
Step "6/6" "Summary"
Info ("Server        " + $Computer)
Info ("Action        " + $(switch ($script:Mode) { "new" { "NEW install and enrol" } "upgrade" { "UPGRADE " + $script:FromVer + " -> " + $NewVer } default { "REFRESH " + $NewVer } }))
Info ("PATCH-01      " + $Server)
Info ("Certificate   " + $(if ($PinIn) { "pin " + $PinIn.Substring(0, 16) + "..." } elseif ($CaFile) { "CA chain " + (Split-Path -Leaf $CaFile) } else { "Windows' own trust" }))
Info ("Agent task    " + $(if ($Gpo) { $SysPolicy + " (Group Policy)" } else { $TaskPolicy + " for its own process; server stays " + $SysPolicy }))
if (-not (Confirm "Go ahead?" $true)) { Stop-Deploy "Stopped at your request." }
if ($UseTokenFile) {
    try { $Token = Get-NextToken } catch { Stop-Deploy ("tokens.txt could not be used: " + $_.Exception.Message) }
    if (-not $Token) { Stop-Deploy "Every token in tokens.txt is used. Make more on PATCH-01 (phase10-windows.sh --tokens N <group>)." }
    $TokenFromFile = $true
    Ok ("Token taken from tokens.txt (fingerprint " + $script:TokenTag + ")")
}

if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }
$transcript = Join-Path $LogDir ("deploy-" + (Get-Date).ToString("yyyyMMdd-HHmmss") + ".log")
try { Start-Transcript -Path $transcript | Out-Null } catch { }
$setupArgs = @{ Server = $Server; Yes = $true }
if ($PinIn) { $setupArgs.Pin = $PinIn } elseif ($CaFile) { $setupArgs.CaFile = $CaFile }
if ($Token) { $setupArgs.Token = $Token }
$global:LASTEXITCODE = 0
$ok = $true; $why = ""
try {
    & (Join-Path $Here "Setup-Agent.ps1") @setupArgs
    if ($LASTEXITCODE -ne 0) { $ok = $false; $why = "Setup-Agent stopped (see above)" }
} catch { $ok = $false; $why = $_.Exception.Message }
$Token = $null
try { Stop-Transcript | Out-Null } catch { }

$now = Get-VersionIn (Join-Path $InstallDir "patch-agent.ps1")
if ($ok -and $now -eq $NewVer) {
    Write-DeployLog "ok" ("agent " + $now + " running; log " + $transcript)
    Write-Host ""; Write-Host ("  DONE  " + $Computer + " is on agent " + $now + ".") -ForegroundColor Green
    Write-Host ("        Full log: " + $transcript)
    if ($cu -and $cu -ne "Undefined") {
        Write-Host ""
        Warn ("Your own account still has CurrentUser = " + $cu + ". Not needed by the agent. To remove it:  Set-ExecutionPolicy Undefined -Scope CurrentUser")
    }
    Write-Host ""
    exit 0
}
$detail = $(if ($why) { $why } else { "installed version is " + $now + ", expected " + $NewVer })
if ($TokenFromFile) {
    if (Test-Path (Join-Path $DataDir "token.bin")) { $detail += "; the token from tokens.txt was used (enrolment happened)" }
    else { Undo-TokenTaken $script:TokenTag; $detail += "; it did not enrol, so its token was given back for the next run" }
}
Write-DeployLog "failed" $detail
Write-Host ""; Write-Host ("  FAILED  " + $detail) -ForegroundColor Red
Write-Host ("          Full log: " + $transcript); Write-Host ""
exit 1
