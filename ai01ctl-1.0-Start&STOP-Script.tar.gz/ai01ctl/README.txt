ai01ctl 1.0 - start, stop and check AI-01 (model server and nginx), in order
===========================================================================

Install (once, as root, on AI-01):

    tar xzf ai01ctl-1.0.tar.gz && cd ai01ctl
    sha256sum -c SHA256SUMS
    ./ai01ctl install

This copies the script to /usr/local/sbin/ai01ctl, so it runs from any
folder, and adds ai01-stack.service:
  - at shutdown or reboot, nginx stops first (no new requests), then the
    model server;
  - at boot, both are checked; anything not running is started, and the model
    server is given time to load the model before nginx is judged.

Use:

    ai01ctl status      both services, whether the model is loaded, the endpoint
    ai01ctl start       model server first (waits for the model), then nginx
    ai01ctl stop        nginx, then the model server
    ai01ctl restart

A model server that never finishes loading is restarted once; if it still
does not answer, start stops and gives the journalctl command to see why.
The model server's port is read from /llm/config/run-llama-server.sh.

Log: /var/log/ai01ctl.log            Remove the boot unit: ai01ctl uninstall
