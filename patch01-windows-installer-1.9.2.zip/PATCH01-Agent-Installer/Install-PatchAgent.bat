@echo off
rem ===========================================================================
rem  PATCH-01 agent for Windows: install a new server, or upgrade an existing one.
rem
rem  Keep in ONE folder (a share, or a copy on the server):
rem      Install-PatchAgent.bat                 this file
rem      patch01-agent-windows-<version>.zip    the agent, as delivered (keep only one)
rem      your CA chain .pem                     optional when you paste the pin
rem
rem  Right-click this file, "Run as administrator". It asks for:
rem      1. PATCH-01's address      https://<name>
rem      2. the certificate pin     on PATCH-01: ./scripts/phase10-windows.sh --pin
rem                                 (checked at once against the certificate PATCH-01 presents)
rem      3. an enrolment token      new servers only; on PATCH-01:
rem                                 ./scripts/phase10-windows.sh --tokens 1 <group>
rem  The pin and the address are remembered in deploy-settings.json in this
rem  folder, so on the next server you press Enter. The token is never stored.
rem
rem  What it does: unzips the agent into %ProgramFiles%\PatchAgent-Setup (only
rem  administrators can write there), unblocks the files (Windows marks files
rem  from a download or a share as "from the internet"), and runs
rem  Deploy-Agent.ps1 with this window's PowerShell set to RemoteSigned for this
rem  one process. The server's own execution policy is not changed. Every result
rem  is added to deploy-log.csv in this folder (when writable) and to
rem  C:\ProgramData\PatchAgent-Deploy on the server.
rem ===========================================================================
setlocal EnableExtensions DisableDelayedExpansion
title PATCH-01 agent - install or upgrade

set "PA_HERE=%~dp0"
if "%PA_HERE:~-1%"=="\" set "PA_HERE=%PA_HERE:~0,-1%"
rem A drive root ("D:") stays a path to that root, without a trailing backslash before a quote
if "%PA_HERE:~-1%"==":" set "PA_HERE=%PA_HERE%\."
set "PA_LOGDIR=%ProgramData%\PatchAgent-Deploy"
if not exist "%PA_LOGDIR%" mkdir "%PA_LOGDIR%" >nul 2>&1
set "PA_LOG=%PA_LOGDIR%\install-bat.log"

echo.
echo  PATCH-01 agent - install or upgrade on %COMPUTERNAME%
echo  ------------------------------------------------------------
echo.

rem ---- 1. Administrator ------------------------------------------------------
rem fltmc answers only in an administrator window (net session needs the Server service)
"%SystemRoot%\System32\fltmc.exe" >nul 2>&1
if errorlevel 1 goto :not_admin
echo  [ok]   Running as administrator

rem ---- 2. PowerShell 5.1 -----------------------------------------------------
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" goto :no_powershell
"%PS%" -NoProfile -NonInteractive -Command "if ($PSVersionTable.PSVersion.Major -lt 5) { exit 1 }" >nul 2>&1
if errorlevel 1 goto :old_powershell
echo  [ok]   Windows PowerShell 5.1 present

rem ---- 3. The agent package --------------------------------------------------
set "PA_ZIPNAME="
set "PA_ZIPCOUNT=0"
for /f "delims=" %%Z in ('dir /b /a-d /o:n "%PA_HERE%\patch01-agent-windows-*.zip" 2^>nul') do (
    set "PA_ZIPNAME=%%Z"
    set /a PA_ZIPCOUNT+=1
)
if not defined PA_ZIPNAME goto :no_zip
if %PA_ZIPCOUNT% GTR 1 echo  [warn] %PA_ZIPCOUNT% agent zips in this folder: using %PA_ZIPNAME% ^(keep only one^)
set "PA_ZIP=%PA_HERE%\%PA_ZIPNAME%"
set "PA_DEST=%ProgramFiles%\PatchAgent-Setup\%PA_ZIPNAME:~0,-4%"
echo  [ok]   Agent package: %PA_ZIPNAME%

rem ---- 4. Unzip on this server and unblock -----------------------------------
rem  Values travel in environment variables, so no path is ever parsed as a command.
"%PS%" -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -Command ^
  "$ErrorActionPreference = 'Stop';" ^
  "try {" ^
  "  if (Test-Path -LiteralPath $env:PA_DEST) { Remove-Item -LiteralPath $env:PA_DEST -Recurse -Force };" ^
  "  New-Item -ItemType Directory -Path $env:PA_DEST -Force | Out-Null;" ^
  "  Add-Type -AssemblyName System.IO.Compression.FileSystem;" ^
  "  [IO.Compression.ZipFile]::ExtractToDirectory($env:PA_ZIP, $env:PA_DEST);" ^
  "  $dir = $env:PA_DEST; $sub = Join-Path $dir 'patch01-agent-windows'; if (Test-Path -LiteralPath (Join-Path $sub 'Deploy-Agent.ps1')) { $dir = $sub };" ^
  "  if (-not (Test-Path -LiteralPath (Join-Path $dir 'Deploy-Agent.ps1'))) { throw 'Deploy-Agent.ps1 is not in the zip' };" ^
  "  Get-ChildItem -LiteralPath $env:PA_HERE -File | Where-Object { $_.Extension -in @('.pem', '.crt', '.cer') } | Copy-Item -Destination $dir -Force;" ^
  "  Get-ChildItem -LiteralPath $env:PA_DEST -Recurse -File | Unblock-File;" ^
  "  Set-Content -LiteralPath (Join-Path $env:PA_DEST 'where.txt') -Value $dir -Encoding ASCII;" ^
  "  exit 0" ^
  "} catch { Write-Host ('  [FAIL] ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }"
if errorlevel 1 goto :unzip_failed
set "PA_DIR="
set /p PA_DIR=<"%PA_DEST%\where.txt"
if not defined PA_DIR goto :unzip_failed
echo  [ok]   Unzipped to %PA_DIR% and unblocked

rem ---- 5. Group Policy that forces AllSigned cannot be overridden here -------
"%PS%" -NoProfile -NonInteractive -Command "if ((Get-ExecutionPolicy -Scope MachinePolicy) -in @('AllSigned', 'Restricted')) { exit 1 }" >nul 2>&1
if errorlevel 1 goto :gpo_policy

rem ---- 6. The installer itself (asks for the pin, the address, the token) ---
echo.
"%PS%" -NoProfile -ExecutionPolicy RemoteSigned -File "%PA_DIR%\Deploy-Agent.ps1" -AllowUnsigned -SharedFolder "%PA_HERE%"
set "PA_RC=%ERRORLEVEL%"
>>"%PA_LOG%" 2>nul echo %DATE% %TIME% %COMPUTERNAME% %PA_ZIPNAME% exit code %PA_RC%
if not "%PA_RC%"=="0" goto :install_failed

rem The unzipped copy is no longer needed: the agent runs from %ProgramFiles%\PatchAgent
rmdir /s /q "%PA_DEST%" >nul 2>&1
echo.
echo  ============================================================
echo   SUCCESS: the PATCH-01 agent is installed and working on %COMPUTERNAME%.
echo   It shows on PATCH-01's Servers page within 2 minutes.
echo  ============================================================
echo.
pause
exit /b 0

:not_admin
echo  [FAIL] This needs administrator rights.
echo         Right-click Install-PatchAgent.bat and choose "Run as administrator".
goto :end_fail

:no_powershell
echo  [FAIL] Windows PowerShell was not found at %PS%.
goto :end_fail

:old_powershell
echo  [FAIL] Windows PowerShell 5.1 is needed. Install Windows Management Framework 5.1 first.
goto :end_fail

:no_zip
echo  [FAIL] No patch01-agent-windows-*.zip in %PA_HERE%
echo         Put the agent zip, as delivered, in the same folder as this file.
echo         Started from a mapped drive letter? An administrator window does not see mapped
echo         drives: run it from its \\server\share path, or copy the folder to this server.
goto :end_fail

:unzip_failed
echo  [FAIL] The agent zip could not be unzipped to %PA_DEST%.
echo         Check the zip is complete ^(copy it again^) and that C: has free space.
goto :end_fail

:gpo_policy
echo  [FAIL] Group Policy sets the PowerShell execution policy for this computer to AllSigned or Restricted.
echo         A Group Policy setting cannot be overridden for one process. Either sign the scripts
echo         ^(Sign-Agent.ps1 on the PC with your code-signing certificate^) or ask for the GPO to allow RemoteSigned.
goto :end_fail

:install_failed
echo.
echo  ============================================================
echo   FAILED on %COMPUTERNAME% ^(exit code %PA_RC%^). The reason is shown above.
echo   Full log: %ProgramData%\PatchAgent-Deploy\deploy-*.log
echo   Nothing half-done is left running: run this file again after fixing it.
echo  ============================================================
echo.
pause
exit /b %PA_RC%

:end_fail
>>"%PA_LOG%" 2>nul echo %DATE% %TIME% %COMPUTERNAME% stopped before the installer
echo.
pause
exit /b 1
