PATCH-01 agent 1.9.2 for Windows: installer
===========================================

Use this 1.9.2 installer for every new install and reinstall: PATCH-01 r82
checks the server's hardware ID when a server enrols again.

1. Put this folder where the servers can read it (a share, e.g.
   \\fileserver\PATCH01-Agent-Installer), or copy it to the server.
   Add your CA chain .pem if you use one (optional when you paste the pin).
   Keep only one patch01-agent-windows-*.zip in the folder.

2. On PATCH-01, get the pin and tokens:
       ./scripts/phase10-windows.sh --pin
       ./scripts/phase10-windows.sh --tokens 1 <group>     (one per new server)

3. On each server: right-click Install-PatchAgent.bat, "Run as administrator".
   It asks, in this order:
       PATCH-01 address  https://<name> (Enter reuses the one remembered)
       Certificate pin   paste it (Enter reuses the one remembered here,
                         offered only while it fits PATCH-01's certificate)
       Enrolment token   new servers, and servers PATCH-01 no longer accepts
                         (removed or decommissioned there, rebuilt, cloned);
                         hidden while you paste it
       Go ahead? [Y/n]   Enter
   and ends with SUCCESS or FAILED and the reason.

Started from a mapped drive letter? An administrator window does not see
mapped drives: use the \\server\share path, or copy the folder locally.

Results of every server: deploy-log.csv in this folder (when writable), and
C:\ProgramData\PatchAgent-Deploy on each server. The token is never stored;
deploy-settings.json here keeps only the pin and the address (not secrets).
The server's PowerShell execution policy is not changed: only the installer's
own window runs with RemoteSigned.

After 1.8.0 or later is installed, newer agents are sent from PATCH-01
(Servers > Update agents): no more visits to the servers.
