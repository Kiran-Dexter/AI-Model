"""Access review (r119): file and folder permissions reports, application and owning-team tags, and
the reports made from them. Admins only. The API records what an admin asks; the worker reads the
file and asks AI-01. Every figure in a report is counted by PostgreSQL from the rows."""
import re
from typing import Dict, List, Optional

from fastapi import Depends, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field

from .core import AgentIdentity, app, audit, client_ip, db, jsonable, require_admin, require_agent

ID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")


def _id(v):
    v = (v or "").lower()
    if not ID_RE.match(v):
        raise HTTPException(404, "Not found.")
    return v


def _call(fn):
    """Run fn(conn) in one transaction; PermError -> HTTP 400 with its sentence."""
    from . import perm_review as pr
    with db() as conn:
        try:
            out = fn(conn)
        except pr.PermError as e:
            conn.rollback()
            raise HTTPException(400, str(e))
        conn.commit()
        return out


def _audit(conn, admin, request, action, detail):
    audit(conn, actor=admin, actor_type="user", action=action, object_type="access_review", detail=detail,
          source_ip=client_ip(request))


@app.get("/api/v1/admin/access")
def access_list(admin: str = Depends(require_admin)):
    from . import perm_review as pr
    with db() as conn:
        out = pr.datasets(conn)
    if out is None:
        raise HTTPException(409, "Schema 060 is not applied yet: run phase3a-schema.sh.")
    return jsonable(out)


class UploadIn(BaseModel):
    file_name: str = Field(..., max_length=200)
    size: int = Field(..., gt=0)
    name: Optional[str] = Field(None, max_length=120)


@app.post("/api/v1/admin/access/uploads")
def access_upload_start(body: UploadIn, request: Request, admin: str = Depends(require_admin)):
    from . import perm_review as pr

    def work(conn):
        r = pr.start_upload(conn, admin, body.file_name, body.size, body.name)
        _audit(conn, admin, request, "access_upload", {"file": body.file_name, "size": body.size, "dataset": r["dataset_id"]})
        return r
    return jsonable(_call(work))


@app.put("/api/v1/admin/access/uploads/{ds_id}")
async def access_upload_piece(ds_id: str, request: Request, offset: int = 0, admin: str = Depends(require_admin)):
    """One piece of the file (at most 32 MB), at the offset PATCH-01 expects."""
    from starlette.concurrency import run_in_threadpool
    from . import perm_review as pr
    ds_id = _id(ds_id)
    cl = request.headers.get("content-length")
    if cl and (not cl.isdigit() or int(cl) > pr.CHUNK_MAX):
        raise HTTPException(413, "A piece is at most 32 MB.")
    data = bytearray()
    async for part in request.stream():
        data += part
        if len(data) > pr.CHUNK_MAX:
            raise HTTPException(413, "A piece is at most 32 MB.")
    return await run_in_threadpool(_call, lambda conn: pr.put_chunk(conn, ds_id, offset, bytes(data)))


@app.post("/api/v1/admin/access/uploads/{ds_id}/complete")
def access_upload_complete(ds_id: str, admin: str = Depends(require_admin)):
    from . import perm_review as pr
    ds_id = _id(ds_id)
    return jsonable(_call(lambda conn: pr.finish_upload(conn, ds_id)))


# ---- the access scanner on a file server (r123) ---------------------------------------------------------

@app.get("/api/v1/admin/access/scanners")
def access_scanners(admin: str = Depends(require_admin)):
    from . import perm_scan as ps
    with db() as conn:
        try:
            with conn.transaction():
                return jsonable(ps.scanners(conn))
        except Exception:  # noqa: BLE001 - schema 063 not applied yet
            raise HTTPException(409, "Schema 063 is not applied yet: run phase3a-schema.sh.")


class ScanAskIn(BaseModel):
    host_id: str = Field(..., max_length=40)
    shares: List[str] = Field(default_factory=list, max_length=200)
    paths: List[str] = Field(default_factory=list, max_length=50)
    depth: int = Field(1, ge=0, le=8)
    max_depth: int = Field(16, ge=0, le=64)
    members: bool = True
    full: bool = False


@app.post("/api/v1/admin/access/scans")
def access_scan_ask(body: ScanAskIn, request: Request, admin: str = Depends(require_admin)):
    from . import perm_scan as ps
    host = _id(body.host_id)

    def work(conn):
        sid = ps.ask(conn, host, body.model_dump(), admin)
        _audit(conn, admin, request, "access_scan", {"host_id": host, "scan": sid, "options": body.model_dump()})
        return {"id": sid}
    return _call(work)


@app.post("/api/v1/admin/access/scans/{scan_id}/cancel")
def access_scan_cancel(scan_id: str, admin: str = Depends(require_admin)):
    from . import perm_scan as ps
    scan_id = _id(scan_id)
    return _call(lambda conn: (ps.cancel(conn, scan_id), {"ok": True})[1])


class ScanRegisterIn(BaseModel):
    version: str = Field(..., max_length=40)
    shares: List[str] = Field(default_factory=list, max_length=500)
    check: bool = False


@app.post("/api/v1/agent/access-scans/register")
def agent_scan_register(body: ScanRegisterIn, agent: AgentIdentity = Depends(require_agent)):
    from . import perm_scan as ps
    return _call(lambda conn: ps.register(conn, agent.host_id, body.version, body.shares, body.check))


class ScanStartIn(BaseModel):
    version: str = Field(..., max_length=40)
    note: Optional[str] = Field(None, max_length=200)
    options: Optional[Dict] = None


@app.post("/api/v1/agent/access-scans")
def agent_scan_start(body: ScanStartIn, agent: AgentIdentity = Depends(require_agent)):
    from . import perm_scan as ps
    return _call(lambda conn: {"scan_id": ps.started_here(conn, agent.host_id, body.version, body.options)})


class ScanProgressIn(BaseModel):
    state: str = Field("running", max_length=20)
    stage: Optional[str] = Field(None, max_length=300)
    note: Optional[str] = Field(None, max_length=2000)
    counts: Optional[Dict] = None
    version: Optional[str] = Field(None, max_length=40)


@app.post("/api/v1/agent/access-scans/{scan_id}/progress")
def agent_scan_progress(scan_id: str, body: ScanProgressIn, agent: AgentIdentity = Depends(require_agent)):
    from . import perm_scan as ps
    scan_id = _id(scan_id)
    return _call(lambda conn: ps.progress(conn, agent.host_id, scan_id, body.model_dump()))


class ScanUploadIn(BaseModel):
    file_name: str = Field(..., max_length=200)
    size: int = Field(..., gt=0)
    scan_uid: Optional[str] = Field(None, max_length=80)
    mode: Optional[str] = Field(None, pattern="^(full|delta)$")


@app.get("/api/v1/agent/access-scans/state")
def agent_scan_state(agent: AgentIdentity = Depends(require_agent)):
    """r125: may this server's scanner send only the changes, and against which of its scans."""
    from . import perm_scan as ps
    return jsonable(_call(lambda conn: ps.agent_state(conn, agent.host_id)))


@app.post("/api/v1/agent/access-scans/{scan_id}/upload")
def agent_scan_upload(scan_id: str, body: ScanUploadIn, agent: AgentIdentity = Depends(require_agent)):
    from . import perm_scan as ps
    scan_id = _id(scan_id)
    return jsonable(_call(lambda conn: ps.upload_start(conn, agent.host_id, agent.hostname, scan_id, body.file_name, body.size,
                                                                body.scan_uid, body.mode)))


@app.put("/api/v1/agent/access-scans/{scan_id}/piece")
async def agent_scan_piece(scan_id: str, request: Request, offset: int = 0, agent: AgentIdentity = Depends(require_agent)):
    from starlette.concurrency import run_in_threadpool
    from . import perm_review as pr, perm_scan as ps
    scan_id = _id(scan_id)
    data = bytearray()
    async for part in request.stream():
        data += part
        if len(data) > pr.CHUNK_MAX:
            raise HTTPException(413, "A piece is at most 32 MB.")
    return await run_in_threadpool(_call, lambda conn: ps.upload_piece(conn, agent.host_id, scan_id, offset, bytes(data)))


@app.post("/api/v1/agent/access-scans/{scan_id}/complete")
def agent_scan_complete(scan_id: str, agent: AgentIdentity = Depends(require_agent)):
    from . import perm_scan as ps
    scan_id = _id(scan_id)
    return jsonable(_call(lambda conn: ps.upload_done(conn, agent.host_id, scan_id)))


@app.get("/api/v1/admin/access/{ds_id}")
def access_get(ds_id: str, admin: str = Depends(require_admin)):
    from . import perm_review as pr
    ds_id = _id(ds_id)
    return jsonable(_call(lambda conn: pr.dataset(conn, ds_id)))


@app.delete("/api/v1/admin/access/{ds_id}")
def access_delete(ds_id: str, request: Request, admin: str = Depends(require_admin)):
    from . import perm_review as pr
    ds_id = _id(ds_id)

    def work(conn):
        name = pr.remove(conn, ds_id)
        _audit(conn, admin, request, "access_delete", {"dataset": ds_id, "name": name})
        return {"ok": True}
    return _call(work)


class SheetIn(BaseModel):
    sheet_no: int = Field(..., ge=0, le=1000)
    role: str = Field(..., max_length=20)
    mapping: Dict[str, Optional[int]] = Field(default_factory=dict)


class MappingIn(BaseModel):
    mapping: Optional[Dict[str, Optional[int]]] = None          # one CSV (r119)
    sheets: Optional[List[SheetIn]] = Field(None, max_length=60)   # every sheet (r120)
    tag_depth: int = Field(1, ge=0, le=4)


@app.put("/api/v1/admin/access/{ds_id}/mapping")
def access_mapping(ds_id: str, body: MappingIn, request: Request, admin: str = Depends(require_admin)):
    from . import perm_review as pr
    ds_id = _id(ds_id)

    def work(conn):
        if body.sheets is None and body.mapping is None:
            raise pr.PermError("Say which column holds what.")
        m = pr.set_mapping(conn, ds_id, admin, body.mapping, body.tag_depth,
                           [x.model_dump() for x in body.sheets] if body.sheets is not None else None)
        _audit(conn, admin, request, "access_mapping", {"dataset": ds_id, "mapping": m, "tag_depth": body.tag_depth})
        return {"ok": True, "mapping": m}
    return _call(work)


@app.post("/api/v1/admin/access/{ds_id}/preview")
def access_preview(ds_id: str, body: MappingIn, admin: str = Depends(require_admin)):
    from . import perm_review as pr
    ds_id = _id(ds_id)
    return jsonable(_call(lambda conn: pr.depth_preview(conn, ds_id, body.mapping, body.tag_depth,
                                                        [x.model_dump() for x in body.sheets] if body.sheets is not None else None)))


@app.get("/api/v1/admin/access/{ds_id}/tags")
def access_tags(ds_id: str, state: Optional[str] = None, q: Optional[str] = None, limit: int = 500,
                admin: str = Depends(require_admin)):
    from . import perm_review as pr
    ds_id = _id(ds_id)
    if state not in (None, "", "all", "suggested", "sure", "unsure", "confirmed", "untagged", "no_owner", "inherited"):
        raise HTTPException(400, "Unknown filter.")
    q = (q or "").strip()[:100] or None
    return jsonable(_call(lambda conn: pr.tags_view(conn, ds_id, state, q, max(1, min(limit, 2000)))))


class TagAskIn(BaseModel):
    again: bool = False
    stop: bool = False
    scope: str = Field("all", pattern="^(all|unsure)$")


@app.post("/api/v1/admin/access/{ds_id}/tags/ask")
def access_tags_ask(ds_id: str, body: TagAskIn, request: Request, admin: str = Depends(require_admin)):
    from . import perm_review as pr
    ds_id = _id(ds_id)

    def work(conn):
        if body.stop:
            conn.execute("UPDATE perm_datasets SET tag_ai = 'idle', tag_ai_note = 'stopped by ' || %s WHERE id = %s "
                         "AND tag_ai IN ('queued', 'running')", (admin, ds_id))
        else:
            pr.ask_tags(conn, ds_id, body.again, body.scope)
            _audit(conn, admin, request, "access_tags_ask", {"dataset": ds_id, "again": body.again, "scope": body.scope})
        return pr.tags_view(conn, ds_id, None, None, 1)
    return jsonable(_call(work))


class TagDecision(BaseModel):
    key: str = Field(..., max_length=600)
    decision: str = Field(..., max_length=10)
    application: Optional[str] = Field(None, max_length=120)
    team: Optional[str] = Field(None, max_length=120)
    owner: Optional[str] = Field(None, max_length=300)
    owner_kind: Optional[str] = Field(None, pattern="^(person|group)$")
    department: Optional[str] = Field(None, max_length=120)
    label: Optional[str] = Field(None, max_length=600)


class TagDecideIn(BaseModel):
    items: List[TagDecision] = Field(..., min_length=1, max_length=2000)


@app.post("/api/v1/admin/access/tags/decide")
def access_tags_decide(body: TagDecideIn, request: Request, admin: str = Depends(require_admin)):
    from . import perm_review as pr

    def work(conn):
        n = pr.decide(conn, admin, [i.model_dump() for i in body.items])
        _audit(conn, admin, request, "access_tags_decide",
               {"count": n, "decisions": {d: sum(1 for i in body.items if i.decision == d) for d in ("confirm", "reject", "clear")},
                "first": [{"key": i.key, "decision": i.decision, "owner": i.owner, "department": i.department,
                           "application": i.application, "team": i.team} for i in body.items[:20]]})
        return {"ok": True, "decided": n}
    return _call(work)


class TagSureIn(BaseModel):
    min_confidence: int = Field(80, ge=80, le=100)


@app.post("/api/v1/admin/access/{ds_id}/tags/accept-sure")
def access_tags_accept_sure(ds_id: str, body: TagSureIn, request: Request, admin: str = Depends(require_admin)):
    """Confirm every suggestion of 80% or more on this upload's folders, as suggested."""
    from . import perm_review as pr
    ds_id = _id(ds_id)

    def work(conn):
        n = pr.accept_sure(conn, ds_id, admin, body.min_confidence)
        _audit(conn, admin, request, "access_tags_accept_sure", {"dataset": ds_id, "min_confidence": body.min_confidence, "count": n})
        return {"ok": True, "decided": n}
    return _call(work)


@app.post("/api/v1/admin/access/{ds_id}/advice")
def access_advice_again(ds_id: str, admin: str = Depends(require_admin)):
    ds_id = _id(ds_id)

    def work(conn):
        conn.execute("UPDATE perm_datasets SET advice = NULL, advice_at = NULL WHERE id = %s AND state = 'ready'", (ds_id,))
        return {"ok": True}
    return _call(work)


class ReportIn(BaseModel):
    kind: str = Field(..., max_length=30)
    title: Optional[str] = Field(None, max_length=120)
    scope: Dict = Field(default_factory=dict)
    options: Dict = Field(default_factory=dict)


@app.post("/api/v1/admin/access/{ds_id}/reports")
def access_report_make(ds_id: str, body: ReportIn, request: Request, admin: str = Depends(require_admin)):
    from . import perm_review as pr
    ds_id = _id(ds_id)

    def work(conn):
        rid = pr.make_report(conn, ds_id, body.model_dump(), admin)
        _audit(conn, admin, request, "access_report", {"dataset": ds_id, "report": rid, "kind": body.kind})
        return {"id": rid}
    return _call(work)


@app.get("/api/v1/admin/access/reports/{report_id}")
def access_report_get(report_id: str, admin: str = Depends(require_admin)):
    from . import perm_review as pr
    report_id = _id(report_id)
    return jsonable(_call(lambda conn: pr.report_view(conn, report_id)))


@app.delete("/api/v1/admin/access/reports/{report_id}")
def access_report_delete(report_id: str, admin: str = Depends(require_admin)):
    report_id = _id(report_id)

    def work(conn):
        conn.execute("DELETE FROM perm_reports WHERE id = %s", (report_id,))
        return {"ok": True}
    return _call(work)


@app.post("/api/v1/admin/access/reports/{report_id}/summary")
def access_report_summary(report_id: str, admin: str = Depends(require_admin)):
    report_id = _id(report_id)

    def work(conn):
        conn.execute("UPDATE perm_reports SET summary_state = 'queued' WHERE id = %s", (report_id,))
        return {"ok": True}
    return _call(work)


@app.get("/api/v1/admin/access/reports/{report_id}/csv")
def access_report_csv(report_id: str, request: Request, what: str = "findings", admin: str = Depends(require_admin)):
    from . import perm_review as pr
    report_id = _id(report_id)
    if what not in ("findings", "people", "folders"):
        raise HTTPException(400, "Unknown export.")

    def work(conn):
        text = {"findings": pr.findings_csv, "people": pr.people_csv, "folders": pr.folders_csv}[what](conn, report_id)
        r = conn.execute("SELECT title FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
        _audit(conn, admin, request, "access_report_csv", {"report": report_id})
        return text, r["title"]
    text, title = _call(work)
    name = (re.sub(r"[^A-Za-z0-9._-]+", "-", title).strip("-")[:60] or "access-report") + {"people": "-accounts", "folders": "-folders"}.get(what, "") + ".csv"
    return Response(text.encode("utf-8"), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{name}"', "Cache-Control": "no-store"})
