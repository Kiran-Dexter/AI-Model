# Patch Platform

A self-hosted patch and vulnerability management platform for an estate of
about 200 Linux servers running RHEL 8/9, Oracle Linux 8 and Ubuntu.

It mirrors vendor patches, tracks which servers are exposed to which
security advisories, explains each verdict in plain language using a local
language model, and shows it all on a web console.

Nothing here reaches the internet except PATCH-01's repository syncs, which go
through the corporate proxy. AI-01 has no internet access at all.


## Architecture

```
                vendor repos (Red Hat CDN, Oracle, Ubuntu)
                               |
                         corporate proxy
                               |
+----------------------------- | -------------------------------------+
| PATCH-01  (RHEL 9, Docker)   v                                       |
|                                                                      |
|  NGINX :443  ── the only port open on this host                      |
|    /                 -> dashboard     static web console             |
|    /api/             -> patch-api     FastAPI: agents, admin, CVEs   |
|    /pulp/api/v3/     -> pulp-api      repository management          |
|    /pulp/content/    -> pulp-content  package downloads              |
|                                                                      |
|  pulp-worker   syncs and publishes repositories                      |
|  postgres      two databases: pulp, patchdb                          |
|  redis         job queue and cache                                   |
|                                                                      |
|  Every service except NGINX publishes NO host port. They talk over   |
|  the internal Docker network "patchnet" by container name.           |
+---------------------------|-----------------------------|------------+
                            | HTTPS 443                   | HTTPS 443
                            v                             v
        ~200 managed servers (agents)          AI-01 (RHEL 9, no internet)
        pull-only: check in, send               NGINX :443, allows PATCH-01 only
        inventory, poll for commands            llama-server on 127.0.0.1:8080
                                                Qwen3-8B Q4_K_M
```

Design rules that run through everything:

- **The verdict comes from a version check, never from the model.** The CVE
  engine decides; AI-01 only explains. Every explanation is labelled as
  advisory in the console.
- **Five applicability states**, stored as a database enum so every screen and
  report reads the same values: `affected`, `fixed_pending_reboot`,
  `fixed_active`, `unknown`, and `not_affected` (implied by absence). Only
  `fixed_active` counts as remediated. A server with the fixed kernel
  installed but not yet booted is **not** remediated.
- **A server that stops reporting shows as "unknown", never as zero.** Silence
  fails toward attention.
- **Agents accept a closed set of eight commands.** None takes a shell string,
  so a compromised PATCH-01 can install signed packages but cannot run
  arbitrary commands as root across the fleet.
- **The audit trail cannot be edited.** A database trigger rejects UPDATE and
  DELETE on the audit log and job events, for every role.
- **Scripts discover what is installed rather than assuming it.** Image names,
  user IDs, data paths, binary locations and supported options are all
  detected at run time.


## What is in this bundle

```
patch-platform/
├── README.md                 this file
├── MANIFEST.sha256           checksums of every file
├── patch01/                  everything for the master server
│   ├── scripts/              run these, in the order below
│   ├── compose/              templates; filled in by the scripts
│   ├── nginx/                ingress configuration
│   ├── sql/                  database schema, applied in order
│   ├── api/                  patch API, CVE engine, AI-01 client
│   ├── dashboard/            web console
│   ├── config/repos.conf     which repositories to mirror
│   └── agent/                copy of the client agent
├── client/                   copy these two files to each managed server
│   ├── patch-agent.py
│   └── install-agent.sh
├── ai01/
│   └── ai01-setup.sh         run on AI-01
└── docs/
    └── proxy-allowlist.txt   for the network team
```


## PATCH-01: build order

Run as root from `patch01/`. Each script has `--dry-run`, and most have
`--check`, which you should run after each step.

| Step | Command | What it does |
|------|---------|--------------|
| 0 | `scripts/phase0-bootstrap.sh` | Packages, LVM volumes, `/patch` tree |
| 1 | `scripts/resolve-images.sh` | Finds which local images fill each role |
| 1a | `scripts/phase1a-ingress.sh` | NGINX and TLS on 443 |
| 1b | `scripts/phase1b-data.sh` | PostgreSQL and Redis |
| 1c | `scripts/phase1c-pulp.sh` | Pulp api, content, worker |
| 2 | `scripts/phase2-repos.py --setup`, `--sync`, `--publish` | Mirror the repositories |
| 3a | `scripts/phase3a-schema.sh` | Patch platform database schema |
| 3b | `scripts/phase3b-api.sh` | Build and run the patch API |
| 4 | `scripts/phase4-cve.sh` | Import advisories, compute verdicts |
| 5 | `scripts/phase5-dashboard.sh` | Web console |
| 6 | `scripts/phase6-llm.sh --ai01 <AI-01 IP>` | Connect to AI-01 |
| 7 | `scripts/phase7-vmware.sh --add <name> --host <vcenter>` | Read VM inventory from each vCenter |
| 8 | `scripts/phase4-cve.sh --set-nvd-key` then `--intel` | Fetch published CVE data |

The **Assess** page and the chat need no setup beyond the API rebuild: they use
data the platform already holds.

Later schema changes are new files in `sql/` (`001`, `002`, `003`, ...).
Re-running `phase3a-schema.sh` applies any that are missing; it is safe to
run again at any time.

Before step 2, the corporate proxy must be recorded in
`/etc/patch-platform/proxy.env` (`HTTP_PROXY`, `HTTPS_PROXY`, `NO_PROXY`).
Step 2 reads it from there, not from your shell.

**Note on phase 0:** it was written when the plan was Podman, before Docker was
chosen. It installs Podman and moves Podman's image store onto `/patch`, which
is harmless but does not apply to Docker. Docker's own storage location is not
handled by phase 0; phase 1a detects if Docker is still storing images on the
root filesystem and prints the steps to move it.


## Client servers

Copy `client/` to the server, then as root:

```bash
# On PATCH-01, get a single-use token
./scripts/phase3b-api.sh --token

# On the server
./install-agent.sh --server https://SGPINFAPPXU01 --token <token> --insecure
```

The installer checks it can reach PATCH-01, tests inventory collection before
contacting it, enrolls, and installs a systemd timer that checks in every five
minutes. `--insecure` is only for while PATCH-01 has its self-signed
placeholder certificate; use `--ca <file>` once the CA-signed certificate is in
place.

Works on RHEL 8 (it uses the system Python 3.6), RHEL 9, Oracle Linux and
Ubuntu. The agent never routes its traffic to PATCH-01 through a proxy, even
if one is set in the environment.


## AI-01

1. Place the model and llama.cpp under `/llm`:
   `/llm/models/*.gguf` and `/llm/bin/llama.cpp-<tag>/`
2. If llama.cpp is source code, build it on AI-01. The compilers come from
   PATCH-01's own mirror, since AI-01 has no internet:

   ```bash
   # /etc/yum.repos.d/patch01.repo pointing at
   #   https://<PATCH-01>/pulp/content/rhel9-baseos/
   #   https://<PATCH-01>/pulp/content/rhel9-appstream/
   dnf --disablerepo='*' --enablerepo='patch01-*' install -y gcc-c++ cmake make nginx
   cd /llm/bin/llama.cpp-<tag>
   cmake -B build -DGGML_NATIVE=ON -DLLAMA_CURL=OFF -DCMAKE_BUILD_TYPE=Release
   cmake --build build -j"$(nproc)" --target llama-server
   ```
3. Run the setup, giving PATCH-01's address as the only allowed client:

   ```bash
   ./ai01-setup.sh --patch01-ip <PATCH-01 IP>
   ./ai01-setup.sh --check
   ./ai01-setup.sh --show-key
   ```
4. On PATCH-01, run step 6 and paste that key when asked.


## VMware vCenter

Read-only. PATCH-01 reads each vCenter's VMs and snapshots and links every
server to the VM it runs in. Nothing is changed in vCenter.

**Account.** Create a dedicated account, for example
`svc-patch01@vsphere.local`, in each vCenter, and give it the built-in
**Read-only** role at the top of the inventory with **Propagate to children**
ticked. That is all this needs. Snapshot rights are added only later, when
patch jobs take snapshots before patching.

**Add each vCenter** from `patch01/`:

```bash
./scripts/phase7-vmware.sh --add vc-sg01 --host vcenter01.corp.local
./scripts/phase7-vmware.sh --add vc-sg02 --host vcenter02.corp.local
./scripts/phase7-vmware.sh --install-timer        # sync every hour
```

`--add` shows vCenter's certificate thumbprint. Compare it with the one in
the vSphere Client under **Administration > Certificates > Certificate
Management > Machine SSL Certificate** before confirming. Use the vCenter's
name as it appears in its certificate, normally its FQDN, or the connection
is refused. The first `--add` also applies schema 004 and rebuilds the API
with VMware's Python library, which it downloads through the proxy.

**How servers are linked to VMs.** By hardware ID, which VMware sets as the
VM's BIOS UUID and the server reads from its firmware. That needs agent 1.2.0
or later. Older agents are linked by hostname or IP address instead, which is
weaker, and the console shows which method linked each one. A VM that shares
its hardware ID with another, usually a clone, is marked ambiguous rather
than guessed.

**Infrastructure and the map.** The VMware page has a **Map** tab showing
vCenter > datacenter > cluster > ESXi host > VM as an expandable tree, with
each VM marked by its patch and agent state, and a datastore summary. Separate
tabs list ESXi hosts (hardware, CPU model, ESXi version and build, connection
state, maintenance mode, uptime, CPU and memory load, VM count), datastores
(type, capacity, used, free, provisioned beyond capacity, hosts, VMs),
networks and clusters (DRS, HA, totals). Each VM also records its ESXi host,
folder path, datastores, networks, disks with sizes and thin provisioning,
hardware version, Tools version, boot time and provisioned storage.

**What the VMware page shows:** every VM across all vCenters, Windows
included, with a filter box for name, server, cluster or OS; Linux VMs running
without an agent; VMs with snapshots and their age; and ambiguous links.
Windows VMs appear as "not managed", since the Linux agent does not cover
them. Each server page
shows its VM, cluster, ESXi host, size and any snapshots.


## CVE intelligence

Advisories say which package to update; they rarely say what the flaw is.
These four sources fill that in, and every fact is shown with its source:

| Source | What it gives |
|--------|---------------|
| NIST NVD | Description, CVSS score and vector, weakness type (CWE) |
| CISA KEV | Whether the CVE is being exploited in the wild |
| FIRST EPSS | Probability of exploitation in the next 30 days |
| Red Hat | Red Hat's own severity, score and statement for RHEL |

**Get a free NVD API key** first. It raises the limit from 5 to 50 requests
every 30 seconds, and the first import is one request per CVE:

```bash
./scripts/phase4-cve.sh --set-nvd-key      # from nvd.nist.gov/developers/request-an-api-key
./scripts/phase4-cve.sh --estimate         # how long the first import will take
./scripts/phase4-cve.sh --intel
```

A few thousand CVEs takes roughly 30 to 40 minutes with a key, and several
hours without. Afterwards only new and changed CVEs are fetched, so the
nightly run is quick. This is the only part of the platform that reaches the
internet besides repository syncs; it needs four proxy allowlist entries,
listed in `docs/proxy-allowlist.txt`.

**Attack types are derived, not claimed.** "Remote code execution, no login
needed" comes from combining the weakness type with the CVSS vector, and the
console always shows what it was derived from, for example "CWE-362; attack
vector network, no login". Where the published data does not support a
label, it says "Unclassified" rather than guessing.

**This is what makes explanations specific.** Before, every CVE produced
roughly the same answer, because the model was only given an advisory title
such as "kernel security update". It now receives the score, how the flaw is
reached, whether it is exploited in the wild, and the CVE description.
Cached explanations are regenerated automatically when NVD rescores a CVE or
CISA adds it to the exploited list.


## Assessing a CVE list from outside

When a SOC, an auditor or a vendor sends a list of CVEs, the **Assess** page
answers which of your servers are affected. Paste the list or upload a text
or CSV file; the parser takes CVE numbers out of any text, including the en
dashes and stray spaces that survive a copy from a document.

Each CVE gets one of six answers:

| Status | Meaning |
|--------|---------|
| Needs patch | At least one server needs the fix |
| Needs reboot | Installed everywhere, but a reboot is due |
| Patched | Every server carrying the package is fixed and running it |
| Unknown | Only servers whose inventory is stale are involved |
| Not applicable | An advisory exists, but no server has the package |
| Cannot assess | No advisory in the mirrors mentions this CVE |

"Cannot assess" is deliberately not "not affected". Without a vendor's
fixed-in version there is nothing to compare an installed package against, and
saying "clean" there would be a guess.

Each assessment is saved, so the answer can be reopened later, and exported as
CSV to send back to whoever asked. That also records that the question was
asked and answered on a date.


## Chat

The icon at the bottom right of the console opens a chat for asking about the
fleet: which servers a CVE affects, which need patches, which agents are
offline, which VMs carry old snapshots.

It is **read-only**. Patching, snapshots and power operations go through the
approval flow, never from a sentence typed into a chat.

How it answers, and why it can be trusted:

- AI-01 only chooses **which prepared query to run**, from a fixed list. It
  never writes database queries and never supplies a figure that appears in an
  answer.
- Parameters are rebuilt against a type and range before use, so a confused or
  manipulated model cannot widen a query.
- Every answer shows the rows it came from, and which query produced them, so a
  wrong choice looks visibly wrong rather than sounding confident.
- If AI-01 is unreachable, keywords choose the query and the chat still works.

Admin only, like the rest of the console.


## Keeping the dashboard truthful

The console can only be as current as the last repository sync. If the mirror
is behind, the platform will report a server as patched because the newer
advisory is not in the mirror yet, while `dnf` talking to the vendor directly
sees it. Sync, import, then compute, in that order:

```bash
./scripts/phase2-repos.py --sync --publish
./scripts/phase4-cve.sh --import
./scripts/phase4-cve.sh --compute
```

`phase4-cve.sh --install-timer` runs the import and compute nightly; schedule
the repository sync a couple of hours earlier so the engine has fresh
advisories to read.


## Everyday operations

| Task | Where | Command |
|------|-------|---------|
| Open the console | browser | `https://SGPINFAPPXU01/` |
| Issue an enrollment token | PATCH-01 | `scripts/phase3b-api.sh --token` |
| Sync repositories | PATCH-01 | `scripts/phase2-repos.py --sync` then `--publish` |
| Recompute verdicts now | PATCH-01 | `scripts/phase4-cve.sh` |
| Verdicts for one server | PATCH-01 | `scripts/phase4-cve.sh --host <name>` |
| Fleet report in the terminal | PATCH-01 | `scripts/phase4-cve.sh --report` |
| Pre-generate explanations | PATCH-01 | `scripts/phase6-llm.sh --warm 20` |
| Nightly CVE run and explanations | PATCH-01 | `phase4-cve.sh --install-timer`, `phase6-llm.sh --install-timer` |
| After a Red Hat certificate refresh | PATCH-01 | `subscription-manager refresh`, then `phase2-repos.py --update-remotes` |
| Health of the whole stack | PATCH-01 | each script's `--check` |
| Agent status, one server | client | `install-agent.sh --status` |
| Agent status, whole fleet | browser | **Agents** page |
| Model server status and speed | AI-01 | `ai01-setup.sh --check`, `--bench` |
| vCenter status | PATCH-01 | `scripts/phase7-vmware.sh --check` |
| Refresh CVE data | PATCH-01 | `scripts/phase4-cve.sh --intel` |
| What is exploited in the wild | PATCH-01 | `scripts/phase4-cve.sh --report` |
| Sync vCenters now | PATCH-01 | `scripts/phase7-vmware.sh --sync` |


## Updating agents

Re-run the installer on the server with the new `client/` files. It keeps the
server's existing identity, so no new token is needed:

```bash
./install-agent.sh --server https://SGPINFAPPXU01 --insecure
```

The **Agents** page lists any server still on an older version. The current
agent is 1.2.0.

Agent states:

| State | Meaning |
|-------|---------|
| Online | Checked in within 15 minutes |
| Offline | Missed several check-ins, but under 24 hours |
| Not reporting | Silent over 24 hours; its verdicts show as unknown |
| No data yet | Enrolled but never checked in |

Agent 1.1.0 and later report boot time, from which uptime is shown. Older
agents keep working but show uptime as "not reported".


## Change log

**Advisory to CVE mapping fix**
- CVEs are linked to advisories through each advisory's reference list. Only
  one of the two field namings Pulp uses was handled, so on some versions no
  CVEs were recorded at all and every advisory appeared to have none.
- Both namings are now accepted, with fallbacks for a CVE that appears only
  in a reference link, is filed under another reference type, or is named in
  the advisory text. The import warns if an advisory set yields no CVEs.
- `./scripts/phase4-cve.sh --diagnose` prints the counts and one advisory
  exactly as your Pulp returns it, so the field names can be confirmed.
- To apply: `./scripts/phase4-cve.sh --import` then `--intel`.

**VMware infrastructure map**
- Map tab: vCenter, datacenter, cluster, ESXi host and VM as an expandable
  tree, each VM coloured by patch and agent state.
- ESXi hosts, datastores, networks and clusters, with hardware, versions,
  state and load. Over-provisioned datastores and unresponsive hosts flagged.
- Per VM: ESXi host, folder, datastores, networks, disks, hardware version,
  Tools version, boot time and storage.
- Schema `007-vmware-infra.sql`. Needs a re-sync to populate:
  `./scripts/phase7-vmware.sh --sync`.

**Fixes**
- Agents page returned HTTP 500: its query selected `host_id` and
  `host_status` from the `hosts` table, where those columns are `id` and
  `status`. It now reads the `v_agents` view.
- Chat returned HTTP 500 on filtered questions such as "which rhel servers
  need patches": an untyped NULL filter makes PostgreSQL refuse the query
  ("could not determine data type of parameter"). Every placeholder now
  carries an explicit type.
- `phase4-cve.sh --diagnose` also reports verdict counts and table sizes, so
  an empty dashboard can be traced to a missing sync, import or compute.

**Assess a CVE list, and admin chat**
- New Assess page: paste or upload a CVE list from a SOC or auditor and get a
  per-CVE verdict across the fleet, saved and exportable as CSV.
- New chat, read-only, behind the icon at the bottom right. The model picks
  which prepared query to run; the database supplies every figure and the rows
  are always shown.
- Schema `006-assessments.sql`; `python-multipart` added to the API image.

**CVE intelligence**
- NVD, CISA KEV, FIRST EPSS and Red Hat data per CVE, with the attack type
  derived from the weakness and the CVSS vector.
- The console shows CVSS, an "Exploited" marker, how the flaw is reached, the
  exploitation probability and the CVE description, with sources.
- AI explanations now use these facts instead of an advisory title, which was
  why every CVE produced a similar answer.
- `phase4-cve.sh --intel`, `--set-nvd-key`, `--estimate`; schema
  `005-cve-intel.sql`; nightly timer now refreshes CVE data too.

**VMware, part 1: inventory**
- New VMware page: each vCenter's status, Linux VMs without an agent, VM
  snapshots and their age, and ambiguous links.
- Each server page shows its VM, cluster, ESXi host, size and snapshots.
- Agent 1.2.0 reports the hardware ID used to link servers to VMs.
- `phase7-vmware.sh`, schema `004-vmware.sql`, and pyVmomi 8.0.3.0.1 in the
  API image. Several vCenters are supported and one failing does not stop
  the others.

**Step 7: agent status**
- New Agents page: online, offline, not reporting, uptime, boot time, agent
  version and address for every server.
- Agent 1.1.0 reports boot time. Compatible both ways with older versions.
- "Hosts" is now "Servers". The Servers list has an Agent column, and each
  server page shows uptime.
- Schema `003-agent-status.sql`.

To apply on an existing PATCH-01:

```bash
./scripts/phase3a-schema.sh      # adds schema 003
./scripts/phase3b-api.sh         # API with boot time and the agents endpoint
./scripts/phase5-dashboard.sh    # Agents page
```

then update agents as above.


## Back these up, off both servers

These cannot be recreated. Losing them loses the data they protect.

| File | Why |
|------|-----|
| `/patch/secrets/postgres.env` | Database passwords. Pulp's 600 GB of packages are unnamed files without the database that maps them. |
| `/patch/config/pulp/certs/database_fields.symmetric.key` | Encrypts sensitive database fields. Without it they are unreadable. |
| `/patch/secrets/pulp-admin.txt` | Pulp admin password. |
| `/patch/secrets/api.env` | Console admin password and the AI-01 key. |
| `/etc/patch-platform/images.env` | Exact image digests this build was made from. |
| `/llm/config/api-key` on AI-01 | The key PATCH-01 uses. |
| `/patch/secrets/vcenter/` | vCenter accounts and pinned certificates. |


## Lessons already built into the scripts

Problems met during the first build, each now detected or prevented by the
script that caused it:

- A config value containing a space broke when the file was sourced. All
  generated values are quoted and the file is test-sourced before use.
- Containers running as non-root users could not read certificates, init
  scripts or keys in `0700` directories. Scripts now set the group to match
  each image's own user and prove access from inside a throwaway container
  before starting the real one.
- `lvcreate` waited forever on a hidden prompt. Commands now run with no
  input, so anything that prompts fails at once with a visible error.
- Pulp would not start without a database encryption key. It is generated,
  validated and mounted before migrations run.
- A build under a hardened `umask 077` left llama-server runnable by root
  only. The AI-01 script fixes permissions and runs the binary as the
  service user before starting the service.
- Pulp rejects keeping old package versions with a "mirror" sync. Syncs are
  additive, which also preserves the ability to downgrade.


## Not built yet

- **Reports** with your logo, exported to PDF.
- **Users, roles and approvals**, then the change engine that patch jobs,
  VMware actions and hardening fixes all share.
- **Hardening dashboard** using OpenSCAP with CIS-aligned profiles.
- **Windows Server**: WSUS reporting, CVE assessment by build number, then a
  PowerShell agent and hardening.
- **Patch jobs.** The schema, the agent's commands and the approval rules exist,
  but there is no scheduler yet and no way to create a job from the console.
  Nothing on the platform can change a managed server today.
- **Oracle Linux and Ubuntu advisories.** Verdicts currently come from Red Hat
  advisories synced into Pulp. Oracle's public repositories often omit errata
  data, so Oracle servers need the Oracle OVAL feed; Ubuntu needs the USN feed.
  Until then those servers show no advisories, and the engine's log says so.
- **RHEL 8 modular packages** are skipped and counted rather than compared, to
  avoid false results across module streams.
- **CA-signed certificates and agent mTLS.** PATCH-01 and AI-01 still use
  self-signed placeholders. Replace PATCH-01's before enrolling the full fleet,
  since agents trust the certificate present when they enroll.
- **Console sign-in** is a single admin password. Single sign-on would replace it.
- **VMware part 2: a VM snapshot before patching**, removed once the job
  succeeds. Needs patch jobs, and two extra vCenter permissions:
  Virtual machine > Snapshot management > Create snapshot and Remove snapshot.
- **Trend Micro.** Apex One protects Windows and macOS, so it adds little to a
  Linux platform. Worth integrating only if the Linux servers appear in Apex
  Central, or if Trend's server product (Server & Workload Protection) is in use.
- **Read-only MCP query layer.** (Step 12.)
