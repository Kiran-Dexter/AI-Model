-- ---------------------------------------------------------------------------
-- 076 (r146) Vulnerabilities > File shares: who owns each share and folder, and who can reach it
--
-- file_share_servers     the file servers being audited (chosen on the page)
-- file_share_scans       one read of a server's shares by its scanner (access-scan.ps1 2.x)
-- file_share_shares      each share of a scan: its path and its share permissions
-- file_share_folders     the folders a scan lists: the share root and every folder down to the listing
--                        depth, and deeper ones with permissions of their own; the folders under one that
--                        only inherit are counted on it ("below")
-- file_share_principals  every account and group a scan met in a permission, as Active Directory or the
--                        server names it; an orphaned SID has no name
-- file_share_members     the people in each group (nested groups included) as Active Directory says
-- file_share_imports     an ownership workbook uploaded (each sheet one server), and how its columns are read
-- file_share_rows        the ownership register: each row of the workbook, or one added on the page, with
--                        what it was matched to and the decision on it
-- Nothing here is ever written back to a server. Re-run safe.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS file_share_servers (
    host_id   UUID PRIMARY KEY REFERENCES hosts(id) ON DELETE CASCADE,
    added_by  TEXT NOT NULL,
    added_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS file_share_scans (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    host_id          UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    state            TEXT NOT NULL DEFAULT 'queued' CHECK (state IN ('queued', 'running', 'done', 'failed', 'cancelled')),
    requested_by     TEXT NOT NULL,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    picked_at        TIMESTAMPTZ,                  -- the agent started the scanner process
    started_at       TIMESTAMPTZ,                  -- the scanner's first report
    last_part_at     TIMESTAMPTZ,
    finished_at      TIMESTAMPTZ,
    scanner_version  TEXT,
    parts            INT NOT NULL DEFAULT 0,
    seqs             INT[] NOT NULL DEFAULT '{}',   -- the parts taken, so a part sent again is taken once
    totals           JSONB NOT NULL DEFAULT '{}'::jsonb,
    error            TEXT
);
CREATE INDEX IF NOT EXISTS idx_fs_scans_host ON file_share_scans (host_id, created_at DESC);

CREATE TABLE IF NOT EXISTS file_share_shares (
    scan_id      UUID NOT NULL REFERENCES file_share_scans(id) ON DELETE CASCADE,
    name         TEXT NOT NULL,
    path         TEXT NOT NULL,
    description  TEXT,
    acl          JSONB NOT NULL DEFAULT '[]'::jsonb,
    error        TEXT,
    PRIMARY KEY (scan_id, name)
);

CREATE TABLE IF NOT EXISTS file_share_folders (
    scan_id     UUID NOT NULL REFERENCES file_share_scans(id) ON DELETE CASCADE,
    path_key    TEXT NOT NULL,                  -- lower case, for matching
    path        TEXT NOT NULL,
    share       TEXT NOT NULL,
    depth       INT NOT NULL CHECK (depth >= 0),
    why         TEXT NOT NULL CHECK (why IN ('level', 'own', 'protected', 'asked')),
    protected   BOOLEAN NOT NULL DEFAULT false, -- inheritance turned off here
    explicit    BOOLEAN NOT NULL DEFAULT false, -- has permissions of its own
    owner_sid   TEXT,
    acl         JSONB NOT NULL DEFAULT '[]'::jsonb,
    below       INT NOT NULL DEFAULT 0 CHECK (below >= 0),
    error       TEXT,
    partial     BOOLEAN NOT NULL DEFAULT false, -- read, but only its first 1,000 entries are kept
    risks       TEXT[] NOT NULL DEFAULT '{}',   -- worked out on PATCH-01 when the scan is done
    PRIMARY KEY (scan_id, path_key)
);
CREATE INDEX IF NOT EXISTS idx_fs_folders_share ON file_share_folders (scan_id, share, depth);

CREATE TABLE IF NOT EXISTS file_share_principals (
    scan_id     UUID NOT NULL REFERENCES file_share_scans(id) ON DELETE CASCADE,
    sid         TEXT NOT NULL,
    name        TEXT,                           -- DOMAIN\name; NULL: an orphaned SID
    kind        TEXT NOT NULL CHECK (kind IN ('user', 'group', 'local_group', 'well_known', 'computer', 'unknown')),
    display     TEXT,
    email       TEXT,
    department  TEXT,
    enabled     BOOLEAN,
    members     TEXT CHECK (members IN ('read', 'all_domain_users', 'not_read', 'too_many')),
    lookup_failed BOOLEAN NOT NULL DEFAULT false,  -- the name could not be looked up then: not an orphan
    PRIMARY KEY (scan_id, sid)
);

CREATE TABLE IF NOT EXISTS file_share_members (
    scan_id    UUID NOT NULL REFERENCES file_share_scans(id) ON DELETE CASCADE,
    group_sid  TEXT NOT NULL,
    user_sid   TEXT NOT NULL,
    PRIMARY KEY (scan_id, group_sid, user_sid)
);
CREATE INDEX IF NOT EXISTS idx_fs_members_user ON file_share_members (scan_id, user_sid);

CREATE TABLE IF NOT EXISTS file_share_imports (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_name    TEXT NOT NULL,
    uploaded_by  TEXT NOT NULL,
    uploaded_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    state        TEXT NOT NULL DEFAULT 'preview' CHECK (state IN ('preview', 'applied', 'discarded')),
    sheets       JSONB NOT NULL,                -- each sheet: its rows, header, columns as read, server
    applied_by   TEXT,
    applied_at   TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS file_share_rows (
    id           BIGSERIAL PRIMARY KEY,
    import_id    UUID REFERENCES file_share_imports(id) ON DELETE SET NULL,   -- NULL: added on the page
    sheet        TEXT NOT NULL,
    row_no       INT,
    host_id      UUID REFERENCES hosts(id) ON DELETE CASCADE,
    path_text    TEXT NOT NULL DEFAULT '',      -- as the workbook writes it
    share_text   TEXT NOT NULL DEFAULT '',
    folder_text  TEXT NOT NULL DEFAULT '',
    department   TEXT NOT NULL DEFAULT '',
    owner        TEXT NOT NULL DEFAULT '',
    email        TEXT NOT NULL DEFAULT '',
    details      JSONB NOT NULL DEFAULT '{}'::jsonb,
    set_key      TEXT,                          -- a folder chosen on the page (Edit, or added for a folder)
    outcome      TEXT NOT NULL DEFAULT 'orphan' CHECK (outcome IN ('mapped', 'doubt', 'orphan', 'no_server', 'empty')),
    how          TEXT NOT NULL DEFAULT '',
    folder_key   TEXT,                          -- the folder it is matched to (path_key), NULL for an orphan
    candidates   JSONB NOT NULL DEFAULT '[]'::jsonb,
    decision     TEXT CHECK (decision IN ('approved', 'rejected')),
    decided_key  TEXT,                          -- the folder the decision was made on
    decided_by   TEXT,
    decided_at   TIMESTAMPTZ,
    edited       BOOLEAN NOT NULL DEFAULT false, -- department, owner or e-mail changed on the page
    sig          TEXT,                          -- the row as the workbook wrote it: a new workbook's same row keeps the decision
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_fs_rows_host ON file_share_rows (host_id, folder_key);

INSERT INTO schema_version (version, description)
VALUES (76, 'File shares: owners, share and NTFS permissions, effective access')
ON CONFLICT (version) DO NOTHING;
