-- ---------------------------------------------------------------------------
-- 075 (r145) Vulnerabilities > Detected CVEs, "All on our servers"
--
-- Every CVE still to install on our servers, of any age, is now analysed like the feeds' ones. The analysis
-- looks each one up by its CVE id in the feed items (whose key starts with the source) and in the Windows
-- updates each server reports missing (an array of CVE ids): neither lookup had an index.
-- Re-run safe.
-- ---------------------------------------------------------------------------

CREATE INDEX IF NOT EXISTS idx_cve_feed_items_cve ON cve_feed_items (cve_id);
CREATE INDEX IF NOT EXISTS idx_windows_updates_cves ON windows_updates USING gin (cves);

INSERT INTO schema_version (version, description)
VALUES (75, 'Detected CVEs, All on our servers: feed items and Windows updates by CVE')
ON CONFLICT (version) DO NOTHING;
