"""File shares (r146): the report, as PDF and Excel, with the logo, classification and colour of Admin > Branding.

PDF (A4, portrait): a title band; At a glance (the figures); the summary in words; three rings (ownership, the
workbook's rows, owned folders by department) and the risks as bars (a folder can have several, so they are not a
ring); then what needs attention (no owner, to confirm, not found), the risks folder by folder, the owners, and who
can reach each share and each folder with permissions of its own (effective: the stricter of share and NTFS);
how it was worked out last. Excel: the same, one sheet each, filters on, with the rings drawn as Excel charts.

Every value from a scan or a workbook is drawn as plain text: never markup, never a formula."""

import io
import re
from xml.sax.saxutils import escape

from . import exports as ex
from . import file_share_store as st
from . import file_shares as fs

TITLE = "File share access and ownership"
OK, BAD, WARN, MOD, MUTED = "#12805C", "#C81E1E", "#B45309", "#2a78d6", "#64708F"
CATS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#4a3aa7"]
INK, INK2, RULE, BAND = "#16202A", "#4A5963", "#C9D1D6", "#EEF2F5"
PDF_ACCESS_MAX = 250        # folders in the PDF's access section; the Excel file has every one
PDF_ROWS_MAX = 500          # rows of each other PDF table; the Excel file has every one
CELL_MAX = 600              # characters of a PDF cell (a page cannot hold a longer one in a narrow column)
STATE_WORD = {"owner": "Matched", "doubt": "To confirm", "orphan": "Not found", "rejected": "Rejected", "empty": "Empty row"}
WRITE_LEVELS = ("Full control", "Modify", "Write", "Some write")
BAD_XML = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]")


def _t(v):
    return BAD_XML.sub(" ", "" if v is None else str(v))


def data(conn, vs):
    s = st.summary(vs)
    rows = []
    for k in ("missing", "doubt", "orphan", "matched", "rejected"):
        rows.append((k, st.review(vs, k)))
    review = dict(rows)
    owners, risks = [], []
    for v in vs:
        for k, state in sorted(v["own_state"].items()):
            if state not in ("owned", "missing"):
                continue
            f = v["by_key"][k]
            o = st.folder_owner(v, k) or {}
            owners.append({"server": v["host"]["hostname"], "share": f["share"], "path": f["path"], "state": state,
                           "department": o.get("department") or "", "owner": o.get("owner") or "", "email": o.get("email") or "",
                           "from": "" if not o else ("the folder above" if o.get("inherited") else "this folder")})
        for f in v["folders"]:
            for r in f.get("risks") or []:
                o = st.folder_owner(v, f["path_key"]) or {}
                risks.append({"server": v["host"]["hostname"], "path": f["path"], "risk": r, "label": fs.RISK_LABEL[r],
                              "owner": o.get("owner") or "", "department": o.get("department") or "", "error": f.get("error") or ""})
    access = []
    for v in vs:
        for a in st.access(conn, v):
            a["server"] = v["host"]["hostname"]
            access.append(a)
    servers = ", ".join(p["host"]["hostname"] for p in s["servers"]) or "none"
    return {"summary": s, "review": review, "owners": owners, "risks": risks, "access": access, "servers": servers}


def rings(s):
    t = s["total"]
    deps = s["departments"]
    dep = [(d, n) for d, n in deps[:5]]
    if len(deps) > 5:
        dep.append(("Other departments", sum(n for _, n in deps[5:])))
    return [
        ("Ownership", "need an owner",
         [("Owner known", t.get("owned", 0), OK), ("No owner", t.get("missing", 0), BAD)]),
        ("The ownership workbook", "rows",
         [("Matched", t.get("matched", 0), OK), ("To confirm", t.get("doubt", 0), WARN), ("Not found", t.get("orphan", 0), BAD),
          ("Rejected", t.get("rejected", 0), MUTED)]),
        ("Owned folders by department", "owned folders",
         [(d, n, (CATS + [MUTED])[i] if d != "Other departments" else MUTED) for i, (d, n) in enumerate(dep)]),
    ]


def render(conn, fmt, user, vs):
    d = data(conn, vs)
    logo, cls, accent = ex.brand_bits(conn)
    company = ex.company_name(conn)
    m = ex.meta(TITLE, user, "Servers: " + d["servers"], len(d["owners"]), company)
    if fmt == "xlsx":
        return xlsx(m, d, logo, accent), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx"
    return pdf(m, d, logo, cls, accent), "application/pdf", "pdf"


# ---------------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------------

def pdf(m, d, logo_png, classification, accent):
    from reportlab.graphics.shapes import Circle, Drawing, Rect, String, Wedge
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import (CondPageBreak, Image, KeepTogether, LongTable, Paragraph, SimpleDocTemplate,
                                    Spacer, Table, TableStyle)

    W, H = A4
    margin = 15 * mm
    usable = W - 2 * margin
    try:
        acc = colors.HexColor(accent)
    except ValueError:
        acc = colors.HexColor("#0B1F3A")
    C = colors.HexColor
    base = ParagraphStyle("b", fontName="Helvetica", fontSize=9, leading=12.5, textColor=C(INK))
    small = ParagraphStyle("s", parent=base, fontSize=7.6, leading=9.6, textColor=C(INK2))
    cell = ParagraphStyle("c", parent=base, fontSize=7.4, leading=9.2)
    head = ParagraphStyle("h", parent=cell, fontName="Helvetica-Bold", textColor=colors.white)
    h1 = ParagraphStyle("h1", parent=base, fontName="Helvetica-Bold", fontSize=20, leading=24, textColor=acc)
    h2 = ParagraphStyle("h2", parent=base, fontName="Helvetica-Bold", fontSize=13, leading=16, textColor=acc, spaceBefore=6, spaceAfter=4)
    h3 = ParagraphStyle("h3", parent=base, fontName="Helvetica-Bold", fontSize=10, leading=13, spaceBefore=4, spaceAfter=2)
    big = ParagraphStyle("big", parent=base, fontName="Helvetica-Bold", fontSize=17, leading=20, textColor=acc)

    def p(text, style=base):
        return Paragraph(escape(_t(text))[:3000], style)

    s = d["summary"]
    t = s["total"]
    story = []
    if logo_png and ex._png_size(logo_png):
        w, h = ex._png_size(logo_png)
        lh = 15 * mm
        lw = min(60 * mm, w * lh / max(1, h))
        story += [Image(io.BytesIO(logo_png), width=lw, height=h * lw / max(1, w), hAlign="LEFT"), Spacer(1, 4 * mm)]
    story += [p(TITLE, h1), Spacer(1, 1.5 * mm),
              p(" · ".join(x for x in (m.get("company"), "Servers: " + d["servers"], "Generated " + m["generated"],
                                       "by " + m["by"]) if x), small), Spacer(1, 5 * mm)]

    # At a glance
    tiles = [("Shares", t.get("shares", 0)), ("Folders read", t.get("walked", 0)),
             ("Owner known", f"{s['owned_pct']}%" if s["owned_pct"] is not None else "–"), ("No owner", t.get("missing", 0)),
             ("To confirm", t.get("doubt", 0)), ("Folders with a risk", t.get("with_risk", 0))]
    tw = usable / len(tiles)
    def fig(k, v):
        col = BAD if k in ("No owner", "Folders with a risk") and v else WARN if k == "To confirm" and v else None
        return p(f"{v:,}" if isinstance(v, int) else v, ParagraphStyle("bg", parent=big, textColor=C(col)) if col else big)
    tt = Table([[fig(k, v) for k, v in tiles], [p(k, small) for k, _ in tiles]], colWidths=[tw] * len(tiles))
    tt.setStyle(TableStyle([("BOX", (i, 0), (i, 1), 0.6, C(RULE)) for i in range(len(tiles))]
                           + [("BACKGROUND", (0, 0), (-1, -1), C("#FAFBFC")), ("LEFTPADDING", (0, 0), (-1, -1), 6),
                              ("TOPPADDING", (0, 0), (-1, 0), 6), ("BOTTOMPADDING", (0, 1), (-1, 1), 6),
                              ("LINEABOVE", (0, 0), (-1, 0), 2.2, acc)]))
    story += [p("At a glance", h2), tt, Spacer(1, 4 * mm), p("Summary", h2)]
    para = ParagraphStyle("para", parent=base, spaceAfter=3.5)
    story += [p(w, para) for w in s["words"]]

    # the rings
    def ring(title, unit, segs):
        size, R, Wd = 34 * mm, 15 * mm, 5.2 * mm
        dr = Drawing(size, size)
        cx = cy = size / 2
        total = sum(n for _, n, _ in segs)
        dr.add(Circle(cx, cy, R, fillColor=None, strokeColor=C("#E3E8EC"), strokeWidth=Wd))
        start = 90
        for _, n, col in segs:
            if not n or not total:
                continue
            sweep = 360 * n / total
            if sweep >= 359.99:
                dr.add(Circle(cx, cy, R, fillColor=None, strokeColor=C(col), strokeWidth=Wd))
            else:
                dr.add(Wedge(cx, cy, R + Wd / 2, start - sweep, start, radius1=R - Wd / 2, fillColor=C(col),
                             strokeColor=colors.white, strokeWidth=0.8))
            start -= sweep
        dr.add(String(cx, cy - 2, f"{total:,}", textAnchor="middle", fontName="Helvetica-Bold", fontSize=13, fillColor=C(INK)))
        dr.add(String(cx, cy - 10, unit[:22], textAnchor="middle", fontName="Helvetica", fontSize=5.6, fillColor=C(INK2)))
        leg = []
        if not segs or not total:
            return [p(title, h3), dr, p("None yet.", small)]
        for label, n, col in segs:
            sw = Drawing(7, 7)
            sw.add(Rect(0, 0.5, 6.5, 6.5, fillColor=C(col), strokeColor=None))
            pct = f"{round(100 * n / total)}%" if total else ""
            leg.append([sw, p(_t(label)[:60], cell), p(f"{n:,}", cell), p(pct, small)])
        lt = Table(leg, colWidths=[3.5 * mm, 26 * mm, 10 * mm, 8 * mm])
        lt.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 1),
                                ("RIGHTPADDING", (0, 0), (-1, -1), 1), ("TOPPADDING", (0, 0), (-1, -1), 0.5),
                                ("BOTTOMPADDING", (0, 0), (-1, -1), 0.5)]))
        return [p(title, h3), dr, lt]

    rs = [ring(*r) for r in rings(s)]
    rt = Table([[x[0] for x in rs], [x[1] for x in rs], [x[2] for x in rs]], colWidths=[usable / 3] * 3)
    rt.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("ALIGN", (0, 1), (-1, 1), "CENTER"),
                            ("LEFTPADDING", (0, 0), (-1, -1), 2)]))
    story += [Spacer(1, 3 * mm), KeepTogether([p("The picture", h2), rt])]

    # risks as bars
    rk = [r for r in s["risks"] if r["n"]]
    if rk:
        top = max(r["n"] for r in rk)
        bars = []
        for r in rk:
            bw = 70 * mm
            dr = Drawing(bw, 6)
            dr.add(Rect(0, 0, bw, 6, fillColor=C("#EEF1F4"), strokeColor=None))
            dr.add(Rect(0, 0, max(1.5, bw * r["n"] / top), 6, fillColor=C(BAD if r["key"] in ("wide_write", "control") else WARN),
                        strokeColor=None))
            bars.append([p(r["label"], cell), dr, p(f"{r['n']:,}", cell), p(r["why"], small)])
        bt = Table(bars, colWidths=[46 * mm, 72 * mm, 12 * mm, usable - 130 * mm])
        bt.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LINEBELOW", (0, 0), (-1, -1), 0.25, C(RULE))]))
        story += [KeepTogether([p("Risks: folders with each", h2), bt])]

    def table(headers, rows, widths, shade=None):
        more = len(rows) - PDF_ROWS_MAX
        rows = rows[:PDF_ROWS_MAX]
        data = [[p(x, head) for x in headers]] + [[p(_t(c)[:CELL_MAX], cell) for c in r] for r in rows]
        tb = LongTable(data, colWidths=widths, repeatRows=1)
        style = [("BACKGROUND", (0, 0), (-1, 0), acc), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                 ("LINEBELOW", (0, 0), (-1, -1), 0.25, C(RULE)), ("LEFTPADDING", (0, 0), (-1, -1), 3),
                 ("RIGHTPADDING", (0, 0), (-1, -1), 3), ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]
        for i in range(1, len(data)):
            if i % 2 == 0:
                style.append(("BACKGROUND", (0, i), (-1, i), C("#F6F8FA")))
            if shade and shade(rows[i - 1]):
                style.append(("BACKGROUND", (0, i), (-1, i), C(shade(rows[i - 1]))))
        tb.setStyle(TableStyle(style))
        if more > 0:
            return KeepTogether([tb, p(f"{more:,} more rows are in the Excel report.", small)])
        return tb

    rv = d["review"]
    story += [CondPageBreak(90 * mm), p("Needs your attention", h2)]
    story += [p(f"No owner ({len(rv['missing']):,})", h3)]
    story += [table(["Server", "Folder", "Folders below", "Risks"],
                    [[x["server"], x["folder"], f"{x['below']:,}", ", ".join(fs.RISK_LABEL[k] for k in x["risks"])] for x in rv["missing"]],
                    [22 * mm, 88 * mm, 22 * mm, usable - 132 * mm]) if rv["missing"] else p("Every share and folder that needs an owner has one.", small)]
    story += [Spacer(1, 3 * mm), p(f"To confirm ({len(rv['doubt']):,})", h3)]
    story += [table(["Sheet, row", "Workbook says", "Owner", "Matched to", "Why it waits"],
                    [[f"{x['sheet']} {x['row_no'] or ''}".strip(), x["path_text"] or (x["share_text"] + " " + x["folder_text"]).strip(),
                      " · ".join(y for y in (x["owner"], x["department"]) if y), x["folder"] or "(choose one)", x["how"]] for x in rv["doubt"]],
                    [22 * mm, 46 * mm, 32 * mm, 46 * mm, usable - 146 * mm]) if rv["doubt"] else p("Nothing waits to be confirmed.", small)]
    story += [Spacer(1, 3 * mm), p(f"Not found on the server ({len(rv['orphan']):,})", h3)]
    story += [table(["Sheet, row", "Workbook says", "Owner", "Why"],
                    [[f"{x['sheet']} {x['row_no'] or ''}".strip(), x["path_text"] or (x["share_text"] + " " + x["folder_text"]).strip(),
                      " · ".join(y for y in (x["owner"], x["department"]) if y), x["how"]] for x in rv["orphan"]],
                    [22 * mm, 56 * mm, 36 * mm, usable - 114 * mm]) if rv["orphan"] else p("Every workbook row names a folder that is on the server.", small)]

    if d["risks"]:
        story += [CondPageBreak(60 * mm), p("Risks, folder by folder", h2)]
        story += [table(["Risk", "Server", "Folder", "Owner"],
                        [[r["label"], r["server"], r["path"], " · ".join(y for y in (r["owner"], r["department"]) if y)]
                         for r in sorted(d["risks"], key=lambda r: ([k for k, _, _ in fs.RISKS].index(r["risk"]), r["server"], r["path"]))],
                        [44 * mm, 22 * mm, 78 * mm, usable - 144 * mm])]

    story += [CondPageBreak(70 * mm), p("Owners", h2),
              p("Each share, and each folder down to the deepest one the workbook tags, with its department and owner. "
                "A folder without its own row takes the owner of the folder above.", small), Spacer(1, 2 * mm)]
    story += [table(["Server", "Folder", "Department", "Owner", "E-mail", "Given on"],
                    [[o["server"], o["path"], o["department"], o["owner"], o["email"], o["from"] or "no owner"] for o in d["owners"]],
                    [18 * mm, 66 * mm, 26 * mm, 28 * mm, 26 * mm, usable - 164 * mm],
                    shade=lambda r: "#FBEAEA" if r[5] == "no owner" else None) if d["owners"] else p("No folder needs an owner yet.", small)]

    story += [CondPageBreak(80 * mm), p("Who can reach each share", h2),
              p("Each share and each folder with permissions of its own. Effective is what a person gets over the network: the "
                "stricter of the share permission and the NTFS permission. Shaded: can change files; darker: full control. "
                "Administrators and the system are left out. Folders that only inherit get the same as the folder above.", small)]
    shown = d["access"][:PDF_ACCESS_MAX]
    for a in shown:
        o = a["owner"] or {}
        rows = [[w["name"] + (" (person)" if w["kind"] == "user" else ""), w["share"], w["ntfs"], w["effective"]]
                for w in a["who"] if not w["admin"]]
        if not rows:
            continue
        block = [p(f"{a['server']}  ·  {a['path']}", h3),
                 p(" · ".join(x for x in ("Share " + a["share"], ("Owner: " + o["owner"]) if o.get("owner") else "",
                                          o.get("department") or "", "inheritance turned off" if a["protected"] else "") if x), small),
                 table(["Account or group", "Share", "NTFS", "Effective"], rows, [70 * mm, 34 * mm, 34 * mm, usable - 138 * mm],
                       shade=lambda r: ("#F9DCDC" if r[3] == "Full control" else "#FBEAEA") if r[3] in WRITE_LEVELS else None)]
        story += ([KeepTogether(block)] if len(rows) < 12 else block) + [Spacer(1, 1 * mm)]
    if len(d["access"]) > PDF_ACCESS_MAX:
        story += [p(f"{len(d['access']) - PDF_ACCESS_MAX:,} more folders with permissions of their own are in the Excel report.", small)]

    story += [CondPageBreak(70 * mm), p("How this was worked out", h2)]
    for line in METHOD:
        story.append(p("• " + line, small))

    def deco(canvas, doc):
        canvas.saveState()
        canvas.setFillColor(acc)
        canvas.rect(0, H - 6 * mm, W, 6 * mm, stroke=0, fill=1)
        canvas.setFillColor(colors.white)
        canvas.setFont("Helvetica-Bold", 7.5)
        canvas.drawString(margin, H - 4.1 * mm, (TITLE + ("  ·  " + m["company"] if m.get("company") else ""))[:120])
        canvas.drawRightString(W - margin, H - 4.1 * mm, classification[:40])
        canvas.setFillColor(C(INK2))
        canvas.setFont("Helvetica", 7)
        canvas.drawString(margin, 8 * mm, f"{ex.PORTAL} · generated {m['generated']} by {m['by']}"[:150])
        canvas.drawRightString(W - margin, 8 * mm, f"Page {doc.page}")
        canvas.setStrokeColor(acc)
        canvas.setLineWidth(0.6)
        canvas.line(margin, 11 * mm, W - margin, 11 * mm)
        canvas.restoreState()

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=margin, rightMargin=margin, topMargin=13 * mm, bottomMargin=16 * mm,
                            title=TITLE, author=ex.PORTAL)
    doc.build(story, onFirstPage=deco, onLaterPages=deco)
    return buf.getvalue()


METHOD = [
    "The scanner on each file server (access-scan.ps1, read-only) lists its shares, leaving out the administrative ones and "
    "those on the system drive, and reads the share permissions and every folder's NTFS permissions, all levels down.",
    "Folders down to three levels below each share are listed, and deeper ones that have permissions of their own; the folders "
    "that only inherit are counted on the folder above them.",
    "Group members come from Active Directory, nested groups included; Domain Users counts every domain account.",
    "Effective access over the network is the stricter of the share and NTFS permissions, entry by entry the way Windows reads "
    "them (an explicit deny before an inherited allow). Administrators and the system are left out of the access tables.",
    "The ownership workbook is matched to the folders by fixed rules: the same folder however its path is written (local path, "
    "\\\\server\\share, share and folder columns) is matched; a folder found by its name alone or written slightly differently "
    "waits to be confirmed; anything else is not found. Nothing is guessed.",
    "A folder needs an owner when it is a share, or no deeper than the deepest folder the workbook tags in its share, and "
    "neither it, a folder above it, nor a folder below it has one.",
    "Nothing is ever changed on the servers.",
]


# ---------------------------------------------------------------------------
# Excel
# ---------------------------------------------------------------------------

def xlsx(m, d, logo_png, accent):
    import openpyxl
    from openpyxl.chart import DoughnutChart, Reference
    from openpyxl.chart.label import DataLabelList
    from openpyxl.chart.series import DataPoint
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    acc = (accent or "#0B1F3A").lstrip("#")
    if not re.fullmatch(r"[0-9A-Fa-f]{6}", acc):
        acc = "0B1F3A"
    wb = openpyxl.Workbook()
    head_font, head_fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor=acc)
    thin = Border(bottom=Side(style="thin", color="C9D1D6"))
    fills = {"Matched": "E5F3EC", "Owner known": "E5F3EC", "To confirm": "FDF1E2", "Not found": "FBEAEA", "No owner": "FBEAEA",
             "Rejected": "ECEEF2"}

    def cell(v):
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            return v
        return ex.safe_cell(v)

    def sheet(ws, headers, rows, widths, state_col=None, note=None):
        r0 = 1
        if note:
            ws.cell(1, 1, ex.safe_cell(note)).font = Font(italic=True, color="4A5963")
            r0 = 3
        for i, hd in enumerate(headers, 1):
            c = ws.cell(r0, i, hd)
            c.font, c.fill = head_font, head_fill
            c.alignment = Alignment(vertical="center", wrap_text=True)
        for j, row in enumerate(rows, r0 + 1):
            for i, v in enumerate(row, 1):
                c = ws.cell(j, i, cell(v))
                c.border = thin
                c.alignment = Alignment(vertical="top", wrap_text=i in (2, 3) and isinstance(v, str) and len(v) > 40)
            if state_col is not None and row[state_col] in fills:
                ws.cell(j, state_col + 1).fill = PatternFill("solid", fgColor=fills[row[state_col]])
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w
        ws.freeze_panes = ws.cell(r0 + 1, 1)
        if rows:
            ws.auto_filter.ref = f"A{r0}:{get_column_letter(len(headers))}{r0 + len(rows)}"

    s = d["summary"]
    t = s["total"]
    ws = wb.active
    ws.title = "Summary"
    top = 1
    if logo_png and ex._png_size(logo_png):
        from openpyxl.drawing.image import Image as XImage
        img = XImage(io.BytesIO(logo_png))
        w, h = ex._png_size(logo_png)
        img.height = 48
        img.width = int(w * 48 / max(1, h))
        ws.add_image(img, "A1")
        top = 4
    ws.cell(top, 1, TITLE).font = Font(bold=True, size=16, color=acc)
    ws.cell(top + 1, 1, ex.safe_cell(" · ".join(x for x in (m.get("company"), "Servers: " + d["servers"], "Generated " + m["generated"],
                                                             "by " + m["by"]) if x))).font = Font(color="4A5963")
    r = top + 3
    ws.cell(r, 1, "At a glance").font = Font(bold=True, size=12, color=acc)
    figs = [("Shares", t.get("shares", 0)), ("Folders read", t.get("walked", 0)),
            ("Folders with permissions of their own", t.get("own_perms", 0)),
            ("Shares and folders that need an owner", t.get("owned", 0) + t.get("missing", 0)),
            ("…of which have one", t.get("owned", 0)), ("…of which have none", t.get("missing", 0)),
            ("Workbook rows matched", t.get("matched", 0)), ("Workbook rows to confirm", t.get("doubt", 0)),
            ("Workbook rows not found", t.get("orphan", 0)), ("Folders with a risk", t.get("with_risk", 0)),
            ("Folders the scanner could not read", t.get("unreadable", 0))]
    for i, (k, v) in enumerate(figs, r + 1):
        ws.cell(i, 1, k)
        ws.cell(i, 2, v).font = Font(bold=True)
    r = r + len(figs) + 2
    ws.cell(r, 1, "Summary").font = Font(bold=True, size=12, color=acc)
    for i, w in enumerate(s["words"], r + 1):
        c = ws.cell(i, 1, ex.safe_cell(w))
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=i, start_column=1, end_row=i, end_column=6)
        ws.row_dimensions[i].height = 30
    r = r + len(s["words"]) + 2
    ws.column_dimensions["A"].width = 40
    ws.column_dimensions["B"].width = 12
    # the rings: their figures in columns H:I, each drawn as a doughnut chart
    cr = top
    for n, (title, _unit, segs) in enumerate(rings(s)):
        ws.cell(cr, 8, title).font = Font(bold=True)
        if not segs:                              # nothing to draw (no department yet): the title and a word, no chart
            ws.cell(cr + 1, 8, "None yet")
            cr += 3
            continue
        for i, (label, v, _col) in enumerate(segs, 1):
            ws.cell(cr + i, 8, ex.safe_cell(label))
            ws.cell(cr + i, 9, v)
        ch = DoughnutChart(holeSize=55)
        ch.title = title
        ch.add_data(Reference(ws, min_col=9, min_row=cr + 1, max_row=cr + len(segs)), titles_from_data=False)
        ch.set_categories(Reference(ws, min_col=8, min_row=cr + 1, max_row=cr + len(segs)))
        ser = ch.series[0]
        for i, (_l, _v, col) in enumerate(segs):
            pt = DataPoint(idx=i)
            pt.graphicalProperties.solidFill = col.lstrip("#")
            ser.dPt.append(pt)
        ch.dataLabels = DataLabelList()
        ch.dataLabels.showVal = True
        ch.height, ch.width = 7, 9
        ws.add_chart(ch, f"K{1 + n * 15}")
        cr += len(segs) + 2
    ws.column_dimensions["H"].width = 26
    rr = cr + 1
    ws.cell(rr, 8, "Risks (folders with each)").font = Font(bold=True)
    for i, x in enumerate(s["risks"], rr + 1):
        ws.cell(i, 8, x["label"])
        ws.cell(i, 9, x["n"])

    rv = d["review"]
    sheet(wb.create_sheet("Needs attention"), ["What", "Server", "Folder or row", "Owner", "Department", "Matched to", "Why"],
          [["No owner", x["server"], x["folder"], "", "", "", f"{x['below']:,} folders below; " + ", ".join(fs.RISK_LABEL[k] for k in x["risks"])]
           for x in rv["missing"]]
          + [["To confirm", x["server"], x["path_text"] or (x["share_text"] + " " + x["folder_text"]).strip(), x["owner"], x["department"],
              x["folder"] or "", x["how"]] for x in rv["doubt"]]
          + [["Not found", x["server"], x["path_text"] or (x["share_text"] + " " + x["folder_text"]).strip(), x["owner"], x["department"],
              "", x["how"]] for x in rv["orphan"]],
          [13, 14, 60, 22, 18, 50, 60], state_col=0)
    sheet(wb.create_sheet("Owners"), ["Server", "Share", "Folder", "State", "Department", "Owner", "E-mail", "Given on"],
          [[o["server"], o["share"], o["path"], "Owner known" if o["state"] == "owned" else "No owner", o["department"], o["owner"],
            o["email"], o["from"]] for o in d["owners"]], [14, 16, 60, 13, 20, 24, 28, 18], state_col=3)
    acc_rows = []
    for a in d["access"]:
        o = a["owner"] or {}
        for w in a["who"]:
            acc_rows.append([a["server"], a["share"], a["path"], w["name"], {"user": "person", "group": "group", "local_group": "local group",
                             "well_known": "built-in group"}.get(w["kind"], w["kind"]), w["share"], w["ntfs"], w["effective"],
                             w["write"], w["control"], w["admin"], "yes" if a["protected"] else "", o.get("owner") or "", o.get("department") or ""])
    sheet(wb.create_sheet("Access"), ["Server", "Share", "Folder", "Account or group", "Kind", "Share", "NTFS", "Effective", "Can change files",
                                      "Can change permissions", "Administrator", "Inheritance off", "Owner", "Department"],
          acc_rows, [14, 16, 56, 34, 13, 15, 15, 15, 10, 12, 11, 10, 22, 18],
          note="Effective: the stricter of the share permission and the NTFS permission (what a person gets over the network). "
               "Each share and each folder with permissions of its own; folders that only inherit get the same as the folder above.")
    sheet(wb.create_sheet("Risks"), ["Risk", "Server", "Folder", "Owner", "Department", "Detail"],
          [[r["label"], r["server"], r["path"], r["owner"], r["department"], r["error"]] for r in d["risks"]], [40, 14, 60, 22, 18, 40])
    allrows = []
    for k in ("matched", "doubt", "orphan", "rejected"):
        for x in rv[k]:
            allrows.append([x["sheet"], x["row_no"] or "", x["server"], x["path_text"], x["share_text"], x["folder_text"], x["department"],
                            x["owner"], x["email"], STATE_WORD.get(x["state"], x["state"]), x["folder"] or "", x["how"],
                            x["decided_by"] or "", "; ".join(f"{a}: {b}" for a, b in (x["details"] or {}).items())])
    allrows.sort(key=lambda r: (str(r[0]), r[1] if isinstance(r[1], int) else 10 ** 9))
    sheet(wb.create_sheet("Workbook rows"), ["Sheet", "Row", "Server", "Path", "Share", "Folder", "Department", "Owner", "E-mail", "Result",
                                             "Matched to", "How", "Decided by", "Other columns"],
          allrows, [14, 6, 12, 44, 14, 20, 18, 22, 26, 12, 44, 44, 14, 40], state_col=9)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
