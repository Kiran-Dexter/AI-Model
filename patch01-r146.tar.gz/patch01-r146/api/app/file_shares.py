"""Vulnerabilities > File shares (r146): who owns each share and folder of the audited file servers, and who can
reach it, worked out the way Windows does.

What the scanner on a file server (access-scan.ps1 2.x) sends is stored as it is: the shares and their share
permissions, the folders down to the listing depth and deeper ones with permissions of their own (with their
access control entries in the order Windows keeps them), and the accounts and groups those name, with the people
in each group from Active Directory. Nothing is ever written back to a server.

Effective access over the network is the stricter of the two layers, entry by entry the way Windows reads an
access control list: in order, the first entry to decide a right decides it, so an explicit deny beats an
inherited allow. The owner of a folder can always read and change its permissions unless an OWNER RIGHTS entry
says otherwise.

The ownership workbook is matched to the scanned folders by fixed rules only (no guessing): the same folder
however its path is written is a match; a folder found by its name alone, or a name written slightly differently,
is a doubt for a person to approve; anything else is an orphan. A folder needs an owner when it is a share root,
or above the deepest folder the workbook tags in its share, and neither it, a folder above it, nor a folder below
it has one."""

import difflib
import json
import re

# ---------------------------------------------------------------------------
# Rights
# ---------------------------------------------------------------------------

RIGHTS = [  # (key, label, mask): the rows of Windows' Advanced Security dialog, in its order
    ("full", "Full control", 0x1F01FF),
    ("traverse", "Traverse folder / execute file", 0x20),
    ("list", "List folder / read data", 0x1),
    ("read_attr", "Read attributes", 0x80),
    ("read_ext", "Read extended attributes", 0x8),
    ("create_files", "Create files / write data", 0x2),
    ("create_folders", "Create folders / append data", 0x4),
    ("write_attr", "Write attributes", 0x100),
    ("write_ext", "Write extended attributes", 0x10),
    ("delete_sub", "Delete subfolders and files", 0x40),
    ("delete", "Delete", 0x10000),
    ("read_perm", "Read permissions", 0x20000),
    ("change_perm", "Change permissions", 0x40000),
    ("take_own", "Take ownership", 0x80000),
]
FULL = 0x1F01FF
SYNCHRONIZE = 0x100000
WRITE_BITS = 0x2 | 0x4 | 0x10 | 0x40 | 0x100 | 0x10000      # change what is in the folder
CONTROL_BITS = 0x40000 | 0x80000                          # change who may: permissions, ownership
GENERIC = {0x80000000: 0x120089, 0x40000000: 0x120116, 0x20000000: 0x1200A0, 0x10000000: FULL}
SHARE_MASK = {"full": FULL, "change": 0x1301BF, "read": 0x1200A9}

# The simple levels Windows' Security tab shows, widest first
LEVELS = [("Full control", FULL), ("Modify", 0x1301BF), ("Read & execute", 0x1200A9), ("Read", 0x120089),
          ("Write", 0x100116)]

EVERYONE, AUTH_USERS, NETWORK, BUILTIN_USERS = "S-1-1-0", "S-1-5-11", "S-1-5-2", "S-1-5-32-545"
OWNER_RIGHTS, CREATOR_OWNER = "S-1-3-4", "S-1-3-0"
WIDE = {EVERYONE: "Everyone", AUTH_USERS: "Authenticated Users", BUILTIN_USERS: "BUILTIN\\Users", NETWORK: "NETWORK"}
WELL_KNOWN = dict(WIDE, **{"S-1-5-18": "NT AUTHORITY\\SYSTEM", "S-1-5-19": "NT AUTHORITY\\LOCAL SERVICE",
                           "S-1-5-20": "NT AUTHORITY\\NETWORK SERVICE", "S-1-5-4": "NT AUTHORITY\\INTERACTIVE",
                           "S-1-5-32-544": "BUILTIN\\Administrators", "S-1-5-32-549": "BUILTIN\\Server Operators",
                           "S-1-5-32-551": "BUILTIN\\Backup Operators", "S-1-5-32-547": "BUILTIN\\Power Users",
                           CREATOR_OWNER: "CREATOR OWNER", OWNER_RIGHTS: "OWNER RIGHTS"})


def kind_of_sid(sid):
    """What a SID is when the scan did not say: a group of the server (S-1-5-32-), a built-in one, or unknown."""
    if sid.startswith("S-1-5-32-"):
        return "local_group"
    if not sid.startswith("S-1-5-21-"):
        return "well_known"
    return "unknown"
ADMIN_SIDS = {"S-1-5-18", "S-1-5-32-544", "S-1-5-32-549", "S-1-5-32-551", "S-1-5-19", "S-1-5-20", CREATOR_OWNER,
              OWNER_RIGHTS, "S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464"}      # TrustedInstaller
ADMIN_RIDS = ("-500", "-512", "-516", "-518", "-519")      # Administrator, Domain/Enterprise/Schema Admins, DCs
SID_RE = re.compile(r"^S-1-[0-9]+(-[0-9]+){1,15}$")


def is_admin_sid(sid):
    return sid in ADMIN_SIDS or (sid.startswith("S-1-5-21-") and sid.endswith(ADMIN_RIDS))


def is_domain_users(sid):
    return sid.startswith("S-1-5-21-") and sid.endswith("-513")


def mask_of(m):
    """An entry's mask as file rights: generic rights mapped to what they mean for a folder."""
    m = int(m) & 0xFFFFFFFF
    out = m & 0x00FFFFFF
    for g, spec in GENERIC.items():
        if m & g:
            out |= spec
    return out & (FULL | SYNCHRONIZE)


def evaluate(acl, sids, owner_sid=None):
    """The rights an access control list gives a caller holding these SIDs, as Windows reads it: in order, the
    first entry to decide a right decides it. Only entries that apply to the folder itself count."""
    sids = set(sids)
    granted = decided = 0
    owner_rights = any(a.get("sid") == OWNER_RIGHTS and a.get("here", True) for a in acl or [])
    if owner_sid and owner_sid in sids:
        sids.add(OWNER_RIGHTS)                    # the owner is the caller OWNER RIGHTS entries speak of
    for a in acl or []:
        if not a.get("here", True) or a.get("sid") not in sids:
            continue
        bits = mask_of(a.get("mask", 0)) & ~decided
        if not bits:
            continue
        if a.get("allow", True):
            granted |= bits
        decided |= bits
    if owner_sid and owner_sid in sids and not owner_rights:
        granted |= 0x60000            # the owner always reads and changes permissions (a deny does not take that away)
    return granted & FULL


def share_rights(share_acl, sids):
    """Share permissions: a deny of a level removes it whatever allows it."""
    sids = set(sids)
    allow = deny = 0
    for a in share_acl or []:
        if a.get("sid") not in sids:
            continue
        m = SHARE_MASK.get((a.get("right") or "").lower(), 0)
        if a.get("allow", True):
            allow |= m
        else:
            deny |= m
    return allow & ~deny


def level_of(mask):
    for label, m in LEVELS:
        if mask & m == m:
            return label
    if mask & 0x1:
        return "Some read"
    if mask & WRITE_BITS:
        return "Some write"
    return "No access" if not mask else "Special"


def grid(share_mask, ntfs_mask):
    eff = share_mask & ntfs_mask
    return [{"key": k, "label": label, "share": share_mask & m == m, "ntfs": ntfs_mask & m == m, "effective": eff & m == m}
            for k, label, m in RIGHTS]


# ---------------------------------------------------------------------------
# Who a caller is: the SIDs that count for a person or a group
# ---------------------------------------------------------------------------

def caller_sids(sid, kind, groups_of_user, all_domain_groups):
    """A person: their own SID, every group Active Directory puts them in (nested), every group that holds all
    domain users, and the groups every network caller has. A group: itself and those every caller has."""
    if sid == EVERYONE:
        return {EVERYONE}
    if sid in (AUTH_USERS, NETWORK):
        return {sid, EVERYONE}
    base = {sid, EVERYONE, AUTH_USERS, NETWORK}
    if kind == "user":
        return base | set(groups_of_user) | set(all_domain_groups)
    return base


# ---------------------------------------------------------------------------
# Risks of one folder
# ---------------------------------------------------------------------------

RISKS = [  # key, label, why
    ("wide_write", "Everyone-type groups can change files",
     "Everyone, Authenticated Users, Domain Users or BUILTIN\\Users can write or delete here, through the share and NTFS."),
    ("control", "Can change permissions or take ownership",
     "An account that is not an administrator can change who has access, or take the folder over."),
    ("person", "Rights given to a person, not a group",
     "A person is named on the folder itself; access is easier to review through groups."),
    ("orphan", "Orphaned SID",
     "A permission names an account that no longer exists."),
    ("broken", "Inheritance turned off",
     "The folder does not take its permissions from the folder above."),
    ("deny", "Deny entry",
     "A deny entry is set here; it overrides allows and is easy to miss."),
    ("unreadable", "Could not be read",
     "The scanner could not read this folder's permissions or list its folders."),
]
RISK_LABEL = {k: l for k, l, _ in RISKS}


def risks(folder, share_acl, principals, wide_sids):
    """The risk keys of one folder. principals: sid -> {kind, name}."""
    out = set()
    acl = folder.get("acl") or []
    if folder.get("error") and not folder.get("partial"):
        out.add("unreadable")
    if folder.get("protected"):
        out.add("broken")
    for sids in wide_sids:
        eff = share_rights(share_acl, sids) & evaluate(acl, sids)
        if eff & WRITE_BITS:
            out.add("wide_write")
            break
    for a in acl:
        s = a.get("sid") or ""
        p = principals.get(s) or {}
        if not p.get("name") and not p.get("lookup_failed") and not s.startswith(("S-1-1-", "S-1-3-", "S-1-5-32-")) \
                and s not in WELL_KNOWN and len(s.split("-")) > 4:
            out.add("orphan")
        if not a.get("inh") and a.get("allow", True):
            if p.get("kind") == "user" and not is_admin_sid(s):
                out.add("person")
            if mask_of(a.get("mask", 0)) & CONTROL_BITS and a.get("here", True) and not is_admin_sid(s):
                out.add("control")
        if not a.get("allow", True) and not a.get("inh"):
            out.add("deny")
    return sorted(out)


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

def key_of(path):
    """A path in one form for matching: back slashes, no doubled ones, no trailing one (but D:\\), lower case."""
    p = (path or "").strip().strip('"').strip("'").strip().replace("/", "\\")
    unc = p.startswith("\\\\")
    p = re.sub(r"\s*\\\s*", "\\\\", p)
    p = re.sub(r"\\{2,}", "\\\\", p)
    if unc:
        p = "\\" + p if not p.startswith("\\\\") else p
    if len(p) > 3 and p.endswith("\\"):
        p = p.rstrip("\\")
    if re.fullmatch(r"[A-Za-z]:", p):
        p += "\\"
    return p.lower()


def parent_key(k):
    if re.fullmatch(r"[a-z]:\\", k):
        return None
    i = k.rfind("\\")
    if i < 0:
        return None
    return k[:i + 1] if re.fullmatch(r"[a-z]:", k[:i]) else k[:i]


def leaf(k):
    return k.rstrip("\\").rsplit("\\", 1)[-1]


def squash(name):
    """A name with its spaces, dashes, dots and underscores taken out: 'HR_Docs' and 'HR Docs' are the same."""
    return re.sub(r"[\s_\-.]+", "", (name or "").lower())


def host_names(host):
    out = set()
    for v in (host.get("hostname"), host.get("fqdn")):
        v = (v or "").strip().lower()
        if v:
            out.add(v)
            out.add(v.split(".")[0])
    return out


def _local(text, scan):
    """A path as written, as a folder key on this server: (key, how), (None, why it cannot be), or (None, None)
    for a bare name."""
    k = key_of(text)
    m = re.match(r"^\\\\([^\\]+)\\([^\\]+)(\\.*)?$", k)
    if m:
        server, sname, rest = m.group(1), m.group(2), m.group(3) or ""
        if server not in scan["names"]:
            return None, f"the path names the server '{server}', not this one"
        root = scan["shares"].get(sname)
        if root is None and re.fullmatch(r"[a-z]\$", sname):
            root = sname[0] + ":\\"                   # \\server\D$\...: the drive itself
        if root is None:
            return None, f"no share '{sname}' on this server"
        return key_of(root.rstrip("\\") + rest if rest else root), "through the share " + scan["share_names"].get(sname, sname)
    if re.match(r"^[a-z]:\\", k):
        return k, "as a path on the server"
    return None, None


CLOSE_MAX = 2000


def _close(name, kids, at=0.85):
    """The siblings whose name is close to this one (ratio >= at), best first. Only names of a near length are
    compared, and the cheap upper bounds go first: a share of thousands of folders stays fast."""
    out, n = [], len(name)
    for c in kids:
        lc = leaf(c)
        if abs(len(lc) - n) > max(2, int(n * 0.2)):
            continue
        sm = difflib.SequenceMatcher(None, name, lc)
        if sm.real_quick_ratio() >= at and sm.quick_ratio() >= at:
            r = sm.ratio()
            if r >= at:
                out.append((r, c))
    return [c for r, c in sorted(out, reverse=True)]


def _bare(text):
    t = (text or "").strip()
    return bool(t) and "\\" not in t and "/" not in t and ":" not in t


def resolve(row, scan):
    """Where an ownership row points: (outcome, how, folder_key, candidates).
    scan: scan_index() of the server's last scan."""
    folders = scan["folders"]
    if row.get("set_key"):
        k = row["set_key"]
        if k in folders:
            return "mapped", "Chosen on the page", k, []
        return "orphan", "The folder chosen on the page is not in the last scan (" + k + ")", None, []
    path = (row.get("path_text") or "").strip()
    share = (row.get("share_text") or "").strip()
    folder = (row.get("folder_text") or "").strip()
    if not (path or share or folder):
        return "empty", "The row names no path, share or folder", None, []
    # a full path written in the share or folder column is the row's path
    if not path and share and not _bare(share):
        path, share = share + ("\\" + folder if folder else ""), ""
        folder = ""
    elif not path and folder and not _bare(folder) and not share:
        path, folder = folder, ""
    tried, cands = [], []

    def seen(k, how):
        if k in folders:
            return ("mapped", "Same folder, " + how, k, [])
        if k in scan["missing"]:
            tried.append(k + " does not exist on the server")
        cands.append(k)
        return None

    if path and not _bare(path):
        k, how = _local(path, scan)
        if k is None:
            tried.append(how or "the path could not be read")
        else:
            if folder and not share:                  # a path and a folder column: the folder is under the path
                k = key_of(k.rstrip("\\") + "\\" + folder)
                how += " and the folder column"
            hit = seen(k, how)
            if hit:
                return hit
    if share:
        sk = scan["shares"].get(share.lower())
        if sk is None:
            tried.append(f"no share '{share}' on this server")
        else:
            k = key_of(sk.rstrip("\\") + "\\" + folder) if folder else sk
            hit = seen(k, "through the share " + share + (" and the folder column" if folder else ""))
            if hit:
                return hit
    one = path if _bare(path) else (folder if folder and not share and not path else "")
    if one:
        sk = scan["shares"].get(one.lower())
        if sk and sk in folders:
            return "mapped", "Same folder: the share " + scan["share_names"].get(one.lower(), one), sk, []
        hits = scan["by_leaf"].get(squash(one), [])
        exact = [x for x in hits if leaf(x) == one.lower()]
        pick = exact or hits
        if len(pick) == 1:
            return "doubt", "Found by its name only" + ("" if exact else ", written differently"), pick[0], []
        if len(pick) > 1:
            return "doubt", f"{len(pick)} folders have this name: choose one", None, sorted(pick)[:20]
    # the same folder written differently, or a close name, inside the folder the row names as its parent
    for k in cands:
        par = parent_key(k)
        if not par or par not in folders:
            continue
        kids = scan["children"].get(par, [])
        same = scan["squashed"].get(par, {}).get(squash(leaf(k)), [])
        if len(same) == 1:
            return "doubt", "Same name written differently (" + leaf(same[0]) + ")", same[0], []
        if len(same) > 1:
            return "doubt", "Names written alike: choose one", None, sorted(same)[:20]
        # close names: among a folder's subfolders; not among thousands (home folders: a name is a person's, not a typo)
        close = _close(leaf(k), kids) if len(kids) <= CLOSE_MAX else []
        if len(close) == 1:
            return "doubt", "Close name (" + leaf(close[0]) + ")", close[0], []
        if len(close) > 1:
            return "doubt", "Close names: choose one", None, close[:20]
    why = "; ".join(dict.fromkeys(tried)) or "no folder of this name in the last scan"
    return "orphan", "Not found: " + why, None, list(dict.fromkeys(cands))[:5]      # the folders looked for


def scan_index(host, shares, folders, missing=()):
    """The lookups resolve() needs, from one scan."""
    sh, names = {}, {}
    for s in shares:
        sh[s["name"].lower()] = key_of(s["path"])
        names[s["name"].lower()] = s["name"]
    fo = {f["path_key"]: f for f in folders}
    by_leaf, children, squashed = {}, {}, {}
    for k, f in fo.items():
        if f["depth"] > 0:
            by_leaf.setdefault(squash(leaf(k)), []).append(k)
        p = parent_key(k)
        if p:
            children.setdefault(p, []).append(k)
            squashed.setdefault(p, {}).setdefault(squash(leaf(k)), []).append(k)
    return {"names": host_names(host), "shares": sh, "share_names": names, "folders": fo, "by_leaf": by_leaf, "children": children,
            "squashed": squashed,
            "missing": {key_of(m) for m in missing}}


def ownership(folders, owned_keys):
    """{path_key: state} for the folders that need an owner: 'owned' (itself or a folder above it has one),
    'split' (a folder below it has one), 'missing'. A folder needs one when it is a share root, or no deeper than
    the deepest owned folder of its share."""
    owned_keys = set(owned_keys)
    by_share = {}
    for f in folders:
        by_share.setdefault(f["share"], []).append(f)
    out = {}
    for share, fs in by_share.items():
        keys = {f["path_key"] for f in fs}
        level = max([f["depth"] for f in fs if f["path_key"] in owned_keys] or [0])
        below = set()
        for k in owned_keys & keys:
            p = parent_key(k)
            while p:                                   # through folders not listed (they only inherit)
                if p in keys:
                    below.add(p)
                p = parent_key(p)
        for f in fs:
            if f["depth"] > level:
                continue
            k = f["path_key"]
            up, p = k in owned_keys, parent_key(k)
            while not up and p:
                up = p in owned_keys
                p = parent_key(p)
            out[k] = "owned" if up else ("split" if k in below else "missing")
    return out


def owner_of(key, owners, keys):
    """The owner row of a folder: its own, or the nearest folder above it."""
    k = key
    while k:                       # up to the drive, through folders the scan did not list
        if k in owners:
            return owners[k], k
        k = parent_key(k)
    return None, None


# ---------------------------------------------------------------------------
# The workbook's columns
# ---------------------------------------------------------------------------

FIELDS = ("path", "share", "folder", "server", "department", "owner", "email")
FIELD_LABEL = {"path": "Full path", "share": "Share", "folder": "Folder", "server": "Server", "department": "Department",
               "owner": "Owner", "email": "Owner's e-mail"}
SYNONYMS = {
    "path": ["full path", "folder path", "share path", "unc path", "unc", "path", "network path", "location", "full name"],
    "share": ["share name", "share", "shared folder", "share folder"],
    "folder": ["folder name", "folder", "sub folder", "subfolder", "directory", "dir"],
    "server": ["server name", "file server", "server", "host name", "hostname", "host"],
    "department": ["department", "dept", "division", "business unit", "bu", "section", "team", "group name", "unit"],
    "owner": ["data owner", "folder owner", "share owner", "business owner", "owner name", "owner", "custodian",
              "responsible", "person in charge", "pic", "approver"],
    "email": ["owner email", "owner e mail", "email address", "e mail address", "email", "e mail", "mail"],
}


def norm_head(h):
    return re.sub(r"[^a-z0-9]+", " ", (h or "").lower()).strip()


def header_row(rows):
    """Among the first 15 rows, the one whose cells name the most of the fields."""
    best, score = 0, -1
    for i, r in enumerate(rows[:15]):
        cells = [norm_head(c) for c in r if c]
        known = sum(1 for c in cells if any(c == s for syn in SYNONYMS.values() for s in syn))
        sc = 10 * known + len(set(cells))
        if sc > score:
            best, score = i, sc
    return best


def guess_columns(headers):
    """field -> column index from the header words: an exact header first, then a header containing the words."""
    out, used = {}, set()
    norm = [norm_head(h) for h in headers]
    for exact in (True, False):
        for field in FIELDS:
            if field in out:
                continue
            for syn in SYNONYMS[field]:
                hit = next((i for i, h in enumerate(norm) if i not in used and (h == syn if exact else
                            (len(syn) > 3 and re.search(r"\b" + re.escape(syn) + r"\b", h)))), None)
                if hit is not None:
                    out[field] = hit
                    used.add(hit)
                    break
    return out


def guess_server(sheet_name, cells, hosts):
    """The audited server a sheet is for: one whose name is in the sheet's name, or in its server column."""
    sn = (sheet_name or "").lower()
    for hst in hosts:
        if any(n and re.search(r"(^|[^a-z0-9])" + re.escape(n) + r"($|[^a-z0-9])", sn) for n in host_names(hst)):
            return hst["id"], "the sheet's name"
    vals = {(c or "").strip().lower() for c in cells if c}
    for hst in hosts:
        if vals & host_names(hst):
            return hst["id"], "its Server column"
    for v in vals:
        m = re.match(r"^\\\\([^\\/]+)", v.replace("/", "\\"))
        if m:
            for hst in hosts:
                if m.group(1).lower() in host_names(hst) or m.group(1).lower().split(".")[0] in host_names(hst):
                    return hst["id"], "the paths it names"
    return (hosts[0]["id"], "the only audited server") if len(hosts) == 1 else (None, "")


def row_fields(cells, mapping, headers):
    """A workbook row as the register keeps it: the mapped fields, and every other column as details."""
    out = {f: (cells[i] if i is not None and i < len(cells) else "").strip()[:500] for f, i in
           ((f, mapping.get(f)) for f in FIELDS)}
    used = {i for i in mapping.values() if i is not None}
    det = {}
    for i, h in enumerate(headers):
        if i in used or i >= len(cells) or not (cells[i] or "").strip():
            continue
        det[(h or f"Column {i + 1}")[:80]] = cells[i].strip()[:500]
    out["details"] = det
    return out


def dumps(v):
    return json.dumps(v, default=str)
