/* ---- Vulnerabilities > File shares (r146) -------------------------------------------------------------
 * Who owns each share and folder of the audited file servers, and who can reach it. Three tabs:
 *   Overview     the rings (ownership, the workbook's rows, departments), the risks, the summary in words
 *   Review       To confirm, No owner, Not found, Matched, Rejected: Approve, Reject, Edit (operators)
 *   Permissions  a server's folders; a folder's accounts and groups; what one of them, or one person, can do
 *                (share, NTFS and effective, as a picture and as a grid, as asked for)
 * The servers and their scans sit above the tabs (a scan is the first step, before any tab has data); the
 * ownership workbook is uploaded from the page head and checked (server and columns of each sheet) before it is
 * used. Nothing here changes a server. */

const FS_BASE = "/file-shares";
const FS_TABS = [["overview", "Overview"], ["review", "Review"], ["permissions", "Permissions"]];
const FS_KINDS = [["doubt", "To confirm"], ["missing", "No owner"], ["orphan", "Not found"], ["matched", "Matched"], ["rejected", "Rejected"]];
const FS_KEYS = ["tab", "kind", "host", "share", "q", "risk", "key", "who"];
const FS_KIND = { user: "person", group: "group", local_group: "group of the server", well_known: "built-in group", computer: "computer", unknown: "unknown" };

function fsHash(st) {
  const p = new URLSearchParams();
  for (const k of FS_KEYS) if (st[k]) p.set(k, st[k]);
  const q = p.toString();
  return "#/file-shares" + (q ? "?" + q : "");
}

function fsNum(n) { return Number(n || 0).toLocaleString(); }

function fsRiskChips(keys, labels) {
  return (keys || []).map(k => h("span", { class: "chip " + (k === "wide_write" || k === "control" ? "chip-bad" : "chip-warn") }, labels[k] || k));
}

/* A box that is drawn by an answer the page waits for: a newer draw of the same box wins, an older answer that
 * comes back last is dropped (in-page redraws do not change the route, so api() cannot tell). */
function fsTurn(box) {
  box._fsTurn = (box._fsTurn || 0) + 1;
  const mine = box._fsTurn;
  return () => box.isConnected && box._fsTurn === mine;
}

function fsFailIn(box, e) {
  if (e instanceof StaleRoute) return;
  box.replaceChildren(h("div", { class: "empty" }, h("p", null, (e && e.message) || "This could not be read.")));
}

async function renderFileShares(params) {
  setNav("file-shares");
  const home = await api(FS_BASE);
  const st = {};
  for (const k of FS_KEYS) if (params.get(k)) st[k] = params.get(k);
  if (!FS_TABS.some(t => t[0] === st.tab)) st.tab = "overview";
  if (!FS_KINDS.some(t => t[0] === st.kind)) st.kind = null;
  const page = h("div", { class: "fs" });
  render(page);
  fsDraw(page, home, st);
}

function fsDraw(page, home, st) {
  const edit = !!home.can_edit;
  const labels = Object.fromEntries((home.risk_labels || []).map(r => [r.key, r.label]));
  const say = h("p", { class: "cm-meta fs-msg", role: "status", "aria-live": "polite" });
  const tell = (t, bad) => { say.textContent = t || ""; say.classList.toggle("hd-failed", !!bad); };
  const keep = () => history.replaceState(null, "", fsHash(st));
  const turn = fsTurn(page);
  const again = async msg => {
    const mine = fsTurn(page);
    let fresh;
    try { fresh = await api(FS_BASE); } catch (e) { if (!(e instanceof StaleRoute)) tell(e.message, true); return; }
    if (!mine()) return;
    fsDraw(page, fresh, st);
    if (msg) { const m = page.querySelector(".fs-msg"); if (m) m.textContent = msg; }
  };
  const go = (tab, extra) => {
    st.tab = tab;
    for (const k of ["kind", "share", "q", "risk", "key", "who"]) delete st[k];
    Object.assign(st, extra || {});
    keep();
    fsDraw(page, home, st);
  };
  void turn;
  const scanned = (home.servers || []).some(s => s.done);
  const sum = home.summary || { total: {}, words: [], risks: [], departments: [], servers: [] };
  const t = sum.total || {};
  const tabs = h("div", { class: "filters fs-tabs", role: "tablist", "aria-label": "Show" },
    FS_TABS.map(([k, label]) => h("button", { type: "button", role: "tab", class: "fbtn", "aria-selected": String(st.tab === k), "aria-pressed": String(st.tab === k),
      on: { click: () => go(k) } }, label + (k === "review" ? " (" + fsNum((t.doubt || 0) + (t.missing || 0) + (t.orphan || 0)) + ")" : ""))));
  const body = h("div", { class: "fs-body" });
  page.replaceChildren(...[
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure vulns --file-shares" }, "File shares"),
      h("div", { class: "head-actions" }, scanned ? fsExport(st, tell) : null,
        edit && (home.servers || []).length ? h("button", { type: "button", class: "btn", on: { click: e => fsPickFile(e.currentTarget, tell, again) } },
          "Upload ownership workbook") : null)),
    h("p", { class: "muted small fs-intro" }, "Who owns each share and folder on the audited file servers, and who can reach it: the share "
      + "permission, the NTFS permission and what a person really gets (the stricter of the two). Read-only: nothing on the servers is changed."),
    fsServers(home, edit, tell, again),
    home.pending ? fsPreview(home, home.pending, edit, tell, again) : null,
    home.workbook && !home.pending ? h("p", { class: "muted small" }, "Ownership workbook in use: " + home.workbook.file_name + ", used by "
      + home.workbook.applied_by + " " + timeAgo(home.workbook.applied_at) + ".") : null,
    scanned ? tabs : null, say, scanned ? body : null].filter(Boolean));         // (replaceChildren would write null as text)
  fsPoll(page, home, edit, tell, again);
  if (!scanned) return;
  if (st.tab === "overview") fsOverview(body, home, go);
  else if (st.tab === "review") fsReview(body, home, st, edit, tell, keep, again, labels).catch(e => fsFailIn(body, e));
  else fsPermissions(body, home, st, keep, tell, labels).catch(e => fsFailIn(body, e));
}

/* One Export control, as every page has: the PDF report or the Excel workbook (of this server on Permissions). */
function fsExport(st, tell) {
  const menu = h("div", { class: "exp-menu", role: "menu", hidden: true });
  const btn = h("button", { type: "button", class: "btn btn-quiet exp-btn", "aria-haspopup": "menu", "aria-expanded": "false" }, "Export ▾");
  const close = () => { menu.hidden = true; btn.setAttribute("aria-expanded", "false"); };
  const run = async fmt => {
    close();
    const one = st.tab === "permissions" && st.host;
    btn.disabled = true; tell("Building the " + (fmt === "pdf" ? "PDF report" : "Excel workbook") + "…");
    try {
      await downloadFile(FS_BASE + "/export?format=" + fmt + (one ? "&host_id=" + encodeURIComponent(st.host) : ""), "file-shares." + fmt);
      tell("The " + (fmt === "pdf" ? "PDF report" : "Excel workbook") + " is downloaded" + (one ? " (this server)." : " (every audited server)."));
    } catch (err) { tell(err.message, true); }
    btn.disabled = false;
  };
  const item = (fmt, title, sub) => h("button", { type: "button", role: "menuitem", on: { click: () => run(fmt) } }, h("strong", null, title), h("span", null, sub));
  menu.append(item("pdf", "PDF report", "With the logo: the summary, the rings, the owners, who can reach each share"),
              item("xlsx", "Excel workbook", "Every sheet: needs attention, owners, access, risks, the workbook's rows"));
  btn.addEventListener("click", e => {
    e.stopPropagation();
    const open = menu.hidden;
    menu.hidden = !open; btn.setAttribute("aria-expanded", String(open));
    if (open) menu.querySelector("button").focus();
  });
  const wrap = h("span", { class: "exp", "data-own-export": "1" }, btn, menu);
  wrap._close = close;
  wrap.addEventListener("keydown", e => { if (e.key === "Escape") { close(); btn.focus(); } });
  return wrap;
}

/* While a scan is queued or running, look again every 10 seconds. A new part only updates the servers box; a scan
 * that starts, ends or stops redraws the page, unless an Edit form or the workbook check is open (then it is said). */
function fsPoll(page, home, edit, tell, again) {
  const busy = s => s.scan && ["queued", "running"].includes(s.scan.state) && !s.scan.stalled;
  if (!(home.servers || []).some(busy)) { clearPageTimer(); return; }
  const states = list => JSON.stringify((list || []).map(s => s.scan && [s.scan.id, s.scan.state, !!s.scan.picked_at, !!s.scan.stalled]));
  const was = states(home.servers);
  setPageTimer(async () => {
    if (!page.isConnected || !location.hash.startsWith("#/file-shares")) return clearPageTimer();
    let fresh;
    try { fresh = await api(FS_BASE); } catch (e) { return; }
    if (!page.isConnected) return;
    if (states(fresh.servers) === was) {
      const box = page.querySelector(".fs-servers");
      if (box) box.replaceWith(fsServers(fresh, edit, tell, again));
      return;
    }
    clearPageTimer();
    if (page.querySelector(".fs-edit, .fs-preview")) {
      const box = page.querySelector(".fs-servers");
      if (box) box.replaceWith(fsServers(fresh, edit, tell, again));
      tell("A scan has moved on: its results show when you finish here and the page is drawn again.");
      return;
    }
    again();
  }, 10000);
}

/* ---- the audited servers and their scans ------------------------------------------------------- */

function fsScanState(s) {
  const sc = s.scan;
  if (!sc) return [h("span", { class: "chip" }, "never scanned")];
  if (sc.stalled) return [h("span", { class: "chip chip-bad" }, "stopped"), " ", h("span", { class: "small" }, sc.stalled_why || "")];
  if (sc.state === "queued") return [h("span", { class: "chip chip-warn" }, sc.picked_at ? "starting" : "waiting for the agent"), " ",
    h("span", { class: "muted small" }, sc.picked_at ? "the scanner was started " + timeAgo(sc.picked_at) : "asked " + timeAgo(sc.created_at))];
  if (sc.state === "running") return [h("span", { class: "chip chip-warn" }, "scanning"), " ",
    h("span", { class: "muted small" }, sc.parts + " part" + (sc.parts === 1 ? "" : "s") + " received, the last " + timeAgo(sc.last_part_at))];
  if (sc.state === "failed" || sc.state === "cancelled") return [h("span", { class: "chip chip-bad" }, sc.state), " ", h("span", { class: "small" }, sc.error || "")];
  return [h("span", { class: "chip chip-ok" }, "scanned"), " ", h("span", { class: "muted small" }, timeAgo(sc.finished_at))];
}

function fsServers(home, edit, tell, again) {
  const servers = home.servers || [];
  const cands = home.candidates || [];
  const act = async (b, fn, msg) => {
    b.disabled = true;
    try { await fn(); await again(msg); } catch (e) { tell(e.message, true); b.disabled = false; }
  };
  const addSel = h("select", { "aria-label": "Windows server to add" }, h("option", { value: "" }, "Choose a Windows server…"),
    cands.map(c => h("option", { value: c.id }, c.hostname)));
  const add = !edit ? null : cands.length ? h("div", { class: "cm-actions" }, addSel,
    h("button", { type: "button", class: "btn btn-quiet", on: { click: e => {
      if (!addSel.value) { tell("Choose the server to add.", true); return; }
      const name = addSel.selectedOptions[0].textContent;
      act(e.currentTarget, () => apiPost(FS_BASE + "/servers", { host_id: addSel.value }), name + " is audited now: scan it to read its shares.");
    } } }, "Add to the audit"))
    : h("p", { class: "muted small" }, servers.length ? "Every Windows server with the agent is audited."
      : "No Windows server with the PATCH-01 agent is known yet: enrol the file servers' agents first (Servers).");
  if (!servers.length) {
    return h("div", { class: "empty fs-empty" }, h("h3", null, "No file server is audited yet"),
      h("ol", { class: "rm-steps" },
        h("li", null, h("strong", null, "Add"), " the file servers (Windows servers with the PATCH-01 agent)."),
        h("li", null, h("strong", null, "Copy the scanner"), " access-scan.ps1 (signed, like the agent) next to patch-agent.ps1 on each of them, "
          + "and try it once as administrator: access-scan.ps1 -DryRun (it sends nothing)."),
        h("li", null, h("strong", null, "Scan"), " each server: its shares, share permissions, NTFS permissions and groups."),
        h("li", null, h("strong", null, "Upload the ownership workbook"), ": one sheet per server; its rows are matched to the folders, and "
          + "you confirm the ones in doubt.")),
      edit ? add : h("p", { class: "muted" }, "An operator adds the servers."));
  }
  const n = Object.fromEntries(((home.summary || {}).servers || []).map(p => [p.host.id, p.n]));
  return h("section", { class: "fs-by fs-servers no-enh" }, h("h3", null, "Audited servers"),
    table([
      { label: "Server", cell: s => h("strong", null, s.hostname) },
      { label: "Last scan", cell: s => h("span", null, fsScanState(s)) },
      { label: "Shares", num: true, cell: s => s.done && n[s.id] ? fsNum(n[s.id].shares) : "–" },
      { label: "Folders read", num: true, cell: s => s.done && n[s.id] ? fsNum(n[s.id].walked) : "–" },
      { label: "", cell: s => edit ? h("span", { class: "cm-actions" },
          s.scan && ["queued", "running"].includes(s.scan.state) && !s.scan.stalled
            ? h("button", { type: "button", class: "btn-link", on: { click: e => act(e.currentTarget,
                () => apiPost(FS_BASE + "/scans/" + encodeURIComponent(s.scan.id) + "/cancel", {}), "The scan of " + s.hostname + " is cancelled.") } }, "Cancel")
            : h("button", { type: "button", class: "btn btn-quiet", on: { click: e => act(e.currentTarget,
                () => apiPost(FS_BASE + "/scan", { host_id: s.id }), "Scan of " + s.hostname + " asked: its agent starts it within a few minutes.") } }, "Scan now"),
          h("button", { type: "button", class: "btn-link", on: { click: e => act(e.currentTarget,
            () => apiSend("DELETE", FS_BASE + "/servers/" + encodeURIComponent(s.id)), s.hostname + " is no longer audited (its scans are kept).") } },
            "Remove")) : null },
    ], servers), add);
}

/* ---- the ownership workbook: upload, check each sheet's server and columns, use it --------------- */

function fsPickFile(btn, tell, again) {
  document.querySelectorAll("input.fs-file").forEach(x => x.remove());
  const input = h("input", { type: "file", class: "fs-file", accept: ".xlsx,.csv", hidden: true });
  document.body.append(input);
  input.addEventListener("change", async () => {
    const f = input.files[0];
    input.remove();
    if (!f) return;
    if (!/\.(xlsx|csv)$/i.test(f.name)) {
      tell(/\.xls$/i.test(f.name) ? "Old .xls files cannot be read: open it in Excel and save it as .xlsx, then upload that."
        : "Upload the ownership workbook as .xlsx (or .csv).", true);
      return;
    }
    btn.disabled = true; tell("Reading " + f.name + "…");
    try {
      const fd = new FormData();
      fd.append("file", f);
      const res = await fetch("/api/v1" + FS_BASE + "/workbook", { method: "POST", body: fd, cache: "no-store",
        headers: { "X-Requested-With": "patch01-dashboard", ...authHeaders() } });
      if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
      if (!res.ok) { let d = ""; try { d = detailText((await res.json()).detail); } catch (e) { /* not JSON */ } throw new ApiError(res.status, d || httpReason(res)); }
      await again("Check each sheet's server and columns below, then use the workbook.");
    } catch (e) { tell(e.message, true); btn.disabled = false; }
  });
  input.click();
}

function fsPreview(home, u, edit, tell, again) {
  const servers = home.servers || [];
  const fields = u.fields || [];
  const cards = (u.sheets || []).map(s => {
    const use = h("input", { type: "checkbox", checked: !!s.use, disabled: !edit, "aria-label": "Use the sheet " + s.name });
    const srv = h("select", { "aria-label": "Server of the sheet " + s.name, disabled: !edit },
      h("option", { value: "" }, "Choose its server…"), servers.map(x => h("option", { value: x.id, selected: x.id === s.host_id }, x.hostname)));
    const cols = {};
    const grid = h("div", { class: "fs-cols" }, fields.map(f => {
      const sel = h("select", { "aria-label": f.label + " column of the sheet " + s.name, disabled: !edit },
        h("option", { value: "" }, "— not in this sheet —"),
        (s.header || []).map((hd, i) => h("option", { value: String(i), selected: s.columns[f.key] === i }, hd || "Column " + (i + 1))));
      cols[f.key] = sel;
      return h("label", null, h("span", { class: "small" }, f.label), sel);
    }));
    const sample = h("div", { class: "table-wrap" }, h("table", null,
      h("thead", null, h("tr", null, (s.header || []).map(hd => h("th", { scope: "col" }, hd)))),
      h("tbody", null, (s.sample || []).map(r => h("tr", null, (s.header || []).map((_, i) => h("td", null, r[i] || "")))))));
    return { s, use, srv, cols, node: h("section", { class: "fs-by fs-sheet" },
      h("h3", null, "Sheet " + s.name, h("span", { class: "muted small" }, " · " + fsNum(s.count) + " rows")),
      h("p", { class: "small" }, h("label", null, use, " Use this sheet"), " · ", h("label", null, "Server: ", srv), " ",
        h("span", { class: "muted small" }, s.host_id ? "found from " + s.host_why : "PATCH-01 could not tell from the sheet: choose it")),
      h("p", { class: "muted small" }, "Each field and the column it was read from (change any). Columns not chosen are kept as the row's other details."),
      grid, sample) };
  });
  let actions;
  if (edit) {
    const go = h("button", { type: "button", class: "btn", on: { click: async e => {
      const b = e.currentTarget;
      const sheets = cards.map(c => ({ name: c.s.name, use: c.use.checked, host_id: c.srv.value || null,
        columns: Object.fromEntries(Object.entries(c.cols).map(([k, sel]) => [k, sel.value === "" ? null : Number(sel.value)])) }));
      b.disabled = true; tell("Matching the rows to the folders…");
      try {
        const r = await apiPost(FS_BASE + "/workbook/" + encodeURIComponent(u.id) + "/apply", { sheets });
        const w = r.workbook || {};
        await again("The workbook's " + fsNum(r.rows) + " rows are matched: " + fsNum(w.owner) + " matched, " + fsNum(w.doubt)
          + " to confirm, " + fsNum(w.orphan) + " not found. See Review.");
      } catch (err) { tell(err.message, true); b.disabled = false; }
    } } }, "Use the workbook");
    const drop = h("button", { type: "button", class: "btn btn-quiet", on: { click: async e => {
      const b = e.currentTarget;
      b.disabled = true;
      try { await apiSend("DELETE", FS_BASE + "/workbook/" + encodeURIComponent(u.id)); await again("The workbook is discarded."); }
      catch (err) { tell(err.message, true); b.disabled = false; }
    } } }, "Discard");
    actions = h("div", { class: "cm-actions" }, go, drop);
  } else {
    actions = h("p", { class: "muted" }, "An operator checks the sheets and uses the workbook.");
  }
  return h("section", { class: "fs-preview no-enh" }, h("h2", null, "Check the workbook: " + u.file_name),
    h("p", { class: "muted small" }, "Uploaded by " + u.uploaded_by + " " + timeAgo(u.uploaded_at) + ". Nothing is used until you press Use the workbook. "
      + "Its rows then replace the last workbook's; rows added on this page, and decisions on rows that are the same in both, are kept."),
    cards.map(c => c.node), actions);
}

/* ---- Overview ------------------------------------------------------------------------------- */

function fsOverview(box, home, go) {
  const s = home.summary;
  const t = s.total || {};
  const deps = s.departments || [];
  const dep = deps.slice(0, 5).map((d, i) => ({ label: d[0], value: d[1], cls: "c-cat" + (i + 1) }));
  if (deps.length > 5) dep.push({ label: "Other departments", value: deps.slice(5).reduce((a, d) => a + d[1], 0), cls: "c-muted" });
  const rk = (s.risks || []).filter(r => r.n);
  box.replaceChildren(
    h("div", { class: "cy-grid" },
      donut("Ownership", [
        { label: "Owner known", value: t.owned, cls: "c-ok" },
        { label: "No owner", value: t.missing, cls: "c-bad", href: fsHash({ tab: "review", kind: "missing" }) },
      ], { caption: "Shares and folders that need an owner", centre: s.owned_pct === null || s.owned_pct === undefined ? "–" : s.owned_pct + "%",
           centreLabel: "owner known" }),
      donut("The ownership workbook", [
        { label: "Matched", value: t.matched, cls: "c-ok", href: fsHash({ tab: "review", kind: "matched" }) },
        { label: "To confirm", value: t.doubt, cls: "c-warn", href: fsHash({ tab: "review", kind: "doubt" }) },
        { label: "Not found", value: t.orphan, cls: "c-bad", href: fsHash({ tab: "review", kind: "orphan" }) },
        { label: "Rejected", value: t.rejected, cls: "c-muted", href: fsHash({ tab: "review", kind: "rejected" }) },
      ], Object.assign({ caption: t.rows ? "Its rows, matched to the folders" : "No workbook used yet: upload it from the page head" },
        t.rows ? { centreLabel: "rows" } : {})),
      donut("Owned folders by department", dep, Object.assign({ caption: "From the workbook and the owners added here" },
        dep.length ? { centreLabel: "folders" } : {}))),
    h("section", { class: "fs-by" }, h("h3", null, "Summary"), (s.words || []).map(w => h("p", null, w))),
    h("section", { class: "fs-by no-enh" }, h("h3", null, "Risks"),
      rk.length ? table([
        { label: "Risk", cell: r => h("button", { type: "button", class: "btn-link", on: { click: () => go("permissions", { risk: r.key }) } }, r.label) },
        { label: "Folders", num: true, cell: r => fsNum(r.n) },
        { label: "Why it matters", cell: r => h("span", { class: "muted small" }, r.why) },
      ], rk) : h("div", { class: "empty" }, h("p", null, "No folder shows any of the risks checked."))),
    h("section", { class: "fs-by no-enh" }, h("h3", null, "By server"), table([
      { label: "Server", cell: p => p.host.hostname },
      { label: "Shares", num: true, cell: p => fsNum(p.n.shares) },
      { label: "Folders read", num: true, cell: p => fsNum(p.n.walked) },
      { label: "With their own permissions", num: true, cell: p => fsNum(p.n.own_perms) },
      { label: "Owner known", num: true, cell: p => fsNum(p.n.owned) },
      { label: "No owner", num: true, cell: p => p.n.missing ? h("span", { class: "chip chip-bad" }, fsNum(p.n.missing)) : "0" },
      { label: "To confirm", num: true, cell: p => p.n.doubt ? h("span", { class: "chip chip-warn" }, fsNum(p.n.doubt)) : "0" },
      { label: "Folders with a risk", num: true, cell: p => fsNum(p.n.with_risk) },
      { label: "Scanned", cell: p => p.scan ? timeAgo(p.scan.finished_at) : "never" },
    ], s.servers || [])));
}

/* ---- Review --------------------------------------------------------------------------------- */

async function fsReview(box, home, st, edit, tell, keep, again, labels) {
  const mine = fsTurn(box);
  const t = home.summary.total || {};
  const count = { doubt: t.doubt, missing: t.missing, orphan: t.orphan, matched: t.matched, rejected: t.rejected };
  if (!st.kind) st.kind = ["doubt", "missing", "orphan"].find(k => count[k]) || "matched";
  const bar = h("div", { class: "filters", role: "group", "aria-label": "Show" }, FS_KINDS.map(([k, label]) =>
    h("button", { type: "button", class: "fbtn", "aria-pressed": String(st.kind === k), on: { click: () => {
      st.kind = k; keep(); fsReview(box, home, st, edit, tell, keep, again, labels).catch(e => fsFailIn(box, e)); } } },
      label + " (" + fsNum(count[k]) + ")")));
  const what = h("p", { class: "muted small" }, {
    doubt: "Rows the workbook matches to a folder only by its name, or written differently: approve the folder, reject the row, or edit it.",
    missing: "Shares and folders that need an owner and have none (no row for them, a folder above or a folder below them). Add the owner.",
    orphan: "Rows naming a folder that is not on the server. Edit the row to point it at the right folder, or reject it. "
      + "The next scan also looks for each path these rows name.",
    matched: "Rows matched to a folder, by the rules or by a decision here.",
    rejected: "Rows rejected here: they give no folder an owner. Undo puts a row back." }[st.kind]);
  const list = h("div", { class: "fs-by no-enh" }, h("p", { class: "muted small" }, "Loading…"));
  const editBox = h("div", { class: "fs-edit-box" });
  box.replaceChildren(bar, what, list, editBox);
  let r;
  try { r = await api(FS_BASE + "/review?kind=" + st.kind); } catch (e) { if (mine()) fsFailIn(list, e); return; }
  if (!mine()) return;
  const items = r.items || [];
  const send = async (b, id, body, msg) => {
    const row = b.closest("tr"), all = row ? [...row.querySelectorAll("button")] : [b];
    all.forEach(x => { x.disabled = true; });
    try { await apiPost(FS_BASE + "/rows/" + id, body); await again(msg); }
    catch (e) { all.forEach(x => { x.disabled = false; }); tell(e.message, true); }
  };
  const said = x => x.path_text || [x.share_text, x.folder_text].filter(Boolean).join(" \\ ");
  const who = x => [x.owner, x.department].filter(Boolean).join(" · ") || h("span", { class: "muted" }, "–");
  const where = x => x.sheet + (x.row_no ? ", row " + x.row_no : "");
  const openEdit = (x, title) => fsEditForm(editBox, x, title, tell, again);
  if (!items.length) {
    list.replaceChildren(h("div", { class: "empty" }, h("p", null, { doubt: "Nothing waits to be confirmed.",
      missing: "Every share and folder that needs an owner has one.", orphan: "Every row names a folder that is on its server.",
      matched: "No row is matched yet.", rejected: "No row is rejected." }[st.kind])));
    return;
  }
  let cols;
  if (st.kind === "missing") {
    cols = [
      { label: "Server", cell: x => x.server },
      { label: "Folder", mono: true, cell: x => x.folder },
      { label: "Folders below", num: true, cell: x => fsNum(x.below) },
      { label: "Risks", cell: x => fsRiskChips(x.risks, labels) },
      { label: "", cell: x => edit ? h("button", { type: "button", class: "btn btn-quiet", on: { click: () =>
          openEdit({ host_id: x.host_id, folder: x.folder, folder_key: x.folder_key, add: true }, "Owner of " + x.folder) } }, "Add owner") : null },
    ];
  } else {
    cols = [
      { label: "Row", nowrap: true, cell: x => where(x) },
      { label: "The workbook says", mono: true, cell: x => said(x) },
      { label: "Owner", cell: x => who(x) },
      { label: st.kind === "orphan" ? "Looked for" : "Folder", mono: true, cell: x => st.kind === "orphan"
          ? (x.candidates || []).map(c => c.path).join("; ") || h("span", { class: "muted" }, "–")
          : x.folder || ((x.candidates || []).length ? h("span", { class: "muted" }, x.candidates.length + " folders: choose one (Edit)") : "–") },
      { label: "Why", cell: x => h("span", { class: "small" }, x.how + (x.decided_by ? " · " + (x.decision || "edited") + " by " + x.decided_by : "")) },
      { label: "", cell: x => !edit ? null : h("span", { class: "cm-actions" },
          st.kind === "doubt" && x.folder ? h("button", { type: "button", class: "btn btn-quiet", on: { click: e => send(e.currentTarget, x.id, { action: "approve" },
            "Approved: " + x.folder + " belongs to " + (x.owner || x.department) + ".") } }, "Approve") : null,
          ["doubt", "orphan", "matched"].includes(st.kind) ? h("button", { type: "button", class: "btn-link", on: { click: () =>
            openEdit(x, where(x)) } }, "Edit") : null,
          ["doubt", "orphan", "matched"].includes(st.kind) ? h("button", { type: "button", class: "btn-link", on: { click: e => send(e.currentTarget, x.id,
            { action: "reject" }, "Rejected: " + where(x) + " gives no folder an owner.") } }, "Reject") : null,
          st.kind === "rejected" || x.decision ? h("button", { type: "button", class: "btn-link", on: { click: e => send(e.currentTarget,
            x.id, { action: "undo" }, "Undone: " + where(x) + " is matched by the rules again.") } }, "Undo") : null) },
    ];
  }
  list.replaceChildren(table(cols, items));
}

/* The Edit form: the folder (any folder of the last scan, found as you type), the department, the owner, the
 * e-mail. Saving approves the row for that folder; for a folder with no owner it adds a row. */
function fsEditForm(box, x, title, tell, again) {
  const folder = h("input", { type: "text", value: x.folder || (x.candidates && x.candidates[0] ? x.candidates[0].path : ""), list: "fs-folder-list",
    size: "60", maxlength: "4000", "aria-label": "Folder", readonly: x.add ? true : null });
  const opts = h("datalist", { id: "fs-folder-list" }, (x.candidates || []).filter(c => c.found).map(c => h("option", { value: c.path })));
  const dep = h("input", { type: "text", value: x.department || "", maxlength: "300", "aria-label": "Department" });
  const own = h("input", { type: "text", value: x.owner || "", maxlength: "300", "aria-label": "Owner" });
  const mail = h("input", { type: "email", value: x.email || "", maxlength: "300", "aria-label": "Owner's e-mail" });
  let timer = null, asked = 0;
  folder.addEventListener("input", () => {
    clearTimeout(timer);
    const q = folder.value.trim().replace(/\//g, "\\").toLowerCase();
    if (q.length < 3 || x.add) return;
    timer = setTimeout(async () => {
      const n = ++asked;
      try {
        const r = await api(FS_BASE + "/folders?host_id=" + encodeURIComponent(x.host_id) + "&q=" + encodeURIComponent(q));
        if (folder.isConnected && n === asked) opts.replaceChildren(...(r.items || []).slice(0, 30).map(f => h("option", { value: f.path })));
      } catch (e) { /* the list stays as it was */ }
    }, 250);
  });
  const save = h("button", { type: "button", class: "btn", on: { click: async e => {
    const b = e.currentTarget;
    if (!folder.value.trim()) { tell("Choose the folder.", true); return; }
    if (!own.value.trim() && !dep.value.trim()) { tell("Give the owner or the department.", true); return; }
    b.disabled = true;
    try {
      const body = { department: dep.value.trim(), owner: own.value.trim(), email: mail.value.trim() };
      if (x.add) await apiPost(FS_BASE + "/owners", Object.assign({ host_id: x.host_id, folder_key: x.folder_key }, body));
      else await apiPost(FS_BASE + "/rows/" + x.id, Object.assign({ action: "edit", folder_key: folder.value.trim() }, body));
      box.replaceChildren();
      await again("Saved: " + folder.value.trim() + " belongs to " + (body.owner || body.department) + ".");
    } catch (err) { tell(err.message, true); b.disabled = false; }
  } } }, "Save");
  box.replaceChildren(h("section", { class: "fs-by fs-edit" }, h("h3", null, title),
    h("div", { class: "fs-cols" },
      h("label", null, h("span", { class: "small" }, "Folder"), folder, opts),
      h("label", null, h("span", { class: "small" }, "Department"), dep),
      h("label", null, h("span", { class: "small" }, "Owner"), own),
      h("label", null, h("span", { class: "small" }, "Owner's e-mail"), mail)),
    x.add ? null : h("p", { class: "muted small" }, "Type part of a folder's path to find it; only folders of the server's last scan can be chosen."),
    h("div", { class: "cm-actions" }, save, h("button", { type: "button", class: "btn btn-quiet", on: { click: () => box.replaceChildren() } }, "Cancel"))));
  box.scrollIntoView({ block: "nearest" });
  (x.add ? own : folder).focus();
}

/* ---- Permissions ---------------------------------------------------------------------------- */

async function fsPermissions(box, home, st, keep, tell, labels) {
  const mine = fsTurn(box);
  const servers = (home.servers || []).filter(s => s.done);
  if (!servers.some(s => s.id === st.host)) st.host = servers[0].id;
  if (!box.firstChild) box.replaceChildren(h("p", { class: "muted small" }, "Loading…"));
  const r = await api(FS_BASE + "/folders?host_id=" + encodeURIComponent(st.host) + (st.share ? "&share=" + encodeURIComponent(st.share) : "")
    + (st.q ? "&q=" + encodeURIComponent(st.q.toLowerCase().replace(/\//g, "\\")) : "") + (st.risk ? "&risk=" + encodeURIComponent(st.risk) : ""));
  if (!mine()) return;
  const redraw = () => { keep(); fsPermissions(box, home, st, keep, tell, labels).catch(e => fsFailIn(box, e)); };
  const pick = (k, v) => { st[k] = v || null; delete st.key; delete st.who; redraw(); };
  const srv = h("select", { "aria-label": "Server", on: { change: e => { delete st.share; pick("host", e.target.value); } } },
    servers.map(s => h("option", { value: s.id, selected: s.id === st.host }, s.hostname)));
  const sh = h("select", { "aria-label": "Share", on: { change: e => pick("share", e.target.value) } },
    h("option", { value: "" }, "Every share"), (r.shares || []).map(s => h("option", { value: s.name, selected: s.name === st.share }, s.name)));
  const rk = h("select", { "aria-label": "Risk", on: { change: e => pick("risk", e.target.value) } },
    h("option", { value: "" }, "Any folder"), (home.risk_labels || []).map(x => h("option", { value: x.key, selected: x.key === st.risk }, x.label)));
  const q = h("input", { type: "search", value: st.q || "", placeholder: "Find a folder", "aria-label": "Find a folder", maxlength: "200" });
  let timer = null;
  q.addEventListener("input", () => {
    clearTimeout(timer);
    timer = setTimeout(() => { if ((q.value.trim() || null) !== (st.q || null)) pick("q", q.value.trim()); }, 350);
  });
  const detail = h("div", { class: "fs-detail" });
  const open = f => { st.key = f.key; delete st.who; keep(); fsFolder(detail, st, keep, labels).catch(e => fsFailIn(detail, e)); };
  const hadFocus = document.activeElement && document.activeElement.getAttribute("aria-label") === "Find a folder";
  box.replaceChildren(...[
    h("div", { class: "cm-actions fs-filter" }, srv, sh, rk, q),
    h("p", { class: "muted small" }, "Each share and each folder the scan lists: down to three levels, and deeper ones with permissions of their own. "
      + "Pick a folder to see who can reach it."),
    (r.items || []).length ? h("div", { class: "fs-by no-enh fs-folders" }, table([
      { label: "Folder", mono: true, cell: f => h("button", { type: "button", class: "btn-link", "aria-pressed": String(f.key === st.key),
          on: { click: () => open(f) } }, f.path) },
      { label: "Owner", cell: f => f.owner ? [f.owner.owner || f.owner.department, f.owner.inherited ? h("span", { class: "muted small" }, " (from above)") : null]
          : (f.state === "missing" ? h("span", { class: "chip chip-bad" }, "No owner") : h("span", { class: "muted" }, "–")) },
      { label: "Department", cell: f => (f.owner && f.owner.department) || "" },
      { label: "Permissions", cell: f => f.error ? "" : f.protected ? "its own (inheritance turned off)" : f.explicit ? "its own, and inherited" : "inherited" },
      { label: "Risks", cell: f => fsRiskChips(f.risks, labels) },
      { label: "Folders below", num: true, cell: f => f.below ? fsNum(f.below) : "" },
    ], r.items)) : h("div", { class: "empty" }, h("p", null, "No folder matches.")),
    r.more ? h("p", { class: "muted small" }, "The first 500 folders are shown: choose a share, a risk, or find a folder to see others.") : null,
    detail].filter(Boolean));
  if (hadFocus) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); }
  if (st.key) fsFolder(detail, st, keep, labels).catch(e => fsFailIn(detail, e));
}

async function fsFolder(box, st, keep, labels) {
  const mine = fsTurn(box);
  box.replaceChildren(h("p", { class: "muted small" }, "Loading the folder…"));
  const d = await api(FS_BASE + "/folder?host_id=" + encodeURIComponent(st.host) + "&key=" + encodeURIComponent(st.key));
  if (!mine()) return;
  const eff = h("div", { class: "fs-eff" });
  const show = sid => { st.who = sid; keep(); fsEffective(eff, st).catch(e => fsFailIn(eff, e)); };
  const person = h("input", { type: "search", list: "fs-people", placeholder: "A person's name, account or e-mail", "aria-label": "Check one person", maxlength: "100" });
  const plist = h("datalist", { id: "fs-people" });
  let found = [], timer = null, asked = 0;
  person.addEventListener("input", () => {
    clearTimeout(timer);
    const v = person.value.trim();
    const hit = found.find(p => p.label === v);
    if (hit) { show(hit.sid); return; }
    if (v.length < 2) return;
    timer = setTimeout(async () => {
      const n = ++asked;
      try {
        const r = await api(FS_BASE + "/people?host_id=" + encodeURIComponent(st.host) + "&q=" + encodeURIComponent(v));
        if (n !== asked || !person.isConnected) return;
        found = (r.items || []).map(p => ({ sid: p.sid, label: (p.display ? p.display + " · " : "") + (p.name || p.sid) }));
        plist.replaceChildren(...found.map(p => h("option", { value: p.label })));
      } catch (e) { /* the list stays as it was */ }
    }, 250);
  });
  const f = d.folder;
  const o = d.owner;
  box.replaceChildren(h("section", { class: "fs-by fs-folder no-enh" },
    h("h3", null, d.server + "  ·  " + f.path),
    h("p", null,
      o ? ["Owner: ", h("strong", null, o.owner || "–"), o.department ? " · " + o.department : "", o.email ? " · " + o.email : "",
           o.inherited ? h("span", { class: "muted small" }, " (given on " + (o.from_path || o.from) + ")") : null]
        : h("span", { class: "chip chip-bad" }, "No owner"),
      " · Share ", h("strong", null, d.share.name), d.ntfs_owner ? " · NTFS owner (Windows): " + d.ntfs_owner : "",
      f.protected ? " · inheritance turned off" : ""),
    d.risks.length ? h("p", null, d.risks.map(r => h("span", { class: "chip " + (r.key === "wide_write" || r.key === "control" ? "chip-bad" : "chip-warn") }, r.label))) : null,
    f.error ? h("p", { class: "hd-failed" }, f.error) : null,
    h("h4", null, "Who has access"),
    h("p", { class: "muted small" }, "Every account and group on the folder or its share. Effective: what each gets over the network, the stricter of the "
      + "share and NTFS. Pick one to see each right."),
    table([
      { label: "Account or group", cell: w => h("button", { type: "button", class: "btn-link", "aria-pressed": String(w.sid === st.who), on: { click: () => show(w.sid) } },
          w.name + (w.display ? " (" + w.display + ")" : "")) },
      { label: "Kind", cell: w => w.orphan ? h("span", { class: "chip chip-warn" }, "Orphaned SID") : (FS_KIND[w.kind] || w.kind) + (w.admin ? ", administrator" : "") },
      { label: "Share", cell: w => w.share },
      { label: "NTFS", cell: w => w.ntfs },
      { label: "Effective", cell: w => h("span", { class: "chip " + (w.control ? "chip-bad" : w.write ? "chip-warn" : w.effective === "No access" ? "" : "chip-ok") }, w.effective) },
    ], d.who),
    h("div", { class: "cm-actions" }, h("label", null, h("span", { class: "small" }, "Check one person: "), person, plist)),
    eff));
  if (st.who) fsEffective(eff, st).catch(e => fsFailIn(eff, e));
}

async function fsEffective(box, st) {
  const mine = fsTurn(box);
  box.replaceChildren(h("p", { class: "muted small" }, "Working it out…"));
  const e = await api(FS_BASE + "/effective?host_id=" + encodeURIComponent(st.host) + "&key=" + encodeURIComponent(st.key) + "&sid=" + encodeURIComponent(st.who));
  if (!mine()) return;
  const g = e.grid || [];
  const n = g.filter(r => r.key !== "full" && r.effective).length;
  const col = (title, k) => h("div", { class: "fs-ladder" }, h("p", { class: "small" }, h("strong", null, title)),
    h("ul", null, g.filter(r => r.key !== "full").map(r => h("li", { class: r[k] ? "fs-on" : "fs-off" },
      h("span", { class: "fs-mark", "aria-hidden": "true" }, r[k] ? "✓" : "–"), r.label, h("span", { class: "fs-sr" }, r[k] ? ": yes" : ": no")))));
  const yes = v => v ? h("span", { class: "chip chip-ok" }, "Yes") : h("span", { class: "muted" }, "No");
  box.replaceChildren(h("section", { class: "fs-by fs-who no-enh" },
    h("h4", null, "What " + e.who.name + (e.who.display ? " (" + e.who.display + ")" : "") + " can do in " + e.folder),
    h("p", null, "Share: ", h("strong", null, e.share_level), " · NTFS: ", h("strong", null, e.ntfs_level), " → Effective: ", h("strong", null, e.effective_level),
      e.who.kind === "user" ? h("span", { class: "muted small" }, " · in " + fsNum(e.who.groups) + " group" + (e.who.groups === 1 ? "" : "s")
        + (e.who.enabled === false ? " · the account is disabled" : "")) : null),
    e.note ? h("p", { class: "muted small" }, e.note) : null,
    h("div", { class: "fs-graph", "aria-label": "Share permissions plus NTFS permissions give the effective permissions" },
      col("Share permissions", "share"), h("span", { class: "fs-sign", "aria-hidden": "true" }, "+"), col("NTFS permissions", "ntfs"),
      h("span", { class: "fs-sign", "aria-hidden": "true" }, "="),
      donut("Effective permissions", [{ label: "Allowed", value: n, cls: "c-ok" }, { label: "Not allowed", value: 13 - n, cls: "c-muted" }],
        { centre: n + "/13", centreLabel: "rights" })),
    table([
      { label: "Permission", cell: r => r.label },
      { label: "Share", cell: r => yes(r.share) },
      { label: "NTFS", cell: r => yes(r.ntfs) },
      { label: "Effective", cell: r => yes(r.effective) },
    ], g),
    h("p", { class: "small" }, h("strong", null, "Through the share: "), (e.through_share || []).length
      ? e.through_share.map(x => x.name + " (" + (x.allow ? "" : "deny ") + x.right + ")").join("; ") : "nothing: no share permission names it or a group it is in."),
    h("p", { class: "small" }, h("strong", null, "Through NTFS: "), (e.through_ntfs || []).length
      ? e.through_ntfs.map(x => x.name + " (" + (x.allow ? "" : "deny ") + x.level + (x.inherited ? ", inherited" : "") + ")").join("; ")
      : "nothing: no NTFS entry on the folder names it or a group it is in.")));
}
