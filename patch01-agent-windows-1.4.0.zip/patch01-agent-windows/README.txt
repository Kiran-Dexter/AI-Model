PATCH-01 agent for Windows Server (agent 1.4.0-win)
===================================================

Extract this folder on the server, open PowerShell as administrator in it, and run:

    powershell -ExecutionPolicy Bypass -File .\Setup-Agent.ps1 -CaFile C:\temp\corp-chain.pem

An existing agent is upgraded in place (identity kept, no token needed).
Do not upgrade while a patch job is running on this server.

1.4.0: the precheck checks everything a job needs before anything changes,
tests where each update file downloads from, and downloads the updates
during the precheck with progress; a stalled download stops with the reason.
