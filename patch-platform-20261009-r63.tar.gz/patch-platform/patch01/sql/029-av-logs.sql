-- ===========================================================================
-- PATCH-01 : schema 029 - antivirus logs from Apex Central (read-only)
--
-- Applied after 028. Idempotent.
--
-- Two kinds of log are read through Apex Central's Automation API:
--
--   Pattern Update Status   each endpoint's pattern versions and how many
--                           versions old they are (0 = up to date ... 7 =
--                           seven or more), as Apex Central judges it
--   Detections              virus/malware, and the other detection logs the
--                           console offers (spyware, behaviour monitoring,
--                           machine learning, C&C callbacks, web threats)
--
-- Log types are discovered per console: a type the console does not offer is
-- recorded as unavailable and tried again daily. Detections are kept 90 days.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS av_pattern_status (
    console_id   UUID NOT NULL REFERENCES av_consoles(id) ON DELETE CASCADE,
    host_name    TEXT NOT NULL,
    pattern      TEXT NOT NULL,          -- "Virus Pattern", "Smart Scan Agent Pattern"...
    ip           TEXT,
    os           TEXT,
    domain       TEXT,
    product      TEXT,
    version      TEXT,
    versions_old INTEGER,                -- 0 up to date ... 7 seven or more versions old
    connection   TEXT,                   -- Apex Central's connection status code, as sent
    log_time     TIMESTAMPTZ,
    seen_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (console_id, host_name, pattern)
);

CREATE TABLE IF NOT EXISTS av_detections (
    console_id   UUID NOT NULL REFERENCES av_consoles(id) ON DELETE CASCADE,
    log_type     TEXT NOT NULL,
    log_id       BIGINT NOT NULL,
    occurred_at  TIMESTAMPTZ,
    host_name    TEXT,
    ip           TEXT,
    user_name    TEXT,
    threat       TEXT,                   -- malware / rule name, as sent (untrusted text)
    category     TEXT NOT NULL,          -- malware, ransomware, spyware, behaviour, machine_learning, c2, web
    action       TEXT,
    result       TEXT,
    unresolved   BOOLEAN NOT NULL DEFAULT false,
    severity     TEXT,
    file_path    TEXT,
    sha1         TEXT,
    count        INTEGER NOT NULL DEFAULT 1,
    product      TEXT,
    fetched_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (console_id, log_type, log_id)
);
CREATE INDEX IF NOT EXISTS idx_av_detections_time ON av_detections (occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_av_detections_host ON av_detections (lower(host_name));

CREATE TABLE IF NOT EXISTS av_log_state (
    console_id   UUID NOT NULL REFERENCES av_consoles(id) ON DELETE CASCADE,
    log_type     TEXT NOT NULL,
    available    BOOLEAN,                -- NULL: not tried yet
    last_id      BIGINT NOT NULL DEFAULT 0,
    last_ok_at   TIMESTAMPTZ,
    checked_at   TIMESTAMPTZ,
    rows_last    INTEGER,
    error        TEXT,
    PRIMARY KEY (console_id, log_type)
);

-- Each threat summary with the figures it was written from, so every sentence can be checked
CREATE TABLE IF NOT EXISTS av_threat_summaries (
    id          BIGSERIAL PRIMARY KEY,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    days        INTEGER NOT NULL,
    facts       JSONB NOT NULL,
    text        TEXT NOT NULL,
    source      TEXT NOT NULL CHECK (source IN ('ai', 'facts')),
    model       TEXT
);
CREATE INDEX IF NOT EXISTS idx_av_threat_summaries ON av_threat_summaries (created_at DESC);

-- The daily threat summary, written by AI-01 from the figures (figures kept with it)
INSERT INTO report_schedules (name, report, format, frequency, at_time, params, builtin, created_by)
SELECT 'Antivirus threats, daily summary', 'av_threats', 'pdf', 'daily', '08:05', '{"days": 1}'::jsonb, true, 'system'
 WHERE NOT EXISTS (SELECT 1 FROM report_schedules WHERE builtin AND report = 'av_threats');

INSERT INTO schema_version (version, description)
VALUES (29, 'Antivirus logs from Apex Central: pattern status and detections; daily threat summary')
ON CONFLICT (version) DO NOTHING;
