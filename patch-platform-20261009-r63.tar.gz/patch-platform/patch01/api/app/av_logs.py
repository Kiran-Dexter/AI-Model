"""Antivirus logs from Apex Central, read-only.

    GET /WebApp/api/v1/Logs/{log type}?output_format=CEF&page_token=N&since_time=EPOCH

Signed like every Apex Central request (antivirus.token): the query string is
part of the checksum. page_token is the log ID to start from (it must be 0
for the Pattern Update Status log, which is read whole each time).

Log types differ between Apex Central versions and licences, so each type is
tried once and remembered as available or not (av_log_state); one that is
not offered is tried again the next day. Everything read from the logs is
untrusted text: fields are cut to size, and malware and host names reach
AI-01 only inside a fenced data block.

CEF fields used (Trend Micro, "CEF Pattern Update Status Logs" and "CEF
Virus/Malware Logs"):
    pattern status: shost, cs2 (IP), msg (pattern name), cs5 (version),
                    cn3 (0 up to date ... 7 seven or more versions old),
                    cn1 (connection status), cs1 (OS), cs4 (domain), rt
    detections:     deviceExternalId (log ID), rt, dhost, dst, duser,
                    header name (threat), act, cs5/cs6 (action results),
                    filePath/fname, fileHash, cnt, severity
"""

import logging
import re
import time
from datetime import datetime, timezone

log = logging.getLogger("patchapi.av_logs")

LOGS_PATH = "/WebApp/api/v1/Logs/"
PATTERN_TYPES = ("pattern_updated_status", "pattern_update_status")      # names differ by version
DETECTION_TYPES = {                 # log type -> category
    "officescan_virus": "malware",
    "spyware": "spyware",
    "behavior_monitoring": "behaviour",
    "predictive_machine_learning": "machine_learning",
    "c_and_c_callback": "c2",
    "web_security": "web",
}
CATEGORY_WORDS = {"malware": "Virus/malware", "ransomware": "Ransomware", "spyware": "Spyware/grayware",
                  "behaviour": "Behaviour monitoring", "machine_learning": "Machine learning",
                  "c2": "C&C callback", "web": "Web threat"}
PAGES_PER_RUN = 20
KEEP_DAYS = 90
FIRST_DAYS = 7                      # how far back the first read of a console goes
RETRY_UNAVAILABLE_HOURS = 24
RANSOM = re.compile(r"ransom|crypt(o)?lock|wannacry|ryuk|lockbit|conti\b|blackcat|unauthori[sz]ed (file )?encryption", re.I)
UNRESOLVED = re.compile(r"unable|fail|could not|cannot|not (cleaned|quarantined|deleted)|passed|pass\b|deferred|access denied", re.I)
RESOLVED = re.compile(r"cleaned|quarantined|deleted|blocked|restricted|terminated|denied access|prevented", re.I)


# ---------------------------------------------------------------------------
# CEF
# ---------------------------------------------------------------------------

def _unescape(v, header=False):
    v = v.replace("\\\\", "\x00")
    v = v.replace("\\|", "|") if header else v.replace("\\=", "=").replace("\\n", " ").replace("\\r", " ")
    return v.replace("\x00", "\\")


def parse_cef(line):
    """'CEF:0|Vendor|Product|Version|EventID|Name|Severity|k=v k=v ...' -> dict, or None."""
    if not isinstance(line, str):
        return None
    line = line.strip()[:16384]
    i = line.find("CEF:")
    if i < 0:
        return None
    line = line[i:]
    parts, cur, esc = [], "", False
    rest = None
    for n, ch in enumerate(line):
        if esc:
            cur += ch
            esc = False
        elif ch == "\\":
            cur += ch
            esc = True
        elif ch == "|" and len(parts) < 7:
            parts.append(cur)
            cur = ""
            if len(parts) == 7:
                rest = line[n + 1:]
                break
        else:
            cur += ch
    if len(parts) < 7 or rest is None:
        return None
    out = {"_vendor": _unescape(parts[1], True), "_product": _unescape(parts[2], True),
           "_event_id": _unescape(parts[4], True), "_name": _unescape(parts[5], True), "_severity": _unescape(parts[6], True)}
    # Extension: key=value, a value runs to the next unescaped " key="
    for m in re.finditer(r"(?:^|(?<=\s))([A-Za-z0-9_.]{1,40})=((?:\\.|[^\\])*?)(?=\s+[A-Za-z0-9_.]{1,40}=|$)", rest):
        out[m.group(1)] = _unescape(m.group(2)).strip()[:2000]
    return out


def cef_lines(obj, out=None, depth=0):
    """Every CEF line anywhere in Apex Central's answer, in order."""
    out = [] if out is None else out
    if depth > 6 or len(out) > 20000:
        return out
    if isinstance(obj, str):
        if "CEF:" in obj:
            out.extend(x for x in obj.splitlines() if "CEF:" in x)
    elif isinstance(obj, list):
        for x in obj[:20000]:
            cef_lines(x, out, depth + 1)
    elif isinstance(obj, dict):
        for x in obj.values():
            cef_lines(x, out, depth + 1)
    return out


def cef_time(v):
    """'Nov 02 2017 12:46:44 GMT+00:00', an epoch in ms or s -> aware datetime, or None."""
    if not v:
        return None
    v = str(v).strip()
    try:
        if re.fullmatch(r"\d{10,13}", v):
            n = int(v)
            return datetime.fromtimestamp(n / 1000 if n > 1e11 else n, timezone.utc)
        m = re.match(r"([A-Z][a-z]{2} \d{1,2} \d{4} \d{2}:\d{2}:\d{2})(?: GMT([+-])(\d{2}):?(\d{2}))?", v)
        if m:
            d = datetime.strptime(m.group(1), "%b %d %Y %H:%M:%S").replace(tzinfo=timezone.utc)
            if m.group(2):          # "GMT+08:00": the clock was 8 h ahead of UTC
                off = (int(m.group(3)) * 60 + int(m.group(4))) * (1 if m.group(2) == "+" else -1)
                d = datetime.fromtimestamp(d.timestamp() - off * 60, timezone.utc)
            return d
    except (ValueError, OverflowError, OSError):
        return None
    return None


def _s(v, n=255):
    v = ("" if v is None else str(v)).strip()
    return re.sub(r"[\x00-\x1f\x7f]", " ", v)[:n] or None


# ---------------------------------------------------------------------------
# Rows
# ---------------------------------------------------------------------------

def pattern_row(c):
    host = _s(c.get("shost") or c.get("dhost"), 255)
    pattern = _s(c.get("msg") or c.get("cn2") or "pattern", 120)
    if not host:
        return None
    try:
        old = int(str(c.get("cn3", "")).strip())
        old = old if 0 <= old <= 7 else None
    except ValueError:
        old = None
    return {"host_name": host, "pattern": pattern, "ip": _s(c.get("cs2") or c.get("dst"), 45), "os": _s(c.get("cs1"), 120),
            "domain": _s(c.get("cs4"), 120), "product": _s(c.get("deviceFacility"), 80), "version": _s(c.get("cs5"), 40),
            "versions_old": old, "connection": _s(c.get("cn1"), 20), "log_time": cef_time(c.get("rt"))}


def detection_row(c, log_type):
    try:
        lid = int(str(c.get("deviceExternalId") or "").strip())
    except ValueError:
        return None
    threat = _s(c.get("_name"), 200)
    texts = " ".join(str(c.get(k) or "") for k in ("act", "cs5", "cs6", "outcome"))
    cat = DETECTION_TYPES.get(log_type, "malware")
    if RANSOM.search(threat or "") or (cat == "behaviour" and RANSOM.search(" ".join(str(v) for v in c.values()))):
        cat = "ransomware"
    try:
        cnt = max(1, min(100000, int(str(c.get("cnt") or 1))))
    except ValueError:
        cnt = 1
    return {"log_id": lid, "occurred_at": cef_time(c.get("rt")), "host_name": _s(c.get("dhost") or c.get("shost"), 255),
            "ip": _s(c.get("dst") or c.get("src"), 45), "user_name": _s(c.get("duser") or c.get("suser"), 120),
            "threat": threat, "category": cat, "action": _s(c.get("act"), 120),
            "result": _s(" / ".join(x for x in (c.get("cs5"), c.get("cs6")) if x), 200),
            "unresolved": bool(UNRESOLVED.search(texts)) and not RESOLVED.search(texts),
            "severity": _s(c.get("_severity"), 10),
            "file_path": _s(c.get("filePath") or c.get("fname"), 500), "sha1": _s(c.get("fileHash"), 64),
            "count": cnt, "product": _s(c.get("deviceFacility") or c.get("_product"), 80)}


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

def fetch(console, api_key, log_type, page_token, since):
    from . import antivirus as av
    if not re.fullmatch(r"[a-z_]{3,40}", log_type):
        raise av.AvError("bad log type")
    raw = f"{LOGS_PATH}{log_type}?output_format=CEF&page_token={int(page_token)}&since_time={int(since)}"
    return cef_lines(av._get(console, api_key, raw))


def _state(conn, cid, lt):
    r = conn.execute("SELECT * FROM av_log_state WHERE console_id = %s AND log_type = %s", (cid, lt)).fetchone()
    return dict(r) if r else {"available": None, "last_id": 0, "checked_at": None}


def _save_state(conn, cid, lt, **kw):
    conn.execute(
        """INSERT INTO av_log_state (console_id, log_type, available, last_id, last_ok_at, checked_at, rows_last, error)
           VALUES (%s, %s, %s, %s, CASE WHEN %s THEN now() END, now(), %s, %s)
           ON CONFLICT (console_id, log_type) DO UPDATE SET available = EXCLUDED.available,
             last_id = GREATEST(av_log_state.last_id, EXCLUDED.last_id),
             last_ok_at = coalesce(EXCLUDED.last_ok_at, av_log_state.last_ok_at), checked_at = now(),
             rows_last = EXCLUDED.rows_last, error = EXCLUDED.error""",
        (cid, lt, kw.get("available"), int(kw.get("last_id") or 0), bool(kw.get("available")), kw.get("rows"),
         (kw.get("error") or None) and str(kw["error"])[:300]))


def _due_type(st):
    if st["available"] is False and st["checked_at"] is not None:
        return (time.time() - st["checked_at"].timestamp()) > RETRY_UNAVAILABLE_HOURS * 3600 \
            if hasattr(st["checked_at"], "timestamp") else True
    return True


def _not_offered(e):
    return "404" in str(e) or "result code" in str(e)


def read_patterns(conn, c, key):
    from . import antivirus as av
    cid = c["id"]
    for lt in PATTERN_TYPES:
        st = _state(conn, cid, lt)
        if not _due_type(st):
            continue
        try:
            lines = fetch(c, key, lt, 0, time.time() - 30 * 86400)
        except av.AvError as e:
            _save_state(conn, cid, lt, available=False if _not_offered(e) else st["available"], error=e)
            conn.commit()
            continue
        rows = [r for r in (pattern_row(parse_cef(x) or {}) for x in lines) if r]
        latest = {}
        for r in rows:                          # newest record per host and pattern
            k = (r["host_name"].lower(), r["pattern"])
            if k not in latest or (r["log_time"] or datetime.min.replace(tzinfo=timezone.utc)) >= \
                    (latest[k]["log_time"] or datetime.min.replace(tzinfo=timezone.utc)):
                latest[k] = r
        with conn.transaction():
            with conn.cursor() as cur:
                cur.executemany(
                    """INSERT INTO av_pattern_status (console_id, host_name, pattern, ip, os, domain, product, version,
                                                      versions_old, connection, log_time, seen_at)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, now())
                       ON CONFLICT (console_id, host_name, pattern) DO UPDATE SET ip = EXCLUDED.ip, os = EXCLUDED.os,
                         domain = EXCLUDED.domain, product = EXCLUDED.product, version = EXCLUDED.version,
                         versions_old = EXCLUDED.versions_old, connection = EXCLUDED.connection,
                         log_time = EXCLUDED.log_time, seen_at = now()""",
                    [(cid, r["host_name"], r["pattern"], r["ip"], r["os"], r["domain"], r["product"], r["version"],
                      r["versions_old"], r["connection"], r["log_time"]) for r in latest.values()])
            conn.execute("DELETE FROM av_pattern_status WHERE console_id = %s AND seen_at < now() - interval '7 days'", (cid,))
            _save_state(conn, cid, lt, available=True, rows=len(latest))
        conn.commit()
        return len(latest)
    return None


def read_detections(conn, c, key):
    from . import antivirus as av
    cid, total = c["id"], 0
    for lt in DETECTION_TYPES:
        st = _state(conn, cid, lt)
        if not _due_type(st):
            continue
        since = time.time() - FIRST_DAYS * 86400
        token, got, err = int(st["last_id"] or 0) + (1 if st["last_id"] else 0), 0, None
        try:
            for _ in range(PAGES_PER_RUN):
                lines = fetch(c, key, lt, token, since)
                rows = [r for r in (detection_row(parse_cef(x) or {}, lt) for x in lines) if r and r["log_id"] >= token]
                if not rows:
                    break
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.executemany(
                            """INSERT INTO av_detections (console_id, log_type, log_id, occurred_at, host_name, ip, user_name,
                                                          threat, category, action, result, unresolved, severity, file_path,
                                                          sha1, count, product)
                               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                               ON CONFLICT (console_id, log_type, log_id) DO NOTHING""",
                            [(cid, lt, r["log_id"], r["occurred_at"], r["host_name"], r["ip"], r["user_name"], r["threat"],
                              r["category"], r["action"], r["result"], r["unresolved"], r["severity"], r["file_path"],
                              r["sha1"], r["count"], r["product"]) for r in rows])
                    top = max(r["log_id"] for r in rows)
                    _save_state(conn, cid, lt, available=True, last_id=top, rows=len(rows))
                conn.commit()
                got += len(rows)
                token = top + 1
        except av.AvError as e:
            err = e
        if err is not None:
            _save_state(conn, cid, lt, available=False if _not_offered(err) and not got else (st["available"] or bool(got)),
                        error=err, last_id=token - 1 if got else st["last_id"])
        elif not got:
            _save_state(conn, cid, lt, available=True, rows=0)
        conn.commit()
        total += got
    conn.execute("DELETE FROM av_detections WHERE occurred_at < now() - make_interval(days => %s::int)", (KEEP_DAYS,))
    conn.commit()
    return total


def sync_logs(conn, cid):
    """Pattern status and new detections for one console. Never raises."""
    from . import antivirus as av
    c = conn.execute("SELECT * FROM av_consoles WHERE id = %s AND enabled", (cid,)).fetchone()
    if not c:
        return None
    c = dict(c)
    conn.commit()
    try:
        key = av.decrypt(c["api_key_enc"])
        p = read_patterns(conn, c, key)
        d = read_detections(conn, c, key)
        return {"patterns": p, "detections": d}
    except Exception as e:  # noqa: BLE001 - logs are extra; the agent list still stands
        conn.rollback()
        log.warning("antivirus logs for %s: %s", c["name"], e if isinstance(e, av.AvError) else type(e).__name__)
        return None


def availability(conn, cid):
    return [dict(r) for r in conn.execute(
        """SELECT log_type, available, rows_last, last_ok_at, checked_at, error FROM av_log_state
            WHERE console_id = %s ORDER BY log_type""", (cid,)).fetchall()]
