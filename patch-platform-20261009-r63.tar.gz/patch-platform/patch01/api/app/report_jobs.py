"""Reports built on the server, for e-mail at once or on a schedule.

Each report is built from the database at the time it is sent (never from a
browser), rendered as PDF or CSV with the branded heading (exports.py), and
queued inside the usual branded mail (notify.render) with a summary and the
first rows in the body. The worker sends the queue every minute and retries
on failure; the attachment is removed from the database once delivered.

Recipients are only ever addresses from Admin > Mail's recipient list.
"""

import logging
from datetime import datetime, timedelta, timezone

log = logging.getLogger("patchapi.reports")

MAX_ATTACHMENT = 10 * 2 ** 20
PREVIEW_ROWS = 25
WEEKDAYS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")

ADVISORIES_SQL = """SELECT * FROM (
                 SELECT a.id, a.vendor, a.title, lower(coalesce(a.severity, '')) AS severity, a.issued_at,
                        a.os_id, a.os_major, 'advisory' AS source,
                        count(DISTINCT ha.host_id) FILTER (WHERE ha.state = 'affected') AS servers_affected,
                        count(DISTINCT ha.host_id) FILTER (WHERE ha.state = 'fixed_pending_reboot') AS servers_reboot,
                        max(r.max_cvss) AS max_cvss, bool_or(coalesce(r.any_kev, false)) AS exploited,
                        (SELECT array_agg(ac.cve_id ORDER BY ac.cve_id) FROM advisory_cves ac WHERE ac.advisory_id = a.id) AS cves
                   FROM advisories a
                   JOIN host_applicability ha ON ha.advisory_id = a.id AND ha.state IN ('affected', 'fixed_pending_reboot')
                   JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'
                   LEFT JOIN v_advisory_risk r ON r.advisory_id = a.id
                  GROUP BY a.id
                 UNION ALL
                 SELECT w.k, 'microsoft', max(w.title), lower(coalesce(max(w.severity), '')),
                        NULL::date, 'windows', NULL::int, 'windows_update',
                        count(DISTINCT w.host_id), 0, NULL::numeric, false,
                        (SELECT array_agg(DISTINCT c ORDER BY c) FROM windows_updates w2, unnest(w2.cves) c
                          WHERE coalesce(w2.kb, w2.update_id) = w.k)
                   FROM (SELECT coalesce(wu.kb, wu.update_id) AS k, wu.title, wu.severity, wu.host_id
                           FROM windows_updates wu JOIN hosts h ON h.id = wu.host_id AND h.status <> 'decommissioned') w
                  GROUP BY w.k
               ) x
              ORDER BY exploited DESC,
                       CASE severity WHEN 'critical' THEN 1 WHEN 'important' THEN 2 WHEN 'high' THEN 2
                                     WHEN 'moderate' THEN 3 WHEN 'medium' THEN 3 ELSE 4 END,
                       servers_affected DESC, id
              LIMIT 2000"""


class ReportError(ValueError):
    pass


def _int(params, key, lo, hi, default):
    try:
        v = int(params.get(key, default))
    except (TypeError, ValueError):
        v = default
    return max(lo, min(hi, v))


def _when(v, tz):
    if not v:
        return ""
    if isinstance(v, str):
        try:
            v = datetime.fromisoformat(v.replace("Z", "+00:00"))
        except ValueError:
            return v
    return v.astimezone(tz).strftime("%d %b %Y %H:%M")


def _ago(v, now):
    if not v:
        return None
    if isinstance(v, str):
        v = datetime.fromisoformat(v.replace("Z", "+00:00"))
    return (now - v).total_seconds() / 3600.0


# ---------------------------------------------------------------------------
# The reports. Each returns a dict: title, headers, rows, filter, intro,
# stats [(label, value, severity)], severity, sections [(heading, headers, rows)]
# ---------------------------------------------------------------------------

def r_servers(conn, params, tz):
    from . import servers
    f = servers.clean_filters(**{k: params.get(k) for k in ("q", "os", "group", "version", "agent", "patch")})
    rows = servers.all_rows(conn, f, "name")
    headers = [label for _, label in servers.EXPORT_COLUMNS]
    data = [[servers.export_value(k, r.get(k)) for k, _ in servers.EXPORT_COLUMNS] for r in rows]
    online = sum(1 for r in rows if r["agent"] == "online")
    need = sum(1 for r in rows if r["needs_patch"] or r["windows_updates_missing"])
    reboot = sum(1 for r in rows if r["reboot_required"] or r["pending_reboot"])
    return {"title": "Servers", "headers": headers, "rows": data, "filter": servers.describe_filters(f),
            "intro": f"{len(rows)} servers: {online} online, {len(rows) - online} offline; {need} need patches, "
                     f"{reboot} wait for a reboot.",
            "stats": [("Servers", len(rows), "info"), ("Offline", len(rows) - online, "warning" if len(rows) - online else "ok"),
                      ("Need patches", need, "warning" if need else "ok"), ("Reboot", reboot, "warning" if reboot else "ok")],
            "severity": "warning" if need or len(rows) - online else "ok",
            "preview": (["Server", "Agent", "Operating system", "Advisories to install", "Windows updates missing"],
                        [[r["hostname"], r["agent"], r["os_label"], r["needs_patch"], r["windows_updates_missing"]]
                         for r in rows if r["agent"] != "online" or r["needs_patch"] or r["windows_updates_missing"]])}


VERDICT_WORDS = {"affected": "Affected", "pending_reboot": "Fixed, reboot needed", "potentially_affected": "Possibly affected",
                 "not_found": "Not found", "not_tracked": "Not inventoried", "not_affected": "Not affected"}


def r_impact(conn, params, tz):
    from . import cve_feeds, cve_impact
    days = int(cve_feeds.settings(conn).get("days_back") or 14)
    verdict = params.get("verdict") if params.get("verdict") in VERDICT_WORDS else None
    items = cve_impact.listing(conn, days, verdict, limit=2000)
    headers = ["CVE", "Severity", "CVSS", "0-day", "Verdict", "Machines", "Applies to",
               "Where found (machine, address, OS, certainty)", "From", "Published", "Title"]
    rows = []
    for i in items:
        ms = [m for m in (i["matches"] or []) if m.get("name")][:12]
        rows.append([i["cve_id"], i["severity"] or "", i["cvss"], "yes" if i["exploited"] else "",
                     VERDICT_WORDS.get(i["verdict"], i["verdict"]), i["machines"], ", ".join(i.get("platforms") or []),
                     "; ".join(f"{m['name']}" + (f" {m['ip']}" if m.get("ip") else "") + (f" [{m['os']}]" if m.get("os") else "")
                               + f" ({str(m.get('certainty')).replace('_', ' ')})" for m in ms),
                     ", ".join(i["sources"] or []), _when(i["published"], tz)[:11], i["title"] or ""])
    aff = [i for i in items if i["verdict"] == "affected"]
    poss = [i for i in items if i["verdict"] == "potentially_affected"]
    zero = [i for i in items if i["exploited"] and i["verdict"] in ("affected", "potentially_affected")]
    return {"title": "Detected CVEs", "headers": headers, "rows": rows,
            "filter": f"last {days} days" + (f"; {VERDICT_WORDS[verdict].lower()}" if verdict else ""),
            "intro": f"{len(aff)} CVEs affect our machines and {len(poss)} possibly do"
                     + (f"; {len(zero)} of them are exploited in the wild." if zero else "."),
            "stats": [("Affected", len(aff), "critical" if aff else "ok"), ("Possibly", len(poss), "warning" if poss else "ok"),
                      ("0-day", len(zero), "critical" if zero else "ok")],
            "severity": "critical" if zero else ("warning" if aff or poss else "ok"),
            "preview": (["CVE", "Severity", "Verdict", "Machines", "Title"],
                        [[i["cve_id"], ("0-day" if i["exploited"] else (i["severity"] or "")), VERDICT_WORDS.get(i["verdict"], ""),
                          i["machines"], i["title"] or ""] for i in aff + poss])}


def r_advisories(conn, params, tz):
    rows = conn.execute(ADVISORIES_SQL).fetchall()
    if params.get("exploited_only"):
        rows = [r for r in rows if r["exploited"]]
    headers = ["Advisory", "Kind", "Severity", "Exploited", "Servers to install", "Servers awaiting reboot", "Worst CVSS",
               "Issued", "CVEs", "Title"]
    data = [[r["id"], "Windows update" if r["source"] == "windows_update" else f"{(r['os_id'] or '').upper()} {r['os_major'] or ''}".strip(),
             r["severity"], "yes" if r["exploited"] else "", r["servers_affected"], r["servers_reboot"], r["max_cvss"],
             _when(r["issued_at"], tz)[:11] if r["issued_at"] else "", " ".join((r["cves"] or [])[:20]), r["title"] or ""]
            for r in rows]
    ex = sum(1 for r in rows if r["exploited"])
    return {"title": "Advisories to install", "headers": headers, "rows": data,
            "filter": "exploited only" if params.get("exploited_only") else "all",
            "intro": f"{len(rows)} advisories and Windows updates are still to install" + (f", {ex} with an exploited CVE." if ex else "."),
            "stats": [("To install", len(rows), "warning" if rows else "ok"), ("Exploited", ex, "critical" if ex else "ok")],
            "severity": "critical" if ex else ("warning" if rows else "ok"),
            "preview": (["Advisory", "Severity", "Servers", "Title"],
                        [[r["id"], ("exploited " if r["exploited"] else "") + (r["severity"] or ""), r["servers_affected"],
                          r["title"] or ""] for r in rows])}


def r_av_agents(conn, params, tz):
    from . import antivirus as av
    agents, _ = av.coverage(conn)
    headers = ["Name", "Address", "Domain", "Product", "Console", "Definitions", "Last connected", "Isolation",
               "In inventory", "Operating system"]
    rows = [[a["host_name"], " ".join(a["ip_addresses"] or []), a["ad_domain"] or "", a["product_name"], a["console"],
             a.get("pattern_version") or "", _when(a.get("last_connected"), tz), a["isolation_status"] or "",
             "yes" if a["asset"] else "no", (a["asset"] or {}).get("os") or ""] for a in agents]
    return {"title": "Antivirus agents", "headers": headers, "rows": rows, "filter": "all consoles",
            "intro": f"{len(agents)} antivirus agents reported by the consoles.",
            "stats": [("Agents", len(agents), "info"), ("Not in inventory", sum(1 for a in agents if not a["asset"]), "info")],
            "severity": "info", "preview": (headers[:5], rows)}


def r_av_unprotected(conn, params, tz):
    from . import antivirus as av
    _, unprot = av.coverage(conn)
    headers = ["Name", "Address", "Operating system", "Known from"]
    rows = [[m["name"], " ".join(m["ips"] or []), m["os"] or "", ", ".join(m["sources"] or [])] for m in unprot]
    return {"title": "Machines with no antivirus agent", "headers": headers, "rows": rows, "filter": "all machines",
            "intro": f"{len(rows)} machines in the inventory are not listed by any antivirus console.",
            "stats": [("No antivirus", len(rows), "critical" if rows else "ok")],
            "severity": "critical" if rows else "ok", "preview": (headers, rows)}


def av_health_rows(conn, params, now=None):
    """The antivirus problems: definitions behind, agents offline, agents no
    longer listed, machines with no agent. Each row says how it was judged."""
    from . import antivirus as av
    now = now or datetime.now(timezone.utc)
    off_h = _int(params, "offline_hours", 1, 720, 24)
    behind = _int(params, "pattern_behind", 1, 50, 4)
    vold = _int(params, "versions_old", 1, 7, 2)
    agents, unprot = av.coverage(conn)
    # Apex Central's own judgement, from its Pattern Update Status log, when it is read (schema 029)
    pstat = {}
    try:
        with conn.transaction():
            for r in conn.execute(
                    """SELECT console_id::text AS cid, lower(host_name) AS h, pattern, version, versions_old
                         FROM av_pattern_status WHERE versions_old IS NOT NULL""").fetchall():
                k = (r["cid"], r["h"].split(".")[0])
                if k not in pstat or r["versions_old"] > pstat[k]["versions_old"]:
                    pstat[k] = dict(r)
    except Exception:  # noqa: BLE001 - schema 029 not applied: versions are compared instead
        pstat = {}
    newest, newest_txt = {}, {}
    for a in agents:
        k = av.pattern_key(a.get("pattern_version"))
        if k and (a["product_name"] not in newest or k > newest[a["product_name"]]):
            newest[a["product_name"]], newest_txt[a["product_name"]] = k, a["pattern_version"]
    outdated, offline, missing = [], [], []
    for a in agents:
        ass = a["asset"] or {}
        base = [a["host_name"], " ".join(a["ip_addresses"] or []), a["product_name"], a["console"], ass.get("os") or ""]
        if a["not_reported"]:
            missing.append(base + [a.get("pattern_version") or "", "",
                                   "Apex Central no longer lists this agent (last listed " + _when(a["last_seen"], TZ) + ")"])
            continue
        k, top = av.pattern_key(a.get("pattern_version")), newest.get(a["product_name"])
        ps = pstat.get((str(a.get("console_id")), (a["host_name"] or "").lower().split(".")[0]))
        if ps:
            if ps["versions_old"] >= vold:
                outdated.append(base + [ps["version"] or "", "",
                                        f"Apex Central: {ps['pattern']} is "
                                        + ("7 or more versions old" if ps["versions_old"] >= 7 else f"{ps['versions_old']} versions old")])
        elif k and top and (k[0] < top[0] or (len(k) > 1 and len(top) > 1 and top[1] - k[1] > behind)):
            outdated.append(base + [a["pattern_version"], newest_txt[a["product_name"]],
                                    f"{top[1] - k[1] if k[0] == top[0] else 'a major version'} releases behind the newest seen"])
        why = None
        lc = _ago(a.get("last_connected"), now)
        if lc is not None:
            if lc > off_h:
                why = f"Apex Central: last connected {_when(a['last_connected'], TZ)} ({int(lc)} h ago)"
        elif a.get("online") is False:
            why = "Apex Central reports it offline"
        elif ass:
            # No connection data from Apex Central: judged from what the inventory knows of the machine
            seen = [x for x in ((ass.get("agent_seen"), "our agent"), (ass.get("wsus_seen"), "WSUS")) if x[0]]
            recent = [x for x in seen if (_ago(x[0], now) or 1e9) <= off_h]
            if ass.get("agent") == "online" or recent:
                why = None
            elif ass.get("power") == "poweredOff":
                why = "the machine is powered off in vCenter"
            elif seen:
                last, src = max(seen, key=lambda x: x[0] if not isinstance(x[0], str) else datetime.fromisoformat(x[0]))
                why = f"the machine has not been seen for over {off_h} h ({src} last {_when(last, TZ)})"
        if why:
            offline.append(base + [a.get("pattern_version") or "", _when(a.get("last_connected"), TZ), why])
    unprotected = [[m["name"], " ".join(m["ips"] or []), "", "", m["os"] or "", "", "",
                    "known from " + ", ".join(m["sources"] or []) + "; no antivirus console lists it"] for m in unprot]
    return {"outdated": outdated, "offline": offline, "missing": missing, "unprotected": unprotected,
            "agents": len(agents), "with_versions": sum(1 for a in agents if a.get("pattern_version")),
            "with_connection": sum(1 for a in agents if a.get("last_connected") or a.get("online") is not None),
            "off_h": off_h, "behind": behind, "vold": vold}


TZ = timezone(timedelta(hours=8))


def r_av_health(conn, params, tz):
    h = av_health_rows(conn, params)
    with_unprot = params.get("include_unprotected", True) is not False
    headers = ["Problem", "Name", "Address", "Product", "Console", "Operating system", "Definitions", "Newest / last connected", "Detail"]
    rows = ([["Definitions outdated"] + r[:7] + [r[7]] for r in h["outdated"]]
            + [["Offline"] + r for r in h["offline"]]
            + [["No longer listed"] + r for r in h["missing"]]
            + ([["No antivirus"] + r for r in h["unprotected"]] if with_unprot else []))
    notes = []
    if h["agents"] and not h["with_versions"]:
        notes.append("The consoles did not report definition versions through their API, so outdated definitions "
                     "cannot be checked yet (see Admin > Antivirus for the fields each console sends).")
    if h["agents"] and not h["with_connection"]:
        notes.append("The consoles did not report connection times, so an agent is counted offline when its machine "
                     "has not been seen by our agent or WSUS for " + str(h["off_h"]) + " hours, or is powered off.")
    bad = len(h["outdated"]) + len(h["offline"])
    sev = "critical" if (with_unprot and h["unprotected"]) or len(h["offline"]) > 5 else ("warning" if bad or h["missing"] else "ok")
    stats = [("Agents", h["agents"], "info"), ("Definitions outdated", len(h["outdated"]), "warning" if h["outdated"] else "ok"),
             ("Offline", len(h["offline"]), "warning" if h["offline"] else "ok")]
    if with_unprot:
        stats.append(("No antivirus", len(h["unprotected"]), "critical" if h["unprotected"] else "ok"))
    sections = [("Definitions outdated", ["Name", "Product", "Definitions", "Newest seen", "Detail"],
                 [[r[0], r[2], r[5], r[6], r[7]] for r in h["outdated"]]),
                ("Offline", ["Name", "Address", "Product", "Why"], [[r[0], r[1], r[2], r[7]] for r in h["offline"]]),
                ("No longer listed by Apex Central", ["Name", "Product", "Detail"], [[r[0], r[2], r[7]] for r in h["missing"]])]
    if with_unprot:
        sections.append(("Machines with no antivirus", ["Name", "Address", "Operating system", "Detail"],
                         [[r[0], r[1], r[4], r[7]] for r in h["unprotected"]]))
    return {"title": "Antivirus health", "headers": headers, "rows": rows,
            "filter": f"offline after {h['off_h']} h; outdated when Apex Central reports {h['vold']}+ versions old "
                      f"(or, without that log, more than {h['behind']} releases behind the newest seen)",
            "intro": (f"{h['agents']} antivirus agents: {len(h['outdated'])} with outdated definitions, {len(h['offline'])} offline"
                      + (f", {len(h['missing'])} no longer listed" if h["missing"] else "")
                      + (f". {len(h['unprotected'])} machines have no antivirus agent." if with_unprot else ".")),
            "notes": notes, "stats": stats, "severity": sev, "sections": sections}


def r_av_threats(conn, params, tz):
    """Malware and ransomware detections, summarised by AI-01 (the scheduler
    asks for a fresh summary; an e-mail sent from a page uses today's, or the
    plain figures, so the page does not wait for AI-01)."""
    from . import av_threats
    from .av_logs import CATEGORY_WORDS
    days = _int(params, "days", 1, 31, 1)
    if params.get("_fresh_ai"):
        text, source, model, f = av_threats.summarise(conn, days)
    else:
        f = av_threats.facts(conn, days)
        last = av_threats.latest(conn)
        fresh = last and last["days"] == days and (datetime.now(timezone.utc) - last["created_at"]).total_seconds() < 6 * 3600 \
            if last and hasattr(last["created_at"], "tzinfo") else False
        text, source = (last["text"], last["source"]) if fresh else (av_threats.facts_text(f), "facts")
    rows = conn.execute(
        """SELECT d.occurred_at, d.host_name, d.ip, d.user_name, d.threat, d.category, d.action, d.result, d.unresolved,
                  d.file_path, d.sha1, d.count, c.name AS console
             FROM av_detections d JOIN av_consoles c ON c.id = d.console_id
            WHERE d.occurred_at > now() - make_interval(days => %s::int)
            ORDER BY (d.category = 'ransomware') DESC, d.unresolved DESC, d.occurred_at DESC LIMIT 5000""", (days,)).fetchall()
    t = f["totals"]
    paras = [p for p in text.split("\n\n") if p.strip()]
    label = "Summary by AI-01, from the figures below" if source == "ai" else "Summary from the figures (AI-01 not used)"
    sections = [
        ("Ransomware, and threats not cleaned or quarantined", ["When", "Machine", "Threat", "Type", "Action", "Result"],
         [[_when(r["occurred_at"], tz), r["host_name"], r["threat"], CATEGORY_WORDS.get(r["category"], r["category"]),
           r["action"] or "", r["result"] or ""] for r in rows if r["category"] == "ransomware" or r["unresolved"]]),
        ("Top threats", ["Threat", "Type", "Detections", "Machines", "Not cleaned"],
         [[x["threat"], CATEGORY_WORDS.get(x["category"], x["category"]), x["events"], x["machines"], x["unresolved"]]
          for x in f["threats"]]),
        ("Machines with most detections", ["Machine", "Detections", "Threats", "Not cleaned", "Ransomware"],
         [[x["host_name"], x["events"], x["threats"], x["unresolved"], "yes" if x["ransomware"] else ""] for x in f["hosts"]]),
    ]
    notes = [label + ":"] + paras
    if f["logs_missing"]:
        notes.append("Not offered by the console: " + ", ".join(f["logs_missing"]) + " (Admin > Antivirus).")
    if not f["logs_available"]:
        notes.append("No detection log has been read from Apex Central yet: check Admin > Antivirus.")
    return {"title": "Antivirus threats", "headers": ["When", "Machine", "Address", "User", "Threat", "Type", "Action", "Result",
                                                     "Not cleaned", "File", "SHA-1", "Count", "Console"],
            "rows": [[_when(r["occurred_at"], tz), r["host_name"] or "", r["ip"] or "", r["user_name"] or "", r["threat"] or "",
                      CATEGORY_WORDS.get(r["category"], r["category"]), r["action"] or "", r["result"] or "",
                      "yes" if r["unresolved"] else "", r["file_path"] or "", r["sha1"] or "", r["count"], r["console"]]
                     for r in rows],
            "filter": "last 24 hours" if days == 1 else f"last {days} days",
            "intro": "", "notes": notes,
            "stats": [("Detections", t["events"], "warning" if t["events"] else "ok"),
                      ("Machines", t["machines"], "info"),
                      ("Ransomware", t["ransomware"], "critical" if t["ransomware"] else "ok"),
                      ("Not cleaned", t["unresolved"], "critical" if t["unresolved"] else "ok"),
                      ("Outdated", f["outdated"], "warning" if f["outdated"] else "ok"),
                      ("Offline", f["offline"], "warning" if f["offline"] else "ok")],
            "severity": "critical" if t["ransomware"] or t["unresolved"] else ("warning" if t["events"] else "ok"),
            "sections": sections}


def r_activity(conn, params, tz):
    days = _int(params, "days", 1, 31, 1)
    rows = conn.execute(
        """SELECT occurred_at, actor, action, object_type, object_id, detail FROM audit_log
            WHERE occurred_at > now() - make_interval(days => %s) ORDER BY occurred_at DESC LIMIT 5000""", (days,)).fetchall()
    data = [[_when(r["occurred_at"], tz), r["actor"], r["action"].replace("_", " "),
             " ".join(x for x in (r["object_type"], r["object_id"]) if x),
             str(r["detail"] or "")[:200]] for r in rows]
    return {"title": "Activity", "headers": ["When", "Who", "Action", "Object", "Detail"], "rows": data,
            "filter": f"last {days} day" + ("s" if days > 1 else ""),
            "intro": f"{len(rows)} recorded actions in the last {days} day" + ("s." if days > 1 else "."),
            "stats": [("Actions", len(rows), "info")], "severity": "info", "preview": (["When", "Who", "Action"], [d[:3] for d in data])}


# key: (title, builder, modules any-of, admin only)
REPORTS = {
    "av_threats": ("Antivirus threats, AI summary (malware, ransomware)", r_av_threats, {"inventory", "patch"}, False),
    "av_health": ("Antivirus health (outdated definitions, offline)", r_av_health, {"inventory", "patch"}, False),
    "av_agents": ("Antivirus agents", r_av_agents, {"inventory", "patch"}, False),
    "av_unprotected": ("Machines with no antivirus", r_av_unprotected, {"inventory", "patch"}, False),
    "servers": ("Servers", r_servers, {"patch"}, False),
    "impact": ("Detected CVEs", r_impact, {"patch"}, False),
    "advisories": ("Advisories to install", r_advisories, {"patch"}, False),
    "activity": ("Activity (all actions)", r_activity, {"patch", "inventory", "lifecycle"}, True),
}


def catalog(modules, is_admin):
    return [{"key": k, "title": t} for k, (t, _, mods, adm) in REPORTS.items()
            if (is_admin or not adm) and (is_admin or set(modules) & mods)]


def allowed(key, modules, is_admin):
    if key not in REPORTS:
        return False
    _, _, mods, adm = REPORTS[key]
    return is_admin or (not adm and bool(set(modules) & mods))


def build(conn, key, params, tz=TZ):
    if key not in REPORTS:
        raise ReportError("Unknown report.")
    return REPORTS[key][1](conn, params or {}, tz)


# ---------------------------------------------------------------------------
# Mail
# ---------------------------------------------------------------------------

def compose(conn, cfg, rep, fmt, by, period=None):
    """(subject, text, html, attachment or None)."""
    from . import exports as ex, notify as nt
    m = ex.meta(rep["title"], by, rep.get("filter") or "", len(rep["rows"]), ex.company_name(conn))
    data, mime, ext = ex.render(fmt, m, rep["headers"], rep["rows"], conn)
    att = (ex.file_name(rep["title"].lower(), ext), mime, data) if len(data) <= MAX_ATTACHMENT else None
    today = datetime.now(cfg["tz"]).strftime("%a %d %b %Y")
    blocks = []
    if rep.get("stats"):
        blocks.append(("stats", rep["stats"]))
    for n in rep.get("notes") or []:
        blocks.append(("p", n))
    for heading, headers, rows in rep.get("sections") or []:
        blocks.append(("h", f"{heading} ({len(rows)})"))
        blocks.append(("table", headers, [[("" if v is None else str(v))[:120] for v in r] for r in rows[:PREVIEW_ROWS]])
                      if rows else ("p", "None."))
        if len(rows) > PREVIEW_ROWS:
            blocks.append(("p", f"And {len(rows) - PREVIEW_ROWS} more in the attached report."))
    if rep.get("preview") and not rep.get("sections"):
        headers, rows = rep["preview"]
        if rows:
            blocks.append(("h", "Needing attention" if rep["severity"] in ("warning", "critical") else "First rows"))
            blocks.append(("table", headers, [[("" if v is None else str(v))[:120] for v in r] for r in rows[:PREVIEW_ROWS]]))
            if len(rows) > PREVIEW_ROWS:
                blocks.append(("p", f"And {len(rows) - PREVIEW_ROWS} more in the attached report."))
    blocks.append(("p", (f"The full report ({len(rep['rows'])} rows, {fmt.upper()}) is attached." if att else
                         f"The full report is larger than {MAX_ATTACHMENT // 2 ** 20} MB and is not attached: export it from the console.")
                        + (f" {period}." if period else "")))
    title = f"{rep['title']}, {today}"
    text, html = nt.render(cfg, title, rep.get("severity") or "info", rep.get("intro") or "", blocks, link="/", label="Report")
    return f"[PATCH-01] {title}", text, html, att


def recipients_for(cfg, wanted):
    """Only configured recipients; None means the daily digest list."""
    allowed_ = {a.lower(): a for a in cfg["to"]}
    if wanted is None:
        return list(cfg["to_digest"])
    return [allowed_[a.lower()] for a in wanted if isinstance(a, str) and a.lower() in allowed_]


def queue(conn, cfg, key, params, fmt, recipients, by, period=None, skip_empty=False):
    """Build, render and queue one report mail. Returns (rows, recipients) or raises."""
    rep = build(conn, key, params)
    if skip_empty and not rep["rows"]:
        return 0, []
    to = recipients_for(cfg, recipients)
    if not to:
        raise ReportError("No recipient: add recipients in Admin > Mail (or tick 'Daily digest' for them).")
    subject, text, html, att = compose(conn, cfg, rep, fmt, by, period)
    from . import notify as nt
    with conn.transaction():
        nt.enqueue(conn, "report", rep.get("severity") or "info", subject, text, html, to, attachment=att)
    return len(rep["rows"]), to


def _due(s, now):
    hh, mm = (int(x) for x in s["at_time"].split(":"))
    if (now.hour, now.minute) < (hh, mm):
        return False
    if s["last_run_on"] and str(s["last_run_on"]) == now.date().isoformat():
        return False
    if s["frequency"] == "weekly" and WEEKDAYS[now.weekday()] != s["weekday"]:
        return False
    if s["frequency"] == "monthly" and now.day != s["monthday"]:
        return False
    return True


def run_due(conn, cfg):
    """Scheduled reports whose time has come today, and any asked for at once."""
    now = datetime.now(cfg["tz"])
    rows = conn.execute("SELECT * FROM report_schedules WHERE enabled OR run_requested_at IS NOT NULL ORDER BY name").fetchall()
    conn.commit()
    done = []
    for s in rows:
        asked = s["run_requested_at"] is not None
        if not asked and not _due(s, now):
            continue
        period = {"daily": "Sent every day", "weekly": "Sent every week", "monthly": "Sent every month"}[s["frequency"]] \
            + f" at {s['at_time']} SGT; change it in Admin > Scheduled reports"
        try:
            n, to = queue(conn, cfg, s["report"], dict(s["params"] or {}, _fresh_ai=True), s["format"], s["recipients"],
                          "scheduled: " + s["name"], period, s["skip_empty"] and not asked)
            ok, msg = True, (f"queued for {len(to)} recipient(s), {n} rows" if to else "nothing to report: not sent")
        except Exception as e:  # noqa: BLE001 - recorded on the schedule, tried again next time
            conn.rollback()
            ok, msg = False, (str(e) if isinstance(e, ReportError) else "could not be built: " + type(e).__name__)
            log.warning("report %s: %s", s["name"], e)
        conn.execute(
            """UPDATE report_schedules SET last_run_at = now(), last_ok = %s, last_msg = %s, run_requested_at = NULL,
                      last_run_on = CASE WHEN %s THEN last_run_on ELSE %s::date END WHERE id = %s""",
            (ok, msg[:300], asked, now.date().isoformat(), s["id"]))
        conn.commit()
        done.append(s["name"])
    return done
