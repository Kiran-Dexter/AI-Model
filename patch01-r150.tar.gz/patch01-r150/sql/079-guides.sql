-- ---------------------------------------------------------------------------
-- 079 (r150) Guides: installation guides (PDF) the assistant reads, searches and turns into simple steps
--
-- An admin uploads a guide (PDF with copyable text). PATCH-01 reads it once: its chapters (the PDF's bookmarks, or
-- its numbered headings), each page's text, and the screenshots on each page. Everyone can read and search it;
-- the assistant answers setup questions from it, with the page; AI-01 turns a chapter into short numbered steps on
-- request (checked against the chapter's own text, then kept).
--
-- guides           one uploaded PDF, kept whole (downloaded as it is)
-- guide_sections   its chapters: title, level, pages, Windows / Linux / general, and the simple steps once made
-- guide_passages   its text, page by page, in passages of a few hundred characters, searchable (full text)
-- guide_images     the screenshots on each page (PNG or JPEG, at most 1600 px wide)
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS guides (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title         TEXT NOT NULL,
    file_name     TEXT NOT NULL,
    sha256        TEXT NOT NULL,
    size_bytes    INTEGER NOT NULL,
    pdf           BYTEA NOT NULL,
    pages         INTEGER NOT NULL DEFAULT 0,
    state         TEXT NOT NULL DEFAULT 'reading' CHECK (state IN ('reading', 'ready', 'failed')),
    error         TEXT,
    read_ms       INTEGER,
    chapters_from TEXT CHECK (chapters_from IN ('bookmarks', 'headings', 'pages')),
    uploaded_by   TEXT NOT NULL,
    uploaded_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_guides_sha ON guides (sha256);

CREATE TABLE IF NOT EXISTS guide_sections (
    id            BIGSERIAL PRIMARY KEY,
    guide_id      UUID NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
    ord           INTEGER NOT NULL,
    title         TEXT NOT NULL,
    level         SMALLINT NOT NULL DEFAULT 1,
    page_from     INTEGER NOT NULL,
    page_to       INTEGER NOT NULL,
    platform      TEXT NOT NULL DEFAULT 'general' CHECK (platform IN ('windows', 'linux', 'general')),
    -- the simple steps: [{"text": ..., "page": n}], made by AI-01 when asked, checked against the chapter's text
    simple        JSONB,
    simple_state  TEXT NOT NULL DEFAULT 'none' CHECK (simple_state IN ('none', 'queued', 'working', 'done', 'failed')),
    simple_note   TEXT,
    simple_by     TEXT,
    simple_at     TIMESTAMPTZ,
    queued_at     TIMESTAMPTZ,
    UNIQUE (guide_id, ord)
);
CREATE INDEX IF NOT EXISTS idx_guide_sections_queue ON guide_sections (queued_at) WHERE simple_state = 'queued';

CREATE TABLE IF NOT EXISTS guide_passages (
    id            BIGSERIAL PRIMARY KEY,
    guide_id      UUID NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
    section_id    BIGINT REFERENCES guide_sections(id) ON DELETE SET NULL,
    page_no       INTEGER NOT NULL,
    ord           INTEGER NOT NULL,
    text          TEXT NOT NULL,
    -- the text, and again with paths split at / and \ (so sensor.conf is found in /etc/contoso/sensor.conf)
    tsv           TSVECTOR GENERATED ALWAYS AS (to_tsvector('english', text || ' ' || regexp_replace(text, '[/\\]+', ' ', 'g'))) STORED
);
CREATE INDEX IF NOT EXISTS idx_guide_passages_tsv ON guide_passages USING GIN (tsv);
CREATE INDEX IF NOT EXISTS idx_guide_passages_page ON guide_passages (guide_id, page_no, ord);

CREATE TABLE IF NOT EXISTS guide_images (
    id            BIGSERIAL PRIMARY KEY,
    guide_id      UUID NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
    page_no       INTEGER NOT NULL,
    ord           INTEGER NOT NULL,
    media_type    TEXT NOT NULL CHECK (media_type IN ('image/png', 'image/jpeg')),
    width         INTEGER NOT NULL,
    height        INTEGER NOT NULL,
    data          BYTEA NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_guide_images_page ON guide_images (guide_id, page_no, ord);

INSERT INTO schema_version (version, description)
VALUES (79, 'Guides: installation guides (PDF) read, searched and turned into simple steps')
ON CONFLICT (version) DO NOTHING;
