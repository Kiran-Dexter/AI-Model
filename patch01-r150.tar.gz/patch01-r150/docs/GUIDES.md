# Guides: installation guides the assistant reads (r150)

Admin > Guides holds your installation guides (PDF). PATCH-01 reads each one once. You can then:

- read it chapter by chapter, page by page, with its screenshots;
- find a word in it;
- ask AI-01 for a chapter's **simple steps**;
- ask the assistant setup questions, which it answers from the guide with the page.

Nothing leaves PATCH-01: the guide stays in its database, and AI-01 reads it on your own network.

## What a guide must be

- **A PDF whose text can be copied**, as in a PDF made by Word. A scanned guide (pictures of pages) cannot be read, and
  the upload says so.
- **No password.** Save a copy without one.
- **At most 50 MB and 800 pages.** (A 60-page guide with screenshots is usually 5 to 30 MB.)

Words inside screenshots are read too when they can be copied in the PDF.

## Upload (admins)

1. Press **Upload guide (PDF)**. It is read in the background, in a process of its own with limits on memory (1.5 GB)
   and time (5 minutes), so a damaged file cannot slow the console; nothing is written to the API's disk. A 60-page guide takes about a minute; guides
   uploaded together are read one after the other.
2. The chapters come from the guide's **bookmarks**, or else from its **numbered headings** (2, 3.1, 3.2...,
   "Chapter 4:", "Appendix A"), or else every 5 pages. A contents page, a numbered list of steps (1. 2. 3.) and a
   quantity ("4 GB RAM") are not taken for chapters. A chapter that starts mid-page shares that page with the one
   before.
3. Each chapter is marked **Windows**, **Linux** or **For both**:
   - by its title first (Windows installation, Linux installation);
   - else by its words, when they are about one system only (msiexec, PowerShell / dnf, systemctl...);
   - else by its parent chapter's.
4. Headers and footers are left out (a line at the top or bottom of 40% of the pages or more, so odd and even pages
   may have their own), and so is a picture repeated on many pages (a logo). Only the pictures a page draws are kept.

**Remove** (pressed twice) deletes the guide and all that was read from it. **Download PDF** gives the file back as
uploaded.

## Read and find (everyone)

- The filter buttons show **All** chapters, or only **Windows**, **Linux** or **For both**.
- Select a chapter to see its simple steps and read its pages, with **‹ Page** and **Page ›**.
- **Find in the guide** lists the passages with your words, the best first. Select one to open its page.

## Simple steps (operators; AI-01)

**Make simple steps** asks AI-01 to turn the chapter into short numbered steps, each with its page. **Simple steps for
every Windows / Linux chapter** asks for all of them. A chapter with no text (a heading, or only pictures) is not
asked for.

The worker makes them one chapter at a time. A person pressed the button, so they wait their turn on AI-01; a chapter
takes a minute or two.

**AI-01 never types a command, path, number or value.** The chapter is given to it line by line, each line with an id;
a step is AI-01's own short sentence plus the id of the line it needs. PATCH-01 shows that line exactly as the guide
writes it (in code type), with its page.

AI-01's own sentence must be plain words: no digit (in any script), no symbol (/ \ = - and the like), no command
name (sudo, dnf, msiexec, systemctl, Stop-Service..., and whatever the guide's commands start with), only everyday
words or the chapter's own, and no word that could turn a step off or into harm (delete, remove, disable, stop, off,
close, not, never, skip...) unless the line it quotes, or the line just before or after it, says it too. A step that breaks
this is left out, and the chapter says how many. If none are left, nothing is shown and it says so (**Try again**).
AI-01 reads the first 14,000 characters of a long chapter, and the chapter says which pages.

## The assistant

Ask it, for example:

- *How do I install the sensor on Linux?*
- *How do I open the firewall on Windows?*
- *What does error 1603 mean?*

It searches the guides, then answers with the steps and their pages. Under the answer are links to those pages and
their screenshots; a link opens the page under Guides.

The same rule as the simple steps: the passages go to AI-01 line by line with ids, and its answer names the lines
({L12}). PATCH-01 puts each line in as the guide writes it, with its page. The answer is shown only if AI-01's own
words follow the rule above and every page it names is one of the passages'. So a command, path, host, port or
number the guide does not have cannot be in an answer, nor one you typed in your question, nor a value from
PATCH-01's own data. Otherwise you see the guide's own passage instead, and the answer says so.

A question about your servers and the guide together ("How many updates is web01 missing, and where are the logs?")
gets what was found, with the guide's pages: the numbers and names of your servers are not the guide's.

What the check cannot prove: that AI-01 chose the right line for the step, or put the steps in the right order. So every answer links to its pages: check the
step there before you run it on a server.

When AI-01 is not set up, the guides can still be read and searched; the assistant and the simple steps need AI-01.
