/* ---- Admin > Guides (r150) ------------------------------------------------------------------------------------
 * Installation guides (PDF) PATCH-01 has read: their chapters (Windows, Linux, both), each page's text and screenshots,
 * a search, and AI-01's simple steps for a chapter (checked against the guide). The assistant answers setup questions
 * from them, with the page, and links here.
 *   head      Upload guide (admins), Download PDF
 *   banner    a guide being read, or one that could not be read
 *   line      the guide (one of several), its facts, Find in the guide
 *   panes     the chapters (All / Windows / Linux / For both) beside the chapter: its simple steps, then its pages
 * Nothing here changes a server. */

const GD_BASE = "/guides";
const GD_KEYS = ["guide", "ch", "page", "q", "plat"];
const GD_PLAT = [["", "All"], ["windows", "Windows"], ["linux", "Linux"], ["general", "For both"]];
const GD_FOR = { windows: "Windows", linux: "Linux", general: "Both" };
const GD_SIMPLE = { none: null, queued: ["chip-warn", "waiting for AI-01"], working: ["chip-warn", "AI-01 is writing them"],
                    done: ["chip-ok", "simple steps"], failed: ["chip-bad", "not made"] };

function gdHash(st) {
  const p = new URLSearchParams();
  for (const k of GD_KEYS) if (st[k]) p.set(k, st[k]);
  const q = p.toString();
  return "#/guides" + (q ? "?" + q : "");
}

function gdNum(n) { return Number(n || 0).toLocaleString(); }

/* replaceChildren writes null as text, and takes no arrays: this one skips the nulls and flattens. */
function gdFill(box, ...kids) {
  box.replaceChildren(...kids.flat(Infinity).filter(k => k !== null && k !== undefined && k !== false));
}

/* A box drawn by an answer the page waits for: a newer draw wins, an older answer that comes back last is dropped. */
function gdTurn(box) {
  box._gdTurn = (box._gdTurn || 0) + 1;
  const mine = box._gdTurn;
  return () => box.isConnected && box._gdTurn === mine;
}

function gdFailIn(box, e) {
  if (e instanceof StaleRoute) return;
  box.replaceChildren(h("p", { class: "hd-failed" }, (e && e.message) || "This could not be read."));
}

/* A screenshot, fetched with the session (an <img> cannot send it) and shown as a data: address (the console's
 * policy allows those, not blob:). Kept for the page's life: the same picture is not fetched twice. */
const GD_IMG = new Map();
async function gdImage(id) {
  if (GD_IMG.has(id)) return GD_IMG.get(id);
  const p = (async () => {
    const res = await fetch("/api/v1" + GD_BASE + "/images/" + encodeURIComponent(id),
      { headers: { "X-Requested-With": "patch01-dashboard", ...authHeaders() }, cache: "no-store" });
    if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
    if (!res.ok) throw new ApiError(res.status, httpReason(res));
    const blob = await res.blob();
    return await new Promise((ok, bad) => {
      const r = new FileReader();
      r.onload = () => ok(r.result);
      r.onerror = () => bad(new ApiError(0, "The screenshot could not be read."));
      r.readAsDataURL(blob);
    });
  })();
  GD_IMG.set(id, p);
  p.catch(() => GD_IMG.delete(id));
  return p;
}

function gdShot(id, alt, cls) {
  const img = h("img", { class: cls || "gd-shot", alt: alt || "Screenshot", loading: "lazy" });
  gdImage(id).then(src => { img.src = src; }).catch(() => { img.replaceWith(h("span", { class: "muted small" }, "(the screenshot could not be shown)")); });
  return img;
}

async function renderGuides(params) {
  setNav("guides");
  const home = await api(GD_BASE);
  const st = {};
  for (const k of GD_KEYS) if ((params.get(k) || "").trim()) st[k] = params.get(k).trim();
  if (!GD_PLAT.some(p => p[0] === (st.plat || ""))) delete st.plat;
  if (st.page && !/^[1-9]\d{0,4}$/.test(st.page)) delete st.page;      // a page is a whole number (not 3.5, 1e3)
  const page = h("div", { class: "gd" });
  render(page);
  await gdDraw(page, home, st);
}

async function gdDraw(page, home, st) {
  document.body.classList.remove("sheet-open");
  const mine = gdTurn(page);
  const say = h("p", { class: "cm-meta gd-msg", role: "status", "aria-live": "polite" });
  const tell = (t, bad) => { say.textContent = t || ""; say.classList.toggle("hd-failed", !!bad); };
  const keep = () => history.replaceState(null, "", gdHash(st));
  const again = async msg => {
    const turn = gdTurn(page);
    let fresh;
    try { fresh = await api(GD_BASE); } catch (e) { if (!(e instanceof StaleRoute)) tell(e.message, true); return; }
    if (!turn()) return;                               // a newer draw of the page came first
    await gdDraw(page, fresh, st);
    if (msg) { const m = page.querySelector(".gd-msg"); if (m) gdFill(m, msg); }
  };
  const show = id => { st.guide = String(id); for (const k of ["ch", "page", "q"]) delete st[k]; keep(); again(); };
  const list = home.guides || [];
  const ready = list.filter(g => g.state === "ready");
  if (!ready.some(g => String(g.id) === st.guide)) { st.guide = ready[0] ? String(ready[0].id) : null; delete st.ch; delete st.page; }
  const cur = ready.find(g => String(g.id) === st.guide) || null;
  const head = h("div", { class: "page-head" }, h("h1", null, "Guides"),
    h("div", { class: "head-actions" },
      cur ? h("button", { type: "button", class: "btn btn-quiet", on: { click: async e => {
        const b = e.currentTarget; b.disabled = true; tell("Downloading " + cur.file_name + "…");
        try { await downloadFile(GD_BASE + "/" + encodeURIComponent(cur.id) + "/file", "guide.pdf"); tell("Downloaded: " + cur.file_name + "."); }
        catch (err) { tell(err.message, true); }
        b.disabled = false;
      } } }, "Download PDF") : null,
      home.can_upload ? h("button", { type: "button", class: "btn", on: { click: e => gdPickFile(e.currentTarget, home, tell, again) } },
        "Upload guide (PDF)") : null));
  const intro = h("p", { class: "muted small" }, "Installation guides for Windows and Linux. Read them chapter by chapter with their screenshots, "
    + "find a word in them, or ask the assistant: it answers setup questions from them, with the page.");
  // the banner: a guide being read, or one that could not be read
  const reading = list.filter(g => g.state === "reading");
  const failed = list.filter(g => g.state === "failed");
  const banners = [
    reading.map(g => h("div", { class: "hs-alert st-running gd-note" }, h("strong", null, "Reading: "),
      g.title + ". The chapters, pages and screenshots show here when it is done (a 60-page guide takes about a minute).")),
    failed.map(g => h("div", { class: "hs-alert st-affected gd-note" }, h("strong", null, g.file_name + ": "), g.error || "it could not be read.",
      home.can_upload ? h("button", { type: "button", class: "btn-link", on: { click: e => gdRemove(e.currentTarget, g, tell, again) } }, "Remove") : null))];
  if (!ready.length) {                                 // none read yet (none, or only one being read or that failed)
    gdFill(page, head, intro, banners, h("div", { class: "empty" }, h("h3", null, "No guide yet"),
      h("ol", { class: "rm-steps" },
        h("li", null, h("strong", null, "Upload"), " the installation guide as a PDF (its text must be copyable, as in a PDF made by Word; "
          + "a scanned guide cannot be read). At most " + home.max_mb + " MB."),
        h("li", null, h("strong", null, "Read"), " it here chapter by chapter, or find a word in it."),
        h("li", null, h("strong", null, "Ask"), " the assistant, for example: How do I install the agent on Linux?")),
      home.can_upload ? null : h("p", { class: "muted" }, "An admin uploads the guides.")), say);
    gdPoll(page, list, again, show);
    return;
  }
  const picker = ready.length > 1 ? h("div", { class: "filters gd-picker", role: "group", "aria-label": "Guide" },
    ready.map(g => h("button", { type: "button", class: "fbtn", "aria-pressed": String(String(g.id) === st.guide),
      on: { click: () => {
        st.guide = String(g.id); for (const k of ["ch", "page", "q"]) delete st[k]; keep(); gdDraw(page, home, st);
        const b = page.querySelector(".gd-picker .fbtn[aria-pressed='true']"); if (b) b.focus();     // drawn again: focus stays on it
      } } }, g.title))) : null;
  const body = h("div", { class: "gd-body" });
  gdFill(page, head, intro, banners, picker,
    cur ? h("p", { class: "small gd-facts" }, h("strong", null, cur.title), " · " + gdNum(cur.pages) + " pages · " + gdNum(cur.chapters)
      + " chapters · " + gdNum(cur.screenshots) + " screenshot" + (cur.screenshots === 1 ? "" : "s") + " · uploaded by " + cur.uploaded_by
      + " " + timeAgo(cur.uploaded_at),
      home.can_upload ? [" · ", h("button", { type: "button", class: "btn-link", on: { click: e => gdRemove(e.currentTarget, cur, tell, again) } }, "Remove")] : null)
      : null,
    say, cur ? body : null);
  body.append(h("p", { class: "muted small" }, "Loading…"));
  page._list = list;
  page._show = show;
  gdPoll(page, list, again, show);
  if (!cur) return;
  try {
    const g = await api(GD_BASE + "/" + encodeURIComponent(cur.id));
    if (!mine()) return;
    gdGuide(body, g, home, st, { tell, keep, again });
  } catch (e) { gdFailIn(body, e); }
}

/* The page's one timer, every 4 seconds while something is under way: a guide being read (the page is drawn again when
 * it is done) and chapters waiting for AI-01 (only their chips and the open chapter's steps are drawn again, so a
 * search being typed or a page being read is left alone). */
function gdPoll(page, list, again, show) {
  show = show || page._show;
  setPageTimer(async () => {
    if (!page.isConnected || !location.hash.startsWith("#/guides")) return clearPageTimer();
    const body = page.querySelector(".gd-body");
    if (list.some(g => g.state === "reading")) {
      let fresh;
      try { fresh = await api(GD_BASE); } catch (e) { return; }
      if (!page.isConnected) return;
      const was = JSON.stringify(list.map(g => [g.id, g.state]));
      if (JSON.stringify((fresh.guides || []).map(g => [g.id, g.state])) !== was) {
        // every guide read since: each named, one read well with a button to open it
        const done = (fresh.guides || []).filter(g => list.some(o => o.id === g.id && o.state === "reading") && g.state !== "reading");
        clearPageTimer();
        return again(done.length ? done.map((d, i) => [i ? " " : null, d.state === "ready"
          ? ["Read: ", show ? h("button", { type: "button", class: "btn-link", on: { click: () => show(d.id) } }, d.title) : d.title,
             ", " + gdNum(d.pages) + " pages, " + gdNum(d.chapters) + " chapters."]
          : d.file_name + " could not be read."]) : null);
      }
    }
    if (body && body._waiting && body._waiting()) await body._refresh();
    else if (!list.some(g => g.state === "reading")) clearPageTimer();
  }, 4000);
}

function gdPickFile(btn, home, tell, again) {
  document.querySelectorAll("input.gd-file").forEach(x => x.remove());
  const input = h("input", { type: "file", class: "gd-file", accept: ".pdf,application/pdf", hidden: true });
  document.body.append(input);
  input.addEventListener("change", async () => {
    const f = input.files[0];
    input.remove();
    if (!f) return;
    if (!/\.pdf$/i.test(f.name)) { tell("Upload the guide as a PDF.", true); return; }
    if (f.size > home.max_mb * 1024 * 1024) { tell("The guide is larger than " + home.max_mb + " MB.", true); return; }
    btn.disabled = true; tell("Uploading " + f.name + "…");
    try {
      const fd = new FormData();
      fd.append("file", f);
      const res = await fetch("/api/v1" + GD_BASE, { method: "POST", body: fd, cache: "no-store",
        headers: { "X-Requested-With": "patch01-dashboard", ...authHeaders() } });
      if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
      if (!res.ok) { let d = ""; try { d = detailText((await res.json()).detail); } catch (e) { /* not JSON */ } throw new ApiError(res.status, d || httpReason(res)); }
      await again("Uploaded: " + f.name + ". It is being read.");
    } catch (e) { tell(e.message, true); btn.disabled = false; }
  });
  input.click();
}

async function gdRemove(btn, g, tell, again) {
  if (!confirm(g.state === "ready" ? "Remove " + g.title + " from PATCH-01? Its chapters, pages, screenshots and simple steps go with it."
                                   : "Remove " + g.file_name + " from PATCH-01?")) return;
  btn.disabled = true;
  try { await apiSend("DELETE", GD_BASE + "/" + encodeURIComponent(g.id)); await again("Removed: " + g.title + "."); }
  catch (e) { tell(e.message, true); btn.disabled = false; }
}

/* ---- one guide: find, the chapters, the chapter --------------------------------------------- */

function gdGuide(body, g, home, st, ctx) {
  const secs = g.sections || [];
  const plat = st.plat || "";
  const find = h("input", { type: "search", value: st.q || "", placeholder: "Find in the guide", "aria-label": "Find in the guide", maxlength: "100" });
  const bar = h("div", { class: "filters", role: "group", "aria-label": "Chapters for" },
    GD_PLAT.map(([k, label]) => h("button", { type: "button", class: "fbtn", "aria-pressed": String(plat === k), on: { click: () => {
      st.plat = k || null; delete st.ch; delete st.page; ctx.keep(); gdGuide(body, g, home, st, ctx);
      const b = body.querySelector(".gd-filter .fbtn[aria-pressed='true']"); if (b) b.focus();     // drawn again: focus stays on it
    } } }, label + " (" + gdNum(k ? secs.filter(s => s.platform === k).length : secs.length) + ")")));
  const all = plat && home.can_simplify && home.ai01 ? h("button", { type: "button", class: "btn btn-quiet", on: { click: async e => {
    const b = e.currentTarget; b.disabled = true;
    try {
      const r = await apiPost(GD_BASE + "/" + encodeURIComponent(g.id) + "/simple", { platform: plat });
      await gdAsked(body, g, home, st, ctx, "Asked AI-01 for the simple steps of " + gdNum(r.queued) + " chapter" + (r.queued === 1 ? "" : "s")
        + ": they show here as they are made.");
      b.disabled = false; b.focus();
    } catch (err) { ctx.tell(err.message, true); b.disabled = false; b.focus(); }
  } } }, "Simple steps for every " + (plat === "general" ? "chapter for both" : GD_FOR[plat] + " chapter")) : null;
  const list = h("div", { class: "pane-list" });
  // not a live region: it holds a whole page of text, which a screen reader would read again on every change
  const panel = h("aside", { class: "pane-detail", "aria-label": "Selected chapter" });
  gdFill(body, h("div", { class: "cm-actions gd-filter" }, bar, find, all), h("div", { class: "panes gd-panes" }, list, panel));
  let timer = null;
  find.addEventListener("input", () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      if ((find.value.trim() || null) === (st.q || null)) return;
      st.q = find.value.trim() || null; ctx.keep();
      gdList(list, panel, g, home, st, ctx);
    }, 350);
  });
  gdList(list, panel, g, home, st, ctx);
  // chapters waiting for AI-01: the page's timer asks again; only what changed is drawn again
  body._waiting = () => (g.sections || []).some(s => s.simple_state === "queued" || s.simple_state === "working");
  body._refresh = () => gdRefresh(body, list, panel, g, home, st, ctx);
}

/* Chapters' steps state, read again: each changed chip in the list, and the open chapter's steps if it changed.
 * The search box, the list's order and the page being read are left as they are. */
async function gdRefresh(body, list, panel, g, home, st, ctx) {
  let fresh;
  try { fresh = await api(GD_BASE + "/" + encodeURIComponent(g.id)); }
  catch (e) { if (e && e.status === 404 && body.isConnected) { clearPageTimer(); ctx.again(g.title + " was removed."); } return; }
  if (!body.isConnected) return;
  const old = new Map((g.sections || []).map(s => [s.id, s]));
  for (const s of fresh.sections || []) {
    const o = old.get(s.id);
    if (o && o.simple_state === s.simple_state && o.simple_at === s.simple_at) continue;
    Object.assign(o || {}, s);
    const tr = list.querySelector("tr[data-ch='" + s.id + "']");
    if (tr) { const td = tr.cells[3]; const c = GD_SIMPLE[s.simple_state]; td.replaceChildren(c ? h("span", { class: ("chip " + c[0]).trim() }, c[1]) : ""); }
    if (String(s.id) === st.ch && panel.isConnected) {
      const box = panel.querySelector(".gd-simple");
      if (box) box.replaceWith(gdSimple(g, o || s, home, st, ctx, panel));
    }
  }
  g.sections = (g.sections || []).map(s => old.get(s.id) || s);
}

/* Ask AI-01 again for chapters: the steps' state is read back at once, the page's timer follows them. */
async function gdAsked(body, g, home, st, ctx, msg) {
  ctx.tell(msg);
  if (body && body._refresh) await body._refresh();
  const page = body && body.closest(".gd");
  if (page) gdPoll(page, page._list || [], ctx.again);           // a guide still being read stays followed too
}

async function gdList(list, panel, g, home, st, ctx) {
  const mine = gdTurn(list);
  const secs = (g.sections || []).filter(s => !st.plat || s.platform === st.plat);
  const select = (s, tr, picked) => {
    st.ch = String(s.id); ctx.keep();
    list.querySelectorAll("tr.selected").forEach(t => t.classList.remove("selected"));
    if (tr) tr.classList.add("selected");
    gdChapter(panel, g, s, home, st, ctx);
    if (picked && !wideScreen()) { panel.classList.add("open"); document.body.classList.add("sheet-open"); }
  };
  const openPage = (n, picked) => {
    const s = gdChapterOf(g, n);
    st.page = String(n);
    if (s) select(s, list.querySelector("tr[data-ch='" + s.id + "']"), picked);
  };
  if (st.q) {
    list.replaceChildren(h("p", { class: "muted small" }, "Loading…"));
    let r;
    try { r = await api(GD_BASE + "/search?guide_id=" + encodeURIComponent(g.id) + "&q=" + encodeURIComponent(st.q)
      + (st.plat ? "&platform=" + encodeURIComponent(st.plat) : "")); }
    catch (e) { if (mine()) gdFailIn(list, e); return; }
    if (!mine()) return;
    const items = r.items || [];
    if (!items.length) {
      gdFill(list, h("div", { class: "empty" }, h("p", null, "Nothing matches.")));
      panel.replaceChildren(h("p", { class: "pane-empty" }, "Select a chapter to see its simple steps and read its pages."));
      return;
    } else {
      const tbl = table([
        { label: "Page", num: true, nowrap: true, cell: x => String(x.page_no) },
        { label: "Chapter", cell: x => x.section || "–" },
        { label: "Passage", cell: x => h("span", { class: "small gd-snip" }, x.text.replace(/\s+/g, " ").slice(0, 220) + (x.text.length > 220 ? "…" : "")) },
      ], items);
      tbl.querySelector("table").dataset.noSelect = "1";
      tbl.querySelectorAll("tbody tr").forEach((tr, i) => {
        tr.tabIndex = 0;
        tr.setAttribute("aria-label", "Page " + items[i].page_no + ", " + (items[i].section || ""));
        tr.addEventListener("click", () => openPage(items[i].page_no, true));
        tr.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openPage(items[i].page_no, true); } });
      });
      gdFill(list, h("p", { class: "muted small" }, gdNum(items.length) + " passage" + (items.length === 1 ? "" : "s") + ", the best first. Select one to read its page."), tbl);
      if (!st.page && wideScreen()) { openPage(items[0].page_no, false); tbl.querySelector("tbody tr").classList.add("selected"); return; }
    }
  } else if (!secs.length) {
    gdFill(list, h("div", { class: "empty" }, h("p", null, "No chapter of the guide is for " + (st.plat === "general" ? "both" : GD_FOR[st.plat] || "this") + (st.plat === "general" ? "." : " alone."))));
  } else {
    const tbl = table([
      { label: "Chapter", cell: s => h("span", { class: "gd-ch gd-l" + Math.min(s.level, 3) }, s.title) },
      { label: "Pages", nowrap: true, cell: s => s.page_from === s.page_to ? String(s.page_from) : s.page_from + "–" + s.page_to },
      { label: "For", cell: s => GD_FOR[s.platform] },
      { label: "Steps", cell: s => { const c = GD_SIMPLE[s.simple_state]; return c ? h("span", { class: ("chip " + c[0]).trim() }, c[1]) : ""; } },
    ], secs);
    tbl.querySelector("table").dataset.noSelect = "1";
    tbl.querySelectorAll("tbody tr").forEach((tr, i) => {
      tr.tabIndex = 0;
      tr.dataset.ch = String(secs[i].id);
      tr.setAttribute("aria-label", secs[i].title + (secs[i].page_from === secs[i].page_to ? ", page " + secs[i].page_from
                                                                                         : ", pages " + secs[i].page_from + " to " + secs[i].page_to));
      tr.addEventListener("click", () => { delete st.page; select(secs[i], tr, true); });
      tr.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); delete st.page; select(secs[i], tr, true); } });
    });
    gdFill(list, tbl);
  }
  // the chapter (or page) in the address opens; on a wide screen the first chapter otherwise
  if (st.page && !(Number(st.page) >= 1 && Number(st.page) <= g.pages)) { delete st.page; ctx.keep(); }     // no such page
  if (st.page) { openPage(Number(st.page), true); return; }       // a link to a page (the assistant's): opened, on a phone too
  const want = secs.find(s => String(s.id) === st.ch) || null;   // a chapter outside the filter is not shown beside it
  if (st.ch && !want) { delete st.ch; ctx.keep(); }
  if (want) select(want, list.querySelector("tr[data-ch='" + want.id + "']"), false);
  else if (wideScreen() && secs.length && !st.q) select(secs[0], list.querySelector("tbody tr"), false);
  else panel.replaceChildren(h("p", { class: "pane-empty" }, "Select a chapter to see its simple steps and read its pages."));
}

function gdChapterOf(g, n) {
  let best = null;
  for (const s of g.sections || []) if (s.page_from <= n && n <= s.page_to && (!best || s.level >= best.level)) best = s;
  return best;
}

/* The panel: the chapter's simple steps (or the button to ask for them), then its pages to read. */
function gdSimple(g, s, home, st, ctx, panel, goPage) {
  goPage = goPage || (n => { const r = panel.querySelector(".gd-reader"); st.page = String(n); ctx.keep(); if (r) gdPage(r, g, s, n, st, ctx); });
  const steps = s.simple || [];
  const ask = async (b, msg) => {
    b.disabled = true;
    try {
      await apiPost(GD_BASE + "/" + encodeURIComponent(g.id) + "/simple", { sections: [s.id] });
      await gdAsked(panel.closest(".gd-body"), g, home, st, ctx, msg);
      const head = !b.isConnected && panel.querySelector(".gd-simple h3");      // the box was drawn again: focus its heading
      if (head) { head.tabIndex = -1; head.focus(); }
    } catch (err) { ctx.tell(err.message, true); b.disabled = false; b.focus(); }
  };
  return h("section", { class: "gd-simple" }, h("h3", { class: "pd-sub" }, "Simple steps"),
    s.simple_state === "done" && steps.length ? [
      // x.say: AI-01's own plain words; x.quote: the guide's line as the guide writes it (steps made by r150 before
      // the lines were quoted have x.text)
      h("ol", { class: "gd-steps" }, steps.map(x => h("li", null, x.say !== undefined ? x.say : x.text,
        x.quote ? h("code", { class: "gd-quote" }, x.quote) : null, " ",
        h("button", { type: "button", class: "btn-link gd-pg", on: { click: () => goPage(x.page) } }, "page " + x.page)))),
      h("p", { class: "muted small" }, "Made by AI-01 from the chapter" + (s.simple_at ? " " + timeAgo(s.simple_at) : "")
        + "; the commands, paths and values are the guide's own lines, quoted as it writes them." + (s.simple_note ? " " + s.simple_note : ""))]
    : s.simple_state === "queued" || s.simple_state === "working"
      ? h("p", { class: "muted small" }, s.simple_state === "working" ? "AI-01 is writing them: they show here when done."
                                                                      : "Waiting for AI-01: they show here when done.")
    : s.simple_state === "failed" ? h("p", { class: "hd-failed small" }, s.simple_note || "They could not be made.")
    : s.has_text === false ? null
    : h("p", { class: "muted small" }, "Short numbered steps for this chapter, made by AI-01 from the guide's own lines."),
    s.has_text === false ? h("p", { class: "muted small" }, "This chapter has no text, so AI-01 cannot make steps for it.")
    : home.can_simplify && home.ai01 && s.simple_state !== "queued" && s.simple_state !== "working"
      ? h("p", null, h("button", { type: "button", class: s.simple_state === "done" ? "btn-link" : "btn btn-quiet",
          on: { click: e => ask(e.currentTarget, "Asked AI-01 for the simple steps of " + s.title + ".") } },
          s.simple_state === "done" ? "Make them again" : s.simple_state === "failed" ? "Try again" : "Make simple steps")) : null,
    !home.ai01 ? h("p", { class: "muted small" }, "AI-01 is not set up, so simple steps cannot be made.") : null);
}

function gdChapter(panel, g, s, home, st, ctx) {
  const close = h("button", { type: "button", class: "pd-close", "aria-label": "Close", on: { click: () => {
    panel.classList.remove("open"); document.body.classList.remove("sheet-open"); } } }, "Close");
  const reader = h("section", { class: "gd-reader" });
  const goPage = n => { st.page = String(n); ctx.keep(); gdPage(reader, g, s, n, st, ctx); };
  const simple = gdSimple(g, s, home, st, ctx, panel, goPage);
  gdFill(panel,
    h("div", { class: "pd-head" }, h("h2", null, s.title), close),
    h("div", { class: "pd-badges" }, h("span", { class: "chip" }, s.platform === "general" ? "For both" : "For " + GD_FOR[s.platform]),
      h("span", { class: "muted small" }, (s.page_from === s.page_to ? "page " + s.page_from : "pages " + s.page_from + "–" + s.page_to) + (s.screenshots ? " · " + gdNum(s.screenshots) + " screenshot" + (s.screenshots === 1 ? "" : "s") : ""))),
    simple, reader);
  const n = Number(st.page);
  gdPage(reader, g, s, n >= s.page_from && n <= s.page_to ? n : s.page_from, st, ctx);
}

async function gdPage(box, g, s, n, st, ctx, which) {
  const mine = gdTurn(box);
  // the project's pager (cyber.js pager()), counting pages of the guide rather than rows of a table
  const go = (k, which) => { st.page = String(k); ctx.keep(); gdPage(box, g, s, k, st, ctx, which); };
  const pager = h("nav", { class: "srv-pager gd-pager", "aria-label": "Pages" },
    h("button", { type: "button", class: "btn btn-quiet", disabled: n <= 1, on: { click: () => go(n - 1, "prev") } }, "‹ Previous"),
    h("span", null, "Page " + n + " of " + g.pages),
    h("button", { type: "button", class: "btn btn-quiet", disabled: n >= g.pages, on: { click: () => go(n + 1, "next") } }, "Next ›"));
  // after Previous or Next, focus stays on that button (or the other one, at the first or last page)
  const refocus = () => { if (!which) return; const b = pager.querySelector(which === "prev" ? "button:first-of-type" : "button:last-of-type");
    (b && !b.disabled ? b : pager.querySelector("button:not([disabled])") || pager).focus(); };
  const pg = g.pages > 1 ? pager : null;                // a one-page guide has no pager, as pager() draws none
  gdFill(box, h("h3", { class: "pd-sub" }, "The pages"), pg, h("p", { class: "muted small" }, "Loading the page…"));
  refocus();
  let p;
  try { p = await api(GD_BASE + "/" + encodeURIComponent(g.id) + "/pages/" + n); }
  catch (e) {
    if (!mine()) return;
    gdFailIn(box, e);
    if (e && e.status === 404) api(GD_BASE + "/" + encodeURIComponent(g.id)).catch(x => {      // the guide itself was removed?
      if (x && x.status === 404 && box.isConnected) { clearPageTimer(); ctx.again(g.title + " was removed."); } });
    return;
  }
  if (!mine()) return;
  const other = p.section && p.section.id !== s.id && !(s.page_from <= n && n <= s.page_to);
  gdFill(box, h("h3", { class: "pd-sub" }, "The pages"), pg,
    other ? h("p", { class: "muted small" }, "In " + p.section.title + ".") : null,
    p.text ? h("div", { class: "gd-text" }, p.text) : h("p", { class: "muted small" }, "This page has no text."),
    (p.images || []).map((im, i) => h("figure", { class: "gd-fig" }, gdShot(im.id, "Screenshot " + (i + 1) + " on page " + n),
      h("figcaption", { class: "muted small" }, "Screenshot " + (i + 1) + " of page " + n))));
  refocus();
}
