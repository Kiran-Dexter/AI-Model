"""Reads one guide (PDF) in a process of its own (r150), so a damaged or hostile PDF cannot slow or exhaust the API.

  python -m app.guide_reader -        the PDF on stdin

Limits: memory (address space) READ_MEMORY_MB, CPU READ_CPU_S; the API also stops it after guides.READ_BUDGET_S plus a
minute. It answers on stdout in frames, each a JSON line {"kind": ..., "len": n} then n bytes: "image" (with "rec",
the screenshot's record; the bytes are the picture) as each is read, then "result" (JSON: pages, chapters, the logos
to leave out, or {"error": ...} with words for the person). Nothing is written to disk: the API's /tmp is a small
in-memory disk. Exit 0 either way; anything else is a crash or a limit reached, said by the API."""

import json
import resource
import sys

READ_MEMORY_MB = 1536
READ_CPU_S = 300


def _frame(out, kind, payload, **head):
    out.write(json.dumps(dict(head, kind=kind, len=len(payload))).encode() + b"\n")
    out.write(payload)
    out.flush()


def main(src="-"):
    resource.setrlimit(resource.RLIMIT_AS, (READ_MEMORY_MB * 1024 * 1024,) * 2)
    resource.setrlimit(resource.RLIMIT_CPU, (READ_CPU_S, READ_CPU_S + 5))
    from . import guides
    out = sys.stdout.buffer
    try:
        data = sys.stdin.buffer.read(guides.MAX_BYTES + 1) if src == "-" else open(src, "rb").read()
        got = guides.read_pdf(data, sink=lambda rec, blob: _frame(out, "image", blob, rec=rec))
        del data
        res = {"pages": got["pages"], "sections": got["sections"], "chapters_from": got["chapters_from"],
               "logos": got["logos"]}
    except guides.GuideError as e:
        res = {"error": str(e)}
    except MemoryError:
        res = {"error": f"Reading the guide needed more than {READ_MEMORY_MB} MB of memory: it is too large or damaged."}
    except Exception as e:  # noqa: BLE001 - anything else in a damaged PDF: said as that, not as a crash
        res = {"error": "The PDF could not be read (" + type(e).__name__ + "): it may be damaged."}
    try:
        payload = json.dumps(res, ensure_ascii=False).encode()
    except UnicodeEncodeError:                         # a character that is not one (read_pdf cleans the text; to be sure)
        payload = json.dumps(res, ensure_ascii=False).encode("utf-8", "replace")
    _frame(out, "result", payload)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "-")
