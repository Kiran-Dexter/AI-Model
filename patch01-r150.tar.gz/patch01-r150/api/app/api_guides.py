"""Guides (r150): installation guides (PDF) under Admin > Guides.

Everyone signed in reads and searches them (as Activity, every module); admins upload and remove them; operators ask
AI-01 for a chapter's simple steps (the worker makes them, one at a time)."""

import threading
from typing import List, Optional

from fastapi import Depends, File, HTTPException, Request, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel, Field

from . import guides
from .core import app, audit, client_ip, db, jsonable, require_admin, require_operator, require_viewer, uuid_or_404

BASE = "/api/v1/guides"


def _audit(conn, user, request, action, detail, object_id=None):
    audit(conn, actor=user, actor_type="user", action=action, object_type="guide", object_id=object_id, detail=detail,
          source_ip=client_ip(request))


def _call(fn):
    try:
        return fn()
    except guides.GuideError as e:
        raise HTTPException(400, str(e))


@app.get(BASE)
def guides_home(request: Request, user: str = Depends(require_viewer)):
    u = getattr(request.state, "user", None) or {}
    from . import auth, llm
    with db() as conn:
        with conn.transaction():
            items = guides.listing(conn)
    return jsonable({"guides": items, "can_upload": auth.role_at_least(u.get("role", "viewer"), "admin"),
                     "can_simplify": auth.role_at_least(u.get("role", "viewer"), "operator"),
                     "ai01": llm.configured(), "max_mb": guides.MAX_BYTES // (1024 * 1024)})


@app.post(BASE)
def guides_upload(request: Request, file: UploadFile = File(...), user: str = Depends(require_admin)):
    # a plain def: FastAPI runs it in a thread; the reading itself goes on in a thread of its own
    data = file.file.read(guides.MAX_BYTES + 1)
    with db() as conn:
        with conn.transaction():
            gid = _call(lambda: guides.create(conn, file.filename or "guide.pdf", data, user))
            _audit(conn, user, request, "guides.upload", {"file": (file.filename or "")[:200], "bytes": len(data)}, gid)
    threading.Thread(target=guides.read, args=(db, gid), name="guide-" + gid[:8], daemon=True).start()
    return {"id": gid, "state": "reading"}


@app.get(BASE + "/search")
def guides_search(q: str = "", platform: Optional[str] = None, guide_id: Optional[str] = None,
                  user: str = Depends(require_viewer)):
    gid = uuid_or_404(guide_id, "No such guide.") if guide_id else None
    with db() as conn:
        rows = guides.search(conn, q[:200], platform if platform in ("windows", "linux", "general") else None, gid, limit=20)
    return jsonable({"items": rows})


@app.get(BASE + "/images/{image_id}")
def guides_image(image_id: int, user: str = Depends(require_viewer)):
    if not 0 < image_id < 2 ** 63:
        raise HTTPException(404, "No such screenshot.")
    with db() as conn:
        r = guides.image(conn, image_id)
    if not r:
        raise HTTPException(404, "No such screenshot.")
    return Response(content=bytes(r["data"]), media_type=r["media_type"],
                    headers={"Cache-Control": "private, max-age=86400", "X-Content-Type-Options": "nosniff"})


@app.get(BASE + "/{guide_id}")
def guides_get(guide_id: str, user: str = Depends(require_viewer)):
    gid = uuid_or_404(guide_id, "No such guide.")
    with db() as conn:
        g = guides.guide(conn, gid)
    if not g:
        raise HTTPException(404, "No such guide.")
    return jsonable(g)


@app.get(BASE + "/{guide_id}/pages/{page_no}")
def guides_page(guide_id: str, page_no: int, user: str = Depends(require_viewer)):
    gid = uuid_or_404(guide_id, "No such guide.")
    if not 0 < page_no < 100000:
        raise HTTPException(404, "No such page.")
    with db() as conn:
        p = guides.page(conn, gid, page_no)
    if not p:
        raise HTTPException(404, "No such page.")
    return jsonable(p)


@app.get(BASE + "/{guide_id}/file")
def guides_file(guide_id: str, request: Request, user: str = Depends(require_viewer)):
    gid = uuid_or_404(guide_id, "No such guide.")
    with db() as conn:
        r = conn.execute("SELECT file_name, pdf FROM guides WHERE id = %s", (gid,)).fetchone()
        if not r:
            raise HTTPException(404, "No such guide.")
        with conn.transaction():
            _audit(conn, user, request, "guides.download", {"file": r["file_name"]}, gid)
    return Response(content=bytes(r["pdf"]), media_type="application/pdf",
                    headers={"Content-Disposition": _disposition(r["file_name"]), "X-Content-Type-Options": "nosniff"})


def _disposition(file_name):
    """attachment; an ASCII name for every browser, and the name as it is (Руководство.pdf) for those that read it."""
    from urllib.parse import quote
    plain = "".join(c if c.isascii() and (c.isalnum() or c in "._- ") else "-" for c in file_name).strip(" -") or "guide.pdf"
    if not plain.lower().endswith(".pdf"):
        plain += ".pdf"
    return f"attachment; filename=\"{plain}\"; filename*=UTF-8''{quote(file_name, safe='')}"


@app.delete(BASE + "/{guide_id}")
def guides_delete(guide_id: str, request: Request, user: str = Depends(require_admin)):
    gid = uuid_or_404(guide_id, "No such guide.")
    with db() as conn:
        with conn.transaction():
            r = conn.execute("DELETE FROM guides WHERE id = %s RETURNING title", (gid,)).fetchone()
            if not r:
                raise HTTPException(404, "No such guide.")
            _audit(conn, user, request, "guides.remove", {"title": r["title"]}, gid)
    return {"ok": True}


# a chapter with no text (only pictures, or a heading alone) has nothing to make steps from: it is not asked for
HAS_TEXT = """ AND EXISTS (SELECT 1 FROM guide_passages p WHERE p.guide_id = s.guide_id
                                       AND p.page_no BETWEEN s.page_from AND s.page_to)"""


class SimpleIn(BaseModel):
    sections: Optional[List[int]] = Field(default=None, max_length=500)
    platform: Optional[str] = Field(default=None, pattern=r"^(windows|linux|general|all)$")


@app.post(BASE + "/{guide_id}/simple")
def guides_simple(guide_id: str, body: SimpleIn, request: Request, user: str = Depends(require_operator)):
    """Ask AI-01 for simple steps: the chapters named, or every chapter of one platform (all: every chapter)."""
    from . import llm
    gid = uuid_or_404(guide_id, "No such guide.")
    if not llm.configured():
        raise HTTPException(503, "AI-01 is not set up, so simple steps cannot be made.")
    with db() as conn:
        with conn.transaction():
            g = conn.execute("SELECT state FROM guides WHERE id = %s", (gid,)).fetchone()
            if not g:
                raise HTTPException(404, "No such guide.")
            if g["state"] != "ready":
                raise HTTPException(409, "The guide is not read yet.")
            if body.sections:
                if any(not 0 < x < 2 ** 63 for x in body.sections):
                    raise HTTPException(400, "No such chapter.")
                ids = [r["id"] for r in conn.execute("SELECT id FROM guide_sections s WHERE guide_id = %s AND id = ANY(%s)"
                                                     + HAS_TEXT, (gid, body.sections)).fetchall()]
                if not ids:
                    raise HTTPException(400, "These chapters have no text to make steps from.")
            elif body.platform:
                ids = [r["id"] for r in conn.execute(
                    "SELECT id FROM guide_sections s WHERE guide_id = %s AND (%s = 'all' OR platform = %s) AND simple_state <> 'done'"
                    + HAS_TEXT,
                    (gid, body.platform, body.platform)).fetchall()]
            else:
                raise HTTPException(400, "Choose the chapters.")
            if not ids:
                raise HTTPException(400, "No chapter to make steps for.")
            n = guides.queue(conn, gid, ids, user)
            _audit(conn, user, request, "guides.simple", {"chapters": n, "platform": body.platform}, gid)
    return {"queued": n}
