#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 : PATCH-01's half of AI-01's hardening (ai01/ai01-harden.sh)
#
#   --test               the portal's link to AI-01, end to end:
#                          - from inside the API container: TLS verified, client
#                            certificate presented, a real answer from the model
#                          - from this host, without the client certificate:
#                            refused once AI-01 enforces it (step mtls-enforce)
#                        It also gives AI-01 the requests its steps "tls13" and
#                        "mtls-enforce" wait to see.
#   --import <tar>       install the client certificate made by ai01-harden.sh
#                        step "mtls", rebuilding the API first if its code
#                        cannot use one yet, then --test
#   --rotate-key         switch PATCH-01 to the new API key from ai01-harden.sh
#                        step "key-rotate"; tested first, undone if it fails
#   --status             what is installed
#
# Run as root on PATCH-01 from the bundle's patch01 folder.
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 077

PATCH_BASE="${PATCH01_BASE:-/patch}"
SECRETS_DIR="$PATCH_BASE/secrets"
PIN_DIR="$SECRETS_DIR/ai01"
API_ENV="$SECRETS_DIR/api.env"
COMPOSE_DIR="$PATCH_BASE/compose"
COMPOSE_FILE="$COMPOSE_DIR/docker-compose.api.yml"
CONTAINER="${PATCH01_API_CONTAINER:-patch01-api}"
LOG_DIR="${PATCH01_LOG_DIR:-/var/log/patch-platform}"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/ai01-client-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"
log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }

if [[ -n "${AI01_INPUT_FILE:-}" ]]; then exec 3<"$AI01_INPUT_FILE"
elif [[ "${1:-}" =~ ^--(import|rotate-key)$ && ! -t 0 ]]; then
  die "Not a terminal: this script asks before each change."
fi
answer() {
  local r="" silent="${2:-}"
  if [[ -n "${AI01_INPUT_FILE:-}" ]]; then IFS= read -r r <&3 || r=""; printf '%s\n' "$1" >&2
  elif [[ -t 0 ]]; then
    if [[ "$silent" == silent ]]; then read -r -s -p "$1 " r || true; echo >&2; else read -r -p "$1 " r || true; fi
  else die "Not a terminal: this script asks before each change."; fi
  printf '%s' "$r"
}
ask() { local r; r="$(answer "$1 [y/N]:")"; log "ASK: $1 -> $r"; [[ "${r,,}" =~ ^(y|yes)$ ]]; }

MODE=""; TAR=""
case "${1:-}" in
  --test) MODE=test ;;
  --import) MODE=import; TAR="${2:-}"; [[ -n "$TAR" ]] || die "--import needs the .tar from AI-01." ;;
  --rotate-key) MODE=rotate ;;
  --status) MODE=status ;;
  -h|--help|"") sed -n '2,22p' "$0"; exit 0 ;;
  *) die "Unknown option: $1 (see --help)" ;;
esac

[[ $EUID -eq 0 ]] || die "Run as root."
[[ -f "$API_ENV" ]] || die "Missing $API_ENV: run phase3b-api.sh and phase6-llm.sh first."
AI01_URL="$(sed -n 's/^AI01_URL=//p' "$API_ENV" | tail -1)"
[[ -n "$AI01_URL" ]] || die "AI-01 is not configured in $API_ENV: run phase6-llm.sh first."
[[ -s "$PIN_DIR/ca.crt" ]] || die "AI-01's certificate is not pinned ($PIN_DIR/ca.crt): run phase6-llm.sh."

in_api() { docker exec "$CONTAINER" "$@"; }
TMPD="$(mktemp -d)"; trap 'rm -rf "$TMPD"' EXIT

host_code() {   # host_code <path> [curl options]: from this host, never through the proxy
  local p="$1" c; shift
  c="$(curl -s --noproxy '*' --cacert "$PIN_DIR/ca.crt" -o "$TMPD/body" -w '%{http_code}' --max-time 20 "$@" "$AI01_URL$p" 2>/dev/null || true)"
  printf '%s' "${c:-000}"   # curl itself prints 000 when it cannot connect
}
json_field() { python3 -c 'import json,sys; d=json.loads(sys.stdin.read() or "{}"); v=d.get(sys.argv[1]); print("" if v is None else str(v).lower())' "$1" 2>/dev/null; }

PASS=0; FAILS=0; WARNS=0; ENFORCED=no
ok()   { say "  PASS  $*"; PASS=$((PASS + 1)); }
bad()  { say "  FAIL  $*"; FAILS=$((FAILS + 1)); }
note() { say "  warn  $*"; WARNS=$((WARNS + 1)); }

api_supports_client_cert() {
  in_api python -c 'import app.llm as m, sys; sys.exit(0 if hasattr(m, "AI01_CLIENT_CERT") else 1)' >>"$LOG_FILE" 2>&1
}

do_test() {
  step "Testing PATCH-01 -> AI-01 ($AI01_URL)"
  PASS=0; FAILS=0; WARNS=0; ENFORCED=no
  local code have_cert=no
  [[ -s "$PIN_DIR/client.crt" && -s "$PIN_DIR/client.key" ]] && have_cert=yes

  # 1. Without the client certificate, from this host: tells whether AI-01 enforces it.
  # Tagged "?nocert-probe" so AI-01 does not take the refusal as the portal failing
  code="$(host_code '/health?nocert-probe')"
  case "$code" in
    200) if [[ "$have_cert" == yes ]]; then note "AI-01 does not require the client certificate yet (step mtls-enforce)"
         else note "no client certificate installed; AI-01 does not require one"; fi ;;
    403) ok "a request WITHOUT the client certificate is refused (403)"; ENFORCED=yes ;;
    000) bad "cannot connect to $AI01_URL (network, firewall, or TLS)" ;;
    *)   note "a request without the client certificate got $code" ;;
  esac
  # TLS 1.2 is refused once AI-01 runs step tls13. Tagged "?tls12-probe" so
  # AI-01 does not count it as PATCH-01 still using TLS 1.2
  if curl -s --noproxy '*' --cacert "$PIN_DIR/ca.crt" --tls-max 1.2 -o /dev/null --max-time 10 "$AI01_URL/health?tls12-probe" 2>/dev/null; then
    note "AI-01 still accepts TLS 1.2 (step tls13)"
  else ok "AI-01 refuses TLS 1.2"; fi

  # 2. The portal's own code, inside the API container
  local h; h="$(in_api python -m app.llm --health 2>>"$LOG_FILE" | tail -1 || true)"
  log "health: $h"
  [[ "$(json_field reachable <<<"$h")" == true ]] && ok "the API container reaches AI-01" || bad "the API container cannot reach AI-01: $h"
  [[ "$(json_field tls_verified <<<"$h")" == true ]] && ok "AI-01's certificate is verified against the pin" || bad "AI-01's certificate is NOT verified"
  if [[ "$have_cert" == yes ]]; then
    if [[ "$(json_field client_cert <<<"$h")" == true ]]; then ok "the API presents PATCH-01's client certificate"
    elif api_supports_client_cert; then bad "the API cannot load the client certificate: $(json_field client_cert_error <<<"$h")"
    else bad "the running API is older than the client-certificate support: run ./scripts/phase3b-api.sh"; fi
  fi
  local p; p="$(in_api python -m app.llm --ping 2>>"$LOG_FILE" | tail -1 || true)"
  log "ping: $p"
  [[ "$(json_field ok <<<"$p")" == true ]] && ok "the portal gets a real answer from the model" || bad "no answer from the model: $p"
  # More requests with the certificate, so AI-01's latest log lines show it
  local i; for i in 1 2 3; do in_api python -m app.llm --health >/dev/null 2>&1 || true; done
  if [[ "$have_cert" == yes && "$ENFORCED" != yes ]]; then
    # Until AI-01 requires it (mtls-enforce), AI-01 answers whether or not it trusts the certificate
    # (optional_no_ca: a certificate from another CA is only recorded as verify=FAILED there)
    note "PATCH-01 cannot see whether AI-01 trusts this client certificate until AI-01 requires it."
    say  "        Confirm on AI-01: ./ai01-harden.sh --check (T19-T21), or verify=SUCCESS for PATCH-01's"
    say  "        address in /var/log/nginx/ai01-security.log (ai01-harden.sh --step mtls-enforce checks this itself)."
  fi

  say ""
  say "  $PASS passed, $WARNS warning(s), $FAILS failed.   Log: $LOG_FILE"
  (( FAILS == 0 ))
}

do_status() {
  step "PATCH-01's AI-01 settings"
  say "  AI-01:              $AI01_URL"
  say "  pinned certificate: $(openssl x509 -noout -fingerprint -sha256 -in "$PIN_DIR/ca.crt" | cut -d= -f2)"
  if [[ -s "$PIN_DIR/client.crt" ]]; then
    say "  client certificate: $(openssl x509 -noout -subject -enddate -in "$PIN_DIR/client.crt" | tr '\n' ' ')"
  else say "  client certificate: none"; fi
  api_supports_client_cert && say "  API code:           supports client certificates" \
    || say "  API code:           older: run ./scripts/phase3b-api.sh"
}

do_import() {
  step "Checking $TAR"
  [[ -f "$TAR" ]] || die "No such file: $TAR"
  local names; names="$(tar -tf "$TAR" 2>/dev/null | sort | tr '\n' ' ')"
  [[ "$names" == "client.crt client.key " ]] || die "Unexpected contents ($names): expected client.crt and client.key only."
  mkdir -p "$TMPD/x"; tar -xf "$TAR" -C "$TMPD/x" --no-same-owner --no-same-permissions
  local c="$TMPD/x/client.crt" k="$TMPD/x/client.key"
  [[ -f "$c" && ! -L "$c" && -f "$k" && ! -L "$k" ]] || die "The bundle must hold two plain files."
  openssl x509 -noout -in "$c" 2>/dev/null || die "client.crt is not a certificate."
  [[ "$(openssl x509 -noout -pubkey -in "$c" | sha256sum)" == "$(openssl pkey -pubout -in "$k" 2>/dev/null | sha256sum)" ]] \
    || die "client.key does not belong to client.crt."
  openssl x509 -noout -ext extendedKeyUsage -in "$c" 2>/dev/null | grep -q 'TLS Web Client Authentication' \
    || die "client.crt is not a client certificate."
  openssl x509 -noout -checkend $((30 * 86400)) -in "$c" >/dev/null || die "client.crt expires within 30 days."
  say "  Subject:     $(openssl x509 -noout -subject -in "$c" | sed 's/^subject=//')"
  say "  Expires:     $(openssl x509 -noout -enddate -in "$c" | cut -d= -f2)"
  say "  Fingerprint: $(openssl x509 -noout -fingerprint -sha256 -in "$c" | cut -d= -f2)"
  say "  It must match the fingerprint ai01-harden.sh printed on AI-01."
  ask "  Does it match?" || die "Stopped: fingerprint not confirmed."

  step "Installing"
  local ts had=no; ts="$(date +%Y%m%d-%H%M%S)"
  if [[ -f "$PIN_DIR/client.crt" && -f "$PIN_DIR/client.key" ]]; then
    had=yes
    cp -a "$PIN_DIR/client.crt" "$PIN_DIR/client.crt.$ts.bak"
    cp -a "$PIN_DIR/client.key" "$PIN_DIR/client.key.$ts.bak"
  fi
  install -m 0640 -o root -g 0 "$c" "$PIN_DIR/client.crt"
  install -m 0640 -o root -g 0 "$k" "$PIN_DIR/client.key"
  say "  installed in $PIN_DIR (the API reads it as /etc/ai01/client.crt)"

  if ! api_supports_client_cert; then
    say "  The running API cannot use a client certificate yet: it must be rebuilt"
    say "  from this bundle (./scripts/phase3b-api.sh, a few minutes; the console"
    say "  is briefly unavailable while the containers restart)."
    if ask "  Rebuild the API now?"; then
      "$SRC_DIR/scripts/phase3b-api.sh" >>"$LOG_FILE" 2>&1 || { tail -15 "$LOG_FILE" >&2; die "API rebuild failed."; }
      say "  API rebuilt."
    else
      say "  Not rebuilt: the certificate is installed but unused until you run phase3b-api.sh."
    fi
  fi
  if do_test; then
    # The previous key is not kept beside the new one in a folder the containers mount
    if [[ "$had" == yes ]]; then
      shred -u "$PIN_DIR/client.key.$ts.bak" 2>/dev/null || rm -f "$PIN_DIR/client.key.$ts.bak"
      rm -f "$PIN_DIR/client.crt.$ts.bak"
    fi
    say ""
    if [[ "$ENFORCED" == yes ]]; then
      say "  Done. AI-01 requires the client certificate and accepts this one."
    else
      say "  Installed, and the portal works. PATCH-01 cannot tell whether AI-01 trusts this"
      say "  certificate (AI-01 does not require one yet): on AI-01 run ./ai01-harden.sh --check"
      say "  (T19-T21) and ./ai01-harden.sh --step mtls-enforce, which requires it only once"
      say "  AI-01 has verified PATCH-01's certificate (verify=SUCCESS in its security log)."
    fi
    if ask "  Shred $TAR (it holds a private key)?"; then shred -u "$TAR" 2>/dev/null || rm -f "$TAR"; fi
  else
    # Put back what was there, so a stale or wrong bundle cannot break the portal
    if [[ "$had" == yes ]]; then
      mv -f "$PIN_DIR/client.crt.$ts.bak" "$PIN_DIR/client.crt"
      mv -f "$PIN_DIR/client.key.$ts.bak" "$PIN_DIR/client.key"
      warn "Test failed: the previous client certificate is back in place."
    else
      rm -f "$PIN_DIR/client.crt" "$PIN_DIR/client.key"
      warn "Test failed: the new client certificate was removed again."
    fi
    do_test || true
    die "The import was undone. Check the bundle came from this AI-01 (./ai01-harden.sh --step mtls)."
  fi
}

recreate_api() {
  (cd "$COMPOSE_DIR" && docker compose -f "$COMPOSE_FILE" up -d --force-recreate) >>"$LOG_FILE" 2>&1 || return 1
  local i; for i in $(seq 1 60); do
    [[ "$(docker inspect -f '{{.State.Health.Status}}' "$CONTAINER" 2>/dev/null)" == healthy ]] && return 0
    [[ "$(docker inspect -f '{{.State.Running}}' "$CONTAINER" 2>/dev/null)" == true ]] \
      && docker exec "$CONTAINER" true >/dev/null 2>&1 && (( i > 5 )) && return 0
    sleep 2
  done
  return 1
}

do_rotate() {
  step "Switching PATCH-01 to AI-01's new API key"
  say "  On AI-01, ./ai01-harden.sh --step key-rotate printed the new key."
  local key; key="$(answer "  Paste the NEW key (input is hidden):" silent | tr -d '[:space:]')"
  [[ "$key" =~ ^[A-Fa-f0-9]{32,128}$ ]] || die "That does not look like a key from ai01-harden.sh."
  local opts=()
  [[ -s "$PIN_DIR/client.crt" ]] && opts=(--cert "$PIN_DIR/client.crt" --key "$PIN_DIR/client.key")
  # the key goes in a header file (TMPD is 0700), never on curl's command line
  printf 'Authorization: Bearer %s\n' "$key" >"$TMPD/auth"
  local code; code="$(host_code /v1/chat/completions "${opts[@]}" -H @"$TMPD/auth" -H 'Content-Type: application/json' \
    -d '{"messages":[{"role":"user","content":"Reply with the single word ok."}],"max_tokens":4,"chat_template_kwargs":{"enable_thinking":false}}' \
    --max-time 180)"
  [[ "$code" == 200 ]] || die "AI-01 did not accept the new key (HTTP $code). Nothing changed."
  say "  AI-01 accepts the new key."
  say "  The API and worker restart to read it (the console pauses for a few seconds)."
  ask "  Switch now?" || die "Stopped. Nothing changed."
  local bk; bk="$API_ENV.$(date +%Y%m%d-%H%M%S).bak"
  cp -a "$API_ENV" "$bk"
  # The key reaches awk through its environment, never a command line (ps shows those)
  AI01_NEW_KEY="$key" awk 'BEGIN { k = ENVIRON["AI01_NEW_KEY"] } /^AI01_API_KEY=/ { print "AI01_API_KEY=" k; next } { print }' \
    "$bk" >"$TMPD/api.env" && cat "$TMPD/api.env" >"$API_ENV" \
    || { cp -a "$bk" "$API_ENV"; die "Could not write the key. Nothing changed."; }
  AI01_NEW_KEY="$key" awk 'BEGIN { k = ENVIRON["AI01_NEW_KEY"]; n = 0 } $0 == "AI01_API_KEY=" k { n++ } END { exit !(n >= 1) }' "$API_ENV" \
    || { cp -a "$bk" "$API_ENV"; die "Could not write the key. Nothing changed."; }
  unset key
  if recreate_api && do_test; then
    say ""; say "  PATCH-01 uses the new key. Now on AI-01: ./ai01-harden.sh --step key-rotate"
    shred -u "$bk" 2>/dev/null || rm -f "$bk"
  else
    warn "The new key did not work end to end: putting the old one back."
    cp -a "$bk" "$API_ENV"; recreate_api || true
    do_test || true
    die "Undone: PATCH-01 is back on the old key (both keys still work on AI-01)."
  fi
}

case "$MODE" in
  test)   do_test ;;
  status) do_status ;;
  import) do_import ;;
  rotate) do_rotate ;;
esac
