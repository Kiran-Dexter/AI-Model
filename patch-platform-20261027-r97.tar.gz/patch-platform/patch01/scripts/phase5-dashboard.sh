#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 phase 5 : dashboard
#
# Serves the static console from the nginx image already on this host. The
# ingress routes / to dashboard:8080, so no ingress change is needed.
#
# Usage:
#   ./phase5-dashboard.sh --dry-run
#   ./phase5-dashboard.sh            deploy or update
#   ./phase5-dashboard.sh --check    validate
#   ./phase5-dashboard.sh --down     stop
# ---------------------------------------------------------------------------

set -Eeuo pipefail

# grep that reads all of its input before answering. "cmd | grep -q" can stop
# reading at the first match; under pipefail the writer then fails (SIGPIPE)
# and a found match reads as "not found". Used for multi-line producers.
gq() { grep "$@" >/dev/null; }

umask 022

PATCH_BASE="/patch"
ETC_DIR="/etc/patch-platform"
LOG_DIR="/var/log/patch-platform"
DASH_DIR="$PATCH_BASE/dashboard"
CONTAINER="patch01-dashboard"

DRY_RUN=no; CHECK_ONLY=no; DO_DOWN=no
while (($#)); do
  case "$1" in
    --dry-run) DRY_RUN=yes ;;
    --check)   CHECK_ONLY=yes ;;
    --down)    DO_DOWN=yes ;;
    -h|--help) sed -n '2,13p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/phase5-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"

log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Run as root."

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
COMPOSE_DIR="$PATCH_BASE/compose"
COMPOSE_FILE="$COMPOSE_DIR/docker-compose.dashboard.yml"

if [[ "$DO_DOWN" == yes ]]; then
  [[ -f "$COMPOSE_FILE" ]] && (cd "$COMPOSE_DIR" && docker compose -f "$COMPOSE_FILE" down) || true
  docker rm -f "$CONTAINER" >/dev/null 2>&1 || true
  say "Dashboard stopped. The ingress shows its placeholder page again."
  exit 0
fi

# ---------------------------------------------------------------------------
# Check
# ---------------------------------------------------------------------------
if [[ "$CHECK_ONLY" == yes ]]; then
  step "Validating the dashboard"
  FAILS=0
  if docker ps --format '{{.Names}}' | gq -x "$CONTAINER"; then
    st="$(docker inspect "$CONTAINER" --format '{{.State.Health.Status}}' 2>/dev/null || echo none)"
    say "$CONTAINER: running, health=$st"
    [[ "$st" == healthy || "$st" == none ]] || FAILS=$((FAILS+1))
  else
    warn "$CONTAINER is not running"; FAILS=$((FAILS+1))
  fi

  BODY="$(curl -sk --noproxy '*' --max-time 15 https://127.0.0.1/ 2>/dev/null || true)"
  if printf '%s' "$BODY" | grep -q 'src="app.js'; then
    say "Ingress serves the dashboard at /"
  elif printf '%s' "$BODY" | grep -qi 'not deployed'; then
    warn "Ingress still shows its placeholder: it cannot reach dashboard:8080"
    FAILS=$((FAILS+1))
  else
    warn "Unexpected response at /"; FAILS=$((FAILS+1))
  fi

  CSP="$(curl -skI --noproxy '*' --max-time 15 https://127.0.0.1/ 2>/dev/null | grep -i '^content-security-policy' || true)"
  [[ -n "$CSP" ]] && say "Content-Security-Policy header present" \
    || { warn "Content-Security-Policy header missing"; FAILS=$((FAILS+1)); }

  # Scripts: compressed, and kept by the browser once fingerprinted
  APPJS="$(printf '%s' "$BODY" | grep -o 'app.js?v=[0-9a-f]*' | head -1 || true)"
  if [[ -n "$APPJS" ]]; then
    HDRS="$(curl -sk --noproxy '*' -o /dev/null -D - --max-time 15 -H 'Accept-Encoding: gzip' "https://127.0.0.1/$APPJS" 2>/dev/null || true)"
    printf '%s' "$HDRS" | grep -qi '^content-encoding: *gzip' && say "Scripts are sent compressed" \
      || { warn "Scripts are not compressed (dashboard nginx.conf)"; FAILS=$((FAILS+1)); }
    printf '%s' "$HDRS" | grep -qi '^cache-control:.*immutable' && say "Fingerprinted scripts are cached by browsers" \
      || { warn "Fingerprinted scripts are not cacheable (dashboard nginx.conf)"; FAILS=$((FAILS+1)); }
    printf '%s' "$HDRS" | grep -qi '^content-security-policy' \
      || { warn "Content-Security-Policy header missing on scripts"; FAILS=$((FAILS+1)); }
  else
    warn "index.html names no fingerprinted app.js (run this script without --check)"; FAILS=$((FAILS+1))
  fi

  # The dashboard needs API endpoints added alongside it
  CODE="$(curl -sk --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 15 \
    -H 'X-Requested-With: patch01-dashboard' https://127.0.0.1/api/v1/admin/compliance || true)"; CODE="${CODE:-000}"
  case "$CODE" in
    401) say "API has the endpoints the dashboard needs" ;;
    404) warn "API is older than the dashboard. Rebuild it: ./scripts/phase3b-api.sh"
         FAILS=$((FAILS+1)) ;;
    *)   warn "API returned HTTP $CODE for /admin/compliance"; FAILS=$((FAILS+1)) ;;
  esac

  pmap="$(docker port "$CONTAINER" 2>/dev/null || true)"
  [[ -z "$pmap" ]] && say "$CONTAINER publishes no host port - correct" \
    || { warn "$CONTAINER publishes: $pmap"; FAILS=$((FAILS+1)); }

  (( FAILS == 0 )) && say "
All checks passed." || die "$FAILS check(s) failed."
  exit 0
fi

# ---------------------------------------------------------------------------
# Preconditions
# ---------------------------------------------------------------------------
step "Checking preconditions"

[[ -f "$ETC_DIR/images.env" ]] || die "No $ETC_DIR/images.env. Run resolve-images.sh"
# shellcheck disable=SC1090
source "$ETC_DIR/images.env"
NGINX_IMAGE="${IMG_NGINX:-}"
[[ -n "$NGINX_IMAGE" ]] || die "The manifest has no nginx image."
docker image inspect "$NGINX_IMAGE" >/dev/null 2>&1 || die "$NGINX_IMAGE is not present."
say "Image: $NGINX_IMAGE (${VER_NGINX:-unknown})"

docker network inspect patchnet >/dev/null 2>&1 || die "patchnet is missing. Run phase1a first."
docker ps --format '{{.Names}}' | gq -x patch01-nginx || die "The ingress is not running."

for f in index.html app.js map.js hardening.js cyber.js nessus.js overview.js gauge.js style.css theme.js; do
  [[ -f "$SRC_DIR/dashboard/html/$f" ]] || die "Missing dashboard/html/$f in the bundle"
done
[[ -f "$SRC_DIR/dashboard/nginx.conf" ]] || die "Missing dashboard/nginx.conf"
# Every page in the menu must be known to the AI-01 assistant (and the API must be updated with it)
if command -v python3 >/dev/null 2>&1; then
  python3 "$SRC_DIR/scripts/check-assistant-coverage.py" "$SRC_DIR" >>"$LOG_FILE" 2>&1 \
    || { python3 "$SRC_DIR/scripts/check-assistant-coverage.py" "$SRC_DIR" >&2 || true; die "The AI-01 assistant is not up to date with the console's pages."; }
fi

# Warn early if the API predates the endpoints the dashboard calls
CODE="$(curl -sk --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 15 \
  -H 'X-Requested-With: patch01-dashboard' https://127.0.0.1/api/v1/admin/compliance || true)"; CODE="${CODE:-000}"
if [[ "$CODE" == "404" ]]; then
  warn "The API does not have /admin/compliance yet."
  warn "Rebuild it after this step:  ./scripts/phase3b-api.sh"
fi

# ---------------------------------------------------------------------------
# Install files
# ---------------------------------------------------------------------------
step "Installing the dashboard files"

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] copy dashboard/html and nginx.conf to $DASH_DIR"
else
  mkdir -p "$DASH_DIR/html"
  cp -f "$SRC_DIR"/dashboard/html/* "$DASH_DIR/html/"
  # Files from older versions that this version no longer has (r90: shell.css merged into style.css)
  for old in "$DASH_DIR"/html/*; do
    [[ -f "$old" && ! -e "$SRC_DIR/dashboard/html/$(basename "$old")" ]] || continue
    rm -f -- "$old"; say "Removed $(basename "$old") (no longer part of the console)"
  done
  # Stamp each script and stylesheet with its own fingerprint, so a browser
  # always fetches the new file after an update instead of reusing an old one
  for f in theme.js style.css map.js hardening.js cyber.js nessus.js overview.js app.js gauge.js; do
    [[ -f "$DASH_DIR/html/$f" ]] || continue
    v="$(sha256sum "$DASH_DIR/html/$f" | cut -c1-10)"
    sed -i -E "s#(src|href)=\"$f(\?v=[0-9a-f]+)?\"#\1=\"$f?v=$v\"#" "$DASH_DIR/html/index.html"
  done
  say "Console files stamped for this version: $(grep -o 'app.js?v=[0-9a-f]*' "$DASH_DIR/html/index.html")"
  cp -f "$SRC_DIR/dashboard/nginx.conf" "$DASH_DIR/nginx.conf"
  # Static and non-secret, so world-readable. That also removes any
  # dependence on which UID the nginx image happens to run as.
  find "$DASH_DIR" -type d -exec chmod 0755 {} \;
  find "$DASH_DIR" -type f -exec chmod 0644 {} \;
  chown -R root:root "$DASH_DIR"
  say "Installed to $DASH_DIR"

  # Validate the config inside the image before starting anything
  if docker run --rm --network none \
      -v "$DASH_DIR/nginx.conf:/etc/nginx-dash/nginx.conf:ro" \
      -v "$DASH_DIR/html:/opt/dashboard:ro" \
      --entrypoint "" "$NGINX_IMAGE" nginx -t -c /etc/nginx-dash/nginx.conf >>"$LOG_FILE" 2>&1; then
    say "nginx configuration is valid"
  else
    tail -15 "$LOG_FILE" >&2
    die "The dashboard nginx configuration failed validation."
  fi
fi

# ---------------------------------------------------------------------------
# Deploy
# ---------------------------------------------------------------------------
step "Starting the dashboard"

TMPL="$SRC_DIR/compose/docker-compose.dashboard.yml.tmpl"
[[ -f "$TMPL" ]] || die "Template not found: $TMPL"

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] generate $COMPOSE_FILE and docker compose up -d"
  exit 0
fi

sed -e "s|@@NGINX_IMAGE@@|$NGINX_IMAGE|g" -e "s|@@DASH_DIR@@|$DASH_DIR|g" \
  "$TMPL" >"$COMPOSE_FILE"
chmod 0640 "$COMPOSE_FILE"
grep -q '@@' "$COMPOSE_FILE" && die "Unfilled placeholders in $COMPOSE_FILE" || true
docker compose -f "$COMPOSE_FILE" config >/dev/null 2>>"$LOG_FILE" || die "Invalid compose file."

(cd "$COMPOSE_DIR" && docker compose -f "$COMPOSE_FILE" up -d --force-recreate) >>"$LOG_FILE" 2>&1 \
  || { tail -20 "$LOG_FILE" >&2; die "Deployment failed."; }

for i in $(seq 1 30); do
  BODY="$(curl -sk --noproxy '*' --max-time 5 https://127.0.0.1/ 2>/dev/null || true)"
  if printf '%s' "$BODY" | grep -q 'src="app.js'; then
    say "Dashboard is live through the ingress."
    break
  fi
  if (( i == 30 )); then
    warn "The ingress is not serving the dashboard yet."
    docker logs --tail 20 "$CONTAINER" 2>&1 >&2 || true
    die "Timed out."
  fi
  sleep 1
done

FQDN="$(hostname -f 2>/dev/null || hostname)"
echo
echo "================================================================"
echo " PHASE 5 COMPLETE - DASHBOARD"
echo "================================================================"
printf ' Open:      https://%s/\n' "$FQDN"
printf ' Sign in:   admin, password from %s/secrets/api.env\n' "$PATCH_BASE"
printf ' Container: %s  (no host port)\n' "$CONTAINER"
printf ' Log:       %s\n' "$LOG_FILE"
echo
echo " Validate:  ./scripts/phase5-dashboard.sh --check"
