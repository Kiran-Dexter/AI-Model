#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 : update this server (OS packages, container images) and check its health
#
# Usage:
#   ./scripts/patch01-update.sh                     health check only (changes nothing)
#   ./scripts/patch01-update.sh --os                OS updates (dnf), then health check
#   ./scripts/patch01-update.sh --os --security     only security updates
#   ./scripts/patch01-update.sh --images            re-pull the current image tags; redeploy what changed
#   ./scripts/patch01-update.sh --all --reboot      both, and restart if needed (health checked after boot)
#   ./scripts/patch01-update.sh --dry-run --all     show what would be updated, change nothing
#
# Options:
#   --yes        no questions (for a scheduled run)
#   --force      go on although patch jobs are running or the system is unhealthy before
#   --keep N     database backups to keep (default 5)
#   --wait-lock  wait (up to 30 min) for a run in progress instead of stopping (used at boot)
#
# What it does, in order:
#   1. Refuses to run twice at once, as non-root, or while patch jobs are running.
#   2. Health check BEFORE: an update never starts on a broken system (unless --force).
#   3. Backup: every database (pg_dumpall), the image list and the package list,
#      in /patch/backups/update-<time>/ (root only, mode 0700/0600). Old ones pruned.
#   4. OS: dnf upgrade (or --security). Docker restarts its containers if updated.
#   5. Images: each image in /etc/patch-platform/images.env is re-pulled by its
#      tag; only stacks whose image changed are redeployed. A PostgreSQL major
#      version change is refused (that needs a dump and restore, never automatic).
#   6. Health check AFTER, with the result in the log and update-last.txt.
#   7. With --reboot and a restart needed: a one-shot service runs the health
#      check after boot and removes itself.
#
# Security: nothing secret is printed or logged (no passwords, keys or tokens);
# backups and logs are readable by root only; every command is run by fixed
# path with fixed arguments; nothing here downloads or runs code from outside
# dnf's signed repositories and the configured container registry.
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 077
export LC_ALL=C

# grep that reads all of its input (see phase5-dashboard.sh)
gq() { grep "$@" >/dev/null; }

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
SCRIPTS="$(dirname "$SELF")"
PATCH_BASE="/patch"
ETC_DIR="/etc/patch-platform"
LOG_DIR="/var/log/patch-platform"
BACKUP_ROOT="$PATCH_BASE/backups"
PG="patch01-postgres"
DB="patchdb"
UNIT="patch01-postboot-check"
LOCK="/run/patch01-update.lock"

REDEPLOY_FAILED=""
DO_OS=no; SECURITY=no; DO_IMAGES=no; DO_REBOOT=no; DRY_RUN=no; YES=no; FORCE=no; KEEP=5; POST_BOOT=no; WAIT_LOCK=no
while (($#)); do
  case "$1" in
    --os)        DO_OS=yes ;;
    --security)  SECURITY=yes ;;
    --images)    DO_IMAGES=yes ;;
    --all)       DO_OS=yes; DO_IMAGES=yes ;;
    --reboot)    DO_REBOOT=yes ;;
    --dry-run)   DRY_RUN=yes ;;
    --yes)       YES=yes ;;
    --force)     FORCE=yes ;;
    --keep)      KEEP="${2:-}"; shift ;;
    --check)     ;;
    --post-boot) POST_BOOT=yes ;;
    --wait-lock) WAIT_LOCK=yes ;;
    -h|--help)   sed -n '2,37p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done
[[ "$KEEP" =~ ^[1-9][0-9]?$ ]] || { echo "--keep takes 1 to 99" >&2; exit 2; }
[[ "$SECURITY" == no || "$DO_OS" == yes ]] || { echo "--security goes with --os" >&2; exit 2; }
[[ $EUID -eq 0 ]] || { echo "Run as root." >&2; exit 1; }

mkdir -p "$LOG_DIR"; chmod 0750 "$LOG_DIR"
LOG_FILE="$LOG_DIR/patch01-update-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"
log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }
trap 'die "Stopped at line $LINENO (exit $?)."' ERR

confirm() {
  [[ "$YES" == yes ]] && return 0
  [[ -t 0 ]] || die "Not a terminal: add --yes to run without questions."
  local r; read -r -p "$1 [y/N]: " r || true
  [[ "${r,,}" =~ ^(y|yes)$ ]]
}

# One run at a time (a scheduled run and a manual one must never overlap)
exec 8>"$LOCK"
take_lock() {
  if [[ "$WAIT_LOCK" == yes ]]; then
    flock -n 8 || { say "Another patch01-update.sh is running: waiting for it (up to 30 minutes)"
                    flock -w 1800 8 || die "Another patch01-update.sh is still running after 30 minutes."; }
  else
    flock -n 8 || die "Another patch01-update.sh is running."
  fi
}
# After a reboot the lock is taken only once every part is started (below):
# patch01-start.sh's own boot run ends with a health check that needs it, and
# waiting here for that run while it waits for us would deadlock
[[ "$POST_BOOT" == yes ]] || take_lock

# This script runs as root (and, with --reboot, from a boot-time service):
# refuse if anyone but root could have changed it or the scripts it calls
safe_path() {   # owned by root and not writable by group or others (a sticky /tmp-style folder is not acceptable here)
  [[ "$(stat -c %u "$1")" == 0 ]] || die "$1 is not owned by root: refusing to run from it as root."
  (( ( 8#$(stat -c %a "$1") & 8#022 ) == 0 )) || die "$1 is writable by others than root: fix with chmod go-w $1"
}
d="$SCRIPTS"; while [[ "$d" != / ]]; do safe_path "$d"; d="$(dirname "$d")"; done
for f in "$SELF" "$SCRIPTS"/*.sh "$SCRIPTS"/*.py; do [[ -e "$f" ]] && safe_path "$f"; done

# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------
HC_FAIL=0; HC_WARN=0; SCHEMA_BEHIND=no
ok()   { say "  ok    $*"; }
bad()  { say "  FAIL  $*"; HC_FAIL=$((HC_FAIL+1)); }
note() { say "  warn  $*"; HC_WARN=$((HC_WARN+1)); }

run_check() {   # name, required(yes/no), script and args: a phase script's own --check
  local name="$1" req="$2"; shift 2
  [[ -x "$SCRIPTS/$1" ]] || { [[ "$req" == yes ]] && bad "$name: $1 missing" || note "$name: $1 missing"; return 0; }
  if "$SCRIPTS/$@" </dev/null >>"$LOG_FILE" 2>&1; then ok "$name"
  elif [[ "$req" == yes ]]; then bad "$name (see $LOG_FILE)"
  else note "$name not passing (optional part; see $LOG_FILE)"; fi
}

sql() { docker exec -i "$PG" psql -U postgres -d "$DB" -qtAX -v ON_ERROR_STOP=1 -c "$1" 2>>"$LOG_FILE"; }

health() {
  local when="$1"
  step "Health check ($when)"
  HC_FAIL=0; HC_WARN=0; SCHEMA_BEHIND=no
  # The server itself
  local pct
  for m in / "$PATCH_BASE"; do
    [[ -d "$m" ]] || continue
    pct="$(df -P "$m" | awk 'NR==2 {gsub("%","",$5); print $5}')"
    if (( pct >= 90 )); then bad "disk $m ${pct}% used"; elif (( pct >= 80 )); then note "disk $m ${pct}% used"; else ok "disk $m ${pct}% used"; fi
  done
  local failed; failed="$(systemctl --failed --no-legend --plain 2>/dev/null | awk '{print $1}' | tr '\n' ' ')"
  [[ -z "${failed// }" ]] && ok "no failed system services" || note "failed system services: $failed"
  [[ "$(timedatectl show -p NTPSynchronized --value 2>/dev/null)" == yes ]] && ok "clock synchronised" \
    || note "clock not synchronised (certificates and schedules depend on it)"
  systemctl is-active --quiet docker && ok "docker running" || { bad "docker not running"; return 0; }

  # Containers: running, and healthy where they report health
  local c st hs
  for c in patch01-nginx patch01-postgres patch01-redis patch01-pulp-api patch01-pulp-content patch01-pulp-worker \
           patch01-api patch01-worker patch01-dashboard; do
    st="$(docker inspect -f '{{.State.Status}}' "$c" 2>/dev/null || echo missing)"
    hs="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$c" 2>/dev/null || echo none)"
    if [[ "$st" == running && ( "$hs" == healthy || "$hs" == none ) ]]; then ok "$c running$([[ "$hs" == healthy ]] && echo ' (healthy)')"
    elif [[ "$st" == running && "$hs" == starting ]]; then note "$c still starting"
    else bad "$c: $st${hs:+ ($hs)}"; fi
  done

  # The console and the API answer through the ingress
  local code
  code="$(curl -sk --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 15 https://127.0.0.1/api/v1/health || true)"; code="${code:-000}"
  [[ "$code" == 200 ]] && ok "API health through the ingress: 200" || bad "API health returned $code"
  code="$(curl -sk --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 15 https://127.0.0.1/ || true)"; code="${code:-000}"
  [[ "$code" == 200 ]] && ok "console page: 200" || bad "console page returned $code"

  # The worker is alive (its change loop beats every few seconds)
  local age; age="$(sql "SELECT coalesce(extract(epoch FROM now() - max(beat_at))::int, 99999) FROM worker_heartbeat WHERE name = 'changes'" || echo 99999)"
  [[ "$age" =~ ^[0-9]+$ ]] || age=99999
  (( age < 300 )) && ok "worker heartbeat ${age}s ago" || bad "worker heartbeat ${age}s ago (expected under 300 s)"

  # PATCH-01's certificate
  if [[ -f "$PATCH_BASE/certs/patch01.crt" ]]; then
    if openssl x509 -checkend $((30*86400)) -noout -in "$PATCH_BASE/certs/patch01.crt" >/dev/null 2>&1; then ok "certificate valid for 30+ days"
    elif openssl x509 -checkend 0 -noout -in "$PATCH_BASE/certs/patch01.crt" >/dev/null 2>&1; then note "certificate expires within 30 days"
    else bad "certificate has expired"; fi
  fi

  # Each part's own detailed check (required parts fail the run; optional ones only warn)
  run_check "ingress"           yes phase1a-ingress.sh --check
  run_check "database and redis" yes phase1b-data.sh --check
  run_check "pulp (mirrors)"    yes phase1c-pulp.sh --check
  local before=$HC_FAIL
  run_check "database schema"   yes phase3a-schema.sh --check
  # This script never changes the schema. After a new bundle is unpacked its
  # migrations (and the API built for them) are applied by hand, in order
  (( HC_FAIL > before )) && SCHEMA_BEHIND=yes || true
  run_check "API and worker"    yes phase3b-api.sh --check
  run_check "dashboard"         yes phase5-dashboard.sh --check
  run_check "link to AI-01"     no  phase6-llm.sh --check
  run_check "mail"              no  phase9-mail.sh --check
  if [[ -d "$PATCH_BASE/secrets/vcenter" ]]; then run_check "vCenter" no phase7-vmware.sh --check; fi

  say ""
  if (( HC_FAIL == 0 )); then say "Health ($when): PASS ($HC_WARN warning(s))"; else say "Health ($when): FAIL: $HC_FAIL problem(s), $HC_WARN warning(s)"; fi
  [[ "$SCHEMA_BEHIND" == yes ]] && say "The database schema check failed: after installing a new bundle, run ./scripts/phase3a-schema.sh (then phase3b-api.sh)." || true
  printf '%s  %s  %s failed, %s warnings  (log %s)\n' "$(date '+%F %T')" "$when" "$HC_FAIL" "$HC_WARN" "$LOG_FILE" \
    > "$LOG_DIR/update-last.txt"
  chmod 0640 "$LOG_DIR/update-last.txt"
}

# Containers come back over a few minutes after docker or a reboot restarts them
wait_settled() {
  local i up
  for i in $(seq 1 60); do
    up=0
    for c in patch01-postgres patch01-api patch01-worker patch01-nginx; do
      [[ "$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "$c" 2>/dev/null)" =~ ^(healthy|running)$ ]] && up=$((up+1))
    done
    (( up == 4 )) && { sleep 20; return 0; }
    sleep 10
  done
  warn "Containers had not settled after 10 minutes."
}

# Start every part in order and repair what does not come up (patch01-start.sh), then wait for it to settle.
# After a reboot, patch01-start.service may be starting everything already: wait for it, do not fail on its lock.
start_all() {
  local sargs=(--no-health); [[ "$POST_BOOT" == yes ]] && sargs+=(--wait-lock)
  say "  starting every part in order (patch01-start.sh)"
  if "$SCRIPTS/patch01-start.sh" "${sargs[@]}" </dev/null 8>&- >>"$LOG_FILE" 2>&1; then say "  every part is up"
  else warn "patch01-start.sh could not bring every part up (details in $LOG_FILE)"; fi
  wait_settled
}

needs_restart() {
  if command -v needs-restarting >/dev/null 2>&1; then
    ! needs-restarting -r >/dev/null 2>&1
  else
    # Without dnf-utils: a newer kernel installed than the one running
    local newest; newest="$(rpm -q --last kernel 2>/dev/null | head -1 | awk '{print $1}' | sed 's/^kernel-//')"
    [[ -n "$newest" && "$newest" != "$(uname -r)" ]]
  fi
}

# ---------------------------------------------------------------------------
# After a reboot (the one-shot service)
# ---------------------------------------------------------------------------
if [[ "$POST_BOOT" == yes ]]; then
  trap - ERR
  # Runs once: disabled first, so it never repeats at the next boot even if it is stopped part way
  systemctl disable "$UNIT.service" >/dev/null 2>&1 || true
  start_all                      # waits for patch01-start.service's own run, if any
  # and for its health check (a check still running after 30 minutes is not waited for: this one runs anyway,
  # so the one-shot unit is always removed below)
  flock -w 1800 8 || warn "Another patch01-update.sh is still running after 30 minutes: checking anyway."
  health "after the restart"
  systemctl disable "$UNIT.service" >/dev/null 2>&1 || true
  rm -f "/etc/systemd/system/$UNIT.service"; systemctl daemon-reload || true
  (( HC_FAIL == 0 )) || exit 1
  exit 0
fi

# Health check only
if [[ "$DO_OS" == no && "$DO_IMAGES" == no && "$DO_REBOOT" == no ]]; then
  trap - ERR
  health "now"
  (( HC_FAIL == 0 )) || exit 1
  exit 0
fi

# ---------------------------------------------------------------------------
# Before updating
# ---------------------------------------------------------------------------
step "Before updating"
command -v dnf >/dev/null || die "dnf not found: this script is for PATCH-01 (RHEL 9)."
RUNNING="$(sql "SELECT count(*) FROM changes WHERE state = 'running'" || echo "?")"
SOON="$(sql "SELECT count(*) FROM changes WHERE state = 'scheduled' AND run_after < now() + interval '2 hours'" || echo "?")"
say "Patch jobs running now: $RUNNING; scheduled to start within 2 hours: $SOON"
if [[ "$RUNNING" != 0 ]]; then
  [[ "$FORCE" == yes ]] || die "Patch jobs are running (or the count is unknown): updating PATCH-01 now would interrupt them. Wait, or add --force."
  warn "Going on with patch jobs running (--force)."
fi
[[ "$SOON" == 0 ]] || warn "Jobs are due within 2 hours: they wait while PATCH-01 restarts."

trap - ERR
health "before"
trap 'die "Stopped at line $LINENO (exit $?)."' ERR
if (( HC_FAIL > 0 )); then
  [[ "$SCHEMA_BEHIND" == no || "$FORCE" == yes ]] \
    || die "The database schema check failed (see $LOG_FILE). If a new bundle was just installed, apply it first: ./scripts/phase3a-schema.sh, then ./scripts/phase3b-api.sh and ./scripts/phase5-dashboard.sh; then update."
  [[ "$FORCE" == yes ]] || die "PATCH-01 is not healthy before the update: run $SCRIPTS/patch01-start.sh to start and repair it, then update (or add --force)."
  warn "Updating an unhealthy system (--force)."
fi

# What would change
OS_COUNT=0
if [[ "$DO_OS" == yes ]]; then
  step "OS updates available"
  DNF_ARGS=(--refresh -q); [[ "$SECURITY" == yes ]] && DNF_ARGS+=(--security)
  rc=0; dnf "${DNF_ARGS[@]}" check-update >"$LOG_DIR/.dnf-check" 2>>"$LOG_FILE" || rc=$?   # 100: updates available
  case "$rc" in
    0)   say "None." ;;
    100) OS_COUNT="$(grep -cE '^[A-Za-z0-9_.+-]+\.(x86_64|noarch|i686|aarch64)\s' "$LOG_DIR/.dnf-check" || true)"
         say "$OS_COUNT package(s) to update$([[ "$SECURITY" == yes ]] && echo ' (security)')"
         grep -E '^(kernel|docker|containerd|openssl|glibc|systemd)[.-]' "$LOG_DIR/.dnf-check" | awk '{print "  " $1 "  " $2}' | head -15 || true ;;
    *)   die "dnf could not read the repositories (exit $rc): check the subscription and the proxy." ;;
  esac
  rm -f "$LOG_DIR/.dnf-check"
fi
if [[ "$DO_IMAGES" == yes ]]; then
  [[ -r "$ETC_DIR/images.env" ]] || die "No $ETC_DIR/images.env: run resolve-images.sh first."
  say "Images to re-pull: $(grep -cE '^IMG_[A-Z0-9_]+="[^"]+"' "$ETC_DIR/images.env" | tr -d ' ') (from images.env)"
fi
if [[ "$DRY_RUN" == yes ]]; then say ""; say "Dry run: nothing changed."; exit 0; fi
UPDATING=no
[[ "$DO_IMAGES" == yes || ( "$DO_OS" == yes && "$OS_COUNT" != 0 ) ]] && UPDATING=yes
if [[ "$UPDATING" == yes ]]; then
  confirm "Update PATCH-01 now? The console is unavailable for a few minutes" || die "Not confirmed."
else
  say "Nothing to update."
fi

# ---------------------------------------------------------------------------
# Backup
# ---------------------------------------------------------------------------
BK="(none)"
if [[ "$UPDATING" == yes ]]; then
step "Backup"
BK="$BACKUP_ROOT/update-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BK"; chmod 0700 "$BACKUP_ROOT" "$BK"
NEED_MB=$(( $(sql "SELECT (sum(pg_database_size(datname)) / 1048576)::bigint FROM pg_database" || echo 0) + 1024 ))
FREE_MB="$(df -Pm "$BACKUP_ROOT" | awk 'NR==2 {print $4}')"
(( FREE_MB > NEED_MB )) || die "Only ${FREE_MB} MB free for a backup needing about ${NEED_MB} MB."
docker exec "$PG" pg_dumpall -U postgres 2>>"$LOG_FILE" | gzip -6 > "$BK/postgres.sql.gz"
gzip -t "$BK/postgres.sql.gz" || die "The database backup is damaged."
(( $(stat -c %s "$BK/postgres.sql.gz") > 1024 )) || die "The database backup is empty."
cp -p "$ETC_DIR/images.env" "$BK/" 2>/dev/null || true
rpm -qa --qf '%{NAME}-%{EPOCHNUM}:%{VERSION}-%{RELEASE}.%{ARCH}\n' | sort > "$BK/packages-before.txt"
docker images --digests --format '{{.Repository}}:{{.Tag}} {{.Digest}} {{.ID}}' | sort > "$BK/images-before.txt"
chmod 0600 "$BK"/*
say "Saved in $BK ($(du -sh "$BK" | cut -f1))"
mapfile -t OLD < <(ls -1d "$BACKUP_ROOT"/update-* 2>/dev/null | sort | head -n -"$KEEP")
for d in "${OLD[@]}"; do rm -rf --one-file-system -- "$d"; say "Removed old backup $(basename "$d")"; done
fi

# ---------------------------------------------------------------------------
# OS
# ---------------------------------------------------------------------------
if [[ "$DO_OS" == yes && "$OS_COUNT" != 0 ]]; then
  step "OS updates"
  DNF_ARGS=(-y); [[ "$SECURITY" == yes ]] && DNF_ARGS+=(--security)
  dnf "${DNF_ARGS[@]}" upgrade >>"$LOG_FILE" 2>&1 || die "dnf upgrade failed. The backup is in $BK."
  rpm -qa --qf '%{NAME}-%{EPOCHNUM}:%{VERSION}-%{RELEASE}.%{ARCH}\n' | sort > "$BK/packages-after.txt"; chmod 0600 "$BK/packages-after.txt"
  say "Updated $(comm -13 "$BK/packages-before.txt" "$BK/packages-after.txt" | wc -l | tr -d ' ') package(s) (dnf history list shows the transaction; dnf history undo can roll it back)"
  start_all
fi

# ---------------------------------------------------------------------------
# Container images
# ---------------------------------------------------------------------------
pg_major() { docker run --rm --network none --entrypoint postgres "$1" --version 2>/dev/null | grep -oE '[0-9]+' | head -1; }

if [[ "$DO_IMAGES" == yes ]]; then
  step "Container images"
  CHANGED=()
  while IFS='=' read -r key val; do
    [[ "$key" =~ ^IMG_([A-Z0-9_]+)$ ]] || continue
    role="${BASH_REMATCH[1],,}"
    [[ "$role" =~ _(variant|digest)$ ]] && continue
    [[ "$role" == node ]] && continue          # listed by resolve-images.sh, used by nothing
    ref="${val%\"}"; ref="${ref#\"}"
    [[ -n "$ref" ]] || continue
    [[ "$ref" =~ ^[A-Za-z0-9][A-Za-z0-9._/:@-]{1,250}$ ]] || { warn "Skipping an image name with unexpected characters ($role)."; continue; }
    if [[ "$ref" == *@sha256:* && "$ref" != *:*@* ]]; then say "  $role: pinned by digest, left as is"; continue; fi
    before="$(docker image inspect -f '{{.Id}}' "$ref" 2>/dev/null || echo none)"
    if ! docker pull -q "$ref" >>"$LOG_FILE" 2>&1; then warn "$role: could not pull $ref (registry or proxy): kept the current one"; continue; fi
    after="$(docker image inspect -f '{{.Id}}' "$ref" 2>/dev/null || echo none)"
    if [[ "$before" == "$after" ]]; then say "  $role: up to date"
    else
      if [[ "$role" == postgres && "$before" != none ]]; then
        mb="$(docker run --rm --network none --entrypoint postgres "$before" --version 2>/dev/null | grep -oE '[0-9]+' | head -1 || true)"
        ma="$(pg_major "$ref" || true)"
        if [[ -n "$mb" && "$mb" != "$ma" ]]; then
          docker tag "$before" "$ref"   # put the old image back under the tag
          die "The postgres tag now points at PostgreSQL $ma (was $mb): a major upgrade needs a dump and restore. The old image is kept; nothing was redeployed."
        fi
      fi
      say "  $role: newer image pulled"; CHANGED+=("$role")
    fi
  done < "$ETC_DIR/images.env"

  if ((${#CHANGED[@]})); then
    "$SCRIPTS/resolve-images.sh" </dev/null >>"$LOG_FILE" 2>&1 || die "resolve-images.sh failed. Backup: $BK."
    has() { local r; for r in "${CHANGED[@]}"; do [[ "$r" == "$1" ]] && return 0; done; return 1; }
    redeploy() { say "  redeploying: $1"; "$SCRIPTS/$1" </dev/null >>"$LOG_FILE" 2>&1 \
                   || { warn "$1 failed (backup: $BK): starting and repairing every part next"; REDEPLOY_FAILED="$1"; }; }
    if has postgres || has redis; then redeploy phase1b-data.sh; fi
    if has pulp || has pulp_web; then redeploy phase1c-pulp.sh; fi
    if has nginx; then redeploy phase1a-ingress.sh; fi
    if has python || has postgres; then redeploy phase3b-api.sh; fi
    if has nginx; then redeploy phase5-dashboard.sh; fi
    start_all
  else
    say "No image changed: nothing redeployed."
  fi
fi

# ---------------------------------------------------------------------------
# After updating
# ---------------------------------------------------------------------------
trap - ERR
health "after the update"
RESULT=$HC_FAIL
if [[ -n "$REDEPLOY_FAILED" ]]; then say "$REDEPLOY_FAILED failed during the update: see $LOG_FILE"; RESULT=$((RESULT + 1)); fi

if needs_restart; then
  if [[ "$DO_REBOOT" == yes && "$RESULT" -gt 0 && "$FORCE" == no ]]; then
    say ""
    say "A restart is needed, but the health check failed: not restarting. Fix the problems above, then run $SELF --reboot"
  elif [[ "$DO_REBOOT" == yes ]]; then
    step "Restart"
    # The boot-time check runs this same script, which was verified above as root-owned
    cat > "/etc/systemd/system/$UNIT.service" <<EOF
[Unit]
Description=PATCH-01 health check after an update restart (runs once, then removes itself)
# After patch01-start.service (when installed with --install-boot): its start
# and health check finish first, so this check never runs mid-start
After=docker.service network-online.target patch01-start.service
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=$SELF --post-boot
# Worst case: up to 30 min waiting for patch01-start.service, its own start
# (up to ~40 min with repairs), 10 min settling, 30 min for the update lock,
# then the health check. It is disabled as its first step, so a timeout never
# makes it run again at the next boot.
TimeoutStartSec=7200

[Install]
WantedBy=multi-user.target
EOF
    chmod 0644 "/etc/systemd/system/$UNIT.service"
    systemctl daemon-reload; systemctl enable "$UNIT.service" >/dev/null 2>&1
    say "Restarting in 1 minute. The health check runs after boot: see $LOG_DIR/update-last.txt"
    shutdown -r +1 "PATCH-01 restarts after its update" >/dev/null 2>&1 || systemctl reboot
  else
    say ""
    say "A restart is needed to finish the update (new kernel or core libraries)."
    say "Restart in a quiet moment with:  $SELF --reboot --yes"
  fi
fi
say "Log: $LOG_FILE"
(( RESULT == 0 )) || exit 1
exit 0
