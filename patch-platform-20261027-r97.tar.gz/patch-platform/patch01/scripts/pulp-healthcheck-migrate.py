#!/usr/bin/env python3
"""Bring the Pulp health checks of a deployed compose file up to date (r96).

  pulp-healthcheck-migrate.py <deployed compose file> <bundle template>

For pulp-api, pulp-content and pulp-worker: if the deployed `test:` line is one
of the old ones (curl -fs / pgrep -f), replace it with the template's. A line
someone changed by hand is left alone. Prints what changed; exit 0 = changed,
1 = nothing to do, 2 = error (file untouched). Writes in place, keeping the
file's owner and mode; the caller keeps a backup and validates the result.
"""
import os
import re
import sys

OLD = {
    "pulp-api": '      test: ["CMD-SHELL", "curl -fs http://127.0.0.1:24817/pulp/api/v3/status/ >/dev/null || exit 1"]',
    "pulp-content": '      test: ["CMD-SHELL", "curl -fs http://127.0.0.1:24816/pulp/content/ >/dev/null || exit 1"]',
    "pulp-worker": '      test: ["CMD-SHELL", "pgrep -f pulpcore-worker >/dev/null || exit 1"]',
}


def blocks(lines):
    """service name -> (start, end) line ranges at two-space indentation under services:"""
    out, cur, start = {}, None, None
    for i, ln in enumerate(lines):
        m = re.match(r"^  ([a-z0-9-]+):\s*$", ln)
        if m or re.match(r"^\S", ln):
            if cur:
                out[cur] = (start, i)
            cur, start = (m.group(1), i) if m else (None, None)
    if cur:
        out[cur] = (start, len(lines))
    return out


def new_lines(tmpl, svc):
    """the template's comment lines plus test: line for one service"""
    lines = tmpl.splitlines()
    s, e = blocks(lines)[svc]
    for i in range(s, e):
        if lines[i].startswith("      test: "):
            j = i
            while j > s and lines[j - 1].startswith("      # "):
                j -= 1
            return lines[j:i + 1]
    raise ValueError(f"no test: line for {svc} in the template")


def main(dep_path, tmpl_path):
    dep = open(dep_path).read()
    tmpl = open(tmpl_path).read()
    lines = dep.splitlines()
    changed = []
    for svc, old in OLD.items():
        b = blocks(lines).get(svc)
        if not b:
            continue
        for i in range(*b):
            if lines[i] == old:
                lines[i:i + 1] = new_lines(tmpl, svc)
                changed.append(svc)
                break
    if not changed:
        return 1
    st = os.stat(dep_path)
    tmp = dep_path + ".r96.tmp"
    with open(tmp, "w") as fh:
        fh.write("\n".join(lines) + ("\n" if dep.endswith("\n") else ""))
    os.chown(tmp, st.st_uid, st.st_gid)
    os.chmod(tmp, st.st_mode & 0o7777)
    os.replace(tmp, dep_path)
    print("health checks updated: " + ", ".join(changed))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1], sys.argv[2]))
    except Exception as ex:  # noqa: BLE001
        print(f"error: {ex}", file=sys.stderr)
        sys.exit(2)
