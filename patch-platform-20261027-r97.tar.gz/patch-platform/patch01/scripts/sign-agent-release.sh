#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# sign-agent-release.sh : the OFFLINE release-signing key for agent updates
#
# Run on the operator's offline machine (NOT on PATCH-01: a key on PATCH-01
# would be exactly what an attacker who takes PATCH-01 needs). Needs only
# bash and openssl.
#
#   ./sign-agent-release.sh --new-key DIR
#        makes DIR/release-signing.key (RSA 3072, encrypted with a passphrase
#        you choose) and DIR/release-signing.pub (the public half), and prints
#        the key's SHA-256. Once. Keep the .key offline (and a backup of it).
#
#   ./sign-agent-release.sh --key DIR/release-signing.key FILE...
#        signs each agent file: writes FILE.sig (RSA PKCS#1 v1.5, SHA-256,
#        over the exact bytes of FILE) and checks it with the public half.
#        Windows: sign with Sign-Agent.ps1 (Authenticode) FIRST, then here;
#        the release signature covers the final bytes.
#
#   ./sign-agent-release.sh --verify DIR/release-signing.pub FILE...
#        checks FILE.sig (what phase12-agents.sh does when PATCH-01 has the
#        public key in /patch/data/agent-releases/release-signing.pub)
#
#   ./sign-agent-release.sh --fingerprint DIR/release-signing.pub
#
# Then: copy patch-agent.py + patch-agent.py.sig (and/or patch-agent.ps1 +
# patch-agent.ps1.sig) to PATCH-01 and publish them with
#   ./scripts/phase12-agents.sh --linux patch-agent.py      (finds the .sig beside it)
#   ./scripts/phase12-agents.sh --windows patch-agent.ps1
# Agents pin release-signing.pub with setup-agent.sh / install-agent.sh
# --release-key (Linux) or install-agent.ps1 / Install-PatchAgent.bat
# (Windows: release-signing.pub in the agent folder); from then on they
# refuse an update whose signature does not verify.
# ---------------------------------------------------------------------------
set -Eeuo pipefail
umask 077

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
command -v openssl >/dev/null || die "openssl is needed."

fingerprint() { openssl pkey -pubin -in "$1" -outform DER 2>/dev/null | sha256sum | cut -d' ' -f1; }
check_pub() {   # an RSA public key of 2048+ bits
  local bits
  bits="$(openssl pkey -pubin -in "$1" -noout -text 2>/dev/null | sed -n 's/.*Public-Key: (\([0-9]*\) bit).*/\1/p' | head -1)"
  openssl pkey -pubin -in "$1" -noout -text 2>/dev/null | grep -qE '^(RSA )?Public-Key' || die "$1 is not an RSA public key."
  [[ "${bits:-0}" -ge 2048 ]] || die "$1 has ${bits:-?} bits: at least 2048 are needed."
}
verify_one() {   # verify_one PUB FILE
  [[ -f "$2.sig" ]] || die "No $2.sig"
  openssl dgst -sha256 -verify "$1" -signature "$2.sig" "$2" >/dev/null 2>&1
}

case "${1:-}" in
  --new-key)
    d="${2:-}"; [[ -n "$d" ]] || die "--new-key DIR"
    mkdir -p "$d"; chmod 0700 "$d"
    [[ -e "$d/release-signing.key" ]] && die "$d/release-signing.key exists: not overwritten."
    echo "Choose a passphrase for the private key (asked twice). Keep it, and the key, offline."
    openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:3072 -aes-256-cbc -out "$d/release-signing.key"
    chmod 0400 "$d/release-signing.key"
    openssl pkey -in "$d/release-signing.key" -pubout -out "$d/release-signing.pub"
    chmod 0644 "$d/release-signing.pub"
    check_pub "$d/release-signing.pub"
    echo
    echo "Private key: $d/release-signing.key   (offline only; back it up the same way)"
    echo "Public key:  $d/release-signing.pub   (copy to the agents' bundles and to PATCH-01)"
    echo "SHA-256:     $(fingerprint "$d/release-signing.pub")"
    ;;
  --key)
    key="${2:-}"; shift 2 || true
    [[ -f "$key" ]] || die "--key KEYFILE FILE..."
    (($#)) || die "Give the agent file(s) to sign."
    # The passphrase is asked once: the key is opened once into a private folder in memory
    # (/dev/shm when there is one), used for every file, and shredded on exit
    shm=/dev/shm; [[ -d "$shm" && -w "$shm" ]] || shm="${TMPDIR:-/tmp}"
    tmp="$(mktemp -d "$shm/agent-sign.XXXXXXXX")"; chmod 0700 "$tmp"
    trap 'shred -u "$tmp"/* 2>/dev/null; rm -rf "$tmp"' EXIT
    trap 'exit 130' INT TERM
    openssl pkey -in "$key" -out "$tmp/key.pem" || die "Could not open $key (passphrase?)."
    key="$tmp/key.pem"
    openssl pkey -in "$key" -pubout -out "$tmp/pub.pem" || die "Could not read the key."
    check_pub "$tmp/pub.pem"
    for f in "$@"; do
      [[ -f "$f" && ! -L "$f" ]] || die "$f is not a file."
      grep -qE '^AGENT_VERSION = "|^\$AgentVersion = "' "$f" || die "$f does not look like a PATCH-01 agent."
      openssl dgst -sha256 -sign "$key" -out "$f.sig.new" "$f" || die "Signing $f failed."
      mv -f "$f.sig.new" "$f.sig"; chmod 0644 "$f.sig"
      verify_one "$tmp/pub.pem" "$f" || die "The signature of $f does not verify: not used."
      printf 'Signed %s  (version %s, SHA-256 %s)\n' "$f" \
        "$(sed -nE 's/^(AGENT_VERSION|\$AgentVersion) = "([^"]+)".*/\2/p' "$f" | head -1)" "$(sha256sum "$f" | cut -d' ' -f1)"
    done
    echo "Key SHA-256: $(fingerprint "$tmp/pub.pem")"
    ;;
  --verify)
    pub="${2:-}"; shift 2 || true
    [[ -f "$pub" ]] || die "--verify PUBFILE FILE..."
    check_pub "$pub"; rc=0
    for f in "$@"; do
      if verify_one "$pub" "$f"; then echo "OK      $f"; else echo "FAILED  $f"; rc=1; fi
    done
    exit "$rc"
    ;;
  --fingerprint)
    [[ -f "${2:-}" ]] || die "--fingerprint PUBFILE"
    check_pub "$2"; fingerprint "$2" ;;
  -h|--help|"") sed -n '2,36p' "$0" ;;
  *) die "Unknown option: $1 (see --help)" ;;
esac
