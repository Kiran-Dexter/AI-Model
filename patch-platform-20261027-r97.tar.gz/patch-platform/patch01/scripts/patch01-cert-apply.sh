#!/usr/bin/env bash
# ===========================================================================
# patch01-cert-apply - install PATCH-01's certificate from the console.
#
# Started by patch01-cert.path when the console writes request.json into
# /patch/certs-staging. It does not trust the web side: it re-checks the
# files itself, installs them, restarts nginx, proves nginx serves exactly
# the expected certificate, and puts the previous one back if not. Its result
# goes to result.json, which the console shows. The private key is removed
# from the hand-over folder once installed.
#
#   request {"action": "install", "dir": "pending-<id>", "pin": "<sha256>"}
#   request {"action": "rollback"}      the certificate before the last change
# ===========================================================================
set -Eeuo pipefail

PATCH_BASE="${PATCH_BASE:-/patch}"
STAGING="$PATCH_BASE/certs-staging"
CERTS="$PATCH_BASE/certs"
KEEP=5                                   # previous certificates kept
LOG="${PATCH01_CERT_LOG:-/var/log/patch01-cert.log}"
NGINX=patch01-nginx
REQ="$STAGING/request.json"
# The staging folder is writable by the API container (uid 1001, group 0), so
# anything in it may be a symlink planted there. Root keeps its lock, temporary
# files and its copy of the upload in a root-only folder, reads from staging
# without following symlinks, and writes there only by an O_NOFOLLOW|O_EXCL
# create followed by a rename (which replaces, never follows, a symlink).
RUN="${PATCH01_CERT_RUN:-/run/patch01-cert}"

log() { printf '%s %s\n' "$(date '+%F %T')" "$*" >>"$LOG"; }
jget() { python3 -c "import json,sys; print(json.load(open(sys.argv[1])).get(sys.argv[2],''))" "$WORK/request.json" "$1"; }
# fetch <name>... <dest>: copy STAGING/<name>/... to <dest> (root-only) without following any symlink
fetch() {
  python3 - "$STAGING" "$@" <<'PY'
import os, sys
base, parts, dest = sys.argv[1], sys.argv[2:-1], sys.argv[-1]
fd = os.open(base, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
for d in parts[:-1]:
    nfd = os.open(d, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd); os.close(fd); fd = nfd
src = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
import stat
if not stat.S_ISREG(os.fstat(src).st_mode):
    sys.exit(1)
data = b""
while True:
    chunk = os.read(src, 65536)
    if not chunk or len(data) > (1 << 20):
        break
    data += chunk
out = os.open(dest, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
os.write(out, data); os.close(out)
PY
}
result() {   # result ok|failed|rolled_back message [pin]
  python3 - "$1" "$2" "${3:-}" "$ID" "$ACTION" "$BY" "$STAGING" <<'PY'
import json, os, sys, datetime, secrets
body = json.dumps({"state": sys.argv[1], "message": sys.argv[2], "pin": sys.argv[3], "id": sys.argv[4],
                   "action": sys.argv[5], "by": sys.argv[6],
                   "at": datetime.datetime.now(datetime.timezone.utc).isoformat()}) + "\n"
d = os.open(sys.argv[7], os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
tmp = ".result.%s.tmp" % secrets.token_hex(8)
fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o640, dir_fd=d)
os.fchmod(fd, 0o640)
try:
    os.fchown(fd, -1, 0)
except OSError:
    pass
os.write(fd, body.encode()); os.close(fd)
os.replace(tmp, "result.json", src_dir_fd=d, dst_dir_fd=d)
PY
  log "$1: $2"
}
served_pin() {
  echo | timeout 10 openssl s_client -connect 127.0.0.1:443 2>/dev/null | openssl x509 -outform der 2>/dev/null \
    | sha256sum | cut -d' ' -f1
}
restart_and_check() {   # restart_and_check <expected pin> : nginx serves it
  # 9>&-: nothing started from here may inherit (and so keep) the run lock
  docker restart "$NGINX" >>"$LOG" 2>&1 9>&- || return 1
  local i p
  for i in $(seq 1 20); do
    sleep 2
    p="$(served_pin)"
    [[ "$p" == "$1" ]] && return 0
  done
  return 1
}

[[ -e "$REQ" || -L "$REQ" ]] || exit 0
[[ -L "$RUN" ]] && { log "refused: $RUN is a symlink"; exit 1; }
mkdir -p -m 0700 "$RUN"; chown root:root "$RUN" 2>/dev/null || true; chmod 0700 "$RUN"
exec 9>"$RUN/lock"
flock -n 9 || { log "another run is in progress; this request waits for it"; exit 0; }
WORK="$RUN/work"; rm -rf "$WORK"; mkdir -m 0700 "$WORK"
trap 'rm -f "$REQ"; rm -rf "$WORK"' EXIT
if [[ -L "$REQ" ]] || ! fetch request.json "$WORK/request.json" 2>/dev/null; then
  rm -f "$REQ"; log "ignored a request that is not a regular file"; exit 0
fi
ID="$(jget id 2>/dev/null || true)"; ACTION="$(jget action 2>/dev/null || true)"; BY="$(jget by 2>/dev/null || true)"
[[ "$ID" =~ ^[0-9a-f]{16}$ ]] || { rm -f "$REQ"; log "ignored a malformed request"; exit 0; }
TS="$(date +%Y%m%d-%H%M%S)"
log "request $ID: $ACTION by $BY"

# nginx runs as uid 1001 in group 0, so the key must stay root:0 0640 as
# phase1a-ingress.sh made it. Overwriting in place keeps the file's owner,
# group, mode and SELinux label exactly; a new file gets phase1a's values.
place() {   # place <source> <destination> <mode if new>
  if [[ -f "$2" ]]; then
    cat "$1" >"$2"
  else
    install -m "$3" -o root -g 0 "$1" "$2"
  fi
  # A key left owner-only by an earlier attempt would lock nginx out again
  [[ "$2" == *.key ]] && { chgrp 0 "$2"; chmod 0640 "$2"; } || true
}

prune() { ls -1dt "$PATCH_BASE"/certs.before-ui-* 2>/dev/null | tail -n +$((KEEP + 1)) | xargs -r rm -rf; }

case "$ACTION" in
  install)
    DIR="$(jget dir)"; WANT="$(jget pin)"
    [[ "$DIR" =~ ^pending-[0-9a-f]{16}$ && "$WANT" =~ ^[0-9a-f]{64}$ ]] || { result failed "the request was malformed"; exit 0; }
    UP="$STAGING/$DIR"
    # Work on root-only copies, read without following symlinks: the checks and the install see the same bytes
    SRC="$WORK/upload"; mkdir -m 0700 "$SRC"
    if [[ -L "$UP" ]] || ! fetch "$DIR" patch01.crt "$SRC/patch01.crt" 2>/dev/null || ! fetch "$DIR" patch01.key "$SRC/patch01.key" 2>/dev/null; then
      rm -rf "$UP"; result failed "the uploaded files are missing (the upload may have expired)"; exit 0
    fi
    rm -rf "$UP"                           # the key leaves the hand-over folder now
    # Check again here: this is the side that can change nginx
    GOT="$(openssl x509 -in "$SRC/patch01.crt" -outform der 2>/dev/null | sha256sum | cut -d' ' -f1)"
    [[ "$GOT" == "$WANT" ]] || { result failed "the certificate is not the one that was checked"; rm -rf "$SRC"; exit 0; }
    [[ "$(openssl x509 -in "$SRC/patch01.crt" -noout -pubkey 2>/dev/null | sha256sum)" == \
       "$(openssl pkey -in "$SRC/patch01.key" -pubout 2>/dev/null | sha256sum)" ]] \
      || { result failed "the key does not match the certificate"; rm -rf "$SRC"; exit 0; }
    openssl x509 -checkend 0 -noout -in "$SRC/patch01.crt" >/dev/null || { result failed "the certificate has expired"; rm -rf "$SRC"; exit 0; }
    OLD="$(served_pin)"
    cp -a "$CERTS" "$PATCH_BASE/certs.before-ui-$TS"
    place "$SRC/patch01.crt" "$CERTS/patch01.crt" 0644
    place "$SRC/patch01.key" "$CERTS/patch01.key" 0640
    rm -rf "$SRC"
    if restart_and_check "$WANT"; then
      prune
      result ok "installed; nginx serves the new certificate (previous one kept as certs.before-ui-$TS)" "$WANT"
    else
      cp -a "$PATCH_BASE/certs.before-ui-$TS/." "$CERTS/"
      if restart_and_check "$OLD"; then
        result rolled_back "nginx did not serve the new certificate, so the previous one was put back and is being served. docker logs $NGINX --tail 30 shows why." "$OLD"
      else
        result failed "nginx served neither the new certificate nor the previous one (the previous files are back in place). Check it now: docker logs $NGINX --tail 30, then patch01ctl start" ""
      fi
    fi
    ;;
  rollback)
    PREV="$(ls -1dt "$PATCH_BASE"/certs.before-ui-* 2>/dev/null | head -1 || true)"
    [[ -n "$PREV" ]] || { result failed "there is no previous certificate to go back to"; exit 0; }
    PIN="$(openssl x509 -in "$PREV/patch01.crt" -outform der 2>/dev/null | sha256sum | cut -d' ' -f1)"
    cp -a "$CERTS" "$PATCH_BASE/certs.before-rollback-$TS"
    cp -a "$PREV/." "$CERTS/"
    if restart_and_check "$PIN"; then
      rm -rf "$PREV"
      result ok "rolled back to the previous certificate" "$PIN"
    else
      cp -a "$PATCH_BASE/certs.before-rollback-$TS/." "$CERTS/"; restart_and_check "$(openssl x509 -in "$CERTS/patch01.crt" -outform der | sha256sum | cut -d' ' -f1)" || true
      result failed "nginx would not serve the previous certificate, so nothing was changed"
    fi
    rm -rf "$PATCH_BASE/certs.before-rollback-$TS"
    ;;
  *) result failed "unknown action" ;;
esac
