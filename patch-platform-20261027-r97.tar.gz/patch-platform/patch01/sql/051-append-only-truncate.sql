-- ---------------------------------------------------------------------------
-- 051: the append-only tables reject TRUNCATE too
--
-- audit_log, job_events and change_events reject UPDATE and DELETE row by row
-- (001, 002, 009). TRUNCATE fires no row triggers, so it needs a statement
-- trigger of its own. The same functions are used: they raise for any TG_OP.
-- A TRUNCATE ... CASCADE from another table fires these triggers as well.
--
-- (Who may DROP these tables is settled by ownership: phase3a-schema.sh keeps
-- the database and schema public owned by postgres, so the API role cannot.)
-- ---------------------------------------------------------------------------

DROP TRIGGER IF EXISTS trg_audit_no_truncate ON audit_log;
CREATE TRIGGER trg_audit_no_truncate
    BEFORE TRUNCATE ON audit_log
    FOR EACH STATEMENT EXECUTE FUNCTION audit_log_immutable();

DROP TRIGGER IF EXISTS trg_jevents_no_truncate ON job_events;
CREATE TRIGGER trg_jevents_no_truncate
    BEFORE TRUNCATE ON job_events
    FOR EACH STATEMENT EXECUTE FUNCTION job_events_immutable();

DROP TRIGGER IF EXISTS trg_change_events_no_truncate ON change_events;
CREATE TRIGGER trg_change_events_no_truncate
    BEFORE TRUNCATE ON change_events
    FOR EACH STATEMENT EXECUTE FUNCTION change_events_immutable();

INSERT INTO schema_version (version, description)
VALUES (51, 'Append-only tables (audit_log, job_events, change_events) reject TRUNCATE')
ON CONFLICT (version) DO NOTHING;
