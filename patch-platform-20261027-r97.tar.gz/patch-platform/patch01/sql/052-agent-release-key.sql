-- ---------------------------------------------------------------------------
-- 052: which servers' agents require signed agent updates
--
-- Agents 1.8.3+ (Linux) and 1.9.5-win+ report at each check-in whether the
-- public half of the OFFLINE release-signing key is pinned on the server:
--   pinned   updates are accepted only when signed with that key
--   none     updates are checked against PATCH-01's SHA-256 only
--   invalid  a key file is there but cannot be used: every update is refused
-- NULL: an older agent, or one that has not checked in since.
--
--   SELECT hostname, agent_version, release_key FROM hosts
--    WHERE status <> 'decommissioned' ORDER BY release_key NULLS FIRST, hostname;
-- ---------------------------------------------------------------------------

ALTER TABLE hosts ADD COLUMN IF NOT EXISTS release_key text;

ALTER TABLE hosts DROP CONSTRAINT IF EXISTS hosts_release_key_check;
ALTER TABLE hosts ADD CONSTRAINT hosts_release_key_check
    CHECK (release_key IS NULL OR release_key IN ('none', 'pinned', 'invalid'));

INSERT INTO schema_version (version, description)
VALUES (52, 'hosts.release_key: whether each agent requires signed agent updates')
ON CONFLICT (version) DO NOTHING;
