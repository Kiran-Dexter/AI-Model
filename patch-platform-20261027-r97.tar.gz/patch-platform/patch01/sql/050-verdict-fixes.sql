-- ===========================================================================
-- PATCH-01 : schema 050 - verdicts that never read as clean on missing evidence
--
-- Applied after 049. Idempotent.
--
-- v_host_patch       a Windows server's "to install" is NULL (unknown) until
--                    Windows Update has completed a search for it
--                    (hosts.wu_searched_at set, schema 018) and while its last
--                    search failed (hosts.wu_error set): 0 is said only when a
--                    search really found nothing missing. Same columns, same
--                    Linux branch as schema 044.
-- cve_impact.verdict 'unknown' is allowed: a CVE whose analysis failed (retried
--                    at the next pass), or one held by a server that cannot
--                    be judged (stopped reporting, not judged, unproven while
--                    others are fixed). Never shown as clean.
-- ===========================================================================

CREATE OR REPLACE VIEW v_host_patch AS
SELECT h.id AS host_id,
       CASE WHEN h.os_id = 'windows'
            THEN CASE WHEN h.wu_searched_at IS NOT NULL AND h.wu_error IS NULL
                      THEN (SELECT count(*) FROM windows_updates wu WHERE wu.host_id = h.id) END
            WHEN h.updates_checked_at IS NOT NULL
            THEN (SELECT count(*) FROM linux_updates lu WHERE lu.host_id = h.id AND lu.security IS NOT FALSE)
       END AS to_install,
       CASE WHEN h.os_id <> 'windows' AND h.updates_checked_at IS NOT NULL
            THEN (SELECT count(*) FROM linux_updates lu WHERE lu.host_id = h.id)
       END AS updates_available,
       h.updates_checked_at, h.updates_error
  FROM hosts h;

ALTER TABLE cve_impact DROP CONSTRAINT IF EXISTS cve_impact_verdict_check;
ALTER TABLE cve_impact ADD CONSTRAINT cve_impact_verdict_check
    CHECK (verdict IN ('affected', 'potentially_affected', 'pending_reboot', 'patched',
                       'not_affected', 'not_found', 'not_tracked', 'unknown'));

-- Results stored by the old rule (an analysis that failed was stored as
-- 'not_found', i.e. clean) are taken again at the next pass
UPDATE cve_impact SET inventory_mark = NULL
 WHERE verdict = 'not_found' AND excluded::text LIKE '%could not be analysed%';

INSERT INTO schema_version (version, description)
VALUES (50, 'Verdicts: Windows to-install unknown until a search succeeds; CVE impact verdict unknown')
ON CONFLICT (version) DO NOTHING;
