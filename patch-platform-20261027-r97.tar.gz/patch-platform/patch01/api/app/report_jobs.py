"""Reports built on the server, for e-mail at once or on a schedule.

Each report is built from the database at the time it is sent (never from a
browser), rendered as PDF or CSV with the branded heading (exports.py), and
queued inside the usual branded mail (notify.render) with a summary and the
first rows in the body. The worker sends the queue every minute and retries
on failure; the attachment is removed from the database once delivered.

Recipients are only ever addresses from Admin > Mail's recipient list.
"""

import logging
from datetime import datetime, timedelta, timezone

log = logging.getLogger("patchapi.reports")

MAX_ATTACHMENT = 10 * 2 ** 20
PREVIEW_ROWS = 25
WEEKDAYS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")

ADVISORIES_SQL = """SELECT * FROM (
                 SELECT a.id, a.vendor, a.title, lower(coalesce(a.severity, '')) AS severity, a.issued_at,
                        a.os_id, a.os_major, 'advisory' AS source,
                        count(DISTINCT ha.host_id) FILTER (WHERE ha.state = 'affected') AS servers_affected,
                        count(DISTINCT ha.host_id) FILTER (WHERE ha.state = 'fixed_pending_reboot') AS servers_reboot,
                        max(r.max_cvss) AS max_cvss, bool_or(coalesce(r.any_kev, false)) AS exploited,
                        (SELECT array_agg(ac.cve_id ORDER BY ac.cve_id) FROM advisory_cves ac WHERE ac.advisory_id = a.id) AS cves
                   FROM advisories a
                   JOIN host_applicability ha ON ha.advisory_id = a.id AND ha.state IN ('affected', 'fixed_pending_reboot')
                   JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'
                   LEFT JOIN v_advisory_risk r ON r.advisory_id = a.id
                  GROUP BY a.id
                 UNION ALL
                 SELECT w.k, 'microsoft', max(w.title), lower(coalesce(max(w.severity), '')),
                        NULL::date, 'windows', NULL::int, 'windows_update',
                        count(DISTINCT w.host_id), 0, NULL::numeric, false,
                        (SELECT array_agg(DISTINCT c ORDER BY c) FROM windows_updates w2, unnest(w2.cves) c
                          WHERE coalesce(w2.kb, w2.update_id) = w.k)
                   FROM (SELECT coalesce(wu.kb, wu.update_id) AS k, wu.title, wu.severity, wu.host_id
                           FROM windows_updates wu JOIN hosts h ON h.id = wu.host_id AND h.status <> 'decommissioned') w
                  GROUP BY w.k
               ) x
              ORDER BY exploited DESC,
                       CASE severity WHEN 'critical' THEN 1 WHEN 'important' THEN 2 WHEN 'high' THEN 2
                                     WHEN 'moderate' THEN 3 WHEN 'medium' THEN 3 ELSE 4 END,
                       servers_affected DESC, id
              LIMIT 2000"""


class ReportError(ValueError):
    pass


def _int(params, key, lo, hi, default):
    try:
        v = int(params.get(key, default))
    except (TypeError, ValueError):
        v = default
    return max(lo, min(hi, v))


def _when(v, tz):
    if not v:
        return ""
    if isinstance(v, str):
        try:
            v = datetime.fromisoformat(v.replace("Z", "+00:00"))
        except ValueError:
            return v
    return v.astimezone(tz).strftime("%d %b %Y %H:%M")


def _ago(v, now):
    if not v:
        return None
    if isinstance(v, str):
        v = datetime.fromisoformat(v.replace("Z", "+00:00"))
    return (now - v).total_seconds() / 3600.0


# ---------------------------------------------------------------------------
# The reports. Each returns a dict: title, headers, rows, filter, intro,
# stats [(label, value, severity)], severity, sections [(heading, headers, rows)]
# ---------------------------------------------------------------------------

def r_servers(conn, params, tz):
    from . import servers
    f = servers.clean_filters(**{k: params.get(k) for k in ("q", "os", "group", "version", "agent", "patch")})
    rows = servers.all_rows(conn, f, "name")
    headers = [label for _, label in servers.EXPORT_COLUMNS]
    data = [[servers.export_value(k, r.get(k)) for k, _ in servers.EXPORT_COLUMNS] for r in rows]
    online = sum(1 for r in rows if r["agent"] == "online")
    need = sum(1 for r in rows if r["to_install"])          # WSUS / the package manager, never the CVE feeds
    unknown = sum(1 for r in rows if r["to_install"] is None)
    reboot = sum(1 for r in rows if r["reboot_required"] or r["pending_reboot"])
    return {"title": "Servers", "headers": headers, "rows": data, "filter": servers.describe_filters(f),
            "intro": f"Server security status: {len(rows)} servers monitored, {online} reporting and {len(rows) - online} not reporting. "
                     f"{need} have outstanding security updates and {reboot} are waiting for a reboot to complete them"
                     + (f"; {unknown} Linux servers do not report their package manager's updates yet (agent older than 1.8.2)" if unknown else "")
                     + ("; servers that are not reporting cannot be assessed and should be checked." if len(rows) - online else "."),
            "action": "Apply outstanding security updates and complete pending reboots in the next maintenance window." if need or reboot else None,
            "stats": [("Servers", len(rows), "info"), ("Offline", len(rows) - online, "warning" if len(rows) - online else "ok"),
                      ("Need patches", need, "warning" if need else "ok"), ("Reboot", reboot, "warning" if reboot else "ok")],
            "severity": "warning" if need or len(rows) - online else "ok",
            "preview": (["Server", "Agent", "Operating system", "Patches to install", "From"],
                        [[r["hostname"], r["agent"], r["os_label"], "" if r["to_install"] is None else r["to_install"],
                          "WSUS" if r["os_id"] == "windows" else ("package manager" if r["to_install"] is not None else "agent 1.8.2 needed")]
                         for r in rows if r["agent"] != "online" or r["to_install"] or r["to_install"] is None])}


def r_impact(conn, params, tz):
    """The CVEs that really affect our environment: proven on our machines; appliances apart."""
    from . import cve_feeds, cve_impact, impact_report as irep
    days = int(cve_feeds.settings(conn).get("days_back") or 14)
    items = [dict(r) for r in cve_impact.listing(conn, days, limit=2000)]
    appl = [dict(r) for r in cve_impact.appliance_listing(conn, days, limit=2000)]
    zero = [i for i in items if i["exploited"]]
    machines = len({str((m.get("name") or "")).lower().split(".")[0] for i in items for m in i.get("matches") or [] if m.get("name")})
    a_aff = sum(1 for i in appl if i.get("appliance_state") == "affected")
    a_chk = sum(1 for i in appl if i.get("appliance_state") == "check")
    rows = irep.machine_rows(items)
    return {"title": "Vulnerabilities in our environment", "headers": irep.MACHINE_HEADERS, "rows": rows,
            "filter": f"new critical, high and exploited CVEs of the last {days} days, proven on our machines",
            "intro": f"{len(items)} new CVEs are proven on {machines} of our machines"
                     + (f"; {len(zero)} of them are exploited in the wild and come first." if zero else ".")
                     + (f" Appliances: {a_aff} CVEs affect a device's recorded firmware, {a_chk} name a device whose firmware "
                        "version is not recorded (to check)." if appl else ""),
            "action": ("Remediate the exploited CVEs first, then the others by severity." if zero
                       else "Remediate the affected CVEs by severity." if items else None),
            "stats": [("Affected CVEs", len(items), "critical" if zero else ("warning" if items else "ok")),
                      ("Machines", machines, "info"), ("0-day", len(zero), "critical" if zero else "ok"),
                      ("Appliances", a_aff + a_chk, "warning" if a_aff else "ok")],
            "severity": "critical" if zero else ("warning" if items else "ok"),
            "preview": (["CVE", "Severity", "Machines", "Products", "Title"],
                        [[i["cve_id"], irep._sev(i), i["machines"], irep._products(i), i["title"] or ""] for i in items])}


def r_advisories(conn, params, tz):
    rows = conn.execute(ADVISORIES_SQL).fetchall()
    if params.get("exploited_only"):
        rows = [r for r in rows if r["exploited"]]
    headers = ["Advisory", "Kind", "Severity", "Exploited", "Servers to install", "Servers awaiting reboot", "Worst CVSS",
               "Issued", "CVEs", "Title"]
    data = [[r["id"], "Windows update" if r["source"] == "windows_update" else f"{(r['os_id'] or '').upper()} {r['os_major'] or ''}".strip(),
             r["severity"], "yes" if r["exploited"] else "", r["servers_affected"], r["servers_reboot"], r["max_cvss"],
             _when(r["issued_at"], tz)[:11] if r["issued_at"] else "", " ".join((r["cves"] or [])[:20]), r["title"] or ""]
            for r in rows]
    ex = sum(1 for r in rows if r["exploited"])
    return {"title": "Advisories to install", "headers": headers, "rows": data,
            "filter": "exploited only" if params.get("exploited_only") else "all",
            "intro": f"Patch backlog: {len(rows)} security advisories and Windows updates are still to be installed"
                     + (f"; {ex} fix vulnerabilities that are being actively exploited." if ex else "."),
            "action": "Schedule the advisories that fix exploited vulnerabilities as a priority." if ex else None,
            "stats": [("To install", len(rows), "warning" if rows else "ok"), ("Exploited", ex, "critical" if ex else "ok")],
            "severity": "critical" if ex else ("warning" if rows else "ok"),
            "preview": (["Advisory", "Severity", "Servers", "Title"],
                        [[r["id"], ("exploited " if r["exploited"] else "") + (r["severity"] or ""), r["servers_affected"],
                          r["title"] or ""] for r in rows])}


def r_av_agents(conn, params, tz):
    from . import antivirus as av
    agents, _ = av.coverage(conn)
    headers = ["Name", "Address", "Domain", "Product", "Console", "Definitions", "Last connected", "Isolation",
               "In inventory", "Operating system"]
    rows = [[a["host_name"], " ".join(a["ip_addresses"] or []), a["ad_domain"] or "", a["product_name"], a["console"],
             a.get("pattern_version") or "", _when(a.get("last_connected"), tz), a["isolation_status"] or "",
             "yes" if a["asset"] else "no", (a["asset"] or {}).get("os") or ""] for a in agents]
    return {"title": "Antivirus agents", "headers": headers, "rows": rows, "filter": "all consoles",
            "intro": f"Endpoint protection inventory: {len(agents)} antivirus agents are reported by the consoles.",
            "stats": [("Agents", len(agents), "info"), ("Not in inventory", sum(1 for a in agents if not a["asset"]), "info")],
            "severity": "info", "preview": (headers[:5], rows)}


def r_av_unprotected(conn, params, tz):
    from . import antivirus as av
    _, unprot = av.coverage(conn)
    headers = ["Name", "Address", "Operating system", "Known from"]
    rows = [[m["name"], " ".join(m["ips"] or []), m["os"] or "", ", ".join(m["sources"] or [])] for m in unprot]
    return {"title": "Machines with no antivirus agent", "headers": headers, "rows": rows, "filter": "all machines",
            "intro": f"Endpoint protection gap: {len(rows)} machines in the inventory are not protected by any antivirus agent "
                     "that a console reports, and are exposed to malware and ransomware.",
            "action": "Install and register the antivirus agent on these machines, or decommission them if they are retired." if rows else None,
            "stats": [("No antivirus", len(rows), "critical" if rows else "ok")],
            "severity": "critical" if rows else "ok", "preview": (headers, rows)}


def av_health_rows(conn, params, now=None):
    """The antivirus problems: definitions behind, agents offline, agents no
    longer listed, machines with no agent. Each row says how it was judged."""
    from . import antivirus as av
    now = now or datetime.now(timezone.utc)
    off_h = _int(params, "offline_hours", 1, 720, 24)
    behind = _int(params, "pattern_behind", 1, 50, 4)
    vold = _int(params, "versions_old", 1, 7, 2)
    agents, unprot = av.coverage(conn)
    # Apex Central's own judgement, from its Pattern Update Status log, when it is read (schema 029)
    pstat = {}
    try:
        with conn.transaction():
            for r in conn.execute(
                    """SELECT console_id::text AS cid, lower(host_name) AS h, pattern, version, versions_old
                         FROM av_pattern_status WHERE versions_old IS NOT NULL""").fetchall():
                k = (r["cid"], r["h"].split(".")[0])
                if k not in pstat or r["versions_old"] > pstat[k]["versions_old"]:
                    pstat[k] = dict(r)
    except Exception:  # noqa: BLE001 - schema 029 not applied: versions are compared instead
        pstat = {}
    newest, newest_txt = {}, {}
    for a in agents:
        k = av.pattern_key(a.get("pattern_version"))
        if k and (a["product_name"] not in newest or k > newest[a["product_name"]]):
            newest[a["product_name"]], newest_txt[a["product_name"]] = k, a["pattern_version"]
    outdated, offline, missing = [], [], []
    for a in agents:
        ass = a["asset"] or {}
        base = [a["host_name"], " ".join(a["ip_addresses"] or []), a["product_name"], a["console"], ass.get("os") or ""]
        if a["not_reported"]:
            missing.append(base + [a.get("pattern_version") or "", "",
                                   "Apex Central no longer lists this agent (last listed " + _when(a["last_seen"], TZ) + ")"])
            continue
        k, top = av.pattern_key(a.get("pattern_version")), newest.get(a["product_name"])
        ps = pstat.get((str(a.get("console_id")), (a["host_name"] or "").lower().split(".")[0]))
        if ps:
            if ps["versions_old"] >= vold:
                outdated.append(base + [ps["version"] or "", "",
                                        f"Apex Central: {ps['pattern']} is "
                                        + ("7 or more versions old" if ps["versions_old"] >= 7 else f"{ps['versions_old']} versions old")])
        elif k and top and (k[0] < top[0] or (len(k) > 1 and len(top) > 1 and top[1] - k[1] > behind)):
            outdated.append(base + [a["pattern_version"], newest_txt[a["product_name"]],
                                    f"{top[1] - k[1] if k[0] == top[0] else 'a major version'} releases behind the newest seen"])
        why = None
        lc = _ago(a.get("last_connected"), now)
        if lc is not None:
            if lc > off_h:
                why = f"Apex Central: last connected {_when(a['last_connected'], TZ)} ({int(lc)} h ago)"
        elif a.get("online") is False:
            why = "Apex Central reports it offline"
        elif ass:
            # No connection data from Apex Central: judged from what the inventory knows of the machine
            seen = [x for x in ((ass.get("agent_seen"), "our agent"), (ass.get("wsus_seen"), "WSUS")) if x[0]]
            recent = [x for x in seen if (_ago(x[0], now) or 1e9) <= off_h]
            if ass.get("agent") == "online" or recent:
                why = None
            elif ass.get("power") == "poweredOff":
                why = "the machine is powered off in vCenter"
            elif seen:
                last, src = max(seen, key=lambda x: x[0] if not isinstance(x[0], str) else datetime.fromisoformat(x[0]))
                why = f"the machine has not been seen for over {off_h} h ({src} last {_when(last, TZ)})"
        if why:
            offline.append(base + [a.get("pattern_version") or "", _when(a.get("last_connected"), TZ), why])
    unprotected = [[m["name"], " ".join(m["ips"] or []), "", "", m["os"] or "", "", "",
                    "known from " + ", ".join(m["sources"] or []) + "; no antivirus console lists it"] for m in unprot]
    return {"outdated": outdated, "offline": offline, "missing": missing, "unprotected": unprotected,
            "agents": len(agents), "with_versions": sum(1 for a in agents if a.get("pattern_version")),
            "with_connection": sum(1 for a in agents if a.get("last_connected") or a.get("online") is not None),
            "off_h": off_h, "behind": behind, "vold": vold}


TZ = timezone(timedelta(hours=8))


def r_av_health(conn, params, tz):
    h = av_health_rows(conn, params)
    with_unprot = params.get("include_unprotected", True) is not False
    headers = ["Problem", "Name", "Address", "Product", "Console", "Operating system", "Definitions", "Newest / last connected", "Detail"]
    rows = ([["Definitions outdated"] + r[:7] + [r[7]] for r in h["outdated"]]
            + [["Offline"] + r for r in h["offline"]]
            + [["No longer listed"] + r for r in h["missing"]]
            + ([["No antivirus"] + r for r in h["unprotected"]] if with_unprot else []))
    notes = []
    if h["agents"] and not h["with_versions"]:
        notes.append("The consoles did not report definition versions through their API, so outdated definitions "
                     "cannot be checked yet (see Admin > Antivirus for the fields each console sends).")
    if h["agents"] and not h["with_connection"]:
        notes.append("The consoles did not report connection times, so an agent is counted offline when its machine "
                     "has not been seen by our agent or WSUS for " + str(h["off_h"]) + " hours, or is powered off.")
    bad = len(h["outdated"]) + len(h["offline"])
    sev = "critical" if (with_unprot and h["unprotected"]) or len(h["offline"]) > 5 else ("warning" if bad or h["missing"] else "ok")
    stats = [("Agents", h["agents"], "info"), ("Definitions outdated", len(h["outdated"]), "warning" if h["outdated"] else "ok"),
             ("Offline", len(h["offline"]), "warning" if h["offline"] else "ok")]
    if with_unprot:
        stats.append(("No antivirus", len(h["unprotected"]), "critical" if h["unprotected"] else "ok"))
    sections = [("Definitions outdated", ["Name", "Product", "Definitions", "Newest seen", "Detail"],
                 [[r[0], r[2], r[5], r[6], r[7]] for r in h["outdated"]]),
                ("Offline", ["Name", "Address", "Product", "Why"], [[r[0], r[1], r[2], r[7]] for r in h["offline"]]),
                ("No longer listed by Apex Central", ["Name", "Product", "Detail"], [[r[0], r[2], r[7]] for r in h["missing"]])]
    if with_unprot:
        sections.append(("Machines with no antivirus", ["Name", "Address", "Operating system", "Detail"],
                         [[r[0], r[1], r[4], r[7]] for r in h["unprotected"]]))
    return {"title": "Antivirus health", "headers": headers, "rows": rows,
            "filter": f"offline after {h['off_h']} h; outdated when Apex Central reports {h['vold']}+ versions old "
                      f"(or, without that log, more than {h['behind']} releases behind the newest seen)",
            "intro": (f"Endpoint protection health: {h['agents']} antivirus agents, {len(h['outdated'])} with outdated definitions "
                      f"and {len(h['offline'])} offline" + (f", {len(h['missing'])} no longer listed" if h["missing"] else "")
                      + (f". {len(h['unprotected'])} machines have no antivirus agent at all." if with_unprot else ".")
                      + " Outdated or offline agents do not detect the latest threats."),
            "action": "Update definitions on the outdated agents and bring the offline agents back online." if h["outdated"] or h["offline"] else None,
            "notes": notes, "stats": stats, "severity": sev, "sections": sections}


def r_av_threats(conn, params, tz):
    """Malware and ransomware detections, summarised by AI-01 (the scheduler
    asks for a fresh summary; an e-mail sent from a page uses today's, or the
    plain figures, so the page does not wait for AI-01)."""
    from . import av_threats
    from .av_logs import CATEGORY_WORDS
    days = _int(params, "days", 1, 31, 1)
    if params.get("_fresh_ai"):
        text, source, model, f = av_threats.summarise(conn, days)
    else:
        f = av_threats.facts(conn, days)
        last = av_threats.latest(conn)
        fresh = last and last["days"] == days and (datetime.now(timezone.utc) - last["created_at"]).total_seconds() < 6 * 3600 \
            if last and hasattr(last["created_at"], "tzinfo") else False
        text, source = (last["text"], last["source"]) if fresh else (av_threats.facts_text(f), "facts")
    rows = conn.execute(
        """SELECT d.occurred_at, d.host_name, d.ip, d.user_name, d.threat, d.category, d.action, d.result, d.unresolved,
                  d.file_path, d.sha1, d.count, c.name AS console
             FROM av_detections d JOIN av_consoles c ON c.id = d.console_id
            WHERE d.occurred_at > now() - make_interval(days => %s::int)
            ORDER BY (d.category = 'ransomware') DESC, d.unresolved DESC, d.occurred_at DESC LIMIT 5000""", (days,)).fetchall()
    t = f["totals"]
    paras = [p for p in text.split("\n\n") if p.strip()]
    label = "Summary by AI-01, from the figures below" if source == "ai" else "Summary from the figures (AI-01 not used)"
    sections = [
        ("Ransomware, and threats not cleaned or quarantined", ["When", "Machine", "Threat", "Type", "Action", "Result"],
         [[_when(r["occurred_at"], tz), r["host_name"], r["threat"], CATEGORY_WORDS.get(r["category"], r["category"]),
           r["action"] or "", r["result"] or ""] for r in rows if r["category"] == "ransomware" or r["unresolved"]]),
        ("Top threats", ["Threat", "Type", "Detections", "Machines", "Not cleaned"],
         [[x["threat"], CATEGORY_WORDS.get(x["category"], x["category"]), x["events"], x["machines"], x["unresolved"]]
          for x in f["threats"]]),
        ("Machines with most detections", ["Machine", "Detections", "Threats", "Not cleaned", "Ransomware"],
         [[x["host_name"], x["events"], x["threats"], x["unresolved"], "yes" if x["ransomware"] else ""] for x in f["hosts"]]),
    ]
    notes = [label + ":"] + paras
    if f["logs_missing"]:
        notes.append("Not offered by the console: " + ", ".join(f["logs_missing"]) + " (Admin > Antivirus).")
    if not f["logs_available"]:
        notes.append("No detection log has been read from Apex Central yet: check Admin > Antivirus.")
    return {"title": "Antivirus threats", "headers": ["When", "Machine", "Address", "User", "Threat", "Type", "Action", "Result",
                                                     "Not cleaned", "File", "SHA-1", "Count", "Console"],
            "rows": [[_when(r["occurred_at"], tz), r["host_name"] or "", r["ip"] or "", r["user_name"] or "", r["threat"] or "",
                      CATEGORY_WORDS.get(r["category"], r["category"]), r["action"] or "", r["result"] or "",
                      "yes" if r["unresolved"] else "", r["file_path"] or "", r["sha1"] or "", r["count"], r["console"]]
                     for r in rows],
            "filter": "last 24 hours" if days == 1 else f"last {days} days",
            "intro": "Threat activity reported by the antivirus consoles for the period, with the AI-01 analysis below.",
            "action": ("Isolate and investigate the machines with ransomware or threats that were not cleaned." if t["ransomware"] or t["unresolved"]
                       else None),
            "notes": notes,
            "stats": [("Detections", t["events"], "warning" if t["events"] else "ok"),
                      ("Machines", t["machines"], "info"),
                      ("Ransomware", t["ransomware"], "critical" if t["ransomware"] else "ok"),
                      ("Not cleaned", t["unresolved"], "critical" if t["unresolved"] else "ok"),
                      ("Outdated", f["outdated"], "warning" if f["outdated"] else "ok"),
                      ("Offline", f["offline"], "warning" if f["offline"] else "ok")],
            "severity": "critical" if t["ransomware"] or t["unresolved"] else ("warning" if t["events"] else "ok"),
            "sections": sections}


def r_asset_gaps(conn, params, tz):
    """Machines missing in WSUS or Apex, with why and what to do; AI-01's
    summary when the scheduler asks for a fresh one, else today's or the figures."""
    from . import inventory as inv, asset_coverage as cov
    assets = inv.load_assets(conn)["assets"]
    rows = cov.gaps(assets)
    # The same filters as the Coverage page: "apex" leaves out agents that are listed but silent ("silent")
    which = params.get("missing") if params.get("missing") in ("wsus", "apex", "silent") else None
    if which == "silent":
        rows = [r for r in rows if r["reason"] == "apex_silent"]
    elif which:
        rows = [r for r in rows if r["missing"] == which and r["reason"] != "apex_silent"]
    if params.get("_fresh_ai"):
        text, source, _, f = cov.summarise(conn, assets, rows if not which else cov.gaps(assets), "scheduled")
    else:
        f = cov.facts(assets, cov.gaps(assets))
        last = cov.latest(conn)
        fresh = last and hasattr(last["created_at"], "tzinfo") and (datetime.now(timezone.utc) - last["created_at"]).total_seconds() < 6 * 3600
        text, source = (last["text"], last["source"]) if fresh else (cov.facts_text(f), "facts")
    label = "Summary by AI-01, from the figures below" if source == "ai" else "Summary from the figures (AI-01 not used)"
    word = {"wsus": "WSUS", "apex": "Apex"}
    data = [[r["priority"], r["name"], r["device"], r["os"] or "", ", ".join(r["ips"][:3]), r["location"] or "",
             ", ".join(inv.SOURCE_LABEL.get(x, x) for x in r["detected"]), word[r["missing"]], r["why"], r["fix"]] for r in rows]
    return {"title": "Asset coverage gaps", "headers": ["Priority", "Machine", "Device", "OS", "IP", "Location", "Detected by",
                                                         "Missing in", "Why", "What to do"],
            "rows": data, "filter": ("listed in Apex but not reporting" if which == "silent" else ("missing in " + word[which]) if which
                                     else "missing in WSUS or Apex"),
            "intro": "Security coverage of the asset inventory: machines that should be patched by WSUS or protected by Apex but are not.",
            "action": "Fix the high-priority gaps first: running machines with no antivirus agent or a silent one." if f["high"] else None,
            "notes": [label + ":"] + [p for p in text.split("\n\n") if p.strip()],
            "stats": [("In WSUS", "–" if f["windows_in_wsus_pct"] is None else f"{f['windows_in_wsus_pct']}%",
                       "ok" if (f["windows_in_wsus_pct"] or 0) >= 95 or f["windows_in_wsus_pct"] is None else "warning"),
                      ("In Apex", "–" if f["windows_in_apex_pct"] is None else f"{f['windows_in_apex_pct']}%",
                       "ok" if (f["windows_in_apex_pct"] or 0) >= 95 or f["windows_in_apex_pct"] is None else "warning"),
                      ("Missing WSUS", f["missing_wsus"], "warning" if f["missing_wsus"] else "ok"),
                      ("Missing Apex", f["missing_apex"], "critical" if f["missing_apex"] else "ok"),
                      ("Apex silent", f["apex_not_reporting"], "warning" if f["apex_not_reporting"] else "ok"),
                      ("High priority", f["high"], "critical" if f["high"] else "ok")],
            "severity": "critical" if f["high"] else ("warning" if rows else "ok"),
            "sections": [("High priority", ["Machine", "Missing in", "Why", "What to do"],
                          [[r["name"], word[r["missing"]], r["why"], r["fix"]] for r in rows if r["priority"] == "high"][:50])]}


def r_activity(conn, params, tz):
    days = _int(params, "days", 1, 31, 1)
    rows = conn.execute(
        """SELECT occurred_at, actor, action, object_type, object_id, detail FROM audit_log
            WHERE occurred_at > now() - make_interval(days => %s) ORDER BY occurred_at DESC LIMIT 5000""", (days,)).fetchall()
    data = [[_when(r["occurred_at"], tz), r["actor"], r["action"].replace("_", " "),
             " ".join(x for x in (r["object_type"], r["object_id"]) if x),
             str(r["detail"] or "")[:200]] for r in rows]
    return {"title": "Activity", "headers": ["When", "Who", "Action", "Object", "Detail"], "rows": data,
            "filter": f"last {days} day" + ("s" if days > 1 else ""),
            "intro": f"Audit trail: {len(rows)} recorded administrative actions in the last {days} day" + ("s" if days > 1 else "")
                     + ". Review for unexpected changes, unknown users or activity outside working hours.",
            "stats": [("Actions", len(rows), "info")], "severity": "info", "preview": (["When", "Who", "Action"], [d[:3] for d in data])}


def r_patch_summary(conn, params, tz):
    from . import patch_reports as pr
    return pr.build_report(conn, params, tz, "summary")


def r_patch_details(conn, params, tz):
    from . import patch_reports as pr
    return pr.build_report(conn, params, tz, "patches")


def r_patch_jobs(conn, params, tz):
    from . import patch_reports as pr
    return pr.build_report(conn, params, tz, "jobs")


def r_patch_groups(conn, params, tz):
    from . import patch_reports as pr
    return pr.build_report(conn, params, tz, "groups")


def r_installed_patches(conn, params, tz):
    """Patches installed per server in the period, grouped by server (one heading row each)."""
    from . import installed_report as ir
    try:
        f = ir.clean_filters(params.get("days", 7), params.get("start"), params.get("end"), params.get("group"), params.get("os"),
                             params.get("hosts"), params.get("q"), params.get("defs"), params.get("failed"))
    except ir.Invalid as e:
        raise ReportError(str(e))
    hosts, t = ir.collect(conn, f)
    rows, heads, cut = ir.grouped(hosts, "in_range", tz, "Nothing installed in this period.", quiet_last=True)
    return {"title": "Installed patches", "headers": ir.ITEM_HEADERS, "rows": rows, "heads": heads, "filter": ir.describe(f),
            "intro": f"Patches installed in the {ir.describe(f)}: {t['in_range']} on {t['with_patches']} of {t['servers']} servers "
                     f"({t['windows']} Windows, {t['linux']} Linux), from each server's own records." + (" The list was cut: narrow the filter." if cut else ""),
            "stats": [("Servers", t["servers"], "info"), ("Patched in the period", t["with_patches"], "ok"),
                      ("Patches installed", t["in_range"], "info")],
            "severity": "info",
            "preview": (["Server", "Installed in the period", "Last installed"],
                        [[h["hostname"], h["n_range"], ir._when(h["last_installed"], tz) if h["last_installed"] else ""]
                         for h in hosts if h["n_range"]])}


# key: (title, builder, modules any-of, admin only)
REPORTS = {
    "asset_gaps": ("Asset coverage gaps (missing in WSUS or Apex), AI summary", r_asset_gaps, {"inventory"}, False),
    "av_threats": ("Antivirus threats, AI summary (malware, ransomware)", r_av_threats, {"inventory", "patch"}, False),
    "av_health": ("Antivirus health (outdated definitions, offline)", r_av_health, {"inventory", "patch"}, False),
    "av_agents": ("Antivirus agents", r_av_agents, {"inventory", "patch"}, False),
    "av_unprotected": ("Machines with no antivirus", r_av_unprotected, {"inventory", "patch"}, False),
    "servers": ("Servers", r_servers, {"patch"}, False),
    "patch_summary": ("Patch report, servers (result of each patch job)", r_patch_summary, {"patch"}, False),
    "patch_details": ("Patch report, installed updates and packages", r_patch_details, {"patch"}, False),
    "patch_jobs": ("Patch report, by job (CHG)", r_patch_jobs, {"patch"}, False),
    "patch_groups": ("Patch report, by patch group", r_patch_groups, {"patch"}, False),
    "installed_patches": ("Installed patches, by server (with dates)", r_installed_patches, {"patch"}, False),
    "impact": ("Vulnerabilities: CVEs proven on our machines", r_impact, {"patch"}, False),
    "advisories": ("Advisories affecting servers (CVE)", r_advisories, {"patch"}, False),
    "activity": ("Activity (all actions)", r_activity, {"patch", "inventory", "lifecycle"}, True),
}


def catalog(modules, is_admin):
    return [{"key": k, "title": t} for k, (t, _, mods, adm) in REPORTS.items()
            if (is_admin or not adm) and (is_admin or set(modules) & mods)]


def allowed(key, modules, is_admin):
    if key not in REPORTS:
        return False
    _, _, mods, adm = REPORTS[key]
    return is_admin or (not adm and bool(set(modules) & mods))


def build(conn, key, params, tz=TZ):
    if key not in REPORTS:
        raise ReportError("Unknown report.")
    return REPORTS[key][1](conn, params or {}, tz)


# ---------------------------------------------------------------------------
# Mail
# ---------------------------------------------------------------------------

def compose(conn, cfg, rep, fmt, by, period=None):
    """(subject, text, html, attachment or None)."""
    from . import exports as ex, notify as nt
    m = ex.meta(rep["title"], by, rep.get("filter") or "", len(rep["rows"]), ex.company_name(conn))
    data, mime, ext = ex.render(fmt, m, rep["headers"], rep["rows"], conn, heads=rep.get("heads"))
    att = (ex.file_name(rep["title"].lower(), ext), mime, data) if len(data) <= MAX_ATTACHMENT else None
    today = datetime.now(cfg["tz"]).strftime("%a %d %b %Y")
    blocks = []
    if rep.get("stats"):
        blocks.append(("stats", rep["stats"]))
    for n in rep.get("notes") or []:
        blocks.append(("p", n))
    for heading, headers, rows in rep.get("sections") or []:
        blocks.append(("h", f"{heading} ({len(rows)})"))
        blocks.append(("table", headers, [[("" if v is None else str(v))[:120] for v in r] for r in rows[:PREVIEW_ROWS]])
                      if rows else ("p", "None."))
        if len(rows) > PREVIEW_ROWS:
            blocks.append(("p", f"And {len(rows) - PREVIEW_ROWS} more in the attached report."))
    if rep.get("preview") and not rep.get("sections"):
        headers, rows = rep["preview"]
        if rows:
            blocks.append(("h", "Needing attention" if rep["severity"] in ("warning", "critical") else "First rows"))
            blocks.append(("table", headers, [[("" if v is None else str(v))[:120] for v in r] for r in rows[:PREVIEW_ROWS]]))
            if len(rows) > PREVIEW_ROWS:
                blocks.append(("p", f"And {len(rows) - PREVIEW_ROWS} more in the attached report."))
    blocks.append(("p", (f"The full report ({len(rep['rows'])} rows, {fmt.upper()}) is attached." if att else
                         f"The full report is larger than {MAX_ATTACHMENT // 2 ** 20} MB and is not attached: export it from the console.")
                        + (f" {period}." if period else "")))
    title = f"{rep['title']}, {today}"
    text, html = nt.render(cfg, title, rep.get("severity") or "info", rep.get("intro") or "", blocks, link="/", label="Security report",
                           action=rep.get("action"))
    return f"[PATCH-01] {title}", text, html, att


def recipients_for(cfg, wanted):
    """Only configured recipients; None means the daily digest list."""
    allowed_ = {a.lower(): a for a in cfg["to"]}
    if wanted is None:
        return list(cfg["to_digest"])
    return [allowed_[a.lower()] for a in wanted if isinstance(a, str) and a.lower() in allowed_]


def queue(conn, cfg, key, params, fmt, recipients, by, period=None, skip_empty=False):
    """Build, render and queue one report mail. Returns (rows, recipients) or raises."""
    rep = build(conn, key, params)
    if skip_empty and not rep["rows"]:
        return 0, []
    to = recipients_for(cfg, recipients)
    if not to:
        raise ReportError("No recipient: add recipients in Admin > Mail (or tick 'Daily digest' for them).")
    subject, text, html, att = compose(conn, cfg, rep, fmt, by, period)
    from . import notify as nt
    with conn.transaction():
        nt.enqueue(conn, "report", rep.get("severity") or "info", subject, text, html, to, attachment=att)
    return len(rep["rows"]), to


def _due(s, now):
    hh, mm = (int(x) for x in s["at_time"].split(":"))
    if (now.hour, now.minute) < (hh, mm):
        return False
    if s["last_run_on"] and str(s["last_run_on"]) == now.date().isoformat():
        return False
    if s["frequency"] == "weekly" and WEEKDAYS[now.weekday()] != s["weekday"]:
        return False
    if s["frequency"] == "monthly" and now.day != s["monthday"]:
        return False
    return True


def counts_as_scheduled(s, now, asked):
    """Does this run stand for today's scheduled one? A scheduled run always; a "Run now" when the
    schedule is on and today's time has already come (else the schedule would send it again)."""
    return not asked or bool(s.get("enabled") and _due(s, now))


def run_due(conn, cfg):
    """Scheduled reports whose time has come today, and any asked for at once."""
    now = datetime.now(cfg["tz"])
    rows = conn.execute("SELECT * FROM report_schedules WHERE enabled OR run_requested_at IS NOT NULL ORDER BY name").fetchall()
    conn.commit()
    done = []
    for s in rows:
        asked = s["run_requested_at"] is not None
        if not asked and not _due(s, now):
            continue
        period = {"daily": "Sent every day", "weekly": "Sent every week", "monthly": "Sent every month"}[s["frequency"]] \
            + f" at {s['at_time']} SGT; change it in Admin > Scheduled reports"
        try:
            n, to = queue(conn, cfg, s["report"], dict(s["params"] or {}, _fresh_ai=True), s["format"], s["recipients"],
                          "scheduled: " + s["name"], period, s["skip_empty"] and not asked)
            ok, msg = True, (f"queued for {len(to)} recipient(s), {n} rows" if to else "nothing to report: not sent")
        except Exception as e:  # noqa: BLE001 - recorded on the schedule, tried again next time
            conn.rollback()
            ok, msg = False, (str(e) if isinstance(e, ReportError) else "could not be built: " + type(e).__name__)
            log.warning("report %s: %s", s["name"], e)
        conn.execute(
            """UPDATE report_schedules SET last_run_at = now(), last_ok = %s, last_msg = %s, run_requested_at = NULL,
                      last_run_on = CASE WHEN %s THEN %s::date ELSE last_run_on END WHERE id = %s""",
            (ok, msg[:300], counts_as_scheduled(s, now, asked), now.date().isoformat(), s["id"]))
        conn.commit()
        done.append(s["name"])
    return done
