"""
PATCH-01 : agent updates

The agent files PATCH-01 can send to its servers are published on PATCH-01
itself, by root, with scripts/phase12-agents.sh (phase3b-api.sh publishes the
bundle's agents). Nothing is uploaded through the console: the folder is
mounted read-only into the API.

    <AGENT_RELEASE_DIR>/windows/<version>/patch-agent.ps1     e.g. 1.8.0-win
    <AGENT_RELEASE_DIR>/linux/<version>/patch-agent.py        e.g. 1.8.0

A file is only offered when the version written inside it is the name of
its folder. An update change freezes the version, SHA-256 and size of the
file chosen; the agent downloads exactly that file over its pinned
connection (only while it runs that step), checks the SHA-256, tests the
file, swaps itself and keeps the previous version. If the new version does
not check in, the previous version puts itself back (agents 1.8.0+).

Release signatures: the operator signs a release OFFLINE (the private key
never lives on PATCH-01: scripts/sign-agent-release.sh) and publishes the
signature beside the file as <file>.sig. PATCH-01 only carries it: the
signature goes to the agent, base64, in the update job ("signature"), and an
agent with the release key pinned (Linux 1.8.3+, Windows 1.9.5+) refuses a
file whose signature does not verify. PATCH-01 cannot make one.
"""

import base64
import hashlib
import os
import re
import stat

RELEASE_DIR = os.environ.get("AGENT_RELEASE_DIR", "/agent-releases")
MAX_BYTES = 4 * 2 ** 20
DOWNLOAD = "/api/v1/agent/update-file"

PLATFORMS = {
    "windows": {"file": "patch-agent.ps1", "label": "Windows",
                "version_re": re.compile(r'^\$AgentVersion = "(\d{1,4}\.\d{1,4}\.\d{1,4}-win)"\s*$', re.M),
                "dir_re": re.compile(r"^\d{1,4}\.\d{1,4}\.\d{1,4}-win$")},
    "linux": {"file": "patch-agent.py", "label": "Linux",
              "version_re": re.compile(r'^AGENT_VERSION = "(\d{1,4}\.\d{1,4}\.\d{1,4})"\s*$', re.M),
              "dir_re": re.compile(r"^\d{1,4}\.\d{1,4}\.\d{1,4}$")},
}
# The first agents that can update themselves (and put themselves back)
SELF_UPDATE_FROM = (1, 8, 0)
SHA_RE = re.compile(r"^[0-9a-f]{64}$")
SIG_MIN, SIG_MAX = 256, 1024                # RSA 2048 to 8192 bits
SIG_B64_RE = re.compile(r"^[A-Za-z0-9+/]{340,1368}={0,2}$")

_cache = {}


class Invalid(ValueError):
    """For the operator."""


def version_tuple(v):
    m = re.match(r"^\s*(\d{1,4})\.(\d{1,4})\.(\d{1,4})", str(v or ""))
    return tuple(int(x) for x in m.groups()) if m else None


def platform_of(os_id, pkg_manager):
    return "windows" if (pkg_manager == "wua" or str(os_id or "").lower() == "windows") else "linux"


def _read(platform, version):
    """One published file, checked, or None. Links and odd files are ignored."""
    spec = PLATFORMS[platform]
    if not spec["dir_re"].match(version or ""):
        return None
    folder = os.path.join(RELEASE_DIR, platform, version)
    path = os.path.join(folder, spec["file"])
    try:
        for p in (folder, path):
            st = os.lstat(p)
            if stat.S_ISLNK(st.st_mode):
                return None
        st = os.lstat(path)
        if not stat.S_ISREG(st.st_mode) or not 0 < st.st_size <= MAX_BYTES:
            return None
    except OSError:
        return None
    sig_path = path + ".sig"
    try:
        sst = os.lstat(sig_path)
        sig_key = (sst.st_mtime_ns, sst.st_size) if stat.S_ISREG(sst.st_mode) else None
    except OSError:
        sig_key = None
    key = (path, st.st_mtime_ns, st.st_size, sig_key)
    hit = _cache.get(path)
    if hit and hit[0] == key:
        return hit[1]
    try:
        with open(path, "rb") as fh:
            data = fh.read(MAX_BYTES + 1)
    except OSError:
        return None
    if len(data) != st.st_size:
        return None
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return None
    m = spec["version_re"].search(text)
    if not m or m.group(1) != version:
        return None
    rel = {"platform": platform, "version": version, "sha256": hashlib.sha256(data).hexdigest(),
           "size": len(data), "published_at": st.st_mtime,
           # A hint only: PATCH-01 cannot check an Authenticode signature; the agent does
           "signed": platform == "windows" and "# SIG # Begin signature block" in text,
           # The offline release signature, carried to the agent (PATCH-01 cannot check or make it)
           "signature": _read_sig(sig_path) if sig_key else None}
    rel["release_signed"] = bool(rel["signature"])
    _cache[path] = (key, rel)
    return rel


def _read_sig(path):
    """<file>.sig as base64, or None when it is missing, a link or not the size of an RSA signature."""
    try:
        st = os.lstat(path)
        if not stat.S_ISREG(st.st_mode) or not SIG_MIN <= st.st_size <= SIG_MAX:
            return None
        with open(path, "rb") as fh:
            raw = fh.read(SIG_MAX + 1)
    except OSError:
        return None
    if not SIG_MIN <= len(raw) <= SIG_MAX:
        return None
    return base64.b64encode(raw).decode("ascii")


def releases(platform):
    """Every valid published version of one platform, newest first."""
    base = os.path.join(RELEASE_DIR, platform)
    try:
        names = os.listdir(base)
    except OSError:
        return []
    out = [r for r in (_read(platform, n) for n in names) if r]
    out.sort(key=lambda r: version_tuple(r["version"]), reverse=True)
    return out


def find(platform, version):
    if platform not in PLATFORMS:
        return None
    return _read(platform, str(version or ""))


def standing(agent_version, latest):
    """How a server's agent compares with the newest published one."""
    have = version_tuple(agent_version)
    if not have:
        return "unknown"
    if not latest:
        return "no_release"
    want = version_tuple(latest["version"])
    return "current" if have == want else "older" if have < want else "newer"


def can_self_update(agent_version):
    have = version_tuple(agent_version)
    return bool(have and have >= SELF_UPDATE_FROM)


FLEET_SQL = """
SELECT h.id::text AS host_id, h.hostname, h.os_id, h.os_version, h.pkg_manager::text AS pkg_manager,
       h.host_group, h.agent_version, h.last_checkin, agent_state(h.last_checkin, h.status) AS agent,
       EXISTS (SELECT 1 FROM change_targets ct JOIN changes c ON c.id = ct.change_id
                WHERE ct.host_id = h.id AND c.state IN ('scheduled', 'running', 'pending_approval')
                  AND c.kind = 'agent_update'
                  AND ct.state NOT IN ('done', 'done_with_warnings', 'failed', 'skipped', 'cancelled')) AS updating
  FROM hosts h
 WHERE h.status <> 'decommissioned'
 ORDER BY h.hostname
"""


def fleet(conn):
    """The published agents, and where each server stands against them."""
    rel = {p: releases(p) for p in PLATFORMS}
    latest = {p: (rel[p][0] if rel[p] else None) for p in PLATFORMS}
    servers, counts = [], {}
    for r in conn.execute(FLEET_SQL).fetchall():
        p = platform_of(r["os_id"], r["pkg_manager"])
        s = standing(r["agent_version"], latest[p])
        row = {k: r[k] for k in ("host_id", "hostname", "os_id", "os_version", "host_group",
                                  "agent_version", "last_checkin", "agent", "updating")}
        row.update(platform=p, standing=s, self_update=can_self_update(r["agent_version"]))
        servers.append(row)
        key = "manual" if s == "older" and not row["self_update"] else s
        counts.setdefault(p, {}).setdefault(key, 0)
        counts[p][key] += 1
    return {"releases": rel, "latest": latest, "servers": servers, "counts": counts,
            "self_update_from": ".".join(str(x) for x in SELF_UPDATE_FROM),
            "release_dir_ok": os.path.isdir(RELEASE_DIR)}


def validate(conn, raw, targets):
    """An agent update change: the version for each platform, frozen now."""
    raw = raw or {}
    hosts = {r["id"]: r for r in conn.execute(
        """SELECT id::text AS id, hostname, os_id, pkg_manager::text AS pkg_manager, agent_version
             FROM hosts WHERE id::text = ANY(%s)""", ([t["host_id"] for t in targets],)).fetchall()}
    need = {}
    for t in targets:
        h = hosts.get(t["host_id"])
        if not h:
            raise Invalid("A selected server no longer exists.")
        need.setdefault(platform_of(h["os_id"], h["pkg_manager"]), []).append(h)
    frozen = {}
    for p, hs in need.items():
        want = str(raw.get(p) or "")
        rel = find(p, want) if want else (releases(p) or [None])[0]
        if not rel:
            raise Invalid(f"No {PLATFORMS[p]['label']} agent {want + ' ' if want else ''}is published on PATCH-01: "
                          f"publish one with ./scripts/phase12-agents.sh.")
        old = [h["hostname"] for h in hs if not can_self_update(h["agent_version"])]
        if old:
            raise Invalid("These servers run an agent older than "
                          + ".".join(str(x) for x in SELF_UPDATE_FROM)
                          + ", which cannot update itself: install the new agent on them once by hand "
                            "(Install-PatchAgent.bat or setup-agent.sh): " + ", ".join(old[:8])
                          + (f" and {len(old) - 8} more" if len(old) > 8 else ""))
        newer = [h["hostname"] for h in hs if version_tuple(h["agent_version"]) > version_tuple(rel["version"])]
        if newer:
            raise Invalid(f"These servers already run a newer agent than {rel['version']}; agents are never "
                          f"downgraded from PATCH-01: " + ", ".join(newer[:8]))
        frozen[p] = {k: rel[k] for k in ("version", "sha256", "size")}
        if rel.get("signature"):
            frozen[p]["signature"] = rel["signature"]
    return {"releases": frozen}


def command_plan(params, platform):
    rel = (params.get("releases") or {}).get(platform)
    if not rel or not SHA_RE.match(str(rel.get("sha256") or "")):
        raise Invalid(f"this change has no {platform} agent")
    plan = {"platform": platform, "version": rel["version"], "sha256": rel["sha256"],
            "size": int(rel["size"]), "download": DOWNLOAD}
    sig = rel.get("signature")
    if not sig:
        # Signed after the change was scheduled: the same file (same SHA-256) with its signature now
        cur = find(platform, rel["version"])
        if cur and cur["sha256"] == rel["sha256"]:
            sig = cur.get("signature")
    if sig and SIG_B64_RE.match(str(sig)):
        plan["signature"] = sig
    return plan


def read_for(platform, version, sha256):
    """The bytes of a published file, only if it is still exactly the one frozen in the change."""
    rel = find(platform, version)
    if not rel or rel["sha256"] != sha256:
        raise Invalid("The published agent file has changed or was removed since this update was scheduled.")
    path = os.path.join(RELEASE_DIR, platform, version, PLATFORMS[platform]["file"])
    with open(path, "rb") as fh:
        data = fh.read(MAX_BYTES + 1)
    if hashlib.sha256(data).hexdigest() != sha256:
        raise Invalid("The published agent file has changed since this update was scheduled.")
    return data
