"""Nessus (Vulnerabilities > Nessus).

Split out of main.py in r90; the code is unchanged."""

import os
import psycopg
import re
from datetime import datetime, timezone
from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field
from typing import List, Optional

from .core import (app, audit, client_ip, db, jsonable, log, require_admin, require_operator, require_viewer)


# ---------------------------------------------------------------------------
# Nessus (Vulnerabilities > Nessus)
# ---------------------------------------------------------------------------


NESSUS_ACTIONS_PER_10MIN = 40


class NessusServerIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=60)
    url: str = Field(..., min_length=9, max_length=300)
    access_key: Optional[str] = Field(None, max_length=80)     # blank on edit: keep the saved one
    secret_key: Optional[str] = Field(None, max_length=80)
    pin_sha256: Optional[str] = Field(None, max_length=120)    # None: keep; "": remove; value: trust this certificate
    enabled: bool = True


class NessusTestIn(BaseModel):
    id: Optional[str] = Field(None, max_length=36)
    url: Optional[str] = Field(None, max_length=300)
    access_key: Optional[str] = Field(None, max_length=80)
    secret_key: Optional[str] = Field(None, max_length=80)
    pin_sha256: Optional[str] = Field(None, max_length=120)


class NessusCertIn(BaseModel):
    url: str = Field(..., max_length=300)


class NessusReportIn(BaseModel):
    server_id: str = Field(..., max_length=36)
    scan_id: int = Field(..., ge=1, le=10**9)
    format: str = Field(..., pattern="^(pdf|html|csv|nessus)$")
    history_id: Optional[int] = Field(None, ge=1, le=10**9)


class NessusScanIn(BaseModel):
    template_uuid: Optional[str] = Field(None, max_length=80)
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = Field(None, max_length=300)
    targets: Optional[str] = Field(None, max_length=40000)      # host names, addresses, ranges
    host_ids: List[str] = Field(default_factory=list, max_length=2000)   # PATCH-01 servers, by id
    groups: List[str] = Field(default_factory=list, max_length=100)      # PATCH-01 patch groups
    folder_id: Optional[int] = Field(None, ge=1, le=10**9)
    schedule: str = Field("ondemand", pattern="^(ondemand|daily|weekly|monthly)$")
    at: Optional[str] = Field(None, max_length=5)
    day: Optional[str] = Field(None, max_length=2)
    dom: Optional[int] = Field(None, ge=1, le=28)
    launch_now: bool = False


def _nid(v, what="Nessus server"):
    if not re.fullmatch(r"[0-9a-f-]{36}", v or ""):
        raise HTTPException(404, f"No such {what}.")
    return v


def _nessus_server(conn, sid):
    r = conn.execute("SELECT * FROM nessus_servers WHERE id = %s", (_nid(sid),)).fetchone()
    if not r:
        raise HTTPException(404, "No such Nessus server.")
    return dict(r)


def _nessus_on(s):
    if not s["enabled"]:
        raise HTTPException(409, f"{s['name']} is turned off in PATCH-01: turn it on (Edit) first.")
    return s


def _nessus_limit(conn, user, actions, n=NESSUS_ACTIONS_PER_10MIN):
    k = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = ANY(%s)
                          AND occurred_at > now() - interval '10 minutes'""", (user, list(actions))).fetchone()["n"]
    if k >= n:
        raise HTTPException(429, f"At most {n} of these in 10 minutes: try again shortly.")


def _nessus_view(conn, admin=False):
    """Servers (no keys, ever), their scans, the import state and what each server allows."""
    from . import nessus as ns
    servers = [dict(r) for r in conn.execute(
        """SELECT id, name, url, enabled, product, version, scan_control, pin_sha256 IS NOT NULL AS pinned, pin_subject,
                  pin_not_after, last_test_at, last_test_ok, last_test_msg, last_sync_at, last_sync_ok, last_sync_msg,
                  created_by, created_at FROM nessus_servers ORDER BY lower(name)""").fetchall()]
    scans = [dict(r) for r in conn.execute(
        """SELECT s.*, (SELECT count(*) FROM nessus_findings f WHERE f.server_id = s.server_id AND f.scan_id = s.scan_id) AS findings
             FROM nessus_scans s ORDER BY lower(s.name)""").fetchall()]
    for s in scans:
        s["server_id"] = str(s["server_id"])
    for v in servers:
        v["id"] = str(v["id"])
        if not admin:
            v.pop("created_by", None)
    reports = [dict(r) for r in conn.execute(
        """SELECT id, server_id, scan_id, format, state, error, requested_by, requested_at, finished_at FROM nessus_reports
            WHERE requested_at > now() - interval '1 day' ORDER BY requested_at DESC LIMIT 30""").fetchall()]
    return {"servers": servers, "scans": scans, "reports": reports, "key_ready": os.access(_av_key_file(), os.R_OK),
            "sync_minutes": ns.SYNC_MINUTES}


def _av_key_file():
    from . import antivirus as av
    return av.KEY_FILE


@app.get("/api/v1/nessus")
def nessus_page(request: Request, user: str = Depends(require_viewer)):
    is_admin = (getattr(request.state, "user", None) or {}).get("role") == "admin"
    with db() as conn:
        try:
            with conn.transaction():
                v = _nessus_view(conn, is_admin)
        except psycopg.errors.UndefinedTable:
            raise HTTPException(409, "Nessus is not set up on this PATCH-01 yet: run phase3a-schema.sh (schema 046).")
        return jsonable(v)


NESSUS_FINDINGS_SQL = """
SELECT f.server_id::text AS server_id, f.scan_id, s.name AS scan, f.host_name, f.host_ip, f.host_fqdn, f.host_os,
       f.host_id::text AS host_id, h.hostname AS our_host, h.host_group, f.plugin_id, f.plugin_name, f.family, f.severity,
       f.cvss3, f.cvss, f.cves, f.port, f.protocol, f.service, f.exploit, f.seen_at
  FROM nessus_findings f JOIN nessus_scans s ON s.server_id = f.server_id AND s.scan_id = f.scan_id
  LEFT JOIN hosts h ON h.id = f.host_id
 WHERE f.severity >= %(min)s
   AND (%(server)s::uuid IS NULL OR f.server_id = %(server)s::uuid)
   AND (%(scan)s::int IS NULL OR f.scan_id = %(scan)s::int)
   -- The same fields, in the same order, as the page's search box (nessus.js drawFindings)
   AND (%(q)s::text IS NULL OR strpos(lower(coalesce(f.host_name, '') || ' ' || coalesce(f.host_ip, '') || ' '
                                       || coalesce(h.hostname, '') || ' ' || coalesce(f.plugin_name, '')
                                       || ' ' || coalesce(array_to_string(f.cves, ' '), '')), lower(%(q)s::text)) > 0)
 ORDER BY f.severity DESC, coalesce(f.cvss3, f.cvss) DESC NULLS LAST, f.host_name, f.plugin_id
 LIMIT %(limit)s"""


def _nessus_filters(server=None, scan=None, severity=1, q=None):
    q = (q or "").strip()
    return {"server": _nid(server) if server else None, "scan": int(scan) if scan else None,
            "min": max(1, min(4, int(severity or 1))),
            "q": q[:80] if q and not re.search(r"[\x00-\x1f\x7f]", q) else None}     # a parameter, never part of the SQL


@app.get("/api/v1/nessus/findings")
def nessus_findings(server: Optional[str] = None, scan: Optional[int] = None, severity: int = 1, q: Optional[str] = None,
                    user: str = Depends(require_viewer)):
    """The imported findings (low severity and above by default), most severe first, with figures for the graphs."""
    f = _nessus_filters(server, scan, severity, q)
    with db() as conn:
        rows = [dict(r) for r in conn.execute(NESSUS_FINDINGS_SQL, dict(f, limit=5000)).fetchall()]
        by_sev = {r["severity"]: r["n"] for r in conn.execute(
            """SELECT severity, count(*) AS n FROM nessus_findings
                WHERE (%(server)s::uuid IS NULL OR server_id = %(server)s::uuid) AND (%(scan)s::int IS NULL OR scan_id = %(scan)s::int)
                GROUP BY 1""", f).fetchall()}
        hosts = conn.execute(
            """SELECT count(DISTINCT host_name) AS n, count(DISTINCT host_name) FILTER (WHERE host_id IS NOT NULL) AS ours,
                      count(DISTINCT c) AS cves
                 FROM nessus_findings LEFT JOIN LATERAL unnest(cves) c ON true
                WHERE severity >= 1 AND (%(server)s::uuid IS NULL OR server_id = %(server)s::uuid)
                  AND (%(scan)s::int IS NULL OR scan_id = %(scan)s::int)""", f).fetchone()
    return jsonable({"items": rows, "limited": len(rows) >= 5000,
                     "severity": [{"label": ns_sev, "n": by_sev.get(k, 0)} for k, ns_sev in ((4, "Critical"), (3, "High"), (2, "Medium"), (1, "Low"))],
                     "hosts": hosts["n"], "our_hosts": hosts["ours"], "cves": hosts["cves"]})


@app.post("/api/v1/nessus/scans/{sid}/{scan_id}/import")
def nessus_import(sid: str, scan_id: int, request: Request, user: str = Depends(require_operator)):
    """Import the scan's newest finished run again (the worker does it within a minute)."""
    with db() as conn:
        _nessus_limit(conn, user, ("nessus_import_requested",))
        with conn.transaction():
            s = _nessus_on(_nessus_server(conn, sid))
            r = conn.execute("""UPDATE nessus_scans SET import_requested_at = now() WHERE server_id = %s AND scan_id = %s
                                RETURNING name, last_history_id, status""", (s["id"], int(scan_id))).fetchone()
            if not r:
                raise HTTPException(404, "No such scan: refresh the list.")
            conn.execute("UPDATE nessus_servers SET sync_requested_at = now() WHERE id = %s", (s["id"],))
            audit(conn, actor=user, actor_type="user", action="nessus_import_requested", object_type="nessus_scan",
                  object_id=f"{s['id']}/{int(scan_id)}", detail={"scan": r["name"]}, source_ip=client_ip(request))
    busy = (r["status"] or "") in ("running", "pausing", "paused", "stopping", "pending", "resuming")
    return {"ok": True, "message": "This scan has no finished run to import yet." if not r["last_history_id"]
            else "The scan is running: its results are imported once it finishes." if busy
            else "Import asked: the results arrive within a minute or two."}


@app.post("/api/v1/nessus/scans/{sid}/{scan_id}/{action}")
def nessus_action(sid: str, scan_id: int, action: str, request: Request, user: str = Depends(require_operator)):
    """Launch, pause, resume or stop a scan in Nessus (where Nessus allows it from outside)."""
    from . import nessus as ns
    if action not in ns.ACTIONS:
        raise HTTPException(404, "Unknown action.")
    with db() as conn:
        _nessus_limit(conn, user, ("nessus_scan_action",))
        s = _nessus_on(_nessus_server(conn, sid))
        sc = conn.execute("SELECT name FROM nessus_scans WHERE server_id = %s AND scan_id = %s", (s["id"], int(scan_id))).fetchone()
        if not sc:
            raise HTTPException(404, "No such scan: refresh the list.")
        if s["scan_control"] is False:
            raise HTTPException(409, f"{s['product'] or 'This Nessus'} does not let outside tools {action} scans: do it in Nessus.")
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="nessus_scan_action", object_type="nessus_scan",
                  object_id=f"{s['id']}/{int(scan_id)}", detail={"scan": sc["name"], "action": action}, source_ip=client_ip(request))
    try:
        ns.act(s, scan_id, action)
    except ns.NotAllowed as e:
        with db() as conn:
            conn.execute("UPDATE nessus_servers SET scan_control = false WHERE id = %s", (s["id"],))
            conn.commit()
        raise HTTPException(409, str(e))
    except ns.NessusError as e:
        raise HTTPException(502, str(e))
    with db() as conn:
        conn.execute("UPDATE nessus_servers SET scan_control = true, sync_requested_at = now() WHERE id = %s", (s["id"],))
        conn.execute("UPDATE nessus_scans SET status = %s WHERE server_id = %s AND scan_id = %s",
                     ({"launch": "pending", "pause": "pausing", "resume": "resuming", "stop": "stopping"}[action], s["id"], int(scan_id)))
        conn.commit()
    return {"ok": True, "message": {"launch": "Scan started in Nessus.", "pause": "Pausing the scan.",
                                    "resume": "Resuming the scan.", "stop": "Stopping the scan."}[action]}


def _nessus_targets(conn, body):
    """The scan's targets: what was typed, PATCH-01 servers chosen, and patch groups (their addresses or names)."""
    from . import nessus as ns
    parts = []
    if body.targets:
        parts += ns.clean_targets(body.targets)
    ids = [i for i in body.host_ids if re.fullmatch(r"[0-9a-f-]{36}", i or "")]
    groups = [g for g in body.groups if re.fullmatch(r"[A-Za-z0-9 ._()+-]{1,40}", g or "")]
    if ids or groups:
        for r in conn.execute(
                """SELECT host(agent_ip) AS ip, fqdn, hostname FROM hosts WHERE status <> 'decommissioned'
                     AND (id = ANY(%s::uuid[]) OR host_group = ANY(%s))""", (ids, groups)).fetchall():
            parts.append(r["ip"] or r["fqdn"] or r["hostname"])
    if not parts:
        raise ns.NessusError("Choose servers or patch groups, or type the targets.")
    return ", ".join(ns.clean_targets(",".join(parts)))


@app.get("/api/v1/nessus/servers/{sid}/editor")
def nessus_editor(sid: str, user: str = Depends(require_admin)):
    """The templates and folders to create a scan with."""
    from . import nessus as ns
    with db() as conn:
        s = _nessus_server(conn, sid)
        groups = [r["name"] for r in conn.execute("SELECT name FROM host_groups ORDER BY patch_order, name").fetchall()]
    if s["scan_control"] is False:
        return {"allowed": False, "message": f"{s['product'] or 'This Nessus'} does not let outside tools create or edit scans.",
                "templates": [], "folders": [], "groups": groups}
    try:
        return {"allowed": True, "templates": [t for t in ns.templates(s) if not t["subscription_only"]],
                "folders": ns.folders(s), "groups": groups}
    except ns.NotAllowed as e:
        with db() as conn:
            conn.execute("UPDATE nessus_servers SET scan_control = false WHERE id = %s", (s["id"],))
            conn.commit()
        return {"allowed": False, "message": str(e), "templates": [], "folders": [], "groups": groups}
    except ns.NessusError as e:
        raise HTTPException(502, str(e))


@app.post("/api/v1/nessus/servers/{sid}/scans")
def nessus_scan_create(sid: str, body: NessusScanIn, request: Request, admin: str = Depends(require_admin)):
    from . import exports as ex, nessus as ns
    with db() as conn:
        _nessus_limit(conn, admin, ("nessus_scan_created", "nessus_scan_edited"), 20)
        s = _nessus_on(_nessus_server(conn, sid))
        try:
            settings = ns.scan_settings(body.name, _nessus_targets(conn, body), body.description, body.folder_id,
                                        body.schedule, body.at, body.day, body.dom, ex.TZ_NAME)
        except ns.NessusError as e:
            raise HTTPException(422, str(e))
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="nessus_scan_created", object_type="nessus_server",
                  object_id=s["id"], detail={"name": settings["name"], "targets": settings["text_targets"][:500],
                                             "schedule": body.schedule}, source_ip=client_ip(request))
    try:
        new_id = ns.create(s, body.template_uuid, settings)
    except ns.NotAllowed as e:
        with db() as conn:
            conn.execute("UPDATE nessus_servers SET scan_control = false WHERE id = %s", (s["id"],))
            conn.commit()
        raise HTTPException(409, str(e))
    except ns.NessusError as e:
        raise HTTPException(502, str(e))
    note = "."
    if body.launch_now and new_id:                  # the scan exists now: a failed start never hides that
        try:
            ns.act(s, new_id, "launch")
            note = " and started."
        except ns.NessusError as e:
            note = f", but it did not start: {e} Use Launch on the scan."
    with db() as conn:
        conn.execute("UPDATE nessus_servers SET scan_control = true, sync_requested_at = now() WHERE id = %s", (s["id"],))
        conn.commit()
    return {"ok": True, "scan_id": new_id, "message": "Scan created in Nessus" + note}


@app.put("/api/v1/nessus/servers/{sid}/scans/{scan_id}")
def nessus_scan_edit(sid: str, scan_id: int, body: NessusScanIn, request: Request, admin: str = Depends(require_admin)):
    from . import exports as ex, nessus as ns
    with db() as conn:
        _nessus_limit(conn, admin, ("nessus_scan_created", "nessus_scan_edited"), 20)
        s = _nessus_on(_nessus_server(conn, sid))
        sc = conn.execute("SELECT name, uuid FROM nessus_scans WHERE server_id = %s AND scan_id = %s", (s["id"], int(scan_id))).fetchone()
        if not sc:
            raise HTTPException(404, "No such scan: refresh the list.")
        try:
            settings = ns.scan_settings(body.name, _nessus_targets(conn, body), body.description, body.folder_id,
                                        body.schedule, body.at, body.day, body.dom, ex.TZ_NAME)
        except ns.NessusError as e:
            raise HTTPException(422, str(e))
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="nessus_scan_edited", object_type="nessus_scan",
                  object_id=f"{s['id']}/{int(scan_id)}", detail={"name": settings["name"], "targets": settings["text_targets"][:500],
                                                                 "schedule": body.schedule}, source_ip=client_ip(request))
    try:
        ns.edit(s, scan_id, body.template_uuid, settings)
    except ns.NotAllowed as e:
        with db() as conn:
            conn.execute("UPDATE nessus_servers SET scan_control = false WHERE id = %s", (s["id"],))
            conn.commit()
        raise HTTPException(409, str(e))
    except ns.NessusError as e:
        raise HTTPException(502, str(e))
    with db() as conn:
        conn.execute("UPDATE nessus_servers SET sync_requested_at = now() WHERE id = %s", (s["id"],))
        conn.commit()
    return {"ok": True, "message": "Scan changed in Nessus."}


@app.post("/api/v1/nessus/reports")
def nessus_report_start(body: NessusReportIn, request: Request, user: str = Depends(require_operator)):
    """Ask Nessus to build a report of a scan (PDF, HTML, CSV, .nessus); poll it, then download it."""
    from . import nessus as ns
    with db() as conn:
        _nessus_limit(conn, user, ("nessus_report_requested",), 30)
        s = _nessus_on(_nessus_server(conn, body.server_id))
        sc = conn.execute("SELECT name, last_history_id FROM nessus_scans WHERE server_id = %s AND scan_id = %s",
                          (s["id"], body.scan_id)).fetchone()
        if not sc:
            raise HTTPException(404, "No such scan: refresh the list.")
    hist = body.history_id or sc["last_history_id"]
    if not hist:
        raise HTTPException(409, "This scan has no finished run to report on yet.")
    try:
        fid = ns.export_start(s, body.scan_id, body.format, hist)
    except ns.NessusError as e:
        raise HTTPException(502, str(e))
    with db() as conn:
        with conn.transaction():
            r = conn.execute("""INSERT INTO nessus_reports (server_id, scan_id, history_id, format, file_id, requested_by)
                                VALUES (%s,%s,%s,%s,%s,%s) RETURNING id""", (s["id"], body.scan_id, hist, body.format, fid, user)).fetchone()
            audit(conn, actor=user, actor_type="user", action="nessus_report_requested", object_type="nessus_scan",
                  object_id=f"{s['id']}/{body.scan_id}", detail={"scan": sc["name"], "format": body.format}, source_ip=client_ip(request))
    return {"id": str(r["id"]), "state": "exporting"}


def _nessus_report(conn, rid):
    r = conn.execute("""SELECT *, extract(epoch FROM now() - requested_at)::int AS age_s FROM nessus_reports
                         WHERE id = %s""", (_nid(rid, "report"),)).fetchone()
    if not r:
        raise HTTPException(404, "No such report.")
    return dict(r)


@app.get("/api/v1/nessus/reports/{rid}")
def nessus_report_state(rid: str, user: str = Depends(require_operator)):
    from . import nessus as ns
    with db() as conn:
        r = _nessus_report(conn, rid)
        s = _nessus_server(conn, str(r["server_id"]))
    if r["state"] == "exporting":
        try:
            st = ns.export_status(s, r["scan_id"], r["file_id"])
        except ns.NessusError as e:
            st, err = "failed", str(e)
        else:
            err = "Nessus could not build the report." if st == "failed" else None
        if st != "exporting" or (r["age_s"] or 0) > 1800:
            if st == "exporting":
                st, err = "failed", "Nessus took longer than 30 minutes to build the report."
            with db() as conn:
                conn.execute("UPDATE nessus_reports SET state = %s, error = %s, finished_at = now() WHERE id = %s", (st, err, r["id"]))
                conn.commit()
            r["state"], r["error"] = st, err
    return {"id": str(r["id"]), "state": r["state"], "error": r["error"], "format": r["format"]}


NESSUS_MEDIA = {"pdf": "application/pdf", "html": "text/html; charset=utf-8", "csv": "text/csv; charset=utf-8",
                "nessus": "application/xml"}


@app.get("/api/v1/nessus/reports/{rid}/download")
def nessus_report_download(rid: str, request: Request, user: str = Depends(require_operator)):
    """The report Nessus built, passed through as it comes (nothing is kept on PATCH-01)."""
    from fastapi.responses import StreamingResponse
    from . import nessus as ns
    with db() as conn:
        r = _nessus_report(conn, rid)
        if r["state"] not in ("ready", "downloaded"):
            raise HTTPException(409, "The report is not ready yet.")
        s = _nessus_server(conn, str(r["server_id"]))
        sc = conn.execute("SELECT name FROM nessus_scans WHERE server_id = %s AND scan_id = %s", (s["id"], r["scan_id"])).fetchone()
        with conn.transaction():
            conn.execute("UPDATE nessus_reports SET state = 'downloaded' WHERE id = %s", (r["id"],))
            audit(conn, actor=user, actor_type="user", action="nessus_report_downloaded", object_type="nessus_scan",
                  object_id=f"{s['id']}/{r['scan_id']}", detail={"format": r["format"]}, source_ip=client_ip(request))
    try:
        c, fh, length, _, _ = ns.export_open(s, r["scan_id"], r["file_id"])
    except ns.NessusError as e:
        raise HTTPException(502, str(e))

    def body():
        try:
            while True:
                b = fh.read(262144)
                if not b:
                    break
                yield b
        except ns.NessusError:
            return                                  # too large: the download stops (the browser shows it failed)
        finally:
            c.close()
    base = re.sub(r"[^A-Za-z0-9._-]+", "-", ((sc or {}).get("name") or f"scan-{r['scan_id']}"))[:60].strip("-") or "scan"
    ext = {"nessus": "nessus"}.get(r["format"], r["format"])
    headers = {"Content-Disposition": f'attachment; filename="nessus-{base}-{datetime.now(timezone.utc):%Y%m%d}.{ext}"',
               "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff",
               "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; img-src data:; sandbox"}
    if length:
        headers["Content-Length"] = str(length)
    return StreamingResponse(body(), media_type=NESSUS_MEDIA[r["format"]], headers=headers)


@app.get("/api/v1/nessus/export")
def nessus_export(request: Request, format: str = "xlsx", server: Optional[str] = None, scan: Optional[int] = None,
                  severity: int = 1, q: Optional[str] = None, user: str = Depends(require_viewer)):
    """PATCH-01's own report of the imported findings. Excel: Summary, By host, Findings, By CVE. PDF: by host."""
    from fastapi.responses import Response
    from . import exports as ex, nessus_report as nrep
    if format not in ("xlsx", "pdf", "csv"):
        raise HTTPException(422, "format must be xlsx, pdf or csv")
    f = _nessus_filters(server, scan, severity, q)
    with db() as conn:
        _nessus_limit(conn, user, ("nessus_findings_exported",), 20)
        rows = [dict(r) for r in conn.execute(NESSUS_FINDINGS_SQL,
                                              dict(f, limit=20000 if format == "pdf" else 200000)).fetchall()]
        body, mime, ext, n = nrep.render(conn, format, user, rows, f, ex.TZ)
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="nessus_findings_exported", detail={"format": format, "rows": n},
                  source_ip=client_ip(request))
    return Response(body, media_type=mime, headers={
        "Content-Disposition": f'attachment; filename="{ex.file_name("nessus-findings", ext)}"',
        "Cache-Control": "no-store", "X-Rows": str(n)})


# ---- Nessus servers (admins) ----

@app.post("/api/v1/admin/nessus/certificate")
def nessus_certificate(body: NessusCertIn, request: Request, admin: str = Depends(require_admin)):
    """The certificate Nessus presents (handshake only), to compare and trust."""
    from . import nessus as ns
    with db() as conn:
        _nessus_limit(conn, admin, ("nessus_certificate_read", "nessus_tested"), 20)
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="nessus_certificate_read", detail={"url": body.url[:200]},
                  source_ip=client_ip(request))
    try:
        cert = ns.certificate(body.url)
        cert["publicly_trusted"] = ns.publicly_trusted(body.url)
        return cert
    except ns.NessusError as e:
        raise HTTPException(422, str(e))


@app.post("/api/v1/admin/nessus/test")
def nessus_test(body: NessusTestIn, request: Request, admin: str = Depends(require_admin)):
    """Sign in to Nessus with what is typed (or a saved server's keys) and read its product and scans."""
    from . import nessus as ns
    with db() as conn:
        _nessus_limit(conn, admin, ("nessus_certificate_read", "nessus_tested"), 20)
        saved = _nessus_server(conn, body.id) if body.id else None
        try:
            url = ns.clean_url(body.url) if body.url else (saved or {}).get("url")
            if not url:
                raise ns.NessusError("Enter Nessus's address, for example https://nessus.example:8834")
            pin = (saved or {}).get("pin_sha256") if body.pin_sha256 is None else ns.clean_pin(body.pin_sha256)
            if saved and url != saved["url"] and body.pin_sha256 is None:
                pin = None                                   # a pinned certificate belongs to its own address
            if body.access_key or body.secret_key:
                keys = (ns.clean_key(body.access_key, "access key"), ns.clean_key(body.secret_key, "secret key"))
            elif saved and url == saved["url"]:
                keys = None                                  # the saved keys, only ever for their own server
            else:
                raise ns.NessusError("Enter the access key and the secret key.")
        except ns.NessusError as e:
            raise HTTPException(422, str(e))
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="nessus_tested", object_id=body.id, detail={"url": url},
                  source_ip=client_ip(request))
    server = dict(saved or {}, url=url, pin_sha256=pin)
    as_saved = bool(saved) and url == saved["url"] and keys is None and pin == saved["pin_sha256"]
    try:
        res = dict(ns.test(server, keys), ok=True)
    except ns.NessusError as e:
        res = {"ok": False, "message": str(e)}
    except Exception as e:  # noqa: BLE001 - never a stack trace from a far end's answer
        log.warning("nessus test: %s", type(e).__name__)
        res = {"ok": False, "message": "Nessus's answer could not be read."}
    finally:
        keys = None
    if as_saved:                                     # only a test of the saved setup itself is recorded on it
        with db() as conn:
            conn.execute("""UPDATE nessus_servers SET last_test_at = now(), last_test_ok = %s, last_test_msg = %s,
                                   product = coalesce(%s, product), version = coalesce(%s, version),
                                   scan_control = CASE WHEN %s::boolean IS NULL THEN scan_control ELSE %s::boolean END
                             WHERE id = %s""",
                         (res["ok"], res["message"][:400], res.get("product"), res.get("version"),
                          res.get("scan_control"), res.get("scan_control"), saved["id"]))
            conn.commit()
    return res


def _nessus_pin_check(url, pin):
    from . import nessus as ns
    cert = ns.certificate(url)
    if cert["sha256"] != pin:
        raise ns.NessusError("Nessus now presents a different certificate (SHA-256 " + cert["sha256_text"] + "): get it again and compare.")
    return cert


@app.post("/api/v1/admin/nessus")
def nessus_server_add(body: NessusServerIn, request: Request, admin: str = Depends(require_admin)):
    from . import nessus as ns
    try:
        name = body.name.strip()
        if not ns.NAME_RE.match(name):
            raise ns.NessusError("The name may use letters, digits, spaces and . _ ( ) -")
        url = ns.clean_url(body.url)
        ak, sk = ns.clean_key(body.access_key, "access key"), ns.clean_key(body.secret_key, "secret key")
        pin = ns.clean_pin(body.pin_sha256)
        if not pin and ns.publicly_trusted(url) is not True:
            raise ns.NessusError("Nessus's certificate is not publicly trusted: use “Get certificate”, compare the "
                                 "fingerprint with the one in Nessus, and trust it. Verification is never turned off.")
        cert = _nessus_pin_check(url, pin) if pin else None
        res = ns.test({"url": url, "pin_sha256": pin}, (ak, sk))
        enc_a, enc_s = ns.encrypt(ak), ns.encrypt(sk)
    except ns.NessusError as e:
        raise HTTPException(422, str(e))
    finally:
        ak = sk = None
    with db() as conn:
        try:
            with conn.transaction():
                if conn.execute("SELECT 1 FROM nessus_servers WHERE lower(name) = lower(%s) OR url = %s", (name, url)).fetchone():
                    raise HTTPException(409, "A Nessus server with this name or address is already added.")
                r = conn.execute(
                    """INSERT INTO nessus_servers (name, url, access_key_enc, secret_key_enc, pin_sha256, pin_subject, pin_not_after,
                                                   pinned_by, pinned_at, enabled, product, version, scan_control, created_by,
                                                   last_test_at, last_test_ok, last_test_msg, sync_requested_at)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s, CASE WHEN %s::text IS NULL THEN NULL ELSE now() END, %s,%s,%s,%s,%s,
                               now(), true, %s, now()) RETURNING id""",
                    (name, url, enc_a, enc_s, pin, (cert or {}).get("subject"), (cert or {}).get("not_after"), admin if pin else None,
                     pin, body.enabled, res["product"], res["version"], res["scan_control"], admin, res["message"][:400])).fetchone()
                audit(conn, actor=admin, actor_type="user", action="nessus_server_added", object_type="nessus_server",
                      object_id=str(r["id"]), detail={"name": name, "url": url, "pinned_sha256": pin, "product": res["product"]},
                      source_ip=client_ip(request))
        except psycopg.errors.UniqueViolation:
            raise HTTPException(409, "A Nessus server with this name or address is already added.")
        return jsonable(_nessus_view(conn, True))


@app.put("/api/v1/admin/nessus/{sid}")
def nessus_server_edit(sid: str, body: NessusServerIn, request: Request, admin: str = Depends(require_admin)):
    from . import nessus as ns
    with db() as conn:
        s = _nessus_server(conn, sid)
    try:
        name = body.name.strip()
        if not ns.NAME_RE.match(name):
            raise ns.NessusError("The name may use letters, digits, spaces and . _ ( ) -")
        url = ns.clean_url(body.url)
        if body.access_key or body.secret_key:
            keys = (ns.clean_key(body.access_key, "access key"), ns.clean_key(body.secret_key, "secret key"))
        elif url != s["url"]:
            raise ns.NessusError("The address changed: enter the API keys again (saved keys only ever go to their own server).")
        else:
            keys = None
        pin = s["pin_sha256"] if body.pin_sha256 is None and url == s["url"] else ns.clean_pin(body.pin_sha256)
        if not pin and ns.publicly_trusted(url) is not True:
            raise ns.NessusError("Nessus's certificate is not publicly trusted: get it, compare it and trust it.")
        cert = _nessus_pin_check(url, pin) if pin and pin != s["pin_sha256"] else None
        res = ns.test(dict(s, url=url, pin_sha256=pin), keys)
        enc = (ns.encrypt(keys[0]), ns.encrypt(keys[1])) if keys else (s["access_key_enc"], s["secret_key_enc"])
    except ns.NessusError as e:
        raise HTTPException(422, str(e))
    finally:
        keys = None
    with db() as conn:
        try:
            with conn.transaction():
                if conn.execute("SELECT 1 FROM nessus_servers WHERE (lower(name) = lower(%s) OR url = %s) AND id <> %s",
                                (name, url, s["id"])).fetchone():
                    raise HTTPException(409, "Another Nessus server has this name or address.")
                conn.execute(
                    """UPDATE nessus_servers SET name=%s, url=%s, access_key_enc=%s, secret_key_enc=%s, pin_sha256=%s,
                              pin_subject = CASE WHEN %s::text IS NULL THEN pin_subject ELSE %s END,
                              pin_not_after = coalesce(%s, CASE WHEN %s::text IS NULL THEN NULL ELSE pin_not_after END),
                              pinned_by = CASE WHEN %s::text IS DISTINCT FROM pin_sha256 THEN %s ELSE pinned_by END,
                              pinned_at = CASE WHEN %s::text IS DISTINCT FROM pin_sha256 THEN now() ELSE pinned_at END,
                              enabled=%s, product=%s, version=%s, scan_control=%s, updated_by=%s, updated_at=now(),
                              last_test_at=now(), last_test_ok=true, last_test_msg=%s, sync_requested_at=now()
                        WHERE id=%s""",
                    (name, url, enc[0], enc[1], pin, (cert or {}).get("subject"), (cert or {}).get("subject"),
                     (cert or {}).get("not_after"), pin, pin, admin if pin else None, pin, body.enabled, res["product"],
                     res["version"], res["scan_control"], admin, res["message"][:400], s["id"]))
                audit(conn, actor=admin, actor_type="user", action="nessus_server_changed", object_type="nessus_server",
                      object_id=str(s["id"]), detail={"name": name, "url": url, "keys_changed": enc[0] != s["access_key_enc"],
                                                      "pinned_sha256": pin}, source_ip=client_ip(request))
        except psycopg.errors.UniqueViolation:
            raise HTTPException(409, "Another Nessus server has this name or address.")
        return jsonable(_nessus_view(conn, True))


@app.delete("/api/v1/admin/nessus/{sid}")
def nessus_server_remove(sid: str, request: Request, admin: str = Depends(require_admin)):
    """Remove a Nessus server from PATCH-01 (its imported findings go too; nothing changes in Nessus)."""
    with db() as conn:
        with conn.transaction():
            r = conn.execute("DELETE FROM nessus_servers WHERE id = %s RETURNING name", (_nid(sid),)).fetchone()
            if not r:
                raise HTTPException(404, "No such Nessus server.")
            conn.execute("DELETE FROM nessus_findings WHERE server_id = %s", (sid,))
            audit(conn, actor=admin, actor_type="user", action="nessus_server_removed", object_type="nessus_server",
                  object_id=sid, detail={"name": r["name"]}, source_ip=client_ip(request))
        return jsonable(_nessus_view(conn, True))


@app.post("/api/v1/nessus/servers/{sid}/sync")
def nessus_sync(sid: str, request: Request, user: str = Depends(require_operator)):
    """Read the server's scans again now (the worker does it within a minute)."""
    with db() as conn:
        _nessus_limit(conn, user, ("nessus_sync_requested",), 20)
        with conn.transaction():
            s = _nessus_server(conn, sid)
            conn.execute("UPDATE nessus_servers SET sync_requested_at = now() WHERE id = %s", (s["id"],))
            audit(conn, actor=user, actor_type="user", action="nessus_sync_requested", object_type="nessus_server",
                  object_id=str(s["id"]), detail={"name": s["name"]}, source_ip=client_ip(request))
    return {"ok": True, "message": "The scans are read again within a minute."}
