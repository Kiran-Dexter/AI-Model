"""Install/operations script fixes: phase2-repos.py behaviour, and static checks
on the shell scripts and SQL that cannot run here (no Docker, no PostgreSQL).

    cd patch01 && python3 -m unittest -v tests.test_scripts_fixes
"""
import importlib.util
import json
import os
import re
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest import mock

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SCRIPTS = os.path.join(ROOT, "scripts")
SQL = os.path.join(ROOT, "sql")

MY_SHELL = ["phase0-bootstrap.sh", "phase1b-data.sh", "phase1c-pulp.sh", "phase3a-schema.sh", "phase3b-api.sh",
            "phase4-cve.sh", "phase5-dashboard.sh", "phase6-llm.sh", "phase7-vmware.sh", "phase8-hardening.sh",
            "lib-admin.sh", "check-connectivity.sh", "patch01-cert-apply.sh", "patch01-start.sh",
            "patch01-update.sh"]


def load_phase2():
    spec = importlib.util.spec_from_file_location("phase2_repos", os.path.join(SCRIPTS, "phase2-repos.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def logical_lines(text):
    """shell lines with backslash continuations joined"""
    return re.sub(r"\\\n\s*", " ", text).split("\n")


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        self.server.hits.append(self.path)
        b = json.dumps({"ok": True}).encode()
        self.send_response(200)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)


class Phase2(unittest.TestCase):
    def setUp(self):
        self.mod = load_phase2()
        self.tmp = tempfile.mkdtemp()
        self.mod.LOG_DIR = self.tmp
        self.mod.LOG_FILE = os.path.join(self.tmp, "phase2.log")

    def test_loopback_calls_ignore_proxy_environment(self):
        srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        srv.hits = []
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            bogus = "http://127.0.0.1:9"     # nothing listens: a proxied request would fail
            env = {"http_proxy": bogus, "https_proxy": bogus, "HTTP_PROXY": bogus, "HTTPS_PROXY": bogus,
                   "no_proxy": "", "NO_PROXY": ""}
            with mock.patch.dict(os.environ, env):
                p = self.mod.Pulp(f"http://127.0.0.1:{srv.server_address[1]}/pulp/api/v3", "admin", "pw")
                self.assertEqual(p.get("/status/"), {"ok": True})
            self.assertEqual(srv.hits, ["/pulp/api/v3/status/"])
        finally:
            srv.shutdown()
            srv.server_close()

    def _run_main(self, fail_sync=(), fail_publish=()):
        m = self.mod
        secrets = os.path.join(self.tmp, "secrets")
        os.makedirs(secrets, exist_ok=True)
        with open(os.path.join(secrets, "pulp-admin.txt"), "w") as fh:
            fh.write("Pulp admin\n  password: pw\n")
        m.SECRETS_DIR = secrets
        m.ETC_DIR = self.tmp
        repos = [{"name": n, "type": "rpm", "policy": "on_demand", "auth": "none"} for n in ("a", "b")]

        class FakePulp:
            def __init__(self, *a):
                pass

            def get(self, path, **kw):
                return {"versions": [], "online_workers": [1]}

            def find_by_name(self, ep, name):
                return "/href/" + name

        def sync(pulp, name, info):
            if name in fail_sync:
                raise RuntimeError("sync broke")

        def publish(pulp, name, info):
            if name in fail_publish:
                raise RuntimeError("publish broke")

        with mock.patch.object(m, "load_repos", return_value=repos), \
                mock.patch.object(m, "Pulp", FakePulp), \
                mock.patch.object(m, "sync_repo", sync), \
                mock.patch.object(m, "publish_and_distribute", publish), \
                mock.patch.object(m, "show_status", lambda *a: None), \
                mock.patch.object(m, "find_entitlement_certs", return_value=(None, None, None)), \
                mock.patch.object(m.os, "geteuid", return_value=0), \
                mock.patch.object(sys, "argv", ["phase2-repos.py", "--sync", "--publish"]), \
                mock.patch("sys.stdout"), mock.patch("sys.stderr"):
            try:
                m.main()
            except SystemExit as e:
                return e.code
        return 0

    def test_exit_zero_when_all_succeed(self):
        self.assertEqual(self._run_main(), 0)

    def test_exit_nonzero_when_a_sync_fails(self):
        self.assertEqual(self._run_main(fail_sync=("a",)), 1)

    def test_exit_nonzero_when_a_publish_fails(self):
        self.assertEqual(self._run_main(fail_publish=("b",)), 1)

    def test_entitlement_test_keeps_proxy_off_argv(self):
        calls = []

        def run(cmd, **kw):
            calls.append((cmd, kw.get("input")))
            return mock.Mock(stdout="200", returncode=0)

        with mock.patch.object(self.mod.subprocess, "run", run), \
                mock.patch.object(self.mod.os.path, "exists", return_value=True), mock.patch("sys.stdout"):
            self.mod.test_entitlement(("/c.pem", "/c-key.pem", None), 'http://bob:pa"55@proxy:8080')
        calls = [c for c in calls if c[0][0] == "curl"]
        self.assertTrue(calls)
        for cmd, inp in calls:
            self.assertFalse(any("pa" in a and "55" in a for a in cmd), cmd)
            self.assertIn("-K", cmd)
            self.assertEqual(inp, 'proxy = "http://bob:pa\\"55@proxy:8080"\n')


class ShellStatic(unittest.TestCase):
    def read(self, name):
        with open(os.path.join(SCRIPTS, name)) as fh:
            return fh.read()

    def test_no_doubled_http_code(self):
        for n in MY_SHELL:
            self.assertNotRegex(self.read(n), r"%\{http_code\}[^\n]*(\\\n[^\n]*)*\|\|\s*echo\s+'?000", n)

    def test_loopback_curl_never_proxied(self):
        for n in MY_SHELL:
            for line in logical_lines(self.read(n)):
                s = line.strip()
                if s.startswith("#") or "127.0.0.1" not in s or not re.search(r"(^|[\s(|])curl\s", s):
                    continue
                if s.startswith(("echo", "say", "printf")):
                    continue
                self.assertIn("--noproxy", s, f"{n}: {s}")

    def test_no_secrets_on_command_lines(self):
        for n in MY_SHELL:
            t = "\n".join(logical_lines(self.read(n)))
            self.assertNotRegex(t, r"-e PGPASSWORD=", n)
            self.assertNotRegex(t, r"reset-admin-password[^\n]*--password", n)
            self.assertNotRegex(t, r'-H "Authorization: Bearer \$', n)
            self.assertNotRegex(t, r'curl[^\n]*-u "admin:\$', n)
            self.assertNotRegex(t, r'--proxy "\$', n)

    def test_no_predictable_tmp_files(self):
        for n in MY_SHELL:
            self.assertNotRegex(self.read(n), r"/tmp/[A-Za-z]+\.\$\$", n)

    def test_cert_helper_keeps_root_files_out_of_staging(self):
        t = self.read("patch01-cert-apply.sh")
        self.assertNotIn('exec 9>"$STAGING', t)
        self.assertNotIn('"$STAGING/.result.tmp"', t)
        self.assertIn("O_NOFOLLOW", t)

    def test_phase7_remove_drops_write_account(self):
        t = self.read("phase7-vmware.sh")
        block = t[t.index("\nremove)"):t.index("\ntimer)")]
        self.assertIn('"$VC_DIR/$NAME-write.env"', block)


class BootUnits(unittest.TestCase):
    def read(self, name):
        with open(os.path.join(SCRIPTS, name)) as fh:
            return fh.read()

    def test_timeouts_cover_the_waits(self):
        upd, start = self.read("patch01-update.sh"), self.read("patch01-start.sh")
        post = int(re.search(r"TimeoutStartSec=(\d+)", upd).group(1))
        boot = int(re.search(r"TimeoutStartSec=(\d+)", start).group(1))
        waits = [int(x) for x in re.findall(r"flock -w (\d+)", upd + start)]
        self.assertTrue(waits)
        lock_wait = max(waits)
        # post-boot: start lock wait + a start (bounded by the boot unit's own budget is too
        # generous; take 40 min) + 10 min settling + update lock wait, with room for the check
        self.assertGreaterEqual(post, lock_wait + 2400 + 600 + lock_wait)
        # boot start: start lock wait + the start + update lock wait for its health check
        self.assertGreaterEqual(boot, lock_wait + 2400 + lock_wait)

    def test_post_boot_disables_itself_first(self):
        upd = self.read("patch01-update.sh")
        blk = upd[upd.index('if [[ "$POST_BOOT" == yes ]]; then'):]
        self.assertLess(blk.index('systemctl disable "$UNIT.service"'), blk.index("start_all"))


class Schema(unittest.TestCase):
    def read(self, name):
        with open(os.path.join(SQL, name)) as fh:
            return fh.read()

    def test_051_truncate_triggers(self):
        t = self.read("051-append-only-truncate.sql")
        for table, fn in (("audit_log", "audit_log_immutable"), ("job_events", "job_events_immutable"),
                          ("change_events", "change_events_immutable")):
            self.assertRegex(t, rf"BEFORE TRUNCATE ON {table}\s+FOR EACH STATEMENT EXECUTE FUNCTION {fn}\(\);")
        self.assertRegex(t, r"VALUES \(51,")
        # the functions it reuses exist in the earlier migrations, and raise for any operation
        for f, fn in (("001-schema.sql", "audit_log_immutable"), ("002-jobs-llm.sql", "job_events_immutable"),
                      ("009-users-changes.sql", "change_events_immutable")):
            body = self.read(f)
            i = body.index(f"FUNCTION {fn}()")
            self.assertIn("RAISE EXCEPTION", body[i:i + 300])
            self.assertNotIn("IF TG_OP", body[i:i + 300])

    def test_051_sorts_after_every_table_it_uses(self):
        names = sorted(f for f in os.listdir(SQL) if f.endswith(".sql"))
        self.assertGreater(names.index("051-append-only-truncate.sql"), names.index("009-users-changes.sql"))

    def test_builtin_schedules_only_on_first_run(self):
        for f, v in (("027-report-schedules.sql", 27), ("029-av-logs.sql", 29)):
            t = self.read(f)
            ins = t.index("INSERT INTO report_schedules")
            stmt = t[ins:t.index(";", ins)]
            self.assertIn(f"NOT EXISTS (SELECT 1 FROM schema_version WHERE version = {v})", stmt, f)
            # and the version row is written after it, in the same file
            self.assertGreater(t.index(f"VALUES ({v},"), ins, f)

    def test_phase3a_ownership_keeps_api_access(self):
        with open(os.path.join(SCRIPTS, "phase3a-schema.sh")) as fh:
            t = fh.read()
        own = t[t.index("<<'OWNERSHIP'"):t.index("\nOWNERSHIP\n")]
        self.assertIn('ALTER SCHEMA public OWNER TO postgres', own)
        self.assertIn('ALTER DATABASE :"dbname" OWNER TO postgres', own)
        self.assertIn('GRANT USAGE ON SCHEMA public TO :"dbuser"', own)
        self.assertIn('GRANT CONNECT, TEMPORARY ON DATABASE', own)
        self.assertNotRegex(own, r"REVOKE[^;]*(SELECT|INSERT|UPDATE|DELETE|USAGE|EXECUTE)")
        # ownership moves BEFORE the grants: ALTER ... OWNER rewrites the old owner's ACL
        # entries to the new owner, so grants made first would be lost by the API role
        self.assertLess(t.index("<<'OWNERSHIP'"), t.index("GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES"))
        self.assertLess(t.index("<<'OWNERSHIP'"), t.index("GRANT USAGE, SELECT ON ALL SEQUENCES"))
        apply_at = t.index('step "Applying the schema"')
        self.assertLess(apply_at, t.index("<<'OWNERSHIP'"))
        # migrations still run as postgres
        self.assertIn('psql -U postgres -d "$DB" \\\n       -v ON_ERROR_STOP=1 --single-transaction', t)

    def test_phase3a_check_names_the_remedy(self):
        with open(os.path.join(SCRIPTS, "phase3a-schema.sh")) as fh:
            t = fh.read()
        chk = t[t.index('if [[ "$CHECK_ONLY" == yes ]]'):t.index('# Dry run')]
        for marker in ("TRUNCATE trigger MISSING", "could drop the audit tables", "migrations go up to"):
            line = next(ln for ln in chk.splitlines() if marker in ln)
            self.assertIn("run ./scripts/phase3a-schema.sh", line, marker)

    def test_phase3a_check_leaves_no_row(self):
        with open(os.path.join(SCRIPTS, "phase3a-schema.sh")) as fh:
            t = fh.read()
        i = t.index('step "Audit log immutability"')
        blk = t[i:t.index("SQL\n)", i)]
        self.assertIn("BEGIN;", blk)
        self.assertTrue(blk.rstrip().endswith("ROLLBACK;"))


if __name__ == "__main__":
    unittest.main()
