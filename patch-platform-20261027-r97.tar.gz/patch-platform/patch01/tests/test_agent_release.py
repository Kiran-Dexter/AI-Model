"""
Linux agent (client/patch-agent.py) and PATCH-01's agent_updates.py:

  - package names can never become package-manager options (O4)
  - signed agent updates with the offline release key (O5)
  - push-linux.sh makes its remote check folder with mktemp -d (O16)
  - sign-agent-release.sh signs what the agents verify

Run from patch01/:  python3 -m unittest -v tests.test_agent_release
The agent is imported from a COPY in a temporary folder (never from client/).
Keys are made with the openssl command line; nothing outside temporary folders
is touched.
"""

import base64
import hashlib
import importlib.util
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

PATCH01 = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.dirname(PATCH01)
AGENT_SRC = os.path.join(ROOT, "client", "patch-agent.py")
PUSH_SRC = os.path.join(ROOT, "client", "push-linux.sh")
SIGNER = os.path.join(PATCH01, "scripts", "sign-agent-release.sh")
AU_SRC = os.path.join(PATCH01, "api", "app", "agent_updates.py")
HAVE_OPENSSL = shutil.which("openssl") is not None
IS_ROOT = hasattr(os, "geteuid") and os.geteuid() == 0


def load(path, name, tmp):
    dst = os.path.join(tmp, name + ".py")
    shutil.copy(path, dst)
    spec = importlib.util.spec_from_file_location(name, dst)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def rd(path, mode="rb"):
    with open(path, mode) as fh:
        return fh.read()


def openssl(*args, **kw):
    return subprocess.run(["openssl"] + list(args), check=True, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, **kw)


class Keys:
    """RSA keys and signatures made with the openssl CLI, as an operator would."""

    def __init__(self, tmp):
        self.tmp = tmp

    def rsa(self, name, bits=3072):
        key = os.path.join(self.tmp, name + ".key")
        pub = os.path.join(self.tmp, name + ".pub")
        openssl("genpkey", "-algorithm", "RSA", "-pkeyopt", "rsa_keygen_bits:%d" % bits, "-out", key)
        openssl("pkey", "-in", key, "-pubout", "-out", pub)
        return key, pub

    def sign(self, key, data):
        f = os.path.join(self.tmp, "data.bin")
        with open(f, "wb") as fh:
            fh.write(data)
        openssl("dgst", "-sha256", "-sign", key, "-out", f + ".sig", f)
        with open(f + ".sig", "rb") as fh:
            return fh.read()


class AgentTestBase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        os.chmod(self.tmp, 0o700)
        self.agent = load(AGENT_SRC, "patch_agent_copy", self.tmp)
        # Never write the real log
        self.logged = []
        self.agent.log = lambda msg, level="INFO": self.logged.append((level, msg))

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)


# ---------------------------------------------------------------------------
# O4: package names
# ---------------------------------------------------------------------------
class PackageNames(AgentTestBase):
    BAD = ["--nogpgcheck", "-y", "--enablerepo=evil", "--allow-unauthenticated", "-oAPT::Get::AllowUnauthenticated=1",
           "--setopt=gpgcheck=0", "~foo", ".hidden", "+x", "", "a b", "a;b", "$(id)", "x\n--nogpgcheck"]
    GOOD = ["bash", "kernel-core", "libstdc++", "python3.11", "openssl-libs", "1:2.3-4.el9", "2.36-9.el9_4.x86_64",
            "0ad", "g++", "libc6:amd64", "1.2~rc1"]

    def test_safe_name(self):
        for n in self.BAD:
            self.assertIsNone(self.agent.SAFE_NAME.match(n), n)
        for n in self.GOOD:
            self.assertIsNotNone(self.agent.SAFE_NAME.match(n), n)

    def test_validated_args_refuse_options(self):
        for n in ["--nogpgcheck", "-y", "--allow-unauthenticated"]:
            with self.assertRaises(RuntimeError):
                self.agent._validated_package_args({"packages": [n]}, "dnf")
            with self.assertRaises(RuntimeError):
                self.agent._validated_package_args({"packages": [{"name": n, "version": "1"}]}, "apt")
        with self.assertRaises(RuntimeError):
            self.agent._validated_package_args({"packages": [{"name": "bash", "version": "--nogpgcheck"}]}, "apt")
        self.assertEqual(self.agent._validated_package_args({"packages": [{"name": "bash", "version": "5.1"}]}, "apt"),
                         ["bash=5.1"])
        self.assertEqual(self.agent._validated_package_args({"packages": [{"name": "bash", "version": "5.1"}]}, "dnf"),
                         ["bash-5.1"])

    def _argv(self, pm, verb, params):
        seen = []
        a = self.agent
        with mock.patch.object(a, "detect_pkg_manager", return_value=pm), \
                mock.patch.object(a, "run_cmd", side_effect=lambda argv, timeout=0: (seen.append(argv), (0, "", ""))[1]), \
                mock.patch.object(a, "collect_kernel", return_value=("k", "k")), \
                mock.patch.object(a, "check_reboot_required", return_value=(False, "")), \
                mock.patch.dict(os.environ, {}):
            verb(None, None, params)
        self.assertEqual(len(seen), 1)
        return seen[0]

    def assert_end_of_options(self, argv, pkgs):
        self.assertIn("--", argv)
        i = argv.index("--")
        self.assertEqual(argv[i + 1:], pkgs, argv)
        self.assertFalse(any(x.startswith("-") for x in argv[i + 1:]))

    def test_argv_has_end_of_options(self):
        a = self.agent
        for pm in ("dnf", "yum"):
            argv = self._argv(pm, a.verb_install_packages, {"packages": [{"name": "bash", "version": "5.1-1.el9"}]})
            self.assertEqual(argv[:3], [pm, "install", "-y"])
            self.assert_end_of_options(argv, ["bash-5.1-1.el9"])
            argv = self._argv(pm, a.verb_install_packages, {"mode": "upgrade", "packages": [{"name": "bash"}, "zlib"]})
            self.assertEqual(argv[:3], [pm, "upgrade", "-y"])
            self.assert_end_of_options(argv, ["bash", "zlib"])
            argv = self._argv(pm, a.verb_download_packages, {"packages": ["bash"]})
            self.assert_end_of_options(argv, ["bash"])
        argv = self._argv("apt", a.verb_install_packages, {"packages": [{"name": "bash", "version": "5.2-2"}]})
        self.assertEqual(argv[0], "apt-get")
        self.assert_end_of_options(argv, ["bash=5.2-2"])
        argv = self._argv("apt", a.verb_install_packages, {"mode": "upgrade", "packages": ["bash"]})
        self.assertIn("--only-upgrade", argv)
        self.assertLess(argv.index("--only-upgrade"), argv.index("--"))
        self.assert_end_of_options(argv, ["bash"])
        argv = self._argv("apt", a.verb_download_packages, {"packages": ["bash"]})
        self.assert_end_of_options(argv, ["bash"])

    def test_option_names_never_reach_run_cmd(self):
        a = self.agent
        for pm in ("dnf", "apt"):
            with mock.patch.object(a, "detect_pkg_manager", return_value=pm), \
                    mock.patch.object(a, "run_cmd") as rc:
                with self.assertRaises(RuntimeError):
                    a.verb_install_packages(None, None, {"packages": ["--nogpgcheck", "bash"]})
                rc.assert_not_called()


# ---------------------------------------------------------------------------
# O5: release signatures
# ---------------------------------------------------------------------------
@unittest.skipUnless(HAVE_OPENSSL, "openssl not installed")
class ReleaseSignature(AgentTestBase):
    def setUp(self):
        super().setUp()
        self.keys = Keys(self.tmp)
        self.key, self.pub = self.rsa = self.keys.rsa("release")
        self.data = b"#!/usr/bin/python3\nAGENT_VERSION = \"9.9.9\"\nprint('x')\n" * 50
        self.sig = self.keys.sign(self.key, self.data)
        conf = os.path.join(self.tmp, "etc")
        os.mkdir(conf, 0o700)
        self.agent.RELEASE_KEY_FILE = os.path.join(conf, "release-signing.pub")

    def pin(self, pub=None, mode=0o644):
        shutil.copy(pub or self.pub, self.agent.RELEASE_KEY_FILE)
        os.chmod(self.agent.RELEASE_KEY_FILE, mode)

    def test_parse_and_fingerprint_match_openssl(self):
        with open(self.pub) as fh:
            n, e, fp = self.agent.parse_release_key(fh.read())
        self.assertEqual(n.bit_length(), 3072)
        self.assertEqual(e, 65537)
        der = openssl("pkey", "-pubin", "-in", self.pub, "-outform", "DER").stdout
        self.assertEqual(fp, hashlib.sha256(der).hexdigest())

    def test_parse_refuses(self):
        small = self.keys.rsa("small", 1024)[1]
        ec_key = os.path.join(self.tmp, "ec.key")
        openssl("genpkey", "-algorithm", "EC", "-pkeyopt", "ec_paramgen_curve:P-256", "-out", ec_key)
        ec_pub = openssl("pkey", "-in", ec_key, "-pubout").stdout
        for bad in [rd(small, "r"), ec_pub, "garbage", "-----BEGIN PUBLIC KEY-----\n!!!\n-----END PUBLIC KEY-----\n",
                    rd(self.key, "r")]:
            with self.assertRaises((ValueError, TypeError)):
                self.agent.parse_release_key(bad)

    def test_verify_accepts_only_the_exact_signature(self):
        with open(self.pub) as fh:
            n, e, _ = self.agent.parse_release_key(fh.read())
        v = self.agent.rsa_verify_sha256
        self.assertTrue(v(n, e, self.data, self.sig))
        self.assertFalse(v(n, e, self.data + b" ", self.sig))
        self.assertFalse(v(n, e, self.data[:-1], self.sig))
        bad = bytearray(self.sig); bad[10] ^= 1
        self.assertFalse(v(n, e, self.data, bytes(bad)))
        self.assertFalse(v(n, e, self.data, self.sig[:-1]))
        self.assertFalse(v(n, e, self.data, b"\x00" + self.sig))
        self.assertFalse(v(n, e, self.data, b""))
        other_key, other_pub = self.keys.rsa("other")
        self.assertFalse(v(n, e, self.data, self.keys.sign(other_key, self.data)))
        # a SHA-1 signature of the same file is not accepted
        f = os.path.join(self.tmp, "d1")
        with open(f, "wb") as fh:
            fh.write(self.data)
        openssl("dgst", "-sha1", "-sign", self.key, "-out", f + ".sig", f)
        self.assertFalse(v(n, e, self.data, rd(f + ".sig")))

    def test_no_key_pinned_keeps_todays_behaviour_and_says_so(self):
        st, note = self.agent.verify_release(self.data, None)
        self.assertEqual(st, "unsigned")
        self.assertIn("NOT signature-checked", note)
        self.assertTrue(any(l == "WARN" and "WITHOUT a release signature check" in m for l, m in self.logged))
        self.assertEqual(self.agent.release_key_state()[0], "none")

    @unittest.skipUnless(IS_ROOT, "the pinned key must be owned by root")
    def test_pinned_key(self):
        self.pin()
        self.assertEqual(self.agent.release_key_state()[0], "pinned")
        b64 = base64.b64encode(self.sig).decode()
        st, note = self.agent.verify_release(self.data, b64)
        self.assertEqual(st, "verified")
        self.assertIn("release signature verified", note)
        with self.assertRaisesRegex(RuntimeError, "carries no signature"):
            self.agent.verify_release(self.data, None)
        with self.assertRaisesRegex(RuntimeError, "does NOT verify"):
            self.agent.verify_release(self.data + b"#", b64)
        with self.assertRaisesRegex(RuntimeError, "not base64"):
            self.agent.verify_release(self.data, "!!!" + b64)
        other_key, _ = self.keys.rsa("other")
        with self.assertRaisesRegex(RuntimeError, "does NOT verify"):
            self.agent.verify_release(self.data, base64.b64encode(self.keys.sign(other_key, self.data)).decode())

    @unittest.skipUnless(IS_ROOT, "the pinned key must be owned by root")
    def test_unusable_pinned_key_refuses_updates(self):
        self.pin(mode=0o666)                                   # others can write it
        self.assertEqual(self.agent.release_key_state()[0], "invalid")
        with self.assertRaisesRegex(RuntimeError, "cannot be used"):
            self.agent.verify_release(self.data, base64.b64encode(self.sig).decode())
        os.chmod(self.agent.RELEASE_KEY_FILE, 0o644)
        with open(self.agent.RELEASE_KEY_FILE, "w") as fh:
            fh.write("not a key\n")
        self.assertEqual(self.agent.release_key_state()[0], "invalid")
        os.unlink(self.agent.RELEASE_KEY_FILE)
        os.symlink(self.pub, self.agent.RELEASE_KEY_FILE)
        self.assertEqual(self.agent.release_key_state()[0], "invalid")

    def test_release_key_command(self):
        copy = os.path.join(self.tmp, "patch_agent_copy.py")
        p = subprocess.run([sys.executable, copy, "release-key", self.pub], stdout=subprocess.PIPE, universal_newlines=True)
        self.assertEqual(p.returncode, 0, p.stdout)
        self.assertIn("RSA 3072 bits", p.stdout)
        p = subprocess.run([sys.executable, copy, "release-key", self.key], stdout=subprocess.PIPE, universal_newlines=True)
        self.assertEqual(p.returncode, 1)
        self.assertIn("not a usable release key", p.stdout)

    # update_agent itself: the signature decides before anything is staged or run
    def _update(self, signature, pinned):
        a = self.agent
        if pinned:
            self.pin()
        me = os.path.join(self.tmp, "bin", "patch-agent")
        os.makedirs(os.path.dirname(me), 0o755, exist_ok=True)
        shutil.rmtree(os.path.join(self.tmp, "update"), ignore_errors=True)
        shutil.copy(AGENT_SRC, me)
        os.chmod(me, 0o755)
        with open(AGENT_SRC, "rb") as fh:
            new = fh.read().replace(b'AGENT_VERSION = "%s"' % a.AGENT_VERSION.encode(), b'AGENT_VERSION = "99.0.0"')
        sig = signature(new) if callable(signature) else signature
        a.UPDATE_DIR = os.path.join(self.tmp, "update")
        a.UPDATE_MARKER = os.path.join(a.UPDATE_DIR, "pending.json")
        seen = {}
        real = a.verify_release

        def spy(data, s):
            seen["result"] = real(data, s)
            return seen["result"]

        class Stop(Exception):
            pass

        params = {"platform": "linux", "version": "99.0.0", "sha256": hashlib.sha256(new).hexdigest(),
                  "size": len(new), "download": a.UPDATE_DOWNLOAD}
        if sig is not None:
            params["signature"] = sig
        with mock.patch.object(a, "_self_path", return_value=me), \
                mock.patch.object(a, "_download_update", return_value=new), \
                mock.patch.object(a, "verify_release", side_effect=spy), \
                mock.patch.object(a, "_test_run", side_effect=Stop("test run reached")):
            try:
                a.verb_update_agent({"verify_tls": "true", "server": "https://p"}, "t", params)
            except Stop:
                return "test-run", seen.get("result")
            except RuntimeError as e:
                return str(e), seen.get("result")
        return "returned", seen.get("result")

    @unittest.skipUnless(IS_ROOT, "the agent's own file must be owned by root")
    def test_update_agent_paths(self):
        good = lambda d: base64.b64encode(self.keys.sign(self.key, d)).decode()
        # no key pinned: as before (reaches the test run), reported as unsigned
        what, res = self._update(None, pinned=False)
        self.assertEqual(what, "test-run")
        self.assertEqual(res[0], "unsigned")
        # key pinned: a good signature reaches the test run
        what, res = self._update(good, pinned=True)
        self.assertEqual(what, "test-run")
        self.assertEqual(res[0], "verified")

    @unittest.skipUnless(IS_ROOT, "the agent's own file must be owned by root")
    def test_update_agent_refusals_change_nothing(self):
        other_key, _ = self.keys.rsa("other")
        for sig, why in [(None, "carries no signature"),
                         (lambda d: base64.b64encode(self.keys.sign(other_key, d)).decode(), "does NOT verify"),
                         (lambda d: base64.b64encode(self.keys.sign(self.key, d + b"x")).decode(), "does NOT verify")]:
            shutil.rmtree(os.path.join(self.tmp, "bin"), ignore_errors=True)
            what, _ = self._update(sig, pinned=True)
            self.assertIn(why, what)
            self.assertFalse(os.path.exists(os.path.join(self.tmp, "update")), "nothing staged")

    def test_checkin_reports_key_state(self):
        a = self.agent
        sent = {}
        with mock.patch.object(a, "load_token", return_value="t"), \
                mock.patch.object(a, "collect_kernel", return_value=("k", "k")), \
                mock.patch.object(a, "check_reboot_required", return_value=(False, "")), \
                mock.patch.object(a, "boot_time_iso", return_value=None), \
                mock.patch.object(a, "hardware_uuid", return_value=None), \
                mock.patch.object(a, "api_call", side_effect=lambda c, m, p, body, t: sent.update(body) or {}):
            a.cmd_checkin({}, None)
        self.assertEqual(sent.get("release_key"), "none")


# ---------------------------------------------------------------------------
# The operator's signing helper and PATCH-01's side
# ---------------------------------------------------------------------------
@unittest.skipUnless(HAVE_OPENSSL, "openssl not installed")
class SigningHelperAndPublishing(AgentTestBase):
    def test_sign_agent_release_script(self):
        keys = Keys(self.tmp)
        key, pub = keys.rsa("release")
        f = os.path.join(self.tmp, "patch-agent.py")
        shutil.copy(AGENT_SRC, f)
        p = subprocess.run(["bash", SIGNER, "--key", key, f], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           universal_newlines=True)
        self.assertEqual(p.returncode, 0, p.stdout)
        self.assertTrue(os.path.exists(f + ".sig"))
        p = subprocess.run(["bash", SIGNER, "--verify", pub, f], stdout=subprocess.PIPE, universal_newlines=True)
        self.assertEqual(p.returncode, 0, p.stdout)
        # what the helper writes is what the agent verifies
        n, e, fp = self.agent.parse_release_key(rd(pub, "r"))
        self.assertTrue(self.agent.rsa_verify_sha256(n, e, rd(f), rd(f + ".sig")))
        fpo = subprocess.run(["bash", SIGNER, "--fingerprint", pub], stdout=subprocess.PIPE, universal_newlines=True)
        self.assertEqual(fpo.stdout.strip(), fp)
        with open(f, "ab") as fh:
            fh.write(b"# changed\n")
        p = subprocess.run(["bash", SIGNER, "--verify", pub, f], stdout=subprocess.PIPE, universal_newlines=True)
        self.assertNotEqual(p.returncode, 0)
        # a small key is refused
        k2, _ = keys.rsa("small", 1024)
        p = subprocess.run(["bash", SIGNER, "--key", k2, f], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           universal_newlines=True)
        self.assertNotEqual(p.returncode, 0)

    def test_agent_updates_carries_the_signature(self):
        rel = os.path.join(self.tmp, "rel")
        au = load(AU_SRC, "agent_updates_copy", self.tmp)
        au.RELEASE_DIR = rel
        d = os.path.join(rel, "linux", "1.8.3")
        os.makedirs(d)
        with open(AGENT_SRC, "rb") as fh:
            data = fh.read().replace(b'AGENT_VERSION = "%s"' % self.agent.AGENT_VERSION.encode(), b'AGENT_VERSION = "1.8.3"')
        with open(os.path.join(d, "patch-agent.py"), "wb") as fh:
            fh.write(data)
        r = au.find("linux", "1.8.3")
        self.assertIsNotNone(r)
        self.assertIsNone(r["signature"])
        self.assertFalse(r["release_signed"])
        frozen = {"releases": {"linux": {k: r[k] for k in ("version", "sha256", "size")}}}
        self.assertNotIn("signature", au.command_plan(frozen, "linux"))
        key, _ = Keys(self.tmp).rsa("release")
        sig = Keys(self.tmp).sign(key, data)
        with open(os.path.join(d, "patch-agent.py.sig"), "wb") as fh:
            fh.write(sig)
        r = au.find("linux", "1.8.3")
        self.assertEqual(base64.b64decode(r["signature"]), sig)
        self.assertTrue(r["release_signed"])
        # signed after the change was frozen: the same file's signature is sent
        plan = au.command_plan(frozen, "linux")
        self.assertEqual(base64.b64decode(plan["signature"]), sig)
        # frozen with its signature
        frozen2 = {"releases": {"linux": dict(frozen["releases"]["linux"], signature=r["signature"])}}
        self.assertEqual(au.command_plan(frozen2, "linux")["signature"], r["signature"])
        # a .sig that is not an RSA signature's size is ignored; a link is ignored
        with open(os.path.join(d, "patch-agent.py.sig"), "wb") as fh:
            fh.write(b"x" * 10)
        self.assertIsNone(au.find("linux", "1.8.3")["signature"])
        os.unlink(os.path.join(d, "patch-agent.py.sig"))
        os.symlink(os.path.join(self.tmp, "release.key"), os.path.join(d, "patch-agent.py.sig"))
        self.assertIsNone(au.find("linux", "1.8.3")["signature"])


# ---------------------------------------------------------------------------
# O16: push-linux.sh's remote check folder
# ---------------------------------------------------------------------------
SSH_STUB = r'''#!/usr/bin/env bash
# ssh stub: logs the remote command; answers mktemp with $FAKE_MKTEMP
printf 'ssh %s\n' "${@: -1}" >>"$STUB_LOG"
cmd="${@: -1}"
case "$cmd" in
  *"mktemp -d /tmp/patch-agent-check."*) printf '%s\n' "$FAKE_MKTEMP" ;;
  *"mktemp -d /tmp/patch-agent-setup."*) printf '/tmp/patch-agent-setup.ZZZZZZZZZZ\n' ;;
  *"bash -s --"*) cat >/dev/null; printf 'os=rhel 9.4\npython=/usr/bin/python3\nenrolled=no\nreach=200\n' ;;
  *) cat >/dev/null 2>&1 || true ;;
esac
exit 0
'''
SCP_STUB = r'''#!/usr/bin/env bash
printf 'scp %s\n' "${@: -1}" >>"$STUB_LOG"
exit 0
'''
CURL_STUB = '#!/usr/bin/env bash\nexit 0\n'


@unittest.skipUnless(HAVE_OPENSSL and shutil.which("bash"), "needs bash and openssl")
class PushLinuxCheckFolder(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.bin = os.path.join(self.tmp, "bin")
        self.work = os.path.join(self.tmp, "client")
        os.makedirs(self.bin)
        os.makedirs(self.work)
        for name, body in (("ssh", SSH_STUB), ("scp", SCP_STUB), ("curl", CURL_STUB)):
            p = os.path.join(self.bin, name)
            with open(p, "w") as fh:
                fh.write(body)
            os.chmod(p, 0o755)
        shutil.copy(PUSH_SRC, os.path.join(self.work, "push-linux.sh"))
        for f in ("install-agent.sh", "patch-agent.py"):
            open(os.path.join(self.work, f), "w").close()
        self.ca = os.path.join(self.tmp, "ca.pem")
        openssl("req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", os.path.join(self.tmp, "ca.key"),
                "-out", self.ca, "-days", "2", "-subj", "/CN=test CA")
        with open(os.path.join(self.tmp, "hosts"), "w") as fh:
            fh.write("srv1.example\n")
        self.log = os.path.join(self.tmp, "stub.log")

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def run_push(self, mktemp_answer):
        env = dict(os.environ, PATH=self.bin + os.pathsep + os.environ["PATH"], STUB_LOG=self.log,
                   FAKE_MKTEMP=mktemp_answer)
        p = subprocess.run(["bash", os.path.join(self.work, "push-linux.sh"), "-H", os.path.join(self.tmp, "hosts"),
                            "-s", "https://patch01.example", "--ca", self.ca, "--test-only"],
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, env=env)
        with open(self.log) as fh:
            return p, fh.read()

    def test_check_folder_comes_from_mktemp(self):
        folder = "/tmp/patch-agent-check.Ab3dEf9hIj"
        p, log = self.run_push(folder)
        self.assertEqual(p.returncode, 0, p.stdout)
        self.assertIn("mktemp -d /tmp/patch-agent-check.XXXXXXXXXX", log)
        self.assertNotIn("mkdir -p /tmp/patch-agent-check", log)
        self.assertIn("scp root@srv1.example:%s/ca.pem" % folder, log)
        self.assertIn("'%s/ca.pem'; rm -rf %s" % (folder, folder), log)
        self.assertRegex(p.stdout, r"srv1\.example\s+rhel 9\.4\s+ready")

    def test_an_odd_answer_is_refused(self):
        for answer in ("", "/tmp/patch-agent-check.$$.0", "/tmp/x; rm -rf /", "/etc"):
            p, log = self.run_push(answer)
            self.assertIn("could not make a private folder", p.stdout)
            self.assertNotIn("scp ", log)
            os.unlink(self.log)


if __name__ == "__main__":
    unittest.main()
