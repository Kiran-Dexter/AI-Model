"""Patch-job state machine fixes in the worker (W1, W3, W4, W6, W7, W9), without PostgreSQL or
vCenter: the database is a fake connection answering by SQL text, vCenter calls are stubbed.

    cd patch01 && python3 -m unittest -v tests.test_jobs_worker
"""
import os
import sys
import threading
import unittest
from datetime import datetime, timedelta, timezone
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "api"))

from app import worker as w          # noqa: E402
from app import vmware               # noqa: E402

UTC = timezone.utc


class Cur:
    def __init__(self, rows):
        self.rows = rows

    def fetchone(self):
        return self.rows[0] if self.rows else None

    def fetchall(self):
        return list(self.rows)


class FakeConn:
    """Answers each query with the rows of the first handler whose text is in the SQL.
    `log` records commits, rollbacks and (via the patched helpers) state changes, in order."""

    def __init__(self, handlers=None, log=None):
        self.handlers = list(handlers or [])
        self.log = log if log is not None else []
        self.sql = []

    def on(self, text, rows):
        self.handlers.insert(0, (text, rows))

    def execute(self, sql, args=None):
        self.sql.append((sql, args))
        for text, rows in self.handlers:
            if text in sql:
                return Cur(rows(args) if callable(rows) else rows)
        return Cur([])

    def commit(self):
        self.log.append(("commit",))

    def rollback(self):
        self.log.append(("rollback",))


class JobTest(unittest.TestCase):
    def setUp(self):
        self.log = []
        self.targets = {}
        self.queued = []
        self.events = []
        self.cmd_n = 0
        log = self.log

        def _set(conn, cid, key, **fields):
            self.targets.setdefault(key, {}).update(fields)
            log.append(("set", key, dict(fields)))

        def _detail(conn, cid, key, **more):
            self.targets.setdefault(key, {}).setdefault("detail", {}).update(more)
            log.append(("detail", key, dict(more)))

        def _queue(conn, change, t, verb, params, hours=4):
            self.cmd_n += 1
            self.queued.append((t["target_key"], verb, params))
            log.append(("queue", t["target_key"], verb))
            return f"cmd-{self.cmd_n}"

        def event(conn, cid, key, actor, step, ok, msg, detail=None):
            self.events.append((key, step, ok, msg))
            log.append(("event", key, step, ok))

        patches = [mock.patch.object(w, "_set", _set), mock.patch.object(w, "_detail", _detail),
                   mock.patch.object(w, "_queue", _queue), mock.patch.object(w.ch, "event", event),
                   mock.patch.object(w, "_recompute", lambda conn, host_id: None)]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)
        w._vc_jobs.clear()
        self.addCleanup(w._vc_jobs.clear)

    # helpers --------------------------------------------------------------
    def conn(self, cancel=False, windows=False):
        c = FakeConn(log=self.log)
        c.on("SELECT cancel_requested FROM changes", [{"cancel_requested": cancel}])
        c.on("pkg_manager='wua'", [{"?column?": 1}] if windows else [])
        c.on("SELECT pkg_manager FROM hosts", [{"pkg_manager": "wua" if windows else "dnf"}])
        c.on("FROM host_applicability", [{"package_name": "openssl", "fixed_evr": "1:3.0.7-27.el9", "advisory_id": "RHSA-2026:1"}])
        return c

    @staticmethod
    def change(run_before=None, cancel=False, **params):
        p = {"reboot": "if_required", "snapshot": "none"}
        p.update(params)
        return {"id": "c1", "number": 42, "kind": "patch", "params": p, "run_before": run_before,
                "max_parallel": 2, "cancel_requested": cancel}

    @staticmethod
    def target(state, **more):
        t = {"target_key": "h1", "host_id": "00000000-0000-0000-0000-000000000001", "label": "srv1", "state": state,
             "step_started_at": datetime.now(UTC) - timedelta(minutes=5), "current_command": None,
             "snapshot_moref": None, "vcenter": "vc1", "vm_moref": "vm-1", "detail": {}}
        t.update(more)
        return t

    def completed(self, conn, ok=True, result=None, verb="run_precheck"):
        conn.on("FROM agent_commands WHERE id", [{"verb": verb, "claimed_at": datetime.now(UTC) - timedelta(minutes=3),
                                                  "completed_at": datetime.now(UTC), "ok": ok, "result": result or {},
                                                  "created_at": datetime.now(UTC) - timedelta(minutes=4), "withdrawn": False}])

    def state(self, key="h1"):
        return self.targets.get(key, {}).get("state")

    def verbs(self):
        return [v for _, v, _ in self.queued]


NOW = datetime.now(UTC)
CLOSED = NOW - timedelta(hours=5)          # the window closed five hours ago
OPEN = NOW + timedelta(hours=2)


class W1RestartAfterWindow(JobTest):
    def test_restart_held_rules(self):
        inside = (CLOSED - timedelta(hours=1)).isoformat()
        after = (CLOSED + timedelta(hours=1)).isoformat()
        self.assertTrue(w.restart_held(self.change(CLOSED), "reboot"))
        self.assertFalse(w.restart_held(self.change(OPEN), "reboot"))
        self.assertFalse(w.restart_held(self.change(None), "reboot"))
        self.assertTrue(w.restart_held(self.change(CLOSED, reboot_at=inside), "reboot_wait"))
        # a restart the job deliberately set for after its window keeps its time
        self.assertFalse(w.restart_held(self.change(CLOSED, reboot_at=after), "reboot_wait"))
        self.assertFalse(w.restart_held(self.change(OPEN, reboot_at=inside), "reboot_wait"))
        self.assertFalse(w.restart_held(self.change(CLOSED), "postcheck"))

    def test_late_install_with_restart_time_is_held(self):
        # window 22:00-04:00, restart at 03:00, the install finished at 09:30
        ch = self.change(CLOSED, reboot_at=(CLOSED - timedelta(hours=1)).isoformat())
        c = self.conn()
        self.completed(c, result={"reboot_required": True}, verb="install_packages")
        w._advance(c, ch, self.target("install", current_command="cmd-x"))
        self.assertEqual(self.state(), "postcheck")
        self.assertEqual(self.verbs(), ["run_postcheck"])
        self.assertTrue(self.targets["h1"]["detail"].get("restart_held"))
        self.assertTrue(any("restart held: the install finished after" in m for *_, m in self.events))

    def test_install_in_window_waits_for_restart_time(self):
        ch = self.change(OPEN, reboot_at=(NOW + timedelta(hours=1)).isoformat())
        c = self.conn()
        self.completed(c, result={"reboot_required": True}, verb="install_packages")
        w._advance(c, ch, self.target("install", current_command="cmd-x"))
        self.assertEqual(self.state(), "reboot_wait")

    def test_waiting_server_not_restarted_after_window(self):
        ch = self.change(CLOSED, reboot_at=(CLOSED - timedelta(hours=1)).isoformat())
        c = self.conn()
        c.on("count(*) AS n FROM change_targets", [{"n": 0}])
        w._advance(c, ch, self.target("reboot_wait"))
        self.assertEqual(self.state(), "postcheck")
        self.assertNotIn("reboot_host", self.verbs())
        self.assertTrue(self.targets["h1"]["detail"].get("restart_held"))

    def test_waiting_server_restarts_in_window(self):
        ch = self.change(OPEN, reboot_at=(NOW - timedelta(minutes=1)).isoformat())
        c = self.conn()
        c.on("count(*) AS n FROM change_targets", [{"n": 0}])
        c.on("SELECT boot_time FROM hosts", [{"boot_time": NOW - timedelta(days=3)}])
        w._advance(c, ch, self.target("reboot_wait"))
        self.assertEqual(self.state(), "reboot")
        self.assertEqual(self.verbs(), ["reboot_host"])

    def test_deliberate_restart_after_window_keeps_its_time(self):
        ch = self.change(CLOSED, reboot_at=(NOW - timedelta(minutes=1)).isoformat())
        c = self.conn()
        c.on("count(*) AS n FROM change_targets", [{"n": 0}])
        w._advance(c, ch, self.target("reboot_wait"))
        self.assertEqual(self.state(), "reboot")

    def test_immediate_restart_hold_unchanged(self):
        c = self.conn()
        self.completed(c, result={"reboot_required": True}, verb="install_packages")
        w._advance(c, self.change(CLOSED), self.target("install", current_command="cmd-x"))
        self.assertEqual(self.state(), "postcheck")
        self.assertTrue(any("restart held: the install finished after the job's window closed" in m
                            for *_, m in self.events))


class W3CancelReRead(JobTest):
    def test_cancel_seen_before_install_after_precheck(self):
        c = self.conn(cancel=True)                 # cancelled after the tick read the change
        self.completed(c)
        ch = self.change(OPEN)
        w._advance(c, ch, self.target("precheck", current_command="cmd-x"))
        self.assertEqual(self.state(), "cancelled")
        self.assertEqual(self.queued, [])
        self.assertTrue(ch["cancel_requested"])   # the rest of the tick sees it too

    def test_cancel_seen_before_snapshot(self):
        c = self.conn(cancel=True)
        w._enter(c, self.change(OPEN, snapshot="keep"), self.target("precheck"), "snapshot")
        self.assertEqual(self.state(), "cancelled")
        self.assertEqual(w._vc_jobs, {})

    def test_cancel_during_snapshot_stops_before_install(self):
        c = self.conn(cancel=True)
        job = w._VcJob()
        job.result = {"snapshot_moref": "snapshot-9", "snapshot_name": "PATCH-01 CHG-000042", "vm": "srv1"}
        job.done.set()
        w._vc_jobs[("snapshot", "c1", "h1")] = job
        w._advance(c, self.change(OPEN, snapshot="keep"), self.target("snapshot"))
        self.assertEqual(self.targets["h1"]["snapshot_moref"], "snapshot-9")
        self.assertEqual(self.state(), "cancelled")
        self.assertNotIn("install_packages", self.verbs())
        self.assertTrue(any("snapshot-9 was kept" in m for *_, m in self.events))

    def test_no_cancel_install_queued(self):
        c = self.conn(cancel=False)
        w._enter(c, self.change(OPEN), self.target("precheck"), "install")
        self.assertEqual(self.verbs(), ["install_packages"])


class W4VcenterInBackground(JobTest):
    def test_snapshot_runs_in_background_and_is_recorded(self):
        gate, started = threading.Event(), threading.Event()

        def slow_snapshot(vc, moref, ref):
            started.set()
            gate.wait(5)
            return {"snapshot_moref": "snapshot-7", "snapshot_name": "PATCH-01 " + ref, "vm": "srv1"}

        c = self.conn()
        c.on("FROM vm_inventory v", [{"vcenter": "vc1", "moref": "vm-1", "name": "srv1", "power_state": "poweredOn"}])
        ch = self.change(OPEN, snapshot="keep")
        with mock.patch.object(vmware, "snapshot_for_patch", slow_snapshot):
            w._enter(c, ch, self.target("precheck"), "snapshot")
            self.assertTrue(started.wait(5))
            self.assertIn(("commit",), self.log)                  # nothing held open while vCenter works
            t = self.target("snapshot")
            w._advance(c, ch, dict(t))                            # still working: returns at once
            self.assertEqual(self.state(), "snapshot")
            self.assertEqual(self.queued, [])
            gate.set()
            w._vc_jobs[("snapshot", "c1", "h1")].done.wait(5)
            w._advance(c, ch, dict(t))
        self.assertEqual(self.targets["h1"]["snapshot_moref"], "snapshot-7")
        self.assertEqual(self.verbs(), ["install_packages"])
        i_rec = self.log.index(("set", "h1", {"snapshot_moref": "snapshot-7"}))
        self.assertEqual(self.log[i_rec + 1], ("commit",))       # recorded at once

    def test_snapshot_failure_keeps_unverified_id(self):
        err = vmware.SnapshotNotVerified("not in the list")
        err.snapshot_moref = "snapshot-3"
        job = w._VcJob()
        job.error = err
        job.done.set()
        w._vc_jobs[("snapshot", "c1", "h1")] = job
        w._advance(self.conn(), self.change(OPEN, snapshot="keep"), self.target("snapshot"))
        self.assertEqual(self.state(), "failed")
        self.assertEqual(self.targets["h1"]["snapshot_moref"], "snapshot-3")

    def test_snapshot_after_restart_reported_when_stuck(self):
        old = self.target("snapshot", step_started_at=NOW - timedelta(minutes=50))
        w._advance(self.conn(), self.change(OPEN, snapshot="keep"), old)
        self.assertEqual(self.state(), "failed")

    def test_cleanup_commits_before_vcenter_and_records_at_once(self):
        seen = []

        def remove(vc, moref, snap, label):
            seen.append(list(self.log))
            return {"vm": "srv1", "removed": label}

        c = self.conn()
        ch = self.change(OPEN, snapshot="remove_on_success")
        with mock.patch.object(vmware, "remove_snapshot", remove):
            w._enter(c, ch, self.target("inventory", snapshot_moref="snapshot-5"), "snapshot_cleanup")
            w._vc_jobs[("cleanup", "c1", "h1")].done.wait(5)
        self.assertEqual(seen[0][-1], ("commit",))             # the step was committed before vCenter was asked
        self.assertEqual(self.state(), "snapshot_cleanup")
        w._advance(c, ch, self.target("snapshot_cleanup", snapshot_moref="snapshot-5"))
        i = self.log.index(("set", "h1", {"snapshot_moref": None}))
        self.assertIn(("commit",), self.log[i:i + 3])            # removal recorded and committed at once
        self.assertEqual(self.state(), "done")
        self.assertTrue(any(s == "snapshot_removed" and ok for _, s, ok, _ in self.events))

    def test_cleanup_failure_is_a_warning(self):
        job = w._VcJob()
        job.error = RuntimeError("vCenter said no")
        job.done.set()
        w._vc_jobs[("cleanup", "c1", "h1")] = job
        w._advance(self.conn(), self.change(OPEN, snapshot="remove_on_success"),
                   self.target("snapshot_cleanup", snapshot_moref="snapshot-5"))
        self.assertEqual(self.state(), "done_with_warnings")

    def test_cleanup_after_restart_uses_inventory(self):
        start = NOW - timedelta(minutes=50)
        c = self.conn()
        c.on("FROM vm_inventory WHERE vcenter", [{"snapshots": [{"moref": "snapshot-1"}], "synced_at": NOW}])
        t = self.target("snapshot_cleanup", snapshot_moref="snapshot-5", step_started_at=start)
        w._advance(c, self.change(OPEN, snapshot="remove_on_success"), dict(t))
        self.assertEqual(self.state(), "done")                   # gone from the VM: no false warning
        self.assertIsNone(self.targets["h1"]["snapshot_moref"])
        # still within the time a removal takes: waits
        self.targets.clear()
        w._advance(c, self.change(OPEN, snapshot="remove_on_success"),
                   dict(t, step_started_at=NOW - timedelta(minutes=5)))
        self.assertIsNone(self.state())

    def test_vm_action_in_background(self):
        gate = threading.Event()

        def action(vc, moref, kind, params):
            gate.wait(5)
            return {"vm": "srv1", "power": "on"}

        rows = {"state": "queued"}
        c = FakeConn(log=self.log)
        c.on("state='vm_action'", lambda a: [dict(target_key="h1", vcenter="vc1", vm_moref="vm-1", label="srv1",
                                                   state="vm_action", step_started_at=NOW)] if rows["state"] == "vm_action" else [])
        c.on("state='queued' ORDER BY label", lambda a: [dict(target_key="h1", vcenter="vc1", vm_moref="vm-1",
                                                               label="srv1", state="queued")] if rows["state"] == "queued" else [])
        ch = {"id": "c2", "number": 43, "kind": "vm_power_on", "params": {}, "cancel_requested": False}
        synced = []
        with mock.patch.object(vmware, "vm_action", action), mock.patch.object(vmware, "sync", lambda only=None: synced.append(only)):
            w.run_vm(c, ch)
            rows["state"] = self.targets["h1"]["state"]
            self.assertEqual(rows["state"], "vm_action")
            w.run_vm(c, ch)                                      # still running: nothing else started
            self.assertEqual(self.state(), "vm_action")
            gate.set()
            w._vc_jobs[("vm", "c2", "h1")].done.wait(5)
            w.run_vm(c, ch)
            w._vc_jobs[("sync", "vc1")].done.wait(5)
        self.assertEqual(self.state(), "done")
        self.assertEqual(synced, ["vc1"])

    def test_background_job_never_blocks_caller(self):
        gate = threading.Event()
        job = w._vc_start(("x", "1"), gate.wait, 5)
        self.assertFalse(job.done.is_set())
        self.assertIs(w._vc_start(("x", "1"), gate.wait, 5), job)     # never twice at once
        self.assertIsNone(w._vc_finished(("x", "1")))
        gate.set()
        job.done.wait(5)
        self.assertIs(w._vc_finished(("x", "1")), job)
        self.assertNotIn(("x", "1"), w._vc_jobs)


class W6WindowClosedAfterPrecheck(JobTest):
    def test_precheck_done_after_window_is_skipped(self):
        c = self.conn()
        self.completed(c)
        w._advance(c, self.change(CLOSED), self.target("precheck", current_command="cmd-x"))
        self.assertEqual(self.state(), "skipped")
        self.assertEqual(self.queued, [])
        self.assertTrue(any("window closed before install" in m for *_, m in self.events))

    def test_precheck_done_in_window_goes_on(self):
        c = self.conn()
        self.completed(c)
        w._advance(c, self.change(OPEN), self.target("precheck", current_command="cmd-x"))
        self.assertEqual(self.state(), "install")

    def test_skipped_counts_as_not_patched(self):
        self.assertEqual(w.change_outcome(["done", "skipped"]), "partially_succeeded")


class W7RebootOnServersClock(JobTest):
    def test_server_clock_behind(self):
        asked = NOW - timedelta(minutes=5)
        before = (NOW - timedelta(days=10, hours=2)).isoformat()      # its clock runs 2 h behind
        new_boot = NOW - timedelta(hours=2, minutes=3)                # booted 2 min ago, by its own clock
        self.assertTrue(w.came_back(new_boot, NOW, asked, {"boot_time_before": before}))
        self.assertFalse(new_boot > asked)                            # what the old check would have said

    def test_not_rebooted_yet(self):
        asked = NOW - timedelta(minutes=5)
        before = NOW - timedelta(days=10)
        self.assertFalse(w.came_back(before, NOW, asked, {"boot_time_before": before.isoformat()}))
        # a second's jitter in the reported boot time is not a restart
        self.assertFalse(w.came_back(before + timedelta(seconds=1), NOW, asked, {"boot_time_before": before.isoformat()}))
        # rebooted, but no check-in since the request yet
        self.assertFalse(w.came_back(NOW, asked - timedelta(seconds=1), asked, {"boot_time_before": before.isoformat()}))

    def test_legacy_target_without_stored_boot_time(self):
        asked = NOW - timedelta(minutes=5)
        self.assertTrue(w.came_back(NOW - timedelta(minutes=1), NOW, asked, {}))
        self.assertFalse(w.came_back(NOW - timedelta(hours=1), NOW, asked, {}))

    def test_reboot_stores_boot_time(self):
        c = self.conn()
        bt = NOW - timedelta(days=4)
        c.on("SELECT boot_time FROM hosts", [{"boot_time": bt}])
        w._enter(c, self.change(OPEN), self.target("install"), "reboot")
        self.assertEqual(self.targets["h1"]["detail"]["boot_time_before"], bt.isoformat())
        self.assertEqual(self.verbs(), ["reboot_host"])

    def test_wait_boot_uses_it(self):
        asked = NOW - timedelta(minutes=5)
        c = self.conn()
        c.on("SELECT boot_time, last_checkin FROM hosts", [{"boot_time": NOW - timedelta(hours=3), "last_checkin": NOW}])
        t = self.target("wait_boot", detail={"reboot_requested_at": asked.isoformat(),
                                             "boot_time_before": (NOW - timedelta(days=9)).isoformat()})
        w._advance(c, self.change(OPEN), t)
        self.assertEqual(self.state(), "postcheck")


class W9AgentUpdatingOneQuery(JobTest):
    def queued_rows(self, n):
        return [dict(target_key=f"h{i}", host_id=f"00000000-0000-0000-0000-{i:012d}", label=f"srv{i}", state="queued",
                     step_started_at=None, current_command=None, snapshot_moref=None, vcenter=None, vm_moref=None, detail={})
                for i in range(n)]

    def test_one_query_for_all_queued(self):
        rows = self.queued_rows(200)
        c = self.conn()
        c.on("FROM change_targets WHERE change_id=%s ORDER BY label", rows)
        c.on("count(*) AS n FROM change_targets", [{"n": 0}])
        c.on("c.kind = 'agent_update'", [{"host_id": rows[0]["host_id"]}])
        ch = self.change(OPEN)
        ch["max_parallel"] = 2
        w.run_patch(c, ch)
        self.assertEqual(sum(1 for s, _ in c.sql if "agent_update" in s), 1)
        self.assertEqual(sorted(self.targets), ["h1", "h2"])          # h0's agent is being replaced
        self.assertEqual({v["state"] for v in self.targets.values()}, {"precheck"})

    def test_no_query_without_a_free_slot(self):
        c = self.conn()
        c.on("FROM change_targets WHERE change_id=%s ORDER BY label", self.queued_rows(50))
        c.on("count(*) AS n FROM change_targets", [{"n": 2}])
        ch = self.change(OPEN)
        ch["max_parallel"] = 2
        w.run_patch(c, ch)
        self.assertFalse(any("agent_update" in s for s, _ in c.sql))
        self.assertEqual(self.targets, {})


class SequenceUnchanged(unittest.TestCase):
    def test_next_patch_state(self):
        p = {"snapshot": "remove_on_success", "reboot": "if_required"}
        self.assertEqual(w.next_patch_state("precheck", p, {}, False), "snapshot")
        self.assertEqual(w.next_patch_state("install", p, {"reboot_required": True}, True), "reboot")
        self.assertEqual(w.next_patch_state("install", dict(p, reboot_at="x"), {"reboot_required": True}, True), "reboot_wait")
        self.assertEqual(w.next_patch_state("inventory", p, {}, True), "snapshot_cleanup")


if __name__ == "__main__":
    unittest.main()
