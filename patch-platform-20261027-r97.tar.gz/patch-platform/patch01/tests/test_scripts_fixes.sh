#!/usr/bin/env bash
# Tests for the install/operations script fixes, run in a temporary folder with
# stubbed commands (docker, curl, openssl s_client, sleep). Nothing outside the
# temporary folder is touched; no container, database or service is needed.
#   ./tests/test_scripts_fixes.sh
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
S="$HERE/../scripts"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
N=0; F=0
ok()  { N=$((N+1)); printf '  ok    %s\n' "$1"; }
bad() { N=$((N+1)); F=$((F+1)); printf '  FAIL  %s\n' "$1"; }
check() { if eval "$2"; then ok "$1"; else bad "$1"; fi; }
# fn <file> <name>: the text of a top-level shell function
fn() { awk -v n="$2" '$0 ~ "^"n"\\(\\) *\\{" {f=1} f {print} f && /^}/ {exit}' "$1"; }
# between <file> <start regex> <end regex>: lines from start up to and including end
between() { awk -v a="$2" -v b="$3" '$0 ~ a {f=1} f {print} f && $0 ~ b {exit}' "$1"; }

# ---------------------------------------------------------------------------
echo "patch01-cert-apply.sh: symlinks planted in the staging folder (I1)"
if [[ $EUID -ne 0 ]] || ! command -v openssl >/dev/null || ! command -v flock >/dev/null; then
  echo "  (skipped: needs root, openssl and flock)"
else
  REAL_OPENSSL="$(command -v openssl)"
  mkdir -p "$T/stub" "$T/p/certs" "$T/p/certs-staging"
  cat >"$T/stub/openssl" <<EOF
#!/bin/bash
# s_client: "nginx" serves whatever is installed in certs/
if [[ "\$1" == s_client ]]; then cat "\$TEST_CERTS/patch01.crt"; exit 0; fi
exec "$REAL_OPENSSL" "\$@"
EOF
  printf '#!/bin/bash\nexit 0\n' >"$T/stub/docker"; printf '#!/bin/bash\nexit 0\n' >"$T/stub/sleep"
  chmod +x "$T/stub/"*
  mkcert() { "$REAL_OPENSSL" req -x509 -newkey rsa:2048 -nodes -subj "/CN=$1" -days 3 -keyout "$2.key" -out "$2.crt" >/dev/null 2>&1; }
  pin() { "$REAL_OPENSSL" x509 -in "$1" -outform der | sha256sum | cut -d' ' -f1; }
  mkcert old "$T/p/certs/patch01"; chmod 0640 "$T/p/certs/patch01.key"
  mkcert new "$T/new"; mkcert other "$T/other"
  ST="$T/p/certs-staging"
  printf 'precious\n' >"$T/victim"; chmod 0600 "$T/victim"
  runapply() { PATH="$T/stub:$PATH" PATCH_BASE="$T/p" PATCH01_CERT_RUN="$T/run" PATCH01_CERT_LOG="$T/cert.log" \
               TEST_CERTS="$T/p/certs" bash "$S/patch01-cert-apply.sh" >/dev/null 2>&1; }
  ID=0123456789abcdef
  request() { printf '{"id":"%s","action":"install","dir":"pending-%s","pin":"%s","by":"t"}' "$ID" "$ID" "$1" >"$ST/request.json"; }

  # Attack 1: the old lock and temp names and result.json point at a root file;
  # the key in the upload is a symlink to a key elsewhere (whose cert is uploaded)
  ln -s "$T/victim" "$ST/.lock"; ln -s "$T/victim" "$ST/.result.tmp"; ln -s "$T/victim" "$ST/result.json"
  mkdir "$ST/pending-$ID"; cp "$T/other.crt" "$ST/pending-$ID/patch01.crt"; ln -s "$T/other.key" "$ST/pending-$ID/patch01.key"
  request "$(pin "$T/other.crt")"
  runapply
  check "victim file untouched (lock, temp and result symlinks)" '[[ "$(cat "$T/victim")" == precious && "$(stat -c %a "$T/victim")" == 600 ]]'
  check "result.json replaced by a regular file, not followed" '[[ -f "$ST/result.json" && ! -L "$ST/result.json" ]]'
  check "symlinked key refused" 'grep -q "\"failed\"" "$ST/result.json"'
  check "certificate not installed" '[[ "$(pin "$T/p/certs/patch01.crt")" != "$(pin "$T/other.crt")" ]]'
  check "result.json is root:0 0640" '[[ "$(stat -c %a:%g "$ST/result.json")" == 640:0 ]]'
  check "request removed" '[[ ! -e "$ST/request.json" ]]'
  check "lock kept in the root-only folder" '[[ -f "$T/run/lock" && "$(stat -c %a "$T/run")" == 700 ]]'

  # Attack 2: request.json is itself a symlink
  ln -s "$T/victim" "$ST/request.json"; runapply
  check "symlinked request ignored and removed, victim untouched" '[[ ! -L "$ST/request.json" && "$(cat "$T/victim")" == precious ]]'

  # Attack 3: the upload folder is a symlink to a folder outside staging
  rm -rf "$ST/pending-$ID"; mkdir "$T/elsewhere"; cp "$T/other.crt" "$T/elsewhere/patch01.crt"; cp "$T/other.key" "$T/elsewhere/patch01.key"
  ln -s "$T/elsewhere" "$ST/pending-$ID"; request "$(pin "$T/other.crt")"; runapply
  check "symlinked upload folder refused" 'grep -q "\"failed\"" "$ST/result.json" && [[ "$(pin "$T/p/certs/patch01.crt")" != "$(pin "$T/other.crt")" ]]'
  check "files behind the symlinked folder untouched" '[[ -f "$T/elsewhere/patch01.key" ]]'
  rm -f "$ST/pending-$ID"

  # Normal install still works
  mkdir "$ST/pending-$ID"; cp "$T/new.crt" "$T/new.key" "$ST/pending-$ID/"
  mv "$ST/pending-$ID/new.crt" "$ST/pending-$ID/patch01.crt"; mv "$ST/pending-$ID/new.key" "$ST/pending-$ID/patch01.key"
  request "$(pin "$T/new.crt")"; runapply
  check "genuine upload installed" '[[ "$(pin "$T/p/certs/patch01.crt")" == "$(pin "$T/new.crt")" ]] && grep -q "\"ok\"" "$ST/result.json"'
  check "key installed root:0 0640" '[[ "$(stat -c %a:%g "$T/p/certs/patch01.key")" == 640:0 ]]'
  check "upload (private key) removed from staging" '[[ ! -e "$ST/pending-$ID" ]]'
  check "no work copies left behind" '[[ ! -e "$T/run/work" ]]'

  # phase3b's .helper-ready never follows a planted symlink
  rm -f "$ST/.helper-ready"; ln -s "$T/victim" "$ST/.helper-ready"
  ( STAGE="$ST"; warn() { :; }
    eval "$(between "$S/phase3b-api.sh" '^  HR="\$STAGE/.helper-ready"' 'Could not create \$HR')" )
  check "phase3b: .helper-ready made as a plain file, victim untouched" \
    '[[ -f "$ST/.helper-ready" && ! -L "$ST/.helper-ready" && "$(cat "$T/victim")" == precious && "$(stat -c %a "$T/victim")" == 600 ]]'
fi

# ---------------------------------------------------------------------------
echo "phase0-bootstrap.sh: re-run keeps data/ ownership (I2), env record (I2), os-release (I12), rollback on die (I3)"
B="$S/phase0-bootstrap.sh"
P0="$T/p0"; mkdir -p "$P0/data/postgres" "$P0/data/redis"
chmod 0700 "$P0/data/postgres"; chmod 0755 "$P0/data/redis"
OWN_BEFORE="$(stat -c %u:%g:%a "$P0/data/postgres")"
if [[ $EUID -eq 0 ]]; then chown 999:999 "$P0/data/postgres"; chown 70:70 "$P0/data/redis"; OWN_BEFORE="$(stat -c %u:%g:%a "$P0/data/postgres")"; fi
REDIS_BEFORE="$(stat -c %u:%g:%a "$P0/data/redis")"
DIRBLOCK="$(between "$B" '^NEW_DIRS=\(\)' '^say "Directory tree')"
[[ -n "$DIRBLOCK" ]] || bad "directory block not found in phase0"
( set -Eeuo pipefail
  PATCH_BASE="$P0"; DRY_RUN=no; MOUNTED_PATHS=()
  DIRS=("$P0" "$P0/config" "$P0/data" "$P0/data/postgres" "$P0/data/redis" "$P0/data/pulp" "$P0/secrets" "$P0/certs")
  run() { "$@"; }; die() { echo "DIE $*"; exit 1; }; say() { :; }
  chown() { [[ $EUID -eq 0 ]] && command chown "$@" || true; }
  eval "$DIRBLOCK" ) || bad "directory block failed"
check "existing data/postgres keeps owner and mode" '[[ "$(stat -c %u:%g:%a "$P0/data/postgres")" == "$OWN_BEFORE" ]]'
check "existing data/redis keeps owner and mode" '[[ "$(stat -c %u:%g:%a "$P0/data/redis")" == "$REDIS_BEFORE" ]]'
check "new data/pulp made 0750" '[[ "$(stat -c %a "$P0/data/pulp")" == 750 ]]'
check "new secrets made 0700" '[[ "$(stat -c %a "$P0/secrets")" == 700 ]]'

ENVBLOCK="$(between "$B" '^CONF="\$ETC_DIR/phase0.env"' '^  chmod 0600 "\$CONF"')"
CONFGET="$(fn "$B" conf_get)"
[[ -n "$ENVBLOCK" && -n "$CONFGET" ]] || bad "env block not found in phase0"
mkdir -p "$T/etc"
write_env() {   # STORAGE_MODE STORAGE_VG NEW_VG VOLS PVS
  ( set -Eeuo pipefail
    eval "$CONFGET"; log() { :; }
    ETC_DIR="$T/etc"; DRY_RUN=no; VERSION="0.9.0"; ROLE=PATCH-01; OS_ID=rhel; OS_VER=9.4; ARCH=x86_64
    PATCH_BASE=/patch; STORAGE_MODE="$1"; STORAGE_LAYOUT=split; STORAGE_VG="$2"; NEW_VG="$3"
    read -r -a VOL_TABLE <<<"$4"; read -r -a NEW_PVS <<<"$5"; FSTAB_BACKUP=""
    FS_SOURCE=x; FS_TYPE=xfs; FS_TARGET=/patch; PODMAN_GRAPHROOT=""; EXPOSED_COUNT=0
    eval "$ENVBLOCK
fi" )
}
write_env newvg vg_patch vg_patch "lv_patch::100" "/dev/sdb"
check "first run records the VG it created" 'grep -qx "PP_STORAGE_VG=\"vg_patch\"" "$T/etc/phase0.env" && grep -qx "PP_VG_CREATED=\"yes\"" "$T/etc/phase0.env"'
write_env skip "" "" "" ""
check "re-run with storage skipped keeps PP_STORAGE_VG" 'grep -qx "PP_STORAGE_VG=\"vg_patch\"" "$T/etc/phase0.env"'
check "re-run keeps PP_VG_CREATED=yes, PVs and volumes" 'grep -qx "PP_VG_CREATED=\"yes\"" "$T/etc/phase0.env" && grep -qx "PP_PVS=\"/dev/sdb\"" "$T/etc/phase0.env" && grep -qx "PP_STORAGE_VOLUMES=\"lv_patch::100\"" "$T/etc/phase0.env"'
check "values quoted; file still parses as shell" '( set -e; . "$T/etc/phase0.env"; [[ "$PP_PHASE0_VERSION" == 0.9.0 && "$PP_OS_VERSION" == 9.4 ]] )'
check "conf_get reads quoted values" '[[ "$(eval "$CONFGET"; conf_get PP_STORAGE_VG "$T/etc/phase0.env")" == vg_patch ]]'

# os-release: read in a subshell; VERSION stays the script's own
printf 'NAME="Red Hat Enterprise Linux"\nVERSION="9.4 (Plow)"\nID="rhel"\nID_LIKE="fedora"\nVERSION_ID="9.4"\nPRETTY_NAME="Red Hat Enterprise Linux 9.4 (Plow)"\n' >"$T/os-release"
OSBLOCK="$(between "$B" '^eval "\$\( # shellcheck' 'done \)"$' | sed "s#/etc/os-release#$T/os-release#")"
OUT="$( set -Eeuo pipefail; VERSION=0.9.0; eval "$OSBLOCK"; echo "$VERSION|$OSREL_ID|$OSREL_VERSION_ID|$OSREL_ID_LIKE|${NAME:-unset}" )"
check "os-release does not overwrite VERSION (got $OUT)" '[[ "$OUT" == "0.9.0|rhel|9.4|fedora|unset" ]]'

# rollback runs when storage setup ends in die (exit), and not after it is committed
TRAPLINE="$(grep -m1 "^  trap 'rc=\$?; if \[\[ \"\$STORAGE_IN_PROGRESS\" == yes" "$B")"
[[ -n "$TRAPLINE" ]] || bad "rollback trap not found in phase0"
rb() { bash -c "set -Eeuo pipefail
  trap 'exit 1' ERR
  rollback_storage() { echo rolled >>'$T/rb'; }
  die() { exit 1; }
  STORAGE_IN_PROGRESS=yes
  $TRAPLINE
  $1" >/dev/null 2>&1; }
rm -f "$T/rb"; rb 'die "mkfs failed"'
check "die during storage setup rolls back" '[[ "$(cat "$T/rb" 2>/dev/null)" == rolled ]]'
rm -f "$T/rb"; rb 'false'
check "a failing command during storage setup rolls back (once)" '[[ "$(cat "$T/rb" 2>/dev/null)" == rolled ]]'
rm -f "$T/rb"; rb 'STORAGE_IN_PROGRESS=no; trap - EXIT; die "later failure"'
check "after commit, a later die does not roll back" '[[ ! -e "$T/rb" ]]'
rm -f "$T/rb"; rb 'true'
check "a successful run does not roll back" '[[ ! -e "$T/rb" ]]'

# ---------------------------------------------------------------------------
echo "phase3a-schema.sh --dry-run on a migration with nothing to list (I10)"
mkdir -p "$T/sql"; printf -- '-- only data\nINSERT INTO x VALUES (1);\n' >"$T/sql/900-data.sql"
DRY="$(between "$S/phase3a-schema.sh" '^  say "Objects created:"' '^  done$')"
OUT="$( set -Eeuo pipefail; say() { echo "$*"; }; MIGRATIONS=("$T/sql/900-data.sql"); eval "$DRY"; echo END )"
check "dry-run carries on past a file with no CREATE" '[[ "$OUT" == *END ]]'

# ---------------------------------------------------------------------------
echo "phase3b-api.sh refuses to deploy on a schema older than sql/ (review item 2)"
VCHK="$(between "$S/phase3b-api.sh" '^NEWEST_MIG="\$\(ls' '^fi$')"
[[ -n "$VCHK" ]] || bad "schema version gate not found in phase3b"
mkdir -p "$T/b/sql"; touch "$T/b/sql/001-schema.sql" "$T/b/sql/009-x.sql" "$T/b/sql/051-y.sql"
gate() {   # gate <db version or ""> <DRY_RUN> : rc
  ( set -Eeuo pipefail; SRC_DIR="$T/b"; PATCHDB_NAME=patchdb; DRY_RUN="$2"; BUILD_ONLY=no
    docker() { [[ -n "$DBV" ]] && echo "$DBV" || return 1; }; DBV="$1"
    say() { :; }; warn() { :; }; die() { echo "$*" >"$T/gate.msg"; exit 1; }
    eval "$VCHK"; exit 0 ) >/dev/null 2>&1; }
gate 50 no; rc=$?
check "schema 50 < migration 51: refused" '[[ $rc == 1 ]] && grep -q "run ./scripts/phase3a-schema.sh first" "$T/gate.msg"'
gate 51 no; rc=$?; check "schema at 51: deploys" '[[ $rc == 0 ]]'
gate 52 no; rc=$?; check "schema newer than the bundle: deploys" '[[ $rc == 0 ]]'
gate "" no; rc=$?; check "schema version unreadable: refused" '[[ $rc == 1 ]]'
gate 50 yes; rc=$?; check "--dry-run only warns" '[[ $rc == 0 ]]'

# ---------------------------------------------------------------------------
echo "phase1c-pulp.sh: admin password on stdin, not argv (O32)"
SAP="$(fn "$S/phase1c-pulp.sh" set_admin_password)"
OUT="$( docker() { printf '%s\n' "$@" >"$T/argv"; cat >"$T/stdin"; }; eval "$SAP"; set_admin_password 'S3cret-pw' )"
check "password not in docker's arguments" '! grep -q S3cret-pw "$T/argv"'
check "password on stdin" '[[ "$(cat "$T/stdin")" == S3cret-pw ]]'
check "uses docker exec -i ... pulpcore-manager shell" 'grep -qx -- -i "$T/argv" && grep -qx shell "$T/argv"'

# ---------------------------------------------------------------------------
echo "lib-admin.sh: no proxy, and HTTP 000 not 000000 (I7, I15)"
mkdir -p "$T/curlstub"
cat >"$T/curlstub/curl" <<EOF
#!/bin/bash
printf '%s\n' "\$@" >"$T/curl.argv"; cat >"$T/curl.stdin"; printf 000; exit 7
EOF
chmod +x "$T/curlstub/curl"
OUT="$( PATH="$T/curlstub:$PATH"; source "$S/lib-admin.sh"; _ADMIN_USER=admin; _ADMIN_PW='pw"x'; _admin_probe )"
check "_admin_probe gives 000 when curl fails (got $OUT)" '[[ "$OUT" == 000 ]]'
check "admin_curl passes --noproxy *" 'grep -qx -- --noproxy "$T/curl.argv" && grep -qx "\*" "$T/curl.argv"'
check "admin password only on curl's stdin" '! grep -q "pw" "$T/curl.argv" && grep -q "pw" "$T/curl.stdin"'

# ---------------------------------------------------------------------------
echo "check-connectivity.sh: proxy credentials neither printed nor on argv (P13)"
MASK="$(fn "$S/check-connectivity.sh" mask_url)"; PCURL="$(fn "$S/check-connectivity.sh" pcurl)"
OUT="$( eval "$MASK"; mask_url 'http://bob:pa55@proxy.corp:8080/' )"
check "credentials masked (got $OUT)" '[[ "$OUT" == "http://***@proxy.corp:8080/" ]]'
OUT="$( eval "$MASK"; mask_url 'http://proxy.corp:8080' )"
check "URL without credentials unchanged" '[[ "$OUT" == "http://proxy.corp:8080" ]]'
( PATH="$T/curlstub:$PATH"; eval "$PCURL"; pcurl 'http://bob:pa55@proxy.corp:8080' -s https://example.invalid/ ) >/dev/null 2>&1
check "proxy not on curl's argv" '! grep -q pa55 "$T/curl.argv" && grep -qx -- -K "$T/curl.argv"'
check "proxy given as curl config on stdin" 'grep -qx "proxy = \"http://bob:pa55@proxy.corp:8080\"" "$T/curl.stdin"'

# ---------------------------------------------------------------------------
echo "phase8-hardening.sh --import-zip refuses an unverified zip (I14)"
IZ="$(fn "$S/phase8-hardening.sh" import_zip)"
printf 'zip' >"$T/scap-security-guide-0.1.76.zip"
iz() { ( HARDENING_DIR="$T/hd"; say() { :; }; warn() { :; }; die() { echo "DIE $*"; exit 1; }
         unpack() { echo UNPACKED; }; import_dir() { :; }; eval "$IZ"; import_zip "$@" ) 2>&1; }
OUT="$(iz "$T/scap-security-guide-0.1.76.zip" "" no)"
check "no .sha512: refused" '[[ "$OUT" == DIE* && "$OUT" != *UNPACKED* ]]'
OUT="$(iz "$T/scap-security-guide-0.1.76.zip" "" yes)"
check "no .sha512 with --unverified: imported" '[[ "$OUT" == *UNPACKED* ]]'
sha512sum "$T/scap-security-guide-0.1.76.zip" | awk '{print $1}' >"$T/scap-security-guide-0.1.76.zip.sha512"
OUT="$(iz "$T/scap-security-guide-0.1.76.zip" "" no)"
check "matching .sha512: imported" '[[ "$OUT" == *UNPACKED* ]]'

# ---------------------------------------------------------------------------
echo "patch01-start.sh / patch01-update.sh: boot runs wait for each other (O17)"
if command -v flock >/dev/null; then
  STARTLOCK="$(between "$S/patch01-start.sh" '^exec 8>"\$LOCK"' '^fi$')"
  lockrun() {   # lockrun <WAIT_LOCK>: rc of the start script's lock block
    bash -c "LOCK='$T/start.lock'; WAIT_LOCK=$1; say() { :; }; die() { exit 1; }
             $STARTLOCK
             exit 0" >/dev/null 2>&1; }
  flock "$T/start.lock" sleep 2 & HOLD=$!; sleep 0.3
  lockrun no; rc=$?
  check "manual start while another runs: stops at once" '[[ $rc == 1 ]]'
  t0=$SECONDS; lockrun yes; rc=$?
  check "boot start (--wait-lock): waits, then runs" '[[ $rc == 0 && $((SECONDS - t0)) -ge 1 ]]'
  wait "$HOLD" 2>/dev/null
  TL="$(fn "$S/patch01-update.sh" take_lock)"
  flock "$T/upd.lock" sleep 2 & HOLD=$!; sleep 0.3
  bash -c "say() { :; }; die() { exit 1; }; WAIT_LOCK=no; exec 8>'$T/upd.lock'; $TL; take_lock" >/dev/null 2>&1; rc=$?
  check "update without --wait-lock: refuses while locked" '[[ $rc == 1 ]]'
  bash -c "say() { :; }; die() { exit 1; }; WAIT_LOCK=yes; exec 8>'$T/upd.lock'; $TL; take_lock" >/dev/null 2>&1; rc=$?
  check "update with --wait-lock: waits for the lock" '[[ $rc == 0 ]]'
  wait "$HOLD" 2>/dev/null
fi
check "post-boot unit is ordered after patch01-start.service" 'grep -q "^After=docker.service network-online.target patch01-start.service$" "$S/patch01-update.sh"'
check "post-boot start waits for a running start" 'grep -q "\[\[ \"\$POST_BOOT\" == yes \]\] && sargs+=(--wait-lock)" "$S/patch01-update.sh"'
check "post-boot takes the update lock only after start_all" '[[ "$(grep -n "\[\[ \"\$POST_BOOT\" == yes \]\] || take_lock" "$S/patch01-update.sh" | wc -l)" == 1 ]]'
check "boot start's health check waits for the update lock" 'grep -q "\[\[ \"\$BOOT\" == yes \]\] && HC_ARGS=(--wait-lock)" "$S/patch01-start.sh"'

echo
echo "$((N - F))/$N passed"
(( F == 0 ))
