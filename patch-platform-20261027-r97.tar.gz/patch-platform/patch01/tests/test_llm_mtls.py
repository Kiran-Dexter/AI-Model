"""llm.py and AI-01 client certificates (ai01-harden.sh steps mtls / mtls-enforce).

Real TLS on 127.0.0.1 with certificates made by openssl for each run:
    cd patch01 && python3 -m unittest -v tests.test_llm_mtls
"""
import json
import os
import shutil
import ssl
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "api"))
from app import llm  # noqa: E402

KEY = "a" * 64


def sh(*args):
    subprocess.run(args, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        self.server.seen.append(bool(self.connection.getpeercert()))
        self._send(200 if self.path == "/health" else 404, {})

    def do_POST(self):
        self.server.seen.append(bool(self.connection.getpeercert()))
        self.rfile.read(int(self.headers.get("Content-Length", "0")))
        if self.headers.get("Authorization") != "Bearer " + KEY:
            return self._send(401, {"error": "bad key"})
        self._send(200, {"choices": [{"message": {"content": "ok"}}]})


class TLSServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, d, verify):
        super().__init__(("127.0.0.1", 0), Handler)
        self.seen = []
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(os.path.join(d, "srv.crt"), os.path.join(d, "srv.key"))
        if verify != ssl.CERT_NONE:
            ctx.load_verify_locations(os.path.join(d, "ca.crt"))
            ctx.verify_mode = verify
        self.ctx = ctx

    def get_request(self):
        sock, addr = self.socket.accept()
        return self.ctx.wrap_socket(sock, server_side=True, do_handshake_on_connect=False), addr

    def finish_request(self, request, client_address):
        try:
            request.do_handshake()
        except (ssl.SSLError, OSError):
            request.close()
            return
        super().finish_request(request, client_address)


class ClientCertTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        d = cls.d = tempfile.mkdtemp()
        sh("openssl", "req", "-x509", "-nodes", "-newkey", "rsa:2048", "-days", "2", "-subj", "/CN=ai01",
           "-addext", "subjectAltName=IP:127.0.0.1", "-keyout", f"{d}/srv.key", "-out", f"{d}/srv.crt")
        sh("openssl", "ecparam", "-name", "prime256v1", "-genkey", "-noout", "-out", f"{d}/ca.key")
        sh("openssl", "req", "-x509", "-new", "-key", f"{d}/ca.key", "-days", "2", "-subj", "/CN=client CA",
           "-addext", "basicConstraints=critical,CA:TRUE", "-out", f"{d}/ca.crt")
        sh("openssl", "ecparam", "-name", "prime256v1", "-genkey", "-noout", "-out", f"{d}/client.key")
        sh("openssl", "req", "-new", "-key", f"{d}/client.key", "-subj", "/CN=patch01-client", "-out", f"{d}/c.csr")
        with open(f"{d}/ext", "w") as fh:
            fh.write("extendedKeyUsage=clientAuth\n")
        sh("openssl", "x509", "-req", "-in", f"{d}/c.csr", "-CA", f"{d}/ca.crt", "-CAkey", f"{d}/ca.key",
           "-CAcreateserial", "-days", "2", "-extfile", f"{d}/ext", "-out", f"{d}/client.crt")

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.d)

    def start(self, verify):
        srv = TLSServer(self.d, verify)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        self.addCleanup(srv.server_close)
        self.addCleanup(srv.shutdown)
        llm.AI01_URL = "https://127.0.0.1:%d" % srv.server_address[1]
        llm.AI01_KEY = KEY
        llm.AI01_CA = os.path.join(self.d, "srv.crt")
        return srv

    def use_client_files(self, cert, key):
        llm.AI01_CLIENT_CERT = cert
        llm.AI01_CLIENT_KEY = key

    def with_cert(self):
        self.use_client_files(os.path.join(self.d, "client.crt"), os.path.join(self.d, "client.key"))

    def without_cert(self):
        self.use_client_files(os.path.join(self.d, "none.crt"), os.path.join(self.d, "none.key"))

    def test_no_client_files_works_as_before(self):
        srv = self.start(ssl.CERT_OPTIONAL)
        self.without_cert()
        h = llm.health()
        self.assertTrue(h["reachable"])
        self.assertTrue(h["tls_verified"])
        self.assertFalse(h["client_cert"])
        self.assertEqual(srv.seen, [False])

    def test_client_files_are_presented(self):
        srv = self.start(ssl.CERT_OPTIONAL)
        self.with_cert()
        h = llm.health()
        self.assertTrue(h["reachable"])
        self.assertTrue(h["client_cert"])
        self.assertEqual(srv.seen, [True])

    def test_enforced_without_files_fails(self):
        self.start(ssl.CERT_REQUIRED)
        self.without_cert()
        self.assertFalse(llm.health()["reachable"])

    def test_enforced_with_files_works_end_to_end(self):
        self.start(ssl.CERT_REQUIRED)
        self.with_cert()
        self.assertTrue(llm.health()["reachable"])
        p = llm.ping()
        self.assertTrue(p["ok"], p)
        self.assertTrue(p["client_cert"])

    def test_broken_key_is_reported_not_fatal(self):
        bad = os.path.join(self.d, "bad.key")
        with open(bad, "w") as fh:
            fh.write("not a key\n")
        srv = self.start(ssl.CERT_OPTIONAL)
        self.use_client_files(os.path.join(self.d, "client.crt"), bad)
        h = llm.health()
        self.assertTrue(h["reachable"], h)
        self.assertFalse(h["client_cert"])
        self.assertIn("client_cert_error", h)
        self.assertEqual(srv.seen, [False])

    def test_wrong_api_key(self):
        self.start(ssl.CERT_OPTIONAL)
        self.with_cert()
        llm.AI01_KEY = "b" * 64
        self.assertFalse(llm.ping()["ok"])

    def test_missing_pin_still_refuses(self):
        self.start(ssl.CERT_OPTIONAL)
        self.with_cert()
        llm.AI01_CA = os.path.join(self.d, "missing.crt")
        h = llm.health()
        self.assertFalse(h["reachable"])
        self.assertIn("certificate", h["error"])

    def test_minimum_tls_version(self):
        self.start(ssl.CERT_OPTIONAL)
        ctx, verified = llm._tls_context()
        self.assertTrue(verified)
        self.assertGreaterEqual(ctx.minimum_version, ssl.TLSVersion.TLSv1_2)


if __name__ == "__main__":
    unittest.main()
