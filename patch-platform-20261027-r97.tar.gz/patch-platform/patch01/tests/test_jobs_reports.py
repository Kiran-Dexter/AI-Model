"""Report fixes: installed patches read by period in SQL (W10), the lowest installed version by
version order (W11), and "Run now" on a due day counting as the scheduled run (W12). No PostgreSQL:
fake connections answer by SQL text.

    cd patch01 && python3 -m unittest -v tests.test_jobs_reports
"""
import os
import sys
import unittest
from datetime import datetime, timedelta, timezone
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "api"))

from app import installed_report as ir   # noqa: E402
from app import patch_reports as pr      # noqa: E402
from app import report_jobs as rj        # noqa: E402

UTC = timezone.utc


class Cur:
    def __init__(self, rows):
        self.rows = rows

    def fetchone(self):
        return self.rows[0] if self.rows else None

    def fetchall(self):
        return list(self.rows)


class FakeConn:
    def __init__(self):
        self.handlers, self.sql, self.commits = [], [], 0

    def on(self, text, rows):
        self.handlers.insert(0, (text, rows))

    def execute(self, sql, args=None):
        self.sql.append((sql, args))
        for text, rows in self.handlers:
            if text in sql:
                return Cur(rows(sql, args) if callable(rows) else rows)
        return Cur([])

    def commit(self):
        self.commits += 1

    def rollback(self):
        pass

    def transaction(self):
        import contextlib
        return contextlib.nullcontext()


LIN = "00000000-0000-0000-0000-00000000000a"
WIN = "00000000-0000-0000-0000-00000000000b"
NOW = datetime.now(UTC)


def lin_rows(sql, args):
    rows = [{"host_id": LIN, "name": "openssl", "arch": "x86_64", "version": "3.0.7-27", "installed_at": NOW - timedelta(days=2)},
            {"host_id": LIN, "name": "kernel", "arch": "x86_64", "version": "5.14-1", "installed_at": NOW - timedelta(days=200)}]
    if "%(lo)s" in sql:          # what the database would return for the period
        rows = [r for r in rows if args["lo"] <= r["installed_at"] < args["hi"]]
    return rows


def win_rows(sql, args):
    rows = [{"host_id": WIN, "kb": "KB5001", "title": "2026-10 Cumulative Update", "kind": "Security Update",
             "installed_on": NOW - timedelta(days=1), "installed_by": "NT AUTHORITY\\SYSTEM", "result": None, "source": "hotfix"},
            {"host_id": WIN, "kb": "KB4001", "title": "2025-01 Cumulative Update", "kind": "Security Update",
             "installed_on": NOW - timedelta(days=300), "installed_by": "", "result": None, "source": "hotfix"}]
    if "%(lo)s" in sql:
        rows = [r for r in rows if r["installed_on"] is None or args["lo"] <= r["installed_on"] < args["hi"]]
    return rows


def report_conn():
    c = FakeConn()
    c.on("FROM hosts h", [{"host_id": LIN, "hostname": "lin1", "host_group": "", "os_id": "rhel", "os_label": "RHEL 9",
                           "agent_version": "1.9.0", "last_inventory": NOW},
                          {"host_id": WIN, "hostname": "win1", "host_group": "", "os_id": "windows", "os_label": "Windows",
                           "agent_version": "1.9.0", "last_inventory": NOW}])
    c.on("FROM linux_package_installs li JOIN base", lin_rows)
    c.on("FROM windows_installed_updates WHERE host_id", win_rows)
    c.on("count(*) AS n, max(li.installed_at)", [{"host_id": LIN, "n": 2, "last": NOW - timedelta(days=2)}])
    c.on("FROM windows_installed_updates w WHERE", [{"host_id": WIN, "n": 2, "last": NOW - timedelta(days=1)}])
    return c


class W10InstalledByPeriod(unittest.TestCase):
    def test_on_screen_reads_the_period_only(self):
        f = ir.clean_filters(days=7)
        c = report_conn()
        hosts, totals = ir.collect(c, f)
        detail = [(s, a) for s, a in c.sql if "linux_package_installs li JOIN base" in s and "count(*)" not in s]
        self.assertEqual(len(detail), 1)
        s, a = detail[0]
        self.assertIn("li.installed_at >= %(lo)s", s)
        self.assertLessEqual(a["lo"], f["since"])
        self.assertGreaterEqual(a["hi"], f["until"])
        win = [s for s, _ in c.sql if "FROM windows_installed_updates WHERE host_id" in s]
        self.assertTrue(all("%(lo)s" in s for s in win))
        by = {h["hostname"]: h for h in hosts}
        self.assertEqual([i["patch"] for i in by["lin1"]["in_range"]], ["openssl.x86_64"])
        self.assertEqual([i["patch"] for i in by["win1"]["in_range"]], ["KB5001"])
        # counts and the newest date still cover everything recorded (from the summary query)
        self.assertEqual(by["lin1"]["n_all"], 2)
        self.assertEqual(totals["all"], 4)
        self.assertEqual(by["lin1"]["last_installed"], NOW - timedelta(days=2))
        self.assertTrue(by["lin1"]["dated"])

    def test_full_reads_everything(self):
        f = ir.clean_filters(days=7)
        c = report_conn()
        hosts, totals = ir.collect(c, f, full=True)
        self.assertFalse(any("%(lo)s" in s for s, _ in c.sql))
        self.assertFalse(any("count(*)" in s for s, _ in c.sql))
        by = {h["hostname"]: h for h in hosts}
        self.assertEqual(len(by["lin1"]["all"]), 2)
        self.assertEqual(len(by["win1"]["all"]), 2)
        self.assertEqual(by["lin1"]["n_range"], 1)

    def test_old_period_keeps_newest_date(self):
        f = ir.clean_filters(start=(NOW - timedelta(days=400)).date().isoformat(), end=(NOW - timedelta(days=350)).date().isoformat())
        hosts, _ = ir.collect(report_conn(), f)
        by = {h["hostname"]: h for h in hosts}
        self.assertEqual(by["lin1"]["in_range"], [])
        self.assertEqual(by["lin1"]["last_installed"], NOW - timedelta(days=2))

    def test_definition_rule_same_in_sql(self):
        import re
        self.assertTrue(re.search(ir.DEFS_PG, "security intelligence update for microsoft defender".lower(), re.I))
        self.assertNotIn("(?i)", ir.DEFS_PG)


class W11LowestByVersionOrder(unittest.TestCase):
    def test_rpm(self):
        self.assertEqual(pr._lowest(("0", "10.0.1", "1"), ("0", "9.9.1", "1"), "dnf"), ("0", "9.9.1", "1"))
        self.assertEqual(pr._lowest(("0", "9.9.1", "1"), ("0", "10.0.1", "1"), "dnf"), ("0", "9.9.1", "1"))
        self.assertEqual(pr._lowest(None, ("0", "1", "1"), "dnf"), ("0", "1", "1"))
        self.assertEqual(pr._lowest(("1", "1.0", "1"), ("0", "9.0", "1"), "dnf"), ("0", "9.0", "1"))

    def test_deb(self):
        self.assertEqual(pr._lowest(("0", "1.2~rc1", "1"), ("0", "1.2", "1"), "apt"), ("0", "1.2~rc1", "1"))

    def test_server_truth_two_architectures(self):
        c = FakeConn()
        c.on("FROM host_packages", [{"host_id": LIN, "name": "glibc", "epoch": 0, "version": "10.0.1", "release": "1"},
                                    {"host_id": LIN, "name": "glibc", "epoch": 0, "version": "9.9.1", "release": "1"}])
        raw = [{"host_id": LIN, "os_id": "rhel", "pkg_manager": "dnf", "detail": {"packages": [{"name": "glibc"}]}}]
        win, linux = pr.server_truth(c, raw)
        self.assertEqual(linux[LIN]["glibc"], ("0", "9.9.1", "1"))
        self.assertFalse(pr._linux_has(linux[LIN]["glibc"], "10.0.1-1", "dnf"))


class W12RunNowOnDueDay(unittest.TestCase):
    def sched(self, **more):
        s = {"id": 1, "name": "daily", "enabled": True, "at_time": "07:00", "frequency": "daily", "weekday": None,
             "monthday": None, "last_run_on": None, "run_requested_at": None, "report": "x", "params": {}, "format": "pdf",
             "recipients": None, "skip_empty": False}
        s.update(more)
        return s

    def test_counts_as_scheduled(self):
        tz = timezone(timedelta(hours=8))
        after = datetime(2026, 10, 27, 9, 0, tzinfo=tz)
        before = datetime(2026, 10, 27, 6, 0, tzinfo=tz)
        self.assertTrue(rj.counts_as_scheduled(self.sched(), after, asked=False))
        self.assertTrue(rj.counts_as_scheduled(self.sched(), after, asked=True))
        self.assertFalse(rj.counts_as_scheduled(self.sched(), before, asked=True))
        self.assertFalse(rj.counts_as_scheduled(self.sched(enabled=False), after, asked=True))
        self.assertFalse(rj.counts_as_scheduled(self.sched(frequency="weekly", weekday="mon"), after, asked=True))   # a Tuesday

    def run_with(self, s, now):
        c = FakeConn()
        c.on("SELECT * FROM report_schedules", [s])
        tz = now.tzinfo

        class FrozenDT(datetime):
            @classmethod
            def now(cls, tz_=None):
                return now.astimezone(tz_) if tz_ else now
        with mock.patch.object(rj, "queue", lambda *a, **k: (3, ["a@example.org"])), mock.patch.object(rj, "datetime", FrozenDT):
            rj.run_due(c, {"tz": tz})
        upd = [a for sql, a in c.sql if "UPDATE report_schedules" in sql][0]
        return upd

    def test_run_now_after_due_time_sets_last_run_on(self):
        tz = timezone(timedelta(hours=8))
        now = datetime(2026, 10, 27, 9, 0, tzinfo=tz)
        upd = self.run_with(self.sched(run_requested_at=now), now)
        self.assertEqual(upd[2:4], (True, "2026-10-27"))
        # and the schedule then does not send again today
        self.assertFalse(rj._due(self.sched(last_run_on="2026-10-27"), now))

    def test_run_now_before_due_time_leaves_it(self):
        tz = timezone(timedelta(hours=8))
        now = datetime(2026, 10, 27, 6, 0, tzinfo=tz)
        upd = self.run_with(self.sched(run_requested_at=now), now)
        self.assertFalse(upd[2])

    def test_scheduled_run_sets_it(self):
        tz = timezone(timedelta(hours=8))
        now = datetime(2026, 10, 27, 9, 0, tzinfo=tz)
        self.assertTrue(self.run_with(self.sched(), now)[2])


if __name__ == "__main__":
    unittest.main()
