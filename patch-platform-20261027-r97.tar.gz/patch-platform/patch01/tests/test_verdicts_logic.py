"""Verdict fixes (O1-O3, O7-O11, O18, O19, W2, W5, W8): the Python decision
logic, with fake database connections where the code needs one. No
PostgreSQL here: the SQL itself is reviewed, not run.

    cd patch01 && python3 -m unittest -v tests.test_verdicts_logic
"""
import ast
import os
import re
import sys
import types
import unittest
from datetime import datetime, timedelta, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "api"))

# cve_engine imports psycopg at module level; it is not installed here
if "psycopg" not in sys.modules:
    try:
        import psycopg  # noqa: F401
    except ImportError:
        _pg = types.ModuleType("psycopg")
        _rows = types.ModuleType("psycopg.rows")
        _rows.dict_row = object()
        _pg.rows = _rows
        _pg.connect = lambda *a, **k: None
        sys.modules["psycopg"] = _pg
        sys.modules["psycopg.rows"] = _rows

from app import assess, cve_engine, cve_feeds, cve_impact, exposure, insights, inventory, overview  # noqa: E402


# ---------------------------------------------------------------------------
# A fake connection: records every statement, answers from a script
# ---------------------------------------------------------------------------

class _Cur:
    def __init__(self, rows=None, rowcount=0):
        self._rows = rows or []
        self.rowcount = rowcount

    def fetchall(self):
        return list(self._rows)

    def fetchone(self):
        return self._rows[0] if self._rows else None


class _Tx:
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class FakeConn:
    def __init__(self, answer=None, autocommit=False):
        self.sql = []
        self.answer = answer or (lambda sql, params: _Cur())
        self.autocommit = autocommit
        self.commits = self.rollbacks = 0

    def execute(self, sql, params=None):
        self.sql.append((sql, params))
        return self.answer(sql, params)

    def transaction(self):
        return _Tx()

    def cursor(self):
        conn = self

        class C:
            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

            def executemany(self, sql, rows):
                conn.sql.append((sql, list(rows)))
        return C()

    def commit(self):
        self.commits += 1

    def rollback(self):
        self.rollbacks += 1


# ---------------------------------------------------------------------------
# O3: unknown wins over patched
# ---------------------------------------------------------------------------

class AssessStatus(unittest.TestCase):
    def c(self, **kw):
        return dict({"affected": 0, "pending_reboot": 0, "patched": 0, "unknown": 0}, **kw)

    def test_unknown_beats_patched(self):
        self.assertEqual(assess._status(self.c(patched=5, unknown=3), True), "unknown")

    def test_order(self):
        self.assertEqual(assess._status(self.c(affected=1, unknown=3, patched=2), True), "affected")
        self.assertEqual(assess._status(self.c(pending_reboot=1, unknown=3), True), "pending_reboot")
        self.assertEqual(assess._status(self.c(patched=4), True), "patched")
        self.assertEqual(assess._status(self.c(), True), "not_applicable")
        self.assertEqual(assess._status(self.c(), False), "no_vendor_data")
        self.assertEqual(assess._status(self.c(unknown=1), False), "unknown")

    def test_unknown_never_maps_to_not_affected(self):
        status = assess._status(self.c(patched=5, unknown=3), True)
        self.assertNotEqual(cve_impact.exposure_word(status, "not_found", [], [], True), "not_affected")
        self.assertEqual(cve_impact.exposure_word(status, "not_found", [], [], True), "no_data")
        # affected still wins
        self.assertEqual(cve_impact.exposure_word("unknown", "affected", [], [], True), "affected")
        self.assertEqual(cve_impact.exposure_word("patched", "not_found", [], [], True), "not_affected")

    def test_evaluate_reads_effective_state(self):
        """Counts and host lists go through the stale guard (O1, read side)."""
        seen = []

        def answer(sql, params):
            seen.append(sql)
            if "count(*) AS n FROM hosts" in sql:
                return _Cur([{"n": 2}])
            if "WITH s AS" in sql:
                return _Cur([{"cve_id": "CVE-2024-1", "state": "fixed_active", "n": 5},
                             {"cve_id": "CVE-2024-1", "state": "unknown", "n": 3}])
            if "FROM advisory_cves ac\n             LEFT JOIN" in sql:
                return _Cur([{"cve_id": "CVE-2024-1", "advisory_id": "RHSA-1", "packages": ["openssl"]}])
            return _Cur([])
        items, n = assess.evaluate(FakeConn(answer), ["CVE-2024-1"])
        self.assertEqual(items[0]["status"], "unknown")
        self.assertEqual((items[0]["patched"], items[0]["unknown"]), (5, 3))
        guarded = [s for s in seen if "host_applicability" in s]
        self.assertEqual(len(guarded), 2)
        for s in guarded:
            self.assertIn("h.status = 'stale'", s)
            self.assertIn("h.last_inventory <", s)


# ---------------------------------------------------------------------------
# O9: mixed version segments
# ---------------------------------------------------------------------------

class VersionCompare(unittest.TestCase):
    def test_openssl_letters(self):
        r = [{"start_incl": "1.1.1", "end_excl": "1.1.1w"}]
        self.assertEqual(exposure.match_versioned("1.1.1k", r)[0], "in_range")
        self.assertEqual(exposure.match_versioned("1.1.1w", r)[0], "outside")
        self.assertEqual(exposure.match_versioned("1.1.1", r)[0], "in_range")
        self.assertEqual(exposure.match_versioned("1.1.0l", r)[0], "outside")

    def test_vcmp(self):
        v = exposure.vcmp
        self.assertEqual(v("8.0", "8.0.0"), 0)
        self.assertEqual(v("8.0.3", "8.0.2"), 1)
        self.assertEqual(v("1.10", "1.9"), 1)
        self.assertEqual(v("1.1.1k", "1.1.1"), 1)
        self.assertEqual(v("1.1.1k", "1.1.1w"), -1)
        self.assertEqual(v("1.0.2", "1.0.1u"), 1)
        self.assertEqual(v("1.0-beta", "1.0"), -1)
        self.assertEqual(v("1.0rc1", "1.0.1"), -1)
        self.assertEqual(v("v2.4", "2.4"), 0)
        self.assertEqual(v("2.4.1", "v2.4"), 1)
        self.assertEqual(v("", "0"), 0)

    def test_existing_results_kept(self):
        r = [{"start_incl": "7.0", "end_excl": "7.0.3"}]
        self.assertEqual(exposure.match_versioned("7.0.2", r)[0], "in_range")
        self.assertEqual(exposure.match_versioned("7.0.3", r)[0], "outside")
        self.assertEqual(exposure.match_versioned("6.7", r)[0], "outside")
        self.assertTrue(exposure.in_range("130.0.1", {"end_incl": "130.0.1"}))
        self.assertFalse(exposure.in_range("130.0.2", {"end_incl": "130.0.1"}))
        self.assertEqual(exposure.vkey("8.0.3"), (8, 0, 3))
        self.assertEqual(exposure.esxi_release("8.0.3"), ("8.0", "3"))


# ---------------------------------------------------------------------------
# O18, O1 (read side), O8, O10: the CVE impact verdict
# ---------------------------------------------------------------------------

class ImpactVerdict(unittest.TestCase):
    def test_all_fixed(self):
        self.assertEqual(cve_impact.impact_verdict([], [{"fixed": True}, {"fixed": True}]), "not_affected")

    def test_partly_proven_is_unknown(self):
        self.assertEqual(cve_impact.impact_verdict([], [{"fixed": True}, {"fixed": False, "unproven": True}]), "unknown")
        self.assertEqual(cve_impact.impact_verdict([], [{"fixed": True}, {"fixed": False, "undecided": True}]), "unknown")
        self.assertEqual(cve_impact.impact_verdict([], [{"fixed": True}], {"ubu01"}), "unknown")

    def test_platform_exclusion_does_not_block(self):
        self.assertEqual(cve_impact.impact_verdict([], [{"fixed": True}, {"fixed": False, "unproven": False}]),
                         "not_affected")

    def test_silent_server(self):
        self.assertEqual(cve_impact.impact_verdict([], [{"fixed": False, "unproven": True, "silent": True}]), "unknown")

    def test_affected_and_nothing(self):
        self.assertEqual(cve_impact.impact_verdict([{"name": "a"}], [{"fixed": True}]), "affected")
        self.assertEqual(cve_impact.impact_verdict([], []), "not_found")
        self.assertEqual(cve_impact.impact_verdict([], [], set()), "not_found")
        # only a platform exclusion: no machine holds the product
        self.assertEqual(cve_impact.impact_verdict([], [{"fixed": False, "unproven": False}]), "not_found")

    def test_held_but_unproven_is_unknown(self):
        """Machines hold the product but nothing proves it either way: unknown, never 'not in our environment'."""
        self.assertEqual(cve_impact.impact_verdict([], [{"fixed": False, "unproven": True}]), "unknown")
        self.assertEqual(cve_impact.impact_verdict([], [{"undecided": True, "fixed": False}], set()), "unknown")
        self.assertEqual(cve_impact.impact_verdict([], [], {"ubu1"}), "unknown")
        self.assertEqual(cve_impact.exposure_word(None, "unknown", [], [], True), "no_data")

    def test_confirmed_matches_silent(self):
        base = {"os_id": "rhel", "package_name": "openssl", "installed_evr": "1", "fixed_evr": "2",
                "advisory_id": "RHSA-1"}
        rows = [dict(base, hostname="a", state="affected", stale=False),
                dict(base, hostname="b", state="affected", stale=True),
                dict(base, hostname="c", state="fixed_active", stale=True),
                dict(base, hostname="d", state="unknown", stale=False),
                dict(base, hostname="e", state="fixed_pending_reboot", stale=False)]
        m, silent = cve_impact.confirmed_matches(rows)
        self.assertEqual([(x["name"], x["certainty"]) for x in m], [("a", "confirmed"), ("e", "pending_reboot")])
        self.assertEqual([x["name"] for x in silent], ["b", "c", "d"])
        self.assertTrue(all(x["silent"] and x["unproven"] for x in silent))

    def test_failed_result_not_clean(self):
        v, n, m, info = cve_impact.failed_result(RuntimeError("boom"))
        self.assertEqual(v, "unknown")
        self.assertTrue(info["failed"])
        self.assertIn("boom", info["notes"][0])


class RedHatKernel(unittest.TestCase):
    BEST = {"epoch": 0, "version": "5.14.0", "release": "570.12.1.el9_6"}

    def row(self, ver_rel, running):
        v, r = ver_rel
        return {"epoch": 0, "version": v, "release": r, "kernel_running": running}

    def test_installed_not_running(self):
        r = self.row(("5.14.0", "570.12.1.el9_6"), "5.14.0-503.11.1.el9_5.x86_64")
        self.assertEqual(cve_impact.rh_fixed_state("kernel", r, self.BEST), "pending_reboot")

    def test_running_fixed(self):
        r = self.row(("5.14.0", "570.12.1.el9_6"), "5.14.0-570.12.1.el9_6.x86_64")
        self.assertEqual(cve_impact.rh_fixed_state("kernel", r, self.BEST), "fixed")

    def test_older_and_unknown_running(self):
        r = self.row(("5.14.0", "503.11.1.el9_5"), "5.14.0-503.11.1.el9_5.x86_64")
        self.assertEqual(cve_impact.rh_fixed_state("kernel", r, self.BEST), "older")
        r = self.row(("5.14.0", "570.12.1.el9_6"), None)
        self.assertEqual(cve_impact.rh_fixed_state("kernel", r, self.BEST), "running_unknown")

    def test_non_kernel_ignores_running(self):
        best = {"epoch": 1, "version": "3.0.7", "release": "27.el9"}
        r = {"epoch": 1, "version": "3.0.7", "release": "27.el9", "kernel_running": "5.14.0-1.el9.x86_64"}
        self.assertEqual(cve_impact.rh_fixed_state("openssl", r, best), "fixed")

    def test_match_redhat_kernel_pending(self):
        from app import rh_state
        st = {"found": True, "fixed": [dict(self.BEST, major=9, package="kernel", advisory="RHSA-2025:1")],
              "states": []}
        rows = [{"hostname": "web01", "os_id": "rhel", "os_major": 9, "kernel_running": "5.14.0-503.11.1.el9_5.x86_64",
                 "name": "kernel-core", "epoch": 0, "version": "5.14.0", "release": "570.12.1.el9_6"},
                {"hostname": "web02", "os_id": "rhel", "os_major": 9, "kernel_running": "5.14.0-570.12.1.el9_6.x86_64",
                 "name": "kernel-core", "epoch": 0, "version": "5.14.0", "release": "570.12.1.el9_6"}]
        old = rh_state.get
        rh_state.get = lambda conn, cid: st
        try:
            m, x, notes, decided = cve_impact.match_redhat(FakeConn(lambda s, p: _Cur(rows)), "CVE-2025-1",
                                                          ["kernel"], [])
        finally:
            rh_state.get = old
        self.assertEqual([(i["name"], i["certainty"]) for i in m], [("web01", "pending_reboot")])
        self.assertEqual([(i["name"], i.get("fixed")) for i in x], [("web02", True)])


# ---------------------------------------------------------------------------
# O11: NVD paging keeps the newest results, up to the last page
# ---------------------------------------------------------------------------

class NvdPaging(unittest.TestCase):
    def run_query(self, total, page=500, cap=4000, short_pages=False):
        calls = []

        def fetch(q):
            start = q["startIndex"]
            calls.append(start)
            n = min(q["resultsPerPage"] if not short_pages else 300, max(0, total - start))
            return {"totalResults": total, "vulnerabilities": [{"cve": {"i": start + k}} for k in range(n)]}
        old = (cve_feeds.NVD_PAGE, cve_feeds.NVD_MAX_PER_QUERY, cve_feeds.parse_nvd_item)
        cve_feeds.NVD_PAGE, cve_feeds.NVD_MAX_PER_QUERY = page, cap
        cve_feeds.parse_nvd_item = lambda cve, general: str(cve["i"])
        notes = []
        try:
            items = [int(i) for i in cve_feeds._nvd_query({}, True, lambda: False, notes, fetch=fetch)]
        finally:
            cve_feeds.NVD_PAGE, cve_feeds.NVD_MAX_PER_QUERY, cve_feeds.parse_nvd_item = old
        return items, notes, calls

    def test_small(self):
        items, notes, calls = self.run_query(1200)
        self.assertEqual(items, list(range(1200)))
        self.assertEqual(notes, [])

    def test_just_over_cap(self):
        items, notes, _ = self.run_query(4300)
        self.assertEqual(items, list(range(300, 4300)))      # the newest 4000, the last one included
        self.assertTrue(notes and "300 older" in notes[0])

    def test_far_over_cap(self):
        items, notes, calls = self.run_query(10123)
        self.assertEqual(items, list(range(10123 - 4000, 10123)))
        self.assertEqual(calls[0], 0)
        self.assertEqual(calls[1], 10123 - 4000)
        self.assertTrue(notes)

    def test_short_pages_from_nvd(self):
        items, _, _ = self.run_query(4300, short_pages=True)
        self.assertEqual(items, list(range(300, 4300)))

    def test_exact_cap_and_empty(self):
        items, notes, _ = self.run_query(4000)
        self.assertEqual(len(items), 4000)
        self.assertEqual(notes, [])
        items, notes, calls = self.run_query(0)
        self.assertEqual((items, calls), ([], [0]))


# ---------------------------------------------------------------------------
# O1, O2, O19: the engine
# ---------------------------------------------------------------------------

class Engine(unittest.TestCase):
    def test_supports_windows(self):
        self.assertTrue(cve_engine.supports("windows"))
        self.assertTrue(cve_engine.supports("rhel"))
        self.assertTrue(cve_engine.supports("ol"))
        self.assertFalse(cve_engine.supports("ubuntu"))
        self.assertFalse(cve_engine.supports(None))

    def test_compute_all_includes_windows(self):
        done = []
        hosts = [{"id": i, "hostname": n, "os_id": o, "os_major": 1, "status": "active", "kernel_running": None,
                  "reboot_required": False, "last_inventory": None}
                 for i, (n, o) in enumerate([("w1", "windows"), ("r1", "rhel"), ("u1", "ubuntu")])]
        old = cve_engine.compute_host
        cve_engine.compute_host = lambda conn, h: done.append(h["hostname"]) or {}
        try:
            cve_engine.compute_all(FakeConn(lambda s, p: _Cur(hosts)))
        finally:
            cve_engine.compute_host = old
        self.assertEqual(done, ["w1", "r1"])

    def test_windows_build_compare(self):
        """A Windows host's OS build against an MSRC advisory gives a verdict."""
        now = datetime.now(timezone.utc)
        host = {"id": "h1", "hostname": "w1", "os_id": "windows", "os_major": 2019, "status": "active",
                "kernel_running": "10.0.17763.6000", "reboot_required": False, "last_inventory": now}

        def answer(sql, params):
            if "FROM host_packages" in sql:
                return _Cur([{"name": "windows-os-build", "arch": "noarch", "epoch": 0,
                              "version": "10.0.17763.6000", "release": "0"}])
            if "FROM advisory_packages" in sql:
                return _Cur([{"advisory_id": "KB5044277", "name": "windows-os-build", "arch": "noarch", "epoch": 0,
                              "version": "10.0.17763.6414", "release": "0"}])
            return _Cur()
        conn = FakeConn(answer)
        self.assertEqual(cve_engine.compute_host(conn, host), {"affected": 1})

    def test_no_inventory_marks_unknown(self):
        host = {"id": "h1", "hostname": "r1", "os_id": "rhel", "os_major": 9, "status": "active",
                "kernel_running": None, "reboot_required": False, "last_inventory": None}

        def answer(sql, params):
            if "UPDATE host_applicability" in sql:
                return _Cur(rowcount=7)
            return _Cur()
        conn = FakeConn(answer)
        res = cve_engine.compute_host(conn, host)
        self.assertEqual(res, {"skipped": "no inventory", "marked_unknown": 7})
        upd = [s for s, p in conn.sql if "UPDATE host_applicability" in s]
        self.assertEqual(len(upd), 1)
        self.assertIn("state = 'unknown'", upd[0])

    def test_sweep_due(self):
        self.assertTrue(cve_engine.sweep_due(1000.0, 0.0, 900))
        self.assertFalse(cve_engine.sweep_due(1000.0, 500.0, 900))
        self.assertTrue(cve_engine.sweep_due(1400.0, 500.0, 900))

    def test_staleness_sweep(self):
        def answer(sql, params):
            if "mark_stale_hosts" in sql:
                return _Cur([{"n": 2}])
            if "UPDATE host_applicability" in sql:
                return _Cur(rowcount=40)
            if "UPDATE hosts h SET packages_changed_at" in sql:
                return _Cur(rowcount=1)
            return _Cur()
        conn = FakeConn(answer)
        res = cve_engine.staleness_sweep(conn, hours=24, force=True)
        self.assertEqual(res, {"stale_hosts": 2, "verdicts_unknown": 40, "requeued": 1})
        sqls = [s for s, _ in conn.sql]
        self.assertIn("mark_stale_hosts", sqls[0])
        self.assertIn("state = 'unknown'", sqls[1])
        self.assertIn("last_inventory <", sqls[1])
        self.assertIn("packages_changed_at = now()", sqls[2])
        # not due again straight away
        self.assertIsNone(cve_engine.staleness_sweep(conn, hours=24))
        # the worker's one-line call commits, and survives a failure
        cve_engine._last_sweep["at"] = 0.0
        conn2 = FakeConn(answer)
        cve_engine.periodic_sweep(conn2)
        self.assertEqual(conn2.commits, 1)
        cve_engine._last_sweep["at"] = 0.0

        def boom(sql, params):
            raise RuntimeError("db down")
        conn3 = FakeConn(boom)
        self.assertIsNone(cve_engine.periodic_sweep(conn3))
        self.assertEqual(conn3.rollbacks, 1)
        cve_engine._last_sweep["at"] = 0.0

    def test_stale_host_compute_unknown(self):
        old = datetime.now(timezone.utc) - timedelta(hours=cve_engine.STALE_HOURS + 1)
        host = {"id": "h1", "hostname": "r1", "os_id": "rhel", "os_major": 9, "status": "active",
                "kernel_running": "5.14.0-570.el9.x86_64", "reboot_required": False, "last_inventory": old}

        def answer(sql, params):
            if "FROM host_packages" in sql:
                return _Cur([{"name": "openssl", "arch": "x86_64", "epoch": 1, "version": "3.0.7", "release": "27.el9"}])
            if "FROM advisory_packages" in sql:
                return _Cur([{"advisory_id": "RHSA-1", "name": "openssl", "arch": "x86_64", "epoch": 1,
                              "version": "3.0.7", "release": "20.el9"}])
            return _Cur()
        self.assertEqual(cve_engine.compute_host(FakeConn(answer), host), {"unknown": 1})


# ---------------------------------------------------------------------------
# O7: compliance never counts silence as patched
# ---------------------------------------------------------------------------

class ImpactCountsAndUi(unittest.TestCase):
    def test_counts_has_unknown(self):
        seen = []
        cve_impact.counts(FakeConn(lambda sql, p: seen.append(sql) or _Cur([{}])), 14)
        self.assertIn("verdict = 'unknown') AS unknown", seen[0])

    def test_cyber_js(self):
        with open(os.path.join(ROOT, "dashboard", "html", "cyber.js")) as fh:
            js = fh.read()
        self.assertIn('unknown: ["Cannot tell", "c-warn"]', js)
        self.assertIn('["affected", "unknown", "not_affected", "not_found"]', js)
        self.assertIn('Windows Update has not completed a search', js)
        from app import servers
        self.assertIn("h.wu_error", servers._BASE_T)


class Compliance(unittest.TestCase):
    def test_overview(self):
        c = {"servers": 10, "to_patch": 2, "unknown": 3, "patched": 5}
        self.assertEqual(overview.compliance_pct(c), 50.0)
        self.assertIsNone(overview.compliance_pct({"servers": 0, "patched": 0}))
        # all offline: nothing counts as patched
        self.assertEqual(overview.compliance_pct({"servers": 4, "to_patch": 0, "unknown": 4, "patched": 0}), 0.0)

    def test_overview_sql(self):
        self.assertIn("to_i = 0 AND agent = 'online'", overview.KPI_SQL)
        self.assertIn("coalesce(to_i = 0 AND agent = 'online', false)", overview.KPI_SQL)

    def test_dashboard(self):
        with open(os.path.join(ROOT, "api", "app", "api_dashboard.py")) as fh:
            src = fh.read()
        fn = next(n for n in ast.parse(src).body if isinstance(n, ast.FunctionDef) and n.name == "compliance_pct")
        ns = {}
        exec(compile(ast.Module([fn], []), "api_dashboard", "exec"), ns)
        self.assertEqual(ns["compliance_pct"]({"total": 10, "patched": 6, "unknown": 2, "not_reporting": 2}), 60)
        self.assertIsNone(ns["compliance_pct"]({"total": 0, "patched": 0}))


# ---------------------------------------------------------------------------
# W2: migration 050's view
# ---------------------------------------------------------------------------

class Migration050(unittest.TestCase):
    def setUp(self):
        with open(os.path.join(ROOT, "sql", "050-verdict-fixes.sql")) as fh:
            self.sql = fh.read()

    def test_view_columns_unchanged(self):
        with open(os.path.join(ROOT, "sql", "044-linux-updates.sql")) as fh:
            old = fh.read()

        def cols(text):
            body = re.search(r"CREATE OR REPLACE VIEW v_host_patch AS(.*?)FROM hosts h;", text, re.S).group(1)
            return re.findall(r"\bAS (\w+)|(h\.updates_\w+)", body)
        self.assertEqual(cols(old), cols(self.sql))

    def test_windows_needs_a_successful_search(self):
        self.assertIn("h.wu_searched_at IS NOT NULL AND h.wu_error IS NULL", self.sql)
        self.assertIn("'unknown'", self.sql)
        self.assertIn("VALUES (50,", self.sql)


# ---------------------------------------------------------------------------
# W5: insights from the servers' own word
# ---------------------------------------------------------------------------

class Insights(unittest.TestCase):
    def test_facts_sql_and_text(self):
        totals = {"servers": 5, "online": 4, "offline": 1, "windows": 1, "need_patches": 2,
                  "patch_state_unknown": 1, "need_reboot": 0, "updates_to_install": 9,
                  "advisories_to_install": 0, "windows_updates_missing": 3}

        def answer(sql, params):
            if "WITH h AS" in sql:
                self.assertIn("v_host_patch", sql)
                self.assertIn("to_i > 0", sql)
                return _Cur([totals])
            if "AS outstanding" in sql:
                self.assertIn("vp.to_install", sql)
                return _Cur([{"hostname": "ubu01", "outstanding": 9, "exploited_cve": False}])
            return _Cur([])
        f = insights.facts(FakeConn(answer))
        self.assertEqual(f["totals"]["need_patches"], 2)
        self.assertEqual(f["most_behind"][0]["hostname"], "ubu01")
        f["changes"] = insights._changes({"totals": dict(totals, patch_state_unknown=0)}, f)
        self.assertIn("patch state unknown: 0 -> 1", f["changes"])
        text = insights.facts_text(f)
        self.assertIn("2 need patches (9 updates to install)", text)
        self.assertIn("1 has an unknown patch state", text)


# ---------------------------------------------------------------------------
# W8: two machines sharing a short name
# ---------------------------------------------------------------------------

class SharedShortName(unittest.TestCase):
    def hosts(self):
        return [{"id": "11111111-aaaa", "hostname": "web01.prod", "fqdn": "web01.prod.example.com", "os_id": "rhel",
                 "agent_version": "1.9", "status": "active", "agent_ip": "10.0.0.1"},
                {"id": "22222222-bbbb", "hostname": "web01.dr", "fqdn": "web01.dr.example.com", "os_id": "rhel",
                 "agent_version": "1.9", "status": "active", "agent_ip": "10.0.1.1"},
                {"id": "33333333-cccc", "hostname": "db01", "fqdn": None, "os_id": "rhel",
                 "agent_version": "1.9", "status": "active", "agent_ip": "10.0.0.5"}]

    def test_agent_keys(self):
        k = inventory.agent_keys(self.hosts())
        self.assertEqual(k["by_id"], {"11111111-aaaa": "web01.prod", "22222222-bbbb": "web01.dr",
                                      "33333333-cccc": "db01"})
        self.assertEqual(k["shared"], {"web01"})

    def test_identical_hostnames(self):
        hs = [{"id": "aaaaaaaa-1", "hostname": "web01", "fqdn": None}, {"id": "bbbbbbbb-2", "hostname": "web01", "fqdn": None}]
        k = inventory.agent_keys(hs)["by_id"]
        self.assertEqual(len(set(k.values())), 2)
        self.assertTrue(all(inventory.KEY_RE.match(v) for v in k.values()))

    def test_merge_keeps_both(self):
        wsus = [{"name": "web01.dr.example.com", "source": "wsus", "os": "Windows", "ip": None}]
        out = inventory.merge(self.hosts(), [], wsus, [], [])
        agents = {a["key"]: a["agent"]["host_id"] for a in out if a.get("agent")}
        self.assertEqual(agents, {"web01.prod": "11111111-aaaa", "web01.dr": "22222222-bbbb", "db01": "33333333-cccc"})
        dr = next(a for a in out if a["key"] == "web01.dr")
        self.assertIsNotNone(dr["wsus"])                   # joined by FQDN, not to web01.prod
        prod = next(a for a in out if a["key"] == "web01.prod")
        self.assertIsNone(prod["wsus"])

    def test_servers_join_by_host(self):
        from app import servers
        self.assertIn("LEFT JOIN imp ON imp.host_id = h.id", servers._BASE_T)
        self.assertIn("hk.sn_count = 1", servers._BASE_T)


if __name__ == "__main__":
    unittest.main()
