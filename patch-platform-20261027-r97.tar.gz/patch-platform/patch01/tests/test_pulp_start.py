"""r96: Pulp health checks, their migration on deployed servers, and the start
script's waiting. Real health-check commands against local HTTP servers.

    cd patch01 && python3 -m unittest -v tests.test_pulp_start
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
TMPL = os.path.join(ROOT, "compose", "docker-compose.pulp.yml.tmpl")
MIGRATE = os.path.join(ROOT, "scripts", "pulp-healthcheck-migrate.py")
START = os.path.join(ROOT, "scripts", "patch01-start.sh")
OLD_TMPL = os.environ.get("OLD_PULP_TMPL", "/home/claude/work/pulp-compose.orig")


def render(text):
    """fill the @@...@@ placeholders the way phase1c-pulp.sh does"""
    vals = {"PULP_IMAGE": "quay.io/pulp/pulp-minimal:3.49", "PULP_UID": "700", "PULP_GID": "700",
            "SECRETS_DIR": "/patch/secrets", "PULP_DATA_DIR": "/patch/data/pulp", "CONFIG_DIR": "/patch/config",
            "API_WORKERS": "4", "CONTENT_WORKERS": "4"}
    return re.sub(r"@@([A-Z_]+)@@", lambda m: vals.get(m.group(1), "x"), text)


def health_test(svc, text=None):
    doc = yaml.safe_load(render(text or open(TMPL).read()))
    return doc["services"][svc]["healthcheck"]["test"]


def run_check(test, port_from, port_to, env=None):
    """run a CMD health check here, pointed at a local port instead of Pulp's"""
    assert test[0] == "CMD", test
    argv = [a.replace(str(port_from), str(port_to)) for a in test[1:]]
    argv[0] = sys.executable
    return subprocess.run(argv, env=env or os.environ.copy(), timeout=20,
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode


class Code(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        self.send_response(self.server.code)
        self.send_header("Content-Length", "0")
        self.end_headers()


def serve(code):
    s = ThreadingHTTPServer(("127.0.0.1", 0), Code)
    s.code = code
    threading.Thread(target=s.serve_forever, daemon=True).start()
    return s


def free_port():
    s = ThreadingHTTPServer(("127.0.0.1", 0), Code)
    p = s.server_address[1]
    s.server_close()
    return p


class HealthChecks(unittest.TestCase):
    def check(self, svc, port, code):
        if code is None:
            return run_check(health_test(svc), port, free_port())
        s = serve(code)
        try:
            return run_check(health_test(svc), port, s.server_address[1])
        finally:
            s.shutdown()
            s.server_close()

    def test_all_are_exec_form_python(self):
        for svc in ("pulp-api", "pulp-content", "pulp-worker"):
            t = health_test(svc)
            self.assertEqual(t[:2], ["CMD", "python3"], svc)
            self.assertNotIn("curl", " ".join(t))
            self.assertNotIn("pgrep", " ".join(t))

    def test_api(self):
        self.assertEqual(self.check("pulp-api", 24817, 200), 0)
        self.assertEqual(self.check("pulp-api", 24817, 500), 1)
        self.assertEqual(self.check("pulp-api", 24817, None), 1)

    def test_content_accepts_404(self):
        self.assertEqual(self.check("pulp-content", 24816, 404), 0)
        self.assertEqual(self.check("pulp-content", 24816, 200), 0)
        self.assertEqual(self.check("pulp-content", 24816, 500), 1)
        self.assertEqual(self.check("pulp-content", 24816, None), 1)

    def test_checks_ignore_a_proxy(self):
        s = serve(200)
        try:
            env = dict(os.environ, http_proxy="http://127.0.0.1:9", HTTP_PROXY="http://127.0.0.1:9")
            self.assertEqual(run_check(health_test("pulp-api"), 24817, s.server_address[1], env), 0)
        finally:
            s.shutdown()
            s.server_close()

    def test_worker(self):
        test = health_test("pulp-worker")
        # nothing called pulpcore-worker runs here: the check must not count itself
        self.assertEqual(run_check(test, 0, 0), 1)
        p = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(30)", "pulpcore-worker"])
        try:
            time.sleep(0.3)
            self.assertEqual(run_check(test, 0, 0), 0)
        finally:
            p.kill()
            p.wait()
        self.assertEqual(run_check(test, 0, 0), 1)

    def test_old_worker_check_matched_itself(self):
        """why it was replaced: sh -c 'pgrep -f pulpcore-worker' finds its own shell"""
        if not shutil.which("pgrep"):
            self.skipTest("no pgrep here")
        r = subprocess.run(["sh", "-c", "pgrep -f pulpcore-worker >/dev/null || exit 1"])
        self.assertEqual(r.returncode, 0)


@unittest.skipUnless(os.path.exists(OLD_TMPL), "old template not available")
class Migration(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.dep = os.path.join(self.d, "docker-compose.pulp.yml")
        with open(self.dep, "w") as fh:
            fh.write(render(open(OLD_TMPL).read()))
        os.chmod(self.dep, 0o640)

    def tearDown(self):
        shutil.rmtree(self.d)

    def migrate(self):
        return subprocess.run([sys.executable, MIGRATE, self.dep, TMPL], capture_output=True, text=True)

    def test_old_file_updated_and_valid(self):
        before = open(self.dep).read()
        r = self.migrate()
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("pulp-api, pulp-content, pulp-worker", r.stdout)
        doc = yaml.safe_load(open(self.dep))
        for svc in ("pulp-api", "pulp-content", "pulp-worker"):
            self.assertEqual(doc["services"][svc]["healthcheck"]["test"], health_test(svc))
        # everything else unchanged: same document apart from the tests
        old = yaml.safe_load(before)
        for svc in old["services"]:
            o, n = old["services"][svc], doc["services"][svc]
            if "healthcheck" in o:
                o = dict(o, healthcheck=dict(o["healthcheck"], test=None))
                n = dict(n, healthcheck=dict(n["healthcheck"], test=None))
            self.assertEqual(o, n, svc)
        self.assertEqual(oct(os.stat(self.dep).st_mode & 0o777), "0o640")

    def test_second_run_does_nothing(self):
        self.migrate()
        after = open(self.dep).read()
        self.assertEqual(self.migrate().returncode, 1)
        self.assertEqual(open(self.dep).read(), after)

    def test_hand_edited_check_left_alone(self):
        t = open(self.dep).read().replace("pgrep -f pulpcore-worker", "pgrep -x pulpcore-worker")
        open(self.dep, "w").write(t)
        self.migrate()
        doc = yaml.safe_load(open(self.dep))
        self.assertIn("pgrep -x", doc["services"]["pulp-worker"]["healthcheck"]["test"][1])
        self.assertEqual(doc["services"]["pulp-api"]["healthcheck"]["test"], health_test("pulp-api"))


class WaitReady(unittest.TestCase):
    """patch01-start.sh's wait_ready with container states played back"""

    def run_wait(self, states, limit, sleep_ok=True):
        fn = re.search(r"^wait_ready\(\) \{.*?^\}", open(START).read(), re.M | re.S).group(0)
        d = tempfile.mkdtemp()
        try:
            seq = os.path.join(d, "seq")
            with open(seq, "w") as fh:
                fh.write("\n".join(states) + "\n")
            script = f'''
say() {{ echo "$*"; }}
echo 0 >{seq}.n
cstate() {{ local n; n=$(( $(cat {seq}.n) + 1 )); echo $n >{seq}.n; local s; s="$(sed -n "${{n}}p" {seq})"; [[ -n "$s" ]] || s="$(tail -1 {seq})"; echo "$s"; }}
sleep() {{ :; }}
{fn}
wait_ready {limit} c1 && echo RESULT=ok || echo RESULT=fail
'''
            r = subprocess.run(["bash", "-c", script], capture_output=True, text=True, timeout=20)
            return r.stdout
        finally:
            shutil.rmtree(d)

    def test_becomes_healthy(self):
        out = self.run_wait(["starting", "starting", "running+healthy"], 600)
        self.assertIn("RESULT=ok", out)

    def test_unhealthy_stops_at_once(self):
        out = self.run_wait(["starting", "unhealthy"], 600)
        self.assertIn("RESULT=fail", out)
        self.assertIn("not waiting any longer", out)

    def test_exited_stops_at_once(self):
        self.assertIn("RESULT=fail", self.run_wait(["exited"], 600))

    def test_progress_every_30s(self):
        out = self.run_wait(["starting"] * 20 + ["running+healthy"], 600)
        self.assertIn("waiting 30s/600s", out)
        self.assertIn("RESULT=ok", out)

    def test_keeps_restarting(self):
        out = self.run_wait(["restarting"], 600)
        self.assertIn("keeps restarting", out)
        self.assertIn("RESULT=fail", out)

    def test_limit_reached(self):
        self.assertIn("RESULT=fail", self.run_wait(["starting"], 60))

    def test_already_up_check_is_quiet(self):
        out = self.run_wait(["unhealthy"], 0)
        self.assertIn("RESULT=fail", out)
        self.assertNotIn("not waiting", out)


if __name__ == "__main__":
    unittest.main()
