<#
.SYNOPSIS
  Install the PATCH-01 agent on many Windows servers at once, over WinRM.

.DESCRIPTION
  Run from an administrator's workstation or jump host with WinRM access to
  the servers. Each server gets its own single-use token from a file made on
  PATCH-01 (./scripts/phase10-windows.sh --tokens 50 > tokens.txt). Each server
  runs the self-test first and is only enrolled if every step passes.

.EXAMPLE
  .\push-agent.ps1 -Computers servers.txt -Tokens tokens.txt -Server https://patch01.example -Pin <sha256>
  .\push-agent.ps1 -Computers servers.txt -Server https://patch01.example -Pin <sha256> -TestOnly
  .\push-agent.ps1 -Computers servers.txt -Server https://patch01.example -Pin <old>,<new> -Repin
#>
param(
    [Parameter(Mandatory = $true)][string]$Computers,
    [string]$Tokens,
    [Parameter(Mandatory = $true)][string]$Server,
    [Parameter(Mandatory = $true)][string]$Pin,
    [switch]$TestOnly,
    [switch]$Repin,
    [pscredential]$Credential
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$names = @(Get-Content $Computers | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith("#") })
$toks = @()
if (-not $TestOnly -and -not $Repin) {
    if (-not $Tokens) { throw "Give -Tokens (one per line, from phase10-windows.sh --tokens N), or use -TestOnly." }
    $toks = @(Get-Content $Tokens | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    if ($toks.Count -lt $names.Count) { throw ("{0} servers but only {1} tokens." -f $names.Count, $toks.Count) }
}
$results = @()
$i = 0
foreach ($c in $names) {
    $row = [pscustomobject]@{ Server = $c; Result = ""; Detail = "" }
    try {
        $sp = @{ ComputerName = $c }
        if ($Credential) { $sp["Credential"] = $Credential }
        $s = New-PSSession @sp
        try {
            # A new folder that only SYSTEM and Administrators can write, under Program Files (admin-only),
            # with a random name: never a folder an ordinary user could have made or changed first
            $setup = Invoke-Command -Session $s -ScriptBlock {
                $root = Join-Path $env:ProgramFiles "PatchAgent-Setup"
                if (-not (Test-Path -LiteralPath $root)) { New-Item -ItemType Directory -Path $root | Out-Null }
                $d = Join-Path $root ("push-" + [guid]::NewGuid().ToString("N"))
                New-Item -ItemType Directory -Path $d -ErrorAction Stop | Out-Null
                $acl = New-Object Security.AccessControl.DirectorySecurity
                $acl.SetAccessRuleProtection($true, $false)
                foreach ($sid in @("S-1-5-18", "S-1-5-32-544")) {
                    $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule((New-Object Security.Principal.SecurityIdentifier($sid)),
                        "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")))
                }
                $acl.SetOwner((New-Object Security.Principal.SecurityIdentifier("S-1-5-32-544")))
                Set-Acl -LiteralPath $d -AclObject $acl
                $d
            }
            if (-not ([string]$setup -match '\\PatchAgent-Setup\\push-[0-9a-f]{32}$')) { throw "could not make a private setup folder on the server" }
            # release-signing.pub and allowed-publishers.txt beside this script are pinned by install-agent.ps1
            foreach ($f in "patch-agent.ps1", "install-agent.ps1", "release-signing.pub", "allowed-publishers.txt") {
                if (-not (Test-Path -LiteralPath (Join-Path $Here $f))) { continue }
                Copy-Item -ToSession $s -Path (Join-Path $Here $f) -Destination (Join-Path $setup $f) -Force
            }
            if ($Repin) {
                $out = Invoke-Command -Session $s -ScriptBlock {
                    param($d, $pin)
                    & (Join-Path $d "install-agent.ps1") -Repin -Pin $pin 2>&1 | Out-String
                } -ArgumentList $setup, $Pin
                $row.Result = if ($out -match "Re-pinned and checked") { "re-pinned" } else { "check" }
                $row.Detail = ($out -split "`n" | Where-Object { $_ -match "pin|failed|error" } | Select-Object -First 2) -join " "
                Invoke-Command -Session $s -ScriptBlock { param($d) Remove-Item -LiteralPath $d -Recurse -Force -ErrorAction SilentlyContinue } -ArgumentList $setup
                $results += $row
                Write-Host ("{0,-28} {1,-16} {2}" -f $row.Server, $row.Result, $row.Detail)
                continue
            }
            $test = Invoke-Command -Session $s -ScriptBlock {
                param($d, $srv, $pin)
                & (Join-Path $d "install-agent.ps1") -Server $srv -Pin $pin -SelfTest | Out-String
            } -ArgumentList $setup, $Server, $Pin
            if ($test -notmatch "All steps passed") {
                $row.Result = "self-test failed"; $row.Detail = ($test -split "`n" | Where-Object { $_ -match "FAILED" }) -join "; "
            } elseif ($TestOnly) {
                $row.Result = "ready"
            } else {
                $tok = $toks[$i]; $i++
                $out = Invoke-Command -Session $s -ScriptBlock {
                    param($d, $srv, $pin, $t)
                    & (Join-Path $d "install-agent.ps1") -Server $srv -Pin $pin -Token $t | Out-String
                } -ArgumentList $setup, $Server, $Pin, $tok
                $row.Result = if ($out -match "Installed\.") { "installed" } else { "check" }
                $row.Detail = ($out -split "`n" | Where-Object { $_ -match "Enrolled|Installed|failed" }) -join " "
            }
            Invoke-Command -Session $s -ScriptBlock { param($d) Remove-Item -LiteralPath $d -Recurse -Force -ErrorAction SilentlyContinue } -ArgumentList $setup
        } finally { Remove-PSSession $s }
    } catch { $row.Result = "error"; $row.Detail = $_.Exception.Message }
    $results += $row
    Write-Host ("{0,-28} {1,-16} {2}" -f $row.Server, $row.Result, $row.Detail)
}
$results | Export-Csv -NoTypeInformation -Path (Join-Path $Here ("push-results-" + (Get-Date -Format "yyyyMMdd-HHmm") + ".csv"))
Write-Host ("Done: {0} installed, {1} ready, {2} need attention. Results saved beside this script." -f `
    @($results | Where-Object Result -eq "installed").Count, @($results | Where-Object Result -eq "ready").Count,
    @($results | Where-Object { $_.Result -notin "installed", "ready", "re-pinned" }).Count)
