#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# AI-01 : start the model server and nginx, repair what does not come up, check health
#
# Usage:
#   sudo ./ai01-start.sh                  start (or confirm) both, then health check
#   sudo ./ai01-start.sh --install-boot   also do this at every boot (systemd service)
#   sudo ./ai01-start.sh --remove-boot    stop doing it at boot
#
# Order: llama-server first (it takes a few minutes to load the model), then
# nginx in front of it. Each is enabled at boot if it was not. A service that
# does not come up is restarted once; if it still fails, the start stops and
# says why: the last lines of its log, and for llama-server whether the binary
# still runs on this OS (an OS update can change the libraries it was built
# against: then rebuild it, see ai01-setup.sh). nginx is only (re)started with
# a configuration that passes nginx -t. Then the full health check runs
# (ai01-update.sh). Nothing secret is printed; the log is root-only.
#
# At boot (--boot, from the service) it also waits for another start or the
# health check after an update restart (ai01-postboot-check) instead of
# failing, and undoes hardening steps that were applied but never kept
# (ai01-harden.sh --undo-pending: their undo timers do not survive a reboot).
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 077
export LC_ALL=C

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
HERE="$(dirname "$SELF")"
# The AI01_* overrides exist for the test suite (tests/run-tests.sh); on AI-01 the defaults are right
BASE="${AI01_BASE:-/llm}"
LOG_DIR=$BASE/logs
BIN_DIR=$BASE/bin
LISTEN_PORT="${AI01_LISTEN_PORT:-8080}"
UNIT="ai01-start"
LOCK_DIR="${AI01_LOCK_DIR:-/run}"
LOCK="$LOCK_DIR/ai01-start.lock"
MODEL_WAIT="${AI01_START_WAIT:-600}"     # seconds for the model to load, per try
LOCK_WAIT="${AI01_START_LOCK_WAIT:-1800}"

HEALTH=yes; INSTALL=no; REMOVE=no; BOOT=no; WAIT_LOCK=no
while (($#)); do
  case "$1" in
    --no-health)    HEALTH=no ;;
    --install-boot) INSTALL=yes ;;
    --remove-boot)  REMOVE=yes ;;
    --boot)         BOOT=yes; WAIT_LOCK=yes ;;
    --wait-lock)    WAIT_LOCK=yes ;;     # ai01-update.sh --post-boot: wait for a start already running
    -h|--help)      sed -n '2,24p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done
[[ $EUID -eq 0 ]] || { echo "Run as root." >&2; exit 1; }

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/ai01-start-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"
log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }

safe_path() {
  [[ "$(stat -c %u "$1")" == 0 ]] || die "$1 is not owned by root: refusing to run from it as root."
  (( ( 8#$(stat -c %a "$1") & 8#022 ) == 0 )) || die "$1 is writable by others than root: fix with chmod go-w $1"
}
d="$HERE"; while [[ "$d" != / ]]; do safe_path "$d"; d="$(dirname "$d")"; done
for f in "$SELF" "$HERE"/*.sh; do [[ -e "$f" ]] && safe_path "$f"; done

if [[ "$BOOT" == yes && -x "$HERE/ai01-harden.sh" ]]; then
  # First, before starting anything: hardening steps applied but never kept (their undo timers did
  # not survive the reboot). One of them may be what stops llama-server or nginx from starting.
  # Run before this script takes its own lock, which ai01-harden.sh waits for.
  step "Hardening steps left pending"
  if "$HERE/ai01-harden.sh" --undo-pending </dev/null >>"$LOG_FILE" 2>&1; then say "  none left (or undone now)"
  else warn "ai01-harden.sh --undo-pending reported a problem (details in $LOG_FILE); starting anyway"; fi
fi

exec 8>"$LOCK"
if [[ "$WAIT_LOCK" == yes ]]; then
  # At boot this service and the post-update health check start together: one waits for the other
  flock -w "$LOCK_WAIT" 8 || die "Another ai01-start.sh is still running after $LOCK_WAIT s."
else
  flock -n 8 || die "Another ai01-start.sh is running."
fi

if [[ "$REMOVE" == yes ]]; then
  systemctl disable --now "$UNIT.service" >/dev/null 2>&1 || true
  rm -f "/etc/systemd/system/$UNIT.service"; systemctl daemon-reload
  say "Removed: AI-01 no longer checks itself at boot (llama-server and nginx still start on their own)."
  exit 0
fi
if [[ "$INSTALL" == yes ]]; then
  cat > "/etc/systemd/system/$UNIT.service" <<EOF
[Unit]
Description=AI-01: start llama-server and nginx, repair, health check
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=$SELF --boot
TimeoutStartSec=1800
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
  chmod 0644 "/etc/systemd/system/$UNIT.service"
  systemctl daemon-reload; systemctl enable "$UNIT.service" >/dev/null 2>&1
  say "Installed: at every boot AI-01 starts and checks itself (result: systemctl status $UNIT)."
  say "Running it once now:"
fi

ready() { curl -sf --max-time 5 "http://127.0.0.1:$LISTEN_PORT/health" >/dev/null 2>&1; }
wait_model() {   # the model takes a while to load
  local t=0
  while (( t <= $1 )); do ready && return 0; sleep 10; t=$((t + 10)); done
  return 1
}
LLAMA_EXE=""; LLAMA_LIBS=""
find_llama_binary() {   # the real llama-server binary, not the wrapper script systemd starts
  local exe; exe="$(systemctl show -p ExecStart --value llama-server 2>/dev/null | grep -oE 'path=[^ ;]+' | head -1 | cut -d= -f2)"
  [[ -n "$exe" ]] || exe="$BASE/config/run-llama-server.sh"
  LLAMA_LIBS=""
  if [[ -f "$exe" ]] && head -c 2 "$exe" 2>/dev/null | grep -q '^#!'; then
    # ai01-setup.sh's run-llama-server.sh: the binary is on its exec line, its libraries in LD_LIBRARY_PATH
    LLAMA_LIBS="$(awk -F= '/^export LD_LIBRARY_PATH=/{gsub(/"/,"",$2); print $2; exit}' "$exe" 2>/dev/null || true)"
    exe="$(awk '/^exec /{gsub(/"/,"",$2); print $2; exit}' "$exe" 2>/dev/null || true)"
    [[ -n "$exe" ]] || exe="$BIN_DIR/llama-server"
  fi
  LLAMA_EXE="$(readlink -f "$exe" 2>/dev/null || true)"
}
binary_runs() {  # does llama-server still load its libraries after an OS update? (0: yes, or cannot tell)
  find_llama_binary
  [[ -n "$LLAMA_EXE" && -f "$LLAMA_EXE" ]] || return 2
  ! LD_LIBRARY_PATH="${LLAMA_LIBS:-$(dirname "$LLAMA_EXE")}" ldd "$LLAMA_EXE" 2>&1 | grep -q 'not found'
}

RC=0
# Stop at the first part that does not come up: nginx and the health check are no use without it
stop_here() {
  say ""
  say "STOPPED: $1"
  say "Nothing after it was started or checked. Log: $LOG_FILE"
  log "FATAL: $1"
  exit 1
}
# ---------------------------------------------------------------------------
step "llama-server"
systemctl is-enabled --quiet llama-server 2>/dev/null || { systemctl enable llama-server >/dev/null 2>&1; say "  enabled at boot (it was not)"; }
if ready; then say "  already up"
else
  systemctl start llama-server || true
  if wait_model "$MODEL_WAIT"; then say "  up"
  else
    warn "llama-server did not answer within $(( MODEL_WAIT / 60 )) minutes: restarting it once"
    systemctl restart llama-server || true
    if wait_model "$MODEL_WAIT"; then say "  up after a restart"
    else
      journalctl -u llama-server --no-pager -n 40 >>"$LOG_FILE" 2>&1 || true
      tail -n 40 "$LOG_DIR/llama-server.log" >>"$LOG_FILE" 2>/dev/null || true
      brc=0; binary_runs || brc=$?
      if (( brc == 1 )); then
        say "  llama-server cannot load its libraries any more (an OS update changed them):"
        LD_LIBRARY_PATH="${LLAMA_LIBS:-$(dirname "$LLAMA_EXE")}" ldd "$LLAMA_EXE" 2>&1 | grep 'not found' | head -5 | sed 's/^/    /' | tee -a "$LOG_FILE" || true
        say "  rebuild it on this server (see ai01-setup.sh, 'Finding llama-server'), then run ai01-setup.sh again."
      elif (( brc == 2 )); then
        say "  the llama-server binary is missing (${LLAMA_EXE:-not found}): run ai01-setup.sh again."
      else
        say "  llama-server does not start: its last messages are in $LOG_FILE"
      fi
      stop_here "llama-server is not up, even after a restart."
    fi
  fi
fi

# ---------------------------------------------------------------------------
step "nginx"
systemctl is-enabled --quiet nginx 2>/dev/null || { systemctl enable nginx >/dev/null 2>&1; say "  enabled at boot (it was not)"; }
if ! nginx -t >>"$LOG_FILE" 2>&1; then
  say "  nginx's configuration does not pass nginx -t: not (re)started. Details in $LOG_FILE."
  say "  ai01-setup.sh writes a fresh one (run it with the same --patch01-ip as at install)."
  stop_here "nginx's configuration does not pass nginx -t."
elif systemctl is-active --quiet nginx; then say "  already up"
else
  systemctl start nginx || true
  sleep 2
  if systemctl is-active --quiet nginx; then say "  up"
  else
    systemctl restart nginx || true; sleep 2
    if systemctl is-active --quiet nginx; then say "  up after a restart"
    else journalctl -u nginx --no-pager -n 30 >>"$LOG_FILE" 2>&1 || true; say "  nginx does not start: see $LOG_FILE"
         stop_here "nginx is not up, even after a restart."; fi
  fi
fi

say ""
say "Both are up."

# The health check takes ai01-update.sh's lock: this one is released first, so a script that holds
# that lock and waits for this one (ai01-update.sh --post-boot) never waits forever
exec 8>&-

if [[ "$HEALTH" == yes ]]; then
  step "Health check"
  HC_ARGS=(); [[ "$BOOT" == yes ]] && HC_ARGS=(--wait-lock)
  "$HERE/ai01-update.sh" "${HC_ARGS[@]}" </dev/null || RC=1
fi
exit "$RC"
