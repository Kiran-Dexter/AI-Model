#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# AI-01 : harden the model server, one step at a time, without breaking the portal
#
# Every step works the same way:
#   1. shows what is in place now, and does nothing if the step is already done
#   2. asks before changing anything
#   3. backs up every file it will touch
#   4. applies the change
#   5. tests the path the portal uses (HTTPS, API key, a real answer from the
#      model) plus the step's own tests
#   6. if any test fails, puts the backed-up files back, restarts what it
#      restarted, and checks the portal path works again
#
# Steps that depend on PATCH-01 (TLS 1.3 only, client certificates) are split
# in two: the first half only records what PATCH-01 does; the second half
# refuses to start until the record shows PATCH-01 is ready for it.
# The firewall step undoes itself after a few minutes unless you confirm you
# can still log in.
#
# Usage:
#   ./ai01-harden.sh                   menu
#   ./ai01-harden.sh --step <name>     one step (names: see the menu)
#   ./ai01-harden.sh --check           run every test, change nothing
#   ./ai01-harden.sh --check --deep    also the rate-limit burst test
#   ./ai01-harden.sh --status          which steps are done
#   ./ai01-harden.sh --rollback <name> put one step's files back
#   ./ai01-harden.sh --rollback-all    every step, newest first (the API key is kept)
#   ./ai01-harden.sh --undo-pending    undo every step applied but never kept (a run that
#                                      ended half way); ai01-start.sh --boot runs it
#
# Steps "tls13" and "mtls-enforce" are only kept once PATCH-01's own requests
# succeed under them (run ./scripts/ai01-client.sh --test on PATCH-01 while
# this script waits); otherwise they undo themselves, also if this session is
# lost (a systemd timer). A step is marked pending (hardening/pending/<step>)
# before it changes anything and unmarked once kept or undone: a pending step
# left by a run that ended (session lost, timer lost in a reboot, timer that
# could not get the lock) is undone by the next run of this script (any mode)
# once the confirmation window has passed, and by ai01-start.sh --boot.
#
# Run as root on AI-01, after ai01-setup.sh. Safe to run again at any time.
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 077

VERSION="1.0"

# Paths. The AI01_* overrides exist for the test suite (tests/run-tests.sh);
# on AI-01 the defaults are right.
BASE="${AI01_BASE:-/llm}"
CONF_DIR="$BASE/config"
CERT_DIR="$BASE/certs"
LOG_DIR="$BASE/logs"
MODEL_DIR="$BASE/models"
CACHE_DIR="$BASE/cache"
STATE_DIR="$BASE/hardening"
ARGS_FILE="$CONF_DIR/llama-server.args"
RUN_SCRIPT="$CONF_DIR/run-llama-server.sh"
KEY_FILE="$CONF_DIR/api-key"
HARDEN_ENV="$CONF_DIR/hardening.env"
SVC_USER="${AI01_SVC_USER:-llm}"
LISTEN_PORT="${AI01_LISTEN_PORT:-8080}"
LLAMA_URL="http://127.0.0.1:$LISTEN_PORT"
FRONT="${AI01_FRONT_URL:-https://127.0.0.1}"
NGINX_CONF="${AI01_NGINX_CONF:-/etc/nginx/conf.d/ai01-llm.conf}"
NGINX_HTTP_SNIPPET="${AI01_NGINX_HTTP_SNIPPET:-/etc/nginx/conf.d/ai01-00-hardening.conf}"
NGINX_SNIP_DIR="${AI01_NGINX_SNIP_DIR:-/etc/nginx/ai01-hardening.d}"
NGINX_LOG_DIR="${AI01_NGINX_LOG_DIR:-/var/log/nginx}"
SEC_LOG="$NGINX_LOG_DIR/ai01-security.log"
SYSTEMD_DIR="${AI01_SYSTEMD_DIR:-/etc/systemd/system}"
DROPIN="$SYSTEMD_DIR/llama-server.service.d/50-hardening.conf"
NFT_FILE="${AI01_NFT_FILE:-/etc/nftables/ai01-harden.nft}"
NFT_MAIN="${AI01_NFT_MAIN:-/etc/sysconfig/nftables.conf}"
LOGROTATE_FILE="${AI01_LOGROTATE_FILE:-/etc/logrotate.d/ai01-llm}"
LLAMA_WAIT="${AI01_LLAMA_WAIT:-300}"           # seconds for the model to load
FW_UNDO_SECS="${AI01_FW_UNDO_SECS:-300}"       # firewall undoes itself after this
CHAT_TIMEOUT="${AI01_CHAT_TIMEOUT:-180}"
CONFIRM_WAIT="${AI01_CONFIRM_WAIT:-600}"       # seconds to see PATCH-01 succeed after tls13 / mtls-enforce
SELF="$(readlink -f "${BASH_SOURCE[0]}")"
SETUP="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/ai01-setup.sh"

STEPS=(observe llama tls13 ratelimit mtls mtls-enforce firewall model logs key-rotate swap disk)

# ---------------------------------------------------------------------------
# Output and questions
# ---------------------------------------------------------------------------
MODE=menu; ONE_STEP=""; DEEP=no; RB_STEP=""; RB_DIR=""
while (($#)); do
  case "$1" in
    --step)          MODE=step; ONE_STEP="${2:-}"; shift ;;
    --check)         MODE=check ;;
    --deep)          DEEP=yes ;;
    --status)        MODE=status ;;
    --rollback)      MODE=rollback; RB_STEP="${2:-}"; shift ;;
    --rollback-all)  MODE=rollback-all ;;
    --auto-undo)     MODE=auto-undo; RB_STEP="${2:-}"; RB_DIR="${3:-}"; shift 2 ;;   # from the undo timer
    --undo-pending)  MODE=undo-pending ;;                                             # ai01-start.sh --boot
    -h|--help)       sed -n '2,39p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1 (see --help)" >&2; exit 2 ;;
  esac
  shift
done

[[ $EUID -eq 0 ]] || { echo "Run as root." >&2; exit 1; }
[[ -d "$BASE" ]] || { echo "$BASE does not exist: run ai01-setup.sh first." >&2; exit 1; }

mkdir -p "$STATE_DIR/backups" "$STATE_DIR/steps" "$STATE_DIR/export" "$STATE_DIR/pending" "$LOG_DIR"
chmod 0700 "$STATE_DIR" "$STATE_DIR/backups" "$STATE_DIR/steps" "$STATE_DIR/export" "$STATE_DIR/pending"
RUNLOG="$STATE_DIR/harden-$(date +%Y%m%d-%H%M%S).log"
: >"$RUNLOG"; chmod 0600 "$RUNLOG"

log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$RUNLOG"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
hdr()  { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$RUNLOG" >&2; exit 1; }

# Answers come from the terminal. The test suite gives them in a file instead
# (AI01_INPUT_FILE, one answer per line); fd 3 keeps its place across subshells.
if [[ -n "${AI01_INPUT_FILE:-}" ]]; then exec 3<"$AI01_INPUT_FILE"
elif [[ "$MODE" =~ ^(menu|step|rollback|rollback-all)$ && ! -t 0 ]]; then
  die "Not a terminal: this script asks before each change. Run it from an SSH session."
fi
answer() {   # answer "prompt" -> the reply on stdout
  local r=""
  if [[ -n "${AI01_INPUT_FILE:-}" ]]; then
    IFS= read -r r <&3 || r=""; printf '%s %s\n' "$1" "$r" >&2
  elif [[ -t 0 ]]; then
    read -r -p "$1 " r || true
  else
    die "Not a terminal: this script asks before each change."
  fi
  printf '%s' "$r"
}
ask() {   # ask "question" -> 0 for yes
  local r; r="$(answer "$1 [y/N]:")"
  log "ASK: $1 -> $r"
  [[ "${r,,}" =~ ^(y|yes)$ ]]
}
read_line() {   # read_line "prompt" -> the answer
  local r; r="$(answer "$1")"
  log "READ: $1 -> $r"
  printf '%s' "$r"
}

# One run at a time, and never while ai01-update.sh or ai01-start.sh runs
LOCK_DIR="${AI01_LOCK_DIR:-/run}"
# An undo (the timer's, or at boot) waits its turn rather than giving up: a menu left
# open or an update running only delays it. If it still cannot run, the change stays
# marked pending and the next run of this script, or the next boot, undoes it.
LOCK_WAIT=0
[[ "$MODE" =~ ^(auto-undo|undo-pending)$ ]] && LOCK_WAIT="${AI01_UNDO_LOCK_WAIT:-1800}"
exec 7>"$LOCK_DIR/ai01-harden.lock"
if (( LOCK_WAIT > 0 )); then
  flock -w "$LOCK_WAIT" 7 || die "$MODE: ai01-harden.sh still running after $LOCK_WAIT s; the pending change is undone by its next run or at boot."
else
  flock -n 7 || die "Another ai01-harden.sh is running."
fi
# Held for the whole run, so ai01-update.sh and ai01-start.sh cannot restart
# nginx or llama-server in the middle of a step (they refuse while it is held)
for other in ai01-update ai01-start; do
  exec {fd}>>"$LOCK_DIR/$other.lock"
  if (( LOCK_WAIT > 0 )); then
    flock -w "$LOCK_WAIT" "$fd" || die "$MODE: $other.sh still running after $LOCK_WAIT s; the pending change is undone by the next run of ai01-harden.sh or at boot."
  else
    flock -n "$fd" || die "$other.sh is running: wait for it to finish."
  fi
done

# ---------------------------------------------------------------------------
# Facts about this AI-01
# ---------------------------------------------------------------------------
api_key() { awk 'NF {print; exit}' "$KEY_FILE" 2>/dev/null || true; }
patch01_ip() { awk '$1=="allow" {gsub(";","",$2); if ($2!="127.0.0.1" && $2!="::1") {print $2; exit}}' "$NGINX_CONF" 2>/dev/null || true; }
llama_bin() {   # the binary run-llama-server.sh starts, and its library folder
  local b; b="$(awk '/^exec /{gsub(/"/,"",$2); print $2; exit}' "$RUN_SCRIPT" 2>/dev/null || true)"
  printf '%s' "${b:-$BASE/bin/llama-server}"
}
llama_libdir() { awk -F= '/^export LD_LIBRARY_PATH=/{gsub(/"/,"",$2); print $2; exit}' "$RUN_SCRIPT" 2>/dev/null || true; }
LLAMA_HELP=""
llama_supports() {   # llama_supports --flag
  [[ -n "$LLAMA_HELP" ]] || LLAMA_HELP="$(LD_LIBRARY_PATH="$(llama_libdir)" "$(llama_bin)" --help 2>&1 || true)"
  printf '%s' "$LLAMA_HELP" | grep -qE -- "(^|[ ,])$1([ ,=]|$)"
}
has_arg() { grep -qxF -- "$1" "$ARGS_FILE" 2>/dev/null; }
llama_pid() { systemctl show -p MainPID --value llama-server 2>/dev/null || echo 0; }
model_file() {   # the model llama-server runs (the value after -m), else the first .gguf
  local m; m="$(awk 'p {print; exit} $0=="-m" || $0=="--model" {p=1}' "$ARGS_FILE" 2>/dev/null || true)"
  [[ -n "$m" && -f "$m" ]] && { printf '%s' "$m"; return; }
  find "$MODEL_DIR" -maxdepth 2 -name '*.gguf' -type f 2>/dev/null | sort | head -1
}

# ---------------------------------------------------------------------------
# The portal's path: HTTPS on the front door, the API key, a real answer
# ---------------------------------------------------------------------------
TMPD="$(mktemp -d)"; trap 'rm -rf "$TMPD"' EXIT

front_code() {   # front_code <path> [curl options...]
  local p="$1" c; shift
  c="$(curl -sk --noproxy '*' -o "$TMPD/body" -w '%{http_code}' --max-time 20 "$@" "$FRONT$p" 2>/dev/null || true)"
  printf '%s' "${c:-000}"   # curl itself prints 000 when it cannot connect
}
chat_code() {   # chat_code <key> [content] -> http code, body in $TMPD/body
  local key="$1" content="${2:-Reply with the single word ok.}"
  local body
  body="$(printf '{"messages":[{"role":"user","content":"%s"}],"max_tokens":4,"temperature":0,"chat_template_kwargs":{"enable_thinking":false}}' "$content")"
  local c
  # the key goes in a header file (TMPD is 0700), never on curl's command line
  printf 'Authorization: Bearer %s\n' "$key" >"$TMPD/auth"
  c="$(curl -sk --noproxy '*' -o "$TMPD/body" -w '%{http_code}' --max-time "$CHAT_TIMEOUT" \
    -H @"$TMPD/auth" -H 'Content-Type: application/json' \
    -d "$body" "$FRONT/v1/chat/completions" 2>/dev/null || true)"
  printf '%s' "${c:-000}"
}
wait_llama() {
  local i
  for ((i = 0; i < LLAMA_WAIT; i++)); do
    curl -sf --noproxy '*' --max-time 5 "$LLAMA_URL/health" >/dev/null 2>&1 && return 0
    if ! systemctl is-active --quiet llama-server; then
      warn "llama-server stopped. Last log lines:"; tail -15 "$LOG_DIR/llama-server.log" >&2 2>/dev/null || true
      return 1
    fi
    sleep 1
  done
  return 1
}
portal_ok() {   # the request PATCH-01 makes, end to end through nginx
  local code k; k="$(api_key)"
  [[ -n "$k" ]] || { say "  FAIL  no API key in $KEY_FILE"; return 1; }
  code="$(front_code /health)"
  [[ "$code" == 200 ]] || { say "  FAIL  HTTPS /health returned $code"; return 1; }
  code="$(chat_code "$k")"
  if [[ "$code" == 200 ]] && grep -q '"choices"' "$TMPD/body"; then
    say "  ok    portal path: HTTPS, API key and an answer from the model"
    return 0
  fi
  say "  FAIL  portal path: chat returned $code"
  return 1
}

# ---------------------------------------------------------------------------
# Backups and rollback. Each step backs up into its own folder, with a
# manifest of what existed before, so a rollback also removes files the step
# created.
# ---------------------------------------------------------------------------
BK=""
begin_backup() {   # begin_backup <step>
  local free; free="$(df -Pk "$STATE_DIR" | awk 'NR==2 {print $4}')"
  (( ${free:-0} > 51200 )) || die "Less than 50 MB free for backups in $STATE_DIR: nothing changed."
  BK="$STATE_DIR/backups/$(date +%Y%m%d-%H%M%S%N)-$1"
  mkdir -p "$BK/files"; : >"$BK/manifest"
  log "backup folder $BK"
}
abort_step() {   # a backup failed: put back what this step changed so far, then stop
  warn "$1"
  restore_files "$BK" || true
  touch "$BK/undone"
  local s="${BK##*/}"; s="$(cut -d- -f3- <<<"$s")"
  [[ -n "$s" ]] && clear_pending "$s"
  nginx -t >>"$RUNLOG" 2>&1 && systemctl reload nginx >>"$RUNLOG" 2>&1 || true
  die "Stopped before changing anything else: $1"
}
backup() {   # backup <file>... (call before changing a file)
  local f
  for f in "$@"; do
    grep -qxF "$f" <(cut -f1 "$BK/manifest") 2>/dev/null && continue
    if [[ -e "$f" ]]; then
      mkdir -p "$BK/files$(dirname "$f")" && cp -a "$f" "$BK/files$f" \
        || abort_step "could not back up $f"
      printf '%s\t1\n' "$f" >>"$BK/manifest"
    else
      printf '%s\t0\n' "$f" >>"$BK/manifest"
    fi
  done
}
file_sum() { [[ -e "$1" ]] && sha256sum "$1" | awk '{print $1}' || echo -; }
record_after() {   # after a step is kept: what its files look like, to spot later changes
  local f had
  : >"$BK/after"
  while IFS=$'\t' read -r f had; do printf '%s\t%s\n' "$f" "$(file_sum "$f")" >>"$BK/after"; done <"$BK/manifest"
}
RESTORE_SKIP=""   # a file never restored (rollback-all keeps the API key)
restore_files() {   # restore_files <backup folder>: 0 if everything was put back
  local d="$1" f had rc=0 want
  [[ -f "$d/manifest" ]] || return 0
  while IFS=$'\t' read -r f had; do
    [[ -n "$f" ]] || continue
    if [[ -n "$RESTORE_SKIP" && "$f" == "$RESTORE_SKIP" ]]; then say "  kept $f"; continue; fi
    # Changed since the step was kept (ai01-setup.sh, a person)? Do not overwrite it.
    want="$(awk -F'\t' -v f="$f" '$1==f {print $2}' "$d/after" 2>/dev/null)"
    if [[ -n "$want" && "$want" != "$(file_sum "$f")" ]]; then
      warn "$f changed after this step was applied: left as it is. Put it back by hand from $d/files$f if needed."
      rc=1; continue
    fi
    chattr -i "$f" 2>/dev/null || true
    if [[ "$had" == 1 ]]; then
      { mkdir -p "$(dirname "$f")" && cp -a "$d/files$f" "$f"; } || { warn "could not restore $f"; rc=1; continue; }
    else
      rm -f "$f" || { warn "could not remove $f"; rc=1; continue; }
    fi
    log "restored $f (existed=$had)"
  done <"$d/manifest"
  # Settings in hardening.env: only the keys this step set go back to their old value
  if [[ -f "$d/env" && -f "$HARDEN_ENV" ]]; then
    local k v
    while IFS=$'\t' read -r k v; do
      [[ "$k" =~ ^[A-Z0-9_]+$ ]] || continue
      sed -i "/^$k=/d" "$HARDEN_ENV"
      [[ "$v" == __UNSET__ ]] || printf '%s=%s\n' "$k" "$v" >>"$HARDEN_ENV"
    done <"$d/env"
  fi
  return "$rc"
}
latest_backup() {   # the newest backup of a step that was KEPT (has "after") and not undone since
  local d
  for d in $(find "$STATE_DIR/backups" -mindepth 1 -maxdepth 1 -type d -name "*-$1" 2>/dev/null | sort -r); do
    [[ -f "$d/after" && ! -e "$d/undone" ]] && { printf '%s' "$d"; return 0; }
  done
  return 0
}
mark_done()   { printf 'done=%s\nbackup=%s\n%s\n' "$(date -Is)" "$BK" "${2:-}" >"$STATE_DIR/steps/$1"; }
mark_undone() { rm -f "$STATE_DIR/steps/$1"; }
is_done()     { [[ -f "$STATE_DIR/steps/$1" ]]; }
step_note()   { sed -n '3p' "$STATE_DIR/steps/$1" 2>/dev/null || true; }

# Pending: applied, not yet kept. Written before a step changes anything, removed
# when it is kept or undone. Survives a lost session and a reboot.
PENDING_DIR="$STATE_DIR/pending"
PENDING_MAX_AGE="${AI01_PENDING_MAX_AGE:-$(( CONFIRM_WAIT + 120 ))}"   # the undo timer's own delay
boot_id() { cat /proc/sys/kernel/random/boot_id 2>/dev/null || echo unknown; }
is_pending() { [[ -f "$PENDING_DIR/$1" ]]; }
pending_get() { sed -n "s/^$2=//p" "$PENDING_DIR/$1" 2>/dev/null | head -1; }
set_pending() {   # set_pending <step>: before the step's first change ($BK is its backup)
  printf 'backup=%s\nat=%s\nboot=%s\nwas_done=%s\n' "$BK" "$(date +%s)" "$(boot_id)" "${WAS_DONE:-no}" >"$PENDING_DIR/.$1.new" \
    && mv -f "$PENDING_DIR/.$1.new" "$PENDING_DIR/$1" || die "Could not write $PENDING_DIR/$1: nothing changed."
}
clear_pending() { rm -f "$PENDING_DIR/$1"; }
pending_stale() {   # its run is over: older than the confirmation window, or from before a reboot
  local at; at="$(pending_get "$1" at)"; [[ "$at" =~ ^[0-9]+$ ]] || at=0
  [[ "$(pending_get "$1" boot)" != "$(boot_id)" ]] || (( $(date +%s) - at >= PENDING_MAX_AGE ))
}
undo_pending() {   # undo_pending all|stale: put back steps applied but never kept
  local f s d rc=0
  for f in "$PENDING_DIR"/*; do
    [[ -f "$f" ]] || continue
    s="$(basename "$f")"
    [[ " ${STEPS[*]} " == *" $s "* ]] || { rm -f "$f"; continue; }
    [[ "$1" == all ]] || pending_stale "$s" || continue
    d="$(pending_get "$s" backup)"
    hdr "Undoing '$s': applied $(date -d "@$(pending_get "$s" at)" '+%F %T' 2>/dev/null || echo '?') but never kept (its run ended first)"
    if [[ -d "$d" && "$d" == "$STATE_DIR/backups/"* && "$d" != *..* ]]; then
      rollback_step "$s" "$d" pending || rc=1
    else
      warn "No backup folder for pending '$s' ($d): marker removed; check ./ai01-harden.sh --check"
      clear_pending "$s"; rc=1
    fi
  done
  return "$rc"
}
in_place() { ! is_pending "$1" && "status_${1//-/_}"; }   # a pending step is not in place

harden_env_set() {   # harden_env_set KEY value: remembered for ai01-setup.sh re-runs
  # The step's backup keeps this key's old value only, so rolling back one
  # step never removes what other steps wrote in the same file
  if ! grep -q "^$1	" "$BK/env" 2>/dev/null; then
    local old; old="$(grep "^$1=" "$HARDEN_ENV" 2>/dev/null | tail -1 | cut -d= -f2-)"
    printf '%s\t%s\n' "$1" "${old:-__UNSET__}" >>"$BK/env"
  fi
  touch "$HARDEN_ENV"
  sed -i "/^$1=/d" "$HARDEN_ENV"
  printf '%s="%s"\n' "$1" "$2" >>"$HARDEN_ENV"
  chown root:"$SVC_USER" "$HARDEN_ENV" 2>/dev/null || true; chmod 0640 "$HARDEN_ENV"
}

nginx_apply() {   # test the configuration, then reload
  if ! nginx -t >>"$RUNLOG" 2>&1; then
    say "  FAIL  nginx -t rejected the configuration"; tail -5 "$RUNLOG" | sed 's/^/        /'
    return 1
  fi
  systemctl reload nginx >>"$RUNLOG" 2>&1 || { say "  FAIL  nginx reload"; return 1; }
  sleep 1
}
llama_restart() {
  systemctl daemon-reload >>"$RUNLOG" 2>&1 || true
  systemctl restart llama-server >>"$RUNLOG" 2>&1 || { say "  FAIL  llama-server restart"; return 1; }
  say "  waiting for the model to load..."
  wait_llama || { say "  FAIL  llama-server did not become ready"; return 1; }
}

dependents() {   # steps that need <step>: they must be rolled back first
  case "$1" in
    observe) echo "ratelimit mtls tls13 mtls-enforce" ;;
    mtls) echo "mtls-enforce" ;;
  esac
}
dep_present() {   # done, pending, or its files still there (tls13 needs observe's log only)
  is_done "$1" || is_pending "$1" || { [[ "$1" != tls13 ]] && "status_${1//-/_}" 2>/dev/null; }
}
snapshot_files() {   # snapshot_files <backup folder>: the current state of its files -> a folder
  local d="$1" sn f
  sn="$(mktemp -d "$TMPD/snap.XXXXXX")"; mkdir -p "$sn/files"; : >"$sn/manifest"
  while IFS= read -r f; do
    [[ -n "$f" ]] || continue
    if [[ -e "$f" ]]; then
      mkdir -p "$sn/files$(dirname "$f")" && cp -a "$f" "$sn/files$f" && printf '%s\t1\n' "$f" >>"$sn/manifest"
    else
      printf '%s\t0\n' "$f" >>"$sn/manifest"
    fi
  done < <( { cut -f1 "$d/manifest" 2>/dev/null; [[ -f "$d/env" ]] && echo "$HARDEN_ENV"; } | sort -u)
  printf '%s' "$sn"
}
WAS_DONE=no
rollback_step() {   # rollback_step <step> [backup folder] [failed|pending]
  # failed: the run that applied it is undoing it now; pending: applied by a run that ended
  local s="$1" d="${2:-}" how="${3:-}" rc=0 dep keep_done=no snap=""
  if [[ -z "$d" ]]; then   # asked for by a person: not under a step that needs it
    for dep in $(dependents "$s"); do
      if dep_present "$dep"; then
        say "  '$dep' needs '$s': roll back '$dep' first (./ai01-harden.sh --rollback $dep)."
        return 1
      fi
    done
    if is_pending "$s"; then d="$(pending_get "$s" backup)"; how=pending
    else d="$(latest_backup "$s")"; fi
  fi
  [[ -n "$d" && -d "$d" ]] || { warn "No backup for step '$s'."; return 1; }
  # A re-run of a step that was already done, undone: the step stays done (its earlier change stays)
  if [[ "$how" == failed && "$WAS_DONE" == yes ]] || [[ "$how" == pending && "$(pending_get "$s" was_done)" == yes ]]; then
    keep_done=yes
  fi
  local conf_step=no
  case "$s" in observe|tls13|ratelimit|mtls|mtls-enforce) conf_step=yes ;; esac
  # What this rollback replaces, so one that would leave nginx's configuration broken is itself undone
  [[ "$conf_step" == yes && "$how" != failed ]] && snap="$(snapshot_files "$d")"
  say "  putting back the files of '$s' from $(basename "$d")"
  restore_files "$d" || rc=1
  case "$s" in
    llama|key-rotate) llama_restart || true ;;
    firewall)
      nft delete table inet ai01_harden >>"$RUNLOG" 2>&1 || true
      systemctl stop ai01-fw-undo.timer >>"$RUNLOG" 2>&1 || true ;;
    model) local m; for m in "$MODEL_DIR"/*.gguf "$MODEL_DIR/SHA256SUMS"; do [[ -e "$m" ]] && chattr -i "$m" 2>/dev/null; done; true ;;
  esac
  case "$s" in
    observe|tls13|ratelimit|mtls|mtls-enforce|llama|logs)
      if nginx -t >>"$RUNLOG" 2>&1; then systemctl reload nginx >>"$RUNLOG" 2>&1 || rc=1
      elif [[ -n "$snap" ]]; then
        # Never leave a configuration nginx refuses (it would not start again at the next boot)
        restore_files "$snap" || true
        warn "nginx -t fails with the files of '$s' put back (see $RUNLOG): they were put back as they were, '$s' stays in place. Fix the configuration (./ai01-harden.sh --check), then roll back again."
        return 1
      else warn "nginx -t fails after the rollback: nginx keeps its previous configuration until fixed (see $RUNLOG)."; rc=1; fi ;;
  esac
  systemctl stop "ai01-harden-undo-$s.timer" >>"$RUNLOG" 2>&1 || true
  touch "$d/undone"                  # never used again by a rollback
  clear_pending "$s"
  if [[ "$keep_done" == yes ]]; then say "  '$s' stays done: this was a re-run; what the step did before is still in place"
  else mark_undone "$s"; fi
  sleep 1
  if ! portal_ok; then warn "Rolled back '$s', but the portal path fails. Check ./ai01-setup.sh --check"; return 1; fi
  if (( rc )); then warn "Rolled back '$s' with problems (above); the portal path works."; return 1; fi
  say "  Rolled back '$s': the portal path works."
}

# run_step <name>: status -> question -> backup -> apply -> verify -> keep or undo
run_step() {
  local s="$1" fn="${1//-/_}"
  declare -F "status_$fn" >/dev/null || die "Unknown step: $s. Steps: ${STEPS[*]}"
  hdr "Step: $s"
  "info_$fn"
  if is_pending "$s"; then
    say "  '$s' was applied by a run that ended before it was kept: it is undone automatically"
    say "  (by its timer, the next run of this script after $(( PENDING_MAX_AGE / 60 )) minutes, or at boot)."
    say "  To undo it now: ./ai01-harden.sh --rollback $s"
    return 1
  fi
  if in_place "$s"; then say "  Already in place: nothing to do."; return 0; fi
  if declare -F "ready_$fn" >/dev/null && ! "ready_$fn"; then return 0; fi
  ask "  Apply step '$s'?" || { say "  Skipped."; return 0; }

  hdr "Checking the portal path before changing anything"
  portal_ok || die "The portal path already fails before any change. Fix that first (./ai01-setup.sh --check)."

  WAS_DONE=no; is_done "$s" && WAS_DONE=yes
  begin_backup "$s"
  set_pending "$s"
  local ok=yes
  hdr "Applying '$s'"
  "apply_$fn" || ok=no
  if [[ "$ok" == yes ]]; then
    hdr "Testing '$s'"
    portal_ok || ok=no
    if [[ "$ok" == yes ]] && declare -F "verify_$fn" >/dev/null; then "verify_$fn" || ok=no; fi
  fi
  if [[ "$ok" == yes ]]; then
    declare -F "commit_$fn" >/dev/null && { "commit_$fn" || ok=no; }
  fi
  if [[ "$ok" == yes ]]; then
    record_after
    [[ -f "$STATE_DIR/steps/$s" ]] || mark_done "$s"
    clear_pending "$s"
    say ""; say "  Step '$s' done. Backup: $BK"
    return 0
  fi
  hdr "A test failed: undoing '$s'"
  rollback_step "$s" "$BK" failed || true
  say "  Step '$s' was undone. Details: $RUNLOG"
  return 1
}

# ===========================================================================
# Step: observe. Record TLS version and client-certificate result per request
# ===========================================================================
info_observe() {
  say "  Adds a security log ($SEC_LOG) with, for each request: time, client"
  say "  address, path, status, TLS version and client-certificate result."
  say "  No request bodies, so no prompts. Needed before 'tls13' and 'mtls-enforce'."
  say "  Also adds the include line other steps use. Changes nothing for the portal."
}
include_line() { printf '    include %s/*.conf;' "$NGINX_SNIP_DIR"; }
status_observe() {
  [[ -f "$NGINX_HTTP_SNIPPET" && -f "$NGINX_SNIP_DIR/10-observe.conf" ]] \
    && grep -qF "include $NGINX_SNIP_DIR/*.conf;" "$NGINX_CONF"
}
write_http_snippet() {
  backup "$NGINX_HTTP_SNIPPET"
  cat >"$NGINX_HTTP_SNIPPET" <<'EOF'
# Managed by ai01-harden.sh. http-level pieces used by /etc/nginx/ai01-hardening.d
# One line per request; never the request body, so never a prompt
log_format ai01_sec '$time_iso8601 $remote_addr "$request" $status $ssl_protocol verify=$ssl_client_verify';
# Rate limit per client address (used by step 'ratelimit')
limit_req_zone $binary_remote_addr zone=ai01_req:1m rate=10r/s;
# Client certificate required except from AI-01 itself (step 'mtls-enforce');
# AI-01's own health checks (ai01-setup.sh --check, ai01-update.sh) use loopback
map "$remote_addr:$ssl_client_verify" $ai01_mtls_ok {
    default        0;
    "~^127\.0\.0\.1:" 1;
    "~^::1:"       1;
    "~:SUCCESS$"   1;
}
EOF
  chmod 0644 "$NGINX_HTTP_SNIPPET"
}
add_include() {
  grep -qF "include $NGINX_SNIP_DIR/*.conf;" "$NGINX_CONF" && return 0
  backup "$NGINX_CONF"
  local anchor='^[[:space:]]*server_tokens'
  grep -qE "$anchor" "$NGINX_CONF" || anchor='^[[:space:]]*server_name'
  grep -qE "$anchor" "$NGINX_CONF" || { say "  FAIL  no server_tokens or server_name line in $NGINX_CONF"; return 1; }
  awk -v a="$anchor" -v inc="$(include_line)" '{print} !done && $0 ~ a {print inc; done=1}' \
    "$NGINX_CONF" >"$TMPD/conf" && cat "$TMPD/conf" >"$NGINX_CONF"
  [[ "$(grep -cF "include $NGINX_SNIP_DIR/*.conf;" "$NGINX_CONF")" == 1 ]]
}
apply_observe() {
  mkdir -p "$NGINX_SNIP_DIR"; chmod 0755 "$NGINX_SNIP_DIR"
  write_http_snippet
  backup "$NGINX_SNIP_DIR/10-observe.conf"
  # access_log here replaces the http-level one for this server: keep that log too
  printf '# Managed by ai01-harden.sh\naccess_log %s ai01_sec;\naccess_log %s/access.log combined;\n' \
    "$SEC_LOG" "$NGINX_LOG_DIR" >"$NGINX_SNIP_DIR/10-observe.conf"
  chmod 0644 "$NGINX_SNIP_DIR/10-observe.conf"
  add_include || return 1
  nginx_apply
}
verify_observe() {
  local n; n="$(grep -c ' "GET /health' "$SEC_LOG" 2>/dev/null || true)"
  if (( ${n:-0} > 0 )) && tail -3 "$SEC_LOG" | grep -qE 'TLSv1\.[23]'; then
    say "  ok    security log records the TLS version"; return 0
  fi
  say "  FAIL  security log $SEC_LOG has no entries"; return 1
}

# ===========================================================================
# Step: llama. No conversation state on disk, memory locked, slot API off
# ===========================================================================
info_llama() {
  say "  llama-server is started with:"
  say "   - no --slot-save-path: conversations are never saved to $CACHE_DIR"
  say "   - --mlock: the model and prompts stay in memory, never written to swap"
  say "   - --no-slots (if this build has it): the slot API is switched off"
  say "   - no verbose logging flags: prompts are not written to the log"
  say "  The model reloads once (about a minute)."
}
VERBOSE_FLAGS=(-v --verbose --log-verbose --verbose-prompt)           # no value
VALUE_FLAGS=(--slot-save-path -lv --verbosity --log-verbosity)         # followed by a value
status_llama() {
  local f; for f in "${VERBOSE_FLAGS[@]}" "${VALUE_FLAGS[@]}"; do has_arg "$f" && return 1; done
  if llama_supports --mlock && ! has_arg --mlock && mlock_fits; then return 1; fi
  if llama_supports --no-slots && ! has_arg --no-slots; then return 1; fi
  return 0
}
mlock_fits() {   # enough memory to lock the whole model and still run
  local m mb avail; m="$(model_file)"; [[ -n "$m" ]] || return 1
  mb=$(( $(stat -c %s "$m") / 1048576 ))
  avail="$(awk '/MemTotal/ {printf "%d", $2/1024}' /proc/meminfo)"
  (( avail > mb + 4096 ))
}
apply_llama() {
  backup "$ARGS_FILE" "$DROPIN"
  local out=() skip=no a
  mapfile -t A <"$ARGS_FILE"
  for a in "${A[@]}"; do
    if [[ "$skip" == yes ]]; then skip=no; continue; fi
    local v drop=no
    for v in "${VALUE_FLAGS[@]}"; do
      [[ "$a" == "$v" ]] && { skip=yes; drop=yes; }
      [[ "$a" == "$v="* ]] && drop=yes
    done
    for v in "${VERBOSE_FLAGS[@]}"; do [[ "$a" == "$v" ]] && drop=yes; done
    [[ "$drop" == yes ]] && { say "  removing $a"; continue; }
    out+=("$a")
  done
  local add=()
  if llama_supports --mlock; then
    if mlock_fits; then add+=(--mlock); else warn "Not enough memory to lock the model: --mlock left off. See step 'swap'."; fi
  else warn "This llama-server build has no --mlock."; fi
  if llama_supports --no-slots; then add+=(--no-slots); else say "  this build has no --no-slots: the slot API stays closed in nginx only"; fi
  for a in "${add[@]}"; do
    printf '%s\n' "${out[@]}" | grep -qxF -- "$a" || { out+=("$a"); say "  adding $a"; }
  done
  printf '%s\n' "${out[@]}" >"$ARGS_FILE"
  chown root:"$SVC_USER" "$ARGS_FILE" 2>/dev/null || true; chmod 0640 "$ARGS_FILE"

  if printf '%s\n' "${out[@]}" | grep -qxF -- --mlock; then
    mkdir -p "$(dirname "$DROPIN")"
    printf '# Managed by ai01-harden.sh: let llama-server lock the model in memory\n[Service]\nLimitMEMLOCK=infinity\n' >"$DROPIN"
    chmod 0644 "$DROPIN"
  fi
  harden_env_set LLAMA_REMOVE_FLAGS "${VALUE_FLAGS[*]} ${VERBOSE_FLAGS[*]}"
  harden_env_set LLAMA_ADD_FLAGS "${add[*]}"
  llama_restart
}
verify_llama() {
  local pid rc=0; pid="$(llama_pid)"
  [[ "$pid" =~ ^[0-9]+$ && "$pid" != 0 ]] || { say "  FAIL  no llama-server process"; return 1; }
  if tr '\0' '\n' <"/proc/$pid/cmdline" | grep -qx -- --slot-save-path; then
    say "  FAIL  running process still has --slot-save-path"; rc=1
  else say "  ok    running process has no --slot-save-path"; fi
  if has_arg --mlock; then
    local lck; lck="$(awk '/^VmLck/ {print $2}' "/proc/$pid/status" 2>/dev/null || echo 0)"
    if (( ${lck:-0} > 0 )); then say "  ok    memory locked: $(( lck / 1024 )) MB"
    else say "  FAIL  --mlock is set but no memory is locked (LimitMEMLOCK?)"; rc=1; fi
  fi
  return "$rc"
}
commit_llama() {
  local n; n="$(find "$CACHE_DIR" -type f 2>/dev/null | wc -l)"
  if (( n > 0 )) && ask "  $CACHE_DIR still holds $n saved file(s) that may contain old prompts. Shred them?"; then
    find "$CACHE_DIR" -type f -exec shred -u {} \; 2>>"$RUNLOG" || find "$CACHE_DIR" -type f -delete
    say "  shredded $n file(s)"
  fi
  return 0
}

# ===========================================================================
# Step: tls13. TLS 1.3 only, once PATCH-01 is seen using it
# ===========================================================================
info_tls13() {
  say "  Accept TLS 1.3 only (today: $(awk '/ssl_protocols/ {$1=""; gsub(";",""); print; exit}' "$NGINX_CONF"))."
  say "  Starts only when the security log shows PATCH-01 already connects with TLS 1.3."
}
status_tls13() { grep -qE '^[[:space:]]*ssl_protocols[[:space:]]+TLSv1\.3;' "$NGINX_CONF"; }
patch01_lines() {   # patch01_lines <n> [since epoch]: PATCH-01's latest requests
  # (not ai01-client.sh's deliberate probes: TLS 1.2, no certificate), only those after <since>
  local ip since="${2:-0}"; ip="$(patch01_ip)"; [[ -n "$ip" ]] || return 0
  grep -F " $ip \"" "$SEC_LOG" 2>/dev/null | grep -vE 'tls12-probe|nocert-probe' | tail -400 \
    | while IFS= read -r l; do
        t="$(date -d "${l%% *}" +%s 2>/dev/null || echo 0)"
        (( t >= since )) && printf '%s\n' "$l"
      done | tail -"${1:-50}" || true
}
EVIDENCE_MAX_AGE="${AI01_EVIDENCE_MAX_AGE:-900}"   # readiness looks at the last 15 minutes only
line_status() { sed -nE 's/.*" ([0-9]{3}) .*/\1/p' <<<"$1"; }
# confirm_from_patch01 <step> <ERE the good lines match>: after tls13 / mtls-enforce,
# keep the change only when PATCH-01's own requests succeed under it. An undo
# timer covers a lost session.
confirm_from_patch01() {
  local s="$1" good_re="$2" since now deadline lines good bad
  since="$(date +%s)"; deadline=$(( since + CONFIRM_WAIT ))
  # A unit left over from an earlier undo (failed, or not yet collected) would stop this one being armed
  systemctl stop "ai01-harden-undo-$s.timer" >>"$RUNLOG" 2>&1 || true
  systemctl reset-failed "ai01-harden-undo-$s.service" "ai01-harden-undo-$s.timer" >>"$RUNLOG" 2>&1 || true
  systemd-run --collect --unit="ai01-harden-undo-$s" --on-active="$(( CONFIRM_WAIT + 120 ))s" --timer-property=AccuracySec=1s \
    "$SELF" --auto-undo "$s" "$BK" >>"$RUNLOG" 2>&1 \
    || { say "  FAIL  could not arm the automatic undo"; return 1; }
  say ""
  say "  Now on PATCH-01, from the bundle's patch01 folder, run:"
  say "      ./scripts/ai01-client.sh --test"
  say "  (or just use the portal). Waiting up to $CONFIRM_WAIT s for PATCH-01's requests to succeed;"
  say "  if they fail, or none arrive, '$s' is undone. Ctrl-C or a lost session: undone by a timer."
  while :; do
    lines="$(patch01_lines 100 "$since")"
    bad="$(printf '%s\n' "$lines" | grep -cE '" (400|403|495|496) ' || true)"
    good="$(printf '%s\n' "$lines" | grep -E '" 200 ' | grep -cE "$good_re" || true)"
    if (( bad > 0 )); then
      say "  FAIL  PATCH-01's requests are refused:"; printf '%s\n' "$lines" | grep -E '" 40[03] ' | tail -3 | sed 's/^/          /'
      systemctl stop "ai01-harden-undo-$s.timer" >>"$RUNLOG" 2>&1 || true
      return 1
    fi
    if (( good >= 3 )); then
      systemctl stop "ai01-harden-undo-$s.timer" >>"$RUNLOG" 2>&1 || true
      say "  ok    $good successful requests from PATCH-01 under the new setting"
      return 0
    fi
    now="$(date +%s)"
    if (( now >= deadline )); then
      say "  FAIL  no successful request from PATCH-01 within $CONFIRM_WAIT s"
      systemctl stop "ai01-harden-undo-$s.timer" >>"$RUNLOG" 2>&1 || true
      return 1
    fi
    sleep 3
  done
}
ready_tls13() {
  is_done observe || { say "  Run step 'observe' first, then use the portal (or ai01-client.sh --test on PATCH-01)."; return 1; }
  local lines n old; lines="$(patch01_lines 50 "$(( $(date +%s) - EVIDENCE_MAX_AGE ))")"
  n="$(printf '%s' "$lines" | grep -c . || true)"
  old="$(printf '%s' "$lines" | grep -cvE ' TLSv1\.3 ' || true)"
  if (( n < 3 )); then
    say "  Not yet: only $n request(s) from PATCH-01 ($(patch01_ip)) in the last $(( EVIDENCE_MAX_AGE / 60 )) minutes."
    say "  On PATCH-01 run: ./scripts/ai01-client.sh --test   then run this step again."; return 1
  fi
  if (( old > 0 )); then
    say "  Not safe: $old of PATCH-01's last $n requests used an older TLS version:"
    printf '%s\n' "$lines" | grep -vE ' TLSv1\.3 ' | tail -3 | sed 's/^/    /'; return 1
  fi
  say "  PATCH-01's last $n requests all used TLS 1.3."
}
apply_tls13() {
  backup "$NGINX_CONF"
  sed -i -E 's/^([[:space:]]*ssl_protocols)[[:space:]]+[^;]*;/\1       TLSv1.3;/' "$NGINX_CONF"
  harden_env_set TLS_PROTOCOLS "TLSv1.3"
  nginx_apply
}
commit_tls13() { confirm_from_patch01 tls13 ' TLSv1\.3 '; }
verify_tls13() {
  local code; code="$(front_code /health --tls-max 1.2)"
  if [[ "$code" == 000 ]]; then say "  ok    TLS 1.2 refused"; return 0; fi
  say "  FAIL  a TLS 1.2 connection still got HTTP $code"; return 1
}

# ===========================================================================
# Step: ratelimit
# ===========================================================================
info_ratelimit() {
  say "  At most 10 requests a second per client address (bursts of 30 allowed),"
  say "  answered with 429 beyond that. PATCH-01 runs 2 questions at a time, far below."
}
status_ratelimit() { [[ -f "$NGINX_SNIP_DIR/20-ratelimit.conf" ]]; }
ready_ratelimit() { is_done observe || status_observe || { say "  Run step 'observe' first."; return 1; }; }
apply_ratelimit() {
  backup "$NGINX_SNIP_DIR/20-ratelimit.conf"
  printf '# Managed by ai01-harden.sh\nlimit_req zone=ai01_req burst=30 nodelay;\nlimit_req_status 429;\n' >"$NGINX_SNIP_DIR/20-ratelimit.conf"
  chmod 0644 "$NGINX_SNIP_DIR/20-ratelimit.conf"
  nginx_apply
}
burst_test() {
  local i c n429=0
  for ((i = 0; i < 80; i++)); do
    c="$(curl -sk --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 5 "$FRONT/health" 2>/dev/null || true)"
    [[ "$c" == 429 ]] && n429=$((n429 + 1))
  done
  printf '%s' "$n429"
}
verify_ratelimit() {
  local n; n="$(burst_test)"
  sleep 4   # let the bucket refill before the next tests
  if (( n > 0 )); then say "  ok    burst of 80 requests: $n answered 429"; return 0; fi
  say "  FAIL  burst of 80 requests: none limited"; return 1
}

# ===========================================================================
# Step: mtls. Client certificate for PATCH-01 (asked for, not yet required)
# ===========================================================================
CLIENT_CA_DIR="$CERT_DIR/client-ca"
CLIENT_DIR="$CERT_DIR/clients"
info_mtls() {
  say "  Creates a small certificate authority on AI-01 and a client certificate"
  say "  for PATCH-01 (both kept if they exist), and makes nginx ask for it."
  say "  Nothing is refused yet, not even a wrong certificate: that is step"
  say "  'mtls-enforce', once PATCH-01 is seen presenting the right one."
}
status_mtls() { [[ -f "$NGINX_SNIP_DIR/30-mtls.conf" && -s "$CLIENT_CA_DIR/ca.crt" && -s "$CLIENT_DIR/patch01.crt" ]]; }
ready_mtls() { is_done observe || status_observe || { say "  Run step 'observe' first."; return 1; }; }
# The CA and PATCH-01's certificate are never removed by a rollback: a new CA
# would silently invalidate the certificate PATCH-01 already has.
make_client_ca() {
  mkdir -p "$CLIENT_CA_DIR" "$CLIENT_DIR"; chmod 0700 "$CLIENT_CA_DIR" "$CLIENT_DIR"
  if [[ ! -s "$CLIENT_CA_DIR/ca.key" ]]; then
    openssl ecparam -name prime256v1 -genkey -noout -out "$CLIENT_CA_DIR/ca.key" 2>>"$RUNLOG"
    chmod 0600 "$CLIENT_CA_DIR/ca.key"
    openssl req -x509 -new -key "$CLIENT_CA_DIR/ca.key" -sha256 -days 3650 \
      -subj "/CN=AI-01 client CA/O=Patch Platform" \
      -addext "basicConstraints=critical,CA:TRUE,pathlen:0" \
      -addext "keyUsage=critical,keyCertSign,cRLSign" \
      -out "$CLIENT_CA_DIR/ca.crt" 2>>"$RUNLOG" || return 1
    chmod 0644 "$CLIENT_CA_DIR/ca.crt"
    say "  created the client CA (EC P-256, 10 years)"
  fi
}
client_cert_ok() {   # PATCH-01's certificate exists, chains to the CA, 30+ days left
  [[ -s "$CLIENT_DIR/patch01.crt" && -s "$CLIENT_DIR/patch01.key" ]] \
    && openssl verify -CAfile "$CLIENT_CA_DIR/ca.crt" "$CLIENT_DIR/patch01.crt" >/dev/null 2>&1 \
    && openssl x509 -checkend $((30 * 86400)) -noout -in "$CLIENT_DIR/patch01.crt" >/dev/null 2>&1
}
issue_client_cert() {   # PATCH-01's certificate, 825 days; an existing good one is kept
  if client_cert_ok; then say "  keeping PATCH-01's existing client certificate"; return 0; fi
  openssl ecparam -name prime256v1 -genkey -noout -out "$CLIENT_DIR/patch01.key" 2>>"$RUNLOG"
  chmod 0600 "$CLIENT_DIR/patch01.key"
  openssl req -new -key "$CLIENT_DIR/patch01.key" -subj "/CN=patch01-client/O=Patch Platform" \
    -out "$TMPD/client.csr" 2>>"$RUNLOG" || return 1
  printf 'basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature\nextendedKeyUsage=clientAuth\n' >"$TMPD/ext"
  openssl x509 -req -in "$TMPD/client.csr" -CA "$CLIENT_CA_DIR/ca.crt" -CAkey "$CLIENT_CA_DIR/ca.key" \
    -CAcreateserial -days 825 -sha256 -extfile "$TMPD/ext" -out "$CLIENT_DIR/patch01.crt" 2>>"$RUNLOG" || return 1
  chmod 0644 "$CLIENT_DIR/patch01.crt"
  openssl verify -CAfile "$CLIENT_CA_DIR/ca.crt" "$CLIENT_DIR/patch01.crt" >>"$RUNLOG" 2>&1
}
export_bundle() {
  local out="$STATE_DIR/export/patch01-client.tar" fp
  ( cd "$TMPD" && rm -rf bundle && mkdir bundle \
    && cp "$CLIENT_DIR/patch01.crt" bundle/client.crt && cp "$CLIENT_DIR/patch01.key" bundle/client.key \
    && chmod 0600 bundle/client.key && tar -cf "$out" -C bundle client.crt client.key )
  chmod 0600 "$out"
  fp="$(openssl x509 -noout -fingerprint -sha256 -in "$CLIENT_DIR/patch01.crt" | cut -d= -f2)"
  say ""
  say "  PATCH-01's certificate and key: $out"
  say "  Fingerprint: $fp"
  say "  Copy it to PATCH-01 over SSH (it holds a private key; delete it here after):"
  if is_done firewall; then
    say "  (AI-01's firewall only lets AI-01 reach PATCH-01 on 443: pull it from"
    say "   PATCH-01 or your admin machine instead, e.g. on PATCH-01:"
    say "    scp root@<AI-01>:$out /root/ )"
  else
    say "    scp $out root@$(patch01_ip):/root/"
  fi
  say "  Then on PATCH-01, from the bundle's patch01 folder:"
  say "    ./scripts/ai01-client.sh --import /root/patch01-client.tar"
}
apply_mtls() {
  make_client_ca || return 1
  issue_client_cert || { say "  FAIL  could not issue PATCH-01's certificate"; return 1; }
  backup "$NGINX_SNIP_DIR/30-mtls.conf"
  # optional_no_ca: a certificate that does not verify is recorded (verify=FAILED)
  # but not refused. Refusing is only step mtls-enforce's job, through the map.
  printf '# Managed by ai01-harden.sh: ask for a client certificate signed by the AI-01 client CA\nssl_client_certificate %s;\nssl_verify_client optional_no_ca;\nssl_verify_depth 1;\n' \
    "$CLIENT_CA_DIR/ca.crt" >"$NGINX_SNIP_DIR/30-mtls.conf"
  chmod 0644 "$NGINX_SNIP_DIR/30-mtls.conf"
  nginx_apply
}
verify_mtls() {
  local rc=0
  front_code /health --cert "$CLIENT_DIR/patch01.crt" --key "$CLIENT_DIR/patch01.key" >/dev/null
  sleep 1
  if tail -5 "$SEC_LOG" 2>/dev/null | grep -q 'verify=SUCCESS'; then say "  ok    the new client certificate is accepted"
  else say "  FAIL  nginx did not accept the new client certificate"; rc=1; fi
  if rogue_untrusted; then say "  ok    a certificate from another CA is not trusted"
  else say "  FAIL  a certificate from another CA was trusted"; rc=1; fi
  return "$rc"
}
rogue_untrusted() {   # a self-made certificate never verifies (FAILED in the log, or refused)
  openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes -days 1 -subj "/CN=rogue" \
    -keyout "$TMPD/rogue.key" -out "$TMPD/rogue.crt" >>"$RUNLOG" 2>&1
  local c; c="$(front_code /health --cert "$TMPD/rogue.crt" --key "$TMPD/rogue.key")"
  sleep 1
  [[ "$c" != 200 ]] || tail -1 "$SEC_LOG" 2>/dev/null | grep -q 'verify=FAILED'
}
commit_mtls() { mark_done mtls "since=$(date +%s)"; export_bundle; }

# ===========================================================================
# Step: mtls-enforce. Refuse PATCH-01's address without the certificate
# ===========================================================================
info_mtls_enforce() {
  say "  From now on a connection needs PATCH-01's client certificate as well as"
  say "  its address and the API key. AI-01's own checks (from 127.0.0.1) are exempt."
}
status_mtls_enforce() { [[ -f "$NGINX_SNIP_DIR/31-mtls-enforce.conf" ]]; }
ready_mtls_enforce() {
  status_mtls || { say "  Run step 'mtls' first."; return 1; }
  local since lines n good
  since="$(sed -n 's/^since=//p' "$STATE_DIR/steps/mtls" 2>/dev/null)"
  [[ "$since" =~ ^[0-9]+$ ]] || since=0
  (( since > $(date +%s) - EVIDENCE_MAX_AGE )) || since=$(( $(date +%s) - EVIDENCE_MAX_AGE ))
  lines="$(patch01_lines 20 "$since")"
  n="$(printf '%s' "$lines" | grep -c . || true)"
  good="$(printf '%s' "$lines" | tail -5 | grep -c 'verify=SUCCESS' || true)"
  if (( n < 3 )); then
    say "  Not yet: only $n request(s) from PATCH-01 recorded. On PATCH-01 run"
    say "    ./scripts/ai01-client.sh --test"; return 1
  fi
  if (( good < $(printf '%s' "$lines" | tail -5 | grep -c . ) )); then
    say "  Not safe: PATCH-01's latest requests do not all present the certificate:"
    printf '%s\n' "$lines" | tail -5 | sed 's/^/    /'
    say "  On PATCH-01: ./scripts/ai01-client.sh --import <tar>, then --test."; return 1
  fi
  say "  PATCH-01's latest requests all present a valid client certificate."
}
apply_mtls_enforce() {
  backup "$NGINX_SNIP_DIR/31-mtls-enforce.conf"
  printf '# Managed by ai01-harden.sh: client certificate required (map in %s)\nif ($ai01_mtls_ok = 0) { return 403; }\n' \
    "$NGINX_HTTP_SNIPPET" >"$NGINX_SNIP_DIR/31-mtls-enforce.conf"
  chmod 0644 "$NGINX_SNIP_DIR/31-mtls-enforce.conf"
  nginx_apply
}
verify_mtls_enforce() { say "  ok    enforcement loaded; AI-01's own checks still pass"; }
commit_mtls_enforce() { confirm_from_patch01 mtls-enforce 'verify=SUCCESS'; }

# ===========================================================================
# Step: firewall. Host firewall in and out; undoes itself unless confirmed
# ===========================================================================
info_firewall() {
  say "  Adds an nftables table 'ai01_harden':"
  say "   in:  PATCH-01 to 443, SSH from the admin addresses you give, ping, loopback"
  say "   out: PATCH-01 443 (OS updates), DNS, NTP, and anything else you list"
  say "  It undoes itself after $FW_UNDO_SECS seconds unless you confirm, from a NEW"
  say "  SSH session, that you can still log in."
}
status_firewall() { nft list table inet ai01_harden >/dev/null 2>&1 && [[ -s "$NFT_FILE" ]]; }
ready_firewall() {
  command -v nft >/dev/null || { say "  nft is not installed (dnf install nftables)."; return 1; }
  command -v systemd-run >/dev/null || { say "  systemd-run is missing: the automatic undo needs it."; return 1; }
  if systemctl is-active --quiet firewalld 2>/dev/null; then
    say "  firewalld is running: use firewalld instead of this step."; return 1
  fi
  [[ -n "$(patch01_ip)" ]] || { say "  PATCH-01's address is not in $NGINX_CONF."; return 1; }
  [[ "$(patch01_ip)" =~ ^[0-9.]+$ ]] || { say "  PATCH-01's address is not IPv4: write the rules by hand."; return 1; }
}
# Reachable = any TLS answer at all, valid certificate or not (-k)
inet_reachable() { curl -sk --noproxy '*' -o /dev/null --max-time 5 "${AI01_INET_PROBE:-https://1.1.1.1/}" 2>/dev/null; }
is_ip4() { [[ "$1" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}(/[0-9]{1,2})?$ ]]; }
csv_ips() {   # validate a comma or space list of IPv4 addresses/CIDRs
  local x out=()
  for x in ${1//,/ }; do
    is_ip4 "$x" || { warn "Not an IPv4 address: $x (left out)"; continue; }
    out+=("$x")
  done
  local IFS=,; printf '%s' "${out[*]}"
}
dns_servers() { awk '$1=="nameserver" && $2 ~ /^[0-9.]+$/ && $2 !~ /^127\./ {print $2}' /etc/resolv.conf 2>/dev/null | paste -sd, -; }
ntp_servers() {
  local h out=()
  for h in $(awk '$1=="server" || $1=="pool" {print $2}' /etc/chrony.conf 2>/dev/null); do
    if is_ip4 "$h"; then out+=("$h")
    else
      warn "NTP server '$h' is a name: the rule holds today's addresses ($(getent ahostsv4 "$h" 2>/dev/null | awk '{print $1}' | sort -u | paste -sd' ' -)). If they change, roll back and re-apply this step."
      while read -r a _; do is_ip4 "$a" && out+=("$a"); done < <(getent ahostsv4 "$h" 2>/dev/null | sort -u)
    fi
  done
  local IFS=,; printf '%s' "${out[*]}" | tr ',' '\n' | sort -u | paste -sd, -
}
ssh_port() { local p; p="$(sshd -T 2>/dev/null | awk '$1=="port" {print $2; exit}')"; printf '%s' "${p:-22}"; }
nft_set() { [[ -n "$2" ]] && printf '    set %s { type ipv4_addr; flags interval; elements = { %s } }\n' "$1" "$2"; return 0; }
write_ruleset() {   # write_ruleset <file>
  local p1; p1="$(patch01_ip)"
  {
    echo "# Managed by ai01-harden.sh. Remove with: ./ai01-harden.sh --rollback firewall"
    echo "table inet ai01_harden"
    echo "delete table inet ai01_harden"
    echo "table inet ai01_harden {"
    nft_set admin_in "$FW_ADMIN"
    nft_set extra_in "$FW_EXTRA_IN"
    nft_set dns_out "$FW_DNS"
    nft_set ntp_out "$FW_NTP"
    nft_set extra_out "$FW_EXTRA_OUT"
    echo "    chain input {"
    echo "        type filter hook input priority filter; policy drop;"
    echo "        iif \"lo\" accept"
    echo "        ct state established,related accept"
    echo "        ct state invalid drop"
    echo "        meta l4proto { icmp, ipv6-icmp } accept"
    echo "        ip saddr $p1 tcp dport 443 accept"
    [[ -n "$FW_ADMIN" ]] && echo "        ip saddr @admin_in tcp dport $(ssh_port) accept"
    [[ -n "$FW_EXTRA_IN" && -n "$FW_EXTRA_IN_PORTS" ]] && echo "        ip saddr @extra_in tcp dport { $FW_EXTRA_IN_PORTS } accept"
    echo "        counter comment \"dropped in\""
    echo "    }"
    echo "    chain output {"
    echo "        type filter hook output priority filter; policy drop;"
    echo "        oif \"lo\" accept"
    echo "        ct state established,related accept"
    echo "        meta l4proto { icmp, ipv6-icmp } accept"
    echo "        ip daddr $p1 tcp dport 443 accept"
    [[ -n "$FW_DNS" ]] && echo "        ip daddr @dns_out meta l4proto { tcp, udp } th dport 53 accept"
    [[ -n "$FW_NTP" ]] && echo "        ip daddr @ntp_out udp dport 123 accept"
    [[ -n "$FW_EXTRA_OUT" ]] && echo "        ip daddr @extra_out accept"
    echo "        counter comment \"dropped out\""
    echo "    }"
    echo "}"
  } >"$1"
}
current_peers() {   # established TCP peers now, excluding loopback
  ss -tnH state established 2>/dev/null | awk '{print $4}' | sed -E 's/^\[?([0-9.]+)\]?:[0-9]+$/\1/' \
    | grep -E '^[0-9.]+$' | grep -v '^127\.' | sort -u
}
apply_firewall() {
  local p1; p1="$(patch01_ip)"
  local me; me="$(awk '{print $1}' <<<"${SSH_CONNECTION:-}")"
  [[ -n "$me" ]] || me="$(who -m 2>/dev/null | sed -n 's/.*(\([0-9.]*\)).*/\1/p' | head -1)"
  say "  PATCH-01:        $p1 (from $NGINX_CONF)"
  say "  You are on SSH from: ${me:-not over SSH}"
  FW_ADMIN="$(csv_ips "$(read_line "  Addresses or subnets allowed to SSH in, comma separated [${me:-none}]:")")"
  [[ -n "$FW_ADMIN" ]] || FW_ADMIN="$(csv_ips "$me")"
  if [[ -z "$FW_ADMIN" ]]; then
    ask "  No SSH addresses: SSH will be closed and only the console will work. Continue?" || return 1
  fi
  FW_DNS="$(dns_servers)"; FW_NTP="$(ntp_servers)"
  say "  DNS servers (from /etc/resolv.conf): ${FW_DNS:-none}"
  say "  NTP servers (from /etc/chrony.conf): ${FW_NTP:-none}"
  if systemctl is-active --quiet sssd 2>/dev/null; then
    warn "sssd is running: logins may need your directory servers (LDAP/Kerberos). Add them below."
  fi
  local peers=() p
  for p in $(current_peers); do
    [[ "$p" == "$p1" ]] && continue
    [[ ",$FW_ADMIN,$FW_DNS,$FW_NTP," == *",$p,"* ]] && continue
    peers+=("$p")
  done
  if ((${#peers[@]})); then
    say "  Open connections to or from these addresses are not covered yet:"
    printf '    %s\n' "${peers[@]}"
    say "  (monitoring, backup, log collection, directory servers...)"
  fi
  FW_EXTRA_OUT="$(csv_ips "$(read_line "  Other addresses AI-01 must reach (any port), comma separated [none]:")")"
  FW_EXTRA_IN="$(csv_ips "$(read_line "  Other addresses that must connect IN, comma separated [none]:")")"
  FW_EXTRA_IN_PORTS=""
  if [[ -n "$FW_EXTRA_IN" ]]; then
    FW_EXTRA_IN_PORTS="$(read_line "  ...on which TCP ports (comma separated)?")"
    [[ "$FW_EXTRA_IN_PORTS" =~ ^[0-9]+(,[0-9]+)*$ ]] || { say "  FAIL  ports must be numbers separated by commas"; return 1; }
    FW_EXTRA_IN_PORTS="${FW_EXTRA_IN_PORTS//,/, }"
  fi

  write_ruleset "$TMPD/ai01.nft"
  say ""; sed 's/^/    /' "$TMPD/ai01.nft"; say ""
  nft -c -f "$TMPD/ai01.nft" >>"$RUNLOG" 2>&1 || { say "  FAIL  nft rejected the rules (see $RUNLOG)"; return 1; }
  say "  ok    rules are valid"
  ask "  Load these rules now (they undo themselves in $FW_UNDO_SECS s unless confirmed)?" || return 1

  systemctl stop ai01-fw-undo.timer >>"$RUNLOG" 2>&1 || true
  systemctl reset-failed ai01-fw-undo.service ai01-fw-undo.timer >>"$RUNLOG" 2>&1 || true
  systemd-run --collect --unit=ai01-fw-undo --on-active="${FW_UNDO_SECS}s" --timer-property=AccuracySec=1s \
    "$(command -v nft)" delete table inet ai01_harden >>"$RUNLOG" 2>&1 \
    || { say "  FAIL  could not arm the automatic undo: rules not loaded"; return 1; }
  say "  automatic undo armed: in $FW_UNDO_SECS s"
  nft -f "$TMPD/ai01.nft" >>"$RUNLOG" 2>&1 || { say "  FAIL  loading the rules"; return 1; }
  FW_LOADED_AT="$(date +%s)"
  say "  rules loaded"
}
verify_firewall() {
  local rc=0 p1 c; p1="$(patch01_ip)"
  c="$(curl -sk --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 10 "${AI01_PATCH01_PROBE:-https://$p1/}" 2>/dev/null || true)"; c="${c:-000}"
  if [[ "$c" != 000 ]]; then say "  ok    AI-01 still reaches PATCH-01 on 443 (OS updates) ($c)"
  else say "  FAIL  AI-01 can no longer reach PATCH-01 on 443"; rc=1; fi
  if inet_reachable; then say "  FAIL  AI-01 can still reach the internet"; rc=1
  else say "  ok    the internet is not reachable"; fi
  return "$rc"
}
commit_firewall() {
  say ""
  say "  Now open a NEW SSH session to AI-01 from your usual machine, and check"
  say "  anything else that talks to AI-01. On PATCH-01 run ./scripts/ai01-client.sh --test."
  say "  Then come back here."
  local r; r="$(read_line "  Type CONFIRM to keep the rules (anything else, or waiting, undoes them):")"
  [[ "$r" == CONFIRM ]] || { say "  not confirmed"; return 1; }
  if is_done observe; then   # the security log shows whether PATCH-01 still gets through
    local n i
    for ((i = 0; i < ${AI01_FW_EVIDENCE_WAIT:-60}; i += 3)); do
      n="$(patch01_lines 50 "${FW_LOADED_AT:-0}" | grep -c '" 200 ' || true)"
      (( n > 0 )) && break
      (( i == 0 )) && say "  waiting up to ${AI01_FW_EVIDENCE_WAIT:-60} s for a request from PATCH-01..."
      sleep 3
    done
    if (( n > 0 )); then say "  ok    $n successful request(s) from PATCH-01 since the rules were loaded"
    else
      ask "  No successful request from PATCH-01 since the rules were loaded. Keep the rules anyway?" \
        || { say "  not kept"; return 1; }
    fi
  fi
  # Back up first, while the undo is still armed: if the backup fails, the step stops and the
  # timer still removes the rules
  backup "$NFT_FILE" "$NFT_MAIN"
  # Then stop the undo, and check the rules are still loaded (it may have just fired)
  systemctl stop ai01-fw-undo.timer >>"$RUNLOG" 2>&1 || true
  if ! nft list table inet ai01_harden >/dev/null 2>&1; then
    say "  FAIL  the undo already ran (too late): rules are gone"; return 1
  fi
  mkdir -p "$(dirname "$NFT_FILE")"
  cp "$TMPD/ai01.nft" "$NFT_FILE"; chmod 0600 "$NFT_FILE"
  mkdir -p "$(dirname "$NFT_MAIN")"; touch "$NFT_MAIN"
  grep -qF "include \"$NFT_FILE\"" "$NFT_MAIN" || printf 'include "%s"\n' "$NFT_FILE" >>"$NFT_MAIN"
  grep -qF "include \"$NFT_FILE\"" "$NFT_MAIN" || { say "  FAIL  could not add the rules to $NFT_MAIN"; return 1; }
  nft -c -f "$NFT_MAIN" >>"$RUNLOG" 2>&1 || { say "  FAIL  $NFT_MAIN does not load cleanly with the rules"; return 1; }
  systemctl enable nftables >>"$RUNLOG" 2>&1 || warn "Could not enable nftables.service: rules will not survive a reboot."
  say "  kept, and loaded at every boot ($NFT_FILE)"
}

# ===========================================================================
# Step: model. Checksum against the publisher, then lock the file
# ===========================================================================
info_model() {
  say "  Checks the model against the SHA-256 the publisher lists (you paste it),"
  say "  then marks the model and SHA256SUMS immutable: not even root can change"
  say "  them by mistake. ai01-setup.sh lifts and restores the mark itself."
}
status_model() {
  local m; m="$(model_file)"; [[ -n "$m" ]] || return 1
  lsattr "$m" 2>/dev/null | awk '{print $1}' | grep -q i
}
ready_model() { [[ -n "$(model_file)" ]] || { say "  No .gguf model in $MODEL_DIR."; return 1; }; }
apply_model() {
  local m sum pub; m="$(model_file)"
  say "  computing the SHA-256 of $(basename "$m") (a minute for a large file)..."
  sum="$(sha256sum "$m" | awk '{print $1}')"
  say "  SHA-256: $sum"
  pub="$(read_line "  Paste the SHA-256 from the publisher's page (blank to skip):")"
  pub="$(printf '%s' "$pub" | tr -d '[:space:]' | tr 'A-F' 'a-f')"
  if [[ -n "$pub" ]]; then
    [[ "$pub" == "$sum" ]] || { say "  FAIL  the model does NOT match the publisher's checksum. Replace the file."; return 1; }
    say "  ok    matches the publisher's checksum"
    harden_env_set MODEL_SHA256_PUBLISHER "$pub"
  else
    warn "Not compared with the publisher: the lock protects the file as it is now."
  fi
  if [[ -f "$MODEL_DIR/SHA256SUMS" ]] && ! (cd "$MODEL_DIR" && sha256sum -c --quiet SHA256SUMS >>"$RUNLOG" 2>&1); then
    say "  FAIL  the model does not match $MODEL_DIR/SHA256SUMS"; return 1
  fi
  chattr +i "$m" || { say "  FAIL  chattr +i (does this filesystem support it?)"; return 1; }
  [[ -f "$MODEL_DIR/SHA256SUMS" ]] && chattr +i "$MODEL_DIR/SHA256SUMS"
  return 0
}
verify_model() {
  local m; m="$(model_file)"
  if lsattr "$m" | awk '{print $1}' | grep -q i; then say "  ok    $(basename "$m") is immutable"; return 0; fi
  say "  FAIL  immutable mark not set"; return 1
}

# ===========================================================================
# Step: logs. Prompts never in logs; rotation; permissions
# ===========================================================================
info_logs() {
  say "  Sends a request containing a unique marker and searches every log for it."
  say "  Then sets log permissions and weekly rotation for llama-server.log."
}
status_logs() { [[ -f "$LOGROTATE_FILE" ]]; }
canary_absent() {   # 0 if a marker sent in a prompt shows up in no log
  local c="CANARY$(openssl rand -hex 6)" code hits
  code="$(chat_code "$(api_key)" "Reply ok. Marker $c")"
  sleep 2
  hits="$( { grep -rlF "$c" "$LOG_DIR" "$NGINX_LOG_DIR" 2>/dev/null || true
             journalctl -u llama-server -u nginx --since "-5 min" --no-pager 2>/dev/null | grep -qF "$c" && echo journal || true; } | sort -u)"
  if [[ -n "$hits" ]]; then
    [[ "${1:-}" == quiet ]] || { say "  FAIL  the prompt text was written to:"; printf '%s\n' "$hits" | sed 's/^/          /'; }
    return 1
  fi
  [[ "${1:-}" == quiet ]] || say "  ok    prompt text is in no log (request returned $code)"
  return 0
}
apply_logs() {
  backup "$LOGROTATE_FILE"
  mkdir -p "$(dirname "$LOGROTATE_FILE")"
  cat >"$LOGROTATE_FILE" <<EOF
# Managed by ai01-harden.sh
$LOG_DIR/llama-server.log {
    weekly
    rotate 8
    compress
    delaycompress
    missingok
    notifempty
    copytruncate
    create 0640 $SVC_USER $SVC_USER
    su $SVC_USER $SVC_USER
}
EOF
  [[ -s "$LOGROTATE_FILE" ]] || { say "  FAIL  could not write $LOGROTATE_FILE"; return 1; }
  chmod 0644 "$LOGROTATE_FILE"
  chmod 0750 "$LOG_DIR"
  [[ -f "$LOG_DIR/llama-server.log" ]] && chmod 0640 "$LOG_DIR/llama-server.log"
  if command -v logrotate >/dev/null; then
    logrotate -d "$LOGROTATE_FILE" >>"$RUNLOG" 2>&1 || { say "  FAIL  logrotate rejected $LOGROTATE_FILE"; return 1; }
  fi
  return 0
}
verify_logs() { canary_absent; }

# ===========================================================================
# Step: key-rotate. New API key with no downtime (two keys for a while)
# ===========================================================================
info_key_rotate() {
  if [[ -f "$STATE_DIR/key-rotate.pending" ]]; then
    say "  Second half: remove the OLD key, once PATCH-01 uses the new one."
  else
    say "  First half: adds a new API key next to the old one; both work. You then"
    say "  give PATCH-01 the new key (ai01-client.sh --rotate-key) and run this step again."
  fi
}
status_key_rotate() { return 1; }
ready_key_rotate() {
  has_arg --api-key-file || { say "  This llama-server is not using --api-key-file: rotation needs ai01-setup.sh."; return 1; }
  if [[ ! -f "$STATE_DIR/key-rotate.pending" && "$(grep -c . "$KEY_FILE")" -gt 1 ]]; then
    say "  $KEY_FILE holds $(grep -c . "$KEY_FILE") keys but no rotation is under way."
    say "  Keep only the key PATCH-01 uses (AI01_API_KEY in /patch/secrets/api.env), then try again."
    return 1
  fi
  if [[ -f "$STATE_DIR/key-rotate.pending" ]]; then
    ask "  Has PATCH-01 been given the new key, and did ./scripts/ai01-client.sh --test pass?" \
      || { say "  Then do that first. Both keys keep working meanwhile."; return 1; }
  fi
}
apply_key_rotate() {
  backup "$KEY_FILE"
  local old new
  if [[ -f "$STATE_DIR/key-rotate.pending" ]]; then
    new="$(cat "$STATE_DIR/key-rotate.pending")"
    printf '%s\n' "$new" >"$KEY_FILE"
  else
    old="$(api_key)"; new="$(openssl rand -hex 32)"
    printf '%s\n%s\n' "$old" "$new" >"$KEY_FILE"
  fi
  chown root:"$SVC_USER" "$KEY_FILE" 2>/dev/null || true; chmod 0640 "$KEY_FILE"
  printf '%s' "$new" >"$TMPD/newkey"
  llama_restart
}
verify_key_rotate() {
  local new old c rc=0; new="$(cat "$TMPD/newkey")"
  c="$(chat_code "$new")"
  if [[ "$c" == 200 ]]; then say "  ok    the new key works"
  else
    say "  FAIL  the new key got $c"; rc=1
    [[ ! -f "$STATE_DIR/key-rotate.pending" && "$(chat_code "$(api_key)")" == 200 ]] \
      && say "        this llama-server build reads only the first key in $KEY_FILE: a rotation"
    [[ ! -f "$STATE_DIR/key-rotate.pending" ]] \
      && say "        without downtime is not possible; replace the key and run phase6-llm.sh instead"
  fi
  if [[ -f "$STATE_DIR/key-rotate.pending" ]]; then
    old="$(awk 'NF {print; exit}' "$BK/files$KEY_FILE")"
    c="$(chat_code "$old")"
    [[ "$c" == 401 ]] && say "  ok    the old key is refused" || { say "  FAIL  the old key got $c"; rc=1; }
  else
    c="$(chat_code "$(api_key)")"
    [[ "$c" == 200 ]] && say "  ok    the old key still works (until the second half)" \
      || { say "  FAIL  the old key stopped working: this build reads one key only"; rc=1; }
  fi
  return "$rc"
}
commit_key_rotate() {
  if [[ -f "$STATE_DIR/key-rotate.pending" ]]; then
    shred -u "$STATE_DIR/key-rotate.pending" 2>/dev/null || rm -f "$STATE_DIR/key-rotate.pending"
    mark_done key-rotate "rotated=$(date -Is)"
    say "  Rotation finished: only the new key works."
  else
    cp "$TMPD/newkey" "$STATE_DIR/key-rotate.pending"; chmod 0600 "$STATE_DIR/key-rotate.pending"
    say ""
    say "  New key (shown once; also kept in $STATE_DIR/key-rotate.pending until the second half):"
    say ""; printf '    %s\n\n' "$(cat "$TMPD/newkey")"; log "OUT: <new key shown>"
    say "  On PATCH-01:  ./scripts/ai01-client.sh --rotate-key   (paste it when asked)"
    say "  Then here:    ./ai01-harden.sh --step key-rotate"
    mark_done key-rotate "pending=$(date -Is)"
  fi
}

# ===========================================================================
# Steps: swap and disk. Report and advise; nothing changed automatically
# ===========================================================================
info_swap() { say "  Checks whether swap could hold model memory unencrypted."; }
swap_state() {   # prints none|encrypted|plain
  local devs d t; devs="$(swapon --show=NAME --noheadings 2>/dev/null || true)"
  [[ -n "$devs" ]] || { echo none; return; }
  for d in $devs; do
    [[ "$d" == /dev/zram* ]] && continue
    t="$(lsblk -nso TYPE "$d" 2>/dev/null | tr '\n' ' ')"
    [[ "$t" == *crypt* ]] || { echo plain; return; }
  done
  echo encrypted
}
status_swap() { [[ "$(swap_state)" != plain ]]; }
ready_swap() {
  say "  Swap is not encrypted: $(swapon --show=NAME --noheadings 2>/dev/null | tr '\n' ' ')"
  if has_arg --mlock; then say "  llama-server locks its memory (--mlock), so the model and prompts are not swapped."; fi
  say "  To remove the remaining risk, either:"
  say "   - turn swap off if memory allows:  swapoff -a, then comment the swap line in /etc/fstab"
  say "   - or encrypt it with a random key at each boot: /etc/crypttab entry with"
  say "     'swap,cipher=aes-xts-plain64,size=512' and point /etc/fstab at /dev/mapper/<name>"
  say "  Not changed automatically: a wrong fstab line stops the server booting."
  return 1
}
info_disk() { say "  Checks whether $BASE (model, keys, logs) is on an encrypted volume."; }
status_disk() {
  local src; src="$(findmnt -no SOURCE -T "$BASE" 2>/dev/null || true)"
  [[ -n "$src" ]] && lsblk -nso TYPE "$src" 2>/dev/null | grep -q crypt
}
ready_disk() {
  say "  $BASE is on $(findmnt -no SOURCE -T "$BASE" 2>/dev/null || echo '?'), which is not encrypted."
  say "  Encrypting it means moving the data to a new LUKS volume (a planned window):"
  say "   1. add a disk, cryptsetup luksFormat it, open it, mkfs, mount on /mnt/llm-new"
  say "   2. stop llama-server, rsync -aHAX $BASE/ /mnt/llm-new/, swap the mounts"
  say "   3. unlock at boot with Clevis (TPM2 or a Tang server), not a typed password"
  say "  Not done automatically: it moves all data and needs a reboot to test."
  return 1
}

# ===========================================================================
# --check: every test, nothing changed
# ===========================================================================
PASS=0; FAILN=0; WARNN=0
t_pass() { printf '  PASS  %-4s %s\n' "$1" "$2"; log "PASS $1 $2"; PASS=$((PASS + 1)); }
t_fail() { printf '  FAIL  %-4s %s\n' "$1" "$2"; log "FAIL $1 $2"; FAILN=$((FAILN + 1)); }
t_warn() { printf '  warn  %-4s %s\n' "$1" "$2"; log "WARN $1 $2"; WARNN=$((WARNN + 1)); }
t() {   # t <id> <description> <hard|soft> <command...>
  local id="$1" d="$2" kind="$3"; shift 3
  if "$@" >>"$RUNLOG" 2>&1; then t_pass "$id" "$d"
  elif [[ "$kind" == hard ]]; then t_fail "$id" "$d"
  else t_warn "$id" "$d"; fi
}
c_active()     { systemctl is-active --quiet llama-server; }
c_loopback()   { local l; l="$(ss -ltnH "sport = :$LISTEN_PORT" 2>/dev/null | awk '{print $4}')"; [[ -n "$l" ]] && ! grep -vqE '^(127\.0\.0\.1|\[::1\]):' <<<"$l"; }
c_health()     { [[ "$(front_code /health)" == 200 ]]; }
c_chat()       { [[ "$(chat_code "$(api_key)")" == 200 ]] && grep -q '"choices"' "$TMPD/body"; }
c_nokey()      { [[ "$(chat_code "")" == 401 ]]; }
c_badkey()     { [[ "$(chat_code "0000$(openssl rand -hex 30)")" == 401 ]]; }
c_closed()     { [[ "$(front_code "$1")" == 404 ]]; }
c_ipdeny()     { local d; d="$(systemctl show -p IPAddressDeny --value llama-server 2>/dev/null)"; [[ "$d" == *any* || "$d" == *0.0.0.0/0* ]]; }
c_noslotsave() { ! has_arg --slot-save-path; }
c_mlock()      { has_arg --mlock && (( $(awk '/^VmLck/ {print $2}' "/proc/$(llama_pid)/status" 2>/dev/null || echo 0) > 0 )); }
c_noverbose()  { local f; for f in "${VERBOSE_FLAGS[@]}" -lv --verbosity --log-verbosity; do has_arg "$f" && return 1; done; return 0; }
c_tls12off()   { [[ "$(front_code /health --tls-max 1.2)" == 000 ]]; }
# From the configuration: RHEL 9's crypto policy stops curl offering TLS 1.0/1.1,
# so a live probe would pass whatever nginx allows
c_tls11off()   { local l; l="$(grep -hE '^[[:space:]]*ssl_protocols' "$NGINX_CONF" "$NGINX_SNIP_DIR"/*.conf 2>/dev/null)"
                 [[ -n "$l" ]] && ! grep -qE 'SSLv|TLSv1(\.1)?[ ;]' <<<"$l"; }
c_mtls_on()    { status_mtls; }
c_mtls_enf()   { status_mtls_enforce; }
c_rogue()      { status_mtls && rogue_untrusted; }
c_cert_days()  { openssl x509 -checkend $((30 * 86400)) -noout -in "$1"; }
c_mode()       { [[ "$(stat -c %a "$1" 2>/dev/null)" == "$2" ]]; }
c_ratelimit()  { [[ -f "$NGINX_SNIP_DIR/20-ratelimit.conf" ]] && { [[ "$DEEP" != yes ]] || { local n; n="$(burst_test)"; sleep 4; (( n > 0 )); }; }; }
c_fw_loaded()  { nft list table inet ai01_harden >/dev/null 2>&1; }
c_fw_boot()    { [[ -s "$NFT_FILE" ]] && grep -qF "include \"$NFT_FILE\"" "$NFT_MAIN" 2>/dev/null; }
c_no_inet()    { ! inet_reachable; }
c_sums()       { [[ -f "$MODEL_DIR/SHA256SUMS" ]] && (cd "$MODEL_DIR" && sha256sum -c --quiet SHA256SUMS); }
c_nginx_t()    { nginx -t; }
c_setup_ok()   { grep -q 'AI01-HARDENING-AWARE' "$SETUP"; }
c_nocache()    { [[ -z "$(find "$CACHE_DIR" -type f 2>/dev/null | head -1)" ]]; }

do_check() {
  hdr "AI-01 tests ($(date '+%F %T'))"
  say "  Service and the portal's path"
  t T01 "llama-server is running"                              hard c_active
  t T02 "llama-server listens on loopback only"                hard c_loopback
  t T03 "HTTPS /health answers 200"                            hard c_health
  t T04 "portal path: chat with the API key answers 200"       hard c_chat
  t T05 "a request without the key is refused (401)"           hard c_nokey
  t T06 "a request with a wrong key is refused (401)"          hard c_badkey
  t T07 "/slots is closed (404)"                               hard c_closed /slots
  t T08 "/metrics is closed (404)"                             hard c_closed /metrics
  t T09 "/props is closed (404)"                               hard c_closed /props
  t T10 "nginx configuration is valid"                         hard c_nginx_t
  say "  llama-server"
  t T11 "systemd blocks llama-server's network (loopback only)" hard c_ipdeny
  t T12 "conversations are not saved to disk (no --slot-save-path)" soft c_noslotsave
  t T13 "no saved conversation files in $CACHE_DIR"           soft c_nocache
  t T14 "model memory locked (--mlock, VmLck > 0)"             soft c_mlock
  t T15 "no verbose logging flags"                             hard c_noverbose
  say "  Encryption in transit"
  t T16 "TLS 1.0 and 1.1 not enabled in nginx"                hard c_tls11off
  t T17 "TLS 1.2 refused (step tls13)"                         soft c_tls12off
  t T18 "server certificate valid for 30+ days"                hard c_cert_days "$CERT_DIR/ai01.crt"
  t T19 "client certificate asked for (step mtls)"             soft c_mtls_on
  t T20 "client certificate required (step mtls-enforce)"      soft c_mtls_enf
  t T21 "a certificate from another CA is not trusted"         soft c_rogue
  if [[ -s "$CLIENT_DIR/patch01.crt" ]]; then
    t T22 "PATCH-01 client certificate valid for 30+ days"     hard c_cert_days "$CLIENT_DIR/patch01.crt"
  fi
  say "  Secrets"
  t T23 "API key file is 0640"                                 hard c_mode "$KEY_FILE" 640
  t T24 "TLS private key is 0600"                              hard c_mode "$CERT_DIR/ai01.key" 600
  if [[ -f "$CLIENT_CA_DIR/ca.key" ]]; then
    t T25 "client CA private key is 0600"                      hard c_mode "$CLIENT_CA_DIR/ca.key" 600
  fi
  if [[ -f "$STATE_DIR/export/patch01-client.tar" ]]; then
    t_warn T26 "PATCH-01's key bundle is still on AI-01: delete $STATE_DIR/export/patch01-client.tar once imported"
  fi
  say "  Network"
  t T27 "rate limit configured$( [[ $DEEP == yes ]] && echo ' and answering 429 under a burst')" soft c_ratelimit
  t T28 "host firewall loaded (step firewall)"                 soft c_fw_loaded
  t T29 "host firewall loaded at boot"                         soft c_fw_boot
  t T30 "the internet is not reachable from AI-01"             soft c_no_inet
  say "  Model, logs, storage"
  t T31 "model matches SHA256SUMS"                             hard c_sums
  t T32 "model is immutable (step model)"                      soft status_model
  t T33 "prompt text is written to no log"                     hard canary_absent quiet
  t T34 "log rotation for llama-server.log (step logs)"        soft test -f "$LOGROTATE_FILE"
  t T35 "swap absent or encrypted"                             soft status_swap
  t T36 "$BASE on an encrypted volume"                         soft status_disk
  t T37 "ai01-setup.sh keeps the hardening when re-run"        soft c_setup_ok
  say ""
  say "  $PASS passed, $WARNN warning(s), $FAILN failed.   Log: $RUNLOG"
  (( FAILN == 0 ))
}

# ===========================================================================
# Status, menu
# ===========================================================================
desc() {
  case "$1" in
    observe) echo "Record TLS details per request (needed by tls13, mtls-enforce)" ;;
    llama) echo "Model server: no prompts on disk, memory locked, slot API off" ;;
    tls13) echo "TLS 1.3 only" ;;
    ratelimit) echo "Limit requests per client" ;;
    mtls) echo "Client certificate for PATCH-01 (asked for, not required)" ;;
    mtls-enforce) echo "Require PATCH-01's client certificate" ;;
    firewall) echo "Host firewall in and out, with automatic undo" ;;
    model) echo "Check the model's checksum and lock the file" ;;
    logs) echo "Prove prompts are not logged; log rotation" ;;
    key-rotate) echo "Rotate the API key with no downtime" ;;
    swap) echo "Check swap (report only)" ;;
    disk) echo "Check disk encryption (report only)" ;;
  esac
}
show_status() {
  hdr "Hardening status"
  local i=1 s mark
  for s in "${STEPS[@]}"; do
    if is_pending "$s"; then mark="PENDING: applied, never kept; undone automatically"
    elif is_done "$s"; then mark="done   $(sed -n '1s/done=//p' "$STATE_DIR/steps/$s" | cut -c1-16)"
    elif in_place "$s" 2>/dev/null; then mark="in place"
    else mark="-"; fi
    [[ "$s" == key-rotate && -f "$STATE_DIR/key-rotate.pending" ]] && mark="HALF DONE: finish it"
    printf '  %2d) %-13s %-58s %s\n' "$i" "$s" "$(desc "$s")" "$mark"
    i=$((i + 1))
  done
}
menu() {
  say "AI-01 hardening $VERSION. Recommended order: 1, 2, 4, 5, then (after PATCH-01"
  say "imports its certificate) 3 and 6, then 7, 8, 9. Each step tests and undoes itself on failure."
  while true; do
    undo_pending stale || true      # an undo timer cannot run while this menu holds the lock
    show_status
    say "   c) run all tests   r) roll back a step   q) quit"
    local a; read -r -p "Choose: " a || exit 0
    case "$a" in
      q|Q) exit 0 ;;
      c|C) do_check || true ;;
      r|R) local s; read -r -p "Step to roll back: " s
           [[ " ${STEPS[*]} " == *" $s "* ]] && { ask "Roll back '$s'?" && rollback_step "$s" || true; } || say "Unknown step." ;;
      ''|*[!0-9]*) say "Choose a number, c, r or q." ;;
      *) (( a >= 1 && a <= ${#STEPS[@]} )) && { run_step "${STEPS[$((a - 1))]}" || true; } || say "No such step." ;;
    esac
  done
}

# Steps applied by a run that ended before keeping them (lost session, lost timer)
if [[ "$MODE" != undo-pending ]]; then undo_pending stale || true; fi

case "$MODE" in
  undo-pending)
    undo_pending all ;;
  auto-undo)
    log "auto-undo $RB_STEP from $RB_DIR"
    [[ " ${STEPS[*]} " == *" $RB_STEP "* ]] || die "auto-undo: unknown step $RB_STEP"
    [[ -d "$RB_DIR" && "$RB_DIR" == "$STATE_DIR/backups/"* && "$RB_DIR" != *..* ]] || die "auto-undo: no backup $RB_DIR"
    if is_pending "$RB_STEP"; then
      [[ "$(pending_get "$RB_STEP" backup)" == "$RB_DIR" ]] \
        || { log "auto-undo: '$RB_STEP' pending from another run: left to that run's undo"; exit 0; }
    elif is_done "$RB_STEP" || [[ -e "$RB_DIR/undone" ]]; then
      log "auto-undo: '$RB_STEP' was kept or undone meanwhile: nothing to do"; exit 0
    fi
    rollback_step "$RB_STEP" "$RB_DIR" pending ;;
  menu)   menu ;;
  step)   run_step "$ONE_STEP" ;;
  check)  do_check ;;
  status) show_status ;;
  rollback)
    [[ " ${STEPS[*]} " == *" $RB_STEP "* ]] || die "Unknown step: $RB_STEP"
    ask "Roll back '$RB_STEP'?" && rollback_step "$RB_STEP" ;;
  rollback-all)
    ask "Roll back every hardening step? (The API key is kept as it is now.)" || exit 0
    rbrc=0
    # No undo timer may fire half way through, or later on what is restored here
    systemctl stop ai01-fw-undo.timer >>"$RUNLOG" 2>&1 || true
    for s in "${STEPS[@]}"; do systemctl stop "ai01-harden-undo-$s.timer" >>"$RUNLOG" 2>&1 || true; done
    undo_pending all || rbrc=1
    RESTORE_SKIP="$KEY_FILE"
    # Only what was kept and is still done: attempts that failed or were undone are not restored
    DONE_NOW=" $(ls -1 "$STATE_DIR/steps" 2>/dev/null | tr '\n' ' ') "
    for d in $(find "$STATE_DIR/backups" -mindepth 1 -maxdepth 1 -type d | sort -r); do
      s="$(basename "$d" | cut -d- -f3-)"
      [[ -f "$d/after" && ! -e "$d/undone" && "$DONE_NOW" == *" $s "* ]] || continue
      restore_files "$d" || rbrc=1
      touch "$d/undone"
      mark_undone "$s"; say "  restored $s from $(basename "$d")"
    done
    if [[ -f "$STATE_DIR/key-rotate.pending" ]]; then
      shred -u "$STATE_DIR/key-rotate.pending" 2>/dev/null || rm -f "$STATE_DIR/key-rotate.pending"
    fi
    nft delete table inet ai01_harden >>"$RUNLOG" 2>&1 || true
    for m in "$MODEL_DIR"/*.gguf "$MODEL_DIR/SHA256SUMS"; do [[ -e "$m" ]] && { chattr -i "$m" 2>/dev/null || true; }; done
    llama_restart || true
    nginx -t >>"$RUNLOG" 2>&1 && systemctl reload nginx >>"$RUNLOG" 2>&1 || true
    portal_ok || { warn "The portal path fails after the full rollback. Run ./ai01-setup.sh --check"; exit 1; }
    (( rbrc == 0 )) || { warn "Some files were left as they were (above)."; exit 1; }
    ;;
esac
