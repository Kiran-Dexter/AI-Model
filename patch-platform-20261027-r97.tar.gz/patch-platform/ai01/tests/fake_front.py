#!/usr/bin/env python3
"""Stand-in for AI-01's nginx in the test suite.

It reads the SAME files ai01-setup.sh and ai01-harden.sh write (the server
block, the http snippet, /etc/nginx/ai01-hardening.d/*.conf) and applies what
they say, the way nginx would, in nginx's phase order:
  rewrite (the mtls-enforce "if")  ->  limit_req  ->  allow/deny  ->  location
It speaks real TLS: ssl_protocols sets the minimum version, and
ssl_client_certificate + ssl_verify_client really verify client certificates.
SIGHUP reloads the files (systemctl reload nginx, in the stubs).

  fake_front.py serve        run (pid in $FAKE_STATE/front.pid)
  fake_front.py test         what "nginx -t" checks here: syntax, includes,
                             names the snippets use are defined, no duplicate
                             ssl_protocols; FAKE_NGINX_T_FAIL=1 forces a failure

It listens twice: on FAKE_FRONT_PORT as seen from AI-01 itself (client
address 127.0.0.1), and on FAKE_FRONT_PORT+1 as seen from PATCH-01 (client
address FAKE_PATCH01_IP), so the suite can be PATCH-01 from one machine.
"""
import glob
import json
import os
import re
import signal
import ssl
import sys
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

E = os.environ
MAIN = E["AI01_NGINX_CONF"]
HTTP_SNIP = E["AI01_NGINX_HTTP_SNIPPET"]
SNIP_DIR = E["AI01_NGINX_SNIP_DIR"]
LLAMA = "http://127.0.0.1:%s" % E.get("AI01_LISTEN_PORT", "8080")
PORT = int(E.get("FAKE_FRONT_PORT", "18443"))
STATE = E["FAKE_STATE"]


def strip_comments(text):
    return "\n".join(ln.split("#", 1)[0] for ln in text.splitlines())


def directives(text):
    return [d.strip() for d in re.split(r"[;{}]", strip_comments(text)) if d.strip()]


def load():
    main = open(MAIN).read()
    m = strip_comments(main)
    cfg = {"protocols": ["TLSv1.2", "TLSv1.3"], "allow": [], "observe": None, "limit": False,
           "client_ca": None, "verify": "off", "enforce": False}
    p = re.search(r"ssl_protocols\s+([^;]+);", m)
    if p:
        cfg["protocols"] = p.group(1).split()
    cfg["cert"] = re.search(r"ssl_certificate\s+([^;]+);", m).group(1).strip()
    cfg["key"] = re.search(r"ssl_certificate_key\s+([^;]+);", m).group(1).strip()
    cfg["allow"] = re.findall(r"^\s*allow\s+([^;]+);", m, re.M)
    if re.search(r"include\s+" + re.escape(SNIP_DIR) + r"/\*\.conf;", m):
        for f in sorted(glob.glob(SNIP_DIR + "/*.conf")):
            t = strip_comments(open(f).read())
            a = re.search(r"access_log\s+(\S+)\s+ai01_sec;", t)
            if a:
                cfg["observe"] = a.group(1)
            if re.search(r"limit_req\s+zone=ai01_req", t):
                cfg["limit"] = True
            c = re.search(r"ssl_client_certificate\s+([^;]+);", t)
            if c:
                cfg["client_ca"] = c.group(1).strip()
            v = re.search(r"ssl_verify_client\s+(\w+);", t)
            if v:
                cfg["verify"] = v.group(1)
            if re.search(r"if\s*\(\$ai01_mtls_ok\s*=\s*0\)\s*\{\s*return\s+403;", t):
                cfg["enforce"] = True
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_3 if cfg["protocols"] == ["TLSv1.3"] else ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(cfg["cert"], cfg["key"])
    # optional_no_ca: nginx accepts any certificate and records verify=FAILED for
    # one that does not verify. Python's ssl cannot accept an unverifiable
    # certificate, so here such a handshake fails instead (the suite allows both).
    if cfg["client_ca"] and cfg["verify"] in ("optional", "optional_no_ca", "on"):
        ctx.load_verify_locations(cfg["client_ca"])
        ctx.verify_mode = ssl.CERT_REQUIRED if cfg["verify"] == "on" else ssl.CERT_OPTIONAL
    cfg["ctx"] = ctx
    return cfg


def config_test():
    if E.get("FAKE_NGINX_T_FAIL") == "1":
        print("nginx: [emerg] simulated failure")
        return 1
    files = [MAIN, HTTP_SNIP] if os.path.exists(HTTP_SNIP) else [MAIN]
    main = strip_comments(open(MAIN).read())
    inc = re.search(r"include\s+" + re.escape(SNIP_DIR) + r"/\*\.conf;", main)
    snips = sorted(glob.glob(SNIP_DIR + "/*.conf")) if inc else []
    files += snips
    alltext = ""
    for f in files:
        t = strip_comments(open(f).read())
        if t.count("{") != t.count("}"):
            print(f"nginx: [emerg] unbalanced braces in {f}")
            return 1
        for d in directives(t):
            if not re.match(r"^[a-z_$\"~^:\\.0-9 =()-]", d.split()[0] if d.split() else "x"):
                print(f"nginx: [emerg] unknown directive {d!r} in {f}")
                return 1
        alltext += t + "\n"
    http = strip_comments(open(HTTP_SNIP).read()) if os.path.exists(HTTP_SNIP) else ""
    for name, rx in (("ai01_sec", r"log_format\s+ai01_sec"), ("zone=ai01_req", r"limit_req_zone\s.*zone=ai01_req"),
                     ("$ai01_mtls_ok", r"map\s.*\$ai01_mtls_ok")):
        used = any(name in strip_comments(open(f).read()) for f in snips)
        if used and not re.search(rx, http):
            print(f"nginx: [emerg] {name} used but not defined")
            return 1
    server_level = main + "\n".join(strip_comments(open(f).read()) for f in snips)
    if len(re.findall(r"\bssl_protocols\b", server_level)) > 1:
        print('nginx: [emerg] "ssl_protocols" directive is duplicate')
        return 1
    for c in re.findall(r"ssl_client_certificate\s+([^;]+);", server_level):
        if not os.path.exists(c.strip()):
            print(f"nginx: [emerg] cannot load certificate {c}")
            return 1
    print("nginx: configuration file test is successful")
    return 0


class Front:
    cfg = None
    buckets = {}
    lock = threading.Lock()


def limited(addr):
    if not Front.cfg["limit"]:
        return False
    now = time.monotonic()
    with Front.lock:
        excess, last = Front.buckets.get(addr, (0.0, now))
        excess = max(0.0, excess - 10.0 * (now - last)) + 1.0
        if excess > 31.0:
            Front.buckets[addr] = (excess - 1.0, now)
            return True
        Front.buckets[addr] = (excess, now)
    return False


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _reply(self, code, body=b"", ctype="text/plain"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)
        cfg = Front.cfg
        if cfg["observe"]:
            line = '%s %s "%s" %d %s verify=%s\n' % (
                time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime()), self.addr,
                self.requestline, code, self.connection.version(), self.verify)
            with open(cfg["observe"], "a") as fh:
                fh.write(line)

    def _handle(self, method):
        cfg = Front.cfg
        self.addr = self.server.forced_addr or self.client_address[0]
        peer = self.connection.getpeercert()
        self.verify = "SUCCESS" if peer else "NONE"
        body = b""
        if method == "POST":
            body = self.rfile.read(int(self.headers.get("Content-Length", "0") or 0))
        # rewrite phase
        if cfg["enforce"] and not (self.addr in ("127.0.0.1", "::1") or self.verify == "SUCCESS"):
            return self._reply(403, b"403 Forbidden")
        # preaccess
        if limited(self.addr):
            return self._reply(429, b"429 Too Many Requests")
        # access
        if self.addr not in cfg["allow"]:
            return self._reply(403, b"403 Forbidden")
        routes = {("GET", "/health"), ("POST", "/v1/chat/completions"), ("GET", "/v1/models")}
        path = self.path.split("?", 1)[0]          # nginx matches locations without the query
        if (method, path) not in routes:
            return self._reply(404, b"404 Not Found")
        req = urllib.request.Request(LLAMA + path, data=body if method == "POST" else None, method=method)
        if self.headers.get("Authorization") is not None:
            req.add_header("Authorization", self.headers["Authorization"])
        req.add_header("Content-Type", "application/json")
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        try:
            with opener.open(req, timeout=30) as r:
                return self._reply(r.status, r.read(), "application/json")
        except urllib.error.HTTPError as e:
            return self._reply(e.code, e.read(), "application/json")
        except Exception:
            return self._reply(502, b"502 Bad Gateway")

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")


class Srv(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def finish_request(self, request, client_address):
        try:
            tls = Front.cfg["ctx"].wrap_socket(request, server_side=True)
        except (ssl.SSLError, OSError):
            request.close()
            return
        try:
            self.RequestHandlerClass(tls, client_address, self)
        finally:
            try:
                tls.close()
            except OSError:
                pass


def serve():
    Front.cfg = load()

    def hup(*_):
        try:
            Front.cfg = load()
        except Exception as e:  # keep the old configuration, like nginx
            print("reload failed:", e, flush=True)
    signal.signal(signal.SIGHUP, hup)
    local = Srv(("127.0.0.1", PORT), H)
    local.forced_addr = None
    remote = Srv(("127.0.0.1", PORT + 1), H)
    remote.forced_addr = E.get("FAKE_PATCH01_IP", "10.20.1.5")
    threading.Thread(target=remote.serve_forever, daemon=True).start()
    with open(os.path.join(STATE, "front.pid"), "w") as fh:
        fh.write(str(os.getpid()))
    local.serve_forever()


if __name__ == "__main__":
    if sys.argv[1:] == ["test"]:
        sys.exit(config_test())
    serve()
