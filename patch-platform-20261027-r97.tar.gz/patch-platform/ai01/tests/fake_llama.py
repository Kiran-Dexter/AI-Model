#!/usr/bin/env python3
"""Stand-in for llama-server in the test suite.

Behaves like llama-server where ai01-harden.sh depends on it: refuses flags it
does not know, prints them in --help, takes API keys from --api-key-file (one
per line), answers /health and /v1/chat/completions, and with --mlock really
locks memory so /proc/<pid>/status shows VmLck.

Test switches (environment):
  FAKE_LLAMA_FLAGS     flags this "build" supports (space separated)
  FAKE_LLAMA_FAIL_ON   a flag that makes it exit at start (a broken change)
  FAKE_LLAMA_MULTIKEY  0: read only the first key line (an old build)
  FAKE_LLAMA_LOG_PROMPTS 1: write each prompt to the log (a leaky build)
"""
import ctypes
import json
import mmap
import os
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DEFAULT_FLAGS = ("-m --host --port -c -t -np --api-key-file --api-key --jinja --no-webui --metrics "
                 "--slot-save-path --mlock --no-slots -v --verbose -lv --verbosity")
FLAGS = os.environ.get("FAKE_LLAMA_FLAGS", DEFAULT_FLAGS).split()
VALUE_FLAGS = {"-m", "--host", "--port", "-c", "-t", "-np", "--api-key-file", "--api-key",
               "--slot-save-path", "-lv", "--verbosity"}

argv = sys.argv[1:]
if "--help" in argv:
    for f in FLAGS:
        print(f"{f}  (fake)")
    sys.exit(0)
if "--version" in argv:
    print("version: fake-llama 1")
    sys.exit(0)

opts, i = {}, 0
while i < len(argv):
    a = argv[i]
    if a not in FLAGS:
        print(f"error: invalid argument: {a}", flush=True)
        sys.exit(1)
    if a in VALUE_FLAGS:
        if i + 1 >= len(argv):
            print(f"error: {a} needs a value", flush=True)
            sys.exit(1)
        opts[a] = argv[i + 1]
        i += 2
    else:
        opts[a] = True
        i += 1

fail_on = os.environ.get("FAKE_LLAMA_FAIL_ON", "")
if fail_on and fail_on in opts:
    print(f"fatal: simulated failure with {fail_on}", flush=True)
    sys.exit(1)

if "--mlock" in opts:
    buf = mmap.mmap(-1, 1 << 20)
    buf.write(b"x" * (1 << 20))
    libc = ctypes.CDLL("libc.so.6", use_errno=True)
    addr = ctypes.c_void_p(ctypes.addressof(ctypes.c_char.from_buffer(buf)))
    if libc.mlock(addr, ctypes.c_size_t(1 << 20)) != 0:
        print(f"warning: failed to mlock: errno {ctypes.get_errno()}", flush=True)
    _keep = buf

keys = []
if "--api-key-file" in opts:
    with open(opts["--api-key-file"]) as fh:
        keys = [ln.strip() for ln in fh if ln.strip()]
    if os.environ.get("FAKE_LLAMA_MULTIKEY", "1") == "0":
        keys = keys[:1]
elif "--api-key" in opts:
    keys = [opts["--api-key"]]
verbose = "-v" in opts or "--verbose" in opts or os.environ.get("FAKE_LLAMA_LOG_PROMPTS") == "1"


class H(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print("srv  %s" % (fmt % args), flush=True)

    def _send(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _authorised(self):
        if not keys:
            return True
        h = self.headers.get("Authorization", "")
        return h.startswith("Bearer ") and h[7:] in keys

    def do_GET(self):
        if self.path == "/health":
            return self._send(200, {"status": "ok"})
        if self.path in ("/v1/models", "/models"):
            return self._send(200, {"data": [{"id": "fake"}]})
        if self.path == "/slots" and "--no-slots" in opts:
            return self._send(501, {"error": "slots disabled"})
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        n = int(self.headers.get("Content-Length", "0") or 0)
        body = self.rfile.read(n).decode(errors="replace")
        if self.path != "/v1/chat/completions":
            return self._send(404, {"error": "not found"})
        if not self._authorised():
            return self._send(401, {"error": {"message": "Invalid API Key"}})
        if verbose:
            print(f"prompt: {body}", flush=True)
        return self._send(200, {"choices": [{"message": {"role": "assistant", "content": "ok"}}],
                                "usage": {"prompt_tokens": 5, "completion_tokens": 1}})


port = int(opts.get("--port", "8080"))
host = opts.get("--host", "127.0.0.1")
print(f"fake llama-server listening on {host}:{port} flags={sorted(k for k in opts if k.startswith('-'))}", flush=True)
ThreadingHTTPServer((host, port), H).serve_forever()
