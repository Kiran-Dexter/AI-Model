<#
.SYNOPSIS
  Install, update or remove the PATCH-01 agent on this Windows server.

.EXAMPLE
  # 1. Check first: nothing is installed or enrolled
  .\install-agent.ps1 -Server https://patch01.example -Pin <sha256> -SelfTest

  # 2. Install and enrol (the token is single use)
  .\install-agent.ps1 -Server https://patch01.example -Pin <sha256> -Token <token>

  # Update the agent files only, keeping its enrolment
  .\install-agent.ps1 -Update

  # Change the certificate pin, keeping the enrolment (no token needed).
  # While PATCH-01's certificate is being replaced, give both: old,new
  .\install-agent.ps1 -Repin -Pin <old>,<new>

  # Remove it
  .\install-agent.ps1 -Uninstall

  Get the pin on PATCH-01 with:  ./scripts/phase10-windows.sh --pin
#>
[CmdletBinding(DefaultParameterSetName = "Install")]
param(
    [Parameter(ParameterSetName = "Install", Mandatory = $true)]
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][string]$Server,
    [Parameter(ParameterSetName = "Install", Mandatory = $true)]
    [Parameter(ParameterSetName = "Repin", Mandatory = $true)]
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][string]$Pin,
    [Parameter(ParameterSetName = "Repin", Mandatory = $true)][switch]$Repin,
    [Parameter(ParameterSetName = "Install", Mandatory = $true)][string]$Token,
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][switch]$SelfTest,
    [Parameter(ParameterSetName = "Update", Mandatory = $true)][switch]$Update,
    [Parameter(ParameterSetName = "Uninstall", Mandatory = $true)][switch]$Uninstall,
    [switch]$RequireSigned
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$InstallDir = Join-Path $env:ProgramFiles "PatchAgent"
$DataDir = Join-Path $env:ProgramData "PatchAgent"
$Agent = Join-Path $InstallDir "patch-agent.ps1"
$TaskName = "PATCH-01 agent"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:RequireSigned = [bool]$RequireSigned

$me = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw "Run PowerShell as administrator." }
if ($PSVersionTable.PSVersion.Major -lt 5) { throw "PowerShell 5.1 is needed (found $($PSVersionTable.PSVersion))." }
if ($Pin) {
    $Pin = ($Pin -replace "[:\s]", "").ToLowerInvariant()
    if ($Pin -notmatch "^(system|[0-9a-f]{64}(,[0-9a-f]{64})?)$") {
        throw "The pin must be the 64-character SHA-256 from phase10-windows.sh --pin (or two of them, comma-separated, while the certificate changes), or 'system'."
    }
}

function Lock-Folder([string]$Path) {
    # Only SYSTEM and Administrators may read the agent's data (its token lives here)
    if (-not (Test-Path $Path)) { New-Item -ItemType Directory -Path $Path | Out-Null }
    $acl = New-Object Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sid in @("S-1-5-18", "S-1-5-32-544")) {   # SYSTEM, Administrators
        $id = New-Object Security.Principal.SecurityIdentifier($sid)
        $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($id, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")))
    }
    # Owned by Administrators: a folder pre-created by an ordinary user would otherwise stay theirs,
    # and an owner can always change the permissions
    $acl.SetOwner((New-Object Security.Principal.SecurityIdentifier("S-1-5-32-544")))
    Set-Acl -Path $Path -AclObject $acl
    # Everything already inside takes the same owner and permissions (token.bin from an older install included)
    & "$env:SystemRoot\System32\icacls.exe" $Path /setowner "*S-1-5-32-544" /T /C /Q | Out-Null
    & "$env:SystemRoot\System32\icacls.exe" (Join-Path $Path "*") /reset /T /C /Q 2>$null | Out-Null
}

function Wait-AgentIdle {
    <# Before replacing the agent: pause its task and wait for a running agent
       (a patch step, an inventory) to finish, so nothing is swapped mid-job. #>
    $t = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    if (-not $t) { return }
    Disable-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue | Out-Null
    $until = (Get-Date).AddMinutes(10)
    while ([string](Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue).State -eq "Running") {
        if ((Get-Date) -gt $until) {
            Enable-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue | Out-Null
            throw "The agent has been busy for 10 minutes (a patch job?). Nothing was changed; run this again after the job."
        }
        Start-Sleep -Seconds 5
    }
}

function Get-SystemPolicy {
    # The execution policy the SYSTEM task runs under: Group Policy for the
    # machine first, then the machine's own setting (not this window's)
    $l = @(Get-ExecutionPolicy -List)
    foreach ($scope in @("MachinePolicy", "LocalMachine")) {
        $v = [string](@($l | Where-Object { [string]$_.Scope -eq $scope })[0].ExecutionPolicy)
        if ($v -and $v -ne "Undefined") { return $v }
    }
    return "RemoteSigned"                       # Windows Server's default
}

function Test-Signature([string]$Path) {
    <# The SYSTEM task cannot answer "Do you want to run software from this
       publisher?", so under AllSigned the signature must be valid AND trusted
       for the whole machine: the signer in LocalMachine\TrustedPublisher and
       its root in LocalMachine\Root. Anything less installs nothing. #>
    $policy = Get-SystemPolicy
    $name = Split-Path -Leaf $Path
    $sig = Get-AuthenticodeSignature -FilePath $Path
    $status = [string]$sig.Status
    $problem = $null
    if ($status -ne "Valid") { $problem = "its signature is " + $status }
    else {
        $cert = $sig.SignerCertificate
        if (-not (Get-ChildItem -Path Cert:\LocalMachine\TrustedPublisher -ErrorAction SilentlyContinue | Where-Object { $_.Thumbprint -eq $cert.Thumbprint })) {
            $problem = "its publisher (" + $cert.Subject + ") is not in this computer's Trusted Publishers (Cert:\LocalMachine\TrustedPublisher), so the SYSTEM task would be refused"
        } else {
            $chain = New-Object Security.Cryptography.X509Certificates.X509Chain($true)   # machine context
            [void]$chain.Build($cert)
            $root = $chain.ChainElements[$chain.ChainElements.Count - 1].Certificate
            if (-not (Get-ChildItem -Path Cert:\LocalMachine\Root -ErrorAction SilentlyContinue | Where-Object { $_.Thumbprint -eq $root.Thumbprint })) {
                $problem = "its root CA (" + $root.Subject + ") is not in this computer's Trusted Root store"
            }
        }
    }
    if (-not $problem) {
        Write-Host ($name + ": signed by " + $sig.SignerCertificate.Subject + ", trusted for this computer")
        # Signed and trusted: the internet-download mark is no longer needed
        Unblock-File -Path $Path -ErrorAction SilentlyContinue
        return $true
    }
    if ($policy -eq "AllSigned" -or $script:RequireSigned) {
        throw ($name + ": " + $problem + ". This server runs scripts under " + $policy + ": sign the agent files and trust the publisher for the computer, then run this again. Nothing was installed.")
    }
    Write-Warning ($name + ": " + $problem + ". The agent's task will run it under RemoteSigned for its own process only; sign it to run under AllSigned.")
    return $false
}

$script:AgentTrusted = $false
function Copy-Agent {
    $script:AgentTrusted = [bool](Test-Signature (Join-Path $Here "patch-agent.ps1"))
    Lock-Folder $InstallDir
    Copy-Item -Force (Join-Path $Here "patch-agent.ps1") $Agent
    Unblock-File -Path $Agent -ErrorAction SilentlyContinue
    # Installed by hand: an update from PATCH-01 still waiting to be confirmed no longer applies
    Unregister-ScheduledTask -TaskName "PATCH-01 agent update check" -Confirm:$false -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath (Join-Path $DataDir "update\pending.json") -Force -ErrorAction SilentlyContinue
}

function Register-AgentTask {
    # The policy for the agent's own process only; the server's setting (Restricted, say) stays as it is
    # for everything else. A signed, trusted agent runs under AllSigned, so a changed file would be refused;
    # otherwise RemoteSigned (the file is local, in a folder only SYSTEM and Administrators can write).
    # A policy set by Group Policy (MachinePolicy) still wins over this.
    $pol = $(if ($script:AgentTrusted) { "AllSigned" } else { "RemoteSigned" })
    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument ("-NoProfile -NonInteractive -ExecutionPolicy " + $pol + " -File `"" + $Agent + "`" -Run")
    Write-Host ("Scheduled task: runs the agent as SYSTEM every 2 minutes and 1 minute after start-up, under " + $pol + " for its own process")
    # Every 2 minutes: a new job step is picked up quickly (a run with nothing to do is one short check-in)
    $every = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 2)
    # Also one minute after Windows starts: after a patch job's restart the postcheck starts at once
    $boot = New-ScheduledTaskTrigger -AtStartup
    $boot.Delay = "PT1M"
    $trigger = @($every, $boot)
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
    # 12 hours: a precheck with its download and the install can run in one go; one run at a time
    $settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 12) -StartWhenAvailable -DontStopOnIdleEnd
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
}

switch ($PSCmdlet.ParameterSetName) {
    "SelfTest" {
        & (Join-Path $Here "patch-agent.ps1") -SelfTest -Server $Server -Pin $Pin
    }
    "Install" {
        Copy-Agent
        Lock-Folder $DataDir
        & $Agent -Enroll -Server $Server -Token $Token -Pin $Pin
        Register-AgentTask
        Write-Output "Sending the first inventory (Windows' own update list when it checked WSUS today, else a WSUS search)..."
        & $Agent -Inventory
        Write-Output "Installed. The agent runs every 2 minutes as SYSTEM; its log is $DataDir\agent.log"
    }
    "Update" {
        if (-not (Test-Path (Join-Path $DataDir "agent.json"))) { throw "Not installed here; use -Server -Pin -Token." }
        Wait-AgentIdle
        try { Copy-Agent; Lock-Folder $DataDir } finally { Register-AgentTask }
        Write-Output "Agent files updated; the enrolment is unchanged."
    }
    "Repin" {
        $cfgFile = Join-Path $DataDir "agent.json"
        if (-not (Test-Path $cfgFile)) { throw "Not installed here; nothing to re-pin." }
        $cfg = Get-Content -Raw $cfgFile | ConvertFrom-Json
        $old = $cfg.pin
        # The installed agent may predate two-pin support: bring it up to date first
        Wait-AgentIdle
        try { Copy-Agent; Lock-Folder $DataDir } finally { Register-AgentTask }
        $cfg.pin = $Pin
        ConvertTo-Json -InputObject $cfg | Set-Content -Path $cfgFile -Encoding UTF8
        # Prove the new pin works now, and put the old one back if it does not
        try {
            & $Agent -Inventory
            Write-Output "Re-pinned and checked: PATCH-01 is reachable with the new pin."
        } catch {
            $m = [string]$_.Exception.Message
            $cfg.pin = $old
            ConvertTo-Json -InputObject $cfg | Set-Content -Path $cfgFile -Encoding UTF8
            # Say what failed: only a certificate mismatch is a pin problem
            if ($m -match "does not match the pin") { throw ("The new pin did not work, so the old one was kept: " + $m) }
            if ($m -match "HTTP 401|unknown or revoked token") { throw ("PATCH-01 no longer accepts this agent's identity (removed on PATCH-01?): enrol it again with a token. The pin is fine. " + $m) }
            if ($m -match "HTTP 403|host is decommissioned") { throw ("This server is decommissioned on PATCH-01: enrol it again with a token. The pin is fine. " + $m) }
            if ($m -match "Key not valid|cannot be read|CryptographicException") { throw ("This server's saved agent identity cannot be read (rebuilt or cloned?): enrol it again with a token. " + $m) }
            throw ("The check after re-pinning failed, so the old pin was put back: " + $m)
        }
    }
    "Uninstall" {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName "PATCH-01 agent update check" -Confirm:$false -ErrorAction SilentlyContinue
        Remove-Item -Recurse -Force $InstallDir, $DataDir -ErrorAction SilentlyContinue
        Write-Output "Removed. Also remove the server from PATCH-01 (Servers page) if it is being retired."
    }
}
