-- ===========================================================================
-- PATCH-01 : schema 018 - Windows servers
--
-- Applied after 017. Idempotent.
--
-- Windows fits the same CVE engine as Linux: each monthly cumulative update
-- (a KB) is an advisory for its Windows Server version, its fixed OS build
-- (10.0.17763.6414) is the "fixed version" of a package called
-- windows-os-build, and the server's own build is the installed version.
-- The CVEs each KB fixes come from Microsoft's Security Update Guide.
--
-- windows_updates: what Windows Update reports as not yet installed on each
-- server, searched against the WSUS the server uses, so it reflects your
-- approvals. Replaced wholesale on each report.
-- ===========================================================================

ALTER TYPE package_manager ADD VALUE IF NOT EXISTS 'wua';

CREATE TABLE IF NOT EXISTS windows_updates (
    host_id      UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    update_id    TEXT NOT NULL,                  -- Windows Update's own identity
    kb           TEXT,
    title        TEXT NOT NULL,
    severity     TEXT,                           -- Critical, Important, Moderate, Low
    categories   TEXT[] NOT NULL DEFAULT '{}',
    cves         TEXT[] NOT NULL DEFAULT '{}',
    downloaded   BOOLEAN,
    reboot_behaviour TEXT,
    size_mb      INTEGER,
    reported_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (host_id, update_id)
);

ALTER TABLE hosts ADD COLUMN IF NOT EXISTS wu_source      TEXT;          -- wsus or microsoft
ALTER TABLE hosts ADD COLUMN IF NOT EXISTS wu_server      TEXT;          -- the WSUS address
ALTER TABLE hosts ADD COLUMN IF NOT EXISTS wu_searched_at TIMESTAMPTZ;
ALTER TABLE hosts ADD COLUMN IF NOT EXISTS wu_error       TEXT;
ALTER TABLE hosts ADD COLUMN IF NOT EXISTS os_edition     TEXT;          -- e.g. Windows Server 2019 Standard

-- One row per Microsoft monthly release imported, so re-imports are cheap
CREATE TABLE IF NOT EXISTS msrc_releases (
    id           TEXT PRIMARY KEY,               -- e.g. 2024-Oct
    released_at  TIMESTAMPTZ,
    imported_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    cves         INTEGER,
    kbs          INTEGER
);

-- The default group for Windows servers' enrolment tokens
INSERT INTO host_groups (name, description, environment, max_concurrent, patch_order)
VALUES ('windows', 'Windows servers', 'prod', 5, 100)
ON CONFLICT (name) DO NOTHING;

INSERT INTO schema_version (version, description)
VALUES (18, 'Windows servers: Windows Update results, Microsoft releases')
ON CONFLICT (version) DO NOTHING;
