-- ===========================================================================
-- PATCH-01 : schema 019 - Windows software inventory and the WSUS view
--
-- Applied after 018. Idempotent.
--
-- windows_software: programs installed on each Windows server (Programs and
--   Features: name, version, publisher, install date), replaced on each report.
-- wsus_sources: each WSUS server that reports to PATCH-01, with its reporting
--   token (hashed) and its latest summary: sync health, update counts.
-- wsus_computers: the computers each WSUS knows, with when they last
--   reported and how many approved updates they still need.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS windows_software (
    host_id      UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    name         TEXT NOT NULL,
    version      TEXT NOT NULL DEFAULT '',
    publisher    TEXT,
    installed_on DATE,
    size_mb      INTEGER,
    arch         TEXT,                       -- 64-bit or 32-bit
    reported_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (host_id, name, version, arch)
);
CREATE INDEX IF NOT EXISTS idx_winsw_name ON windows_software (lower(name));

CREATE TABLE IF NOT EXISTS wsus_sources (
    name          TEXT PRIMARY KEY,          -- the WSUS server's name
    token_hash    TEXT NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    reported_at   TIMESTAMPTZ,
    report        JSONB,                      -- sync state, counts, groups
    error         TEXT
);

CREATE TABLE IF NOT EXISTS wsus_computers (
    source        TEXT NOT NULL REFERENCES wsus_sources(name) ON DELETE CASCADE,
    name          TEXT NOT NULL,              -- FQDN as WSUS knows it
    ip            TEXT,
    os            TEXT,
    groups        TEXT[] NOT NULL DEFAULT '{}',
    last_reported TIMESTAMPTZ,
    last_synced   TIMESTAMPTZ,
    needed        INTEGER,                    -- approved, not installed
    failed        INTEGER,
    pending_reboot INTEGER,
    PRIMARY KEY (source, name)
);

INSERT INTO schema_version (version, description)
VALUES (19, 'Windows software inventory; WSUS view')
ON CONFLICT (version) DO NOTHING;
