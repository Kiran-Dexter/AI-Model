-- ===========================================================================
-- PATCH-01 : schema 014 - mail settings and recipients, managed in the console
--
-- Applied after 013. Idempotent.
--
-- One settings row. The relay password is stored encrypted (Fernet), with a
-- key that exists only in /patch/secrets/mail.key on PATCH-01: a database
-- dump or backup alone cannot reveal it. The console can replace the
-- password but never reads it back.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS mail_settings (
    id              INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    enabled         BOOLEAN NOT NULL DEFAULT FALSE,
    host            TEXT,
    port            INTEGER NOT NULL DEFAULT 25 CHECK (port BETWEEN 1 AND 65535),
    tls             TEXT NOT NULL DEFAULT 'starttls' CHECK (tls IN ('starttls', 'tls', 'none')),
    verify          BOOLEAN NOT NULL DEFAULT TRUE,
    ca_pem          TEXT,                        -- the relay's CA, if it is internal
    username        TEXT,
    password_enc    TEXT,                        -- Fernet token; never returned to the console
    from_addr       TEXT,
    from_name       TEXT,
    send_critical   BOOLEAN NOT NULL DEFAULT TRUE,
    send_tasks      BOOLEAN NOT NULL DEFAULT TRUE,
    send_digest     BOOLEAN NOT NULL DEFAULT TRUE,
    send_weekly     BOOLEAN NOT NULL DEFAULT TRUE,
    digest_time     TEXT NOT NULL DEFAULT '07:00' CHECK (digest_time ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'),
    weekly_day      TEXT NOT NULL DEFAULT 'mon' CHECK (weekly_day IN ('mon','tue','wed','thu','fri','sat','sun')),
    console_url     TEXT,
    company         TEXT,
    updated_by      TEXT,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO mail_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS mail_recipients (
    id          BIGSERIAL PRIMARY KEY,
    address     TEXT NOT NULL,
    name        TEXT,
    critical    BOOLEAN NOT NULL DEFAULT TRUE,
    tasks       BOOLEAN NOT NULL DEFAULT TRUE,
    digest      BOOLEAN NOT NULL DEFAULT TRUE,
    weekly      BOOLEAN NOT NULL DEFAULT TRUE,
    added_by    TEXT,
    added_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_mail_recipients_addr ON mail_recipients (lower(address));

INSERT INTO schema_version (version, description)
VALUES (14, 'mail settings and recipients managed in the console')
ON CONFLICT (version) DO NOTHING;
