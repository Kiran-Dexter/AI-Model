-- ===========================================================================
-- PATCH-01 : schema 016 - one e-mail signature for every mail PATCH-01 sends
--
-- Applied after 015. Idempotent. Used on report e-mails and alerts alike.
-- ===========================================================================

ALTER TABLE mail_settings ADD COLUMN IF NOT EXISTS signature TEXT;

-- The figures of each report, kept with it, so an e-mail about a report
-- describes exactly that report even after newer scans
ALTER TABLE reports ADD COLUMN IF NOT EXISTS facts JSONB;

INSERT INTO schema_version (version, description)
VALUES (16, 'global e-mail signature; report figures kept with each report')
ON CONFLICT (version) DO NOTHING;
