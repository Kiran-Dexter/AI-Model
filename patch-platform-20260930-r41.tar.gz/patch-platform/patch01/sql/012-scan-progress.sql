-- ===========================================================================
-- PATCH-01 : schema 012 - hardening scan progress
--
-- Applied after 011. Idempotent.
--
-- The agent reports where a scan is: downloading the benchmark, scanning
-- (rules done out of total), uploading. The console shows it live.
-- ===========================================================================

ALTER TABLE hardening_scans ADD COLUMN IF NOT EXISTS stage          TEXT;  -- picked_up, downloading, scanning, uploading, processing
ALTER TABLE hardening_scans ADD COLUMN IF NOT EXISTS stage_at       TIMESTAMPTZ;
ALTER TABLE hardening_scans ADD COLUMN IF NOT EXISTS progress_done  INTEGER;
ALTER TABLE hardening_scans ADD COLUMN IF NOT EXISTS progress_total INTEGER;

INSERT INTO schema_version (version, description)
VALUES (12, 'hardening scan progress')
ON CONFLICT (version) DO NOTHING;
