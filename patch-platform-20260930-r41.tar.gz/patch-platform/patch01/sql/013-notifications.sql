-- ===========================================================================
-- PATCH-01 : schema 013 - mail alerts
--
-- Applied after 012. Idempotent.
--
-- notifications: every mail PATCH-01 sends, queued first and retried, so a
--   relay outage delays mail rather than losing it. Kept 180 days.
-- notify_seen: what has already been alerted on. Events (a failed change, a
--   new exploited CVE on a server) are alerted once. Conditions (a host down,
--   a full datastore) are alerted when they start; the key is removed when the
--   condition clears, so a later recurrence alerts again.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS notifications (
    id              BIGSERIAL PRIMARY KEY,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    category        TEXT NOT NULL,              -- critical, task, digest, weekly, test, system
    severity        TEXT NOT NULL DEFAULT 'info',
    subject         TEXT NOT NULL,
    body_text       TEXT NOT NULL,
    body_html       TEXT,
    recipients      TEXT[] NOT NULL DEFAULT '{}',
    state           TEXT NOT NULL DEFAULT 'queued',   -- queued, sent, failed, disabled
    attempts        INTEGER NOT NULL DEFAULT 0,
    next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    sent_at         TIMESTAMPTZ,
    last_error      TEXT,
    event_keys      TEXT[] NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_notifications_queue ON notifications (next_attempt_at) WHERE state = 'queued';
CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications (created_at DESC);

CREATE TABLE IF NOT EXISTS notify_seen (
    key         TEXT PRIMARY KEY,
    kind        TEXT NOT NULL,                  -- event or condition
    first_seen  TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS notify_state (
    key         TEXT PRIMARY KEY,
    value       TEXT,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO schema_version (version, description)
VALUES (13, 'mail alerts: queue, de-duplication, schedule state')
ON CONFLICT (version) DO NOTHING;
