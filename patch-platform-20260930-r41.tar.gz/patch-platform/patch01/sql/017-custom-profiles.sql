-- ===========================================================================
-- PATCH-01 : schema 017 - custom profiles from an uploaded document
--
-- Applied after 016. Idempotent.
--
-- A custom profile is built from a document (txt, csv, docx) listing the
-- settings to check. Each line becomes an item, matched to benchmark rules
-- by CIS number, by title, by AI-01 on request, or by hand. People review the
-- matches before the profile is used. Lines no rule can check stay in the
-- profile and are reported as not checked automatically.
--
-- Scans with a custom profile use level 'custom:<profile id>'.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS custom_profiles (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            TEXT NOT NULL,
    description     TEXT,
    product         TEXT NOT NULL,              -- the benchmark the document's CIS numbers follow
    status          TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'retired')),
    version         INTEGER NOT NULL DEFAULT 1,
    source_file     TEXT,
    source_sha256   TEXT,
    created_by      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by      TEXT,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS custom_profile_items (
    id          BIGSERIAL PRIMARY KEY,
    profile_id  UUID NOT NULL REFERENCES custom_profiles(id) ON DELETE CASCADE,
    line_no     INTEGER NOT NULL,
    source_text TEXT NOT NULL,
    rule_ids    TEXT[] NOT NULL DEFAULT '{}',
    matched_by  TEXT NOT NULL DEFAULT 'none',   -- cis, title, ai, manual, none, skipped
    confidence  TEXT,                           -- high, medium, low
    note        TEXT
);
CREATE INDEX IF NOT EXISTS idx_cpi_profile ON custom_profile_items (profile_id, line_no);

INSERT INTO schema_version (version, description)
VALUES (17, 'custom hardening profiles from uploaded documents')
ON CONFLICT (version) DO NOTHING;
