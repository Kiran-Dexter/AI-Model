-- ===========================================================================
-- PATCH-01 : schema 015 - branding and the report archive
--
-- Applied after 014. Idempotent.
--
-- branding: how reports and mail present the organisation. The logo itself
-- is a PNG dropped in /patch/data/branding on PATCH-01; PATCH-01 finds,
-- trims and sizes it.
-- reports: every report generated, kept with its fingerprint so a copy
-- handed to an auditor can be matched to the original.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS branding (
    id              INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    company         TEXT,
    copyright       TEXT,
    classification  TEXT NOT NULL DEFAULT 'CONFIDENTIAL',
    accent          TEXT CHECK (accent IS NULL OR accent ~ '^#[0-9A-Fa-f]{6}$'),  -- blank: taken from the logo
    updated_by      TEXT,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO branding (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS reports (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    number        BIGSERIAL UNIQUE,
    kind          TEXT NOT NULL,                -- hardening
    level         TEXT,
    scope         JSONB NOT NULL DEFAULT '{}'::jsonb,
    format        TEXT NOT NULL CHECK (format IN ('pdf', 'docx')),
    title         TEXT,
    generated_by  TEXT,
    generated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    pages         INTEGER,
    servers       INTEGER,
    score         NUMERIC(5,2),
    size_bytes    BIGINT,
    sha256        TEXT,
    path          TEXT
);
CREATE INDEX IF NOT EXISTS idx_reports_at ON reports (generated_at DESC);

INSERT INTO schema_version (version, description)
VALUES (15, 'branding and report archive')
ON CONFLICT (version) DO NOTHING;
