"""Custom hardening profiles, built from a document the user uploads.

Each line of the document (txt, csv or docx) becomes an item, matched to
benchmark rules in this order, most reliable first:

  1. CIS number: "5.2.4 Ensure SSH root login is disabled" matches the rules
     carrying CIS 5.2.4 in the chosen benchmark. If the line's words do not
     resemble those rules, the match is marked for checking: CIS renumbers
     between benchmark versions.
  2. Title: lines without a number are compared with rule titles and names.
  3. AI-01, only when asked, and only choosing from a shortlist of real rules.
  4. By hand, in the review.

A profile is scanned with an OpenSCAP tailoring file that selects exactly its
rules, so a scan checks those settings and nothing else.
"""

import csv
import difflib
import hashlib
import io
import os
import re
from datetime import datetime, timezone
from xml.sax.saxutils import escape, quoteattr

RULE_PREFIX = "xccdf_org.ssgproject.content_rule_"
TAILOR_DIR = os.path.join(os.environ.get("HARDENING_DIR", "/hardening"), "tailoring")
MAX_LINES = 1500
CIS_RE = re.compile(r"(?<![\d.])(\d{1,2}(?:\.\d{1,2}){1,4})(?![\d.])")
STOP = set("""a an and are as at be by for from has have in into is it its not of on or that the this to with
ensure ensured configure configured verify make sure must shall should set setting settings enable enabled
disable disabled properly correct correctly appropriate is are be all any""".split())
PRODUCT_NAME = {"rhel8": "RHEL 8", "rhel9": "RHEL 9", "rhel10": "RHEL 10", "ol7": "Oracle Linux 7",
                "ol8": "Oracle Linux 8", "ol9": "Oracle Linux 9", "ubuntu2004": "Ubuntu 20.04",
                "ubuntu2204": "Ubuntu 22.04", "ubuntu2404": "Ubuntu 24.04"}


# ---------------------------------------------------------------------------
# Reading the document
# ---------------------------------------------------------------------------

def extract_lines(filename, data):
    """[(line number, text)] from a txt, csv or docx file."""
    name = (filename or "").lower()
    out = []
    if name.endswith(".docx"):
        import docx
        d = docx.Document(io.BytesIO(data))
        for p in d.paragraphs:
            out.append(p.text)
        for t in d.tables:
            for row in t.rows:
                cells, seen = [], set()
                for c in row.cells:             # merged cells repeat: keep each once
                    tx = c.text.strip()
                    if tx and tx not in seen:
                        seen.add(tx); cells.append(tx)
                out.append("  ".join(cells))
    else:
        text = None
        for enc in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                text = data.decode(enc); break
            except UnicodeDecodeError:
                continue
        if name.endswith(".csv"):
            try:
                dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t|")
            except csv.Error:
                dialect = csv.excel
            for row in csv.reader(io.StringIO(text), dialect):
                out.append("  ".join(c.strip() for c in row if c.strip()))
        else:
            out = text.splitlines()
    lines = []
    for raw in out:
        t = " ".join(raw.split())
        # Headings and blanks carry nothing to check
        if len(t) < 6 or not re.search(r"[A-Za-z]{3}", t):
            continue
        if re.fullmatch(r"(recommendation|control|cis ?(id|ref|no\.?)|title|description|section|item)s?"
                        r"(\s+(recommendation|title|description|id|ref|status|level))*", t, re.I):
            continue                            # a table's header row
        lines.append(t)
        if len(lines) >= MAX_LINES:
            break
    return list(enumerate(lines, start=1))


# ---------------------------------------------------------------------------
# Matching
# ---------------------------------------------------------------------------

# How standards phrase things, mapped to how benchmark rules name them
SYNONYM = {"characters": "length", "character": "length", "chars": "length", "long": "length", "minlen": "length",
           "installed": "package", "install": "package", "uninstall": "package", "uninstalled": "package",
           "removed": "package", "remove": "package", "client": "package",
           "bootloader": "boot", "grub": "boot", "grub2": "boot", "loader": "boot",
           "lock": "lockout", "locked": "lockout", "locks": "lockout", "faillock": "lockout",
           "attempts": "attempt", "logon": "login", "logins": "login",
           "auditd": "audit", "auditing": "audit", "running": "enabled", "active": "enabled",
           "ntp": "time", "chrony": "time", "chronyd": "time", "clock": "time",
           "warning": "banner", "motd": "banner", "issue": "banner",
           "enforcing": "enforce", "enforced": "enforce", "permitrootlogin": "root",
           "usb": "usb", "storage": "storage", "modprobe": "module"}


def _norm(w):
    w = SYNONYM.get(w, w)
    if len(w) > 4 and w.endswith("s") and not w.endswith("ss"):
        w = w[:-1]
    return SYNONYM.get(w, w)


def tokens(text):
    words = re.findall(r"[a-z0-9]+", (text or "").lower().replace("_", " ").replace("-", " "))
    return {_norm(w) for w in words if w not in STOP and len(w) > 1 and not w.isdigit()}


def catalog(conn, product):
    """Every rule in the active content for a product, ready to match."""
    rows = conn.execute(
        """SELECT r.rule_id, r.title, r.cis_ref, r.severity FROM hardening_rules r
             JOIN hardening_content c USING (content_version, product)
            WHERE c.active AND r.product = %s""", (product,)).fetchall()
    cat, by_cis = [], {}
    for r in rows:
        short = r["rule_id"].replace(RULE_PREFIX, "")
        item = {"rule_id": r["rule_id"], "title": r["title"] or short, "cis": r["cis_ref"], "severity": r["severity"],
                "tok": tokens((r["title"] or "") + " " + short)}
        cat.append(item)
        for ref in [x.strip() for x in (r["cis_ref"] or "").split(",") if x.strip()]:
            by_cis.setdefault(ref, []).append(item)
    return cat, by_cis


def _similar(text_tok, text, rule):
    if not text_tok or not rule["tok"]:
        return 0.0
    common = len(text_tok & rule["tok"])
    if common == 0:
        return 0.0
    jac = common / len(text_tok | rule["tok"])
    cov_rule = common / len(rule["tok"])        # how much of the rule the line mentions
    cov_line = common / len(text_tok)           # how much of the line the rule covers
    seq = difflib.SequenceMatcher(None, " ".join(sorted(text_tok)), " ".join(sorted(rule["tok"]))).ratio()
    score = 0.25 * jac + 0.2 * cov_rule + 0.4 * cov_line + 0.15 * seq
    if common < 2 and len(text_tok) > 1:        # one shared word is not a match
        score *= 0.5
    return round(score, 3)


def match_line(text, cat, by_cis):
    """(rule_ids, matched_by, confidence, note) for one line of the document."""
    tok = tokens(CIS_RE.sub(" ", text))
    for num in CIS_RE.findall(text):
        rules = by_cis.get(num)
        if not rules:
            continue
        best = max(_similar(tok, text, r) for r in rules) if tok else 1.0
        if not tok or best >= 0.18:
            return [r["rule_id"] for r in rules], "cis", "high" if best >= 0.3 or not tok else "medium", \
                f"CIS {num}" + (f", {len(rules)} rules" if len(rules) > 1 else "")
        return [r["rule_id"] for r in rules], "cis", "low", \
            (f"CIS {num} exists, but its rules do not resemble this line: the document may follow another "
             "benchmark version. Check it.")
    if not tok:
        return [], "none", None, "Nothing in this line that a rule could check."
    scored = sorted(((_similar(tok, text, r), r) for r in cat), key=lambda x: -x[0])
    if scored and scored[0][0] >= 0.45 and (len(scored) < 2 or scored[0][0] - scored[1][0] >= 0.04):
        top, r = scored[0]
        return [r["rule_id"]], "title", "high" if top >= 0.62 else "medium", f"Title match ({round(top * 100)}%)"
    if scored and scored[0][0] >= 0.45:
        return [], "none", None, ("Several rules are equally close; pick the right one, or ask AI-01: "
                                  + "; ".join(r["title"] for _, r in scored[:3]))
    return [], "none", None, "No rule matched automatically. Pick one, ask AI-01, or leave it as a manual check."


def shortlist(text, cat, n=8):
    tok = tokens(CIS_RE.sub(" ", text))
    return [r for s, r in sorted(((_similar(tok, text, r), r) for r in cat), key=lambda x: -x[0])[:n] if s > 0]


def build(conn, name, product, filename, data, user, description=None):
    """Create a draft profile from a document and match every line."""
    lines = extract_lines(filename, data)
    if not lines:
        raise ValueError("No lines with anything to check were found in the file.")
    cat, by_cis = catalog(conn, product)
    if not cat:
        raise ValueError(f"No benchmark content is imported for {PRODUCT_NAME.get(product, product)}.")
    prof = conn.execute(
        """INSERT INTO custom_profiles (name, description, product, source_file, source_sha256, created_by, updated_by)
           VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING id""",
        (name, description, product, os.path.basename(filename or "pasted text"), hashlib.sha256(data).hexdigest(),
         user, user)).fetchone()
    counts = {"cis": 0, "title": 0, "none": 0}
    with conn.cursor() as cur:
        rows = []
        for no, text in lines:
            ids, how, conf, note = match_line(text, cat, by_cis)
            counts[how] = counts.get(how, 0) + 1
            rows.append((prof["id"], no, text[:2000], ids, how, conf, note))
        cur.executemany(
            """INSERT INTO custom_profile_items (profile_id, line_no, source_text, rule_ids, matched_by, confidence, note)
               VALUES (%s,%s,%s,%s,%s,%s,%s)""", rows)
    return str(prof["id"]), {"lines": len(lines), **counts}


def suggest(conn, profile_id, item_id):
    """AI-01 picks from a shortlist of real rules, or says none fits."""
    from . import llm
    it = conn.execute("SELECT i.*, p.product FROM custom_profile_items i JOIN custom_profiles p ON p.id = i.profile_id "
                      "WHERE i.id=%s AND i.profile_id=%s", (item_id, profile_id)).fetchone()
    if not it:
        raise ValueError("No such line in this profile.")
    cat, _ = catalog(conn, it["product"])
    short = shortlist(it["source_text"], cat)
    if not short:
        return None, "No rule is even close to this line: leave it as a manual check."
    if not llm.configured():
        return None, "AI-01 is not configured."
    opts = "\n".join(f"{i}. {r['title']} ({r['rule_id'].replace(RULE_PREFIX, '')})" for i, r in enumerate(short, 1))
    res = llm._chat([{"role": "system", "content":
                      "You map a line from a security hardening standard to the one benchmark rule that checks it. "
                      "Reply with the number of the best rule only, or 0 if none of them checks what the line asks. "
                      "No other words."},
                     {"role": "user", "content": f"Line: {it['source_text'][:600]}\n\nRules:\n{opts}"}], max_tokens=6)
    reply = res["choices"][0]["message"]["content"].strip()
    m = re.search(r"\d+", reply)
    k = int(m.group(0)) if m else 0
    if not 1 <= k <= len(short):
        return None, "AI-01 found no rule that checks this line: leave it as a manual check, or pick one."
    r = short[k - 1]
    conn.execute("UPDATE custom_profile_items SET rule_ids=%s, matched_by='ai', confidence='medium', note=%s WHERE id=%s",
                 ([r["rule_id"]], "Suggested by AI-01: confirm it checks what the line asks.", item_id))
    return r, "Suggested by AI-01 from the closest rules. Confirm it checks what the line asks."


def search(conn, product, q, limit=25):
    cat, by_cis = catalog(conn, product)
    q = (q or "").strip()
    if CIS_RE.fullmatch(q):
        return by_cis.get(q, [])[:limit]
    tok = tokens(q)
    ql = q.lower().replace(" ", "_")
    scored = []
    for r in cat:
        s = _similar(tok, q, r) + (0.5 if ql and ql in r["rule_id"] else 0)
        if s > 0:
            scored.append((s, r))
    return [r for _, r in sorted(scored, key=lambda x: -x[0])[:limit]]


# ---------------------------------------------------------------------------
# Scanning: an OpenSCAP tailoring file selecting exactly the profile's rules
# ---------------------------------------------------------------------------

def xccdf_profile_id(profile_id):
    return "xccdf_patch01_profile_custom_" + str(profile_id).replace("-", "")[:16]


def tailoring(conn, profile, product, content):
    """(relative path, sha256, rules selected, rules missing) for one product.

    Every rule of the benchmark is listed: the profile's rules selected, all
    others deselected, so nothing else is evaluated whatever the benchmark's
    defaults are.
    """
    wanted = set()
    for r in conn.execute("SELECT rule_ids FROM custom_profile_items WHERE profile_id=%s", (profile["id"],)).fetchall():
        wanted |= set(r["rule_ids"] or [])
    rules = [r["rule_id"] for r in conn.execute(
        "SELECT rule_id FROM hardening_rules WHERE content_version=%s AND product=%s ORDER BY rule_id",
        (content["content_version"], product)).fetchall()]
    have = set(rules)
    chosen = sorted(wanted & have)
    missing = sorted(wanted - have)
    pid = xccdf_profile_id(profile["id"])
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
    sel = "\n".join(f'    <xccdf:select idref={quoteattr(r)} selected="{"true" if r in wanted else "false"}"/>'
                    for r in rules)
    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<xccdf:Tailoring xmlns:xccdf="http://checklists.nist.gov/xccdf/1.2" id="xccdf_patch01_tailoring_{str(profile['id']).replace('-', '')[:16]}">
  <xccdf:benchmark href={quoteattr(os.path.basename(content['file_name']))}/>
  <xccdf:version time="{now}">{int(profile['version'])}</xccdf:version>
  <xccdf:Profile id="{pid}">
    <xccdf:title>{escape(profile['name'])}</xccdf:title>
    <xccdf:description>{escape('Custom profile from ' + (profile.get('source_file') or 'a document') + ', built in PATCH-01.')}</xccdf:description>
{sel}
  </xccdf:Profile>
</xccdf:Tailoring>
""".encode()
    os.makedirs(TAILOR_DIR, exist_ok=True)
    name = f"{str(profile['id'])[:8]}-v{int(profile['version'])}-{product}-{content['content_version']}.xml"
    with open(os.path.join(TAILOR_DIR, name), "wb") as fh:
        fh.write(xml)
    return name, hashlib.sha256(xml).hexdigest(), chosen, missing


def level_of(profile_id):
    return f"custom:{profile_id}"


def profile_for_level(conn, level):
    if not (level or "").startswith("custom:"):
        return None
    return conn.execute("SELECT * FROM custom_profiles WHERE id=%s", (level.split(":", 1)[1],)).fetchone()
