"""Branding for reports and mail: the logo, company name, copyright, colours.

Drop a PNG in /patch/data/branding on PATCH-01 (mounted at /branding).
PATCH-01 picks logo.png if there is one, otherwise the largest PNG there;
logo-white.png, if present, is used on dark backgrounds. The chosen file is
trimmed of empty margins, scaled to a crisp print size, analysed for whether
it is light or dark and for its main colour, and cached until the file
changes. Nothing needs configuring for the logo itself.
"""

import glob
import hashlib
import io
import os

BRAND_DIR = os.environ.get("BRANDING_DIR", "/branding")
CACHE_DIR = os.path.join(os.environ.get("HARDENING_DIR", "/hardening"), "cache", "branding")
MAX_BYTES = 25 * 1024 * 1024
MAX_SIDE = 10000               # refuse absurd images
OUT_MAX_W, OUT_MAX_H = 1600, 520
NAVY = "#0B1F3A"
DEFAULT_ACCENT = "#1F5AA6"


def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def find_logos(directory=None):
    """(main logo, white logo or None). Only real PNG files count."""
    directory = directory or BRAND_DIR          # read at call time, not import time
    pngs = []
    for p in glob.glob(os.path.join(directory, "*")):
        if not os.path.isfile(p) or os.path.getsize(p) > MAX_BYTES:
            continue
        try:
            with open(p, "rb") as fh:
                if fh.read(8) != b"\x89PNG\r\n\x1a\n":
                    continue
        except OSError:
            continue
        pngs.append(p)
    by_name = {os.path.basename(p).lower(): p for p in pngs}
    white = by_name.get("logo-white.png")
    main = by_name.get("logo.png")
    if not main:
        others = [p for p in pngs if p != white]
        main = max(others, key=os.path.getsize) if others else None
    return main, white


def _trim(im):
    """Remove empty margins: transparent ones, or a plain background colour."""
    from PIL import Image, ImageChops
    alpha = im.getchannel("A")
    if alpha.getextrema()[0] < 250:                       # has transparency
        box = alpha.point(lambda a: 255 if a > 12 else 0).getbbox()
    else:                                                 # opaque: trim the corner colour
        bg = im.getpixel((0, 0))
        diff = ImageChops.difference(im.convert("RGB"), Image.new("RGB", im.size, bg[:3]))
        box = diff.convert("L").point(lambda v: 255 if v > 18 else 0).getbbox()
    if not box:
        return im
    pad = max(2, int(0.02 * max(box[2] - box[0], box[3] - box[1])))
    box = (max(0, box[0] - pad), max(0, box[1] - pad), min(im.width, box[2] + pad), min(im.height, box[3] + pad))
    return im.crop(box)


def _analyse(im):
    """Mean luminance of the visible pixels, and the most frequent strong colour."""
    import colorsys
    small = im.copy()
    small.thumbnail((200, 200))
    px = [p for p in small.getdata() if p[3] > 128]
    if not px:
        return 1.0, None, True
    lum = sum(0.2126 * r + 0.7152 * g + 0.0722 * b for r, g, b, _ in px) / (255.0 * len(px))
    buckets = {}
    for r, g, b, _ in px:
        h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
        if s >= 0.35 and 0.25 <= v <= 0.92:               # a real colour, not grey, white or black
            key = (r // 24, g // 24, b // 24)
            e = buckets.setdefault(key, [0, 0, 0, 0])
            e[0] += 1; e[1] += r; e[2] += g; e[3] += b
    accent = None
    if buckets:
        n, r, g, b = max(buckets.values(), key=lambda e: e[0])
        if n >= 0.03 * len(px):                           # enough of it to be a brand colour
            accent = "#{:02X}{:02X}{:02X}".format(r // n, g // n, b // n)
    transparent = im.getchannel("A").getextrema()[0] < 250
    return lum, accent, transparent


def process(path):
    """Trimmed, sized PNG bytes and what was learned about the logo, cached."""
    from PIL import Image
    digest = _sha(path)
    os.makedirs(CACHE_DIR, exist_ok=True)
    cached = os.path.join(CACHE_DIR, digest + ".png")
    meta_path = cached + ".meta"
    if os.path.exists(cached) and os.path.exists(meta_path):
        import json
        with open(meta_path) as fh:
            meta = json.load(fh)
        with open(cached, "rb") as fh:
            return fh.read(), meta
    with Image.open(path) as src:
        if max(src.size) > MAX_SIDE:
            raise ValueError(f"{os.path.basename(path)} is {src.width}x{src.height}: too large to be a logo")
        src.load()
        orig = src.size
        im = src.convert("RGBA")
    im = _trim(im)
    scale = min(1.0, OUT_MAX_W / im.width, OUT_MAX_H / im.height)
    if scale < 1.0:
        im = im.resize((max(1, round(im.width * scale)), max(1, round(im.height * scale))), Image.LANCZOS)
    lum, accent, transparent = _analyse(im)
    buf = io.BytesIO()
    im.save(buf, "PNG", optimize=True)
    data = buf.getvalue()
    warnings = []
    if im.width < 300:
        warnings.append(f"The logo is only {im.width} pixels wide after trimming, so it may look soft in print. "
                        "A PNG at least 600 pixels wide is best.")
    if not transparent:
        warnings.append("The logo has a solid background. A PNG with a transparent background sits more cleanly "
                        "on coloured areas.")
    meta = {"file": os.path.basename(path), "sha256": digest, "original": list(orig), "size": [im.width, im.height],
            "aspect": round(im.width / im.height, 4), "bytes_in": os.path.getsize(path), "bytes_out": len(data),
            "luminance": round(lum, 3), "dark": lum < 0.5, "accent": accent, "transparent": transparent,
            "warnings": warnings}
    tmp = cached + ".tmp"
    with open(tmp, "wb") as fh:
        fh.write(data)
    os.replace(tmp, cached)
    import json
    with open(meta_path, "w") as fh:
        json.dump(meta, fh)
    return data, meta


def settings(conn):
    """Everything a report or mail needs to present the organisation."""
    row = conn.execute("SELECT * FROM branding WHERE id = 1").fetchone() or {}
    main, white = find_logos()
    logo = logo_white = None
    meta, problem = None, None
    try:
        if main:
            logo, meta = process(main)
        if white:
            logo_white, _ = process(white)
    except Exception as e:  # noqa: BLE001 - a bad logo must never stop a report
        problem = f"The logo could not be read: {e}"
        logo = logo_white = meta = None
    from datetime import date
    company = (row.get("company") or "").strip() or "Your organisation"
    year = date.today().year
    return {
        "company": company,
        "copyright": (row.get("copyright") or "").strip() or f"\u00a9 {year} {company}. All rights reserved.",
        "classification": (row.get("classification") or "CONFIDENTIAL").strip().upper(),
        "accent": row.get("accent") or (meta or {}).get("accent") or DEFAULT_ACCENT,
        "accent_source": "set" if row.get("accent") else ("logo" if (meta or {}).get("accent") else "default"),
        "navy": NAVY,
        "logo": logo, "logo_white": logo_white, "logo_meta": meta, "logo_problem": problem,
        "logo_file": os.path.basename(main) if main else None,
        "logo_white_file": os.path.basename(white) if white else None,
        "company_set": bool((row.get("company") or "").strip()),
        "updated_by": row.get("updated_by"), "updated_at": row.get("updated_at"),
    }
