"""Container health checks.

    python -m app.health worker   passes when the worker's main loop has
                                  reported its heartbeat recently

The worker uses the API's image, whose built-in health check asks the web
server on port 8000. The worker runs no web server, so that check always
failed; this one tests the worker itself.
"""
import os
import sys

MAX_AGE_S = 180


def worker():
    import psycopg
    try:
        with psycopg.connect(host=os.environ.get("PATCHDB_HOST", "postgres"),
                             port=int(os.environ.get("PATCHDB_PORT", "5432")),
                             dbname=os.environ.get("PATCHDB_NAME", "patchdb"),
                             user=os.environ.get("PATCHDB_USER", "patchapi"),
                             password=os.environ.get("PATCHDB_PASSWORD", ""),
                             connect_timeout=8) as conn:
            row = conn.execute("SELECT extract(epoch FROM now() - beat_at) FROM worker_heartbeat "
                               "WHERE name = 'changes'").fetchone()
    except Exception as e:  # noqa: BLE001 - any failure is unhealthy
        print(f"unhealthy: cannot read the heartbeat: {e}")
        return 1
    if not row:
        print("unhealthy: the worker has not reported yet")
        return 1
    age = float(row[0])
    if age > MAX_AGE_S:
        print(f"unhealthy: last heartbeat {int(age)} s ago")
        return 1
    print(f"healthy: last heartbeat {int(age)} s ago")
    return 0


if __name__ == "__main__":
    sys.exit(worker() if sys.argv[1:] == ["worker"] else 2)
