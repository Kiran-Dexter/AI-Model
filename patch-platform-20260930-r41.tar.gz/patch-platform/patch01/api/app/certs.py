"""PATCH-01's own HTTPS certificate, managed from the console.

The console never installs a certificate itself: that would need control of
Docker, which is root on PATCH-01. Instead it checks an upload thoroughly,
then hands the checked files to a root helper on the host through one folder
(/patch/certs-staging, mounted here at /cert-staging). The helper
(patch01-cert-apply, started by a systemd path unit) installs them, restarts
nginx, proves nginx serves the new certificate, rolls back if not, and writes
its result back to the same folder.

The private key is kept only in that folder, readable by root, and the helper
deletes it once installed. It is never stored in the database.
"""

import datetime as _dt
import hashlib
import json
import os
import re
import secrets
import socket
import ssl

STAGING = os.environ.get("CERT_STAGING_DIR", "/cert-staging")
NGINX = (os.environ.get("NGINX_HOST", "patch01-nginx"), int(os.environ.get("NGINX_HTTPS_PORT", "8443")))
PENDING_MAX_AGE_S = 3600


class CertError(ValueError):
    pass


def _x509():
    from cryptography import x509
    return x509


def _pin(cert):
    from cryptography.hazmat.primitives.serialization import Encoding
    return hashlib.sha256(cert.public_bytes(Encoding.DER)).hexdigest()


def _names(cert):
    x509 = _x509()
    try:
        san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    except x509.ExtensionNotFound:
        return [], []
    return [n.lower() for n in san.get_values_for_type(x509.DNSName)], [str(i) for i in san.get_values_for_type(x509.IPAddress)]


def _cn(name):
    x509 = _x509()
    try:
        return name.get_attributes_for_oid(x509.oid.NameOID.COMMON_NAME)[0].value
    except (IndexError, ValueError):
        return name.rfc4514_string()


def describe(cert):
    """What the console shows about a certificate."""
    dns, ips = _names(cert)
    nb = cert.not_valid_before_utc
    na = cert.not_valid_after_utc
    now = _dt.datetime.now(_dt.timezone.utc)
    return {"subject": _cn(cert.subject), "issuer": _cn(cert.issuer),
            "self_signed": cert.issuer == cert.subject,
            "not_before": nb.isoformat(), "not_after": na.isoformat(),
            "days_left": (na - now).days, "dns_names": dns, "ip_names": ips, "pin": _pin(cert),
            "serial": format(cert.serial_number, "x")}


def served():
    """The certificate nginx is serving right now, as a client sees it."""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    with socket.create_connection(NGINX, timeout=8) as s:
        with ctx.wrap_socket(s, server_hostname=NGINX[0]) as t:
            der = t.getpeercert(binary_form=True)
    return describe(_x509().load_der_x509_certificate(der))


def _load_key(data, password):
    from cryptography.hazmat.primitives import serialization
    try:
        return serialization.load_pem_private_key(data, password=password or None)
    except TypeError:
        raise CertError("The private key is protected by a passphrase: give it in the password box.")
    except ValueError as e:
        raise CertError("The private key could not be read" + (" (wrong passphrase?)" if password else "")
                        + f": {str(e)[:80]}")


def _pem_certs(data):
    x509 = _x509()
    try:
        return x509.load_pem_x509_certificates(data)
    except ValueError:
        try:                                  # a single DER certificate (.cer from Windows)
            return [x509.load_der_x509_certificate(data)]
        except ValueError:
            raise CertError("The certificate file is neither PEM nor DER.")


def parse_upload(cert_data=None, key_data=None, chain_data=None, pfx_data=None, password=None):
    """(leaf, key, intermediates) from a PEM/DER set or a .pfx, the leaf found by its key."""
    pw = password.encode() if password else None
    if pfx_data:
        from cryptography.hazmat.primitives.serialization import pkcs12
        try:
            key, leaf, extra = pkcs12.load_key_and_certificates(pfx_data, pw)
        except ValueError as e:
            raise CertError("The .pfx file could not be opened" + (" (wrong password?)" if pw else
                            " (it probably needs its password)") + f": {str(e)[:60]}")
        if key is None or leaf is None:
            raise CertError("The .pfx file has no private key or no certificate in it.")
        return leaf, key, list(extra or [])
    if not cert_data or not key_data:
        raise CertError("Give the certificate and its private key, or a .pfx file.")
    certs = _pem_certs(cert_data) + (_pem_certs(chain_data) if chain_data else [])
    key = _load_key(key_data, pw)
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    kpub = key.public_key().public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo)
    leaf = next((c for c in certs if c.public_key().public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo) == kpub), None)
    if leaf is None:
        raise CertError("The private key does not belong to any certificate in the upload.")
    return leaf, key, [c for c in certs if c is not leaf]


def order_chain(leaf, others):
    """Intermediates in order from the leaf upwards; roots and strays dropped."""
    out, cur, pool = [], leaf, list(others)
    while True:
        nxt = next((c for c in pool if c.subject == cur.issuer and c.subject != c.issuer), None)
        if nxt is None:
            break
        out.append(nxt); pool.remove(nxt); cur = nxt
    return out


def check(leaf, key, others, short_name, fqdn):
    """Everything wrong with it (errors stop it; warnings are shown)."""
    errors, warnings = [], []
    d = describe(leaf)
    now = _dt.datetime.now(_dt.timezone.utc)
    if leaf.not_valid_after_utc <= now:
        errors.append(f"It expired on {leaf.not_valid_after_utc:%d %b %Y}.")
    elif d["days_left"] < 30:
        warnings.append(f"It expires in {d['days_left']} days.")
    if leaf.not_valid_before_utc > now:
        errors.append(f"It is not valid until {leaf.not_valid_before_utc:%d %b %Y %H:%M} UTC.")
    if short_name.lower() not in d["dns_names"]:
        warnings.append(f"It does not name {short_name}: agents use https://{short_name}. Windows agents are "
                        "fine with a pin; Linux agents verifying it must use the full name.")
    if fqdn.lower() not in d["dns_names"]:
        warnings.append(f"It does not name {fqdn}.")
    chain = order_chain(leaf, others)
    if not d["self_signed"] and not chain:
        warnings.append("No intermediate CA certificate was given: add it, or some clients cannot verify the chain.")
    x509 = _x509()
    try:
        eku = leaf.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value
        if x509.oid.ExtendedKeyUsageOID.SERVER_AUTH not in eku:
            errors.append("It is not issued for server authentication (TLS server).")
    except x509.ExtensionNotFound:
        pass
    from cryptography.hazmat.primitives.asymmetric import rsa
    if isinstance(key, rsa.RSAPrivateKey) and key.key_size < 2048:
        errors.append(f"Its RSA key is only {key.key_size} bits; 2048 or more is needed.")
    return errors, warnings, chain


def _pem(obj_list):
    from cryptography.hazmat.primitives.serialization import Encoding
    return b"".join(c.public_bytes(Encoding.PEM) for c in obj_list)


def _key_pem(key):
    from cryptography.hazmat.primitives import serialization
    return key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                             serialization.NoEncryption())


def stage(leaf, key, chain, user):
    """Keep the checked files until the admin confirms. Returns an id."""
    os.makedirs(STAGING, exist_ok=True)
    for f in os.listdir(STAGING):               # drop stale uploads
        p = os.path.join(STAGING, f)
        if f.startswith("pending-") and os.path.getmtime(p) < _dt.datetime.now().timestamp() - PENDING_MAX_AGE_S:
            _rm(p)
    sid = secrets.token_hex(8)
    d = os.path.join(STAGING, f"pending-{sid}")
    os.makedirs(d, mode=0o700)
    _write(os.path.join(d, "patch01.crt"), _pem([leaf] + chain), 0o640)
    _write(os.path.join(d, "patch01.key"), _key_pem(key), 0o640)
    _write(os.path.join(d, "meta.json"), json.dumps({"by": user, "pin": _pin(leaf), "subject": _cn(leaf.subject),
                                                     "at": _dt.datetime.now(_dt.timezone.utc).isoformat()}).encode(), 0o640)
    return sid


def request_apply(sid, user):
    d = os.path.join(STAGING, f"pending-{sid}")
    if not re.fullmatch(r"[0-9a-f]{16}", sid) or not os.path.isdir(d):
        raise CertError("That upload has expired or was already used: upload it again.")
    meta = json.load(open(os.path.join(d, "meta.json")))
    req = {"id": sid, "action": "install", "dir": f"pending-{sid}", "pin": meta["pin"], "by": user,
           "at": _dt.datetime.now(_dt.timezone.utc).isoformat()}
    _write_request(req)
    return req


def request_rollback(user):
    req = {"id": secrets.token_hex(8), "action": "rollback", "by": user,
           "at": _dt.datetime.now(_dt.timezone.utc).isoformat()}
    _write_request(req)
    return req


def _write_request(req):
    if os.path.exists(os.path.join(STAGING, "request.json")):
        raise CertError("A certificate change is already being applied: wait for it to finish.")
    tmp = os.path.join(STAGING, ".request.tmp")
    _write(tmp, json.dumps(req).encode(), 0o640)
    os.replace(tmp, os.path.join(STAGING, "request.json"))   # the helper watches for this file


def status():
    """The helper's last result, and whether a request is waiting."""
    out = {"pending": os.path.exists(os.path.join(STAGING, "request.json")), "last": None,
           "helper_ready": os.path.exists(os.path.join(STAGING, ".helper-ready"))}
    p = os.path.join(STAGING, "result.json")
    if os.path.exists(p):
        try:
            out["last"] = json.load(open(p))
        except ValueError:
            pass
    return out


def _write(path, data, mode):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode)
    with os.fdopen(fd, "wb") as fh:
        fh.write(data)
    os.chmod(path, mode)


def _rm(path):
    import shutil
    shutil.rmtree(path, ignore_errors=True) if os.path.isdir(path) else os.remove(path)
