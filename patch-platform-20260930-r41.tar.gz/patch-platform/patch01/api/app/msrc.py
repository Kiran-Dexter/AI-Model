"""Microsoft Security Update Guide (MSRC CVRF API) for Windows Server.

Each monthly release lists, per CVE, the products it affects, its severity,
whether it is exploited, its CVSS score, and the update that fixes it: a KB
and, for Windows itself, the fixed OS build (10.0.17763.6414). Those become
advisories the existing CVE engine understands:

    advisory      KB5044277, os_id windows, os_major 2019
    package       windows-os-build, fixed version 10.0.17763.6414
    CVEs          every CVE that KB fixes for that Windows Server version

A server reports its own build as the installed version of windows-os-build,
so the engine marks it affected by every KB whose fixed build is newer.
Updates without a fixed build (.NET, SQL Server) are not modelled here; the
Windows Update search on each server still lists them as missing updates.

    python -m app.msrc import [--months 24]
"""

import argparse
import json
import logging
import os
import re
import sys
import urllib.request
from datetime import date, datetime, timezone

log = logging.getLogger("msrc")
API = os.environ.get("MSRC_API", "https://api.msrc.microsoft.com/cvrf/v3.0")
PACKAGE = "windows-os-build"
# Windows Server versions, and the product names Microsoft uses for them
SERVER_RE = re.compile(r"^Windows Server (2012 R2|2016|2019|2022|2025)(?: \(Server Core installation\))?$")
MAJOR = {"2012 R2": 2012, "2016": 2016, "2019": 2019, "2022": 2022, "2025": 2025}
SEV_ORDER = {"critical": 0, "important": 1, "moderate": 2, "low": 3}


def _get(path, timeout=120):
    req = urllib.request.Request(API + path, headers={"Accept": "application/json",
                                                       "User-Agent": "PATCH-01"})
    with urllib.request.urlopen(req, timeout=timeout) as r:   # uses the proxy from the environment
        return json.loads(r.read().decode("utf-8-sig"))


def _val(x):
    return (x or {}).get("Value") if isinstance(x, dict) else x


def parse_release(doc):
    """{(kb, major): advisory} from one monthly CVRF document."""
    products = {}
    for p in (doc.get("ProductTree") or {}).get("FullProductName") or []:
        m = SERVER_RE.match((p.get("Value") or "").strip())
        if m:
            products[p["ProductID"]] = MAJOR[m.group(1)]
    released = (doc.get("DocumentTracking") or {}).get("CurrentReleaseDate") or \
               (doc.get("DocumentTracking") or {}).get("InitialReleaseDate")
    rel_id = _val((doc.get("DocumentTracking") or {}).get("Identification", {}).get("ID"))
    out = {}
    for v in doc.get("Vulnerability") or []:
        cve = v.get("CVE")
        if not cve or not cve.startswith("CVE-"):
            continue
        title = _val(v.get("Title"))
        sev_by_pid, exploited_by_pid = {}, {}
        for t in v.get("Threats") or []:
            desc = _val(t.get("Description")) or ""
            for pid in t.get("ProductID") or []:
                if t.get("Type") == 3:
                    sev_by_pid[pid] = desc.strip().lower()
                elif t.get("Type") == 1:
                    exploited_by_pid[pid] = "exploited:yes" in desc.replace(" ", "").lower()
        cvss_by_pid = {}
        for sc in v.get("CVSSScoreSets") or []:
            for pid in sc.get("ProductID") or []:
                try:
                    cvss_by_pid[pid] = float(sc.get("BaseScore"))
                except (TypeError, ValueError):
                    pass
        for rem in v.get("Remediations") or []:
            if rem.get("Type") != 2:                # 2 = vendor fix
                continue
            build = (rem.get("FixedBuild") or "").strip()
            kb = re.sub(r"\D", "", _val(rem.get("Description")) or "")
            if not (kb and re.fullmatch(r"10\.0\.\d+\.\d+", build)):
                continue                            # not an OS build update
            for pid in rem.get("ProductID") or []:
                major = products.get(pid)
                if not major:
                    continue
                key = (f"KB{kb}", major)
                a = out.setdefault(key, {"id": f"KB{kb}", "major": major, "build": build, "released": released,
                                         "release_id": rel_id, "cves": {}, "severity": None, "exploited": False})
                # the same KB can list a later fixed build for a later revision
                if _build_key(build) > _build_key(a["build"]):
                    a["build"] = build
                sev = sev_by_pid.get(pid)
                if sev and (a["severity"] is None or SEV_ORDER.get(sev, 9) < SEV_ORDER.get(a["severity"], 9)):
                    a["severity"] = sev
                a["exploited"] = a["exploited"] or exploited_by_pid.get(pid, False)
                prev = a["cves"].get(cve)
                score = cvss_by_pid.get(pid)
                a["cves"][cve] = max(x for x in (prev, score) if x is not None) if (prev or score) else None
                a.setdefault("titles", {})[cve] = title
    return out


def _build_key(b):
    try:
        return tuple(int(x) for x in b.split("."))
    except (ValueError, AttributeError):
        return (0,)


def store(conn, advisories):
    n = 0
    with conn.transaction():
        for a in advisories.values():
            day = None
            if a["released"]:
                try:
                    day = datetime.fromisoformat(a["released"].replace("Z", "+00:00")).date()
                except ValueError:
                    day = None
            name = f"Windows Server {a['major']} security update {a['id']}"
            summary = f"{len(a['cves'])} CVEs fixed in OS build {a['build']}" + (
                "; at least one is exploited" if a["exploited"] else "")
            conn.execute(
                """INSERT INTO advisories (id, vendor, title, severity, issued_at, summary, os_id, os_major, source_url)
                   VALUES (%s, 'microsoft', %s, %s, %s, %s, 'windows', %s, %s)
                   ON CONFLICT (id) DO UPDATE SET title=EXCLUDED.title, severity=EXCLUDED.severity,
                          issued_at=EXCLUDED.issued_at, summary=EXCLUDED.summary, imported_at=now()""",
                (a["id"], name, a["severity"], day, summary, a["major"],
                 f"https://support.microsoft.com/help/{a['id'][2:]}"))
            conn.execute(
                """INSERT INTO advisory_packages (advisory_id, name, arch, epoch, version, release)
                   VALUES (%s, %s, 'noarch', 0, %s, '0')
                   ON CONFLICT (advisory_id, name, arch) DO UPDATE SET version=EXCLUDED.version""",
                (a["id"], PACKAGE, a["build"]))
            with conn.cursor() as cur:
                cur.executemany(
                    """INSERT INTO advisory_cves (advisory_id, cve_id, cvss_score) VALUES (%s, %s, %s)
                       ON CONFLICT (advisory_id, cve_id) DO UPDATE SET cvss_score=EXCLUDED.cvss_score""",
                    [(a["id"], c, s) for c, s in a["cves"].items()])
            n += 1
    return n


def import_recent(conn, months=24):
    """Import the last N monthly releases; releases already imported are skipped
    unless Microsoft has revised them since."""
    index = _get("/updates").get("value") or []
    index = sorted(index, key=lambda r: r.get("InitialReleaseDate") or "", reverse=True)[:months]
    done = {r["id"]: r["released_at"] for r in conn.execute("SELECT id, released_at FROM msrc_releases").fetchall()}
    total_kb = total_cve = 0
    for r in index:
        rid = r.get("ID")
        cur = r.get("CurrentReleaseDate")
        cur_dt = datetime.fromisoformat(cur.replace("Z", "+00:00")) if cur else None
        if rid in done and done[rid] and cur_dt and cur_dt <= done[rid]:
            continue
        log.info("reading %s", rid)
        doc = _get(f"/cvrf/{rid}")
        advs = parse_release(doc)
        kbs = store(conn, advs)
        cves = len({c for a in advs.values() for c in a["cves"]})
        conn.execute(
            """INSERT INTO msrc_releases (id, released_at, cves, kbs) VALUES (%s, %s, %s, %s)
               ON CONFLICT (id) DO UPDATE SET released_at=EXCLUDED.released_at, cves=EXCLUDED.cves,
                      kbs=EXCLUDED.kbs, imported_at=now()""", (rid, cur_dt, cves, kbs))
        conn.commit()
        total_kb += kbs; total_cve += cves
        print(f"  {rid:10} {kbs:3} Windows Server updates, {cves:4} CVEs")
    return total_kb, total_cve


def main(argv=None):
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    ap = argparse.ArgumentParser(prog="msrc")
    sub = ap.add_subparsers(dest="cmd", required=True)
    im = sub.add_parser("import"); im.add_argument("--months", type=int, default=24)
    sub.add_parser("status")
    a = ap.parse_args(argv)
    from .hardening import _db
    with _db() as conn:
        if a.cmd == "import":
            kb, cve = import_recent(conn, a.months)
            print(f"Imported {kb} Windows Server updates covering {cve} CVEs.")
            return 0
        for r in conn.execute("SELECT id, released_at, kbs, cves FROM msrc_releases ORDER BY released_at DESC LIMIT 24").fetchall():
            print(f"  {r['id']:10} {r['kbs']:3} updates  {r['cves']:4} CVEs")
        n = conn.execute("SELECT count(*) AS n FROM advisories WHERE vendor='microsoft'").fetchone()["n"]
        print(f"  {n} Windows Server updates in the database")
    return 0


if __name__ == "__main__":
    sys.exit(main())
