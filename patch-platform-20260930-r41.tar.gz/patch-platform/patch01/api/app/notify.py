"""Mail alerts from PATCH-01.

Critical alerts go out within a minute, task updates as changes and scans
finish, a daily digest at 07:00 and a weekly summary. Everything is queued in
notifications and retried, so a relay outage delays mail rather than losing it.

Sent through the internal relay configured in /patch/secrets/mail.env
(phase9-mail.sh --setup). SMTP goes straight to the relay: never through the
web proxy, which carries HTTP only.

Command line, inside the API container:
    python -m app.notify test [--to someone@example.com]
    python -m app.notify status
    python -m app.notify watchdog         # run by a host timer every 5 minutes
    python -m app.notify digest --now     # send today's digest immediately
"""

import argparse
import html as _html
import json
import logging
import os
import smtplib
import socket
import ssl
import sys
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from email.utils import formatdate, make_msgid

log = logging.getLogger("notify")

BACKOFF_MIN = [1, 5, 15, 60, 240]          # retry after these many minutes, then give up
MAX_CRITICAL_SINGLE = 3                     # more new critical items than this in one pass: one combined mail
DS_ALERT, DS_CLEAR = 90, 85                 # datastore used %: alert at 90, clear below 85
WORKER_STALE_MIN = 5

NAVY, ACCENT, INK, INK2, RULE, PANEL = "#0B1F3A", "#1F5AA6", "#1B2430", "#5A6573", "#D9DEE4", "#F4F6F9"
SEV_COLOR = {"critical": "#C0392B", "warning": "#C8850A", "info": "#1F5AA6", "ok": "#1E8E5A"}


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

KEY_FILE = os.environ.get("MAIL_KEY_FILE", "/etc/patch01/mail.key")
TZ = timezone(timedelta(hours=8))           # Singapore: no daylight saving, so a fixed offset is exact


def _fernet():
    from cryptography.fernet import Fernet
    try:
        with open(KEY_FILE, "rb") as fh:
            return Fernet(fh.read().strip())
    except FileNotFoundError:
        raise RuntimeError(f"the mail key {KEY_FILE} is missing: re-run phase3b-api.sh on PATCH-01")
    except ValueError:
        raise RuntimeError(f"the mail key {KEY_FILE} is not a valid key: remove it and re-run phase3b-api.sh")


def encrypt(secret):
    return _fernet().encrypt(secret.encode()).decode()


def decrypt(token):
    from cryptography.fernet import InvalidToken
    if not token:
        return ""
    try:
        return _fernet().decrypt(token.encode()).decode()
    except InvalidToken:
        raise RuntimeError("the saved relay password cannot be read with this PATCH-01's mail key: enter it again")


def config(conn, with_password=True):
    """Mail settings as saved in the console, and the recipients of each kind."""
    s = conn.execute("SELECT * FROM mail_settings WHERE id = 1").fetchone() or {}
    rec = conn.execute("SELECT * FROM mail_recipients ORDER BY lower(address)").fetchall()
    pick = lambda k: [r["address"] for r in rec if r[k]]  # noqa: E731
    password = ""
    if with_password and s.get("password_enc"):
        password = decrypt(s["password_enc"])
    return {
        "enabled": bool(s.get("enabled")),
        "host": s.get("host") or "", "port": int(s.get("port") or 25),
        "tls": s.get("tls") or "starttls", "verify": s.get("verify", True) is not False,
        "ca_pem": s.get("ca_pem") or None, "ca_file": None,
        "user": s.get("username") or "", "password": password,
        "password_set": bool(s.get("password_enc")),
        "from": s.get("from_addr") or "", "from_name": s.get("from_name") or "",
        "to": [r["address"] for r in rec],
        "to_critical": pick("critical"), "to_tasks": pick("tasks"),
        "to_digest": pick("digest"), "to_weekly": pick("weekly"),
        "critical": s.get("send_critical", True) is not False, "tasks": s.get("send_tasks", True) is not False,
        "digest": s.get("send_digest", True) is not False, "weekly": s.get("send_weekly", True) is not False,
        "digest_time": s.get("digest_time") or "07:00", "weekly_day": s.get("weekly_day") or "mon",
        "tz": TZ, "tz_label": "SGT",
        "console": (s.get("console_url") or "").rstrip("/"),
        "company": s.get("company") or _brand_company(conn) or "PATCH-01",
        "signature": (s.get("signature") or "").strip(),
        "updated_by": s.get("updated_by"), "updated_at": s.get("updated_at"),
    }


def _brand_company(conn):
    try:
        r = conn.execute("SELECT company FROM branding WHERE id = 1").fetchone()
        return (r or {}).get("company") or None
    except Exception:  # noqa: BLE001 - branding table from a later schema
        return None


def public_config(cfg):
    """What the console may show: never the password."""
    return {k: (v if k != "tz" else cfg["tz_label"]) for k, v in cfg.items() if k != "password"} | {
        "auth": bool(cfg["user"])}


# ---------------------------------------------------------------------------
# Rendering: one plain-text and one HTML body from the same blocks
# ---------------------------------------------------------------------------

def esc(v):
    return _html.escape("" if v is None else str(v))


def render(cfg, title, severity, intro, blocks, link=None, link_label="Open in PATCH-01", label=None):
    """blocks: ("h", text) | ("p", text) | ("kv", [(k, v)]) | ("table", headers, rows) | ("stats", [(label, value, sev)])"""
    color = SEV_COLOR.get(severity, ACCENT)
    url = (cfg["console"] + link) if (cfg["console"] and link) else None
    t = [title, "=" * len(title), "", intro, ""]
    h = []
    for b in blocks:
        kind = b[0]
        if kind == "h":
            t += [b[1], "-" * len(b[1])]
            h.append(f'<tr><td style="padding:18px 28px 6px;font:600 15px Arial,Helvetica,sans-serif;color:{NAVY}">{esc(b[1])}</td></tr>')
        elif kind == "text":
            # Written prose: paragraphs split by blank lines, "- " lines as bullets
            t += [b[1], ""]
            for para in [x for x in b[1].replace("\r", "").split("\n\n") if x.strip()]:
                lines = para.split("\n")
                if all(l.strip().startswith(("- ", "\u2022 ", "* ")) for l in lines if l.strip()):
                    items = "".join(f'<li style="margin:0 0 4px">{esc(l.strip()[2:])}</li>' for l in lines if l.strip())
                    h.append(f'<tr><td style="padding:2px 28px 8px"><ul style="margin:0;padding-left:20px;'
                             f'font:14px/21px Arial,Helvetica,sans-serif;color:{INK}">{items}</ul></td></tr>')
                else:
                    h.append(f'<tr><td style="padding:4px 28px 8px;font:14px/21px Arial,Helvetica,sans-serif;color:{INK}">'
                             + "<br>".join(esc(l) for l in lines) + "</td></tr>")
        elif kind == "p":
            t += [b[1], ""]
            h.append(f'<tr><td style="padding:4px 28px 8px;font:14px/21px Arial,Helvetica,sans-serif;color:{INK}">{esc(b[1])}</td></tr>')
        elif kind == "kv":
            rows = "".join(
                f'<tr><td style="padding:7px 0;border-bottom:1px solid {RULE};font:bold 11px Arial,Helvetica,sans-serif;'
                f'color:{INK2};text-transform:uppercase;width:42%;padding-right:12px">{esc(k)}</td>'
                f'<td style="padding:7px 0;border-bottom:1px solid {RULE};font:14px Arial,Helvetica,sans-serif;color:{INK}">{esc(v)}</td></tr>'
                for k, v in b[1])
            t += [f"  {k}: {v}" for k, v in b[1]] + [""]
            h.append(f'<tr><td style="padding:4px 28px 10px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0">{rows}</table></td></tr>')
        elif kind == "stats":
            cells = "".join(
                f'<td style="padding:12px;background:{PANEL};border-top:3px solid {SEV_COLOR.get(sv, ACCENT)};width:{100 // max(1, len(b[1]))}%">'
                f'<div style="font:bold 10px Arial,Helvetica,sans-serif;color:{INK2};text-transform:uppercase">{esc(lbl)}</div>'
                f'<div style="font:bold 24px Arial,Helvetica,sans-serif;color:{SEV_COLOR.get(sv, INK) if sv != "info" else INK};padding-top:4px">{esc(val)}</div></td>'
                '<td style="width:8px"></td>'
                for lbl, val, sv in b[1])
            t += ["  " + "   ".join(f"{lbl}: {val}" for lbl, val, _ in b[1]), ""]
            h.append(f'<tr><td style="padding:8px 28px 10px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>{cells}</tr></table></td></tr>')
        elif kind == "table":
            heads, rows = b[1], b[2]
            if not rows:
                continue
            th = "".join(f'<th align="left" style="padding:7px 8px;background:{PANEL};border-bottom:2px solid {NAVY};'
                         f'font:bold 11px Arial,Helvetica,sans-serif;color:{INK2}">{esc(x)}</th>' for x in heads)
            tr = "".join("<tr>" + "".join(
                f'<td style="padding:7px 8px;border-bottom:1px solid {RULE};font:13px Arial,Helvetica,sans-serif;color:{INK}">{esc(c)}</td>'
                for c in r) + "</tr>" for r in rows)
            widths = [max(len(str(x)) for x in [hd] + [r[i] for r in rows]) for i, hd in enumerate(heads)]
            fmt = lambda r: "  " + "  ".join(str(c).ljust(min(w, 40)) for c, w in zip(r, widths))  # noqa: E731
            t += [fmt(heads)] + [fmt(r) for r in rows] + [""]
            h.append(f'<tr><td style="padding:4px 28px 12px"><table role="presentation" width="100%" cellpadding="0" '
                     f'cellspacing="0" style="border-collapse:collapse"><tr>{th}</tr>{tr}</table></td></tr>')
    if url:
        t += [f"{link_label}: {url}", ""]
        h.append(f'<tr><td style="padding:14px 28px 22px"><a href="{esc(url)}" style="display:inline-block;background:{NAVY};'
                 f'color:#ffffff;text-decoration:none;font:bold 13px Arial,Helvetica,sans-serif;padding:10px 18px;'
                 f'border-radius:3px">{esc(link_label)}</a></td></tr>')
    if cfg.get("signature"):
        t += ["", cfg["signature"], ""]
        h.append(f'<tr><td style="padding:14px 28px 6px;font:13px/19px Arial,Helvetica,sans-serif;color:{INK}">'
                 + "<br>".join(esc(l) for l in cfg["signature"].splitlines()) + "</td></tr>")
    now = datetime.now(cfg["tz"]).strftime("%d %b %Y, %H:%M ") + cfg["tz_label"]
    footer = f"Sent by PATCH-01 for {cfg['company']} at {now}."
    t += ["--", footer]
    ls = logo_size() if logo_bytes() else None
    brand = (f'<img src="cid:patch01logo" alt="{esc(cfg["company"])}" width="{ls[0]}" height="{ls[1]}" '
             f'style="display:block;border:0;width:{ls[0]}px;height:{ls[1]}px">'
             if ls else f'<span style="font:bold 17px Arial,Helvetica,sans-serif;color:{NAVY}">{esc(cfg["company"])}</span>')
    html = f"""<!DOCTYPE html><html><body style="margin:0;padding:0;background:#EEF1F5">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#EEF1F5"><tr><td align="center" style="padding:24px 12px">
<table role="presentation" width="640" cellpadding="0" cellspacing="0" style="max-width:640px;width:100%;background:#ffffff;border:1px solid {RULE}">
<tr><td style="background:#ffffff;padding:18px 28px 14px;border-bottom:1px solid {RULE}">{brand}</td></tr>
<tr><td style="height:3px;background:{color};font-size:0;line-height:0">&nbsp;</td></tr>
<tr><td style="padding:22px 28px 4px"><div style="font:bold 11px Arial,Helvetica,sans-serif;color:{color};text-transform:uppercase;letter-spacing:.06em">{esc(label or (severity if severity != 'ok' else 'resolved'))}</div>
<div style="font:bold 21px/27px Arial,Helvetica,sans-serif;color:{NAVY};padding-top:4px">{esc(title)}</div></td></tr>
<tr><td style="padding:6px 28px 8px;font:14px/21px Arial,Helvetica,sans-serif;color:{INK}">{esc(intro)}</td></tr>
{''.join(h)}
<tr><td style="padding:16px 28px;border-top:1px solid {RULE};font:11px/16px Arial,Helvetica,sans-serif;color:{INK2}">{esc(footer)}</td></tr>
</table></td></tr></table></body></html>"""
    return "\n".join(t), html


def logo_bytes():
    """The logo for the mail header. The header is white, so the main logo
    shows as it is, whatever its colours."""
    try:
        from . import branding as br
        main, _ = br.find_logos()
        if main:
            return br.process(main)[0]
    except Exception:  # noqa: BLE001 - mail goes out with the name instead
        pass
    return None


def logo_size():
    try:
        from . import branding as br
        main, _ = br.find_logos()
        if main:
            a = br.process(main)[1]["aspect"]
            h = 34 if a < 5 else 26                       # wide logos a little shorter
            return min(220, round(h * a)), h
    except Exception:  # noqa: BLE001
        pass
    return None


# ---------------------------------------------------------------------------
# Sending
# ---------------------------------------------------------------------------

def send(cfg, to, subject, text, html=None, cc=None, attachments=None):
    """Send one mail now. Raises with a readable reason on failure."""
    if not cfg["host"] or not cfg["from"]:
        raise RuntimeError("mail is not configured: run phase9-mail.sh --setup")
    if not to:
        raise RuntimeError("no recipients configured")
    msg = EmailMessage()
    from email.utils import formataddr
    msg["From"] = formataddr((cfg["from_name"], cfg["from"])) if cfg.get("from_name") else cfg["from"]
    msg["To"] = ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg["Subject"] = subject
    msg["Date"] = formatdate(localtime=True)
    msg["Message-ID"] = make_msgid(domain=cfg["from"].split("@")[-1].strip(">") or "patch01.local")
    msg["X-Mailer"] = "PATCH-01"
    msg.set_content(text)
    if html:
        msg.add_alternative(html, subtype="html")
        logo = logo_bytes()
        if logo and "cid:patch01logo" in html:
            msg.get_payload()[1].add_related(logo, "image", "png", cid="<patch01logo>")
    for fname, data, mime in attachments or []:
        maintype, subtype = mime.split("/", 1)
        msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=fname)
    ctx = tls_context(cfg)
    try:
        if cfg["tls"] == "tls":
            s = smtplib.SMTP_SSL(cfg["host"], cfg["port"], context=ctx, timeout=30)
        else:
            s = smtplib.SMTP(cfg["host"], cfg["port"], timeout=30)
        with s:
            s.ehlo()
            if cfg["tls"] == "starttls":
                if not s.has_extn("starttls"):
                    raise RuntimeError(f"{cfg['host']} does not offer STARTTLS; set SMTP_TLS=none if it is a plain internal relay")
                s.starttls(context=ctx)
                s.ehlo()
            if cfg["user"]:
                s.login(cfg["user"], cfg["password"])
            refused = s.send_message(msg, to_addrs=list(to) + list(cc or []))
            if refused:
                raise RuntimeError("relay refused: " + ", ".join(refused))
    except smtplib.SMTPAuthenticationError as e:
        raise RuntimeError(f"the relay rejected the login for {cfg['user']}: {_code(e)}") from e
    except smtplib.SMTPSenderRefused as e:
        hint = ("it wants a login: set SMTP_USER and SMTP_PASSWORD" if e.smtp_code == 530
                else "check MAIL_FROM is a sender the relay accepts, and that PATCH-01's address may relay")
        raise RuntimeError(f"the relay refused the sender {cfg['from']} ({_code(e)}); {hint}") from e
    except smtplib.SMTPRecipientsRefused as e:
        bad = "; ".join(f"{addr} ({code} {msg.decode(errors='replace') if isinstance(msg, bytes) else msg})"
                        for addr, (code, msg) in e.recipients.items())
        raise RuntimeError(f"the relay refused the recipient: {bad}") from e
    except smtplib.SMTPServerDisconnected as e:
        raise RuntimeError(f"{cfg['host']}:{cfg['port']} closed the connection unexpectedly"
                           + (f" ({e})" if str(e) else "") + ": it may not be an SMTP relay, or it rejected PATCH-01") from e
    except smtplib.SMTPException as e:
        raise RuntimeError(f"the relay said: {_code(e)}") from e
    except (socket.timeout, TimeoutError) as e:
        raise RuntimeError(f"no answer from {cfg['host']}:{cfg['port']} within 30 s: check the firewall allows PATCH-01 to reach it") from e
    except ConnectionRefusedError as e:
        raise RuntimeError(f"{cfg['host']}:{cfg['port']} refused the connection: wrong port, or the relay is not listening") from e
    except ssl.SSLCertVerificationError as e:
        raise RuntimeError(f"the relay's certificate is not trusted ({e.verify_message}): put your CA certificate at /patch/secrets/mail-ca/ca.pem") from e
    except OSError as e:
        raise RuntimeError(f"cannot reach {cfg['host']}:{cfg['port']}: {e}") from e


def _code(e):
    code = getattr(e, "smtp_code", None)
    msg = getattr(e, "smtp_error", b"")
    msg = msg.decode(errors="replace") if isinstance(msg, bytes) else str(msg or "")
    msg = msg or str(e) or type(e).__name__        # never an empty reason
    return f"{code} {msg}".strip() if code else msg


def tls_context(cfg):
    """TLS settings for the relay: the pasted CA if there is one, else the system's."""
    if cfg["tls"] == "none":
        return None
    ctx = ssl.create_default_context()
    if cfg.get("ca_pem"):
        try:
            ctx.load_verify_locations(cadata=cfg["ca_pem"])
        except ssl.SSLError as e:
            raise RuntimeError(f"the CA certificate saved for the relay is not valid PEM: {e}")
    if not cfg["verify"]:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    return ctx


def test_connection(cfg):
    """Walk through a delivery without sending anything, step by step.

    Reach the relay, read its greeting, start TLS, log in, and check it
    accepts the From address (MAIL FROM, then RSET). Stops at the first
    failure and says why.
    """
    steps = []
    def ok(step, detail=""):
        steps.append({"step": step, "ok": True, "detail": detail})
    def bad(step, detail):
        steps.append({"step": step, "ok": False, "detail": detail})
        return steps
    if not cfg["host"]:
        return bad("Settings", "enter the relay's host name")
    try:
        infos = socket.getaddrinfo(cfg["host"], cfg["port"], proto=socket.IPPROTO_TCP)
        ok("Name lookup", f"{cfg['host']} is {infos[0][4][0]}")
    except socket.gaierror as e:
        return bad("Name lookup", f"{cfg['host']} does not resolve ({e.strerror}): check the name, or use its IP address")
    ctx = None
    try:
        ctx = tls_context(cfg)
    except RuntimeError as e:
        return bad("TLS settings", str(e))
    try:
        if cfg["tls"] == "tls":
            s = smtplib.SMTP_SSL(cfg["host"], cfg["port"], context=ctx, timeout=15)
        else:
            s = smtplib.SMTP(cfg["host"], cfg["port"], timeout=15)
    except (socket.timeout, TimeoutError):
        return bad("Connect", f"no answer from {cfg['host']}:{cfg['port']} within 15 s: the firewall probably blocks PATCH-01")
    except ConnectionRefusedError:
        return bad("Connect", f"{cfg['host']}:{cfg['port']} refused the connection: wrong port, or nothing listening")
    except ssl.SSLCertVerificationError as e:
        return bad("Connect", f"the relay's certificate is not trusted ({e.verify_message}): paste its CA certificate")
    except (ssl.SSLError, OSError, smtplib.SMTPException) as e:
        return bad("Connect", f"{e}")
    try:
        with s:
            code, banner = s.ehlo()
            ok("Connect", f"{cfg['host']}:{cfg['port']} answered: " + (banner.decode(errors="replace").splitlines() or [""])[0][:120])
            if cfg["tls"] == "starttls":
                if not s.has_extn("starttls"):
                    return bad("Start TLS", "the relay does not offer STARTTLS: choose 'none' if it is a plain internal relay")
                try:
                    s.starttls(context=ctx)
                    s.ehlo()
                except ssl.SSLCertVerificationError as e:
                    return bad("Start TLS", f"the relay's certificate is not trusted ({e.verify_message}): paste its CA certificate")
                except (ssl.SSLError, smtplib.SMTPException) as e:
                    return bad("Start TLS", str(e))
            if cfg["tls"] != "none":
                cert = s.sock.getpeercert() or {}
                subj = dict(x[0] for x in cert.get("subject", ())) if cert else {}
                iss = dict(x[0] for x in cert.get("issuer", ())) if cert else {}
                detail = f"{s.sock.version()}"
                if cert:
                    detail += f", certificate for {subj.get('commonName', '?')} from {iss.get('commonName', '?')}, valid until {cert.get('notAfter', '?')}"
                else:
                    detail += ", certificate not checked"
                ok("Encryption", detail)
            else:
                ok("Encryption", "none: mail travels unencrypted on the internal network")
            if cfg["user"]:
                if not s.has_extn("auth"):
                    return bad("Log in", "the relay does not accept logins on this port: leave the login blank, or use port 587")
                try:
                    s.login(cfg["user"], cfg["password"])
                    ok("Log in", f"accepted for {cfg['user']}")
                except smtplib.SMTPAuthenticationError as e:
                    return bad("Log in", f"the relay rejected the login for {cfg['user']}: {_code(e)}")
                except smtplib.SMTPException as e:
                    return bad("Log in", str(e))
            if cfg["from"]:
                code, resp = s.mail(cfg["from"])
                if code >= 400:
                    hint = " (it wants a login)" if code == 530 else ""
                    return bad("Sender", f"the relay refused {cfg['from']}: {code} {resp.decode(errors='replace')}{hint}")
                s.rset()
                ok("Sender", f"{cfg['from']} accepted; nothing was sent")
    except smtplib.SMTPServerDisconnected:
        return bad("Connect", "the relay closed the connection: it may not be an SMTP relay, or it rejected PATCH-01")
    except (socket.timeout, TimeoutError):
        return bad("Connect", "the relay stopped answering")
    return steps


def enqueue(conn, category, severity, subject, text, html, recipients, keys=()):
    conn.execute(
        """INSERT INTO notifications (category, severity, subject, body_text, body_html, recipients, event_keys)
           VALUES (%s,%s,%s,%s,%s,%s,%s)""",
        (category, severity, subject[:300], text, html, list(recipients), list(keys)))


def send_queued(conn, cfg, limit=20):
    """Send what is due; back off and retry on failure, give up after the last step."""
    sent = failed = 0
    with conn.transaction():
        rows = conn.execute(
            """SELECT * FROM notifications WHERE state='queued' AND next_attempt_at <= now()
                ORDER BY id LIMIT %s FOR UPDATE SKIP LOCKED""", (limit,)).fetchall()
        for n in rows:
            try:
                send(cfg, n["recipients"], n["subject"], n["body_text"], n["body_html"])
                conn.execute("UPDATE notifications SET state='sent', sent_at=now(), attempts=attempts+1, last_error=NULL WHERE id=%s",
                             (n["id"],))
                sent += 1
            except Exception as e:  # noqa: BLE001 - recorded, retried
                a = n["attempts"] + 1
                if a > len(BACKOFF_MIN):
                    conn.execute("UPDATE notifications SET state='failed', attempts=%s, last_error=%s WHERE id=%s",
                                 (a, str(e)[:500], n["id"]))
                else:
                    conn.execute(
                        """UPDATE notifications SET attempts=%s, last_error=%s,
                                  next_attempt_at=now() + make_interval(mins => %s) WHERE id=%s""",
                        (a, str(e)[:500], BACKOFF_MIN[a - 1], n["id"]))
                failed += 1
    return sent, failed


# ---------------------------------------------------------------------------
# Detection: what is new since the last pass
# ---------------------------------------------------------------------------

def _pct(used, total):
    try:
        return round(100.0 * float(used) / float(total)) if total else None
    except (TypeError, ValueError):
        return None


def detect(conn):
    """Everything that could warrant a mail right now, as (key, kind, group, item)."""
    out = []
    # 1. Exploited vulnerabilities newly affecting a server
    for r in conn.execute(
            """SELECT ha.host_id, h.hostname, ha.advisory_id, a.title, a.severity, r.max_cvss, r.max_epss
                 FROM host_applicability ha
                 JOIN hosts h ON h.id = ha.host_id
                 JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id
                 JOIN advisories a ON a.id = ha.advisory_id
                WHERE ha.state = 'affected' AND r.any_kev AND h.status <> 'decommissioned'""").fetchall():
        out.append((f"kev:{r['host_id']}:{r['advisory_id']}", "event", "kev", r))
    # 2. ESXi hosts not connected
    for r in conn.execute(
            """SELECT vcenter, moref, name, cluster, connection_state FROM esxi_hosts
                WHERE connection_state IS NOT NULL AND connection_state <> 'connected'""").fetchall():
        out.append((f"esxi:{r['vcenter']}:{r['moref']}", "condition", "esxi", r))
    # 3. vCenter unreachable: stream down 10+ minutes, or last sync failed
    for r in conn.execute(
            """SELECT c.name, c.last_ok, c.last_error, l.connected, l.error, l.updated_at
                 FROM vcenters c LEFT JOIN vmware_live l ON l.vcenter = c.name
                WHERE c.last_ok IS FALSE
                   OR (l.connected IS FALSE AND l.updated_at < now() - interval '10 minutes')""").fetchall():
        out.append((f"vc:{r['name']}", "condition", "vcenter", r))
    # 4. Datastores filling up (with hysteresis: alert at 90%, clear below 85%)
    for r in conn.execute(
            """SELECT vcenter, moref, name, type, capacity_mb, free_mb FROM datastores
                WHERE capacity_mb > 0 AND 100.0 * (capacity_mb - free_mb) / capacity_mb >= %s""",
            (DS_CLEAR,)).fetchall():
        r["used_pct"] = _pct(r["capacity_mb"] - r["free_mb"], r["capacity_mb"])
        out.append((f"ds:{r['vcenter']}:{r['moref']}", "condition", "datastore", r))
    # 5. Changes that failed or only partly succeeded
    for r in conn.execute(
            """SELECT id, number, title, kind, state, requested_by, finished_at FROM changes
                WHERE state IN ('failed', 'partially_succeeded') AND finished_at > now() - interval '7 days'""").fetchall():
        out.append((f"chg:{r['id']}:{r['state']}", "event", "change_failed", r))
    # 6. Hardening drift on a high-severity rule: passed last scan, fails now
    for r in conn.execute(
            """WITH ranked AS (
                 SELECT id, host_id, level, content_version, product, finished_at,
                        row_number() OVER (PARTITION BY host_id, level ORDER BY finished_at DESC) AS rn
                   FROM hardening_scans WHERE state = 'done')
               SELECT cur.id AS scan_id, cur.host_id, h.hostname, cur.level, r.rule_id, hr.title, hr.cis_ref
                 FROM ranked cur
                 JOIN ranked prev ON prev.host_id = cur.host_id AND prev.level = cur.level AND prev.rn = 2
                 JOIN hardening_results r  ON r.scan_id = cur.id AND r.result = 'fail'
                 JOIN hardening_results pr ON pr.scan_id = prev.id AND pr.rule_id = r.rule_id AND pr.result = 'pass'
                 JOIN hardening_rules hr ON hr.content_version = cur.content_version AND hr.product = cur.product
                                        AND hr.rule_id = r.rule_id
                 JOIN hosts h ON h.id = cur.host_id
                WHERE cur.rn = 1 AND hr.severity = 'high'""").fetchall():
        out.append((f"drift:{r['scan_id']}:{r['rule_id']}", "event", "drift", r))
    # 7. Task updates: changes starting and finishing (failures are critical above)
    for r in conn.execute(
            """SELECT id, number, title, kind, state, requested_by, started_at, finished_at, summary FROM changes
                WHERE state IN ('running', 'succeeded', 'cancelled')
                  AND coalesce(finished_at, started_at) > now() - interval '2 days'""").fetchall():
        out.append((f"task-chg:{r['id']}:{r['state']}", "event", "task_change", r))
    # 8. Task updates: scans people asked for (scheduled ones go in the digest)
    for r in conn.execute(
            """SELECT s.id, s.host_id, h.hostname, s.level, s.state, s.score, s.failed, s.error, s.requested_by, s.finished_at
                 FROM hardening_scans s JOIN hosts h ON h.id = s.host_id
                WHERE s.state IN ('done', 'failed') AND s.requested_by <> 'schedule'
                  AND s.finished_at > now() - interval '2 days'""").fetchall():
        out.append((f"task-scan:{r['id']}", "event", "task_scan", r))
    return out


def _still_active(key, item, seen):
    """Datastores clear only below 85%; everything else clears when it is gone."""
    if key.startswith("ds:"):
        u = item["used_pct"]
        return u is not None and (u >= DS_ALERT or (key in seen and u >= DS_CLEAR))
    return True


def cycle(conn, cfg):
    """One pass: find what is new, record it, queue the mails. Returns counts."""
    items = detect(conn)
    seen = {r["key"]: r["kind"] for r in conn.execute("SELECT key, kind FROM notify_seen").fetchall()}
    first = conn.execute("SELECT value FROM notify_state WHERE key='baseline'").fetchone() is None
    active = {k: (kind, grp, it) for k, kind, grp, it in items if _still_active(k, it, seen)}
    new = {k: v for k, v in active.items() if k not in seen}
    cleared = [k for k, kind in seen.items() if kind == "condition" and k not in active]
    with conn.transaction():
        for k, (kind, _, _) in new.items():
            conn.execute("INSERT INTO notify_seen (key, kind) VALUES (%s,%s) ON CONFLICT (key) DO NOTHING", (k, kind))
        conn.execute("UPDATE notify_seen SET last_seen=now() WHERE key = ANY(%s)", (list(active),))
        for k in cleared:
            conn.execute("DELETE FROM notify_seen WHERE key=%s", (k,))
        conn.execute("DELETE FROM notify_seen WHERE kind='event' AND last_seen < now() - interval '180 days'")
        if first:
            # Enabling mail must not flood the mailbox with everything already
            # known: record the current state quietly and say so once.
            conn.execute("INSERT INTO notify_state (key, value) VALUES ('baseline', now()::text) ON CONFLICT (key) DO NOTHING")
            counts = {}
            for _, (_, grp, _) in new.items():
                counts[grp] = counts.get(grp, 0) + 1
            text, html = render(cfg, "Mail alerts are on", "info",
                                "From now on PATCH-01 mails critical alerts as they happen, task updates, a daily digest at "
                                f"{cfg['digest_time']} {cfg['tz_label']} and a weekly summary. What is already known has been "
                                "recorded without alerting; the next digest covers it.",
                                [("kv", [("Exploited CVEs on servers", counts.get("kev", 0)),
                                         ("ESXi hosts not connected", counts.get("esxi", 0)),
                                         ("Datastores 85% or fuller", counts.get("datastore", 0)),
                                         ("vCenters with problems", counts.get("vcenter", 0))])], link="/")
            enqueue(conn, "system", "info", "[PATCH-01] Mail alerts are on", text, html, cfg["to"])
            return {"baseline": len(new)}
        queued = queue_alerts(conn, cfg, new)
    return {"new": len(new), "cleared": len(cleared), **queued}


def queue_alerts(conn, cfg, new):
    by = {}
    for k, (kind, grp, it) in new.items():
        by.setdefault(grp, []).append((k, it))
    q = {"critical": 0, "task": 0}
    critical = []
    if cfg["critical"]:
        for grp in ("kev", "esxi", "vcenter", "datastore", "change_failed", "drift"):
            critical += [(grp, k, it) for k, it in by.get(grp, [])]
    if len(critical) > MAX_CRITICAL_SINGLE:
        rows = [[_crit_title(g, it), _crit_where(g, it)] for g, _, it in critical[:40]]
        text, html = render(cfg, f"{len(critical)} critical alerts", "critical",
                            "Several critical conditions appeared at once, so they are listed together here.",
                            [("table", ["Alert", "Where"], rows)]
                            + ([("p", f"...and {len(critical) - 40} more.")] if len(critical) > 40 else []),
                            link="/")
        enqueue(conn, "critical", "critical", f"[PATCH-01] CRITICAL: {len(critical)} alerts", text, html,
                cfg["to_critical"], [k for _, k, _ in critical])
        q["critical"] += 1
    else:
        for g, k, it in critical:
            subj, text, html = _crit_mail(cfg, g, it)
            enqueue(conn, "critical", "critical", subj, text, html, cfg["to_critical"], [k])
            q["critical"] += 1
    if cfg["tasks"]:
        for k, it in by.get("task_change", []):
            subj, text, html = _task_change_mail(cfg, it)
            enqueue(conn, "task", "ok" if it["state"] == "succeeded" else "info", subj, text, html, cfg["to_tasks"], [k])
            q["task"] += 1
        for k, it in by.get("task_scan", []):
            subj, text, html = _task_scan_mail(cfg, it)
            enqueue(conn, "task", "info" if it["state"] == "done" else "warning", subj, text, html, cfg["to_tasks"], [k])
            q["task"] += 1
    return q


ESXI_STATE = {"notResponding": "not responding", "disconnected": "disconnected"}


def _ref(n):
    return f"CHG-{int(n):06d}" if n is not None else "CHG"


def _crit_title(g, it):
    return {"kev": f"Exploited vulnerability {it.get('advisory_id')}",
            "esxi": f"ESXi host {ESXI_STATE.get(it.get('connection_state'), it.get('connection_state'))}",
            "vcenter": "vCenter unreachable",
            "datastore": f"Datastore {it.get('used_pct')}% full",
            "change_failed": f"{_ref(it.get('number'))} {str(it.get('state')).replace('_', ' ')}",
            "drift": f"Hardening drift: {it.get('title')}"}[g]


def _crit_where(g, it):
    return {"kev": it.get("hostname"), "esxi": f"{it.get('name')} ({it.get('cluster') or 'standalone'})",
            "vcenter": it.get("name"), "datastore": f"{it.get('name')} on {it.get('vcenter')}",
            "change_failed": it.get("title"), "drift": it.get("hostname")}[g]


def _crit_mail(cfg, g, it):
    if g == "kev":
        return (f"[PATCH-01] CRITICAL: exploited vulnerability on {it['hostname']}",
                *render(cfg, f"Exploited vulnerability on {it['hostname']}", "critical",
                        "A vulnerability on CISA's list of those actively exploited now affects this server. "
                        "Patch it first.",
                        [("kv", [("Server", it["hostname"]), ("Advisory", it["advisory_id"]),
                                 ("Title", it.get("title") or ""), ("Worst CVSS", it.get("max_cvss") or "unknown"),
                                 ("Exploitation probability (EPSS)",
                                  f"{float(it['max_epss']) * 100:.0f}%" if it.get("max_epss") is not None else "unknown")])],
                        link=f"/#/host/{it['host_id']}"))
    if g == "esxi":
        state = ESXI_STATE.get(it["connection_state"], it["connection_state"])
        return (f"[PATCH-01] CRITICAL: ESXi host {it['name']} is {state}",
                *render(cfg, f"ESXi host {it['name']} is {state}", "critical",
                        "vCenter reports this host is not connected. Its VMs may be down; if HA is on, they restart elsewhere.",
                        [("kv", [("Host", it["name"]), ("Cluster", it.get("cluster") or "standalone"),
                                 ("vCenter", it["vcenter"]), ("State", state)])],
                        link="/#/vmware"))
    if g == "vcenter":
        why = it.get("last_error") or it.get("error") or "the live stream has been disconnected for over 10 minutes"
        return (f"[PATCH-01] CRITICAL: vCenter {it['name']} unreachable",
                *render(cfg, f"vCenter {it['name']} is unreachable", "critical",
                        "PATCH-01 cannot read this vCenter, so the VMware map and alerts for it are out of date.",
                        [("kv", [("vCenter", it["name"]), ("Reason", why)])], link="/#/vmware"))
    if g == "datastore":
        return (f"[PATCH-01] CRITICAL: datastore {it['name']} is {it['used_pct']}% full",
                *render(cfg, f"Datastore {it['name']} is {it['used_pct']}% full", "critical",
                        "When a datastore fills, every VM on it can stop. Free space or move VMs now.",
                        [("kv", [("Datastore", it["name"]), ("Type", it.get("type") or ""), ("vCenter", it["vcenter"]),
                                 ("Used", f"{it['used_pct']}%"),
                                 ("Free", f"{round((it['free_mb'] or 0) / 1024)} GB of {round((it['capacity_mb'] or 0) / 1024)} GB")])],
                        link="/#/vmware?view=datastores"))
    if g == "change_failed":
        st = str(it["state"]).replace("_", " ")
        return (f"[PATCH-01] CRITICAL: {_ref(it['number'])} {st}: {it['title']}",
                *render(cfg, f"{_ref(it['number'])} {st}", "critical",
                        "A scheduled change did not complete. Servers that failed kept their snapshot for rollback.",
                        [("kv", [("Change", f"{_ref(it['number'])} {it['title']}"), ("Kind", it["kind"]),
                                 ("Requested by", it.get("requested_by") or ""), ("Result", st)])],
                        link=f"/#/change/{it['id']}"))
    return (f"[PATCH-01] CRITICAL: hardening drift on {it['hostname']}",
            *render(cfg, f"Hardening drift on {it['hostname']}", "critical",
                    "A high-severity check that passed in the previous scan now fails: the setting was changed.",
                    [("kv", [("Server", it["hostname"]), ("Check", it.get("title") or it["rule_id"]),
                             ("CIS", it.get("cis_ref") or ""), ("Profile", str(it["level"]).upper())])],
                    link=f"/#/hardening/host/{it['host_id']}?level={it['level']}"))


def _task_change_mail(cfg, it):
    st = {"running": "started", "succeeded": "completed", "cancelled": "cancelled"}[it["state"]]
    return (f"[PATCH-01] {_ref(it['number'])} {st}: {it['title']}",
            *render(cfg, f"{_ref(it['number'])} {st}", "ok" if st == "completed" else "info",
                    f"{it['title']}", [("kv", [("Kind", it["kind"]), ("Requested by", it.get("requested_by") or ""),
                                               ("State", st)])], link=f"/#/change/{it['id']}"))


def _task_scan_mail(cfg, it):
    if it["state"] == "done":
        return (f"[PATCH-01] Hardening scan done: {it['hostname']} {float(it['score'] or 0):.1f}%",
                *render(cfg, f"Hardening scan done: {it['hostname']}", "info",
                        f"CIS {str(it['level']).upper()} scan finished.",
                        [("kv", [("Score", f"{float(it['score'] or 0):.1f}%"), ("Failed checks", it.get("failed")),
                                 ("Requested by", it.get("requested_by") or "")])],
                        link=f"/#/hardening/host/{it['host_id']}?level={it['level']}"))
    return (f"[PATCH-01] Hardening scan failed: {it['hostname']}",
            *render(cfg, f"Hardening scan failed: {it['hostname']}", "warning", it.get("error") or "The scan did not complete.",
                    [], link=f"/#/hardening/host/{it['host_id']}?level={it['level']}"))


# ---------------------------------------------------------------------------
# Digest and weekly summary
# ---------------------------------------------------------------------------

def fleet_state(conn):
    q = lambda sql, *a: conn.execute(sql, a).fetchone()  # noqa: E731
    st = {}
    st["servers"] = q("SELECT count(*) AS n FROM hosts WHERE status <> 'decommissioned'")["n"]
    ag = conn.execute("SELECT agent_state, count(*) AS n FROM v_agents GROUP BY 1").fetchall()
    st["agents"] = {r["agent_state"]: r["n"] for r in ag}
    st["need_patch"] = q("SELECT count(DISTINCT host_id) AS n FROM host_applicability WHERE state='affected'")["n"]
    st["need_reboot"] = q("SELECT count(DISTINCT host_id) AS n FROM host_applicability WHERE state='fixed_pending_reboot'")["n"]
    st["kev_servers"] = q(
        """SELECT count(DISTINCT ha.host_id) AS n FROM host_applicability ha
             JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id WHERE ha.state='affected' AND r.any_kev""")["n"]
    hs = q("SELECT round(avg(score), 1) AS s, count(*) AS n FROM v_hardening_latest WHERE level='l1'")
    st["hardening"], st["hardening_servers"] = hs["s"], hs["n"]
    st["esxi_down"] = q("SELECT count(*) AS n FROM esxi_hosts WHERE connection_state <> 'connected'")["n"]
    st["ds_high"] = q("""SELECT count(*) AS n FROM datastores
                          WHERE capacity_mb > 0 AND 100.0 * (capacity_mb - free_mb) / capacity_mb >= %s""", DS_CLEAR)["n"]
    st["old_snapshots"] = q("""SELECT count(*) AS n FROM vm_inventory
                                WHERE oldest_snapshot_at < now() - interval '7 days'""")["n"]
    return st


def build_digest(conn, cfg, weekly=False):
    st = fleet_state(conn)
    days = 7 if weekly else 1
    since = f"{days} days"
    crit = conn.execute(
        """SELECT created_at, subject FROM notifications WHERE category='critical' AND created_at > now() - %s::interval
            ORDER BY created_at DESC LIMIT 15""", (since,)).fetchall()
    chg = conn.execute(
        """SELECT number, title, state, requested_by FROM changes
            WHERE coalesce(finished_at, started_at, requested_at) > now() - %s::interval
            ORDER BY coalesce(finished_at, started_at, requested_at) DESC LIMIT 15""", (since,)).fetchall()
    scans = conn.execute(
        """SELECT count(*) AS n, round(avg(score), 1) AS s, count(*) FILTER (WHERE state='failed') AS failed
             FROM hardening_scans WHERE finished_at > now() - %s::interval""", (since,)).fetchone()
    offline = st["agents"].get("offline", 0) + st["agents"].get("not_reporting", 0)
    blocks = [("stats", [("Servers", st["servers"], "info"),
                         ("Need patching", st["need_patch"], "warning" if st["need_patch"] else "ok"),
                         ("Exploited CVEs", st["kev_servers"], "critical" if st["kev_servers"] else "ok"),
                         ("Hardening L1", f"{st['hardening']}%" if st["hardening"] is not None else "\u2013",
                          "ok" if (st["hardening"] or 0) >= 85 else "warning")]),
              ("kv", [("Servers needing a reboot", st["need_reboot"]),
                      ("Agents offline or not reporting", offline),
                      ("ESXi hosts not connected", st["esxi_down"]),
                      ("Datastores 85% or fuller", st["ds_high"]),
                      ("VMs with snapshots over 7 days old", st["old_snapshots"]),
                      ("Servers with a hardening score", st["hardening_servers"])])]
    label = "this week" if weekly else "the last 24 hours"
    blocks.append(("h", f"Critical alerts in {label} ({len(crit)})"))
    blocks.append(("table", ["When", "Alert"],
                   [[r["created_at"].astimezone(cfg["tz"]).strftime("%d %b %H:%M"), r["subject"].replace("[PATCH-01] ", "")]
                    for r in crit]) if crit else ("p", "None."))
    blocks.append(("h", f"Changes in {label} ({len(chg)})"))
    blocks.append(("table", ["Change", "Title", "State", "By"],
                   [[_ref(r["number"]), r["title"], str(r["state"]).replace("_", " "), r["requested_by"] or ""] for r in chg])
                  if chg else ("p", "None."))
    blocks.append(("h", f"Hardening scans in {label}"))
    blocks.append(("p", f"{scans['n']} scans finished" + (f", average score {scans['s']}%" if scans["s"] is not None else "")
                   + (f", {scans['failed']} failed." if scans["failed"] else ".")))
    if weekly:
        top = conn.execute(
            """SELECT h.hostname, count(*) AS n FROM host_applicability ha JOIN hosts h ON h.id = ha.host_id
                WHERE ha.state='affected' GROUP BY 1 ORDER BY 2 DESC LIMIT 5""").fetchall()
        blocks += [("h", "Servers with most to patch"),
                   ("table", ["Server", "Advisories outstanding"], [[r["hostname"], r["n"]] for r in top])
                   if top else ("p", "Nothing outstanding.")]
    today = datetime.now(cfg["tz"]).strftime("%A %d %B %Y")
    title = ("Weekly summary" if weekly else "Daily digest") + f", {today}"
    sev = "critical" if st["kev_servers"] or st["esxi_down"] else ("warning" if st["need_patch"] else "ok")
    intro = (f"{st['servers']} servers. " + (f"{st['kev_servers']} have exploited vulnerabilities to patch. " if st["kev_servers"] else "")
             + (f"{st['need_patch']} need patching. " if st["need_patch"] else "Nothing needs patching. ")
             + (f"{len(crit)} critical alerts in {label}." if crit else f"No critical alerts in {label}."))
    text, html = render(cfg, title, sev, intro, blocks, link="/", label="Weekly summary" if weekly else "Daily digest")
    return f"[PATCH-01] {title}", text, html


def maybe_digests(conn, cfg):
    now = datetime.now(cfg["tz"])
    try:
        hh, mm = [int(x) for x in cfg["digest_time"].split(":")]
    except ValueError:
        hh, mm = 7, 0
    if (now.hour, now.minute) < (hh, mm):
        return []
    done = []
    today = now.date().isoformat()
    for key, on, weekly in (("digest_last", cfg["digest"], False), ("weekly_last", cfg["weekly"], True)):
        if not on or (weekly and now.strftime("%a").lower()[:3] != cfg["weekly_day"]):
            continue
        last = conn.execute("SELECT value FROM notify_state WHERE key=%s", (key,)).fetchone()
        if last and last["value"] == today:
            continue
        subj, text, html = build_digest(conn, cfg, weekly=weekly)
        with conn.transaction():
            enqueue(conn, "weekly" if weekly else "digest", "info", subj, text, html,
                    cfg["to_weekly"] if weekly else cfg["to_digest"])
            conn.execute("""INSERT INTO notify_state (key, value, updated_at) VALUES (%s,%s,now())
                            ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value, updated_at=now()""", (key, today))
        done.append(key)
    return done


# ---------------------------------------------------------------------------
# Watchdog: the worker cannot report its own death, so the host checks it
# ---------------------------------------------------------------------------

def watchdog(conn, cfg):
    r = conn.execute("SELECT extract(epoch FROM now() - beat_at)::int AS age FROM worker_heartbeat WHERE name='changes'").fetchone()
    age = r["age"] if r else None
    down = age is None or age > WORKER_STALE_MIN * 60
    was = conn.execute("SELECT 1 FROM notify_seen WHERE key='worker-down'").fetchone() is not None
    if down and not was:
        text, html = render(cfg, "The PATCH-01 worker has stopped", "critical",
                            "Scheduled changes, scans and mail alerts do not run while the worker is down.",
                            [("kv", [("Last report", f"{age} seconds ago" if age is not None else "never")]),
                             ("p", "On PATCH-01: docker logs patch01-worker --tail 50, then ./scripts/phase3b-api.sh")],
                            link="/")
        send(cfg, cfg["to_critical"], "[PATCH-01] CRITICAL: worker stopped", text, html)
        conn.execute("INSERT INTO notify_seen (key, kind) VALUES ('worker-down','condition') ON CONFLICT DO NOTHING")
        conn.commit()
        return "alerted"
    if not down and was:
        text, html = render(cfg, "The PATCH-01 worker is running again", "ok",
                            "Scheduled changes, scans and mail alerts have resumed.", [], link="/")
        send(cfg, cfg["to_critical"], "[PATCH-01] RESOLVED: worker running again", text, html)
        conn.execute("DELETE FROM notify_seen WHERE key='worker-down'")
        conn.commit()
        return "recovered"
    return "down" if down else "ok"


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------

def _db():
    import psycopg
    from psycopg.rows import dict_row
    return psycopg.connect(
        host=os.environ.get("PATCHDB_HOST", "postgres"), port=int(os.environ.get("PATCHDB_PORT", "5432")),
        dbname=os.environ.get("PATCHDB_NAME", "patchdb"), user=os.environ.get("PATCHDB_USER", "patchapi"),
        password=os.environ.get("PATCHDB_PASSWORD", ""), row_factory=dict_row, connect_timeout=15)


def test_mail(cfg, to=None):
    text, html = render(cfg, "Test mail from PATCH-01", "ok",
                        "If you can read this, PATCH-01 can reach your mail relay and alerts will arrive here.",
                        [("kv", [("Relay", f"{cfg['host']}:{cfg['port']} ({cfg['tls']})"),
                                 ("From", cfg["from"]), ("Critical alerts to", ", ".join(cfg["to_critical"]) or "nobody"),
                                 ("Task updates to", ", ".join(cfg["to_tasks"]) or "nobody"),
                                 ("Daily digest to", ", ".join(cfg["to_digest"]) or "nobody"),
                                 ("Weekly summary to", ", ".join(cfg["to_weekly"]) or "nobody"),
                                 ("Daily digest", f"{cfg['digest_time']} {cfg['tz_label']}" if cfg["digest"] else "off"),
                                 ("Weekly summary", f"{cfg['weekly_day'].title()} {cfg['digest_time']}" if cfg["weekly"] else "off")])],
                        link="/")
    send(cfg, to or cfg["to"], "[PATCH-01] Test mail", text, html)


def main(argv=None):
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    ap = argparse.ArgumentParser(prog="notify")
    sub = ap.add_subparsers(dest="cmd", required=True)
    t = sub.add_parser("test"); t.add_argument("--to", action="append")
    sub.add_parser("status"); sub.add_parser("watchdog"); sub.add_parser("check")
    d = sub.add_parser("digest"); d.add_argument("--weekly", action="store_true")
    e = sub.add_parser("enable"); e.add_argument("state", choices=["on", "off"])
    a = ap.parse_args(argv)
    with _db() as conn:
        cfg = config(conn)
        if a.cmd == "check":
            for st in test_connection(cfg):
                print(f"  {'ok ' if st['ok'] else 'FAIL'}  {st['step']:12} {st['detail']}")
            return 0
        if a.cmd == "test":
            try:
                test_mail(cfg, a.to)
            except Exception as ex:  # noqa: BLE001
                print(f"FAILED: {ex}")
                return 1
            print(f"Sent to {', '.join(a.to or cfg['to'])}")
            return 0
        if a.cmd == "enable":
            conn.execute("UPDATE mail_settings SET enabled=%s, updated_by='cli', updated_at=now() WHERE id=1",
                         (a.state == "on",))
            conn.commit()
            print(f"Mail alerts {'on' if a.state == 'on' else 'off'}.")
            return 0
        if a.cmd == "status":
            pc = public_config(cfg)
            print(f"  enabled   {pc['enabled']}\n  relay     {pc['host'] or '-'}:{pc['port']} ({pc['tls']}"
                  f"{', verify' if pc['verify'] else ', NO verify'}{', login ' + pc['user'] if pc['auth'] else ''})\n"
                  f"  from      {pc['from'] or '-'}\n  to        {', '.join(pc['to']) or '-'}\n"
                  f"  digest    {pc['digest_time']} SGT, weekly {pc['weekly_day']}")
            for r in conn.execute("""SELECT state, count(*) AS n, max(created_at) AS last FROM notifications
                                      GROUP BY 1 ORDER BY 1""").fetchall():
                print(f"  {r['state']:9} {r['n']:5}  last {r['last']:%Y-%m-%d %H:%M}")
            for r in conn.execute("""SELECT subject, last_error FROM notifications WHERE state IN ('queued','failed')
                                      AND last_error IS NOT NULL ORDER BY id DESC LIMIT 3""").fetchall():
                print(f"  problem: {r['subject'][:60]} -> {r['last_error']}")
            return 0
        if a.cmd == "watchdog":
            if cfg["enabled"]:
                print(watchdog(conn, cfg))
            return 0
        if a.cmd == "digest":
            subj, text, html = build_digest(conn, cfg, weekly=a.weekly)
            send(cfg, cfg["to_weekly"] if a.weekly else cfg["to_digest"], subj, text, html)
            print(f"Sent: {subj}")
            return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
