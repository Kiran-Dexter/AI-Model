"""E-mails that send a report: drafted by AI-01 from the report's own figures.

AI-01 is given only the figures recorded with the report and told to use
nothing else. Its draft is then checked: any number in it that the figures do
not contain means the draft is thrown away and the structured template used
instead, so a mail never states something the attached report does not.
"""

import re

from . import llm

SYSTEM = """You write e-mails from an enterprise IT security team that send a CIS hardening report.
Readers are managers and security leads. Write plainly and precisely, in a cybersecurity register:
name the risk, the exposure and the action. No hype, no marketing words, no emoji, no markdown.

Use ONLY the facts provided. Never invent numbers, server names, CVEs or dates.

Keep it short: at most 90 words in the body. No bullet lists, no headings.

Output exactly this shape:
SUBJECT: <one line, under 80 characters, with the scope and the score>

Hello,

<one sentence: what was assessed>

<one or two sentences: how many checks passed and failed, the score, the trend if given, and the single most important gap>

<one sentence pointing to the attached report>"""


def _pct(v):
    return f"{float(v):.1f}%" if v is not None else "not scored"


def facts_text(f):
    lines = [f"Report: {f['report_id']} ({f['style']}, {f['level']})", f"Scope: {f['scope']}, {f['servers']} servers",
             f"Assessment period: {f['period']}", f"Score: {_pct(f['score'])} ({f['passed']} checks passed, {f['failed']} failed)"]
    if f.get("previous_score") is not None:
        lines.append(f"Previous assessment score: {_pct(f['previous_score'])}")
        if f.get("score") is not None:
            delta = float(f["score"]) - float(f["previous_score"])
            lines.append(f"Change since the previous assessment: {'up' if delta >= 0 else 'down'} {abs(delta):.1f} points")
    lines.append(f"Distinct checks failing on at least one server: {f['checks_failing']} of {f['checks_total']}")
    lines.append(f"High-severity checks failing: {f['high_open']}")
    if f.get("weakest"):
        lines.append(f"Weakest area: {f['weakest']['name']} at {f['weakest']['pct']}% passing")
    if f.get("below_70"):
        lines.append("Servers below 70%: " + ", ".join(f"{x['hostname']} ({_pct(x['score'])})" for x in f["below_70"]))
    if f.get("top"):
        lines.append("Most widespread failing checks:")
        lines += [f"  - {t['title']} ({t['severity']}, CIS {t['cis'] or 'n/a'}): fails on {t['servers']} of {f['servers']} servers"
                  for t in f["top"]]
    if f.get("worst_servers"):
        lines.append("Lowest-scoring servers: " + ", ".join(
            f"{x['hostname']} {_pct(x['score'])}" + (f" with {x['high']} high-severity failures" if x.get("high") else "")
            for x in f["worst_servers"][:3]))
    lines.append(f"Attached file: {f['file']}")
    return "\n".join(lines)


def summary(f):
    """The short factual summary shown beside the draft."""
    out = [("Score", _pct(f["score"]) + (f" (was {_pct(f['previous_score'])})" if f.get("previous_score") is not None else "")),
           ("Scope", f"{f['servers']} servers \u00b7 {f['scope']}"),
           ("Checks failing", f"{f['checks_failing']} of {f['checks_total']}"),
           ("High severity", str(f["high_open"])),
           ("Below 70%", ", ".join(x["hostname"] for x in f.get("below_70") or []) or "none")]
    if f.get("weakest"):
        out.append(("Weakest area", f"{f['weakest']['name']} ({f['weakest']['pct']}%)"))
    if f.get("top"):
        out.append(("Most widespread gap", f"{f['top'][0]['title']} ({f['top'][0]['servers']} of {f['servers']})"))
    return out


def stats(f):
    """The four figures shown as boxes at the top of the e-mail."""
    return [("Servers", str(f["servers"]), "info"),
            ("Checks passed", str(f["passed"]), "ok"),
            ("Checks failed", str(f["failed"]), "critical" if f["failed"] else "ok"),
            ("Score", _pct(f["score"]), "ok" if (f["score"] or 0) >= 85 else "warning" if (f["score"] or 0) >= 70 else "critical")]


def template(f):
    """A short, factual e-mail: what was assessed and the result."""
    subject = f"CIS hardening report: {f['scope']}, {_pct(f['score'])} compliant"
    trend = ""
    if f.get("previous_score") is not None and f.get("score") is not None:
        delta = float(f["score"]) - float(f["previous_score"])
        trend = f" ({'up' if delta >= 0 else 'down'} {abs(delta):.1f} points since the last assessment)"
    n_high = f.get("high_open") or 0
    high = (f" {n_high} of the failing checks {'is' if n_high == 1 else 'are'} high severity." if n_high else "")
    body = (f"Hello,\n\n"
            f"Please find attached the CIS hardening report for {f['scope']}: {f['servers']} server"
            f"{'s' if f['servers'] != 1 else ''} assessed against the {f['level']} benchmark.\n\n"
            f"Across these servers, {f['passed']} checks passed and {f['failed']} failed, "
            f"a compliance score of {_pct(f['score'])}{trend}.{high}\n\n"
            "The attached report lists the result of every check on each server.")
    return subject, body


def _allowed_numbers(f, facts):
    nums = set(re.findall(r"\d+(?:\.\d+)?", facts))
    for n in list(nums):                       # 75.5 may be written 75.5% or 76%
        try:
            v = float(n)
            nums.add(str(round(v))); nums.add(f"{v:.1f}")
        except ValueError:
            pass
    nums |= {"70", "85", "100"}          # the score thresholds the report itself uses
    return nums


def _clean(text):
    text = re.sub(r"\*\*|__|`|^#+\s*", "", text, flags=re.M)
    text = re.sub(r"^\s*[\u2022*]\s+", "- ", text, flags=re.M)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def draft(f):
    """AI-01's polish of the short e-mail: (subject, body, source, note)."""
    facts = facts_text(f)
    if not llm.configured():
        s, b = template(f)
        return s, b, "template", "AI-01 is not configured, so this draft comes from the report's figures."
    try:
        res = llm._chat([{"role": "system", "content": SYSTEM},
                         {"role": "user", "content": "Facts from the report:\n" + facts}], max_tokens=480)
        text = _clean(res["choices"][0]["message"]["content"])
    except Exception as e:  # noqa: BLE001 - the template always works
        s, b = template(f)
        return s, b, "template", f"AI-01 could not draft this ({str(e)[:120]}), so it comes from the report's figures."
    m = re.match(r"\s*SUBJECT:\s*(.+?)\s*\n(.*)", text, re.S | re.I)
    if not m or len(m.group(2).strip()) < 80:
        s, b = template(f)
        return s, b, "template", "AI-01's draft was incomplete, so this one comes from the report's figures."
    subject, body = m.group(1).strip()[:120], m.group(2).strip()
    allowed = _allowed_numbers(f, facts)
    stray = [n for n in re.findall(r"\b\d+(?:\.\d+)?\b", subject + " " + body) if n not in allowed]
    if stray:
        s, b = template(f)
        return s, b, "template", ("AI-01's draft contained figures that are not in the report (" + ", ".join(stray[:4])
                                  + "), so it was discarded; this draft comes from the report's figures.")
    return subject, body, "ai", "Drafted by AI-01 from the report's figures. Check it before sending."
