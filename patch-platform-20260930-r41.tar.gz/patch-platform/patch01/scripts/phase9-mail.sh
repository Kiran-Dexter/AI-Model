#!/usr/bin/env bash
# ===========================================================================
# PATCH-01 : phase 9 - mail alerts, from the command line
#
# Mail is set up in the console: Mail page (admin). These commands are for
# checking from PATCH-01 itself, or when the console cannot be reached:
#
#   ./phase9-mail.sh --status          settings (never the password), queue, problems
#   ./phase9-mail.sh --check           test the relay step by step; sends nothing
#   ./phase9-mail.sh --test [ADDRESS]  send a test mail
#   ./phase9-mail.sh --digest          send today's digest now
#   ./phase9-mail.sh --off | --on      stop or resume all mail
# ===========================================================================
set -Eeuo pipefail
API_CONTAINER="${API_CONTAINER:-patch01-api}"
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
usage() { sed -n '4,13p' "$0" | sed 's/^# \{0,1\}//'; exit "${1:-0}"; }
[[ $EUID -eq 0 ]] || die "Run as root."
docker inspect "$API_CONTAINER" >/dev/null 2>&1 || die "$API_CONTAINER is not running. Run phase3b-api.sh first."
run() { docker exec -i "$API_CONTAINER" python -m app.notify "$@"; }
[[ $# -ge 1 ]] || usage 1
case "$1" in
  --status) run status ;;
  --check)  run check ;;
  --test)   run test ${2:+--to "$2"} ;;
  --digest) run digest ;;
  --on)     run enable on ;;
  --off)    run enable off ;;
  -h|--help) usage 0 ;;
  *) usage 1 ;;
esac
