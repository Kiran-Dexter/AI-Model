#!/usr/bin/env bash
# ===========================================================================
# patch01-cert-apply - install PATCH-01's certificate from the console.
#
# Started by patch01-cert.path when the console writes request.json into
# /patch/certs-staging. It does not trust the web side: it re-checks the
# files itself, installs them, restarts nginx, proves nginx serves exactly
# the expected certificate, and puts the previous one back if not. Its result
# goes to result.json, which the console shows. The private key is removed
# from the hand-over folder once installed.
#
#   request {"action": "install", "dir": "pending-<id>", "pin": "<sha256>"}
#   request {"action": "rollback"}      the certificate before the last change
# ===========================================================================
set -Eeuo pipefail

PATCH_BASE="${PATCH_BASE:-/patch}"
STAGING="$PATCH_BASE/certs-staging"
CERTS="$PATCH_BASE/certs"
KEEP=5                                   # previous certificates kept
LOG=/var/log/patch01-cert.log
NGINX=patch01-nginx
REQ="$STAGING/request.json"

log() { printf '%s %s\n' "$(date '+%F %T')" "$*" >>"$LOG"; }
jget() { python3 -c "import json,sys; print(json.load(open(sys.argv[1])).get(sys.argv[2],''))" "$REQ" "$1"; }
result() {   # result ok|failed|rolled_back message [pin]
  python3 - "$1" "$2" "${3:-}" "$ID" "$ACTION" "$BY" >"$STAGING/.result.tmp" <<'PY'
import json, sys, datetime
print(json.dumps({"state": sys.argv[1], "message": sys.argv[2], "pin": sys.argv[3], "id": sys.argv[4],
                  "action": sys.argv[5], "by": sys.argv[6],
                  "at": datetime.datetime.now(datetime.timezone.utc).isoformat()}))
PY
  chmod 0640 "$STAGING/.result.tmp"; chgrp 0 "$STAGING/.result.tmp" 2>/dev/null || true
  mv -f "$STAGING/.result.tmp" "$STAGING/result.json"
  log "$1: $2"
}
served_pin() {
  echo | timeout 10 openssl s_client -connect 127.0.0.1:443 2>/dev/null | openssl x509 -outform der 2>/dev/null \
    | sha256sum | cut -d' ' -f1
}
restart_and_check() {   # restart_and_check <expected pin> : nginx serves it
  # 9>&-: nothing started from here may inherit (and so keep) the run lock
  docker restart "$NGINX" >>"$LOG" 2>&1 9>&- || return 1
  local i p
  for i in $(seq 1 20); do
    sleep 2
    p="$(served_pin)"
    [[ "$p" == "$1" ]] && return 0
  done
  return 1
}

[[ -f "$REQ" ]] || exit 0
exec 9>"$STAGING/.lock"
flock -n 9 || { log "another run is in progress; this request waits for it"; exit 0; }
ID="$(jget id)"; ACTION="$(jget action)"; BY="$(jget by)"
[[ "$ID" =~ ^[0-9a-f]{16}$ ]] || { rm -f "$REQ"; log "ignored a malformed request"; exit 0; }
TS="$(date +%Y%m%d-%H%M%S)"
trap 'rm -f "$REQ"' EXIT
log "request $ID: $ACTION by $BY"

# nginx runs as uid 1001 in group 0, so the key must stay root:0 0640 as
# phase1a-ingress.sh made it. Overwriting in place keeps the file's owner,
# group, mode and SELinux label exactly; a new file gets phase1a's values.
place() {   # place <source> <destination> <mode if new>
  if [[ -f "$2" ]]; then
    cat "$1" >"$2"
  else
    install -m "$3" -o root -g 0 "$1" "$2"
  fi
  # A key left owner-only by an earlier attempt would lock nginx out again
  [[ "$2" == *.key ]] && { chgrp 0 "$2"; chmod 0640 "$2"; } || true
}

prune() { ls -1dt "$PATCH_BASE"/certs.before-ui-* 2>/dev/null | tail -n +$((KEEP + 1)) | xargs -r rm -rf; }

case "$ACTION" in
  install)
    DIR="$(jget dir)"; WANT="$(jget pin)"
    [[ "$DIR" =~ ^pending-[0-9a-f]{16}$ && "$WANT" =~ ^[0-9a-f]{64}$ ]] || { result failed "the request was malformed"; exit 0; }
    SRC="$STAGING/$DIR"
    [[ -f "$SRC/patch01.crt" && -f "$SRC/patch01.key" ]] || { result failed "the uploaded files are missing (the upload may have expired)"; exit 0; }
    # Check again here: this is the side that can change nginx
    GOT="$(openssl x509 -in "$SRC/patch01.crt" -outform der 2>/dev/null | sha256sum | cut -d' ' -f1)"
    [[ "$GOT" == "$WANT" ]] || { result failed "the certificate is not the one that was checked"; rm -rf "$SRC"; exit 0; }
    [[ "$(openssl x509 -in "$SRC/patch01.crt" -noout -pubkey 2>/dev/null | sha256sum)" == \
       "$(openssl pkey -in "$SRC/patch01.key" -pubout 2>/dev/null | sha256sum)" ]] \
      || { result failed "the key does not match the certificate"; rm -rf "$SRC"; exit 0; }
    openssl x509 -checkend 0 -noout -in "$SRC/patch01.crt" >/dev/null || { result failed "the certificate has expired"; rm -rf "$SRC"; exit 0; }
    OLD="$(served_pin)"
    cp -a "$CERTS" "$PATCH_BASE/certs.before-ui-$TS"
    place "$SRC/patch01.crt" "$CERTS/patch01.crt" 0644
    place "$SRC/patch01.key" "$CERTS/patch01.key" 0640
    rm -rf "$SRC"                          # the key leaves the hand-over folder now
    if restart_and_check "$WANT"; then
      prune
      result ok "installed; nginx serves the new certificate (previous one kept as certs.before-ui-$TS)" "$WANT"
    else
      cp -a "$PATCH_BASE/certs.before-ui-$TS/." "$CERTS/"
      if restart_and_check "$OLD"; then
        result rolled_back "nginx did not serve the new certificate, so the previous one was put back and is being served. docker logs $NGINX --tail 30 shows why." "$OLD"
      else
        result failed "nginx served neither the new certificate nor the previous one (the previous files are back in place). Check it now: docker logs $NGINX --tail 30, then patch01ctl start" ""
      fi
    fi
    ;;
  rollback)
    PREV="$(ls -1dt "$PATCH_BASE"/certs.before-ui-* 2>/dev/null | head -1 || true)"
    [[ -n "$PREV" ]] || { result failed "there is no previous certificate to go back to"; exit 0; }
    PIN="$(openssl x509 -in "$PREV/patch01.crt" -outform der 2>/dev/null | sha256sum | cut -d' ' -f1)"
    cp -a "$CERTS" "$PATCH_BASE/certs.before-rollback-$TS"
    cp -a "$PREV/." "$CERTS/"
    if restart_and_check "$PIN"; then
      rm -rf "$PREV"
      result ok "rolled back to the previous certificate" "$PIN"
    else
      cp -a "$PATCH_BASE/certs.before-rollback-$TS/." "$CERTS/"; restart_and_check "$(openssl x509 -in "$CERTS/patch01.crt" -outform der | sha256sum | cut -d' ' -f1)" || true
      result failed "nginx would not serve the previous certificate, so nothing was changed"
    fi
    rm -rf "$PATCH_BASE/certs.before-rollback-$TS"
    ;;
  *) result failed "unknown action" ;;
esac
