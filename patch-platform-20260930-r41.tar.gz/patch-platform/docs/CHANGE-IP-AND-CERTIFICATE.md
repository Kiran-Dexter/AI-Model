# Changing PATCH-01's certificate and the IPs of PATCH-01 and AI-01

Do the three parts in this order, one at a time, checking each before the next.
Nothing here needs agents to re-enrol.

## Part 1 - install the CA-signed certificate (IPs unchanged)

1. **Check the certificate before anything else.**
   ```bash
   openssl x509 -in new.crt -noout -subject -enddate -ext subjectAltName
   ```
   The names must include what agents use: `SGPINFAPPXU01` (the short name in
   every agent's address) and the FQDN. If the short name is missing, tell the
   CA, or plan to point the Linux agents at the FQDN in step 7.
   The file must be the **full chain**: the server certificate first, then the
   intermediate CA certificates. Check the key matches:
   ```bash
   [ "$(openssl x509 -noout -modulus -in new.crt | sha256sum)" = "$(openssl rsa -noout -modulus -in new.key | sha256sum)" ] && echo "key matches"
   ```
2. **New pin, and the commands to use it:**
   `./scripts/phase10-windows.sh --pin --cert new.crt`
3. **Windows agents, both pins,** while the old certificate is still live, so
   they work before and after the swap (from the jump host):
   `.\push-agent.ps1 -Computers servers.txt -Server https://SGPINFAPPXU01 -Pin <old>,<new> -Repin`
   Each server checks the new setting works before keeping it.
4. **Each WSUS server, both pins:** `.\wsus-report.ps1 -Repin -Pin <old>,<new>`
5. **Install the certificate on PATCH-01:**
   ```bash
   cp -a /patch/certs /patch/certs.before-ca        # the way back
   install -m 0644 new.crt /patch/certs/patch01.crt
   install -m 0600 new.key /patch/certs/patch01.key
   ./scripts/phase1a-ingress.sh
   ./scripts/phase1a-ingress.sh --check            # shows the names and expiry now served
   ```
6. **Check:** the console loads without a warning; on **Agents**, the Windows
   servers keep checking in; **Windows \u203a WSUS** keeps receiving reports.
7. **Linux agents can now verify PATCH-01 properly** (they have been running
   with `--insecure`). Copy your CA certificate to each and re-run the
   installer with no token; the enrolment is kept:
   ```bash
   ./install-agent.sh --server https://SGPINFAPPXU01 --ca /etc/pki/ca-trust/source/anchors/corp-ca.pem
   ```
8. **Later, optional:** drop the old pin from Windows (`-Pin <new> -Repin`),
   or use `-Pin system` if your CA is trusted by Windows (for example
   through Group Policy).

**If anything goes wrong in step 5:** `cp -a /patch/certs.before-ca/. /patch/certs/ && ./scripts/phase1a-ingress.sh`.
The Windows agents still accept the old certificate, because of step 3.

## Part 2 - PATCH-01's new IP

Agents, WSUS servers and the Pulp repositories all use PATCH-01's **name**, so
they follow DNS. What names the **IP** has to be changed with it:

1. Lower the DNS TTL for `SGPINFAPPXU01` a day ahead.
2. Change the IP, then update the DNS A record (short name and FQDN).
3. **AI-01's allow-list** admits only PATCH-01's IP. On AI-01:
   `./ai01-setup.sh --patch01-ip <PATCH-01's new IP>`
4. **Anything that allows PATCH-01 by address:** the web proxy (PATCH-01
   fetches NVD, CISA, Microsoft and GitHub through it), the mail relay (relay
   permission), vCenter if it restricts clients, and firewall rules towards
   PATCH-01 on 443 from servers and WSUS.
5. **Check:** `./scripts/phase3b-api.sh --check`, a test mail from
   **Admin \u203a Mail**, and a CVE feed run (`./scripts/phase4-cve.sh --check`).

## Part 3 - AI-01's new IP

AI-01's certificate names its IP, and PATCH-01 connects to it by IP, so the
certificate is made again and PATCH-01 re-pins it.

1. Change AI-01's IP.
2. On AI-01, move the old certificate aside so a new one is made for the new
   address, then run the setup again:
   ```bash
   mv /llm/certs /llm/certs.before-ip
   ./ai01-setup.sh --patch01-ip <PATCH-01's IP>
   ```
3. On PATCH-01: `./scripts/phase6-llm.sh --ai01 <AI-01's new IP>`
   This finds AI-01 at its new address and pins its new certificate.
4. **Check:** the chat on the console answers, and a custom-profile
   "Ask AI-01" or a report e-mail's "Polish with AI-01" works.
