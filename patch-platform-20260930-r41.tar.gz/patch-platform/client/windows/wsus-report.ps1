<#
.SYNOPSIS
  Send a read-only summary of this WSUS server to PATCH-01.

.DESCRIPTION
  Runs on the WSUS server. Reads, never changes: sync health, update counts,
  computer groups, and for every computer when it last reported and how many
  approved updates it still needs. Uses Microsoft's UpdateServices module,
  installed with the WSUS role.

  Make a reporting token on PATCH-01:   ./scripts/phase10-windows.sh --wsus-token <this server's name>

.EXAMPLE
  .\wsus-report.ps1 -Server https://SGPINFAPPXU01 -Pin <sha256> -Token <token> -Test      # collect and show, send nothing
  .\wsus-report.ps1 -Server https://SGPINFAPPXU01 -Pin <sha256> -Token <token> -Install   # send now, then every 6 hours
  .\wsus-report.ps1 -Repin -Pin <old>,<new>      # change the certificate pin, keep the token
  .\wsus-report.ps1 -Uninstall
#>
param(
    [string]$Server, [string]$Pin, [string]$Token,
    [switch]$Test, [switch]$Install, [switch]$Uninstall, [switch]$Run, [switch]$Repin
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$Dir = Join-Path $env:ProgramData "PatchAgentWsus"
$Cfg = Join-Path $Dir "wsus.json"
$Tok = Join-Path $Dir "token.bin"
$TaskName = "PATCH-01 WSUS report"
$Self = Join-Path $Dir "wsus-report.ps1"

if (-not ("PatchAgentPin" -as [type])) {
    Add-Type -TypeDefinition @"
using System; using System.Net; using System.Net.Security;
using System.Security.Cryptography; using System.Security.Cryptography.X509Certificates;
public static class PatchAgentPin {
    public static string Pin = ""; public static string Seen = "";
    public static bool Check(object s, X509Certificate cert, X509Chain ch, SslPolicyErrors e) {
        if (cert == null) { return false; }
        using (SHA256 sha = SHA256.Create()) { Seen = BitConverter.ToString(sha.ComputeHash(cert.GetRawCertData())).Replace("-", "").ToLowerInvariant(); }
        if (Pin == "system") { return e == SslPolicyErrors.None; }
        // Several fingerprints, comma-separated, while a certificate is being replaced
        foreach (string one in Pin.Split(',')) { if (one.Length > 0 && Seen == one) { return true; } }
        return false;
    }
    public static void Use(string pin) {
        Pin = pin.Trim().ToLowerInvariant().Replace(":", "").Replace(" ", "");
        ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(Check);
    }
}
"@
}

function Get-IsoUtc($When) {
    if ($null -eq $When -or $When -eq [datetime]::MinValue) { return $null }
    return ([datetime]$When).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ", [Globalization.CultureInfo]::InvariantCulture)
}

function Get-Summary {
    Import-Module UpdateServices -ErrorAction Stop
    $w = Get-WsusServer
    $sub = $w.GetSubscription()
    $last = $sub.GetLastSynchronizationInfo()
    $st = $w.GetStatus()
    $groups = @{}
    foreach ($g in $w.GetComputerTargetGroups()) { $groups[[string]$g.Id] = [string]$g.Name }
    $scope = New-Object Microsoft.UpdateServices.Administration.UpdateScope
    $scope.ApprovedStates = [Microsoft.UpdateServices.Administration.ApprovedStates]::LatestRevisionApproved
    $cscope = New-Object Microsoft.UpdateServices.Administration.ComputerTargetScope
    $sums = @{}
    foreach ($s in $w.GetSummariesPerComputerTarget($scope, $cscope)) { $sums[[string]$s.ComputerTargetId] = $s }
    $computers = @()
    foreach ($c in $w.GetComputerTargets($cscope)) {
        $s = $sums[[string]$c.Id]
        $gn = @(); foreach ($gid in $c.ComputerTargetGroupIds) { if ($groups.ContainsKey([string]$gid)) { $gn += $groups[[string]$gid] } }
        $row = @{ name = ([string]$c.FullDomainName).ToLowerInvariant(); ip = [string]$c.IPAddress; os = [string]$c.OSDescription
                  groups = $gn; last_reported = (Get-IsoUtc $c.LastReportedStatusTime); last_synced = (Get-IsoUtc $c.LastSyncTime) }
        if ($s) {
            $row["needed"] = [int]($s.NotInstalledCount + $s.DownloadedCount)
            $row["failed"] = [int]$s.FailedCount
            $row["pending_reboot"] = [int]$s.InstalledPendingRebootCount
        }
        $computers += $row
    }
    $server = @{
        name = [string]$w.Name; version = [string]$w.Version; port = [int]$w.PortNumber
        sync = @{ last_start = (Get-IsoUtc $last.StartTime); last_end = (Get-IsoUtc $last.EndTime); result = [string]$last.Result
                  error = [string]$last.Error; automatic = [bool]$sub.SynchronizeAutomatically
                  next = (Get-IsoUtc $sub.GetNextSynchronizationTime()) }
        updates = @{ total = [int]$st.UpdateCount; approved = [int]$st.ApprovedUpdateCount; not_approved = [int]$st.NotApprovedUpdateCount
                     declined = [int]$st.DeclinedUpdateCount; expired = [int]$st.ExpiredUpdateCount
                     security_not_approved = [int]$st.CriticalOrSecurityUpdatesNotApprovedForInstallCount
                     needed_by_computers = [int]$st.UpdatesNeededByComputersCount }
        computers = @{ total = [int]$st.ComputerTargetCount; needing_updates = [int]$st.ComputerTargetsNeedingUpdatesCount
                       with_errors = [int]$st.ComputerTargetsWithUpdateErrorsCount }
        groups = @($groups.Values | Sort-Object)
    }
    return @{ server = $server; computers = $computers }
}

function Send-Summary([string]$Srv, [string]$PinValue, [string]$T) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [PatchAgentPin]::Use($PinValue)
    [Net.WebRequest]::DefaultWebProxy = $null
    try { $body = Get-Summary } catch { $body = @{ server = @{}; computers = @(); error = [string]$_.Exception.Message } }
    $json = ConvertTo-Json -InputObject $body -Depth 8 -Compress
    try {
        $r = Invoke-RestMethod -Method Post -Uri ($Srv.TrimEnd("/") + "/api/v1/wsus/report") -UseBasicParsing -TimeoutSec 120 `
               -Headers @{ Authorization = "Bearer " + $T } -ContentType "application/json; charset=utf-8" -Body ([Text.Encoding]::UTF8.GetBytes($json))
    } catch {
        $d = $_.Exception.Message
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $d = $_.ErrorDetails.Message }
        if ([PatchAgentPin]::Seen -and [PatchAgentPin]::Pin -ne "system" -and ([PatchAgentPin]::Pin.Split(",") -notcontains [PatchAgentPin]::Seen)) {
            $d = "PATCH-01's certificate does not match the pin. It presented " + [PatchAgentPin]::Seen }
        throw "Sending to PATCH-01 failed: $d"
    }
    return $r
}

$me = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw "Run PowerShell as administrator." }

if ($Uninstall) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force $Dir -ErrorAction SilentlyContinue
    "Removed."; return
}
if ($Repin) {
    if (-not $Pin) { throw "Give -Pin (old,new while the certificate changes)." }
    $p = ($Pin -replace "[:\s]", "").ToLowerInvariant()
    if ($p -notmatch "^(system|[0-9a-f]{64}(,[0-9a-f]{64})?)$") { throw "The pin must be one or two 64-character SHA-256 values, comma-separated, or 'system'." }
    Add-Type -AssemblyName System.Security
    $c = Get-Content -Raw $Cfg | ConvertFrom-Json
    $t = [Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($Tok), $null, "LocalMachine"))
    $r = Send-Summary $c.server $p $t              # proves the new pin before keeping it
    $c.pin = $p
    ConvertTo-Json -InputObject $c | Set-Content -Path $Cfg -Encoding UTF8
    "Re-pinned and checked: sent {0} computers with the new pin." -f $r.computers
    return
}
if ($Run) {
    Add-Type -AssemblyName System.Security
    $c = Get-Content -Raw $Cfg | ConvertFrom-Json
    $t = [Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($Tok), $null, "LocalMachine"))
    Send-Summary $c.server $c.pin $t | Out-Null
    return
}
if (-not ($Server -and $Pin -and $Token)) { throw "Give -Server, -Pin and -Token (see the help: Get-Help .\wsus-report.ps1)." }
if ($Test) {
    $s = Get-Summary
    "WSUS {0} (version {1})" -f $s.server.name, $s.server.version
    "Last sync: {0}, {1}" -f $s.server.sync.last_end, $s.server.sync.result
    "Updates: {0} approved, {1} security updates not approved" -f $s.server.updates.approved, $s.server.updates.security_not_approved
    "Computers: {0}, {1} needing updates, {2} with errors" -f $s.computers.Count, $s.server.computers.needing_updates, $s.server.computers.with_errors
    "Nothing was sent. Use -Install to send it to PATCH-01."
    return
}
if ($Install) {
    if (-not (Test-Path $Dir)) { New-Item -ItemType Directory -Path $Dir | Out-Null }
    $acl = New-Object Security.AccessControl.DirectorySecurity; $acl.SetAccessRuleProtection($true, $false)
    foreach ($sid in @("S-1-5-18", "S-1-5-32-544")) {
        $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule((New-Object Security.Principal.SecurityIdentifier($sid)), "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")))
    }
    Set-Acl -Path $Dir -AclObject $acl
    Copy-Item -Force $MyInvocation.MyCommand.Path $Self
    ConvertTo-Json -InputObject @{ server = $Server.TrimEnd("/"); pin = $Pin.Trim().ToLowerInvariant() } | Set-Content -Path $Cfg -Encoding UTF8
    Add-Type -AssemblyName System.Security
    [IO.File]::WriteAllBytes($Tok, [Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($Token), $null, "LocalMachine"))
    $r = Send-Summary $Server $Pin $Token
    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument ("-NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"" + $Self + "`" -Run")
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(10) -RepetitionInterval (New-TimeSpan -Hours 6)
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Force | Out-Null
    "Sent: {0} computers. It will send again every 6 hours." -f $r.computers
    return
}
throw "Choose -Test, -Install or -Uninstall."
