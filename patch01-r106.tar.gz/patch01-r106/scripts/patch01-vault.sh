#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 : every credential in Vault (r103)
#
# Usage (as root):
#   ./patch01-vault.sh --setup [--manual] [--image IMAGE]
#                         first time: Vault in Docker, unseal keys (shown once), every
#                         file of /patch/secrets moved into it, /patch/secrets in RAM
#   ./patch01-vault.sh --status       sealed or not, everything saved or not
#   ./patch01-vault.sh --unseal       type the unseal keys (manual mode, after a restart)
#   ./patch01-vault.sh --save         save changes in /patch/secrets now (also automatic)
#   ./patch01-vault.sh --manual       stop keeping unseal keys on this server
#   ./patch01-vault.sh --auto         keep them again (Vault unseals by itself at boot)
#   ./patch01-vault.sh --new-token [--typed]
#                         a new access token (expired: PATCH-01 off 32+ days, or the kept one
#                         cannot be read on this machine); --typed: you type the unseal keys
#   ./patch01-vault.sh --forget FILE  delete one file from Vault for good (e.g. vcenter/old.env)
#   ./patch01-vault.sh --forget-old   delete the old plain files (/patch/secrets.pre-vault)
#   ./patch01-vault.sh --disable      back to plain files on disk (Vault and its data are kept); works
#                                     even when Vault does not answer: from what is loaded in RAM
#   ./patch01-vault.sh --doctor       one report of why Vault does not answer (no secrets in it)
#   --boot                            used by patch01-start.sh: start, unseal, fill /patch/secrets
#
# How it works: Vault keeps the credentials, encrypted. It listens on a Unix
# socket only (no network port). While PATCH-01 runs, /patch/secrets is RAM
# (tmpfs), filled from Vault: every script and container finds the same files
# as before, and none is on disk in clear. Changes there are saved back to
# Vault within seconds (a systemd path unit), every 5 minutes, and at shutdown.
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 077
export LC_ALL=C

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
SCRIPTS="$(dirname "$SELF")"
SRC_DIR="$(dirname "$SCRIPTS")"
# Overridable only for the tests (a temporary folder, stand-ins for docker and systemd)
PATCH_BASE="${PATCH01_BASE:-/patch}"
ETC="${PATCH01_ETC:-/etc}"
SECRETS="$PATCH_BASE/secrets"
OLD="$PATCH_BASE/secrets.pre-vault"
VAULT_DIR="$PATCH_BASE/vault"
# Outside /patch: a backup of /patch (Vault's encrypted data) never holds the unseal keys too
KEYS="${PATCH01_VAULT_KEYS:-/var/lib/patch01-vault}"
VLOG="$PATCH_BASE/logs/vault"
SOCK_DIR="${PATCH01_VAULT_SOCKDIR:-/run/patch01-vault}"
COMPOSE_DIR="$PATCH_BASE/compose"
CF="$COMPOSE_DIR/docker-compose.vault.yml"
TMPL="$SRC_DIR/compose/docker-compose.vault.yml.tmpl"
HCL="$SRC_DIR/config/vault/vault.hcl"
PYV="$SCRIPTS/patch01_vault.py"
DEFAULT_IMAGE="hashicorp/vault:1.20.1"
UNITS="$ETC/systemd/system"
LOG_DIR="${PATCH01_LOG_DIR:-/var/log/patch-platform}"
export PATCH01_VAULT_SOCKET="$SOCK_DIR/vault.sock" PATCH01_VAULT_KEYS="$KEYS"
export PATCH01_VAULT_STATE="${PATCH01_VAULT_STATE:-/run/patch01-vault-state.json}"

MODE=""; MANUAL=no; IMAGE=""; TYPED=no; FORGET_FILE=""
while (($#)); do
  case "$1" in
    --setup) MODE=setup ;; --status) MODE=status ;; --unseal) MODE=unseal ;; --save) MODE=save ;;
    --manual) MANUAL=yes ;;                       # with --setup in any order; alone: switch to manual
    --auto) MODE=auto ;; --new-token) MODE=newtoken ;; --forget-old) MODE=forget ;;
    --forget) MODE=forgetfile; FORGET_FILE="${2:-}"; shift ;;
    --typed) TYPED=yes ;;
    --disable) MODE=disable ;; --boot) MODE=boot ;; --doctor) MODE=doctor ;;
    --image) IMAGE="${2:-}"; shift ;;
    -h|--help) sed -n '2,32p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done
[[ -z "$MODE" && "$MANUAL" == yes ]] && MODE=manual
[[ -n "$MODE" ]] || { sed -n '2,32p' "$0"; exit 2; }
[[ $EUID -eq 0 ]] || { echo "Run as root." >&2; exit 1; }

mkdir -p "$LOG_DIR"; chmod 0750 "$LOG_DIR"
if [[ "$MODE" == status ]]; then LOG_FILE=/dev/null     # run by every health check: no log file each time
else LOG_FILE="$LOG_DIR/patch01-vault-$(date +%Y%m%d-%H%M%S).log"; : >"$LOG_FILE"; chmod 0600 "$LOG_FILE"; fi
log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
SWITCHING=no
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2
         [[ "$SWITCHING" == yes ]] && { SWITCHING=no; rollback; }      # half switched to RAM: put back
         exit 1; }

PY="$(command -v python3 || true)"
[[ -n "$PY" ]] || die "python3 is needed (dnf install python3)."
pyv() { "$PY" "$PYV" "$@"; }

enabled()   { [[ -e "$KEYS/enabled" ]]; }
in_ram()    { [[ "$(findmnt -n -o FSTYPE --target "$SECRETS" 2>/dev/null)" == tmpfs ]] && mountpoint -q "$SECRETS"; }
loaded()    { [[ -e "$SECRETS/.vault-loaded" ]]; }
# Vault answers (the socket file alone proves nothing: a restarted container leaves the old one)
sock_up()   { pyv ping --wait "${1:-60}" >>"$LOG_FILE" 2>&1; }
compose()   { (cd "$COMPOSE_DIR" && docker compose -f "$CF" "$@") >>"$LOG_FILE" 2>&1; }

# Containers that read /patch/secrets: restarted after it is filled, so their bind mounts are the RAM files
restart_users() {
  local c
  for c in $(docker ps --format '{{.Names}}' | grep '^patch01-' | grep -vx 'patch01-vault' || true); do
    docker restart "$c" >>"$LOG_FILE" 2>&1 && say "  restarted $c" || warn "could not restart $c"
  done
}

fill() {   # unsealed Vault -> /patch/secrets (RAM)
  in_ram || systemctl start patch-secrets.mount || die "/patch/secrets could not be mounted in RAM (systemctl status patch-secrets.mount)"
  in_ram || die "/patch/secrets is not RAM (tmpfs): not filling it from Vault"
  pyv render --dest "$SECRETS" | tee -a "$LOG_FILE" || die "could not fill $SECRETS from Vault"
}

start_vault() {
  systemd-tmpfiles --create "$ETC/tmpfiles.d/patch01-vault.conf" >>"$LOG_FILE" 2>&1 || true
  [[ -f "$CF" ]] || die "$CF is missing: run --setup"
  compose up -d || die "the Vault container did not start (docker compose; details in $LOG_FILE)"
  sock_up 60 || die "Vault does not answer on $SOCK_DIR/vault.sock (docker logs patch01-vault)"
}

selinux_on() { command -v getenforce >/dev/null 2>&1 && [[ "$(getenforce 2>/dev/null || echo Disabled)" != Disabled ]]; }

# SELinux (when on): the same label as PATCH-01's other bind-mounted folders (phase0-bootstrap.sh)
selinux_label() {
  selinux_on && command -v semanage >/dev/null 2>&1 || return 0
  local d
  for d in "$VAULT_DIR" "$SOCK_DIR"; do
    semanage fcontext -a -t container_file_t "${d}(/.*)?" >>"$LOG_FILE" 2>&1 \
      || semanage fcontext -m -t container_file_t "${d}(/.*)?" >>"$LOG_FILE" 2>&1 || warn "could not label $d for SELinux"
    restorecon -R "$d" >>"$LOG_FILE" 2>&1 || true
  done
}

install_units() {   # uid gid of the image's vault user
  local dirs d opts="mode=0700,size=64m,nosuid,nodev,noexec"
  # A tmpfs takes its SELinux label from the mount: containers may read it like the folder it replaces
  selinux_on && opts+=",context=system_u:object_r:container_file_t:s0"
  mkdir -p "$ETC/tmpfiles.d" "$ETC/logrotate.d" "$UNITS"
  cat >"$ETC/tmpfiles.d/patch01-vault.conf" <<EOF
# PATCH-01 Vault's socket folder (r103): only root and the container's vault user
d $SOCK_DIR 0700 $1 $2 -
EOF
  systemd-tmpfiles --create "$ETC/tmpfiles.d/patch01-vault.conf"
  cat >"$UNITS/patch-secrets.mount" <<EOF
[Unit]
Description=PATCH-01 credentials in RAM, filled from Vault (r103)
RequiresMountsFor=$PATCH_BASE
Before=docker.service

[Mount]
What=tmpfs
Where=$SECRETS
Type=tmpfs
Options=$opts

[Install]
WantedBy=multi-user.target
EOF
  cat >"$UNITS/patch01-secrets-skeleton.service" <<EOF
[Unit]
Description=PATCH-01: empty credential files until Vault fills them (r103)
Requires=patch-secrets.mount
After=patch-secrets.mount
Before=docker.service

[Service]
Type=oneshot
ExecStart=$PY $PYV skeleton --dest $SECRETS

[Install]
WantedBy=multi-user.target
EOF
  mkdir -p "$UNITS/docker.service.d"
  cat >"$UNITS/docker.service.d/patch01-vault.conf" <<EOF
# PATCH-01 (r103): /patch/secrets is RAM with its empty files before any container starts
[Unit]
Wants=patch-secrets.mount patch01-secrets-skeleton.service
After=patch-secrets.mount patch01-secrets-skeleton.service
EOF
  cat >"$UNITS/patch01-secrets-save.service" <<EOF
[Unit]
Description=PATCH-01: save changed credentials to Vault (r103)
ConditionPathExists=$SECRETS/.vault-loaded

[Service]
Type=oneshot
# A script writing several files (or a temporary file then mv) is given a moment to finish
ExecStartPre=/bin/sleep 3
ExecStart=$PY $PYV save --src $SECRETS --quiet
EOF
  cat >"$UNITS/patch01-secrets-save.timer" <<EOF
[Unit]
Description=PATCH-01: save changed credentials to Vault every 5 minutes (r103)

[Timer]
OnBootSec=10min
OnUnitActiveSec=5min

[Install]
WantedBy=timers.target
EOF
  dirs="PathChanged=$SECRETS"
  while IFS= read -r d; do dirs+=$'\n'"PathChanged=$d"; done < <(find "$SECRETS" -mindepth 1 -type d)
  cat >"$UNITS/patch01-secrets-save.path" <<EOF
[Unit]
Description=PATCH-01: save credentials to Vault as soon as they change (r103)

[Path]
$dirs
Unit=patch01-secrets-save.service

[Install]
WantedBy=paths.target
EOF
  cat >"$UNITS/patch01-secrets-final-save.service" <<EOF
[Unit]
Description=PATCH-01: save credentials to Vault before shutdown (r103)
After=docker.service patch-secrets.mount

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/true
ExecStop=-$PY $PYV save --src $SECRETS --quiet

[Install]
WantedBy=multi-user.target
EOF
  cat >"$ETC/logrotate.d/patch01-vault" <<EOF
$VLOG/audit.log {
    weekly
    rotate 26
    compress
    missingok
    notifempty
    copytruncate
}
EOF
  systemctl daemon-reload
}

rollback() {   # a setup that stopped while switching /patch/secrets to RAM: everything as it was
  trap - ERR
  warn "putting $SECRETS back as it was"
  umount -l "$SECRETS" 2>/dev/null || systemctl stop patch-secrets.mount 2>/dev/null || true
  if [[ -d "$OLD" ]]; then
    if [[ -d "$SECRETS" ]]; then rm -rf --one-file-system "$SECRETS" 2>/dev/null || true; fi
    mv "$OLD" "$SECRETS"
  fi
  remove_units; rm -f "$KEYS/enabled"
}

remove_units() {
  systemctl disable --now patch01-secrets-save.path patch01-secrets-save.timer patch01-secrets-final-save.service \
    patch01-secrets-skeleton.service >>"$LOG_FILE" 2>&1 || true
  systemctl disable patch-secrets.mount >>"$LOG_FILE" 2>&1 || true
  rm -f "$UNITS/patch-secrets.mount" "$UNITS/patch01-secrets-skeleton.service" "$UNITS/docker.service.d/patch01-vault.conf" \
        "$UNITS/patch01-secrets-save.service" "$UNITS/patch01-secrets-save.timer" "$UNITS/patch01-secrets-save.path" \
        "$UNITS/patch01-secrets-final-save.service"
  systemctl daemon-reload
}

# ---------------------------------------------------------------------------
case "$MODE" in
status)
  enabled || { say "Vault is not used: credentials are plain files in $SECRETS (run --setup to move them into Vault)"; exit 0; }
  rc=0; pyv status --src "$SECRETS" || rc=$?
  [[ -d "$OLD" ]] && say "Old plain files still on disk: $OLD (delete with --forget-old once PATCH-01 works)"
  exit "$rc" ;;

boot)
  enabled || exit 0
  step "vault (credentials)"
  start_vault
  urc=0; pyv unseal --auto 2>&1 | tee -a "$LOG_FILE" || urc=${PIPESTATUS[0]}
  if (( urc == 3 )); then
    say ""
    say "  Vault is SEALED (manual mode). PATCH-01 cannot start without its credentials."
    say "  Run:  $SELF --unseal"
    exit 3
  fi
  (( urc == 0 )) || die "Vault could not be unsealed (details above and in $LOG_FILE)"
  if loaded; then say "  credentials already loaded"; exit 0; fi
  fill
  # Containers Docker started at boot found empty files: they read the real ones from now on
  restart_users
  exit 0 ;;

unseal)
  enabled || die "Vault is not used on this server."
  start_vault
  pyv unseal || die "Vault is still sealed."
  if ! loaded; then fill; restart_users; fi
  say ""
  say "Unsealed. Starting PATCH-01:"
  exec "$SCRIPTS/patch01-start.sh" ;;

save)
  enabled && loaded || die "Vault is not in use or $SECRETS was not filled from it."
  pyv save --src "$SECRETS"
  say "Everything in $SECRETS is in Vault." ;;

manual) enabled || die "Vault is not used."; pyv seal-mode manual ;;
auto)   enabled || die "Vault is not used."; pyv seal-mode auto ;;

newtoken)
  # Also after a --setup that stopped part way (Vault initialised, not in use yet)
  enabled || [[ -f "$CF" ]] || die "Vault is not set up here."
  start_vault
  if [[ "$TYPED" == yes || "$(cat "$KEYS/mode" 2>/dev/null)" == manual ]]; then pyv new-token --typed; else pyv new-token; fi ;;

forgetfile)
  enabled || die "Vault is not used."
  [[ -n "$FORGET_FILE" ]] || die "Name the file, as under $SECRETS: --forget vcenter/old.env"
  read -r -p "Delete $FORGET_FILE from Vault for good (every version)? Type DELETE: " a
  [[ "$a" == DELETE ]] || { say "Kept."; exit 0; }
  pyv forget "$FORGET_FILE" $([[ "$TYPED" == yes ]] && echo --typed)
  [[ -e "$SECRETS/$FORGET_FILE" ]] && say "Still in $SECRETS (RAM) until you delete it there: rm $SECRETS/$FORGET_FILE" || true ;;

forget)
  enabled || die "Vault is not used."
  [[ -d "$OLD" ]] || { say "Nothing to delete: $OLD is not there."; exit 0; }
  step "Comparing the old files with Vault"
  pyv verify --src "$OLD" || say "  (differences above: credentials changed since the move are newer in Vault, which is expected)"
  read -r -p "Delete $OLD for good (overwritten, then removed)? Type DELETE: " a
  [[ "$a" == DELETE ]] || { say "Kept."; exit 0; }
  find "$OLD" -type f -exec shred -u {} + 2>>"$LOG_FILE" || true
  rm -rf "$OLD"
  say "Deleted. The credentials are now only in Vault (and in RAM while PATCH-01 runs)." ;;

disable)
  enabled || die "Vault is not used."
  step "Writing the credentials back to plain files"
  TMP="$PATCH_BASE/secrets.from-vault"
  rm -rf "$TMP"
  FROM=""
  # 1. From Vault, when it answers (and can be unsealed)
  if pyv ping --wait 10 >>"$LOG_FILE" 2>&1 \
     && { pyv unseal --auto >>"$LOG_FILE" 2>&1 || { [[ -t 0 ]] && pyv unseal; }; }; then
    loaded && { pyv save --src "$SECRETS" >>"$LOG_FILE" 2>&1 || true; }
    pyv export --dest "$TMP" >>"$LOG_FILE" 2>&1 && FROM="Vault"
  fi
  # 2. Vault does not answer (r106): what PATCH-01 has loaded now, in RAM, is the newest copy
  if [[ -z "$FROM" ]] && in_ram && loaded; then
    warn "Vault does not answer: taking the credentials PATCH-01 has loaded now (RAM)"
    rm -rf "$TMP"; mkdir -m 0700 "$TMP"
    cp -a "$SECRETS/." "$TMP/" || die "could not copy $SECRETS"
    rm -f "$TMP/.vault-loaded"
    FROM="the credentials loaded in RAM"
  fi
  # 3. Nothing loaded either: the plain files kept from before the move
  if [[ -z "$FROM" && -d "$OLD" ]]; then
    warn "Vault does not answer and nothing is loaded: taking the plain files kept from before the move ($OLD)"
    rm -rf "$TMP"; cp -a "$OLD" "$TMP" || die "could not copy $OLD"
    FROM="the files kept from before the move (changes made since are not in them)"
  fi
  [[ -n "$FROM" ]] || die "Vault does not answer, nothing is loaded in RAM and $OLD is gone: nothing to put back. Send: $SELF --doctor"
  [[ -n "$(find "$TMP" -type f | head -1)" ]] || die "the copy taken from $FROM is empty: nothing changed"
  say "  taken from $FROM: $(find "$TMP" -type f | wc -l) file(s)"
  remove_units
  umount -l "$SECRETS" 2>>"$LOG_FILE" || true
  in_ram && die "$SECRETS is still mounted"
  rmdir "$SECRETS" 2>/dev/null || mv "$SECRETS" "$SECRETS.empty-$(date +%s)"
  mv "$TMP" "$SECRETS"; chmod 0700 "$SECRETS"
  rm -f "$KEYS/enabled"
  restart_users
  say ""
  say "Back to plain files in $SECRETS (from $FROM). Vault and its data are kept (stop it with:"
  say "  cd $COMPOSE_DIR && docker compose -f $CF down )" ;;

doctor)
  # Everything needed to see why Vault does not answer, in one file: no secret values
  set +e; trap - ERR                     # a report goes on whatever fails: that is what it reports
  REPORT="$LOG_DIR/patch01-vault-doctor-$(date +%Y%m%d-%H%M%S).txt"
  sec() { printf '\n== %s\n' "$*"; }
  {
    sec "package"; cat "$SRC_DIR/VERSION" 2>&1; date -Is; uname -r
    sec "in use"; ls -la "$KEYS/enabled" 2>&1; cat "$KEYS/mode" 2>&1
    sec "status"; timeout 30 "$PY" "$PYV" status --src "$SECRETS" 2>&1
    sec "container"; docker ps -a --filter name=patch01-vault --format '{{.Names}} | {{.Status}} | {{.Image}}' 2>&1
    docker inspect -f 'started {{.State.StartedAt}}, restarts {{.RestartCount}}, running {{.State.Running}}, pid {{.State.Pid}}' patch01-vault 2>&1
    sec "mounts (host -> container)"
    docker inspect -f '{{range .Mounts}}{{.Source}} -> {{.Destination}} (rw={{.RW}}, propagation={{.Propagation}}){{"\n"}}{{end}}' patch01-vault 2>&1
    sec "socket folder on the host"; ls -laZ "$SOCK_DIR" 2>&1 || ls -la "$SOCK_DIR" 2>&1
    sec "socket folder in the container"; docker exec patch01-vault ls -la /vault/sock 2>&1; docker exec patch01-vault id vault 2>&1
    sec "listening sockets in the container"; docker exec patch01-vault cat /proc/net/unix 2>&1 | grep -i vault
    sec "vault status in the container"; docker exec patch01-vault vault status 2>&1
    sec "config"; ls -laZ "$VAULT_DIR/config" 2>&1 || ls -la "$VAULT_DIR/config" 2>&1; cat "$VAULT_DIR/config/vault.hcl" 2>&1
    sec "compose file"; cat "$CF" 2>&1
    sec "tmpfiles rule"; cat "$ETC/tmpfiles.d/patch01-vault.conf" 2>&1
    sec "vault log: start"; docker logs patch01-vault 2>&1 | head -40
    sec "vault log: last lines"; docker logs --tail 40 patch01-vault 2>&1
    sec "SELinux"; getenforce 2>&1; command -v ausearch >/dev/null && ausearch -m avc -ts today 2>/dev/null | grep -i -E "vault|patch01" | tail -20
    sec "/patch/secrets (names only)"; findmnt "$SECRETS" 2>&1; ls -la "$SECRETS" 2>&1 | head -40
    sec "kept keys (names only)"; ls -la "$KEYS" 2>&1
    sec "old plain files (names only)"; ls -la "$OLD" 2>&1 | head -20
    sec "docker"; docker version --format 'server {{.Server.Version}}' 2>&1; docker info --format 'driver {{.Driver}}, root {{.DockerRootDir}}, security {{.SecurityOptions}}' 2>&1
    sec "systemd units"; systemctl is-active patch-secrets.mount patch01-secrets-save.path patch01-secrets-save.timer 2>&1
  } >"$REPORT" 2>&1
  chmod 0600 "$REPORT"
  cat "$REPORT"
  say ""
  say "Saved in: $REPORT   (no passwords or keys in it: names, states and Vault's own log only)" ;;

setup)
  enabled && die "Vault is already in use here (see --status)."
  [[ "$MANUAL" == yes ]] || MANUAL=no
  [[ -d "$SECRETS" ]] && ! in_ram || die "$SECRETS is missing or already RAM."
  [[ -n "$(ls -A "$SECRETS" 2>/dev/null)" ]] || die "$SECRETS is empty: nothing to move."
  [[ ! -e "$OLD" ]] || die "$OLD already exists: a previous move was not finished. Look at it, then remove or rename it."
  [[ -f "$TMPL" && -f "$HCL" ]] || die "files of this package are missing ($TMPL, $HCL)"
  timeout 20 docker info >/dev/null 2>&1 || die "docker is not running."

  step "Vault image"
  if [[ -z "$IMAGE" ]]; then
    if docker image inspect "$DEFAULT_IMAGE" >/dev/null 2>&1; then IMAGE="$DEFAULT_IMAGE"
    else IMAGE="$(docker images --format '{{.Repository}}:{{.Tag}}' 'hashicorp/vault' | grep -E ':[0-9]+\.[0-9]+' | sort -V | tail -1 || true)"; fi
    if [[ -z "$IMAGE" ]]; then
      say "  pulling $DEFAULT_IMAGE (through the host's Docker proxy)..."
      docker pull -q "$DEFAULT_IMAGE" >>"$LOG_FILE" 2>&1 \
        || die "No Vault image here and $DEFAULT_IMAGE could not be pulled. Pull or load one (docker load -i vault.tar), then: $0 --setup --image hashicorp/vault:TAG"
      IMAGE="$DEFAULT_IMAGE"
    fi
  fi
  docker image inspect "$IMAGE" >/dev/null 2>&1 || die "image $IMAGE is not on this host"
  ids="$(docker run --rm --network none --entrypoint sh "$IMAGE" -c 'command -v vault >/dev/null && id -u vault && id -g vault' 2>>"$LOG_FILE")" \
    || die "$IMAGE does not look like the hashicorp/vault image (no vault command or vault user)"
  VUID="$(sed -n 1p <<<"$ids")"; VGID="$(sed -n 2p <<<"$ids")"
  [[ "$VUID" =~ ^[0-9]+$ && "$VGID" =~ ^[0-9]+$ ]] || die "could not read the vault user's ids from $IMAGE"
  say "  $IMAGE (vault user $VUID:$VGID)"

  step "Vault container (no network; a Unix socket for root only)"
  mkdir -p "$VAULT_DIR/config" "$VAULT_DIR/data" "$VLOG" "$KEYS" "$COMPOSE_DIR"
  chmod 0700 "$VAULT_DIR" "$KEYS"
  install -m 0400 -o "$VUID" -g 0 "$HCL" "$VAULT_DIR/config/vault.hcl"
  chown "$VUID":0 "$VAULT_DIR/config"; chmod 0500 "$VAULT_DIR/config"
  chown "$VUID:$VGID" "$VAULT_DIR/data" "$VLOG"; chmod 0700 "$VAULT_DIR/data" "$VLOG"
  install_units "$VUID" "$VGID"
  selinux_label
  sed -e "s|@@VAULT_IMAGE@@|$IMAGE|g" -e "s|@@VAULT_DIR@@|$VAULT_DIR|g" \
      -e "s|@@LOG_DIR@@|$VLOG|g" -e "s|@@SOCK_DIR@@|$SOCK_DIR|g" "$TMPL" >"$CF"
  chmod 0640 "$CF"
  grep -q '@@' "$CF" && die "$CF still has placeholders"
  start_vault
  say "  running"

  if pyv initialized; then
    # An earlier --setup stopped part way: Vault keeps what it has; carry on from there
    step "Vault is already initialised (an earlier --setup stopped): continuing"
    pyv unseal --auto >>"$LOG_FILE" 2>&1 || pyv unseal || die "Vault must be unsealed to continue"
    if [[ ! -s "$KEYS/token.cred" && ! -s "$KEYS/token.plain" ]]; then
      say "  No access token kept yet: making one with the unseal keys"
      pyv new-token --typed || die "could not make an access token"
    fi
    [[ "$MANUAL" == yes ]] && pyv seal-mode manual >/dev/null
  else
    step "Initialising Vault"
    say "  The 5 unseal keys are printed ONCE below. Have somewhere safe ready."
    read -r -p "  Press Enter to show them..." _
    pyv setup $([[ "$MANUAL" == yes ]] && echo --manual) \
      || die "Vault setup failed. If unseal keys were shown, keep them: run --setup again to continue."
    echo
    while :; do
      read -r -p "Type SAVED once all 5 keys are stored safely (they are not shown again): " a
      [[ "$a" == SAVED ]] && break
    done
    command -v clear >/dev/null && clear || true
    say "  Keys stored by you. Vault is unsealed."
  fi
  [[ "$MANUAL" == yes ]] && say "  Manual mode: after every restart of PATCH-01, run: $SELF --unseal"

  step "Moving every file of $SECRETS into Vault"
  pyv import --src "$SECRETS" | tee -a "$LOG_FILE" || die "the import failed: nothing was changed on disk. Fix the cause shown above, then run --setup again (it continues from here)."

  step "Switching $SECRETS to RAM"
  trap 'rollback' ERR
  SWITCHING=yes
  mv "$SECRETS" "$OLD"; chmod 0700 "$OLD"
  mkdir -m 0700 "$SECRETS"
  systemctl enable --now patch-secrets.mount >>"$LOG_FILE" 2>&1
  fill
  pyv verify --src "$SECRETS" | tee -a "$LOG_FILE"
  pyv verify --src "$SECRETS" >/dev/null
  install_units "$VUID" "$VGID"           # again: the path unit watches the folders now in RAM
  systemctl enable patch01-secrets-skeleton.service patch01-secrets-final-save.service >>"$LOG_FILE" 2>&1
  systemctl start patch01-secrets-final-save.service
  systemctl enable --now patch01-secrets-save.timer patch01-secrets-save.path >>"$LOG_FILE" 2>&1
  touch "$KEYS/enabled"
  trap - ERR; SWITCHING=no
  restart_users

  say ""
  say "Done. Every credential is in Vault; $SECRETS is RAM, filled from it."
  say "  - At boot, patch01-start.sh unseals Vault ($([[ "$MANUAL" == yes ]] && echo "manual: you type the keys" || echo "by itself")) and fills it."
  say "  - Changes there are saved to Vault by themselves."
  say "  - The old plain files are kept in $OLD until you are sure:"
  say "      $SCRIPTS/patch01-update.sh        (health check)"
  say "      $SELF --forget-old"
  say "  Back up: $VAULT_DIR (encrypted) with the rest of /patch. Keep the unseal keys apart from it." ;;
esac
