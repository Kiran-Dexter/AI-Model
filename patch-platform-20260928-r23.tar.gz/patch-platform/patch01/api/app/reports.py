"""Hardening reports, as PDF and Word, branded from /patch/data/branding.

Both formats carry the same content: a cover, contents, an executive summary
with the score, pass rate by CIS section and the most widely failing checks,
results by server, findings in detail, the evidence behind every figure, and
how the assessment was made. Every page after the cover has the logo, title
and classification in the header, and the copyright line and "Page X of Y"
in the footer.
"""

import hashlib
import io
import json
import os
import re
from datetime import datetime, timedelta, timezone

FONT_DIR = os.path.join(os.path.dirname(__file__), "fonts")
REPORT_DIR = os.path.join(os.environ.get("HARDENING_DIR", "/hardening"), "reports")
TZ = timezone(timedelta(hours=8))
SEV_ORDER = {"high": 0, "medium": 1, "low": 2, "unknown": 3}
SECTION_NAMES = {"1": "Initial setup", "2": "Services", "3": "Network", "4": "Host-based firewall",
                 "5": "Access control", "6": "Logging and auditing", "7": "System maintenance"}
LEVEL_NAME = {"l1": "CIS Level 1 Server", "l2": "CIS Level 2 Server"}
PRODUCT_NAME = {"rhel8": "RHEL 8", "rhel9": "RHEL 9", "rhel10": "RHEL 10", "ol7": "Oracle Linux 7",
                "ol8": "Oracle Linux 8", "ol9": "Oracle Linux 9", "ubuntu2004": "Ubuntu 20.04",
                "ubuntu2204": "Ubuntu 22.04", "ubuntu2404": "Ubuntu 24.04"}


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------

def _section(cis):
    first = (cis or "").split(",")[0].strip()
    m = re.match(r"(\d+)", first)
    return m.group(1) if m else None


def gather(conn, level, host_ids=None, detail="high_medium"):
    """Everything the report shows, from the latest finished scan per server."""
    scans = conn.execute(
        """SELECT * FROM v_hardening_latest WHERE level = %s
              AND (%s::uuid[] IS NULL OR host_id = ANY(%s::uuid[]))
            ORDER BY score NULLS LAST, hostname""", (level, host_ids, host_ids)).fetchall()
    if not scans:
        raise ValueError("No finished scan at this level for the chosen servers: scan them first.")
    ids = [s["id"] for s in scans]
    rows = conn.execute(
        """SELECT r.scan_id, r.rule_id, r.result, coalesce(hr.severity, r.severity, 'unknown') AS severity,
                  hr.title, hr.cis_ref, hr.description, hr.rationale, hr.fix_available, hr.fix_script, hr.risky
             FROM hardening_results r
             JOIN hardening_scans s ON s.id = r.scan_id
             LEFT JOIN hardening_rules hr ON hr.content_version = s.content_version
                  AND hr.product = s.product AND hr.rule_id = r.rule_id
            WHERE r.scan_id = ANY(%s::uuid[]) AND r.result IN ('pass', 'fail')""", (ids,)).fetchall()
    prev = conn.execute(
        """SELECT DISTINCT ON (host_id) host_id, score FROM hardening_scans
            WHERE level = %s AND state = 'done' AND host_id = ANY(%s::uuid[]) AND NOT (id = ANY(%s::uuid[]))
            ORDER BY host_id, finished_at DESC""",
        (level, [s["host_id"] for s in scans], ids)).fetchall()
    host_of = {s["id"]: s for s in scans}

    rules, sections = {}, {}
    per_host = {s["id"]: {"high": 0} for s in scans}
    for r in rows:
        sev = (r["severity"] or "unknown").lower()
        sec = _section(r["cis_ref"]) or "other"
        st = sections.setdefault(sec, [0, 0])
        st[0 if r["result"] == "pass" else 1] += 1
        if r["result"] != "fail":
            continue
        if sev == "high":
            per_host[r["scan_id"]]["high"] += 1
        k = r["rule_id"]
        e = rules.setdefault(k, {"rule_id": k, "title": r["title"] or k.split("content_rule_")[-1],
                                 "severity": sev, "cis": r["cis_ref"], "description": r["description"],
                                 "rationale": r["rationale"], "fix": r["fix_script"], "fix_available": r["fix_available"],
                                 "risky": bool(r["risky"]), "servers": []})
        e["servers"].append(host_of[r["scan_id"]]["hostname"])
    failing = sorted(rules.values(), key=lambda x: (SEV_ORDER.get(x["severity"], 3), -len(x["servers"]), x["title"]))
    passed = sum(s["passed"] or 0 for s in scans)
    failed = sum(s["failed"] or 0 for s in scans)
    scores = [float(s["score"]) for s in scans if s["score"] is not None]
    prev_scores = [float(p["score"]) for p in prev if p["score"] is not None]
    fleet = round(sum(scores) / len(scores), 1) if scores else None
    previous = round(sum(prev_scores) / len(prev_scores), 1) if prev_scores else None
    sec_rows = []
    for k in sorted(sections, key=lambda x: (x == "other", int(x) if x.isdigit() else 99)):
        p_, f_ = sections[k]
        if p_ + f_:
            sec_rows.append({"key": k, "name": SECTION_NAMES.get(k, "Other checks" if k == "other" else f"Section {k}"),
                             "pct": round(100 * p_ / (p_ + f_)), "passed": p_, "failed": f_})
    products = sorted({s["product"] for s in scans})
    content = sorted({s["content_version"] for s in scans})
    servers = [{"hostname": s["hostname"], "os": PRODUCT_NAME.get(s["product"], s["product"]),
                "score": float(s["score"]) if s["score"] is not None else None, "passed": s["passed"] or 0,
                "failed": s["failed"] or 0, "high": per_host[s["id"]]["high"], "finished": s["finished_at"],
                "oscap": s.get("oscap_version"), "sha256": s.get("evidence_sha256")} for s in scans]
    shown = {"all": failing, "high": [r for r in failing if r["severity"] == "high"],
             "high_medium": [r for r in failing if r["severity"] in ("high", "medium")]}.get(detail, failing)
    finished = [s["finished_at"] for s in scans if s["finished_at"]]
    return {
        "level": level, "level_name": LEVEL_NAME.get(level, level.upper()), "servers": servers,
        "fleet_score": fleet, "previous_score": previous, "passed": passed, "failed": failed,
        "high_open": sum(1 for r in failing if r["severity"] == "high"),
        "below_70": [s for s in servers if s["score"] is not None and s["score"] < 70],
        "sections": sec_rows,
        "top": sorted(failing, key=lambda x: (-len(x["servers"]), SEV_ORDER.get(x["severity"], 3), x["title"]))[:10],
        "findings": shown,
        "findings_other": [r for r in failing if r not in shown],
        "detail": detail, "products": [PRODUCT_NAME.get(p, p) for p in products], "content": content,
        "period": (min(finished), max(finished)) if finished else (None, None),
    }


def key_messages(d):
    """Plain statements drawn only from the figures, never guessed."""
    out = []
    if d["top"]:
        t = d["top"][0]
        out.append(("The most widespread gap", f"\u201c{t['title']}\u201d fails on {len(t['servers'])} of "
                    f"{len(d['servers'])} servers; fixing it once lifts all of them."))
    if d["sections"]:
        w = min(d["sections"], key=lambda s: s["pct"])
        out.append((f"{w['name']} is the weakest area", f"{w['pct']}% of its checks pass across the servers assessed."))
    if d["below_70"]:
        lo = min(d["below_70"], key=lambda s: s["score"])
        out.append((f"{lo['hostname']} needs attention first",
                    f"it scores {lo['score']:.1f}%" + (f" with {lo['high']} high-severity failures." if lo["high"] else ".")))
    if d["high_open"]:
        out.append(("High-severity findings are open", f"{d['high_open']} distinct high-severity checks fail somewhere in scope."))
    if d["previous_score"] is not None and d["fleet_score"] is not None:
        delta = d["fleet_score"] - d["previous_score"]
        out.append(("Trend", f"the fleet score moved {'up' if delta >= 0 else 'down'} {abs(delta):.1f} points "
                    f"since the previous assessment ({d['previous_score']:.1f}%)."))
    return out


def _band(score):
    return "good" if score >= 85 else "fair" if score >= 70 else "poor"


def _fmt(ts, with_time=True):
    if not ts:
        return "-"
    return ts.astimezone(TZ).strftime("%d %b %Y, %H:%M SGT" if with_time else "%d %b %Y")


def _period(d):
    a, b = d["period"]
    if not a:
        return "-"
    a, b = a.astimezone(TZ), b.astimezone(TZ)
    return a.strftime("%d %b %Y") if a.date() == b.date() else f"{a.strftime('%d %b')} to {b.strftime('%d %b %Y')}"


def _fix_excerpt(script, lines=12):
    if not script:
        return None
    body = [l for l in script.strip().splitlines() if l.strip() and not l.strip().startswith("#")]
    more = len(body) > lines
    return "\n".join(body[:lines]) + ("\n..." if more else "")


# ---------------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------------

def build_pdf(d, brand, meta, path):
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_RIGHT
    from reportlab.lib.fonts import addMapping
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.pdfgen import canvas as pdfcanvas
    from reportlab.platypus import (BaseDocTemplate, CondPageBreak, Flowable, Frame, KeepTogether, NextPageTemplate,
                                    PageBreak, PageTemplate, Paragraph, Preformatted, Spacer, Table, TableStyle)
    from reportlab.platypus.tableofcontents import TableOfContents
    from reportlab.graphics.shapes import Circle, Drawing, String, Wedge
    from xml.sax.saxutils import escape as X

    for name, f in (("Head", "Poppins-Medium"), ("HeadB", "Poppins-Bold"), ("HeadL", "Poppins-Light"),
                    ("Body", "LiberationSans-Regular"), ("BodyB", "LiberationSans-Bold"),
                    ("BodyI", "LiberationSans-Italic"), ("Mono", "LiberationMono-Regular")):
        if name not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont(name, os.path.join(FONT_DIR, f + ".ttf")))
    addMapping("Body", 0, 0, "Body"); addMapping("Body", 1, 0, "BodyB"); addMapping("Body", 0, 1, "BodyI")

    NAVY = colors.HexColor(brand["navy"]); ACCENT = colors.HexColor(brand["accent"])
    INK = colors.HexColor("#1B2430"); INK2 = colors.HexColor("#5A6573"); RULE = colors.HexColor("#D9DEE4")
    PANEL = colors.HexColor("#F4F6F9"); PASS = colors.HexColor("#1E8E5A"); FAIL = colors.HexColor("#C0392B")
    WARN = colors.HexColor("#C8850A")
    BAND = {"good": PASS, "fair": WARN, "poor": FAIL}
    SEV = {"high": FAIL, "medium": WARN, "low": INK2, "unknown": INK2}
    PAGE_W, PAGE_H = A4
    M = 18 * mm
    S = {
        "h1": ParagraphStyle("h1", fontName="HeadB", fontSize=18, leading=23, textColor=NAVY, spaceBefore=2, spaceAfter=8),
        "h2": ParagraphStyle("h2", fontName="Head", fontSize=12.5, leading=17, textColor=NAVY, spaceBefore=12, spaceAfter=5),
        "body": ParagraphStyle("body", fontName="Body", fontSize=9.6, leading=14, textColor=INK, spaceAfter=6),
        "small": ParagraphStyle("small", fontName="Body", fontSize=8.2, leading=11.5, textColor=INK2),
        "cell": ParagraphStyle("cell", fontName="Body", fontSize=8.6, leading=11.4, textColor=INK),
        "cellr": ParagraphStyle("cellr", fontName="Body", fontSize=8.6, leading=11.4, textColor=INK, alignment=TA_RIGHT),
        "th": ParagraphStyle("th", fontName="BodyB", fontSize=7.8, leading=10, textColor=INK2),
        "thr": ParagraphStyle("thr", fontName="BodyB", fontSize=7.8, leading=10, textColor=INK2, alignment=TA_RIGHT),
        "label": ParagraphStyle("label", fontName="BodyB", fontSize=7.4, leading=9, textColor=INK2),
        "mono": ParagraphStyle("mono", fontName="Mono", fontSize=7.2, leading=9.4, textColor=INK),
    }
    P = lambda t, st="cell": Paragraph(t, S[st])  # noqa: E731
    title = f"CIS Hardening Report \u00b7 {d['level_name']}"

    logo = ImageReader(io.BytesIO(brand["logo"])) if brand["logo"] else None
    logo_w = ImageReader(io.BytesIO(brand["logo_white"])) if brand["logo_white"] else None
    aspect = (brand["logo_meta"] or {}).get("aspect") or 3.0

    def draw_logo(c, x, y, box_w, box_h, on_dark=False):
        """Fit the logo in the box, keeping its shape. On a dark band a dark
        logo sits on a white plate so it stays visible."""
        img = logo_w if (on_dark and logo_w) else logo
        if img is None:
            c.saveState(); c.setFillColor(colors.white if on_dark else NAVY); c.setFont("HeadB", min(16, box_h * 0.6))
            c.drawString(x, y + box_h * 0.25, brand["company"]); c.restoreState()
            return
        w = min(box_w, box_h * aspect); h = w / aspect
        if on_dark and not logo_w and (brand["logo_meta"] or {}).get("dark", True):
            pad = 3.2 * mm
            c.saveState(); c.setFillColor(colors.white)
            c.roundRect(x - pad, y + (box_h - h) / 2 - pad, w + 2 * pad, h + 2 * pad, 3, stroke=0, fill=1)
            c.restoreState()
        c.drawImage(img, x, y + (box_h - h) / 2, width=w, height=h, mask="auto", preserveAspectRatio=True)

    class NumberedCanvas(pdfcanvas.Canvas):
        def __init__(self, *a, **k):
            super().__init__(*a, **k); self._saved = []
        def showPage(self):
            self._saved.append(dict(self.__dict__)); self._startPage()
        def save(self):
            total = len(self._saved)
            for st in self._saved:
                self.__dict__.update(st)
                if self._pageNumber > 1:
                    self.saveState()
                    self.setStrokeColor(RULE); self.setLineWidth(0.6); self.line(M, 14 * mm, PAGE_W - M, 14 * mm)
                    self.setFont("Body", 7.4); self.setFillColor(INK2)
                    self.drawString(M, 9.5 * mm, brand["copyright"])
                    self.drawCentredString(PAGE_W / 2, 9.5 * mm, brand["classification"])
                    self.setFont("BodyB", 7.6); self.setFillColor(INK)
                    self.drawRightString(PAGE_W - M, 9.5 * mm, f"Page {self._pageNumber} of {total}")
                    self.restoreState()
                super().showPage()
            super().save()
            meta["pages"] = total

    def cover(c, doc):
        c.saveState()
        c.setFillColor(NAVY); c.rect(0, PAGE_H - 118 * mm, PAGE_W, 118 * mm, stroke=0, fill=1)
        c.setFillColor(ACCENT); c.rect(0, PAGE_H - 118 * mm, PAGE_W, 2.2 * mm, stroke=0, fill=1)
        draw_logo(c, M, PAGE_H - 36 * mm, 60 * mm, 18 * mm, on_dark=True)
        c.setFillColor(colors.HexColor("#9FB3CC")); c.setFont("Head", 9.5)
        c.drawString(M, PAGE_H - 62 * mm, "SECURITY CONFIGURATION ASSESSMENT")
        c.setFillColor(colors.white); c.setFont("HeadB", 30); c.drawString(M, PAGE_H - 76 * mm, "CIS Hardening Report")
        c.setFont("HeadL", 14); c.setFillColor(colors.HexColor("#DCE6F2"))
        c.drawString(M, PAGE_H - 87 * mm, f"{d['level_name']} \u00b7 {meta['scope_label']}")
        tw = c.stringWidth(brand["classification"], "BodyB", 8.5)
        c.setFillColor(colors.white); c.roundRect(M, PAGE_H - 104 * mm, tw + 14, 16, 3, stroke=0, fill=1)
        c.setFillColor(NAVY); c.setFont("BodyB", 8.5); c.drawString(M + 7, PAGE_H - 104 * mm + 5, brand["classification"])
        y = PAGE_H - 140 * mm
        facts = [("Organisation", brand["company"]),
                 ("Scope", f"{len(d['servers'])} server{'s' if len(d['servers']) != 1 else ''} \u00b7 {', '.join(d['products'])}"),
                 ("Benchmark", f"{d['level_name']} \u00b7 SSG {', '.join(d['content'])}"),
                 ("Assessment period", _period(d)),
                 ("Generated", f"{_fmt(meta['generated_at'])} \u00b7 {meta['generated_by']}"),
                 ("Report ID", meta["report_id"])]
        for k, v in facts:
            c.setFont("BodyB", 7.6); c.setFillColor(INK2); c.drawString(M, y, k.upper())
            c.setFillColor(INK)
            room = PAGE_W - 2 * M - 36 * mm - 64 * mm
            size, vv = 10, v
            while size > 7.5 and c.stringWidth(vv, "Body", size) > room:
                size -= 0.5                                  # shrink a little first
            while c.stringWidth(vv, "Body", size) > room and len(vv) > 4:
                vv = vv[:-2].rstrip() + "\u2026" if not vv.endswith("\u2026") else vv[:-3].rstrip() + "\u2026"
            c.setFont("Body", size); c.drawString(M + 36 * mm, y - 0.5, vv)
            c.setStrokeColor(RULE); c.setLineWidth(0.5); c.line(M, y - 5 * mm, PAGE_W - M - 64 * mm, y - 5 * mm)
            y -= 12.5 * mm
        if d["fleet_score"] is not None:
            col = BAND[_band(d["fleet_score"])]
            bx, by = PAGE_W - M - 56 * mm, PAGE_H - 184 * mm
            c.setFillColor(PANEL); c.roundRect(bx, by, 56 * mm, 48 * mm, 4, stroke=0, fill=1)
            c.setFillColor(col); c.rect(bx, by + 48 * mm - 1.6 * mm, 56 * mm, 1.6 * mm, stroke=0, fill=1)
            c.setFillColor(INK2); c.setFont("BodyB", 7.4)
            c.drawString(bx + 6 * mm, by + 38 * mm, "FLEET SCORE" if len(d["servers"]) > 1 else "SCORE")
            c.setFillColor(col); c.setFont("HeadB", 34); c.drawString(bx + 6 * mm, by + 23 * mm, f"{d['fleet_score']:.1f}%")
            c.setFillColor(INK); c.setFont("Body", 8.4)
            c.drawString(bx + 6 * mm, by + 14 * mm, f"{d['passed']} passed \u00b7 {d['failed']} failed")
            if d["previous_score"] is not None:
                delta = d["fleet_score"] - d["previous_score"]
                c.setFillColor(PASS if delta >= 0 else FAIL); c.setFont("BodyB", 8.4)
                arrow = "\u25B2" if delta >= 0 else "\u25BC"
                c.drawString(bx + 6 * mm, by + 8 * mm, f"{arrow} {abs(delta):.1f} points")
                c.setFillColor(INK2); c.setFont("Body", 8.4)
                c.drawString(bx + 27 * mm, by + 8 * mm, f"since {d['previous_score']:.1f}%")
        c.setFont("Body", 7.4); c.setFillColor(INK2)
        c.drawString(M, 20 * mm, "Produced by PATCH-01. Results are CIS-aligned, from the SCAP Security Guide; "
                                 "this is not a CIS-CAT assessment.")
        c.drawString(M, 16 * mm, f"{brand['copyright']}  This document is {brand['classification'].lower()}.")
        c.restoreState()

    def body_page(c, doc):
        c.saveState()
        draw_logo(c, M, PAGE_H - 16.5 * mm, 36 * mm, 10 * mm)
        c.setFont("Head", 8.4); c.setFillColor(INK); c.drawRightString(PAGE_W - M, PAGE_H - 11 * mm, title)
        c.setFont("BodyB", 7); c.setFillColor(FAIL); c.drawRightString(PAGE_W - M, PAGE_H - 15 * mm, brand["classification"])
        c.setStrokeColor(RULE); c.setLineWidth(0.6); c.line(M, PAGE_H - 19 * mm, PAGE_W - M, PAGE_H - 19 * mm)
        c.restoreState()

    class Doc(BaseDocTemplate):
        def __init__(self, fn):
            super().__init__(fn, pagesize=A4, leftMargin=M, rightMargin=M, topMargin=26 * mm, bottomMargin=22 * mm,
                             title=title, author=brand["company"], subject=f"{d['level_name']} assessment",
                             creator="PATCH-01")
            f = Frame(M, 22 * mm, PAGE_W - 2 * M, PAGE_H - 48 * mm, id="f", leftPadding=0, rightPadding=0)
            self.addPageTemplates([PageTemplate("cover", frames=[Frame(0, 0, PAGE_W, PAGE_H)], onPage=cover),
                                   PageTemplate("body", frames=[f], onPage=body_page)])
        def afterFlowable(self, fl):
            if isinstance(fl, Paragraph) and fl.style.name in ("h1", "h2"):
                self.notify("TOCEntry", (0 if fl.style.name == "h1" else 1, fl.getPlainText(), self.page))

    class Bar(Flowable):
        def __init__(self, pct, w=42 * mm, h=3.2 * mm):
            super().__init__(); self.pct, self.w, self.h = pct, w, h
        def wrap(self, *a):
            return self.w, self.h + 1
        def draw(self):
            c = self.canv
            c.setFillColor(RULE); c.roundRect(0, 0.5, self.w, self.h, 1.2, stroke=0, fill=1)
            c.setFillColor(BAND[_band(self.pct)])
            c.roundRect(0, 0.5, max(0.8, self.w * self.pct / 100), self.h, 1.2, stroke=0, fill=1)

    def table(rows, widths, head=True, zebra=True):
        t = Table(rows, colWidths=widths, repeatRows=1 if head else 0)
        st = [("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 4.2),
              ("BOTTOMPADDING", (0, 0), (-1, -1), 4.2), ("LEFTPADDING", (0, 0), (-1, -1), 5),
              ("RIGHTPADDING", (0, 0), (-1, -1), 5), ("LINEBELOW", (0, 0), (-1, -1), 0.4, RULE)]
        if head:
            st += [("BACKGROUND", (0, 0), (-1, 0), PANEL), ("LINEBELOW", (0, 0), (-1, 0), 0.8, NAVY)]
        if zebra:
            st += [("BACKGROUND", (0, i), (-1, i), colors.HexColor("#FAFBFC")) for i in range(2 if head else 1, len(rows), 2)]
        t.setStyle(TableStyle(st))
        return t

    def sev(s):
        return P(f'<font color="{SEV.get(s, INK2).hexval()}"><b>{X(s.title())}</b></font>')

    def donut(score, size=46 * mm):
        dr = Drawing(size, size); cx = cy = size / 2; r = size / 2 - 2
        dr.add(Circle(cx, cy, r, fillColor=RULE, strokeColor=None))
        dr.add(Wedge(cx, cy, r, 90 - 360 * score / 100, 90, fillColor=BAND[_band(score)], strokeColor=None))
        dr.add(Circle(cx, cy, r * 0.72, fillColor=colors.white, strokeColor=None))
        dr.add(String(cx, cy + 1, f"{score:.1f}%", fontName="HeadB", fontSize=17, fillColor=INK, textAnchor="middle"))
        dr.add(String(cx, cy - 12, "score", fontName="Body", fontSize=7.5, fillColor=INK2, textAnchor="middle"))
        return dr

    def kpi(label, value, sub, color=INK):
        t = Table([[P(X(label.upper()), "label")],
                   [Paragraph(f'<font name="HeadB" size="20" color="{color.hexval()}">{X(str(value))}</font>',
                              ParagraphStyle("kv", parent=S["cell"], leading=24))],
                   [P(X(sub), "small")]], colWidths=[38 * mm])
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), PANEL), ("LEFTPADDING", (0, 0), (-1, -1), 8),
                               ("TOPPADDING", (0, 0), (0, 0), 8), ("BOTTOMPADDING", (0, -1), (-1, -1), 8),
                               ("TOPPADDING", (0, 1), (-1, -1), 1), ("BOTTOMPADDING", (0, 0), (-1, -2), 1),
                               ("LINEABOVE", (0, 0), (-1, 0), 1.6, color if color != INK else ACCENT)]))
        return t

    n = len(d["servers"])
    story = [NextPageTemplate("body"), PageBreak()]
    toc = TableOfContents()
    toc.levelStyles = [ParagraphStyle("t0", fontName="Head", fontSize=10.5, leading=20, textColor=NAVY),
                       ParagraphStyle("t1", fontName="Body", fontSize=9, leading=15, leftIndent=12, textColor=INK)]
    toc.dotsMinLevel = 0
    story += [Paragraph("Contents", ParagraphStyle("tt", parent=S["h1"])), Spacer(1, 4), toc, PageBreak()]

    # 1. Executive summary
    story.append(Paragraph("1. Executive summary", S["h1"]))
    lead = (f"{n} server{'s were' if n != 1 else ' was'} assessed against the {d['level_name']} benchmark. "
            f"{'The fleet passes' if n > 1 else 'It passes'} <b>{d['fleet_score']:.1f}%</b> of applicable checks")
    if d["previous_score"] is not None:
        delta = d["fleet_score"] - d["previous_score"]
        lead += f", {'up' if delta >= 0 else 'down'} {abs(delta):.1f} points on the previous assessment"
    lead += f". {len(d['below_70'])} below the 70% threshold; {d['high_open']} high-severity checks fail."
    story.append(P(lead, "body"))
    kp = Table([[donut(d["fleet_score"]), kpi("Servers assessed", n, "in scope"),
                 kpi("High severity", d["high_open"], "failing checks", FAIL if d["high_open"] else PASS),
                 kpi("Below 70%", len(d["below_70"]),
                     (d["below_70"][0]["hostname"] + f" at {d['below_70'][0]['score']:.1f}%") if d["below_70"] else "none",
                     FAIL if d["below_70"] else PASS)]],
               colWidths=[52 * mm, 41 * mm, 41 * mm, 40 * mm])
    kp.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                            ("RIGHTPADDING", (0, 0), (-1, -1), 3)]))
    story += [Spacer(1, 4), kp, Spacer(1, 6)]
    msgs = key_messages(d)
    if msgs:
        story.append(Paragraph("Key messages", S["h2"]))
        for head, text in msgs:
            story.append(Paragraph(f"\u2022 <b>{X(head)}</b>: {X(text)}",
                                   ParagraphStyle("bl", parent=S["body"], leftIndent=10, firstLineIndent=-8)))
    if d["sections"]:
        story.append(Paragraph("Compliance by CIS section", S["h2"]))
        rows = [[P("Section", "th"), P("", "th"), P("Pass rate", "thr")]]
        for sct in d["sections"]:
            rows.append([P(f"<b>{X(sct['key']) if sct['key'] != 'other' else ''}</b>&nbsp;&nbsp;{X(sct['name'])}"),
                         Bar(sct["pct"], 80 * mm), P(f"{sct['pct']}%", "cellr")])
        story.append(table(rows, [62 * mm, 88 * mm, 24 * mm], zebra=False))
    if d["top"]:
        rows = [[P("Check", "th"), P("CIS", "th"), P("Severity", "th"), P("Servers failing", "thr")]]
        for r in d["top"]:
            rows.append([P(X(r["title"]) + (' <font color="#C8850A">\u25B2</font>' if r["risky"] else "")),
                         P(X(r["cis"] or "-")), sev(r["severity"]), P(f"<b>{len(r['servers'])}</b> of {n}", "cellr")])
        story.append(CondPageBreak(55 * mm))
        story += [Paragraph("Most widely failing checks", S["h2"]),
                  P("Fixing one of these improves every server listed against it. Checks marked "
                    "\u25B2 can cut off access or stop services if changed carelessly; apply them to "
                    "one server first.", "small"), Spacer(1, 3),
                  table(rows, [96 * mm, 24 * mm, 24 * mm, 30 * mm])]
    story.append(CondPageBreak(90 * mm))

    # 2. Results by server
    story.append(Paragraph("2. Results by server", S["h1"]))
    story.append(P("Score = passed checks divided by passed plus failed. Checks that do not apply to a server are "
                   "excluded either way.", "body"))
    rows = [[P("Server", "th"), P("Operating system", "th"), P("Score", "th"), P("", "th"),
             P("Passed", "thr"), P("Failed", "thr"), P("High", "thr")]]
    for sv in d["servers"]:
        sc = sv["score"] or 0
        rows.append([P(f"<b>{X(sv['hostname'])}</b>"), P(X(sv["os"])), Bar(sc, 34 * mm),
                     P(f'<font color="{BAND[_band(sc)].hexval()}"><b>{sc:.1f}%</b></font>', "cellr"),
                     P(str(sv["passed"]), "cellr"), P(str(sv["failed"]), "cellr"),
                     P(f'<font color="#C0392B"><b>{sv["high"]}</b></font>' if sv["high"] else "0", "cellr")])
    story.append(table(rows, [30 * mm, 30 * mm, 38 * mm, 18 * mm, 18 * mm, 18 * mm, 22 * mm]))
    story.append(Spacer(1, 6))
    story.append(P("Score bands: <font color='#1E8E5A'><b>85% and above</b></font> good, "
                   "<font color='#C8850A'><b>70 to 84%</b></font> needs work, "
                   "<font color='#C0392B'><b>below 70%</b></font> priority.", "small"))

    # 3. Findings
    story.append(CondPageBreak(80 * mm))
    story.append(Paragraph("3. Findings in detail", S["h1"]))
    scope_text = {"all": "every failing check", "high": "high-severity failing checks",
                  "high_medium": "high- and medium-severity failing checks"}[d["detail"]]
    story.append(P(f"This section covers {scope_text}: what was found, why it matters, and how to fix it, ordered "
                   "by severity and then by how many servers fail it.", "body"))
    if not d["findings"]:
        story.append(P("No failing checks in this category.", "body"))
    for r in d["findings"]:
        col = SEV.get(r["severity"], INK2)
        head = Table([[P(f'<font name="Head" size="10.5" color="{NAVY.hexval()}">{X(r["title"])}</font>'),
                       P(f'<font color="{col.hexval()}"><b>{X(r["severity"].upper())}</b></font>'
                         + (f" \u00b7 CIS {X(r['cis'])}" if r["cis"] else ""), "cellr")]], colWidths=[120 * mm, 54 * mm])
        head.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, 0), 1.2, col), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                                  ("RIGHTPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
        body = [[P("FOUND", "label"), P(f"Fails on <b>{len(r['servers'])}</b> of {n} servers."
                                        + (f" {X(r['description'])}" if r["description"] else ""))]]
        if r["rationale"]:
            body.append([P("WHY IT MATTERS", "label"), P(X(r["rationale"]))])
        fx = _fix_excerpt(r["fix"])
        body.append([P("HOW TO FIX", "label"),
                     Preformatted(fx, S["mono"], maxLineLength=96) if fx else P("No automated fix: apply by hand, "
                                                                                 "following the description above.")])
        body.append([P("SERVERS", "label"), P(X(", ".join(sorted(r["servers"]))))])
        body.append([P("RULE", "label"), P(f'<font name="Mono" size="7.4">{X(r["rule_id"].split("content_rule_")[-1])}</font>')])
        if r["risky"]:
            body.append([P("CAUTION", "label"), P('<font color="#C8850A"><b>Can cut off access or stop services.</b></font> '
                                                   "Apply to one server first and confirm access before rolling out.")])
        bt = Table(body, colWidths=[30 * mm, 144 * mm])
        bt.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 3.4),
                                ("BOTTOMPADDING", (0, 0), (-1, -1), 3.4), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
        story.append(KeepTogether([Spacer(1, 6), head, Spacer(1, 3), bt, Spacer(1, 6)]))
    if d["findings_other"]:
        rows = [[P("Other failing check", "th"), P("CIS", "th"), P("Severity", "th"), P("Servers", "thr")]]
        for r in d["findings_other"]:
            rows.append([P(X(r["title"])), P(X(r["cis"] or "-")), sev(r["severity"]), P(str(len(r["servers"])), "cellr")])
        story.append(KeepTogether([Paragraph("Other failing checks", S["h2"]),
                                   table(rows, [100 * mm, 26 * mm, 22 * mm, 26 * mm])]))

    # 4. Evidence
    rows = [[P("Server", "th"), P("Scanned", "th"), P("Scanner", "th"), P("Result file SHA-256", "th")]]
    for sv in d["servers"]:
        hx = sv["sha256"] or ""
        rows.append([P(f"<b>{X(sv['hostname'])}</b>"), P(_fmt(sv["finished"])),
                     P(X((sv["oscap"] or "").replace("OpenSCAP command line tool (oscap) ", "oscap ")[:24])),
                     P(X(hx[:32]) + "<br/>" + X(hx[32:]), "mono")])
    story.append(CondPageBreak(60 * mm))
    story.append(Paragraph("4. Evidence", S["h1"]))
    story.append(P("The full OpenSCAP result file of every scan is kept on PATCH-01. Each is identified by its "
                   "SHA-256, so any figure in this report can be traced back to the raw result.", "body"))
    story.append(table(rows, [28 * mm, 34 * mm, 24 * mm, 88 * mm]))

    # 5. Method
    story.append(CondPageBreak(50 * mm))
    story.append(Paragraph("5. Method and scope", S["h1"]))
    for t in [f"<b>Benchmark.</b> {X(d['level_name'])} profiles from the SCAP Security Guide (ComplianceAsCode) "
              f"release {X(', '.join(d['content']))}, one pinned copy served to every server so all are judged by "
              "the same rules.",
              "<b>Scanning.</b> OpenSCAP ran on each server with read-only checks; nothing was changed by the assessment.",
              "<b>Scoring.</b> Passed checks divided by passed plus failed. Not-applicable and not-checked results are excluded.",
              "<b>Status.</b> Results are CIS-aligned. This is not a CIS-CAT assessment and does not certify compliance.",
              f"<b>This report.</b> {X(meta['report_id'])}, generated {X(_fmt(meta['generated_at']))} by "
              f"{X(meta['generated_by'])}. Its SHA-256 is recorded in PATCH-01's report archive."]:
        story.append(Paragraph(t, S["body"]))

    doc = Doc(path)
    doc.multiBuild(story, canvasmaker=NumberedCanvas)


# ---------------------------------------------------------------------------
# Word
# ---------------------------------------------------------------------------

def _chart_png(kind, d, brand):
    """Charts for the Word version, drawn at print resolution."""
    from PIL import Image, ImageDraw, ImageFont
    f = lambda n, s: ImageFont.truetype(os.path.join(FONT_DIR, n + ".ttf"), s)  # noqa: E731
    band = {"good": (30, 142, 90), "fair": (200, 133, 10), "poor": (192, 57, 43)}
    if kind == "donut":
        W = 600; im = Image.new("RGB", (W, W), "white"); dr = ImageDraw.Draw(im)
        sc = d["fleet_score"]
        dr.ellipse((20, 20, W - 20, W - 20), fill=(217, 222, 228))
        dr.pieslice((20, 20, W - 20, W - 20), -90, -90 + 360 * sc / 100, fill=band[_band(sc)])
        dr.ellipse((110, 110, W - 110, W - 110), fill="white")
        t = f"{sc:.1f}%"; ft = f("Poppins-Bold", 96)
        dr.text((W / 2, W / 2 - 10), t, font=ft, fill=(27, 36, 48), anchor="mm")
        dr.text((W / 2, W / 2 + 62), "score", font=f("LiberationSans-Regular", 34), fill=(90, 101, 115), anchor="mm")
        return im
    rows = d["sections"]
    W, rh = 1800, 64
    im = Image.new("RGB", (W, rh * len(rows) + 10), "white"); dr = ImageDraw.Draw(im)
    fl = f("LiberationSans-Regular", 30); fb = f("LiberationSans-Bold", 30)
    for i, s in enumerate(rows):
        y = i * rh + 12
        dr.text((10, y + 8), (s["key"] + "  " if s["key"] != "other" else "") + s["name"], font=fl, fill=(27, 36, 48))
        x0, x1 = 640, 1600
        dr.rounded_rectangle((x0, y + 14, x1, y + 38), radius=6, fill=(217, 222, 228))
        dr.rounded_rectangle((x0, y + 14, x0 + max(8, (x1 - x0) * s["pct"] / 100), y + 38), radius=6, fill=band[_band(s["pct"])])
        dr.text((W - 20, y + 8), f"{s['pct']}%", font=fb, fill=(27, 36, 48), anchor="ra")
        dr.line((0, y + rh - 8, W, y + rh - 8), fill=(217, 222, 228), width=2)
    return im


def build_docx(d, brand, meta, path):
    from docx import Document
    from docx.enum.section import WD_SECTION
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Mm, Pt, RGBColor

    def rgb(hexv):
        hexv = hexv.lstrip("#"); return RGBColor(int(hexv[0:2], 16), int(hexv[2:4], 16), int(hexv[4:6], 16))
    NAVY, INK, INK2 = rgb(brand["navy"]), rgb("#1B2430"), rgb("#5A6573")
    BAND = {"good": rgb("#1E8E5A"), "fair": rgb("#C8850A"), "poor": rgb("#C0392B")}
    SEV = {"high": rgb("#C0392B"), "medium": rgb("#C8850A"), "low": INK2, "unknown": INK2}
    FONT = "Calibri"                 # installed wherever Word is; the PDF carries its own fonts

    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Mm(210), Mm(297)
    sec.left_margin = sec.right_margin = Mm(18); sec.top_margin = Mm(24); sec.bottom_margin = Mm(20)
    sec.header_distance = Mm(9); sec.footer_distance = Mm(8)
    sec.different_first_page_header_footer = True
    st = doc.styles["Normal"]; st.font.name = FONT; st.font.size = Pt(10); st.font.color.rgb = INK
    st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    for name, size, bold in (("Heading 1", 18, True), ("Heading 2", 13, True)):
        hs = doc.styles[name]; hs.font.name = FONT; hs.font.size = Pt(size); hs.font.bold = bold
        hs.font.color.rgb = NAVY; hs.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
        hs.paragraph_format.space_before = Pt(14 if size > 15 else 10); hs.paragraph_format.space_after = Pt(6)

    def shade(cell, hexv):
        tc = cell._tc.get_or_add_tcPr(); sh = OxmlElement("w:shd")
        sh.set(qn("w:val"), "clear"); sh.set(qn("w:color"), "auto"); sh.set(qn("w:fill"), hexv.lstrip("#")); tc.append(sh)

    def widths(table, mm_list):
        """Fixed column widths. Word and LibreOffice read the table grid, not
        only each cell, so set the layout, the grid and every cell."""
        table.autofit = False
        pr = table._tbl.tblPr
        lay = OxmlElement("w:tblLayout"); lay.set(qn("w:type"), "fixed"); pr.append(lay)
        grid = table._tbl.tblGrid
        for i, gc in enumerate(grid.findall(qn("w:gridCol"))):
            if i < len(mm_list):
                gc.set(qn("w:w"), str(int(mm_list[i] * 56.7)))      # twentieths of a point
        for row in table.rows:
            for i, cell in enumerate(row.cells):
                if i < len(mm_list):
                    cell.width = Mm(mm_list[i])

    def borders(table, color="D9DEE4"):
        tbl = table._tbl; pr = tbl.tblPr; b = OxmlElement("w:tblBorders")
        for edge in ("top", "bottom", "insideH"):
            e = OxmlElement(f"w:{edge}"); e.set(qn("w:val"), "single"); e.set(qn("w:sz"), "4")
            e.set(qn("w:color"), color); b.append(e)
        for edge in ("left", "right", "insideV"):
            e = OxmlElement(f"w:{edge}"); e.set(qn("w:val"), "nil"); b.append(e)
        pr.append(b)

    def run(p, text, size=None, bold=False, color=None, italic=False, font=None):
        r = p.add_run(text); r.bold = bold; r.italic = italic
        if size: r.font.size = Pt(size)
        if color is not None: r.font.color.rgb = color
        if font: r.font.name = font; r._element.rPr.rFonts.set(qn("w:eastAsia"), font)
        return r

    def field(p, instr, size=8, fallback=None):
        """A live Word field: PAGE, NUMPAGES, TOC."""
        r = p.add_run(); r.font.size = Pt(size)
        a = OxmlElement("w:fldChar"); a.set(qn("w:fldCharType"), "begin")
        t = OxmlElement("w:instrText"); t.set(qn("xml:space"), "preserve"); t.text = instr
        b = OxmlElement("w:fldChar"); b.set(qn("w:fldCharType"), "separate")
        placeholder = OxmlElement("w:t"); placeholder.set(qn("xml:space"), "preserve")
        placeholder.text = fallback if fallback is not None else ("1" if "PAGE" in instr else "")
        c = OxmlElement("w:fldChar"); c.set(qn("w:fldCharType"), "end")
        for el in (a, t, b, placeholder, c):
            r._r.append(el)
        return r

    def data_table(headers, rows, widths_mm, right=()):
        t = doc.add_table(rows=1, cols=len(headers)); t.alignment = WD_TABLE_ALIGNMENT.LEFT; borders(t)
        for i, hd in enumerate(headers):
            c = t.rows[0].cells[i]; shade(c, "F4F6F9")
            p = c.paragraphs[0]; run(p, hd, 8, True, INK2)
            if i in right: p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        for r in rows:
            cells = t.add_row().cells
            for i, v in enumerate(r):
                p = cells[i].paragraphs[0]
                if isinstance(v, tuple):
                    run(p, v[0], 9, v[1] if len(v) > 1 else False, v[2] if len(v) > 2 else None)
                else:
                    run(p, str(v), 9)
                if i in right: p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        widths(t, widths_mm)
        return t

    # Header and footer for every page after the cover
    hdr = sec.header; hp = hdr.paragraphs[0]
    ht = hdr.add_table(rows=1, cols=2, width=Mm(174))
    widths(ht, [70, 104])
    lc, rc = ht.rows[0].cells
    if brand["logo"]:
        lc.paragraphs[0].add_run().add_picture(io.BytesIO(brand["logo"]), height=Mm(9)
                                               if (brand["logo_meta"] or {}).get("aspect", 3) < 4 else None,
                                               width=Mm(34) if (brand["logo_meta"] or {}).get("aspect", 3) >= 4 else None)
    else:
        run(lc.paragraphs[0], brand["company"], 11, True, NAVY)
    rp = rc.paragraphs[0]; rp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run(rp, f"CIS Hardening Report \u00b7 {d['level_name']}", 8, True, INK)
    rp2 = rc.add_paragraph(); rp2.alignment = WD_ALIGN_PARAGRAPH.RIGHT; run(rp2, brand["classification"], 7, True, rgb("#C0392B"))
    hp._p.getparent().remove(hp._p)
    ftr = sec.footer; fp = ftr.paragraphs[0]
    ft = ftr.add_table(rows=1, cols=3, width=Mm(174))
    widths(ft, [86, 40, 48])
    a, b, c = ft.rows[0].cells
    run(a.paragraphs[0], brand["copyright"], 7, False, INK2)
    b.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER; run(b.paragraphs[0], brand["classification"], 7, False, INK2)
    pc = c.paragraphs[0]; pc.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run(pc, "Page ", 8, True, INK); field(pc, "PAGE"); run(pc, " of ", 8, True, INK); field(pc, "NUMPAGES")
    fp._p.getparent().remove(fp._p)

    # Cover: a navy band, as in the PDF
    band = doc.add_table(rows=1, cols=1); band.alignment = WD_TABLE_ALIGNMENT.CENTER
    widths(band, [174])
    cell = band.rows[0].cells[0]; shade(cell, brand["navy"]); cell.width = Mm(174)
    p = cell.paragraphs[0]
    logo_img = brand["logo_white"] or brand["logo"]
    if logo_img and (brand["logo_white"] or not (brand["logo_meta"] or {}).get("dark", True)):
        p.add_run().add_picture(io.BytesIO(logo_img), width=Mm(55) if (brand["logo_meta"] or {}).get("aspect", 3) >= 3 else None,
                                height=Mm(16) if (brand["logo_meta"] or {}).get("aspect", 3) < 3 else None)
    else:
        run(p, brand["company"], 16, True, RGBColor(255, 255, 255))
    for text, size, bold, col in (("", 8, False, None), ("SECURITY CONFIGURATION ASSESSMENT", 9, True, rgb("#9FB3CC")),
                                  ("CIS Hardening Report", 28, True, RGBColor(255, 255, 255)),
                                  (f"{d['level_name']} \u00b7 {meta['scope_label']}", 13, False, rgb("#DCE6F2")),
                                  (brand["classification"], 9, True, rgb("#9FB3CC")), ("", 8, False, None)):
        q = cell.add_paragraph(); run(q, text, size, bold, col)
    if logo_img is not None and (brand["logo_meta"] or {}).get("dark", True) and not brand["logo_white"]:
        # A dark logo would vanish on navy: show it on white, above the band
        lp = doc.paragraphs[0] if doc.paragraphs else doc.add_paragraph()
        band._tbl.addprevious(lp._p)
        lp.add_run().add_picture(io.BytesIO(brand["logo"]), width=Mm(55) if (brand["logo_meta"] or {}).get("aspect", 3) >= 3 else None,
                                 height=Mm(16) if (brand["logo_meta"] or {}).get("aspect", 3) < 3 else None)
    doc.add_paragraph()
    facts = doc.add_table(rows=0, cols=2); borders(facts)
    for k, v in (("Organisation", brand["company"]),
                 ("Scope", f"{len(d['servers'])} server{'s' if len(d['servers']) != 1 else ''} \u00b7 {', '.join(d['products'])}"),
                 ("Benchmark", f"{d['level_name']} \u00b7 SSG {', '.join(d['content'])}"),
                 ("Assessment period", _period(d)), ("Generated", f"{_fmt(meta['generated_at'])} \u00b7 {meta['generated_by']}"),
                 ("Report ID", meta["report_id"]),
                 ("Fleet score" if len(d["servers"]) > 1 else "Score",
                  f"{d['fleet_score']:.1f}%  ({d['passed']} passed, {d['failed']} failed)")):
        r_ = facts.add_row().cells; r_[0].width = Mm(45); r_[1].width = Mm(129)
        run(r_[0].paragraphs[0], k.upper(), 8, True, INK2)
        run(r_[1].paragraphs[0], v, 10.5, k.startswith(("Fleet", "Score")),
            BAND[_band(d["fleet_score"])] if k.startswith(("Fleet", "Score")) else None)
    widths(facts, [45, 129])
    q = doc.add_paragraph(); q.paragraph_format.space_before = Pt(40)
    run(q, "Produced by PATCH-01. Results are CIS-aligned, from the SCAP Security Guide; this is not a CIS-CAT "
           "assessment.", 8, False, INK2)
    q.add_run().add_break(WD_BREAK.PAGE)

    # Contents (Word fills it in when the fields are updated on opening)
    doc.add_heading("Contents", 1)
    toc_lines = ["1. Executive summary", "2. Results by server", "3. Findings in detail", "4. Evidence",
                 "5. Method and scope"]
    tp = doc.add_paragraph()
    field(tp, 'TOC \\o "1-2" \\h \\z \\u', 10, fallback="   ".join(toc_lines))
    note = doc.add_paragraph(); run(note, "Page numbers appear when Word updates the fields on opening "
                                          "(or right-click the contents and choose Update Field).", 8, False, INK2, True)
    doc.add_page_break()
    settings = doc.settings.element
    uf = OxmlElement("w:updateFields"); uf.set(qn("w:val"), "true"); settings.append(uf)

    n = len(d["servers"])
    doc.add_heading("1. Executive summary", 1)
    lead = (f"{n} server{'s were' if n != 1 else ' was'} assessed against the {d['level_name']} benchmark, passing "
            f"{d['fleet_score']:.1f}% of applicable checks")
    if d["previous_score"] is not None:
        delta = d["fleet_score"] - d["previous_score"]
        lead += f", {'up' if delta >= 0 else 'down'} {abs(delta):.1f} points on the previous assessment"
    doc.add_paragraph(lead + f". {len(d['below_70'])} below the 70% threshold; {d['high_open']} high-severity checks fail.")
    buf = io.BytesIO(); _chart_png("donut", d, brand).save(buf, "PNG"); buf.seek(0)
    kt = doc.add_table(rows=1, cols=4)
    widths(kt, [46, 42, 43, 43])
    kt.rows[0].cells[0].paragraphs[0].add_run().add_picture(buf, width=Mm(40))
    for i, (lab, val, sub, col) in enumerate((("SERVERS ASSESSED", n, "in scope", INK),
                                              ("HIGH SEVERITY", d["high_open"], "failing checks", SEV["high"] if d["high_open"] else BAND["good"]),
                                              ("BELOW 70%", len(d["below_70"]), d["below_70"][0]["hostname"] if d["below_70"] else "none",
                                               SEV["high"] if d["below_70"] else BAND["good"])), start=1):
        cc = kt.rows[0].cells[i]; shade(cc, "F4F6F9")
        run(cc.paragraphs[0], lab, 7.5, True, INK2)
        run(cc.add_paragraph(), str(val), 22, True, col); run(cc.add_paragraph(), sub, 8, False, INK2)
    for head, text in key_messages(d):
        pm = doc.add_paragraph(style="List Bullet"); run(pm, head + ": ", None, True); run(pm, text)
    if d["sections"]:
        doc.add_heading("Compliance by CIS section", 2)
        buf = io.BytesIO(); _chart_png("sections", d, brand).save(buf, "PNG"); buf.seek(0)
        doc.add_picture(buf, width=Mm(172))
    if d["top"]:
        doc.add_heading("Most widely failing checks", 2)
        doc.add_paragraph("Fixing one of these improves every server listed against it. Checks marked \u25B2 can cut "
                          "off access or stop services if changed carelessly; apply them to one server first.")
        data_table(["Check", "CIS", "Severity", "Servers failing"],
                   [[r["title"] + (" \u25B2" if r["risky"] else ""), r["cis"] or "-",
                     (r["severity"].title(), True, SEV.get(r["severity"], INK2)), (f"{len(r['servers'])} of {n}", True)]
                    for r in d["top"]], [100, 24, 22, 28], right=(3,))

    doc.add_heading("2. Results by server", 1)
    doc.add_paragraph("Score = passed checks divided by passed plus failed. Checks that do not apply to a server are "
                      "excluded either way. Bands: 85% and above good, 70 to 84% needs work, below 70% priority.")
    data_table(["Server", "Operating system", "Score", "Passed", "Failed", "High"],
               [[(sv["hostname"], True), sv["os"], (f"{(sv['score'] or 0):.1f}%", True, BAND[_band(sv["score"] or 0)]),
                 sv["passed"], sv["failed"], (str(sv["high"]), bool(sv["high"]), SEV["high"] if sv["high"] else None)]
                for sv in d["servers"]], [40, 38, 24, 24, 24, 24], right=(2, 3, 4, 5))

    doc.add_heading("3. Findings in detail", 1)
    doc.add_paragraph({"all": "Every failing check", "high": "High-severity failing checks",
                       "high_medium": "High- and medium-severity failing checks"}[d["detail"]]
                      + ": what was found, why it matters, and how to fix it.")
    for r in d["findings"]:
        h = doc.add_heading(level=2); run(h, r["title"])
        m = doc.add_paragraph(); run(m, r["severity"].upper(), 8.5, True, SEV.get(r["severity"], INK2))
        if r["cis"]:
            run(m, f"  \u00b7  CIS {r['cis']}", 8.5, False, INK2)
        rows = [("FOUND", f"Fails on {len(r['servers'])} of {n} servers." + (f" {r['description']}" if r["description"] else ""))]
        if r["rationale"]:
            rows.append(("WHY IT MATTERS", r["rationale"]))
        rows.append(("HOW TO FIX", _fix_excerpt(r["fix"]) or "No automated fix: apply by hand, following the description above."))
        rows.append(("SERVERS", ", ".join(sorted(r["servers"]))))
        if r["risky"]:
            rows.append(("CAUTION", "Can cut off access or stop services. Apply to one server first and confirm access "
                                    "before rolling out."))
        t = doc.add_table(rows=0, cols=2); borders(t)
        for k, v in rows:
            cc = t.add_row().cells; cc[0].width = Mm(32); cc[1].width = Mm(142)
            run(cc[0].paragraphs[0], k, 7.5, True, INK2)
            run(cc[1].paragraphs[0], v, 8 if k == "HOW TO FIX" else 9.5, k == "CAUTION",
                SEV["medium"] if k == "CAUTION" else None, font="Consolas" if k == "HOW TO FIX" and r["fix"] else None)
        widths(t, [32, 142])
    if d["findings_other"]:
        doc.add_heading("Other failing checks", 2)
        data_table(["Check", "CIS", "Severity", "Servers"],
                   [[r["title"], r["cis"] or "-", (r["severity"].title(), True, SEV.get(r["severity"], INK2)),
                     len(r["servers"])] for r in d["findings_other"]], [104, 26, 22, 22], right=(3,))

    doc.add_heading("4. Evidence", 1)
    doc.add_paragraph("The full OpenSCAP result file of every scan is kept on PATCH-01. Each is identified by its "
                      "SHA-256, so any figure in this report can be traced back to the raw result.")
    et = data_table(["Server", "Scanned", "Result file SHA-256"],
                    [[(sv["hostname"], True), _fmt(sv["finished"]), sv["sha256"] or "-"] for sv in d["servers"]],
                    [32, 40, 102])
    for row in et.rows[1:]:
        for r_ in row.cells[2].paragraphs[0].runs:
            r_.font.name = "Consolas"; r_.font.size = Pt(7.5)

    doc.add_heading("5. Method and scope", 1)
    for head, text in (("Benchmark", f"{d['level_name']} profiles from the SCAP Security Guide (ComplianceAsCode) release "
                                     f"{', '.join(d['content'])}, one pinned copy served to every server."),
                       ("Scanning", "OpenSCAP ran on each server with read-only checks; nothing was changed by the assessment."),
                       ("Scoring", "Passed checks divided by passed plus failed. Not-applicable and not-checked results are excluded."),
                       ("Status", "Results are CIS-aligned. This is not a CIS-CAT assessment and does not certify compliance."),
                       ("This report", f"{meta['report_id']}, generated {_fmt(meta['generated_at'])} by {meta['generated_by']}.")):
        pm = doc.add_paragraph(); run(pm, head + ". ", None, True); run(pm, text)

    doc.core_properties.title = f"CIS Hardening Report \u00b7 {d['level_name']}"
    doc.core_properties.author = brand["company"]
    doc.core_properties.subject = f"{d['level_name']} assessment"
    doc.save(path)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def generate(conn, brand, level, fmt, host_ids=None, scope_label=None, detail="high_medium", user="unknown"):
    """Build a report, keep it in the archive, and return its record."""
    if fmt not in ("pdf", "docx"):
        raise ValueError("format must be pdf or docx")
    d = gather(conn, level, host_ids, detail)
    row = conn.execute(
        """INSERT INTO reports (kind, level, scope, format, generated_by, servers, score)
           VALUES ('hardening', %s, %s, %s, %s, %s, %s) RETURNING id, number, generated_at""",
        (level, json.dumps({"host_ids": host_ids, "label": scope_label, "detail": detail}),
         fmt, user, len(d["servers"]), d["fleet_score"])).fetchone()
    meta = {"report_id": f"HRD-{row['generated_at'].astimezone(TZ):%Y%m%d}-{row['number']:04d}",
            "generated_at": row["generated_at"], "generated_by": user,
            "scope_label": scope_label or ("All servers" if not host_ids else f"{len(d['servers'])} selected servers"),
            "pages": None}
    os.makedirs(REPORT_DIR, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9]+", "-", meta["scope_label"]).strip("-")[:40] or "report"
    name = f"{meta['report_id']}-{level.upper()}-{safe}.{fmt}"
    path = os.path.join(REPORT_DIR, name)
    (build_pdf if fmt == "pdf" else build_docx)(d, brand, meta, path)
    digest = hashlib.sha256(open(path, "rb").read()).hexdigest()
    title = f"CIS Hardening Report, {d['level_name']}, {meta['scope_label']}"
    conn.execute("UPDATE reports SET title=%s, pages=%s, size_bytes=%s, sha256=%s, path=%s WHERE id=%s",
                 (title, meta["pages"], os.path.getsize(path), digest, path, row["id"]))
    return {"id": str(row["id"]), "report_id": meta["report_id"], "file": name, "pages": meta["pages"],
            "size_bytes": os.path.getsize(path), "sha256": digest, "servers": len(d["servers"]),
            "score": d["fleet_score"], "format": fmt, "title": title}
