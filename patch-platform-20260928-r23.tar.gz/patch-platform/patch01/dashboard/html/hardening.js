/* PATCH-01 hardening pages: CIS-aligned OpenSCAP results.
 * Uses the console's shared helpers from app.js (h, api, render, table ...).
 */
"use strict";

const HLEVELS = [["l1", "CIS Level 1 Server"], ["l2", "CIS Level 2 Server"], ["custom", "Custom (from a document)"]];
const HRESULT = {
  pass: ["Pass", "hr-pass"], fail: ["Fail", "hr-fail"], error: ["Error", "hr-error"],
  notapplicable: ["Not applicable", "hr-na"], notchecked: ["Not checked", "hr-na"],
  unknown: ["Unknown", "hr-na"], informational: ["Info", "hr-na"], fixed: ["Fixed", "hr-pass"],
};

function hLevel(params) {
  const l = params.get("level") || localStorage.getItem("patch01.hardening.level") || "l1";
  return ["l1", "l2"].includes(l) ? l : "l1";
}

function levelPicker(level, onChange) {
  const sel = h("select", { "aria-label": "Benchmark profile", class: "hd-level" },
    HLEVELS.map(([k, label]) => h("option", { value: k, selected: k === level, disabled: k === "custom" },
      label + (k === "custom" ? " \u2013 coming next" : ""))));
  sel.addEventListener("change", () => { localStorage.setItem("patch01.hardening.level", sel.value); onChange(sel.value); });
  return sel;
}

function scoreBadge(score) {
  if (score === null || score === undefined) return h("span", { class: "muted" }, "not scanned");
  const n = Number(score);
  const cls = n >= 85 ? "hd-good" : n >= 70 ? "hd-fair" : "hd-poor";
  return h("span", { class: "hd-score " + cls }, n.toFixed(n % 1 ? 1 : 0) + "%");
}

function scoreBar(score) {
  if (score === null || score === undefined) return h("span", { class: "muted" }, "\u2013");
  const n = Math.max(0, Math.min(100, Number(score)));
  const bar = h("span", { class: "hd-bar " + (n >= 85 ? "hd-good" : n >= 70 ? "hd-fair" : "hd-poor") },
    h("span", { class: "hd-bar-fill" }));
  bar.firstChild.style.width = n + "%";
  return h("span", { class: "hd-bar-cell" }, bar, scoreBadge(n));
}

function sevChip(sev) {
  const s = (sev || "unknown").toLowerCase();
  return h("span", { class: "hd-sev hd-sev-" + s }, s === "unknown" ? "\u2013" : s[0].toUpperCase() + s.slice(1));
}

function resultChip(r) {
  const [label, cls] = HRESULT[r] || [r, "hr-na"];
  return h("span", { class: "hd-res " + cls }, label);
}

const CHECKIN_MIN = 5;   // the agent's timer: install-agent.sh --interval

// Where an in-flight scan is, in words, with a bar while rules are checked
function scanProgress(row) {
  const st = row.last_state, stage = row.stage;
  if (st === "queued") {
    // Past two check-ins, the agent is not calling in: say so plainly
    const mins = row.last_requested ? (Date.now() - new Date(row.last_requested).getTime()) / 60000 : 0;
    if (mins > 2 * CHECKIN_MIN + 2) {
      return h("span", { class: "hd-prog hd-failed" },
        "Not picked up after " + Math.round(mins) + " min: the agent is not checking in. "
        + "On the server: systemctl status patch-agent.timer");
    }
    return h("span", { class: "hd-prog" }, h("span", { class: "hd-pulse" }),
      h("span", null, "Waiting for the agent's next check-in ",
        h("span", { class: "muted" }, "(every " + CHECKIN_MIN + " min; queued " + timeAgo(row.last_requested) + ")")));
  }
  const labels = { picked_up: "Starting", downloading: "Downloading benchmark",
                   uploading: "Uploading results", processing: "Processing results" };
  if (stage === "scanning") {
    const done = Number(row.progress_done || 0), total = Number(row.progress_total || 0);
    const pct = total ? Math.min(100, Math.round(100 * done / total)) : null;
    const bar = h("span", { class: "hd-pbar" }, h("span", { class: "hd-pbar-fill" }));
    bar.firstChild.style.width = (pct === null ? 100 : pct) + "%";
    if (pct === null) bar.classList.add("hd-pbar-indet");
    return h("span", { class: "hd-prog" }, bar,
      h("span", null, "Scanning " + (total ? done + " / " + total + " rules (" + pct + "%)" : done + " rules")));
  }
  if (stage && labels[stage]) {
    const old = stage === "picked_up" && row.agent_version && versionBelow(row.agent_version, "1.5.0");
    return h("span", { class: "hd-prog" }, h("span", { class: "hd-pulse" }),
      h("span", null, old ? "Scanning " : labels[stage] + "\u2026 ",
        old ? h("span", { class: "muted" }, "(agent " + row.agent_version + " does not report progress; 1.5.0 does)") : null));
  }
  return h("span", { class: "hd-prog" }, h("span", { class: "hd-pulse" }), "Scanning\u2026");
}

// Numeric version comparison: "1.10.0" is newer than "1.5.0"
function versionBelow(v, than) {
  const a = String(v || "0").split(".").map(Number), b = String(than).split(".").map(Number);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const x = a[i] || 0, y = b[i] || 0;
    if (x !== y) return x < y;
  }
  return false;
}

function inFlight(row) { return row.last_state === "queued" || row.last_state === "running"; }

function scanState(row) {
  if (inFlight(row)) return scanProgress(row);
  if (row.last_state === "failed") return h("span", { class: "hd-failed", title: row.last_error || "" },
    "last scan failed: " + (row.last_error || "unknown").slice(0, 80));
  return row.finished_at ? timeAgo(row.finished_at) : h("span", { class: "muted" }, "never");
}

function trendSvg(points) {
  if (!points || points.length < 2) return null;
  const W = 260, H = 54, xs = points.map((_, i) => 6 + i * (W - 12) / (points.length - 1));
  // Scaled to the data's own range, padded, so a real improvement is visible
  const vals = points.map(p => Number(p.score));
  const lo = Math.max(0, Math.min(...vals) - 5), hi = Math.min(100, Math.max(...vals) + 5);
  const span = Math.max(1, hi - lo);
  const ys = vals.map(v => H - 6 - ((v - lo) / span) * (H - 12));
  const NS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("viewBox", "0 0 " + W + " " + H); svg.setAttribute("class", "hd-trend");
  svg.setAttribute("role", "img"); svg.setAttribute("aria-label", "Fleet score over the last 90 days");
  const path = document.createElementNS(NS, "path");
  path.setAttribute("d", xs.map((x, i) => (i ? "L" : "M") + x.toFixed(1) + "," + ys[i].toFixed(1)).join(""));
  svg.append(path);
  const dot = document.createElementNS(NS, "circle");
  dot.setAttribute("cx", xs[xs.length - 1]); dot.setAttribute("cy", ys[ys.length - 1]); dot.setAttribute("r", 3);
  svg.append(dot);
  return svg;
}

async function queueScans(level, hostIds, btn, onDone) {
  btn.disabled = true;
  const was = btn.textContent;
  btn.textContent = "Queuing\u2026";
  try {
    const r = await apiPost("/hardening/scans", { level, host_ids: hostIds || null });
    btn.textContent = r.queued.length + " queued" + (r.skipped.length ? ", " + r.skipped.length + " skipped" : "");
    if (r.skipped.length) btn.title = r.skipped.map(x => x.hostname + ": " + x.reason).join("\n");
    setTimeout(() => { btn.textContent = was; btn.disabled = false; onDone && onDone(); }, 2500);
  } catch (err) {
    btn.textContent = was; btn.disabled = false;
    alert(err.message);
  }
}

// ---- fleet page ----------------------------------------------------------
async function renderHardening(params) {
  setNav("hardening");
  const level = hLevel(params);
  const [sum, list] = await Promise.all([api("/hardening/summary?level=" + level), api("/hardening/hosts?level=" + level)]);
  const reload = l => { location.hash = "#/hardening?level=" + l; };
  const scanAll = can("operator")
    ? h("button", { type: "button", class: "btn", on: { click: e => queueScans(level, null, e.target, () => renderHardening(params)) } },
        "Scan all servers") : null;

  const content = sum.content || [];
  const noContent = !content.length;
  const head = h("div", { class: "page-head" },
    h("h1", { "data-cmd": "patchctl harden --report" }, "Hardening"),
    h("div", { class: "head-actions" }, levelPicker(level, reload),
      h("button", { type: "button", class: "btn btn-quiet", on: { click: () => {
        const p = document.querySelector(".rep-panel"); if (p) { p.hidden = !p.hidden; if (!p.hidden) p.scrollIntoView({ block: "nearest" }); }
      } } }, "Export report"), scanAll));

  if (noContent) {
    render(head, h("div", { class: "empty" },
      h("p", null, "No benchmark content has been imported yet."),
      h("p", { class: "muted" }, "On PATCH-01: ./scripts/phase8-hardening.sh --fetch <version>, with the release number from "
        + "the ComplianceAsCode releases page. Then update agents to 1.4.0 and install the OpenSCAP scanner on each server.")));
    return;
  }

  const levelsOf = new Map(content.map(c => [c.product, c.levels || []]));
  const cards = h("div", { class: "hd-cards" },
    h("div", { class: "hd-card hd-card-main" },
      h("div", { class: "hd-card-l" }, "Fleet score"),
      h("div", { class: "hd-card-n" }, sum.fleet_score === null ? "\u2013" : scoreBadge(sum.fleet_score)),
      h("div", { class: "muted small" }, "Average of the latest scan per server: passed rules out of passed plus failed."),
      trendSvg(sum.trend)),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Servers scanned"),
      h("div", { class: "hd-card-n" }, String(sum.scanned), h("span", { class: "muted" }, " / " + sum.servers)),
      sum.no_content ? h("div", { class: "muted small" }, sum.no_content + " have no " + level.toUpperCase() + " content for their OS") : null),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "By score"),
      h("div", { class: "hd-bands" },
        h("span", { class: "hd-good" }, sum.bands.good, h("small", null, "85%+")),
        h("span", { class: "hd-fair" }, sum.bands.fair, h("small", null, "70\u201384%")),
        h("span", { class: "hd-poor" }, sum.bands.poor, h("small", null, "under 70%")))),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Failed checks"),
      h("div", { class: "hd-card-n" }, sum.failed_rules_total),
      h("div", { class: "muted small" }, "across all servers' latest scans")));

  const contentLine = h("p", { class: "muted small" }, "Benchmark: SCAP Security Guide " + content[0].content_version + ". "
    + content.map(c => c.product + " (" + ((c.levels || []).map(x => x.toUpperCase()).join(", ") || "no CIS server profile") + ")").join(", ") + ".");

  const top = sum.top_failing || [];
  const topTable = top.length ? table([
    { label: "Rule", cell: r => h("a", { href: "#/hardening/rule/" + encodeURIComponent(r.rule_id) + "?level=" + level }, r.title || r.rule_id) },
    { label: "CIS", nowrap: true, cell: r => r.cis_ref || h("span", { class: "muted" }, "\u2013") },
    { label: "Severity", nowrap: true, cell: r => sevChip(r.severity) },
    { label: "Servers failing", num: true, cell: r => h("strong", null, r.servers) },
    { label: "", nowrap: true, cell: r => r.risky ? h("span", { class: "hd-risky", title: "Fixing this can cut off access or break services. Test on one server first." }, "risky to fix") : "" },
  ], top) : h("div", { class: "empty" }, h("p", null, "Nothing failing in the latest scans."));

  const hosts = list.hosts || [];
  const hostTable = table([
    { label: "Server", nowrap: true, cell: r => h("a", { href: "#/hardening/host/" + r.id + "?level=" + level }, r.hostname) },
    { label: "Benchmark", nowrap: true, cell: r => {
        if (!r.product) return h("span", { class: "muted" }, "no content for " + r.os_id + " " + r.os_version);
        const lv = levelsOf.get(r.product);
        if (!lv) return h("span", { class: "muted" }, r.product + ": not imported");
        return lv.includes(level) ? r.product : h("span", { class: "muted" }, r.product + ": no " + level.toUpperCase() + " profile");
      } },
    { label: "Score", nowrap: true, cell: r => scoreBar(r.score) },
    { label: "Failed", num: true, cell: r => r.failed === null || r.failed === undefined ? "" :
        h("span", null, r.failed, Number(r.high_failed) ? h("span", { class: "hd-high" }, " (" + r.high_failed + " high)") : null) },
    { label: "Last scan", nowrap: true, cell: r => scanState(r) },
    can("operator") ? { label: "", nowrap: true, cell: r => h("button", { type: "button", class: "btn-link",
        on: { click: e => { e.stopPropagation(); queueScans(level, [r.id], e.target, () => renderHardening(params)); } } }, "Scan") } : null,
  ].filter(Boolean), hosts);

  const exportPanel = reportPanel(level, hosts);
  const archive = h("div");
  loadArchive(archive);
  render(head,
    exportPanel,
    h("p", { class: "muted" }, "How each server's configuration compares with the CIS benchmark: SSH, logins, "
      + "auditing, file permissions, services and kernel settings. Scans are read-only; they change nothing."),
    cards, contentLine,
    h("h2", null, "Most widely failing rules"),
    h("p", { class: "muted small" }, "Fixing one of these lifts every server listed against it."),
    topTable,
    h("h2", null, "Servers (" + hosts.length + ")"),
    hostTable,
    h("h2", null, "Reports"),
    archive);

  // While scans are in flight, redraw every 5 s so progress moves on its own
  if (hosts.some(inFlight)) {
    setPageTimer(async () => {
      if (!location.hash.startsWith("#/hardening") || location.hash.includes("/host/")
          || location.hash.includes("/rule/")) return clearPageTimer();
      const y = window.scrollY;
      await renderHardening(params);
      window.scrollTo(0, y);
    }, 5000);
  } else {
    clearPageTimer();
  }
}

// ---- one server ------------------------------------------------------------
async function renderHardeningHost(hostId, params) {
  setNav("hardening");
  const level = hLevel(params);
  const d = await api("/hardening/hosts/" + hostId + "?level=" + level);
  const s = d.scan;
  let filter = params.get("show") || "fail";
  const body = h("div");
  const counts = { fail: 0, pass: 0, na: 0, error: 0 };
  (d.results || []).forEach(r => {
    if (r.result === "fail") counts.fail++; else if (r.result === "pass") counts.pass++;
    else if (r.result === "error") counts.error++; else counts.na++;
  });
  const tabs = [["fail", "Failed", counts.fail], ["error", "Errors", counts.error], ["pass", "Passed", counts.pass],
                ["na", "Not applicable", counts.na], ["all", "All", (d.results || []).length]];
  const tabBtns = tabs.map(([k, label, n]) => h("button", { type: "button", "data-k": k,
    on: { click: () => { filter = k; paint(); } } }, label + " (" + n + ")"));

  function detail(r) {
    return h("div", { class: "hd-detail" },
      r.description ? h("p", null, r.description) : null,
      r.rationale ? h("p", null, h("strong", null, "Why it matters: "), r.rationale) : null,
      h("p", { class: "muted small" },
        (r.cis_ref ? "CIS " + r.cis_ref + " \u00b7 " : "") + "Rule " + r.rule_id.replace("xccdf_org.ssgproject.content_rule_", "")
        + " \u00b7 " + (r.fix_available ? "an automated fix exists" : "no automated fix; fix by hand")),
      r.risky && r.result === "fail" ? h("p", { class: "hd-risky-note" },
        "Changing this can lock out logins, cut network access or stop services. Test the fix on one server first.") : null);
  }

  function paint() {
    tabBtns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === filter)));
    const rows = (d.results || []).filter(r => filter === "all" || r.result === filter
      || (filter === "na" && !["pass", "fail", "error"].includes(r.result)));
    if (!rows.length) { body.replaceChildren(h("div", { class: "empty" }, h("p", null, "Nothing here."))); return; }
    const t = table([
      { label: "Result", nowrap: true, cell: r => resultChip(r.result) },
      { label: "Rule", cell: r => r.title || r.rule_id },
      { label: "CIS", nowrap: true, cell: r => r.cis_ref || "" },
      { label: "Severity", nowrap: true, cell: r => sevChip(r.severity) },
      { label: "", nowrap: true, cell: r => r.risky && r.result === "fail" ? h("span", { class: "hd-risky" }, "risky to fix") : "" },
    ], rows, { onRow: (r, tr) => {
      const next = tr.nextElementSibling;
      if (next && next.classList.contains("hd-detail-row")) { next.remove(); return; }
      const td = h("td", { colspan: "5" }, detail(r));
      tr.after(h("tr", { class: "hd-detail-row" }, td));
    } });
    body.replaceChildren(h("p", { class: "muted small" }, "Click a rule for what it checks and why."), t);
  }

  const hist = (d.history || []).slice().reverse().filter(x => x.state === "done");
  const live = (d.history || [])[0];
  const liveRow = live && (live.state === "queued" || live.state === "running")
    ? Object.assign({}, live, { last_state: live.state, last_requested: live.requested_at }) : null;
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl harden --host " + d.host.hostname }, d.host.hostname),
      h("div", { class: "head-actions" },
        levelPicker(level, l => { location.hash = "#/hardening/host/" + hostId + "?level=" + l; }),
        can("operator") ? h("button", { type: "button", class: "btn",
          on: { click: e => queueScans(level, [hostId], e.target, () => renderHardeningHost(hostId, params)) } }, "Scan now") : null,
        h("a", { href: "#/hardening?level=" + level }, "All servers"))),
    liveRow ? h("div", { class: "hd-live" }, h("span", { class: "hd-card-l" }, "Scan in progress"), scanProgress(liveRow)) : null,
    s ? h("div", { class: "hd-cards" },
      h("div", { class: "hd-card hd-card-main" }, h("div", { class: "hd-card-l" }, "Score"),
        h("div", { class: "hd-card-n" }, scoreBadge(s.score)),
        h("div", { class: "muted small" }, s.passed + " passed, " + s.failed + " failed, " + s.not_applicable + " not applicable"),
        trendSvg(hist.map(x => ({ score: x.score })))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Scanned"),
        h("div", null, fmtDateTime(s.finished_at)), h("div", { class: "muted small" }, timeAgo(s.finished_at)
          + (s.requested_by ? ", requested by " + s.requested_by : ""))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Benchmark"),
        h("div", null, s.product + " \u00b7 SSG " + s.content_version),
        h("div", { class: "muted small" }, s.profile_id.replace("xccdf_org.ssgproject.content_profile_", "") + ", oscap " + (s.oscap_version || "?"))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Evidence"),
        h("div", { class: "muted small hd-hash", title: "SHA-256 of the full result file kept on PATCH-01" },
          "SHA-256 " + (s.evidence_sha256 || "").slice(0, 16) + "\u2026"),
        h("div", { class: "muted small" }, "Full result file kept for audit.")))
      : h("div", { class: "empty" }, h("p", null, "No completed " + level.toUpperCase() + " scan for this server yet."),
          (d.history || [])[0] && d.history[0].state === "failed" ? h("p", { class: "hd-failed" }, "Last attempt failed: " + d.history[0].error) : null),
    s ? h("div", { class: "filters", role: "group", "aria-label": "Show" }, tabBtns) : null,
    s ? body : null);
  if (s) paint();
  if (liveRow) {
    setPageTimer(async () => {
      if (!location.hash.startsWith("#/hardening/host/" + hostId)) return clearPageTimer();
      const y = window.scrollY;
      await renderHardeningHost(hostId, params);
      window.scrollTo(0, y);
    }, 5000);
  } else if (location.hash.startsWith("#/hardening/host/")) {
    clearPageTimer();
  }
}

// ---- one rule --------------------------------------------------------------
async function renderHardeningRule(ruleId, params) {
  setNav("hardening");
  const level = hLevel(params);
  const d = await api("/hardening/rules/" + encodeURIComponent(ruleId) + "?level=" + level);
  const r = d.rule;
  const failing = d.servers.filter(x => x.result === "fail");
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl harden --rule" }, r.title || r.rule_id),
      h("a", { href: "#/hardening?level=" + level }, "All rules")),
    h("div", { class: "hd-rule-meta" }, sevChip(r.severity), r.cis_ref ? h("span", null, "CIS " + r.cis_ref) : null,
      r.risky ? h("span", { class: "hd-risky" }, "risky to fix") : null,
      h("span", { class: "muted" }, r.fix_available ? "automated fix available" : "fix by hand")),
    r.description ? h("p", null, r.description) : null,
    r.rationale ? h("p", null, h("strong", null, "Why it matters: "), r.rationale) : null,
    r.risky ? h("p", { class: "hd-risky-note" }, "Fixing this can lock out logins, cut network access or stop services. "
      + "Test on one server first.") : null,
    h("h2", null, "Servers (" + failing.length + " failing of " + d.servers.length + ")"),
    d.servers.length ? table([
      { label: "Server", cell: x => h("a", { href: "#/hardening/host/" + x.host_id + "?level=" + level }, x.hostname) },
      { label: "Result", nowrap: true, cell: x => resultChip(x.result) },
      { label: "Benchmark", nowrap: true, cell: x => x.product },
      { label: "Scanned", nowrap: true, cell: x => timeAgo(x.finished_at) },
    ], d.servers) : h("div", { class: "empty" }, h("p", null, "No server's latest scan includes this rule.")));
}

// ---- mail alerts (admin) ---------------------------------------------------
async function renderMail(params) {
  setNav("mail");
  let d = await api("/admin/mail");
  const c = d.settings;
  const f = {};                                   // form fields by name
  const inp = (name, attrs) => (f[name] = h("input", Object.assign({ name }, attrs)));
  const chk = (name, on, label) => h("label", { class: "check" },
    (f[name] = h("input", { type: "checkbox", name, checked: on })), h("span", null, label));
  const field = (label, el, hint) => h("label", null, h("span", null, label), el, hint ? h("span", { class: "muted small" }, hint) : null);

  inp("host", { type: "text", value: c.host || "", placeholder: "smtp-relay.corp.local" });
  inp("port", { type: "number", min: "1", max: "65535", value: String(c.port || 25) });
  f.tls = h("select", { name: "tls" }, [["starttls", "STARTTLS (port 587, or 25)"], ["tls", "TLS from the start (port 465)"],
    ["none", "None (plain internal relay)"]].map(([v, l]) => h("option", { value: v, selected: c.tls === v }, l)));
  inp("username", { type: "text", value: c.user || "", placeholder: "Blank if the relay accepts PATCH-01 by address",
                    autocomplete: "off" });
  inp("password", { type: "password", autocomplete: "new-password",
                    placeholder: c.password_set ? "Saved. Leave blank to keep it" : "Mailbox password" });
  const clearPw = c.password_set ? chk("clear_password", false, "Remove the saved password") : null;
  f.ca_pem = h("textarea", { name: "ca_pem", rows: "5", placeholder: "-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----" },
               c.ca_pem || "");
  inp("from_addr", { type: "text", value: c.from || "", placeholder: "patch01-alerts@corp.example" });
  inp("from_name", { type: "text", value: c.from_name || "", placeholder: "PATCH-01 Alerts" });
  inp("digest_time", { type: "text", value: c.digest_time || "07:00", pattern: "\\d{2}:\\d{2}" });
  f.weekly_day = h("select", { name: "weekly_day" }, ["mon", "tue", "wed", "thu", "fri", "sat", "sun"].map(v =>
    h("option", { value: v, selected: c.weekly_day === v }, v[0].toUpperCase() + v.slice(1))));
  inp("console_url", { type: "text", value: c.console || "", placeholder: "https://SGPINFAPPXU01" });
  inp("company", { type: "text", value: c.company === "PATCH-01" ? "" : (c.company || ""), placeholder: "Your Company Pte Ltd" });

  const values = () => {
    const pw = f.password.value;
    return {
      enabled: f.enabled.checked, host: f.host.value.trim(), port: Number(f.port.value || 25), tls: f.tls.value,
      verify: f.verify.checked, ca_pem: f.ca_pem.value.trim() || null, username: f.username.value.trim(),
      password: pw ? pw : (f.clear_password && f.clear_password.checked ? "" : null),
      from_addr: f.from_addr.value.trim(), from_name: f.from_name.value.trim(),
      send_critical: f.send_critical.checked, send_tasks: f.send_tasks.checked,
      send_digest: f.send_digest.checked, send_weekly: f.send_weekly.checked,
      digest_time: f.digest_time.value.trim(), weekly_day: f.weekly_day.value,
      console_url: f.console_url.value.trim(), company: f.company.value.trim(),
    };
  };

  // Test connection: step by step, with the values in the form, saved or not
  const steps = h("ol", { class: "mail-steps" });
  const checkBtn = h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
    checkBtn.disabled = true; steps.replaceChildren(h("li", { class: "muted" }, "Testing\u2026"));
    try {
      const r = await apiPost("/admin/mail/check", values());
      steps.replaceChildren(...r.steps.map(st => h("li", { class: st.ok ? "ms-ok" : "ms-bad" },
        h("strong", null, st.step), " ", st.detail)));
      if (r.ok) steps.append(h("li", { class: "ms-ok ms-final" }, h("strong", null, "Ready."),
        " The relay accepts mail from PATCH-01. Save, then send a test mail."));
    } catch (e) { steps.replaceChildren(h("li", { class: "ms-bad" }, e.message)); }
    checkBtn.disabled = false;
  } } }, "Test connection");

  const saveMsg = h("span", { class: "small" });
  const saveBtn = h("button", { type: "button", class: "btn", on: { click: async () => {
    saveBtn.disabled = true; saveMsg.className = "muted small"; saveMsg.textContent = "Saving\u2026";
    try {
      d = await apiSend("PUT", "/admin/mail", values());
      saveMsg.className = "hd-good small"; saveMsg.textContent = "Saved.";
      setTimeout(() => renderMail(params), 700);
    } catch (e) { saveMsg.className = "hd-failed"; saveMsg.textContent = e.message; }
    saveBtn.disabled = false;
  } } }, "Save settings");

  // Recipients
  const KINDS = [["critical", "Critical"], ["tasks", "Tasks"], ["digest", "Daily digest"], ["weekly", "Weekly"]];
  const rmsg = h("span", { class: "small" });
  const recTable = () => (d.recipients || []).length ? table([
    { label: "Address", cell: r => h("span", null, h("strong", null, r.address), r.name ? h("span", { class: "muted" }, " \u00b7 " + r.name) : null) },
    ...KINDS.map(([k, label]) => ({ label, nowrap: true, cell: r => {
      const cb = h("input", { type: "checkbox", checked: r[k], "aria-label": label + " for " + r.address });
      cb.addEventListener("change", async () => {
        try { d = await apiSend("PATCH", "/admin/mail/recipients/" + r.id, { [k]: cb.checked }); }
        catch (e) { cb.checked = !cb.checked; rmsg.className = "hd-failed"; rmsg.textContent = e.message; }
      });
      return cb;
    } })),
    { label: "", nowrap: true, cell: r => h("span", { class: "row-actions" },
        h("button", { type: "button", class: "btn-link", on: { click: async e => {
          const b = e.target; b.disabled = true; b.textContent = "Sending\u2026";
          try { await apiPost("/admin/mail/test", { to: r.address }); b.textContent = "Sent \u2713"; }
          catch (err) { b.textContent = "Test"; rmsg.className = "hd-failed"; rmsg.textContent = err.message; }
          setTimeout(() => { b.disabled = false; b.textContent = "Test"; }, 3000);
        } } }, "Test"),
        h("button", { type: "button", class: "btn-link", on: { click: async () => {
          if (!confirm("Stop sending mail to " + r.address + "?")) return;
          try { d = await apiSend("DELETE", "/admin/mail/recipients/" + r.id); showRecipients();
                rmsg.className = "muted small"; rmsg.textContent = r.address + " removed."; }
          catch (err) { rmsg.className = "hd-failed"; rmsg.textContent = err.message; }
        } } }, "Remove")) },
  ], d.recipients) : h("div", { class: "empty" }, h("p", null, "No recipients yet. Add at least one to turn mail on."));
  const recBox = h("div");
  const showRecipients = () => recBox.replaceChildren(recTable());
  const newAddr = h("input", { type: "text", placeholder: "name@corp.example", "aria-label": "New recipient address" });
  const newName = h("input", { type: "text", placeholder: "Name or team (optional)", "aria-label": "New recipient name" });
  const newKinds = KINDS.map(([k, label]) => h("label", { class: "check" }, h("input", { type: "checkbox", checked: true, "data-k": k }), h("span", null, label)));
  const addBtn = h("button", { type: "button", class: "btn", on: { click: async () => {
    const body = { address: newAddr.value.trim(), name: newName.value.trim() };
    newKinds.forEach(l => { const cb = l.querySelector("input"); body[cb.dataset.k] = cb.checked; });
    try {
      d = await apiPost("/admin/mail/recipients", body);
      showRecipients(); newAddr.value = ""; newName.value = ""; rmsg.className = "hd-good small";
      rmsg.textContent = body.address + " added.";
    } catch (e) { rmsg.className = "hd-failed"; rmsg.textContent = e.message; }
  } } }, "Add recipient");

  const w = d.worker;
  const STATE = { sent: ["Sent", "hr-pass"], queued: ["Queued", "hr-na"], failed: ["Failed", "hr-fail"] };
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl mail --setup" }, "Mail alerts"),
      h("span", { class: "muted small" }, c.updated_by ? "Last changed by " + c.updated_by + ", " + timeAgo(c.updated_at) : "")),
    !c.key_present ? h("div", { class: "form-warn" }, h("strong", null, "The mail key is missing. "),
      "A password cannot be saved until phase3b-api.sh has run on PATCH-01.") : null,
    h("div", { class: "form-sec" },
      h("label", { class: "check mail-enable" }, (f.enabled = h("input", { type: "checkbox", name: "enabled", checked: c.enabled })),
        h("span", null, h("strong", null, "Send mail alerts"), h("span", { class: "muted small" },
          c.enabled ? " \u00b7 on" : " \u00b7 off: nothing is sent until this is ticked and saved")))),
    h("div", { class: "form-sec" }, h("h2", null, "1. Relay"),
      h("div", { class: "af-row" }, field("Relay host", f.host), field("Port", f.port), field("Encryption", f.tls)),
      h("div", { class: "af-row" }, field("Login (the mailbox)", f.username), field("Password", f.password,
        "Stored encrypted on PATCH-01; never shown again.")),
      clearPw,
      h("details", { class: "mail-adv", open: !!c.ca_pem || c.verify === false },
        h("summary", null, "Certificate checks"),
        chk("verify", c.verify !== false, "Check the relay's certificate (recommended)"),
        field("CA certificate, if the relay's certificate comes from an internal CA", f.ca_pem,
          "Paste the PEM text. Leave blank for a publicly trusted certificate."))),
    h("div", { class: "form-sec" }, h("h2", null, "2. Sender"),
      h("div", { class: "af-row" }, field("From address (the mailbox)", f.from_addr), field("From name", f.from_name),
        field("Company name in mail", f.company)),
      field("Console address, for links in mail", f.console_url)),
    h("div", { class: "form-actions" }, checkBtn, h("span", { class: "muted small" }, "Uses the values above, saved or not. Sends nothing.")),
    steps,
    h("div", { class: "form-sec" }, h("h2", null, "3. What to send"),
      chk("send_critical", c.critical, "Critical alerts, within a minute"),
      chk("send_tasks", c.tasks, "Task updates: changes started and finished, scans completed"),
      chk("send_digest", c.digest, "Daily digest"),
      chk("send_weekly", c.weekly, "Weekly summary"),
      h("div", { class: "af-row" }, field("Digest time (Singapore, 24-hour)", f.digest_time), field("Weekly summary day", f.weekly_day))),
    h("div", { class: "form-actions" }, saveBtn, saveMsg),
    h("h2", null, "4. Recipients"),
    h("p", { class: "muted small" }, "Choose who gets each kind of mail. Changes apply at once and are recorded in Activity."),
    recBox,
    h("div", { class: "mail-add" }, newAddr, newName, h("span", { class: "mail-kinds" }, newKinds), addBtn),
    rmsg,
    h("h2", null, "Recent mail"),
    h("p", { class: "muted small" }, (d.counts_7d.sent || 0) + " sent, " + (d.counts_7d.queued || 0) + " queued, "
      + (d.counts_7d.failed || 0) + " failed in the last 7 days"
      + (w ? " \u00b7 the worker last checked " + timeAgo(w.beat_at) : "")),
    (d.recent || []).length ? table([
      { label: "When", nowrap: true, cell: n => fmtDateTime(n.created_at) },
      { label: "Kind", nowrap: true, cell: n => ({ critical: "Critical", task: "Task", digest: "Daily digest", weekly: "Weekly",
                                                   system: "System", test: "Test" })[n.category] || n.category },
      { label: "Subject", cell: n => n.subject.replace("[PATCH-01] ", "") },
      { label: "State", nowrap: true, cell: n => { const [l, cls] = STATE[n.state] || [n.state, "hr-na"];
          return h("span", { class: "hd-res " + cls }, l + (n.state === "queued" && n.attempts ? " (retry " + n.attempts + ")" : "")); } },
      { label: "Problem", cell: n => n.last_error ? h("span", { class: "hd-failed" }, n.last_error) : "" },
    ], d.recent) : h("div", { class: "empty" }, h("p", null, "No mail sent yet.")));
  showRecipients();
}


// ---- reports ------------------------------------------------------------------
function fmtBytes(n) { return n >= 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB"; }

async function downloadReport(id, btn) {
  // A link cannot carry the sign-in token, so fetch the file and hand it over
  const was = btn ? btn.textContent : null;
  if (btn) { btn.disabled = true; btn.textContent = "Downloading\u2026"; }
  try {
    const res = await fetch("/api/v1/reports/" + id + "/download", { headers: { ...authHeaders(), "X-Requested-With": "patch01-dashboard" } });
    if (!res.ok) { let d = ""; try { d = detailText((await res.json()).detail); } catch (e) { /* not JSON */ } throw new Error(d || res.statusText); }
    const cd = res.headers.get("Content-Disposition") || "";
    const m = /filename="?([^";]+)"?/.exec(cd);
    const blob = await res.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = m ? m[1] : "report";
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 30000);
  } catch (e) { alert(e.message); }
  if (btn) { btn.disabled = false; btn.textContent = was; }
}

function reportPanel(level, hosts) {
  const groups = [...new Set(hosts.map(x => x.host_group).filter(Boolean))].sort();
  const scope = h("select", { "aria-label": "Report scope" },
    h("option", { value: "all" }, "All servers"),
    ...groups.map(g => h("option", { value: "g:" + g }, "Group: " + g)),
    h("option", { value: "attention" }, "Servers below 85%"));
  const detail = h("select", { "aria-label": "Findings to include" },
    h("option", { value: "high_medium" }, "High and medium findings in detail"),
    h("option", { value: "all" }, "Every finding in detail"),
    h("option", { value: "high" }, "High findings only in detail"));
  const label = h("input", { type: "text", placeholder: "Title for the cover, e.g. Production Linux fleet", maxlength: "80" });
  const out = h("div", { class: "rep-out" });
  const go = fmt => async e => {
    const btn = e.target; btn.disabled = true; const was = btn.textContent; btn.textContent = "Building\u2026";
    out.replaceChildren(h("span", { class: "muted small" }, "Building the report from the latest scans\u2026"));
    const body = { level, format: fmt, detail: detail.value, scope_label: label.value.trim() || null };
    if (scope.value.startsWith("g:")) body.host_group = scope.value.slice(2);
    if (scope.value === "attention") {
      body.host_ids = hosts.filter(x => x.score !== null && Number(x.score) < 85).map(x => x.id);
      body.scope_label = body.scope_label || "Servers below 85%";
      if (!body.host_ids.length) { out.replaceChildren(h("span", { class: "hd-good small" }, "No scanned server is below 85%.")); btn.disabled = false; btn.textContent = was; return; }
    }
    try {
      const r = await apiPost("/reports/hardening", body);
      const dl = h("button", { type: "button", class: "btn", on: { click: ev => downloadReport(r.id, ev.target) } }, "Download " + (fmt === "pdf" ? "PDF" : "Word"));
      out.replaceChildren(h("div", { class: "rep-ready" },
        h("strong", null, r.report_id), " \u00b7 " + r.servers + " server" + (r.servers === 1 ? "" : "s")
          + (r.pages ? " \u00b7 " + r.pages + " pages" : "") + " \u00b7 " + fmtBytes(r.size_bytes), dl,
        h("div", { class: "muted small hd-hash" }, "SHA-256 " + r.sha256)));
      downloadReport(r.id);
      const arch = document.querySelector(".rep-archive"); if (arch) loadArchive(arch.parentNode);
    } catch (err) { out.replaceChildren(h("span", { class: "hd-failed" }, err.message)); }
    btn.disabled = false; btn.textContent = was;
  };
  return h("div", { class: "rep-panel", hidden: true },
    h("div", { class: "rep-row" },
      h("label", null, h("span", null, "Scope"), scope),
      h("label", null, h("span", null, "Findings"), detail),
      h("label", { class: "rep-wide" }, h("span", null, "Cover title (optional)"), label)),
    h("div", { class: "rep-row" },
      h("button", { type: "button", class: "btn", on: { click: go("pdf") } }, "PDF"),
      h("button", { type: "button", class: "btn btn-quiet", on: { click: go("docx") } }, "Word"),
      h("span", { class: "muted small" }, (HLEVELS.find(x => x[0] === level) || [0, level])[1]
        + ", from each server's latest scan. The logo and company details come from Admin \u203a Branding.")),
    out);
}

async function loadArchive(box) {
  try {
    const d = await api("/reports");
    const rows = (d.reports || []).slice(0, 15);
    box.replaceChildren(rows.length ? h("div", { class: "rep-archive" }, table([
      { label: "Report", nowrap: true, cell: r => h("strong", null, "HRD-" + (r.generated_at || "").slice(0, 10).replace(/-/g, "") + "-" + String(r.number).padStart(4, "0")) },
      { label: "Title", cell: r => (r.title || "").replace("CIS Hardening Report, ", "") },
      { label: "Format", nowrap: true, cell: r => r.format === "pdf" ? "PDF" : "Word" },
      { label: "Servers", num: true, cell: r => r.servers },
      { label: "Score", num: true, cell: r => r.score === null ? "\u2013" : Number(r.score).toFixed(1) + "%" },
      { label: "By", nowrap: true, cell: r => r.generated_by },
      { label: "When", nowrap: true, cell: r => timeAgo(r.generated_at) },
      { label: "", nowrap: true, cell: r => h("button", { type: "button", class: "btn-link", on: { click: e => downloadReport(r.id, e.target) } }, "Download") },
    ], rows)) : h("div", { class: "empty rep-archive" }, h("p", null, "No reports yet. Use Export report above.")));
  } catch (e) { box.replaceChildren(h("p", { class: "hd-failed" }, e.message)); }
}

// ---- admin: tabs, branding ------------------------------------------------------
function adminTabs(active) {
  const tabs = [["users", "Users"], ["mail", "Mail"], ["branding", "Branding"]];
  const el = h("div", { class: "filters admin-tabs", role: "group", "aria-label": "Admin" },
    tabs.map(([k, label]) => h("a", { class: "fbtn", href: "#/" + k, "aria-pressed": String(k === active) }, label)));
  const view = document.getElementById("view");
  if (view && !view.querySelector(".admin-tabs")) view.prepend(el);
  document.querySelectorAll("nav a[data-nav]").forEach(a => a.removeAttribute("aria-current"));
  const nav = document.querySelector('nav a[data-nav="admin"]');
  if (nav) nav.setAttribute("aria-current", "page");
}

async function renderBranding(params) {
  setNav("admin");
  const d = await api("/admin/branding");
  const e = d.effective, sv = d.saved || {};
  const m = e.logo_meta;
  const company = h("input", { type: "text", value: sv.company || "", placeholder: "Your Company Pte Ltd", maxlength: "120" });
  const copy = h("input", { type: "text", value: sv.copyright || "", placeholder: e.copyright, maxlength: "200" });
  const CLS = ["CONFIDENTIAL", "INTERNAL", "RESTRICTED", "PUBLIC"];
  const cls = h("select", null, CLS.map(c => h("option", { value: c, selected: (sv.classification || "CONFIDENTIAL") === c }, c)));
  const own = h("input", { type: "checkbox", checked: !!sv.accent });
  const colour = h("input", { type: "color", value: sv.accent || e.accent || "#1F5AA6", disabled: !sv.accent });
  own.addEventListener("change", () => { colour.disabled = !own.checked; });
  const img = h("img", { class: "brand-logo", alt: "Processed logo" });
  const imgW = h("img", { class: "brand-logo brand-dark", alt: "Logo on a dark background" });
  async function loadImg(el, variant) {
    try {
      const res = await fetch("/api/v1/branding/logo?variant=" + variant, { headers: authHeaders() });
      if (res.ok) el.src = URL.createObjectURL(await res.blob()); else el.remove();
    } catch (err) { el.remove(); }
  }
  const msg = h("span", { class: "small" });
  const save = h("button", { type: "button", class: "btn", on: { click: async () => {
    save.disabled = true;
    try {
      await apiSend("PUT", "/admin/branding", { company: company.value.trim(), copyright: copy.value.trim(),
        classification: cls.value, accent: own.checked ? colour.value.toUpperCase() : null });
      msg.className = "hd-good small"; msg.textContent = "Saved. New reports use it at once.";
      setTimeout(() => renderBranding(params), 800);
    } catch (err) { msg.className = "hd-failed"; msg.textContent = err.message; }
    save.disabled = false;
  } } }, "Save");
  const fact = (k, v) => h("div", { class: "brand-fact" }, h("span", { class: "muted small" }, k), h("span", null, v));
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl branding" }, "Branding")),
    h("h2", null, "Logo"),
    m ? h("div", { class: "brand-grid" },
      h("div", { class: "brand-previews" },
        h("div", { class: "brand-light" }, img),
        h("div", { class: "brand-navy" }, e.has_logo_white || !m.dark ? imgW
          : h("div", { class: "brand-plate" }, h("img", { class: "brand-logo", alt: "", src: "" }))),
        h("p", { class: "muted small" }, e.has_logo_white ? "On dark backgrounds: " + e.logo_white_file
          : (m.dark ? "Dark logo: on the navy cover it sits on a white plate so it stays visible."
                    : "Light logo: used directly on dark backgrounds."))),
      h("div", null,
        fact("File", e.logo_file), fact("Original", m.original[0] + " \u00d7 " + m.original[1] + " px, " + fmtBytes(m.bytes_in)),
        fact("As used", m.size[0] + " \u00d7 " + m.size[1] + " px, " + fmtBytes(m.bytes_out) + " (margins trimmed)"),
        fact("Background", m.transparent ? "transparent" : "solid"),
        fact("Main colour", m.accent ? h("span", null, h("span", { class: "brand-swatch", style: null, "data-c": m.accent }), " " + m.accent) : "none found"),
        ...(m.warnings || []).map(w => h("p", { class: "hd-risky-note" }, w))))
      : h("div", { class: "empty" }, h("p", null, e.logo_problem || "No logo yet."),
          h("p", { class: "muted" }, "Copy a PNG to " + d.folder + "/logo.png on PATCH-01. Any size works: PATCH-01 "
            + "trims the margins and scales it. For dark backgrounds you can add logo-white.png as well.")),
    m ? h("p", { class: "muted small" }, "To change it, replace the file in " + d.folder
      + " on PATCH-01. It is picked up the next time a report is made.") : null,
    h("div", { class: "form-sec" }, h("h2", null, "Company"),
      h("label", null, h("span", null, "Company name"), company),
      h("label", null, h("span", null, "Copyright line (footer of every page)"), copy),
      h("label", null, h("span", null, "Classification (header, footer and cover)"), cls),
      h("label", { class: "check" }, own, h("span", null, "Choose the accent colour myself")),
      h("label", null, h("span", null, "Accent colour " + (e.accent_source === "logo" ? "(now taken from the logo: " + e.accent + ")" : "")), colour)),
    h("div", { class: "form-actions" }, save, msg));
  if (m) {
    loadImg(img, "main");
    if (e.has_logo_white || !m.dark) loadImg(imgW, e.has_logo_white ? "white" : "main");
    else loadImg(document.querySelector(".brand-plate img"), "main");
    document.querySelectorAll(".brand-swatch").forEach(x => { x.style.background = x.dataset.c; });
  }
}
