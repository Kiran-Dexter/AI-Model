PATCH-01 agent for Windows Server 1.5.2-win: deployment kit
===========================================================

One folder, one script per server, for new installs and upgrades alike.
Your servers' policy (LocalMachine = Restricted) is never changed.

PREPARE THE FOLDER (once)
-------------------------
  1. Extract this zip. Put your CA chain (.pem, the CA that issued
     PATCH-01's certificate) in the same folder.
  2. Enrolment tokens for NEW servers (upgrades need none):
     - Copying the folder to each server: the script asks you to paste a
       token (hidden while typing). Make them on PATCH-01 with
           ./scripts/phase10-windows.sh --tokens 1 <group>
     - Running from ONE shared folder (\\server\share, readable by
       administrators only): put tokens.txt there, made with
           ./scripts/phase10-windows.sh --tokens 50 <group> > tokens.txt
       Each new server takes the next unused token after you confirm.
       tokens.txt is refused in a local copy (every server would take the
       same token). Delete tokens.txt from the share when done.
  3. Optional, only with a code-signing certificate: run .\Sign-Agent.ps1
     on the PC that holds it (then the agent runs under AllSigned).

ON EACH SERVER (PowerShell as administrator, in the folder)
-----------------------------------------------------------
     Set-ExecutionPolicy RemoteSigned -Scope Process -Force
     Get-ChildItem .\*.ps1 | Unblock-File
     .\Deploy-Agent.ps1

  Line 1 allows scripts in this PowerShell window only (ends when it closes).
  Line 2 removes the "downloaded from the internet" mark from the scripts.

  Deploy-Agent.ps1 checks the server, finds an existing agent (UPGRADE,
  identity kept, no token) or not (NEW), asks for PATCH-01's address once,
  picks up the .pem, shows a summary and changes nothing until you press Y.
  An upgrade waits (up to 10 minutes) for a running agent to finish first.
  At the end it proves the agent works by running its task as SYSTEM.

HOW THE AGENT RUNS ON A "Restricted" SERVER
-------------------------------------------
  The server stays Restricted. Only the agent's own scheduled task gets a
  policy, for its own PowerShell process: AllSigned if signed and trusted,
  otherwise RemoteSigned (the agent file sits in C:\Program Files\PatchAgent,
  owned by Administrators, writable only by SYSTEM and Administrators).

RECORDS
-------
  deploy-log.csv     one line per server: when, action, from/to version, result
  tokens-used.csv    (shared folder only) which server took which token, by
                     fingerprint; a token is given back if enrolment fails
  C:\ProgramData\PatchAgent-Deploy\   the full log of each run on that server

NEW IN 1.5.2: UPDATES ALREADY PUSHED BY WSUS GO FIRST
----------------------------------------------------
With WSUS set to "3 - Auto download and notify for install" (AUOptions=3),
the approved updates are already downloaded and waiting on each server.
The agent now reads that local list first (seconds) when Windows checked
WSUS within the last 24 hours, and installs the job's waiting updates
straight away: no WSUS search, usually no download. Only when nothing for
the job is waiting, or the last check is older than 24 hours, it checks
WSUS once. WSUS approvals still decide what is installed. Keep AUOptions
at 3 (never 4, which would install and restart on Windows' own schedule,
bypassing the snapshot and approvals).

Also in 1.5.2: during a long Windows Update search the agent reports
"still working" every 2 minutes, so a server in the middle of a patch job
is not shown as offline (needs PATCH-01 r70 of 13 Oct, 14:40 or later).

WHAT 1.5.1 FIXES (on top of 1.5.0)
----------------------------------
- A failed Windows Update search could be read as "nothing to install" and
  the job reported success: a failed search now fails (and is retried once
  after restarting Windows Update).
- An empty or damaged state file no longer breaks every later run.
- The log never throws (file locked by antivirus or a log reader), and its
  time stamps no longer depend on the server's regional settings.
- Software inventory survives odd registry values; the 4-hourly missing-
  updates report survives one unreadable update.
- Only https:// is accepted for PATCH-01 (the pin needs TLS).
- A restart already scheduled is not reported as a failure.
- Install/upgrade/uninstall of software: exit codes are never lost; MSI-based
  programs uninstall by product code.
- Installer: upgrades wait for a running agent; the check at the end really
  runs the new agent as SYSTEM; the data folder is owned by Administrators;
  "Windows trusts PATCH-01" is checked for the computer, not the admin; a
  failed upgrade puts the previous address and pin back.

FASTER PATCHING (1.5.x)
-----------------------
- One WSUS search per job (the install reuses the precheck's search).
- High-priority downloads; servicing stack first, then all other updates
  in one Windows Update session (one by one if that fails).
- The check after the restart reads the installed-update list and history.
- The agent checks for work every 2 minutes.

WHAT 1.5.0 FIXED
----------------
- Precheck crash ("cannot convert ... GB free on C: to type System.Double").
- The install never found the job's updates, so nothing was patched.
- "The property 'Sum' cannot be found" when the download folder was empty.
- More than 1 GB free on C: is enough; Windows Update service restarted
  before searching; one failed update does not fail the server; updates
  checked again after the restart; services compared before and after (a
  service that will not start is a warning, not a patch failure).
