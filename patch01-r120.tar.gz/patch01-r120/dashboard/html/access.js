/* Access review (r119): file and folder permissions, application and owning-team tags, reports.
 *
 *   #/access-review                      uploads, and the reports made
 *   #/access-review?ds=<id>&step=...     one upload, step by step: sheets and columns, tags, report
 *   #/access-review?report=<id>          a report: donuts, sorted tables, AI-01's summary, CSV
 *
 * Every figure is counted by PostgreSQL from the rows; AI-01 proposes (columns, tags, which
 * reports fit, a summary) and an admin confirms. Plain DOM, no innerHTML. */
"use strict";

const AR_STATE = { uploading: "Uploading", uploaded: "Waiting to be read", reading: "Reading the file", mapping: "Columns to confirm",
  normalising: "Making the rows plain", ready: "Ready", failed: "Failed" };
const AR_STEPS = [["upload", "Upload"], ["columns", "Sheets & columns"], ["tags", "Applications & teams"], ["report", "Report"]];
const AR_ROLE_HELP = {
  path: "the folder or file the entry is on", identity: "who has the access (user, group, SID)", rights: "what they may do (words, letters or an access mask)",
  access_type: "Allow or Deny (Allow when missing)", inherited: "inherited from the parent or set on the folder itself",
  owner: "the folder's owner", server: "the file server, when the path is a drive path (D:\\\u2026)", share: "the share name, when separate",
  account_type: "user, group or computer: makes \u201cpeople given rights directly\u201d exact",
  application: "the application, when the tool already has it", team: "the owning team, when the tool already has it" };
// Fixed colours: an entity keeps its colour wherever it appears (palette validated for light and dark, legend always shown)
const AR_CAT_CLS = { broad_write: "c-ar8", explicit_user: "c-ar1", orphan: "c-ar7", full_nonadmin: "c-ar2", deny: "c-ar4", broad_read: "c-ar5", can_change: "c-ar2" };
const AR_LEVEL_CLS = { unstated: "c-muted", full: "c-ar8", modify: "c-ar2", write: "c-ar4", read_execute: "c-ar3", read: "c-ar1", list: "c-ar7", special: "c-ar5", none: "c-ar-un" };
const AR_KIND_CLS = { user: "c-ar1", group: "c-ar3", computer: "c-ar7", broad: "c-ar8", admin: "c-ar2", system: "c-muted", orphan: "c-ar5", unknown: "c-ar-un" };
const AR_KIND_TEXT = { user: "Person", group: "Group", computer: "Computer", broad: "Everyone-type group", admin: "Admin group",
  system: "System account", orphan: "Orphaned (SID)", unknown: "Not stated in the file" };
const AR_LEVEL_TEXT = { full: "Full control", modify: "Modify", write: "Write", read_execute: "Read & execute", read: "Read", list: "List folder",
  special: "Special", unstated: "Not stated in the file", none: "None" };
let arTimer = null;
// replaceChildren would write null as the text "null"
const arPut = (el, ...nodes) => el.replaceChildren(...nodes.flat(3).filter(n => n !== null && n !== undefined && n !== false));
let arUpload = null;

const arNum = n => (Number(n) || 0).toLocaleString();
const arPct = (a, b) => b ? Math.round((a / b) * 100) : 0;

function arChip(text, cls) { return h("span", { class: "ar-chip " + (cls || "") }, text); }
function arTile(label, value, cls, note) {
  return h("div", { class: "ar-tile " + (cls || "") }, h("div", { class: "ar-tile-n" }, arNum(value)), h("div", { class: "ar-tile-l" }, label),
    note ? h("div", { class: "ar-tile-x" }, note) : null);
}
function arStop() { clearInterval(arTimer); arTimer = null; }
function arWatch(page, every, fn) {
  arStop();
  arTimer = setInterval(async () => {
    if (!document.body.contains(page)) { arStop(); return; }
    try { await fn(); } catch (e) { if (!(e instanceof StaleRoute)) { /* next time */ } }
  }, every);
}
function arHead(title, sub, ...actions) {
  return h("div", { class: "page-head ar-head" }, h("div", null, h("h1", null, title), sub ? h("p", { class: "muted ar-sub" }, sub) : null),
    actions.length ? h("div", { class: "ar-actions" }, actions) : null);
}

async function renderAccessReview(params) {
  setNav("access-review");
  arStop();
  if (!can("admin")) return render(h("div", { class: "empty" }, h("p", null, "Access review needs the admin role.")));
  const report = params.get("report"), ds = params.get("ds");
  if (report) return arReport(report);
  if (ds) return arDataset(ds, params.get("step"));
  return arHome();
}

/* ---- the start: upload, and what was uploaded -------------------------------------------- */

async function arHome() {
  let d;
  try { d = await api("/admin/access"); }
  catch (e) {
    if (e instanceof StaleRoute) throw e;
    return render(arHead("Access review"), h("div", { class: "empty" }, h("p", null, e.message)));
  }
  const page = h("div", { class: "ar" });
  const draw = d => {
    arPut(page, 
      arHead("Access review", "File and folder permissions: who can open and change what, which application and team each folder belongs to, and what to fix."),
      arHowItWorks(),
      arUploadBox(d),
      h("section", { class: "ar-card" }, h("h2", null, "Uploads"),
        d.items.length ? table([
          { label: "Name", cell: r => h("a", { href: "#/access-review?ds=" + encodeURIComponent(r.id) }, r.name) },
          { label: "File", cell: r => h("span", { class: "mono small" }, r.file_name) },
          { label: "Rows", num: true, cell: r => r.row_count === null ? "" : arNum(r.row_count) },
          { label: "State", cell: r => arChip(AR_STATE[r.state] || r.state, "ar-s-" + r.state) },
          { label: "Reports", num: true, cell: r => String(r.reports || 0) },
          { label: "Uploaded", cell: r => h("span", { title: r.uploaded_at }, timeAgo(r.uploaded_at) + " by " + r.uploaded_by) },
        ], d.items, { onRow: r => { location.hash = "#/access-review?ds=" + encodeURIComponent(r.id); } })
          : h("p", { class: "muted" }, "Nothing uploaded yet.")));
  };
  render(page);
  draw(d);
  arWatch(page, 5000, async () => {
    if (!d.items.some(r => ["uploaded", "reading", "normalising"].includes(r.state)) || arUpload) return;
    d = await api("/admin/access"); draw(d);
  });
}

function arHowItWorks() {
  const steps = [["1", "Upload", "the CSV or Excel workbook your tool exports (NTFS Permissions Reporter, Netwrix, Varonis, ManageEngine, PowerShell Get-Acl\u2026)"],
    ["2", "Sheets & columns", "AI-01 and the rules say what each sheet holds and which column is which; you confirm. Junk characters are cleaned"],
    ["3", "Tags", "AI-01 suggests each folder's application and owning team; you confirm, edit or reject. Kept for the next upload"],
    ["4", "Report", "choose what to report, step by step; charts and tables counted from every row; CSV of every finding"]];
  return h("ol", { class: "ar-how" }, steps.map(s => h("li", null, h("span", { class: "ar-how-n" }, s[0]),
    h("div", null, h("strong", null, s[1]), h("span", { class: "muted" }, " \u2014 " + s[2])))));
}

function arUploadBox(d) {
  const file = h("input", { type: "file", accept: ".csv,.txt,.tsv,.xlsx,.xlsm,.xls,text/csv", "aria-label": "Permissions report (CSV or Excel)" });
  const name = h("input", { type: "text", maxlength: 120, placeholder: "Name (optional), e.g. FS01 November", "aria-label": "Name of the upload" });
  const bar = h("progress", { max: 100, value: 0, hidden: true, class: "ar-bar" });
  const msg = h("p", { class: "small", role: "status", "aria-live": "polite" });
  const cancel = h("button", { type: "button", class: "btn btn-quiet", hidden: true, on: { click: () => { if (arUpload) arUpload.cancel = true; } } }, "Cancel");
  const go = h("button", { type: "button", class: "btn", on: { click: async () => {
    const f = file.files && file.files[0];
    if (!f) { msg.textContent = "Choose the CSV file first."; return; }
    if (f.size > d.max_mb * 1048576) { msg.textContent = "The file is larger than " + d.max_mb + " MB: export it in parts (for example per server)."; return; }
    const me = { cancel: false };
    arUpload = me;
    go.disabled = true; file.disabled = true; cancel.hidden = false; bar.hidden = false; msg.textContent = "";
    try {
      const id = await arSendFile(f, name.value.trim(), me, (done, total) => {
        bar.value = arPct(done, total);
        msg.textContent = "Sent " + (done / 1048576).toFixed(1) + " of " + (total / 1048576).toFixed(1) + " MB (" + arPct(done, total) + "%)";
      });
      location.hash = "#/access-review?ds=" + encodeURIComponent(id);
    } catch (e) {
      msg.textContent = "Upload failed: " + (e.message || e);
    } finally {
      if (arUpload === me) arUpload = null;
      go.disabled = false; file.disabled = false; cancel.hidden = true;
    }
  } } }, "Upload");
  return h("section", { class: "ar-card ar-up" }, h("h2", null, "Upload a permissions report"),
    h("div", { class: "ar-up-row" }, file, name, go, cancel), bar, msg,
    h("p", { class: "muted small" }, "A CSV or an Excel workbook (.xlsx or .xls, every sheet: permissions, drive information, group members). "
      + "CSV: comma, semicolon or tab; UTF-8, UTF-16 or Windows-1252; "
      + "a title above the header is skipped. Up to " + d.max_mb + " MB and " + arNum(d.max_rows) + " rows, sent in 16 MB pieces."));
}

async function arSendFile(file, name, me, progress) {
  const start = await apiPost("/admin/access/uploads", { file_name: file.name, size: file.size, name: name || null });
  const id = start.dataset_id, chunk = start.chunk_bytes || 16777216;
  let off = 0, tries = 0;
  progress(0, file.size);
  while (off < file.size) {
    if (me.cancel) {
      await apiSend("DELETE", "/admin/access/" + encodeURIComponent(id)).catch(() => {});
      throw new Error("cancelled; nothing was kept");
    }
    let res = null, detail = "";
    try {
      res = await fetch("/api/v1/admin/access/uploads/" + encodeURIComponent(id) + "?offset=" + off, {
        method: "PUT", body: file.slice(off, Math.min(file.size, off + chunk)), cache: "no-store",
        headers: { "Content-Type": "application/octet-stream", "X-Requested-With": "patch01-dashboard", ...authHeaders() } });
    } catch (e) { res = null; detail = "the network connection dropped"; }
    if (res && res.ok) { const r = await res.json(); off = r.received; tries = 0; progress(off, file.size); continue; }
    if (res) { try { detail = detailText((await res.json()).detail); } catch (e) { detail = httpReason(res); } }
    if (res && res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
    const m = /expected the bytes from (\d+)/.exec(detail);
    if (res && res.status === 400 && m) { off = Number(m[1]); progress(off, file.size); continue; }   // a piece that did arrive
    const retry = !res || res.status >= 500 || res.status === 408 || res.status === 429;
    if (!retry || ++tries > 4) throw new Error(detail || "the upload stopped");
    await new Promise(r => setTimeout(r, 2000 * tries));
  }
  await apiPost("/admin/access/uploads/" + encodeURIComponent(id) + "/complete", {});
  return id;
}

/* ---- one upload, step by step ------------------------------------------------------------- */

function arStepOf(d, asked) {
  if (d.state !== "ready") return d.headers && ["mapping", "failed", "normalising"].includes(d.state) ? "columns" : "upload";
  if (asked && AR_STEPS.some(s => s[0] === asked)) return asked;
  return "tags";
}

function arStepper(d, cur) {
  const reach = { upload: true, columns: !!d.headers, tags: d.state === "ready", report: d.state === "ready" };
  const idx = AR_STEPS.findIndex(s => s[0] === cur);
  return h("ol", { class: "ar-steps", "aria-label": "Steps" }, AR_STEPS.map(([k, label], i) => {
    const done = i < idx || (k === "upload" && d.headers);
    const inner = [h("span", { class: "ar-step-n" }, done && i !== idx ? "\u2713" : String(i + 1)), h("span", null, label)];
    return h("li", { class: "ar-step" + (i === idx ? " on" : "") + (done ? " done" : "") },
      reach[k] && i !== idx && k !== "upload"
        ? h("a", { href: "#/access-review?ds=" + encodeURIComponent(d.id) + "&step=" + k }, inner)
        : h("span", { "aria-current": i === idx ? "step" : null }, inner));
  }));
}

async function arDataset(id, asked) {
  let d;
  try { d = await api("/admin/access/" + encodeURIComponent(id)); }
  catch (e) {
    if (e instanceof StaleRoute) throw e;
    return render(arHead("Access review"), h("div", { class: "empty" }, h("p", null, e.message),
      h("p", null, h("a", { href: "#/access-review" }, "Back to the uploads"))));
  }
  const page = h("div", { class: "ar" });
  render(page);
  const draw = async () => {
    const step = arStepOf(d, asked);
    const body = step === "upload" ? arWaiting(d) : step === "columns" ? arColumns(d) : step === "tags" ? await arTags(d) : arWizard(d);
    arPut(page, 
      arHead(d.name, d.file_name + " \u00b7 " + (d.row_count !== null ? arNum(d.row_count) + " rows \u00b7 " : "") + "uploaded " + timeAgo(d.uploaded_at) + " by " + d.uploaded_by,
        h("a", { class: "btn btn-quiet", href: "#/access-review" }, "All uploads"),
        h("button", { type: "button", class: "btn btn-quiet ar-del", on: { click: async e => {
          const b = e.currentTarget;
          if (b.dataset.sure !== "1") { b.dataset.sure = "1"; b.textContent = "Click again to remove it and its reports"; return; }
          await apiSend("DELETE", "/admin/access/" + encodeURIComponent(d.id));
          location.hash = "#/access-review";
        } } }, "Remove")),
      arStepper(d, step), body,
      d.reports && d.reports.length ? arReportList(d) : null);
    page._step = step;
  };
  await draw();
  arWatch(page, 4000, async () => {
    const busy = ["uploaded", "reading", "normalising"].includes(d.state) || (d.state === "mapping" && !d.proposal)
      || (d.state === "ready" && !d.advice && page._step === "report")
      || (d.reports || []).some(x => ["queued", "computing"].includes(x.state));
    if (page.querySelector(".ar-tags") && page.querySelector(".ar-tags")._dirty) return;     // never over what an admin is typing
    if (!busy) return;
    const was = d.state;
    d = await api("/admin/access/" + encodeURIComponent(id));
    if (was === "normalising" && d.state === "ready") asked = "tags";        // the rows are ready: on to the tags
    await draw();
  });
}

function arWaiting(d) {
  if (d.state === "failed") {
    return h("section", { class: "ar-card ar-fail", role: "alert" }, h("h2", null, "The file could not be read"), h("p", null, d.error || "Unknown error."),
      h("p", { class: "muted" }, "Check that it is the CSV export (not .xlsx), then upload it again."), h("a", { class: "btn", href: "#/access-review" }, "Upload again"));
  }
  if (d.state === "uploading") {
    return h("section", { class: "ar-card" }, h("h2", null, "The upload was not finished"),
      h("p", null, arNum(d.received) + " of " + arNum(d.size_bytes) + " bytes arrived. Remove it and upload the file again."));
  }
  const p = d.progress || {};
  return h("section", { class: "ar-card ar-wait" },
    hudRing({ pct: null, idle: d.state === "reading" ? "READING" : "QUEUED", title: "READING", sub: p.rows ? arNum(p.rows) + " rows" : "", live: true,
      key: "ar-read-" + d.id, label: "Reading the file" }),
    h("div", null, h("h2", null, d.state === "reading" ? "Reading the file" : "Waiting for the worker"),
      h("p", { class: "muted" }, p.rows ? arNum(p.rows) + " rows read so far." : "The encoding, the separator and the header row are found first."),
      h("p", { class: "muted small" }, "This page follows it; you can leave and come back.")));
}

/* Step 2: which column is which, and how deep folders are tagged */
const AR_SHEET_HELP = {
  permissions: "who has access to which folder, file or drive \u2014 one entry per row",
  drives: "drive letters: where each points (\\\\server\\share), label, owner \u2014 used to turn H:\\\u2026 into the real share",
  members: "a group and its members per row \u2014 used to tell groups from people and to open groups up",
  skip: "a summary, totals or notes: not read" };
const AR_ROLE_HELP2 = {
  drive: "H:, P:\u2026 (or the sheet's name, e.g. \u201cH Drive members\u201d)", target: "\\\\server\\share the letter points to",
  label: "what the drive is for (shown to AI-01 when it suggests applications)", group: "the group", member: "one member of it",
  member_type: "user, group or computer: makes the kinds exact", owner: "who owns the drive (shown to AI-01)" };
const AR_CLEAN_TEXT = { invisible: "invisible characters removed", spaces: "odd spaces made plain", breaks: "line breaks inside a cell made spaces",
  excel_escapes: "Excel escapes (_x000D_) removed", repaired: "garbled text repaired", unreadable: "cells with an unreadable character left as they are" };

// Characters nobody can see, written out: "CORP\\Payroll\u27e8U+200B\u27e9"
function arShowHidden(t) {
  return String(t || "").replace(/[\u0000-\u001f\u007f-\u00a0\u00ad\u061c\u1680\u180e\u2000-\u200f\u2028-\u202f\u205f-\u2064\u2066-\u2069\u3000\ufeff\ufff9-\ufffb]/g,
    ch => "\u27e8U+" + ch.charCodeAt(0).toString(16).toUpperCase().padStart(4, "0") + "\u27e9");
}

function arCleaning(d) {
  const c = d.cleaning || {};
  const counts = c.counts || {};
  const keys = Object.keys(counts).filter(k => counts[k]);
  return h("section", { class: "ar-card ar-clean" }, h("h2", null, keys.length ? "\u2728 Cleaned while reading" : "\u2714 Clean text"),
    h("p", { class: "muted small" }, "Read as " + (d.encoding_text || d.encoding || "?") + (d.delimiter ? ", separator " + (d.delimiter === "tab" ? "tab" : "\u201c" + d.delimiter + "\u201d") : "")
      + ". " + (keys.length ? arNum(c.cells) + " cells were cleaned; nothing else was changed." : "No junk characters found: every cell is as in the file.")),
    keys.length ? h("ul", { class: "ar-clean-l" }, keys.map(k => h("li", null, h("strong", null, arNum(counts[k])), " " + (AR_CLEAN_TEXT[k] || k)))) : null,
    (c.examples || []).length ? h("details", null, h("summary", null, "Examples, before \u2192 after"),
      h("table", { class: "ar-prev-t no-enh" }, h("tbody", null, c.examples.map(e => h("tr", null,
        h("td", { class: "small" }, AR_CLEAN_TEXT[e.kind] || e.kind),
        h("td", { class: "mono small ar-before" }, arShowHidden(e.before)),
        h("td", { class: "mono small" }, e.after)))))) : null);
}

function arColumns(d) {
  if (d.state === "normalising") {
    const p = d.progress || {};
    return h("section", { class: "ar-card ar-wait" },
      hudRing({ pct: p.total ? arPct(p.rows, p.total) : null, idle: "STARTING", title: "ROWS", sub: p.total ? arNum(p.rows) + " / " + arNum(p.total) : "",
        live: true, key: "ar-norm-" + d.id, label: "Making the rows plain" }),
      h("div", null, h("h2", null, "Making the rows plain"),
        h("p", { class: "muted" }, "Drive letters resolved, groups opened up, then each row: server, share, folder, account and its kind, access level, allow or deny, inherited."
          + (p.sheet ? " Sheet \u201c" + p.sheet + "\u201d." : ""))));
  }
  if (d.state === "mapping" && !d.proposal) {
    return h("section", { class: "ar-card ar-wait" },
      hudRing({ pct: null, idle: "AI-01", title: "SHEETS", live: true, key: "ar-map-" + d.id, label: "AI-01 reads the sheets" }),
      h("div", null, h("h2", null, "AI-01 is reading the sheets"), h("p", { class: "muted" }, "What each sheet holds and which column is which, with the rules, from the columns and their values.")));
  }
  const R = d.sheet_roles || {};
  const sheets = (d.sheets || []);
  const state = sheets.map(sh => {
    const p = sh.proposal || { role: "skip", roles: {} };
    const role = sh.role || p.role || "skip";
    const cur = sh.role && sh.mapping ? sh.mapping : Object.fromEntries(Object.entries((p.role === role ? p.roles : {}) || {}).map(([k, v]) => [k, v.col]));
    return { sh, role, mapping: Object.assign({}, cur), p };
  });
  const depth = h("select", { "aria-label": "Tag depth" }, [0, 1, 2, 3, 4].map(n => h("option", { value: String(n) },
    n === 0 ? "The share (or drive) itself" : n + " folder level" + (n > 1 ? "s" : "") + " below the share")));
  depth.value = String(d.tag_depth);
  const prev = h("div", { class: "ar-prev", "aria-live": "polite" });
  const msg = h("p", { class: "small", role: "status" });
  const cfg = () => state.map(x => ({ sheet_no: x.sh.sheet_no, role: x.role, mapping: x.role === "skip" ? {} : x.mapping }));
  let pv = 0;
  const preview = async () => {
    const me = ++pv;
    try {
      const r = await apiPost("/admin/access/" + encodeURIComponent(d.id) + "/preview", { sheets: cfg(), tag_depth: Number(depth.value) });
      if (me !== pv) return;
      arPut(prev, h("table", { class: "ar-prev-t no-enh" }, h("thead", null, h("tr", null, h("th", null, "Depth"), h("th", { class: "num" }, "Folders"), h("th", null, "For example"))),
        h("tbody", null, r.depths.map(x => h("tr", { class: x.depth === Number(depth.value) ? "on" : null },
          h("td", null, String(x.depth)), h("td", { class: "num" }, arNum(x.folders)),
          h("td", { class: "mono small" }, x.examples.slice(0, 3).join("  \u00b7  ")))))),
        h("p", { class: "muted small" }, "From the first " + arNum(r.rows_looked_at) + " rows. Each folder at this depth is tagged with an application and a team; "
          + "everything under it belongs to it."
          + (r.drives_resolved ? " " + arNum(r.drives_resolved) + " drive paths resolved to their share." : "")),
        r.drives_ambiguous && r.drives_ambiguous.length ? h("p", { class: "ar-note" }, "Drive " + r.drives_ambiguous.join(", ")
          + " points to more than one share in the drive sheet: those paths are kept as written (add a server column to the drive sheet to tell them apart).") : null);
      msg.textContent = "";
    } catch (e) { if (me === pv) { arPut(prev); msg.textContent = e.message; } }
  };
  const card = x => {
    const sh = x.sh, box = h("div", { class: "ar-sheet-body" });
    const headers = sh.headers || [];
    const roleSel = h("select", { "aria-label": "What sheet " + sh.name + " holds", disabled: !sh.row_count },
      ["permissions", "drives", "members", "skip"].map(k => h("option", { value: k }, (R[k] || {}).title || k)));
    roleSel.value = x.role;
    const drawBody = () => {
      if (x.role === "skip") { arPut(box, h("p", { class: "muted small" }, AR_SHEET_HELP.skip)); return; }
      const def = R[x.role] || { fields: [], name_roles: [] };
      const props = x.p.role === x.role ? (x.p.roles || {}) : {};
      const rows = def.fields.map(f => {
        const sel = h("select", { "aria-label": f.label + " in " + sh.name }, h("option", { value: "" }, f.required ? "\u2014 choose \u2014" : "(not in the sheet)"),
          headers.map((c, i) => h("option", { value: String(i) }, c)),
          def.name_roles.includes(f.key) ? h("option", { value: String(headers.length) }, "(the sheet's name: " + sh.name + ")") : null);
        sel.value = x.mapping[f.key] !== undefined && x.mapping[f.key] !== null ? String(x.mapping[f.key]) : "";
        sel.addEventListener("change", () => { if (sel.value === "") delete x.mapping[f.key]; else x.mapping[f.key] = Number(sel.value); preview(); });
        const p = props[f.key];
        return h("tr", null,
          h("th", { scope: "row" }, f.label, f.required ? h("span", { class: "ar-req", title: "needed" }, " *") : null,
            h("div", { class: "muted small" }, (x.role === "permissions" ? AR_ROLE_HELP[f.key] : AR_ROLE_HELP2[f.key] || AR_ROLE_HELP[f.key]) || "")),
          h("td", null, sel),
          h("td", { class: "small" }, p ? [arChip(p.by === "AI-01" ? "\u2605 AI-01" : "rules", p.by === "AI-01" ? "ar-ai" : "ar-rule"), " ", p.why] : h("span", { class: "muted" }, "nothing found")));
      });
      const sample = (sh.sample || []).slice(0, 6);
      arPut(box, h("table", { class: "ar-map no-enh" }, h("tbody", null, rows)),
        h("details", { class: "ar-sample-d" }, h("summary", null, "The first rows, as in the sheet"),
          h("div", { class: "table-wrap ar-sample" }, h("table", { class: "no-enh" },
            h("thead", null, h("tr", null, headers.map(c => h("th", null, c)))),
            h("tbody", null, sample.map(r => h("tr", null, headers.map((_, i) => h("td", { class: "small" }, (r[i] || "").slice(0, 80))))))))));
    };
    roleSel.addEventListener("change", () => {
      x.role = roleSel.value;
      x.mapping = x.p.role === x.role ? Object.fromEntries(Object.entries(x.p.roles || {}).map(([k, v]) => [k, v.col])) : {};
      drawBody(); preview();
    });
    drawBody();
    return h("section", { class: "ar-card ar-sheet ar-sheet-" + x.role },
      h("div", { class: "ar-sheet-top" },
        h("div", null, h("h3", null, "\ud83d\udcc4 " + sh.name, sh.hidden ? arChip("hidden sheet", "ar-rule") : null),
          h("div", { class: "muted small" }, sh.row_count ? arNum(sh.row_count) + (sh.row_count === 1 ? " row" : " rows") + " \u00b7 header on line " + sh.header_row + (sh.skipped ? " \u00b7 " + arNum(sh.skipped) + " lines skipped" : "") : "no rows")),
        h("label", { class: "ar-lab" }, "Holds ", roleSel)),
      h("p", { class: "small" }, arChip(x.p.by && x.p.by.includes("AI-01") ? "\u2605 " + x.p.by : "rules", x.p.by && x.p.by.includes("AI-01") ? "ar-ai" : "ar-rule"),
        " " + (SHEET_ROLE_WORD[x.p.role] || "") + (x.p.why ? ": " + x.p.why : "")),
      box);
  };
  depth.addEventListener("change", preview);
  const go = h("button", { type: "button", class: "btn", on: { click: async () => {
    go.disabled = true; msg.textContent = "";
    try {
      await apiSend("PUT", "/admin/access/" + encodeURIComponent(d.id) + "/mapping", { sheets: cfg(), tag_depth: Number(depth.value) });
      location.hash = "#/access-review?ds=" + encodeURIComponent(d.id) + "&step=columns&t=" + Date.now();
    } catch (e) { msg.textContent = e.message; go.disabled = false; }
  } } }, d.state === "ready" ? "Save and read the rows again" : (sheets.length > 1 ? "Confirm the sheets" : "Confirm the columns"));
  setTimeout(preview, 0);
  return h("div", { class: "ar-cols" },
    d.state === "failed" ? h("p", { class: "ar-fail", role: "alert" }, d.error) : null,
    arCleaning(d),
    h("section", { class: "ar-card" }, h("h2", null, sheets.length > 1 ? "What each sheet holds, and which column is which" : "Which column is which"),
      d.proposal && d.proposal.note ? h("p", { class: "ar-note" }, d.proposal.note) : null,
      h("p", { class: "muted small" }, sheets.length > 1 ? arNum(sheets.length) + " sheets. Told from their columns and rows, not from their names: change any choice. "
        + "Drive sheets turn drive letters into the share they point to; members sheets tell groups from people and open groups up." : "")),
    ...state.map(card),
    h("section", { class: "ar-card" }, h("h3", null, "Tag folders at"), h("div", { class: "ar-row" }, depth), prev,
      h("div", { class: "ar-actions" }, go, msg)));
}
const SHEET_ROLE_WORD = { permissions: "permissions", drives: "drive information", members: "group members", skip: "not used" };

/* Step 3: application and owning team of each folder */
async function arTags(d, filter, q) {
  filter = filter || "all";
  const box = h("div", { class: "ar-tags" });
  const load = async () => {
    const qs = new URLSearchParams({ state: filter === "all" ? "" : filter, q: q || "", limit: "500" });
    const t = await api("/admin/access/" + encodeURIComponent(d.id) + "/tags?" + qs);
    arDrawTags(box, d, t, filter, q, (f, s) => { filter = f; q = s; load(); });
    return t;
  };
  const t = await load();
  if (["queued", "running"].includes(t.tag_ai)) {
    const id = setInterval(async () => {
      if (!document.body.contains(box)) { clearInterval(id); return; }
      if (box._dirty) return;                                  // never over what an admin is typing
      try { const n = await load(); if (!["queued", "running"].includes(n.tag_ai)) clearInterval(id); } catch (e) { /* next */ }
    }, 6000);
  }
  return box;
}

function arDrawTags(box, d, t, filter, q, reload) {
  const c = t.counts || {};
  const running = ["queued", "running"].includes(t.tag_ai);
  const msg = h("p", { class: "small", role: "status", "aria-live": "polite" });
  const ask = again => async () => {
    try { await apiPost("/admin/access/" + encodeURIComponent(d.id) + "/tags/ask", { again: !!again }); reload(filter, q); }
    catch (e) { msg.textContent = e.message; }
  };
  const aiBox = h("section", { class: "ar-card ar-aibox" },
    hudRing({ pct: c.folders ? arPct(c.folders - c.not_asked, c.folders) : null, idle: "IDLE", title: "AI-01 TAGS", size: "sm",
      sub: arNum(c.folders - c.not_asked) + " / " + arNum(c.folders), live: running, key: "ar-tag-" + d.id, label: "Folders AI-01 has looked at" }),
    h("div", null, h("h2", null, "\u2605 AI-01 suggests, you confirm"),
      h("p", { class: "muted small" }, "AI-01 reads each folder's name, its sub-folders and the groups on it, and suggests the application and the owning team, "
        + "reusing the names you confirmed before. Nothing counts as confirmed until you confirm it. Confirmed tags are kept for the next upload."),
      t.tag_ai_note ? h("p", { class: "ar-note" }, t.tag_ai_note) : null,
      h("div", { class: "ar-actions" },
        running ? h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
          await apiPost("/admin/access/" + encodeURIComponent(d.id) + "/tags/ask", { stop: true }); reload(filter, q); } } }, "Stop")
          : h("button", { type: "button", class: "btn", on: { click: ask(false) } }, c.not_asked ? "\u2605 Suggest tags with AI-01" : "\u2605 Suggest for new folders"),
        !running && c.suggested ? h("button", { type: "button", class: "btn btn-quiet", on: { click: ask(true) } }, "Ask again for the undecided ones") : null,
        h("a", { class: "btn btn-quiet", href: "#/access-review?ds=" + encodeURIComponent(d.id) + "&step=report" }, "Next: the report \u2192")), msg));
  const tiles = h("div", { class: "ar-tiles" },
    arTile("Folders", c.folders), arTile("Confirmed", c.confirmed, "ar-t-ok"), arTile("Suggested, to decide", c.suggested, "ar-t-ai"),
    arTile("No tag yet", c.untagged, "ar-t-warn"));
  const chips = h("div", { class: "ar-filters", role: "group", "aria-label": "Show" }, [["all", "All"], ["suggested", "To decide"], ["confirmed", "Confirmed"],
    ["untagged", "No tag"], ["inherited", "From a parent"]].map(([k, l]) =>
    h("button", { type: "button", class: "ar-f" + (k === filter ? " on" : ""), "aria-pressed": String(k === filter), on: { click: () => reload(k, q) } }, l)));
  const search = h("input", { type: "search", placeholder: "Search folder, application, team", value: q || "", "aria-label": "Search" });
  search.addEventListener("keydown", e => { if (e.key === "Enter") reload(filter, search.value.trim()); });
  const apps = h("datalist", { id: "ar-apps" }, (t.known_applications || []).map(a => h("option", { value: a })));
  const teams = h("datalist", { id: "ar-teams" }, (t.known_teams || []).map(a => h("option", { value: a })));
  const picked = new Map();
  const bulk = h("div", { class: "ar-bulk" });
  const decide = async items => {
    msg.textContent = "";
    try {
      const r = await apiPost("/admin/access/tags/decide", { items });
      msg.textContent = r.decided + " saved.";
      reload(filter, q);
    } catch (e) { msg.textContent = e.message; }
  };
  const rowsEl = t.items.map(it => {
    const sug = it.own_state === "suggested" && (it.s_application || it.s_team);
    const app = h("input", { type: "text", list: "ar-apps", maxlength: 120, "aria-label": "Application of " + it.label,
      value: (it.own_state === "confirmed" ? it.s_application : sug ? it.s_application : it.application) || "" });
    const team = h("input", { type: "text", list: "ar-teams", maxlength: 120, "aria-label": "Owning team of " + it.label,
      value: (it.own_state === "confirmed" ? it.s_team : sug ? it.s_team : it.team) || "" });
    const tick = h("input", { type: "checkbox", "aria-label": "Select " + it.label });
    const item = () => ({ key: it.key, decision: "confirm", application: app.value.trim() || null, team: team.value.trim() || null, label: it.label });
    tick.addEventListener("change", () => { if (tick.checked) picked.set(it.key, item); else picked.delete(it.key); drawBulk(); });
    tick._it = it; tick._item = item;
    const conf = it.confidence;
    const state = it.own_state === "confirmed" ? arChip("Confirmed", "ar-ok") : sug ? arChip("\u2605 AI-01 " + conf + "%", conf >= 80 ? "ar-ai" : conf >= 50 ? "ar-ai-mid" : "ar-ai-low")
      : it.own_state === "suggested" && it.suggested_by === "file" ? arChip("From the file", "ar-rule")
      : it.tag_key && it.tag_key !== it.key ? arChip("From " + it.tag_key, "ar-rule") : it.own_state === "rejected" ? arChip("Rejected", "ar-no") : arChip("No tag", "ar-none");
    return h("tr", null, h("td", null, tick),
      h("td", null, h("div", { class: "mono small ar-folder" }, it.label),
        h("div", { class: "muted small" }, arNum(it.entries) + " entries \u00b7 " + arNum(it.identities) + " accounts"),
        it.reason && (sug || it.own_state === "confirmed") ? h("div", { class: "small ar-why" }, (it.suggested_by === "file" ? "" : "\u2605 ") + it.reason)
          : it.reason && it.own_state === "suggested" ? h("div", { class: "small muted" }, "AI-01: " + it.reason + " (no suggestion)") : null),
      h("td", null, state), h("td", null, app), h("td", null, team),
      h("td", { class: "nowrap" },
        h("button", { type: "button", class: "btn ar-sm", on: { click: () => decide([item()]) } }, "Confirm"),
        it.own_state && it.own_state !== "rejected" ? h("button", { type: "button", class: "btn btn-quiet ar-sm", title: "Not this application: AI-01 does not suggest it again",
          on: { click: () => decide([{ key: it.key, decision: "reject" }]) } }, "Reject") : null,
        it.own_state ? h("button", { type: "button", class: "btn-link ar-sm", title: "Forget the tag on this folder",
          on: { click: () => decide([{ key: it.key, decision: "clear" }]) } }, "Clear") : null));
  });
  const ticks = () => [...box.querySelectorAll("tbody input[type=checkbox]")];
  function drawBulk() {
    bulk.replaceChildren(
      h("button", { type: "button", class: "btn btn-quiet ar-sm", on: { click: () => {
        ticks().forEach(x => { const ok = x._it.own_state === "suggested" && (x._it.confidence || 0) >= 80 && (x._it.s_application || x._it.s_team);
          x.checked = !!ok; if (ok) picked.set(x._it.key, x._item); else picked.delete(x._it.key); });
        drawBulk(); } } }, "Select AI-01 suggestions of 80% or more"),
      h("button", { type: "button", class: "btn btn-quiet ar-sm", on: { click: () => { ticks().forEach(x => { x.checked = false; }); picked.clear(); drawBulk(); } } }, "Select none"),
      h("button", { type: "button", class: "btn ar-sm", disabled: !picked.size, on: { click: () => decide([...picked.values()].map(f => f())) } },
        "Confirm the " + picked.size + " selected"));
  }
  drawBulk();
  box._dirty = false;
  box.addEventListener("input", () => { box._dirty = true; }, { once: true });
  arPut(box, aiBox, tiles,
    h("section", { class: "ar-card" }, h("div", { class: "ar-tools" }, chips, search), bulk, apps, teams,
      t.items.length ? h("div", { class: "table-wrap" }, h("table", { class: "ar-tag-t no-enh" },
        h("thead", null, h("tr", null, h("th", { scope: "col" }, ""), h("th", { scope: "col" }, "Folder"), h("th", { scope: "col" }, "Tag"),
          h("th", { scope: "col" }, "Application"), h("th", { scope: "col" }, "Owning team"), h("th", { scope: "col" }, ""))),
        h("tbody", null, rowsEl))) : h("p", { class: "muted" }, "No folders here."),
      t.items.length >= 500 ? h("p", { class: "muted small" }, "The 500 biggest folders are shown: search to find the others.") : null));
}

/* Step 4: what to report, asked step by step */
function arWizard(d) {
  const kinds = d.kinds || [];
  const adv = (d.advice && d.advice.items) || [];
  const advBy = Object.fromEntries(adv.map(a => [a.report, a]));
  const st = { step: 0, kind: adv.length ? adv[0].report : "risk", title: "", servers: [], applications: [], teams: [], untagged: true,
    levels: ["full", "modify", "write"], inherited: true, tags: "confirmed" };
  const box = h("section", { class: "ar-card ar-wiz" });
  const prof = d.profile || {};
  const ch = d.choices || { servers: [], applications: [], teams: [] };
  const QS = ["What is the report for?", "Which part of the file?", "What counts as risky?", "Check and make it"];
  const pickList = (items, sel, label) => items.length ? h("div", { class: "ar-pick", role: "group", "aria-label": label },
    items.map(x => { const cb = h("input", { type: "checkbox", checked: sel.includes(x) });
      cb.addEventListener("change", () => { const i = sel.indexOf(x); if (cb.checked && i < 0) sel.push(x); if (!cb.checked && i >= 0) sel.splice(i, 1); });
      return h("label", { class: "ar-pick-i" }, cb, " ", x); })) : h("p", { class: "muted small" }, "None in this file.");
  const draw = () => {
    const nav = h("div", { class: "ar-actions" },
      st.step ? h("button", { type: "button", class: "btn btn-quiet", on: { click: () => { st.step--; draw(); } } }, "\u2190 Back") : null,
      st.step < 3 ? h("button", { type: "button", class: "btn", on: { click: () => { st.step++; draw(); } } }, "Next \u2192") : null);
    let body;
    if (st.step === 0) {
      const order = [...adv.map(a => a.report), ...kinds.map(k => k.key).filter(k => !advBy[k])];
      body = [d.advice ? h("p", { class: "muted small" }, d.advice.by === "AI-01" ? "\u2605 AI-01 read the counts of this file and recommends the first ones."
        : "Recommended from the counts of this file." + (d.advice.note ? " " + d.advice.note : "")) : h("p", { class: "muted small" }, "AI-01 is reading the counts\u2026"),
        h("div", { class: "ar-kinds", role: "radiogroup", "aria-label": QS[0] }, order.map(k => {
          const kd = kinds.find(x => x.key === k); if (!kd) return null;
          const a = advBy[k];
          return h("button", { type: "button", role: "radio", "aria-checked": String(st.kind === k), class: "ar-kind" + (st.kind === k ? " on" : "") + (a ? " rec" : ""),
            on: { click: () => { st.kind = k; draw(); } } },
            h("div", { class: "ar-kind-t" }, a ? h("span", { class: "ar-star", "aria-label": "recommended" }, "\u2605 ") : null, kd.title),
            h("div", { class: "muted small" }, kd.about), a ? h("div", { class: "small ar-kind-why" }, a.why) : null);
        }))];
    } else if (st.step === 1) {
      const untag = h("input", { type: "checkbox", checked: st.untagged });
      untag.addEventListener("change", () => { st.untagged = untag.checked; });
      body = [h("p", { class: "muted small" }, "Leave everything unticked for the whole file."),
        h("h3", null, "Servers"), pickList(ch.servers, st.servers, "Servers"),
        h("h3", null, "Applications"), pickList(ch.applications, st.applications, "Applications"),
        h("h3", null, "Owning teams"), pickList(ch.teams, st.teams, "Teams"),
        h("label", { class: "ar-pick-i" }, untag, " Include folders without an application or team")];
    } else if (st.step === 2) {
      const lv = ["full", "modify", "write", "read_execute", "read"].map(k => {
        const cb = h("input", { type: "checkbox", checked: st.levels.includes(k) });
        cb.addEventListener("change", () => { st.levels = cb.checked ? [...new Set([...st.levels, k])] : st.levels.filter(x => x !== k); });
        return h("label", { class: "ar-pick-i" }, cb, " ", AR_LEVEL_TEXT[k]);
      });
      const inh = h("input", { type: "checkbox", checked: st.inherited });
      inh.addEventListener("change", () => { st.inherited = inh.checked; });
      const tg = h("select", { "aria-label": "Which tags" }, h("option", { value: "confirmed" }, "Confirmed tags only (suggestions count as \u201cNot tagged\u201d)"),
        h("option", { value: "with_suggested" }, "Confirmed and AI-01's suggestions (marked as a draft)"));
      tg.value = st.tags;
      tg.addEventListener("change", () => { st.tags = tg.value; });
      body = [h("h3", null, "Access that counts as risky for Everyone-type groups"), h("div", { class: "ar-pick" }, lv),
        h("p", { class: "muted small" }, "People given rights directly, orphaned accounts, full control outside the admin groups and deny entries are always reported."),
        h("label", { class: "ar-pick-i" }, inh, " Include inherited entries" + (prof.inherit_unknown ? " (" + arNum(prof.inherit_unknown) + " entries do not say)" : "")),
        h("h3", null, "Applications and teams"), tg];
    } else {
      const kd = kinds.find(x => x.key === st.kind) || {};
      const title = h("input", { type: "text", maxlength: 120, value: st.title || kd.title || "", "aria-label": "Title of the report" });
      title.addEventListener("input", () => { st.title = title.value; });
      const msg = h("p", { class: "small", role: "status" });
      const go = h("button", { type: "button", class: "btn", on: { click: async () => {
        if (!st.levels.length) { msg.textContent = "Choose at least one access level that counts as risky."; return; }
        go.disabled = true;
        try {
          const r = await apiPost("/admin/access/" + encodeURIComponent(d.id) + "/reports", { kind: st.kind, title: st.title || null,
            scope: { servers: st.servers, applications: st.applications, teams: st.teams, untagged: st.untagged },
            options: { risky_levels: st.levels, include_inherited: st.inherited, tags: st.tags } });
          location.hash = "#/access-review?report=" + encodeURIComponent(r.id);
        } catch (e) { msg.textContent = e.message; go.disabled = false; }
      } } }, "Make the report");
      const all = a => a.length ? a.join(", ") : "all";
      body = [h("dl", { class: "ar-review" },
        h("dt", null, "Report"), h("dd", null, kd.title || st.kind),
        h("dt", null, "Servers"), h("dd", null, all(st.servers)),
        h("dt", null, "Applications"), h("dd", null, all(st.applications) + (st.untagged ? ", and folders without a tag" : "")),
        h("dt", null, "Teams"), h("dd", null, all(st.teams)),
        h("dt", null, "Risky for Everyone-type groups"), h("dd", null, st.levels.map(x => AR_LEVEL_TEXT[x]).join(", ") || "\u2014"),
        h("dt", null, "Inherited entries"), h("dd", null, st.inherited ? "included" : "left out"),
        h("dt", null, "Tags"), h("dd", null, st.tags === "confirmed" ? "confirmed only" : "confirmed and suggestions (draft)")),
        h("label", { class: "ar-lab" }, "Title ", title), h("div", { class: "ar-actions" }, go, msg),
        h("p", { class: "muted small" }, "Every figure is counted from all " + arNum(prof.entries) + " rows. AI-01 then writes a summary from those figures only.")];
      if (prof.tagged === 0 && st.tags === "confirmed" && ["by_app", "team_review"].includes(st.kind)) {
        body.unshift(h("p", { class: "ar-note" }, "No folder has a confirmed application yet: everything will show as \u201cNot tagged\u201d. Confirm tags first, or include the suggestions."));
      }
    }
    arPut(box, h("div", { class: "ar-wiz-top" }, h("span", { class: "ar-wiz-n" }, "Question " + (st.step + 1) + " of 4"),
      h("div", { class: "ar-wiz-dots", "aria-hidden": "true" }, QS.map((_, i) => h("span", { class: i <= st.step ? "on" : null })))),
      h("h2", null, QS[st.step]), ...[].concat(body).filter(Boolean), nav);
  };
  draw();
  return h("div", null, arProfile(prof), box);
}

function arProfile(p) {
  if (!p || !p.entries) return null;
  return h("div", { class: "ar-tiles" },
    arTile("Entries", p.entries), arTile("Folders tagged", p.tagged, "ar-t-ok", "of " + arNum(p.folders)),
    arTile("Open to everyone (change)", p.broad_write, "ar-t-bad"), arTile("People given rights directly", p.explicit_users, "ar-t-warn"),
    arTile("Orphaned accounts", p.orphans, "ar-t-warn"), arTile("Full control outside admins", p.full_nonadmin, "ar-t-bad"),
    p.drives ? arTile("Drive letters", p.drives, "ar-t-ai", "from the drive sheet") : null,
    p.groups_opened ? arTile("Groups opened up", p.groups_opened, "ar-t-ai", arNum(p.accounts_behind) + " accounts behind them") : null);
}

function arReportList(d) {
  return h("section", { class: "ar-card" }, h("h2", null, "Reports made from this upload"),
    table([{ label: "Report", cell: r => h("a", { href: "#/access-review?report=" + encodeURIComponent(r.id) }, r.title) },
      { label: "Findings", num: true, cell: r => r.findings === null ? (r.state === "failed" ? "failed" : "counting\u2026") : arNum(r.findings) },
      { label: "Made", cell: r => h("span", { title: r.created_at }, timeAgo(r.created_at) + " by " + r.created_by) }], d.reports));
}

/* ---- a report -------------------------------------------------------------------------------- */

// The donut, with its total written as the tiles write numbers (2,558, not 2558)
function arDonut(title, segs, opts = {}) {
  const total = segs.reduce((a, x) => a + (Number(x.value) || 0), 0);
  return donut(title, segs, Object.assign({ centre: arNum(total) }, opts));
}

function arSegs(list, labelKey, valueKey, clsOf) {
  return list.map((x, i) => ({ label: x[labelKey], value: x[valueKey], cls: clsOf(x, i) }));
}
function arNamedCls(s, i) { return s.untagged ? "c-ar-un" : s.other ? "c-muted" : "c-ar" + ((i % 8) + 1); }

async function arReport(id) {
  let r;
  try { r = await api("/admin/access/reports/" + encodeURIComponent(id)); }
  catch (e) {
    if (e instanceof StaleRoute) throw e;
    return render(arHead("Access review"), h("div", { class: "empty" }, h("p", null, e.message)));
  }
  const page = h("div", { class: "ar ar-rep" });
  render(page);
  const draw = () => arPut(page, ...arReportBody(r));
  draw();
  arWatch(page, 4000, async () => {
    if (!["queued", "computing"].includes(r.state) && !(r.state === "ready" && ["queued", "running"].includes(r.summary_state))) return;
    r = await api("/admin/access/reports/" + encodeURIComponent(id));
    draw();
  });
}

function arReportBody(r) {
  const back = h("a", { class: "btn btn-quiet", href: "#/access-review?ds=" + encodeURIComponent(r.dataset_id) + "&step=report" }, "\u2190 Another report");
  const head = arHead(r.title, r.dataset + " (" + r.file_name + ") \u00b7 made " + fmtDateTime(r.created_at) + " by " + r.created_by, back);
  if (r.state === "failed") return [head, h("p", { class: "ar-fail", role: "alert" }, r.error || "The figures could not be counted.")];
  if (r.state !== "ready" || !r.result) {
    return [head, h("section", { class: "ar-card ar-wait" }, hudRing({ pct: null, idle: "COUNTING", title: "REPORT", live: true, key: "ar-rep-" + r.id, label: "Counting" }),
      h("div", null, h("h2", null, "Counting every row"), h("p", { class: "muted" }, "A million rows take a few seconds.")))];
  }
  const res = r.result, k = res.kpis, spec = r.spec || {};
  const msg = h("span", { class: "small", role: "status" });
  const actions = h("div", { class: "ar-actions ar-noprint" },
    h("button", { type: "button", class: "btn", on: { click: async () => {
      msg.textContent = "Preparing the CSV\u2026";
      try { await downloadFile("/admin/access/reports/" + encodeURIComponent(r.id) + "/csv", "access-report.csv"); msg.textContent = ""; }
      catch (e) { msg.textContent = e.message; }
    } } }, "\u2b07 CSV of all " + arNum(res.findings_total) + " findings"),
    r.kind === "effective" ? h("button", { type: "button", class: "btn", on: { click: async () => {
      msg.textContent = "Preparing the CSV\u2026";
      try { await downloadFile("/admin/access/reports/" + encodeURIComponent(r.id) + "/csv?what=people", "access-accounts.csv"); msg.textContent = ""; }
      catch (e) { msg.textContent = e.message; }
    } } }, "\u2b07 CSV of all " + arNum(res.people_total) + " accounts, folder by folder") : null,
    h("button", { type: "button", class: "btn btn-quiet", on: { click: () => window.print() } }, "Print / PDF"), msg);
  const measure = res.measure === "entries" ? "entries" : "findings";
  const cats = Object.entries(res.categories).filter(([, v]) => v.in_report);
  const donuts = h("div", { class: "ar-donuts" },
    !["untagged", "by_server", "effective"].includes(r.kind) ? arDonut("Kinds of risk", cats.map(([key, v]) => ({ label: v.label, value: v.n, cls: AR_CAT_CLS[key] })),
      { centre: arNum(k.findings), centreLabel: "findings", caption: "An entry can be of more than one kind." }) : null,
    arDonut("By application", res.donuts.applications.map((s, i) => ({ label: s.label, value: s.value, cls: arNamedCls(s, i) })),
      { centreLabel: measure, caption: spec.options && spec.options.tags === "with_suggested" ? "Draft: includes AI-01's suggestions." : "Confirmed tags." }),
    arDonut("By owning team", res.donuts.teams.map((s, i) => ({ label: s.label, value: s.value, cls: arNamedCls(s, i) })), { centreLabel: measure }),
    arDonut("Access level", res.levels.map(x => ({ label: x.label, value: x.n, cls: AR_LEVEL_CLS[x.level] })), { centreLabel: "allow entries" }),
    arDonut("Kind of account", res.kinds.map(x => ({ label: x.label, value: x.n, cls: AR_KIND_CLS[x.kind] })), { centreLabel: "entries" }),
    res.donuts.servers.length > 1 ? arDonut("By server and share", res.donuts.servers.map((s, i) => ({ label: s.label, value: s.value, cls: arNamedCls(s, i) })),
      { centreLabel: measure }) : null);
  const sm = r.summary;
  const summary = h("section", { class: "ar-card ar-sum" }, h("h2", null, "\u2605 Summary by AI-01"),
    r.summary_state === "done" && sm ? [h("p", { class: "ar-headline" }, sm.headline),
      sm.points.length ? h("ul", null, sm.points.map(p => h("li", null, p))) : null,
      sm.actions.length ? [h("h3", null, "First actions"), h("ol", null, sm.actions.map(p => h("li", null, p)))] : null,
      h("p", { class: "muted small" }, "Written from the figures below only; any sentence quoting a number that is not in this report was removed.")]
    : ["queued", "running"].includes(r.summary_state) ? h("p", { class: "muted" }, "AI-01 is writing it from the figures\u2026")
    : r.summary_state === "off" ? h("p", { class: "muted" }, "AI-01 is not configured on PATCH-01: the figures below are complete without it.")
    : [h("p", { class: "muted" }, "AI-01 could not write it this time."), h("button", { type: "button", class: "btn btn-quiet ar-noprint", on: { click: async e => {
        e.currentTarget.disabled = true; await apiPost("/admin/access/reports/" + encodeURIComponent(r.id) + "/summary", {});
        location.hash = "#/access-review?report=" + encodeURIComponent(r.id) + "&t=" + Date.now(); } } }, "Ask again")]);
  const why = f => h("div", { class: "ar-whys" }, (f.why || []).map(w => arChip(w, "ar-w")));
  const catCols = cats.map(([key, v]) => ({ label: v.label, num: true, cell: x => x[key] ? h("span", { "data-sort": x[key] }, arNum(x[key])) : h("span", { class: "muted", "data-sort": 0 }, "0") }));
  const groupTable = (title, rows, first) => rows.length ? h("section", { class: "ar-card" }, h("h2", null, title),
    table([{ label: first, cell: x => x.name === "Not tagged" ? h("em", null, "Not tagged") : x.name },
      { label: "Findings", num: true, cell: x => h("strong", { "data-sort": x.findings }, arNum(x.findings)) },
      { label: "Entries", num: true, cell: x => h("span", { "data-sort": x.entries }, arNum(x.entries)) },
      { label: "Folders", num: true, cell: x => h("span", { "data-sort": x.folders }, arNum(x.folders)) },
      { label: "Accounts", num: true, cell: x => h("span", { "data-sort": x.identities }, arNum(x.identities)) }, ...catCols], rows)) : null;
  const sections = [];
  if (["by_app", "team_review", "risk", "untagged"].includes(r.kind)) sections.push(groupTable("By application", res.applications, "Application"), groupTable("By owning team", res.teams, "Owning team"));
  if (r.kind === "by_server") sections.push(groupTable("By server and share", res.servers, "Server \u00b7 share"));
  sections.push(h("section", { class: "ar-card" }, h("h2", null, "Folders, most findings first"),
    table([{ label: "Folder", cell: x => h("span", { class: "mono small" }, x.folder) },
      { label: "Application", cell: x => x.application || h("em", { class: "muted" }, "Not tagged") }, { label: "Team", cell: x => x.team || "" },
      { label: r.kind === "untagged" || r.kind === "by_server" ? "Entries" : "Findings", num: true, cell: x => h("strong", { "data-sort": x[measure] }, arNum(x[measure])) },
      ...catCols], res.folders),
    res.folders.length >= 200 ? h("p", { class: "muted small" }, "The 200 folders with the most findings; the CSV has every finding.") : null));
  if (res.who.length) sections.push(h("section", { class: "ar-card" }, h("h2", null, "Accounts, most findings first"),
    table([{ label: "Account", cell: x => h("span", { class: "mono small" }, x.identity) }, { label: "Kind", cell: x => arChip(AR_KIND_TEXT[x.identity_kind] || x.identity_kind, "ar-k " + AR_KIND_CLS[x.identity_kind]) },
      { label: "Highest access", cell: x => AR_LEVEL_TEXT[x.worst] || x.worst },
      { label: "Findings", num: true, cell: x => h("strong", { "data-sort": x.findings }, arNum(x.findings)) },
      { label: "Folders", num: true, cell: x => h("span", { "data-sort": x.folders }, arNum(x.folders)) },
      res.has_members ? { label: "Accounts behind it", num: true, cell: x => x.behind ? h("span", { "data-sort": x.behind }, arNum(x.behind))
        : h("span", { class: "muted", "data-sort": -1 }, x.identity_kind === "broad" ? "everyone" : "\u2014") } : null].filter(Boolean), res.who)));
  if (r.kind === "effective") sections.unshift(h("section", { class: "ar-card" },
    h("h2", null, "Who really can change data" + (res.people_total > res.people.length ? " (first " + arNum(res.people.length) + " of " + arNum(res.people_total) + ")" : "")),
    h("p", { class: "muted small" }, "Every account with write access or more (admin and system accounts left out), given directly or through a group: "
      + "groups the members sheet lists are opened up, nested groups too. Everyone-type groups are not opened: they mean everyone."),
    res.people.length ? table([{ label: "Account", cell: x => h("span", { class: "mono small" }, x.account) },
      { label: "Kind", cell: x => arChip(AR_KIND_TEXT[x.kind] || x.kind, "ar-k " + (AR_KIND_CLS[x.kind] || "")) },
      { label: "How", cell: x => [x.direct ? arChip("directly", "ar-rule") : null, ...(x.through || []).map(g => h("div", { class: "mono small" }, "via " + g))] },
      { label: "Folders", num: true, cell: x => h("strong", { "data-sort": x.folders }, arNum(x.folders)) },
      { label: "Applications", num: true, cell: x => h("span", { "data-sort": x.applications }, arNum(x.applications)) },
      { label: "Highest access", cell: x => AR_LEVEL_TEXT[x.worst] || x.worst }], res.people)
      : h("p", { class: "muted" }, "Nobody outside the admin groups can change data in scope.")));
  (res.team_sections || []).forEach(t => sections.push(h("section", { class: "ar-card ar-team" },
    h("h2", null, "Review pack: " + t.team), h("p", { class: "muted small" }, "Every account (other than admin and system accounts) that can write or more on the team's folders. Keep or remove each one."),
    t.rows.length ? table([{ label: "Folder", cell: x => h("span", { class: "mono small" }, x.folder) }, { label: "Account", cell: x => [h("span", { class: "mono small" }, x.identity),
        x.members ? h("details", { class: "ar-mem" }, h("summary", { class: "small" }, arNum(x.members.n) + " account" + (x.members.n === 1 ? "" : "s") + " in it"),
          h("div", { class: "mono small" }, x.members.names.join(", ") + (x.members.n > x.members.names.length ? ", \u2026" : ""))) : null] },
      { label: "Kind", cell: x => AR_KIND_TEXT[x.kind] || x.kind }, { label: "Access", cell: x => AR_LEVEL_TEXT[x.level] || x.level },
      { label: "Risky", cell: x => x.risky ? arChip("Yes", "ar-w") : "" }, { label: "Keep / remove", cell: () => h("span", { class: "ar-box" }, "\u2610 keep   \u2610 remove") }], t.rows)
      : h("p", { class: "muted" }, "Nothing with write access or more."))));
  sections.push(h("section", { class: "ar-card" }, h("h2", null, "Findings" + (res.findings_total > res.findings.length ? " (first " + arNum(res.findings.length) + " of " + arNum(res.findings_total) + ")" : "")),
    res.findings.length ? table([{ label: "Path", cell: x => h("span", { class: "mono small" }, x.path) }, { label: "Account", cell: x => h("span", { class: "mono small" }, x.identity) },
      { label: "Kind", cell: x => AR_KIND_TEXT[x.identity_kind] || x.identity_kind }, { label: "Access", cell: x => (x.allow ? "" : "Deny ") + (AR_LEVEL_TEXT[x.level] || x.level) },
      { label: "Inherited", cell: x => x.inherited === null ? "?" : x.inherited ? "Yes" : "No" }, { label: "Application", cell: x => x.application || "" },
      { label: "Why", cell: why }], res.findings) : h("p", { class: "muted" }, "No findings: nothing in scope matches this report.")));
  const scope = spec.scope || {};
  const caveats = [k.kind_unknown ? arNum(k.kind_unknown) + " entries do not say whether the account is a person or a group (no account type column): those people are not counted as \u201cgiven rights directly\u201d." : null,
    k.inherit_unknown ? arNum(k.inherit_unknown) + " entries do not say whether they are inherited." : null].filter(Boolean);
  return [head, actions,
    h("div", { class: "ar-tiles" }, arTile("Entries in scope", k.entries), arTile("Folders", k.folders), arTile("Accounts", k.identities),
      arTile(r.kind === "untagged" ? "Entries without a tag" : "Findings", k.findings, "ar-t-bad", arPct(k.findings, k.entries) + "% of the entries"),
      arTile("Folders with findings", k.folders_with, "ar-t-warn"), arTile("Applications", k.applications), arTile("Teams", k.teams),
      k.accounts_behind !== undefined ? arTile("Accounts behind the groups", k.accounts_behind, "ar-t-ai", "from the members sheet") : null,
      r.kind === "effective" ? arTile("Accounts that can change data", res.people_total, "ar-t-bad", "directly or through groups") : null),
    h("p", { class: "muted small" }, "Scope: " + ["servers " + ((scope.servers || []).join(", ") || "all"), "applications " + ((scope.applications || []).join(", ") || "all"),
      "teams " + ((scope.teams || []).join(", ") || "all")].join(" \u00b7 ") + (scope.untagged === false ? " \u00b7 tagged folders only" : "")
      + " \u00b7 risky for Everyone-type groups: " + ((spec.options || {}).risky_levels || []).map(x => AR_LEVEL_TEXT[x]).join(", ")
      + ((spec.options || {}).include_inherited === false ? " \u00b7 inherited entries left out" : "")),
    caveats.length ? h("ul", { class: "ar-caveats" }, caveats.map(c => h("li", null, c))) : null,
    summary, donuts, ...sections.filter(Boolean)];
}
