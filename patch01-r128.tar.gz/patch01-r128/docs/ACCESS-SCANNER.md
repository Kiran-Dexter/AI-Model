# Access scanner: file and folder permissions straight from the file server

`access-scan.ps1` runs **on the file servers you choose** (not on every server). It reads the
shares, every folder's permissions and, from Active Directory, each group's members and each
person's department. Its file has exact columns, so PATCH-01 imports it with nothing to map, and
it goes straight to the Owners & departments step of Access review.

It only reads. Nothing on the server is changed.

## 1. Put it on a file server

Copy `agent\windows\access-scan.ps1` from the package to `C:\Program Files\PatchAgent\` (next
to `patch-agent.ps1`). If your agents run AllSigned, sign it the same way as the agent
(`Sign-Agent.ps1` signs every `.ps1` in its folder).

## 2. Check it (as an administrator, on that server)

```
& "C:\Program Files\PatchAgent\access-scan.ps1" -SelfTest
```

It builds a small folder tree with known permissions, scans it, reads the file back, checks
PATCH-01 answers with the agent's pin and token, and removes the tree. Every step must say `ok`.

## 3. Tell PATCH-01

```
& "C:\Program Files\PatchAgent\access-scan.ps1" -Register
```

The server now shows in **Access review › File-server scanners**.

## 4. Scan

Pick whichever way suits you:

| How | What to do |
|---|---|
| From PATCH-01 | **Scan now** on the server's row. Needs agent **1.10.0-win** on that server (Admin › Agent updates, choose only the file servers). |
| On the server | `access-scan.ps1 -Upload` (every share), or `-Shares Finance,HR -Upload`, or `-Paths D:\Data -Upload` for folders that are not shared; `-Full` sends everything again |
| On a schedule | Task Scheduler, as SYSTEM: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Program Files\PatchAgent\access-scan.ps1" -Upload` |
| No network to PATCH-01 | Run it without `-Upload` and upload `C:\ProgramData\PatchAgent\access-scan\access-scan-<server>-<time>.ndjson.gz` in Access review |

In **Scan now** you tick the shares to scan (the list is every share the server has, from its last scan or
`-Register`), how many levels to list in full, and whether this scan is full.

## Only the changes after the first scan (scanner 1.1.0)

- The **first** scan of a server is **full**.
- After that, the scanner still reads every folder on the server, but sends **only the folders whose
  permissions or owner changed, the new ones, and the ones removed**. PATCH-01 adds them to the complete
  picture it keeps of the server, so every upload and every report is complete, row for row the same as a
  full scan.
- A scan is full again by itself when the shares or levels change, or when a scan in between failed.
  Ask for one with **Full scan** in Scan now, or `-Full` on the server.
- `C:\ProgramData\PatchAgent\access-scan\state.tsv.gz` keeps what was sent last (folder paths and
  checksums, nothing else). Deleting it makes the next scan full.

## Stopping a scan

- **On the server:** Ctrl+C, or closing the window. The scanner tells PATCH-01 as it stops, and the scan shows
  **Stopped** at once. Nothing of a half-sent file is kept.
- **From PATCH-01:** **Stop** on the scan's row. It shows Stopped at once; the scanner stops within 30 seconds
  and PATCH-01 takes no more of its file.
- If the scanner is killed (Task Manager, a restart), it cannot say so: the scan shows stopped after
  **20 minutes** with no word (a running scan reports every 30 seconds), and never blocks a new scan after that.

## The system drive is left out (scanner 1.2.0)

- Shares and folders on the server's system drive (`C:`) are not scanned, and they are not listed in
  Scan now's share picker. `-IncludeSystemDrive` on the server reads them.
- A file from an older scanner, or a report from another tool, has its `C:\` and `C$` folders left out
  when PATCH-01 imports it. The upload says how many were left out.

## Last year's mapping workbook

In **Owners & departments**, upload the workbook you mapped last time (xlsx, xls or csv, every sheet).

1. Every sheet is read. For each column PATCH-01 says what it holds: folder path, server, share, folder
   below the share, folder on the server's disk, business owner, owner's e-mail, department, team or
   application. It also says **why**: the column's name, or what its values are. AI-01 is asked only about
   the columns left over, and only where the values agree. **You confirm the columns.**
2. Sheets are linked only where one sheet's values are found in a column of another sheet that holds each
   value once, for example *App ID*. The numbers are shown: "2 of 3 values found".
3. Each row is matched to this scan's folders, **exactly**: the path, the server and share, or the folder on
   the server's disk through its share. The owner is matched to an account by account name, e-mail or
   display name ("Smith, John" too), exactly. A name no account has is kept as written, below the
   bulk-accept line. Admin, system and Everyone-type accounts are never the owner.
4. Every row gets its outcome:
   - matched;
   - no such folder now;
   - ambiguous (the same share name on two servers);
   - below the folders being tagged;
   - nothing to use;
   - used through a linked sheet.

   Two rows giving different owners for one folder are a **conflict**: that field is not used, and both
   are shown. A CSV has every row.
5. **Use it** turns the matches into suggestions, with the sheet and row as evidence. Accept them in bulk as
   usual. Confirmed and rejected tags are never changed.

## Big servers

- Files are never read. A row is one folder × one account on it.
- By default (`-Depth 1`), the share and its first folders are listed in full. Below that, only the folders
  whose permissions change are listed, down to `-MaxDepth` (16). A folder that only inherits is the same as
  the folder above it, so it is not repeated. This keeps a server with millions of folders to a few hundred
  thousand rows.
- One scan can hold up to 10 million permission entries (people and group members do not count).

## What is read

- **Shares**: their folders, descriptions and share permissions. `C$`, `ADMIN$`, `IPC$` and `print$` are left out.
- **Folders**:
  - every folder down to `-Depth` levels (1 by default);
  - below that, only the folders whose permissions change (they add entries of their own, or stop inheriting), down to `-MaxDepth` (16);
  - files are not read;
  - junctions and links are not followed;
  - a share inside another share is scanned once, under its own name.
- **Accounts**: users, groups, computers, Everyone-type groups and orphaned SIDs. Names are always told by SID, so a German or French server is read the same way.
- **From Active Directory**:
  - members of each group, with nested groups opened up. Everyone-type groups such as Domain Users are not opened.
  - each person's department, title, manager, office, e-mail, whether the account is enabled, and their last logon (lastLogonTimestamp).

Folders the scanner cannot read are listed in the upload as "could not be read", never skipped silently.

## Files and logs on the server

- `C:\ProgramData\PatchAgent\access-scan\` holds the scan files and `access-scan.log`.
- Only one scan runs at a time.

## Owners & departments (r124)

Folders only: files are not read. Right after the import, every folder gets a suggestion:

| Owner (first that applies) | Confidence |
|---|---|
| The NTFS owner, when it is a person whose account is enabled | 85 (90 if they can also change it) |
| The only group given Modify or Full control on the folder directly | 80 (70 if people are also given rights directly) |
| The only person given change rights on the folder directly | 75 |
| The NTFS owner, when that account is disabled | 40 (never bulk-accepted) |
| Several groups or people, no single one | no owner: AI-01 looks |

**Department:** the owner's department; else the department of most (60% or more) of the enabled people who can change the folder, groups opened up.
Admin, system and Everyone-type accounts are never owners.

**AI-01:** after the import, AI-01 checks by itself the folders below 80% and the folders with no suggestion.
- It sees the NTFS owner, who has change rights directly, the departments with their numbers, and what the rules found.
- An owner it names must be in that folder's evidence, and a department must be in the file or in a confirmed tag. Anything else is dropped and said so.

**You decide:**
- **Accept all of 80% or more** confirms the sure suggestions in one click.
- You can edit any owner, department, team or application, then confirm.
- Confirmed owners stay for the next scan.
- A sub-folder whose evidence shows a different owner from its confirmed parent gets its own suggestion.

**Reports:**
- **Permissions & ownership:** one row per folder, with these columns:
  - NTFS owner
  - owner and whether it is a person or a group
  - department, team and application
  - who has access, and whether it was given on the folder or inherited
  - whether Everyone-type groups can get in

  It has a CSV with every folder.
- **By department & owner:** each department, its owners and their folders, with what is risky. The folders without an owner or department come last.
