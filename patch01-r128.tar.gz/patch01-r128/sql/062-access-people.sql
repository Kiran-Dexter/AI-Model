-- ---------------------------------------------------------------------------
-- PATCH-01 : schema 062 - Access review: people and their departments (r122)
--
-- perm_people   one row per person a "people" sheet (or a members sheet with a department
--               column) lists: department, title, manager, location, e-mail
-- perm_sheets   the role 'people' is allowed
-- Re-run safe; no constraint is narrowed.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS perm_people (
    dataset_id   UUID NOT NULL REFERENCES perm_datasets(id) ON DELETE CASCADE,
    person_key   TEXT NOT NULL,          -- short name in lower case, as perm_entries.identity_key
    person       TEXT NOT NULL,          -- as written in the sheet
    display_name TEXT,
    department   TEXT,
    title        TEXT,
    manager      TEXT,
    location     TEXT,
    email        TEXT,
    sources      INT NOT NULL DEFAULT 1, -- rows that named this person
    conflicts    TEXT,                   -- other departments other rows gave, when they disagree
    PRIMARY KEY (dataset_id, person_key)
);
CREATE INDEX IF NOT EXISTS perm_people_dept ON perm_people (dataset_id, lower(department));

ALTER TABLE perm_sheets DROP CONSTRAINT IF EXISTS perm_sheets_role_check;
ALTER TABLE perm_sheets ADD CONSTRAINT perm_sheets_role_check
    CHECK (role IS NULL OR role IN ('permissions', 'drives', 'members', 'people', 'skip'));

INSERT INTO schema_version (version, description)
VALUES (62, 'Access review: people and their departments')
ON CONFLICT (version) DO NOTHING;
