-- ---------------------------------------------------------------------------
-- PATCH-01 : schema 061 - Access review: Excel workbooks with several sheets,
--            drive information and group members (r120)
--
-- perm_sheets    every sheet of an upload (a CSV is one sheet): its header, sample, and the role
--                an admin confirmed: permissions / drives / members / skip
-- perm_drives    drive letters as a "drive information" sheet lists them: where each points,
--                its label, owner, application, team
-- perm_members   group members as a sheet lists them (with the drive, when the sheet says)
-- perm_access    the people behind each group, nested groups opened up
-- perm_entries   + sheet_no, the path as written in the file, the account's short key
-- Re-run safe; no constraint is narrowed.
-- ---------------------------------------------------------------------------

ALTER TABLE perm_raw ADD COLUMN IF NOT EXISTS sheet_no INT NOT NULL DEFAULT 0;

ALTER TABLE perm_datasets ADD COLUMN IF NOT EXISTS file_type TEXT;          -- csv / xlsx / xls / html
ALTER TABLE perm_datasets ADD COLUMN IF NOT EXISTS cleaning JSONB;          -- what was cleaned while reading
ALTER TABLE perm_datasets ADD COLUMN IF NOT EXISTS links JSONB;             -- drives resolved, members used

CREATE TABLE IF NOT EXISTS perm_sheets (
    dataset_id   UUID NOT NULL REFERENCES perm_datasets(id) ON DELETE CASCADE,
    sheet_no     INT NOT NULL,
    name         TEXT NOT NULL,
    hidden       BOOLEAN NOT NULL DEFAULT false,
    header_row   INT,
    headers      TEXT[],
    row_count    INT NOT NULL DEFAULT 0,
    skipped      INT NOT NULL DEFAULT 0,
    sample       JSONB,
    proposal     JSONB,                  -- role and columns proposed by the rules and AI-01, with why
    role         TEXT CHECK (role IS NULL OR role IN ('permissions', 'drives', 'members', 'skip')),
    mapping      JSONB,                  -- the columns an admin confirmed for the role
    PRIMARY KEY (dataset_id, sheet_no)
);

CREATE TABLE IF NOT EXISTS perm_drives (
    dataset_id   UUID NOT NULL REFERENCES perm_datasets(id) ON DELETE CASCADE,
    sheet_no     INT NOT NULL,
    rn           INT NOT NULL,
    drive        TEXT NOT NULL,          -- "H:"
    server       TEXT,
    target       TEXT,                   -- \\server\share\... it points to, as written
    target_key   TEXT,                   -- the folder key of the target (lower case)
    label        TEXT,
    owner        TEXT,
    application  TEXT,
    team         TEXT,
    PRIMARY KEY (dataset_id, sheet_no, rn)
);

CREATE TABLE IF NOT EXISTS perm_members (
    dataset_id   UUID NOT NULL REFERENCES perm_datasets(id) ON DELETE CASCADE,
    sheet_no     INT NOT NULL,
    rn           INT NOT NULL,
    group_name   TEXT NOT NULL,
    group_key    TEXT NOT NULL,          -- short name in lower case (CORP\GG_X and gg_x@corp.com are one)
    member       TEXT NOT NULL,
    member_key   TEXT NOT NULL,
    member_kind  TEXT NOT NULL,
    drive        TEXT,
    PRIMARY KEY (dataset_id, sheet_no, rn)
);
CREATE INDEX IF NOT EXISTS perm_members_group ON perm_members (dataset_id, group_key);

CREATE TABLE IF NOT EXISTS perm_access (
    dataset_id   UUID NOT NULL REFERENCES perm_datasets(id) ON DELETE CASCADE,
    group_key    TEXT NOT NULL,
    member       TEXT NOT NULL,
    member_key   TEXT NOT NULL,
    member_kind  TEXT NOT NULL,
    via          TEXT,                   -- the nested groups on the way, when not direct
    PRIMARY KEY (dataset_id, group_key, member_key)
);

ALTER TABLE perm_entries ADD COLUMN IF NOT EXISTS sheet_no INT;
ALTER TABLE perm_entries ADD COLUMN IF NOT EXISTS path_raw TEXT;
ALTER TABLE perm_entries ADD COLUMN IF NOT EXISTS identity_key TEXT;
CREATE INDEX IF NOT EXISTS perm_entries_ikey ON perm_entries (dataset_id, identity_key);

-- wider: the kind of an account told by the members sheet; an access level the sheet does not state
ALTER TABLE perm_entries DROP CONSTRAINT IF EXISTS perm_entries_kind_source_check;
ALTER TABLE perm_entries ADD CONSTRAINT perm_entries_kind_source_check
    CHECK (kind_source IN ('column', 'rule', 'name', 'members'));
ALTER TABLE perm_entries DROP CONSTRAINT IF EXISTS perm_entries_level_check;
ALTER TABLE perm_entries ADD CONSTRAINT perm_entries_level_check
    CHECK (level IN ('full', 'modify', 'write', 'read_execute', 'read', 'list', 'special', 'unstated', 'none'));

-- uploads read by r119 (one CSV each): their one sheet, and the accounts' short keys
INSERT INTO perm_sheets (dataset_id, sheet_no, name, header_row, headers, row_count, skipped, sample, proposal, role, mapping)
SELECT d.id, 0, d.file_name, d.header_row, d.headers, coalesce(d.row_count, 0), 0, d.sample,
       CASE WHEN d.proposal IS NOT NULL THEN jsonb_build_object('role', 'permissions', 'by', 'rules', 'why', 'the one table of the CSV',
                                                                'roles', coalesce(d.proposal->'roles', '{}'::jsonb)) END,
       CASE WHEN d.mapping IS NOT NULL THEN 'permissions' END, d.mapping
  FROM perm_datasets d
 WHERE d.headers IS NOT NULL AND NOT EXISTS (SELECT 1 FROM perm_sheets s WHERE s.dataset_id = d.id);
UPDATE perm_raw SET sheet_no = 0 WHERE sheet_no IS NULL;
UPDATE perm_entries SET identity_key = left(split_part(regexp_replace(lower(btrim(identity, ' "')), '^.*\\', ''), '@', 1), 300)
 WHERE identity_key IS NULL;
UPDATE perm_datasets SET file_type = 'csv' WHERE file_type IS NULL AND headers IS NOT NULL;

INSERT INTO schema_version (version, description)
VALUES (61, 'Access review: Excel sheets, drive information, group members')
ON CONFLICT (version) DO NOTHING;
