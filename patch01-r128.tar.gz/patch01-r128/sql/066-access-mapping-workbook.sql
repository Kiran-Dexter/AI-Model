-- ---------------------------------------------------------------------------
-- 066 (r127) Access review: last year's mapping workbook
--
-- An admin uploads the workbook used last time (xlsx, xls or csv; every sheet: share info, ownership,
-- departments, ...). PATCH-01 reads every sheet, says what each column holds and why (the rules, then AI-01
-- for the columns the rules cannot place), joins sheets only where their values match, and the admin confirms.
-- Each row is then matched to this scan's folders by exact path or server + share (never a guess); the owner to
-- an account by account name, e-mail or display name (exact). Every row keeps its outcome; the folders matched
-- become suggestions with their evidence when the admin applies them. Confirmed tags are never changed.
--
-- perm_maps          one workbook: its file, its sheets (columns, roles, why), the joins, the analysis
-- perm_map_rows      its rows, cleaned
-- perm_map_outcomes  what became of each row (matched, conflict, ambiguous, no such folder, ...)
-- perm_map_targets   per folder of the scan: what the workbook says (merged over its rows), ready to apply
-- Re-run safe.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS perm_maps (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_name    TEXT NOT NULL,
    size_bytes   BIGINT NOT NULL,
    data         BYTEA,                   -- the file until it is read
    state        TEXT NOT NULL DEFAULT 'uploaded'
                 CHECK (state IN ('uploaded', 'reading', 'review', 'analysing', 'analysed', 'failed')),
    error        TEXT,
    note         TEXT,
    file_type    TEXT,
    sheets       JSONB,                   -- [{sheet_no, name, header_row, headers, rows, sample, roles, why, use}]
    joins        JSONB,                   -- [{sheet, col, to_sheet, to_col, matched, of, use}]
    covers       BOOLEAN NOT NULL DEFAULT true,   -- a share's row also for its folders that have no row of their own
    dataset_id   UUID REFERENCES perm_datasets(id) ON DELETE SET NULL,
    result       JSONB,
    created_by   TEXT NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    confirmed_by TEXT,
    analysed_at  TIMESTAMPTZ,
    applied_by   TEXT,
    applied_at   TIMESTAMPTZ,
    applied      INT
);

CREATE TABLE IF NOT EXISTS perm_map_rows (
    map_id    UUID NOT NULL REFERENCES perm_maps(id) ON DELETE CASCADE,
    sheet_no  INT NOT NULL,
    rn        INT NOT NULL,               -- the row's number in the sheet, as Excel shows it
    cells     TEXT[] NOT NULL,
    PRIMARY KEY (map_id, sheet_no, rn)
);

CREATE TABLE IF NOT EXISTS perm_map_outcomes (
    map_id      UUID NOT NULL REFERENCES perm_maps(id) ON DELETE CASCADE,
    sheet_no    INT NOT NULL,
    rn          INT NOT NULL,
    status      TEXT NOT NULL,
    location    TEXT,                     -- where the row says (path, or server + share), as written
    folder_key  TEXT,
    folder      TEXT,
    how         TEXT,
    owner_text  TEXT,
    owner       TEXT,
    owner_kind  TEXT,
    owner_how   TEXT,
    department  TEXT,
    team        TEXT,
    application TEXT,
    note        TEXT,
    PRIMARY KEY (map_id, sheet_no, rn)
);
CREATE INDEX IF NOT EXISTS perm_map_outcomes_status ON perm_map_outcomes (map_id, status);

CREATE TABLE IF NOT EXISTS perm_map_targets (
    map_id      UUID NOT NULL REFERENCES perm_maps(id) ON DELETE CASCADE,
    folder_key  TEXT NOT NULL,
    folder      TEXT,
    owner       TEXT,
    owner_kind  TEXT,
    department  TEXT,
    team        TEXT,
    application TEXT,
    confidence  INT NOT NULL,
    evidence    TEXT NOT NULL,
    conflicts   TEXT,
    now_state   TEXT,                     -- the folder's own tag when analysed: none, suggested, confirmed, rejected
    same_as_now BOOLEAN,
    PRIMARY KEY (map_id, folder_key)
);

INSERT INTO schema_version (version, description)
VALUES (66, 'Access review: last year''s mapping workbook')
ON CONFLICT (version) DO NOTHING;
