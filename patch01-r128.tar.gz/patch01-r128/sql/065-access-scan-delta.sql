-- ---------------------------------------------------------------------------
-- 065 (r125) Access scanner: change-only (delta) scans
--
-- The first scan of a server is full. After that the scanner still reads every folder's permissions on the server,
-- but sends only the folders whose permissions or owner changed, the new ones and the ones gone. PATCH-01 keeps
-- the server's last full picture here and builds the complete upload from it, so every report stays complete.
--
-- perm_scan_folders  each folder's record as the scanner last sent it (one row per folder, per server)
-- perm_scanners      + state_scan: the scan (scanner's own id) the picture is at; state_shares / state_options:
--                      what it covers; pending_scan: a scan accepted but not built yet; full_next: the next scan
--                      must be full (a change-only scan did not match); state_at; all_shares: every disk share
--                      the server has (for the share picker), as its last scan or -Register said
-- perm_scans         + scan_uid (the scanner's id for the run), mode (full | delta), changes (counts)
-- Re-run safe.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS perm_scan_folders (
    host_id   UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    unc_l     TEXT NOT NULL,
    rec       JSONB NOT NULL,
    PRIMARY KEY (host_id, unc_l)
);

ALTER TABLE perm_scanners ADD COLUMN IF NOT EXISTS state_scan TEXT;
ALTER TABLE perm_scanners ADD COLUMN IF NOT EXISTS state_shares TEXT[];
ALTER TABLE perm_scanners ADD COLUMN IF NOT EXISTS state_options JSONB;
ALTER TABLE perm_scanners ADD COLUMN IF NOT EXISTS state_at TIMESTAMPTZ;
ALTER TABLE perm_scanners ADD COLUMN IF NOT EXISTS pending_scan TEXT;
ALTER TABLE perm_scanners ADD COLUMN IF NOT EXISTS full_next BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE perm_scanners ADD COLUMN IF NOT EXISTS share_info JSONB;

ALTER TABLE perm_scans ADD COLUMN IF NOT EXISTS scan_uid TEXT;
ALTER TABLE perm_scans ADD COLUMN IF NOT EXISTS mode TEXT;
ALTER TABLE perm_scans ADD COLUMN IF NOT EXISTS changes JSONB;

INSERT INTO schema_version (version, description)
VALUES (65, 'Access scanner: change-only scans')
ON CONFLICT (version) DO NOTHING;
