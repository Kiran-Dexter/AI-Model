-- ---------------------------------------------------------------------------
-- PATCH-01 : schema 060 - Access review: file and folder permissions, application tagging (r119)
--
-- An admin uploads a permissions report (CSV from any tool). The worker reads it,
-- AI-01 proposes which column is which and which application and owning team each
-- folder belongs to; the admin confirms; reports are counted from the rows themselves.
--
-- perm_datasets   one per uploaded file: its state, columns, the mapping, progress
-- perm_chunks     the file while it is uploaded (removed once it is read)
-- perm_raw        each row as it came (so the mapping can be changed without uploading again)
-- perm_entries    each row made plain: server, share, path, who, what level, inherited, flags
-- perm_folders    the folders tagged (server\share\first levels): counts, and the tag in force
-- perm_tags       application and owning team per folder, kept across uploads:
--                 'suggested' by AI-01 (never counted as confirmed), 'confirmed' or 'rejected' by an admin
-- perm_reports    each report made: what was asked, the figures (counted by the worker), AI-01's summary
-- Re-run safe.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS perm_datasets (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name          TEXT NOT NULL,
    file_name     TEXT NOT NULL,
    size_bytes    BIGINT NOT NULL,
    received      BIGINT NOT NULL DEFAULT 0,
    uploaded_by   TEXT NOT NULL,
    uploaded_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    state         TEXT NOT NULL DEFAULT 'uploading'
                  CHECK (state IN ('uploading', 'uploaded', 'reading', 'mapping', 'normalising', 'ready', 'failed')),
    error         TEXT,
    encoding      TEXT,
    delimiter     TEXT,
    header_row    INT,
    headers       TEXT[],
    sample        JSONB,
    row_count     INT,
    skipped       INT NOT NULL DEFAULT 0,
    mapping       JSONB,                 -- the mapping in force (confirmed by an admin)
    mapping_by    TEXT,
    mapping_at    TIMESTAMPTZ,
    proposal      JSONB,                 -- what the rules and AI-01 proposed, with reasons
    tag_depth     INT NOT NULL DEFAULT 1 CHECK (tag_depth BETWEEN 0 AND 4),
    profile       JSONB,                 -- counts once the rows are made plain
    progress      JSONB,
    tag_ai        TEXT NOT NULL DEFAULT 'idle' CHECK (tag_ai IN ('idle', 'queued', 'running', 'done', 'failed')),
    tag_ai_note   TEXT,
    advice        JSONB,
    advice_at     TIMESTAMPTZ,
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS perm_chunks (
    dataset_id  UUID NOT NULL REFERENCES perm_datasets(id) ON DELETE CASCADE,
    seq         INT NOT NULL,
    offset_b    BIGINT NOT NULL,
    data        BYTEA NOT NULL,
    PRIMARY KEY (dataset_id, seq)
);

CREATE TABLE IF NOT EXISTS perm_raw (
    dataset_id  UUID NOT NULL REFERENCES perm_datasets(id) ON DELETE CASCADE,
    rn          INT NOT NULL,
    cells       TEXT[] NOT NULL,
    PRIMARY KEY (dataset_id, rn)
);

CREATE TABLE IF NOT EXISTS perm_entries (
    dataset_id     UUID NOT NULL REFERENCES perm_datasets(id) ON DELETE CASCADE,
    rn             INT NOT NULL,
    server         TEXT,
    share          TEXT,
    path           TEXT NOT NULL,
    folder_key     TEXT NOT NULL,       -- lower case: server\share\first levels (the unit tagged)
    depth          INT NOT NULL,
    identity       TEXT NOT NULL,
    identity_kind  TEXT NOT NULL CHECK (identity_kind IN ('user', 'group', 'computer', 'broad', 'admin', 'system', 'orphan', 'unknown')),
    kind_source    TEXT NOT NULL DEFAULT 'rule' CHECK (kind_source IN ('column', 'rule', 'name')),
    rights_raw     TEXT,
    level          TEXT NOT NULL CHECK (level IN ('full', 'modify', 'write', 'read_execute', 'read', 'list', 'special', 'none')),
    allow          BOOLEAN NOT NULL DEFAULT true,
    inherited      BOOLEAN,
    owner          TEXT,
    PRIMARY KEY (dataset_id, rn)
);
CREATE INDEX IF NOT EXISTS perm_entries_folder ON perm_entries (dataset_id, folder_key);
CREATE INDEX IF NOT EXISTS perm_entries_identity ON perm_entries (dataset_id, lower(identity));

CREATE TABLE IF NOT EXISTS perm_folders (
    dataset_id   UUID NOT NULL REFERENCES perm_datasets(id) ON DELETE CASCADE,
    folder_key   TEXT NOT NULL,
    label        TEXT NOT NULL,         -- as written in the file
    server       TEXT,
    entries      INT NOT NULL,
    paths        INT NOT NULL,
    identities   INT NOT NULL,
    hints        JSONB,                 -- what AI-01 is shown: groups seen, sub-folders
    tag_key      TEXT,                  -- the tag in force (this folder or a parent), if any
    application  TEXT,
    team         TEXT,
    tag_state    TEXT CHECK (tag_state IS NULL OR tag_state IN ('suggested', 'confirmed')),
    PRIMARY KEY (dataset_id, folder_key)
);

CREATE TABLE IF NOT EXISTS perm_tags (
    key_l         TEXT PRIMARY KEY,     -- lower case folder: server\share\folder...
    label         TEXT NOT NULL,
    application   TEXT,
    team          TEXT,
    state         TEXT NOT NULL CHECK (state IN ('suggested', 'confirmed', 'rejected')),
    confidence    INT CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 100),
    reason        TEXT,
    suggested_by  TEXT,
    suggested_at  TIMESTAMPTZ,
    decided_by    TEXT,
    decided_at    TIMESTAMPTZ,
    CHECK (state <> 'confirmed' OR application IS NOT NULL OR team IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS perm_reports (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    dataset_id  UUID NOT NULL REFERENCES perm_datasets(id) ON DELETE CASCADE,
    kind        TEXT NOT NULL,
    title       TEXT NOT NULL,
    spec        JSONB NOT NULL,
    state       TEXT NOT NULL DEFAULT 'queued' CHECK (state IN ('queued', 'computing', 'ready', 'failed')),
    error       TEXT,
    result      JSONB,                 -- the figures, counted by the worker (a million rows take a few seconds)
    summary     JSONB,
    summary_state TEXT NOT NULL DEFAULT 'queued' CHECK (summary_state IN ('queued', 'running', 'done', 'failed', 'off')),
    created_by  TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS perm_reports_dataset ON perm_reports (dataset_id, created_at DESC);

INSERT INTO schema_version (version, description)
VALUES (60, 'Access review: file and folder permissions, application tagging')
ON CONFLICT (version) DO NOTHING;
