-- ---------------------------------------------------------------------------
-- 067 (r128) Access review: AI-01's checks shown as they really go
--
-- perm_datasets + tag_ai_progress: how far AI-01's checks of the owners are ({total, done, secs, batches,
--                   started, waiting}): counted from the start of the checks, with how long they take, so the page
--                   can say "120 of 186 checked, about 12 minutes left" (or that AI-01 waits for people using it)
-- perm_folders  + evidence: false when the folder's permissions say nothing about its owner (only inherited rights,
--                   or only admin, system and Everyone-type accounts): AI-01 is not asked to guess about those;
--                   evidence_note: in words
-- Re-run safe.
-- ---------------------------------------------------------------------------

ALTER TABLE perm_datasets ADD COLUMN IF NOT EXISTS tag_ai_progress JSONB;
ALTER TABLE perm_folders ADD COLUMN IF NOT EXISTS evidence BOOLEAN;
ALTER TABLE perm_folders ADD COLUMN IF NOT EXISTS evidence_note TEXT;

INSERT INTO schema_version (version, description)
VALUES (67, 'Access review: AI-01 checks shown as they go')
ON CONFLICT (version) DO NOTHING;
