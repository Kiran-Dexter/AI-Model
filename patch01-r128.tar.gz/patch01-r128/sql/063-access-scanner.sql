-- ---------------------------------------------------------------------------
-- PATCH-01 : schema 063 - Access review: the file-server access scanner (r123)
--
-- perm_scanners  the servers with access-scan.ps1 installed (it registers itself)
-- perm_scans     each scan asked for (from PATCH-01, or run on the server): its options, how far
--                it got, and the upload it became
-- perm_shares    the shares a scan found, with each share's own permissions
-- perm_people    + enabled, last logon (read from Active Directory by the scanner)
-- perm_datasets  + where an upload came from (a scan, or a file an admin uploaded)
-- agent_verb     + access_scan
-- Re-run safe; no constraint is narrowed.
-- ---------------------------------------------------------------------------

ALTER TYPE agent_verb ADD VALUE IF NOT EXISTS 'access_scan';

CREATE TABLE IF NOT EXISTS perm_scanners (
    host_id        UUID PRIMARY KEY REFERENCES hosts(id) ON DELETE CASCADE,
    version        TEXT NOT NULL,
    shares         TEXT[] NOT NULL DEFAULT '{}',
    registered_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS perm_scans (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    host_id       UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    state         TEXT NOT NULL DEFAULT 'queued'
                  CHECK (state IN ('queued', 'started', 'running', 'uploading', 'importing', 'done', 'failed', 'cancelled')),
    options       JSONB NOT NULL DEFAULT '{}'::jsonb,
    requested_by  TEXT NOT NULL,                       -- an admin, or 'the server' when run there
    requested_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    command_id    UUID,
    stage         TEXT,
    progress      JSONB,
    note          TEXT,
    dataset_id    UUID REFERENCES perm_datasets(id) ON DELETE SET NULL,
    error         TEXT,
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS perm_scans_host ON perm_scans (host_id, requested_at DESC);

CREATE TABLE IF NOT EXISTS perm_shares (
    dataset_id   UUID NOT NULL REFERENCES perm_datasets(id) ON DELETE CASCADE,
    name         TEXT NOT NULL,
    path         TEXT,
    unc          TEXT,
    description  TEXT,
    access       JSONB,                  -- the share's own permissions: [{account, sid, right, type}]
    PRIMARY KEY (dataset_id, name)
);

ALTER TABLE perm_people ADD COLUMN IF NOT EXISTS enabled BOOLEAN;
ALTER TABLE perm_people ADD COLUMN IF NOT EXISTS last_logon DATE;

ALTER TABLE perm_datasets ADD COLUMN IF NOT EXISTS source TEXT;            -- 'scan' or NULL (a file uploaded)
ALTER TABLE perm_datasets ADD COLUMN IF NOT EXISTS scan_id UUID;
ALTER TABLE perm_datasets ADD COLUMN IF NOT EXISTS host_id UUID;
ALTER TABLE perm_datasets ADD COLUMN IF NOT EXISTS scan_errors JSONB;      -- folders the scanner could not read

INSERT INTO schema_version (version, description)
VALUES (63, 'Access review: file-server access scanner')
ON CONFLICT (version) DO NOTHING;
