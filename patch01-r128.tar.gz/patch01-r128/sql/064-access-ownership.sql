-- ---------------------------------------------------------------------------
-- 064 (r124) Access review: owner and department of each folder
--
-- perm_tags     + owner (a person such as CORP\jsmith, or a group / team), owner_kind (person | group),
--                 department, evidence (what the rules saw, in words, with the numbers), ai_asked_at
--                 (AI-01 looked at it; not asked again unless an admin asks again).
--                 A confirmed tag needs at least one of application, team, owner or department.
-- perm_folders  + the tag in force's owner, owner_kind and department, and the folder's NTFS owner
--                 as the file or the scanner gives it.
-- perm_datasets + tag_ai_scope: 'unsure' (AI-01 checks only what the rules are unsure of, queued by
--                 itself after the import) or 'all' (an admin asked for every folder).
-- Re-run safe.
-- ---------------------------------------------------------------------------

ALTER TABLE perm_tags ADD COLUMN IF NOT EXISTS owner TEXT;
ALTER TABLE perm_tags ADD COLUMN IF NOT EXISTS owner_kind TEXT;
ALTER TABLE perm_tags ADD COLUMN IF NOT EXISTS department TEXT;
ALTER TABLE perm_tags ADD COLUMN IF NOT EXISTS evidence TEXT;
ALTER TABLE perm_tags ADD COLUMN IF NOT EXISTS ai_asked_at TIMESTAMPTZ;

ALTER TABLE perm_folders ADD COLUMN IF NOT EXISTS owner TEXT;
ALTER TABLE perm_folders ADD COLUMN IF NOT EXISTS owner_kind TEXT;
ALTER TABLE perm_folders ADD COLUMN IF NOT EXISTS department TEXT;
ALTER TABLE perm_folders ADD COLUMN IF NOT EXISTS ntfs_owner TEXT;

ALTER TABLE perm_datasets ADD COLUMN IF NOT EXISTS tag_ai_scope TEXT NOT NULL DEFAULT 'all';

DO $$
DECLARE c record;
BEGIN
    -- the old rule "confirmed needs an application or a team" is replaced by one that also takes an owner or a department
    FOR c IN SELECT conname FROM pg_constraint
              WHERE conrelid = 'perm_tags'::regclass AND contype = 'c'
                AND pg_get_constraintdef(oid) LIKE '%application%' AND pg_get_constraintdef(oid) NOT LIKE '%department%'
    LOOP
        EXECUTE format('ALTER TABLE perm_tags DROP CONSTRAINT %I', c.conname);
    END LOOP;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'perm_tags'::regclass AND conname = 'perm_tags_confirmed_has') THEN
        ALTER TABLE perm_tags ADD CONSTRAINT perm_tags_confirmed_has
            CHECK (state <> 'confirmed' OR application IS NOT NULL OR team IS NOT NULL OR owner IS NOT NULL OR department IS NOT NULL);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'perm_tags'::regclass AND conname = 'perm_tags_owner_kind') THEN
        ALTER TABLE perm_tags ADD CONSTRAINT perm_tags_owner_kind CHECK (owner_kind IS NULL OR owner_kind IN ('person', 'group'));
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'perm_datasets'::regclass AND conname = 'perm_datasets_tag_ai_scope') THEN
        ALTER TABLE perm_datasets ADD CONSTRAINT perm_datasets_tag_ai_scope CHECK (tag_ai_scope IN ('all', 'unsure'));
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS perm_tags_owner ON perm_tags (lower(owner)) WHERE owner IS NOT NULL;

INSERT INTO schema_version (version, description)
VALUES (64, 'Access review: owner and department of each folder')
ON CONFLICT (version) DO NOTHING;
