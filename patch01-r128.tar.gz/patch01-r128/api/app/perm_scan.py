"""Access review (r123): files from the access scanner (access-scan.ps1) on a file server.

The scanner writes one exact format (patch01-access-scan/1: one JSON object per line, gzip), so
nothing is guessed: no column mapping, no AI-01 for the columns. The file becomes the same three
tables a workbook can give (permissions, group members, people), with their columns already set,
and goes straight to "making the rows plain".

Lines: header (first), share, folder (with its entries by SID), group (its members by SID),
identity (each SID: name, kind, and for people department, title, manager, office, e-mail,
enabled, last logon), error (a folder that could not be read), end (last; a file without it was cut).
"""
import gzip
import io
import json
import re

SCHEMA = "patch01-access-scan/1"
MAX_ERRORS_KEPT = 2000
KIND_TYPE = {"user": "User", "group": "Group", "computer": "Computer", "wellknown": "Everyone-type group",
             "system": "System account", "orphan": "Orphaned SID", "unknown": ""}

PERM_HEADERS = ["Path", "Account", "Account type", "Rights", "Access", "Inherited", "Applies to", "Owner", "Server", "SID"]
PERM_MAP = {"path": 0, "identity": 1, "account_type": 2, "rights": 3, "access_type": 4, "inherited": 5, "owner": 7, "server": 8}
MEMBER_HEADERS = ["Group", "Member", "Member type"]
MEMBER_MAP = {"group": 0, "member": 1, "member_type": 2}
PEOPLE_HEADERS = ["User", "Department", "Full name", "Title", "Manager", "Office", "E-mail", "Enabled", "Last logon"]
PEOPLE_MAP = {"person": 0, "department": 1, "display_name": 2, "title": 3, "manager": 4, "location": 5, "email": 6,
              "enabled": 7, "last_logon": 8}


class ScanError(ValueError):
    pass


def is_scan(head):
    """True when the bytes start a scanner file (gzip whose first line is our header)."""
    if not head.startswith(b"\x1f\x8b"):
        return False
    try:
        with gzip.GzipFile(fileobj=io.BytesIO(head)) as g:
            first = g.readline(65536)
    except (OSError, EOFError):
        return False
    try:
        rec = json.loads(first.decode("utf-8-sig"))
    except ValueError:
        return False
    return isinstance(rec, dict) and rec.get("t") == "header" and str(rec.get("schema", "")).startswith("patch01-access-scan/")


def _lines(open_file):
    with gzip.GzipFile(fileobj=open_file()) as g:
        for n, raw in enumerate(io.TextIOWrapper(g, encoding="utf-8-sig", newline="\n")):
            raw = raw.strip()
            if not raw:
                continue
            try:
                rec = json.loads(raw)
            except ValueError:
                raise ScanError(f"line {n + 1} of the scan is not JSON: the file is damaged")
            if not isinstance(rec, dict) or "t" not in rec:
                raise ScanError(f"line {n + 1} of the scan has no record type")
            yield rec


def system_drive(header):
    """The server's system drive ("C:") whose folders are left out, or None when the scan asked to include it.
    Scanner 1.2.0 writes it; for older scanners it is C:."""
    h = header or {}
    if (h.get("options") or {}).get("include_system_drive"):
        return None
    d = str(h.get("system_drive") or "C:").strip().rstrip("\\").upper()
    return d if re.match(r"^[A-Z]:$", d) else "C:"


def on_drive(rec, drive):
    """A share or folder record whose local folder is on that drive."""
    if not drive:
        return False
    p = str(rec.get("path") or "").upper()
    return p == drive or p.startswith(drive + "\\")


def read_scan(open_file):
    """First pass: everything but the folders (the names come at the end of the file).
    open_file() gives a fresh binary file object each time (the scan is read twice)."""
    out = {"header": None, "shares": [], "groups": {}, "ids": {}, "errors": [], "errors_total": 0, "end": None,
           "folders": 0, "lines": 0}
    for rec in _lines(open_file):
        out["lines"] += 1
        t = rec["t"]
        if out["lines"] == 1:
            if t != "header" or rec.get("schema") != SCHEMA:
                raise ScanError(f"not a {SCHEMA} file (its first line is not the scanner's header)")
            out["header"] = rec
        elif t == "share":
            if on_drive(rec, system_drive(out["header"])):
                out["system_skipped"] = out.get("system_skipped", 0) + 1     # r127: the system drive is left out
            else:
                out["shares"].append(rec)
        elif t == "folder":
            if on_drive(rec, system_drive(out["header"])):
                out["system_folders"] = out.get("system_folders", 0) + 1
                continue
            out["folders"] += 1
        elif t == "group":
            out["groups"][rec.get("sid")] = rec
        elif t == "identity":
            out["ids"][rec.get("sid")] = rec
        elif t == "error":
            out["errors_total"] += 1
            if len(out["errors"]) < MAX_ERRORS_KEPT:
                out["errors"].append({"path": str(rec.get("path") or "")[:600], "error": str(rec.get("error") or "")[:300]})
        elif t == "end":
            out["end"] = rec
    if not out["end"]:
        raise ScanError("the scan file is cut: it has no end line (the scan was stopped, or the upload is incomplete). Run the scan again.")
    want = (out["end"].get("counts") or {}).get("lines")
    if isinstance(want, int) and want != out["lines"]:
        raise ScanError(f"the scan file has {out['lines']} lines, its end line says {want}: it is damaged. Run the scan again.")
    return out


def _name(scan, sid):
    rec = scan["ids"].get(sid)
    return (rec.get("name") if rec else None) or sid or ""


def _type(scan, sid):
    rec = scan["ids"].get(sid)
    return KIND_TYPE.get((rec or {}).get("kind", "unknown"), "")


def permission_rows(scan, open_file):
    server = (scan["header"] or {}).get("server") or ""
    sysd = system_drive(scan["header"])
    yield PERM_HEADERS
    for rec in _lines(open_file):
        if rec["t"] != "folder" or on_drive(rec, sysd):
            continue
        path = rec.get("unc") or rec.get("path") or ""
        owner = _name(scan, rec.get("owner")) if rec.get("owner") else ""
        for a in rec.get("aces") or []:
            sid = a.get("sid")
            applies = ", ".join(x for x in (a.get("flags"), a.get("prop")) if x and x != "None")
            yield [path, _name(scan, sid), _type(scan, sid), str(int(a.get("rights") or 0)), "Deny" if a.get("deny") else "Allow",
                   "True" if a.get("inherited") else "False", applies, owner, "" if rec.get("unc") else server, sid or ""]


def member_rows(scan):
    yield MEMBER_HEADERS
    for g in scan["groups"].values():
        gname = _name(scan, g.get("sid"))
        for m in g.get("members") or []:
            yield [gname, _name(scan, m), _type(scan, m)]


def people_rows(scan):
    yield PEOPLE_HEADERS
    for rec in scan["ids"].values():
        if rec.get("kind") != "user":
            continue
        en = rec.get("enabled")
        yield [rec.get("name") or rec.get("sid"), rec.get("department") or "", rec.get("display_name") or "", rec.get("title") or "",
               rec.get("manager") or "", rec.get("office") or "", rec.get("mail") or "",
               "" if en is None else ("True" if en else "False"), rec.get("last_logon") or ""]


def sheets(scan, open_file, Sheet):
    """The scan as three sheets with their roles and columns already set: [(Sheet, role, mapping)]."""
    out = [(Sheet("Permissions (scanner)", permission_rows(scan, open_file)), "permissions", PERM_MAP)]
    if scan["groups"]:
        out.append((Sheet("Group members (scanner)", member_rows(scan)), "members", MEMBER_MAP))
    if any(r.get("kind") == "user" for r in scan["ids"].values()):
        out.append((Sheet("People (scanner)", people_rows(scan)), "people", PEOPLE_MAP))
    for sh, _, _ in out:
        sh.header_index = 0
    return out


def summary(scan):
    h, e = scan["header"] or {}, scan["end"] or {}
    return {"server": h.get("server"), "fqdn": h.get("fqdn"), "domain": h.get("domain"), "os": h.get("os"), "run_as": h.get("run_as"),
            "scanner": h.get("scanner"), "started": h.get("started"), "finished": e.get("finished"), "options": h.get("options"),
            "counts": e.get("counts"), "shares": len(scan["shares"]), "errors_total": scan["errors_total"],
            "system_drive": system_drive(h), "system_drive_skipped": {"shares": scan.get("system_skipped", 0),
                                                                     "folders": scan.get("system_folders", 0)}}


# ---- scans: asked for, started, uploaded, imported ---------------------------------------------------------

SHARE_RE = re.compile(r'^[^\\/:*?"<>|]{1,80}$')
PATH_RE = re.compile(r'^[A-Za-z]:\\[^*?"<>|]{0,250}$')
STALE_MINUTES = 20       # r126: no word from a running scan for this long: stopped (the scanner says something every 30 s)


SCANNER_VERSION = "1.2.0"     # the scanner in this package (agent/windows/access-scan.ps1)
SCHEMA_WANTED = 67


def health(conn):
    """Access review's own health, for the line at the top of the page: is the worker reading, the schema in place,
    AI-01 there, the scanners up to date. Plain words; nothing from the files."""
    import time
    out = {"schema": None, "schema_wanted": SCHEMA_WANTED, "worker": None, "scanners_old": []}
    try:
        out["schema"] = conn.execute("SELECT max(version) AS v FROM schema_version").fetchone()["v"]
    except Exception:  # noqa: BLE001
        conn.rollback()
    beats = {r["name"]: r for r in conn.execute("""SELECT name, extract(epoch FROM now() - beat_at)::int AS age, detail
                                                     FROM worker_heartbeat WHERE name IN ('perm', 'perm_error')""").fetchall()}
    ok, err = beats.get("perm"), beats.get("perm_error")
    detail = (ok or {}).get("detail") or {}
    if isinstance(detail, str):
        detail = json.loads(detail or "{}")
    w = {"seen_s": ok["age"] if ok else None, "schema_ready": detail.get("schema", True) is not False}
    if err and (not ok or err["age"] < ok["age"]):        # failed since it last finished a pass
        e = err["detail"] if isinstance(err["detail"], dict) else json.loads(err["detail"] or "{}")
        w.update({"error": e.get("error"), "error_s": err["age"]})
    w["state"] = ("never" if not ok and not err else "failing" if w.get("error") else
                  "stalled" if ok["age"] > 600 else "schema" if not w["schema_ready"] else "ok")
    out["worker"] = w
    out["scanners_old"] = [r["hostname"] for r in conn.execute(
        "SELECT h.hostname, s.version FROM perm_scanners s JOIN hosts h ON h.id = s.host_id WHERE h.status <> 'decommissioned'").fetchall()
        if _ver(r["version"]) < _ver(SCANNER_VERSION)]
    out["scanner_version"] = SCANNER_VERSION
    t = time.time()
    try:
        from . import llm
        hh = llm.health(timeout=3)
        out["ai"] = {"configured": bool(hh.get("configured")), "reachable": bool(hh.get("reachable")), "error": hh.get("error")}
    except Exception as e:  # noqa: BLE001
        out["ai"] = {"configured": False, "reachable": False, "error": str(e)[:200]}
    out["ai"]["checked_ms"] = int((time.time() - t) * 1000)
    from .perm_review import SLOT_TOKENS
    out["ai"]["slot_tokens"] = SLOT_TOKENS
    return out


def _ver(v):
    try:
        return tuple(int(x) for x in re.findall(r"\d+", str(v or ""))[:3])
    except ValueError:
        return (0,)


def scanners(conn):
    """The servers with the scanner installed, and their recent scans."""
    rows = conn.execute("""SELECT s.host_id::text AS host_id, h.hostname, h.fqdn, h.agent_version, h.last_checkin, s.version, s.shares,
                                  s.registered_at, s.last_seen, s.share_info, s.state_scan IS NOT NULL AS has_picture, s.state_at,
                                  s.state_options, s.full_next,
                                  (SELECT count(*) FROM perm_scan_folders f WHERE f.host_id = s.host_id) AS picture_folders
                             FROM perm_scanners s JOIN hosts h ON h.id = s.host_id
                            WHERE h.status <> 'decommissioned' ORDER BY h.hostname""").fetchall()
    scans = conn.execute("""SELECT p.id::text AS id, p.host_id::text AS host_id, h.hostname, p.state, p.options, p.requested_by, p.requested_at,
                                   p.stage, p.progress, p.note, p.dataset_id::text AS dataset_id, p.error, p.updated_at, p.mode, p.changes
                              FROM perm_scans p JOIN hosts h ON h.id = p.host_id ORDER BY p.requested_at DESC LIMIT 40""").fetchall()
    return {"scanners": rows, "scans": scans}


def check_options(o):
    from .perm_review import PermError
    o = o or {}
    shares = [str(x).strip() for x in (o.get("shares") or []) if str(x).strip()]
    paths = [str(x).strip().rstrip("\\") for x in (o.get("paths") or []) if str(x).strip()]
    bad = [x for x in shares if not SHARE_RE.match(x)] + [x for x in paths if not PATH_RE.match(x + "\\")]
    if bad:
        raise PermError("Not a share name or a local folder (D:\\Data): " + ", ".join(bad[:5]))
    if len(shares) > 200 or len(paths) > 50:
        raise PermError("At most 200 shares and 50 folders in one scan.")
    try:
        depth, max_depth = int(o.get("depth", 1)), int(o.get("max_depth", 16))
    except (TypeError, ValueError):
        raise PermError("The depths are numbers.")
    if not 0 <= depth <= 8:
        raise PermError("Read every folder down to 0 to 8 levels.")
    if not depth <= max_depth <= 64:
        raise PermError("Below that, folders whose permissions change are read down to 64 levels at most, and not less than the first depth.")
    return {"shares": shares, "paths": paths, "depth": depth, "max_depth": max_depth, "members": bool(o.get("members", True)),
            "full": bool(o.get("full", False))}


def ask(conn, host_id, options, user):
    """An admin asks for a scan of one server: queued for its agent (1.10.0-win starts the scanner)."""
    from .perm_review import PermError
    h = conn.execute("""SELECT h.id::text AS id, h.hostname, h.agent_version, s.version FROM hosts h
                          LEFT JOIN perm_scanners s ON s.host_id = h.id WHERE h.id = %s AND h.status <> 'decommissioned'""",
                     (host_id,)).fetchone()
    if not h:
        raise PermError("That server is not known.")
    if not h["version"]:
        raise PermError(f"{h['hostname']} has no access scanner: copy access-scan.ps1 next to its agent and run access-scan.ps1 -Register.")
    if not agent_starts_scans(h["agent_version"]):
        raise PermError(f"{h['hostname']}'s agent ({h['agent_version'] or 'unknown'}) cannot start a scan: update it to 1.10.0-win, "
                        "or run access-scan.ps1 -Upload on the server (or from Task Scheduler).")
    busy = conn.execute("""SELECT 1 FROM perm_scans WHERE host_id = %s AND state IN ('queued', 'started', 'running', 'uploading', 'importing')
                            AND updated_at > now() - make_interval(mins => %s)""", (host_id, STALE_MINUTES)).fetchone()
    if busy:
        raise PermError(f"A scan of {h['hostname']} is already under way.")
    opt = check_options(options)
    if opt.pop("full", False):                             # the scanner asks PATCH-01 before it scans: this one is full
        conn.execute("UPDATE perm_scanners SET full_next = true WHERE host_id = %s", (host_id,))
        opt["full"] = True
    sc = conn.execute("""INSERT INTO perm_scans (host_id, options, requested_by) VALUES (%s, %s::jsonb, %s) RETURNING id::text AS id""",
                      (host_id, json.dumps(opt), user)).fetchone()
    cmd = conn.execute("""INSERT INTO agent_commands (host_id, verb, params, expires_at)
                          VALUES (%s, 'access_scan', %s::jsonb, now() + interval '1 day') RETURNING id::text AS id""",
                       (host_id, json.dumps(dict(opt, scan_id=sc["id"])))).fetchone()
    conn.execute("UPDATE perm_scans SET command_id = %s WHERE id = %s", (cmd["id"], sc["id"]))
    return sc["id"]


def agent_starts_scans(version):
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)-win$", version or "")
    return bool(m) and tuple(int(x) for x in m.groups()) >= (1, 10, 0)


def cancel(conn, scan_id, user="an admin"):
    """Stop a scan: one not started yet is never started; a running one is marked stopped at once, and the
    scanner stops at its next word to PATCH-01 (within 30 s), its file is not taken."""
    from .perm_review import PermError
    r = conn.execute("""UPDATE perm_scans SET state = 'cancelled', updated_at = now(),
                               note = CASE WHEN state = 'queued' THEN 'cancelled before the server started it' ELSE %s END
                         WHERE id = %s AND state IN ('queued', 'started', 'running', 'uploading')
                     RETURNING command_id::text AS c, dataset_id::text AS d""", (f"stopped from PATCH-01 by {user}", scan_id)).fetchone()
    if not r:
        raise PermError("This scan is finished already: only a waiting or running scan can be stopped.")
    if r["c"]:
        conn.execute("DELETE FROM agent_commands WHERE id = %s AND claimed_at IS NULL", (r["c"],))
    if r["d"]:                                             # a file half sent: nothing of it is kept
        conn.execute("DELETE FROM perm_datasets WHERE id = %s AND state = 'uploading'", (r["d"],))


# ---- what the scanner sends (with the agent's token) ------------------------------------------------------

def register(conn, host_id, version, shares, check=False):
    v = str(version or "")[:40]
    if check:
        return {"message": "PATCH-01 answers this server's scanner"}
    names = [str(x)[:80] for x in (shares or [])][:500]
    conn.execute("""INSERT INTO perm_scanners (host_id, version, shares) VALUES (%s, %s, %s)
                    ON CONFLICT (host_id) DO UPDATE SET version = EXCLUDED.version, shares = EXCLUDED.shares, last_seen = now()""",
                 (host_id, v, names))
    _share_info(conn, host_id, {"all_shares": names}, [])
    return {"message": f"registered: {len(shares or [])} shares; scans can now be started from PATCH-01 > Access review"}


def started_here(conn, host_id, version, options):
    """A scan run on the server itself (by hand or from Task Scheduler)."""
    try:
        opt = check_options(options) if options else {}
    except ValueError:
        opt = {}
    conn.execute("""INSERT INTO perm_scanners (host_id, version) VALUES (%s, %s)
                    ON CONFLICT (host_id) DO UPDATE SET version = EXCLUDED.version, last_seen = now()""", (host_id, str(version or "")[:40]))
    r = conn.execute("""INSERT INTO perm_scans (host_id, options, requested_by, state, stage) VALUES (%s, %s::jsonb, 'the server', 'running', 'starting')
                        RETURNING id::text AS id""", (host_id, json.dumps(opt))).fetchone()
    return r["id"]


def _mine(conn, host_id, scan_id):
    from .perm_review import PermError
    r = conn.execute("SELECT id::text AS id, state, dataset_id::text AS dataset_id FROM perm_scans WHERE id = %s AND host_id = %s FOR UPDATE",
                     (scan_id, host_id)).fetchone()
    if not r:
        raise PermError("no such scan for this server")
    return r


def progress(conn, host_id, scan_id, body):
    sc = _mine(conn, host_id, scan_id)
    if sc["state"] == "cancelled":
        return {"ok": True, "stop": True}                  # stopped from PATCH-01: the scanner stops
    if sc["state"] in ("done", "importing"):
        return {"ok": True}
    if body.get("state") == "cancelled":                   # r126: stopped on the server (Ctrl+C, or the window closed)
        conn.execute("""UPDATE perm_scans SET state = 'cancelled', stage = %s, note = %s, updated_at = now() WHERE id = %s""",
                     (str(body.get("stage") or "")[:200], (str(body.get("note") or "") or "stopped on the server")[:500], scan_id))
        if sc["dataset_id"]:
            conn.execute("DELETE FROM perm_datasets WHERE id = %s AND state = 'uploading'", (sc["dataset_id"],))
        return {"ok": True}
    state = body.get("state") if body.get("state") in ("running", "uploading", "failed") else "running"
    counts = body.get("counts") if isinstance(body.get("counts"), dict) else {}
    counts = {str(k)[:30]: int(v) for k, v in list(counts.items())[:20] if isinstance(v, (int, float))}
    conn.execute("""UPDATE perm_scans SET state = %s, stage = %s, progress = %s::jsonb, note = coalesce(%s, note),
                           error = CASE WHEN %s = 'failed' THEN %s ELSE error END, updated_at = now() WHERE id = %s""",
                 (state, str(body.get("stage") or "")[:200], json.dumps(counts), (str(body.get("note") or "")[:500] or None),
                  state, (str(body.get("note") or "the scan stopped on the server")[:500]), scan_id))
    conn.execute("UPDATE perm_scanners SET last_seen = now() WHERE host_id = %s", (host_id,))
    return {"ok": True}


def upload_start(conn, host_id, hostname, scan_id, file_name, size, scan_uid=None, mode=None):
    """The scan's file is about to be sent: one upload per scan (asked again, it resumes)."""
    from .perm_review import PermError, start_upload
    sc = _mine(conn, host_id, scan_id)
    if scan_uid or mode:
        conn.execute("UPDATE perm_scans SET scan_uid = %s, mode = %s WHERE id = %s",
                     (str(scan_uid or "")[:80] or None, mode if mode in ("full", "delta") else None, scan_id))
    if sc["state"] == "cancelled":
        raise PermError("this scan was stopped from PATCH-01")
    if sc["state"] in ("done", "importing"):
        raise PermError("this scan is finished already")
    if sc["dataset_id"]:
        d = conn.execute("SELECT state, received, size_bytes FROM perm_datasets WHERE id = %s", (sc["dataset_id"],)).fetchone()
        if d and d["state"] == "uploading" and d["size_bytes"] == int(size):
            return {"received": d["received"], "dataset_id": sc["dataset_id"]}
        if d and d["state"] == "uploading":
            conn.execute("DELETE FROM perm_datasets WHERE id = %s", (sc["dataset_id"],))
    fn = str(file_name or "scan.ndjson.gz")
    if not fn.endswith(".ndjson.gz"):
        fn = "scan.ndjson.gz"
    up = start_upload(conn, f"scanner on {hostname}", fn, int(size), f"{hostname} scan")
    conn.execute("UPDATE perm_datasets SET source = 'scan', scan_id = %s, host_id = %s WHERE id = %s", (scan_id, host_id, up["dataset_id"]))
    conn.execute("UPDATE perm_scans SET dataset_id = %s, state = 'uploading', stage = 'uploading', updated_at = now() WHERE id = %s",
                 (up["dataset_id"], scan_id))
    return {"received": 0, "dataset_id": up["dataset_id"]}


def upload_piece(conn, host_id, scan_id, offset, data):
    from .perm_review import PermError, put_chunk
    sc = _mine(conn, host_id, scan_id)
    if sc["state"] == "cancelled":
        raise PermError("this scan was stopped from PATCH-01")
    if not sc["dataset_id"]:
        raise PermError("start the upload first")
    r = put_chunk(conn, sc["dataset_id"], offset, data)
    conn.execute("UPDATE perm_scans SET updated_at = now() WHERE id = %s", (scan_id,))
    return r


def upload_done(conn, host_id, scan_id):
    from .perm_review import PermError, finish_upload
    sc = _mine(conn, host_id, scan_id)
    if sc["state"] == "cancelled":
        raise PermError("this scan was stopped from PATCH-01")
    if not sc["dataset_id"]:
        raise PermError("start the upload first")
    finish_upload(conn, sc["dataset_id"])
    conn.execute("UPDATE perm_scans SET state = 'importing', stage = 'reading the file', updated_at = now() WHERE id = %s", (scan_id,))
    uid = (conn.execute("SELECT scan_uid FROM perm_scans WHERE id = %s", (scan_id,)).fetchone() or {}).get("scan_uid")
    if uid:                                                # the next change-only scan may be made against this one
        conn.execute("UPDATE perm_scanners SET pending_scan = %s WHERE host_id = %s", (uid, host_id))
    return {"ok": True, "dataset_id": sc["dataset_id"]}


def follow(conn):
    """The worker: scans whose upload is read become done (or failed); a scan with no word for hours fails."""
    conn.execute("""UPDATE perm_scans s SET state = CASE WHEN d.state = 'ready' THEN 'done' ELSE 'failed' END,
                           stage = CASE WHEN d.state = 'ready' THEN 'ready' ELSE 'failed' END,
                           error = CASE WHEN d.state = 'failed' THEN d.error ELSE s.error END, updated_at = now()
                      FROM perm_datasets d
                     WHERE s.dataset_id = d.id AND s.state = 'importing' AND d.state IN ('ready', 'failed')""")
    conn.execute("""UPDATE perm_scans SET state = 'failed', error = %s, updated_at = now()
                     WHERE state IN ('started', 'running', 'uploading') AND updated_at < now() - make_interval(mins => %s)""",
                 (f"stopped: no word from the scanner for {STALE_MINUTES} minutes (it was stopped on the server, its window "
                  "closed, or the server restarted). Run it again.", STALE_MINUTES))
    conn.execute("""UPDATE perm_scans SET state = 'failed', error = 'the server never picked the scan up (its agent did not check in for a day)',
                           updated_at = now()
                     WHERE state = 'queued' AND requested_at < now() - interval '1 day'""")


# ---- r125: change-only (delta) scans ----------------------------------------------------------------------
#
# The scanner (1.1.0) asks PATCH-01 what picture it has of the server (agent_state). When PATCH-01 has the scan
# the scanner last sent, with the same shares and depths, the scanner sends only what changed: the folders whose
# record (owner, inheritance, entries) differs, the new ones, and "gone" lines for the folders removed. Before the
# file is read, prepare() applies it to the picture kept in perm_scan_folders and writes the complete file in its
# place, so the rest of the import (and every report) works on the complete picture. A full scan replaces the
# picture. A change-only scan that does not fit (PATCH-01 lost the base, or the options differ) is refused and the
# next scan is full: the picture is never patched with something it was not made from.

def signature(options):
    """What a picture covers: the shares (lower case, sorted; [] = every share), the folders, the depths."""
    o = options or {}
    return {"shares": sorted({str(x).strip().lower() for x in (o.get("shares") or []) if str(x).strip()}),
            "paths": sorted({str(x).strip().rstrip("\\").lower() for x in (o.get("paths") or []) if str(x).strip()}),
            "depth": int(o.get("depth") if o.get("depth") is not None else 1),
            "max_depth": int(o.get("max_depth") if o.get("max_depth") is not None else 16)}


def agent_state(conn, host_id):
    """For the scanner, before it scans: may it send only the changes, and against which scan."""
    r = conn.execute("""SELECT state_scan, pending_scan, full_next, state_options, state_at FROM perm_scanners WHERE host_id = %s""",
                     (host_id,)).fetchone()
    if not r:
        return {"state_scan": None, "pending_scan": None, "full_next": True, "options": None}
    return {"state_scan": r["state_scan"], "pending_scan": r["pending_scan"], "full_next": bool(r["full_next"]),
            "options": r["state_options"], "state_at": r["state_at"].isoformat() if r["state_at"] else None}


def _host_of(conn, ds_id, header):
    r = conn.execute("SELECT host_id::text AS h FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    if r and r["h"]:
        return r["h"]
    name = str((header or {}).get("server") or "")      # a file uploaded by hand: its server, when PATCH-01 knows it
    if not name:
        return None
    r = conn.execute("""SELECT h.id::text AS h FROM hosts h JOIN perm_scanners s ON s.host_id = h.id
                         WHERE lower(h.hostname) = lower(%s) OR lower(split_part(h.hostname, '.', 1)) = lower(%s)
                         ORDER BY h.hostname LIMIT 2""", (name, name)).fetchall()
    return r[0]["h"] if len(r) == 1 else None


def _share_info(conn, host_id, header, shares):
    """The share picker: every disk share the server has (the header lists them), when each was last scanned."""
    old = (conn.execute("SELECT share_info FROM perm_scanners WHERE host_id = %s", (host_id,)).fetchone() or {}).get("share_info") or {}
    names = header.get("all_shares")
    if not isinstance(names, list):                        # scanner 1.0.0: the shares it was told about, and the ones scanned
        names = list(old) + [s.get("name") for s in shares if s.get("name") and s.get("name") not in old]
    when = header.get("started")
    info = {}
    for n in [str(x)[:80] for x in names[:500] if str(x).strip()]:
        info[n] = dict(old.get(n) or {})
    for s in shares:
        n = str(s.get("name") or "")[:80]
        if n:
            info.setdefault(n, {}).update({"path": str(s.get("path") or "")[:600], "scanned_at": when})
    conn.execute("UPDATE perm_scanners SET share_info = %s::jsonb, shares = %s WHERE host_id = %s",
                 (json.dumps(info), sorted(info, key=str.lower), host_id))


class _ChunkWriter(io.RawIOBase):
    """A file written straight into perm_chunks, a piece at a time (never whole in memory)."""
    def __init__(self, conn, ds_id, piece):
        super().__init__()
        self.conn, self.ds, self.piece = conn, ds_id, piece
        self.buf, self.seq, self.off = bytearray(), 0, 0

    def writable(self):
        return True

    def write(self, b):
        self.buf += b
        while len(self.buf) >= self.piece:
            self._put(bytes(self.buf[:self.piece]))
            del self.buf[:self.piece]
        return len(b)

    def _put(self, data):
        self.conn.execute("INSERT INTO perm_chunks (dataset_id, seq, offset_b, data) VALUES (%s, %s, %s, %s)",
                          (self.ds, self.seq, self.off, data))
        self.seq += 1
        self.off += len(data)

    def close(self):
        if self.buf:
            self._put(bytes(self.buf))
            self.buf = bytearray()
        super().close()


def _folder_rec(rec):
    return {k: v for k, v in rec.items() if k != "t"}


def prepare(conn, ds_id, open_file, piece):
    """Before a scanner file is read: a full scan becomes the server's picture; a change-only scan is applied to the
    picture and replaced by the complete file. Returns the scan as read_scan gives it (of the file now in place)."""
    from .perm_review import PermError, bulk_insert
    scan = read_scan(open_file)
    h = scan["header"] or {}
    mode = h.get("mode") or "full"
    if mode == "assembled":                                # already built (the worker restarted while reading it)
        return scan
    host = _host_of(conn, ds_id, h)
    sig = signature(h.get("options"))
    uid = str(h.get("scan_uid") or "")[:80] or None
    if mode == "delta":
        st = conn.execute("""SELECT state_scan, state_options, full_next FROM perm_scanners WHERE host_id = %s FOR UPDATE""",
                          (host,)).fetchone() if host else None
        why = None
        if not st:
            why = "PATCH-01 has no earlier scan of this server"
        elif st["full_next"]:
            why = "PATCH-01 asked for a full scan"
        elif not h.get("base") or st["state_scan"] != h.get("base"):
            why = "it was made against a scan PATCH-01 does not have as the latest (a scan in between failed or was removed)"
        elif signature(st["state_options"]) != sig:
            why = "its shares or depths differ from the last full scan"
        if why:
            if host:
                conn.execute("UPDATE perm_scanners SET full_next = true WHERE host_id = %s", (host,))
                conn.commit()
            raise PermError(f"This scan holds only the changes, and {why}: it cannot be used. The next scan of this server is "
                            "a full one (Scan now, or access-scan.ps1 -Upload).")
    changes = {"changed": 0, "gone": 0, "mode": mode}
    if mode == "full" and host:
        conn.execute("DELETE FROM perm_scan_folders WHERE host_id = %s", (host,))
    if host:
        batch, seen = [], set()
        sysd = system_drive(h)
        for rec in _lines(open_file):
            if rec["t"] == "folder" and on_drive(rec, sysd):
                continue                                   # r127: the system drive is left out
            if rec["t"] == "folder":
                key = str(rec.get("unc") or rec.get("path") or "").lower()
                if not key or (mode == "full" and key in seen):
                    continue                               # a folder twice (a share inside a scanned folder): kept once
                seen.add(key)
                if mode == "delta":
                    conn.execute("""INSERT INTO perm_scan_folders (host_id, unc_l, rec) VALUES (%s, %s, %s::jsonb)
                                    ON CONFLICT (host_id, unc_l) DO UPDATE SET rec = EXCLUDED.rec""",
                                 (host, key, json.dumps(_folder_rec(rec))))
                else:
                    batch.append((host, key, json.dumps(_folder_rec(rec))))
                    if len(batch) >= 5000:
                        bulk_insert(conn, "perm_scan_folders", ("host_id", "unc_l", "rec"), batch)
                        batch = []
                changes["changed"] += 1
            elif rec["t"] == "gone" and mode == "delta":
                key = str(rec.get("unc") or rec.get("path") or "").lower()
                conn.execute("DELETE FROM perm_scan_folders WHERE host_id = %s AND unc_l = %s", (host, key))
                changes["gone"] += 1
        bulk_insert(conn, "perm_scan_folders", ("host_id", "unc_l", "rec"), batch)
        conn.execute("""UPDATE perm_scanners SET state_scan = %s, state_options = %s::jsonb, state_shares = %s, state_at = now(),
                               full_next = false, pending_scan = CASE WHEN pending_scan = %s THEN NULL ELSE pending_scan END
                         WHERE host_id = %s""",
                     (uid, json.dumps(sig), [s.get("name") for s in scan["shares"]][:500], uid, host))
        _share_info(conn, host, h, scan["shares"])
        conn.execute("""UPDATE perm_scans SET mode = %s, changes = %s::jsonb WHERE dataset_id = %s""",
                     (mode, json.dumps(changes), ds_id))
    elif mode == "delta":
        raise PermError("This scan holds only the changes, and PATCH-01 cannot tell which server it is from.")
    if mode == "full":
        conn.commit()
        return scan
    # the complete file, from the picture: what the change-only file had (shares, accounts, members, folders it
    # could not read) and every folder PATCH-01 has for the server
    conn.execute("DELETE FROM perm_chunks WHERE dataset_id = %s", (ds_id,))
    w = _ChunkWriter(conn, ds_id, piece)
    n = 0
    with gzip.GzipFile(fileobj=w, mode="wb", compresslevel=5) as g:
        def put(o):
            nonlocal n
            n += 1
            g.write((json.dumps(o, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8"))
        hh = dict(h, mode="assembled", changes=changes)
        put(hh)
        for s in scan["shares"]:
            put(s)
        listed = entries = 0
        last = ""
        while True:
            rows = conn.execute("""SELECT unc_l, rec FROM perm_scan_folders WHERE host_id = %s AND unc_l > %s
                                    ORDER BY unc_l LIMIT 5000""", (host, last)).fetchall()
            if not rows:
                break
            for r in rows:
                rec = r["rec"] if isinstance(r["rec"], dict) else json.loads(r["rec"])
                put(dict({"t": "folder"}, **rec))
                listed += 1
                entries += len(rec.get("aces") or [])
            last = rows[-1]["unc_l"]
        for e in scan["errors"]:
            put({"t": "error", "path": e["path"], "error": e["error"]})
        for g_ in scan["groups"].values():
            put(g_)
        for i in scan["ids"].values():
            put(i)
        end = dict(scan["end"] or {})
        counts = dict(end.get("counts") or {})
        counts.update({"lines": n + 1, "folders_listed": listed, "entries": entries, "changed": changes["changed"], "gone": changes["gone"]})
        end["counts"] = counts
        put(end)
    w.close()
    conn.execute("UPDATE perm_datasets SET size_bytes = %s, received = %s WHERE id = %s", (w.off, w.off, ds_id))
    conn.commit()
    return read_scan(open_file)
