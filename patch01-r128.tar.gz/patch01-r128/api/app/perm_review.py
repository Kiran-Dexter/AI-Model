"""Access review (r119): file and folder permissions, and which application and team owns them.

An admin uploads a permissions report as CSV, from whichever tool made it (NTFS Permissions
Reporter, Netwrix, Varonis, ManageEngine, PowerShell Get-Acl, ...). Then:

  1. Reading:  the worker reads it as it is: its encoding (UTF-8, UTF-16, Windows-1252), its
               separator, and where the header row is (a title above it is skipped).
  2. Columns:  rules that know these tools' column names, then AI-01 for the rest, propose which
               column is the path, the account, the permissions, and so on. The admin confirms.
  3. Rows:     each row is made plain by rules, never by AI-01: server, share, folder, account,
               the kind of account, the access level (from words, letters or an access mask),
               allow or deny, inherited or not.
  4. Tagging:  r124: right after the import the rules suggest each folder's owner (the NTFS owner when
               it is a person, else the one group or person given change rights on it directly) and
               department (the owner's, or that of most people who can change it), with a confidence
               and the evidence in numbers; AI-01 checks by itself the unsure ones (below 80%) and may
               only name accounts and departments in the evidence. AI-01 also proposes the application
               and owning team (from its path, the groups on it, its sub-folders, and what the admin
               confirmed before). Nothing
               it proposes counts as confirmed until an admin says so; confirmed tags are kept
               for the next upload. A tag covers the folder and everything under it.
  5. Reports:  AI-01 recommends which reports fit this file; the admin chooses step by step;
               every figure is counted by PostgreSQL from the rows. AI-01 then writes a short
               summary from those figures only.

AI-01 only ever sees column names, a few sample values, folder names and group names: never the
whole file, and it never counts.
"""
import codecs
import csv
import io
import json
import logging
import os
import re

log = logging.getLogger("patchapi.perm")

MAX_BYTES = 1024 * 2 ** 20          # 1 GB
MAX_ROWS = 3_000_000                # rows of one sheet of a report file
MAX_SCAN_ROWS = 10_000_000          # permission entries of one scanner file (r125: was 3,000,000 for the whole file)
MAX_COLS = 80
MAX_CELL = 2000
CHUNK = 16 * 2 ** 20
CHUNK_MAX = 32 * 2 ** 20
csv.field_size_limit(4 * 2 ** 20)

# ---- 1. reading (perm_read.py: CSV, .xlsx, .xls, HTML tables; encodings; cleaning) -------------------------

from .perm_read import (Cleaner, ENCODING_TEXT, bom_or_utf16, find_header, lines_from, plain,  # noqa: E402,F401
                        sniff_delimiter)


def clean_cell(v):
    return plain(v)


# ---- 2. columns ----------------------------------------------------------------------------------------

ROLES = [
    ("path", "Folder or file path", True),
    ("identity", "Account or group", True),
    ("rights", "Permissions (when missing: \u201cnot stated\u201d)", False),
    ("access_type", "Allow or deny", False),
    ("inherited", "Inherited", False),
    ("owner", "Owner of the folder", False),
    ("server", "Server", False),
    ("share", "Share", False),
    ("share_path", "The share's own folder (D:\\Shares\\Fin), when listed", False),
    ("domain", "Domain of the account, when in its own column", False),
    ("account_type", "Kind of account (user, group)", False),
    ("application", "Application (when the file has it)", False),
    ("team", "Owning team (when the file has it)", False),
]
ROLE_KEYS = [r[0] for r in ROLES]
REQUIRED = [r[0] for r in ROLES if r[2]]

# A sheet of drive information: the drive letters and where each points (r120)
DRIVE_ROLES = [
    ("drive", "Drive letter", True),
    ("target", "Where it points (\\\\server\\share)", False),
    ("server", "Server", False),
    ("label", "Label or description", False),
    ("owner", "Owner", False),
    ("application", "Application", False),
    ("team", "Owning team", False),
]
# A sheet of group members (per drive or not)
MEMBER_ROLES = [
    ("group", "Group", True),
    ("member", "Member", True),
    ("member_type", "Kind of member (user, group, computer)", False),
    ("drive", "Drive letter", False),
    ("department", "Department of the member", False),
]
# A sheet of people: user name and department (and title, manager...) (r122)
PEOPLE_ROLES = [
    ("person", "User name (the account)", True),
    ("department", "Department", True),
    ("display_name", "Full name", False),
    ("title", "Job title", False),
    ("manager", "Manager", False),
    ("location", "Location or office", False),
    ("email", "E-mail", False),
    ("enabled", "Account enabled", False),
    ("last_logon", "Last logon", False),
]
ROLESETS = {"permissions": ROLES, "drives": DRIVE_ROLES, "members": MEMBER_ROLES, "people": PEOPLE_ROLES}
SHEET_ROLE_TEXT = {"permissions": "Permissions", "drives": "Drive information", "members": "Group members",
                   "people": "People (user details)", "skip": "Not used"}
SHEET_NAME_ROLES = {"permissions": ("server", "share", "application", "team"), "drives": ("drive", "server", "label"),
                    "members": ("drive", "group", "department"), "people": ("department",)}

# Column names as these tools write them (lower case, letters and digits only)
SYNONYMS = {
    "path": ["path", "folderpath", "objectpath", "fullpath", "folder", "directory", "directorypath", "dir", "resource",
             "resourcepath", "location", "filepath", "sharepath", "uncpath", "object", "objectname", "foldername", "item",
             "itempath", "fullname", "filesystempath",
             "pfad", "ordner", "ordnerpfad", "chemin", "dossier", "ruta", "carpeta", "percorso", "cartella", "pad", "map"],
    "identity": ["account", "accountname", "identity", "identityreference", "trustee", "trusteename", "user", "username",
                 "principal", "principalname", "securityprincipal", "group", "groupname", "member", "accountdisplayname",
                 "samaccountname", "who", "name", "useraccount", "userorgroup", "usergroup", "accountorgroup",
                 "benutzer", "konto", "benutzergruppe", "utilisateur", "compte", "usuario", "cuenta", "utente", "gebruiker"],
    "rights": ["permissions", "permission", "rights", "accessrights", "filesystemrights", "access", "accessmask",
               "permissionlevel", "effectivepermissions", "accesslevel", "perms", "ntfspermissions", "folderpermissions",
               "permissionsgranted", "accesspermissions",
               "berechtigung", "berechtigungen", "rechte", "droits", "autorisations", "permisos", "permessi", "rechten", "machtigingen"],
    "access_type": ["accesscontroltype", "accesstype", "permissiontype", "allowdeny", "acetype", "type", "accesscontrol",
                    "allowordeny", "grantdeny"],
    "inherited": ["inherited", "isinherited", "inheritance", "inheritedfrom", "inherit", "inheritedpermission",
                  "explicitorinherited", "inheritancetype",
                  "vererbt", "geerbt", "herite", "heredado", "ereditato", "overgenomen"],
    "owner": ["owner", "folderowner", "objectowner", "fileowner"],
    "server": ["server", "servername", "host", "hostname", "computer", "computername", "fileserver", "machine", "device",
               "devicename", "nasname", "filer"],
    "share": ["share", "sharename", "sharedfolder", "netshare"],
    "share_path": ["sharelocalpath", "sharerootpath", "sharerootfolder", "localsharepath", "sharefolderpath", "sharedpath",
                   "sharelocation", "rootpath", "sharepathlocal"],
    "domain": ["domain", "domainname", "netbiosdomain", "accountdomain", "trusteedomain", "userdomain"],
    "account_type": ["accounttype", "objecttype", "objectclass", "principaltype", "trusteetype", "accountclass",
                     "identitytype", "usertype", "type"],
    "application": ["application", "app", "appname", "applicationname", "system", "service", "businessapplication"],
    "team": ["team", "ownerteam", "owningteam", "appowner", "applicationowner", "department", "businessowner",
             "dataowner", "supportteam", "resolvergroup"],
}


SYNONYMS_DRIVES = {
    "drive": ["drive", "driveletter", "letter", "drv", "mappeddrive", "mapdrive", "volume", "volumeletter", "mountpoint",
              "drivename", "localdrive", "networkdrive"],
    "target": ["target", "path", "uncpath", "unc", "mappedto", "mappedpath", "remotepath", "sharepath", "networkpath",
               "location", "pointsto", "share", "sharename", "providername", "remotename"],
    "server": SYNONYMS["server"],
    "label": ["label", "volumelabel", "description", "desc", "name", "drivelabel", "purpose", "comment", "displayname"],
    "owner": ["owner", "driveowner", "dataowner", "contact", "custodian"],
    "application": SYNONYMS["application"],
    "team": SYNONYMS["team"],
}
SYNONYMS_MEMBERS = {
    "group": ["group", "groupname", "adgroup", "securitygroup", "parentgroup", "groupsamaccountname", "memberof",
              "groupdisplayname", "distributiongroup", "role"],
    "member": ["member", "membername", "members", "user", "username", "account", "accountname", "samaccountname",
               "userprincipalname", "upn", "displayname", "employee", "login", "userid", "memberaccount"],
    "member_type": ["membertype", "objectclass", "objecttype", "type", "accounttype", "memberclass", "class", "kind"],
    "drive": SYNONYMS_DRIVES["drive"],
}
DEPT_WORDS = ["department", "dept", "departmentname", "deptname", "division", "businessunit", "bu", "orgunit", "organisation",
              "organization", "org", "function", "costcenter", "costcentre", "team", "teamname", "unit", "section", "group department",
              "abteilung", "departement", "departamento", "reparto", "afdeling", "service"]
SYNONYMS_MEMBERS["department"] = DEPT_WORDS
SYNONYMS_PEOPLE = {
    "person": ["username", "user", "samaccountname", "account", "accountname", "login", "loginname", "logonname", "userid",
               "userlogonname", "userprincipalname", "upn", "networkid", "windowsid", "adaccount", "userlogin", "member",
               "membername", "benutzer", "benutzername", "utilisateur", "usuario", "utente", "gebruiker"],
    "department": DEPT_WORDS,
    "display_name": ["displayname", "fullname", "name", "employeename", "employee", "cn", "commonname", "personname",
                     "staffname", "firstnamelastname"],
    "title": ["title", "jobtitle", "position", "designation", "role", "jobrole"],
    "manager": ["manager", "managername", "reportsto", "linemanager", "supervisor", "lead"],
    "location": ["location", "office", "site", "city", "country", "physicaldeliveryofficename", "building", "region"],
    "email": ["email", "mail", "emailaddress", "smtp", "smtpaddress", "primaryemail", "workemail"],
    "enabled": ["enabled", "accountenabled", "isenabled", "active", "status", "accountstatus"],
    "last_logon": ["lastlogon", "lastlogondate", "lastlogontimestamp", "lastsignin", "lastlogin", "lastseen"],
}
SYNONYMS_BY = {"permissions": SYNONYMS, "drives": SYNONYMS_DRIVES, "members": SYNONYMS_MEMBERS, "people": SYNONYMS_PEOPLE}
DRIVE_RE = re.compile(r"^\s*([A-Za-z]):?\\?\s*$")


def drive_of(text):
    """'H', 'h:', 'H:\\' -> 'H:'; also from a sheet's name: 'H Drive', 'Drive H', 'H-Drive members' -> 'H:'."""
    t = (text or "").strip()
    m = DRIVE_RE.match(t)
    if m:
        return m.group(1).upper() + ":"
    m = re.search(r"(?:^|[^a-z0-9])([a-z])(?::|\s*[-_ ]?\s*drive\b)", t, re.I) or re.search(r"\bdrive\s*[-_ ]?\s*([a-z])\b", t, re.I)
    return m.group(1).upper() + ":" if m else None


def _norm_header(h):
    return re.sub(r"[^a-z0-9]", "", (h or "").lower())


def _value_score(role, values):
    """How well a column's values fit a role: 0 none .. 3 sure."""
    vals = [v for v in values if v][:40]
    if not vals:
        return 0
    def share(pred):
        return sum(1 for v in vals if pred(v)) / len(vals)
    if role == "path":
        s = share(lambda v: bool(re.match(r"^(\\\\[^\\]+\\|[A-Za-z]:\\|/)", clean_path(v))))
        return 3 if s > 0.8 else 1 if s > 0.3 else 0
    if role == "share_path":
        s = share(lambda v: bool(re.match(r"^[A-Za-z]:\\|^/", clean_path(v))))
        return 3 if s > 0.8 else 0
    if role == "domain":
        s = share(lambda v: bool(re.fullmatch(r"[A-Za-z][\w.\- ]{0,62}", v)) and "\\" not in v)
        return 1 if s > 0.9 else 0
    if role == "identity":
        s = share(lambda v: bool(re.match(r"^([\w.\- ]+\\[\w.\-$ ]+|[\w.\-]+@[\w.\-]+|S-1-[\d-]+|everyone|authenticated users|"
                                          r"creator owner|system|[\w.\- $]{2,64})$", v, re.I)) and not re.match(r"^(\\\\|[A-Za-z]:\\)", v))
        return 2 if s > 0.8 else 0
    if role == "rights":
        s = share(lambda v: level_of(v) not in ("special", "none") or v.lower() in ("special", "special permissions"))
        return 3 if s > 0.7 else 1 if s > 0.3 else 0
    if role == "access_type":
        s = share(lambda v: v.strip().lower() in ("allow", "deny", "allowed", "denied", "grant", "granted"))
        return 3 if s > 0.9 else 0
    if role == "inherited":
        s = share(lambda v: bool_of(v) is not None)
        return 2 if s > 0.9 else 0
    if role == "drive":
        s = share(lambda v: bool(DRIVE_RE.match(v)))
        return 3 if s > 0.8 else 0
    if role == "target":
        s = share(lambda v: v.startswith("\\\\") or v.startswith("//"))
        return 3 if s > 0.8 else 0
    if role in ("group", "member"):
        s = share(lambda v: bool(re.match(r"^([\w.\- ]+\\[\w.\-$ ]+|[\w.\-]+@[\w.\-]+|[\w.\- $&()]{2,64})$", v))
                  and not re.match(r"^(\\\\|[A-Za-z]:\\?$)", v))
        if s <= 0.8:
            return 0
        distinct = len(set(v.lower() for v in vals)) / len(vals)
        if role == "group":
            return 2 if distinct < 0.7 else 1             # a group repeats down the sheet, once per member
        return 2
    if role == "person":
        s = share(lambda v: bool(re.match(r"^([\w.\- ]{1,64}\\[\w.\-$]{1,104}|[\w.\-]+@[\w.\-]+\.\w+|[\w.\-$]{2,64})$", v)))
        return 2 if s > 0.8 else 0                 # a person can be listed twice (two departments, two rows)
    if role == "department":
        s = share(lambda v: bool(re.fullmatch(r"[^\\/:@]{2,80}", v)) and not re.fullmatch(r"[\d.,]+", v))
        distinct = len(set(v.lower() for v in vals)) / len(vals)
        return 1 if s > 0.9 and (distinct < 0.7 or len(vals) < 4) else 0
    if role == "email":
        s = share(lambda v: bool(re.fullmatch(r"[\w.+\-']+@[\w\-]+(\.[\w\-]+)+", v)))
        return 3 if s > 0.8 else 0
    if role == "display_name":
        s = share(lambda v: bool(re.fullmatch(r"[^\\/@\d]{2,80}", v)) and " " in v.strip())
        return 1 if s > 0.7 else 0
    if role in ("account_type", "member_type"):
        s = share(lambda v: any(w in v.lower() for w in ("user", "group", "computer", "well-known", "wellknown", "alias")))
        return 2 if s > 0.8 else 0
    return 1


def rule_mapping(headers, rows, roleset="permissions"):
    """Which column is which, by the names these tools use and by what the values look like.
    {role: {"col": index, "score": n, "why": text}}; each column is used for one role at most."""
    cols = {i: [r[i] if i < len(r) else "" for r in rows] for i in range(len(headers))}
    syn = SYNONYMS_BY[roleset]
    cand = []
    for role in [r[0] for r in ROLESETS[roleset]]:
        for i, h in enumerate(headers):
            n = _norm_header(h)
            name = 3 if n in syn[role] else 2 if any(n.endswith(x) or n.startswith(x) for x in syn[role] if len(x) > 3) else 0
            vs = _value_score(role, cols[i])
            if role in ("path", "rights", "access_type", "inherited", "drive", "target", "share_path", "domain", "email",
                        "person", "department") and name and not vs:
                name = 0                              # a name alone is not enough when the values say otherwise
            score = name * 2 + vs
            if score >= 3:
                cand.append((score, role, i, f"column \"{h}\": " + ("its name" if name else "") +
                             (" and " if name and vs else "") + ("its values" if vs else "")))
    out, used = {}, set()
    for score, role, i, why in sorted(cand, key=lambda x: -x[0]):
        if role in out or i in used:
            continue
        out[role] = {"col": i, "score": score, "why": why}
        used.add(i)
    return out


def mapping_messages(headers, rows, roleset="permissions"):
    """What AI-01 is shown to map the columns: each column's name and up to five sample values (fewer and shorter
    for a wide sheet, so the question fits AI-01's slot whole)."""
    def build(nv, ln):
        cols = []
        for i, h in enumerate(headers[:MAX_COLS]):
            vals = []
            for r in rows:
                v = (r[i] if i < len(r) else "").strip()
                if v and v[:ln] not in vals:
                    vals.append(v[:ln])
                if len(vals) >= nv:
                    break
            cols.append({"column": h[:80], "samples": vals})
        return cols
    for nv, ln in ((5, 60), (3, 40), (2, 30), (1, 24), (0, 0)):
        cols = build(nv, ln)
        if len(json.dumps(cols)) / CHARS_PER_TOKEN <= prompt_budget(500) - 300:
            break
    roles = {k: label for k, label, _ in ROLESETS[roleset]}
    what = {"permissions": "a file and folder permissions report", "drives": "a sheet of drive information (drive letters)",
            "members": "a sheet of group members", "people": "a sheet of people (user name, department, ...)"}[roleset]
    return [
        {"role": "system", "content": f"You map the columns of {what} to fields. "
         "Answer only with JSON. For each field give the exact column name that holds it, or an empty string when no "
         "column does. Never invent a column name. Use a column for one field at most."},
        {"role": "user", "content": "Fields: " + json.dumps(roles) + "\nColumns with sample values: " + json.dumps(cols)},
    ]


def mapping_schema(headers, roleset="permissions"):
    names = [h[:80] for h in headers[:MAX_COLS]] + [""]
    keys = [r[0] for r in ROLESETS[roleset]]
    return {"type": "object", "properties": {k: {"type": "string", "enum": names} for k in keys}, "required": keys}


SHEET_SYSTEM = """You sort the sheets of a workbook exported by a file-permissions tool. For each sheet you are given its name,
its column names and a few sample rows. Say what the sheet holds:
  "permissions"  rows of who has access to which folder, file or drive (a path or drive, an account, maybe the rights)
  "drives"       information about drive letters: where each drive points, its label, owner (no accounts per row)
  "members"      group membership: a group and its members, one member per row (maybe per drive)
  "people"       details of people: a user name with a department (maybe title, manager, location, e-mail), no access rights
  "skip"         anything else: a summary, totals, charts, notes, settings
Answer only with JSON. Never invent a sheet."""
SHEET_SCHEMA = {"type": "object", "properties": {"role": {"type": "string", "enum": ["permissions", "drives", "members", "people", "skip"]},
                                                 "why": {"type": "string"}}, "required": ["role", "why"]}


def sheet_messages(name, headers, rows):
    cols = mapping_messages(headers, rows)[1]["content"].split("Columns with sample values: ", 1)[1]
    return [{"role": "system", "content": SHEET_SYSTEM},
            {"role": "user", "content": json.dumps({"sheet": name[:80]}) + "\nColumns with sample values: " + cols}]


def rule_role(name, headers, rows):
    """(role, sure, why, {roleset: rule mapping}) by the rules alone."""
    perm = rule_mapping(headers, rows, "permissions")
    drv = rule_mapping(headers, rows, "drives")
    mem = rule_mapping(headers, rows, "members")
    ppl = rule_mapping(headers, rows, "people")
    rules = {"permissions": perm, "drives": drv, "members": mem, "people": ppl}
    if "path" in perm and "identity" in perm:
        sure = perm["path"]["score"] >= 5 and perm["identity"]["score"] >= 4
        return "permissions", sure, "a path and an account on each row" + (" with the rights" if "rights" in perm else ""), rules
    if "group" in mem and "member" in mem:
        sure = mem["group"]["score"] >= 6 and mem["member"]["score"] >= 6
        return "members", sure, f"a group (\u201c{headers[mem['group']['col']]}\u201d) and its members on each row", rules
    if "person" in ppl and "department" in ppl:
        sure = ppl["person"]["score"] >= 6 and ppl["department"]["score"] >= 5
        return "people", sure, (f"a person (\u201c{headers[ppl['person']['col']]}\u201d) and a department "
                                f"(\u201c{headers[ppl['department']['col']]}\u201d) on each row"), rules
    if "drive" in drv and ("member" in mem or "identity" in perm):
        # a drive and an account on each row: who has the drive (a permissions list with the drive as the path)
        acc = mem.get("member") or perm.get("identity")
        rules["permissions"] = {"path": dict(drv["drive"], why=drv["drive"]["why"] + " (the drive is the path)"),
                                "identity": acc}
        for k in ("rights", "access_type", "inherited", "account_type", "server"):
            if k in perm and perm[k]["col"] not in (drv["drive"]["col"], acc["col"]):
                rules["permissions"][k] = perm[k]
        return "permissions", False, "a drive letter and an account on each row: who has access to each drive", rules
    if "drive" in drv:
        return "drives", drv["drive"]["score"] >= 6, "drive letters" + (" and where they point" if "target" in drv else ""), rules
    return "skip", False, "no path, account, drive letter or group found", rules


def merge_mapping(headers, rule, ai, roleset="permissions"):
    """The proposal: a sure rule wins; AI-01 fills what the rules could not tell, only with a
    column that exists and is not used yet. {role: {"col", "by", "why"}}."""
    out, used = {}, set()
    for role, r in rule.items():
        if r["score"] >= 5:
            out[role] = {"col": r["col"], "by": "rules", "why": r["why"]}
            used.add(r["col"])
    idx = {h[:80]: i for i, h in enumerate(headers)}
    for role in [r[0] for r in ROLESETS[roleset]]:
        if role in out:
            continue
        name = (ai if isinstance(ai, dict) else {}).get(role) or ""
        name = name if isinstance(name, str) else ""
        if name in idx and idx[name] not in used:
            out[role] = {"col": idx[name], "by": "AI-01", "why": f"AI-01 read column \"{name}\" as {role.replace('_', ' ')}"}
            used.add(idx[name])
        elif role in rule and rule[role]["col"] not in used:
            out[role] = {"col": rule[role]["col"], "by": "rules", "why": rule[role]["why"]}
            used.add(rule[role]["col"])
    return out


def check_mapping(mapping, headers, roleset="permissions", sheet=None):
    """An admin's mapping: {role: column index or None}; the index len(headers) is the sheet's own
    name (for the roles that can take it). Returns the clean mapping, or PermError."""
    if not isinstance(mapping, dict):
        raise PermError("The mapping must say which column holds what.")
    where = f"Sheet \u201c{sheet}\u201d: " if sheet else ""
    roles = ROLESETS[roleset]
    out, used = {}, {}
    for role in [r[0] for r in roles]:
        v = mapping.get(role)
        if v is None or v == "":
            continue
        try:
            i = int(v)
        except (TypeError, ValueError):
            raise PermError(f"{role}: not a column.")
        if i == len(headers) and role in SHEET_NAME_ROLES.get(roleset, ()):
            out[role] = i                            # the sheet's name
            continue
        if not 0 <= i < len(headers):
            raise PermError(f"{where}{role}: there is no column {i + 1}.")
        if i in used:
            raise PermError(f"{where}column \"{headers[i]}\" is chosen for both {used[i]} and {role}: one field per column.")
        used[i] = role
        out[role] = i
    missing = [label for k, label, req in roles if req and k not in out]
    if missing:
        raise PermError(where + "choose the column for: " + ", ".join(missing) + ".")
    return out


# ---- 3. rows made plain -----------------------------------------------------------------------------------

LEVELS = ["none", "unstated", "special", "list", "read", "read_execute", "write", "modify", "full"]
RANK = {lv: i for i, lv in enumerate(LEVELS)}
LEVEL_TEXT = {"full": "Full control", "modify": "Modify", "write": "Write", "read_execute": "Read & execute",
              "read": "Read", "list": "List folder", "special": "Special", "unstated": "Not stated in the file", "none": "None"}


def rank_sql(col):
    """SQL: an entry's level as its rank (LEVELS order), to take the highest with max()."""
    return "CASE " + col + " " + " ".join(f"WHEN '{lv}' THEN {i}" for i, lv in enumerate(LEVELS)) + " ELSE 0 END"
WRITE_LEVELS = ("write", "modify", "full")

WORDS = [  # (pattern on the squeezed text, level); the highest found wins
    (r"fullcontrol|^full$|^fullaccess$|^fc$|genericall|changepermissions|takeownership|writedac|writeowner", "full"),
    (r"modify|^change$", "modify"),
    (r"write|createfiles|createdirectories|appenddata|writedata|genericwrite|^delete", "write"),
    (r"readandexecute|read&execute|readexecute|executefile|traverse|genericexecute", "read_execute"),
    (r"read|genericread|readdata|readattributes|readpermissions", "read"),
    (r"list|listdirectory|listfolder", "list"),
    (r"special|synchronize", "special"),
    (r"^noaccess$|^none$|^noaccessrights$|^denyall$", "none"),
]
LETTERS = {"f": "full", "m": "modify", "w": "write", "x": "read_execute", "r": "read", "l": "list"}


def level_of_mask(m):
    if m & 0x10000000 or (m & 0x1F01FF) == 0x1F01FF or m & 0x40000 or m & 0x80000:
        return "full"                                  # all rights, or can change permissions or take ownership
    if m & 0x10000 and m & 0x2 and m & 0x1:
        return "modify"
    if m & (0x2 | 0x4 | 0x40000000):
        return "write"
    if (m & 0x20 and m & 0x1) or m & 0x20000000:
        return "read_execute"
    if m & (0x1 | 0x80000000):
        return "read"
    if m & 0x20:
        return "list"
    return "special" if m else "none"


# icacls letters (the inheritance flags OI CI IO NP I carry no rights)
ICACLS = {"F": "full", "GA": "full", "WDAC": "full", "WO": "full", "M": "modify", "RX": "read_execute", "GE": "read_execute",
          "X": "read_execute", "R": "read", "GR": "read", "RD": "read", "REA": "read", "RA": "read", "RC": "read", "S": "list",
          "W": "write", "GW": "write", "WD": "write", "AD": "write", "WEA": "write", "WA": "write", "D": "write", "DE": "write",
          "DC": "write", "N": "none"}


def level_of(text):
    """The access level of one entry, from the words, letters or access mask a tool writes."""
    t = (text or "").strip()
    if not t:
        return "none"
    if re.fullmatch(r"-?\d{1,10}", t):
        return level_of_mask(int(t) & 0xFFFFFFFF)
    if re.fullmatch(r"0x[0-9a-fA-F]{1,8}", t):
        return level_of_mask(int(t, 16))
    if re.fullmatch(r"(\([A-Z,]+\))+", t.replace(" ", "")):                     # icacls: (OI)(CI)(M), (I)(RX), (R,W)
        lv = None
        for tok in re.findall(r"[A-Z]+", t):
            got = ICACLS.get(tok)
            if got and (lv is None or RANK[got] > RANK[lv]):
                lv = got
        return lv or "special"
    if re.fullmatch(r"[FMRWXLfmrwxl]{1,6}", t) and t.isupper():
        return max((LETTERS[c.lower()] for c in t), key=lambda lv: RANK[lv])
    bits = [b.strip() for b in re.split(r"[,;|/+ ]+", t) if b.strip()]
    if bits and all(len(b) == 1 and b.isupper() and b.lower() in LETTERS for b in bits):     # R/W, R W X
        return max((LETTERS[b.lower()] for b in bits), key=lambda lv: RANK[lv])
    best = None
    for part in re.split(r"[,;|/+]", t):
        sq = re.sub(r"[\s_\-()]", "", part.lower())
        if not sq:
            continue
        for pat, lv in WORDS:
            if re.search(pat, sq):
                if best is None or RANK[lv] > RANK[best]:
                    best = lv
                break
    return best or "special"


def bool_of(v):
    t = (v or "").strip().strip("<>()[]").strip().lower()
    if t.startswith(("not inherited", "not-inherited", "noninherited", "non-inherited", "no inherit")):
        return False
    if t.startswith(("explicit", "direct", "this folder only", "this object only", "set directly", "set here")):
        return False
    if t.startswith("inherit") or t.startswith("parent") or t.endswith("(parent)"):
        return True
    if t in ("ja", "oui", "si", "s\u00ed", "wahr", "vrai", "verdadero", "vero", "waar", "geerbt", "vererbt", "h\u00e9rit\u00e9", "heredado"):
        return True
    if t in ("nein", "non", "falsch", "faux", "falso", "nee", "onwaar", "explizit", "explicite", "expl\u00edcito"):
        return False
    if t in ("true", "yes", "y", "1", "inherited", "inherit", "parent") or t.startswith("inherited from") or t.startswith("yes"):
        return True
    if t in ("false", "no", "n", "0", "explicit", "direct", "not inherited", "this folder only", "none", "explicitly assigned",
             "explicit permission"):
        return False
    if t.startswith("\\\\") or re.match(r"^[a-z]:\\", t):
        return True                                    # "inherited from" written as the parent's path
    return None


def allow_of(v):
    t = (v or "").strip().lower()
    if t.startswith("deny") or t.startswith("denied"):
        return False
    return True


SYSTEM_NAMES = {"system", "nt authority\\system", "creator owner", "creator group", "local system", "trustedinstaller",
                "nt service\\trustedinstaller", "owner rights", "nt authority\\local service", "nt authority\\network service"}
ADMIN_NAMES = {"administrators", "builtin\\administrators", "domain admins", "enterprise admins", "backup operators",
               "builtin\\backup operators", "server operators", "builtin\\server operators", "schema admins"}
BROAD_NAMES = {"everyone", "authenticated users", "nt authority\\authenticated users", "users", "builtin\\users",
               "domain users", "domain computers", "guests", "builtin\\guests", "domain guests", "anonymous logon",
               "nt authority\\anonymous logon", "network", "nt authority\\network", "interactive",
               "nt authority\\interactive", "all users", "world"}
GROUP_NAME_RE = re.compile(r"^(grp|gg|sg|dl|lg|ug|gs|gl|acl|fs|role|sec|app)[_\-. ]|[_\-. ](rw|ro|mod|modify|read|write|"
                           r"readonly|readwrite|full|fc|owners?|members?|users|admins|group|grp|team|editors|readers|viewers)$|"
                           r"\bgroup\b", re.I)


ACCOUNT_IN = r"(?:[\w.\- ]{1,64}\\[\w.\-$ ]{1,104}|[\w.\-]+@[\w.\-]+\.\w+)"


def norm_identity(v):
    """An account as tools write it -> the account: quotes and trailing punctuation off,
    "John Smith (CORP\\jsmith)" -> CORP\\jsmith, "CORP\\jsmith (John Smith)" -> CORP\\jsmith."""
    t = re.sub(r"\s+", " ", (v or "").strip()).strip('"').strip("'").strip().rstrip(";,").strip()
    m = re.fullmatch(r"[^()\\]{1,120}\((" + ACCOUNT_IN + r")\)", t)
    if m:
        return m.group(1).strip()[:300]
    m = re.fullmatch(r"(" + ACCOUNT_IN + r")\s+\([^()]{1,120}\)", t)
    if m and not re.search(r"S-1-\d", t):
        return m.group(1).strip()[:300]
    return t[:300]


def identity_kind(identity, account_type=None):
    """(kind, how it was told). Known built-in names first; then the file's own account type
    column; then a group's usual name; else 'unknown' (never a guess)."""
    low = identity.lower()
    short = low.split("\\", 1)[1] if "\\" in low else low
    if re.fullmatch(r"s-1-5-21(-\d+){3,5}", low) or "account unknown" in low or "unknown account" in low or \
            "(unresolved)" in low or "deleted account" in low:
        return "orphan", "rule"
    if low in SYSTEM_NAMES or low.startswith("nt service\\") or short in ("system", "creator owner", "creator group"):
        return "system", "rule"
    if low in ADMIN_NAMES or short in ADMIN_NAMES:
        return "admin", "rule"
    if low in BROAD_NAMES or short in ("everyone", "authenticated users", "domain users", "domain computers", "users",
                                       "guests", "domain guests", "anonymous logon"):
        return "broad", "rule"
    at = (account_type or "").strip().lower()
    if at:
        if "everyone" in at or "broad" in at:                 # the scanner's "Everyone-type group" (any language)
            return "broad", "column"
        if "orphan" in at:
            return "orphan", "column"
        if at in ("system account", "system"):
            return "system", "column"
        if "computer" in at or "machine" in at:
            return "computer", "column"
        if "group" in at or "alias" in at or "well" in at:
            return "group", "column"
        if "user" in at or "person" in at or "account" == at:
            return "user", "column"
    if low.endswith("$"):
        return "computer", "rule"
    if GROUP_NAME_RE.search(short):
        return "group", "name"
    return "unknown", "rule"


PROVIDER_RE = re.compile(r"^\s*(?:Microsoft\.PowerShell\.Core\\)?FileSystem::", re.I)


def clean_path(p):
    """A path as tools write it -> a plain path: PowerShell's provider prefix
    (Microsoft.PowerShell.Core\\FileSystem::\\\\fs\\a), file: URLs, quotes."""
    t = (p or "").strip().strip('"').strip("'")
    t = PROVIDER_RE.sub("", t)
    m = re.match(r"^file:/*(.*)$", t, re.I)
    if m:
        rest = m.group(1).replace("/", "\\")
        t = rest if re.match(r"^[A-Za-z]:", rest) else "\\\\" + rest.lstrip("\\")
    return t


def split_path(path, server_col=None, share_col=None):
    """(server, share, parts below the share, display path, style). UNC \\\\server\\share\\a\\b,
    a drive path D:\\a\\b (server from its column), or a Linux path /srv/a/b."""
    path = clean_path(path)
    p = path.replace("/", "\\") if not path.startswith("/") else path
    server, share = (server_col or "").strip() or None, (share_col or "").strip() or None
    if p.startswith("\\\\?\\UNC\\"):
        p = "\\\\" + p[8:]
    elif p.startswith("\\\\?\\"):
        p = p[4:]
    if p.startswith("\\\\"):
        bits = [b for b in p[2:].split("\\") if b]
        server = bits[0] if bits else server
        share = bits[1] if len(bits) > 1 else share
        parts = bits[2:]
        disp = "\\\\" + "\\".join(bits)
        style = "unc"
    elif re.match(r"^[A-Za-z]:\\?", p):
        bits = [b for b in p.split("\\") if b]
        share = bits[0].upper().rstrip("\\")
        parts = bits[1:]
        disp = ((server + " ") if server else "") + "\\".join([share] + parts)
        style = "drive"
    elif p.startswith("/"):
        bits = [b for b in p.split("/") if b]
        share = "/" + bits[0] if bits else "/"
        parts = bits[1:]
        disp = ((server + ":") if server else "") + p
        style = "posix"
    else:
        bits = [b for b in p.split("\\") if b]
        parts = bits
        disp = ((server + " ") if server else "") + p
        style = "plain"
    return server, share, parts, disp, style


def folder_key(server, share, parts, depth, style="unc"):
    """The unit tagged with an application: the share (or drive) and `depth` folder levels below
    it. (key in lower case, label as written). A tag on it covers everything under it."""
    below = list(parts[:depth])
    if style == "unc" and server:
        label = "\\\\" + "\\".join([server] + ([share] if share else []) + below)
    elif style == "drive":
        label = ((server + " ") if server else "") + "\\".join([share] + below) + ("" if below else "\\")
    elif style == "posix":
        label = ((server + ":") if server else "") + share + "".join("/" + b for b in below)
    else:
        label = ((server + " ") if server else "") + "\\".join(below or ["(no folder)"])
    return label.lower(), label


def ident_key(v):
    """An account's short name in lower case: CORP\\GG_X, gg_x@corp.com and GG_X are one account.
    (Two domains with the same short name would be taken as one: rare in one company's file servers.)"""
    t = (v or "").strip().strip('"').lower()
    if "\\" in t:
        t = t.rsplit("\\", 1)[1]
    if "@" in t and not t.startswith("@"):
        t = t.split("@", 1)[0]
    return t[:300]


class Context:
    """What the other sheets tell about the permission rows: where each drive letter points, which
    accounts are groups (they have members), and the kind of each member."""
    def __init__(self):
        self.targets = {}        # (server lower or "", "H:") -> set of targets (\\server\share\...)
        self.groups = set()      # short keys of the groups a members sheet lists
        self.member_kind = {}    # short key -> kind a members sheet states (from its type column)
        self.resolved = 0
        self.ambiguous = set()
        self.share_roots = {}    # (server lower, share lower) -> the share's own folder: [parts], from its column or the paths

    def target_for(self, server, drive):
        for key in ((server or "").lower(), ""):
            t = self.targets.get((key, drive))
            if t is not None:
                if len(t) == 1:
                    return next(iter(t))
                self.ambiguous.add(drive)
                return None
        return None


SYSTEM_DRIVE = "C"


def on_system_drive(e):
    """A folder on the system drive: a local C: path, or the C$ admin share. In a report file the server's own
    system drive is not written, so C: is taken (the scanner reads the server's own)."""
    p = (e.get("path") or "").upper()
    return p.startswith(SYSTEM_DRIVE + ":\\") or p == SYSTEM_DRIVE + ":" or (e.get("share") or "").upper() == SYSTEM_DRIVE + "$"


def entry_from(cells, m, depth, ctx=None, sheet_name=None):
    """One raw row -> a plain entry, or None (no path or no account: not an entry). The mapping's
    index len(cells) is the sheet's name."""
    def get(role):
        i = m.get(role)
        if i is None:
            return ""
        if i == m.get("_name_at", -1):
            return clean_cell(sheet_name)
        return clean_cell(cells[i]) if i < len(cells) else ""
    path_raw = get("path")
    path, ident = clean_path(path_raw), norm_identity(get("identity"))
    if not path or not ident:
        return None
    dom = get("domain")
    if dom and "\\" not in ident and "@" not in ident and not ident.upper().startswith("S-1-"):
        ident = dom + "\\" + ident                                # Varonis and others: CORP | jsmith -> CORP\jsmith
    server_col = get("server")
    share_col = get("share")
    if share_col and re.match(r"^[A-Za-z]:(\\|$)", path):
        # a local path with its share named: \\server\share\<the rest below the share's own folder>
        root = split_path(get("share_path"))[2] if get("share_path") else (ctx.share_roots.get(((server_col or "").lower(),
                                                                                                 share_col.lower())) if ctx else None)
        if root is not None and server_col:
            parts = [b for b in path.split("\\") if b]
            drive = parts[0].upper()
            rparts = [b for b in clean_path(get("share_path")).split("\\") if b] if get("share_path") else None
            rootp = [x.lower() for x in (rparts[1:] if rparts else root)]
            rdrive = (rparts[0].upper() if rparts else drive)
            low = [x.lower() for x in parts[1:]]
            if drive == rdrive and low[:len(rootp)] == rootp:
                path = "\\\\" + "\\".join([server_col, share_col] + parts[1 + len(rootp):])
                server_col = None
    if DRIVE_RE.match(path):
        path = path.strip().rstrip("\\").upper() + "\\"            # "H" or "h:" -> "H:\"
    if ctx and re.match(r"^[A-Za-z]:(\\|$)", path):
        target = ctx.target_for(server_col, path[:2].upper())
        if target:                                                 # H:\Finance -> \\FS01\Dept\Finance
            rest = path[2:].lstrip("\\")
            path = target.rstrip("\\") + ("\\" + rest if rest else "")
            server_col = None
            ctx.resolved += 1
    server, share, parts, disp, style = split_path(path, server_col, share_col)
    key, label = folder_key(server, share, parts, depth, style)
    kind, src = identity_kind(ident, get("account_type"))
    ik = ident_key(ident)
    if ctx and kind in ("unknown", "group", "user") and src != "column":
        if ik in ctx.groups:
            kind, src = "group", "members"                         # it has members: a group
        elif kind == "unknown" and ctx.member_kind.get(ik) in ("user", "group", "computer"):
            kind, src = ctx.member_kind[ik], "members"
    rights = get("rights")
    return {"server": server, "share": share, "path": disp[:1000], "path_raw": path_raw[:1000], "folder_key": key[:600],
            "folder_label": label[:600], "depth": len(parts), "identity": ident, "identity_key": ik, "identity_kind": kind,
            "kind_source": src, "rights_raw": rights[:300] or None,
            "level": level_of(rights) if rights else "unstated",
            "allow": allow_of(get("access_type")) if m.get("access_type") is not None else
            (False if re.search(r"\bdeny\b", rights, re.I) else True),
            "inherited": (bool_of(get("inherited")) if get("inherited") or not m.get("_inh_from") else False)
            if m.get("inherited") is not None else (True if re.search(r"\(I\)", rights) else
                                                      False if re.fullmatch(r"(\([A-Z,]+\))+", rights.replace(" ", "")) else None),
            "owner": get("owner")[:300] or None, "application": get("application")[:120] or None,
            "team": get("team")[:120] or None}


# ---- the upload (in pieces, as Deployment's) ------------------------------------------------------------

NAME_RE = re.compile(r"^[^\x00-\x1f<>]{1,120}$")
FILE_RE = re.compile(r"\.(csv|txt|tsv|xlsx|xlsm|xls|ndjson\.gz|gz)$", re.I)
MAX_XLS = 300 * 2 ** 20            # an .xls is read whole (the format holds 65,536 rows a sheet)


class PermError(ValueError):
    """Shown to the admin as it is."""


def start_upload(conn, user, file_name, size, name=None):
    fn = (file_name or "").replace("\\", "/").split("/")[-1].strip()[:200]
    if not fn or not FILE_RE.search(fn):
        raise PermError("Upload the report as a .csv, .xlsx or .xls file (or .txt / .tsv), or the access scanner's .ndjson.gz.")
    try:
        size = int(size)
    except (TypeError, ValueError):
        raise PermError("The file size is missing.")
    if size <= 0:
        raise PermError("The file is empty.")
    if size > MAX_BYTES:
        raise PermError(f"The file is larger than {MAX_BYTES // 2 ** 20} MB: export it in parts (for example per server).")
    if fn.lower().endswith(".xls") and size > MAX_XLS:
        raise PermError(f"An .xls file is read whole: at most {MAX_XLS // 2 ** 20} MB. Save it as .xlsx or .csv.")
    nm = (name or fn.rsplit(".", 1)[0]).strip()[:120]
    if not NAME_RE.match(nm):
        raise PermError("Give the upload a name without control characters.")
    r = conn.execute("""INSERT INTO perm_datasets (name, file_name, size_bytes, uploaded_by) VALUES (%s, %s, %s, %s)
                        RETURNING id::text AS id""", (nm, fn, size, user)).fetchone()
    return {"dataset_id": r["id"], "chunk_bytes": CHUNK, "size": size}


def remove(conn, ds_id):
    r = conn.execute("DELETE FROM perm_datasets WHERE id = %s RETURNING name", (ds_id,)).fetchone()
    if not r:
        raise PermError("That upload is not known.")
    return r["name"]


def put_chunk(conn, upload_id, offset, data):
    ds = conn.execute("SELECT state, size_bytes, received FROM perm_datasets WHERE id = %s FOR UPDATE",
                      (upload_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known (it may have been removed).")
    if ds["state"] != "uploading":
        raise PermError("That upload is finished already.")
    if len(data) > CHUNK_MAX or not data:
        raise PermError("A piece of the file is empty or too large.")
    if offset != ds["received"]:
        raise PermError(f"Piece out of order: expected the bytes from {ds['received']}.")
    if offset + len(data) > ds["size_bytes"]:
        raise PermError("The file is larger than announced.")
    seq = conn.execute("SELECT coalesce(max(seq), -1) + 1 AS n FROM perm_chunks WHERE dataset_id = %s", (upload_id,)).fetchone()["n"]
    conn.execute("INSERT INTO perm_chunks (dataset_id, seq, offset_b, data) VALUES (%s, %s, %s, %s)",
                 (upload_id, seq, offset, bytes(data)))
    conn.execute("UPDATE perm_datasets SET received = received + %s, updated_at = now() WHERE id = %s", (len(data), upload_id))
    return {"received": offset + len(data)}


def finish_upload(conn, upload_id):
    ds = conn.execute("SELECT state, size_bytes, received FROM perm_datasets WHERE id = %s FOR UPDATE", (upload_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known.")
    if ds["state"] != "uploading":
        raise PermError("That upload is finished already.")
    if ds["received"] != ds["size_bytes"]:
        raise PermError(f"Only {ds['received']} of {ds['size_bytes']} bytes arrived: upload it again.")
    conn.execute("UPDATE perm_datasets SET state = 'uploaded', progress = %s::jsonb, updated_at = now() WHERE id = %s",
                 (json.dumps({"step": "waiting", "note": "the worker reads it within a few seconds"}), upload_id))
    return {"ok": True}


# ---- reading the file (worker) ----------------------------------------------------------------------------

def _progress(conn, ds_id, **p):
    conn.execute("UPDATE perm_datasets SET progress = %s::jsonb, updated_at = now() WHERE id = %s", (json.dumps(p), ds_id))
    conn.commit()


def _pieces(conn, ds_id):
    n = conn.execute("SELECT count(*) AS n FROM perm_chunks WHERE dataset_id = %s", (ds_id,)).fetchone()["n"]
    for seq in range(n):
        r = conn.execute("SELECT data FROM perm_chunks WHERE dataset_id = %s AND seq = %s", (ds_id, seq)).fetchone()
        if r:
            yield bytes(r["data"])


class ChunkFile(io.RawIOBase):
    """The uploaded pieces as one seekable file, read from the database a piece at a time (an
    .xlsx is a zip: it is read from its end; the worker's /tmp is far too small for it)."""
    def __init__(self, conn, ds_id):
        super().__init__()
        self.conn, self.ds = conn, ds_id
        self.index = [(r["seq"], r["offset_b"], r["n"]) for r in conn.execute(
            "SELECT seq, offset_b, length(data) AS n FROM perm_chunks WHERE dataset_id = %s ORDER BY seq", (ds_id,)).fetchall()]
        self.size = sum(n for _, _, n in self.index)
        self.pos = 0
        self.cache = {}

    def readable(self):
        return True

    def seekable(self):
        return True

    def tell(self):
        return self.pos

    def seek(self, off, whence=0):
        self.pos = off if whence == 0 else self.pos + off if whence == 1 else self.size + off
        self.pos = max(0, self.pos)
        return self.pos

    def _piece(self, seq):
        if seq not in self.cache:
            if len(self.cache) >= 3:
                self.cache.pop(next(iter(self.cache)))
            self.cache[seq] = bytes(self.conn.execute("SELECT data FROM perm_chunks WHERE dataset_id = %s AND seq = %s",
                                                      (self.ds, seq)).fetchone()["data"])
        return self.cache[seq]

    def readinto(self, buf):
        want, got = len(buf), 0
        while got < want and self.pos < self.size:
            for seq, off, n in self.index:
                if off <= self.pos < off + n:
                    data = self._piece(seq)
                    take = data[self.pos - off:self.pos - off + (want - got)]
                    buf[got:got + len(take)] = take
                    got += len(take)
                    self.pos += len(take)
                    break
            else:
                break
        return got


def bulk_insert(conn, table, cols, rows, types=None):
    """COPY when the driver has it (psycopg 3), else plain inserts."""
    rows = list(rows)
    if not rows:
        return
    cur = conn.cursor()
    if hasattr(cur, "copy"):
        # text format: the server reads each value as its column's type (no binary type names needed)
        with cur.copy(f"COPY {table} ({', '.join(cols)}) FROM STDIN") as cp:
            for r in rows:
                cp.write_row(r)
    else:
        cur.executemany(f"INSERT INTO {table} ({', '.join(cols)}) VALUES ({', '.join(['%s'] * len(cols))})", rows)


def open_sheets(conn, ds_id, file_name):
    """(kind, encoding, delimiter, [Sheet]) of the upload, from its bytes."""
    from . import perm_read as rd
    first = b""
    for b in _pieces(conn, ds_id):
        first += b
        if len(first) >= 262144:
            break
    from . import perm_scan
    if perm_scan.is_scan(first[:262144]):
        # The access scanner's own file (r123): its columns are known, nothing is guessed
        def open_file():
            return io.BufferedReader(ChunkFile(conn, ds_id), 1 << 20)
        try:
            scan = perm_scan.prepare(conn, ds_id, open_file, CHUNK)     # r125: a change-only scan becomes the complete file
        except (perm_scan.ScanError, OSError, EOFError) as e:
            raise PermError(str(e) if isinstance(e, perm_scan.ScanError) else
                            "The scan file could not be read (" + type(e).__name__ + "): upload it again.")
        out = []
        for sh, role, m in perm_scan.sheets(scan, open_file, rd.Sheet):
            sh.role, sh.mapping = role, m
            out.append(sh)
        out[0].scan = scan
        return "scan", "scan", None, out
    kind = rd.kind_of(first[:65536], file_name)
    base = re.sub(r"\.[A-Za-z0-9]{1,5}$", "", file_name)[:80] or "Sheet"
    if kind == "xlsx":
        try:
            sheets, _ = rd.xlsx_sheets(ChunkFile(conn, ds_id))
        except Exception as e:  # noqa: BLE001
            raise PermError("The .xlsx could not be opened (" + type(e).__name__ + ": " + str(e)[:120] +
                            "). Is it password-protected? Save it again without a password.")
        return kind, "xlsx", None, sheets
    if kind == "xls":
        try:
            import xlrd  # noqa: F401
        except ImportError:
            raise PermError("Reading .xls needs PATCH-01 r120's image: run phase3b-api.sh again (it installs xlrd), "
                            "or save the file as .xlsx.")
        data = b"".join(_pieces(conn, ds_id))
        try:
            sheets, _ = rd.xls_sheets(data)
        except Exception as e:  # noqa: BLE001
            raise PermError("The .xls could not be opened (" + type(e).__name__ + ": " + str(e)[:120] +
                            "). Save it again as .xlsx or .csv.")
        return kind, "xls", None, sheets
    enc = rd.bom_or_utf16(first[:65536]) or rd.scan_encoding(_pieces(conn, ds_id))
    if kind == "html":
        if sum(1 for _ in _pieces(conn, ds_id)) * CHUNK > MAX_XLS:
            raise PermError("An HTML table saved as .xls is read whole: at most 300 MB. Save it as .csv.")
        dec = rd.decoder_for(enc)
        text = "".join(dec.decode(b) for b in _pieces(conn, ds_id)) + dec.decode(b"", final=True)
        sheets = rd.html_sheets(text, base)
        if not sheets:
            raise PermError("The file is a web page without a table: is it the report?")
        return "html", enc, None, sheets
    pieces = _pieces(conn, ds_id)
    head = b""
    for b in pieces:
        head += b
        if len(head) >= 262144:
            break
    sh = rd.csv_sheet(base, head, pieces, enc)
    return "csv", enc, sh.delimiter, [sh]


def read_file(conn, ds_id, stop=lambda: False):
    """The uploaded bytes -> perm_raw rows, every sheet; each sheet's header and sample saved."""
    from . import perm_read as rd
    ds = conn.execute("SELECT file_name FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    conn.execute("UPDATE perm_datasets SET state = 'reading', error = NULL WHERE id = %s", (ds_id,))
    conn.execute("DELETE FROM perm_raw WHERE dataset_id = %s", (ds_id,))
    conn.execute("DELETE FROM perm_sheets WHERE dataset_id = %s", (ds_id,))
    conn.commit()
    kind, enc, delim, sheets = open_sheets(conn, ds_id, ds["file_name"])
    clean = Cleaner()
    rn, first_sheet = 0, None
    for sheet_no, sh in enumerate(sheets[:60]):
        it = iter(sh.rows)
        if getattr(sh, "header_index", None) is not None:
            hdr_i, head_rows = sh.header_index, []          # the scanner's own tables: the header is the first row
        else:
            hdr_i, head_rows = rd.split_head(it)
        headers, batch, n, skipped, sample = None, [], 0, 0, []

        def rows_of():
            yield from head_rows
            yield from it
        for i, row in enumerate(rows_of()):
            if i < hdr_i:
                continue
            if headers is None:
                headers = [clean(c) or f"Column {j + 1}" for j, c in enumerate(row[:MAX_COLS])]
                continue
            cells = [clean(c) for c in row[:MAX_COLS]]
            if not any(cells):
                continue
            if len([c for c in cells if c]) < 2 and len(headers) >= 2:
                skipped += 1                   # a total line, a note under the table
                continue
            n += 1
            rn += 1
            if kind == "scan" and n > MAX_SCAN_ROWS:
                raise PermError(f"More than {MAX_SCAN_ROWS:,} permission entries in one scan: scan fewer shares at a time, or "
                                "fewer levels in full (-Depth 1: deeper, only the folders whose permissions change are read).")
            if kind != "scan" and n > MAX_ROWS:
                raise PermError(f"More than {MAX_ROWS:,} rows in one sheet: export the report in parts (for example per server).")
            if len(sample) < 25:
                sample.append(cells)
            batch.append((ds_id, rn, sheet_no, cells))
            if len(batch) >= 5000:
                bulk_insert(conn, "perm_raw", ("dataset_id", "rn", "sheet_no", "cells"), batch)
                batch = []
                if rn % 50000 == 0:
                    _progress(conn, ds_id, step="reading", rows=rn, sheet=sh.name)
                    if stop():
                        raise PermError("Stopped: the worker was restarted.")
        bulk_insert(conn, "perm_raw", ("dataset_id", "rn", "sheet_no", "cells"), batch)
        headers = headers or []
        useful = n > 0 and len(headers) >= 2
        known = getattr(sh, "role", None)                 # the scanner's tables come with their roles and columns
        conn.execute("""INSERT INTO perm_sheets (dataset_id, sheet_no, name, hidden, header_row, headers, row_count, skipped,
                                                 sample, role, mapping, proposal)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb, %s, %s::jsonb, %s::jsonb)""",
                     (ds_id, sheet_no, clean_cell(sh.name)[:120] or f"Sheet {sheet_no + 1}", bool(sh.hidden),
                      hdr_i + 1 + getattr(sh, "offset", 0), headers, n, skipped,
                      json.dumps(sample), (known if useful else "skip") if known else (None if useful else "skip"),
                      json.dumps(sh.mapping) if known and useful else None,
                      json.dumps({"role": known, "by": "scanner", "why": "the access scanner's own table",
                                  "roles": {k: {"col": v, "by": "scanner", "why": "the scanner's column"} for k, v in sh.mapping.items()}})
                      if known else None))
        if useful and first_sheet is None:
            first_sheet = (headers, sample, hdr_i + 1 + getattr(sh, "offset", 0))
        conn.commit()
    if first_sheet is None:
        raise PermError("No table with rows found: the file has fewer than two columns or no rows under the header. "
                        "Is it a permissions report?")
    total_skipped = conn.execute("SELECT coalesce(sum(skipped), 0) AS n FROM perm_sheets WHERE dataset_id = %s",
                                 (ds_id,)).fetchone()["n"]
    conn.execute("""UPDATE perm_datasets SET encoding = %s, delimiter = %s, file_type = %s, header_row = %s, headers = %s,
                           sample = %s::jsonb, row_count = %s, skipped = %s, cleaning = %s::jsonb, state = 'mapping',
                           progress = NULL WHERE id = %s""",
                 (enc, {"\t": "tab"}.get(delim, delim) if delim else None, kind, first_sheet[2], first_sheet[0],
                  json.dumps(first_sheet[1]), rn, total_skipped, json.dumps(clean.report()), ds_id))
    if kind == "scan":
        _scan_done(conn, ds_id, sheets[0].scan, first_sheet)
    conn.execute("DELETE FROM perm_chunks WHERE dataset_id = %s", (ds_id,))
    conn.commit()
    return {"rows": rn, "sheets": len(sheets), "encoding": enc, "delimiter": delim}


def _scan_done(conn, ds_id, scan, first_sheet):
    """A scanner file read: its shares and unreadable folders kept, and the rows made plain at once
    (no columns to confirm)."""
    from . import perm_scan
    conn.execute("DELETE FROM perm_shares WHERE dataset_id = %s", (ds_id,))
    for sh in scan["shares"]:
        conn.execute("""INSERT INTO perm_shares (dataset_id, name, path, unc, description, access) VALUES (%s, %s, %s, %s, %s, %s::jsonb)
                        ON CONFLICT (dataset_id, name) DO NOTHING""",
                     (ds_id, clean_cell(sh.get("name"))[:200] or "?", clean_cell(sh.get("path"))[:600] or None,
                      clean_cell(sh.get("unc"))[:600] or None, clean_cell(sh.get("description"))[:300] or None,
                      json.dumps(sh.get("access")) if sh.get("access") is not None else None))
    info = perm_scan.summary(scan)
    conn.execute("""UPDATE perm_datasets SET source = 'scan', scan_errors = %s::jsonb, mapping = %s::jsonb, mapping_by = 'scanner',
                           mapping_at = now(), proposal = %s::jsonb, state = 'normalising', file_type = 'scan',
                           progress = %s::jsonb WHERE id = %s""",
                 (json.dumps({"total": scan["errors_total"], "items": scan["errors"], "scan": info}), json.dumps(perm_scan.PERM_MAP),
                  json.dumps({"roles": {}, "note": None, "ai": False, "scanner": True, "sheets": 3}),
                  json.dumps({"step": "normalising", "rows": 0}), ds_id))


def sheets_of(conn, ds_id):
    return conn.execute("""SELECT sheet_no, name, hidden, header_row, headers, row_count, skipped, sample, proposal, role, mapping
                             FROM perm_sheets WHERE dataset_id = %s ORDER BY sheet_no""", (ds_id,)).fetchall()


def propose(conn, ds_id, ai=None):
    """For each sheet: what it holds and which column is which, by the rules and AI-01; the admin confirms."""
    sheets = sheets_of(conn, ds_id)
    notes, used_ai = [], False
    props = {}
    for sh in sheets:
        if sh["role"] == "skip" and not sh["row_count"]:
            props[sh["sheet_no"]] = {"role": "skip", "by": "rules", "why": "empty, or fewer than two columns", "roles": {}}
            continue
        headers, sample = sh["headers"], sh["sample"] or []
        role, sure, why, rules = rule_role(sh["name"], headers, sample)
        by = "rules"
        if ai and not sure:
            try:
                got = _json(ai(sheet_messages(sh["name"], headers, sample), SHEET_SCHEMA))
                if got.get("role") in SHEET_ROLE_TEXT and (got["role"] != role):
                    role, by = got["role"], "AI-01"
                    why = clean_tag_text(got.get("why"), 200) or "AI-01 read the sheet's columns and rows"
                    used_ai = True
                elif got.get("role") == role:
                    by = "rules and AI-01"
                    used_ai = True
            except Exception as e:  # noqa: BLE001 - the rules' proposal stands alone
                notes.append(f"AI-01 did not answer for sheet \u201c{sh['name']}\u201d (" + str(e)[:80] + ").")
        cols = {}
        if role in ROLESETS:
            ai_cols = None
            if ai:
                try:
                    ai_cols = _json(ai(mapping_messages(headers, sample, role), mapping_schema(headers, role)))
                    used_ai = True
                except Exception as e:  # noqa: BLE001
                    notes.append(f"AI-01 did not map the columns of \u201c{sh['name']}\u201d (" + str(e)[:80] + ").")
            cols = merge_mapping(headers, rules.get(role, {}), ai_cols, role)
        props[sh["sheet_no"]] = {"role": role, "by": by, "why": why, "roles": cols}
    # the sheet's own name, where it tells what no column says
    perms = [sh for sh in sheets if props[sh["sheet_no"]]["role"] == "permissions"]
    for sh in sheets:
        p = props[sh["sheet_no"]]
        nm_i = len(sh["headers"] or [])
        if p["role"] in ("drives", "members") and "drive" not in p["roles"] and drive_of(sh["name"]):
            p["roles"]["drive"] = {"col": nm_i, "by": "rules", "why": f"the sheet's name \u201c{sh['name']}\u201d is drive {drive_of(sh['name'])}"}
        if p["role"] == "permissions" and "server" not in p["roles"] and len(perms) > 1 and "path" in p["roles"]:
            vals = [r[p["roles"]["path"]["col"]] for r in (sh["sample"] or []) if p["roles"]["path"]["col"] < len(r)]
            names = {x["name"].lower() for x in perms}
            if vals and all(re.match(r"^[A-Za-z]:", v) for v in vals if v) and len(names) == len(perms) \
                    and not re.fullmatch(r"(sheet|tabelle|feuil|hoja|foglio)\s*\d+", sh["name"], re.I):
                p["roles"]["server"] = {"col": nm_i, "by": "rules", "why": "drive paths on several sheets and no server "
                                        f"column: the sheet's name \u201c{sh['name']}\u201d tells the servers apart"}
    for sh in sheets:
        conn.execute("UPDATE perm_sheets SET proposal = %s::jsonb WHERE dataset_id = %s AND sheet_no = %s",
                     (json.dumps(props[sh["sheet_no"]]), ds_id, sh["sheet_no"]))
    first = next((props[sh["sheet_no"]] for sh in perms), {"roles": {}})
    conn.execute("UPDATE perm_datasets SET proposal = %s::jsonb WHERE id = %s",
                 (json.dumps({"roles": first["roles"], "note": " ".join(notes) or None, "ai": used_ai, "sheets": len(sheets)}), ds_id))
    conn.commit()
    return props


def check_sheets(sheets, cfg):
    """An admin's choice per sheet: [{sheet_no, role, mapping}] -> {sheet_no: (role, mapping)}."""
    by_no = {sh["sheet_no"]: sh for sh in sheets}
    out = {}
    for c in cfg or []:
        try:
            no = int(c.get("sheet_no"))
        except (TypeError, ValueError, AttributeError):
            raise PermError("Each sheet's choice needs its number.")
        sh = by_no.get(no)
        if not sh:
            raise PermError(f"There is no sheet {no + 1}.")
        role = c.get("role")
        if role not in SHEET_ROLE_TEXT:
            raise PermError(f"Sheet \u201c{sh['name']}\u201d: say what it holds.")
        if role != "skip" and not sh["row_count"]:
            raise PermError(f"Sheet \u201c{sh['name']}\u201d has no rows: it can only be left out.")
        m = check_mapping(c.get("mapping") or {}, sh["headers"] or [], role, sh["name"]) if role in ROLESETS else {}
        out[no] = (role, m)
    for no, sh in by_no.items():
        out.setdefault(no, ("skip", {}))
    if not any(r == "permissions" for r, _ in out.values()):
        raise PermError("Choose at least one sheet of permissions (who has access to which folder or drive).")
    return out


def set_mapping(conn, ds_id, user, mapping=None, tag_depth=1, sheets=None):
    """An admin confirms what each sheet holds and which column is which (and how deep folders are
    tagged): the rows are made plain again. `mapping` alone is the one sheet of a CSV."""
    ds = conn.execute("SELECT state, headers FROM perm_datasets WHERE id = %s FOR UPDATE", (ds_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known.")
    if ds["state"] not in ("mapping", "ready", "failed") or not ds["headers"]:
        raise PermError("The file is still being read: wait a moment." if ds["state"] in ("uploaded", "reading", "normalising")
                        else "The file was not read: upload it again.")
    all_sheets = sheets_of(conn, ds_id)
    if sheets is None:
        first = next((sh for sh in all_sheets if sh["row_count"]), None)
        if first is None:
            raise PermError("The file has no rows.")
        sheets = [{"sheet_no": first["sheet_no"], "role": "permissions", "mapping": mapping}]
    chosen = check_sheets(all_sheets, sheets)
    try:
        tag_depth = int(tag_depth)
    except (TypeError, ValueError):
        raise PermError("The tag depth is a number from 0 to 4.")
    if not 0 <= tag_depth <= 4:
        raise PermError("The tag depth is a number from 0 to 4.")
    for no, (role, m) in chosen.items():
        conn.execute("UPDATE perm_sheets SET role = %s, mapping = %s::jsonb WHERE dataset_id = %s AND sheet_no = %s",
                     (role, json.dumps(m), ds_id, no))
    first = next(m for no, (r, m) in sorted(chosen.items()) if r == "permissions")
    conn.execute("""UPDATE perm_datasets SET mapping = %s::jsonb, mapping_by = %s, mapping_at = now(), tag_depth = %s,
                           state = 'normalising', error = NULL, advice = NULL, advice_at = NULL,
                           progress = %s::jsonb, updated_at = now() WHERE id = %s""",
                 (json.dumps(first), user, tag_depth, json.dumps({"step": "normalising", "rows": 0}), ds_id))
    return {str(no): {"role": r, "mapping": m} for no, (r, m) in chosen.items()}


def _with_name(m, headers):
    """A mapping with what the rows need to know about it: where the sheet's name is, and whether the
    inherited column is an "Inherited from" column (empty there means set on the folder itself)."""
    m = dict(m)
    m["_name_at"] = len(headers or [])
    i = m.get("inherited")
    if i is not None and i < len(headers or []) and "from" in _norm_header(headers[i]):
        m["_inh_from"] = True
    return m


def share_roots(rows, mm, sheet_name, ctx):
    """For a sheet with a share column and local paths (D:\\Shares\\Fin\\...): each share's own folder,
    the folder all its paths have in common (when no column lists it)."""
    if mm.get("share") is None or mm.get("share_path") is not None:
        return
    seen = {}
    for cells in rows:
        def get(role):
            i = mm.get(role)
            if i is None:
                return ""
            return clean_cell(sheet_name) if i == mm["_name_at"] else clean_cell(cells[i]) if i < len(cells) else ""
        path, share = clean_path(get("path")), get("share")
        if not share or not re.match(r"^[A-Za-z]:(\\|$)", path):
            continue
        parts = [b.lower() for b in path.split("\\") if b]
        key = (get("server").lower(), share.lower())
        cur = seen.get(key)
        if cur is None:
            seen[key] = parts
        else:
            n = 0
            while n < min(len(cur), len(parts)) and cur[n] == parts[n]:
                n += 1
            seen[key] = cur[:n]
    for key, parts in seen.items():
        if parts:                                            # the same drive: the common folder below it
            ctx.share_roots[key] = parts[1:]


def _drive_rows(conn, ds_id, chosen, sheets, limit=None):
    """The drive information sheets' rows as dicts."""
    out = []
    for sh in sheets:
        role, m = chosen.get(sh["sheet_no"], (None, None))
        if role != "drives":
            continue
        mm = _with_name(m, sh["headers"])
        q = "SELECT rn, cells FROM perm_raw WHERE dataset_id = %s AND sheet_no = %s ORDER BY rn" + (f" LIMIT {int(limit)}" if limit else "")
        for r in conn.execute(q, (ds_id, sh["sheet_no"])).fetchall():
            def get(role):
                i = mm.get(role)
                if i is None:
                    return ""
                return clean_cell(sh["name"]) if i == mm["_name_at"] else clean_cell(r["cells"][i]) if i < len(r["cells"]) else ""
            d = drive_of(get("drive"))
            if not d:
                continue
            tgt = get("target")
            tkey = None
            if tgt.startswith("\\\\") or tgt.startswith("//"):
                srv, shr, parts, _, st = split_path(tgt.replace("/", "\\"))
                tgt = "\\\\" + "\\".join([x for x in [srv, shr] + parts if x])
                tkey = folder_key(srv, shr, parts, len(parts), st)[0]
            else:
                tgt = ""
            out.append({"sheet_no": sh["sheet_no"], "rn": r["rn"], "drive": d, "server": get("server") or None, "target": tgt or None,
                        "target_key": tkey, "label": get("label")[:200] or None, "owner": get("owner")[:200] or None,
                        "application": get("application")[:120] or None, "team": get("team")[:120] or None})
    return out


def _member_rows(conn, ds_id, chosen, sheets, limit=None):
    out = []
    for sh in sheets:
        role, m = chosen.get(sh["sheet_no"], (None, None))
        if role != "members":
            continue
        mm = _with_name(m, sh["headers"])
        q = "SELECT rn, cells FROM perm_raw WHERE dataset_id = %s AND sheet_no = %s ORDER BY rn" + (f" LIMIT {int(limit)}" if limit else "")
        for r in conn.execute(q, (ds_id, sh["sheet_no"])).fetchall():
            def get(role):
                i = mm.get(role)
                if i is None:
                    return ""
                return clean_cell(sh["name"]) if i == mm["_name_at"] else clean_cell(r["cells"][i]) if i < len(r["cells"]) else ""
            g, mem = norm_identity(get("group")), norm_identity(get("member"))
            if not g or not mem:
                continue
            kind, src = identity_kind(mem, get("member_type"))
            out.append({"sheet_no": sh["sheet_no"], "rn": r["rn"], "group_name": g, "group_key": ident_key(g), "member": mem,
                        "member_key": ident_key(mem), "member_kind": kind, "kind_by_type": src == "column",
                        "drive": drive_of(get("drive")) if get("drive") else None,
                        "department": get("department")[:120] or None})
    return out


def _people_rows(conn, ds_id, chosen, sheets, members=()):
    """Every person with a department: from the people sheets, and from members sheets with a department
    column. One row per person; when rows disagree, the department most rows give (the others kept)."""
    rows = []
    for sh in sheets:
        role, m = chosen.get(sh["sheet_no"], (None, None))
        if role != "people":
            continue
        mm = _with_name(m, sh["headers"])
        for r in conn.execute("SELECT cells FROM perm_raw WHERE dataset_id = %s AND sheet_no = %s ORDER BY rn",
                              (ds_id, sh["sheet_no"])).fetchall():
            def get(role):
                i = mm.get(role)
                if i is None:
                    return ""
                return clean_cell(sh["name"]) if i == mm["_name_at"] else clean_cell(r["cells"][i]) if i < len(r["cells"]) else ""
            person = norm_identity(get("person"))
            if not person:
                continue
            en = get("enabled").lower()
            ll = re.match(r"^(\d{4}-\d\d-\d\d)", get("last_logon"))
            rows.append({"person": person, "department": get("department")[:120] or None,
                         "display_name": get("display_name")[:120] or None, "title": get("title")[:120] or None,
                         "manager": norm_identity(get("manager"))[:120] or None, "location": get("location")[:120] or None,
                         "email": get("email")[:200] or None,
                         "enabled": True if en in ("true", "yes", "enabled", "active", "1") else
                         False if en in ("false", "no", "disabled", "inactive", "0") else None,
                         "last_logon": ll.group(1) if ll else None})
    for m in members:
        if m.get("department") and m["member_kind"] not in ("group",):
            rows.append({"person": m["member"], "department": m["department"], "display_name": None, "title": None,
                         "manager": None, "location": None, "email": None, "enabled": None, "last_logon": None})
    people = {}
    for r in rows:
        keys = [ident_key(r["person"])]
        if r["email"] and "@" in r["email"]:
            keys.append(ident_key(r["email"]))                    # jwatson@corp.com is CORP\jwatson
        for k in dict.fromkeys(keys):
            if not k:
                continue
            p = people.setdefault(k, {"person": r["person"], "depts": {}, "sources": 0})
            p["sources"] += 1
            if r["department"]:
                d = r["department"].strip()
                p["depts"][d] = p["depts"].get(d, 0) + 1
            for f in ("display_name", "title", "manager", "location", "email", "last_logon"):
                if r[f] and not p.get(f):
                    p[f] = r[f]
            if r["enabled"] is not None and p.get("enabled") is None:
                p["enabled"] = r["enabled"]
    out = []
    for k, p in people.items():
        depts = sorted(p["depts"].items(), key=lambda x: (-x[1], x[0].lower()))
        # the same department written two ways ("IT", "it ") is one
        merged = {}
        for d, n in depts:
            merged.setdefault(d.lower(), [d, 0])[1] += n
        best = sorted(merged.values(), key=lambda x: -x[1])
        out.append({"person_key": k, "person": p["person"], "department": best[0][0] if best else None,
                    "conflicts": ", ".join(d for d, _ in best[1:])[:300] or None, "sources": p["sources"],
                    "display_name": p.get("display_name"), "title": p.get("title"), "manager": p.get("manager"),
                    "location": p.get("location"), "email": p.get("email"), "enabled": p.get("enabled"),
                    "last_logon": p.get("last_logon")})
    return out


def build_context(drives, members, people=()):
    ctx = Context()
    for d in drives:
        if d["target"]:
            ctx.targets.setdefault(((d["server"] or "").lower(), d["drive"]), set()).add(d["target"])
    for m in members:
        ctx.groups.add(m["group_key"])
    for m in members:
        if m["kind_by_type"]:
            ctx.member_kind[m["member_key"]] = m["member_kind"]
    for p in people:                      # listed in a people sheet (with a department, or read from the directory): a person
        if (p["department"] or p.get("enabled") is not None) and p["person_key"] not in ctx.groups:
            ctx.member_kind.setdefault(p["person_key"], "user")
    return ctx


def open_groups(members, cap=200000):
    """Every group's accounts, nested groups opened up: [(group_key, member, member_key, kind, via)].
    A member that is itself a listed group is opened (cycles are stopped); what is left are the
    accounts behind the group."""
    direct = {}
    for m in members:
        direct.setdefault(m["group_key"], {}).setdefault(m["member_key"], m)
    out = []
    for g in direct:
        seen_groups, seen = {g}, set()
        stack = [(m, []) for m in direct[g].values()]
        while stack and len(seen) < cap:
            m, via = stack.pop()
            k = m["member_key"]
            if k in direct and k not in seen_groups:
                seen_groups.add(k)
                stack.extend((x, via + [m["member"]]) for x in direct[k].values())
                continue
            if k in direct or k in seen:
                continue
            seen.add(k)
            kind = m["member_kind"]
            if kind == "unknown" and not m["kind_by_type"]:
                kind = "unknown"
            out.append((g, m["member"], k, kind, " > ".join(via)[:300] or None))
    return out


ENTRY_COLS = ("dataset_id", "rn", "sheet_no", "server", "share", "path", "path_raw", "folder_key", "depth", "identity",
              "identity_key", "identity_kind", "kind_source", "rights_raw", "level", "allow", "inherited", "owner")


def depth_preview(conn, ds_id, mapping=None, tag_depth=1, sheets=None):
    """The folders a depth gives, from the first rows (before anything is saved), with the drive
    letters resolved as the drive sheets say."""
    ds = conn.execute("SELECT headers FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    if not ds or not ds["headers"]:
        raise PermError("The file is still being read.")
    all_sheets = sheets_of(conn, ds_id)
    if sheets is None:
        first = next(sh for sh in all_sheets if sh["row_count"])
        sheets = [{"sheet_no": first["sheet_no"], "role": "permissions", "mapping": mapping}]
    chosen = check_sheets(all_sheets, sheets)
    ctx = build_context(_drive_rows(conn, ds_id, chosen, all_sheets, 5000), _member_rows(conn, ds_id, chosen, all_sheets, 20000))
    rows = []
    for sh in all_sheets:
        role, m = chosen[sh["sheet_no"]]
        if role == "permissions":
            mm = _with_name(m, sh["headers"])
            for r in conn.execute("SELECT cells FROM perm_raw WHERE dataset_id = %s AND sheet_no = %s ORDER BY rn LIMIT 5000",
                                  (ds_id, sh["sheet_no"])).fetchall():
                rows.append((r["cells"], mm, sh["name"]))
    for name in {n for _, _, n in rows}:
        sel = [(c, mm) for c, mm, n in rows if n == name]
        if sel and sel[0][1].get("share") is not None:
            share_roots((c for c, _ in sel), sel[0][1], name, ctx)
    out = []
    for d in range(5):
        seen = {}
        ctx.resolved = 0
        for cells, mm, name in rows:
            e = entry_from(cells, mm, d, ctx, name)
            if e:
                seen[e["folder_key"]] = e["folder_label"]
        out.append({"depth": d, "folders": len(seen), "examples": sorted(seen.values())[:6]})
    return {"rows_looked_at": len(rows), "depths": out, "chosen": int(tag_depth) if str(tag_depth).isdigit() else 1,
            "drives_resolved": ctx.resolved, "drives_ambiguous": sorted(ctx.ambiguous)}


def normalise(conn, ds_id, stop=lambda: False):
    ds = conn.execute("SELECT tag_depth, row_count, file_type FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    sys_skip = 0                                           # r127: folders on the system drive are left out (the scanner does it itself)
    depth = ds["tag_depth"]
    all_sheets = sheets_of(conn, ds_id)
    chosen = {sh["sheet_no"]: (sh["role"] or "skip", {k: int(v) for k, v in (sh["mapping"] or {}).items()}) for sh in all_sheets}
    if not any(r == "permissions" for r, _ in chosen.values()):
        raise PermError("No sheet of permissions was chosen: confirm the sheets again.")
    conn.execute("UPDATE perm_datasets SET state = 'normalising', error = NULL WHERE id = %s", (ds_id,))
    for t in ("perm_entries", "perm_folders", "perm_drives", "perm_members", "perm_access"):
        conn.execute(f"DELETE FROM {t} WHERE dataset_id = %s", (ds_id,))
    conn.commit()
    # 1. the drive information and the group members first: the permission rows use them
    drives = _drive_rows(conn, ds_id, chosen, all_sheets)
    members = _member_rows(conn, ds_id, chosen, all_sheets)
    bulk_insert(conn, "perm_drives", ("dataset_id", "sheet_no", "rn", "drive", "server", "target", "target_key", "label", "owner",
                                      "application", "team"),
                [(ds_id, d["sheet_no"], d["rn"], d["drive"], d["server"], d["target"], d["target_key"], d["label"], d["owner"],
                  d["application"], d["team"]) for d in drives])
    bulk_insert(conn, "perm_members", ("dataset_id", "sheet_no", "rn", "group_name", "group_key", "member", "member_key",
                                       "member_kind", "drive"),
                [(ds_id, m["sheet_no"], m["rn"], m["group_name"], m["group_key"], m["member"], m["member_key"], m["member_kind"],
                  m["drive"]) for m in members])
    opened = open_groups(members)
    conn.execute("DELETE FROM perm_people WHERE dataset_id = %s", (ds_id,))
    people = _people_rows(conn, ds_id, chosen, all_sheets, members)
    bulk_insert(conn, "perm_people", ("dataset_id", "person_key", "person", "display_name", "department", "title", "manager",
                                      "location", "email", "sources", "conflicts", "enabled", "last_logon"),
                [(ds_id, p["person_key"], p["person"], p["display_name"], p["department"], p["title"], p["manager"], p["location"],
                  p["email"], p["sources"], p["conflicts"], p["enabled"], p["last_logon"]) for p in people])
    conn.execute("""UPDATE perm_access a SET member_kind = 'user' FROM perm_people p
                     WHERE a.dataset_id = %s AND p.dataset_id = a.dataset_id AND p.person_key = a.member_key
                       AND a.member_kind = 'unknown' AND p.department IS NOT NULL""", (ds_id,))
    bulk_insert(conn, "perm_access", ("dataset_id", "group_key", "member", "member_key", "member_kind", "via"),
                [(ds_id,) + x for x in opened])
    conn.commit()
    ctx = build_context(drives, members, people)
    # 2. the permission rows, sheet by sheet
    labels, file_tags, skipped = {}, {}, 0
    total = sum(sh["row_count"] for sh in all_sheets if chosen[sh["sheet_no"]][0] == "permissions")
    done = 0
    for sh in all_sheets:
        role, m = chosen[sh["sheet_no"]]
        if role != "permissions":
            continue
        mm = _with_name(m, sh["headers"])
        if mm.get("share") is not None:
            share_roots((r["cells"] for r in conn.execute("SELECT cells FROM perm_raw WHERE dataset_id = %s AND sheet_no = %s",
                                                           (ds_id, sh["sheet_no"])).fetchall()), mm, sh["name"], ctx)
        last = 0
        while True:
            rows = conn.execute("""SELECT rn, cells FROM perm_raw WHERE dataset_id = %s AND sheet_no = %s AND rn > %s
                                    ORDER BY rn LIMIT 20000""", (ds_id, sh["sheet_no"], last)).fetchall()
            if not rows:
                break
            out = []
            for r in rows:
                last = r["rn"]
                e = entry_from(r["cells"], mm, depth, ctx, sh["name"])
                if not e:
                    skipped += 1
                    continue
                if ds["file_type"] != "scan" and on_system_drive(e):
                    sys_skip += 1
                    continue
                labels.setdefault(e["folder_key"], e["folder_label"])
                if e["application"] or e["team"]:
                    t = file_tags.setdefault(e["folder_key"], {})
                    t[(e["application"], e["team"])] = t.get((e["application"], e["team"]), 0) + 1
                out.append((ds_id, r["rn"], sh["sheet_no"], e["server"], e["share"], e["path"], e["path_raw"], e["folder_key"],
                            e["depth"], e["identity"], e["identity_key"], e["identity_kind"], e["kind_source"], e["rights_raw"],
                            e["level"], e["allow"], e["inherited"], e["owner"]))
            bulk_insert(conn, "perm_entries", ENTRY_COLS, out)
            conn.commit()
            done += len(rows)
            _progress(conn, ds_id, step="normalising", rows=done, total=total, sheet=sh["name"])
            if stop():
                raise PermError("Stopped: the worker was restarted. Confirm the columns again to go on.")
    if not labels:
        raise PermError("No row has both a path and an account with these columns: check the columns chosen.")
    conn.execute("""INSERT INTO perm_folders (dataset_id, folder_key, label, server, entries, paths, identities)
                    SELECT dataset_id, folder_key, '', min(server), count(*), count(DISTINCT lower(path)), count(DISTINCT lower(identity))
                      FROM perm_entries WHERE dataset_id = %s GROUP BY dataset_id, folder_key""", (ds_id,))
    for k, lab in labels.items():
        conn.execute("UPDATE perm_folders SET label = %s WHERE dataset_id = %s AND folder_key = %s", (lab, ds_id, k))
    # Application / team in the file itself (permission rows, or the drive sheet): suggestions an admin confirms
    for k, counts in file_tags.items():
        (app, team), n = max(counts.items(), key=lambda x: x[1])
        _file_tag(conn, k, labels.get(k, k), app, team, f"from the file's own columns ({n} rows say so)")
    for d in drives:
        if d["target_key"] and (d["application"] or d["team"]):
            _file_tag(conn, d["target_key"], d["target"], d["application"], d["team"],
                      f"from the drive sheet: drive {d['drive']}" + (f" \u201c{d['label']}\u201d" if d["label"] else ""))
    resolve_tags(conn, ds_id)
    owners, unsure = suggest_owners(conn, ds_id)
    links = {"system_drive_rows": sys_skip, "owners_suggested": owners, "owners_unsure": unsure, "drives": len(drives), "drive_targets": len({d["target"] for d in drives if d["target"]}),
             "paths_resolved": ctx.resolved, "ambiguous_drives": sorted(ctx.ambiguous),
             "groups_listed": len(ctx.groups), "member_rows": len(members), "accounts_behind": len({x[2] for x in opened}),
             "people_listed": len(people), "departments": len({p["department"].lower() for p in people if p["department"]}),
             "department_conflicts": sum(1 for p in people if p["conflicts"]),
             "kinds_from_members": conn.execute("SELECT count(*) AS n FROM perm_entries WHERE dataset_id = %s AND kind_source = 'members'",
                                                (ds_id,)).fetchone()["n"]}
    conn.execute("""UPDATE perm_datasets SET state = 'ready', skipped = %s, progress = NULL, profile = %s::jsonb, links = %s::jsonb
                     WHERE id = %s""",
                 (skipped + sum(sh["skipped"] for sh in all_sheets), json.dumps(profile(conn, ds_id)), json.dumps(links), ds_id))
    conn.commit()


def _file_tag(conn, key, label, app, team, reason):
    conn.execute("""INSERT INTO perm_tags (key_l, label, application, team, state, confidence, reason, suggested_by, suggested_at)
                    VALUES (%s, %s, %s, %s, 'suggested', 90, %s, 'file', now())
                    ON CONFLICT (key_l) DO UPDATE SET application = EXCLUDED.application, team = EXCLUDED.team,
                        confidence = 90, reason = EXCLUDED.reason, suggested_by = 'file', suggested_at = now()
                    WHERE perm_tags.state = 'suggested'""", (key, label or key, app, team, reason))


def parents(key):
    """A folder key and every parent of it that can carry a tag, longest first."""
    out = [key]
    k = key
    while True:
        cut = max(k.rfind("\\"), k.rfind("/"))
        if cut <= 2:
            break
        k = k[:cut]
        if k.endswith(":"):
            out.append(k + "\\")                     # a drive's root: "srv d:\\"
            break
        if k in ("\\", ""):
            break
        out.append(k)
    return out


def resolve_tags(conn, ds_id=None):
    """Each folder's tag in force: its own, else its nearest tagged parent; confirmed before suggested.
    For one upload, or (ds_id None) every upload (after an admin decides)."""
    tags = {r["key_l"]: r for r in conn.execute(f"""SELECT key_l, application, team, owner, owner_kind, department, state FROM perm_tags
                                                      WHERE state <> 'rejected' AND {TAG_HAS}""")}
    where, args = ("WHERE dataset_id = %s", (ds_id,)) if ds_id else ("", ())
    folders = conn.execute("""SELECT dataset_id, folder_key, tag_key, application, team, owner, owner_kind, department, tag_state
                                FROM perm_folders """ + where, args).fetchall()
    for f in folders:
        chain = parents(f["folder_key"])
        best = None
        for k in chain:
            t = tags.get(k)
            if t and t["state"] == "confirmed":
                best = (k, t)
                break
            if t and best is None:
                best = (k, t)
        if best:
            # what the tag in force leaves empty comes from the nearest folder above it that says it
            # (a sub-folder's owner suggested by the rules keeps the application its parent has)
            vals = {c: best[1][c] for c in TAG_FIELDS}
            for k in chain[chain.index(best[0]) + 1:]:
                t = tags.get(k)
                if not t:
                    continue
                for c in ("application", "team", "owner", "department"):
                    if vals[c] is None and t[c] is not None:
                        vals[c] = t[c]
                        if c == "owner":
                            vals["owner_kind"] = t["owner_kind"]
            now = (best[0],) + tuple(vals[c] for c in TAG_FIELDS) + (best[1]["state"],)
        else:
            now = (None,) * (len(TAG_FIELDS) + 2)
        if now == (f["tag_key"],) + tuple(f[c] for c in TAG_FIELDS) + (f["tag_state"],):
            continue                                       # unchanged: nothing written
        conn.execute("""UPDATE perm_folders SET tag_key = %s, application = %s, team = %s, owner = %s, owner_kind = %s,
                               department = %s, tag_state = %s
                         WHERE dataset_id = %s AND folder_key = %s""", now + (f["dataset_id"], f["folder_key"]))
    conn.commit()


# ---- r124: owner and department of each folder, from the evidence ---------------------------------------------

TAG_FIELDS = ("application", "team", "owner", "owner_kind", "department")
TAG_HAS = "(application IS NOT NULL OR team IS NOT NULL OR owner IS NOT NULL OR department IS NOT NULL)"
TAG_HAS_T = "(t.application IS NOT NULL OR t.team IS NOT NULL OR t.owner IS NOT NULL OR t.department IS NOT NULL)"
SURE = 80                      # a suggestion of this confidence or more can be accepted in bulk; below it AI-01 checks it
CHANGE_LEVELS = ("write", "modify", "full")
OWNER_KINDS = ("person", "group")


def _kind_of_account(name, kind, people, groups):
    """'person', 'group' or None (cannot tell) for an account: the people and members sheets first, then its kind."""
    k = ident_key(name)
    if k in people:
        return "person"
    if k in groups:
        return "group"
    return {"user": "person", "group": "group"}.get(kind)


def _people_and_groups(conn, ds_id):
    people = {r["person_key"]: r for r in conn.execute(
        """SELECT person_key, person, display_name, department, enabled FROM perm_people WHERE dataset_id = %s""", (ds_id,)).fetchall()}
    groups = {r["k"] for r in conn.execute("""SELECT DISTINCT group_key AS k FROM perm_access WHERE dataset_id = %s
                                              UNION SELECT DISTINCT group_key FROM perm_members WHERE dataset_id = %s""",
                                           (ds_id, ds_id)).fetchall()}
    return people, groups


def owner_evidence(conn, ds_id, keys=None):
    """What each folder's permissions say about its owner: {folder_key: {ntfs_owner, ntfs_kind, ntfs_person,
    explicit: [(account, kind, level)], inherited_change: n, depts: [(department, people)], people_can_change}}.
    Counted by PostgreSQL over every row of the upload (the folder itself = its top path)."""
    people, groups = _people_and_groups(conn, ds_id)
    only = " AND e.folder_key = ANY(%(keys)s)" if keys is not None else ""
    a = {"ds": ds_id, "keys": list(keys or []), "chg": list(CHANGE_LEVELS)}
    ev = {}
    for r in conn.execute(f"""SELECT DISTINCT ON (e.folder_key) e.folder_key, e.owner FROM perm_entries e
                               WHERE e.dataset_id = %(ds)s AND coalesce(e.owner, '') <> '' {only}
                               ORDER BY e.folder_key, e.depth, length(e.path), e.rn""", a).fetchall():
        ev.setdefault(r["folder_key"], {})["ntfs_owner"] = norm_identity(r["owner"])
    for r in conn.execute(f"""WITH top AS (SELECT e.folder_key, min(e.depth) AS d FROM perm_entries e
                                            WHERE e.dataset_id = %(ds)s {only} GROUP BY e.folder_key)
                              SELECT e.folder_key, min(e.identity) AS identity, e.identity_key, min(e.identity_kind) AS kind,
                                     max({rank_sql('e.level')}) AS lv, bool_or(e.inherited IS NOT TRUE) AS explicit
                                FROM perm_entries e JOIN top ON top.folder_key = e.folder_key AND e.depth = top.d
                               WHERE e.dataset_id = %(ds)s AND e.allow AND e.level = ANY(%(chg)s)
                                 AND e.identity_kind IN ('user', 'group', 'unknown')
                               GROUP BY e.folder_key, e.identity_key
                               ORDER BY e.folder_key, max({rank_sql('e.level')}) DESC, min(e.identity)""", a).fetchall():
        x = ev.setdefault(r["folder_key"], {})
        if r["explicit"]:
            x.setdefault("explicit", []).append((r["identity"], _kind_of_account(r["identity"], r["kind"], people, groups), LEVELS[r["lv"]]))
        else:
            x["inherited_change"] = x.get("inherited_change", 0) + 1
    for r in conn.execute(f"""SELECT e.folder_key, p.department, count(DISTINCT p.person_key) AS n
                                FROM perm_entries e
                                LEFT JOIN perm_access a ON a.dataset_id = e.dataset_id AND a.group_key = e.identity_key
                                JOIN perm_people p ON p.dataset_id = e.dataset_id AND p.person_key = coalesce(a.member_key, e.identity_key)
                               WHERE e.dataset_id = %(ds)s AND e.allow AND e.level = ANY(%(chg)s) AND p.enabled IS NOT FALSE
                                 AND e.identity_kind NOT IN ('admin', 'system', 'broad', 'orphan') {only}
                               GROUP BY e.folder_key, p.department""", a).fetchall():
        x = ev.setdefault(r["folder_key"], {})
        x["people_can_change"] = x.get("people_can_change", 0) + r["n"]
        if r["department"]:
            x.setdefault("depts", []).append((r["department"], r["n"]))
    for x in ev.values():
        x["depts"] = sorted(x.get("depts", []), key=lambda d: (-d[1], d[0].lower()))
        x.setdefault("explicit", [])
        o = x.get("ntfs_owner")
        if o:
            kind = identity_kind(o)[0]
            x["ntfs_kind"] = kind
            x["ntfs_person"] = people.get(ident_key(o)) if kind in ("user", "unknown") else None
            x["ntfs_as"] = ("person" if x["ntfs_person"] or kind == "user" else
                            "group" if kind == "group" or ident_key(o) in groups else None) if kind in ("user", "group", "unknown") else None
    return ev, people


def _owner_is(x):
    """What the NTFS owner of a folder is, in words."""
    p = x.get("ntfs_person")
    if p or x.get("ntfs_as") == "person":
        return "a person, whose account is disabled" if p and p.get("enabled") is False else "a person"
    if x.get("ntfs_as") == "group":
        return "a group"
    k = x.get("ntfs_kind")
    return KIND_TEXT[k].lower() if k and k != "unknown" else "an account the file does not describe"


def rule_owner(x, people, depts_known):
    """The owner and department the evidence of one folder shows, with a confidence and the reason in numbers.
    Returns None when the evidence shows neither. Never a guess: each part names what it comes from."""
    owner = kind = dept = None
    oc = dc = 0
    why = []
    o = x.get("ntfs_owner")
    p = x.get("ntfs_person")
    explicit = x.get("explicit", [])
    ex_groups = [e for e in explicit if e[1] == "group"]
    ex_people = [e for e in explicit if e[1] == "person"]
    ex_other = [e for e in explicit if e[1] is None]
    if o and x.get("ntfs_as") == "person" and not (p and p["enabled"] is False):
        owner, kind, oc = o, "person", 85
        why.append(f"NTFS owner is {o}" + (f" ({p['display_name']})" if p and p.get("display_name") else "") + ", a person")
        if any(ident_key(e[0]) == ident_key(o) for e in explicit):
            oc += 5
            why.append("who can also change it")
    elif len(ex_groups) == 1 and not ex_other:
        g = ex_groups[0]
        owner, kind = g[0], "group"
        oc = 80 if not ex_people else 70
        why.append(f"{g[0]} is the only group given {LEVEL_TEXT[g[2]]} on it directly"
                   + (f" ({len(ex_people)} more people are too)" if ex_people else ""))
        if o:
            why.append(f"NTFS owner is {o} ({_owner_is(x)})")
    elif len(ex_people) == 1 and not ex_groups and not ex_other:
        e = ex_people[0]
        owner, kind, oc = e[0], "person", 75
        why.append(f"{e[0]} is the only account given {LEVEL_TEXT[e[2]]} on it directly")
    elif o and x.get("ntfs_as") == "person":                     # the owner's account is disabled: shown, never bulk-accepted
        owner, kind, oc = o, "person", 40
        why.append(f"NTFS owner is {o}, whose account is disabled")
    else:
        if len(explicit) > 1:
            why.append(f"{len(explicit)} accounts can change it directly (" + ", ".join(e[0] for e in explicit[:4])
                       + (", …" if len(explicit) > 4 else "") + "): no single owner")
        elif x.get("inherited_change") and not explicit:
            why.append("everyone who can change it gets that from a parent folder")
        if o:
            why.append(f"NTFS owner is {o} ({_owner_is(x)})")
    depts = x.get("depts", [])
    total = x.get("people_can_change", 0)
    od = (p or {}).get("department") if kind == "person" else None
    if kind == "person" and not od:
        od = (people.get(ident_key(owner)) or {}).get("department")
    if od:
        dept, dc = od, 85
        why.append(f"the owner is in {od}")
        top = depts[0] if depts else None
        if top and top[0].lower() == od.lower() and total >= 2:
            dc = 90
            why.append(f"{top[1]} of the {total} people who can change it are in {od} too")
    elif depts and total:
        name, n = depts[0]
        share = n / total
        if share >= 0.6:
            dept = name
            dc = 85 if total >= 3 and share >= 0.8 else 75 if total >= 3 else 60
            why.append(f"the only person who can change it is in {name}" if total == 1 else
                       f"{n} of the {total} people who can change it are in {name}")
        else:
            why.append("the people who can change it are in " + ", ".join(f"{d} ({k})" for d, k in depts[:3])
                       + f" of {total}: no department has most of them")
    if not owner and not dept:
        return None
    if owner and dept:
        conf = min(oc, dc) + (5 if od and dc == 90 else 0)
    elif owner:
        conf = oc if not depts_known else oc - 15             # the department is half of the answer when the file has them
    else:
        conf = dc - 15
    return {"owner": owner, "owner_kind": kind, "department": dept, "confidence": max(0, min(95, conf)),
            "evidence": ("; ".join(why))[:500]}


def suggest_owners(conn, ds_id):
    """After the import: every folder's owner and department, suggested from its permissions (rules first; AI-01 then
    checks the ones the rules are unsure of). Confirmed and rejected tags are never touched; suggestions an admin has
    not decided are brought up to date with this upload's evidence. Returns (suggested, unsure)."""
    ev, people = owner_evidence(conn, ds_id)
    depts_known = any(p["department"] for p in people.values())
    folders = conn.execute("""SELECT f.folder_key, f.label, f.tag_state, f.owner, f.department, t.state AS own_state, t.suggested_by
                                FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key
                               WHERE f.dataset_id = %s""", (ds_id,)).fetchall()
    for k, x in ev.items():                                # new folders start without one: only the ones with an owner are written
        if x.get("ntfs_owner"):
            conn.execute("UPDATE perm_folders SET ntfs_owner = %s WHERE dataset_id = %s AND folder_key = %s", (x["ntfs_owner"], ds_id, k))
    # r128: a folder whose permissions say nothing of its owner is not given to AI-01 to guess about
    conn.execute("UPDATE perm_folders SET evidence = true, evidence_note = NULL WHERE dataset_id = %s", (ds_id,))
    for f in folders:
        why = no_evidence(ev.get(f["folder_key"], {}))
        if why:
            conn.execute("UPDATE perm_folders SET evidence = false, evidence_note = %s WHERE dataset_id = %s AND folder_key = %s",
                         (why, ds_id, f["folder_key"]))
    n = 0
    for f in folders:
        if f["own_state"] in ("confirmed", "rejected"):
            continue                                       # an admin decided
        s = rule_owner(ev.get(f["folder_key"], {}), people, depts_known)
        if s and f["tag_state"] == "confirmed":            # in force from a confirmed parent
            same = lambda a, b: a is None or (b or "").lower() == a.lower()          # noqa: E731
            if same(s["owner"], f["owner"]) and same(s["department"], f["department"]):
                s = None                                   # a parent's confirmed owner already says it: nothing new to decide
        if f["own_state"] == "suggested" and f["suggested_by"] not in ("rules", "file"):
            continue                                       # AI-01's suggestion waits for the admin; AI-01 saw the evidence
        if not s:
            if f["suggested_by"] == "rules":               # the evidence no longer shows it
                conn.execute("DELETE FROM perm_tags WHERE key_l = %s AND state = 'suggested' AND suggested_by = 'rules'", (f["folder_key"],))
            continue
        if f["suggested_by"] == "file":                    # the file's own application / team stay; owner and department added
            conn.execute("""UPDATE perm_tags SET owner = %s, owner_kind = %s, department = %s, evidence = %s,
                                   confidence = least(coalesce(confidence, 90), %s)
                             WHERE key_l = %s AND state = 'suggested'""",
                         (s["owner"], s["owner_kind"], s["department"], s["evidence"], s["confidence"], f["folder_key"]))
        else:
            conn.execute("""INSERT INTO perm_tags (key_l, label, owner, owner_kind, department, state, confidence, reason, evidence,
                                                   suggested_by, suggested_at)
                            VALUES (%s, %s, %s, %s, %s, 'suggested', %s, NULL, %s, 'rules', now())
                            ON CONFLICT (key_l) DO UPDATE SET owner = EXCLUDED.owner, owner_kind = EXCLUDED.owner_kind,
                                department = EXCLUDED.department, confidence = EXCLUDED.confidence, evidence = EXCLUDED.evidence,
                                reason = NULL, application = NULL, team = NULL, suggested_at = now(), ai_asked_at = NULL
                            WHERE perm_tags.state = 'suggested' AND perm_tags.suggested_by = 'rules'""",
                         (f["folder_key"], f["label"] or f["folder_key"], s["owner"], s["owner_kind"], s["department"],
                          s["confidence"], s["evidence"]))
        n += 1
    resolve_tags(conn, ds_id)
    return n, unsure_count(conn, ds_id)


def no_evidence(x):
    """Why a folder's permissions say nothing about who owns it, or None when they do (an owner in Windows who is a
    person or a group, someone given change rights on it directly, or the departments of the people who can)."""
    if x.get("explicit") or x.get("ntfs_as") in ("person", "group") or x.get("depts"):
        return None
    if x.get("inherited_change"):
        return "only rights inherited from the folder above: nothing on this folder itself says who owns it"
    if x.get("ntfs_owner"):
        return (f"its owner in Windows is {x['ntfs_owner']} ({KIND_TEXT.get(x.get('ntfs_kind'), 'account').lower()}) and only admin, "
                "system or Everyone-type accounts can change it")
    return "only admin, system or Everyone-type accounts can change it"


UNSURE_SQL = f"""f.tag_state IS DISTINCT FROM 'confirmed' AND (%(all)s OR f.evidence IS NOT FALSE)
                 AND ((t.key_l IS NULL AND f.tag_key IS NULL)
                      OR (t.state = 'suggested' AND t.ai_asked_at IS NULL AND t.suggested_by IN ('rules', 'file')
                          AND (%(all)s OR coalesce(t.confidence, 0) < {SURE} OR (t.owner IS NULL AND t.department IS NULL))))"""


UNSURE_VIEW = (f"f.tag_state IS DISTINCT FROM 'confirmed' AND (t.key_l IS NULL OR (t.state = 'suggested' AND "
               f"(coalesce(t.confidence, 0) < {SURE} OR (t.owner IS NULL AND t.department IS NULL))))")


def unsure_count(conn, ds_id):
    return conn.execute(f"""SELECT count(*) AS n FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key
                             WHERE f.dataset_id = %(ds)s AND {UNSURE_SQL}""", {"ds": ds_id, "all": False}).fetchone()["n"]


def accept_sure(conn, ds_id, user, min_conf=SURE):
    """Confirm, as suggested, every suggestion on this upload's folders of min_conf% or more. Returns how many."""
    min_conf = max(SURE, min(100, int(min_conf)))
    rows = conn.execute(f"""UPDATE perm_tags t SET state = 'confirmed', decided_by = %s, decided_at = now()
                              FROM perm_folders f
                             WHERE f.dataset_id = %s AND t.key_l = f.folder_key AND t.state = 'suggested'
                               AND coalesce(t.confidence, 0) >= %s AND {TAG_HAS_T}
                         RETURNING t.key_l""", (user, ds_id, min_conf)).fetchall()
    resolve_tags(conn)
    return len(rows)


def profile(conn, ds_id):
    """What the file holds, counted: the facts AI-01 recommends reports from."""
    r = conn.execute("""SELECT count(*) AS entries, count(DISTINCT lower(path)) AS paths, count(DISTINCT lower(identity)) AS identities,
                               count(DISTINCT lower(server)) AS servers, count(DISTINCT lower(coalesce(server, '') || '\\' || coalesce(share, ''))) AS shares,
                               count(*) FILTER (WHERE identity_kind = 'broad' AND allow AND level IN ('write', 'modify', 'full')) AS broad_write,
                               count(*) FILTER (WHERE identity_kind = 'broad' AND allow) AS broad_any,
                               count(*) FILTER (WHERE identity_kind = 'user' AND allow AND inherited IS FALSE) AS explicit_users,
                               count(*) FILTER (WHERE identity_kind = 'user') AS users,
                               count(*) FILTER (WHERE identity_kind = 'unknown') AS kind_unknown,
                               count(*) FILTER (WHERE identity_kind = 'orphan') AS orphans,
                               count(*) FILTER (WHERE NOT allow) AS denies,
                               count(*) FILTER (WHERE level = 'full' AND allow AND identity_kind NOT IN ('admin', 'system')) AS full_nonadmin,
                               count(*) FILTER (WHERE inherited IS NULL) AS inherit_unknown,
                               count(*) FILTER (WHERE level = 'special') AS special
                          FROM perm_entries WHERE dataset_id = %s""", (ds_id,)).fetchone()
    x = conn.execute("""SELECT (SELECT count(DISTINCT group_key) FROM perm_access WHERE dataset_id = %s) AS groups_opened,
                               (SELECT count(DISTINCT member_key) FROM perm_access WHERE dataset_id = %s) AS accounts_behind,
                               (SELECT count(*) FROM perm_drives WHERE dataset_id = %s) AS drives,
                               (SELECT count(*) FROM perm_people WHERE dataset_id = %s AND department IS NOT NULL) AS people_listed,
                               (SELECT count(DISTINCT lower(department)) FROM perm_people WHERE dataset_id = %s) AS departments""",
                     (ds_id, ds_id, ds_id, ds_id, ds_id)).fetchone()
    return dict(r, **x, **folder_counts(conn, ds_id))


def folder_counts(conn, ds_id):
    """The tag counts, always as they are now (tags change after the rows are read)."""
    return conn.execute("""SELECT count(*) AS folders, count(*) FILTER (WHERE tag_state = 'confirmed') AS tagged,
                               count(*) FILTER (WHERE tag_state = 'suggested') AS suggested,
                               count(DISTINCT application) FILTER (WHERE tag_state = 'confirmed') AS applications,
                               count(DISTINCT team) FILTER (WHERE tag_state = 'confirmed') AS teams
                          FROM perm_folders WHERE dataset_id = %s""", (ds_id,)).fetchone()


# ---- tagging with AI-01 (worker) ------------------------------------------------------------------------

TAG_BATCH = 12


def folder_hints(conn, ds_id, key, ev=None, rule=None):
    """What AI-01 is shown about one folder: groups on it with their level, sub-folder names, the drive sheet,
    the departments of the people who can change it, its NTFS owner and who has change rights on it directly
    (ev: owner_evidence), and what the rules found (rule)."""
    groups = conn.execute(f"""SELECT identity, max({rank_sql('level')}) AS lv, count(*) AS n
                               FROM perm_entries WHERE dataset_id = %s AND folder_key = %s
                                AND identity_kind NOT IN ('system', 'admin', 'orphan')
                              GROUP BY identity ORDER BY count(*) DESC LIMIT 10""", (ds_id, key)).fetchall()
    subs = conn.execute("""SELECT DISTINCT path FROM perm_entries WHERE dataset_id = %s AND folder_key = %s LIMIT 400""",
                        (ds_id, key)).fetchall()
    names = []
    for s in subs:
        p = s["path"]
        rest = p[len(key):] if p.lower().startswith(key) else p
        bit = [b for b in re.split(r"[\\/]", rest) if b]
        if bit and bit[0] not in names:
            names.append(bit[0][:40])
        if len(names) >= 8:
            break
    drives = conn.execute("""SELECT drive, label, owner, application, team FROM perm_drives
                              WHERE dataset_id = %s AND target_key IS NOT NULL
                                AND (%s = target_key OR left(%s, length(target_key) + 1) = target_key || chr(92)
                                     OR left(target_key, length(%s) + 1) = %s || chr(92))
                              LIMIT 3""", (ds_id, key, key, key, key)).fetchall()
    out = {"groups": [{"name": g["identity"][:80], "level": LEVELS[g["lv"]]} for g in groups], "subfolders": names}
    if drives:
        out["drive_information"] = [{k: (v or "")[:80] for k, v in d.items() if v} for d in drives]
    depts = conn.execute("""SELECT p.department, count(DISTINCT p.person_key) AS people
                              FROM perm_entries e
                              LEFT JOIN perm_access a ON a.dataset_id = e.dataset_id AND a.group_key = e.identity_key
                              JOIN perm_people p ON p.dataset_id = e.dataset_id AND p.person_key = coalesce(a.member_key, e.identity_key)
                             WHERE e.dataset_id = %s AND e.folder_key = %s AND e.allow AND e.level IN ('write', 'modify', 'full')
                               AND e.identity_kind NOT IN ('admin', 'system', 'broad') AND p.department IS NOT NULL
                             GROUP BY p.department ORDER BY count(DISTINCT p.person_key) DESC LIMIT 4""", (ds_id, key)).fetchall()
    if depts:
        out["departments_of_people_who_can_change_it"] = [{"department": d["department"][:60], "people": d["people"]} for d in depts]
    if ev is not None:
        x = ev.get(key, {})
        if x.get("ntfs_owner"):
            out["ntfs_owner"] = {"account": x["ntfs_owner"][:80], "kind": KIND_TEXT.get(x.get("ntfs_kind"), "account")}
            p = x.get("ntfs_person")
            if p:
                out["ntfs_owner"].update({k: (p.get(k) or "")[:60] for k in ("display_name", "department") if p.get(k)})
                if p.get("enabled") is False:
                    out["ntfs_owner"]["account_disabled"] = True
        if x.get("explicit"):
            out["given_change_rights_directly"] = [{"account": e[0][:80], "is": e[1] or "not known", "level": e[2]}
                                                   for e in x["explicit"][:8]]
    if rule:
        out["rules_found"] = {k: rule[k] for k in ("owner", "department", "confidence", "evidence") if rule.get(k) is not None}
    return out


TAG_SYSTEM = """You map file-share folders to their owner, department, owning team and business application, for an access review.
You are given folders with their evidence: the NTFS owner, the accounts given change rights on the folder directly, the
groups that have access, some sub-folder names, the departments of the people who can change it (with the numbers), and
what the rules found. You are also given examples an administrator confirmed.
For each folder answer:
- owner: the person or group accountable for it. Only an account named in that folder's evidence (the NTFS owner or an
  account given rights on it), written exactly as given; prefer a person who owns it, else the one group that can change it.
  Never an admin, system or Everyone-type account. Empty when the evidence does not show one.
- department: the department most of the people who can change it are in, or the owner's department, written exactly as
  given in the evidence or the examples. Empty when not shown.
- team and application: short names (e.g. "Finance IT", "SAP Finance"), reusing the confirmed examples' names when they fit.
  Empty when the evidence does not show them.
- confidence from 0 to 100 for the whole answer, and the reason in a few words quoting the evidence (with its numbers).
When the rules found an owner or department and the evidence agrees, keep it. Never guess from nothing. Answer only with JSON."""

TAG_SCHEMA = {"type": "object", "properties": {"items": {"type": "array", "items": {"type": "object", "properties": {
    "folder": {"type": "string"}, "owner": {"type": "string"}, "department": {"type": "string"},
    "application": {"type": "string"}, "team": {"type": "string"},
    "confidence": {"type": "integer"}, "reason": {"type": "string"}},
    "required": ["folder", "owner", "department", "application", "team", "confidence", "reason"]}}}, "required": ["items"]}


# ---- r127: every question to AI-01 fits its slot, whole --------------------------------------------------------
# AI-01 answers in slots of AI01_SLOT_TOKENS (4,096 by default: context 8,192 over 2 parallel slots). The question
# and the answer share the slot, so a question gets the slot less the answer's budget and a margin. Paths and JSON
# are about 3 characters a token; counted that way (on the safe side). A question is never cut: folders that do not
# fit wait for the next batch, and long lists are shortened (said so in the question) before anything else.

SLOT_TOKENS = int(os.environ.get("AI01_SLOT_TOKENS", "4096"))
CHARS_PER_TOKEN = 3.0
TAG_ANSWER_TOKENS = 1400
SUMMARY_ANSWER_TOKENS = 800


def est_tokens(messages):
    return int(sum(len(m["content"]) for m in messages) / CHARS_PER_TOKEN) + 8 * len(messages)


def prompt_budget(answer_tokens):
    return max(600, SLOT_TOKENS - answer_tokens - 250)


def _slim_hint(h):
    """A folder's evidence with its long lists shortened (the folder and its owner evidence kept whole)."""
    out = dict(h)
    for k, n in (("groups", 6), ("sub_folders", 4), ("given_change_rights_directly", 5), ("departments_of_people_who_can_change_it", 4)):
        if isinstance(out.get(k), list) and len(out[k]) > n:
            out[k] = out[k][:n] + [{"more": len(h[k]) - n}]
    if isinstance(out.get("rules_found"), dict) and out["rules_found"].get("evidence"):
        out["rules_found"] = dict(out["rules_found"], evidence=out["rules_found"]["evidence"][:240])
    return out


def tag_messages(folders, examples):
    data = {"confirmed_examples": examples[:15], "folders": folders}
    return [{"role": "system", "content": TAG_SYSTEM}, {"role": "user", "content": json.dumps(data)}]


def fit_tag_batch(folders, examples, budget=None):
    """(the folders that fit one question, whole; the examples kept). The first folder always goes (shortened if
    need be); the others in order while they fit."""
    budget = budget or prompt_budget(TAG_ANSWER_TOKENS)
    ex = list(examples[:15])
    while ex and est_tokens(tag_messages([_slim_hint(folders[0])], ex)) > budget // 2:
        ex = ex[:len(ex) // 2]                              # the examples never take more than half
    out = []
    for f in folders:
        for cand in (f, _slim_hint(f)):
            if est_tokens(tag_messages(out + [cand], ex)) <= budget:
                out.append(cand)
                break
        else:
            if not out:                                    # one folder alone: its lists shortened further
                g = _slim_hint(f)
                for k in ("groups", "sub_folders", "given_change_rights_directly", "departments_of_people_who_can_change_it", "drive"):
                    if est_tokens(tag_messages([g], ex)) <= budget:
                        break
                    if k in g:                             # left out, and said so
                        g[k] = [{"more": len(f[k])}] if isinstance(f.get(k), list) else {"left_out": True}
                out.append(g)
            break                                          # the next folders wait for the next batch, in order
    return out, ex


def clean_tag_text(v, limit=80):
    t = re.sub(r"[\x00-\x1f<>]", " ", str(v or "")).strip()
    return re.sub(r"\s+", " ", t)[:limit]


def _allowed_owners(hint):
    """The accounts AI-01 may name as the owner of a folder: the ones in that folder's evidence (lower case)."""
    names = set()
    if hint.get("ntfs_owner"):
        names.add(hint["ntfs_owner"]["account"])
    names.update(x["account"] for x in hint.get("given_change_rights_directly", []))
    names.update(g["name"] for g in hint.get("groups", []))
    if (hint.get("rules_found") or {}).get("owner"):
        names.add(hint["rules_found"]["owner"])
    out = {}
    for n in names:
        if identity_kind(n)[0] not in ("admin", "system", "broad", "orphan", "computer"):
            out[n.lower()] = n
            out.setdefault(ident_key(n), n)
    return out


def known_departments(conn, ds_id):
    """Departments as written in this upload's people sheet and in confirmed tags: lower case -> as written."""
    out = {}
    for r in conn.execute("""SELECT DISTINCT department AS d FROM perm_people WHERE dataset_id = %s AND department IS NOT NULL
                             UNION SELECT DISTINCT department FROM perm_tags WHERE state = 'confirmed' AND department IS NOT NULL""",
                          (ds_id,)).fetchall():
        out.setdefault(r["d"].lower(), r["d"])
    return out


def suggest_batch(conn, ds_id, ai, by="AI-01"):
    """One batch of folders (biggest first): with no tag, or the rules' suggestions AI-01 has not checked (only the
    unsure ones unless an admin asked for every folder) -> AI-01's suggestions. An owner AI-01 names must be in that
    folder's evidence and a department must be one the file or a confirmed tag has: anything else is dropped (never
    invented). Returns how many folders were looked at."""
    scope = (conn.execute("SELECT tag_ai_scope FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone() or {}).get("tag_ai_scope") or "all"
    rows = conn.execute(f"""SELECT f.folder_key, f.label, f.entries, t.key_l AS has_tag, t.owner, t.department, t.confidence, t.evidence
                              FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key
                             WHERE f.dataset_id = %(ds)s AND {UNSURE_SQL}
                             ORDER BY f.entries DESC, f.folder_key LIMIT %(n)s""", {"ds": ds_id, "all": scope == "all", "n": TAG_BATCH}).fetchall()
    if not rows:
        return 0
    examples = [{k: v for k, v in r.items() if v} for r in conn.execute(
        """SELECT label AS folder, owner, department, application, team FROM perm_tags WHERE state = 'confirmed'
            ORDER BY decided_at DESC LIMIT 15""")]
    ev, _ = owner_evidence(conn, ds_id, [r["folder_key"] for r in rows])
    hints = {}
    for r in rows:
        rule = {"owner": r["owner"], "department": r["department"], "confidence": r["confidence"], "evidence": r["evidence"]} \
            if r["has_tag"] and (r["owner"] or r["department"]) else None
        hints[r["folder_key"]] = folder_hints(conn, ds_id, r["folder_key"], ev, rule)
    depts = known_departments(conn, ds_id)
    folders = [dict({"folder": r["label"]}, **hints[r["folder_key"]]) for r in rows]
    folders, examples = fit_tag_batch(folders, examples)
    rows = rows[:len(folders)]                             # the ones that did not fit are asked in the next batch
    conn.commit()                                          # nothing held open while AI-01 thinks
    out = ai(tag_messages(folders, examples), TAG_SCHEMA)
    by_label = {r["label"].lower(): r for r in rows}
    for it in (out or {}).get("items") or []:
        r = by_label.get(str(it.get("folder") or "").strip().lower())
        if not r:
            continue                                       # a folder AI-01 made up, or renamed: ignored
        app, team = clean_tag_text(it.get("application")), clean_tag_text(it.get("team"))
        try:
            conf = max(0, min(100, int(it.get("confidence") or 0)))
        except (TypeError, ValueError):
            conf = 0
        notes = []
        owner = clean_tag_text(it.get("owner"), 200) or None
        if owner:
            ok = _allowed_owners(hints[r["folder_key"]])
            owner = ok.get(owner.lower()) or ok.get(ident_key(owner))
            if not owner:
                notes.append("its owner was not in the folder's evidence: left out")
                conf = min(conf, 50)
        dept = clean_tag_text(it.get("department"), 120) or None
        if dept:
            dept = depts.get(dept.lower())
            if not dept:
                notes.append("its department is not one the file has: left out")
                conf = min(conf, 50)
        owner_kind = None
        if owner:
            x = ev.get(r["folder_key"], {})
            owner_kind = next((e[1] for e in x.get("explicit", []) if ident_key(e[0]) == ident_key(owner)), None) or \
                (x.get("ntfs_as") if x.get("ntfs_owner") and ident_key(x["ntfs_owner"]) == ident_key(owner) else None) or \
                {"user": "person", "group": "group"}.get(identity_kind(owner)[0])
        if not (app or team or owner or dept):
            conf = min(conf, 20)
        reason = clean_tag_text("; ".join([str(it.get("reason") or "")] + notes), 300) or None
        if r["has_tag"]:                                   # the rules' (or the file's) suggestion: AI-01 fills in and may correct it
            conn.execute("""UPDATE perm_tags SET   -- the file's own application and team stay as the file says
                                   application = CASE WHEN suggested_by = 'file' THEN coalesce(application, %s) ELSE coalesce(%s, application) END,
                                   team = CASE WHEN suggested_by = 'file' THEN coalesce(team, %s) ELSE coalesce(%s, team) END,
                                   owner = coalesce(%s, owner), owner_kind = CASE WHEN %s::text IS NOT NULL THEN %s ELSE owner_kind END,
                                   department = coalesce(%s, department), confidence = %s, reason = %s,
                                   suggested_by = CASE WHEN suggested_by = 'file' OR NOT %s THEN suggested_by ELSE %s END,
                                   suggested_at = now(), ai_asked_at = now()
                             WHERE key_l = %s AND state = 'suggested'""",
                         (app or None, app or None, team or None, team or None, owner, owner, owner_kind, dept, conf if (app or team or owner or dept) else r["confidence"],
                          reason, bool(app or team or owner or dept), by, r["folder_key"]))
        else:
            conn.execute("""INSERT INTO perm_tags (key_l, label, application, team, owner, owner_kind, department, state, confidence,
                                                   reason, suggested_by, suggested_at, ai_asked_at)
                            VALUES (%s, %s, %s, %s, %s, %s, %s, 'suggested', %s, %s, %s, now(), now()) ON CONFLICT (key_l) DO NOTHING""",
                         (r["folder_key"], r["label"], app or None, team or None, owner, owner_kind, dept, conf, reason, by))
    # folders AI-01 skipped: marked as looked at, so the next batch moves on (a rules suggestion stays as it was)
    for r in rows:
        if r["has_tag"]:
            conn.execute("UPDATE perm_tags SET ai_asked_at = now() WHERE key_l = %s AND ai_asked_at IS NULL", (r["folder_key"],))
        else:
            conn.execute("""INSERT INTO perm_tags (key_l, label, state, confidence, reason, suggested_by, suggested_at, ai_asked_at)
                            VALUES (%s, %s, 'suggested', 0, 'AI-01 gave no answer for it', %s, now(), now()) ON CONFLICT (key_l) DO NOTHING""",
                         (r["folder_key"], r["label"], by))
    resolve_tags(conn, ds_id)
    return len(rows)


def owner_kind_of(conn, owner):
    """'person' or 'group' for an owner an admin typed: as the people / members sheets know it, else its name."""
    if not owner:
        return None
    k = ident_key(owner)
    if conn.execute("SELECT 1 FROM perm_people WHERE person_key = %s LIMIT 1", (k,)).fetchone():
        return "person"
    if conn.execute("SELECT 1 FROM perm_access WHERE group_key = %s LIMIT 1", (k,)).fetchone() or \
            conn.execute("SELECT 1 FROM perm_members WHERE group_key = %s LIMIT 1", (k,)).fetchone():
        return "group"
    return {"user": "person", "group": "group"}.get(identity_kind(owner)[0])


def decide(conn, user, items):
    """An admin's decisions on tags: confirm (as proposed or edited), or reject. items:
    [{key, decision: confirm|reject|clear, owner, owner_kind, department, application, team}]"""
    done = 0
    for it in items[:2000]:
        key = str(it.get("key") or "").strip().lower()[:600]
        if not key:
            continue
        d = it.get("decision")
        app, team = clean_tag_text(it.get("application")) or None, clean_tag_text(it.get("team")) or None
        owner = clean_tag_text(norm_identity(str(it.get("owner") or "")), 200) or None
        dept = clean_tag_text(it.get("department"), 120) or None
        if d == "confirm":
            if not (app or team or owner or dept):
                raise PermError(f"{key}: give the owner, the department, the team or the application before confirming.")
            if owner and identity_kind(owner)[0] in ("admin", "system", "broad"):
                raise PermError(f"{key}: {owner} is an admin, system or Everyone-type account: it cannot be the owner.")
            kind = it.get("owner_kind") if it.get("owner_kind") in OWNER_KINDS else owner_kind_of(conn, owner)
            label = clean_tag_text(it.get("label"), 600) or key
            conn.execute("""INSERT INTO perm_tags (key_l, label, application, team, owner, owner_kind, department, state, decided_by, decided_at)
                            VALUES (%s, %s, %s, %s, %s, %s, %s, 'confirmed', %s, now())
                            ON CONFLICT (key_l) DO UPDATE SET application = EXCLUDED.application, team = EXCLUDED.team,
                                owner = EXCLUDED.owner, owner_kind = EXCLUDED.owner_kind, department = EXCLUDED.department,
                                state = 'confirmed', decided_by = EXCLUDED.decided_by, decided_at = now()""",
                         (key, label, app, team, owner, kind if owner else None, dept, user))
        elif d == "reject":
            conn.execute("""UPDATE perm_tags SET state = 'rejected', decided_by = %s, decided_at = now() WHERE key_l = %s""",
                         (user, key))
        elif d == "clear":
            conn.execute("DELETE FROM perm_tags WHERE key_l = %s", (key,))
        else:
            raise PermError("Each decision is confirm, reject or clear.")
        done += 1
    resolve_tags(conn)
    return done


# ---- 5. reports ---------------------------------------------------------------------------------------------

KINDS = {
    "risk": ("Risky access overview", "Every kind of risky access in one view: open to everyone, people given rights "
             "directly, orphaned accounts, full control outside the admin groups, deny entries."),
    "by_app": ("Access by application and owning team", "For each application and team: their folders, who has access, "
               "and what is risky there."),
    "team_review": ("Access review pack per owning team", "What each owning team must confirm: their folders and every "
                    "account with write access or more, to keep or remove."),
    "broad": ("Folders open to everyone", "Folders where Everyone, Authenticated Users, Domain Users or similar broad "
              "groups can change or read data."),
    "explicit_users": ("People given rights directly", "Accounts of people added to folders directly instead of through "
                       "a group: hard to review and to remove when they leave."),
    "orphans": ("Orphaned accounts", "Deleted users or groups still listed on folders (shown as a SID): clean-up candidates."),
    "full_control": ("Full control outside the admin groups", "Accounts other than the admin and system accounts that can "
                     "change permissions and take ownership."),
    "untagged": ("Folders without an application or owner", "What still needs an application and an owning team before "
                 "it can be reviewed by its owner."),
    "by_department": ("Access by department (people grouped)", "Each department, its people, and every share and folder "
                      "each person reaches, directly or through groups: one line per person and folder, with every way in. "
                      "Shows who reaches folders owned by another team."),
    "effective": ("Who really has access (groups opened up)", "Every account that can change data, given rights directly or "
                  "through the groups it is in (nested groups opened up, from the members sheet), per folder and application."),
    "by_server": ("Summary by server and share", "For each server and share: how many folders and entries, and what is risky."),
    "ownership": ("Permissions & ownership (one row per folder)", "Every folder with its NTFS owner, its owner and department, "
                  "the owning team and application, who has access and how (given on the folder or inherited), and whether "
                  "Everyone-type groups can get in. The CSV has every folder."),
    "by_owner": ("By department & owner", "Each department, the owners of its folders (people or groups), and each owner's "
                 "folders with what is risky there. Folders without an owner or department yet are listed apart."),
}
CATS = {   # each finding's kind; an entry can be in more than one
    "broad_write": ("Open to everyone (change)", "e.identity_kind = 'broad' AND e.allow AND e.level = ANY(%(risky)s)"),
    "broad_read": ("Open to everyone (read)", "e.identity_kind = 'broad' AND e.allow AND NOT (e.level = ANY(%(risky)s)) AND e.level <> 'none'"),
    "explicit_user": ("Person given rights directly", "e.identity_kind = 'user' AND e.allow AND e.inherited IS FALSE"),
    "orphan": ("Orphaned account", "e.identity_kind = 'orphan'"),
    "full_nonadmin": ("Full control outside admins", "e.allow AND e.level = 'full' AND e.identity_kind NOT IN ('admin', 'system')"),
    "deny": ("Deny entry", "NOT e.allow"),
    "has_access": ("Has access", "e.allow AND e.level <> 'none' AND e.identity_kind NOT IN ('admin', 'system')"),
    "disabled": ("Disabled account", "e.allow AND EXISTS (SELECT 1 FROM perm_people pp WHERE pp.dataset_id = e.dataset_id "
                 "AND pp.person_key = e.identity_key AND pp.enabled IS FALSE)"),
    "stale": ("Not used for 90 days", "e.allow AND EXISTS (SELECT 1 FROM perm_people pp WHERE pp.dataset_id = e.dataset_id "
              "AND pp.person_key = e.identity_key AND pp.enabled IS NOT FALSE AND pp.last_logon < current_date - 90)"),
    "can_change": ("Can change data", "e.allow AND e.level = ANY(%(risky)s) AND e.identity_kind NOT IN ('admin', 'system')"),
}
KIND_CATS = {"risk": ["broad_write", "explicit_user", "orphan", "full_nonadmin", "deny", "disabled", "stale"], "broad": ["broad_write", "broad_read"],
             "explicit_users": ["explicit_user"], "orphans": ["orphan"], "full_control": ["full_nonadmin"],
             "by_app": ["broad_write", "explicit_user", "orphan", "full_nonadmin"], "team_review": ["broad_write", "explicit_user", "orphan", "full_nonadmin"],
             "by_server": ["broad_write", "explicit_user", "orphan", "full_nonadmin"], "untagged": ["broad_write", "explicit_user", "orphan", "full_nonadmin"],
             "effective": ["can_change"], "by_department": ["has_access"], "ownership": ["has_access"],
             "by_owner": ["broad_write", "explicit_user", "orphan", "full_nonadmin"]}
KIND_TEXT = {"user": "Person", "group": "Group", "computer": "Computer", "broad": "Everyone-type group", "admin": "Admin group",
             "system": "System account", "orphan": "Orphaned (SID)", "unknown": "Not stated in the file"}
TOP = 7


def clean_spec(conn, ds_id, spec):
    """An admin's choices, checked. Returns the clean spec."""
    if not isinstance(spec, dict):
        raise PermError("Say which report.")
    kind = spec.get("kind")
    if kind not in KINDS:
        raise PermError("Choose one of the reports.")
    sc = spec.get("scope") or {}
    op = spec.get("options") or {}
    def strs(v, n=500):
        return [clean_tag_text(x, 200) for x in (v or []) if clean_tag_text(x, 200)][:n] if isinstance(v, list) else []
    risky = [lv for lv in (op.get("risky_levels") or list(WRITE_LEVELS)) if lv in LEVELS]
    if not risky:
        raise PermError("Choose at least one access level that counts as risky.")
    tags = op.get("tags") if op.get("tags") in ("confirmed", "with_suggested") else "confirmed"
    title = clean_tag_text(spec.get("title"), 120) or KINDS[kind][0]
    return {"kind": kind, "title": title,
            "scope": {"servers": strs(sc.get("servers")), "applications": strs(sc.get("applications")), "teams": strs(sc.get("teams")),
                      "untagged": bool(sc.get("untagged", True))},
            "options": {"risky_levels": risky, "include_inherited": bool(op.get("include_inherited", True)), "tags": tags}}


def tag_cols(spec):
    """The owner and department of a folder in a report: confirmed only, or with suggestions (as the report asks)."""
    tagok = "f.tag_state = 'confirmed'" if spec["options"]["tags"] == "confirmed" else "f.tag_state IS NOT NULL"
    return f"CASE WHEN {tagok} THEN f.owner END", f"CASE WHEN {tagok} THEN f.department END"


def untagged_cond(spec, app, team):
    own, dept = tag_cols(spec)
    return f"({app} IS NULL AND {team} IS NULL AND {own} IS NULL AND {dept} IS NULL)"


def _base(spec):
    """The FROM and WHERE every figure of a report shares, and its parameters."""
    sc, op = spec["scope"], spec["options"]
    tagok = "f.tag_state = 'confirmed'" if op["tags"] == "confirmed" else "f.tag_state IS NOT NULL"
    app = f"CASE WHEN {tagok} THEN f.application END"
    team = f"CASE WHEN {tagok} THEN f.team END"
    own, dept = tag_cols(spec)
    none = f"({app} IS NULL AND {team} IS NULL AND {own} IS NULL AND {dept} IS NULL)"
    where = ["e.dataset_id = %(ds)s"]
    if not op["include_inherited"]:
        where.append("e.inherited IS NOT TRUE")
    if sc["servers"]:
        where.append("lower(coalesce(e.server, '')) = ANY(%(servers)s)")
    tag_or = []
    if sc["applications"]:
        tag_or.append(f"{app} = ANY(%(apps)s)")
    if sc["teams"]:
        tag_or.append(f"{team} = ANY(%(teams)s)")
    if tag_or:
        if sc["untagged"]:
            tag_or.append(none)
        where.append("(" + " OR ".join(tag_or) + ")")
    elif not sc["untagged"]:
        where.append(f"NOT {none}")
    frm = " FROM perm_entries e JOIN perm_folders f ON f.dataset_id = e.dataset_id AND f.folder_key = e.folder_key "
    args = {"servers": [x.lower() for x in sc["servers"]], "apps": sc["applications"], "teams": sc["teams"],
            "risky": op["risky_levels"]}
    return frm + " WHERE " + " AND ".join(where), args, app, team


# a share as people write it: \\\\server\\share, "server D:\\" for a local drive, server:/srv for Linux
SHARE_SQL = ("CASE WHEN e.share ~ '^[A-Za-z]:$' THEN coalesce(e.server || ' ', '') || e.share || chr(92) "
             "WHEN e.share LIKE '/%%' THEN coalesce(e.server || ':', '') || e.share "
             "WHEN e.server IS NULL AND e.share IS NULL THEN '(no share)' "
             "ELSE chr(92) || chr(92) || coalesce(e.server, '') || chr(92) || coalesce(e.share, '') END")


def people_cte(base, app, cond, team="NULL::text"):
    """SQL (a WITH clause ending in 'allx'): every account reaching the entries that match cond, directly or
    through a group the members sheet lists (nested groups opened up). Everyone-type groups are not opened:
    they mean everyone."""
    return f"""WITH ent AS (SELECT e.identity, e.identity_key, e.identity_kind, e.folder_key, f.label AS folder,
                                {app} AS application, {team} AS team, {rank_sql('e.level')} AS lv, {SHARE_SQL} AS share {base} AND {cond}),
     via AS (SELECT a.member AS account, a.member_key AS key, a.member_kind AS kind, ent.identity AS through, ent.folder_key,
                    ent.folder, ent.application, ent.team, ent.lv, ent.share
               FROM ent JOIN perm_access a ON a.dataset_id = %(ds)s AND a.group_key = ent.identity_key
              WHERE ent.identity_kind <> 'broad'),
     direct AS (SELECT ent.identity AS account, ent.identity_key AS key, ent.identity_kind AS kind, NULL::text AS through,
                       ent.folder_key, ent.folder, ent.application, ent.team, ent.lv, ent.share
                  FROM ent WHERE ent.identity_kind = 'broad' OR NOT EXISTS
                       (SELECT 1 FROM perm_access a WHERE a.dataset_id = %(ds)s AND a.group_key = ent.identity_key)),
     allx AS (SELECT * FROM via UNION ALL SELECT * FROM direct)"""


NO_DEPT = "(department not in the file)"
PERSON_KINDS = "('user', 'unknown', 'computer')"
DEPT_TOP, DEPT_PEOPLE, PERSON_FOLDERS = 40, 150, 80


def person_info(conn, ds_id, keys):
    """Department, full name and title of people, by their short key."""
    out = {}
    for r in conn.execute("""SELECT person_key, department, display_name, title, conflicts FROM perm_people
                              WHERE dataset_id = %s AND person_key = ANY(%s)""", (ds_id, list(keys))).fetchall():
        out[r["person_key"]] = {"department": r["department"], "display_name": r["display_name"], "title": r["title"],
                                "dept_conflicts": r["conflicts"]}
    return out


def department_report(conn, ds_id, base, app, team, anycat, args, spec):
    """Department -> its people -> the shares and folders each reaches. One line per person and folder:
    the highest level and every way in (directly, through which groups). Counted by PostgreSQL."""
    risky = [RANK[x] for x in spec["options"]["risky_levels"]]
    cte = people_cte(base, app, anycat, team) + f""",
     px AS (SELECT allx.*, coalesce(p.department, %(nodept)s) AS dept FROM allx
              LEFT JOIN perm_people p ON p.dataset_id = %(ds)s AND p.person_key = allx.key
             WHERE p.person_key IS NOT NULL OR allx.kind IN {PERSON_KINDS})"""
    a = dict(args, nodept=NO_DEPT, risky_ranks=risky)
    q = lambda sql, x=None: conn.execute(cte + sql, x or a).fetchall()      # noqa: E731
    depts = q("""SELECT dept AS name, count(DISTINCT key) AS people, count(DISTINCT share) AS shares,
                        count(DISTINCT folder_key) AS folders,
                        count(DISTINCT key) FILTER (WHERE lv = ANY(%(risky_ranks)s)) AS can_change,
                        count(DISTINCT key) FILTER (WHERE lv = ANY(%(risky_ranks)s) AND team IS NOT NULL
                                                    AND lower(team) <> lower(dept) AND dept <> %(nodept)s) AS outside_people
                   FROM px GROUP BY dept ORDER BY count(DISTINCT key) DESC, dept""")
    per = q("""SELECT dept, key, min(account) AS account, min(kind) AS kind, count(DISTINCT share) AS shares,
                      count(DISTINCT folder_key) AS folders, max(lv) AS worst
                 FROM px GROUP BY dept, key ORDER BY dept, count(DISTINCT folder_key) DESC, key""")
    chosen, by_dept = [], {}
    for r in per:
        lst = by_dept.setdefault(r["dept"], [])
        if len(lst) < DEPT_PEOPLE:
            lst.append(r)
    top = [d["name"] for d in depts[:DEPT_TOP]]
    for d in top:
        chosen += [r["key"] for r in by_dept.get(d, [])]
    rows = q("""SELECT dept, key, share, folder, folder_key, min(application) AS application, min(team) AS team, max(lv) AS lv,
                       array_agg(DISTINCT coalesce(through, '')) AS routes
                  FROM px WHERE key = ANY(%(keys)s)
                 GROUP BY dept, key, share, folder, folder_key ORDER BY dept, key, share, folder""", dict(a, keys=chosen))
    folders = {}
    for r in rows:
        folders.setdefault((r["dept"], r["key"]), []).append(r)
    info = person_info(conn, ds_id, chosen)
    view = []
    for d in depts[:DEPT_TOP]:
        ppl = []
        for r in by_dept.get(d["name"], []):
            fl = folders.get((d["name"], r["key"]), [])
            shares = {}
            for f in fl:
                shares.setdefault(f["share"], []).append(f)
            share_list = []
            for sh, fs in sorted(shares.items(), key=lambda x: (-max(f["lv"] for f in x[1]), x[0].lower())):
                share_list.append({"share": sh, "level": LEVELS[max(f["lv"] for f in fs)],
                                   "folders": [{"folder": f["folder"], "level": LEVELS[f["lv"]], "application": f["application"],
                                                "team": f["team"], "direct": "" in f["routes"],
                                                "via": sorted(x for x in f["routes"] if x),
                                                "outside": bool(f["team"] and d["name"] != NO_DEPT and f["lv"] in risky
                                                                and f["team"].lower() != d["name"].lower())}
                                               for f in fs[:PERSON_FOLDERS]]})
            pi = info.get(r["key"], {})
            ppl.append({"account": r["account"], "key": r["key"], "kind": r["kind"], "shares": r["shares"], "folders": r["folders"],
                        "worst": LEVELS[r["worst"]], "display_name": pi.get("display_name"), "title": pi.get("title"),
                        "dept_conflicts": pi.get("dept_conflicts"), "share_list": share_list})
        view.append({"department": d["name"], "people": d["people"], "shown": len(ppl), "list": ppl})
    outside = q("""SELECT dept, min(account) AS account, key, folder, min(team) AS team, max(lv) AS lv,
                          array_agg(DISTINCT coalesce(through, '')) AS routes
                     FROM px WHERE lv = ANY(%(risky_ranks)s) AND team IS NOT NULL AND dept <> %(nodept)s AND lower(team) <> lower(dept)
                    GROUP BY dept, key, folder ORDER BY dept, key, folder LIMIT 500""")
    outside_total = q("""SELECT count(*) AS n FROM (SELECT DISTINCT key, folder_key FROM px WHERE lv = ANY(%(risky_ranks)s)
                           AND team IS NOT NULL AND dept <> %(nodept)s AND lower(team) <> lower(dept)) t""")[0]["n"]
    for o in outside:
        o["level"] = LEVELS[o.pop("lv")]
        o["direct"] = "" in o["routes"]
        o["via"] = sorted(x for x in o.pop("routes") if x)
    unopened = q("SELECT count(DISTINCT key) AS n FROM allx WHERE kind = 'group'")[0]["n"]
    return depts, {"view": view, "outside": outside, "outside_total": outside_total, "groups_not_opened": unopened,
                   "people_total": q("SELECT count(DISTINCT key) AS n FROM px")[0]["n"]}


OWN_FOLDERS, OWN_ACCOUNTS, OWNERS_PER_DEPT, FOLDERS_PER_OWNER = 1000, 40, 60, 60
NO_OWNER, NO_OWNER_DEPT = "(no owner yet)", "(no department yet)"
EVERYONE_TEXT = {"change": "Everyone can change", "read": "Everyone can read", None: ""}


def _folder_access_sql(base):
    """Per folder and account: highest allowed level, given on the folder itself or inherited, deny."""
    return f"""SELECT e.folder_key, min(e.identity) AS identity, min(e.identity_kind) AS kind,
                      max({rank_sql('e.level')}) FILTER (WHERE e.allow) AS lv,
                      bool_or(e.inherited IS FALSE) AS explicit, bool_or(e.inherited IS TRUE) AS inherited,
                      bool_or(e.inherited IS NULL) AS inherit_unknown, bool_or(NOT e.allow) AS deny
                 {base} GROUP BY e.folder_key, lower(e.identity)"""


ACCESS_GROUPS = (("people", "People and groups"), ("everyone", "Everyone-type groups"), ("admin", "Admin and system"),
                 ("orphan", "Orphaned SIDs (accounts that no longer exist)"))


def access_group(kind):
    return {"broad": "everyone", "admin": "admin", "system": "admin", "orphan": "orphan"}.get(kind, "people")


def ownership_rows(conn, base, args, app, team, own, dept, limit=None):
    """One row per folder in scope: NTFS owner, owner, department, team, application, who has access and how."""
    lim = f" LIMIT {int(limit)}" if limit else ""
    folders = conn.execute(f"""SELECT f.folder_key, f.label AS folder, f.server, f.ntfs_owner, {own} AS owner,
                                      CASE WHEN {own} IS NOT NULL THEN f.owner_kind END AS owner_kind, {dept} AS department,
                                      {team} AS team, {app} AS application, f.tag_state,
                                      count(*) AS entries, count(*) FILTER (WHERE e.inherited IS FALSE) AS explicit_entries,
                                      count(*) FILTER (WHERE e.inherited IS TRUE) AS inherited_entries,
                                      count(DISTINCT lower(e.identity)) FILTER (WHERE e.allow AND e.level <> 'none'
                                            AND e.identity_kind NOT IN ('admin', 'system')) AS accounts,
                                      bool_or(e.identity_kind = 'broad' AND e.allow AND e.level = ANY(%(risky)s)) AS everyone_change,
                                      bool_or(e.identity_kind = 'broad' AND e.allow AND e.level <> 'none') AS everyone_any,
                                      count(*) FILTER (WHERE e.allow AND e.identity_kind NOT IN ('admin', 'system', 'broad') AND e.level = ANY(%(risky)s)) AS can_change
                                 {base} GROUP BY f.dataset_id, f.folder_key
                                 ORDER BY f.label, f.folder_key{lim}""", args).fetchall()
    keys = [f["folder_key"] for f in folders]
    acc = {}
    if keys:
        for r in conn.execute(_folder_access_sql(base + " AND e.folder_key = ANY(%(fkeys)s)") +
                              " ORDER BY e.folder_key, max(" + rank_sql("e.level") + ") FILTER (WHERE e.allow) DESC NULLS LAST, min(e.identity)",
                              dict(args, fkeys=keys)).fetchall():
            acc.setdefault(r["folder_key"], []).append(r)
    for f in folders:
        f["everyone"] = "change" if f.pop("everyone_change") else "read" if f.pop("everyone_any") else None
        f["orphans"] = sum(1 for r in acc.get(f["folder_key"], []) if r["kind"] == "orphan")
        lst = acc.get(f["folder_key"], [])
        f["access"] = [{"account": r["identity"], "kind": r["kind"], "group": access_group(r["kind"]),
                        "level": LEVELS[r["lv"]] if r["lv"] is not None else None,
                        "how": "given here" if r["explicit"] and not r["inherited"] else "inherited" if r["inherited"] and not r["explicit"]
                        else "given here and inherited" if r["explicit"] else "not stated", "deny": r["deny"]} for r in lst]
    return folders


def ownership_report(conn, ds_id, base, args, app, team, spec):
    own, dept = tag_cols(spec)
    rows = ownership_rows(conn, base, args, app, team, own, dept, OWN_FOLDERS + 1)
    more = len(rows) > OWN_FOLDERS
    rows = rows[:OWN_FOLDERS]
    for f in rows:
        f["accounts_shown"] = len(f["access"][:OWN_ACCOUNTS])
        f["access_total"] = len(f["access"])
        f["access"] = f["access"][:OWN_ACCOUNTS]
    total = conn.execute(f"SELECT count(DISTINCT e.folder_key) AS n {base}", args).fetchone()["n"]
    c = conn.execute(f"""SELECT count(DISTINCT f.folder_key) FILTER (WHERE {own} IS NOT NULL) AS with_owner,
                                count(DISTINCT f.folder_key) FILTER (WHERE {own} IS NOT NULL AND f.owner_kind = 'person') AS person_owner,
                                count(DISTINCT f.folder_key) FILTER (WHERE {own} IS NOT NULL AND f.owner_kind = 'group') AS group_owner,
                                count(DISTINCT f.folder_key) FILTER (WHERE {dept} IS NOT NULL) AS with_department,
                                count(DISTINCT f.folder_key) FILTER (WHERE f.ntfs_owner IS NOT NULL) AS with_ntfs_owner,
                                count(DISTINCT f.folder_key) FILTER (WHERE e.identity_kind = 'broad' AND e.allow AND e.level = ANY(%(risky)s)) AS everyone_change,
                                count(DISTINCT f.folder_key) FILTER (WHERE e.identity_kind = 'broad' AND e.allow AND e.level <> 'none') AS everyone_any
                           {base}""", args).fetchone()
    orphans = conn.execute(f"""SELECT min(e.identity) AS sid, count(DISTINCT e.folder_key) AS folders, count(*) AS entries,
                                      max({rank_sql('e.level')}) FILTER (WHERE e.allow) AS lv,
                                      count(*) FILTER (WHERE e.inherited IS FALSE) AS explicit,
                                      count(*) FILTER (WHERE e.inherited IS TRUE) AS inherited,
                                      (array_agg(DISTINCT f.label))[1:5] AS some_folders
                                 {base} AND e.identity_kind = 'orphan'
                                GROUP BY lower(e.identity) ORDER BY count(DISTINCT e.folder_key) DESC, min(e.identity) LIMIT 501""",
                           args).fetchall()
    for o in orphans:
        o["level"] = LEVELS[o.pop("lv")] if o.get("lv") is not None else None
    return {"folders": rows, "total": total, "more": more, "counts": c, "orphans": orphans[:500], "orphans_more": len(orphans) > 500}


def by_owner_report(conn, ds_id, base, args, app, team, anycat, spec):
    """Department -> owners -> their folders, counted by PostgreSQL."""
    own, dept = tag_cols(spec)
    a = dict(args, noown=NO_OWNER, nodept=NO_OWNER_DEPT)
    rows = conn.execute(f"""SELECT coalesce({dept}, %(nodept)s) AS department, coalesce({own}, %(noown)s) AS owner,
                                   CASE WHEN {own} IS NOT NULL THEN f.owner_kind END AS owner_kind,
                                   f.label AS folder, f.folder_key, {team} AS team, {app} AS application, f.ntfs_owner, f.tag_state,
                                   count(*) AS entries, count(*) FILTER (WHERE {anycat}) AS findings,
                                   count(DISTINCT lower(e.identity)) FILTER (WHERE e.allow AND e.level <> 'none'
                                         AND e.identity_kind NOT IN ('admin', 'system')) AS accounts,
                                   """ + ", ".join(f"count(*) FILTER (WHERE {CATS[c][1]}) AS {c}" for c in ("broad_write", "broad_read", "explicit_user", "orphan", "full_nonadmin")) + f"""
                              {base}
                             GROUP BY f.dataset_id, f.folder_key
                             ORDER BY 1, 2, f.label""", a).fetchall()
    depts = {}
    for r in rows:
        d = depts.setdefault(r["department"], {"department": r["department"], "folders": 0, "findings": 0, "entries": 0, "owners": {}})
        d["folders"] += 1
        d["findings"] += r["findings"]
        d["entries"] += r["entries"]
        o = d["owners"].setdefault(r["owner"], {"owner": r["owner"], "owner_kind": r["owner_kind"], "folders": 0, "findings": 0,
                                                "broad_write": 0, "list": []})
        o["folders"] += 1
        o["findings"] += r["findings"]
        o["broad_write"] += 1 if r["broad_write"] else 0
        if len(o["list"]) < FOLDERS_PER_OWNER:
            o["list"].append({k: r[k] for k in ("folder", "team", "application", "ntfs_owner", "tag_state", "entries", "findings", "accounts",
                                                "broad_write", "broad_read", "explicit_user", "orphan", "full_nonadmin")})
    out = []
    for d in sorted(depts.values(), key=lambda d: (d["department"] == NO_OWNER_DEPT, -d["folders"], d["department"].lower())):
        owners = sorted(d["owners"].values(), key=lambda o: (o["owner"] == NO_OWNER, -o["folders"], o["owner"].lower()))
        d["owner_count"] = sum(1 for o in owners if o["owner"] != NO_OWNER)
        d["owners_total"] = len(owners)
        d["owners"] = owners[:OWNERS_PER_DEPT]
        out.append(d)
    return out


def compute(conn, ds_id, spec):
    """Every figure of a report, counted from the rows."""
    base, args, app, team = _base(spec)
    args["ds"] = ds_id
    cats = KIND_CATS[spec["kind"]]
    anycat = "(" + " OR ".join("(" + CATS[c][1] + ")" for c in cats) + ")"
    if spec["kind"] == "untagged":
        anycat = untagged_cond(spec, app, team)
    q = lambda sql: conn.execute(sql, args).fetchall()      # noqa: E731
    k = q(f"""SELECT count(*) AS entries, count(DISTINCT e.folder_key) AS folders, count(DISTINCT lower(e.path)) AS paths,
                     count(DISTINCT lower(e.identity)) AS identities, count(*) FILTER (WHERE {anycat}) AS findings,
                     count(DISTINCT e.folder_key) FILTER (WHERE {anycat}) AS folders_with,
                     count(DISTINCT {app}) AS applications, count(DISTINCT {team}) AS teams,
                     count(*) FILTER (WHERE e.identity_kind = 'unknown') AS kind_unknown,
                     count(*) FILTER (WHERE e.inherited IS NULL) AS inherit_unknown
                {base}""")[0]
    cat_counts = q("SELECT " + ", ".join(f"count(*) FILTER (WHERE {CATS[c][1]}) AS {c}" for c in CATS) + base)[0]
    levels = {r["level"]: r["n"] for r in q(f"SELECT e.level, count(*) AS n {base} AND e.allow GROUP BY e.level")}
    kinds = {r["identity_kind"]: r["n"] for r in q(f"SELECT e.identity_kind, count(*) AS n {base} GROUP BY e.identity_kind")}

    def by(expr, label_null):
        rows = q(f"""SELECT {expr} AS name, count(*) AS entries, count(*) FILTER (WHERE {anycat}) AS findings,
                            count(DISTINCT e.folder_key) AS folders, count(DISTINCT lower(e.identity)) AS identities,
                            """ + ", ".join(f"count(*) FILTER (WHERE {CATS[c][1]}) AS {c}" for c in CATS) +
                 f" {base} GROUP BY 1 ORDER BY count(*) FILTER (WHERE {anycat}) DESC, count(*) DESC")
        for r in rows:
            r["name"] = r["name"] if r["name"] is not None else label_null
        return rows
    apps = by(app, "Not tagged")
    teams = by(team, "Not tagged")
    servers = by("coalesce(e.server, '(not in the file)') || CASE WHEN e.share IS NOT NULL THEN ' · ' || e.share ELSE '' END",
                 "(not in the file)")
    folders = q(f"""SELECT f.label AS folder, {app} AS application, {team} AS team, f.tag_state AS tag_state,
                           count(*) AS entries, count(*) FILTER (WHERE {anycat}) AS findings,
                           """ + ", ".join(f"count(*) FILTER (WHERE {CATS[c][1]}) AS {c}" for c in CATS) + f"""
                      {base} GROUP BY f.label, 2, 3, f.tag_state
                      ORDER BY count(*) FILTER (WHERE {anycat}) DESC, count(*) DESC, f.label LIMIT 200""")
    who = q(f"""SELECT e.identity, e.identity_kind, count(*) AS findings, count(DISTINCT e.folder_key) AS folders,
                       max({rank_sql('e.level')}) AS worst
                  {base} AND {anycat} GROUP BY e.identity, e.identity_kind
                  ORDER BY count(*) DESC, e.identity LIMIT 100""")
    has_members = bool(conn.execute("SELECT 1 FROM perm_access WHERE dataset_id = %s LIMIT 1", (ds_id,)).fetchone())
    behind = {}
    if has_members and who:
        behind = {r["group_key"]: r["n"] for r in conn.execute(
            """SELECT group_key, count(*) AS n FROM perm_access WHERE dataset_id = %s AND group_key = ANY(%s) GROUP BY group_key""",
            (ds_id, [ident_key(w["identity"]) for w in who])).fetchall()}
    for w in who:
        w["worst"] = LEVELS[w["worst"]]
        w["behind"] = behind.get(ident_key(w["identity"])) if w["identity_kind"] != "broad" else None
    people, people_total = [], None
    if has_members:
        k["accounts_behind"] = q(people_cte(base, app, "e.allow", team) + " SELECT count(DISTINCT key) AS n FROM via")[0]["n"]
    if spec["kind"] == "effective":
        cte = people_cte(base, app, anycat, team)
        people_total = q(cte + " SELECT count(DISTINCT key) AS n FROM allx")[0]["n"]
        people = q(cte + """ SELECT min(account) AS account, key, min(kind) AS kind, count(DISTINCT folder_key) AS folders,
                                     max(lv) AS worst, count(DISTINCT application) AS applications,
                                     (array_agg(DISTINCT through) FILTER (WHERE through IS NOT NULL))[1:4] AS through,
                                     bool_or(through IS NULL) AS direct
                                FROM allx GROUP BY key ORDER BY count(DISTINCT folder_key) DESC, max(lv) DESC, key LIMIT 300""")
        for r in people:
            r["worst"] = LEVELS[r["worst"]]
            r["through"] = r["through"] or []
    has_people = bool(conn.execute("SELECT 1 FROM perm_people WHERE dataset_id = %s LIMIT 1", (ds_id,)).fetchone())
    if has_people and people:
        info = person_info(conn, ds_id, [r["key"] for r in people])
        for r in people:
            r.update(info.get(r["key"], {"department": None}))
    ownership = owners_view = None
    if spec["kind"] == "ownership":
        ownership = ownership_report(conn, ds_id, base, args, app, team, spec)
    if spec["kind"] == "by_owner":
        owners_view = by_owner_report(conn, ds_id, base, args, app, team, anycat, spec)
    departments = dept_view = None
    if spec["kind"] == "by_department":
        departments, dept_view = department_report(conn, ds_id, base, app, team, anycat, args, spec)
    _, find_sql, _ = compute_sql_only(ds_id, spec)
    findings = conn.execute(find_sql + " LIMIT 500", args).fetchall()
    for f in findings:
        f["why"] = [CATS[c][0] for c in CATS if f.pop(c) and c in cats]
    team_sections = []
    if spec["kind"] == "team_review":
        for t in teams[:40]:
            cond = f"{team} IS NULL" if t["name"] == "Not tagged" else f"{team} = %(t)s"
            rows = conn.execute(f"""SELECT f.label AS folder, e.identity, e.identity_kind, e.identity_key,
                                           max({rank_sql('e.level')}) AS lv,
                                           bool_or({anycat}) AS risky
                                      {base} AND {cond} AND e.allow AND e.level IN ('write', 'modify', 'full')
                                       AND e.identity_kind NOT IN ('system', 'admin')
                                     GROUP BY f.label, e.identity, e.identity_kind, e.identity_key ORDER BY f.label, lv DESC, e.identity LIMIT 400""",
                                dict(args, t=t["name"])).fetchall()
            members = {}
            gkeys = list({r["identity_key"] for r in rows if r["identity_kind"] != "broad" and r["identity_key"]})
            if has_members and gkeys:
                for g in conn.execute("""SELECT group_key, count(*) AS n, (array_agg(member ORDER BY member))[1:30] AS names
                                           FROM perm_access WHERE dataset_id = %s AND group_key = ANY(%s) GROUP BY group_key""",
                                      (ds_id, gkeys)).fetchall():
                    members[g["group_key"]] = {"n": g["n"], "names": g["names"]}
            team_sections.append({"team": t["name"], "rows": [{"folder": r["folder"], "identity": r["identity"],
                                  "kind": r["identity_kind"], "level": LEVELS[r["lv"]], "risky": r["risky"],
                                  "members": members.get(r["identity_key"])} for r in rows]})

    def donut_of(rows, key="findings"):
        rows = [r for r in rows if r[key]]
        named = [r for r in rows if r["name"] != "Not tagged"]
        top, rest = named[:TOP], named[TOP:]
        segs = [{"label": r["name"], "value": r[key]} for r in top]
        if rest:
            segs.append({"label": f"Other ({len(rest)})", "value": sum(r[key] for r in rest), "other": True})
        nt = [r for r in rows if r["name"] == "Not tagged"]
        if nt:
            segs.append({"label": "Not tagged", "value": nt[0][key], "untagged": True})
        return segs
    measure = "entries" if spec["kind"] in ("untagged", "by_server") else "findings"
    return {
        "kpis": k, "categories": {c: {"label": CATS[c][0], "n": cat_counts[c], "in_report": c in cats} for c in CATS},
        "levels": [{"level": lv, "label": LEVEL_TEXT[lv], "n": levels.get(lv, 0)} for lv in reversed(LEVELS) if levels.get(lv)],
        "kinds": [{"kind": kd, "label": KIND_TEXT[kd], "n": n} for kd, n in sorted(kinds.items(), key=lambda x: -x[1])],
        "donuts": {"applications": donut_of(apps, measure), "teams": donut_of(teams, measure),
                   "servers": [{"label": r["name"], "value": r[measure]} for r in servers[:TOP] if r[measure]] +
                              ([{"label": f"Other ({len(servers) - TOP})", "value": sum(r[measure] for r in servers[TOP:]), "other": True}]
                               if len(servers) > TOP and sum(r[measure] for r in servers[TOP:]) else [])},
        "measure": measure,
        "dept_donut": ([{"label": d["name"], "value": d["people"], "untagged": d["name"] == NO_DEPT}
                        for d in departments if d["name"] != NO_DEPT][:TOP] +
                       ([{"label": f"Other ({len([d for d in departments if d['name'] != NO_DEPT]) - TOP})",
                          "value": sum(d["people"] for d in [d for d in departments if d["name"] != NO_DEPT][TOP:]), "other": True}]
                        if len([d for d in departments if d["name"] != NO_DEPT]) > TOP else []) +
                       [{"label": "Department not in the file", "value": d["people"], "untagged": True}
                        for d in departments if d["name"] == NO_DEPT]) if departments else None,
        "applications": apps[:200], "teams": teams[:200], "servers": servers[:200], "folders": folders, "who": who,
        "findings": findings, "findings_total": k["findings"], "team_sections": team_sections,
        "people": people, "people_total": people_total, "has_members": has_members, "has_people": has_people,
        "departments": departments, "department_view": dept_view, "ownership": ownership, "owners_view": owners_view,
        "owner_donut": ([{"label": "No department yet" if d["department"] == NO_OWNER_DEPT else d["department"], "value": d["folders"], "untagged": d["department"] == NO_OWNER_DEPT}
                         for d in owners_view[:TOP]] + ([{"label": f"Other ({len(owners_view) - TOP})",
                                                          "value": sum(d["folders"] for d in owners_view[TOP:]), "other": True}]
                                                        if len(owners_view) > TOP else [])) if owners_view else None,
        "shares": [dict(r) for r in conn.execute("SELECT name, unc, path, description, access FROM perm_shares WHERE dataset_id = %s ORDER BY name",
                                                 (ds_id,)).fetchall()],
        "scan_errors": (conn.execute("SELECT scan_errors->'total' AS n FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone() or {}).get("n"),
    }, find_sql, args


def make_report(conn, ds_id, spec, user):
    ds = conn.execute("SELECT state FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known.")
    if ds["state"] != "ready":
        raise PermError("The rows are not ready yet: confirm the columns first.")
    spec = clean_spec(conn, ds_id, spec)
    r = conn.execute("""INSERT INTO perm_reports (dataset_id, kind, title, spec, created_by)
                        VALUES (%s, %s, %s, %s::jsonb, %s) RETURNING id::text AS id""",
                     (ds_id, spec["kind"], spec["title"], json.dumps(spec), user)).fetchone()
    return r["id"]


def build_report(conn, report_id):
    """The worker counts a report's figures (a million rows take a few seconds: not in the web request)."""
    r = conn.execute("SELECT dataset_id::text AS ds, spec FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
    conn.execute("UPDATE perm_reports SET state = 'computing' WHERE id = %s", (report_id,))
    conn.commit()
    result, _, _ = compute(conn, r["ds"], r["spec"])
    conn.execute("UPDATE perm_reports SET result = %s::jsonb, state = 'ready', error = NULL WHERE id = %s",
                 (json.dumps(result, default=str), report_id))
    conn.commit()


CSV_COLS = ["Folder", "Path", "Account", "Kind of account", "Access level", "Rights as in the file", "Allow or deny", "Inherited",
            "Application", "Owning team", "Why it is in the report", "Owner", "Department", "NTFS owner"]
FOLDER_COLS = ["Folder", "Server", "NTFS owner (Windows)", "Business owner", "Business owner is", "Department", "Owning team",
               "Application", "Tag", "Everyone-type groups", "Accounts with access", "People and groups (level, how)",
               "Everyone-type (level, how)", "Admin and system (level, how)", "Orphaned SIDs (level, how)",
               "Entries given here", "Entries inherited"]
ORPHAN_COLS = ["Orphaned SID", "Folders", "Entries", "Highest level", "Given on the folder", "Inherited", "Some of its folders"]


def safe_csv(v):
    """A cell a spreadsheet will never run as a formula."""
    t = "" if v is None else str(v)
    return "'" + t if t[:1] in ("=", "+", "-", "@", "\t", "\r") else t


def findings_csv(conn, report_id):
    """Every finding of a report (not only the first 500), as CSV text, counted again from the rows."""
    rep = conn.execute("SELECT dataset_id::text AS ds, spec, state FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
    if not rep:
        raise PermError("That report is not known.")
    if rep["state"] != "ready":
        raise PermError("The report is still being counted.")
    spec = rep["spec"] if isinstance(rep["spec"], dict) else json.loads(rep["spec"])
    _, sql, args = compute_sql_only(rep["ds"], spec)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(CSV_COLS)
    cats = KIND_CATS[spec["kind"]]
    for f in conn.execute(sql, args):
        why = [CATS[c][0] for c in CATS if f.get(c) and c in cats]
        w.writerow([safe_csv(x) for x in (f["folder"], f["path"], f["identity"], KIND_TEXT.get(f["identity_kind"], f["identity_kind"]),
                                          LEVEL_TEXT.get(f["level"], f["level"]), f["rights_raw"], "Allow" if f["allow"] else "Deny",
                                          {True: "Yes", False: "No"}.get(f["inherited"], "Not in the file"),
                                          f["application"] or "", f["team"] or "", "; ".join(why) or "Not tagged",
                                          f["owner"] or "", f["department"] or "", f["ntfs_owner"] or "")])
    return "\ufeff" + buf.getvalue()


def orphans_csv(conn, report_id):
    """A 'Permissions & ownership' report: every orphaned SID with the folders it is on."""
    rep = conn.execute("SELECT dataset_id::text AS ds, spec, state FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
    if not rep:
        raise PermError("That report is not known.")
    if rep["state"] != "ready":
        raise PermError("The report is still being counted.")
    spec = rep["spec"] if isinstance(rep["spec"], dict) else json.loads(rep["spec"])
    base, args, app, team = _base(spec)
    args["ds"] = rep["ds"]
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(ORPHAN_COLS)
    for o in conn.execute(f"""SELECT min(e.identity) AS sid, count(DISTINCT e.folder_key) AS folders, count(*) AS entries,
                                     max({rank_sql('e.level')}) FILTER (WHERE e.allow) AS lv,
                                     count(*) FILTER (WHERE e.inherited IS FALSE) AS explicit, count(*) FILTER (WHERE e.inherited IS TRUE) AS inh,
                                     string_agg(DISTINCT f.label, '; ') AS folders_list
                                {base} AND e.identity_kind = 'orphan' GROUP BY lower(e.identity) ORDER BY 2 DESC, 1""", args).fetchall():
        w.writerow([safe_csv(x) for x in (o["sid"], o["folders"], o["entries"],
                                          LEVEL_TEXT.get(LEVELS[o["lv"]], "") if o["lv"] is not None else "Deny only",
                                          o["explicit"], o["inh"], (o["folders_list"] or "")[:30000])])
    return "\ufeff" + buf.getvalue()


def folders_csv(conn, report_id):
    """A 'Permissions & ownership' report: every folder in scope, one line each (not only the first 1,000)."""
    rep = conn.execute("SELECT dataset_id::text AS ds, spec, state FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
    if not rep:
        raise PermError("That report is not known.")
    if rep["state"] != "ready":
        raise PermError("The report is still being counted.")
    spec = rep["spec"] if isinstance(rep["spec"], dict) else json.loads(rep["spec"])
    base, args, app, team = _base(spec)
    args["ds"] = rep["ds"]
    own, dept = tag_cols(spec)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(FOLDER_COLS)
    for f in ownership_rows(conn, base, args, app, team, own, dept):
        def who(g):
            return "; ".join(f"{a['account']}: " + ("Deny" if a["deny"] and not a["level"] else LEVEL_TEXT.get(a["level"], a["level"] or ""))
                             + (" + deny" if a["deny"] and a["level"] else "") + f" ({a['how']})" for a in f["access"] if a["group"] == g)
        w.writerow([safe_csv(x) for x in (f["folder"], f["server"] or "", f["ntfs_owner"] or "", f["owner"] or "",
                                          {"person": "Person", "group": "Group or team"}.get(f["owner_kind"], ""), f["department"] or "",
                                          f["team"] or "", f["application"] or "",
                                          {"confirmed": "Confirmed", "suggested": "Suggested"}.get(f["tag_state"], "None"),
                                          EVERYONE_TEXT[f["everyone"]], f["accounts"], who("people"), who("everyone"), who("admin"),
                                          who("orphan"), f["explicit_entries"], f["inherited_entries"])])
    return "\ufeff" + buf.getvalue()


PEOPLE_COLS = ["Department", "Account", "Full name", "Kind of account", "Share", "Folder", "Highest access level", "How",
               "Application", "Owning team"]


def people_csv(conn, report_id):
    """Every account and folder of a 'who really has access' or 'by department' report: one line per
    account and folder, the highest level and every way in."""
    rep = conn.execute("SELECT dataset_id::text AS ds, spec, state FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
    if not rep:
        raise PermError("That report is not known.")
    if rep["state"] != "ready":
        raise PermError("The report is still being counted.")
    spec = rep["spec"] if isinstance(rep["spec"], dict) else json.loads(rep["spec"])
    base, args, app, team = _base(spec)
    args["ds"] = rep["ds"]
    args["nodept"] = NO_DEPT
    cats = KIND_CATS[spec["kind"]]
    anycat = "(" + " OR ".join("(" + CATS[c][1] + ")" for c in cats) + ")"
    keep = f"WHERE p.person_key IS NOT NULL OR allx.kind IN {PERSON_KINDS}" if spec["kind"] == "by_department" else ""
    sql = people_cte(base, app, anycat, team) + f""" SELECT coalesce(min(p.department), %(nodept)s) AS dept, min(allx.account) AS account,
                                                            min(p.display_name) AS display_name, min(allx.kind) AS kind, allx.share,
                                                            allx.folder, max(allx.lv) AS lv,
                                                            array_agg(DISTINCT coalesce(allx.through, '')) AS routes,
                                                            min(allx.application) AS application, min(allx.team) AS team
                                                       FROM allx LEFT JOIN perm_people p ON p.dataset_id = %(ds)s AND p.person_key = allx.key
                                                      {keep}
                                                      GROUP BY allx.key, allx.share, allx.folder
                                                      ORDER BY 1, allx.key, allx.share, allx.folder"""
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(PEOPLE_COLS)
    for r in conn.execute(sql, args):
        how = "; ".join((["directly"] if "" in r["routes"] else []) + ["via " + x for x in sorted(x for x in r["routes"] if x)])
        w.writerow([safe_csv(x) for x in (r["dept"], r["account"], r["display_name"] or "", KIND_TEXT.get(r["kind"], r["kind"]),
                                          r["share"], r["folder"], LEVEL_TEXT.get(LEVELS[r["lv"]], ""), how,
                                          r["application"] or "", r["team"] or "")])
    return "\ufeff" + buf.getvalue()


def compute_sql_only(ds_id, spec):
    base, args, app, team = _base(spec)
    args["ds"] = ds_id
    cats = KIND_CATS[spec["kind"]]
    anycat = "(" + " OR ".join("(" + CATS[c][1] + ")" for c in cats) + ")"
    if spec["kind"] == "untagged":
        anycat = untagged_cond(spec, app, team)
    own, dept = tag_cols(spec)
    sql = (f"""SELECT e.path, e.identity, e.identity_kind, e.kind_source, e.level, e.rights_raw, e.allow, e.inherited,
                      {app} AS application, {team} AS team, {own} AS owner, {dept} AS department, f.ntfs_owner,
                      f.label AS folder, """ +
           ", ".join(f"({CATS[c][1]}) AS {c}" for c in CATS) +
           f" {base} AND {anycat} ORDER BY CASE e.level WHEN 'full' THEN 0 WHEN 'modify' THEN 1 WHEN 'write' THEN 2 ELSE 3 END,"
           " lower(e.path), lower(e.identity), e.rn")
    return None, sql, args


# ---- AI-01: which reports fit, and the summary ----------------------------------------------------------------

ADVICE_SYSTEM = """You help an administrator choose access-review reports for a file and folder permissions export.
You are given counts from the file. Recommend up to four reports from the list, the most useful first, each with one
sentence of why, quoting only counts you were given. Never invent a count. Answer only with JSON."""


def advice_messages(prof):
    kinds = {k: v[0] for k, v in KINDS.items()}
    return [{"role": "system", "content": ADVICE_SYSTEM},
            {"role": "user", "content": "Reports: " + json.dumps(kinds) + "\nCounts from the file: " + json.dumps(prof, default=str)}]


ADVICE_SCHEMA = {"type": "object", "properties": {"recommended": {"type": "array", "items": {"type": "object", "properties": {
    "report": {"type": "string", "enum": list(KINDS)}, "why": {"type": "string"}}, "required": ["report", "why"]}}},
    "required": ["recommended"]}


def rule_advice(prof):
    """What the rules recommend from the counts (also when AI-01 cannot be asked)."""
    p = prof or {}
    out = []
    if p.get("broad_write"):
        out.append(("broad", f"{p['broad_write']} entries let Everyone-type groups change data."))
    if p.get("orphans"):
        out.append(("orphans", f"{p['orphans']} entries name accounts that no longer exist."))
    if p.get("explicit_users"):
        out.append(("explicit_users", f"{p['explicit_users']} entries give people rights directly, not through a group."))
    if p.get("full_nonadmin"):
        out.append(("full_control", f"{p['full_nonadmin']} entries give full control outside the admin groups."))
    if p.get("people_listed"):
        out.append(("by_department", f"The people sheet gives {p['people_listed']} people in {p['departments']} departments: "
                                     "see each department's people and the shares and folders they reach."))
    if p.get("accounts_behind"):
        out.append(("effective", f"The members sheet opens up {p['groups_opened']} groups into {p['accounts_behind']} accounts: "
                                 "see who really can change data."))
    if p.get("tagged"):
        out.append(("by_app", f"{p['tagged']} folders have a confirmed application and team."))
    if p.get("folders") and (p.get("tagged") or 0) < p["folders"]:
        out.append(("untagged", f"{p['folders'] - (p.get('tagged') or 0)} of {p['folders']} folders have no confirmed application yet."))
    out.append(("risk", "One view of every kind of risky access in the file."))
    seen, res = set(), []
    for k, why in out:
        if k not in seen:
            seen.add(k)
            res.append({"report": k, "why": why, "by": "rules"})
    return res[:4]


NUM_RE = re.compile(r"\d[\d,]*")


def numbers_in(doc):
    """Every number a report holds (counts, as integers), to check AI-01's text against."""
    out = set()
    def walk(x):
        if isinstance(x, bool):
            return
        if isinstance(x, (int, float)):
            out.add(int(x))
        elif isinstance(x, dict):
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
    walk(doc)
    return out


def grounded(text, allowed):
    """Keep only the sentences whose numbers are all figures of the report (AI-01 never counts)."""
    keep = []
    for sent in re.split(r"(?<=[.!?])\s+", (text or "").strip()):
        nums = [int(n.replace(",", "")) for n in NUM_RE.findall(sent) if n.replace(",", "").isdigit()]
        if all(n in allowed for n in nums):
            keep.append(sent)
    return " ".join(keep).strip()


SUMMARY_SYSTEM = """You write the summary of an access-review report for the owners of the data. You are given the report's
figures. Write a headline (one sentence), three to five key points, and up to three first actions. Quote only figures you are
given, exactly as given; never compute percentages or new totals; never name an account, folder or team that is not in the
figures. Plain words, no jargon. Answer only with JSON."""
SUMMARY_SCHEMA = {"type": "object", "properties": {"headline": {"type": "string"}, "points": {"type": "array", "items": {"type": "string"}},
                                                   "actions": {"type": "array", "items": {"type": "string"}}},
                  "required": ["headline", "points", "actions"]}


def summary_facts(title, result):
    k = result["kpis"]
    return {"report": title, "entries_in_scope": k["entries"], "folders": k["folders"], "accounts": k["identities"],
            "findings": k["findings"], "folders_with_findings": k["folders_with"],
            **({"findings_are": "entries that give access (this report groups people, it does not judge risk)",
                "departments": [{"department": d["name"], "people": d["people"], "can_change_data": d["can_change"],
                                 "outside_their_department": d["outside_people"]} for d in result["departments"][:8]],
                "people_outside_the_owning_department": result["department_view"]["outside_total"]}
               if result.get("department_view") else {}),
            "by_kind_of_risk": {v["label"]: v["n"] for v in result["categories"].values() if v["in_report"]},
            "top_applications": [{"application": r["name"], "findings": r["findings"], "entries": r["entries"]} for r in result["applications"][:6]],
            "top_teams": [{"team": r["name"], "findings": r["findings"]} for r in result["teams"][:6]],
            "top_folders": [{"folder": r["folder"], "findings": r["findings"]} for r in result["folders"][:5]],
            "top_accounts": [{"account": r["identity"], "findings": r["findings"], "folders": r["folders"]} for r in result["who"][:5]]}


def summary_messages(facts, budget=None):
    """The report's figures, whole: when they do not fit the slot, the longest lists are halved (never cut mid-way)."""
    budget = budget or prompt_budget(SUMMARY_ANSWER_TOKENS)
    f = json.loads(json.dumps(facts, default=str))

    def msgs():
        return [{"role": "system", "content": SUMMARY_SYSTEM}, {"role": "user", "content": json.dumps(f)}]

    def lists(o, path=()):
        if isinstance(o, dict):
            for k, v in o.items():
                yield from lists(v, path + (k,))
        elif isinstance(o, list) and len(o) > 1:
            yield path, o
    for _ in range(40):
        if est_tokens(msgs()) <= budget:
            break
        cands = sorted(lists(f), key=lambda x: -len(json.dumps(x[1])))
        if not cands:
            break
        path, lst = cands[0]
        tgt = f
        for k in path[:-1]:
            tgt = tgt[k]
        tgt[path[-1]] = lst[:max(1, len(lst) // 2)]
    return msgs()


def clean_summary(doc, facts):
    allowed = numbers_in(facts)
    head = grounded(clean_tag_text((doc or {}).get("headline"), 300), allowed)
    pts = [grounded(clean_tag_text(x, 300), allowed) for x in ((doc or {}).get("points") or [])[:5]]
    acts = [grounded(clean_tag_text(x, 300), allowed) for x in ((doc or {}).get("actions") or [])[:3]]
    pts, acts = [x for x in pts if x], [x for x in acts if x]
    if not head and not pts:
        return None
    return {"headline": head, "points": pts, "actions": acts}


# ---- what the console shows ----------------------------------------------------------------------------------

DS_COLS = """id::text AS id, name, file_name, size_bytes, received, uploaded_by, uploaded_at, state, error, encoding, delimiter,
             header_row, row_count, skipped, tag_depth, tag_ai, tag_ai_note, progress, mapping_by, mapping_at, updated_at"""


def datasets(conn):
    try:
        with conn.transaction():
            rows = conn.execute(f"""SELECT {DS_COLS}, (SELECT count(*) FROM perm_reports r WHERE r.dataset_id = d.id) AS reports
                                      FROM perm_datasets d ORDER BY uploaded_at DESC LIMIT 100""").fetchall()
    except Exception:  # noqa: BLE001 - schema 060 not applied yet
        return None
    return {"items": rows, "max_mb": MAX_BYTES // 2 ** 20, "max_rows": MAX_ROWS, "chunk_bytes": CHUNK,
            "roles": [{"key": k, "label": lab, "required": req} for k, lab, req in ROLES],
            "kinds": [{"key": k, "title": v[0], "about": v[1]} for k, v in KINDS.items()],
            "levels": [{"key": lv, "label": LEVEL_TEXT[lv]} for lv in reversed(LEVELS)]}


def dataset(conn, ds_id):
    d = conn.execute(f"""SELECT {DS_COLS}, headers, sample, mapping, proposal, profile, advice, advice_at, file_type, cleaning, links,
                                source, scan_errors
                           FROM perm_datasets WHERE id = %s""", (ds_id,)).fetchone()
    if not d:
        raise PermError("That upload is not known (it may have been removed).")
    d["sheets"] = sheets_of(conn, ds_id)
    d["encoding_text"] = ENCODING_TEXT.get(d["encoding"] or "", d["encoding"])
    d["sheet_roles"] = {k: {"title": SHEET_ROLE_TEXT[k], "fields": [{"key": f, "label": lab, "required": req} for f, lab, req in v],
                            "name_roles": list(SHEET_NAME_ROLES.get(k, ()))} for k, v in ROLESETS.items()}
    d["sheet_roles"]["skip"] = {"title": SHEET_ROLE_TEXT["skip"], "fields": [], "name_roles": []}
    if d["profile"]:
        d["profile"] = dict(d["profile"], **folder_counts(conn, ds_id))
    d["roles"] = [{"key": k, "label": lab, "required": req} for k, lab, req in ROLES]
    d["kinds"] = [{"key": k, "title": v[0], "about": v[1]} for k, v in KINDS.items()]
    d["reports"] = conn.execute("""SELECT id::text AS id, kind, title, created_by, created_at, summary_state, state,
                                          (result->'kpis'->>'findings')::int AS findings
                                     FROM perm_reports WHERE dataset_id = %s ORDER BY created_at DESC LIMIT 50""", (ds_id,)).fetchall()
    if d["state"] == "ready":
        d["choices"] = {
            "servers": [r["s"] for r in conn.execute("""SELECT DISTINCT server AS s FROM perm_entries WHERE dataset_id = %s
                                                          AND server IS NOT NULL ORDER BY 1 LIMIT 300""", (ds_id,))],
            "applications": [r["a"] for r in conn.execute("""SELECT DISTINCT application AS a FROM perm_folders WHERE dataset_id = %s
                                                               AND application IS NOT NULL ORDER BY 1 LIMIT 500""", (ds_id,))],
            "teams": [r["t"] for r in conn.execute("""SELECT DISTINCT team AS t FROM perm_folders WHERE dataset_id = %s
                                                        AND team IS NOT NULL ORDER BY 1 LIMIT 500""", (ds_id,))],
            "confirmed_only_apps": [r["a"] for r in conn.execute("""SELECT DISTINCT application AS a FROM perm_folders
                                     WHERE dataset_id = %s AND tag_state = 'confirmed' AND application IS NOT NULL ORDER BY 1 LIMIT 500""", (ds_id,))],
        }
    return d


def tags_view(conn, ds_id, state=None, q=None, limit=500):
    """This upload's folders with the tag in force (owner, department, team, application), and the suggestion
    waiting (biggest first)."""
    where, args = ["f.dataset_id = %s"], [ds_id]
    if state == "suggested":
        where.append("t.state = 'suggested' AND " + TAG_HAS_T)
    elif state == "sure":
        where.append(f"t.state = 'suggested' AND coalesce(t.confidence, 0) >= {SURE} AND " + TAG_HAS_T)
    elif state == "unsure":
        where.append(UNSURE_VIEW)
    elif state == "confirmed":
        where.append("f.tag_state = 'confirmed'")
    elif state == "untagged":
        where.append("f.tag_key IS NULL")
    elif state == "no_owner":
        where.append("f.owner IS NULL")
    elif state == "no_evidence":
        where.append("f.evidence IS FALSE AND f.tag_state IS DISTINCT FROM 'confirmed'")
    elif state == "inherited":
        where.append("f.tag_key IS NOT NULL AND f.tag_key <> f.folder_key")
    if q:
        cols = ("f.label", "f.application", "f.team", "f.owner", "f.department", "f.ntfs_owner", "t.owner", "t.department")
        where.append("(" + " OR ".join(f"strpos(lower(coalesce({c}, '')), %s) > 0" for c in cols) + ")")  # plain text
        args += [q.lower()] * len(cols)
    rows = conn.execute(f"""SELECT f.folder_key AS key, f.label, f.server, f.entries, f.paths, f.identities, f.ntfs_owner,
                                   f.application, f.team, f.owner, f.owner_kind, f.department, f.tag_state, f.tag_key,
                                   f.evidence AS has_evidence, f.evidence_note,
                                   t.state AS own_state, t.application AS s_application, t.team AS s_team, t.owner AS s_owner,
                                   t.owner_kind AS s_owner_kind, t.department AS s_department, t.confidence,
                                   t.reason, t.evidence, t.suggested_by, t.ai_asked_at, t.decided_by, t.decided_at
                              FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key
                             WHERE {' AND '.join(where)}
                             ORDER BY f.entries DESC, f.folder_key LIMIT %s""", args + [min(int(limit), 2000)]).fetchall()
    c = conn.execute(f"""SELECT count(*) AS folders, count(*) FILTER (WHERE f.tag_state = 'confirmed') AS confirmed,
                               count(*) FILTER (WHERE t.state = 'suggested' AND {TAG_HAS_T}) AS suggested,
                               count(*) FILTER (WHERE t.state = 'suggested' AND coalesce(t.confidence, 0) >= {SURE} AND {TAG_HAS_T}) AS sure,
                               count(*) FILTER (WHERE t.state = 'suggested' AND t.suggested_by = 'rules') AS by_rules,
                               count(*) FILTER (WHERE t.ai_asked_at IS NOT NULL) AS ai_asked,
                               count(*) FILTER (WHERE f.tag_key IS NULL) AS untagged,
                               count(*) FILTER (WHERE f.owner IS NOT NULL) AS with_owner,
                               count(*) FILTER (WHERE f.department IS NOT NULL) AS with_department,
                               count(*) FILTER (WHERE f.ntfs_owner IS NOT NULL) AS with_ntfs_owner,
                               count(*) FILTER (WHERE t.state = 'rejected') AS rejected,
                               count(*) FILTER (WHERE t.key_l IS NULL) AS not_asked,
                               count(*) FILTER (WHERE f.evidence IS FALSE AND f.tag_state IS DISTINCT FROM 'confirmed') AS no_evidence
                          FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key WHERE f.dataset_id = %s""",
                     (ds_id,)).fetchone()
    c["unsure"] = conn.execute(f"""SELECT count(*) AS n FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key
                                    WHERE f.dataset_id = %s AND {UNSURE_VIEW}""", (ds_id,)).fetchone()["n"]
    c["to_check"] = unsure_count(conn, ds_id)              # of those, the ones AI-01 has not looked at yet
    names = conn.execute("""SELECT array(SELECT DISTINCT application FROM perm_tags WHERE state = 'confirmed' AND application IS NOT NULL ORDER BY 1) AS apps,
                                   array(SELECT DISTINCT team FROM perm_tags WHERE state = 'confirmed' AND team IS NOT NULL ORDER BY 1) AS teams,
                                   array(SELECT DISTINCT owner FROM perm_tags WHERE state = 'confirmed' AND owner IS NOT NULL ORDER BY 1) AS owners""").fetchone()
    st = conn.execute("SELECT tag_ai, tag_ai_note, tag_ai_scope, tag_ai_progress FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone() or {}
    return {"items": rows, "counts": c, "known_applications": names["apps"] or [], "known_teams": names["teams"] or [],
            "known_owners": names["owners"] or [], "known_departments": sorted(set(known_departments(conn, ds_id).values()), key=str.lower),
            "tag_ai": st.get("tag_ai"), "tag_ai_note": st.get("tag_ai_note"), "tag_ai_scope": st.get("tag_ai_scope"), "sure_at": SURE,
            "ai_progress": ai_progress_view(st.get("tag_ai_progress"), st.get("tag_ai"), conn.execute(
                f"""SELECT count(*) AS n FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key
                     WHERE f.dataset_id = %(ds)s AND {UNSURE_SQL}""", {"ds": ds_id, "all": st.get("tag_ai_scope") == "all"}).fetchone()["n"])}


def ai_progress_view(p, state, to_check):
    """How far AI-01's checks are, in numbers the page can show as they are: checked of the total since they began,
    the time they take, about how long is left, and whether AI-01 is waiting for people using it."""
    p = p if isinstance(p, dict) else (json.loads(p) if p else {})
    if not p and state not in ("queued", "running"):
        return None
    total = int(p.get("total") or 0)
    done = max(0, total - int(to_check)) if total else 0
    total = max(total, done + int(to_check))
    secs, checked = float(p.get("secs") or 0), int(p.get("checked") or 0)
    per = secs / checked if checked else None
    left = int(per * to_check) if per is not None and state in ("queued", "running") else None
    import datetime as _dt
    waiting = p.get("waiting")
    if waiting:
        try:
            age = (_dt.datetime.now(_dt.timezone.utc) - _dt.datetime.fromisoformat(waiting)).total_seconds()
        except ValueError:
            age = 0
        waiting = waiting if age < 180 else None          # an old mark: it is not waiting now
    return {"total": total, "done": done, "left": int(to_check), "pct": round(100 * done / total) if total else 100,
            "seconds_left": left, "secs_per_folder": round(per, 1) if per is not None else None, "batches": int(p.get("batches") or 0),
            "started": p.get("started"), "waiting": waiting, "state": state}


def _ai_start(conn, ds_id, total):
    import datetime as _dt
    conn.execute("UPDATE perm_datasets SET tag_ai_progress = %s::jsonb WHERE id = %s",
                 (json.dumps({"total": int(total), "checked": 0, "secs": 0, "batches": 0,
                              "started": _dt.datetime.now(_dt.timezone.utc).isoformat()}), ds_id))


def ask_tags(conn, ds_id, again=False, scope="all"):
    """AI-01 checks the folders: scope 'all' (every suggestion not decided) or 'unsure' (below SURE, or no owner and
    no department). again: what nobody decided yet is suggested afresh (the rules first, then AI-01)."""
    ds = conn.execute("SELECT state FROM perm_datasets WHERE id = %s FOR UPDATE", (ds_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known.")
    if ds["state"] != "ready":
        raise PermError("Confirm the columns first: AI-01 tags the folders once the rows are ready.")
    if again:     # suggestions nobody decided yet are made again (confirmed and rejected stay)
        conn.execute("""DELETE FROM perm_tags t USING perm_folders f WHERE f.dataset_id = %s AND t.key_l = f.folder_key
                         AND t.state = 'suggested' AND t.suggested_by <> 'file'""", (ds_id,))
        conn.execute("""UPDATE perm_tags t SET ai_asked_at = NULL FROM perm_folders f WHERE f.dataset_id = %s AND t.key_l = f.folder_key
                         AND t.state = 'suggested'""", (ds_id,))
        resolve_tags(conn, ds_id)
        suggest_owners(conn, ds_id)
    conn.execute("UPDATE perm_datasets SET tag_ai = 'queued', tag_ai_note = NULL, tag_ai_scope = %s WHERE id = %s",
                 ("unsure" if scope == "unsure" else "all", ds_id))
    n = conn.execute(f"""SELECT count(*) AS n FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key
                          WHERE f.dataset_id = %(ds)s AND {UNSURE_SQL}""", {"ds": ds_id, "all": scope != "unsure"}).fetchone()["n"]
    _ai_start(conn, ds_id, n)


def report_view(conn, report_id):
    r = conn.execute("""SELECT r.id::text AS id, r.dataset_id::text AS dataset_id, r.kind, r.title, r.spec, r.result, r.summary,
                               r.state, r.error,
                               r.summary_state, r.created_by, r.created_at, d.name AS dataset, d.file_name, d.uploaded_at
                          FROM perm_reports r JOIN perm_datasets d ON d.id = r.dataset_id WHERE r.id = %s""", (report_id,)).fetchone()
    if not r:
        raise PermError("That report is not known.")
    r["kind_title"], r["kind_about"] = KINDS.get(r["kind"], ("", ""))
    return r


# ---- the worker: one pass ---------------------------------------------------------------------------------------

def _json(text):
    """AI-01's answer as JSON (it may wrap it in words or a <think> block)."""
    if isinstance(text, dict):
        return text
    t = re.sub(r"<think>.*?</think>", "", str(text or ""), flags=re.S)
    a, b = t.find("{"), t.rfind("}")
    if a < 0 or b < a:
        raise ValueError("AI-01 gave no JSON")
    return json.loads(t[a:b + 1])


def make_advice(conn, ds_id, ai=None):
    prof = conn.execute("SELECT profile FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()["profile"] or {}
    rules = rule_advice(prof)
    items, by, note = [], "rules", None
    if ai:
        try:
            got = _json(ai(advice_messages(prof), ADVICE_SCHEMA))
            allowed = numbers_in(prof)
            for it in (got.get("recommended") or [])[:4]:
                k = it.get("report")
                why = grounded(clean_tag_text(it.get("why"), 300), allowed)
                if k in KINDS and k not in {x["report"] for x in items}:
                    items.append({"report": k, "why": why or next((r["why"] for r in rules if r["report"] == k), KINDS[k][1]),
                                  "by": "AI-01"})
            by = "AI-01" if items else "rules"
        except Exception as e:  # noqa: BLE001 - the rules' advice stands alone
            note = "AI-01 did not answer (" + str(e)[:100] + "): recommended by the rules from the counts."
    for r in rules:                                   # the rules fill in what AI-01 left out
        if len(items) >= 4:
            break
        if r["report"] not in {x["report"] for x in items}:
            items.append(r)
    conn.execute("UPDATE perm_datasets SET advice = %s::jsonb, advice_at = now() WHERE id = %s",
                 (json.dumps({"items": items, "by": by, "note": note}), ds_id))
    conn.commit()
    return items


def summarise(conn, report_id, ai):
    r = conn.execute("SELECT title, result FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
    facts = summary_facts(r["title"], r["result"])
    conn.execute("UPDATE perm_reports SET summary_state = 'running' WHERE id = %s", (report_id,))
    conn.commit()
    doc = clean_summary(_json(ai(summary_messages(facts), SUMMARY_SCHEMA)), facts)
    conn.execute("UPDATE perm_reports SET summary = %s::jsonb, summary_state = %s WHERE id = %s",
                 (json.dumps(doc) if doc else None, "done" if doc else "failed", report_id))
    conn.commit()


def _fail(conn, ds_id, msg):
    conn.rollback()
    conn.execute("UPDATE perm_datasets SET state = 'failed', error = %s, progress = NULL, updated_at = now() WHERE id = %s",
                 (str(msg)[:500], ds_id))
    conn.commit()


AI_PASS_SECONDS = 150


def _n(n, word):
    return f"{n:,} {word}" + ("" if n == 1 else "s")


def _tag_pass(conn, ds_id, ai_for, stop, background_ok, did):
    """One pass of AI-01's checks of an upload's owners."""
    import datetime as _dt
    import time as _t
    ai = ai_for("tags")
    if not ai:
        conn.execute("UPDATE perm_datasets SET tag_ai = 'failed', tag_ai_note = 'AI-01 is not set up on PATCH-01: the rules\' suggestions stand' WHERE id = %s",
                     (ds_id,))
        conn.commit()
        return
    row = conn.execute("SELECT tag_ai_progress, tag_ai_scope FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    prog = row["tag_ai_progress"] if isinstance(row["tag_ai_progress"], dict) else json.loads(row["tag_ai_progress"] or "{}")
    scope_all = row["tag_ai_scope"] == "all"

    def remaining():
        return conn.execute(f"""SELECT count(*) AS n FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key
                                 WHERE f.dataset_id = %(ds)s AND {UNSURE_SQL}""", {"ds": ds_id, "all": scope_all}).fetchone()["n"]
    if not prog.get("total"):                              # queued before r128: counted from now
        prog = {"total": remaining(), "checked": 0, "secs": 0, "batches": 0, "started": _dt.datetime.now(_dt.timezone.utc).isoformat()}

    def save(**k):
        prog.update(k)
        conn.execute("UPDATE perm_datasets SET tag_ai_progress = %s::jsonb WHERE id = %s", (json.dumps(prog), ds_id))
    conn.execute("UPDATE perm_datasets SET tag_ai = 'running' WHERE id = %s", (ds_id,))
    save(waiting=None)
    conn.commit()
    began, fails, first = _t.time(), 0, True
    while not stop():
        if not first and _t.time() - began > AI_PASS_SECONDS:
            break                                          # at least one batch a pass; then the others get a turn
        first = False
        if not background_ok():
            save(waiting=_dt.datetime.now(_dt.timezone.utc).isoformat())
            conn.execute("UPDATE perm_datasets SET tag_ai_note = %s WHERE id = %s AND tag_ai = 'running'",
                         ("Waiting: AI-01 is answering people's questions; the checks go on as soon as it is free", ds_id))
            conn.commit()
            break
        if conn.execute("SELECT tag_ai FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()["tag_ai"] != "running":
            break                                          # an admin pressed Stop
        t0 = _t.time()
        try:
            n = suggest_batch(conn, ds_id, lambda msgs, sch: _json(ai(msgs, sch)))
        except Exception as e:  # noqa: BLE001 - AI-01 busy or slow: again next pass, given up after 3 in a row
            conn.rollback()
            fails += 1
            log.info("access review: tag batch failed: %s", e)
            if fails >= 3:
                conn.execute("UPDATE perm_datasets SET tag_ai = 'failed', tag_ai_note = %s WHERE id = %s",
                             ("AI-01 did not answer three times in a row (" + str(e)[:120] + "). The rules' suggestions stand; ask again later.", ds_id))
                conn.commit()
                return
            continue
        fails = 0
        if not n:
            left = conn.execute(f"""SELECT count(*) FILTER (WHERE {TAG_HAS_T}) AS s
                                     FROM perm_folders f JOIN perm_tags t ON t.key_l = f.folder_key
                                    WHERE f.dataset_id = %s AND t.state = 'suggested'""", (ds_id,)).fetchone()["s"]
            ne = conn.execute("""SELECT count(*) AS n FROM perm_folders WHERE dataset_id = %s AND evidence IS FALSE
                                   AND tag_state IS DISTINCT FROM 'confirmed'""", (ds_id,)).fetchone()["n"]
            save(waiting=None, finished=_dt.datetime.now(_dt.timezone.utc).isoformat())
            conn.execute("""UPDATE perm_datasets SET tag_ai = 'done', tag_ai_note = %s, profile = %s::jsonb WHERE id = %s""",
                         (f"AI-01 checked {_n(prog.get('checked', 0), 'folder')}. {_n(left, 'suggestion')} "
                          + ("waits" if left == 1 else "wait") + " for your decision"
                          + (f"; {_n(ne, 'folder')} " + ("has" if ne == 1 else "have") + " nothing in its permissions about an owner (filter: No evidence)" if ne else ""),
                          json.dumps(profile(conn, ds_id)), ds_id))
            conn.commit()
            did.append(("tagged", ds_id))
            return
        left = remaining()
        save(checked=int(prog.get("checked", 0)) + n, secs=round(float(prog.get("secs", 0)) + (_t.time() - t0), 1),
             batches=int(prog.get("batches", 0)) + 1, waiting=None, total=max(int(prog.get("total") or 0), int(prog.get("checked", 0)) + n + left))
        conn.execute("UPDATE perm_datasets SET tag_ai_note = %s WHERE id = %s AND tag_ai = 'running'",
                     (f"AI-01 has checked {prog['checked']} of {prog['total']} folders (biggest first); {left} to go", ds_id))
        conn.commit()
        did.append(("tag_batch", ds_id))


def housekeeping(conn):
    """r128: nothing left waiting for ever. An upload the browser never finished (no piece for a day) fails and its
    pieces go; a scan whose upload was removed while it was being read fails."""
    try:
        with conn.transaction():
            gone = conn.execute("""UPDATE perm_datasets SET state = 'failed', updated_at = now(),
                                          error = 'The upload was not finished (the browser was closed or the connection dropped): upload it again.'
                                    WHERE state = 'uploading' AND updated_at < now() - interval '1 day' RETURNING id""").fetchall()
            for g in gone:
                conn.execute("DELETE FROM perm_chunks WHERE dataset_id = %s", (g["id"],))
            if conn.execute("SELECT to_regclass('perm_scans') IS NOT NULL AS ok").fetchone()["ok"]:
                conn.execute("""UPDATE perm_scans SET state = 'failed', updated_at = now(),
                                       error = 'its upload was removed in PATCH-01 before it was read'
                                 WHERE state = 'importing' AND dataset_id IS NULL""")
        conn.commit()
    except Exception as e:  # noqa: BLE001
        conn.rollback()
        log.warning("access review: housekeeping: %s", e)


def _follow_scans(conn):
    """r123: scans follow their uploads (ready -> done, failed -> failed)."""
    try:
        from . import perm_scan
        with conn.transaction():
            perm_scan.follow(conn)
        conn.commit()
    except Exception as e:  # noqa: BLE001 - schema 063 not applied yet
        conn.rollback()
        log.debug("scans: %s", e)


def run_once(conn, ai_for, stop=lambda: False, background_ok=lambda: True):
    """One pass of everything waiting. ai_for(kind) gives a function (messages, schema) -> dict, or None
    when AI-01 is not configured. Returns what it did (for the heartbeat and the tests)."""
    did = []
    housekeeping(conn)
    _follow_scans(conn)
    # 1. files uploaded (or cut short while being read): read them, then propose the columns
    for d in conn.execute("SELECT id::text AS id, state FROM perm_datasets WHERE state IN ('uploaded', 'reading') ORDER BY uploaded_at").fetchall():
        if stop():
            return did
        try:
            read_file(conn, d["id"], stop)
        except Exception as e:  # noqa: BLE001
            if stop():
                return did             # left as it is: read again after the restart
            log.warning("access review: reading %s failed: %s", d["id"], e)
            _fail(conn, d["id"], e if isinstance(e, PermError) else
                  "The file could not be read as CSV (" + type(e).__name__ + ": " + str(e)[:160] + ").")
            continue
        did.append(("read", d["id"]))
    for d in conn.execute("SELECT id::text AS id FROM perm_datasets WHERE state = 'mapping' AND proposal IS NULL").fetchall():
        try:
            propose(conn, d["id"], ai_for("mapping"))
        except Exception as e:  # noqa: BLE001 - r128: one upload never stops the others (it used to stop every pass)
            conn.rollback()
            log.warning("access review: proposing the columns of %s failed: %s", d["id"], e)
            try:
                propose(conn, d["id"], None)               # the rules' proposal alone
            except Exception as e2:  # noqa: BLE001
                conn.rollback()
                _fail(conn, d["id"], "The columns could not be proposed (" + type(e2).__name__ + ": " + str(e2)[:160] + ").")
                continue
        did.append(("proposed", d["id"]))
    # 2. columns confirmed: make the rows plain, then recommend reports
    for d in conn.execute("SELECT id::text AS id FROM perm_datasets WHERE state = 'normalising' ORDER BY mapping_at").fetchall():
        if stop():
            return did
        try:
            normalise(conn, d["id"], stop)
        except Exception as e:  # noqa: BLE001
            if stop():
                return did
            log.warning("access review: rows of %s failed: %s", d["id"], e)
            _fail(conn, d["id"], e if isinstance(e, PermError) else "The rows could not be read with these columns (" + str(e)[:160] + ").")
            continue
        did.append(("normalised", d["id"]))
        # r124: AI-01 checks by itself the folders whose owner or department the rules are unsure of
        unsure = unsure_count(conn, d["id"])
        if unsure and ai_for("tags"):
            r = conn.execute("""UPDATE perm_datasets SET tag_ai = 'queued', tag_ai_scope = 'unsure',
                                       tag_ai_note = %s WHERE id = %s AND coalesce(tag_ai, 'idle') NOT IN ('queued', 'running')
                                RETURNING id""", (f"AI-01 checks the {unsure} folders the rules are unsure of", d["id"])).fetchone()
            if r:
                _ai_start(conn, d["id"], unsure)
            conn.commit()
    for d in conn.execute("SELECT id::text AS id FROM perm_datasets WHERE state = 'ready' AND advice IS NULL").fetchall():
        try:
            make_advice(conn, d["id"], ai_for("advice"))
        except Exception as e:  # noqa: BLE001 - r128: never stops the pass; the advice is left out
            conn.rollback()
            log.warning("access review: advice for %s failed: %s", d["id"], e)
            conn.execute("UPDATE perm_datasets SET advice = %s::jsonb, advice_at = now() WHERE id = %s",
                         (json.dumps({"items": [], "by": "rules", "note": "The recommendations could not be made: choose a report below."}), d["id"]))
            conn.commit()
            continue
        did.append(("advice", d["id"]))
    # 3. reports asked for: count them, then AI-01's summary
    for r in conn.execute("SELECT id::text AS id FROM perm_reports WHERE state IN ('queued', 'computing') ORDER BY created_at").fetchall():
        if stop():
            return did
        try:
            build_report(conn, r["id"])
            did.append(("report", r["id"]))
        except Exception as e:  # noqa: BLE001
            log.warning("access review: report %s failed: %s", r["id"], e)
            conn.rollback()
            conn.execute("UPDATE perm_reports SET state = 'failed', error = %s, summary_state = 'off' WHERE id = %s",
                         ("The figures could not be counted (" + type(e).__name__ + ": " + str(e)[:160] + ").", r["id"]))
            conn.commit()
    for r in conn.execute("""SELECT id::text AS id FROM perm_reports WHERE state = 'ready' AND summary_state IN ('queued', 'running')
                              ORDER BY created_at""").fetchall():
        if stop() or not background_ok():
            break
        ai = ai_for("summary")
        if not ai:
            conn.execute("UPDATE perm_reports SET summary_state = 'off' WHERE id = %s", (r["id"],))
            conn.commit()
            continue
        try:
            summarise(conn, r["id"], ai)
            did.append(("summary", r["id"]))
        except Exception as e:  # noqa: BLE001
            conn.rollback()
            log.info("access review: summary failed: %s", e)
            conn.execute("UPDATE perm_reports SET summary_state = 'failed' WHERE id = %s", (r["id"],))
            conn.commit()
    # 4. tags asked of AI-01 (r128: after the reports, at most AI_PASS_SECONDS a pass, so nothing waits behind it):
    #    a batch at a time, yielding to people using AI-01; how far it is, and how long it takes, is kept as it goes
    for d in conn.execute("""SELECT id::text AS id FROM perm_datasets WHERE state = 'ready' AND tag_ai IN ('queued', 'running')
                              ORDER BY updated_at""").fetchall():
        try:
            _tag_pass(conn, d["id"], ai_for, stop, background_ok, did)
        except Exception as e:  # noqa: BLE001 - one upload's checks never stop the others, nor the worker
            conn.rollback()
            log.warning("access review: AI-01 checks of %s failed: %s", d["id"], e)
            conn.execute("UPDATE perm_datasets SET tag_ai = 'failed', tag_ai_note = %s WHERE id = %s",
                         (("The checks stopped on an error (" + type(e).__name__ + ": " + str(e))[:300] + "). Ask again.", d["id"]))
            conn.commit()
    _follow_scans(conn)
    from . import perm_map                                 # r127: last year's mapping workbooks (schema 066)
    if conn.execute("SELECT to_regclass('perm_maps') IS NOT NULL AS ok").fetchone()["ok"]:
        did += perm_map.run_once(conn, ai_for)
    return did
