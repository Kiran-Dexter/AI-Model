"""PATCH-01 repositories: sync and publish from the console (r117).

Until r117 the repositories were synced only by hand on the server (phase2-repos.py --sync,
--publish), so unless someone ran it, nothing new reached the servers. Now:

  * Admin › Repositories shows every repository in Pulp: what it holds, when it was last synced
    and published, whether servers see the newest content, and the address servers use;
  * an admin can Sync, Publish, or Sync and publish (one repository or all);
  * the worker does it every day at the times set (default 02:00), then imports the new security
    advisories (the CVE engine) so the patch verdicts use them at once.

Only the worker talks to Pulp, with Pulp's admin password from worker.env (phase3b-api.sh);
the API never holds it. Remotes and repositories are still created on the server
(phase2-repos.py --setup): that needs root, the Red Hat entitlement certificates and repos.conf.

Same rules as phase2-repos.py: sync_policy "additive" (a version the vendor drops is kept, which
is what makes a downgrade possible); Ubuntu is published verbatim, with Ubuntu's own signatures,
so apt checks them as it does against Ubuntu itself.
"""
import base64
import json
import logging
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

log = logging.getLogger("patchapi.repos")

PULP_URL = os.environ.get("PULP_URL", "http://pulp-api:24817").rstrip("/")
PULP_USER = os.environ.get("PULP_USER", "admin")
REMOTES = {"rpm": "/pulp/api/v3/remotes/rpm/rpm/", "deb": "/pulp/api/v3/remotes/deb/apt/"}
TYPES = {
    "rpm": {"repository": "/pulp/api/v3/repositories/rpm/rpm/", "publication": "/pulp/api/v3/publications/rpm/rpm/",
            "distribution": "/pulp/api/v3/distributions/rpm/rpm/", "packages": "/pulp/api/v3/content/rpm/packages/",
            "advisories": "/pulp/api/v3/content/rpm/advisories/"},
    "deb": {"repository": "/pulp/api/v3/repositories/deb/apt/", "publication": "/pulp/api/v3/publications/deb/verbatim/",
            "distribution": "/pulp/api/v3/distributions/deb/apt/", "packages": "/pulp/api/v3/content/deb/packages/"},
}
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$")
SYNC_TIMEOUT = 6 * 3600
TZ = timezone(timedelta(hours=8))            # times are set in SGT, as the CVE sync
TZ_LABEL = "SGT"
TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


class PulpError(RuntimeError):
    pass


def password():
    return os.environ.get("PULP_PASSWORD", "")


def configured():
    return bool(password())


class Pulp:
    """Pulp's API on the internal network, never through a proxy."""

    def __init__(self):
        if not configured():
            raise PulpError("The worker has no Pulp password: run phase3b-api.sh on PATCH-01 (it adds it to worker.env).")
        self.auth = "Basic " + base64.b64encode(f"{PULP_USER}:{password()}".encode()).decode()
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def request(self, method, path, body=None, timeout=120):
        url = path if path.startswith("http") else PULP_URL + path
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Authorization", self.auth)
        req.add_header("Accept", "application/json")
        if data is not None:
            req.add_header("Content-Type", "application/json")
        try:
            with self.opener.open(req, timeout=timeout) as r:
                raw = r.read(32 * 2 ** 20)
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            detail = e.read(2000).decode(errors="replace")
            if e.code == 401:
                raise PulpError("Pulp refused the admin password in worker.env: run phase3b-api.sh again.") from None
            raise PulpError(f"Pulp answered HTTP {e.code} on {method} {path.split('?')[0]}: {detail[:300]}") from None
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise PulpError(f"Pulp cannot be reached ({e}): is patch01-pulp-api running?") from None

    def get(self, path):
        return self.request("GET", path)

    def paged(self, path):
        url = path
        while url:
            page = self.get(url)
            yield from page.get("results", [])
            nxt = page.get("next")
            url = (url.split("?", 1)[0] + "?" + nxt.split("?", 1)[1]) if nxt and "?" in nxt else None

    def count(self, path):
        return int(self.get(path + ("&" if "?" in path else "?") + "limit=1").get("count") or 0)

    def wait(self, task, stop=lambda: False, progress=None, timeout=SYNC_TIMEOUT):
        start = time.time()
        while True:
            t = self.get(task)
            st = t.get("state")
            if progress:
                progress(t)
            if st == "completed":
                return t
            if st in ("failed", "canceled"):
                err = t.get("error") or {}
                raise PulpError((err.get("description") or err.get("reason") or json.dumps(err))[:600])
            if stop() or time.time() - start > timeout:
                raise PulpError(f"still {st} after {int(time.time() - start)} s: left running in Pulp")
            time.sleep(5)


def _version_no(href):
    m = re.search(r"/versions/(\d+)/$", href or "")
    return int(m.group(1)) if m else 0


# ---- what Pulp holds --------------------------------------------------------------------------------

def inventory(pulp):
    """Every repository in Pulp with what servers see: [{name, type, version, published_version, ...}].
    What servers see is found from each distribution: its publication, and the repository
    version that publication was made from."""
    out = []
    for kind, ep in TYPES.items():
        served = {}                                     # repository href -> (distribution, version number)
        for d in pulp.paged(ep["distribution"] + "?limit=100"):
            if not d.get("publication"):
                continue
            try:
                pub = pulp.get(d["publication"])
            except PulpError:
                continue
            rv = pub.get("repository_version") or ""
            rhref = rv.split("versions/")[0] if "/versions/" in rv else pub.get("repository")
            if rhref:
                served[rhref] = (d, _version_no(rv))
        # phase2-repos.py names each remote "<repository>-remote" and does not attach it to the
        # repository: a remote counts when the repository names it, or by that name (r117.1)
        remotes = {x.get("name"): x["pulp_href"] for x in pulp.paged(REMOTES[kind] + "?limit=200")}
        for r in pulp.paged(ep["repository"] + "?limit=100"):
            latest = r.get("latest_version_href") or ""
            remote = r.get("remote") or remotes.get(r["name"] + "-remote") or remotes.get(r["name"])
            d, sv = served.get(r["pulp_href"], (None, None))
            pkgs = adv = None
            if latest and not latest.endswith("/versions/0/"):
                pkgs = pulp.count(ep["packages"] + "?repository_version=" + urllib.parse.quote(latest))
                if "advisories" in ep:
                    adv = pulp.count(ep["advisories"] + "?repository_version=" + urllib.parse.quote(latest))
            out.append({"name": r["name"], "type": kind, "href": r["pulp_href"], "remote": remote,
                        "version": _version_no(latest), "published_version": sv,
                        "base_path": (d or {}).get("base_path"), "packages": pkgs, "advisories": adv,
                        "has_remote": bool(remote)})
    return sorted(out, key=lambda x: x["name"])


def _remote_for(pulp, repo):
    if repo.get("remote"):
        return repo["remote"]
    for want in (repo["name"] + "-remote", repo["name"]):          # phase2-repos.py's name first
        for x in pulp.paged(REMOTES[repo["type"]] + "?name=" + urllib.parse.quote(want)):
            if x.get("name") == want:
                return x["pulp_href"]
    return None


def sync(pulp, repo, stop=lambda: False, progress=None):
    """Sync one repository from its remote. Returns the new version number."""
    remote = _remote_for(pulp, repo)
    if not remote:
        raise PulpError("no remote: create it on PATCH-01 with phase2-repos.py --setup")
    body = {"remote": remote, "sync_policy": "additive"}
    if repo["type"] == "rpm":
        body["optimize"] = True
    t = pulp.request("POST", repo["href"] + "sync/", body)
    done = pulp.wait(t["task"], stop, progress)
    created = [h for h in done.get("created_resources") or [] if "/versions/" in h]
    return _version_no(created[0]) if created else None


def publish(pulp, repo):
    """Publish the newest version and point the servers' address at it. Returns the base path."""
    ep = TYPES[repo["type"]]
    r = pulp.get(repo["href"])
    latest = r.get("latest_version_href")
    if not latest or latest.endswith("/versions/0/"):
        raise PulpError("nothing synced yet: sync it first")
    t = pulp.request("POST", ep["publication"], {"repository_version": latest})
    done = pulp.wait(t["task"])
    pub = next((h for h in done.get("created_resources") or [] if "/publications/" in h), None)
    if not pub:
        raise PulpError("Pulp made no publication")
    dist = next((d for d in pulp.paged(ep["distribution"] + "?name=" + urllib.parse.quote(repo["name"]))
                 if d.get("name") == repo["name"]), None)
    if dist:
        t = pulp.request("PATCH", dist["pulp_href"], {"publication": pub})
        if t.get("task"):
            pulp.wait(t["task"])
        return dist.get("base_path")
    t = pulp.request("POST", ep["distribution"], {"name": repo["name"], "base_path": repo["name"], "publication": pub})
    if t.get("task"):
        pulp.wait(t["task"])
    return repo["name"]


# ---- the console's side (database) -----------------------------------------------------------------

def settings(conn):
    try:
        with conn.transaction():
            r = conn.execute("SELECT * FROM repo_settings WHERE id = 1").fetchone()
    except Exception:  # noqa: BLE001 - schema 059 not applied yet
        return None
    return dict(r) if r else None


def listing(conn):
    s = settings(conn)
    if s is None:
        return None
    rows = [dict(r) for r in conn.execute("SELECT * FROM repo_state ORDER BY name").fetchall()]
    # The worker's own word: is it running, does it have Pulp's password (r117.1)
    w = None
    try:
        with conn.transaction():
            w = conn.execute("""SELECT beat_at, detail, extract(epoch FROM now() - beat_at)::int AS age
                                  FROM worker_heartbeat WHERE name = 'repos'""").fetchone()
    except Exception:  # noqa: BLE001
        w = None
    worker = None
    if w:
        d = w["detail"] if isinstance(w["detail"], dict) else json.loads(w["detail"] or "{}")
        worker = {"beat_at": w["beat_at"], "age_s": w["age"], "configured": d.get("configured", True),
                  "running": d.get("running"), "importing": bool(d.get("importing"))}
    return {"settings": s, "repos": rows, "tz": TZ_LABEL, "worker": worker}


def request(conn, names, action, actor):
    """Queue an action for the worker. names: list of repository names, or ['*'] for all."""
    if action not in ("sync", "publish", "sync_publish"):
        raise ValueError("The action must be sync, publish or sync_publish.")
    names = [n for n in names if n == "*" or NAME_RE.match(n)][:200]
    if not names:
        raise ValueError("Say which repositories.")
    if "*" in names:
        r = conn.execute("""UPDATE repo_state SET requested = %s, requested_by = %s, requested_at = now()
                             WHERE state <> 'running' RETURNING name""", (action, actor)).fetchall()
    else:
        r = conn.execute("""UPDATE repo_state SET requested = %s, requested_by = %s, requested_at = now()
                             WHERE name = ANY(%s) AND state <> 'running' RETURNING name""", (action, actor, names)).fetchall()
    return [x["name"] for x in r]


def due_slot(s, now=None):
    """The scheduled run due now ('YYYY-MM-DD HH:MM' SGT), or None. A slot is due from its time
    for 3 hours, and runs once (last_slot)."""
    if not s or not s.get("enabled"):
        return None
    now = (now or datetime.now(timezone.utc)).astimezone(TZ)
    for t in sorted(s.get("times") or []):
        if not TIME_RE.match(t):
            continue
        h, m = int(t[:2]), int(t[3:])
        for day in (now.date(), now.date() - timedelta(days=1)):
            at = datetime(day.year, day.month, day.day, h, m, tzinfo=TZ)
            slot = at.strftime("%Y-%m-%d %H:%M")
            if at <= now < at + timedelta(hours=3) and slot > (s.get("last_slot") or ""):
                return slot
    return None


def refresh(conn, pulp):
    """Bring repo_state in line with what Pulp holds (new repositories appear, removed ones go)."""
    inv = inventory(pulp)
    names = [x["name"] for x in inv]
    for x in inv:
        conn.execute(
            """INSERT INTO repo_state (name, type, version, published_version, base_path, packages, advisories, has_remote, seen_at)
               VALUES (%(name)s, %(type)s, %(version)s, %(published_version)s, %(base_path)s, %(packages)s, %(advisories)s,
                       %(has_remote)s, now())
               ON CONFLICT (name) DO UPDATE SET type = EXCLUDED.type, version = EXCLUDED.version,
                   published_version = EXCLUDED.published_version, base_path = EXCLUDED.base_path,
                   packages = EXCLUDED.packages, advisories = EXCLUDED.advisories, has_remote = EXCLUDED.has_remote,
                   seen_at = now()""", x)
    conn.execute("DELETE FROM repo_state WHERE NOT (name = ANY(%s)) AND state <> 'running'", (names,))
    conn.execute("UPDATE repo_settings SET pulp_ok_at = now(), pulp_error = NULL WHERE id = 1")
    conn.commit()
    return {x["name"]: x for x in inv}


def run_one(conn, pulp, repo, action, stop=lambda: False):
    """Sync and/or publish one repository, recording each step. Returns True when it worked."""
    name = repo["name"]
    conn.execute("""UPDATE repo_state SET state = 'running', step = %s, started_at = now(), progress = NULL, error = NULL,
                           requested = NULL WHERE name = %s""", ("sync" if action != "publish" else "publish", name))
    conn.commit()
    last = {"t": 0.0}

    def progress(t):
        if time.time() - last["t"] < 10:
            return
        last["t"] = time.time()
        reps = [{"m": (p.get("message") or "")[:80], "done": p.get("done"), "total": p.get("total")}
                for p in (t.get("progress_reports") or [])][:6]
        conn.execute("UPDATE repo_state SET progress = %s::jsonb WHERE name = %s", (json.dumps(reps), name))
        conn.commit()
    try:
        if action in ("sync", "sync_publish"):
            v = sync(pulp, repo, stop, progress)
            conn.execute("""UPDATE repo_state SET last_sync_at = now(), last_sync_ok = true, last_sync_version = %s,
                                   step = 'publish' WHERE name = %s""", (v, name))
            conn.commit()
        if action in ("publish", "sync_publish"):
            bp = publish(pulp, repo)
            conn.execute("UPDATE repo_state SET last_publish_at = now(), base_path = %s WHERE name = %s", (bp, name))
        conn.execute("UPDATE repo_state SET state = 'done', step = NULL, finished_at = now(), progress = NULL WHERE name = %s",
                     (name,))
        conn.commit()
        return True
    except Exception as e:  # noqa: BLE001 - recorded, the next repository goes on
        msg = str(e) if isinstance(e, PulpError) else f"{type(e).__name__}: {e}"
        log.warning("repository %s: %s", name, msg)
        conn.rollback()
        conn.execute("""UPDATE repo_state SET state = 'failed', finished_at = now(), error = %s, progress = NULL,
                               last_sync_ok = CASE WHEN step = 'sync' THEN false ELSE last_sync_ok END WHERE name = %s""",
                     (msg[:600], name))
        conn.commit()
        return False
