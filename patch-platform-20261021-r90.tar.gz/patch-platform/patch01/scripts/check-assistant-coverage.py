#!/usr/bin/env python3
"""Every page in the console's menu must be known to the AI-01 assistant (api/app/chat.py,
PORTAL_PAGES), and the assistant must not point to pages that are gone. Run by
phase5-dashboard.sh before the console is installed: a page added without teaching the
assistant stops the deploy. Standard library only; reads the two files as text.

  ./scripts/check-assistant-coverage.py [bundle root]
"""
import os
import re
import sys

root = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
js = open(os.path.join(root, "dashboard/html/cyber.js"), encoding="utf-8").read()
py = open(os.path.join(root, "api/app/chat.py"), encoding="utf-8").read()


def block(text, start, end):
    i = text.index(start)
    return text[i:text.index(end, i)]


menu = set(re.findall(r'\["([a-z-]+)", "[A-Z]', block(js, "const SECTIONS = [", "];")))
home = set(re.findall(r'(?:^|[{,]\s*)"?([a-z-]+)"?:\s*\[', block(js, "const ROUTE_HOME = {", "};")))
known = set(re.findall(r'^\s*\("([a-z-]+)", "', block(py, "PORTAL_PAGES = [", "\n]"), re.M))
missing = sorted(menu - known)
stale = sorted(known - menu - home)
if not menu or not known:
    print("check-assistant-coverage: could not read the menu or the assistant's pages", file=sys.stderr)
    sys.exit(2)
if missing or stale:
    if missing:
        print("The AI-01 assistant does not know these pages: " + ", ".join(missing)
              + " (add them to PORTAL_PAGES in api/app/chat.py)", file=sys.stderr)
    if stale:
        print("The AI-01 assistant points to pages no longer in the menu: " + ", ".join(stale), file=sys.stderr)
    sys.exit(1)
print(f"AI-01 assistant knows all {len(menu)} pages of the menu.")
