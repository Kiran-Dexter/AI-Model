-- ===========================================================================
-- PATCH-01 : schema 047 - Software under one roof; removing installed tools
--
-- Applied after 046. Idempotent.
--
-- windows_software.uninstall_key  the program's own Programs and Features key
--                                  (an MSI product code, or the key's name), sent
--                                  by Windows agent 1.9.3 and later
-- windows_software.uninstall_how  how it can be removed silently: msi, quiet
--                                  (its own quiet command), inno, nsis; NULL: no
--                                  silent way known, so never removed from here
-- software_removable               the removable tools list: a program may be
--                                  removed only when its name starts with an entry
--                                  (and it is not critical software, which the code
--                                  refuses whatever this list says)
-- ===========================================================================

ALTER TABLE windows_software ADD COLUMN IF NOT EXISTS uninstall_key TEXT;
ALTER TABLE windows_software ADD COLUMN IF NOT EXISTS uninstall_how TEXT;
ALTER TABLE windows_software DROP CONSTRAINT IF EXISTS windows_software_uninstall_how_check;
ALTER TABLE windows_software ADD CONSTRAINT windows_software_uninstall_how_check
    CHECK (uninstall_how IS NULL OR uninstall_how IN ('msi', 'quiet', 'inno', 'nsis'));

CREATE TABLE IF NOT EXISTS software_removable (
    pattern     TEXT PRIMARY KEY CHECK (pattern ~ '^[A-Za-z0-9][A-Za-z0-9 .+_()&''-]{2,79}$'),
    builtin     BOOLEAN NOT NULL DEFAULT false,
    created_by  TEXT NOT NULL DEFAULT 'PATCH-01',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_swrem_lower ON software_removable (lower(pattern));

-- The common tools PATCH-01 starts with (only when the list has never been set up,
-- so entries an admin removed do not come back)
INSERT INTO software_removable (pattern, builtin)
SELECT x, true FROM unnest(ARRAY[
    '7-Zip', 'Notepad++', 'WinRAR', 'PeaZip', 'PuTTY', 'WinSCP', 'FileZilla Client', 'Wireshark', 'Npcap', 'WinPcap',
    'mRemoteNG', 'TreeSize', 'WinDirStat', 'WinMerge', 'Sublime Text', 'Microsoft Visual Studio Code', 'Notepad2',
    'Google Chrome', 'Mozilla Firefox', 'Adobe Acrobat Reader', 'Foxit PDF Reader', 'VLC media player', 'Greenshot',
    'paint.net', 'KeePass', 'TeamViewer', 'AnyDesk', 'Advanced IP Scanner', 'Angry IP Scanner', 'Bginfo']) AS x
WHERE NOT EXISTS (SELECT 1 FROM schema_version WHERE version = 47)
ON CONFLICT DO NOTHING;

INSERT INTO schema_version (version, description)
VALUES (47, 'Software under one roof; removing installed tools (removable tools list, uninstall keys)')
ON CONFLICT (version) DO NOTHING;
