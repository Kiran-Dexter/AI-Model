-- ===========================================================================
-- PATCH-01 : schema 049 - Faster pages at fleet scale
--
-- Applied after 048. Idempotent. Measured with 2,000 servers (r90):
--
-- jit = off            PostgreSQL's JIT compiler spent ~7 s compiling the Servers
--                      page's query (which itself runs in ~0.1 s) once the
--                      fleet grew past a few hundred servers. The console's
--                      queries are short and many: JIT never pays back here.
--                      Set for this database only; new sessions pick it up
--                      (the API and worker reconnect when phase3b restarts them).
-- idx_winsw_host_reported
--                      each server's newest software report (Deployment's
--                      per-server list): an index lookup instead of walking
--                      every report (8.7 s -> 0.15 s).
-- idx_pkgs_lower_name  Linux packages listed in name order without sorting a
--                      million rows on disk (1 s -> 0.07 s).
-- ===========================================================================

DO $$
BEGIN
    EXECUTE format('ALTER DATABASE %I SET jit = off', current_database());
END
$$;

CREATE INDEX IF NOT EXISTS idx_winsw_host_reported ON windows_software (host_id, reported_at DESC);
CREATE INDEX IF NOT EXISTS idx_pkgs_lower_name ON host_packages (lower(name));

INSERT INTO schema_version (version, description)
VALUES (49, 'Faster pages at fleet scale: JIT off, two indexes')
ON CONFLICT (version) DO NOTHING;
