-- ===========================================================================
-- PATCH-01 : schema 048 - Software end of support / end of life (the frame)
--
-- Applied after 047. Idempotent.
--
-- software_lifecycle  one rule per product (and optionally per version line):
--                     the program's name as it starts, an optional version
--                     prefix ("2016", "8.0"), and the end-of-support and
--                     end-of-life dates. Installed software shows each
--                     program's support state from the most specific rule.
--                     Rules are kept by admins today; a feed can fill the same
--                     table later (source says where a rule came from).
-- ===========================================================================

CREATE TABLE IF NOT EXISTS software_lifecycle (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    platform        TEXT NOT NULL DEFAULT 'windows' CHECK (platform IN ('windows', 'linux')),
    name_prefix     TEXT NOT NULL CHECK (name_prefix ~ '^[A-Za-z0-9][A-Za-z0-9 .+_()&''/-]{1,79}$'),
    version_prefix  TEXT NOT NULL DEFAULT '' CHECK (version_prefix ~ '^[0-9A-Za-z.\-]{0,40}$'),
    eos             DATE,                 -- end of (mainstream) support
    eol             DATE,                 -- end of life: no more security fixes
    note            TEXT CHECK (note IS NULL OR length(note) <= 300),
    source          TEXT NOT NULL DEFAULT 'manual' CHECK (source ~ '^[a-z0-9_-]{1,30}$'),
    created_by      TEXT NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by      TEXT,
    updated_at      TIMESTAMPTZ,
    CHECK (eos IS NOT NULL OR eol IS NOT NULL),
    CHECK (eos IS NULL OR eol IS NULL OR eos <= eol)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_swlc_rule ON software_lifecycle (platform, lower(name_prefix), lower(version_prefix));

-- Installed software is cached until a server sends a new inventory: finding the newest report is an index lookup
CREATE INDEX IF NOT EXISTS idx_winsw_reported ON windows_software (reported_at DESC);

INSERT INTO schema_version (version, description)
VALUES (48, 'Software end of support / end of life rules (frame)')
ON CONFLICT (version) DO NOTHING;
