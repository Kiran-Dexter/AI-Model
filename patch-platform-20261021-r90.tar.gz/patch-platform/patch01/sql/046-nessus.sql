-- ===========================================================================
-- PATCH-01 : schema 046 - Nessus (Vulnerabilities > Nessus)
--
-- Applied after 045. Idempotent.
--
-- nessus_servers   the Nessus scanners PATCH-01 talks to: https address, API keys
--                  (encrypted with av.key, never shown again), the pinned
--                  certificate, the product Nessus reports (Professional,
--                  Manager...) and whether it lets PATCH-01 start and create
--                  scans (scan_control: NULL not yet known, false: Nessus refuses,
--                  as Nessus Professional does)
-- nessus_scans     the scans each server holds, read every 15 minutes
-- nessus_findings  the latest imported results of each scan: one row per host,
--                  plugin and port (low severity and above), with the CVEs
-- nessus_reports   reports asked of Nessus (PDF, HTML, CSV, .nessus): Nessus
--                  builds the file, PATCH-01 passes it through, nothing is kept
-- ===========================================================================

CREATE TABLE IF NOT EXISTS nessus_servers (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name              TEXT NOT NULL UNIQUE CHECK (name ~ '^[A-Za-z0-9 ._()-]{1,60}$'),
    url               TEXT NOT NULL UNIQUE,
    access_key_enc    TEXT NOT NULL,
    secret_key_enc    TEXT NOT NULL,
    pin_sha256        TEXT CHECK (pin_sha256 IS NULL OR pin_sha256 ~ '^[0-9a-f]{64}$'),
    pin_subject       TEXT,
    pin_not_after     TIMESTAMPTZ,
    pinned_by         TEXT,
    pinned_at         TIMESTAMPTZ,
    enabled           BOOLEAN NOT NULL DEFAULT true,
    product           TEXT,
    version           TEXT,
    scan_control      BOOLEAN,
    created_by        TEXT NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by        TEXT,
    updated_at        TIMESTAMPTZ,
    last_test_at      TIMESTAMPTZ,
    last_test_ok      BOOLEAN,
    last_test_msg     TEXT,
    last_sync_at      TIMESTAMPTZ,
    last_sync_ok      BOOLEAN,
    last_sync_msg     TEXT,
    sync_requested_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS nessus_scans (
    server_id           UUID NOT NULL REFERENCES nessus_servers(id) ON DELETE CASCADE,
    scan_id             INTEGER NOT NULL,
    uuid                TEXT,
    name                TEXT NOT NULL,
    folder              TEXT,
    folder_id           INTEGER,
    rrules              TEXT,                -- Nessus's own schedule rule (kept to edit the scan)
    status              TEXT,
    enabled             BOOLEAN,
    schedule            TEXT,
    targets             TEXT,
    owner               TEXT,
    last_start          TIMESTAMPTZ,
    last_end            TIMESTAMPTZ,
    last_history_id     INTEGER,             -- the newest finished run
    history_end         TIMESTAMPTZ,         -- when that run finished (the date its findings count from)
    hosts               INTEGER,
    critical            INTEGER,
    high                INTEGER,
    medium              INTEGER,
    low                 INTEGER,
    imported_history_id INTEGER,
    imported_at         TIMESTAMPTZ,
    import_requested_at TIMESTAMPTZ,
    import_error        TEXT,
    synced_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (server_id, scan_id)
);

CREATE TABLE IF NOT EXISTS nessus_findings (
    server_id      UUID NOT NULL,
    scan_id        INTEGER NOT NULL,
    history_id     INTEGER,
    host_name      TEXT NOT NULL,
    host_ip        TEXT,
    host_fqdn      TEXT,
    host_os        TEXT,
    host_id        UUID REFERENCES hosts(id) ON DELETE SET NULL,
    plugin_id      INTEGER NOT NULL,
    plugin_name    TEXT,
    family         TEXT,
    severity       SMALLINT NOT NULL CHECK (severity BETWEEN 0 AND 4),
    cvss3          NUMERIC(3,1),
    cvss           NUMERIC(3,1),
    cves           TEXT[] NOT NULL DEFAULT '{}',
    port           INTEGER NOT NULL DEFAULT 0,
    protocol       TEXT NOT NULL DEFAULT '',
    service        TEXT,
    synopsis       TEXT,
    solution       TEXT,
    exploit        BOOLEAN,
    seen_at        TIMESTAMPTZ,
    PRIMARY KEY (server_id, scan_id, host_name, plugin_id, port, protocol),
    FOREIGN KEY (server_id, scan_id) REFERENCES nessus_scans(server_id, scan_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_nf_cves ON nessus_findings USING gin (cves);
CREATE INDEX IF NOT EXISTS idx_nf_host ON nessus_findings (host_id);
CREATE INDEX IF NOT EXISTS idx_nf_sev ON nessus_findings (severity DESC);

CREATE TABLE IF NOT EXISTS nessus_reports (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    server_id     UUID NOT NULL REFERENCES nessus_servers(id) ON DELETE CASCADE,
    scan_id       INTEGER NOT NULL,
    history_id    INTEGER,
    format        TEXT NOT NULL CHECK (format IN ('pdf', 'html', 'csv', 'nessus')),
    file_id       BIGINT,
    state         TEXT NOT NULL DEFAULT 'exporting' CHECK (state IN ('exporting', 'ready', 'failed', 'downloaded')),
    error         TEXT,
    requested_by  TEXT NOT NULL,
    requested_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at   TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_nr_at ON nessus_reports (requested_at DESC);

INSERT INTO schema_version (version, description)
VALUES (46, 'Nessus: scanners, scans, imported findings, reports')
ON CONFLICT (version) DO NOTHING;
