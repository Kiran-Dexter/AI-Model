"""Mail alerts, branding, reports, and reports by e-mail.

Split out of main.py in r90; the code is unchanged."""

import json
import os
import re
from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field, field_validator
from typing import Any, Dict, List, Optional

from .core import (EMAIL_RE, app, audit, client_ip, db, jsonable, require_admin, require_operator, require_viewer)


# ---------------------------------------------------------------------------
# Mail alerts (admin): settings, recipients, tests
# ---------------------------------------------------------------------------


def _mail_audit(conn, admin, request, action, obj, detail):
    conn.execute(
        """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
           VALUES (%s,'user',%s,'mail',%s,%s,%s)""",
        (admin, action, obj, json.dumps(detail), client_ip(request)))


def _mail_view(conn):
    from . import notify as nt
    cfg = nt.config(conn, with_password=False)
    recips = conn.execute("SELECT * FROM mail_recipients ORDER BY lower(address)").fetchall()
    recent = conn.execute(
        """SELECT id, created_at, category, severity, subject, recipients, state, attempts,
                  sent_at, last_error FROM notifications ORDER BY id DESC LIMIT 60""").fetchall()
    counts = conn.execute("""SELECT state, count(*) AS n FROM notifications
                              WHERE created_at > now() - interval '7 days' GROUP BY 1""").fetchall()
    beat = conn.execute("SELECT beat_at, detail FROM worker_heartbeat WHERE name='mail'").fetchone()
    pub = nt.public_config(cfg)
    pub["key_present"] = os.path.exists(nt.KEY_FILE)
    return {"settings": pub, "recipients": recips, "recent": recent,
            "counts_7d": {r["state"]: r["n"] for r in counts}, "worker": beat}


@app.get("/api/v1/admin/mail")
def mail_get(admin: str = Depends(require_admin)):
    with db() as conn:
        return _mail_view(conn)


class MailSettingsIn(BaseModel):
    enabled: bool = False
    host: str = Field(default="", max_length=253)
    port: int = Field(default=25, ge=1, le=65535)
    tls: str = Field(default="starttls", pattern="^(starttls|tls|none)$")
    verify: bool = True
    ca_pem: Optional[str] = Field(default=None, max_length=20000)
    username: str = Field(default="", max_length=320)
    # None keeps the saved password; "" removes it; anything else replaces it
    password: Optional[str] = Field(default=None, max_length=512)
    from_addr: str = Field(default="", max_length=320)
    from_name: str = Field(default="", max_length=120)
    send_critical: bool = True
    send_tasks: bool = True
    send_digest: bool = True
    send_weekly: bool = True
    digest_time: str = Field(default="07:00", pattern="^([01][0-9]|2[0-3]):[0-5][0-9]$")
    weekly_day: str = Field(default="mon", pattern="^(mon|tue|wed|thu|fri|sat|sun)$")
    console_url: str = Field(default="", max_length=300)
    company: str = Field(default="", max_length=120)
    signature: str = Field(default="", max_length=2000)


def _cfg_from_form(conn, body):
    """A config built from form values not yet saved, for testing before saving."""
    from . import notify as nt
    cfg = nt.config(conn)
    cfg.update(host=body.host.strip(), port=body.port, tls=body.tls, verify=body.verify,
               ca_pem=(body.ca_pem or "").strip() or None, user=body.username.strip(),
               **{"from": body.from_addr.strip()}, from_name=body.from_name.strip(),
               console=body.console_url.strip().rstrip("/"), company=body.company.strip() or "PATCH-01",
               signature=body.signature.strip())
    if body.password is not None:
        cfg["password"] = body.password
    return cfg


@app.put("/api/v1/admin/mail")
def mail_save(body: MailSettingsIn, request: Request, admin: str = Depends(require_admin)):
    import re as _re
    from . import notify as nt
    if body.from_addr and not _re.match(EMAIL_RE, body.from_addr.strip()):
        raise HTTPException(422, "The From address is not an e-mail address.")
    if body.enabled and not (body.host.strip() and body.from_addr.strip()):
        raise HTTPException(422, "To turn mail on, enter the relay host and the From address.")
    if body.ca_pem and "BEGIN CERTIFICATE" not in body.ca_pem:
        raise HTTPException(422, "The CA certificate must be PEM text starting with -----BEGIN CERTIFICATE-----.")
    with db() as conn:
        with conn.transaction():
            enc = None
            if body.password:
                try:
                    enc = nt.encrypt(body.password)
                except RuntimeError as e:
                    raise HTTPException(503, str(e))
            if body.enabled and not conn.execute("SELECT 1 FROM mail_recipients LIMIT 1").fetchone():
                raise HTTPException(422, "Add at least one recipient before turning mail on.")
            conn.execute(
                """UPDATE mail_settings SET enabled=%s, host=%s, port=%s, tls=%s, verify=%s, ca_pem=%s,
                          username=%s, from_addr=%s, from_name=%s, send_critical=%s, send_tasks=%s,
                          send_digest=%s, send_weekly=%s, digest_time=%s, weekly_day=%s, console_url=%s,
                          company=%s, signature=%s, updated_by=%s, updated_at=now(),
                          password_enc = CASE WHEN %s::boolean THEN %s
                                              WHEN %s::boolean THEN NULL ELSE password_enc END
                    WHERE id = 1""",
                (body.enabled, body.host.strip(), body.port, body.tls, body.verify, (body.ca_pem or "").strip() or None,
                 body.username.strip(), body.from_addr.strip(), body.from_name.strip(), body.send_critical,
                 body.send_tasks, body.send_digest, body.send_weekly, body.digest_time, body.weekly_day,
                 body.console_url.strip().rstrip("/"), body.company.strip(), body.signature.strip(), admin,
                 enc is not None, enc, body.password == "" and enc is None))
            _mail_audit(conn, admin, request, "mail_settings_saved", body.host.strip() or "-",
                        {"enabled": body.enabled, "host": body.host, "port": body.port, "tls": body.tls,
                         "verify": body.verify, "login": bool(body.username),
                         "password": "replaced" if enc else ("removed" if body.password == "" else "unchanged")})
        return _mail_view(conn)


@app.post("/api/v1/admin/mail/check")
def mail_check(body: MailSettingsIn, request: Request, admin: str = Depends(require_admin)):
    """Test the relay with the values in the form, saved or not. Sends nothing."""
    from . import notify as nt
    with db() as conn:
        try:
            cfg = _cfg_from_form(conn, body)
        except RuntimeError as e:
            return {"ok": False, "steps": [{"step": "Password", "ok": False, "detail": str(e)}]}
        steps = nt.test_connection(cfg)
        _mail_audit(conn, admin, request, "mail_connection_test", cfg["host"] or "-",
                    {"ok": all(x["ok"] for x in steps), "failed_at": next((x["step"] for x in steps if not x["ok"]), None)})
        conn.commit()
    return {"ok": all(x["ok"] for x in steps), "steps": steps}


class MailTestIn(BaseModel):
    to: Optional[str] = Field(default=None, max_length=320)


@app.post("/api/v1/admin/mail/test")
def mail_test(body: MailTestIn, request: Request, admin: str = Depends(require_admin)):
    """Send a real test mail with the saved settings."""
    import re as _re
    from . import notify as nt
    with db() as conn:
        cfg = nt.config(conn)
        to = [body.to.strip()] if body.to and _re.match(EMAIL_RE, body.to.strip()) else cfg["to"]
        try:
            nt.test_mail(cfg, to)
            ok, err = True, None
        except Exception as e:  # noqa: BLE001 - the reason is the point of a test
            ok, err = False, str(e)
        _mail_audit(conn, admin, request, "mail_test", ", ".join(to) or "-", {"ok": ok, "error": err})
        conn.commit()
    if not ok:
        raise HTTPException(502, err)
    return {"ok": True, "to": to}


class RecipientIn(BaseModel):
    address: str = Field(..., max_length=320)
    name: str = Field(default="", max_length=120)
    critical: bool = True
    tasks: bool = True
    digest: bool = True
    weekly: bool = True


@app.post("/api/v1/admin/mail/recipients")
def mail_recipient_add(body: RecipientIn, request: Request, admin: str = Depends(require_admin)):
    import re as _re
    addr = body.address.strip()
    if not _re.match(EMAIL_RE, addr):
        raise HTTPException(422, f"'{addr}' is not an e-mail address.")
    with db() as conn:
        with conn.transaction():
            if conn.execute("SELECT 1 FROM mail_recipients WHERE lower(address)=lower(%s)", (addr,)).fetchone():
                raise HTTPException(409, f"{addr} is already a recipient.")
            conn.execute(
                """INSERT INTO mail_recipients (address, name, critical, tasks, digest, weekly, added_by)
                   VALUES (%s,%s,%s,%s,%s,%s,%s)""",
                (addr, body.name.strip() or None, body.critical, body.tasks, body.digest, body.weekly, admin))
            _mail_audit(conn, admin, request, "mail_recipient_added", addr,
                        {"critical": body.critical, "tasks": body.tasks, "digest": body.digest, "weekly": body.weekly})
        return _mail_view(conn)


class RecipientPatch(BaseModel):
    name: Optional[str] = Field(default=None, max_length=120)
    critical: Optional[bool] = None
    tasks: Optional[bool] = None
    digest: Optional[bool] = None
    weekly: Optional[bool] = None


@app.patch("/api/v1/admin/mail/recipients/{rid}")
def mail_recipient_update(rid: int, body: RecipientPatch, request: Request, admin: str = Depends(require_admin)):
    changes = {k: v for k, v in body.model_dump().items() if v is not None}
    if not changes:
        raise HTTPException(422, "Nothing to change.")
    with db() as conn:
        with conn.transaction():
            row = conn.execute("SELECT address FROM mail_recipients WHERE id=%s", (rid,)).fetchone()
            if not row:
                raise HTTPException(404, "No such recipient.")
            sets = ", ".join(f"{k}=%s" for k in changes)
            conn.execute(f"UPDATE mail_recipients SET {sets} WHERE id=%s", (*changes.values(), rid))
            _mail_audit(conn, admin, request, "mail_recipient_changed", row["address"], changes)
        return _mail_view(conn)


@app.delete("/api/v1/admin/mail/recipients/{rid}")
def mail_recipient_delete(rid: int, request: Request, admin: str = Depends(require_admin)):
    with db() as conn:
        with conn.transaction():
            row = conn.execute("DELETE FROM mail_recipients WHERE id=%s RETURNING address", (rid,)).fetchone()
            if not row:
                raise HTTPException(404, "No such recipient.")
            left = conn.execute("SELECT count(*) AS n FROM mail_recipients").fetchone()["n"]
            if left == 0:
                conn.execute("UPDATE mail_settings SET enabled=FALSE, updated_by=%s, updated_at=now() WHERE id=1", (admin,))
            _mail_audit(conn, admin, request, "mail_recipient_removed", row["address"], {"remaining": left})
        return _mail_view(conn)


# ---------------------------------------------------------------------------
# Branding (admin) and reports
# ---------------------------------------------------------------------------


def _brand_public(b):
    return {k: v for k, v in b.items() if k not in ("logo", "logo_white")} | {
        "has_logo": bool(b["logo"]), "has_logo_white": bool(b["logo_white"])}


@app.get("/api/v1/admin/branding")
def branding_get(admin: str = Depends(require_admin)):
    from . import branding as br
    with db() as conn:
        b = br.settings(conn)
        row = conn.execute("SELECT company, copyright, classification, accent FROM branding WHERE id=1").fetchone()
    return {"effective": _brand_public(b), "saved": row, "folder": "/patch/data/branding"}


class BrandingIn(BaseModel):
    company: str = Field(default="", max_length=120)
    copyright: str = Field(default="", max_length=200)
    classification: str = Field(default="CONFIDENTIAL", min_length=1, max_length=40)
    accent: Optional[str] = Field(default=None, pattern="^#[0-9A-Fa-f]{6}$")


@app.put("/api/v1/admin/branding")
def branding_put(body: BrandingIn, request: Request, admin: str = Depends(require_admin)):
    from . import branding as br
    with db() as conn:
        with conn.transaction():
            conn.execute(
                """UPDATE branding SET company=%s, copyright=%s, classification=%s, accent=%s,
                          updated_by=%s, updated_at=now() WHERE id=1""",
                (body.company.strip(), body.copyright.strip(), body.classification.strip().upper(),
                 body.accent, admin))
            conn.execute(
                """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
                   VALUES (%s,'user','branding_saved','branding','1',%s,%s)""",
                (admin, json.dumps(body.model_dump()), client_ip(request)))
        return {"effective": _brand_public(br.settings(conn))}


TABLE_REPORT_MAX_CHARS = 3_000_000     # all cell text in one report (about 1,500 PDF pages)


TABLE_REPORTS_PER_10MIN = 30


class TableReportIn(BaseModel):
    title: str = Field(..., min_length=1, max_length=120)
    filter: str = Field(default="", max_length=300)
    columns: List[str] = Field(..., min_length=1, max_length=30)
    rows: List[List[Any]] = Field(default_factory=list, max_length=5000)
    format: str = Field("pdf", pattern="^(pdf|csv)$")

    @field_validator("columns")
    @classmethod
    def _cols(cls, v):
        return [str(c)[:60] for c in v]


@app.post("/api/v1/export/table")
def export_table(body: TableReportIn, request: Request, user: str = Depends(require_viewer)):
    """A report of the table a page is showing, as PDF (with the logo) or CSV,
    both with the organisation, date and time, user and filter. The browser
    sends only what this user is already looking at; every value is written as
    plain text (no markup in the PDF, no formulas in the CSV)."""
    from fastapi.responses import Response
    from . import exports as ex
    n = len(body.columns)
    rows, budget = [], TABLE_REPORT_MAX_CHARS
    for r in body.rows:
        out = []
        for v in r[:n]:
            if v is None or isinstance(v, (bool, int, float)):
                out.append(v)
            else:
                out.append(str(v)[:1000])
                budget -= len(out[-1])
        if budget < 0:
            raise HTTPException(413, "This table is too large for one report: narrow it with the filters.")
        rows.append(out + [""] * (n - len(out)))
    title = re.sub(r"[\r\n\t]+", " ", body.title).strip()
    with db() as conn:
        recent = conn.execute(
            """SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'report_exported'
                AND occurred_at > now() - interval '10 minutes'""", (user,)).fetchone()["n"]
        if recent >= TABLE_REPORTS_PER_10MIN:
            raise HTTPException(429, f"At most {TABLE_REPORTS_PER_10MIN} exports in 10 minutes: try again shortly.")
        m = ex.meta(title, user, re.sub(r"[\r\n\t]+", " ", body.filter).strip(), len(rows), ex.company_name(conn))
        data, mime, ext = ex.render(body.format, m, body.columns, rows, conn)
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="report_exported",
                  detail={"title": title, "format": body.format, "rows": len(rows)}, source_ip=client_ip(request))
    base = re.sub(r"[^A-Za-z0-9]+", "-", title.lower()).strip("-")[:40] or "report"
    return Response(data, media_type=mime, headers={
        "Content-Disposition": f'attachment; filename="{ex.file_name(base, ext)}"',
        "Cache-Control": "no-store", "X-Rows": str(len(rows))})


@app.get("/api/v1/branding/info")
def branding_info(user: str = Depends(require_viewer)):
    """The organisation's name, for the heading of exports made in the browser."""
    from . import exports as ex
    with db() as conn:
        return {"company": ex.company_name(conn), "portal": ex.PORTAL, "tz": ex.TZ_LABEL}


@app.get("/api/v1/branding/logo")
def branding_logo(variant: str = "main", user: str = Depends(require_viewer)):
    """The processed logo, as reports use it."""
    from fastapi.responses import Response
    from . import branding as br
    with db() as conn:
        b = br.settings(conn)
    data = b["logo_white"] if variant == "white" else b["logo"]
    if not data:
        raise HTTPException(404, "No logo found in /patch/data/branding.")
    return Response(data, media_type="image/png", headers={"Cache-Control": "no-store"})


class ReportIn(BaseModel):
    level: str = Field(default="l1", pattern="^(l1|l2|custom:[0-9a-f-]{36})$")
    format: str = Field(default="pdf", pattern="^(pdf|docx)$")
    host_ids: Optional[List[str]] = None
    host_group: Optional[str] = Field(default=None, max_length=120)
    scope_label: Optional[str] = Field(default=None, max_length=80)
    detail: str = Field(default="high_medium", pattern="^(all|high_medium|high)$")
    style: str = Field(default="management", pattern="^(management|technical)$")


@app.post("/api/v1/reports/hardening")
def report_hardening(body: ReportIn, request: Request, user: str = Depends(require_viewer)):
    """Build a branded hardening report and keep it in the archive."""
    from . import branding as br, reports as rp
    with db() as conn:
        host_ids = body.host_ids
        label = body.scope_label
        if body.host_group:
            host_ids = [str(r["id"]) for r in conn.execute(
                "SELECT id FROM hosts WHERE host_group=%s AND status <> 'decommissioned'", (body.host_group,)).fetchall()]
            label = label or f"Group {body.host_group}"
            if not host_ids:
                raise HTTPException(422, f"No servers in group {body.host_group}.")
        role = getattr(request.state, "user", {}) or {}
        who = f"{user} ({role.get('role')})" if isinstance(role, dict) and role.get("role") else user
        try:
            with conn.transaction():
                r = rp.generate(conn, br.settings(conn), body.level, body.format, host_ids, label, body.detail, who,
                                body.style)
                conn.execute(
                    """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
                       VALUES (%s,'user','report_generated','report',%s,%s,%s)""",
                    (user, r["id"], json.dumps({"report": r["report_id"], "format": body.format, "level": body.level,
                                                "servers": r["servers"], "sha256": r["sha256"]}), client_ip(request)))
        except ValueError as e:
            raise HTTPException(422, str(e))
    return r


@app.get("/api/v1/reports")
def reports_list(user: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT id, number, kind, level, format, title, generated_by, generated_at, pages, servers, score,
                      size_bytes, sha256, facts->>'report_id' AS report_ref, scope->>'style' AS style
                 FROM reports WHERE path IS NOT NULL ORDER BY generated_at DESC LIMIT 100""").fetchall()
    return {"reports": rows}


@app.get("/api/v1/reports/{report_id}/download")
def report_download(report_id: str, request: Request, user: str = Depends(require_viewer)):
    from fastapi.responses import FileResponse
    with db() as conn:
        r = conn.execute("SELECT * FROM reports WHERE id=%s", (report_id,)).fetchone()
        if not r or not r["path"] or not os.path.exists(r["path"]):
            raise HTTPException(404, "This report file is no longer on PATCH-01.")
        conn.execute(
            """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
               VALUES (%s,'user','report_downloaded','report',%s,%s,%s)""",
            (user, report_id, json.dumps({"file": os.path.basename(r["path"])}), client_ip(request)))
        conn.commit()
    media = "application/pdf" if r["format"] == "pdf" else \
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    return FileResponse(r["path"], media_type=media, filename=os.path.basename(r["path"]))


# ---------------------------------------------------------------------------
# E-mailing a report (operators and admins)
# ---------------------------------------------------------------------------


@app.get("/api/v1/mail/recipients")
def mail_recipients(user: str = Depends(require_operator)):
    """Addresses to pick from when sending a report. Addresses only."""
    with db() as conn:
        rows = conn.execute("SELECT address, name FROM mail_recipients ORDER BY lower(address)").fetchall()
    return {"recipients": rows}


def _report_row(conn, report_id):
    r = conn.execute("SELECT * FROM reports WHERE id=%s", (report_id,)).fetchone()
    if not r or not r["path"] or not os.path.exists(r["path"]):
        raise HTTPException(404, "This report file is no longer on PATCH-01.")
    if not r.get("facts"):
        raise HTTPException(409, "This report was made before e-mailing was possible: generate it again.")
    return r


@app.post("/api/v1/reports/{report_id}/email/draft")
def report_email_draft(report_id: str, user: str = Depends(require_operator)):
    """A summary of the report and a draft e-mail for it. AI-01 drafts from
    the report's own figures; if it cannot, a structured template does."""
    from . import notify as nt, report_mail as rm
    with db() as conn:
        r = _report_row(conn, report_id)
        cfg = nt.config(conn, with_password=False)
    f = r["facts"]
    subject, body = rm.template(f)
    return {"summary": rm.summary(f), "stats": rm.stats(f), "subject": subject, "body": body, "source": "template",
            "note": "A short summary of the report. Edit it as you like, or ask AI-01 to polish it.",
            "attachment": {"file": os.path.basename(r["path"]), "size_bytes": r["size_bytes"], "format": r["format"]},
            "signature": cfg["signature"], "from": cfg["from"], "from_name": cfg["from_name"],
            "ready": bool(cfg["host"] and cfg["from"])}


@app.post("/api/v1/reports/{report_id}/email/polish")
def report_email_polish(report_id: str, user: str = Depends(require_operator)):
    """AI-01's version of the short e-mail, checked against the report's figures."""
    from . import report_mail as rm
    with db() as conn:
        r = _report_row(conn, report_id)
    subject, body, source, note = rm.draft(r["facts"])
    return {"subject": subject, "body": body, "source": source, "note": note}


class ReportMailIn(BaseModel):
    to: List[str] = Field(..., min_length=1, max_length=30)
    cc: List[str] = Field(default_factory=list, max_length=30)
    subject: str = Field(..., min_length=3, max_length=200)
    body: str = Field(..., min_length=20, max_length=20000)


@app.post("/api/v1/reports/{report_id}/email")
def report_email_send(report_id: str, body: ReportMailIn, request: Request, user: str = Depends(require_operator)):
    """Send the report, attached, with the body as written and the signature."""
    import re as _re
    from . import notify as nt
    bad = [a for a in body.to + body.cc if not _re.match(EMAIL_RE, a.strip())]
    if bad:
        raise HTTPException(422, "Not e-mail addresses: " + ", ".join(bad))
    to = [a.strip() for a in body.to]
    cc = [a.strip() for a in body.cc if a.strip().lower() not in {x.lower() for x in to}]
    with db() as conn:
        r = _report_row(conn, report_id)
        cfg = nt.config(conn)
        if not (cfg["host"] and cfg["from"]):
            raise HTTPException(409, "Mail is not set up yet: an admin can do it under Admin, Mail.")
        # Only inside the organisation: the configured recipients, or addresses in the same mail domains
        # as the sender and the recipients set in Admin > Mail (a hardening report lists weaknesses)
        domains = {a.rsplit("@", 1)[-1].lower() for a in [cfg["from"]] + list(cfg.get("to") or []) if "@" in a}
        known = {a.lower() for a in cfg.get("to") or []}
        outside = [a for a in to + cc if a.lower() not in known and a.rsplit("@", 1)[-1].lower() not in domains]
        if outside:
            raise HTTPException(403, "Hardening reports go only to addresses in your organisation's mail domains ("
                                     + ", ".join(sorted(domains)[:5]) + "). Not allowed: " + ", ".join(a[:80] for a in outside[:5]))
        n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'report_emailed'
                              AND occurred_at > now() - interval '1 hour'""", (user,)).fetchone()["n"]
        if n >= REPORT_MAILS_PER_HOUR:
            raise HTTPException(429, f"At most {REPORT_MAILS_PER_HOUR} report e-mails an hour: try again later.")
        with open(r["path"], "rb") as fh:
            data = fh.read()
        mime = "application/pdf" if r["format"] == "pdf" else \
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        from . import report_mail as rm
        text, html = nt.render(cfg, body.subject, "info", "", [("stats", rm.stats(r["facts"])), ("text", body.body)],
                               link=None, label="Hardening report", greeting=False)   # the editable draft carries its own greeting
        state, err = "sent", None
        try:
            nt.send(cfg, to, body.subject, text, html, cc=cc, attachments=[(os.path.basename(r["path"]), data, mime)])
        except Exception as e:  # noqa: BLE001 - reported back and recorded
            state, err = "failed", str(e)
        with conn.transaction():
            conn.execute(
                """INSERT INTO notifications (category, severity, subject, body_text, body_html, recipients, state,
                                              attempts, sent_at, last_error, event_keys)
                   VALUES ('report', 'info', %s, %s, %s, %s, %s, 1, CASE WHEN %s THEN now() END, %s, %s)""",
                (body.subject, text, html, to + cc, state, state == "sent", err, [f"report:{report_id}"]))
            conn.execute(
                """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
                   VALUES (%s,'user','report_emailed','report',%s,%s,%s)""",
                (user, report_id, json.dumps({"to": to, "cc": cc, "subject": body.subject, "state": state, "error": err,
                                              "file": os.path.basename(r["path"])}), client_ip(request)))
    if err:
        raise HTTPException(502, err)
    return {"ok": True, "to": to, "cc": cc}


# ---------------------------------------------------------------------------
# Reports by e-mail: at once (operators) or on a schedule (admins)
# ---------------------------------------------------------------------------


REPORT_MAILS_PER_HOUR = 10


TIME_RE = r"^([01][0-9]|2[0-3]):[0-5][0-9]$"


def _report_params(p):
    """Report parameters: a few plain values, checked again by each report."""
    out = {}
    for k, v in list((p or {}).items())[:10]:
        if not re.fullmatch(r"[a-z][a-z_]{0,29}", str(k)):       # "_..." keys are set by the scheduler only
            continue
        if isinstance(v, bool) or (isinstance(v, int) and -10**6 < v < 10**6):
            out[k] = v
        elif isinstance(v, str) and len(v) <= 80 and re.fullmatch(r"[A-Za-z0-9 ._:()/+-]*", v):
            out[k] = v
    return out


class ReportNowIn(BaseModel):
    report: str = Field(..., max_length=40)
    params: Dict[str, Any] = Field(default_factory=dict)
    format: str = Field("pdf", pattern="^(pdf|csv)$")
    recipients: List[str] = Field(..., min_length=1, max_length=30)


class ReportScheduleIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=80)
    report: str = Field(..., max_length=40)
    params: Dict[str, Any] = Field(default_factory=dict)
    format: str = Field("pdf", pattern="^(pdf|csv)$")
    frequency: str = Field("daily", pattern="^(daily|weekly|monthly)$")
    at_time: str = Field("08:00", pattern=TIME_RE)
    weekday: str = Field("mon", pattern="^(mon|tue|wed|thu|fri|sat|sun)$")
    monthday: int = Field(1, ge=1, le=28)
    recipients: Optional[List[str]] = Field(None, max_length=30)   # None: the daily digest recipients
    skip_empty: bool = False
    enabled: bool = True


def _mail_recipients(conn):
    return [dict(r) for r in conn.execute(
        "SELECT address, name, digest FROM mail_recipients ORDER BY lower(address)").fetchall()]


@app.get("/api/v1/reports/email-options")
def report_mail_options(request: Request, user: str = Depends(require_operator)):
    """What this user may e-mail, and to whom (the configured recipients only)."""
    from . import auth, notify as nt, report_jobs
    is_admin = request.state.user.get("role") == "admin"
    with db() as conn:
        cfg = nt.config(conn, with_password=False)
        return {"reports": report_jobs.catalog(auth.user_modules(request.state.user), is_admin),
                "recipients": [{"address": r["address"], "name": r["name"]} for r in _mail_recipients(conn)],
                "mail_ready": bool(cfg["enabled"] and cfg["host"] and cfg["from"]), "can_schedule": is_admin}


@app.post("/api/v1/reports/email")
def report_mail_now(body: ReportNowIn, request: Request, user: str = Depends(require_operator)):
    """Build a report on the server now and queue it, branded, with the PDF or
    CSV attached. Never contains anything sent by the browser."""
    from . import auth, notify as nt, report_jobs
    is_admin = request.state.user.get("role") == "admin"
    if not report_jobs.allowed(body.report, auth.user_modules(request.state.user), is_admin):
        raise HTTPException(403, "Your account cannot send this report.")
    with db() as conn:
        n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'report_emailed'
                              AND occurred_at > now() - interval '1 hour'""", (user,)).fetchone()["n"]
        if n >= REPORT_MAILS_PER_HOUR:
            raise HTTPException(429, f"At most {REPORT_MAILS_PER_HOUR} report e-mails an hour: try again later.")
        cfg = nt.config(conn, with_password=False)
        if not (cfg["enabled"] and cfg["host"] and cfg["from"]):
            raise HTTPException(409, "Mail is not turned on: an admin can do it under Admin > Mail.")
        known = {a.lower() for a in cfg["to"]}
        refused = [a for a in body.recipients if a.lower() not in known]
        if refused:
            raise HTTPException(403, "Reports go only to the recipients set in Admin > Mail. Not on that list: "
                                     + ", ".join(a[:80] for a in refused[:5]))
        params = _report_params(body.params)
        # Recorded before the report is built, so requests sent together count against the hourly limit
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="report_emailed", object_type="report", object_id=body.report,
                  detail={"format": body.format, "to": body.recipients[:30], "params": params}, source_ip=client_ip(request))
        conn.commit()           # counted at once (and kept if the report then fails), so parallel requests see it
        try:
            rows, to = report_jobs.queue(conn, cfg, body.report, params, body.format, body.recipients, user)
        except report_jobs.ReportError as e:
            raise HTTPException(422, str(e))
    return {"ok": True, "rows": rows, "to": to,
            "message": f"Queued for {len(to)} recipient(s); it goes out within a minute."}


class TableMailIn(TableReportIn):
    recipients: List[str] = Field(..., min_length=1, max_length=30)
    page: str = Field("", max_length=80)


@app.post("/api/v1/reports/email-table")
def report_mail_table(body: TableMailIn, request: Request, user: str = Depends(require_operator)):
    """E-mail the table a page shows (or its selected rows) as PDF or CSV, in
    the branded mail. The rows come from the browser, so the mail says so:
    'as shown on <page> by <user>'. Only to the recipients set in Admin >
    Mail, counted in the same hourly limit as other report mails, recorded in
    Activity before it is built."""
    from . import notify as nt, report_jobs
    n = len(body.columns)
    rows, budget = [], TABLE_REPORT_MAX_CHARS
    for r in body.rows:
        out = []
        for v in r[:n]:
            out.append(v if v is None or isinstance(v, (bool, int, float)) else str(v)[:1000])
            budget -= len(str(out[-1] or ""))
        if budget < 0:
            raise HTTPException(413, "This table is too large to e-mail: narrow it with the filters or select fewer rows.")
        rows.append(out + [""] * (n - len(out)))
    title = re.sub(r"[\r\n\t]+", " ", body.title).strip()[:120]
    page = re.sub(r"[^A-Za-z0-9 ,.:/()&+-]", "", body.page or "").strip()[:80] or title
    with db() as conn:
        cnt = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action IN ('report_emailed', 'table_emailed')
                                AND occurred_at > now() - interval '1 hour'""", (user,)).fetchone()["n"]
        if cnt >= REPORT_MAILS_PER_HOUR:
            raise HTTPException(429, f"At most {REPORT_MAILS_PER_HOUR} report e-mails an hour: try again later.")
        cfg = nt.config(conn, with_password=False)
        if not (cfg["enabled"] and cfg["host"] and cfg["from"]):
            raise HTTPException(409, "Mail is not turned on: an admin can do it under Admin > Mail.")
        known = {a.lower() for a in cfg["to"]}
        refused = [a for a in body.recipients if a.lower() not in known]
        if refused:
            raise HTTPException(403, "Reports go only to the recipients set in Admin > Mail. Not on that list: "
                                     + ", ".join(a[:80] for a in refused[:5]))
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="table_emailed", object_type="report", object_id=title[:80],
                  detail={"format": body.format, "rows": len(rows), "to": body.recipients[:30], "page": page}, source_ip=client_ip(request))
        conn.commit()           # counted at once, so parallel requests see it
        filt = re.sub(r"[\r\n\t]+", " ", body.filter).strip()[:300]
        rep_ = {"title": title, "headers": [str(c)[:60] for c in body.columns], "rows": rows, "filter": filt,
                "intro": f"{len(rows)} row{'s' if len(rows) != 1 else ''} as shown on the {page} page of Cyber-Secure by {user}"
                         + (f" (filter: {filt})" if filt else "") + ". The data is attached and summarised below.",
                "severity": "info", "preview": ([str(c)[:60] for c in body.columns][:6], [r[:6] for r in rows])}
        to = report_jobs.recipients_for(cfg, body.recipients)
        subject, text, html, att = report_jobs.compose(conn, cfg, rep_, body.format, user)
        with conn.transaction():
            nt.enqueue(conn, "report", "info", subject, text, html, to, attachment=att)
    return {"ok": True, "rows": len(rows), "to": to, "message": f"Queued for {len(to)} recipient(s); it goes out within a minute."}


def _schedules(conn):
    from . import notify as nt
    cfg = nt.config(conn, with_password=False)
    rows = [dict(r) for r in conn.execute("SELECT * FROM report_schedules ORDER BY builtin DESC, lower(name)").fetchall()]
    from . import report_jobs
    return {"schedules": rows, "recipients": _mail_recipients(conn),
            "mail_ready": bool(cfg["enabled"] and cfg["host"] and cfg["from"]),
            "digest_recipients": cfg["to_digest"],
            "reports": [{"key": k, "title": v[0]} for k, v in report_jobs.REPORTS.items()]}


def _schedule_values(conn, body):
    from . import report_jobs
    if body.report not in report_jobs.REPORTS:
        raise HTTPException(422, "Unknown report.")
    if body.recipients is not None:
        known = {r["address"].lower(): r["address"] for r in _mail_recipients(conn)}
        refused = [a for a in body.recipients if a.lower() not in known]
        if refused:
            raise HTTPException(422, "Reports go only to the recipients set in Admin > Mail. Not on that list: "
                                     + ", ".join(a[:80] for a in refused[:5]))
        if not body.recipients:
            raise HTTPException(422, "Choose at least one recipient, or the daily digest recipients.")
        recips = [known[a.lower()] for a in body.recipients]
    else:
        recips = None
    if any(c in body.name for c in "\r\n"):
        raise HTTPException(422, "The name cannot contain a line break.")
    return (body.name.strip(), body.report, body.format, body.frequency, body.at_time, body.weekday, body.monthday,
            recips, json.dumps(_report_params(body.params)), body.skip_empty, body.enabled)


@app.get("/api/v1/admin/report-schedules")
def report_schedules(admin: str = Depends(require_admin)):
    with db() as conn:
        return jsonable(_schedules(conn))


@app.post("/api/v1/admin/report-schedules")
def report_schedule_add(body: ReportScheduleIn, request: Request, admin: str = Depends(require_admin)):
    with db() as conn:
        with conn.transaction():
            v = _schedule_values(conn, body)
            r = conn.execute(
                """INSERT INTO report_schedules (name, report, format, frequency, at_time, weekday, monthday, recipients,
                                                 params, skip_empty, enabled, created_by)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id""", v + (admin,)).fetchone()
            audit(conn, actor=admin, actor_type="user", action="report_schedule_added", object_type="report_schedule",
                  object_id=str(r["id"]), detail={"name": v[0], "report": v[1], "frequency": v[3], "at": v[4],
                                                  "to": v[7] or "digest recipients"}, source_ip=client_ip(request))
        return jsonable(_schedules(conn))


def _sched_id(sid):
    if not re.fullmatch(r"[0-9a-f-]{36}", sid or ""):
        raise HTTPException(404, "No such schedule.")
    return sid


@app.put("/api/v1/admin/report-schedules/{sid}")
def report_schedule_edit(sid: str, body: ReportScheduleIn, request: Request, admin: str = Depends(require_admin)):
    sid = _sched_id(sid)
    with db() as conn:
        with conn.transaction():
            v = _schedule_values(conn, body)
            r = conn.execute(
                """UPDATE report_schedules SET name=%s, report=%s, format=%s, frequency=%s, at_time=%s, weekday=%s,
                          monthday=%s, recipients=%s, params=%s, skip_empty=%s, enabled=%s, updated_by=%s, updated_at=now()
                    WHERE id=%s RETURNING id""", v + (admin, sid)).fetchone()
            if not r:
                raise HTTPException(404, "No such schedule.")
            audit(conn, actor=admin, actor_type="user", action="report_schedule_changed", object_type="report_schedule",
                  object_id=sid, detail={"name": v[0], "report": v[1], "frequency": v[3], "at": v[4],
                                         "to": v[7] or "digest recipients", "enabled": v[10]}, source_ip=client_ip(request))
        return jsonable(_schedules(conn))


@app.delete("/api/v1/admin/report-schedules/{sid}")
def report_schedule_delete(sid: str, request: Request, admin: str = Depends(require_admin)):
    sid = _sched_id(sid)
    with db() as conn:
        with conn.transaction():
            r = conn.execute("DELETE FROM report_schedules WHERE id=%s RETURNING name", (sid,)).fetchone()
            if not r:
                raise HTTPException(404, "No such schedule.")
            audit(conn, actor=admin, actor_type="user", action="report_schedule_removed", object_type="report_schedule",
                  object_id=sid, detail={"name": r["name"]}, source_ip=client_ip(request))
        return jsonable(_schedules(conn))


@app.post("/api/v1/admin/report-schedules/{sid}/run")
def report_schedule_run(sid: str, request: Request, admin: str = Depends(require_admin)):
    """Send this scheduled report now (within a minute), whatever its schedule."""
    sid = _sched_id(sid)
    with db() as conn:
        with conn.transaction():
            r = conn.execute("UPDATE report_schedules SET run_requested_at = now() WHERE id=%s RETURNING name", (sid,)).fetchone()
            if not r:
                raise HTTPException(404, "No such schedule.")
            audit(conn, actor=admin, actor_type="user", action="report_schedule_run", object_type="report_schedule",
                  object_id=sid, detail={"name": r["name"]}, source_ip=client_ip(request))
        return jsonable(_schedules(conn))
