"""Changes: patch jobs, software jobs and VMware actions.

Split out of main.py in r90; the code is unchanged."""

import os
from datetime import datetime, timezone
from fastapi import Body, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional

from .core import (_agent_update_ok, _allowed_kinds, _change_ok, _removal_ok, app, audit, client_ip, db,
                   require_admin, require_operator, require_viewer)


# ---------------------------------------------------------------------------
# Changes: patch jobs and VMware actions
# ---------------------------------------------------------------------------


class ChangeIn(BaseModel):
    kind: str
    title: Optional[str] = Field(default=None, max_length=200)
    reason: str = Field(..., max_length=2000)
    targets: List[Any]
    params: Dict[str, Any] = Field(default_factory=dict)
    run_after: Optional[str] = None
    run_before: Optional[str] = None
    max_parallel: int = 5


@app.post("/api/v1/changes/preview")
def preview_change(body: ChangeIn, request: Request, user: str = Depends(require_operator)):
    """What a change would do, before it is scheduled: for patching, the
    exact packages per server."""
    from . import changes as ch
    from .worker import choose_fixed_versions
    _change_ok(request, body.kind)
    _agent_update_ok(request, body.kind)
    _removal_ok(request, body.kind, body.params)
    with db() as conn:
        try:
            targets, params, ra, rb, mp = ch.validate(conn, body.kind, body.targets, body.params,
                                                      body.run_after, body.run_before, body.max_parallel)
        except ch.Invalid as e:
            raise HTTPException(status_code=422, detail=str(e))
        out = []
        if body.kind == "patch":
            from .worker import _linux_security_updates
            for t in targets:
                pm = conn.execute("SELECT pkg_manager::text AS pkg_manager FROM hosts WHERE id=%s", (t["host_id"],)).fetchone()
                pmn = (pm or {}).get("pkg_manager")
                lu = None
                if pmn == "wua" and params["mode"] != "advisories":
                    # Windows: what Windows Update reports missing against WSUS (the agent searches again before installing)
                    wu = conn.execute("SELECT kb, title FROM windows_updates WHERE host_id=%s ORDER BY kb", (t["host_id"],)).fetchall()
                    out.append({"label": t["label"], "host_id": t["host_id"], "linked_vm": bool(t.get("vm_moref")),
                                "advisories": [], "source": "WSUS",
                                "packages": [{"name": w["kb"] or (w["title"] or "update")[:60], "version": ""} for w in wu]})
                    continue
                if params["mode"] != "advisories":
                    lu = _linux_security_updates(conn, t["host_id"])
                if lu is not None:
                    rows, source = lu, "package manager"
                else:
                    sql = """SELECT package_name, fixed_evr, advisory_id FROM host_applicability
                              WHERE host_id=%s AND state='affected' AND fixed_evr IS NOT NULL"""
                    args = [t["host_id"]]
                    if params["mode"] == "advisories":
                        sql += " AND advisory_id = ANY(%s)"
                        args.append(params["advisories"])
                    rows, source = conn.execute(sql, args).fetchall(), "advisories"
                out.append({"label": t["label"], "host_id": t["host_id"],
                            "linked_vm": bool(t.get("vm_moref")), "source": source,
                            "advisories": sorted({r["advisory_id"] for r in rows if r.get("advisory_id")})
                                          if source == "advisories" else sorted({r["advisory"] for r in rows if r.get("advisory")}),
                            "packages": choose_fixed_versions(rows, pmn)})
        else:
            out = [{"label": t["label"], "vcenter": t["vcenter"], "vm_moref": t["vm_moref"]}
                   for t in targets]
    return {"kind": body.kind, "params": params, "targets": out,
            "run_after": ra, "run_before": rb, "max_parallel": mp}


@app.post("/api/v1/changes")
def create_change(body: ChangeIn, request: Request, user: str = Depends(require_operator)):
    from . import changes as ch
    _change_ok(request, body.kind)
    _agent_update_ok(request, body.kind)
    _removal_ok(request, body.kind, body.params)
    with db() as conn:
        try:
            targets, params, ra, rb, mp = ch.validate(conn, body.kind, body.targets, body.params,
                                                      body.run_after, body.run_before, body.max_parallel)
            with conn.transaction():
                cid, number = ch.create(conn, body.kind, body.title, body.reason, targets, params,
                                        ra, rb, mp, user, request.state.user["role"])
                audit(conn, actor=user, actor_type="user", action="change_created",
                      object_type="change", object_id=cid,
                      detail={"ref": ch.ref(number), "kind": body.kind, "targets": len(targets),
                              "reason": body.reason[:300]},
                      source_ip=client_ip(request))
        except ch.Invalid as e:
            raise HTTPException(status_code=422, detail=str(e))
    return {"id": cid, "ref": ch.ref(number), "number": number}


@app.get("/api/v1/changes")
def list_changes(request: Request, state: Optional[str] = None, limit: int = 100,
                 user: str = Depends(require_viewer)):
    limit = max(1, min(limit, 500))
    kinds = _allowed_kinds(request)
    with db() as conn:
        rows = conn.execute(
            """SELECT c.id, c.number, c.kind::text AS kind, c.title, c.reason, c.state::text AS state,
                      c.requested_by, c.requested_at, c.run_after, c.run_before, c.started_at,
                      c.finished_at, c.max_parallel, c.summary,
                      count(t.*) AS targets,
                      count(t.*) FILTER (WHERE t.state IN ('done','done_with_warnings'))   AS done,
                      count(t.*) FILTER (WHERE t.state='failed') AS failed,
                      count(t.*) FILTER (WHERE t.state NOT IN
                            ('queued','done','done_with_warnings','failed','skipped','cancelled')) AS in_progress
                 FROM changes c LEFT JOIN change_targets t ON t.change_id = c.id
                WHERE (%s::text IS NULL OR c.state::text = %s::text) AND c.kind::text = ANY(%s)
                GROUP BY c.id ORDER BY c.requested_at DESC LIMIT %s::int""",
            (state, state, kinds, limit)).fetchall()
    return {"count": len(rows), "changes": rows}


@app.get("/api/v1/changes/{change_id}")
def get_change(change_id: str, request: Request, user: str = Depends(require_viewer)):
    with db() as conn:
        c = conn.execute(
            """SELECT id, number, kind::text AS kind, title, reason, state::text AS state, params,
                      requested_by, requested_role::text AS requested_role, requested_at,
                      approval_required, approved_by, approved_at, run_after, run_before,
                      max_parallel, started_at, finished_at, cancel_requested, summary
                 FROM changes WHERE id::text=%s""", (change_id,)).fetchone()
        if not c:
            raise HTTPException(status_code=404, detail="No such change.")
        _change_ok(request, c["kind"])
        targets = conn.execute(
            """SELECT target_key, host_id, vcenter, vm_moref, label, state, step_started_at,
                      updated_at, snapshot_moref, detail, error
                 FROM change_targets WHERE change_id=%s ORDER BY label""", (c["id"],)).fetchall()
        events = conn.execute(
            """SELECT id, target_key, at, actor, event, ok, message
                 FROM change_events WHERE change_id=%s ORDER BY id""", (c["id"],)).fetchall()
    return {"change": c, "targets": targets, "events": events}


@app.post("/api/v1/changes/{change_id}/cancel")
def cancel_change(change_id: str, request: Request, user: str = Depends(require_operator)):
    """Stops a change. Servers not yet started are cancelled; a server part way
    through finishes its current step and stops before installing."""
    from . import changes as ch
    with db() as conn:
        with conn.transaction():
            c = conn.execute("SELECT id, number, state::text AS state, kind::text AS kind FROM changes "
                             "WHERE id::text=%s FOR UPDATE", (change_id,)).fetchone()
            if not c:
                raise HTTPException(status_code=404, detail="No such change.")
            _change_ok(request, c["kind"])
            if c["state"] in ("scheduled", "pending_approval"):
                conn.execute("UPDATE changes SET state='cancelled', finished_at=now() WHERE id=%s", (c["id"],))
                conn.execute("UPDATE change_targets SET state='cancelled' WHERE change_id=%s", (c["id"],))
            elif c["state"] == "running":
                conn.execute("UPDATE changes SET cancel_requested=TRUE WHERE id=%s", (c["id"],))
            else:
                raise HTTPException(status_code=409, detail=f"A {c['state']} change cannot be cancelled.")
            ch.event(conn, c["id"], None, user, "cancel_requested", None,
                     f"{ch.ref(c['number'])} cancelled by {user}")
            audit(conn, actor=user, actor_type="user", action="change_cancelled",
                  object_type="change", object_id=str(c["id"]), detail={"ref": ch.ref(c["number"])},
                  source_ip=client_ip(request))
    return {"ok": True}


@app.post("/api/v1/changes/{change_id}/decide")
def decide_change(change_id: str, request: Request, approve: bool = Body(..., embed=True),
                  note: Optional[str] = Body(default=None, embed=True),
                  user: str = Depends(require_admin)):
    """Only used when REQUIRE_APPROVAL is switched on."""
    from . import changes as ch
    with db() as conn:
        with conn.transaction():
            c = conn.execute("""SELECT id, number, requested_by, state::text AS state, params FROM changes
                                 WHERE id::text=%s FOR UPDATE""", (change_id,)).fetchone()
            if not c or c["state"] != "pending_approval":
                raise HTTPException(status_code=409, detail="This change is not waiting for approval.")
            at = (c["params"] or {}).get("reboot_at") if isinstance(c["params"], dict) else None
            if approve and at:
                try:
                    past = datetime.fromisoformat(str(at)) < datetime.now(timezone.utc)
                except ValueError:
                    past = False
                if past:
                    # Approved now, every server would restart the moment it installs: in working hours, unplanned
                    raise HTTPException(409, "This job's restart time has already passed, so its servers would restart straight "
                                             "after installing. Reject it and book it again with a new restart time.")
            if c["requested_by"] == user:
                raise HTTPException(status_code=403, detail="Nobody approves their own change.")
            conn.execute("""UPDATE changes SET state=%s, approved_by=%s, approved_at=now(),
                                   decision_note=%s WHERE id=%s""",
                         ("scheduled" if approve else "rejected", user, (note or "")[:1000], c["id"]))
            ch.event(conn, c["id"], None, user, "approved" if approve else "rejected", approve, note)
    return {"ok": True}


@app.get("/api/v1/worker/status")
def worker_status(user: str = Depends(require_viewer)):
    with db() as conn:
        beats = conn.execute("""SELECT name, beat_at, started_at, detail,
                                       extract(epoch FROM now() - beat_at)::int AS seconds_ago
                                  FROM worker_heartbeat ORDER BY name""").fetchall()
    # Each thread reports at its own pace (hardening only hourly), so each is
    # judged against its own interval. "alive" is the change runner alone:
    # that is what decides whether scheduled changes start.
    limit = {"changes": 90, "enrichment": 180, "vmware_live": 180, "mail": 300, "hardening": 2 * 3600 + 300,
             "feeds": 3 * 3600, "impact": 3600, "insights": 1800, "antivirus": 1800,
             "nessus": 2 * 3600 + 300}
    for b in beats:
        b["stale"] = b["seconds_ago"] > limit.get(b["name"], 600)
    ch = next((b for b in beats if b["name"] == "changes"), None)
    alive = bool(ch) and not ch["stale"]
    return {"alive": alive, "threads": beats, "stale": [b["name"] for b in beats if b["stale"]]}


@app.get("/api/v1/admin/vmware/writers")
def vmware_writers(user: str = Depends(require_viewer)):
    """Which vCenters have a write account, so the console only offers
    actions that can actually be carried out."""
    from . import vmware
    import glob as _g
    names = [v["name"] for v in vmware.load_vcenters()]
    have = {os.path.basename(f)[:-len(vmware.WRITE_SUFFIX) - 4]
            for f in _g.glob(os.path.join(vmware.CONFIG_DIR, "*" + vmware.WRITE_SUFFIX + ".env"))}
    return {"vcenters": [{"name": n, "can_write": n in have} for n in names]}


@app.get("/api/v1/admin/vmware/vm/{vcenter}/{moref}")
def vmware_vm_detail(vcenter: str, moref: str, user: str = Depends(require_viewer)):
    with db() as conn:
        row = conn.execute("SELECT * FROM v_vm_map WHERE vcenter=%s AND moref=%s",
                           (vcenter, moref)).fetchone()
        snaps = conn.execute("SELECT snapshots FROM vm_inventory WHERE vcenter=%s AND moref=%s",
                             (vcenter, moref)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="No such VM.")
    return {"vm": row, "snapshots": (snaps or {}).get("snapshots") or []}
