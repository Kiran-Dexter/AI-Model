"""The AI-01 assistant: read-only questions, CSV export, e-mail on confirmation.

Split out of main.py in r90; the code is unchanged."""

import re
from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional

from .core import (EMAIL_RE, app, audit, client_ip, db, jsonable, log, require_operator)


# ---------------------------------------------------------------------------
# The assistant: read-only questions, CSV export, e-mail on confirmation
# ---------------------------------------------------------------------------


class ChatContext(BaseModel):
    tool: str = Field(..., max_length=40)
    args: Dict[str, Any] = Field(default_factory=dict)


class ChatIn(BaseModel):
    question: str = Field(..., min_length=1, max_length=400)
    context: Optional[ChatContext] = None


@app.post("/api/v1/admin/chat")
def chat(request: Request, body: ChatIn, admin: str = Depends(require_operator)):
    """Answer a question from prepared read-only queries.

    The model only selects which query to run; the figures come from the
    database and the rows are returned so the operator can check them.
    Nothing here can change a server, and nothing here sends mail: an e-mail
    is returned as a draft for the operator to send.
    """
    from . import chat as chatmod
    from . import llm

    with db() as conn:
        asked = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'chat_query'
                                  AND occurred_at > now() - interval '10 minutes'""", (admin,)).fetchone()["n"]
    if asked >= CHAT_QUESTIONS_PER_10MIN:
        raise HTTPException(429, f"At most {CHAT_QUESTIONS_PER_10MIN} questions in 10 minutes: try again shortly.")
    use_model = None
    try:
        if llm.configured():
            # A person is waiting: AI-01 gets up to 8 s to free a slot, and background work stands aside
            use_model = lambda messages, schema=None: llm.choose(messages, max_tokens=100, schema=schema, wait=8)  # noqa: E731
            with db() as conn:
                llm.mark_interactive(conn)
    except Exception:  # noqa: BLE001
        use_model = None

    from . import auth
    ctx = body.context.model_dump() if body.context else None
    modules = auth.user_modules(request.state.user)
    try:
        # No database connection is held while AI-01 chooses the query
        res = chatmod.ask_db(db, body.question, ask_model=use_model, requested_by=admin, context=ctx,
                             modules=modules)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    with db() as conn:
        if res.get("action") == "email":
            res["email"]["allowed"] = _assistant_mail_policy(conn)["describe"]
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="chat_query",
                  detail={"question": body.question[:300], "tool": res.get("tool"), "args": res.get("args"),
                          "how": res.get("how"), "action": res.get("action"),
                          "rows": len(res.get("rows") or [])},
                  source_ip=client_ip(request))
    return jsonable(res)


CHAT_QUESTIONS_PER_10MIN = 60


CHAT_INSIGHTS_PER_10MIN = 30


class ChatInsightIn(BaseModel):
    question: str = Field(..., min_length=1, max_length=400)
    tool: Optional[str] = Field(default=None, max_length=40)
    args: Dict[str, Any] = Field(default_factory=dict)


@app.post("/api/v1/admin/chat/insight")
def chat_insight(request: Request, body: ChatInsightIn, admin: str = Depends(require_operator)):
    """AI-01 answers in its own words, after the rows are on screen. From the
    rows of the query just shown (every number and server name checked against
    them before it is shown), or, when no query fits, a general answer that is
    labelled as not coming from PATCH-01's data. Read-only."""
    from . import auth, chat as chatmod, llm
    if not llm.configured():
        return {"text": None, "kind": "off", "why": "AI-01 is not set up."}
    with db() as conn:
        n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'chat_insight'
                              AND occurred_at > now() - interval '10 minutes'""", (admin,)).fetchone()["n"]
    if n >= CHAT_INSIGHTS_PER_10MIN:
        return {"text": None, "kind": "data", "why": "AI-01 has answered many questions from you in the last 10 minutes: the table is the answer for now."}

    def before_ai():                              # only once the request is valid: a person is waiting
        with db() as conn:
            llm.mark_interactive(conn)
    ask_text = lambda messages, n: llm.choose(messages, max_tokens=n, timeout=90, temperature=0.3, wait=10)  # noqa: E731
    try:
        out = chatmod.insight(db, body.question, body.tool, body.args, auth.user_modules(request.state.user), ask_text,
                              before_ai=before_ai)
    except ValueError as e:
        raise HTTPException(422, str(e))
    except PermissionError:
        raise HTTPException(403, "Your account does not have access to this information.")
    except llm.LLMBusy:
        raise HTTPException(429, "AI-01 is busy with another question. Try again in a moment.")
    except llm.LLMUnavailable as e:
        log.warning("chat insight: %s", e)
        return {"text": None, "kind": "off", "why": "AI-01 did not answer."}
    with db() as conn, conn.transaction():
        audit(conn, actor=admin, actor_type="user", action="chat_insight",
              detail={"question": body.question[:300], "tool": body.tool, "kind": out.get("kind"),
                      "shown": bool(out.get("text"))}, source_ip=client_ip(request))
    return out


class AssistantQuery(BaseModel):
    tool: str = Field(..., max_length=40)
    args: Dict[str, Any] = Field(default_factory=dict)


@app.post("/api/v1/assistant/export")
def assistant_export(request: Request, body: AssistantQuery, user: str = Depends(require_operator)):
    """The same validated query as an answer, re-run on the server with up to
    5000 rows, as CSV. Cells that a spreadsheet would run as a formula are
    neutralised."""
    from fastapi.responses import Response
    from . import auth, chat as chatmod
    if not chatmod.tool_allowed(body.tool, auth.user_modules(request.state.user)):
        raise HTTPException(403, "Your account does not have access to this information.")
    with db() as conn:
        try:
            args, rows, cols, missing = chatmod.run_tool(conn, body.tool, body.args, chatmod.EXPORT_ROWS,
                                                         auth.user_modules(request.state.user))
        except ValueError:
            raise HTTPException(422, "Unknown query.")
        if missing:
            raise HTTPException(422, "The query needs: " + ", ".join(missing))
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="assistant_export",
                  detail={"tool": body.tool, "args": args, "rows": len(rows)}, source_ip=client_ip(request))
    from . import exports as ex
    with db() as conn:
        company = ex.company_name(conn)
    cols = cols or ["result"]
    m = ex.meta("Assistant: " + chatmod.title_for(body.tool, args), user, chatmod.title_for(body.tool, args), len(rows), company)
    data = ex.csv_text(m, [c.replace("_", " ") for c in cols],
                       [[r.get(c) for c in cols] for r in rows]).encode("utf-8")
    name = ex.file_name(chatmod.file_name(body.tool, args), "csv")
    return Response(data, media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{name}"',
                             "X-Rows": str(len(rows)), "Cache-Control": "no-store"})


ASSISTANT_MAIL_PER_HOUR = 10


def _assistant_mail_policy(conn):
    """Who the assistant may mail: the configured recipients, and anyone at
    the same mail domains as them or as the sender. Worked out from the mail
    settings each time, never stored."""
    recs = [r["address"].strip().lower() for r in conn.execute("SELECT address FROM mail_recipients").fetchall()]
    s = conn.execute("SELECT from_addr FROM mail_settings WHERE id = 1").fetchone() or {}
    domains = {a.split("@")[-1] for a in recs if "@" in a}
    if s.get("from_addr") and "@" in s["from_addr"]:
        domains.add(s["from_addr"].strip().lower().split("@")[-1].strip(">"))
    return {"addresses": set(recs), "domains": domains,
            "describe": {"recipients": sorted(recs), "domains": sorted(domains)}}


class AssistantMailIn(BaseModel):
    tool: str = Field(..., max_length=40)
    args: Dict[str, Any] = Field(default_factory=dict)
    to: List[str] = Field(..., min_length=1, max_length=20)
    cc: List[str] = Field(default_factory=list, max_length=20)
    subject: str = Field(..., min_length=3, max_length=200)
    body: str = Field(..., min_length=1, max_length=10000)
    attach: bool = True


@app.post("/api/v1/assistant/email")
def assistant_email(request: Request, body: AssistantMailIn, user: str = Depends(require_operator)):
    """Send an answer by mail, after the operator pressed Send.

    The data is re-read here from the same validated query: nothing the
    browser sends back is put in the mail except the text the operator wrote.
    Recipients must be allowed by the mail policy above. At most ten mails an
    hour per user, every one in the audit log."""
    from . import auth, chat as chatmod
    from . import notify as nt
    if not chatmod.tool_allowed(body.tool, auth.user_modules(request.state.user)):
        raise HTTPException(403, "Your account does not have access to this information.")
    if any(c in body.subject for c in "\r\n"):
        raise HTTPException(422, "The subject cannot contain a line break.")
    to = [a.strip() for a in body.to if a.strip()]
    cc = [a.strip() for a in body.cc if a.strip() and a.strip().lower() not in {x.lower() for x in to}]
    bad = [a for a in to + cc if not re.match(EMAIL_RE, a)]
    if bad:
        raise HTTPException(422, "Not e-mail addresses: " + ", ".join(bad))
    with db() as conn:
        pol = _assistant_mail_policy(conn)
        refused = [a for a in to + cc if a.lower() not in pol["addresses"] and a.lower().split("@")[-1] not in pol["domains"]]
        if refused:
            raise HTTPException(403, "The assistant may only mail the configured recipients or addresses at "
                                     + (", ".join(sorted(pol["domains"])) or "your mail domain")
                                     + ". Not allowed: " + ", ".join(refused))
        sent_recently = conn.execute(
            """SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'assistant_email'
                AND occurred_at > now() - interval '1 hour'""", (user,)).fetchone()["n"]
        if sent_recently >= ASSISTANT_MAIL_PER_HOUR:
            raise HTTPException(429, f"At most {ASSISTANT_MAIL_PER_HOUR} assistant e-mails an hour: try again later.")
        cfg = nt.config(conn)
        if not (cfg["host"] and cfg["from"]):
            raise HTTPException(409, "Mail is not set up yet: an admin can do it under Admin, Mail.")
        try:
            args, rows, cols, missing = chatmod.run_tool(conn, body.tool, body.args, chatmod.EXPORT_ROWS,
                                                         auth.user_modules(request.state.user))
        except ValueError:
            raise HTTPException(422, "Unknown query.")
        if missing:
            raise HTTPException(422, "The query needs: " + ", ".join(missing))
        title = chatmod.title_for(body.tool, args)
        shown = rows[:25]
        blocks = [("text", body.body)]
        if shown:
            blocks.append(("table", [c.replace("_", " ") for c in cols],
                           [[chatmod._cell(r.get(c)).lstrip("'") for c in cols] for r in shown]))
            if len(rows) > len(shown):
                blocks.append(("p", f"The first {len(shown)} of {len(rows)} rows; all are in the attached file."))
        text, html = nt.render(cfg, body.subject, "info", "", blocks, link=None, label="Cyber-Secure assistant",
                               greeting=False)            # the editable draft carries its own greeting
        files = []
        if body.attach and rows:
            from . import exports as ex
            m = ex.meta("Assistant: " + title, user, title, len(rows), ex.company_name(conn))
            files.append((ex.file_name(chatmod.file_name(body.tool, args), "csv"),
                          ex.csv_text(m, [c.replace("_", " ") for c in cols],
                                      [[r.get(c) for c in cols] for r in rows]).encode("utf-8"), "text/csv"))
        state, err = "sent", None
        try:
            nt.send(cfg, to, body.subject, text, html, cc=cc, attachments=files)
        except Exception as e:  # noqa: BLE001 - reported back and recorded
            state, err = "failed", str(e)
        with conn.transaction():
            conn.execute(
                """INSERT INTO notifications (category, severity, subject, body_text, body_html, recipients, state,
                                              attempts, sent_at, last_error, event_keys)
                   VALUES ('assistant', 'info', %s, %s, %s, %s, %s, 1, CASE WHEN %s THEN now() END, %s, %s)""",
                (body.subject, text, html, to + cc, state, state == "sent", err, [f"assistant:{body.tool}"]))
            audit(conn, actor=user, actor_type="user", action="assistant_email",
                  detail={"tool": body.tool, "args": args, "title": title, "to": to, "cc": cc,
                          "subject": body.subject, "rows": len(rows), "attached": bool(files),
                          "state": state, "error": err}, source_ip=client_ip(request))
    if err:
        raise HTTPException(502, err)
    return {"ok": True, "to": to, "cc": cc, "rows": len(rows), "attached": bool(files)}
