"""CVE assessments of outside lists, and the CVE news feeds.

Split out of main.py in r90; the code is unchanged."""

import json
import os
import re
import time
from fastapi import Depends, File, Form, HTTPException, Request, Response, UploadFile
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field
from typing import List, Optional

from .core import (_audit, _change_ok, app, audit, client_ip, db, jsonable, mfa_exempt, require_admin,
                   require_operator, require_viewer)


# ---------------------------------------------------------------------------
# CVE assessments: evaluate a list that arrived from outside
# ---------------------------------------------------------------------------


MAX_UPLOAD_BYTES = 2 * 1024 * 1024


@app.post("/api/v1/admin/assessments")
async def create_assessment(request: Request,
                            name: str = Form(...),
                            source: Optional[str] = Form(default=None),
                            note: Optional[str] = Form(default=None),
                            text: Optional[str] = Form(default=None),
                            file: Optional[UploadFile] = File(default=None),
                            admin: str = Depends(require_operator)):
    """Take a CVE list, as an uploaded file or pasted text, and evaluate it."""
    from . import assess

    body = text or ""
    if file is not None:
        raw = await file.read(MAX_UPLOAD_BYTES + 1)
        if len(raw) > MAX_UPLOAD_BYTES:
            raise HTTPException(status_code=413,
                                detail=f"file larger than {MAX_UPLOAD_BYTES // 1024 // 1024} MB")
        # Any text format: a pasted list, CSV, or an exported bulletin
        body += "\n" + raw.decode("utf-8", errors="replace")

    cves, rejected = assess.parse_cve_list(body)
    if not cves:
        raise HTTPException(
            status_code=422,
            detail="No CVE identifiers found. Expected text containing CVE-YYYY-NNNN. "
                   "Spreadsheets must be saved as CSV or the list pasted in.")

    name = (name or "").strip()[:200] or "Untitled assessment"
    with db() as conn:
        with conn.transaction():
            items, in_scope = assess.evaluate(conn, cves)
            aid = assess.save(conn, name, (source or "").strip()[:100] or None,
                              (note or "").strip()[:2000] or None, admin,
                              cves, rejected, items, in_scope)
            # The worker now looks each CVE up in NVD, matches what it affects
            # against the inventory, and writes the AI brief
            conn.execute("""UPDATE cve_assessments SET state='enriching', progress=0,
                                   progress_total=%s WHERE id=%s""", (len(cves), aid))
            audit(conn, actor=admin, actor_type="user", action="cve_assessment",
                  object_type="assessment", object_id=aid,
                  detail={"name": name, "cves": len(cves),
                          **assess.summarise(items)},
                  source_ip=client_ip(request))
    return {"id": aid, "name": name, "cve_count": len(cves), "rejected": rejected,
            "hosts_in_scope": in_scope, "summary": assess.summarise(items),
            "items": items, "state": "enriching"}


@app.get("/api/v1/admin/assessments")
def list_assessments(admin: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT a.id, a.name, a.source, a.created_by, a.created_at, a.cve_count,
                      a.hosts_in_scope, a.state, a.progress, a.progress_total,
                      count(*) FILTER (WHERE i.status='affected')       AS affected,
                      count(*) FILTER (WHERE i.status='pending_reboot') AS pending_reboot,
                      count(*) FILTER (WHERE i.status='patched')        AS patched,
                      count(*) FILTER (WHERE i.status='unknown')        AS unknown,
                      count(*) FILTER (WHERE i.status='not_applicable') AS not_applicable,
                      count(*) FILTER (WHERE i.status='no_vendor_data') AS no_vendor_data,
                      count(*) FILTER (WHERE i.kev AND i.status='affected') AS exploited_affected,
                      count(*) FILTER (WHERE i.exposure IN ('affected','potentially_affected')) AS exposed
                 FROM cve_assessments a
                 LEFT JOIN cve_assessment_items i ON i.assessment_id = a.id
                GROUP BY a.id ORDER BY a.created_at DESC LIMIT 200""").fetchall()
    return {"count": len(rows), "assessments": rows}


@app.get("/api/v1/admin/assessments/{assessment_id}")
def get_assessment(assessment_id: str, admin: str = Depends(require_viewer)):
    with db() as conn:
        head = conn.execute("SELECT * FROM cve_assessments WHERE id=%s",
                            (assessment_id,)).fetchone()
        if not head:
            raise HTTPException(status_code=404, detail="assessment not found")
        items = conn.execute(
            """SELECT * FROM cve_assessment_items WHERE assessment_id=%s
                ORDER BY CASE coalesce(exposure, status)
                           WHEN 'affected' THEN 1 WHEN 'potentially_affected' THEN 2
                           WHEN 'pending_reboot' THEN 3 WHEN 'unknown' THEN 4
                           WHEN 'not_tracked' THEN 5 WHEN 'no_vendor_data' THEN 6
                           WHEN 'not_found' THEN 6 WHEN 'patched' THEN 7 ELSE 8 END,
                         kev DESC, cvss_score DESC NULLS LAST, cve_id""",
            (assessment_id,)).fetchall()
    return {"assessment": head, "items": items}


@app.get("/api/v1/admin/assessments/{assessment_id}/export.csv",
         response_class=PlainTextResponse)
def export_assessment(assessment_id: str, request: Request, admin: str = Depends(require_viewer)):
    """CSV to send back to whoever asked the question, with the branded heading."""
    from . import exports as ex
    with db() as conn:
        company = ex.company_name(conn)
        head = conn.execute("SELECT name, created_at FROM cve_assessments WHERE id=%s",
                            (assessment_id,)).fetchone()
        if not head:
            raise HTTPException(status_code=404, detail="assessment not found")
        items = conn.execute(
            """SELECT cve_id, status, exposure, cvss_score, cvss_severity, cvss_vector, kev, epss,
                      attack_class, published, description, product_classes, products,
                      inventory_matches, affected, pending_reboot, patched, unknown,
                      advisories, packages, affected_hosts, ai_summary, platforms, excluded
                 FROM cve_assessment_items WHERE assessment_id=%s ORDER BY cve_id""",
            (assessment_id,)).fetchall()
    out_rows = []
    headers = (["cve", "exposure", "package_verdict", "cvss", "severity", "vector",
                "exploited_in_wild", "epss", "attack_type", "published", "affects",
                "affected_products", "platforms", "found_in_inventory", "ruled_out", "servers_affected",
                "servers_awaiting_reboot", "servers_patched", "advisories", "packages",
                "affected_server_names", "description", "ai_summary"])
    for i in items:
        names = ";".join(h.get("hostname", "") for h in (i["affected_hosts"] or [])
                         if h.get("state") == "affected")
        prods = ";".join(f"{p.get('vendor')} {p.get('product')}" for p in (i["products"] or []))
        found = ";".join(f"{m.get('where') or m.get('kind')}: {m.get('name') or '-'}"
                         + (f" [{m['ip']}]" if m.get("ip") else "") + (f" {m['os']}" if m.get("os") else "")
                         + f" ({m.get('certainty')})" for m in (i["inventory_matches"] or [])
                         if m.get("certainty") != "not_tracked")
        ex_ = i.get("excluded") or {}
        ruled_out = ";".join(f"{e.get('name')}: {e.get('reason')}" for e in (ex_.get("machines") or [])[:30])
        out_rows.append([i["cve_id"], i["exposure"] or "", i["status"], i["cvss_score"] or "",
                    i["cvss_severity"] or "", i["cvss_vector"] or "",
                    "yes" if i["kev"] else "no",
                    f"{float(i['epss']):.4f}" if i["epss"] is not None else "",
                    i["attack_class"] or "", (i["published"].date().isoformat() if i["published"] else ""),
                    ";".join(i["product_classes"] or []), prods, ";".join(i.get("platforms") or []), found, ruled_out,
                    i["affected"], i["pending_reboot"], i["patched"],
                    ";".join(i["advisories"] or []), ";".join(i["packages"] or []), names,
                    (i["description"] or "").replace("\n", " "),
                    (i["ai_summary"] or "").replace("\n", " ")])
    fn = re.sub(r"[^A-Za-z0-9_-]+", "-", head["name"])[:60] or "assessment"
    m = ex.meta("CVE assessment: " + head["name"][:80], admin, "assessment " + head["name"][:80], len(out_rows), company)
    return PlainTextResponse(
        ex.csv_text(m, headers, out_rows), media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{ex.file_name(fn, "csv")}"'})


@app.delete("/api/v1/admin/assessments/{assessment_id}")
def delete_assessment(assessment_id: str, request: Request,
                      admin: str = Depends(require_operator)):
    with db() as conn:
        with conn.transaction():
            row = conn.execute("DELETE FROM cve_assessments WHERE id=%s RETURNING name",
                               (assessment_id,)).fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="assessment not found")
            audit(conn, actor=admin, actor_type="user", action="delete_assessment",
                  object_type="assessment", object_id=assessment_id,
                  detail={"name": row["name"]}, source_ip=client_ip(request))
    return {"ok": True}


# ---------------------------------------------------------------------------
# CVE news feeds: NIST, Microsoft, Red Hat
# ---------------------------------------------------------------------------


@app.get("/api/v1/servers")
def servers_list(request: Request, page: int = 1, q: Optional[str] = None, os: Optional[str] = None,
                 group: Optional[str] = None, version: Optional[str] = None, agent: Optional[str] = None,
                 patch: Optional[str] = None, sort: str = "agent", view: str = "list",
                 user: str = Depends(require_viewer)):
    """Servers and their agents in one list: 20 a page, filtered here, with
    the values each filter offers and AI-01's latest analysis. view=groups:
    every matching server, in its patch group."""
    from . import servers as sv, insights
    f = sv.clean_filters(q, os, group, version, agent, patch)
    if view == "groups":
        with db() as conn:
            res = sv.grouped(conn, f, sort=sort if sort in sv.SORTS else "name")
            res["facets"] = sv.facets(conn)
        res["filters"] = f
        return jsonable(res)
    with db() as conn:
        res = sv.page(conn, f, page, sort=sort if sort in sv.SORTS else "agent")
        res["facets"] = sv.facets(conn)
        try:
            res["insight"] = insights.latest(conn, "servers")
        except Exception:  # noqa: BLE001 - schema 024 not applied yet
            conn.rollback()
            res["insight"] = None
    res["filters"] = f
    return jsonable(res)


@app.get("/api/v1/servers/{host_id}/pending")
def server_pending(host_id: str, user: str = Depends(require_viewer)):
    """The patches a job would install on this server now (CVEs: Vulnerabilities page)."""
    from . import servers as sv
    if not re.fullmatch(r"[0-9a-f-]{36}", host_id or ""):
        raise HTTPException(404, "No such server.")
    with db() as conn:
        out = sv.pending(conn, host_id)
    if out is None:
        raise HTTPException(404, "No such server.")
    return jsonable(out)


HOST_METRICS_FILE = os.environ.get("HOST_METRICS_FILE", "/host-metrics/host.json")


_HOST_METRICS = {"mtime": None, "data": None}


@app.get("/api/v1/system/health")
def system_health(request: Request, response: Response):
    """PATCH-01's own CPU, memory and network (patch01-metrics.service on the
    host), for the header gauges. A background request: it does not extend
    the session, so an open console still times out when nobody uses it."""
    from . import auth, mfa
    header = request.headers.get("authorization") or ""
    if not header.lower().startswith("bearer "):
        raise HTTPException(401, "Your session has ended. Sign in again.")
    with db() as conn:
        u = auth.session_user(conn, header[7:].strip(), extend=False)
    if not u:
        raise HTTPException(401, "Your session has ended. Sign in again.")
    if u.get("must_change_password") or (mfa.REQUIRE_2FA and not u.get("totp_enabled") and u["username"] not in mfa_exempt()):
        raise HTTPException(403, "Not available until the sign-in is complete.")
    response.headers["Cache-Control"] = "no-store"
    import math
    import stat as _stat
    def num(v, lo=0.0, hi=1e15):
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
            return None
        return min(hi, max(lo, float(v)))
    def bad_const(c):
        raise ValueError("not a number: " + c)
    try:
        # Never follow a link and never wait on a pipe: only a regular file is read
        fd = os.open(HOST_METRICS_FILE, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        try:
            st = os.fstat(fd)
            if not _stat.S_ISREG(st.st_mode) or st.st_size > 256 * 1024:
                raise ValueError("not a plain snapshot file")
            key = (st.st_ino, st.st_mtime_ns, st.st_size)
            if _HOST_METRICS["mtime"] != key:
                with os.fdopen(fd, "rb", closefd=False) as fh:
                    raw = json.loads(fh.read(256 * 1024), parse_constant=bad_const)
                if not isinstance(raw, dict) or num(raw.get("ts"), 1, 4e9) is None:
                    raise ValueError("not a snapshot")
                obj = lambda v: v if isinstance(v, dict) else {}
                cpu, mem, net, col = obj(raw.get("cpu")), obj(raw.get("mem")), obj(raw.get("net")), obj(raw.get("collector"))
                pct = lambda v: num(v, 0.0, 100.0)
                hist = []
                for x in (raw.get("history") if isinstance(raw.get("history"), list) else [])[-120:]:
                    if isinstance(x, list) and len(x) == 4 and num(x[0], 0, 4e9) is not None:
                        hist.append([int(num(x[0], 0, 4e9))] + [pct(y) for y in x[1:4]])
                loads = cpu.get("load") if isinstance(cpu.get("load"), list) else []
                data = {
                    "ts": int(num(raw.get("ts"), 0, 4e9) or 0), "interval": num(raw.get("interval"), 1, 600) or 5.0,
                    "cpu": {"pct": pct(cpu.get("pct")), "cores": int(num(cpu.get("cores"), 0, 100000) or 0),
                            "load": [num(x, 0, 1e6) for x in loads[:3]]},
                    "mem": {"pct": pct(mem.get("pct")), "used": num(mem.get("used")), "total": num(mem.get("total")),
                            "swap_pct": pct(mem.get("swap_pct")), "swap_total": num(mem.get("swap_total"))},
                    "net": {"pct": pct(net.get("pct")), "rx_bps": num(net.get("rx_bps")), "tx_bps": num(net.get("tx_bps")),
                            "link_mbps": num(net.get("link_mbps"), 0, 1e7), "link_assumed": net.get("link_assumed") is True},
                    "history": hist,
                    "collector": {"cpu_s": num(col.get("cpu_s")), "rss_kb": num(col.get("rss_kb")), "since": num(col.get("since"), 0, 4e9)},
                }
                _HOST_METRICS["data"], _HOST_METRICS["mtime"] = data, key
            d = dict(_HOST_METRICS["data"])
        finally:
            os.close(fd)
    except FileNotFoundError:
        return {"available": False, "why": "Not measured yet: run phase3b-api.sh on PATCH-01 (it installs patch01-metrics)."}
    except (OSError, ValueError, TypeError, AttributeError, OverflowError, RecursionError):
        return {"available": False, "why": "The measurement could not be read: journalctl -u patch01-metrics on PATCH-01."}
    d["available"] = True
    d["stale"] = (time.time() - d["ts"]) > 30
    return d


@app.get("/api/v1/overview")
def overview_page(tz: str = "UTC", user: str = Depends(require_viewer)):
    """Everything the Overview shows, computed from the database in one request."""
    from zoneinfo import ZoneInfo
    from . import overview
    try:
        if not re.fullmatch(r"[A-Za-z]+(?:/[A-Za-z0-9_+-]+){0,2}", tz or ""):
            raise ValueError
        ZoneInfo(tz)
    except Exception:  # noqa: BLE001 - an unknown zone: UTC
        tz = "UTC"
    from datetime import datetime as _dt
    with db() as conn:
        return jsonable(overview.build(conn, tz=tz, today=_dt.now(ZoneInfo(tz)).date()))


@app.get("/api/v1/server-groups")
def server_groups(user: str = Depends(require_viewer)):
    from . import servers as sv
    with db() as conn:
        return jsonable({"groups": sv.group_list(conn)})


class GroupIn(BaseModel):
    name: str = Field(..., max_length=40)
    description: Optional[str] = Field(default=None, max_length=200)
    environment: str = Field(default="prod", pattern="^(dev|test|staging|prod)$")
    max_concurrent: int = Field(default=5, ge=1, le=50)
    patch_order: int = Field(default=100, ge=0, le=10000)


@app.post("/api/v1/admin/server-groups")
def server_group_add(body: GroupIn, request: Request, user: str = Depends(require_admin)):
    from . import servers as sv
    name = body.name.strip()
    if not sv.GROUP_NAME_RE.match(name) or name == sv.NO_GROUP:
        raise HTTPException(422, "A group name is 1 to 40 letters, digits, spaces and . _ ( ) + -")
    with db() as conn:
        if conn.execute("SELECT 1 FROM host_groups WHERE lower(name) = lower(%s)", (name,)).fetchone():
            raise HTTPException(409, f"There is already a group called {name}.")
        conn.execute("""INSERT INTO host_groups (name, description, environment, max_concurrent, patch_order)
                        VALUES (%s, %s, %s::environment_tier, %s, %s)""",
                     (name, (body.description or "").strip() or None, body.environment, body.max_concurrent, body.patch_order))
        _audit(conn, user, "server_group_added", "server_group", name, body.model_dump(), client_ip(request))
    return {"ok": True}


class GroupEditIn(BaseModel):
    description: Optional[str] = Field(default=None, max_length=200)
    environment: str = Field(default="prod", pattern="^(dev|test|staging|prod)$")
    max_concurrent: int = Field(default=5, ge=1, le=50)
    patch_order: int = Field(default=100, ge=0, le=10000)


@app.put("/api/v1/admin/server-groups/{name}")
def server_group_edit(name: str, body: GroupEditIn, request: Request, user: str = Depends(require_admin)):
    with db() as conn:
        row = conn.execute(
            """UPDATE host_groups SET description=%s, environment=%s::environment_tier, max_concurrent=%s, patch_order=%s
                WHERE name=%s RETURNING name""",
            ((body.description or "").strip() or None, body.environment, body.max_concurrent, body.patch_order, name)).fetchone()
        if not row:
            raise HTTPException(404, "No such group.")
        _audit(conn, user, "server_group_changed", "server_group", name, body.model_dump(), client_ip(request))
    return {"ok": True}


@app.delete("/api/v1/admin/server-groups/{name}")
def server_group_delete(name: str, request: Request, user: str = Depends(require_admin)):
    with db() as conn:
        if name == "default":
            raise HTTPException(409, "The default group is kept: new servers without a group go there.")
        n = conn.execute("SELECT count(*) AS n FROM hosts WHERE host_group=%s AND status <> 'decommissioned'", (name,)).fetchone()["n"]
        if n:
            raise HTTPException(409, f"{n} server(s) are in this group: move them to another group first.")
        t = conn.execute("""SELECT count(*) AS n FROM enrollment_tokens WHERE host_group=%s
                              AND used_at IS NULL AND revoked_at IS NULL AND expires_at > now()""", (name,)).fetchone()["n"]
        if t:
            raise HTTPException(409, f"{t} unused enrolment token(s) enrol into this group: let them expire or revoke them first.")
        w = conn.execute("SELECT count(*) AS n FROM maintenance_windows WHERE host_group=%s", (name,)).fetchone()["n"]
        if w:
            raise HTTPException(409, f"{w} maintenance window(s) belong to this group: remove them first (Patching > Windows).")
        # The checks again in the same statement, so a server moved in meanwhile is not orphaned
        row = conn.execute("""DELETE FROM host_groups g WHERE g.name=%s
                                 AND NOT EXISTS (SELECT 1 FROM hosts h WHERE h.host_group=g.name AND h.status <> 'decommissioned')
                                 AND NOT EXISTS (SELECT 1 FROM maintenance_windows m WHERE m.host_group=g.name)
                               RETURNING name""", (name,)).fetchone()
        if not row:
            if conn.execute("SELECT 1 FROM host_groups WHERE name=%s", (name,)).fetchone():
                raise HTTPException(409, "The group changed meanwhile: reload and try again.")
            raise HTTPException(404, "No such group.")
        _audit(conn, user, "server_group_removed", "server_group", name, {}, client_ip(request))
    return {"ok": True}


class MoveGroupIn(BaseModel):
    host_ids: List[str] = Field(..., min_length=1, max_length=500)
    group: str = Field(..., max_length=40)


@app.post("/api/v1/servers/move-group")
def servers_move_group(body: MoveGroupIn, request: Request, user: str = Depends(require_operator)):
    """Put servers in a patch group. Patch jobs and windows follow the group."""
    ids = [i for i in body.host_ids if re.fullmatch(r"[0-9a-f-]{36}", i or "")]
    if len(ids) != len(body.host_ids):
        raise HTTPException(422, "A server id was not recognised.")
    with db() as conn:
        if not conn.execute("SELECT 1 FROM host_groups WHERE name=%s", (body.group,)).fetchone():
            raise HTTPException(422, "No such group: an admin adds groups under Servers > Groups.")
        rows = conn.execute("""UPDATE hosts SET host_group=%s, updated_at=now()
                                WHERE id::text = ANY(%s) AND status <> 'decommissioned'
                            RETURNING hostname""", (body.group, ids)).fetchall()
        _audit(conn, user, "servers_moved_group", "server_group", body.group,
               {"servers": [r["hostname"] for r in rows][:500]}, client_ip(request))
    return {"ok": True, "moved": len(rows)}


class MatchNamesIn(BaseModel):
    names: List[str] = Field(..., min_length=1, max_length=2000)


HOSTNAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,252}$")


@app.post("/api/v1/servers/match-names")
def servers_match_names(body: MatchNamesIn, user: str = Depends(require_operator)):
    """A list of server names (from an uploaded text file) matched to the
    servers PATCH-01 knows: by name, full name (FQDN) or short name. Changes
    nothing: the console then asks which group to move them to."""
    seen, names, invalid = set(), [], []
    for raw in body.names:
        n = (raw or "").strip().rstrip(".")
        if not n:
            continue
        if not HOSTNAME_RE.match(n):
            invalid.append(n[:80])
            continue
        if n.lower() not in seen:
            seen.add(n.lower()); names.append(n)
    if not names and not invalid:
        raise HTTPException(422, "The list has no server names.")
    lows = [n.lower() for n in names]
    shorts = [n.split(".")[0] for n in lows]
    with db() as conn:
        hosts = conn.execute(
            """SELECT id::text AS host_id, hostname, fqdn, os_id, os_version, host_group
                 FROM hosts
                WHERE status <> 'decommissioned'
                  AND (lower(hostname) = ANY(%(l)s) OR lower(fqdn) = ANY(%(l)s)
                       OR split_part(lower(hostname), '.', 1) = ANY(%(s)s))""",
            {"l": lows, "s": shorts}).fetchall()
    by_name, by_fqdn, by_short = {}, {}, {}
    for h_ in hosts:
        by_name.setdefault(h_["hostname"].lower(), []).append(h_)
        if h_["fqdn"]:
            by_fqdn.setdefault(h_["fqdn"].lower(), []).append(h_)
        by_short.setdefault(h_["hostname"].lower().split(".")[0], []).append(h_)
    found, not_found, ambiguous, taken = [], [], [], set()
    for n, low, short in zip(names, lows, shorts):
        cand, how = by_name.get(low), "name"
        if not cand:
            cand, how = by_fqdn.get(low), "full name"
        if not cand:
            # A short name matches; a listed full name (with dots) matches by its
            # short name only a server whose own full name is not known to differ
            cand, how = by_short.get(short), "short name"
            if cand and "." in low:
                cand = [c for c in cand if not c["fqdn"] or c["fqdn"].lower() == low] or None
        if not cand:
            not_found.append(n)
        elif len(cand) > 1:
            ambiguous.append({"name": n, "servers": sorted(c["hostname"] for c in cand)})
        elif cand[0]["host_id"] not in taken:
            taken.add(cand[0]["host_id"])
            found.append(dict(cand[0], listed_as=n, matched_by=how))
    return jsonable({"found": found, "not_found": not_found, "ambiguous": ambiguous, "invalid": invalid,
                     "listed": len(names) + len(invalid)})


@app.get("/api/v1/servers/export")
def servers_export(request: Request, format: str = "csv", q: Optional[str] = None, os: Optional[str] = None,
                   group: Optional[str] = None, version: Optional[str] = None, agent: Optional[str] = None,
                   patch: Optional[str] = None, sort: str = "name", user: str = Depends(require_viewer)):
    """Every server matching the filters (not just one page), as CSV or as an
    Excel file with the logo. Both carry the organisation, the time it was
    made, who made it and the filter."""
    from fastapi.responses import Response
    from . import servers as sv, exports as ex, branding as br
    if format not in ("csv", "pdf", "xlsx"):
        raise HTTPException(422, "format must be pdf or csv")
    f = sv.clean_filters(q, os, group, version, agent, patch)
    with db() as conn:
        rows = sv.all_rows(conn, f, sort if sort in sv.SORTS else "name")
        company = ex.company_name(conn)
        cols = sv.EXPORT_COLUMNS if format != "pdf" else sv.EXPORT_COLUMNS[:12]   # a page is only so wide
        heads = [label for _, label in cols]
        data_rows = [[sv.export_value(k, r.get(k)) for k, _ in cols] for r in rows]
        m = ex.meta("Servers report", user, sv.describe_filters(f), len(rows), company)
        body, mime, ext = ex.render(format, m, heads, data_rows, conn)
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="servers_exported",
                  detail={"format": format, "filters": f, "rows": len(rows)}, source_ip=client_ip(request))
    return Response(body, media_type=mime, headers={
        "Content-Disposition": f'attachment; filename="{ex.file_name("servers", ext)}"',
        "Cache-Control": "no-store", "X-Rows": str(len(rows))})


@app.get("/api/v1/patch-reports")
def patch_reports_list(days: Optional[int] = 30, os: Optional[str] = None, result: Optional[str] = None,
                       q: Optional[str] = None, change: Optional[str] = None, group: Optional[str] = None,
                       user: str = Depends(require_viewer)):
    """Finished patch jobs: per job, per patch group, per server per job, and one row per
    Windows update or Linux package each job handled, checked against the servers' own lists."""
    from . import patch_reports as pr
    f = pr.clean_filters(days, os, result, q, change, group)
    with db() as conn:
        summary, patches, info = pr.collect(conn, f)
        groups = [r["name"] for r in conn.execute("SELECT name FROM host_groups ORDER BY patch_order, name").fetchall()]
    return jsonable({"filters": f, "describe": pr.describe(f), "totals": info["totals"],
                     "summary": summary, "patches": patches, "jobs": info["jobs"], "groups": info["groups"],
                     "group_names": groups, "days": list(pr.DAYS), "limited": info["limited"]})


@app.get("/api/v1/patch-reports/export")
def patch_reports_export(request: Request, format: str = "pdf", view: str = "summary", days: Optional[int] = 30,
                         os: Optional[str] = None, result: Optional[str] = None, q: Optional[str] = None,
                         change: Optional[str] = None, group: Optional[str] = None, user: str = Depends(require_viewer)):
    """The Patch report as PDF (landscape, logo) or CSV, every row matching the filters."""
    from fastapi.responses import Response
    from . import patch_reports as pr, exports as ex
    if format not in ("csv", "pdf", "xlsx"):
        raise HTTPException(422, "format must be pdf or csv")
    if view not in pr.VIEWS:
        raise HTTPException(422, "view must be jobs, groups, summary or patches")
    f = pr.clean_filters(days, os, result, q, change, group)
    with db() as conn:
        summary, patches, info = pr.collect(conn, f)
        (heads, rows), title = pr.table_for(view, summary, patches, info, ex.TZ)
        m = ex.meta(title, user, pr.describe(f), len(rows), ex.company_name(conn))
        body, mime, ext = ex.render(format, m, heads, rows, conn)
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="patch_report_exported",
                  detail={"format": format, "view": view, "filters": f, "rows": len(rows)}, source_ip=client_ip(request))
    return Response(body, media_type=mime, headers={
        "Content-Disposition": f'attachment; filename="{ex.file_name("patch-report-" + view, ext)}"',
        "Cache-Control": "no-store", "X-Rows": str(len(rows))})


@app.get("/api/v1/installed-patches")
def installed_patches(days: Optional[int] = 30, start: Optional[str] = None, end: Optional[str] = None,
                      group: Optional[str] = None, os: Optional[str] = None, hosts: Optional[str] = None,
                      q: Optional[str] = None, defs: Optional[str] = None, failed: Optional[str] = None,
                      user: str = Depends(require_viewer)):
    """Patches installed per server in a period, with their dates, from the servers' own records
    (Windows installed updates and history, Linux package install times). Never the CVE feeds."""
    from . import installed_report as ir
    try:
        f = ir.clean_filters(days, start, end, group, os, hosts, q, defs, failed)
    except ir.Invalid as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        hosts_, totals = ir.collect(conn, f)
        groups = [r["name"] for r in conn.execute("SELECT name FROM host_groups ORDER BY patch_order, name").fetchall()]
    per_host = 400                    # on screen; the export has every row
    for h in hosts_:
        h["more"] = max(0, len(h["in_range"]) - per_host)
        h["in_range"] = h["in_range"][:per_host]
        h.pop("all", None)
    return jsonable({"filters": {k: v for k, v in f.items() if k not in ("since", "until")}, "describe": ir.describe(f),
                     "totals": totals, "servers": hosts_, "group_names": groups, "days": list(ir.DAY_CHOICES)})


@app.get("/api/v1/installed-patches/export")
def installed_patches_export(request: Request, format: str = "xlsx", days: Optional[int] = 30, start: Optional[str] = None,
                             end: Optional[str] = None, group: Optional[str] = None, os: Optional[str] = None,
                             hosts: Optional[str] = None, q: Optional[str] = None, defs: Optional[str] = None,
                             failed: Optional[str] = None, user: str = Depends(require_viewer)):
    """Excel: a summary per server, the period by server, everything installed by server, and
    a flat sheet for filtering. PDF: the period by server. CSV: the flat list."""
    from fastapi.responses import Response
    from . import installed_report as ir, exports as ex
    if format not in ("csv", "pdf", "xlsx"):
        raise HTTPException(422, "format must be xlsx, pdf or csv")
    try:
        f = ir.clean_filters(days, start, end, group, os, hosts, q, defs, failed)
    except ir.Invalid as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        body, mime, ext, n = ir.render(conn, f, format, user)
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="installed_patches_exported",
                  detail={"format": format, "filters": {k: str(v) for k, v in f.items() if v not in (None, False)}, "rows": n},
                  source_ip=client_ip(request))
    return Response(body, media_type=mime, headers={
        "Content-Disposition": f'attachment; filename="{ex.file_name("installed-patches", ext)}"',
        "Cache-Control": "no-store", "X-Rows": str(n)})


@app.post("/api/v1/changes/{change_id}/targets/{target_key}/explain")
def change_target_explain(change_id: str, target_key: str, request: Request, user: str = Depends(require_operator)):
    """Ask AI-01 again why this server failed (the worker answers within a minute or two)."""
    if not re.match(r"^[0-9a-f-]{36}$", change_id) or not re.match(r"^[A-Za-z0-9|._:-]{1,200}$", target_key):
        raise HTTPException(404, "Not found.")
    with db() as conn:
        c = conn.execute("SELECT kind::text AS kind FROM changes WHERE id = %s", (change_id,)).fetchone()
        if not c or c["kind"] not in ("patch", "software"):
            raise HTTPException(404, "No such patch or software change.")
        _change_ok(request, c["kind"])
        with conn.transaction():
            # The same rule the worker uses to pick servers to explain (errhelp.CANDIDATES_SQL)
            r = conn.execute("""UPDATE change_targets SET detail = jsonb_set(detail, '{explain}', '{"state": "pending", "again": true}'::jsonb)
                                 WHERE change_id = %s AND target_key = %s
                                   AND (state = 'failed' OR (state = 'done_with_warnings' AND detail ? 'warnings'))
                                 RETURNING target_key""", (change_id, target_key)).fetchone()
            if not r:
                raise HTTPException(409, "Only a server that failed or has warnings can be explained.")
    return {"ok": True}
