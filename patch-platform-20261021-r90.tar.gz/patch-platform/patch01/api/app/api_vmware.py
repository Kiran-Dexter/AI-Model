"""VMware: inventory, infrastructure, live map, blast radius and coverage (read-only).

Split out of main.py in r90; the code is unchanged."""

import os
import re
from fastapi import Depends, HTTPException

from .core import (app, db, jsonable, require_viewer)


# ---------------------------------------------------------------------------
# VMware (read-only; written by app.vmware)
# ---------------------------------------------------------------------------


SNAPSHOT_OLD_DAYS = int(os.environ.get("SNAPSHOT_OLD_DAYS", "7"))


@app.get("/api/v1/admin/vmware/summary")
def vmware_summary(admin: str = Depends(require_viewer)):
    with db() as conn:
        vcs = conn.execute(
            """SELECT name, host, version, last_sync_at, last_ok, last_error, vm_count
                 FROM vcenters ORDER BY name""").fetchall()
        c = conn.execute(
            """SELECT count(*)                                             AS vms,
                      count(*) FILTER (WHERE is_linux)                     AS linux,
                      count(*) FILTER (WHERE host_id IS NOT NULL)          AS matched,
                      count(*) FILTER (WHERE is_linux AND host_id IS NULL
                                         AND power_state='poweredOn')       AS unmanaged,
                      count(*) FILTER (WHERE match_method='ambiguous')     AS ambiguous,
                      count(*) FILTER (WHERE snapshot_count > 0
                        AND oldest_snapshot_at < now() - make_interval(days => %s)) AS old_snapshots
                 FROM vm_inventory""", (SNAPSHOT_OLD_DAYS,)).fetchone()
        unmatched_hosts = conn.execute(
            """SELECT count(*) AS n FROM hosts h
                WHERE h.status <> 'decommissioned'
                  AND NOT EXISTS (SELECT 1 FROM vm_inventory v WHERE v.host_id = h.id)"""
        ).fetchone()["n"]
    return {"vcenters": vcs, "counts": c, "servers_without_vm": unmatched_hosts,
            "snapshot_old_days": SNAPSHOT_OLD_DAYS}


@app.get("/api/v1/admin/vmware/vms")
def vmware_vms(view: str = "unmanaged", admin: str = Depends(require_viewer)):
    where = {
        "unmanaged": "v.is_linux AND v.host_id IS NULL AND v.power_state='poweredOn'",
        "snapshots": "v.snapshot_count > 0",
        "ambiguous": "v.match_method = 'ambiguous'",
        "linux": "v.is_linux",
        "all": "TRUE",
    }.get(view)
    if where is None:
        raise HTTPException(status_code=422, detail="unknown view")
    order = "v.oldest_snapshot_at NULLS LAST" if view == "snapshots" else "v.vcenter, v.name"
    with db() as conn:
        rows = conn.execute(
            f"""SELECT v.vcenter, v.moref, v.name, v.power_state, v.guest_os, v.is_linux,
                       v.guest_hostname, v.guest_ips, v.tools_running, v.esxi_host,
                       v.cluster, v.datacenter, v.num_cpu, v.memory_mb,
                       v.snapshot_count, v.oldest_snapshot_at, v.snapshots,
                       v.match_method, v.synced_at, v.host_id, h.hostname AS server
                  FROM vm_inventory v LEFT JOIN hosts h ON h.id = v.host_id
                 WHERE {where}
                 ORDER BY {order}
                 LIMIT 5000""").fetchall()
    return {"count": len(rows), "view": view, "vms": rows}


@app.get("/api/v1/admin/hosts/{host_id}/vm")
def host_vm(host_id: str, admin: str = Depends(require_viewer)):
    with db() as conn:
        row = conn.execute(
            """SELECT vcenter, moref, name, power_state, guest_os, esxi_host, cluster,
                      datacenter, num_cpu, memory_mb, tools_running, tools_version_status,
                      snapshot_count, oldest_snapshot_at, snapshots, match_method, synced_at
                 FROM vm_inventory WHERE host_id = %s
                 ORDER BY synced_at DESC LIMIT 1""", (host_id,)).fetchone()
    return {"vm": row, "snapshot_old_days": SNAPSHOT_OLD_DAYS}


ADVISORY_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9:._-]{1,60}$")


@app.get("/api/v1/admin/advisories")
def advisories_list(user: str = Depends(require_viewer)):
    """Every advisory still to install somewhere: vendor advisories from the
    CVE engine (Linux, and Windows builds from Microsoft's guide) and the
    Windows updates the servers themselves report missing, by KB."""
    with db() as conn:
        from . import report_jobs
        rows = conn.execute(report_jobs.ADVISORIES_SQL).fetchall()
    return jsonable({"count": len(rows), "advisories": rows})


@app.get("/api/v1/admin/advisories/{advisory_id}/hosts")
def advisory_hosts(advisory_id: str, user: str = Depends(require_viewer)):
    """The servers one advisory (or a Windows update, by KB) is still to be
    installed on, with what they have and what fixes it."""
    if not ADVISORY_ID_RE.match(advisory_id):
        raise HTTPException(404, "No such advisory.")
    with db() as conn:
        rows = conn.execute(
            """SELECT h.id::text AS host_id, h.hostname, agent_state(h.last_checkin, h.status) AS agent,
                      ha.state::text AS state, ha.package_name AS package, ha.installed_evr AS installed, ha.fixed_evr AS fixed_in
                 FROM host_applicability ha JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'
                WHERE ha.advisory_id = %(id)s AND ha.state IN ('affected', 'fixed_pending_reboot')
               UNION ALL
               SELECT h.id::text, h.hostname, agent_state(h.last_checkin, h.status), 'affected', 'Windows update',
                      CASE WHEN wu.downloaded THEN 'downloaded' ELSE 'not downloaded' END, wu.kb
                 FROM windows_updates wu JOIN hosts h ON h.id = wu.host_id AND h.status <> 'decommissioned'
                WHERE coalesce(wu.kb, wu.update_id) = %(id)s
                ORDER BY 2 LIMIT 1000""", {"id": advisory_id}).fetchall()
    return jsonable({"advisory_id": advisory_id, "hosts": rows})


@app.get("/api/v1/admin/advisories/{advisory_id}/cves")
def advisory_cves(advisory_id: str, admin: str = Depends(require_viewer)):
    """Published facts for every CVE in one advisory: score, how it is
    reached, whether it is being exploited, and the derived attack type with
    the data it was derived from."""
    with db() as conn:
        rows = conn.execute(
            """SELECT ac.cve_id, cd.cvss_score, cd.cvss_severity, cd.cvss_vector,
                      cd.cvss_version, cd.cvss_source, cd.attack_class, cd.attack_class_basis,
                      cd.attack_vector, cd.attack_complexity, cd.privileges_required,
                      cd.user_interaction, cd.cwes, cd.description,
                      cd.kev, cd.kev_added, cd.kev_due, cd.kev_ransomware,
                      cd.epss, cd.epss_percentile,
                      cd.rh_severity, cd.rh_cvss_score, cd.rh_statement,
                      cd.published, cd.last_modified, cd.nvd_fetched_at, cd.fetch_error
                 FROM advisory_cves ac
                 LEFT JOIN cve_details cd ON cd.cve_id = ac.cve_id
                WHERE ac.advisory_id = %s
                ORDER BY cd.kev DESC NULLS LAST, cd.cvss_score DESC NULLS LAST, ac.cve_id""",
            (advisory_id,)).fetchall()
    have = sum(1 for r in rows if r["nvd_fetched_at"])
    return {"advisory_id": advisory_id, "count": len(rows), "with_details": have, "cves": rows}


# ---------------------------------------------------------------------------
# VMware infrastructure (read-only)
# ---------------------------------------------------------------------------


@app.get("/api/v1/admin/vmware/hosts")
def vmware_hosts(admin: str = Depends(require_viewer)):
    """Every ESXi host: hardware, version, state and load."""
    with db() as conn:
        rows = conn.execute(
            """SELECT e.*,
                      CASE WHEN e.memory_mb > 0
                           THEN round(100.0 * e.memory_usage_mb / e.memory_mb) END AS memory_pct,
                      CASE WHEN (e.cpu_mhz * e.cpu_cores) > 0
                           THEN round(100.0 * e.cpu_usage_mhz / (e.cpu_mhz * e.cpu_cores)) END AS cpu_pct
                 FROM esxi_hosts e
                ORDER BY e.vcenter, e.cluster NULLS LAST, e.name""").fetchall()
    return {"count": len(rows), "hosts": rows}


@app.get("/api/v1/admin/vmware/datastores")
def vmware_datastores(admin: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT *,
                      capacity_mb - free_mb AS used_mb,
                      CASE WHEN capacity_mb > 0
                           THEN round(100.0 * (capacity_mb - free_mb) / capacity_mb) END AS used_pct,
                      CASE WHEN capacity_mb > 0
                           THEN round(100.0 * (capacity_mb - free_mb + coalesce(uncommitted_mb,0))
                                      / capacity_mb) END AS provisioned_pct
                 FROM datastores
                ORDER BY used_pct DESC NULLS LAST, name""").fetchall()
    return {"count": len(rows), "datastores": rows}


@app.get("/api/v1/admin/vmware/networks")
def vmware_networks(admin: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT * FROM vm_networks ORDER BY vcenter, name""").fetchall()
    return {"count": len(rows), "networks": rows}


@app.get("/api/v1/admin/vmware/clusters")
def vmware_clusters(admin: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT c.*,
                      (SELECT count(*) FROM esxi_hosts e
                        WHERE e.vcenter = c.vcenter AND e.cluster = c.name) AS hosts_seen,
                      (SELECT count(*) FROM vm_inventory v
                        WHERE v.vcenter = c.vcenter AND v.cluster = c.name) AS vms
                 FROM vm_clusters c ORDER BY c.vcenter, c.name""").fetchall()
    return {"count": len(rows), "clusters": rows}


@app.get("/api/v1/admin/vmware/map")
def vmware_map(admin: str = Depends(require_viewer)):
    """The infrastructure tree, assembled for drawing:
    vCenter > datacenter > cluster > ESXi host > VM, plus datastores."""
    with db() as conn:
        hosts = conn.execute(
            """SELECT vcenter, moref, name, cluster, datacenter, connection_state,
                      power_state, maintenance_mode, esxi_version, cpu_cores,
                      memory_mb, cpu_usage_mhz, memory_usage_mb, cpu_mhz, vm_count,
                      uptime_seconds
                 FROM esxi_hosts ORDER BY vcenter, datacenter, cluster NULLS LAST, name"""
        ).fetchall()
        vms = conn.execute(
            """SELECT vcenter, datacenter, cluster, esxi_host, esxi_moref, moref, vm,
                      power_state, guest_os, is_linux, num_cpu, memory_mb, tools_running,
                      snapshot_count, oldest_snapshot_at, datastore_names, network_names,
                      host_id, server, agent_state, needs_patch, needs_reboot
                 FROM v_vm_map ORDER BY vm"""
        ).fetchall()
        ds = conn.execute(
            """SELECT vcenter, name, type, datacenter, capacity_mb, free_mb, vm_count,
                      CASE WHEN capacity_mb > 0
                           THEN round(100.0 * (capacity_mb - free_mb) / capacity_mb) END AS used_pct
                 FROM datastores ORDER BY name"""
        ).fetchall()
        vcs = conn.execute("SELECT name, host, version, last_sync_at, last_ok FROM vcenters ORDER BY name").fetchall()
    return {"vcenters": vcs, "hosts": hosts, "vms": vms, "datastores": ds}


# ---------------------------------------------------------------------------
# VMware live map, blast radius, coverage (read-only, vCenter data only)
# ---------------------------------------------------------------------------


def _vmware_model(conn):
    from . import blast as bl
    hosts = conn.execute("SELECT * FROM esxi_hosts").fetchall()
    vms = conn.execute(
        """SELECT v.vcenter, v.moref, v.name, v.power_state, v.guest_os, v.is_linux, v.num_cpu,
                  v.memory_mb, v.tools_running, v.snapshot_count, v.oldest_snapshot_at,
                  v.datastore_names, v.network_names, v.esxi_moref, v.esxi_host, v.cluster,
                  v.datacenter, v.folder_path, v.overall_status, v.alarms, v.tags, v.app_group,
                  v.app_group_source, v.host_id, h.hostname AS server,
                  agent_state(h.last_checkin, h.status) AS agent_state,
                  (SELECT count(*) FROM host_applicability ha
                    WHERE ha.host_id = v.host_id AND ha.state = 'affected') AS needs_patch,
                  (SELECT count(*) FROM host_applicability ha
                    WHERE ha.host_id = v.host_id AND ha.state = 'fixed_pending_reboot') AS needs_reboot,
                  (SELECT count(*) FROM host_applicability ha
                     JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id
                    WHERE ha.host_id = v.host_id AND ha.state = 'affected' AND r.any_kev) AS kev_advisories
             FROM vm_inventory v LEFT JOIN hosts h ON h.id = v.host_id""").fetchall()
    ds = conn.execute("SELECT * FROM datastores").fetchall()
    nets = conn.execute("SELECT * FROM vm_networks").fetchall()
    cls = conn.execute("SELECT * FROM vm_clusters").fetchall()
    return bl.build_model(hosts, vms, ds, nets, cls)


def _live_meta(conn):
    return conn.execute(
        """SELECT c.name AS vcenter, l.connected, l.connected_since, l.last_update_at,
                  l.last_event_at, l.error, c.last_sync_at, c.last_ok
             FROM vcenters c LEFT JOIN vmware_live l ON l.vcenter = c.name
            ORDER BY c.name""").fetchall()


@app.get("/api/v1/admin/vmware/graph")
def vmware_graph(user: str = Depends(require_viewer)):
    """Everything the live map draws, graded red, amber, green or grey."""
    with db() as conn:
        m = _vmware_model(conn)
        live = _live_meta(conn)
        last = conn.execute("SELECT coalesce(max(id), 0) AS id FROM vmware_changes").fetchone()["id"]
        last_ev = conn.execute("SELECT coalesce(max(id), 0) AS id FROM vmware_events").fetchone()["id"]
    pick = lambda d, ks: {k: d.get(k) for k in ks}  # noqa: E731
    return {
        "live": live, "change_id": last, "event_id": last_ev,
        "clusters": [pick(c, ["key", "vcenter", "name", "datacenter", "ha_enabled", "drs_enabled",
                              "num_hosts", "grade"]) for c in m["clusters"].values()],
        "hosts": [dict(pick(h, ["key", "vcenter", "moref", "name", "cluster", "datacenter",
                                "connection_state", "maintenance_mode", "esxi_version", "esxi_build",
                                "cpu_cores", "memory_mb", "vm_count", "uptime_seconds", "grade"]),
                       cpu_pct=_pct(h.get("cpu_usage_mhz"), (h.get("cpu_mhz") or 0) * (h.get("cpu_cores") or 0)),
                       mem_pct=_pct(h.get("memory_usage_mb"), h.get("memory_mb")))
                  for h in m["hosts"].values()],
        "datastores": [dict(pick(d, ["key", "vcenter", "name", "type", "capacity_mb", "free_mb",
                                     "host_count", "vm_count", "local", "grade"]),
                            used_pct=_pct((d.get("capacity_mb") or 0) - (d.get("free_mb") or 0),
                                          d.get("capacity_mb")))
                       for d in m["datastores"].values()],
        "networks": [pick(n, ["key", "vcenter", "name", "kind", "vm_count", "grade"])
                     for n in m["networks"].values()],
        "vms": [pick(v, ["key", "vcenter", "moref", "name", "power_state", "guest_os", "is_linux",
                         "num_cpu", "memory_mb", "tools_running", "snapshot_count", "host_key",
                         "esxi_host", "cluster", "ds_keys", "net_keys", "app_group", "app_group_source",
                         "host_id", "server", "agent_state", "needs_patch", "kev_advisories", "grade"])
                for v in m["vms"].values()],
    }


def _pct(used, total):
    from . import blast as bl
    return bl.pct(used, total)


@app.get("/api/v1/admin/vmware/blast")
def vmware_blast(kind: str, key: str, user: str = Depends(require_viewer)):
    """What fails with this host, datastore or port group."""
    if kind not in ("host", "datastore", "network"):
        raise HTTPException(422, "kind must be host, datastore or network")
    from . import blast as bl
    with db() as conn:
        m = _vmware_model(conn)
    r = bl.blast(m, kind, key)
    if r is None:
        raise HTTPException(404, "Not found. It may have been removed since the map loaded.")
    return r


@app.get("/api/v1/admin/vmware/live")
def vmware_live(since: int = 0, since_event: int = 0, user: str = Depends(require_viewer)):
    """Changes and events after the given ids. The map polls this."""
    with db() as conn:
        changes = conn.execute(
            """SELECT id, at, vcenter, object_type, moref, name, field, old_value, new_value
                 FROM vmware_changes WHERE id > %s::bigint ORDER BY id LIMIT 500""", (since,)).fetchall()
        events = conn.execute(
            """SELECT id, vcenter, created_at, kind, severity, object_type, object_moref,
                      object_name, user_name, message
                 FROM vmware_events WHERE id > %s::bigint ORDER BY id DESC LIMIT 100""",
            (since_event,)).fetchall()
        live = _live_meta(conn)
        last = conn.execute("SELECT coalesce(max(id), 0) AS id FROM vmware_changes").fetchone()["id"]
        last_ev = conn.execute("SELECT coalesce(max(id), 0) AS id FROM vmware_events").fetchone()["id"]
    return {"changes": changes, "events": events, "live": live,
            "change_id": last, "event_id": last_ev}


@app.get("/api/v1/admin/vmware/coverage")
def vmware_coverage(user: str = Depends(require_viewer)):
    """How much of the estate the map can fully describe: Distributed vs
    standard switches (flow data needs Distributed), and application grouping."""
    with db() as conn:
        rows = conn.execute(
            """WITH per_vm AS (
                 SELECT v.vcenter, v.moref, v.name, v.power_state, v.app_group, v.app_group_source,
                        v.cluster, v.folder_path,
                        count(n.moref) FILTER (WHERE n.kind = 'DistributedVirtualPortgroup') AS vds,
                        count(n.moref) FILTER (WHERE n.kind = 'Network') AS std,
                        count(n.moref) FILTER (WHERE n.kind NOT IN ('DistributedVirtualPortgroup','Network')) AS other
                   FROM vm_inventory v
                   LEFT JOIN vm_networks n ON n.vcenter = v.vcenter AND n.name = ANY(v.network_names)
                  GROUP BY v.vcenter, v.moref, v.name, v.power_state, v.app_group,
                           v.app_group_source, v.cluster, v.folder_path)
               SELECT *, CASE WHEN vds > 0 AND std = 0 THEN 'distributed'
                              WHEN vds > 0 AND std > 0 THEN 'mixed'
                              WHEN std > 0 THEN 'standard'
                              WHEN other > 0 THEN 'other'
                              ELSE 'none' END AS switching
                 FROM per_vm ORDER BY name""").fetchall()
    sw = {"distributed": 0, "mixed": 0, "standard": 0, "other": 0, "none": 0}
    grp = {"tag": 0, "folder": 0, "none": 0}
    for r in rows:
        sw[r["switching"]] += 1
        grp[r["app_group_source"] or "none"] += 1
    apps = {}
    for r in rows:
        if r["app_group"]:
            a = apps.setdefault(r["app_group"], {"app": r["app_group"], "source": r["app_group_source"], "vms": 0})
            a["vms"] += 1
    return {"total": len(rows), "switching": sw, "grouping": grp,
            "apps": sorted(apps.values(), key=lambda a: (-a["vms"], a["app"])),
            "standard_only": [dict(vcenter=r["vcenter"], name=r["name"], cluster=r["cluster"])
                              for r in rows if r["switching"] == "standard"],
            "ungrouped": [dict(vcenter=r["vcenter"], name=r["name"], cluster=r["cluster"],
                               folder=r["folder_path"]) for r in rows if not r["app_group"]]}
