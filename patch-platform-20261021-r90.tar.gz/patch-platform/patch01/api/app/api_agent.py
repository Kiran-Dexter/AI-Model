"""Agent endpoints: enrolment, check-in, inventory, commands, and the agents' log lines.

Split out of main.py in r90; the code is unchanged."""

import json
import psycopg
import re
import secrets
import uuid
from datetime import datetime, timedelta
from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field
from typing import List, Optional

from .core import (AgentIdentity, CheckinIn, CommandOut, CommandResultIn, EnrollRequest, EnrollResponse, InventoryIn,
                   MIN_PLAUSIBLE_PACKAGES, _allowed_kinds, _change_ok, _updates_from, app, audit, client_ip, db, log,
                   now, parse_evr, require_agent, require_viewer, sha256)


# ---------------------------------------------------------------------------
# Agent endpoints
# ---------------------------------------------------------------------------


@app.post("/api/v1/agent/enroll", response_model=EnrollResponse)
def enroll(request: Request, body: EnrollRequest):
    """Redeem a single-use enrollment token for a per-host agent token.

    machine_id is the identity key rather than hostname, so a host that is
    renamed keeps its history instead of appearing as a new machine.
    """
    ip = client_ip(request)
    eth = sha256(body.enrollment_token)

    with db() as conn:
        with conn.transaction():
            tok = conn.execute(
                """SELECT id, host_group, expires_at, used_at, revoked_at
                     FROM enrollment_tokens
                    WHERE token_hash = %s
                    FOR UPDATE""",
                (eth,),
            ).fetchone()

            if not tok:
                log.warning("enroll rejected: unknown token from %s", ip)
                raise HTTPException(status_code=401, detail="invalid enrollment token")
            if tok["revoked_at"]:
                raise HTTPException(status_code=401, detail="enrollment token revoked")
            if tok["used_at"]:
                raise HTTPException(status_code=409, detail="enrollment token already used")
            if tok["expires_at"] < now():
                raise HTTPException(status_code=401, detail="enrollment token expired")

            agent_token = secrets.token_urlsafe(32)
            ath = sha256(agent_token)

            # Re-enrolment of a known machine keeps its id and history
            existing = conn.execute(
                "SELECT id, status::text AS status, token_hash, hardware_uuid FROM hosts WHERE machine_id = %s",
                (body.machine_id,),
            ).fetchone()
            if existing and existing["status"] != "decommissioned" and existing["token_hash"]:
                # Known hardware must match (either byte order of the BIOS UUID). A server whose
                # hardware was never recorded re-enrols as before and its UUID is recorded now
                from . import vmware as _vm
                known = _vm.uuid_forms(existing["hardware_uuid"])
                same = (not known) or bool(known & _vm.uuid_forms(body.hardware_uuid))
                if not same:
                    # An unused token must not take over an active server's identity (a clone, or a
                    # leaked token): the token stays unused
                    log.warning("enroll refused from %s: machine id of an active server, different or unknown hardware", ip)
                    raise HTTPException(status_code=409, detail=(
                        "This machine is already enrolled and its agent is active on PATCH-01. If you are reinstalling "
                        "this same server, decommission it on the Servers page first (its history is kept), then run "
                        "the installer again. A copy or clone of another server needs its own machine ID."))

            os_major = None
            m = re.match(r"^(\d+)", body.os_version or "")
            if m:
                os_major = int(m.group(1))

            if existing:
                host_id = existing["id"]
                conn.execute(
                    """UPDATE hosts
                          SET hostname=%s, fqdn=%s, os_id=%s, os_version=%s,
                              os_major=%s, arch=%s, pkg_manager=%s,
                              agent_version=%s, token_hash=%s,
                              host_group=%s, status='active',
                              hardware_uuid=COALESCE(lower(%s), hardware_uuid),
                              enrolled_at=now(), updated_at=now()
                        WHERE id=%s""",
                    (body.hostname, body.fqdn, body.os_id, body.os_version,
                     os_major, body.arch, body.pkg_manager, body.agent_version,
                     ath, tok["host_group"], body.hardware_uuid, host_id),
                )
                action = "re_enroll"
            else:
                row = conn.execute(
                    """INSERT INTO hosts
                         (hostname, fqdn, machine_id, os_id, os_version, os_major,
                          arch, pkg_manager, agent_version, token_hash,
                          host_group, status, hardware_uuid)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'active',lower(%s))
                       RETURNING id""",
                    (body.hostname, body.fqdn, body.machine_id, body.os_id,
                     body.os_version, os_major, body.arch, body.pkg_manager,
                     body.agent_version, ath, tok["host_group"], body.hardware_uuid),
                ).fetchone()
                host_id = row["id"]
                action = "enroll"

            conn.execute(
                """UPDATE enrollment_tokens
                      SET used_at=now(), used_by_host=%s
                    WHERE id=%s""",
                (host_id, tok["id"]),
            )

            audit(conn, actor=body.hostname, actor_type="agent", action=action,
                  host_id=str(host_id), object_type="host",
                  object_id=str(host_id),
                  detail={"os": f"{body.os_id} {body.os_version}",
                          "arch": body.arch,
                          "machine_id": body.machine_id},
                  source_ip=ip)

        # A new server is linked to its VM at the next vCenter read: ask the worker for one now
        try:
            with conn.transaction():
                conn.execute("UPDATE vcenters SET sync_requested_at = now()")
        except Exception:  # noqa: BLE001 - schema 035 not applied, or no vCenter: the 5-minute read links it
            pass

    log.info("%s: host %s (%s)", action, body.hostname, host_id)
    return EnrollResponse(
        host_id=str(host_id),
        agent_token=agent_token,
        checkin_interval_sec=300,
    )


@app.post("/api/v1/agent/checkin")
def checkin(request: Request, body: CheckinIn,
            agent: AgentIdentity = Depends(require_agent)):
    """Lightweight heartbeat. Returns whether a full inventory is wanted."""
    ip = client_ip(request)
    with db() as conn:
        with conn.transaction():
            conn.execute(
                """UPDATE hosts
                      SET last_checkin=now(), last_run_at=now(), status='active', updated_at=now(),
                          agent_version=COALESCE(%s, agent_version),
                          kernel_running=COALESCE(%s, kernel_running),
                          reboot_required=COALESCE(%s, reboot_required),
                          boot_time=COALESCE(%s, boot_time),
                          agent_ip=COALESCE(%s::inet, agent_ip),
                          hardware_uuid=COALESCE(lower(%s), hardware_uuid)
                    WHERE id=%s""",
                (body.agent_version, body.kernel_running,
                 body.reboot_required, body.boot_time, ip, body.hardware_uuid,
                 agent.host_id),
            )
            row = conn.execute(
                "SELECT last_inventory FROM hosts WHERE id=%s",
                (agent.host_id,),
            ).fetchone()

    last_inv = row["last_inventory"] if row else None
    want_inventory = last_inv is None or (now() - last_inv) > timedelta(hours=4)   # CVEs are checked every 4 hours

    return {
        "ok": True,
        "want_inventory": want_inventory,
        "checkin_interval_sec": 300,
    }


def _record_installs(conn, host_id, rows):
    """Every package version seen installed, with its install time: the history
    behind the Installed patches report (kept after the next upgrade)."""
    data = [(host_id, r[1], r[2], r[6], r[8]) for r in rows]
    with conn.cursor() as cur:
        cur.executemany(
            """INSERT INTO linux_package_installs (host_id, name, arch, version, installed_at)
               VALUES (%s,%s,%s,%s,%s)
               ON CONFLICT (host_id, name, arch, version)
               DO UPDATE SET installed_at = COALESCE(EXCLUDED.installed_at, linux_package_installs.installed_at)""",
            data)


def _store_updates(conn, host_id, up):
    """What the package manager would install now. A failed check keeps the last
    good list and records why, so a passing network fault never shows 0 to install."""
    if up.error:
        conn.execute("UPDATE hosts SET updates_error=%s WHERE id=%s", (up.error[:500], host_id))
        return
    conn.execute("DELETE FROM linux_updates WHERE host_id=%s", (host_id,))
    seen, rows = set(), []
    for i in up.items:
        if (i.name, i.arch) in seen:
            continue
        seen.add((i.name, i.arch))
        rows.append((host_id, i.name, i.arch, i.installed, i.available, i.repo, i.security, i.advisory, i.severity, up.checked_at))
    if rows:
        with conn.cursor() as cur:
            cur.executemany(
                """INSERT INTO linux_updates (host_id, name, arch, installed, available, repo, security, advisory, severity, reported_at)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""", rows)
    conn.execute("UPDATE hosts SET updates_checked_at=%s, updates_error=NULL WHERE id=%s", (up.checked_at, host_id))


@app.post("/api/v1/agent/inventory")
def submit_inventory(request: Request, body: InventoryIn,
                     agent: AgentIdentity = Depends(require_agent)):
    """Replace this host's package set.

    Wholesale replacement inside one transaction: a diff would miss packages
    removed outside the agent's knowledge, and a partial write would leave
    the applicability engine reading a half-updated inventory.
    """
    ip = client_ip(request)
    pkgs = body.packages

    # A suspiciously small inventory usually means a broken collector. Record
    # the run as failed rather than destroying good data with bad.
    # Windows lists its OS build plus installed KBs, often fewer than 50, so
    # there the test is one well-formed OS build entry. Which test applies is
    # decided by the server's recorded OS, not by the shape of the report.
    with db() as conn:
        os_row = conn.execute("SELECT os_id FROM hosts WHERE id=%s", (agent.host_id,)).fetchone()
    if (os_row or {}).get("os_id") == "windows":
        builds = [p_ for p_ in pkgs if p_.name == "windows-os-build"]
        plausible = len(builds) == 1 and re.fullmatch(r"10\.0\.\d+\.\d+-0", builds[0].version or "") is not None
        why = (f"expected one windows-os-build entry with a build like 10.0.17763.6414, got "
               f"{len(builds)}" + (f" ({builds[0].version})" if builds else ""))
    else:
        plausible = len(pkgs) >= MIN_PLAUSIBLE_PACKAGES
        why = (f"only {len(pkgs)} packages reported; refusing to replace inventory "
               f"(minimum {MIN_PLAUSIBLE_PACKAGES})")
    if not plausible:
        with db() as conn:
            with conn.transaction():
                conn.execute(
                    """INSERT INTO inventory_runs
                         (host_id, collected_at, package_count, ok, error,
                          agent_version)
                       VALUES (%s,%s,%s,FALSE,%s,%s)""",
                    (agent.host_id, body.collected_at, len(pkgs),
                     f"implausible inventory: {why}",
                     body.agent_version),
                )
                audit(conn, actor=agent.hostname, actor_type="agent",
                      action="inventory_rejected", host_id=agent.host_id,
                      detail={"package_count": len(pkgs)}, source_ip=ip)
        raise HTTPException(status_code=422, detail=why)

    # Hash the sorted set so unchanged inventories can skip recomputation
    # ("v2": the newest-version rule above changed what is stored, so every
    # server's next inventory is stored again once, even if it did not change)
    # ("v3": agent 1.8.2 sends install times; they are part of what is stored)
    timed = any(getattr(p, "install_time", None) for p in pkgs)
    canonical = ("v3\n" if timed else "v2\n") + "\n".join(
        sorted(f"{p.name}|{p.arch}|{p.version}" + (f"|{p.install_time.isoformat() if p.install_time else ''}" if timed else "")
               for p in pkgs)
    )
    content_hash = sha256(canonical)

    # One row per package and architecture: the NEWEST version. Kernels are
    # installed side by side; keeping whichever came last in the list could keep
    # an old kernel, and the server then showed "1 to install" for ever.
    from .evr import rpm_label_compare, deb_compare
    best, cmp = {}, None
    for p in pkgs:
        epoch, version, release = parse_evr(p.version)
        key = (p.name, p.arch)
        cur = best.get(key)
        if cur is not None and cmp is None:       # listed twice: compare by the server's package format
            with db() as c0:
                pm = c0.execute("SELECT pkg_manager::text AS pm FROM hosts WHERE id=%s", (agent.host_id,)).fetchone()
            cmp = deb_compare if pm and pm["pm"] == "apt" else rpm_label_compare
        if cur is None or cmp(epoch, version, release, cur[3], cur[4], cur[5]) > 0:
            best[key] = (agent.host_id, p.name, p.arch, epoch, version, release, p.version, p.from_repo,
                         getattr(p, "install_time", None))
    rows = list(best.values())

    os_major = None
    if body.os_version:
        m = re.match(r"^(\d+)", body.os_version)
        if m:
            os_major = int(m.group(1))

    with db() as conn:
        with conn.transaction():
            prev = conn.execute(
                """SELECT content_hash FROM inventory_runs
                    WHERE host_id=%s AND ok
                    ORDER BY collected_at DESC LIMIT 1""",
                (agent.host_id,),
            ).fetchone()
            unchanged = bool(prev and prev["content_hash"] == content_hash)

            if not unchanged:
                conn.execute("DELETE FROM host_packages WHERE host_id=%s",
                             (agent.host_id,))
                with conn.cursor() as cur:
                    cur.executemany(
                        """INSERT INTO host_packages
                             (host_id, name, arch, epoch, version, release,
                              full_nevra, from_repo, install_time)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
                           ON CONFLICT (host_id, name, arch) DO UPDATE
                             SET epoch=EXCLUDED.epoch,
                                 version=EXCLUDED.version,
                                 release=EXCLUDED.release,
                                 full_nevra=EXCLUDED.full_nevra,
                                 from_repo=EXCLUDED.from_repo,
                                 install_time=EXCLUDED.install_time""",
                        rows,
                    )
                if timed and (os_row or {}).get("os_id") != "windows":
                    _record_installs(conn, agent.host_id, rows)
                from . import cve_impact
                cve_impact.inventory_changed(conn)     # Detected CVEs are re-checked against the new versions
                try:
                    with conn.transaction():           # "to install" is worked out again by the worker within a minute
                        conn.execute("UPDATE hosts SET packages_changed_at = now() WHERE id = %s", (agent.host_id,))
                except psycopg.errors.UndefinedColumn:
                    pass                               # schema 039 not applied yet: the nightly run catches up

            conn.execute(
                """INSERT INTO inventory_runs
                     (host_id, collected_at, package_count, content_hash,
                      agent_version, duration_ms, ok)
                   VALUES (%s,%s,%s,%s,%s,%s,TRUE)""",
                (agent.host_id, body.collected_at, len(pkgs), content_hash,
                 body.agent_version, body.duration_ms),
            )

            conn.execute(
                """UPDATE hosts
                      SET last_inventory=now(), last_checkin=now(),
                          status='active', updated_at=now(),
                          kernel_running=%s,
                          kernel_latest=COALESCE(%s, kernel_latest),
                          reboot_required=%s,
                          reboot_reason=%s,
                          os_version=COALESCE(%s, os_version),
                          os_major=COALESCE(%s, os_major),
                          agent_version=COALESCE(%s, agent_version),
                          boot_time=COALESCE(%s, boot_time),
                          agent_ip=COALESCE(%s::inet, agent_ip),
                          hardware_uuid=COALESCE(lower(%s), hardware_uuid)
                    WHERE id=%s""",
                (body.kernel_running, body.kernel_latest,
                 body.reboot_required, body.reboot_reason,
                 body.os_version, os_major, body.agent_version,
                 body.boot_time, ip, body.hardware_uuid, agent.host_id),
            )
            up = getattr(body, "updates", None)
            up = _updates_from(up) if isinstance(up, dict) else up
            if up is not None and (os_row or {}).get("os_id") != "windows":
                _store_updates(conn, agent.host_id, up)

            audit(conn, actor=agent.hostname, actor_type="agent",
                  action="inventory", host_id=agent.host_id,
                  detail={"packages": len(pkgs), "unchanged": unchanged,
                          "kernel": body.kernel_running,
                          "reboot_required": body.reboot_required},
                  source_ip=ip)

    log.info("inventory from %s: %d packages%s", agent.hostname, len(pkgs),
             " (unchanged)" if unchanged else "")
    return {"ok": True, "packages_received": len(pkgs), "unchanged": unchanged}


@app.get("/api/v1/agent/commands", response_model=List[CommandOut])
def poll_commands(agent: AgentIdentity = Depends(require_agent)):
    """Claim pending commands for this host.

    Returns a bounded verb and JSON parameters. There is deliberately no
    verb that carries a shell command: the agent's own implementation maps
    each verb to a fixed action.
    """
    with db() as conn:
        with conn.transaction():
            rows = conn.execute(
                """UPDATE agent_commands
                      SET claimed_at = now()
                    WHERE id IN (
                        SELECT id FROM agent_commands
                         WHERE host_id = %s
                           AND claimed_at IS NULL
                           AND expires_at > now()
                         ORDER BY created_at
                         LIMIT 10
                         FOR UPDATE SKIP LOCKED
                    )
                RETURNING id, verb, params, job_id""",
                (agent.host_id,),
            ).fetchall()
            scans = [(r["params"] or {}).get("scan_id") for r in rows if r["verb"] == "run_hardening_scan"]
            if scans:
                conn.execute(
                    """UPDATE hardening_scans SET state='running', started_at=now(),
                              stage='picked_up', stage_at=now()
                        WHERE id = ANY(%s::uuid[]) AND host_id=%s AND state='queued'""",
                    ([x for x in scans if x], agent.host_id))

    return [
        CommandOut(
            id=str(r["id"]),
            verb=r["verb"],
            params=r["params"] or {},
            job_id=str(r["job_id"]) if r["job_id"] else None,
        )
        for r in rows
    ]


def _with_message(result, message):
    """Keep the agent's message with its result: for a failure it is often the
    only explanation (the Linux agent sends its errors there)."""
    out = dict(result or {})
    if message and "message" not in out:
        out["message"] = str(message)[:4000]
    return out


@app.post("/api/v1/agent/commands/{command_id}/result")
def command_result(command_id: str, body: CommandResultIn,
                   request: Request,
                   agent: AgentIdentity = Depends(require_agent)):
    """Report the outcome of a claimed command.

    Scoped to the calling host, so an agent cannot complete another's work.
    """
    ip = client_ip(request)
    if not body.ok and isinstance(body.result, dict) and body.result.get("deferred") is True:
        # Not run because the agent replaced itself a moment ago: back in the queue for the new version
        with db() as conn:
            with conn.transaction():
                back = conn.execute(
                    """UPDATE agent_commands SET claimed_at = NULL
                        WHERE id=%s AND host_id=%s AND completed_at IS NULL AND claimed_at IS NOT NULL
                    RETURNING id""", (command_id, agent.host_id)).fetchone()
                if not back:
                    raise HTTPException(status_code=404, detail="no such pending command for this host")
        return {"ok": True, "requeued": True}
    with db() as conn:
        with conn.transaction():
            row = conn.execute(
                """UPDATE agent_commands
                      SET completed_at=now(), ok=%s, result=%s
                    WHERE id=%s AND host_id=%s AND completed_at IS NULL
                RETURNING id, verb, job_id""",
                (body.ok, json.dumps(_with_message(body.result, body.message)), command_id, agent.host_id),
            ).fetchone()

            if not row:
                raise HTTPException(
                    status_code=404,
                    detail="no such pending command for this host",
                )
            conn.execute("UPDATE hosts SET last_checkin = now() WHERE id = %s AND status <> 'decommissioned'", (agent.host_id,))

            if row["verb"] == "run_hardening_scan" and not body.ok:
                conn.execute(
                    """UPDATE hardening_scans SET state='failed', finished_at=now(), error=%s
                        WHERE id = (SELECT (params->>'scan_id')::uuid FROM agent_commands WHERE id=%s)
                          AND host_id=%s AND state IN ('queued','running')""",
                    ((body.result or {}).get("error") or body.message or "scan failed on the server",
                     command_id, agent.host_id))

            # Evidence is written as work progresses, not only at the end, so
            # a job that dies midway still shows how far it got.
            if row["job_id"]:
                stage_map = {
                    "run_precheck": "precheck",
                    "download_packages": "download",
                    "install_packages": "install",
                    "reboot_host": "reboot",
                    "run_postcheck": "postcheck",
                    "report_evidence": "evidence",
                }
                stage = stage_map.get(row["verb"], "queued")
                conn.execute(
                    """INSERT INTO job_events
                         (job_id, host_id, stage, ok, message, detail)
                       VALUES (%s,%s,%s,%s,%s,%s)""",
                    (row["job_id"], agent.host_id, stage, body.ok,
                     body.message, json.dumps(body.result)),
                )

            audit(conn, actor=agent.hostname, actor_type="agent",
                  action=f"command_result:{row['verb']}",
                  host_id=agent.host_id, object_type="command",
                  object_id=str(command_id),
                  detail={"ok": body.ok}, source_ip=ip)

    return {"ok": True}


# ---------------------------------------------------------------------------
# Agent log lines, and the console's live log
# ---------------------------------------------------------------------------


# "Authorization: Bearer <t>" and "Basic <t>" first: masking only the word after
# "Authorization:" would leave the token itself in the line
_AUTH_RE = re.compile(r"(?i)\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]+")


_SECRET_RE = re.compile(r"(?i)\b((?:password|passwd|pwd|secret|token|api[_-]?key|credential)s?)(\s*[:=]\s*|\s+)"
                        r"(\"[^\"]*\"|'[^']*'|\S+)")


LOG_KEEP_PER_HOST = 3000


def scrub(line):
    """Anything that looks like a secret is masked, whatever the sender did."""
    line = _AUTH_RE.sub(lambda m: m.group(1) + " [hidden]", line)
    return _SECRET_RE.sub(lambda m: m.group(1) + m.group(2) + "[hidden]", line)


class LogLineIn(BaseModel):
    at: datetime
    level: str = Field(default="INFO", max_length=8)
    msg: str = Field(..., max_length=2000)


class LogBatchIn(BaseModel):
    lines: List[LogLineIn] = Field(default_factory=list, max_length=500)


@app.post("/api/v1/agent/log")
def agent_log(body: LogBatchIn, agent: AgentIdentity = Depends(require_agent)):
    rows = []
    for l in body.lines:
        lvl = l.level.upper() if l.level.upper() in ("DEBUG", "INFO", "WARN", "WARNING", "ERROR") else "INFO"
        msg = scrub(l.msg.replace("\r", " ").replace("\n", " "))[:2000]
        if msg.strip():
            rows.append((agent.host_id, l.at, "WARN" if lvl == "WARNING" else lvl, msg))
    with db() as conn:
        with conn.transaction():
            with conn.cursor() as cur:
                cur.executemany("INSERT INTO agent_logs (host_id, at, level, line) VALUES (%s,%s,%s,%s)", rows)
            # Log lines arrive every 30 s while an agent works on a long step: that is contact,
            # so the server is not shown offline in the middle of a patch job
            conn.execute("UPDATE hosts SET last_checkin = now() WHERE id = %s AND status <> 'decommissioned'", (agent.host_id,))
            # bounded: the newest lines per server, and nothing older than 14 days
            conn.execute(
                """DELETE FROM agent_logs WHERE host_id=%s AND (received < now() - interval '14 days' OR id <
                       (SELECT id FROM agent_logs WHERE host_id=%s ORDER BY id DESC OFFSET %s LIMIT 1))""",
                (agent.host_id, agent.host_id, LOG_KEEP_PER_HOST))
    return {"ok": True, "stored": len(rows)}


@app.get("/api/v1/console/stream")
def console_stream(request: Request, after_log: int = 0, after_event: int = 0, host: Optional[str] = None,
                   change: Optional[str] = None, user: str = Depends(require_viewer)):
    """New agent log lines and change events since the given ids, oldest first,
    for the console's live log. With host or change, only those. Without the
    patch module, only one change of a kind the user may see."""
    from . import auth
    def _uuid(v):
        try:
            return str(uuid.UUID(v)) if v else None
        except (ValueError, AttributeError, TypeError):
            return None
    host = _uuid(host)
    change = _uuid(change)
    if "patch" not in auth.user_modules(request.state.user):
        if not change:
            return {"logs": [], "events": []}
        host = None
    with db() as conn:
        if change and "patch" not in auth.user_modules(request.state.user):
            k = conn.execute("SELECT kind::text AS kind FROM changes WHERE id::text=%s", (change,)).fetchone()
            if not k:
                return {"logs": [], "events": []}
            _change_ok(request, k["kind"])
        hosts = None
        if change:
            hosts = [r["host_id"] for r in conn.execute(
                "SELECT host_id::text AS host_id FROM change_targets WHERE change_id=%s AND host_id IS NOT NULL",
                (change,)).fetchall()]
        elif host:
            hosts = [host]
        first = after_log == 0 and after_event == 0
        logs = conn.execute(
            f"""SELECT * FROM (
                  SELECT l.id, l.at, l.level, l.line, h.hostname FROM agent_logs l JOIN hosts h ON h.id = l.host_id
                   WHERE l.id > %s {"AND l.host_id = ANY(%s::uuid[])" if hosts is not None else ""}
                   ORDER BY l.id DESC LIMIT %s) x ORDER BY id""",
            ((after_log, hosts, 80 if first else 400) if hosts is not None else (after_log, 80 if first else 400))).fetchall()
        # Only the kinds of change this user may see (a patch-only user does not see software jobs)
        kinds = _allowed_kinds(request)
        evs = conn.execute(
            f"""SELECT * FROM (
                  SELECT e.id, e.at, e.actor, e.event, e.ok, e.message, c.number
                    FROM change_events e JOIN changes c ON c.id = e.change_id
                   WHERE e.id > %s {"AND e.change_id = %s" if change else ""} AND c.kind::text = ANY(%s)
                   ORDER BY e.id DESC LIMIT %s) x ORDER BY id""",
            ((after_event, change, kinds, 60 if first else 300) if change else (after_event, kinds, 60 if first else 300))).fetchall()
    return {"logs": logs, "events": evs}
