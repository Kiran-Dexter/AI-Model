"""Hardening (OpenSCAP, CIS-aligned) and custom profiles.

Split out of main.py in r90; the code is unchanged."""

import json
import os
import re
from fastapi import Depends, File, Form, HTTPException, Request, UploadFile
from pydantic import BaseModel, Field
from typing import List, Optional

from .core import (AgentIdentity, app, client_ip, db, require_agent, require_operator, require_viewer)


# ---------------------------------------------------------------------------
# Hardening (OpenSCAP, CIS-aligned)
# ---------------------------------------------------------------------------


HARDENING_LEVELS = ("l1", "l2")


SCAN_STALE_HOURS = 5


@app.get("/api/v1/agent/hardening/content/{product}")
def agent_hardening_content(product: str, agent: AgentIdentity = Depends(require_agent)):
    """The active benchmark data stream for this product, as a file."""
    from fastapi.responses import FileResponse
    from . import hardening as hd
    with db() as conn:
        c = hd.active_content(conn, product)
    if not c:
        raise HTTPException(404, f"no active hardening content for {product}")
    path = os.path.join(hd.CONTENT_DIR, c["file_name"]) if not c["file_name"].startswith("/") else c["file_name"]
    if not os.path.exists(path):
        raise HTTPException(503, "hardening content is registered but its file is missing on PATCH-01")
    return FileResponse(path, media_type="application/xml",
                        headers={"X-Content-SHA256": c["sha256"], "X-Content-Version": c["content_version"]})


class HardeningProgressIn(BaseModel):
    scan_id: str
    stage: str = Field(..., pattern="^(downloading|scanning|uploading)$")
    done: Optional[int] = Field(default=None, ge=0, le=100000)
    total: Optional[int] = Field(default=None, ge=0, le=100000)


@app.post("/api/v1/agent/hardening/progress")
def agent_hardening_progress(body: HardeningProgressIn, agent: AgentIdentity = Depends(require_agent)):
    """Where a running scan has got to. Best effort: a lost update only
    means the console shows the previous figure a little longer."""
    with db() as conn:
        cur = conn.execute(
            """UPDATE hardening_scans SET stage=%s, stage_at=now(),
                      progress_done=coalesce(%s, progress_done), progress_total=coalesce(%s, progress_total)
                WHERE id=%s AND host_id=%s AND state IN ('queued','running')""",
            (body.stage, body.done, body.total, body.scan_id, agent.host_id))
        conn.commit()
    return {"ok": bool(cur.rowcount)}


class HardeningResultIn(BaseModel):
    scan_id: str
    arf_gz_b64: str = Field(..., max_length=60_000_000)
    oscap_version: Optional[str] = Field(default=None, max_length=200)
    exit_code: Optional[int] = None


@app.post("/api/v1/agent/hardening/result")
def agent_hardening_result(body: HardeningResultIn, agent: AgentIdentity = Depends(require_agent)):
    """The agent's scan result. Kept as evidence, then parsed."""
    import base64
    from . import hardening as hd
    with db() as conn:
        scan = conn.execute("SELECT id, state FROM hardening_scans WHERE id=%s AND host_id=%s",
                            (body.scan_id, agent.host_id)).fetchone()
        if not scan:
            raise HTTPException(404, "no such scan for this host")
        conn.execute("UPDATE hardening_scans SET stage='processing', stage_at=now() WHERE id=%s",
                     (body.scan_id,))
        conn.commit()
        try:
            data = base64.b64decode(body.arf_gz_b64, validate=True)
            r = hd.ingest(conn, body.scan_id, data, body.oscap_version)
        except Exception as e:  # noqa: BLE001 - the reason is shown on the scan
            conn.execute("UPDATE hardening_scans SET state='failed', finished_at=now(), error=%s WHERE id=%s",
                         (f"result could not be read: {e}"[:500], body.scan_id))
            conn.commit()
            raise HTTPException(422, f"result could not be read: {e}")
    return {"ok": True, **r}


def queue_hardening_scan(conn, host, level, requested_by):
    from . import hardening as hd
    return hd.queue_scan(conn, host, level, requested_by)


class HardeningScanIn(BaseModel):
    level: str = "l1"
    host_ids: Optional[List[str]] = None       # none means every active server


@app.post("/api/v1/hardening/scans")
def hardening_scan(body: HardeningScanIn, request: Request, user: str = Depends(require_operator)):
    _level(body.level)
    queued, skipped = [], []
    with db() as conn:
        with conn.transaction():
            hosts = conn.execute(
                """SELECT id, hostname, os_id, os_version FROM hosts
                    WHERE status <> 'decommissioned' AND (%s::uuid[] IS NULL OR id = ANY(%s::uuid[]))
                    ORDER BY hostname""", (body.host_ids, body.host_ids)).fetchall()
            for hst in hosts:
                sid, why = queue_hardening_scan(conn, hst, body.level, user)
                (queued if sid else skipped).append({"host_id": str(hst["id"]), "hostname": hst["hostname"],
                                                     "scan_id": sid, "reason": why})
            conn.execute(
                """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
                   VALUES (%s,'user','hardening_scan_requested','hardening',%s,%s,%s)""",
                (user, body.level, json.dumps({"queued": len(queued), "skipped": len(skipped)}),
                 client_ip(request)))
    return {"queued": queued, "skipped": skipped}


def _level(level):
    if level in HARDENING_LEVELS:
        return level
    if re.match(r"^custom:[0-9a-f-]{36}$", level or ""):
        return level
    raise HTTPException(422, "level must be l1, l2 or a custom profile")


@app.get("/api/v1/hardening/summary")
def hardening_summary(level: str = "l1", user: str = Depends(require_viewer)):
    _level(level)
    with db() as conn:
        latest = conn.execute("SELECT * FROM v_hardening_latest WHERE level=%s", (level,)).fetchall()
        hosts = conn.execute("SELECT id, os_id, os_version FROM hosts WHERE status <> 'decommissioned'").fetchall()
        content = conn.execute(
            """SELECT c.content_version, c.product, c.benchmark_version,
                      array_remove(array_agg(DISTINCT p.level), NULL) AS levels
                 FROM hardening_content c LEFT JOIN hardening_profiles p USING (content_version, product)
                WHERE c.active GROUP BY 1,2,3 ORDER BY 2""").fetchall()
        top = conn.execute(
            """SELECT r.rule_id, hr.title, hr.severity, hr.cis_ref, hr.risky, hr.fix_available,
                      count(*) AS servers
                 FROM v_hardening_latest l
                 JOIN hardening_results r ON r.scan_id = l.id AND r.result = 'fail'
                 LEFT JOIN hardening_rules hr ON hr.content_version = l.content_version
                      AND hr.product = l.product AND hr.rule_id = r.rule_id
                WHERE l.level = %s
                GROUP BY 1,2,3,4,5,6
                ORDER BY servers DESC,
                         CASE hr.severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 WHEN 'low' THEN 2 ELSE 3 END, 2
                LIMIT 15""", (level,)).fetchall()
        trend = conn.execute(
            """SELECT date_trunc('day', finished_at)::date AS day, round(avg(score), 1) AS score, count(*) AS scans
                 FROM hardening_scans WHERE level=%s AND state='done' AND finished_at > now() - interval '90 days'
                GROUP BY 1 ORDER BY 1""", (level,)).fetchall()
    have = {c["product"]: c for c in content}
    from . import hardening as hd
    custom = level.startswith("custom:")
    no_content = sum(1 for h in hosts
                     if not (hd.product_for(h["os_id"], h["os_version"]) in have
                             and (custom or level in (have[hd.product_for(h["os_id"], h["os_version"])]["levels"] or []))))
    scores = [float(x["score"]) for x in latest if x["score"] is not None]
    return {
        "level": level, "servers": len(hosts), "scanned": len(latest), "no_content": no_content,
        "fleet_score": round(sum(scores) / len(scores), 1) if scores else None,
        "failed_rules_total": sum(x["failed"] or 0 for x in latest),
        "bands": {"good": sum(1 for x in scores if x >= 85), "fair": sum(1 for x in scores if 70 <= x < 85),
                  "poor": sum(1 for x in scores if x < 70)},
        "content": content, "top_failing": top, "trend": trend,
    }


@app.get("/api/v1/hardening/hosts")
def hardening_hosts(level: str = "l1", user: str = Depends(require_viewer)):
    _level(level)
    from . import hardening as hd
    with db() as conn:
        rows = conn.execute(
            """SELECT h.id, h.hostname, h.os_id, h.os_version, h.host_group,
                      l.id AS scan_id, l.score, l.passed, l.failed, l.not_applicable, l.finished_at,
                      l.content_version, l.product,
                      n.state AS last_state, n.error AS last_error, n.requested_at AS last_requested,
                      n.stage, n.stage_at, n.progress_done, n.progress_total, n.agent_version,
                      (SELECT count(*) FROM hardening_results r
                         JOIN hardening_rules hr ON hr.content_version = l.content_version
                              AND hr.product = l.product AND hr.rule_id = r.rule_id
                        WHERE r.scan_id = l.id AND r.result = 'fail' AND hr.severity = 'high') AS high_failed
                 FROM hosts h
                 LEFT JOIN v_hardening_latest l ON l.host_id = h.id AND l.level = %s
                 LEFT JOIN LATERAL (SELECT s.state, s.error, s.requested_at, s.stage, s.stage_at,
                                           s.progress_done, s.progress_total, h.agent_version
                                      FROM hardening_scans s
                                     WHERE s.host_id = h.id AND s.level = %s
                                     ORDER BY requested_at DESC LIMIT 1) n ON TRUE
                WHERE h.status <> 'decommissioned'
                ORDER BY l.score NULLS LAST, h.hostname""", (level, level)).fetchall()
    for r in rows:
        r["product"] = r["product"] or hd.product_for(r["os_id"], r["os_version"])
        if r["last_state"] in ("queued", "running") and r["last_requested"]:
            from datetime import datetime, timezone, timedelta
            if datetime.now(timezone.utc) - r["last_requested"] > timedelta(hours=SCAN_STALE_HOURS):
                r["last_state"], r["last_error"] = "failed", "the agent did not pick the scan up in time"
    return {"level": level, "hosts": rows}


@app.get("/api/v1/hardening/hosts/{host_id}")
def hardening_host(host_id: str, level: str = "l1", user: str = Depends(require_viewer)):
    _level(level)
    with db() as conn:
        host = conn.execute("SELECT id, hostname, os_id, os_version, host_group FROM hosts WHERE id=%s",
                            (host_id,)).fetchone()
        if not host:
            raise HTTPException(404, "No such server.")
        scan = conn.execute("SELECT * FROM v_hardening_latest WHERE host_id=%s AND level=%s",
                            (host_id, level)).fetchone()
        results = []
        if scan:
            results = conn.execute(
                """SELECT r.rule_id, r.result, coalesce(hr.severity, r.severity) AS severity, hr.title,
                          hr.cis_ref, hr.description, hr.rationale, hr.fix_available, hr.risky
                     FROM hardening_results r
                     LEFT JOIN hardening_rules hr ON hr.content_version=%s AND hr.product=%s AND hr.rule_id=r.rule_id
                    WHERE r.scan_id=%s
                    ORDER BY CASE r.result WHEN 'fail' THEN 0 WHEN 'error' THEN 1 WHEN 'pass' THEN 3 ELSE 2 END,
                             CASE hr.severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 WHEN 'low' THEN 2 ELSE 3 END,
                             hr.cis_ref NULLS LAST, hr.title""",
                (scan["content_version"], scan["product"], scan["id"])).fetchall()
        history = conn.execute(
            """SELECT id, state, score, passed, failed, requested_at, finished_at, requested_by, error,
                      stage, stage_at, progress_done, progress_total
                 FROM hardening_scans WHERE host_id=%s AND level=%s ORDER BY requested_at DESC LIMIT 12""",
            (host_id, level)).fetchall()
    return {"host": host, "level": level, "scan": scan, "results": results, "history": history}


@app.get("/api/v1/hardening/rules/{rule_id}")
def hardening_rule(rule_id: str, level: str = "l1", user: str = Depends(require_viewer)):
    _level(level)
    with db() as conn:
        rule = conn.execute(
            """SELECT r.* FROM hardening_rules r JOIN hardening_content c USING (content_version, product)
                WHERE c.active AND r.rule_id=%s ORDER BY r.product LIMIT 1""", (rule_id,)).fetchone()
        if not rule:
            raise HTTPException(404, "No such rule in the active content.")
        servers = conn.execute(
            """SELECT l.host_id, l.hostname, l.product, l.finished_at, r.result
                 FROM v_hardening_latest l JOIN hardening_results r ON r.scan_id = l.id AND r.rule_id = %s
                WHERE l.level = %s
                ORDER BY CASE r.result WHEN 'fail' THEN 0 WHEN 'error' THEN 1 ELSE 2 END, l.hostname""",
            (rule_id, level)).fetchall()
    rule.pop("fix_script", None)
    return {"rule": rule, "level": level, "servers": servers}


# ---------------------------------------------------------------------------
# Custom hardening profiles (from an uploaded document)
# ---------------------------------------------------------------------------


@app.get("/api/v1/agent/hardening/tailoring/{name}")
def agent_tailoring(name: str, agent: AgentIdentity = Depends(require_agent)):
    from fastapi.responses import FileResponse
    from . import custom_profiles as cp
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,120}\.xml", name):
        raise HTTPException(404, "no such file")
    path = os.path.join(cp.TAILOR_DIR, name)
    if not os.path.exists(path):
        raise HTTPException(404, "no such file")
    return FileResponse(path, media_type="application/xml")


def _cp_view(conn, pid):
    from . import custom_profiles as cp
    prof = conn.execute("SELECT * FROM custom_profiles WHERE id=%s", (pid,)).fetchone()
    if not prof:
        raise HTTPException(404, "No such custom profile.")
    items = conn.execute("SELECT * FROM custom_profile_items WHERE profile_id=%s ORDER BY line_no", (pid,)).fetchall()
    ids = sorted({r for it in items for r in (it["rule_ids"] or [])})
    rules = {r["rule_id"]: r for r in conn.execute(
        """SELECT DISTINCT ON (r.rule_id) r.rule_id, r.title, r.cis_ref, r.severity FROM hardening_rules r
             JOIN hardening_content c USING (content_version, product)
            WHERE c.active AND r.product=%s AND r.rule_id = ANY(%s)""", (prof["product"], ids)).fetchall()}
    for it in items:
        it["rules"] = [rules.get(r, {"rule_id": r, "title": r.replace(cp.RULE_PREFIX, ""), "cis_ref": None,
                                     "severity": None}) for r in (it["rule_ids"] or [])]
    counts = {"lines": len(items), "checks": len(ids),
              "matched": sum(1 for it in items if it["rule_ids"]),
              "manual": sum(1 for it in items if not it["rule_ids"] and it["matched_by"] != "skipped"),
              "skipped": sum(1 for it in items if it["matched_by"] == "skipped"),
              "to_review": sum(1 for it in items if it["confidence"] in ("low", "medium") and it["matched_by"] in ("cis", "title", "ai"))}
    return {"profile": prof, "items": items, "counts": counts, "product_name": cp.PRODUCT_NAME.get(prof["product"], prof["product"])}


@app.get("/api/v1/hardening/custom")
def custom_list(user: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT p.*, (SELECT count(*) FROM custom_profile_items i WHERE i.profile_id = p.id) AS lines,
                      (SELECT count(*) FROM custom_profile_items i WHERE i.profile_id = p.id AND cardinality(i.rule_ids) > 0) AS matched
                 FROM custom_profiles p WHERE p.status <> 'retired' ORDER BY p.updated_at DESC""").fetchall()
    return {"profiles": rows}


@app.post("/api/v1/hardening/custom")
async def custom_create(request: Request, name: str = Form(...), product: str = Form("rhel9"),
                        description: str = Form(""), text: str = Form(""), file: Optional[UploadFile] = File(None),
                        user: str = Depends(require_operator)):
    from . import custom_profiles as cp
    name = name.strip()[:120]
    if not name:
        raise HTTPException(422, "Give the profile a name.")
    if not re.fullmatch(r"[a-z0-9]{2,20}", product):
        raise HTTPException(422, "Choose the benchmark the document follows.")
    if file is not None and file.filename:
        fn = file.filename
        if not fn.lower().endswith((".txt", ".csv", ".docx")):
            raise HTTPException(422, "Upload a .txt, .csv or .docx file.")
        data = await file.read()
        if len(data) > 5 * 1024 * 1024:
            raise HTTPException(413, "The file is over 5 MB.")
    elif text.strip():
        fn, data = "pasted.txt", text.encode()
    else:
        raise HTTPException(422, "Upload a file or paste the list.")
    with db() as conn:
        try:
            with conn.transaction():
                pid, counts = cp.build(conn, name, product, fn, data, user, description.strip() or None)
                conn.execute(
                    """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
                       VALUES (%s,'user','custom_profile_created','custom_profile',%s,%s,%s)""",
                    (user, pid, json.dumps({"name": name, "file": fn, **counts}), client_ip(request)))
        except ValueError as e:
            raise HTTPException(422, str(e))
    return {"id": pid, **counts}


@app.get("/api/v1/hardening/custom/{pid}")
def custom_get(pid: str, user: str = Depends(require_viewer)):
    with db() as conn:
        return _cp_view(conn, pid)


class CustomItemIn(BaseModel):
    rule_ids: Optional[List[str]] = None
    skip: Optional[bool] = None


@app.patch("/api/v1/hardening/custom/{pid}/items/{item_id}")
def custom_item_update(pid: str, item_id: int, body: CustomItemIn, user: str = Depends(require_operator)):
    with db() as conn:
        with conn.transaction():
            prof = conn.execute("SELECT status, product FROM custom_profiles WHERE id=%s", (pid,)).fetchone()
            if not prof:
                raise HTTPException(404, "No such custom profile.")
            if prof["status"] == "active":
                # Scans and reports refer to this version: edits make a new one
                raise HTTPException(409, "The profile is in use. Choose Edit (back to draft) first; that makes a new version.")
            if body.skip is not None:
                conn.execute("""UPDATE custom_profile_items SET rule_ids='{}', matched_by=%s, confidence=NULL, note=%s
                                 WHERE id=%s AND profile_id=%s""",
                             ("skipped" if body.skip else "none",
                              "Not part of the checks (a heading or note)." if body.skip else "Left as a manual check.",
                              item_id, pid))
            if body.rule_ids is not None:
                ok = {r["rule_id"] for r in conn.execute(
                    """SELECT r.rule_id FROM hardening_rules r JOIN hardening_content c USING (content_version, product)
                        WHERE c.active AND r.product=%s AND r.rule_id = ANY(%s)""", (prof["product"], body.rule_ids)).fetchall()}
                ids = [r for r in body.rule_ids if r in ok]
                conn.execute("""UPDATE custom_profile_items SET rule_ids=%s, matched_by=%s, confidence=%s, note=%s
                                 WHERE id=%s AND profile_id=%s""",
                             (ids, "manual" if ids else "none", "high" if ids else None,
                              f"Chosen by {user}." if ids else "Left as a manual check.", item_id, pid))
            conn.execute("UPDATE custom_profiles SET updated_by=%s, updated_at=now() WHERE id=%s", (user, pid))
        return _cp_view(conn, pid)


@app.post("/api/v1/hardening/custom/{pid}/items/{item_id}/suggest")
def custom_item_suggest(pid: str, item_id: int, user: str = Depends(require_operator)):
    from . import custom_profiles as cp
    with db() as conn:
        try:
            with conn.transaction():
                rule, note = cp.suggest(conn, pid, item_id)
        except ValueError as e:
            raise HTTPException(404, str(e))
        except Exception as e:  # noqa: BLE001 - AI-01 down is an answer, not a crash
            return {"ok": False, "note": f"AI-01 could not help: {str(e)[:140]}", "view": _cp_view(conn, pid)}
        return {"ok": bool(rule), "note": note, "view": _cp_view(conn, pid)}


@app.get("/api/v1/hardening/custom/{pid}/search")
def custom_search(pid: str, q: str = "", user: str = Depends(require_operator)):
    from . import custom_profiles as cp
    with db() as conn:
        prof = conn.execute("SELECT product FROM custom_profiles WHERE id=%s", (pid,)).fetchone()
        if not prof:
            raise HTTPException(404, "No such custom profile.")
        res = cp.search(conn, prof["product"], q)
    return {"rules": [{"rule_id": r["rule_id"], "title": r["title"], "cis_ref": r["cis"], "severity": r["severity"]}
                      for r in res]}


class CustomStateIn(BaseModel):
    status: str = Field(..., pattern="^(active|draft|retired)$")
    name: Optional[str] = Field(default=None, max_length=120)


@app.post("/api/v1/hardening/custom/{pid}/state")
def custom_state(pid: str, body: CustomStateIn, request: Request, user: str = Depends(require_operator)):
    with db() as conn:
        with conn.transaction():
            prof = conn.execute("SELECT * FROM custom_profiles WHERE id=%s", (pid,)).fetchone()
            if not prof:
                raise HTTPException(404, "No such custom profile.")
            if body.status == "active":
                n = conn.execute("SELECT count(*) AS n FROM custom_profile_items WHERE profile_id=%s AND cardinality(rule_ids) > 0",
                                 (pid,)).fetchone()["n"]
                if not n:
                    raise HTTPException(422, "Match at least one line to a check before using the profile.")
            bump = prof["status"] == "active" and body.status == "draft"
            conn.execute("""UPDATE custom_profiles SET status=%s, name=coalesce(%s, name), updated_by=%s, updated_at=now(),
                                   version = version + %s WHERE id=%s""",
                         (body.status, body.name, user, 1 if bump else 0, pid))
            conn.execute(
                """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
                   VALUES (%s,'user','custom_profile_state','custom_profile',%s,%s,%s)""",
                (user, pid, json.dumps({"status": body.status}), client_ip(request)))
        return _cp_view(conn, pid)
