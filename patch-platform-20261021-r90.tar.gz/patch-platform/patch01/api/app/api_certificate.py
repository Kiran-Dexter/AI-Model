"""PATCH-01's certificate.

Split out of main.py in r90; the code is unchanged."""

import json
import os
from fastapi import Depends, File, Form, HTTPException, Request, UploadFile
from pydantic import BaseModel, Field
from typing import Optional

from .core import (app, client_ip, db, require_admin)


# ---------------------------------------------------------------------------
# PATCH-01's certificate (admin): check uploads here; a root helper installs
# ---------------------------------------------------------------------------


def _host_names():
    fq = (os.environ.get("PATCH01_FQDN") or "").lower()
    short = (os.environ.get("PATCH01_SHORT") or (fq.split(".")[0] if fq else "")).lower()
    return short or "patch01.example", fq or short or "patch01.example"


@app.get("/api/v1/admin/certificate")
def cert_get(admin: str = Depends(require_admin)):
    from . import certs as cm
    try:
        cur = cm.served()
    except Exception as e:  # noqa: BLE001 - shown, not fatal
        cur = {"error": f"could not read the served certificate: {e}"}
    short, fq = _host_names()
    return {"served": cur, "status": cm.status(), "names": {"short": short, "fqdn": fq}}


@app.post("/api/v1/admin/certificate/check")
async def cert_check(request: Request, cert: Optional[UploadFile] = File(None), key: Optional[UploadFile] = File(None),
                     chain: Optional[UploadFile] = File(None), pfx: Optional[UploadFile] = File(None),
                     password: str = Form(""), admin: str = Depends(require_admin)):
    """Check an upload thoroughly. Nothing changes; a checked upload is kept for one hour."""
    from . import certs as cm
    async def read(f):
        if f is None or not f.filename:
            return None
        data = await f.read()
        if len(data) > 200_000:
            raise HTTPException(413, f"{f.filename} is too large for a certificate file.")
        return data
    try:
        leaf, k, others = cm.parse_upload(await read(cert), await read(key), await read(chain), await read(pfx),
                                          password or None)
        short, fq = _host_names()
        errors, warnings, ordered = cm.check(leaf, k, others, short, fq)
    except cm.CertError as e:
        return {"ok": False, "errors": [str(e)], "warnings": []}
    info = cm.describe(leaf)
    out = {"ok": not errors, "errors": errors, "warnings": warnings, "certificate": info,
           "chain": [cm.describe(c) for c in ordered]}
    if not errors:
        out["id"] = cm.stage(leaf, k, ordered, admin)
        try:
            old = cm.served()["pin"]
        except Exception:  # noqa: BLE001
            old = None
        out["pins"] = {"old": old, "new": info["pin"]}
    with db() as conn:
        conn.execute(
            """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
               VALUES (%s,'user','certificate_checked','certificate',%s,%s,%s)""",
            (admin, info["pin"][:16], json.dumps({"subject": info["subject"], "issuer": info["issuer"],
                                                  "ok": not errors, "errors": errors}), client_ip(request)))
        conn.commit()
    return out


class CertApplyIn(BaseModel):
    id: str = Field(..., pattern="^[0-9a-f]{16}$")
    windows_repinned: bool = False


@app.post("/api/v1/admin/certificate/apply")
def cert_apply(body: CertApplyIn, request: Request, admin: str = Depends(require_admin)):
    from . import certs as cm
    if not cm.status()["helper_ready"]:
        raise HTTPException(503, "The certificate helper is not installed on PATCH-01: run phase3b-api.sh.")
    try:
        req = cm.request_apply(body.id, admin)
    except cm.CertError as e:
        raise HTTPException(409, str(e))
    with db() as conn:
        conn.execute(
            """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
               VALUES (%s,'user','certificate_install_requested','certificate',%s,%s,%s)""",
            (admin, req["pin"][:16], json.dumps({"pin": req["pin"], "windows_repinned": body.windows_repinned}),
             client_ip(request)))
        conn.commit()
    return {"ok": True, "request": req["id"]}


@app.post("/api/v1/admin/certificate/rollback")
def cert_rollback(request: Request, admin: str = Depends(require_admin)):
    from . import certs as cm
    if not cm.status()["helper_ready"]:
        raise HTTPException(503, "The certificate helper is not installed on PATCH-01: run phase3b-api.sh.")
    try:
        req = cm.request_rollback(admin)
    except cm.CertError as e:
        raise HTTPException(409, str(e))
    with db() as conn:
        conn.execute(
            """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
               VALUES (%s,'user','certificate_rollback_requested','certificate','-','{}',%s)""",
            (admin, client_ip(request)))
        conn.commit()
    return {"ok": True, "request": req["id"]}
