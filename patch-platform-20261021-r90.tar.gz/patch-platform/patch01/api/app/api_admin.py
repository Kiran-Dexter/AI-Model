"""Servers and advisories (admin views), applicability, and AI-01's explanations.

Split out of main.py in r90; the code is unchanged."""

import secrets
from datetime import timedelta
from fastapi import Body, Depends, HTTPException, Request
from typing import Any, List, Optional

from .core import (ENROLL_TOKEN_TTL_HOURS, ONLINE_MINUTES, app, audit, client_ip, db, log, now, require_admin,
                   require_operator, require_viewer, sha256)


# ---------------------------------------------------------------------------
# Admin endpoints
# ---------------------------------------------------------------------------


@app.post("/api/v1/admin/enrollment-tokens")
def create_enrollment_token(
    request: Request,
    label: Optional[str] = Body(default=None),
    host_group: str = Body(default="default"),
    ttl_hours: int = Body(default=ENROLL_TOKEN_TTL_HOURS),
    admin: str = Depends(require_admin),
):
    """Issue a single-use enrollment token.

    Returned in full exactly once; only its hash is stored. A shared secret
    baked into an image would let any host that ever held it impersonate any
    other host indefinitely, which is why these expire and are single-use.
    """
    if not 1 <= ttl_hours <= 720:
        raise HTTPException(status_code=422, detail="ttl_hours must be 1..720")

    token = secrets.token_urlsafe(32)
    expires = now() + timedelta(hours=ttl_hours)

    with db() as conn:
        with conn.transaction():
            grp = conn.execute(
                "SELECT name FROM host_groups WHERE name=%s", (host_group,)
            ).fetchone()
            if not grp:
                raise HTTPException(
                    status_code=422,
                    detail=f"unknown host_group '{host_group}'",
                )
            row = conn.execute(
                """INSERT INTO enrollment_tokens
                     (token_hash, label, host_group, expires_at)
                   VALUES (%s,%s,%s,%s) RETURNING id""",
                (sha256(token), label, host_group, expires),
            ).fetchone()
            audit(conn, actor=admin, actor_type="user",
                  action="create_enrollment_token",
                  object_type="enrollment_token", object_id=str(row["id"]),
                  detail={"host_group": host_group, "ttl_hours": ttl_hours,
                          "label": label},
                  source_ip=client_ip(request))

    return {
        "id": str(row["id"]),
        "enrollment_token": token,
        "host_group": host_group,
        "expires_at": expires.isoformat(),
        "note": "shown once; only the hash is stored",
    }


@app.get("/api/v1/admin/hosts")
def list_hosts(status_filter: Optional[str] = None,
               os_id: Optional[str] = None,
               admin: str = Depends(require_viewer)):
    sql = """SELECT id, hostname, fqdn, os_id, os_version, arch, status,
                    kernel_running, reboot_required, host_group,
                    agent_version, last_checkin, last_inventory, enrolled_at
               FROM hosts WHERE TRUE"""
    params: List[Any] = []
    if status_filter:
        sql += " AND status = %s"
        params.append(status_filter)
    if os_id:
        sql += " AND os_id = %s"
        params.append(os_id)
    sql += " ORDER BY hostname"

    with db() as conn:
        rows = conn.execute(sql, params).fetchall()

    return {"count": len(rows), "hosts": [
        {**r, "id": str(r["id"])} for r in rows
    ]}


@app.get("/api/v1/admin/hosts/{host_id}")
def get_host(host_id: str, admin: str = Depends(require_viewer)):
    with db() as conn:
        host = conn.execute(
            """SELECT id, hostname, fqdn, machine_id, os_id, os_version,
                      os_major, arch, pkg_manager, kernel_running,
                      kernel_latest, reboot_required, reboot_reason,
                      agent_version, status, host_group, tags,
                      enrolled_at, last_checkin, last_inventory,
                      boot_time, host(agent_ip) AS agent_ip
                 FROM hosts WHERE id=%s""",
            (host_id,)).fetchone()
        if not host:
            raise HTTPException(status_code=404, detail="host not found")
        pkg_count = conn.execute(
            "SELECT count(*) AS n FROM host_packages WHERE host_id=%s",
            (host_id,)).fetchone()["n"]
        runs = conn.execute(
            """SELECT collected_at, package_count, ok, error
                 FROM inventory_runs WHERE host_id=%s
                ORDER BY collected_at DESC LIMIT 5""",
            (host_id,)).fetchall()

    return {
        "host": {**host, "id": str(host["id"])},
        "package_count": pkg_count,
        "recent_inventory_runs": runs,
    }


@app.get("/api/v1/admin/hosts/{host_id}/packages")
def get_host_packages(host_id: str, name: Optional[str] = None,
                      admin: str = Depends(require_viewer)):
    sql = """SELECT name, arch, epoch, version, release, full_nevra, from_repo
               FROM host_packages WHERE host_id=%s"""
    params: List[Any] = [host_id]
    if name:
        sql += " AND name ILIKE %s"
        params.append(f"%{name}%")
    sql += " ORDER BY name LIMIT 5000"

    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"count": len(rows), "packages": rows}


@app.get("/api/v1/admin/fleet-summary")
def fleet_summary(admin: str = Depends(require_viewer)):
    with db() as conn:
        summary = conn.execute("SELECT * FROM v_fleet_summary").fetchall()
        totals = conn.execute(
            """SELECT count(*) AS hosts,
                      count(*) FILTER (WHERE status='active')  AS active,
                      count(*) FILTER (WHERE status='stale')   AS stale,
                      count(*) FILTER (WHERE status='pending') AS pending,
                      count(*) FILTER (WHERE reboot_required)  AS awaiting_reboot
                 FROM hosts WHERE status <> 'decommissioned'"""
        ).fetchone()
    return {"totals": totals, "by_os": summary}


@app.post("/api/v1/admin/hosts/{host_id}/decommission")
def decommission(host_id: str, request: Request,
                 admin: str = Depends(require_admin)):
    """Retire a host. History is retained: the audit log has no foreign key
    to hosts precisely so decommissioning does not erase evidence."""
    with db() as conn:
        with conn.transaction():
            row = conn.execute(
                """UPDATE hosts
                      SET status='decommissioned', token_hash=NULL,
                          updated_at=now()
                    WHERE id=%s RETURNING hostname""",
                (host_id,),
            ).fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="host not found")
            # Revoking the token is the actual access removal
            conn.execute("DELETE FROM agent_commands WHERE host_id=%s",
                         (host_id,))
            audit(conn, actor=admin, actor_type="user", action="decommission",
                  host_id=host_id, detail={"hostname": row["hostname"]},
                  source_ip=client_ip(request))
    return {"ok": True, "hostname": row["hostname"]}


@app.get("/api/v1/admin/audit")
def get_audit(request: Request, limit: int = 100, host_id: Optional[str] = None,
              action: Optional[str] = None,
              admin: str = Depends(require_viewer)):
    limit = max(1, min(limit, 1000))
    sql = "SELECT * FROM audit_log WHERE TRUE"
    params: List[Any] = []
    is_admin = request.state.user.get("role") == "admin"
    if not is_admin:
        # Other users' questions, sign-ins and account changes are for admins only
        sql += (" AND action !~ '^(chat_|assistant_|login|logout|user_|password|session|feeds_|impact_|"
                "branding|mail_|certificate|credential|av_|report_schedule|2fa_)'")
    if host_id:
        sql += " AND host_id = %s"
        params.append(host_id)
    if action:
        sql += " AND action = %s"
        params.append(action)
    sql += " ORDER BY occurred_at DESC LIMIT %s"
    params.append(limit)

    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
    if not is_admin:
        for r in rows:
            r["source_ip"] = None
    return {"count": len(rows), "events": rows}


# ---------------------------------------------------------------------------
# Applicability (read-only; written by app.cve_engine)
# ---------------------------------------------------------------------------


@app.get("/api/v1/admin/hosts/{host_id}/advisories")
def host_advisories(host_id: str, state: Optional[str] = None,
                    admin: str = Depends(require_viewer)):
    valid = {"affected", "fixed_active", "fixed_pending_reboot", "unknown"}
    if state and state not in valid:
        raise HTTPException(status_code=422,
                            detail=f"state must be one of {sorted(valid)}")
    sql = """SELECT ha.advisory_id, ha.state, ha.fix_available,
                    ha.package_name, ha.installed_evr, ha.fixed_evr,
                    ha.reason, ha.computed_at,
                    a.severity, a.title, a.issued_at,
                    r.max_cvss, r.any_kev, r.max_epss, r.attack_classes,
                    r.cves_with_details,
                    array_agg(DISTINCT ac.cve_id) FILTER (WHERE ac.cve_id IS NOT NULL) AS cves
               FROM host_applicability ha
               JOIN advisories a ON a.id = ha.advisory_id
               LEFT JOIN advisory_cves ac ON ac.advisory_id = a.id
               LEFT JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id
              WHERE ha.host_id = %s"""
    params: List[Any] = [host_id]
    if state:
        sql += " AND ha.state = %s"
        params.append(state)
    sql += """ GROUP BY ha.advisory_id, ha.state, ha.fix_available, ha.package_name,
                        ha.installed_evr, ha.fixed_evr, ha.reason, ha.computed_at,
                        a.severity, a.title, a.issued_at,
                        r.max_cvss, r.any_kev, r.max_epss, r.attack_classes,
                        r.cves_with_details
               ORDER BY r.any_kev DESC NULLS LAST,
                        CASE ha.state WHEN 'affected' THEN 1
                          WHEN 'fixed_pending_reboot' THEN 2 WHEN 'unknown' THEN 3
                          ELSE 4 END,
                        CASE a.severity WHEN 'critical' THEN 1 WHEN 'important' THEN 2
                          WHEN 'moderate' THEN 3 ELSE 4 END,
                        a.issued_at DESC
               LIMIT 2000"""
    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"count": len(rows), "advisories": rows}


@app.get("/api/v1/admin/compliance")
def compliance(admin: str = Depends(require_viewer)):
    """One row per host with its verdict counts."""
    with db() as conn:
        rows = conn.execute(
            """SELECT v.host_id, v.hostname, v.os_id, v.os_major,
                      v.host_status, v.last_checkin,
                      v.affected, v.pending_reboot, v.remediated, v.unknown,
                      v.blocked_not_mirrored,
                      h.os_version, h.kernel_running, h.reboot_required,
                      h.host_group, h.last_inventory, h.boot_time,
                      agent_state(h.last_checkin, h.status, %s) AS agent_state
                 FROM v_compliance v JOIN hosts h ON h.id = v.host_id
                ORDER BY v.affected DESC, v.pending_reboot DESC, v.hostname""",
            (ONLINE_MINUTES,),
        ).fetchall()
    return {"count": len(rows), "hosts": rows, "online_minutes": ONLINE_MINUTES}


# ---------------------------------------------------------------------------
# Explanations from AI-01 (advisory only; the verdict is the CVE engine's)
# ---------------------------------------------------------------------------


@app.post("/api/v1/admin/hosts/{host_id}/advisories/{advisory_id}/explain")
def explain_verdict(host_id: str, advisory_id: str, request: Request,
                    admin: str = Depends(require_operator)):
    from . import llm
    try:
        return llm.explain_db(db, host_id, advisory_id, requested_by=admin)
    except llm.NotFound as e:
        raise HTTPException(status_code=404, detail=str(e))
    except llm.LLMBusy as e:
        raise HTTPException(status_code=429, detail=str(e))
    except llm.LLMUnavailable as e:
        log.warning("explain failed for %s: %s", advisory_id, e)
        raise HTTPException(status_code=503, detail=str(e))


@app.get("/api/v1/admin/llm/status")
def llm_status(admin: str = Depends(require_viewer)):
    from . import llm
    h = llm.health()
    with db() as conn:
        s = llm.stats(conn)
    return {**h, **s, "prompt_version": llm.PROMPT_VERSION,
            "model_tag": llm.AI01_MODEL_TAG}
