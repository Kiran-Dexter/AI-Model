"""Sign in, sign out, password, two-factor, and user management.

Split out of main.py in r90; the code is unchanged."""

import psycopg
import secrets
from datetime import datetime, timezone
from fastapi import Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field
from typing import List, Optional

from .core import (ASSET_PERMS, _asset_perms, app, audit, client_ip, db, require_admin, require_viewer)


# ---------------------------------------------------------------------------
# Sign in, sign out, password
# ---------------------------------------------------------------------------


class LoginIn(BaseModel):
    username: str = Field(..., max_length=64)
    password: str = Field(..., max_length=256)


@app.post("/api/v1/auth/login")
def login(body: LoginIn, request: Request):
    from . import auth
    ip = client_ip(request)
    with db() as conn:
        try:
            u = auth.authenticate(conn, body.username, body.password)
        except auth.LoginError as e:
            conn.commit()   # keep the failed-attempt count even though we refuse
            audit(conn, actor=(body.username or "")[:64] or "unknown", actor_type="user",
                  action="login_failed", detail={}, source_ip=ip)
            conn.commit()
            raise HTTPException(status_code=401, detail=str(e))
        if u.get("totp_enabled"):
            # The password was right; the session is only made once the code is right too
            from . import mfa
            ticket = secrets.token_urlsafe(32)
            conn.execute("DELETE FROM user_mfa_challenges WHERE user_id=%s OR expires_at < now()", (u["id"],))
            conn.execute("""INSERT INTO user_mfa_challenges (token_hash, user_id, expires_at, source_ip)
                            VALUES (%s, %s, now() + make_interval(mins => %s), %s::inet)""",
                         (mfa.ticket_hash(ticket), u["id"], mfa.TICKET_MINUTES, ip))
            audit(conn, actor=u["username"], actor_type="user", action="login_password_ok",
                  detail={"second_factor": "pending"}, source_ip=ip)
            return {"mfa_required": True, "mfa_ticket": ticket}
        return _login_ok(conn, u, request, ip)


def _login_ok(conn, u, request, ip, how="password"):
    from . import auth, mfa
    token = auth.new_session(conn, u["id"], ip, request.headers.get("user-agent"))
    audit(conn, actor=u["username"], actor_type="user", action="login",
          detail={"role": u["role"], "factors": how}, source_ip=ip)
    return {"token": token, "user": {"username": u["username"], "role": u["role"],
            "display_name": u["display_name"],
            "must_change_password": u["must_change_password"],
            "totp_enabled": bool(u.get("totp_enabled")),
            "must_setup_2fa": bool(mfa.REQUIRE_2FA and not u.get("totp_enabled")),
            "modules": auth.user_modules(u)}}


class MfaLoginIn(BaseModel):
    mfa_ticket: str = Field(..., min_length=20, max_length=100)
    code: str = Field(..., min_length=6, max_length=20)


@app.post("/api/v1/auth/login/2fa")
def login_second_factor(body: MfaLoginIn, request: Request):
    """The authenticator code (or a recovery code) after a correct password."""
    from . import auth, mfa
    ip = client_ip(request)
    with db() as conn:
        ch = conn.execute(
            """UPDATE user_mfa_challenges SET attempts = attempts + 1
                WHERE token_hash = %s AND expires_at > now() AND attempts < %s
            RETURNING user_id""", (mfa.ticket_hash(body.mfa_ticket), mfa.TICKET_TRIES)).fetchone()
        if not ch:
            conn.commit()
            raise HTTPException(401, "This sign-in has expired or had too many wrong codes. Sign in again.")
        u = conn.execute(
            """SELECT id, username, role::text AS role, display_name, active, must_change_password, modules,
                      totp_enabled, totp_secret_enc, totp_last_step, totp_recovery, locked_until
                 FROM users WHERE id = %s""", (ch["user_id"],)).fetchone()
        if not u or not u["active"] or not u["totp_enabled"] or not u["totp_secret_enc"] \
                or (u["locked_until"] and u["locked_until"] > datetime.now(timezone.utc)):
            conn.commit()
            raise HTTPException(401, "That sign-in is not possible now. Sign in again, or ask an admin.")
        how = None
        try:
            step = mfa.check(mfa.decrypt(u["totp_secret_enc"]), body.code, u["totp_last_step"])
        except mfa.MfaError as e:
            conn.commit()
            raise HTTPException(503, str(e))
        if step is not None:
            # Atomic: two sign-ins racing with the same code cannot both use it
            if conn.execute("""UPDATE users SET totp_last_step=%s WHERE id=%s
                                 AND (totp_last_step IS NULL OR totp_last_step < %s) RETURNING id""",
                            (step, u["id"], step)).fetchone():
                how = "password+totp"
        else:
            rc = mfa.norm_recovery(body.code)
            if rc:
                left = list(u["totp_recovery"] or [])
                for i, hsh in enumerate(left):
                    if auth.verify_password(rc, hsh):
                        left.pop(i)
                        if conn.execute("""UPDATE users SET totp_recovery=array_remove(totp_recovery, %s)
                                            WHERE id=%s AND %s = ANY(totp_recovery) RETURNING id""",
                                        (hsh, u["id"], hsh)).fetchone():
                            how = "password+recovery_code"
                        break
        if not how:
            auth.count_failure(conn, u["id"])
            audit(conn, actor=u["username"], actor_type="user", action="login_failed",
                  detail={"second_factor": "wrong code"}, source_ip=ip)
            conn.commit()
            raise HTTPException(401, "That code was not accepted. Check the time on your phone, and use the newest code.")
        conn.execute("DELETE FROM user_mfa_challenges WHERE user_id=%s", (u["id"],))
        conn.execute("UPDATE users SET failed_logins=0, locked_until=NULL, last_login_at=now() WHERE id=%s", (u["id"],))
        out = _login_ok(conn, dict(u), request, ip, how)
        if how == "password+recovery_code":
            out["recovery_codes_left"] = len(left)
        return out


class MfaSetupIn(BaseModel):
    password: str = Field(..., max_length=256)


class MfaCodeIn(BaseModel):
    code: str = Field(..., min_length=6, max_length=20)
    password: Optional[str] = Field(default=None, max_length=256)


def _me_row(conn, username):
    return conn.execute(
        """SELECT id, username, password_hash, totp_enabled, totp_secret_enc, totp_pending_enc,
                  totp_last_step, totp_recovery, totp_enabled_at
             FROM users WHERE username = %s""", (username,)).fetchone()


@app.get("/api/v1/auth/2fa")
def mfa_status(user: str = Depends(require_viewer)):
    from . import mfa
    with db() as conn:
        r = _me_row(conn, user)
    return {"enabled": bool(r and r["totp_enabled"]), "enabled_at": r and r["totp_enabled_at"],
            "recovery_codes_left": len((r or {}).get("totp_recovery") or []) if r and r["totp_enabled"] else 0,
            "required": mfa.REQUIRE_2FA, "available": mfa.available()}


@app.post("/api/v1/auth/2fa/setup")
def mfa_setup(body: MfaSetupIn, request: Request, response: Response, user: str = Depends(require_viewer)):
    """A new secret, waiting for its first code. The password is asked again."""
    from . import auth, mfa, qrsvg
    with db() as conn:
        r = _me_row(conn, user)
        if not r or not auth.verify_password(body.password or "", r["password_hash"]):
            if r:
                auth.count_failure(conn, r["id"])
                conn.commit()
            raise HTTPException(401, "Your password was not accepted.")
        if r["totp_enabled"]:
            raise HTTPException(409, "Two-factor sign-in is already on. Turn it off first to set up a new phone.")
        secret = mfa.new_secret()
        try:
            conn.execute("UPDATE users SET totp_pending_enc=%s, totp_setup_fails=0 WHERE id=%s", (mfa.encrypt(secret), r["id"]))
        except mfa.MfaError as e:
            raise HTTPException(503, str(e))
        audit(conn, actor=user, actor_type="user", action="2fa_setup_started", detail={}, source_ip=client_ip(request))
    link = mfa.uri(user, secret)
    response.headers["Cache-Control"] = "no-store"
    return {"secret": secret, "uri": link, "qr_svg": qrsvg.svg(link)}


def _end_other_sessions(conn, request, uid):
    from . import auth
    header = request.headers.get("authorization") or ""
    keep = header[7:].strip() if header.lower().startswith("bearer ") else ""
    conn.execute("DELETE FROM user_sessions WHERE user_id=%s AND token_hash <> %s", (uid, auth._token_hash(keep)))


@app.post("/api/v1/auth/2fa/enable")
def mfa_enable(body: MfaCodeIn, request: Request, user: str = Depends(require_viewer)):
    """The first code from the app proves it is set up; recovery codes are shown once."""
    from . import auth, mfa
    with db() as conn:
        r = _me_row(conn, user)
        if not r or not r["totp_pending_enc"]:
            raise HTTPException(409, "Start the setup first.")
        try:
            secret = mfa.decrypt(r["totp_pending_enc"])
        except mfa.MfaError as e:
            raise HTTPException(503, str(e))
        step = mfa.check(secret, body.code)
        if step is None:
            # Guessing is bounded: after 10 wrong codes the setup starts again with a new secret
            n = conn.execute("""UPDATE users SET totp_setup_fails = totp_setup_fails + 1 WHERE id=%s
                                RETURNING totp_setup_fails""", (r["id"],)).fetchone()["totp_setup_fails"]
            if n >= 10:
                conn.execute("UPDATE users SET totp_pending_enc=NULL, totp_setup_fails=0 WHERE id=%s", (r["id"],))
            conn.commit()                          # kept although the request fails
            if n >= 10:
                raise HTTPException(422, "Too many wrong codes: start the setup again.")
            raise HTTPException(422, "That code was not accepted. Check the time on your phone, and use the newest code.")
        codes = mfa.new_recovery_codes()
        conn.execute("""UPDATE users SET totp_secret_enc=totp_pending_enc, totp_pending_enc=NULL, totp_enabled=TRUE,
                               totp_last_step=%s, totp_recovery=%s, totp_enabled_at=now(), totp_setup_fails=0
                         WHERE id=%s""",
                     (step, [auth.hash_password(mfa.norm_recovery(c)) for c in codes], r["id"]))
        # M2: other sessions end - turning this on is often a response to a leak
        _end_other_sessions(conn, request, r["id"])
        audit(conn, actor=user, actor_type="user", action="2fa_enabled", detail={}, source_ip=client_ip(request))
    return {"enabled": True, "recovery_codes": codes}


@app.post("/api/v1/auth/2fa/disable")
def mfa_disable(body: MfaCodeIn, request: Request, user: str = Depends(require_viewer)):
    from . import auth, mfa
    if mfa.REQUIRE_2FA:
        raise HTTPException(409, "Two-factor sign-in is required for every account here; an admin can reset it.")
    with db() as conn:
        r = _me_row(conn, user)
        if not r or not r["totp_enabled"]:
            raise HTTPException(409, "Two-factor sign-in is not on.")
        # The same lock as sign-in: after too many wrong passwords or codes, no more guesses here either
        if conn.execute("SELECT 1 FROM users WHERE id=%s AND locked_until > now()", (r["id"],)).fetchone():
            raise HTTPException(423, "Too many failed attempts: the account is locked for a while. Try again later.")
        if not auth.verify_password(body.password or "", r["password_hash"]):
            auth.count_failure(conn, r["id"])
            conn.commit()                       # kept: the request then fails
            raise HTTPException(401, "Your password was not accepted.")
        try:
            ok = mfa.check(mfa.decrypt(r["totp_secret_enc"]), body.code, r["totp_last_step"]) is not None
        except mfa.MfaError as e:
            raise HTTPException(503, str(e))
        if not ok:
            auth.count_failure(conn, r["id"])
            conn.commit()
            raise HTTPException(422, "That code was not accepted.")
        conn.execute("""UPDATE users SET totp_enabled=FALSE, totp_secret_enc=NULL, totp_pending_enc=NULL,
                               totp_last_step=NULL, totp_recovery='{}', totp_enabled_at=NULL WHERE id=%s""", (r["id"],))
        _end_other_sessions(conn, request, r["id"])
        audit(conn, actor=user, actor_type="user", action="2fa_disabled", detail={}, source_ip=client_ip(request))
    return {"enabled": False}


@app.post("/api/v1/auth/logout")
def logout(request: Request, user: str = Depends(require_viewer)):
    from . import auth
    header = request.headers.get("authorization") or ""
    if header.lower().startswith("bearer "):
        with db() as conn:
            auth.end_session(conn, header[7:].strip())
    return {"ok": True}


@app.get("/api/v1/auth/me")
def whoami(request: Request, user: str = Depends(require_viewer)):
    from . import auth
    u = request.state.user
    from . import mfa
    return {"username": u["username"], "role": u["role"],
            "display_name": u.get("display_name"),
            "must_change_password": u.get("must_change_password", False),
            "totp_enabled": bool(u.get("totp_enabled")),
            "must_setup_2fa": bool(mfa.REQUIRE_2FA and not u.get("totp_enabled")),
            "modules": auth.user_modules(u), "asset_perms": _asset_perms_me(u)}


def _asset_perms_me(u):
    with db() as conn:
        return _asset_perms(conn, u)


class PasswordIn(BaseModel):
    current_password: str = Field(..., max_length=256)
    new_password: str = Field(..., max_length=256)


@app.post("/api/v1/auth/password")
def change_password(body: PasswordIn, request: Request, user: str = Depends(require_viewer)):
    from . import auth
    with db() as conn:
        try:
            auth.authenticate(conn, user, body.current_password)
        except auth.LoginError:
            conn.commit()                          # the failure count is kept (account lock)
            raise HTTPException(status_code=401, detail="The current password is not correct.")
        problem = auth.password_problem(body.new_password, user)
        if problem:
            raise HTTPException(status_code=422, detail=problem)
        uid = request.state.user["id"]
        conn.execute("""UPDATE users SET password_hash=%s, must_change_password=FALSE,
                               password_changed_at=now() WHERE id=%s""",
                     (auth.hash_password(body.new_password), uid))
        # Other sessions end: a password change is often a response to a leak
        header = request.headers.get("authorization") or ""
        keep = header[7:].strip() if header.lower().startswith("bearer ") else ""
        # Without a bearer token (HTTP Basic, scripts) every session ends
        conn.execute("DELETE FROM user_sessions WHERE user_id=%s AND token_hash <> %s",
                     (uid, auth._token_hash(keep)))
        conn.execute("DELETE FROM user_mfa_challenges WHERE user_id=%s", (uid,))
        audit(conn, actor=user, actor_type="user", action="password_changed",
              detail={}, source_ip=client_ip(request))
    return {"ok": True}


# ---------------------------------------------------------------------------
# User management (admin)
# ---------------------------------------------------------------------------


class UserIn(BaseModel):
    username: str = Field(..., max_length=64)
    display_name: Optional[str] = Field(default=None, max_length=120)
    role: str
    password: str = Field(..., max_length=256)
    modules: List[str] = Field(default_factory=list, max_length=3)    # none until an admin grants them


class UserPatch(BaseModel):
    display_name: Optional[str] = Field(default=None, max_length=120)
    role: Optional[str] = None
    active: Optional[bool] = None
    new_password: Optional[str] = Field(default=None, max_length=256)
    unlock: Optional[bool] = None
    reset_2fa: Optional[bool] = None
    modules: Optional[List[str]] = Field(default=None, max_length=3)
    asset_perms: Optional[List[str]] = Field(default=None, max_length=3)


def _active_admins(conn, excluding=None):
    return conn.execute(
        "SELECT count(*) AS n FROM users WHERE role='admin' AND active AND username <> %s",
        (excluding or "",)).fetchone()["n"]


@app.get("/api/v1/admin/users")
def list_users(user: str = Depends(require_admin)):
    with db() as conn:
        perms = {}
        try:
            with conn.transaction():
                perms = {r["username"]: r["asset_perms"] for r in conn.execute("SELECT username, asset_perms FROM users").fetchall()}
        except psycopg.errors.UndefinedColumn:
            pass
        rows = conn.execute(
            """SELECT username, display_name, role::text AS role, active, must_change_password, modules,
                      coalesce((to_jsonb(u) ->> 'totp_enabled')::boolean, false) AS totp_enabled,
                      locked_until > now() AS locked, created_at, created_by, last_login_at,
                      password_changed_at,
                      (SELECT count(*) FROM user_sessions s
                        WHERE s.user_id = u.id AND s.expires_at > now()) AS sessions
                 FROM users u ORDER BY role DESC, username""").fetchall()
    rows = [{**dict(r), "asset_perms": perms.get(r["username"]) or []} for r in rows]
    return {"count": len(rows), "users": rows, "asset_perms_installed": bool(perms) or not rows}


@app.post("/api/v1/admin/users")
def create_user(body: UserIn, request: Request, user: str = Depends(require_admin)):
    from . import auth
    name = body.username.strip().lower()
    if not auth.USERNAME_RE.match(name):
        raise HTTPException(status_code=422,
                            detail="Usernames are 2 to 63 lowercase letters, digits, dots, dashes or underscores.")
    if body.role not in auth.ROLES:
        raise HTTPException(status_code=422, detail="Role must be viewer, operator or admin.")
    problem = auth.password_problem(body.password, name)
    if problem:
        raise HTTPException(status_code=422, detail=problem)
    mods = sorted(set(body.modules))
    if any(m not in auth.MODULES for m in mods):
        raise HTTPException(status_code=422, detail="Modules are patch, inventory and lifecycle.")
    with db() as conn:
        if conn.execute("SELECT 1 FROM users WHERE username=%s", (name,)).fetchone():
            raise HTTPException(status_code=409, detail="That username is taken.")
        # A password an admin chose is known to the admin: the user changes it
        conn.execute(
            """INSERT INTO users (username, display_name, role, password_hash,
                                  must_change_password, created_by, modules)
               VALUES (%s, %s, %s, %s, TRUE, %s, %s)""",
            (name, (body.display_name or "").strip() or None, body.role,
             auth.hash_password(body.password), user, mods))
        audit(conn, actor=user, actor_type="user", action="user_created",
              object_type="user", object_id=name, detail={"role": body.role, "modules": mods},
              source_ip=client_ip(request))
    return {"ok": True, "username": name}


@app.patch("/api/v1/admin/users/{username}")
def update_user(username: str, body: UserPatch, request: Request,
                user: str = Depends(require_admin)):
    from . import auth
    with db() as conn:
        row = conn.execute("SELECT id, role::text AS role, active FROM users WHERE username=%s",
                           (username,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="No such user.")
        # Never leave the platform without an active admin
        losing_admin = row["role"] == "admin" and (
            (body.role is not None and body.role != "admin") or body.active is False)
        if losing_admin and _active_admins(conn, excluding=username) == 0:
            raise HTTPException(status_code=409,
                                detail="This is the last active admin. Make someone else an admin first.")
        changes = {}
        if body.role is not None:
            if body.role not in auth.ROLES:
                raise HTTPException(status_code=422, detail="Role must be viewer, operator or admin.")
            conn.execute("UPDATE users SET role=%s WHERE id=%s", (body.role, row["id"]))
            changes["role"] = body.role
            if row["role"] == "admin" and body.role != "admin" and body.modules is None:
                # A former admin starts with no modules; an admin grants them under Access
                conn.execute("UPDATE users SET modules='{}' WHERE id=%s", (row["id"],))
                changes["modules"] = []
        if body.display_name is not None:
            conn.execute("UPDATE users SET display_name=%s WHERE id=%s",
                         (body.display_name.strip() or None, row["id"]))
            changes["display_name"] = True
        if body.active is not None:
            conn.execute("UPDATE users SET active=%s WHERE id=%s", (body.active, row["id"]))
            if not body.active:
                auth.end_all_sessions(conn, row["id"])
            changes["active"] = body.active
        if body.new_password:
            problem = auth.password_problem(body.new_password, username)
            if problem:
                raise HTTPException(status_code=422, detail=problem)
            conn.execute("""UPDATE users SET password_hash=%s, must_change_password=TRUE,
                                   password_changed_at=now(), failed_logins=0, locked_until=NULL
                             WHERE id=%s""", (auth.hash_password(body.new_password), row["id"]))
            auth.end_all_sessions(conn, row["id"])
            changes["password_reset"] = True
        if body.unlock:
            conn.execute("UPDATE users SET failed_logins=0, locked_until=NULL WHERE id=%s", (row["id"],))
            changes["unlocked"] = True
        if body.reset_2fa:
            # A lost phone: two-factor sign-in is switched off and every session ends; the user sets it up again
            conn.execute("""UPDATE users SET totp_enabled=FALSE, totp_secret_enc=NULL, totp_pending_enc=NULL,
                                   totp_last_step=NULL, totp_recovery='{}', totp_enabled_at=NULL WHERE id=%s""", (row["id"],))
            conn.execute("DELETE FROM user_mfa_challenges WHERE user_id=%s", (row["id"],))
            auth.end_all_sessions(conn, row["id"])
            changes["2fa_reset"] = True
        if body.modules is not None:
            mods = sorted(set(body.modules))
            if any(m not in auth.MODULES for m in mods):
                raise HTTPException(status_code=422, detail="Modules are patch, inventory and lifecycle.")
            conn.execute("UPDATE users SET modules=%s WHERE id=%s", (mods, row["id"]))
            changes["modules"] = mods
        if body.asset_perms is not None:
            perms = sorted(set(body.asset_perms))
            if any(p not in ASSET_PERMS for p in perms):
                raise HTTPException(status_code=422, detail="Asset permissions are approve, decom and revoke.")
            try:
                with conn.transaction():
                    conn.execute("UPDATE users SET asset_perms=%s WHERE id=%s", (perms, row["id"]))
            except psycopg.errors.UndefinedColumn:
                raise HTTPException(503, "Asset permissions are not installed yet: run phase3a-schema.sh.")
            changes["asset_perms"] = perms
        audit(conn, actor=user, actor_type="user", action="user_updated",
              object_type="user", object_id=username, detail=changes,
              source_ip=client_ip(request))
        stored = conn.execute("SELECT modules FROM users WHERE id=%s", (row["id"],)).fetchone()
        stored_perms = changes.get("asset_perms")
    return {"ok": True, "changed": changes, "modules": (stored or {}).get("modules"), "asset_perms": stored_perms}
