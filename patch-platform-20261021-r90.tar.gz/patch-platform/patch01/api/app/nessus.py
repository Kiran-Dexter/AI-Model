"""Nessus: the scanners' scans, their results and their reports, from PATCH-01.

PATCH-01 talks to Nessus's REST API over HTTPS with an API key pair (Nessus:
Settings > My Account > API Keys). The keys are encrypted with av.key before
they are stored, decrypted only in memory for a request, and never returned to
the browser or written to a log. The certificate Nessus presents is pinned
(its SHA-256 compared right after the handshake) unless it is publicly trusted.

What each product allows:
  Nessus Professional  read scans and results, export reports. Tenable does not
                       let outside tools start, stop, create or edit scans
                       ("API is not available"); PATCH-01 says so and offers
                       the scan's page in Nessus instead.
  Nessus Manager       all of the above, and start, pause, resume, stop,
                       create and edit scans.

Results are imported from the .nessus export of each scan's newest finished
run: parsed as a stream with defusedxml (no entities, no DTD), bounded in size,
one row per host, plugin and port from low severity up.
"""

import ipaddress
import io
import json
import logging
import re
import time
import urllib.parse
from datetime import datetime, timezone

log = logging.getLogger("patchapi.nessus")

TIMEOUT = 30
DEADLINE = 120
MAX_JSON = 64 * 2 ** 20
MAX_EXPORT = 1024 * 2 ** 20           # a .nessus or a report passed through
SYNC_MINUTES = 15
EXPORT_WAIT = 900                     # the worker waits this long for a .nessus export
NAME_RE = re.compile(r"^[A-Za-z0-9 ._()-]{1,60}$")
KEY_RE = re.compile(r"^[0-9a-f]{64}$")
TARGET_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9.:/_-]{0,252}$")
SCAN_NAME_RE = re.compile(r"^[A-Za-z0-9 ._()/:+-]{1,100}$")
FORMATS = ("pdf", "html", "csv", "nessus")
ACTIONS = ("launch", "pause", "resume", "stop")
SEVERITY = {0: "Info", 1: "Low", 2: "Medium", 3: "High", 4: "Critical"}
CVE_RE = re.compile(r"^CVE-\d{4}-\d{4,7}$")
NOT_ALLOWED = re.compile(r"api is not available|not available.*(license|professional)|license.*(not|does not).*allow", re.I)
PRO_TEXT = re.compile(r"professional|\bpro\b|essentials|home|expert", re.I)
MANAGER_TEXT = re.compile(r"manager", re.I)


class NessusError(RuntimeError):
    """A problem worth showing as it is."""


class NotAllowed(NessusError):
    """Nessus refuses this kind of request from outside tools (Nessus Professional)."""


def _av():
    from . import antivirus
    return antivirus


def _say(e):
    """The antivirus helpers' wording, for Nessus."""
    return NessusError(str(e).replace("an Apex Central console", "a Nessus scanner").replace("Apex Central", "Nessus")
                       .replace("the console's", "Nessus's").replace("The console's", "Nessus's")
                       .replace("the console", "Nessus").replace("The console", "Nessus")
                       .replace("antivirus key av.key", "secrets key av.key"))


# ---------------------------------------------------------------------------
# Checking what an admin types
# ---------------------------------------------------------------------------

def clean_url(url):
    av = _av()
    try:
        return av.clean_url(url)
    except av.AvError as e:
        raise _say(e)


def clean_key(v, what):
    v = (v or "").strip().lower()
    if not KEY_RE.match(v):
        raise NessusError(f"The {what} is 64 hexadecimal characters: copy it again from Nessus (Settings > My Account > API Keys).")
    return v


def clean_pin(v):
    av = _av()
    try:
        return av.clean_pin(v)
    except av.AvError as e:
        raise _say(e)


def encrypt(v):
    av = _av()
    try:
        return av.encrypt(v)
    except av.AvError as e:
        raise _say(e)


def decrypt(v):
    av = _av()
    try:
        return av.decrypt(v)
    except av.AvError as e:
        raise _say(e)


def clean_targets(text):
    """Host names, addresses and ranges (10.0.0.0/24, 10.0.0.1-10.0.0.20), one list."""
    parts = [p.strip() for p in re.split(r"[\s,;]+", text or "") if p.strip()]
    if not parts:
        raise NessusError("Enter at least one target: a host name, an address or a range.")
    if len(parts) > 2000:
        raise NessusError("At most 2000 targets in one scan.")
    bad = [p for p in parts if not TARGET_RE.match(p) or ".." in p]
    if bad:
        raise NessusError("These targets are not host names, addresses or ranges: " + ", ".join(b[:40] for b in bad[:5]))
    seen, out = set(), []
    for p in parts:
        if p.lower() not in seen:
            seen.add(p.lower())
            out.append(p)
    return out


# ---------------------------------------------------------------------------
# Requests
# ---------------------------------------------------------------------------

def _keys(server):
    return decrypt(server["access_key_enc"]), decrypt(server["secret_key_enc"])


def _open(server, method, path, body=None, keys=None):
    """(connection, response) for one request; the caller reads and closes."""
    av = _av()
    u = urllib.parse.urlsplit(clean_url(server["url"]))
    host, port = u.hostname, u.port or 443
    ak, sk = keys or _keys(server)
    headers = {"X-ApiKeys": f"accessKey={ak}; secretKey={sk}", "Accept": "application/json",
               "User-Agent": "PATCH-01", "Host": u.netloc}
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
    try:
        ctx = av._context({"pin_sha256": server.get("pin_sha256"), "ca_pem": None})
        conn = av._connection({"pin_sha256": server.get("pin_sha256"), "use_proxy": False}, host, port, ctx)
        conn.request(method, path, body=data, headers=headers)
        r = conn.getresponse()
    except av.AvError as e:
        raise _say(e)
    except Exception as e:  # noqa: BLE001 - one plain message
        log.info("nessus: %s: %s", server.get("url"), type(e).__name__)
        raise _say(av.AvError(av._fail_text(e)))
    finally:
        ak = sk = None
        headers = None
    return conn, r


def _error(r, raw):
    try:
        msg = str((json.loads(raw.decode("utf-8", "replace")) or {}).get("error") or "")[:200]
    except Exception:  # noqa: BLE001
        msg = ""
    if NOT_ALLOWED.search(msg):
        raise NotAllowed("Nessus refuses this from outside tools (“API is not available”): Nessus Professional only "
                         "allows reading scans and exporting reports. Do it in Nessus.")
    if r.status == 401:
        raise NessusError("Nessus refused the API keys (401): check them, and that the account is not disabled.")
    if r.status == 403:
        raise NessusError("Nessus refused the request (403): the account behind the API keys may not do this.")
    if r.status == 404:
        raise NessusError("Nessus has no such scan or file (404): it may have been deleted in Nessus.")
    if r.status in (301, 302, 303, 307, 308):
        raise NessusError(f"Nessus answered with a redirect ({r.status}): use its own https address and port (usually 8834).")
    safe = re.sub(r"[^A-Za-z0-9 .,:;()'_/-]", "", msg)[:160]
    raise NessusError(f"Nessus answered HTTP {r.status}" + (f": {safe}" if safe else "") + ".")


def call(server, method, path, body=None, keys=None):
    """One JSON request. Returns the parsed answer ({} when Nessus sends none)."""
    deadline = time.monotonic() + DEADLINE
    conn, r = _open(server, method, path, body, keys)
    try:
        chunks, size = [], 0
        while True:
            if time.monotonic() > deadline:
                raise NessusError(f"Nessus took longer than {DEADLINE} seconds to answer.")
            b = r.read(65536)
            if not b:
                break
            size += len(b)
            if size > MAX_JSON:
                raise NessusError("Nessus's answer is too large.")
            chunks.append(b)
        raw = b"".join(chunks)
        if not 200 <= r.status < 300:
            _error(r, raw)
    except (NessusError, NotAllowed):
        raise
    except Exception as e:  # noqa: BLE001
        raise _say(_av().AvError(_av()._fail_text(e)))
    finally:
        conn.close()
    if not raw.strip():
        return {}
    try:
        doc = json.loads(raw.decode("utf-8-sig"))
    except Exception:  # noqa: BLE001
        raise NessusError("Nessus's answer is not JSON: check the address points at Nessus (usually port 8834).")
    return doc if isinstance(doc, dict) else {"items": doc}


class _Limited(io.RawIOBase):
    """A response read in pieces, refused past MAX_EXPORT bytes."""

    def __init__(self, r, limit=MAX_EXPORT):
        self.r, self.left = r, limit

    def readable(self):
        return True

    def readinto(self, b):
        n = self.r.readinto(b)
        if n:
            self.left -= n
            if self.left < 0:
                raise NessusError("The file from Nessus is larger than " + str(MAX_EXPORT // 2 ** 20) + " MB.")
        return n


def stream(server, path):
    """(connection, file-like, length, content type, file name) of a download; the caller closes."""
    conn, r = _open(server, "GET", path)
    if not 200 <= r.status < 300:
        raw = r.read(65536)
        conn.close()
        _error(r, raw)
    length = r.getheader("Content-Length")
    if length and length.isdigit() and int(length) > MAX_EXPORT:
        conn.close()
        raise NessusError("The file from Nessus is larger than " + str(MAX_EXPORT // 2 ** 20) + " MB.")
    disp = r.getheader("Content-Disposition") or ""
    m = re.search(r'filename="?([A-Za-z0-9 ._()-]{1,120})"?', disp)
    return conn, io.BufferedReader(_Limited(r)), (int(length) if length and length.isdigit() else None), \
        (r.getheader("Content-Type") or "application/octet-stream"), (m.group(1) if m else None)


# ---------------------------------------------------------------------------
# The server: product, version, whether scans can be started from here
# ---------------------------------------------------------------------------

def product_of(props):
    """(product name, version, scan_control) from /server/properties."""
    lic = props.get("license") if isinstance(props.get("license"), dict) else {}
    words = " ".join(str(x) for x in (props.get("nessus_type"), lic.get("name"), lic.get("type"),
                                       props.get("nessus_ui_build"), props.get("server_build")) if x)
    version = str(props.get("server_version") or props.get("nessus_ui_version") or "")[:40] or None
    if MANAGER_TEXT.search(words):
        return "Nessus Manager", version, True
    if PRO_TEXT.search(words):
        name = "Nessus Essentials" if re.search(r"essentials|home", words, re.I) else \
            "Nessus Expert" if re.search(r"expert", words, re.I) else "Nessus Professional"
        return name, version, False
    return (str(props.get("nessus_type") or "Nessus")[:60]), version, None


def test(server, keys=None):
    """Sign in, read the product and the scans. Returns facts to show."""
    props = call(server, "GET", "/server/properties", keys=keys)
    product, version, control = product_of(props)
    scans = call(server, "GET", "/scans", keys=keys)
    n = len(scans.get("scans") or [])
    return {"product": product, "version": version, "scan_control": control, "scans": n,
            "message": f"Signed in to {product}" + (f" {version}" if version else "") + f": {n} scan" + ("" if n == 1 else "s") + "."}


def certificate(url):
    av = _av()
    try:
        return av.fetch_certificate({"url": clean_url(url), "use_proxy": False})
    except av.AvError as e:
        raise _say(e)


def publicly_trusted(url):
    return _av().trusted_publicly(clean_url(url), False, None)


# ---------------------------------------------------------------------------
# Scans
# ---------------------------------------------------------------------------

def _ts(v):
    try:
        v = int(v)
    except (TypeError, ValueError):
        return None
    return datetime.fromtimestamp(v, timezone.utc) if v > 0 else None


def _schedule_text(s):
    rr = str(s.get("rrules") or "")
    if not s.get("enabled") or not rr:
        return "On demand"
    freq = re.search(r"FREQ=(\w+)", rr)
    day = re.search(r"BYDAY=([\w,]+)", rr)
    start = str(s.get("starttime") or "")
    at = f" at {start[9:11]}:{start[11:13]}" if re.match(r"^\d{8}T\d{6}", start) else ""
    return ((freq.group(1).capitalize() if freq else "Scheduled") + (f" ({day.group(1)})" if day else "") + at)[:60]


def list_scans(server):
    doc = call(server, "GET", "/scans")
    folders = {f.get("id"): str(f.get("name") or "")[:80] for f in doc.get("folders") or [] if isinstance(f, dict)}
    out = []
    for s in doc.get("scans") or []:
        if not isinstance(s, dict) or not isinstance(s.get("id"), int):
            continue
        if folders.get(s.get("folder_id"), "").lower() == "trash":
            continue
        out.append({"scan_id": s["id"], "uuid": str(s.get("uuid") or "")[:80] or None,
                    "name": str(s.get("name") or "")[:200] or f"Scan {s['id']}",
                    "folder": folders.get(s.get("folder_id")), "status": str(s.get("status") or "")[:30] or None,
                    "folder_id": s.get("folder_id") if isinstance(s.get("folder_id"), int) else None,
                    "rrules": (str(s.get("rrules") or "")[:200] or None) if s.get("enabled") else None,
                    "enabled": bool(s.get("enabled")), "schedule": _schedule_text(s),
                    "owner": str(s.get("owner") or "")[:80] or None,
                    "last_start": _ts(s.get("starttime") if str(s.get("starttime") or "").isdigit() else None),
                    "last_end": _ts(s.get("last_modification_date"))})
    return out


def scan_detail(server, scan_id):
    d = call(server, "GET", f"/scans/{int(scan_id)}")
    info = d.get("info") if isinstance(d.get("info"), dict) else {}
    hosts = [h for h in d.get("hosts") or [] if isinstance(h, dict)]
    hist = [h for h in d.get("history") or [] if isinstance(h, dict)]
    done = [h for h in hist if str(h.get("status")) in ("completed", "imported") and isinstance(h.get("history_id"), int)]
    last = max(done, key=lambda h: int(h.get("last_modification_date") or 0)) if done else None
    sev = lambda k: sum(int(h.get(k) or 0) for h in hosts)
    return {"targets": str(info.get("targets") or "")[:40000] or None, "status": str(info.get("status") or "")[:30] or None,
            "last_start": _ts(info.get("scan_start")), "last_end": _ts(info.get("scan_end")),
            "hosts": int(info.get("hostcount") or len(hosts) or 0), "critical": sev("critical"), "high": sev("high"),
            "medium": sev("medium"), "low": sev("low"),
            "last_history_id": last["history_id"] if last else None,
            "history_end": _ts(last.get("last_modification_date")) if last else None, "policy": str(info.get("policy") or "")[:100] or None}


def act(server, scan_id, verb):
    if verb not in ACTIONS:
        raise NessusError("Unknown action.")
    call(server, "POST", f"/scans/{int(scan_id)}/{verb}", body={})


def templates(server):
    d = call(server, "GET", "/editor/scan/templates")
    out = []
    for t in d.get("templates") or []:
        if isinstance(t, dict) and re.fullmatch(r"[0-9a-f-]{20,80}", str(t.get("uuid") or "")):
            out.append({"uuid": t["uuid"], "title": str(t.get("title") or t.get("name") or "")[:80],
                        "name": str(t.get("name") or "")[:60], "subscription_only": bool(t.get("subscription_only"))})
    return out


def folders(server):
    d = call(server, "GET", "/folders")
    return [{"id": f["id"], "name": str(f.get("name") or "")[:80]} for f in d.get("folders") or []
            if isinstance(f, dict) and isinstance(f.get("id"), int) and str(f.get("type") or "") != "trash"]


RRULE = {"daily": "FREQ=DAILY;INTERVAL=1", "weekly": "FREQ=WEEKLY;INTERVAL=1;BYDAY={day}",
         "monthly": "FREQ=MONTHLY;INTERVAL=1;BYMONTHDAY={dom}"}
DAYS = ("MO", "TU", "WE", "TH", "FR", "SA", "SU")


def scan_settings(name, targets, description=None, folder_id=None, schedule="ondemand", at=None, day=None, dom=None,
                  tz="UTC"):
    """The 'settings' Nessus takes to create or change a scan, from checked values only."""
    name = (name or "").strip()
    if not SCAN_NAME_RE.match(name):
        raise NessusError("The scan name may use letters, digits, spaces and . _ ( ) / : + -")
    t = clean_targets(targets)
    s = {"name": name, "text_targets": ",".join(t), "enabled": schedule != "ondemand"}
    if description:
        s["description"] = re.sub(r"[^\w .,:;()/+-]", "", str(description))[:300]
    if folder_id is not None:
        s["folder_id"] = int(folder_id)
    if schedule != "ondemand":
        if schedule not in RRULE:
            raise NessusError("Choose on demand, daily, weekly or monthly.")
        m = re.fullmatch(r"([01]\d|2[0-3]):([0-5]\d)", at or "")
        if not m:
            raise NessusError("Give the time as HH:MM.")
        if schedule == "weekly" and day not in DAYS:
            raise NessusError("Choose the day of the week.")
        if schedule == "monthly" and not (isinstance(dom, int) and 1 <= dom <= 28):
            raise NessusError("Choose a day of the month from 1 to 28.")
        tz = tz if re.fullmatch(r"[A-Za-z_]+(/[A-Za-z0-9_+-]+){0,2}", tz or "") else "UTC"
        try:
            from zoneinfo import ZoneInfo
            today = datetime.now(ZoneInfo(tz)).strftime("%Y%m%d")
        except Exception:  # noqa: BLE001 - an unknown zone: UTC
            tz, today = "UTC", datetime.now(timezone.utc).strftime("%Y%m%d")
        s.update(rrules=RRULE[schedule].format(day=day, dom=dom), starttime=f"{today}T{m.group(1)}{m.group(2)}00",
                 timezone=tz, launch=schedule.upper())
    return s


def create(server, template_uuid, settings):
    if not re.fullmatch(r"[0-9a-f-]{20,80}", template_uuid or ""):
        raise NessusError("Choose a scan template.")
    d = call(server, "POST", "/scans", body={"uuid": template_uuid, "settings": settings})
    sc = d.get("scan") if isinstance(d.get("scan"), dict) else {}
    return sc.get("id")


def edit(server, scan_id, template_uuid, settings):
    if not (template_uuid and re.fullmatch(r"[0-9a-f-]{20,80}", template_uuid)):
        cur = call(server, "GET", f"/editor/scan/{int(scan_id)}")      # the scan's own template: Nessus needs it
        template_uuid = str(cur.get("uuid") or "")
        if not re.fullmatch(r"[0-9a-f-]{20,80}", template_uuid):
            raise NessusError("Nessus did not say which template the scan uses: choose the template.")
    body = {"uuid": template_uuid, "settings": settings}
    call(server, "PUT", f"/scans/{int(scan_id)}", body=body)


# ---------------------------------------------------------------------------
# Reports (Nessus builds them; PATCH-01 passes them through)
# ---------------------------------------------------------------------------

CHAPTERS = "vuln_hosts_summary;vuln_by_host;remediations"


def _report_template(server):
    """The 'Detailed Vulnerabilities By Host' report template, when this Nessus has templates."""
    try:
        d = call(server, "GET", "/reports/custom/templates")
    except NessusError:
        return None
    items = d.get("items") or d.get("templates") or []
    items = [t for t in items if isinstance(t, dict) and isinstance(t.get("id"), int)]
    for want in ("detailed vulnerabilities by host", "complete list of vulnerabilities by host", "vulnerabilities by host"):
        for t in items:
            if want in str(t.get("name") or "").lower():
                return t["id"]
    return items[0]["id"] if items else None


def export_start(server, scan_id, fmt, history_id=None):
    if fmt not in FORMATS:
        raise NessusError("Choose PDF, HTML, CSV or .nessus.")
    q = f"?history_id={int(history_id)}" if history_id else ""
    body = {"format": fmt}
    if fmt in ("pdf", "html"):
        tid = _report_template(server)
        if tid is not None:
            body["template_id"] = tid
        else:
            body["chapters"] = CHAPTERS
    d = call(server, "POST", f"/scans/{int(scan_id)}/export{q}", body=body)
    fid = d.get("file")
    if not isinstance(fid, int):
        raise NessusError("Nessus did not start the export.")
    return fid


def export_status(server, scan_id, file_id):
    d = call(server, "GET", f"/scans/{int(scan_id)}/export/{int(file_id)}/status")
    st = str(d.get("status") or "").lower()
    if st == "ready":
        return "ready"
    if st in ("error", "failed"):
        return "failed"
    return "exporting"


def export_open(server, scan_id, file_id):
    return stream(server, f"/scans/{int(scan_id)}/export/{int(file_id)}/download")


# ---------------------------------------------------------------------------
# Importing results (.nessus, parsed as a stream)
# ---------------------------------------------------------------------------

def _num(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return round(f, 1) if 0 <= f <= 10 else None


def parse_nessus(fh, min_severity=1):
    """Hosts and findings from a .nessus file, as a stream. Yields (host facts, [findings])."""
    from defusedxml.ElementTree import iterparse
    host, props, items = None, {}, []
    for ev, el in iterparse(fh, events=("start", "end"), forbid_dtd=True, forbid_entities=True, forbid_external=True):
        tag = el.tag.rsplit("}", 1)[-1]
        if ev == "start" and tag == "ReportHost":
            host, props, items = str(el.get("name") or "")[:255], {}, []
            continue
        if ev != "end":
            continue
        if tag == "tag" and host is not None:
            k = str(el.get("name") or "")
            if k in ("host-ip", "host-fqdn", "netbios-name", "operating-system", "HOST_END", "host-rdns", "hostname"):
                props[k] = (el.text or "").strip()[:255]
            el.clear()
        elif tag == "ReportItem" and host is not None:
            try:
                sev = int(el.get("severity") or 0)
            except ValueError:
                sev = 0
            if sev >= min_severity and len(items) < 20000:
                cves = sorted({(c.text or "").strip().upper() for c in el.findall("cve") if CVE_RE.match((c.text or "").strip().upper())})[:100]
                g = lambda n: ((el.findtext(n) or "").strip())
                try:
                    pid = int(el.get("pluginID") or 0)
                    port = int(el.get("port") or 0)
                except ValueError:
                    pid, port = 0, 0
                if pid > 0:
                    items.append({"plugin_id": pid, "plugin_name": str(el.get("pluginName") or "")[:300],
                                  "family": str(el.get("pluginFamily") or "")[:100], "severity": min(4, max(0, sev)),
                                  "port": max(0, min(65535, port)), "protocol": str(el.get("protocol") or "")[:10],
                                  "service": str(el.get("svc_name") or "")[:60], "cves": cves,
                                  "cvss3": _num(g("cvss3_base_score")), "cvss": _num(g("cvss_base_score")),
                                  "synopsis": g("synopsis")[:600], "solution": g("solution")[:1200],
                                  "exploit": g("exploit_available").lower() == "true"})
            el.clear()
        elif tag == "ReportHost" and host is not None:
            yield ({"name": host, "ip": props.get("host-ip") or (host if _is_ip(host) else None),
                    "fqdn": props.get("host-fqdn") or props.get("host-rdns"), "os": props.get("operating-system"),
                    "end": props.get("HOST_END")}, items)
            host, props, items = None, {}, []
            el.clear()


def _is_ip(v):
    try:
        ipaddress.ip_address(v)
        return True
    except ValueError:
        return False


def _host_map(conn):
    """Our servers by address and full name; by short name only where one server has it."""
    by, short = {}, {}
    for r in conn.execute("""SELECT id::text AS id, lower(hostname) AS hn, lower(coalesce(fqdn, '')) AS fq, host(agent_ip) AS ip
                               FROM hosts WHERE status <> 'decommissioned'""").fetchall():
        for k in (r["ip"], r["fq"], r["hn"]):
            if k:
                by.setdefault(k, r["id"])
        for k in {(r["hn"] or "").split(".")[0], (r["fq"] or "").split(".")[0]} - {""}:
            short.setdefault(k, set()).add(r["id"])
    return by, {k: next(iter(v)) for k, v in short.items() if len(v) == 1}


MAX_FINDINGS = 200000
BATCH = 2000
INSERT_FINDINGS = """INSERT INTO nessus_findings (server_id, scan_id, history_id, host_name, host_ip, host_fqdn, host_os, host_id,
                                                plugin_id, plugin_name, family, severity, cvss3, cvss, cves, port, protocol,
                                                service, synopsis, solution, exploit, seen_at)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                   ON CONFLICT (server_id, scan_id, host_name, plugin_id, port, protocol) DO NOTHING"""


def import_scan(conn, server, scan_id, history_id, fh, seen_at=None):
    """Replace a scan's findings with those of one run (a .nessus file-like), as it streams in, in
    batches, all in one transaction (a failure keeps the previous findings). Returns (hosts, findings)."""
    by, short = _host_map(conn)
    conn.commit()                                   # no transaction held open on hosts while Nessus sends the file
    rows, hosts, total = [], 0, 0
    with conn.transaction():
        conn.execute("DELETE FROM nessus_findings WHERE server_id = %s AND scan_id = %s", (server["id"], scan_id))

        def flush():
            if rows:
                with conn.cursor() as cur:
                    cur.executemany(INSERT_FINDINGS, rows)
                rows.clear()
        for h, items in parse_nessus(fh):
            hosts += 1
            full = [x.lower() for x in (h["ip"], h["fqdn"], h["name"]) if x]
            hid = next((by[k] for k in full if k in by), None)
            if hid is None:
                hid = next((short[k.split(".")[0]] for k in full if not _is_ip(k) and k.split(".")[0] in short), None)
            for it in items:
                rows.append((server["id"], scan_id, history_id, h["name"], h["ip"], h["fqdn"], (h["os"] or "")[:255] or None, hid,
                             it["plugin_id"], it["plugin_name"], it["family"], it["severity"], it["cvss3"], it["cvss"], it["cves"],
                             it["port"], it["protocol"], it["service"], it["synopsis"], it["solution"], it["exploit"], seen_at))
            total += len(items)
            if total > MAX_FINDINGS:
                raise NessusError(f"The scan has more than {MAX_FINDINGS:,} findings of low severity or above: import refused "
                                  "(the previous results are kept). Split the scan in Nessus.")
            if len(rows) >= BATCH:
                flush()
        flush()
        conn.execute("""UPDATE nessus_scans SET imported_history_id = %s, imported_at = now(), import_error = NULL,
                               import_requested_at = NULL WHERE server_id = %s AND scan_id = %s""",
                     (history_id, server["id"], scan_id))
    return hosts, total


# ---------------------------------------------------------------------------
# The worker: read the scans, import finished runs
# ---------------------------------------------------------------------------

SCAN_UPSERT = """INSERT INTO nessus_scans (server_id, scan_id, uuid, name, folder, folder_id, rrules, status, enabled, schedule,
                                           owner, last_start, last_end, synced_at)
                 VALUES (%(sid)s,%(scan_id)s,%(uuid)s,%(name)s,%(folder)s,%(folder_id)s,%(rrules)s,%(status)s,%(enabled)s,%(schedule)s,
                         %(owner)s,%(last_start)s,%(last_end)s, now())
                 ON CONFLICT (server_id, scan_id) DO UPDATE SET uuid=EXCLUDED.uuid, name=EXCLUDED.name, folder=EXCLUDED.folder,
                   folder_id=EXCLUDED.folder_id, rrules=EXCLUDED.rrules,
                   status=EXCLUDED.status, enabled=EXCLUDED.enabled, schedule=EXCLUDED.schedule, owner=EXCLUDED.owner,
                   last_start=coalesce(EXCLUDED.last_start, nessus_scans.last_start),
                   last_end=coalesce(EXCLUDED.last_end, nessus_scans.last_end), synced_at=now()"""


def servers_due(conn):
    return [dict(r) for r in conn.execute(
        f"""SELECT * FROM nessus_servers WHERE enabled
              AND (last_sync_at IS NULL OR last_sync_at < now() - interval '{SYNC_MINUTES} minutes'
                   OR sync_requested_at > coalesce(last_sync_at, 'epoch'))""").fetchall()]


def sync_server(conn, server):
    """The server's scans and their latest finished run; returns how many scans."""
    scans = list_scans(server)
    seen = []
    for s in scans:
        conn.execute(SCAN_UPSERT, dict(s, sid=server["id"]))
        seen.append(s["scan_id"])
    if seen:
        conn.execute("DELETE FROM nessus_scans WHERE server_id = %s AND NOT (scan_id = ANY(%s::int[]))", (server["id"], seen))
    else:
        conn.execute("DELETE FROM nessus_scans WHERE server_id = %s", (server["id"],))
    conn.commit()
    for s in scans:
        try:
            d = scan_detail(server, s["scan_id"])
        except NessusError as e:
            log.info("nessus: scan %s: %s", s["scan_id"], e)
            continue
        conn.execute("""UPDATE nessus_scans SET targets=%s, status=coalesce(%s, status), last_start=coalesce(%s, last_start),
                               last_end=coalesce(%s, last_end), hosts=%s, critical=%s, high=%s, medium=%s, low=%s,
                               last_history_id=%s, history_end=%s WHERE server_id=%s AND scan_id=%s""",
                     (d["targets"], d["status"], d["last_start"], d["last_end"], d["hosts"], d["critical"], d["high"],
                      d["medium"], d["low"], d["last_history_id"], d["history_end"], server["id"], s["scan_id"]))
        conn.commit()
    return len(scans)


def import_due(conn, server):
    """Scans whose newest finished run is not imported yet, or asked for again."""
    return [dict(r) for r in conn.execute(
        """SELECT * FROM nessus_scans WHERE server_id = %s AND last_history_id IS NOT NULL
              AND (imported_history_id IS DISTINCT FROM last_history_id
                   OR import_requested_at > coalesce(imported_at, 'epoch'))
              AND coalesce(status, '') NOT IN ('running', 'pausing', 'paused', 'stopping', 'pending', 'resuming')
            ORDER BY last_end DESC NULLS LAST LIMIT 5""", (server["id"],)).fetchall()]


def import_run(conn, server, scan, stop=None):
    """Export the .nessus of the scan's newest finished run, wait for it, and import it."""
    fid = export_start(server, scan["scan_id"], "nessus", scan["last_history_id"])
    t0 = time.monotonic()
    while True:
        if stop is not None and stop.is_set():
            return None
        st = export_status(server, scan["scan_id"], fid)
        if st == "ready":
            break
        if st == "failed":
            raise NessusError("Nessus could not export the scan's results.")
        if time.monotonic() - t0 > EXPORT_WAIT:
            raise NessusError(f"Nessus took longer than {EXPORT_WAIT // 60} minutes to export the results.")
        (stop.wait(5) if stop is not None else time.sleep(5))
    conn_, fh, _, _, _ = export_open(server, scan["scan_id"], fid)
    try:
        return import_scan(conn, server, scan["scan_id"], scan["last_history_id"], fh, scan.get("history_end") or scan.get("last_end"))
    finally:
        conn_.close()
