"""Software end of support (EOS) and end of life (EOL): the frame.

A rule names a product as its name starts (whole words, as Installed software shows it),
optionally a version line ("2016", "8.0"), and its dates. The most specific rule wins: the
longest name, then the longest version prefix. Today admins keep the rules (Admin › Software
rules); a vendor feed can fill the same table later (source says where a rule came from).

States: eol (past end of life), eos (past end of support), eol_soon (end of life within
SOON_DAYS), supported, or None when no rule covers the program.
"""
import re
from datetime import date, timedelta

SOON_DAYS = 180
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 .+_()&'/-]{1,79}$")
VER_RE = re.compile(r"^[0-9A-Za-z.\-]{0,40}$")
STATE_TEXT = {"eol": "End of life", "eos": "End of support", "eol_soon": "End of life soon", "supported": "Supported"}


class Invalid(ValueError):
    pass


def rules(conn, platform=None):
    try:
        with conn.transaction():
            return [dict(r) for r in conn.execute(
                """SELECT id::text AS id, platform, name_prefix, version_prefix, eos, eol, note, source, created_by, created_at,
                          updated_by, updated_at
                     FROM software_lifecycle WHERE %s::text IS NULL OR platform = %s::text
                    ORDER BY lower(name_prefix), version_prefix""", (platform, platform)).fetchall()]
    except Exception as e:  # noqa: BLE001 - before schema 048 there are no rules
        if "software_lifecycle" in str(e):
            return []
        raise


def _starts_word(text, prefix):
    t, p = (text or "").strip().lower(), (prefix or "").strip().lower()
    return bool(p) and t.startswith(p) and (len(t) == len(p) or not t[len(p)].isalnum() or not p[-1].isalnum())


def _version_in(version, prefix):
    if not prefix:
        return True
    v, p = (version or "").strip().lower(), prefix.strip().lower()
    return v == p or (v.startswith(p) and not v[len(p)].isalnum()) or (v.startswith(p) and not p[-1].isalnum())


def _day(v):
    if v is None or isinstance(v, date):
        return v
    try:
        return date.fromisoformat(str(v)[:10])
    except ValueError:
        return None


def rule_for(rs, name, version):
    """The most specific rule covering this program and version, or None. A version prefix may
    also be written into the product's name ("Windows Server 2012"): both are looked at."""
    best, key = None, None
    for r in rs:
        if not _starts_word(name, r["name_prefix"]):
            continue
        vp = r.get("version_prefix") or ""
        # The version line in the reported version (8.0 covers 8.0.31), or written in the product's name as a word of
        # its own ("Java 8 Update 401", "SQL Server 2019"), never inside a dotted version ("Kit 17.0.8")
        if vp and not (_version_in(version, vp)
                       or re.search(r"(?<![0-9A-Za-z.])" + re.escape(vp) + r"(?![0-9A-Za-z]|\.[0-9])", name or "")):
            continue
        k = (len(r["name_prefix"]), len(vp))
        if key is None or k > key:
            best, key = r, k
    return best


def state(rule, today=None):
    if not rule:
        return None
    today = today or date.today()
    eos, eol = _day(rule.get("eos")), _day(rule.get("eol"))
    if eol and eol <= today:
        s = "eol"
    elif eos and eos <= today:
        s = "eos"
    elif eol and eol <= today + timedelta(days=SOON_DAYS):
        s = "eol_soon"
    else:
        s = "supported"
    return {"state": s, "text": STATE_TEXT[s], "eos": eos.isoformat() if eos else None,
            "eol": eol.isoformat() if eol else None, "rule": rule.get("id"), "source": rule.get("source"),
            "note": rule.get("note")}


def clean(body):
    """A rule from the console: checked values only."""
    platform = body.get("platform") or "windows"
    if platform not in ("windows", "linux"):
        raise Invalid("Platform must be windows or linux.")
    name = re.sub(r"\s+", " ", str(body.get("name_prefix") or "")).strip()
    if not NAME_RE.match(name):
        raise Invalid("The product name as it starts: 2 to 80 letters, digits, spaces and . + _ ( ) & ' / -")
    ver = str(body.get("version_prefix") or "").strip()
    if not VER_RE.match(ver):
        raise Invalid("The version line: letters, digits, dots and dashes only (for example 2016 or 8.0).")
    eos, eol = _day(body.get("eos")) if body.get("eos") else None, _day(body.get("eol")) if body.get("eol") else None
    if body.get("eos") and not eos or body.get("eol") and not eol:
        raise Invalid("Dates as YYYY-MM-DD.")
    if not eos and not eol:
        raise Invalid("Give the end-of-support date, the end-of-life date, or both.")
    if eos and eol and eos > eol:
        raise Invalid("End of support comes before end of life.")
    note = str(body.get("note") or "").strip()[:300] or None
    if note and re.search(r"[\x00-\x1f]", note):
        raise Invalid("The note may not hold control characters.")
    return {"platform": platform, "name_prefix": name, "version_prefix": ver, "eos": eos, "eol": eol, "note": note}
