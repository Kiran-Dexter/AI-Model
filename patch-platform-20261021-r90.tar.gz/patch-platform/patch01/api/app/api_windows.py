"""Windows servers: Windows Update results, software inventory, WSUS summaries.

Split out of main.py in r90; the code is unchanged."""

import hashlib
import json
import psycopg
import re
from datetime import datetime
from fastapi import Depends, Header, HTTPException
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional

from .core import (AgentIdentity, app, db, jsonable, require_agent, require_viewer)


# ---------------------------------------------------------------------------
# Windows servers: Windows Update results from the PowerShell agent
# ---------------------------------------------------------------------------


class WinUpdateIn(BaseModel):
    update_id: str = Field(..., max_length=80)
    kb: Optional[str] = Field(default=None, max_length=20)
    title: str = Field(..., max_length=500)
    severity: Optional[str] = Field(default=None, max_length=20)
    categories: List[str] = Field(default_factory=list, max_length=20)
    cves: List[str] = Field(default_factory=list, max_length=500)
    downloaded: Optional[bool] = None
    reboot_behaviour: Optional[str] = Field(default=None, max_length=40)
    size_mb: Optional[int] = Field(default=None, ge=0, le=100000)
    # agent 1.9.0: installed, waiting for the restart (not to install)
    installed_pending_reboot: Optional[bool] = None


class WinUpdatesIn(BaseModel):
    searched_at: datetime
    source: Optional[str] = Field(default=None, max_length=20)      # wsus or microsoft
    server: Optional[str] = Field(default=None, max_length=300)     # the WSUS address
    os_edition: Optional[str] = Field(default=None, max_length=120)
    error: Optional[str] = Field(default=None, max_length=1000)
    updates: List[WinUpdateIn] = Field(default_factory=list, max_length=2000)
    # agent 1.9.0: true when the list is Windows' cached one (no WSUS search this time)
    offline: Optional[bool] = None


@app.post("/api/v1/agent/windows/updates")
def agent_windows_updates(body: WinUpdatesIn, agent: AgentIdentity = Depends(require_agent)):
    """What Windows Update says is not yet installed, searched against the
    server's own WSUS, so it reflects your approvals. Replaces the last report."""
    cve_re = re.compile(r"^CVE-\d{4}-\d{4,7}$")
    with db() as conn:
        with conn.transaction():
            conn.execute(
                """UPDATE hosts SET wu_source=%s, wu_server=%s, wu_searched_at=%s, wu_error=%s,
                          os_edition=coalesce(%s, os_edition) WHERE id=%s""",
                (body.source, body.server, body.searched_at, body.error, body.os_edition, agent.host_id))
            if body.error is None:
                conn.execute("DELETE FROM windows_updates WHERE host_id=%s", (agent.host_id,))
                # Windows' own cached list can still name an update that is already
                # installed (its KB is in the server's installed-updates list): such an
                # update is not "to install"
                have = {r["k"] for r in conn.execute(
                    "SELECT upper(name) AS k FROM host_packages WHERE host_id=%s AND name LIKE 'kb%%'",
                    (agent.host_id,)).fetchall()}
                # After a full search (agent 1.9.0 says offline=false) Windows Update is the
                # authority: an update it offers is listed even if a KB of that number is
                # installed (a re-release). Windows' cached list (offline=true; older
                # agents do not say) can lag behind an install: its KB filter applies.
                cached = body.offline is not False
                todo = [u for u in body.updates
                        if not u.installed_pending_reboot and not (cached and u.kb and u.kb.upper() in have)]
                with conn.cursor() as cur:
                    cur.executemany(
                        """INSERT INTO windows_updates (host_id, update_id, kb, title, severity, categories, cves,
                                                        downloaded, reboot_behaviour, size_mb, reported_at)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,now())
                           ON CONFLICT (host_id, update_id) DO NOTHING""",
                        [(agent.host_id, u.update_id, u.kb, u.title[:500], u.severity, u.categories[:20],
                          [c for c in u.cves if cve_re.match(c)], u.downloaded, u.reboot_behaviour, u.size_mb)
                         for u in todo])
            else:
                todo = []
    return {"ok": True, "stored": len(todo)}


class WinInstalledItem(BaseModel):
    kb: Optional[str] = Field(default=None, max_length=12, pattern=r"^KB\d{4,8}$")
    title: Optional[str] = Field(default=None, max_length=500)
    kind: Optional[str] = Field(default=None, max_length=60)
    installed_on: Optional[datetime] = None
    installed_by: Optional[str] = Field(default=None, max_length=120)
    result: Optional[str] = Field(default=None, max_length=30)
    source: str = Field(..., pattern="^(hotfix|history)$")


class WinInstalledIn(BaseModel):
    collected_at: datetime
    items: List[WinInstalledItem] = Field(default_factory=list, max_length=3000)


@app.post("/api/v1/agent/windows/installed")
def agent_windows_installed(body: WinInstalledIn, agent: AgentIdentity = Depends(require_agent)):
    """The installed updates with their details (agent 1.9.0+). Replaces the last report."""
    clean = lambda v: (" ".join(v.split())[:500] or None) if isinstance(v, str) else v
    with db() as conn:
        h = conn.execute("SELECT os_id FROM hosts WHERE id=%s", (agent.host_id,)).fetchone()
        if not h or h["os_id"] != "windows":
            raise HTTPException(409, "Installed updates are reported by Windows servers only.")
        with conn.transaction():
            conn.execute("DELETE FROM windows_installed_updates WHERE host_id=%s", (agent.host_id,))
            with conn.cursor() as cur:
                cur.executemany(
                    """INSERT INTO windows_installed_updates
                         (host_id, kb, title, kind, installed_on, installed_by, result, source)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
                    [(agent.host_id, i.kb, clean(i.title), clean(i.kind), i.installed_on, clean(i.installed_by),
                      clean(i.result), i.source) for i in body.items])
    return {"ok": True, "stored": len(body.items)}


def windows_installed(conn, host_id):
    """One row per installed update: the hotfix list joined with the update
    history (title, result). Updates only in the history (.NET, Defender) are
    listed with their newest result. Older agents: the KBs and their type."""
    try:
        with conn.transaction():
            rows = conn.execute(
                """SELECT kb, title, kind, installed_on, installed_by, result, source
                     FROM windows_installed_updates WHERE host_id=%s""", (host_id,)).fetchall()
    except psycopg.errors.UndefinedTable:
        rows = []
    if not rows:
        return [{"kb": r["name"].upper(), "title": None, "kind": r["from_repo"], "installed_on": r["install_time"],
                 "installed_by": None, "result": "Installed"} for r in conn.execute(
            "SELECT name, from_repo, install_time FROM host_packages WHERE host_id=%s AND name LIKE 'kb%%' ORDER BY name",
            (host_id,)).fetchall()], False
    hot = {r["kb"]: dict(r) for r in rows if r["source"] == "hotfix" and r["kb"]}
    out = list(hot.values())
    for r in rows:
        if r["source"] != "history":
            continue
        if r["kb"] and r["kb"] in hot:
            x = hot[r["kb"]]
            x["title"] = x["title"] or r["title"]
            x["installed_on"] = x["installed_on"] or r["installed_on"]
            continue
        out.append(dict(r))
    for o in out:
        o.pop("source", None)
    dated = sorted((o for o in out if o["installed_on"]), key=lambda o: o["installed_on"], reverse=True)
    undated = sorted((o for o in out if not o["installed_on"]), key=lambda o: o["kb"] or o["title"] or "")
    return dated + undated, True


@app.get("/api/v1/admin/hosts/{host_id}/linux")
def host_linux(host_id: str, days: int = 90, user: str = Depends(require_viewer)):
    """A Linux server's patching, from its own package manager (agent 1.8.2+): the updates
    it would install now, and the package versions installed recently with their dates."""
    from . import servers as sv
    if not re.fullmatch(r"[0-9a-f-]{36}", host_id or ""):
        raise HTTPException(404, "No such server.")
    days = max(1, min(int(days or 90), 3650))
    with db() as conn:
        h = conn.execute("SELECT os_id FROM hosts WHERE id=%s", (host_id,)).fetchone()
        if not h or h["os_id"] == "windows":
            raise HTTPException(404, "Not a Linux server.")
        pend = sv.pending(conn, host_id)
        inst = conn.execute(
            """SELECT name, arch, version, installed_at FROM linux_package_installs
                WHERE host_id=%s AND installed_at > now() - make_interval(days => %s)
                ORDER BY installed_at DESC, name LIMIT 1000""", (host_id, days)).fetchall()
        known = conn.execute("SELECT count(*) AS n FROM linux_package_installs WHERE host_id=%s AND installed_at IS NOT NULL",
                             (host_id,)).fetchone()["n"]
    return jsonable({"pending": pend, "installed": inst, "days": days, "dated": known > 0})


@app.get("/api/v1/admin/hosts/{host_id}/windows")
def host_windows(host_id: str, user: str = Depends(require_viewer)):
    with db() as conn:
        h = conn.execute(
            """SELECT id, hostname, os_id, os_version, os_edition, kernel_running AS build, wu_source, wu_server,
                      wu_searched_at, wu_error, reboot_required FROM hosts WHERE id=%s""", (host_id,)).fetchone()
        if not h or h["os_id"] != "windows":
            raise HTTPException(404, "Not a Windows server.")
        ups = conn.execute(
            """SELECT update_id, kb, title, severity, categories, cves, downloaded, reboot_behaviour, size_mb, reported_at
                 FROM windows_updates WHERE host_id=%s
                ORDER BY CASE severity WHEN 'Critical' THEN 0 WHEN 'Important' THEN 1 WHEN 'Moderate' THEN 2
                                       WHEN 'Low' THEN 3 ELSE 4 END, kb""", (host_id,)).fetchall()
        installed, detailed = windows_installed(conn, h["id"])
    return {"host": h, "missing": ups, "installed": installed, "installed_detailed": detailed,
            "installed_kbs": [i["kb"] for i in installed if i.get("kb") and i.get("result") in ("Installed", "Succeeded", "Succeeded with errors")]}


# ---------------------------------------------------------------------------
# Windows software inventory
# ---------------------------------------------------------------------------


class WinSoftwareItem(BaseModel):
    name: str = Field(..., min_length=1, max_length=300)
    version: str = Field(default="", max_length=120)
    publisher: Optional[str] = Field(default=None, max_length=200)
    installed_on: Optional[str] = Field(default=None, max_length=10)     # yyyymmdd, as Windows keeps it
    size_mb: Optional[int] = Field(default=None, ge=0, le=10_000_000)
    arch: Optional[str] = Field(default=None, max_length=10)
    # Agent 1.9.3-win: the entry's own key and how it can be removed silently
    uninstall_key: Optional[str] = Field(default=None, max_length=200, pattern=r"^[A-Za-z0-9{][A-Za-z0-9 ._{}()+-]{0,199}$")
    uninstall_how: Optional[str] = Field(default=None, pattern=r"^(msi|quiet|inno|nsis)$")


class WinSoftwareIn(BaseModel):
    software: List[WinSoftwareItem] = Field(default_factory=list, max_length=5000)


@app.post("/api/v1/agent/windows/software")
def agent_windows_software(body: WinSoftwareIn, agent: AgentIdentity = Depends(require_agent)):
    """Programs and Features on this server. Replaces the last report."""
    from datetime import date as _date
    def day(v):
        if v and re.fullmatch(r"\d{8}", v):
            try:
                return _date(int(v[:4]), int(v[4:6]), int(v[6:]))
            except ValueError:
                return None
        return None
    seen, rows = set(), []
    for it in body.software:
        k = (it.name.strip(), it.version.strip(), it.arch or "")
        if k in seen:
            continue
        seen.add(k)
        rows.append((agent.host_id, k[0], k[1], (it.publisher or "").strip() or None, day(it.installed_on),
                     it.size_mb, it.arch, it.uninstall_key, it.uninstall_how if it.uninstall_key else None))
    with db() as conn:
        with conn.transaction():
            before = {(r["name"], r["version"]) for r in conn.execute(
                "SELECT name, version FROM windows_software WHERE host_id=%s", (agent.host_id,)).fetchall()}
            conn.execute("DELETE FROM windows_software WHERE host_id=%s", (agent.host_id,))
            with conn.cursor() as cur:
                cur.executemany(
                    """INSERT INTO windows_software (host_id, name, version, publisher, installed_on, size_mb, arch,
                                                     uninstall_key, uninstall_how)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING""", rows)
            if before != {(r[1], r[2]) for r in rows}:
                from . import cve_impact
                cve_impact.inventory_changed(conn)     # a program installed, removed or updated
    return {"ok": True, "stored": len(rows)}


@app.get("/api/v1/admin/hosts/{host_id}/software")
def host_software(host_id: str, user: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT name, version, publisher, installed_on, size_mb, arch, reported_at
                 FROM windows_software WHERE host_id=%s ORDER BY lower(name), version""", (host_id,)).fetchall()
    return {"software": rows}


# ---------------------------------------------------------------------------
# WSUS: summaries sent by a read-only script on each WSUS server
# ---------------------------------------------------------------------------


def _wsus_source(conn, authorization):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "missing token")
    th = hashlib.sha256(authorization[7:].strip().encode()).hexdigest()
    src = conn.execute("SELECT name FROM wsus_sources WHERE token_hash=%s", (th,)).fetchone()
    if not src:
        raise HTTPException(401, "unknown WSUS reporting token")
    return src["name"]


class WsusComputerIn(BaseModel):
    name: str = Field(..., max_length=260)
    ip: Optional[str] = Field(default=None, max_length=64)
    os: Optional[str] = Field(default=None, max_length=200)
    groups: List[str] = Field(default_factory=list, max_length=50)
    last_reported: Optional[datetime] = None
    last_synced: Optional[datetime] = None
    needed: Optional[int] = Field(default=None, ge=0)
    failed: Optional[int] = Field(default=None, ge=0)
    pending_reboot: Optional[int] = Field(default=None, ge=0)


class WsusReportIn(BaseModel):
    server: Dict[str, Any] = Field(default_factory=dict)          # version, sync state, counts, groups
    computers: List[WsusComputerIn] = Field(default_factory=list, max_length=20000)
    error: Optional[str] = Field(default=None, max_length=2000)


@app.post("/api/v1/wsus/report")
def wsus_report(body: WsusReportIn, authorization: Optional[str] = Header(default=None)):
    with db() as conn:
        name = _wsus_source(conn, authorization)
        with conn.transaction():
            conn.execute("UPDATE wsus_sources SET reported_at=now(), report=%s, error=%s WHERE name=%s",
                         (json.dumps(body.server, default=str), body.error, name))
            if body.error is None:
                conn.execute("DELETE FROM wsus_computers WHERE source=%s", (name,))
                with conn.cursor() as cur:
                    cur.executemany(
                        """INSERT INTO wsus_computers (source, name, ip, os, groups, last_reported, last_synced,
                                                       needed, failed, pending_reboot)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING""",
                        [(name, c.name.lower(), c.ip, c.os, c.groups[:50], c.last_reported, c.last_synced,
                          c.needed, c.failed, c.pending_reboot) for c in body.computers])
    return {"ok": True, "computers": len(body.computers)}


@app.get("/api/v1/wsus")
def wsus_view(user: str = Depends(require_viewer)):
    """Each WSUS, its computers, and how they line up with PATCH-01's servers."""
    with db() as conn:
        srcs = conn.execute("SELECT name, reported_at, report, error FROM wsus_sources ORDER BY name").fetchall()
        comps = conn.execute(
            """SELECT c.*, h.id AS host_id, h.hostname AS patch01_name
                 FROM wsus_computers c
                 LEFT JOIN hosts h ON h.status <> 'decommissioned'
                      AND (lower(h.hostname) = split_part(c.name, '.', 1) OR lower(h.fqdn) = c.name)
                ORDER BY c.needed DESC NULLS LAST, c.name""").fetchall()
        win = conn.execute(
            """SELECT h.id, h.hostname, h.fqdn FROM hosts h
                WHERE h.os_id='windows' AND h.status <> 'decommissioned'""").fetchall()
    known = {c["patch01_name"] for c in comps if c["patch01_name"]}
    return {"sources": srcs, "computers": comps,
            "not_in_wsus": [w for w in win if w["hostname"] not in known] if srcs else []}
