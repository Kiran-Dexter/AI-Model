"""Which installed Windows programs PATCH-01 may remove (default: none).

A program may be removed only when all of these hold:
  1. its name starts with an entry of the "removable tools" list (admins keep the list;
     it starts with common tools: 7-Zip, Notepad++, PuTTY, WinSCP...);
  2. it is not critical software. CRITICAL is fixed in the code and cannot be changed from
     the console: databases (SQL Server and the rest), security and EDR agents, backup
     agents, hypervisor tools, runtimes and drivers, server roles, monitoring and
     management agents, and PATCH-01's own agent. A tools-list entry that names critical
     software is refused, and a program matching both is never removable;
  3. the server's agent reported a silent way to remove it (MSI, the program's own quiet
     uninstall command, or a known silent uninstaller).
The Windows agent checks the critical list again itself before it removes anything.
"""
import re
import unicodedata

# Critical software: never removable from PATCH-01, whatever the tools list says.
# Word-based, case-insensitive; matched anywhere in the program's name or publisher.
CRITICAL_WORDS = (
    # databases and data platforms
    r"sql", r"database", r"oracle", r"mysql", r"mariadb", r"postgres", r"mongodb", r"db2", r"sybase", r"informix",
    r"postgresql", r"mssql", r"sqlite", r"sqlexpress", r"redis", r"cassandra", r"elasticsearch", r"couchbase", r"teradata", r"hana", r"firebird",
    # security, antivirus, EDR
    r"trend micro", r"apex one", r"deep security", r"defender", r"crowdstrike", r"falcon", r"sentinel ?one", r"sophos",
    r"symantec", r"mcafee", r"trellix", r"carbon black", r"cylance", r"eset", r"kaspersky", r"bitdefender",
    r"cortex", r"traps", r"forcepoint", r"tenable", r"nessus", r"qualys", r"rapid7", r"insight ?agent", r"splunk", r"wazuh",
    r"sysmon", r"tanium", r"cyberark", r"beyondtrust", r"thycotic", r"duo", r"okta", r"antivirus", r"anti-?malware",
    r"endpoint", r"firewall", r"edr", r"xdr", r"dlp", r"encryption", r"bitlocker",
    # backup and recovery
    r"veeam", r"commvault", r"netbackup", r"veritas", r"backup", r"arcserve", r"avamar", r"networker", r"rubrik",
    r"cohesity", r"zerto", r"recovery",
    # virtualisation and hardware
    r"vmware", r"hyper-?v", r"citrix", r"xenserver", r"nutanix", r"virtualbox", r"integration services",
    r"driver", r"firmware", r"chipset", r"bios", r"idrac", r"ilo", r"openmanage", r"hpe?\b.*\bagent", r"raid", r"storage",
    r"multipath", r"mpio", r"broadcom", r"emulex", r"qlogic", r"intel\(r\)", r"nvidia", r"\bamd\b", r"realtek",
    # runtimes and frameworks
    r"\.net", r"dotnet", r"visual c\+\+", r"redistributable", r"runtime", r"framework", r"java", r"jre", r"jdk",
    r"openjdk", r"python", r"powershell", r"windows management framework", r"msxml", r"directx", r"webview2",
    # server roles and Microsoft server products
    r"exchange", r"\biis\b", r"internet information services", r"sharepoint", r"active directory", r"\bad\b",
    r"system center", r"configuration manager", r"sccm", r"\bscom\b", r"wsus", r"windows server", r"windows admin center",
    r"remote desktop", r"\brds\b", r"dynamics", r"skype", r"lync", r"biztalk", r"failover", r"cluster", r"dfs",
    # monitoring and management agents
    r"monitoring", r"monitor agent", r"zabbix", r"nagios", r"solarwinds", r"prtg", r"datadog", r"dynatrace",
    r"new relic", r"appdynamics", r"azure", r"arc\b", r"amazon", r"aws", r"ssm agent", r"google cloud", r"guest agent",
    r"puppet", r"chef", r"ansible", r"salt ?minion", r"bigfix", r"ivanti", r"landesk", r"manageengine", r"kace",
    r"intune", r"snmp", r"syslog", r"log ?analytics", r"ops ?agent",
    # PATCH-01 itself
    r"patch-?01", r"patch ?agent", r"cyber-?secure",
    # more security, backup, data, monitoring and management products (review r88)
    r"malwarebytes", r"webroot", r"avast", r"avg", r"norton", r"f-?secure", r"withsecure", r"cybereason", r"huntress",
    r"arctic ?wolf", r"forticlient", r"fortinet", r"globalprotect", r"cisco secure", r"anyconnect", r"zscaler", r"netskope",
    r"sentinel agent", r"acronis", r"data protector", r"druva", r"datto", r"altaro", r"nakivo", r"unitrends", r"carbonite",
    r"spectrum protect", r"tivoli", r"neo4j", r"influxdb", r"couchdb", r"pervasive", r"psql", r"actian", r"openedge",
    r"rabbitmq", r"erlang", r"elastic", r"winlogbeat", r"beats?", r"nxlog", r"telegraf", r"fluent ?bit", r"fluentd",
    r"windows_exporter", r"check_?mk", r"checkmk", r"kaseya", r"connectwise", r"screenconnect", r"ninja ?rmm", r"n-able",
    r"lansweeper", r"velociraptor", r"tripwire", r"powerpath", r"dynamic link manager", r"netapp", r"mellanox", r"winof",
    r"node\.?js", r"temurin", r"zulu", r"adoptopenjdk", r"corretto", r"openssl", r"perl", r"php", r"ruby",
    r"laps", r"local administrator password", r"safenet", r"rsa", r"yubikey", r"activclient", r"smart ?card",
    r"minidriver", r"virtio", r"xen", r"parallels", r"qemu", r"agent", r"service pack", r"hotfix", r"security update",
    r"certificate", r"pki", r"radius", r"vpn", r"proxy", r"dns", r"dhcp",
)
# Distinctive pieces matched anywhere in a name (no word edges): ASP.NET, VMwareTools, SQLServer...
CRITICAL_ANYWHERE = (r"(?<!paint)\.net\b", r"sql", r"vmware", r"driver", r"virtio", r"openssl", r"jdk", r"jre\b", r"redistributable",
                     r"runtime", r"database", r"antivirus", r"backup", r"defender", r"firewall")
CRITICAL = re.compile(r"(?i)(?<![a-z0-9])(?:" + "|".join(CRITICAL_WORDS) + r")s?(?![a-z0-9])|(?:"
                      + "|".join(CRITICAL_ANYWHERE) + r")")
# Vendor or generic words that are never a tools-list entry on their own (too broad)
TOO_BROAD = {"microsoft", "windows", "win", "dell", "hp", "hpe", "intel", "google", "amazon", "oracle", "ibm", "cisco",
             "apache", "open", "adobe", "apple", "mozilla", "the", "tool", "tools", "app", "application", "program",
             "software", "server", "client", "service", "update", "setup", "system", "remote", "free", "pro", "lenovo",
             "vmware", "citrix", "red hat", "sap", "symantec", "broadcom", "nvidia", "amd", "realtek", "logitech"}

# The removable tools PATCH-01 starts with (admins add or remove entries)
DEFAULT_TOOLS = (
    "7-Zip", "Notepad++", "WinRAR", "PeaZip", "PuTTY", "WinSCP", "FileZilla Client", "Wireshark", "Npcap", "WinPcap",
    "mRemoteNG", "TreeSize", "WinDirStat", "WinMerge", "Sublime Text", "Microsoft Visual Studio Code", "Notepad2",
    "Google Chrome", "Mozilla Firefox", "Adobe Acrobat Reader", "Foxit PDF Reader", "VLC media player", "Greenshot",
    "paint.net", "KeePass", "TeamViewer", "AnyDesk", "Advanced IP Scanner", "Angry IP Scanner", "Bginfo",
)

PATTERN_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 .+_()&'-]{2,79}$")
HOW = ("msi", "quiet", "inno", "nsis")
HOW_TEXT = {"msi": "Windows Installer (msiexec /x)", "quiet": "its own quiet uninstall command",
            "inno": "its Inno Setup uninstaller, silent", "nsis": "its NSIS uninstaller, silent"}


class Refused(ValueError):
    """Why something may not be removed, or a tools-list entry may not be added."""


def normal(text):
    """For matching: compatibility-normalised (full-width letters, ligatures), invisible format
    characters (zero-width spaces and joiners) removed, spaces collapsed."""
    t = unicodedata.normalize("NFKC", str(text or ""))
    t = "".join(ch for ch in t if unicodedata.category(ch) != "Cf")
    return re.sub(r"\s+", " ", t).strip()


def critical(name, publisher=None, *more):
    """The critical word a program (its name, publisher, or the paths given) matches, or None."""
    for text in (name, publisher) + more:
        m = CRITICAL.search(normal(text))
        if m:
            return m.group(0)
    return None


def clean_pattern(p):
    p = normal(p)
    if not PATTERN_RE.match(p):
        raise Refused("A tool's name: 3 to 80 letters, digits, spaces and . + _ ( ) & ' -")
    word = critical(p)
    if word:
        raise Refused(f"“{p}” names critical software (“{word}”): it can never be made removable from PATCH-01.")
    if p.lower() in TOO_BROAD or len(re.sub(r"[^A-Za-z0-9]", "", p)) < 4:
        raise Refused(f"“{p}” is too broad: name the tool itself (for example “7-Zip” or “Notepad++”), not a vendor or a word.")
    return p


def tools(conn):
    return [dict(r) for r in conn.execute(
        """SELECT pattern, builtin, created_by, created_at FROM software_removable ORDER BY lower(pattern)""").fetchall()]


def allowed_by(patterns, name):
    """The tools-list entry the program's name starts with, as a whole word (“7-Zip” matches
    “7-Zip 23.01 (x64)”, “Win” does not match “Winlogbeat”), or None."""
    n = normal(name).lower()
    for p in patterns:
        q = normal(p).lower()
        if n.startswith(q) and (len(n) == len(q) or not n[len(q)].isalnum() or not q[-1].isalnum()):
            return p
    return None


def verdict(patterns, name, publisher=None):
    """(state, reason) for a program: 'removable', 'critical' or 'not_listed'."""
    word = critical(name, publisher)
    if word:
        return "critical", f"critical software (“{word}”): never removed from PATCH-01"
    hit = allowed_by(patterns, name)
    if not hit:
        return "not_listed", "not on the removable tools list (Admin › Software rules)"
    return "removable", f"on the removable tools list (“{hit}”)"


def check(conn, name, publisher=None):
    """The tools-list entry that allows removing the program; raises Refused otherwise (policy
    only: each server's own silent uninstaller is checked per server)."""
    pats = [t["pattern"] for t in tools(conn)]
    state, why = verdict(pats, name, publisher)
    if state != "removable":
        raise Refused(f"{name}: {why}.")
    return allowed_by(pats, name)


def matches(conn, pattern, limit=30):
    """The Windows programs installed now that this entry would make removable (not critical)."""
    names = [r["name"] for r in conn.execute(
        """SELECT DISTINCT name FROM windows_software WHERE lower(name) LIKE lower(%s) || '%%' ORDER BY name LIMIT 500""",
        (pattern,)).fetchall()]
    return [n for n in names if allowed_by([pattern], n) and not critical(n)][:limit]
