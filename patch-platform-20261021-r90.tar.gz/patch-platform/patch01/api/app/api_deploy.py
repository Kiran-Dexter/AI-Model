"""Deployment: packages uploaded to PATCH-01 and installed by the Windows agents.

Split out of main.py in r90; the code is unchanged."""

import json
import psycopg
import re
from datetime import datetime, timedelta, timezone
from fastapi import Body, Depends, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import Dict, Optional

from .core import (AgentIdentity, OS_LABEL_SQL, _PUBLIC_CACHE, _audit, _public_cached, app, audit, client_ip, db,
                   jsonable, log, now, require_admin, require_agent, require_operator, require_viewer)


# ---------------------------------------------------------------------------
# Deployment: packages uploaded to PATCH-01, installed by the Windows agents
# ---------------------------------------------------------------------------


class DeployUploadIn(BaseModel):
    file_name: str = Field(..., max_length=200)
    size: int = Field(..., gt=0)


class DeployReviewIn(BaseModel):
    name: str = Field(..., max_length=80)
    version: str = Field(..., max_length=40)
    vendor: Optional[str] = Field(default=None, max_length=120)
    detect_name: Optional[str] = Field(default=None, max_length=120)
    install_args: Optional[str] = Field(default=None, max_length=300)
    notes: Optional[str] = Field(default=None, max_length=500)
    require_signature: bool = False
    publisher: Optional[str] = Field(default=None, max_length=200)


def _deploy_call(fn):
    """Run fn(conn) in one transaction, turning the module's refusals into HTTP answers."""
    from . import deploy
    try:
        with db() as conn:
            with conn.transaction():
                return fn(conn)
    except deploy.NotFound as e:
        raise HTTPException(404, str(e))
    except deploy.Invalid as e:
        raise HTTPException(409, str(e))
    except psycopg.errors.UniqueViolation:
        raise HTTPException(409, "The same file was just uploaded by someone else: refresh the page to see it.")
    except OSError as e:
        log.error("deploy storage: %s", e)
        raise HTTPException(507, "PATCH-01 could not write the package: " + (e.strerror or str(e))[:200])


@app.get("/api/v1/deploy/status")
def deploy_status(user: str = Depends(require_viewer)):
    from . import deploy
    with db() as conn:
        return jsonable(deploy.status(conn))


@app.get("/api/v1/deploy/packages")
def deploy_packages(user: str = Depends(require_viewer)):
    from . import deploy
    with db() as conn:
        return jsonable({"items": deploy.list_packages(conn)})


@app.get("/api/v1/deploy/packages/{package_id}")
def deploy_package(package_id: str, user: str = Depends(require_viewer)):
    from . import deploy
    return jsonable(_deploy_call(lambda conn: deploy.view(deploy.get(conn, package_id))))


@app.get("/api/v1/deploy/packages/{package_id}/servers")
def deploy_package_servers(package_id: str, user: str = Depends(require_viewer)):
    """Every Windows server and what it has of this package now (from its software inventory)."""
    from . import deploy
    return jsonable(_deploy_call(lambda conn: deploy.servers_for(conn, package_id)))


@app.post("/api/v1/deploy/uploads")
def deploy_upload_start(body: DeployUploadIn, request: Request, user: str = Depends(require_operator)):
    from . import deploy
    r = _deploy_call(lambda conn: deploy.start_upload(conn, user, body.file_name, body.size))
    return r


@app.put("/api/v1/deploy/uploads/{upload_id}")
async def deploy_upload_piece(upload_id: str, request: Request, offset: int = 0, user: str = Depends(require_operator)):
    """One piece of the file (at most 32 MB), at the offset PATCH-01 expects."""
    from starlette.concurrency import run_in_threadpool
    from . import deploy
    cl = request.headers.get("content-length")
    if cl and (not cl.isdigit() or int(cl) > deploy.CHUNK_MAX):
        raise HTTPException(413, "A piece is at most 32 MB.")
    data = bytearray()
    async for part in request.stream():
        data += part
        if len(data) > deploy.CHUNK_MAX:
            raise HTTPException(413, "A piece is at most 32 MB.")
    return await run_in_threadpool(_deploy_call, lambda conn: deploy.put_chunk(conn, user, upload_id, offset, bytes(data)))


@app.delete("/api/v1/deploy/uploads/{upload_id}")
def deploy_upload_cancel(upload_id: str, user: str = Depends(require_operator)):
    from . import deploy
    _deploy_call(lambda conn: deploy.cancel_upload(conn, user, upload_id))
    return {"ok": True}


@app.post("/api/v1/deploy/uploads/{upload_id}/complete")
def deploy_upload_complete(upload_id: str, request: Request, user: str = Depends(require_operator)):
    from . import deploy

    def work(conn):
        pkg, dup = deploy.finish_upload(conn, user, upload_id)
        if not dup:
            _audit(conn, user, "package_uploaded", "package", pkg["id"],
                   {"file": pkg["file_name"], "sha256": pkg["sha256"], "size": pkg["size_bytes"]}, client_ip(request))
        return {"package": deploy.view(pkg), "duplicate": dup}
    return jsonable(_deploy_call(work))


@app.put("/api/v1/deploy/packages/{package_id}")
def deploy_package_review(package_id: str, body: DeployReviewIn, request: Request, user: str = Depends(require_operator)):
    from . import deploy

    def work(conn):
        p = deploy.save_review(conn, user, package_id, body.model_dump())
        _audit(conn, user, "package_reviewed", "package", package_id,
               {"name": p["name"], "version": p["version"], "args": p["install_args"],
                "require_signature": p["require_signature"]}, client_ip(request))
        return p
    return jsonable(_deploy_call(work))


@app.post("/api/v1/deploy/packages/{package_id}/{what}")
def deploy_package_again(package_id: str, what: str, user: str = Depends(require_operator)):
    from . import deploy
    if what not in ("scan", "ai"):
        raise HTTPException(404, "Not found.")
    _deploy_call(lambda conn: deploy.request_again(conn, package_id, what))
    return {"ok": True}


@app.delete("/api/v1/deploy/packages/{package_id}")
def deploy_package_remove(package_id: str, request: Request, user: str = Depends(require_operator)):
    from . import deploy

    def work(conn):
        p = deploy.remove(conn, user, package_id)
        _audit(conn, user, "package_removed", "package", package_id, {"file": p["file_name"], "sha256": p["sha256"]},
               client_ip(request))
    _deploy_call(work)
    return {"ok": True}


DEPLOY_JOBS_SQL = """
SELECT c.id::text AS change_id, 'CHG-' || lpad(c.number::text, 6, '0') AS ref, c.title, c.state::text AS state,
       c.params, c.requested_by, c.requested_at, c.run_after, c.started_at, c.finished_at,
       coalesce(json_agg(json_build_object(
         'target_key', ct.target_key, 'label', ct.label, 'host_id', ct.host_id, 'state', ct.state,
         'error', ct.error, 'warnings', ct.detail->'warnings', 'explain', ct.detail->'explain', 'updated_at', ct.updated_at,
         'result', (SELECT ac.result FROM agent_commands ac
                     WHERE ac.change_id = c.id AND ac.target_key = ct.target_key AND ac.verb = 'software_action'
                     ORDER BY ac.created_at DESC LIMIT 1)) ORDER BY ct.label) FILTER (WHERE ct.target_key IS NOT NULL), '[]') AS targets
  FROM changes c LEFT JOIN change_targets ct ON ct.change_id = c.id
 WHERE c.kind = 'software' AND c.params->>'source' = 'package'
   AND c.requested_at > now() - make_interval(days => %s)
 GROUP BY c.id ORDER BY c.requested_at DESC LIMIT 300"""


@app.get("/api/v1/deploy/jobs")
def deploy_jobs(days: int = 30, user: str = Depends(require_viewer)):
    """Deployments of uploaded packages, each server's state, error and the agent's own result."""
    days = max(1, min(int(days), 365))
    with db() as conn:
        rows = [dict(r) for r in conn.execute(DEPLOY_JOBS_SQL, (days,)).fetchall()]
    keep = ("message", "action", "before", "after", "exit_code", "reboot_required", "nothing_to_do", "target_path",
            "drive", "downloaded_mb", "download_seconds", "signature", "log_excerpt", "warnings", "folder_created")
    for r in rows:
        for t in r["targets"] or []:
            res = t.get("result") or {}
            t["result"] = {k: res.get(k) for k in keep if k in res} if isinstance(res, dict) else {}
    return jsonable({"items": rows})


@app.get("/api/v1/deploy/jobs/{change_id}/log")
def deploy_job_log(change_id: str, target_key: str, user: str = Depends(require_viewer)):
    """The agent's own log lines for one server of one deployment: from when it took
    its first step of this job to two minutes after its last result."""
    if not re.match(r"^[0-9a-f-]{36}$", change_id) or not re.match(r"^[0-9a-f-]{36}$", target_key):
        raise HTTPException(404, "Not found.")
    with db() as conn:
        t = conn.execute(
            """SELECT ct.host_id::text AS host_id,
                      coalesce((SELECT min(ac.claimed_at) FROM agent_commands ac
                                 WHERE ac.change_id = c.id AND ac.target_key = ct.target_key), c.started_at) IS NOT NULL AS started
                 FROM change_targets ct JOIN changes c ON c.id = ct.change_id
                WHERE ct.change_id = %s AND ct.target_key = %s AND c.kind = 'software'""", (change_id, target_key)).fetchone()
        if not t or not t["host_id"]:
            raise HTTPException(404, "No such server in this deployment.")
        if not t["started"]:
            return {"lines": [], "note": "This server has not started yet."}
        lines = conn.execute(
            """WITH w AS (
                 SELECT ct.host_id,
                        coalesce((SELECT min(ac.claimed_at) FROM agent_commands ac
                                   WHERE ac.change_id = c.id AND ac.target_key = ct.target_key), c.started_at) - interval '1 minute' AS since,
                        coalesce((SELECT max(ac.completed_at) FROM agent_commands ac
                                   WHERE ac.change_id = c.id AND ac.target_key = ct.target_key) + interval '2 minutes',
                                 c.finished_at, now()) AS until
                   FROM change_targets ct JOIN changes c ON c.id = ct.change_id
                  WHERE ct.change_id = %s AND ct.target_key = %s)
               SELECT l.at, l.level, l.line FROM agent_logs l JOIN w ON l.host_id = w.host_id
                WHERE l.at BETWEEN w.since AND w.until ORDER BY l.at, l.id LIMIT 600""", (change_id, target_key)).fetchall()
    return jsonable({"lines": [dict(r) for r in lines]})


@app.get("/api/v1/agent/packages/{package_id}/file")
def agent_package_file(package_id: str, request: Request, offset: int = 0, length: int = 16 * 2 ** 20,
                       agent: AgentIdentity = Depends(require_agent)):
    """One piece of a package, for a server that is running that package's job now."""
    from fastapi.responses import Response
    from . import deploy
    if not deploy.ID_RE.match(package_id):
        raise HTTPException(404, "Not found.")
    with db() as conn:
        cmd = conn.execute(
            """SELECT c.id::text AS id FROM agent_commands c JOIN changes ch ON ch.id = c.change_id
                WHERE c.host_id = %s AND c.verb = 'software_action' AND c.params->>'package_id' = %s
                  AND c.claimed_at IS NOT NULL AND c.completed_at IS NULL AND ch.state = 'running'
                LIMIT 1""", (agent.host_id, package_id)).fetchone()
        if not cmd:
            raise HTTPException(403, "This server has no running job for that package.")
        try:
            p = deploy.get(conn, package_id)
        except deploy.NotFound:
            raise HTTPException(410, "The package was removed from PATCH-01.")
        if offset == 0:
            _audit(conn, agent.hostname, "package_download_started", "package", package_id,
                   {"command": cmd["id"], "file": p["file_name"]}, client_ip(request), actor_type="agent")
            conn.commit()
    try:
        data = deploy.read_piece(p, int(offset), int(length))
    except deploy.Invalid as e:
        raise HTTPException(416, str(e))
    except OSError:
        raise HTTPException(410, "The package file is missing on PATCH-01.")
    return Response(data, media_type="application/octet-stream",
                    headers={"Cache-Control": "no-store", "X-Total-Size": str(p["size_bytes"])})


@app.get("/api/v1/admin/agent-updates")
def agent_updates_view(user: str = Depends(require_viewer)):
    """The agents published on PATCH-01 and where each server stands."""
    from . import agent_updates as au
    with db() as conn:
        return jsonable(au.fleet(conn))


@app.get("/api/v1/agent/update-file")
def agent_update_file(request: Request, agent: AgentIdentity = Depends(require_agent)):
    """The new agent file, for a server running its update step now, and only
    the exact file (SHA-256) frozen in that change."""
    from fastapi.responses import Response
    from . import agent_updates as au
    with db() as conn:
        cmd = conn.execute(
            """SELECT c.id::text AS id, c.params FROM agent_commands c JOIN changes ch ON ch.id = c.change_id
                 JOIN change_targets ct ON ct.change_id = c.change_id AND ct.current_command = c.id AND ct.state = 'update'
                WHERE c.host_id = %s AND c.verb = 'update_agent' AND ch.kind = 'agent_update' AND ch.state = 'running'
                  AND c.claimed_at IS NOT NULL AND c.completed_at IS NULL
                ORDER BY c.claimed_at DESC LIMIT 1""", (agent.host_id,)).fetchone()
        if not cmd:
            raise HTTPException(403, "This server has no running agent update.")
        p = cmd["params"] or {}
        plat, ver, sha = str(p.get("platform") or ""), str(p.get("version") or ""), str(p.get("sha256") or "")
        try:
            data = au.read_for(plat, ver, sha)
        except au.Invalid as e:
            raise HTTPException(410, str(e))
        except (OSError, KeyError):
            raise HTTPException(410, "The agent file is missing on PATCH-01.")
        _audit(conn, agent.hostname, "agent_update_download", "command", cmd["id"],
               {"platform": plat, "version": ver, "sha256": sha}, client_ip(request), actor_type="agent")
        conn.commit()
    return Response(data, media_type="application/octet-stream",
                    headers={"Cache-Control": "no-store", "X-Total-Size": str(len(data))})


class RunStatsIn(BaseModel):
    seconds: float = Field(..., ge=0, le=86400)
    commands: int = Field(default=0, ge=0, le=1000)
    phases: Dict[str, float] = Field(default_factory=dict)
    slowest: Optional[str] = Field(default=None, max_length=60)


@app.post("/api/v1/agent/run-stats")
def agent_run_stats(body: RunStatsIn, agent: AgentIdentity = Depends(require_agent)):
    """How long the agent's last run took, and which part (Windows agent 1.6.0+)."""
    phases = {}
    for k, v in list(body.phases.items())[:30]:
        if re.match(r"^[A-Za-z][A-Za-z0-9_ -]{0,39}$", str(k)) and isinstance(v, (int, float)) and 0 <= v <= 86400:
            phases[k] = round(float(v), 1)
    slowest = body.slowest if body.slowest in phases else None
    doc = {"seconds": round(body.seconds, 1), "commands": body.commands, "phases": phases, "slowest": slowest,
           "at": datetime.now(timezone.utc).isoformat()}
    try:
        with db() as conn:
            conn.execute("UPDATE hosts SET agent_run = %s WHERE id = %s", (json.dumps(doc), agent.host_id))
            conn.commit()
    except psycopg.errors.UndefinedColumn:
        pass                          # schema 036 not applied yet: ignored, the agent carries on
    return {"ok": True}


@app.get("/api/v1/impact")
def impact_list(verdict: Optional[str] = None, user: str = Depends(require_viewer)):
    """The new critical, high and exploited CVEs that really affect our environment: proven on
    a server (Windows, Linux, ESXi, vCenter), and apart from them the ones that name an appliance
    in the asset inventory. With the graphs' figures and the state of an on-demand scan."""
    from . import cve_feeds, cve_impact
    with db() as conn:
        days = int(cve_feeds.settings(conn).get("days_back") or 14)
        items = [dict(r) for r in cve_impact.listing(conn, days)]
        appl = [dict(r) for r in cve_impact.appliance_listing(conn, days)]
        return jsonable({"days": days, "counts": cve_impact.counts(conn, days), "items": items, "appliances": appl,
                         "graphs": cve_impact.graphs(conn, days, items), "scan": _impact_scan_state(conn),
                         "every_hours": cve_impact.REANALYSE_HOURS})


def _impact_scan_state(conn):
    """The last on-demand scan: when, by whom, how many servers were asked and have reported since."""
    try:
        with conn.transaction():
            s = conn.execute("SELECT scan_requested_at, scan_requested_by, scan_servers FROM cve_feed_settings WHERE id = 1").fetchone()
            if not s or not s["scan_requested_at"]:
                return None
            from . import cve_feeds
            days = int(cve_feeds.settings(conn).get("days_back") or 14)
            r = conn.execute(
                """WITH w AS (SELECT analysed_at FROM cve_impact
                               WHERE published >= now() - make_interval(days => %(d)s::int)
                                 AND EXISTS (SELECT 1 FROM cve_feed_items f WHERE f.cve_id = cve_impact.cve_id))
                   SELECT (SELECT count(*) FROM hosts WHERE status <> 'decommissioned' AND last_inventory >= %(t)s) AS reported,
                          (SELECT count(*) FROM w WHERE analysed_at >= %(t)s) AS analysed,
                          (SELECT count(*) FROM w) AS total""", {"t": s["scan_requested_at"], "d": days}).fetchone()
    except Exception:  # noqa: BLE001 - schema 045 not applied
        return None
    return {"at": s["scan_requested_at"], "by": s["scan_requested_by"], "servers": s["scan_servers"],
            "reported": r["reported"], "analysed": r["analysed"], "total": r["total"]}


IMPACT_SCAN_MIN_GAP = timedelta(minutes=10)


@app.post("/api/v1/impact/scan")
def impact_scan(request: Request, user: str = Depends(require_operator)):
    """An on-demand scan: every reporting server sends its inventory now (installed packages,
    programs, updates), vCenter is read again, and every CVE in the window is checked again as
    the answers come in."""
    with db() as conn:
        with conn.transaction():
            last = conn.execute("SELECT scan_requested_at FROM cve_feed_settings WHERE id = 1 FOR UPDATE").fetchone()
            if last and last["scan_requested_at"] and now() - last["scan_requested_at"] < IMPACT_SCAN_MIN_GAP:
                raise HTTPException(429, "A scan was started less than 10 minutes ago: it is still collecting the inventories.")
            # A command for each server whose agent reported in the last day and has none waiting
            n = conn.execute(
                """INSERT INTO agent_commands (host_id, verb, params, expires_at)
                   SELECT h.id, 'collect_inventory', '{"reason": "on-demand vulnerability scan"}'::jsonb, now() + interval '3 hours'
                     FROM hosts h
                    WHERE h.status <> 'decommissioned' AND h.last_checkin > now() - interval '1 day'
                      AND NOT EXISTS (SELECT 1 FROM agent_commands c WHERE c.host_id = h.id AND c.verb = 'collect_inventory'
                                        AND c.claimed_at IS NULL AND c.expires_at > now())
                   RETURNING host_id""").fetchall()
            # Servers asked: the new commands and those still waiting from before
            n = conn.execute("""SELECT DISTINCT host_id FROM agent_commands WHERE verb = 'collect_inventory'
                                   AND claimed_at IS NULL AND expires_at > now()""").fetchall()
            conn.execute("UPDATE vcenters SET sync_requested_at = now()")
            conn.execute("UPDATE cve_impact SET inventory_mark = NULL")
            conn.execute("""UPDATE cve_feed_settings SET scan_requested_at = now(), scan_requested_by = %s, scan_servers = %s,
                                   impact_requested_at = now() WHERE id = 1""", (user, len(n)))
            audit(conn, actor=user, actor_type="user", action="impact_scan_requested", detail={"servers": len(n)},
                  source_ip=client_ip(request))
    _feeds_cache_clear()
    return {"ok": True, "servers": len(n)}


@app.get("/api/v1/impact/export")
def impact_export(request: Request, format: str = "xlsx", user: str = Depends(require_viewer)):
    """Excel: a summary, the affected CVEs, every affected machine with its evidence, and the
    appliances. PDF: the affected CVEs, each with its machines. CSV: one row per CVE and machine."""
    from fastapi.responses import Response
    from . import cve_feeds, cve_impact, exports as ex, impact_report as irep
    if format not in ("csv", "pdf", "xlsx"):
        raise HTTPException(422, "format must be xlsx, pdf or csv")
    with db() as conn:
        days = int(cve_feeds.settings(conn).get("days_back") or 14)
        items = [dict(r) for r in cve_impact.listing(conn, days, limit=2000)]
        appl = [dict(r) for r in cve_impact.appliance_listing(conn, days, limit=2000)]
        c = cve_impact.counts(conn, days)
        body, mime, ext, n = irep.render(conn, format, user, days, items, appl, c, ex.TZ)
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="impact_exported", detail={"format": format, "rows": n},
                  source_ip=client_ip(request))
    return Response(body, media_type=mime, headers={
        "Content-Disposition": f'attachment; filename="{ex.file_name("vulnerabilities", ext)}"',
        "Cache-Control": "no-store", "X-Rows": str(n)})


def _feeds_cache_clear():
    for k in [k for k in _PUBLIC_CACHE if k.startswith(("feeds-", "news"))]:
        _PUBLIC_CACHE.pop(k, None)


@app.get("/api/v1/public/brand")
def public_brand():
    """What the sign-in page needs before anyone has signed in: the portal's
    name and whether a logo exists. Nothing else about this installation."""
    def build():
        from . import branding as br
        try:
            with db() as conn:
                b = br.settings(conn)
            return {"portal": "Cyber-Secure", "has_logo": bool(b.get("logo")), "has_logo_white": bool(b.get("logo_white"))}
        except Exception:  # noqa: BLE001
            return {"portal": "Cyber-Secure", "has_logo": False, "has_logo_white": False}
    return JSONResponse(_public_cached("brand", build), headers={"Cache-Control": "public, max-age=120"})


@app.get("/api/v1/public/logo")
def public_logo(variant: str = "main"):
    """The same processed logo as the mails and reports use."""
    from fastapi.responses import Response
    if variant not in ("main", "white"):
        raise HTTPException(422, "variant must be main or white")

    def build():
        from . import branding as br
        with db() as conn:
            b = br.settings(conn)
        return b.get("logo_white") if variant == "white" else b.get("logo")
    data = _public_cached("logo-" + variant, build)
    if not data:
        raise HTTPException(404, "No logo.")
    return Response(data, media_type="image/png",
                    headers={"Cache-Control": "public, max-age=300", "X-Content-Type-Options": "nosniff"})


@app.get("/api/v1/public/news")
def public_news():
    """The sign-in page's news board: the latest CVEs NIST, Microsoft and Red
    Hat published, from the general feeds only. The watch list is never used
    here, so nothing on this page says what software runs behind it."""
    from . import cve_feeds

    def build():
        try:
            with db() as conn:
                return jsonable(cve_feeds.public_news(conn))
        except Exception:  # noqa: BLE001 - schema 022 not applied yet
            return {"enabled": False, "sources": {}}
    return JSONResponse(_public_cached("news", build), headers={"Cache-Control": "public, max-age=120"})


def _feeds_admin_view(conn):
    from . import cve_feeds
    return jsonable({
        "settings": cve_feeds.settings(conn),
        "watch": conn.execute("SELECT id, term, kind, enabled, added_by, added_at FROM cve_feed_watch ORDER BY lower(term)").fetchall(),
        "state": conn.execute("SELECT * FROM cve_feed_state ORDER BY source").fetchall(),
        "stored": conn.execute("SELECT source, count(*) AS n, max(published) AS newest FROM cve_feed_items GROUP BY 1 ORDER BY 1").fetchall(),
        # The worker reads the feeds, so it is the worker's key that counts
        "nvd_api_key": bool(((conn.execute("SELECT detail FROM worker_heartbeat WHERE name = 'feeds'").fetchone()
                              or {}).get("detail") or {}).get("nvd_key")),
        "worker_seen": bool(conn.execute("SELECT 1 FROM worker_heartbeat WHERE name = 'feeds'").fetchone())})


@app.get("/api/v1/admin/feeds")
def feeds_admin(admin: str = Depends(require_admin)):
    with db() as conn:
        return _feeds_admin_view(conn)


class FeedSettingsIn(BaseModel):
    nist: bool = True
    msrc: bool = True
    redhat: bool = True
    days_back: int = Field(14, ge=1, le=90)
    min_cvss: float = Field(0, ge=0, le=10)
    interval_minutes: int = Field(60, ge=15, le=1440)
    signin_board: bool = True
    signin_min_cvss: float = Field(7.0, ge=0, le=10)


@app.put("/api/v1/admin/feeds/settings")
def feeds_settings_put(body: FeedSettingsIn, request: Request, admin: str = Depends(require_admin)):
    with db() as conn:
        with conn.transaction():
            conn.execute(
                """UPDATE cve_feed_settings SET nist=%s, msrc=%s, redhat=%s, days_back=%s, min_cvss=%s,
                          interval_minutes=%s, signin_board=%s, signin_min_cvss=%s,
                          updated_by=%s, updated_at=now() WHERE id=1""",
                (body.nist, body.msrc, body.redhat, body.days_back, body.min_cvss, body.interval_minutes,
                 body.signin_board, body.signin_min_cvss, admin))
            audit(conn, actor=admin, actor_type="user", action="feeds_settings_saved",
                  detail=body.model_dump(), source_ip=client_ip(request))
        _feeds_cache_clear()
        return _feeds_admin_view(conn)


class FeedWatchIn(BaseModel):
    term: str = Field(..., min_length=2, max_length=60)
    kind: str = Field("software", pattern="^(software|vendor|keyword)$")


@app.post("/api/v1/admin/feeds/watch")
def feeds_watch_add(body: FeedWatchIn, request: Request, admin: str = Depends(require_admin)):
    from . import cve_feeds
    try:
        term = cve_feeds.clean_term(body.term)
    except ValueError as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        try:
            with conn.transaction():
                # One change to the list at a time, so the checks below hold
                conn.execute("SELECT pg_advisory_xact_lock(hashtext('cve_feed_watch'))")
                if conn.execute("SELECT 1 FROM cve_feed_watch WHERE lower(term) = lower(%s)", (term,)).fetchone():
                    raise HTTPException(409, f"{term} is already on the watch list.")
                if conn.execute("SELECT count(*) AS n FROM cve_feed_watch").fetchone()["n"] >= 200:
                    raise HTTPException(409, "The watch list holds at most 200 entries.")
                conn.execute("INSERT INTO cve_feed_watch (term, pattern, kind, added_by) VALUES (%s, %s, %s, %s)",
                             (term, cve_feeds.term_pattern(term), body.kind, admin))
                audit(conn, actor=admin, actor_type="user", action="feeds_watch_added",
                      detail={"term": term, "kind": body.kind}, source_ip=client_ip(request))
        except psycopg.errors.UniqueViolation:
            raise HTTPException(409, f"{term} is already on the watch list.")
        _feeds_cache_clear()
        return _feeds_admin_view(conn)


@app.patch("/api/v1/admin/feeds/watch/{wid}")
def feeds_watch_toggle(wid: int, request: Request, enabled: bool = Body(..., embed=True),
                       admin: str = Depends(require_admin)):
    with db() as conn:
        with conn.transaction():
            r = conn.execute("UPDATE cve_feed_watch SET enabled=%s WHERE id=%s RETURNING term", (enabled, wid)).fetchone()
            if not r:
                raise HTTPException(404, "No such entry.")
            audit(conn, actor=admin, actor_type="user", action="feeds_watch_" + ("enabled" if enabled else "disabled"),
                  detail={"term": r["term"]}, source_ip=client_ip(request))
        _feeds_cache_clear()
        return _feeds_admin_view(conn)


@app.delete("/api/v1/admin/feeds/watch/{wid}")
def feeds_watch_remove(wid: int, request: Request, admin: str = Depends(require_admin)):
    with db() as conn:
        with conn.transaction():
            r = conn.execute("DELETE FROM cve_feed_watch WHERE id=%s RETURNING term", (wid,)).fetchone()
            if not r:
                raise HTTPException(404, "No such entry.")
            audit(conn, actor=admin, actor_type="user", action="feeds_watch_removed",
                  detail={"term": r["term"]}, source_ip=client_ip(request))
        _feeds_cache_clear()
        return _feeds_admin_view(conn)


@app.post("/api/v1/admin/feeds/sync")
def feeds_sync_now(request: Request, admin: str = Depends(require_admin)):
    """Ask the worker to read the feeds now (within a minute)."""
    with db() as conn:
        with conn.transaction():
            conn.execute("UPDATE cve_feed_settings SET run_requested_at=now() WHERE id=1")
            audit(conn, actor=admin, actor_type="user", action="feeds_sync_requested", detail={},
                  source_ip=client_ip(request))
        return _feeds_admin_view(conn)


# Server software worth following that is commonly installed on Linux; offered
# as suggestions when one of your servers has it.
LINUX_NOTABLE = ["openssl", "openssh", "httpd", "nginx", "tomcat", "java", "postgresql", "mysql", "mariadb", "php",
                 "python3", "bind", "samba", "docker", "podman", "curl", "sudo", "glibc", "kernel", "systemd",
                 "polkit", "git", "redis", "haproxy", "squid", "postfix", "dovecot", "vim", "bash", "rsync"]
assert not any("-" in n for n in LINUX_NOTABLE), "feeds_suggestions matches a name by the part before its first hyphen"


@app.get("/api/v1/admin/feeds/suggestions")
def feeds_suggestions(admin: str = Depends(require_admin)):
    """Software to choose from: what your servers run, most common first."""
    with db() as conn:
        win = conn.execute(
            r"""SELECT regexp_replace(regexp_replace(name, '\s*\(?\d[\d.]*(\s*\(?(x64|x86|64-bit|32-bit)\)?)?\)?\s*$', ''),
                                      '\s+', ' ', 'g') AS name, count(DISTINCT host_id) AS servers
                  FROM windows_software
                 WHERE name !~* '^(security update|update for|hotfix|microsoft visual c\+\+ 20\d\d (x64|x86) (minimum|additional) runtime)'
                 GROUP BY 1
                 ORDER BY 2 DESC, 1 LIMIT 80""").fetchall()
        # A package is "n" or "n-something" (openssl, openssl-libs). No name on the list has a hyphen, so that is
        # the part before the first hyphen: one pass over the packages instead of one per name (r90)
        lin = conn.execute(
            """SELECT split_part(hp.name, '-', 1) AS name, count(DISTINCT hp.host_id) AS servers
                 FROM host_packages hp
                WHERE split_part(hp.name, '-', 1) = ANY(%s::text[])
                GROUP BY 1 ORDER BY 2 DESC, 1""", (LINUX_NOTABLE,)).fetchall()
        oses = conn.execute(
            f"""SELECT DISTINCT {OS_LABEL_SQL} AS name FROM hosts h WHERE h.status <> 'decommissioned' ORDER BY 1""").fetchall()
        have = {r["term"].lower() for r in conn.execute("SELECT term FROM cve_feed_watch").fetchall()}
    import re as _re
    ok = _re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._+-]{1,59}$")

    seen = set()

    def keep(rows, kind):
        out = []
        for r in rows:
            n = _re.sub(r"\s*\((x64|x86|64-bit|32-bit)\)\s*$", "", (r["name"] or "").strip(), flags=_re.I)
            if ok.match(n) and n.lower() not in have and n.lower() not in seen:
                seen.add(n.lower())
                out.append({"name": n, "servers": r.get("servers"), "kind": kind})
        return out
    return {"windows": keep(win, "software"), "linux": keep(lin, "software"),
            "os": keep([{"name": r["name"].replace("RHEL", "Red Hat Enterprise Linux")} for r in oses], "software")}
