"""Antivirus: Trend Micro Apex Central consoles and their products (read-only).

Split out of main.py in r90; the code is unchanged."""

import os
import psycopg
import re
from datetime import datetime, timezone
from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field
from typing import List, Optional

from .core import (app, audit, client_ip, db, jsonable, log, require_admin, require_viewer)


# ---------------------------------------------------------------------------
# Antivirus: Trend Micro Apex Central consoles (read-only)
# ---------------------------------------------------------------------------


AV_TESTS_PER_10MIN = 20


class AvConsoleIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=60)
    url: str = Field(..., min_length=9, max_length=300)
    app_id: Optional[str] = Field(None, max_length=80)        # blank on edit: keep the saved one
    api_key: Optional[str] = Field(None, max_length=200)      # blank on edit: keep the saved one
    ca_pem: Optional[str] = Field(None, max_length=20000)
    use_proxy: bool = False
    enabled: bool = True
    pin_sha256: Optional[str] = Field(None, max_length=120)   # None: keep; "": remove; value: trust this certificate


class AvTestIn(BaseModel):
    id: Optional[str] = Field(None, max_length=36)            # test a saved console (its saved key) ...
    url: Optional[str] = Field(None, max_length=300)          # ... or what is typed in the form
    app_id: Optional[str] = Field(None, max_length=80)
    api_key: Optional[str] = Field(None, max_length=200)
    ca_pem: Optional[str] = Field(None, max_length=20000)
    use_proxy: bool = False
    pin_sha256: Optional[str] = Field(None, max_length=120)   # None: keep; "": remove; value: trust this certificate


def _av_view(conn):
    from . import antivirus as av
    cons = av.consoles(conn)
    try:
        with conn.transaction():
            from . import av_logs
            for c in cons:
                c["logs"] = av_logs.availability(conn, c["id"])
    except psycopg.errors.UndefinedTable:
        pass
    products_ready = True
    try:                                            # product servers under each console (schema 034)
        with conn.transaction():
            from . import av_products
            by = {}
            for p in av_products.listing(conn):
                by.setdefault(str(p["console_id"]), []).append(p)
            flags = {str(r["id"]): r for r in conn.execute(
                "SELECT id, products_chosen, products_checked_at FROM av_consoles").fetchall()}
            for c in cons:
                c["products"] = by.get(str(c["id"]), [])
                f = flags.get(str(c["id"])) or {}
                c["products_chosen"], c["products_checked_at"] = bool(f.get("products_chosen")), f.get("products_checked_at")
    except (psycopg.errors.UndefinedTable, psycopg.errors.UndefinedColumn):
        products_ready = False
    return {"consoles": cons, "key_ready": os.access(av.KEY_FILE, os.R_OK),
            "sync_minutes": av.SYNC_MINUTES, "products_ready": products_ready}


def _av_id(cid):
    if not re.fullmatch(r"[0-9a-f-]{36}", cid or ""):
        raise HTTPException(404, "No such console.")
    return cid


class AvCertIn(BaseModel):
    id: Optional[str] = Field(None, max_length=36)
    url: Optional[str] = Field(None, max_length=300)
    use_proxy: bool = False


def _av_pin_check(url, use_proxy, pin):
    """The console must present the pinned certificate now, so a typo or a
    certificate changed in the meantime is caught when saving."""
    from . import antivirus as av
    cert = av.fetch_certificate({"url": url, "use_proxy": use_proxy})
    if cert["sha256"] != pin:
        raise av.AvError("The console now presents a different certificate (SHA-256 " + cert["sha256_text"]
                         + "): get it again and compare.")
    return cert


@app.post("/api/v1/admin/antivirus/certificate")
def av_certificate(body: AvCertIn, request: Request, admin: str = Depends(require_admin)):
    """The certificate the console presents (handshake only: nothing is sent),
    with both fingerprints, for the admin to compare and trust."""
    from . import antivirus as av
    with db() as conn:
        n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action IN ('av_console_tested', 'av_certificate_read')
                              AND occurred_at > now() - interval '10 minutes'""", (admin,)).fetchone()["n"]
        if n >= AV_TESTS_PER_10MIN:
            raise HTTPException(429, f"At most {AV_TESTS_PER_10MIN} checks in 10 minutes: try again shortly.")
        saved = conn.execute("SELECT url, use_proxy, pin_sha256 FROM av_consoles WHERE id = %s", (_av_id(body.id),)).fetchone() \
            if body.id else None
        try:
            url = av.clean_url(body.url) if body.url else (saved or {}).get("url")
            if not url:
                raise av.AvError("Enter the console URL.")
        except av.AvError as e:
            raise HTTPException(422, str(e))
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="av_certificate_read", object_type="av_console",
                  object_id=body.id, detail={"url": url}, source_ip=client_ip(request))
    try:
        cert = av.fetch_certificate({"url": url, "use_proxy": body.use_proxy if body.url or not saved else saved["use_proxy"]})
    except av.AvError as e:
        raise HTTPException(422, str(e))
    cert["pinned_now"] = bool(saved and saved["pin_sha256"] == cert["sha256"])
    return cert


@app.get("/api/v1/admin/antivirus")
def av_admin(admin: str = Depends(require_admin)):
    with db() as conn:
        return jsonable(_av_view(conn))


@app.post("/api/v1/admin/antivirus/test")
def av_test(body: AvTestIn, request: Request, admin: str = Depends(require_admin)):
    """Sign in to Apex Central and list its agents, without saving them. With
    an id and no key typed, the saved key is used (it never leaves PATCH-01)."""
    from . import antivirus as av
    with db() as conn:
        n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'av_console_tested'
                              AND occurred_at > now() - interval '10 minutes'""", (admin,)).fetchone()["n"]
        if n >= AV_TESTS_PER_10MIN:
            raise HTTPException(429, f"At most {AV_TESTS_PER_10MIN} tests in 10 minutes: try again shortly.")
        saved = None
        if body.id:
            saved = conn.execute("SELECT * FROM av_consoles WHERE id = %s", (_av_id(body.id),)).fetchone()
            if not saved:
                raise HTTPException(404, "No such console.")
        try:
            url = av.clean_url(body.url) if body.url else (saved or {}).get("url")
            console = {"url": url,
                       "app_id": av.clean_app_id(body.app_id) if body.app_id else (saved or {}).get("app_id"),
                       # None: the saved CA; "": none (the form's "remove"); text: this CA
                       "ca_pem": (saved or {}).get("ca_pem") if body.ca_pem is None else av.clean_ca(body.ca_pem),
                       "use_proxy": body.use_proxy,
                       "pin_sha256": (saved or {}).get("pin_sha256") if body.pin_sha256 is None else av.clean_pin(body.pin_sha256)}
            if saved and url != saved["url"] and body.pin_sha256 is None:
                console["pin_sha256"] = None              # a pinned certificate belongs to its own address
            if not console["url"] or not console["app_id"]:
                raise av.AvError("Enter the console URL and the Application ID.")
            if body.api_key:
                key = av.clean_key(body.api_key)
            elif saved and url == saved["url"]:
                key = av.decrypt(saved["api_key_enc"])          # the saved key only ever signs for its own console
            elif saved:
                raise av.AvError("The URL differs from the saved one: enter the API key again to test it.")
            else:
                raise av.AvError("Enter the API key.")
        except av.AvError as e:
            raise HTTPException(422, str(e))
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="av_console_tested", object_type="av_console",
                  object_id=body.id, detail={"url": console["url"]}, source_ip=client_ip(request))
        conn.commit()
    started = datetime.now(timezone.utc)
    try:
        agents, truncated, fields = av.list_agents(console, key, with_fields=True)
        sm = av.summary(agents)
        sm["fields"] = fields
        sm["health"] = {"definitions": sum(1 for a in agents if a.get("pattern_version")),
                        "connection": sum(1 for a in agents if a.get("last_connected") or a.get("online") is not None)}
        result = {"ok": True, "message": f"Signed in. Apex Central lists {sm['agents']}"
                                         + ("+" if truncated else "") + " agents.", **sm,
                  "sample": [a["host_name"] for a in agents[:5]],
                  "ms": int((datetime.now(timezone.utc) - started).total_seconds() * 1000)}
    except av.AvError as e:
        result = {"ok": False, "message": str(e)}
    except Exception as e:  # noqa: BLE001 - never a 500 with a stack trace from a far end's answer
        log.warning("antivirus test: %s", type(e).__name__)
        result = {"ok": False, "message": "The console's answer could not be read."}
    finally:
        key = None
    if saved:
        with db() as conn:
            conn.execute("UPDATE av_consoles SET last_test_at = now(), last_test_ok = %s, last_test_msg = %s WHERE id = %s",
                         (result["ok"], result["message"][:400], saved["id"]))
            conn.commit()
    return result


@app.post("/api/v1/admin/antivirus")
def av_create(body: AvConsoleIn, request: Request, admin: str = Depends(require_admin)):
    from . import antivirus as av
    try:
        name = body.name.strip()
        if not av.NAME_RE.match(name):
            raise av.AvError("The name may use letters, digits, spaces and . _ ( ) -")
        url, app_id = av.clean_url(body.url), av.clean_app_id(body.app_id)
        key_enc = av.encrypt(av.clean_key(body.api_key))
        ca = av.clean_ca(body.ca_pem)
        pin = av.clean_pin(body.pin_sha256)
        pin_cert = _av_pin_check(url, body.use_proxy, pin) if pin else None
    except av.AvError as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        with conn.transaction():
            if conn.execute("SELECT 1 FROM av_consoles WHERE lower(name) = lower(%s) OR url = %s", (name, url)).fetchone():
                raise HTTPException(409, "A console with this name or URL is already added.")
            try:
                with conn.transaction():
                    r = conn.execute(
                        """INSERT INTO av_consoles (name, url, app_id, api_key_enc, ca_pem, use_proxy, enabled, created_by,
                                                    sync_requested_at, pin_sha256, pin_subject, pin_not_after, pinned_by, pinned_at)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s, now(), %s,%s,%s,%s, CASE WHEN %s::text IS NULL THEN NULL ELSE now() END)
                           RETURNING id""",
                        (name, url, app_id, key_enc, ca, body.use_proxy, body.enabled, admin, pin,
                         (pin_cert or {}).get("subject"), (pin_cert or {}).get("not_after"), admin if pin else None, pin)).fetchone()
            except psycopg.errors.UniqueViolation:
                raise HTTPException(409, "A console with this name is already added.")
            audit(conn, actor=admin, actor_type="user", action="av_console_added", object_type="av_console",
                  object_id=str(r["id"]), detail={"name": name, "url": url, "ca": bool(ca), "proxy": body.use_proxy,
                                                  "pinned_sha256": pin},
                  source_ip=client_ip(request))
        return jsonable(_av_view(conn))


@app.put("/api/v1/admin/antivirus/{cid}")
def av_update(cid: str, body: AvConsoleIn, request: Request, admin: str = Depends(require_admin)):
    from . import antivirus as av
    cid = _av_id(cid)
    try:
        name = body.name.strip()
        if not av.NAME_RE.match(name):
            raise av.AvError("The name may use letters, digits, spaces and . _ ( ) -")
        url = av.clean_url(body.url)
        app_id = av.clean_app_id(body.app_id) if body.app_id else None
        key_enc = av.encrypt(av.clean_key(body.api_key)) if body.api_key else None
        ca = av.clean_ca(body.ca_pem) if body.ca_pem is not None else None
        pin = av.clean_pin(body.pin_sha256) if body.pin_sha256 else None
        pin_cert = _av_pin_check(url, body.use_proxy, pin) if pin else None
    except av.AvError as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        with conn.transaction():
            cur = conn.execute("SELECT url FROM av_consoles WHERE id = %s", (cid,)).fetchone()
            if not cur:
                raise HTTPException(404, "No such console.")
            if url != cur["url"] and not key_enc:
                # The saved key never signs for another address
                raise HTTPException(422, "The URL has changed: enter the API key again.")
            if conn.execute("SELECT 1 FROM av_consoles WHERE id <> %s AND (lower(name) = lower(%s) OR url = %s)",
                            (cid, name, url)).fetchone():
                raise HTTPException(409, "Another console has this name or URL.")
            try:
                with conn.transaction():
                    conn.execute(
                        """UPDATE av_consoles SET name = %s, url = %s, app_id = coalesce(%s, app_id),
                                  api_key_enc = coalesce(%s, api_key_enc),
                                  ca_pem = CASE WHEN %s::boolean THEN %s ELSE ca_pem END,
                                  use_proxy = %s, enabled = %s, updated_by = %s, updated_at = now(),
                                  sync_requested_at = now(),
                                  pin_sha256 = CASE WHEN %s THEN %s WHEN url <> %s THEN NULL ELSE pin_sha256 END,
                                  pin_subject = CASE WHEN %s THEN %s WHEN url <> %s THEN NULL ELSE pin_subject END,
                                  pin_not_after = CASE WHEN %s THEN %s::timestamptz WHEN url <> %s THEN NULL ELSE pin_not_after END,
                                  pinned_by = CASE WHEN %s THEN %s WHEN url <> %s THEN NULL ELSE pinned_by END,
                                  pinned_at = CASE WHEN %s THEN (CASE WHEN %s::text IS NULL THEN NULL ELSE now() END)
                                                   WHEN url <> %s THEN NULL ELSE pinned_at END
                            WHERE id = %s""",
                        (name, url, app_id, key_enc, body.ca_pem is not None, ca, body.use_proxy, body.enabled, admin,
                         body.pin_sha256 is not None, pin, url,
                         body.pin_sha256 is not None, (pin_cert or {}).get("subject"), url,
                         body.pin_sha256 is not None, (pin_cert or {}).get("not_after"), url,
                         body.pin_sha256 is not None, admin if pin else None, url,
                         body.pin_sha256 is not None, pin, url, cid))
            except psycopg.errors.UniqueViolation:
                raise HTTPException(409, "Another console has this name.")
            audit(conn, actor=admin, actor_type="user", action="av_console_changed", object_type="av_console",
                  object_id=cid, detail={"name": name, "url": url, "app_id": "replaced" if app_id else "unchanged",
                                         "api_key": "replaced" if key_enc else "unchanged",
                                         "ca": "changed" if body.ca_pem is not None else "unchanged",
                                         "pinned_sha256": pin if body.pin_sha256 else ("removed" if body.pin_sha256 == "" else "unchanged"),
                                         "enabled": body.enabled}, source_ip=client_ip(request))
        return jsonable(_av_view(conn))


@app.delete("/api/v1/admin/antivirus/{cid}")
def av_delete(cid: str, request: Request, admin: str = Depends(require_admin)):
    cid = _av_id(cid)
    with db() as conn:
        with conn.transaction():
            r = conn.execute("DELETE FROM av_consoles WHERE id = %s RETURNING name, url", (cid,)).fetchone()
            if not r:
                raise HTTPException(404, "No such console.")
            audit(conn, actor=admin, actor_type="user", action="av_console_removed", object_type="av_console",
                  object_id=cid, detail=dict(r), source_ip=client_ip(request))
        return jsonable(_av_view(conn))


@app.post("/api/v1/admin/antivirus/{cid}/sync")
def av_sync(cid: str, request: Request, admin: str = Depends(require_admin)):
    cid = _av_id(cid)
    with db() as conn:
        with conn.transaction():
            r = conn.execute("UPDATE av_consoles SET sync_requested_at = now() WHERE id = %s AND enabled RETURNING name",
                             (cid,)).fetchone()
            if not r:
                raise HTTPException(404, "No such console, or it is turned off.")
            audit(conn, actor=admin, actor_type="user", action="av_sync_requested", object_type="av_console",
                  object_id=cid, detail={"name": r["name"]}, source_ip=client_ip(request))
        return jsonable(_av_view(conn))


# ---------------------------------------------------------------------------
# Products under each Apex Central (schema 034): discover, tick which to sync,
# and read a Deep Security Manager directly with its own API key
# ---------------------------------------------------------------------------


def _av_pid(pid):
    if not re.fullmatch(r"[0-9a-f-]{36}", pid or ""):
        raise HTTPException(404, "No such product server.")
    return pid


def _av_checks(conn, admin, limit_actions=("av_console_tested", "av_certificate_read", "av_products_discovered",
                                           "av_dsm_tested", "av_dsm_certificate_read")):
    n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = ANY(%s)
                          AND occurred_at > now() - interval '10 minutes'""", (admin, list(limit_actions))).fetchone()["n"]
    if n >= AV_TESTS_PER_10MIN:
        raise HTTPException(429, f"At most {AV_TESTS_PER_10MIN} checks in 10 minutes: try again shortly.")


def _av_products_ready(conn):
    try:
        with conn.transaction():
            conn.execute("SELECT 1 FROM av_products LIMIT 1")
    except (psycopg.errors.UndefinedTable, psycopg.errors.UndefinedColumn):
        raise HTTPException(503, "Product servers need schema 034: run phase3a-schema.sh.")


@app.post("/api/v1/admin/antivirus/{cid}/products/discover")
def av_products_discover(cid: str, request: Request, admin: str = Depends(require_admin)):
    """Ask Apex Central which product servers it manages (Apex One servers,
    Deep Security Managers, email security). Nothing is synced until ticked."""
    from . import antivirus as av, av_products
    cid = _av_id(cid)
    with db() as conn:
        _av_products_ready(conn)
        _av_checks(conn, admin)
        if not conn.execute("SELECT 1 FROM av_consoles WHERE id = %s", (cid,)).fetchone():
            raise HTTPException(404, "No such console.")
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="av_products_discovered", object_type="av_console",
                  object_id=cid, detail={}, source_ip=client_ip(request))
        conn.commit()
        try:
            items = av_products.discover(conn, cid)
        except av.AvError as e:
            conn.rollback()
            raise HTTPException(422, str(e))
        except Exception as e:  # noqa: BLE001 - never the far end's text
            conn.rollback()
            log.warning("antivirus products: %s", type(e).__name__)
            raise HTTPException(422, "The console's product list could not be read.")
        return jsonable({"products": items, **_av_view(conn)})


@app.get("/api/v1/admin/antivirus/{cid}/products")
def av_products_list(cid: str, admin: str = Depends(require_admin)):
    from . import av_products
    cid = _av_id(cid)
    with db() as conn:
        _av_products_ready(conn)
        return jsonable({"products": av_products.listing(conn, cid)})


class AvChooseIn(BaseModel):
    selected: List[str] = Field(default_factory=list, max_length=500)


@app.put("/api/v1/admin/antivirus/{cid}/products")
def av_products_choose(cid: str, body: AvChooseIn, request: Request, admin: str = Depends(require_admin)):
    """Tick which product servers are synced. Agents under a server left
    unticked are removed now and skipped from then on."""
    from . import av_products
    cid = _av_id(cid)
    ids = [_av_pid(x) for x in body.selected]
    with db() as conn:
        _av_products_ready(conn)
        if not conn.execute("SELECT 1 FROM av_consoles WHERE id = %s", (cid,)).fetchone():
            raise HTTPException(404, "No such console.")
        with conn.transaction():
            names = {str(r["id"]): r["host_name"] or r["entity_id"] for r in conn.execute(
                "SELECT id, host_name, entity_id FROM av_products WHERE console_id = %s", (cid,)).fetchall()}
            audit(conn, actor=admin, actor_type="user", action="av_products_chosen", object_type="av_console",
                  object_id=cid, detail={"selected": sorted(names[i] for i in ids if i in names),
                                         "not_selected": sorted(v for k, v in names.items() if k not in ids)},
                  source_ip=client_ip(request))
            r = av_products.choose(conn, cid, ids)
            conn.execute("UPDATE av_consoles SET sync_requested_at = now() WHERE id = %s AND enabled", (cid,))
        return jsonable({"result": r, **_av_view(conn)})


def _dsm_product(conn, pid):
    p = conn.execute("SELECT * FROM av_products WHERE id = %s", (_av_pid(pid),)).fetchone()
    if not p:
        raise HTTPException(404, "No such product server.")
    if p["kind"] != "deep_security":
        raise HTTPException(422, "Only a Deep Security Manager can be read directly.")
    return dict(p)


def _trust_word(cert):
    """What the certificate check found, in one word the page explains."""
    if cert.get("expired"):
        return "expired"
    if cert.get("trusted"):
        return "private_ca_saved" if cert.get("trusted_with") else "public_ca"                 # verifies as it is: nothing to paste or pin
    if cert.get("self_signed"):
        return "self_signed"               # pin it by its fingerprint
    return "private_ca"                    # from a CA PATCH-01 does not know: paste that CA, or pin


class DsmCertIn(BaseModel):
    url: Optional[str] = Field(None, max_length=300)
    use_proxy: bool = False


@app.post("/api/v1/admin/antivirus/products/{pid}/dsm/certificate")
def dsm_certificate(pid: str, body: DsmCertIn, request: Request, admin: str = Depends(require_admin)):
    """The certificate the Manager presents (handshake only), to check and trust."""
    from . import antivirus as av
    with db() as conn:
        _av_products_ready(conn)
        _av_checks(conn, admin)
        p = _dsm_product(conn, pid)
        try:
            url = av.clean_url(body.url) if body.url else p["dsm_url"]
            if not url:
                raise av.AvError("Enter the Manager's URL (usually https://<manager>:4119).")
        except av.AvError as e:
            raise HTTPException(422, str(e))
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="av_dsm_certificate_read", object_type="av_product",
                  object_id=str(p["id"]), detail={"url": url}, source_ip=client_ip(request))
    try:
        cert = av.fetch_certificate({"url": url, "use_proxy": body.use_proxy if body.url else p["dsm_use_proxy"]})
    except av.AvError as e:
        raise HTTPException(422, str(e).replace("console", "Manager"))
    cert["pinned_now"] = bool(p["dsm_pin_sha256"] and p["dsm_pin_sha256"] == cert["sha256"])
    same = url == p["dsm_url"]
    cert["trusted"] = av.trusted_publicly(url, body.use_proxy if body.url else p["dsm_use_proxy"],
                                          p["dsm_ca_pem"] if same else None)
    cert["trusted_with"] = "your CA" if cert["trusted"] and same and p["dsm_ca_pem"] else None
    cert["trust"] = _trust_word(cert)
    return cert


class DsmIn(BaseModel):
    url: Optional[str] = Field(None, max_length=300)
    api_key: Optional[str] = Field(None, max_length=300)     # None or "": keep the saved key
    ca_pem: Optional[str] = Field(None, max_length=20000)     # None: keep; "": remove
    pin_sha256: Optional[str] = Field(None, max_length=120)   # None: keep; "": remove
    use_proxy: bool = False
    enabled: bool = True


def _dsm_settings(p, body):
    """(target, key) from the form, falling back to what is saved. A saved key
    or pin only ever goes to its own address."""
    from . import antivirus as av, av_products
    url = av.clean_url(body.url) if body.url else p["dsm_url"]
    if not url:
        raise av.AvError("Enter the Manager's URL (usually https://<manager>:4119).")
    same = url == p["dsm_url"]
    ca = (p["dsm_ca_pem"] if same else None) if body.ca_pem is None else av.clean_ca(body.ca_pem)
    pin = (p["dsm_pin_sha256"] if same else None) if body.pin_sha256 is None else av.clean_pin(body.pin_sha256)
    t = av_products.target(p, url=url, ca_pem=ca or None, pin=pin or None, use_proxy=body.use_proxy)
    if body.api_key:
        key = av_products.clean_dsm_key(body.api_key)
    elif p["dsm_key_enc"] and same:
        key = av.decrypt(p["dsm_key_enc"])
    elif p["dsm_key_enc"]:
        raise av.AvError("The URL differs from the saved one: enter the API key again.")
    else:
        raise av.AvError("Enter the Manager's API key.")
    return t, key


@app.post("/api/v1/admin/antivirus/products/{pid}/dsm/test")
def dsm_test(pid: str, body: DsmIn, request: Request, admin: str = Depends(require_admin)):
    from . import antivirus as av, av_products
    with db() as conn:
        _av_products_ready(conn)
        _av_checks(conn, admin)
        p = _dsm_product(conn, pid)
        try:
            t, key = _dsm_settings(p, body)
        except av.AvError as e:
            raise HTTPException(422, str(e))
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="av_dsm_tested", object_type="av_product",
                  object_id=str(p["id"]), detail={"url": t["url"]}, source_ip=client_ip(request))
    try:
        r = av_products.dsm_test(t, key)
        return {"ok": True, "message": f"Signed in. The Manager lists {r['computers']} computers."}
    except av.AvError as e:
        return {"ok": False, "message": str(e)}
    except Exception as e:  # noqa: BLE001
        log.warning("deep security test: %s", type(e).__name__)
        return {"ok": False, "message": "The Manager's answer could not be read."}
    finally:
        key = None


@app.put("/api/v1/admin/antivirus/products/{pid}/dsm")
def dsm_save(pid: str, body: DsmIn, request: Request, admin: str = Depends(require_admin)):
    """Save how to read this Manager directly. The key is kept encrypted and
    never sent to the browser."""
    from . import antivirus as av, av_products
    with db() as conn:
        _av_products_ready(conn)
        p = _dsm_product(conn, pid)
        try:
            t, key = _dsm_settings(p, body)
            key_enc = av.encrypt(key) if body.api_key else p["dsm_key_enc"]
            key = None
        except av.AvError as e:
            raise HTTPException(422, str(e).replace("console", "Manager"))
        pin_cert = None
        if t["pin_sha256"] and t["pin_sha256"] != p["dsm_pin_sha256"]:
            # A new pin: the Manager must present exactly that certificate now (handshake only)
            _av_checks(conn, admin)
            with conn.transaction():
                audit(conn, actor=admin, actor_type="user", action="av_dsm_certificate_read", object_type="av_product",
                      object_id=str(p["id"]), detail={"url": t["url"], "for": "pin check"}, source_ip=client_ip(request))
            conn.commit()                             # nothing held open during the handshake
            try:
                cert = av.fetch_certificate({"url": t["url"], "use_proxy": t["use_proxy"]})
                if cert["sha256"] != t["pin_sha256"]:
                    raise av.AvError("The Manager now presents a different certificate (SHA-256 " + cert["sha256_text"]
                                     + "): get it again and compare.")
            except av.AvError as e:
                raise HTTPException(422, str(e).replace("console", "Manager"))
            pin_cert = cert
            p = _dsm_product(conn, pid)               # read again: it may have changed meanwhile
        with conn.transaction():
            conn.execute(
                """UPDATE av_products SET dsm_url = %s, dsm_key_enc = %s, dsm_ca_pem = %s, dsm_pin_sha256 = %s,
                          dsm_pin_subject = CASE WHEN %s::text IS NULL THEN NULL WHEN %s::text IS NOT NULL THEN %s
                                                 ELSE dsm_pin_subject END,
                          dsm_use_proxy = %s, dsm_enabled = %s, dsm_set_by = %s, dsm_set_at = now(),
                          sync_requested_at = CASE WHEN %s THEN now() ELSE NULL END
                    WHERE id = %s""",
                (t["url"], key_enc, t["ca_pem"], t["pin_sha256"], t["pin_sha256"], (pin_cert or {}).get("subject"),
                 (pin_cert or {}).get("subject"), t["use_proxy"], body.enabled, admin, body.enabled, p["id"]))
            if not body.enabled:
                # Apex Central's own list covers this Manager again from the next read
                conn.execute("DELETE FROM av_agents WHERE product_id = %s", (p["id"],))
            audit(conn, actor=admin, actor_type="user", action="av_dsm_saved", object_type="av_product",
                  object_id=str(p["id"]), detail={"manager": p["host_name"], "url": t["url"],
                                                  "api_key": "replaced" if body.api_key else "unchanged",
                                                  "ca": bool(t["ca_pem"]), "pinned_sha256": t["pin_sha256"],
                                                  "proxy": t["use_proxy"], "enabled": body.enabled},
                  source_ip=client_ip(request))
            conn.execute("UPDATE av_consoles SET sync_requested_at = now() WHERE id = %s AND enabled", (p["console_id"],))
        return jsonable(_av_view(conn))


@app.delete("/api/v1/admin/antivirus/products/{pid}/dsm")
def dsm_remove(pid: str, request: Request, admin: str = Depends(require_admin)):
    """Forget the Manager's key and settings; its agents come from Apex Central again."""
    with db() as conn:
        _av_products_ready(conn)
        p = _dsm_product(conn, pid)
        with conn.transaction():
            conn.execute("""UPDATE av_products SET dsm_url = NULL, dsm_key_enc = NULL, dsm_ca_pem = NULL, dsm_pin_sha256 = NULL,
                                   dsm_pin_subject = NULL, dsm_enabled = false, dsm_set_by = %s, dsm_set_at = now(),
                                   last_sync_at = NULL, last_sync_ok = NULL, last_sync_msg = NULL, agents = NULL,
                                   sync_requested_at = NULL
                             WHERE id = %s""", (admin, p["id"]))
            conn.execute("DELETE FROM av_agents WHERE product_id = %s", (p["id"],))
            conn.execute("UPDATE av_consoles SET sync_requested_at = now() WHERE id = %s AND enabled", (p["console_id"],))
            audit(conn, actor=admin, actor_type="user", action="av_dsm_removed", object_type="av_product",
                  object_id=str(p["id"]), detail={"manager": p["host_name"]}, source_ip=client_ip(request))
        return jsonable(_av_view(conn))


@app.post("/api/v1/admin/antivirus/products/{pid}/sync")
def dsm_sync_now(pid: str, request: Request, admin: str = Depends(require_admin)):
    with db() as conn:
        _av_products_ready(conn)
        p = _dsm_product(conn, pid)
        with conn.transaction():
            r = conn.execute("""UPDATE av_products SET sync_requested_at = now()
                                 WHERE id = %s AND selected AND dsm_enabled AND dsm_key_enc IS NOT NULL RETURNING id""",
                             (p["id"],)).fetchone()
            if not r:
                raise HTTPException(422, "Tick this Manager for sync and save its API key first.")
            audit(conn, actor=admin, actor_type="user", action="av_dsm_sync_requested", object_type="av_product",
                  object_id=str(p["id"]), detail={"manager": p["host_name"]}, source_ip=client_ip(request))
        return jsonable(_av_view(conn))


@app.get("/api/v1/antivirus")
def av_page(user: str = Depends(require_viewer)):
    """Every antivirus agent the consoles report, the machine it is in our
    inventory, and our machines with no antivirus agent."""
    from . import antivirus as av
    with db() as conn:
        try:
            with conn.transaction():
                cons = av.consoles(conn)
                agents, unprotected = av.coverage(conn)
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Antivirus is not installed yet: run phase3a-schema.sh.")
    for c in cons:
        c.pop("last_test_msg", None)
    # Detections, definition status and the latest threat summary (schema 029)
    detections, summary, pstat = [], None, {}
    with db() as conn:
        try:
            with conn.transaction():
                detections = [dict(r) for r in conn.execute(
                    """SELECT d.occurred_at, d.host_name, d.ip, d.user_name, d.threat, d.category, d.action, d.result,
                              d.unresolved, d.file_path, d.sha1, d.count, c.name AS console,
                              d.occurred_at > now() - interval '24 hours' AS last_day
                         FROM av_detections d JOIN av_consoles c ON c.id = d.console_id
                        WHERE d.occurred_at > now() - interval '7 days'
                        ORDER BY d.occurred_at DESC LIMIT 2000""").fetchall()]
                for r in conn.execute("""SELECT console_id::text AS cid, lower(split_part(host_name, '.', 1)) AS h, pattern,
                                                version, versions_old FROM av_pattern_status""").fetchall():
                    k = (r["cid"], r["h"])
                    if k not in pstat or (r["versions_old"] or 0) > (pstat[k]["versions_old"] or 0):
                        pstat[k] = {"pattern": r["pattern"], "version": r["version"], "versions_old": r["versions_old"]}
                from . import av_threats
                summary = av_threats.latest(conn)
        except psycopg.errors.UndefinedTable:
            pass
    for a in agents:
        a["definitions"] = pstat.get((str(a.get("console_id")), (a["host_name"] or "").lower().split(".")[0]))
    products = []
    with db() as conn:
        try:                                        # product servers under each console (schema 034)
            with conn.transaction():
                from . import av_products
                products = [{k: p.get(k) for k in ("console", "host_name", "ip_addresses", "kind", "kind_label", "product_label",
                                                    "selected", "apex_agents", "dsm_agents", "dsm_enabled", "last_sync_at",
                                                    "last_sync_ok", "last_sync_msg", "first_seen", "last_seen")}
                            for p in av_products.listing(conn)]
        except (psycopg.errors.UndefinedTable, psycopg.errors.UndefinedColumn):
            pass
    day = [d for d in detections if d.pop("last_day", False)]
    for d in detections:
        d.pop("last_day", None)
    return jsonable({"consoles": [{k: c[k] for k in ("id", "name", "enabled", "last_sync_at", "last_sync_ok",
                                                     "last_sync_msg", "agents")} for c in cons],
                     "agents": agents, "unprotected": unprotected, "detections": detections, "summary": summary,
                     "products": products,
                     "counts": {"agents": len(agents),
                                "matched": sum(1 for a in agents if a["asset"]),
                                "unmatched": sum(1 for a in agents if not a["asset"]),
                                "isolated": sum(1 for a in agents
                                                if (a["isolation_status"] or "").lower() not in ("", "normal", "none")),
                                "not_reported": sum(1 for a in agents if a["not_reported"]),
                                "unprotected": len(unprotected),
                                "outdated": sum(1 for a in agents if a["definitions"] and (a["definitions"]["versions_old"] or 0) >= 2),
                                "detections_24h": len(day),
                                "ransomware_24h": sum(1 for d in day if d["category"] == "ransomware"),
                                "unresolved_24h": sum(1 for d in day if d["unresolved"])}})
