"""PATCH-01's own report of the Nessus findings it imported (not Nessus's own reports, which
are passed through as Nessus builds them).

  Excel  Summary (figures, by severity), By host, Findings (one row per host, plugin and port), By CVE
  PDF    the findings grouped by host, most severe first
  CSV    one row per finding
"""

SEV = {4: "Critical", 3: "High", 2: "Medium", 1: "Low", 0: "Info"}
HEADERS = ["Severity", "CVSS", "Host", "Address", "Our server", "Patch group", "Plugin", "Finding", "Family", "CVEs",
           "Port", "Exploit available", "Scan", "Seen"]
HOST_HEADERS = ["Host", "Address", "Our server", "Operating system", "Critical", "High", "Medium", "Low", "CVEs"]
CVE_HEADERS = ["CVE", "Worst severity", "Hosts", "Findings"]
PDF_HEADERS = ["Severity", "CVSS", "Plugin", "Finding", "CVEs", "Port", "Exploit"]


def _score(r):
    v = r.get("cvss3") if r.get("cvss3") is not None else r.get("cvss")
    return float(v) if v is not None else None


def _day(v, tz):
    if not v:
        return ""
    if hasattr(v, "astimezone") and getattr(v, "tzinfo", None):
        v = v.astimezone(tz)
    return v.strftime("%Y-%m-%d") if hasattr(v, "strftime") else str(v)[:10]


def _port(r):
    return f"{r['port']}/{r['protocol']}" if r.get("port") else (r.get("protocol") or "")


def finding_rows(rows, tz):
    return [[SEV.get(r["severity"], ""), _score(r), r["host_name"], r.get("host_ip") or "", r.get("our_host") or "",
             r.get("host_group") or "", r["plugin_id"], r.get("plugin_name") or "", r.get("family") or "",
             ", ".join(r.get("cves") or [])[:400], _port(r), "yes" if r.get("exploit") else "", r.get("scan") or "",
             _day(r.get("seen_at"), tz)] for r in rows]


def host_rows(rows):
    by = {}
    for r in rows:
        k = (r["host_name"], r.get("host_ip"))
        x = by.setdefault(k, {"os": r.get("host_os"), "our": r.get("our_host"), 4: 0, 3: 0, 2: 0, 1: 0, "cves": set()})
        x[r["severity"]] = x.get(r["severity"], 0) + 1
        x["cves"].update(r.get("cves") or [])
    out = [[k[0], k[1] or "", x["our"] or "", (x["os"] or "")[:120], x[4], x[3], x[2], x[1], len(x["cves"])]
           for k, x in by.items()]
    return sorted(out, key=lambda r: (-r[4], -r[5], -r[6], r[0].lower()))


def cve_rows(rows):
    by = {}
    for r in rows:
        for c in r.get("cves") or []:
            x = by.setdefault(c, {"sev": 0, "hosts": set(), "n": 0})
            x["sev"] = max(x["sev"], r["severity"])
            x["hosts"].add(r["host_name"])
            x["n"] += 1
    order = sorted(by.items(), key=lambda kv: (-kv[1]["sev"], -len(kv[1]["hosts"]), kv[0]))
    return [[c, SEV.get(x["sev"], ""), len(x["hosts"]), x["n"]] for c, x in order]


def render(conn, fmt, user, rows, f, tz):
    """(bytes, media type, extension, rows)."""
    from . import exports as ex
    title = "Nessus findings"
    filt = f"{SEV.get(f['min'], 'Low')} severity and above" + (f"; search “{f['q']}”" if f.get("q") else "") \
        + ("; one scan" if f.get("scan") else "") + ("; one Nessus server" if f.get("server") and not f.get("scan") else "")
    fr = finding_rows(rows, tz)
    if fmt == "csv":
        m = ex.meta(title, user, filt, len(fr), ex.company_name(conn))
        return ex.csv_text(m, HEADERS, fr).encode("utf-8"), "text/csv; charset=utf-8", "csv", len(fr)
    logo, cls, accent = ex.brand_bits(conn)
    if fmt == "pdf":
        out, heads, cur = [], [], None
        for r in sorted(rows, key=lambda r: (r["host_name"].lower(), -r["severity"])):
            if r["host_name"] != cur:
                cur = r["host_name"]
                heads.append(len(out))
                out.append([r["host_name"], r.get("host_ip") or "", (r.get("our_host") and "our server " + r["our_host"]) or "",
                            (r.get("host_os") or "")[:100], "", "", ""])
            s = _score(r)
            out.append([SEV.get(r["severity"], ""), "" if s is None else f"{s:.1f}", str(r["plugin_id"]),
                        (r.get("plugin_name") or "")[:120], ", ".join((r.get("cves") or [])[:6]), _port(r),
                        "yes" if r.get("exploit") else ""])
        m = ex.meta(title, user, filt, len(fr), ex.company_name(conn))
        return ex.pdf_bytes(m, PDF_HEADERS, out, logo, cls, accent, heads=heads), "application/pdf", "pdf", len(fr)
    hr = host_rows(rows)
    sev = {k: 0 for k in SEV}
    for r in rows:
        sev[r["severity"]] = sev.get(r["severity"], 0) + 1
    summ = [["Findings", len(rows)], ["Hosts", len(hr)], ["Hosts matched to our servers", sum(1 for r in hr if r[2])],
            ["CVEs", len(cve_rows(rows))], ["", ""], ["By severity", ""]] + [[SEV[k], sev.get(k, 0)] for k in (4, 3, 2, 1)]
    sheets = [
        {"name": "Summary", "headers": ["Figure", "Count"], "rows": summ,
         "note": "The latest finished run of each Nessus scan, imported by PATCH-01. Informational findings are left out."},
        {"name": "By host", "headers": HOST_HEADERS, "rows": hr, "filter": True},
        {"name": "Findings", "headers": HEADERS, "rows": fr, "filter": True},
        {"name": "By CVE", "headers": CVE_HEADERS, "rows": cve_rows(rows), "filter": True},
    ]
    m = ex.meta(title, user, filt, len(fr), ex.company_name(conn))
    return (ex.xlsx_workbook(m, sheets, logo), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx",
            len(fr))
