"""The dashboard's fleet figures.

Split out of main.py in r90; the code is unchanged."""

from datetime import datetime, timezone
from fastapi import Depends, HTTPException

from .core import (OS_LABEL_SQL, _public_cached, app, db, jsonable, require_viewer)


# ---------------------------------------------------------------------------
# Cyber-Secure dashboard: fleet figures for the donuts (viewers and up)
# ---------------------------------------------------------------------------


@app.get("/api/v1/dashboard/summary")
def dashboard_summary(user: str = Depends(require_viewer)):
    """Everything the dashboard's donuts show, computed live from the
    database, so a server enrolled a minute ago is already counted."""
    from . import cve_feeds
    with db() as conn:
        servers = conn.execute(
            """WITH h AS (
                 SELECT agent_state(h.last_checkin, h.status) AS st,
                        -- patching from the servers' own word (WSUS, the package manager): v_host_patch, schema 044.
                        -- NULL: a Linux server whose agent is older than 1.8.2 (its patch state is unknown)
                        (SELECT vp.to_install FROM v_host_patch vp WHERE vp.host_id = h.id) AS to_i,
                        h.reboot_required
                          OR EXISTS (SELECT 1 FROM host_applicability ha
                                      WHERE ha.host_id = h.id AND ha.state = 'fixed_pending_reboot') AS reboot
                   FROM hosts h WHERE h.status <> 'decommissioned')
               SELECT count(*) AS total,
                      count(*) FILTER (WHERE st <> 'online') AS not_reporting,
                      count(*) FILTER (WHERE st = 'online' AND to_i > 0) AS needs_patch,
                      count(*) FILTER (WHERE st = 'online' AND to_i = 0 AND reboot) AS needs_reboot,
                      count(*) FILTER (WHERE st = 'online' AND to_i = 0 AND NOT reboot) AS patched,
                      count(*) FILTER (WHERE st = 'online' AND to_i IS NULL) AS unknown,
                      count(*) FILTER (WHERE reboot) AS reboot_any
                 FROM h""").fetchone()
        advisories = conn.execute(
            """SELECT (SELECT count(*) FROM linux_updates lu JOIN hosts x ON x.id = lu.host_id
                        WHERE x.status <> 'decommissioned' AND lu.security IS NOT FALSE) AS to_install,
                      (SELECT count(*) FROM windows_updates wu JOIN hosts x ON x.id = wu.host_id
                        WHERE x.status <> 'decommissioned') AS windows_to_install,
                      (SELECT count(*) FROM linux_package_installs li JOIN hosts x ON x.id = li.host_id
                         JOIN (SELECT host_id, min(installed_at) AS built FROM linux_package_installs
                                WHERE installed_at IS NOT NULL GROUP BY host_id) b ON b.host_id = li.host_id
                        WHERE x.status <> 'decommissioned' AND li.installed_at > now() - interval '30 days'
                          AND li.installed_at > b.built + interval '1 day')
                    + (SELECT count(*) FROM windows_installed_updates wi JOIN hosts x ON x.id = wi.host_id
                        WHERE x.status <> 'decommissioned' AND wi.installed_on > now() - interval '30 days'
                          AND coalesce(wi.result, 'Succeeded') IN ('Succeeded', 'Installed', 'Succeeded with errors')) AS installed_30d""").fetchone()
        severity = conn.execute(
            """WITH o AS (
                 SELECT DISTINCT coalesce(lu.advisory, lu.name || '-' || lu.available) AS id, lower(coalesce(lu.severity, '')) AS sev
                   FROM linux_updates lu JOIN hosts h ON h.id = lu.host_id AND h.status <> 'decommissioned'
                  WHERE lu.security IS NOT FALSE
                 UNION
                 SELECT DISTINCT coalesce(wu.kb, wu.update_id), lower(coalesce(wu.severity, ''))
                   FROM windows_updates wu JOIN hosts h ON h.id = wu.host_id AND h.status <> 'decommissioned')
               SELECT count(*) FILTER (WHERE sev = 'critical') AS critical,
                      count(*) FILTER (WHERE sev IN ('important', 'high')) AS important,
                      count(*) FILTER (WHERE sev IN ('moderate', 'medium')) AS moderate,
                      count(*) FILTER (WHERE sev NOT IN ('critical', 'important', 'high', 'moderate', 'medium')) AS low_or_unrated
                 FROM o""").fetchone()
        os_rows = conn.execute(
            f"""SELECT {OS_LABEL_SQL} AS os, count(*) AS n
                  FROM hosts h WHERE h.status <> 'decommissioned' GROUP BY 1 ORDER BY 2 DESC, 1""").fetchall()
        agents = conn.execute(
            """SELECT agent_state(last_checkin, status) AS state, count(*) AS n
                 FROM hosts WHERE status <> 'decommissioned' GROUP BY 1""").fetchall()
    def feeds_build():
        from . import cve_impact
        with db() as c2:
            out = cve_feeds.summary(c2)
            out["impact"] = cve_impact.counts(c2, out["days"])
            return jsonable(out)
    try:
        feeds = _public_cached("feeds-summary", feeds_build, ttl=60)
    except HTTPException:                 # schema 022 not applied yet, or the feeds tables unreadable
        feeds = None
    top, other = os_rows[:6], sum(r["n"] for r in os_rows[6:])
    if other:
        top.append({"os": "Other", "n": other})
    online = (servers["total"] or 0) - (servers["not_reporting"] or 0)
    return jsonable({"servers": servers, "advisories": advisories, "severity": severity, "os": top,
                     "agents": {r["state"]: r["n"] for r in agents}, "feeds": feeds,
                     # Servers whose patch state is unknown (Linux agent older than 1.8.2) are left out of the rate
                     "compliance_pct": round(100.0 * servers["patched"] / (online - (servers["unknown"] or 0)))
                                       if online - (servers["unknown"] or 0) > 0 else None,
                     "at": datetime.now(timezone.utc)})
