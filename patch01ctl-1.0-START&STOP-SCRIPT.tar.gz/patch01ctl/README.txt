patch01ctl 1.0 - start, stop and check the whole PATCH-01 stack, in order
===========================================================================

Install (once, as root, on PATCH-01):

    tar xzf patch01ctl-1.0.tar.gz && cd patch01ctl
    sha256sum -c SHA256SUMS
    ./patch01ctl install

This copies the script to /usr/local/sbin/patch01ctl, so it runs from any
folder, and adds patch01-stack.service:
  - at shutdown or reboot, the stack is stopped cleanly and in order before
    Docker stops (the database gets up to 90 seconds);
  - at boot, every layer is checked and anything not running or not healthy
    is started, in order.

Use:

    patch01ctl status          every part, its health, the site, the timers
    patch01ctl start           start what is not running, layer by layer
    patch01ctl stop            pause the timers, stop in reverse order
    patch01ctl stop --force    stop even while a patch job is running
    patch01ctl restart

Order (started top to bottom, stopped bottom to top):
    data       PostgreSQL, Redis
    pulp       Pulp (its migration step runs first)
    api        API, worker
    dashboard  console
    ingress    nginx
Each layer must be healthy before the next starts. If one is not, start stops
there and says which container, because the layers after it depend on it.

Nothing is hard-coded: containers come from the compose files in
/patch/compose, timers are every patch01-*.timer. Components added later are
picked up with no change here.

Log: /var/log/patch01ctl.log         Remove the boot unit: patch01ctl uninstall
