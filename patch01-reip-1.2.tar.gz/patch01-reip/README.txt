patch01-reip 1.2 - update PATCH-01 and AI-01 after an IP change, then test
===========================================================================

Run on PATCH-01, as root, after the new IPs are in place (and ideally after
DNS for PATCH-01's name points at its new IP):

    tar xzf patch01-reip-1.2.tar.gz && cd patch01-reip
    sha256sum -c SHA256SUMS
    ./patch01-reip --dry-run      # finds everything, shows the plan, changes nothing
    ./patch01-reip                # does it; asks before each step

It proposes every value (Enter accepts it, or type another):
  1. Finds PATCH-01's new IP, its old IP (from the certificate it made for
     itself), AI-01's current address, and checks DNS. Shows the plan.
  2. Backs up every file that may change: /patch/backup/reip-<time>.tar.gz
  3. PATCH-01: replaces the old IPs wherever its settings hold them
     (proxy exceptions, AI-01's address), showing each file.
  4. AI-01, over SSH (one password prompt without an SSH key):
     - lets PATCH-01's new IP through its allow-list,
     - makes a certificate for AI-01's new IP if the old one names the old IP,
     - tests nginx; if the test fails, the old allow-list is put back.
     Without SSH, it writes the AI-01 script for you to run there.
  5. PATCH-01 trusts AI-01's new certificate, but only after checking it is
     exactly the one AI-01 just reported. Restarts the API and worker.
  6. Starts anything not running (uses patch01ctl if installed).
  7. Tests: PATCH-01's API, DNS for its short name and FQDN, AI-01 from inside
     the API with its certificate verified, the mail relay, the proxy,
     vCenter, and how many agents have checked in. Each failure says what to
     look at.
  8. Optional: installs PATCH-01's CA-signed certificate. It checks the key
     matches, the dates, the names, and the chain; prints the Windows re-pin
     commands first (both pins, so nothing drops out); installs it; proves
     nginx serves it; and puts the old one back automatically if not.

Also:
    ./patch01-reip --test         only the tests (for example 10 minutes later)
    ./patch01-reip --cert         only the certificate step

Undo on PATCH-01:  tar xzf /patch/backup/reip-<time>.tar.gz -C / && patch01ctl restart
Undo on AI-01:     the previous files are kept as *.before-reip-<time>
Log: /var/log/patch01-reip.log

1.1: the DNS test asks the DNS server itself. On PATCH-01, its own name is answered
     locally (often with an IPv6 link-local fe80:: address), which hid what DNS says.
     Also checks /etc/hosts for a stale entry, and the default gateway.
1.2: vCenter and mail relay are tested from inside the worker, which is what really
     connects to them (trying every address DNS returns), with vCenter's last good sync.
