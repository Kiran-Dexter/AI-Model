"""
PATCH-01 : patch platform API

Endpoints fall into three groups:

  /api/v1/agent/*   called by agents on managed hosts, bearer-token auth
  /api/v1/admin/*   called by operators, basic auth
  /api/v1/health    unauthenticated liveness

Design notes:

  * Agents authenticate with a per-host bearer token obtained by redeeming a
    single-use enrollment token. Only the SHA-256 of each token is stored, so
    a database dump does not yield working credentials.

  * The agent may only submit data about ITSELF. The host identity comes from
    the authenticated token, never from the request body, so agent A cannot
    overwrite agent B's inventory.

  * Commands returned to agents are a bounded verb plus JSON parameters.
    There is no endpoint that accepts or returns a shell command.

  * Inventory replaces the package set wholesale inside a transaction. A diff
    based approach loses packages removed outside the agent's knowledge.

  * Package versions are stored as separate epoch/version/release columns.
    Epoch is parsed explicitly because dropping it silently inverts version
    comparisons later.
"""

import hashlib
import hmac
import ipaddress
import json
import logging
import os
import re
import secrets
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import psycopg
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

from fastapi import (Body, Depends, FastAPI, File, Form, Header, HTTPException,
                     Request, UploadFile, status)
from fastapi.responses import PlainTextResponse
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel, Field, field_validator

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
logging.basicConfig(
    level=LOG_LEVEL,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("patchapi")

DB_HOST = os.environ.get("PATCHDB_HOST", "postgres")
DB_PORT = int(os.environ.get("PATCHDB_PORT", "5432"))
DB_NAME = os.environ.get("PATCHDB_NAME", "patchdb")
DB_USER = os.environ.get("PATCHDB_USER", "patchapi")
DB_PASS = os.environ.get("PATCHDB_PASSWORD", "")

ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")

# How long before a silent host is considered stale. Must match what the
# applicability engine uses, or a host can read as compliant while its
# inventory is too old to judge.
STALE_HOURS = int(os.environ.get("STALE_HOURS", "24"))

# A host is online if it checked in within this many minutes. Agents check in
# every 5 minutes with up to a minute of jitter, so 15 tolerates two misses.
ONLINE_MINUTES = int(os.environ.get("ONLINE_MINUTES", "15"))

# Bounds on submitted data. A host reporting 200k packages is a bug or an
# attack, not a real inventory.
MAX_PACKAGES = int(os.environ.get("MAX_PACKAGES", "20000"))
MIN_PLAUSIBLE_PACKAGES = 50

ENROLL_TOKEN_TTL_HOURS = int(os.environ.get("ENROLL_TOKEN_TTL_HOURS", "24"))

app = FastAPI(
    title="PATCH-01 Patch Platform API",
    version="1.0.0",
    docs_url="/api/v1/docs",
    openapi_url="/api/v1/openapi.json",
)

pool: Optional[ConnectionPool] = None


@app.on_event("startup")
def startup() -> None:
    global pool
    conninfo = (
        f"host={DB_HOST} port={DB_PORT} dbname={DB_NAME} "
        f"user={DB_USER} password={DB_PASS} connect_timeout=10"
    )
    pool = ConnectionPool(conninfo, min_size=2, max_size=10, open=True,
                          kwargs={"row_factory": dict_row})
    log.info("connected to %s@%s:%s/%s", DB_USER, DB_HOST, DB_PORT, DB_NAME)
    if not ADMIN_PASSWORD:
        log.warning("ADMIN_PASSWORD is empty; admin endpoints will reject all requests")


@app.on_event("shutdown")
def shutdown() -> None:
    if pool:
        pool.close()


@contextmanager
def db():
    if pool is None:
        raise HTTPException(status_code=503, detail="database pool not ready")
    with pool.connection() as conn:
        yield conn


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def sha256(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def now() -> datetime:
    return datetime.now(timezone.utc)


def client_ip(request: Request) -> Optional[str]:
    """Real client address, trusting NGINX's X-Forwarded-For.

    NGINX is the only thing that can reach this service, so its header is
    trustworthy here. The leftmost entry is the original client.
    """
    xff = request.headers.get("x-forwarded-for")
    if xff:
        candidate = xff.split(",")[0].strip()
        try:
            ipaddress.ip_address(candidate)
            return candidate
        except ValueError:
            pass
    return request.client.host if request.client else None


def audit(conn, actor: str, actor_type: str, action: str,
          host_id: Optional[str] = None, object_type: Optional[str] = None,
          object_id: Optional[str] = None, detail: Optional[Dict] = None,
          source_ip: Optional[str] = None) -> None:
    """Append to the audit log. Never raises: a failed audit write must not
    silently succeed, but it also must not lose the caller's work, so it is
    logged loudly and re-raised only on programming errors."""
    conn.execute(
        """INSERT INTO audit_log
             (actor, actor_type, action, host_id, object_type, object_id,
              detail, source_ip)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
        (actor, actor_type, action, host_id, object_type, object_id,
         json.dumps(detail or {}), source_ip),
    )


NEVRA_RE = re.compile(r"^[A-Za-z0-9._+\-~^]+$")


def parse_evr(version_string: str) -> tuple:
    """Split an RPM or DEB version string into (epoch, version, release).

    Epoch is returned explicitly, defaulting to 0 rather than None, because
    a dropped epoch silently inverts comparisons. RPM release is the part
    after the last '-'; DEB revision is treated the same way.
    """
    s = (version_string or "").strip()
    epoch = 0
    if ":" in s:
        head, _, s = s.partition(":")
        try:
            epoch = int(head)
        except ValueError:
            epoch = 0
    if "-" in s:
        version, _, release = s.rpartition("-")
    else:
        version, release = s, ""
    return epoch, version, release


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------

basic = HTTPBasic(auto_error=False)


def require_admin(request: Request,
                  creds: Optional[HTTPBasicCredentials] = Depends(basic)) -> str:
    if not ADMIN_PASSWORD:
        raise HTTPException(status_code=503, detail="admin auth not configured")
    # The dashboard has its own sign-in form. Sending WWW-Authenticate to it
    # would also pop the browser's native dialog, so omit it for its requests.
    challenge = ({} if request.headers.get("x-requested-with") == "patch01-dashboard"
                 else {"WWW-Authenticate": "Basic"})
    if creds is None:
        raise HTTPException(
            status_code=401, detail="authentication required",
            headers=challenge,
        )
    # compare_digest on both fields, so a wrong username costs the same as a
    # wrong password
    user_ok = hmac.compare_digest(creds.username, ADMIN_USER)
    pass_ok = hmac.compare_digest(creds.password, ADMIN_PASSWORD)
    if not (user_ok and pass_ok):
        raise HTTPException(
            status_code=401, detail="invalid credentials",
            headers=challenge,
        )
    return creds.username


class AgentIdentity(BaseModel):
    host_id: str
    hostname: str
    host_group: str


def require_agent(
    request: Request,
    authorization: Optional[str] = Header(default=None),
) -> AgentIdentity:
    """Resolve the calling agent from its bearer token.

    The host identity comes from here and nowhere else. No endpoint accepts a
    host_id from the request body, which is what prevents one agent writing
    another's data.
    """
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="bearer token required")
    token = authorization[7:].strip()
    if not token:
        raise HTTPException(status_code=401, detail="empty token")

    th = sha256(token)
    with db() as conn:
        row = conn.execute(
            """SELECT id, hostname, host_group, status
                 FROM hosts
                WHERE token_hash = %s""",
            (th,),
        ).fetchone()

        if not row:
            raise HTTPException(status_code=401, detail="unknown or revoked token")
        if row["status"] == "decommissioned":
            raise HTTPException(status_code=403, detail="host is decommissioned")

        return AgentIdentity(
            host_id=str(row["id"]),
            hostname=row["hostname"],
            host_group=row["host_group"] or "default",
        )


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class EnrollRequest(BaseModel):
    enrollment_token: str = Field(min_length=16, max_length=128)
    machine_id: str = Field(min_length=8, max_length=128)
    hostname: str = Field(min_length=1, max_length=253)
    fqdn: Optional[str] = Field(default=None, max_length=253)
    os_id: str = Field(max_length=32)
    os_version: str = Field(max_length=32)
    arch: str = Field(max_length=16)
    pkg_manager: str = Field(max_length=8)
    agent_version: str = Field(max_length=32)

    @field_validator("hostname", "fqdn")
    @classmethod
    def valid_hostname(cls, v):
        if v is None:
            return v
        # Lowercase and validate: uppercase hostnames break TLS SAN matching
        # and some apt tooling later.
        v = v.strip().lower()
        if not re.match(r"^[a-z0-9]([a-z0-9.\-]{0,251}[a-z0-9])?$", v):
            raise ValueError("invalid hostname")
        return v

    @field_validator("pkg_manager")
    @classmethod
    def valid_pkg_manager(cls, v):
        if v not in ("dnf", "yum", "apt"):
            raise ValueError("pkg_manager must be dnf, yum or apt")
        return v

    @field_validator("os_id")
    @classmethod
    def valid_os(cls, v):
        v = v.strip().lower()
        if not re.match(r"^[a-z0-9_\-]+$", v):
            raise ValueError("invalid os_id")
        return v


class EnrollResponse(BaseModel):
    host_id: str
    agent_token: str
    checkin_interval_sec: int


class PackageIn(BaseModel):
    name: str = Field(max_length=256)
    version: str = Field(max_length=128)
    arch: str = Field(default="noarch", max_length=32)
    from_repo: Optional[str] = Field(default=None, max_length=128)

    @field_validator("name", "arch")
    @classmethod
    def safe_chars(cls, v):
        if not NEVRA_RE.match(v):
            raise ValueError(f"unsafe characters in {v!r}")
        return v


class InventoryIn(BaseModel):
    collected_at: datetime
    kernel_running: str = Field(max_length=128)
    kernel_latest: Optional[str] = Field(default=None, max_length=128)
    reboot_required: bool = False
    reboot_reason: Optional[str] = Field(default=None, max_length=512)
    os_version: Optional[str] = Field(default=None, max_length=32)
    agent_version: Optional[str] = Field(default=None, max_length=32)
    duration_ms: Optional[int] = None
    boot_time: Optional[datetime] = None
    hardware_uuid: Optional[str] = Field(default=None, max_length=36,
                                         pattern=r"^[0-9a-fA-F-]{32,36}$")
    packages: List[PackageIn]

    @field_validator("packages")
    @classmethod
    def bounded(cls, v):
        if len(v) > MAX_PACKAGES:
            raise ValueError(f"too many packages ({len(v)} > {MAX_PACKAGES})")
        if not v:
            raise ValueError("package list is empty")
        return v


class CheckinIn(BaseModel):
    agent_version: Optional[str] = Field(default=None, max_length=32)
    kernel_running: Optional[str] = Field(default=None, max_length=128)
    reboot_required: Optional[bool] = None
    # Agent 1.1.0+. Optional so older agents keep working unchanged.
    boot_time: Optional[datetime] = None
    # Agent 1.2.0+: links the server to its VM in vCenter
    hardware_uuid: Optional[str] = Field(default=None, max_length=36,
                                         pattern=r"^[0-9a-fA-F-]{32,36}$")


class CommandOut(BaseModel):
    id: str
    verb: str
    params: Dict[str, Any]
    job_id: Optional[str] = None


class CommandResultIn(BaseModel):
    ok: bool
    result: Dict[str, Any] = Field(default_factory=dict)
    # Free-form message, bounded so a runaway agent cannot fill the database
    message: Optional[str] = Field(default=None, max_length=8192)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/api/v1/health")
def health():
    try:
        with db() as conn:
            conn.execute("SELECT 1").fetchone()
        return {"status": "ok", "database": "connected"}
    except Exception as e:
        log.error("health check failed: %s", e)
        return JSONResponse(
            status_code=503,
            content={"status": "degraded", "database": "unreachable"},
        )


# ---------------------------------------------------------------------------
# Agent endpoints
# ---------------------------------------------------------------------------

@app.post("/api/v1/agent/enroll", response_model=EnrollResponse)
def enroll(request: Request, body: EnrollRequest):
    """Redeem a single-use enrollment token for a per-host agent token.

    machine_id is the identity key rather than hostname, so a host that is
    renamed keeps its history instead of appearing as a new machine.
    """
    ip = client_ip(request)
    eth = sha256(body.enrollment_token)

    with db() as conn:
        with conn.transaction():
            tok = conn.execute(
                """SELECT id, host_group, expires_at, used_at, revoked_at
                     FROM enrollment_tokens
                    WHERE token_hash = %s
                    FOR UPDATE""",
                (eth,),
            ).fetchone()

            if not tok:
                log.warning("enroll rejected: unknown token from %s", ip)
                raise HTTPException(status_code=401, detail="invalid enrollment token")
            if tok["revoked_at"]:
                raise HTTPException(status_code=401, detail="enrollment token revoked")
            if tok["used_at"]:
                raise HTTPException(status_code=409, detail="enrollment token already used")
            if tok["expires_at"] < now():
                raise HTTPException(status_code=401, detail="enrollment token expired")

            agent_token = secrets.token_urlsafe(32)
            ath = sha256(agent_token)

            # Re-enrolment of a known machine keeps its id and history
            existing = conn.execute(
                "SELECT id FROM hosts WHERE machine_id = %s",
                (body.machine_id,),
            ).fetchone()

            os_major = None
            m = re.match(r"^(\d+)", body.os_version or "")
            if m:
                os_major = int(m.group(1))

            if existing:
                host_id = existing["id"]
                conn.execute(
                    """UPDATE hosts
                          SET hostname=%s, fqdn=%s, os_id=%s, os_version=%s,
                              os_major=%s, arch=%s, pkg_manager=%s,
                              agent_version=%s, token_hash=%s,
                              host_group=%s, status='active',
                              enrolled_at=now(), updated_at=now()
                        WHERE id=%s""",
                    (body.hostname, body.fqdn, body.os_id, body.os_version,
                     os_major, body.arch, body.pkg_manager, body.agent_version,
                     ath, tok["host_group"], host_id),
                )
                action = "re_enroll"
            else:
                row = conn.execute(
                    """INSERT INTO hosts
                         (hostname, fqdn, machine_id, os_id, os_version, os_major,
                          arch, pkg_manager, agent_version, token_hash,
                          host_group, status)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'active')
                       RETURNING id""",
                    (body.hostname, body.fqdn, body.machine_id, body.os_id,
                     body.os_version, os_major, body.arch, body.pkg_manager,
                     body.agent_version, ath, tok["host_group"]),
                ).fetchone()
                host_id = row["id"]
                action = "enroll"

            conn.execute(
                """UPDATE enrollment_tokens
                      SET used_at=now(), used_by_host=%s
                    WHERE id=%s""",
                (host_id, tok["id"]),
            )

            audit(conn, actor=body.hostname, actor_type="agent", action=action,
                  host_id=str(host_id), object_type="host",
                  object_id=str(host_id),
                  detail={"os": f"{body.os_id} {body.os_version}",
                          "arch": body.arch,
                          "machine_id": body.machine_id},
                  source_ip=ip)

    log.info("%s: host %s (%s)", action, body.hostname, host_id)
    return EnrollResponse(
        host_id=str(host_id),
        agent_token=agent_token,
        checkin_interval_sec=300,
    )


@app.post("/api/v1/agent/checkin")
def checkin(request: Request, body: CheckinIn,
            agent: AgentIdentity = Depends(require_agent)):
    """Lightweight heartbeat. Returns whether a full inventory is wanted."""
    ip = client_ip(request)
    with db() as conn:
        with conn.transaction():
            conn.execute(
                """UPDATE hosts
                      SET last_checkin=now(), status='active', updated_at=now(),
                          agent_version=COALESCE(%s, agent_version),
                          kernel_running=COALESCE(%s, kernel_running),
                          reboot_required=COALESCE(%s, reboot_required),
                          boot_time=COALESCE(%s, boot_time),
                          agent_ip=COALESCE(%s::inet, agent_ip),
                          hardware_uuid=COALESCE(lower(%s), hardware_uuid)
                    WHERE id=%s""",
                (body.agent_version, body.kernel_running,
                 body.reboot_required, body.boot_time, ip, body.hardware_uuid,
                 agent.host_id),
            )
            row = conn.execute(
                "SELECT last_inventory FROM hosts WHERE id=%s",
                (agent.host_id,),
            ).fetchone()

    last_inv = row["last_inventory"] if row else None
    want_inventory = last_inv is None or (now() - last_inv) > timedelta(hours=12)

    return {
        "ok": True,
        "want_inventory": want_inventory,
        "checkin_interval_sec": 300,
    }


@app.post("/api/v1/agent/inventory")
def submit_inventory(request: Request, body: InventoryIn,
                     agent: AgentIdentity = Depends(require_agent)):
    """Replace this host's package set.

    Wholesale replacement inside one transaction: a diff would miss packages
    removed outside the agent's knowledge, and a partial write would leave
    the applicability engine reading a half-updated inventory.
    """
    ip = client_ip(request)
    pkgs = body.packages

    # A suspiciously small inventory usually means a broken collector. Record
    # the run as failed rather than destroying good data with bad.
    if len(pkgs) < MIN_PLAUSIBLE_PACKAGES:
        with db() as conn:
            with conn.transaction():
                conn.execute(
                    """INSERT INTO inventory_runs
                         (host_id, collected_at, package_count, ok, error,
                          agent_version)
                       VALUES (%s,%s,%s,FALSE,%s,%s)""",
                    (agent.host_id, body.collected_at, len(pkgs),
                     f"implausible package count: {len(pkgs)}",
                     body.agent_version),
                )
                audit(conn, actor=agent.hostname, actor_type="agent",
                      action="inventory_rejected", host_id=agent.host_id,
                      detail={"package_count": len(pkgs)}, source_ip=ip)
        raise HTTPException(
            status_code=422,
            detail=f"only {len(pkgs)} packages reported; refusing to replace "
                   f"inventory (minimum {MIN_PLAUSIBLE_PACKAGES})",
        )

    # Hash the sorted set so unchanged inventories can skip recomputation
    canonical = "\n".join(
        sorted(f"{p.name}|{p.arch}|{p.version}" for p in pkgs)
    )
    content_hash = sha256(canonical)

    rows = []
    for p in pkgs:
        epoch, version, release = parse_evr(p.version)
        rows.append((agent.host_id, p.name, p.arch, epoch, version, release,
                     p.version, p.from_repo))

    os_major = None
    if body.os_version:
        m = re.match(r"^(\d+)", body.os_version)
        if m:
            os_major = int(m.group(1))

    with db() as conn:
        with conn.transaction():
            prev = conn.execute(
                """SELECT content_hash FROM inventory_runs
                    WHERE host_id=%s AND ok
                    ORDER BY collected_at DESC LIMIT 1""",
                (agent.host_id,),
            ).fetchone()
            unchanged = bool(prev and prev["content_hash"] == content_hash)

            if not unchanged:
                conn.execute("DELETE FROM host_packages WHERE host_id=%s",
                             (agent.host_id,))
                with conn.cursor() as cur:
                    cur.executemany(
                        """INSERT INTO host_packages
                             (host_id, name, arch, epoch, version, release,
                              full_nevra, from_repo)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
                           ON CONFLICT (host_id, name, arch) DO UPDATE
                             SET epoch=EXCLUDED.epoch,
                                 version=EXCLUDED.version,
                                 release=EXCLUDED.release,
                                 full_nevra=EXCLUDED.full_nevra,
                                 from_repo=EXCLUDED.from_repo""",
                        rows,
                    )

            conn.execute(
                """INSERT INTO inventory_runs
                     (host_id, collected_at, package_count, content_hash,
                      agent_version, duration_ms, ok)
                   VALUES (%s,%s,%s,%s,%s,%s,TRUE)""",
                (agent.host_id, body.collected_at, len(pkgs), content_hash,
                 body.agent_version, body.duration_ms),
            )

            conn.execute(
                """UPDATE hosts
                      SET last_inventory=now(), last_checkin=now(),
                          status='active', updated_at=now(),
                          kernel_running=%s,
                          kernel_latest=COALESCE(%s, kernel_latest),
                          reboot_required=%s,
                          reboot_reason=%s,
                          os_version=COALESCE(%s, os_version),
                          os_major=COALESCE(%s, os_major),
                          agent_version=COALESCE(%s, agent_version),
                          boot_time=COALESCE(%s, boot_time),
                          agent_ip=COALESCE(%s::inet, agent_ip),
                          hardware_uuid=COALESCE(lower(%s), hardware_uuid)
                    WHERE id=%s""",
                (body.kernel_running, body.kernel_latest,
                 body.reboot_required, body.reboot_reason,
                 body.os_version, os_major, body.agent_version,
                 body.boot_time, ip, body.hardware_uuid, agent.host_id),
            )

            audit(conn, actor=agent.hostname, actor_type="agent",
                  action="inventory", host_id=agent.host_id,
                  detail={"packages": len(pkgs), "unchanged": unchanged,
                          "kernel": body.kernel_running,
                          "reboot_required": body.reboot_required},
                  source_ip=ip)

    log.info("inventory from %s: %d packages%s", agent.hostname, len(pkgs),
             " (unchanged)" if unchanged else "")
    return {"ok": True, "packages_received": len(pkgs), "unchanged": unchanged}


@app.get("/api/v1/agent/commands", response_model=List[CommandOut])
def poll_commands(agent: AgentIdentity = Depends(require_agent)):
    """Claim pending commands for this host.

    Returns a bounded verb and JSON parameters. There is deliberately no
    verb that carries a shell command: the agent's own implementation maps
    each verb to a fixed action.
    """
    with db() as conn:
        with conn.transaction():
            rows = conn.execute(
                """UPDATE agent_commands
                      SET claimed_at = now()
                    WHERE id IN (
                        SELECT id FROM agent_commands
                         WHERE host_id = %s
                           AND claimed_at IS NULL
                           AND expires_at > now()
                         ORDER BY created_at
                         LIMIT 10
                         FOR UPDATE SKIP LOCKED
                    )
                RETURNING id, verb, params, job_id""",
                (agent.host_id,),
            ).fetchall()

    return [
        CommandOut(
            id=str(r["id"]),
            verb=r["verb"],
            params=r["params"] or {},
            job_id=str(r["job_id"]) if r["job_id"] else None,
        )
        for r in rows
    ]


@app.post("/api/v1/agent/commands/{command_id}/result")
def command_result(command_id: str, body: CommandResultIn,
                   request: Request,
                   agent: AgentIdentity = Depends(require_agent)):
    """Report the outcome of a claimed command.

    Scoped to the calling host, so an agent cannot complete another's work.
    """
    ip = client_ip(request)
    with db() as conn:
        with conn.transaction():
            row = conn.execute(
                """UPDATE agent_commands
                      SET completed_at=now(), ok=%s, result=%s
                    WHERE id=%s AND host_id=%s AND completed_at IS NULL
                RETURNING id, verb, job_id""",
                (body.ok, json.dumps(body.result), command_id, agent.host_id),
            ).fetchone()

            if not row:
                raise HTTPException(
                    status_code=404,
                    detail="no such pending command for this host",
                )

            # Evidence is written as work progresses, not only at the end, so
            # a job that dies midway still shows how far it got.
            if row["job_id"]:
                stage_map = {
                    "run_precheck": "precheck",
                    "download_packages": "download",
                    "install_packages": "install",
                    "reboot_host": "reboot",
                    "run_postcheck": "postcheck",
                    "report_evidence": "evidence",
                }
                stage = stage_map.get(row["verb"], "queued")
                conn.execute(
                    """INSERT INTO job_events
                         (job_id, host_id, stage, ok, message, detail)
                       VALUES (%s,%s,%s,%s,%s,%s)""",
                    (row["job_id"], agent.host_id, stage, body.ok,
                     body.message, json.dumps(body.result)),
                )

            audit(conn, actor=agent.hostname, actor_type="agent",
                  action=f"command_result:{row['verb']}",
                  host_id=agent.host_id, object_type="command",
                  object_id=str(command_id),
                  detail={"ok": body.ok}, source_ip=ip)

    return {"ok": True}


# ---------------------------------------------------------------------------
# Admin endpoints
# ---------------------------------------------------------------------------

@app.post("/api/v1/admin/enrollment-tokens")
def create_enrollment_token(
    request: Request,
    label: Optional[str] = Body(default=None),
    host_group: str = Body(default="default"),
    ttl_hours: int = Body(default=ENROLL_TOKEN_TTL_HOURS),
    admin: str = Depends(require_admin),
):
    """Issue a single-use enrollment token.

    Returned in full exactly once; only its hash is stored. A shared secret
    baked into an image would let any host that ever held it impersonate any
    other host indefinitely, which is why these expire and are single-use.
    """
    if not 1 <= ttl_hours <= 720:
        raise HTTPException(status_code=422, detail="ttl_hours must be 1..720")

    token = secrets.token_urlsafe(32)
    expires = now() + timedelta(hours=ttl_hours)

    with db() as conn:
        with conn.transaction():
            grp = conn.execute(
                "SELECT name FROM host_groups WHERE name=%s", (host_group,)
            ).fetchone()
            if not grp:
                raise HTTPException(
                    status_code=422,
                    detail=f"unknown host_group '{host_group}'",
                )
            row = conn.execute(
                """INSERT INTO enrollment_tokens
                     (token_hash, label, host_group, expires_at)
                   VALUES (%s,%s,%s,%s) RETURNING id""",
                (sha256(token), label, host_group, expires),
            ).fetchone()
            audit(conn, actor=admin, actor_type="user",
                  action="create_enrollment_token",
                  object_type="enrollment_token", object_id=str(row["id"]),
                  detail={"host_group": host_group, "ttl_hours": ttl_hours,
                          "label": label},
                  source_ip=client_ip(request))

    return {
        "id": str(row["id"]),
        "enrollment_token": token,
        "host_group": host_group,
        "expires_at": expires.isoformat(),
        "note": "shown once; only the hash is stored",
    }


@app.get("/api/v1/admin/hosts")
def list_hosts(status_filter: Optional[str] = None,
               os_id: Optional[str] = None,
               admin: str = Depends(require_admin)):
    sql = """SELECT id, hostname, fqdn, os_id, os_version, arch, status,
                    kernel_running, reboot_required, host_group,
                    agent_version, last_checkin, last_inventory, enrolled_at
               FROM hosts WHERE TRUE"""
    params: List[Any] = []
    if status_filter:
        sql += " AND status = %s"
        params.append(status_filter)
    if os_id:
        sql += " AND os_id = %s"
        params.append(os_id)
    sql += " ORDER BY hostname"

    with db() as conn:
        rows = conn.execute(sql, params).fetchall()

    return {"count": len(rows), "hosts": [
        {**r, "id": str(r["id"])} for r in rows
    ]}


@app.get("/api/v1/admin/hosts/{host_id}")
def get_host(host_id: str, admin: str = Depends(require_admin)):
    with db() as conn:
        host = conn.execute(
            """SELECT id, hostname, fqdn, machine_id, os_id, os_version,
                      os_major, arch, pkg_manager, kernel_running,
                      kernel_latest, reboot_required, reboot_reason,
                      agent_version, status, host_group, tags,
                      enrolled_at, last_checkin, last_inventory,
                      boot_time, host(agent_ip) AS agent_ip
                 FROM hosts WHERE id=%s""",
            (host_id,)).fetchone()
        if not host:
            raise HTTPException(status_code=404, detail="host not found")
        pkg_count = conn.execute(
            "SELECT count(*) AS n FROM host_packages WHERE host_id=%s",
            (host_id,)).fetchone()["n"]
        runs = conn.execute(
            """SELECT collected_at, package_count, ok, error
                 FROM inventory_runs WHERE host_id=%s
                ORDER BY collected_at DESC LIMIT 5""",
            (host_id,)).fetchall()

    return {
        "host": {**host, "id": str(host["id"])},
        "package_count": pkg_count,
        "recent_inventory_runs": runs,
    }


@app.get("/api/v1/admin/hosts/{host_id}/packages")
def get_host_packages(host_id: str, name: Optional[str] = None,
                      admin: str = Depends(require_admin)):
    sql = """SELECT name, arch, epoch, version, release, full_nevra, from_repo
               FROM host_packages WHERE host_id=%s"""
    params: List[Any] = [host_id]
    if name:
        sql += " AND name ILIKE %s"
        params.append(f"%{name}%")
    sql += " ORDER BY name LIMIT 5000"

    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"count": len(rows), "packages": rows}


@app.get("/api/v1/admin/fleet-summary")
def fleet_summary(admin: str = Depends(require_admin)):
    with db() as conn:
        summary = conn.execute("SELECT * FROM v_fleet_summary").fetchall()
        totals = conn.execute(
            """SELECT count(*) AS hosts,
                      count(*) FILTER (WHERE status='active')  AS active,
                      count(*) FILTER (WHERE status='stale')   AS stale,
                      count(*) FILTER (WHERE status='pending') AS pending,
                      count(*) FILTER (WHERE reboot_required)  AS awaiting_reboot
                 FROM hosts WHERE status <> 'decommissioned'"""
        ).fetchone()
    return {"totals": totals, "by_os": summary}


@app.post("/api/v1/admin/mark-stale")
def mark_stale(admin: str = Depends(require_admin),
               staleness_hours: int = Body(default=STALE_HOURS)):
    """Mark silent hosts stale and their verdicts unknown.

    A host that stops reporting must fail toward attention, never read as
    compliant. Normally driven by the scheduler; exposed here for operators.
    """
    with db() as conn:
        with conn.transaction():
            n = conn.execute("SELECT mark_stale_hosts(%s) AS n",
                             (staleness_hours,)).fetchone()["n"]
            audit(conn, actor=admin, actor_type="user", action="mark_stale",
                  detail={"hosts_marked": n, "staleness_hours": staleness_hours})
    return {"hosts_marked_stale": n}


@app.post("/api/v1/admin/hosts/{host_id}/decommission")
def decommission(host_id: str, request: Request,
                 admin: str = Depends(require_admin)):
    """Retire a host. History is retained: the audit log has no foreign key
    to hosts precisely so decommissioning does not erase evidence."""
    with db() as conn:
        with conn.transaction():
            row = conn.execute(
                """UPDATE hosts
                      SET status='decommissioned', token_hash=NULL,
                          updated_at=now()
                    WHERE id=%s RETURNING hostname""",
                (host_id,),
            ).fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="host not found")
            # Revoking the token is the actual access removal
            conn.execute("DELETE FROM agent_commands WHERE host_id=%s",
                         (host_id,))
            audit(conn, actor=admin, actor_type="user", action="decommission",
                  host_id=host_id, detail={"hostname": row["hostname"]},
                  source_ip=client_ip(request))
    return {"ok": True, "hostname": row["hostname"]}


@app.get("/api/v1/admin/audit")
def get_audit(limit: int = 100, host_id: Optional[str] = None,
              action: Optional[str] = None,
              admin: str = Depends(require_admin)):
    limit = max(1, min(limit, 1000))
    sql = "SELECT * FROM audit_log WHERE TRUE"
    params: List[Any] = []
    if host_id:
        sql += " AND host_id = %s"
        params.append(host_id)
    if action:
        sql += " AND action = %s"
        params.append(action)
    sql += " ORDER BY occurred_at DESC LIMIT %s"
    params.append(limit)

    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"count": len(rows), "events": rows}


# ---------------------------------------------------------------------------
# Applicability (read-only; written by app.cve_engine)
# ---------------------------------------------------------------------------

@app.get("/api/v1/admin/applicability/summary")
def applicability_summary(admin: str = Depends(require_admin)):
    """Fleet-wide verdict counts. Only fixed_active counts as remediated."""
    with db() as conn:
        by_state = conn.execute(
            """SELECT state, count(*) AS n, count(DISTINCT host_id) AS hosts
                 FROM host_applicability GROUP BY state ORDER BY state"""
        ).fetchall()
        top = conn.execute(
            """SELECT ha.advisory_id, a.severity, a.title, a.issued_at,
                      count(DISTINCT ha.host_id) AS hosts_affected,
                      array_agg(DISTINCT ac.cve_id) FILTER (WHERE ac.cve_id IS NOT NULL) AS cves
                 FROM host_applicability ha
                 JOIN advisories a ON a.id = ha.advisory_id
                 LEFT JOIN advisory_cves ac ON ac.advisory_id = a.id
                WHERE ha.state = 'affected'
                GROUP BY ha.advisory_id, a.severity, a.title, a.issued_at
                ORDER BY CASE a.severity WHEN 'critical' THEN 1 WHEN 'important' THEN 2
                                         WHEN 'moderate' THEN 3 ELSE 4 END,
                         hosts_affected DESC, a.issued_at DESC
                LIMIT 25"""
        ).fetchall()
        last = conn.execute(
            "SELECT max(computed_at) AS at FROM host_applicability").fetchone()
    return {"computed_at": last["at"], "by_state": by_state,
            "top_affected": top}


@app.get("/api/v1/admin/hosts/{host_id}/advisories")
def host_advisories(host_id: str, state: Optional[str] = None,
                    admin: str = Depends(require_admin)):
    valid = {"affected", "fixed_active", "fixed_pending_reboot", "unknown"}
    if state and state not in valid:
        raise HTTPException(status_code=422,
                            detail=f"state must be one of {sorted(valid)}")
    sql = """SELECT ha.advisory_id, ha.state, ha.fix_available,
                    ha.package_name, ha.installed_evr, ha.fixed_evr,
                    ha.reason, ha.computed_at,
                    a.severity, a.title, a.issued_at,
                    r.max_cvss, r.any_kev, r.max_epss, r.attack_classes,
                    r.cves_with_details,
                    array_agg(DISTINCT ac.cve_id) FILTER (WHERE ac.cve_id IS NOT NULL) AS cves
               FROM host_applicability ha
               JOIN advisories a ON a.id = ha.advisory_id
               LEFT JOIN advisory_cves ac ON ac.advisory_id = a.id
               LEFT JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id
              WHERE ha.host_id = %s"""
    params: List[Any] = [host_id]
    if state:
        sql += " AND ha.state = %s"
        params.append(state)
    sql += """ GROUP BY ha.advisory_id, ha.state, ha.fix_available, ha.package_name,
                        ha.installed_evr, ha.fixed_evr, ha.reason, ha.computed_at,
                        a.severity, a.title, a.issued_at,
                        r.max_cvss, r.any_kev, r.max_epss, r.attack_classes,
                        r.cves_with_details
               ORDER BY r.any_kev DESC NULLS LAST,
                        CASE ha.state WHEN 'affected' THEN 1
                          WHEN 'fixed_pending_reboot' THEN 2 WHEN 'unknown' THEN 3
                          ELSE 4 END,
                        CASE a.severity WHEN 'critical' THEN 1 WHEN 'important' THEN 2
                          WHEN 'moderate' THEN 3 ELSE 4 END,
                        a.issued_at DESC
               LIMIT 2000"""
    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"count": len(rows), "advisories": rows}


@app.get("/api/v1/admin/compliance")
def compliance(admin: str = Depends(require_admin)):
    """One row per host with its verdict counts."""
    with db() as conn:
        rows = conn.execute(
            """SELECT v.host_id, v.hostname, v.os_id, v.os_major,
                      v.host_status, v.last_checkin,
                      v.affected, v.pending_reboot, v.remediated, v.unknown,
                      v.blocked_not_mirrored,
                      h.os_version, h.kernel_running, h.reboot_required,
                      h.host_group, h.last_inventory, h.boot_time,
                      agent_state(h.last_checkin, h.status, %s) AS agent_state
                 FROM v_compliance v JOIN hosts h ON h.id = v.host_id
                ORDER BY v.affected DESC, v.pending_reboot DESC, v.hostname""",
            (ONLINE_MINUTES,),
        ).fetchall()
    return {"count": len(rows), "hosts": rows, "online_minutes": ONLINE_MINUTES}


# ---------------------------------------------------------------------------
# Explanations from AI-01 (advisory only; the verdict is the CVE engine's)
# ---------------------------------------------------------------------------

@app.post("/api/v1/admin/hosts/{host_id}/advisories/{advisory_id}/explain")
def explain_verdict(host_id: str, advisory_id: str, request: Request,
                    admin: str = Depends(require_admin)):
    from . import llm
    with db() as conn:
        try:
            return llm.explain(conn, host_id, advisory_id, requested_by=admin)
        except llm.NotFound as e:
            raise HTTPException(status_code=404, detail=str(e))
        except llm.LLMBusy as e:
            raise HTTPException(status_code=429, detail=str(e))
        except llm.LLMUnavailable as e:
            log.warning("explain failed for %s: %s", advisory_id, e)
            raise HTTPException(status_code=503, detail=str(e))


@app.get("/api/v1/admin/llm/status")
def llm_status(admin: str = Depends(require_admin)):
    from . import llm
    h = llm.health()
    with db() as conn:
        s = llm.stats(conn)
    return {**h, **s, "prompt_version": llm.PROMPT_VERSION,
            "model_tag": llm.AI01_MODEL_TAG}


@app.get("/api/v1/admin/agents")
def list_agents(admin: str = Depends(require_admin)):
    """Agent health for every server. Online/offline is computed now, from
    the last check-in, so it cannot be out of date."""
    with db() as conn:
        rows = conn.execute(
            """SELECT host_id, hostname, fqdn, os_id, os_version, host_group,
                      agent_version, host(agent_ip) AS agent_ip, host_status,
                      agent_state(last_checkin, host_status, %s) AS agent_state,
                      last_checkin, last_inventory, boot_time,
                      CASE WHEN boot_time IS NOT NULL
                           THEN extract(epoch FROM (now() - boot_time))::bigint END AS uptime_seconds,
                      reboot_required, enrolled_at
                 FROM hosts
                WHERE status <> 'decommissioned'
                ORDER BY CASE agent_state(last_checkin, status, %s)
                           WHEN 'offline' THEN 1 WHEN 'not_reporting' THEN 2
                           WHEN 'no_data' THEN 3 ELSE 4 END,
                         hostname""",
            (ONLINE_MINUTES, ONLINE_MINUTES),
        ).fetchall()
        versions = conn.execute(
            """SELECT coalesce(agent_version, 'unknown') AS version, count(*) AS n
                 FROM hosts WHERE status <> 'decommissioned'
                GROUP BY 1 ORDER BY 2 DESC"""
        ).fetchall()
    counts = {}
    for r in rows:
        counts[r["agent_state"]] = counts.get(r["agent_state"], 0) + 1
    return {"count": len(rows), "online_minutes": ONLINE_MINUTES,
            "by_state": counts, "versions": versions, "agents": rows}


# ---------------------------------------------------------------------------
# VMware (read-only; written by app.vmware)
# ---------------------------------------------------------------------------

SNAPSHOT_OLD_DAYS = int(os.environ.get("SNAPSHOT_OLD_DAYS", "7"))


@app.get("/api/v1/admin/vmware/summary")
def vmware_summary(admin: str = Depends(require_admin)):
    with db() as conn:
        vcs = conn.execute(
            """SELECT name, host, version, last_sync_at, last_ok, last_error, vm_count
                 FROM vcenters ORDER BY name""").fetchall()
        c = conn.execute(
            """SELECT count(*)                                             AS vms,
                      count(*) FILTER (WHERE is_linux)                     AS linux,
                      count(*) FILTER (WHERE host_id IS NOT NULL)          AS matched,
                      count(*) FILTER (WHERE is_linux AND host_id IS NULL
                                         AND power_state='poweredOn')       AS unmanaged,
                      count(*) FILTER (WHERE match_method='ambiguous')     AS ambiguous,
                      count(*) FILTER (WHERE snapshot_count > 0
                        AND oldest_snapshot_at < now() - make_interval(days => %s)) AS old_snapshots
                 FROM vm_inventory""", (SNAPSHOT_OLD_DAYS,)).fetchone()
        unmatched_hosts = conn.execute(
            """SELECT count(*) AS n FROM hosts h
                WHERE h.status <> 'decommissioned'
                  AND NOT EXISTS (SELECT 1 FROM vm_inventory v WHERE v.host_id = h.id)"""
        ).fetchone()["n"]
    return {"vcenters": vcs, "counts": c, "servers_without_vm": unmatched_hosts,
            "snapshot_old_days": SNAPSHOT_OLD_DAYS}


@app.get("/api/v1/admin/vmware/vms")
def vmware_vms(view: str = "unmanaged", admin: str = Depends(require_admin)):
    where = {
        "unmanaged": "v.is_linux AND v.host_id IS NULL AND v.power_state='poweredOn'",
        "snapshots": "v.snapshot_count > 0",
        "ambiguous": "v.match_method = 'ambiguous'",
        "linux": "v.is_linux",
        "all": "TRUE",
    }.get(view)
    if where is None:
        raise HTTPException(status_code=422, detail="unknown view")
    order = "v.oldest_snapshot_at NULLS LAST" if view == "snapshots" else "v.vcenter, v.name"
    with db() as conn:
        rows = conn.execute(
            f"""SELECT v.vcenter, v.moref, v.name, v.power_state, v.guest_os, v.is_linux,
                       v.guest_hostname, v.guest_ips, v.tools_running, v.esxi_host,
                       v.cluster, v.datacenter, v.num_cpu, v.memory_mb,
                       v.snapshot_count, v.oldest_snapshot_at, v.snapshots,
                       v.match_method, v.synced_at, v.host_id, h.hostname AS server
                  FROM vm_inventory v LEFT JOIN hosts h ON h.id = v.host_id
                 WHERE {where}
                 ORDER BY {order}
                 LIMIT 5000""").fetchall()
    return {"count": len(rows), "view": view, "vms": rows}


@app.get("/api/v1/admin/hosts/{host_id}/vm")
def host_vm(host_id: str, admin: str = Depends(require_admin)):
    with db() as conn:
        row = conn.execute(
            """SELECT vcenter, moref, name, power_state, guest_os, esxi_host, cluster,
                      datacenter, num_cpu, memory_mb, tools_running, tools_version_status,
                      snapshot_count, oldest_snapshot_at, snapshots, match_method, synced_at
                 FROM vm_inventory WHERE host_id = %s
                 ORDER BY synced_at DESC LIMIT 1""", (host_id,)).fetchone()
    return {"vm": row, "snapshot_old_days": SNAPSHOT_OLD_DAYS}


@app.get("/api/v1/admin/advisories/{advisory_id}/cves")
def advisory_cves(advisory_id: str, admin: str = Depends(require_admin)):
    """Published facts for every CVE in one advisory: score, how it is
    reached, whether it is being exploited, and the derived attack type with
    the data it was derived from."""
    with db() as conn:
        rows = conn.execute(
            """SELECT ac.cve_id, cd.cvss_score, cd.cvss_severity, cd.cvss_vector,
                      cd.cvss_version, cd.cvss_source, cd.attack_class, cd.attack_class_basis,
                      cd.attack_vector, cd.attack_complexity, cd.privileges_required,
                      cd.user_interaction, cd.cwes, cd.description,
                      cd.kev, cd.kev_added, cd.kev_due, cd.kev_ransomware,
                      cd.epss, cd.epss_percentile,
                      cd.rh_severity, cd.rh_cvss_score, cd.rh_statement,
                      cd.published, cd.last_modified, cd.nvd_fetched_at, cd.fetch_error
                 FROM advisory_cves ac
                 LEFT JOIN cve_details cd ON cd.cve_id = ac.cve_id
                WHERE ac.advisory_id = %s
                ORDER BY cd.kev DESC NULLS LAST, cd.cvss_score DESC NULLS LAST, ac.cve_id""",
            (advisory_id,)).fetchall()
    have = sum(1 for r in rows if r["nvd_fetched_at"])
    return {"advisory_id": advisory_id, "count": len(rows), "with_details": have, "cves": rows}


@app.get("/api/v1/admin/cve-intel/status")
def cve_intel_status(admin: str = Depends(require_admin)):
    with db() as conn:
        c = conn.execute(
            """SELECT count(*) AS cves,
                      count(*) FILTER (WHERE nvd_fetched_at IS NOT NULL) AS with_nvd,
                      count(*) FILTER (WHERE kev)                        AS exploited,
                      count(*) FILTER (WHERE epss IS NOT NULL)           AS with_epss,
                      count(*) FILTER (WHERE attack_class IS NOT NULL)   AS classified
                 FROM cve_details""").fetchone()
        tracked = conn.execute("SELECT count(DISTINCT cve_id) AS n FROM advisory_cves").fetchone()["n"]
        syncs = conn.execute(
            """SELECT DISTINCT ON (source) source, started_at, finished_at, ok, items, error
                 FROM intel_syncs ORDER BY source, started_at DESC""").fetchall()
    return {"cves_referenced": tracked, **dict(c), "last_syncs": syncs}


# ---------------------------------------------------------------------------
# CVE assessments: evaluate a list that arrived from outside
# ---------------------------------------------------------------------------

MAX_UPLOAD_BYTES = 2 * 1024 * 1024


@app.post("/api/v1/admin/assessments")
async def create_assessment(request: Request,
                            name: str = Form(...),
                            source: Optional[str] = Form(default=None),
                            note: Optional[str] = Form(default=None),
                            text: Optional[str] = Form(default=None),
                            file: Optional[UploadFile] = File(default=None),
                            admin: str = Depends(require_admin)):
    """Take a CVE list, as an uploaded file or pasted text, and evaluate it."""
    from . import assess

    body = text or ""
    if file is not None:
        raw = await file.read(MAX_UPLOAD_BYTES + 1)
        if len(raw) > MAX_UPLOAD_BYTES:
            raise HTTPException(status_code=413,
                                detail=f"file larger than {MAX_UPLOAD_BYTES // 1024 // 1024} MB")
        # Any text format: a pasted list, CSV, or an exported bulletin
        body += "\n" + raw.decode("utf-8", errors="replace")

    cves, rejected = assess.parse_cve_list(body)
    if not cves:
        raise HTTPException(
            status_code=422,
            detail="No CVE identifiers found. Expected text containing CVE-YYYY-NNNN. "
                   "Spreadsheets must be saved as CSV or the list pasted in.")

    name = (name or "").strip()[:200] or "Untitled assessment"
    with db() as conn:
        with conn.transaction():
            items, in_scope = assess.evaluate(conn, cves)
            aid = assess.save(conn, name, (source or "").strip()[:100] or None,
                              (note or "").strip()[:2000] or None, admin,
                              cves, rejected, items, in_scope)
            audit(conn, actor=admin, actor_type="user", action="cve_assessment",
                  object_type="assessment", object_id=aid,
                  detail={"name": name, "cves": len(cves),
                          **assess.summarise(items)},
                  source_ip=client_ip(request))
    return {"id": aid, "name": name, "cve_count": len(cves), "rejected": rejected,
            "hosts_in_scope": in_scope, "summary": assess.summarise(items),
            "items": items}


@app.get("/api/v1/admin/assessments")
def list_assessments(admin: str = Depends(require_admin)):
    with db() as conn:
        rows = conn.execute(
            """SELECT a.id, a.name, a.source, a.created_by, a.created_at, a.cve_count,
                      a.hosts_in_scope,
                      count(*) FILTER (WHERE i.status='affected')       AS affected,
                      count(*) FILTER (WHERE i.status='pending_reboot') AS pending_reboot,
                      count(*) FILTER (WHERE i.status='patched')        AS patched,
                      count(*) FILTER (WHERE i.status='unknown')        AS unknown,
                      count(*) FILTER (WHERE i.status='not_applicable') AS not_applicable,
                      count(*) FILTER (WHERE i.status='no_vendor_data') AS no_vendor_data,
                      count(*) FILTER (WHERE i.kev AND i.status='affected') AS exploited_affected
                 FROM cve_assessments a
                 LEFT JOIN cve_assessment_items i ON i.assessment_id = a.id
                GROUP BY a.id ORDER BY a.created_at DESC LIMIT 200""").fetchall()
    return {"count": len(rows), "assessments": rows}


@app.get("/api/v1/admin/assessments/{assessment_id}")
def get_assessment(assessment_id: str, admin: str = Depends(require_admin)):
    with db() as conn:
        head = conn.execute("SELECT * FROM cve_assessments WHERE id=%s",
                            (assessment_id,)).fetchone()
        if not head:
            raise HTTPException(status_code=404, detail="assessment not found")
        items = conn.execute(
            """SELECT * FROM cve_assessment_items WHERE assessment_id=%s
                ORDER BY CASE status WHEN 'affected' THEN 1 WHEN 'pending_reboot' THEN 2
                           WHEN 'unknown' THEN 3 WHEN 'no_vendor_data' THEN 4
                           WHEN 'patched' THEN 5 ELSE 6 END,
                         kev DESC, cvss_score DESC NULLS LAST, cve_id""",
            (assessment_id,)).fetchall()
    return {"assessment": head, "items": items}


@app.get("/api/v1/admin/assessments/{assessment_id}/export.csv",
         response_class=PlainTextResponse)
def export_assessment(assessment_id: str, admin: str = Depends(require_admin)):
    """CSV to send back to whoever asked the question."""
    import csv
    import io
    with db() as conn:
        head = conn.execute("SELECT name, created_at FROM cve_assessments WHERE id=%s",
                            (assessment_id,)).fetchone()
        if not head:
            raise HTTPException(status_code=404, detail="assessment not found")
        items = conn.execute(
            """SELECT cve_id, status, cvss_score, kev, attack_class, affected,
                      pending_reboot, patched, unknown, advisories, packages, affected_hosts
                 FROM cve_assessment_items WHERE assessment_id=%s ORDER BY cve_id""",
            (assessment_id,)).fetchall()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["cve", "status", "cvss", "exploited_in_wild", "attack_type",
                "servers_affected", "servers_awaiting_reboot", "servers_patched",
                "servers_unknown", "advisories", "packages", "affected_server_names"])
    for i in items:
        names = ";".join(h.get("hostname", "") for h in (i["affected_hosts"] or [])
                         if h.get("state") == "affected")
        w.writerow([i["cve_id"], i["status"], i["cvss_score"] or "",
                    "yes" if i["kev"] else "no", i["attack_class"] or "",
                    i["affected"], i["pending_reboot"], i["patched"], i["unknown"],
                    ";".join(i["advisories"] or []), ";".join(i["packages"] or []), names])
    fn = re.sub(r"[^A-Za-z0-9_-]+", "-", head["name"])[:60] or "assessment"
    return PlainTextResponse(
        buf.getvalue(), media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{fn}.csv"'})


@app.delete("/api/v1/admin/assessments/{assessment_id}")
def delete_assessment(assessment_id: str, request: Request,
                      admin: str = Depends(require_admin)):
    with db() as conn:
        with conn.transaction():
            row = conn.execute("DELETE FROM cve_assessments WHERE id=%s RETURNING name",
                               (assessment_id,)).fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="assessment not found")
            audit(conn, actor=admin, actor_type="user", action="delete_assessment",
                  object_type="assessment", object_id=assessment_id,
                  detail={"name": row["name"]}, source_ip=client_ip(request))
    return {"ok": True}


# ---------------------------------------------------------------------------
# Admin chat: read-only questions about the fleet
# ---------------------------------------------------------------------------

@app.post("/api/v1/admin/chat")
def chat(request: Request, question: str = Body(..., embed=True),
         admin: str = Depends(require_admin)):
    """Answer a question from prepared read-only queries.

    The model only selects which query to run; the figures come from the
    database and the rows are returned so the operator can check them.
    Nothing here can change a server.
    """
    from . import chat as chatmod
    from . import llm

    def ask_model(messages):
        return llm.choose(messages)

    use_model = None
    try:
        if llm.configured():
            use_model = ask_model
    except Exception:  # noqa: BLE001
        use_model = None

    with db() as conn:
        try:
            res = chatmod.ask(conn, question, ask_model=use_model, requested_by=admin)
        except ValueError as e:
            raise HTTPException(status_code=422, detail=str(e))
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="chat_query",
                  detail={"question": question[:300], "tool": res.get("tool"),
                          "how": res.get("how"), "rows": len(res.get("rows") or [])},
                  source_ip=client_ip(request))
    return res
