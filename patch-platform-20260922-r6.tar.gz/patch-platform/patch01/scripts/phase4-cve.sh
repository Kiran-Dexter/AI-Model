#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 phase 4 : CVE applicability engine
#
# Runs app.cve_engine inside the API image on the patchnet network, so it can
# reach Pulp and PostgreSQL by name without publishing any port.
#
# Usage:
#   ./phase4-cve.sh                  import advisories and compute verdicts
#   ./phase4-cve.sh --import         import only
#   ./phase4-cve.sh --compute        compute only (after new inventory)
#   ./phase4-cve.sh --report         print the current results
#   ./phase4-cve.sh --host NAME      verdicts for one host
#   ./phase4-cve.sh --install-timer  run nightly at 03:30
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 027

PATCH_BASE="/patch"
ETC_DIR="/etc/patch-platform"
LOG_DIR="/var/log/patch-platform"
SECRETS_DIR="$PATCH_BASE/secrets"
API_IMAGE="patch01/api:1.0.0"

MODE_ARGS=()
REPORT=no
HOST=""
TIMER=no
INTEL=no
INTEL_ARGS=()
SET_KEY=no
DIAGNOSE=no
NVD_KEY_FILE="/patch/secrets/nvd-api-key"

while (($#)); do
  case "$1" in
    --import)        MODE_ARGS=(--import) ;;
    --intel)         INTEL=yes ;;
    --estimate)      INTEL=yes; INTEL_ARGS=(--estimate) ;;
    --intel-only)    INTEL=yes; INTEL_ARGS=(--only "${2:-nvd}"); shift ;;
    --set-nvd-key)   SET_KEY=yes ;;
    --diagnose)      DIAGNOSE=yes ;;
    --compute)       MODE_ARGS=(--compute) ;;
    --report)        REPORT=yes ;;
    --host)          HOST="${2:-}"; shift ;;
    --install-timer) TIMER=yes ;;
    -h|--help)       sed -n '2,15p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/phase4-$(date +%Y%m%d-%H%M%S).log"

say()  { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }
step() { printf '\n==> %s\n' "$*"; }
die()  { printf '\nERROR: %s\n' "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Run as root."

psql_db() {
  docker exec -i patch01-postgres psql -U postgres -d patchdb -P pager=off "$@"
}

# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------
if [[ -n "$HOST" ]]; then
  step "Verdicts for $HOST"
  psql_db -v h="$HOST" <<'SQL'
SELECT ha.state, a.severity, ha.advisory_id, ha.package_name,
       ha.installed_evr AS installed, ha.fixed_evr AS fixed
  FROM host_applicability ha
  JOIN hosts h ON h.id = ha.host_id
  JOIN advisories a ON a.id = ha.advisory_id
 WHERE h.hostname = :'h' AND ha.state <> 'fixed_active'
 ORDER BY CASE ha.state WHEN 'affected' THEN 1 WHEN 'fixed_pending_reboot' THEN 2 ELSE 3 END,
          CASE a.severity WHEN 'critical' THEN 1 WHEN 'important' THEN 2
                          WHEN 'moderate' THEN 3 ELSE 4 END,
          a.issued_at DESC
 LIMIT 50;
SQL
  exit 0
fi

if [[ "$REPORT" == yes ]]; then
  step "Advisory data"
  psql_db <<'SQL'
SELECT vendor, os_id, os_major, count(*) AS advisories,
       count(*) FILTER (WHERE severity='critical')  AS critical,
       count(*) FILTER (WHERE severity='important') AS important
  FROM advisories GROUP BY vendor, os_id, os_major ORDER BY os_id, os_major;
SQL
  step "Verdicts by state (only fixed_active counts as remediated)"
  psql_db <<'SQL'
SELECT state, count(*) AS verdicts, count(DISTINCT host_id) AS hosts
  FROM host_applicability GROUP BY state ORDER BY state;
SQL
  step "Per host"
  psql_db <<'SQL'
SELECT v.hostname, v.os_id || ' ' || h.os_version AS os, v.host_status,
       v.affected, v.pending_reboot, v.remediated, v.unknown
  FROM v_compliance v JOIN hosts h ON h.id = v.host_id
 ORDER BY v.affected DESC, v.hostname;
SQL
  step "CVE data collected"
  psql_db <<'SQL'
SELECT count(*) AS cves,
       count(*) FILTER (WHERE nvd_fetched_at IS NOT NULL) AS from_nvd,
       count(*) FILTER (WHERE kev)                        AS exploited_in_wild,
       count(*) FILTER (WHERE epss IS NOT NULL)           AS with_epss,
       count(*) FILTER (WHERE attack_class IS NOT NULL)   AS attack_type_known
  FROM cve_details;
SQL
  step "Exploited in the wild, affecting your servers"
  psql_db <<'SQL'
SELECT cd.cve_id, cd.cvss_score AS cvss, left(coalesce(cd.attack_class,'-'), 44) AS attack_type,
       count(DISTINCT ha.host_id) AS servers
  FROM cve_details cd
  JOIN advisory_cves ac ON ac.cve_id = cd.cve_id
  JOIN host_applicability ha ON ha.advisory_id = ac.advisory_id AND ha.state = 'affected'
 WHERE cd.kev
 GROUP BY cd.cve_id, cd.cvss_score, cd.attack_class
 ORDER BY servers DESC, cd.cvss_score DESC NULLS LAST
 LIMIT 15;
SQL
  step "Most urgent affected advisories"
  psql_db <<'SQL'
SELECT ha.advisory_id, a.severity, count(DISTINCT ha.host_id) AS hosts,
       left(a.title, 60) AS title
  FROM host_applicability ha JOIN advisories a ON a.id = ha.advisory_id
 WHERE ha.state = 'affected'
 GROUP BY ha.advisory_id, a.severity, a.title, a.issued_at
 ORDER BY CASE a.severity WHEN 'critical' THEN 1 WHEN 'important' THEN 2
                          WHEN 'moderate' THEN 3 ELSE 4 END, hosts DESC, a.issued_at DESC
 LIMIT 15;
SQL
  exit 0
fi

# ---------------------------------------------------------------------------
# Timer
# ---------------------------------------------------------------------------
if [[ "$TIMER" == yes ]]; then
  SELF="$(readlink -f "$0")"
  cat >/etc/systemd/system/patch01-cve.service <<EOF
[Unit]
Description=PATCH-01 CVE applicability engine
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
ExecStart=$SELF
ExecStart=$SELF --intel
TimeoutStartSec=6h
EOF
  cat >/etc/systemd/system/patch01-cve.timer <<'EOF'
[Unit]
Description=Run the PATCH-01 CVE engine nightly

[Timer]
OnCalendar=*-*-* 03:30:00
RandomizedDelaySec=10min
Persistent=true

[Install]
WantedBy=timers.target
EOF
  systemctl daemon-reload
  systemctl enable --now patch01-cve.timer
  say "Nightly timer installed. Next run:"
  systemctl list-timers patch01-cve.timer --no-pager | sed -n '2p'
  say ""
  say "Schedule the repository sync before 03:30 so the engine sees new advisories."
  exit 0
fi

# ---------------------------------------------------------------------------
# Diagnose the advisory to CVE mapping
# ---------------------------------------------------------------------------
if [[ "$DIAGNOSE" == yes ]]; then
  step "Advisory and CVE counts"
  psql_db <<'SQL'
SELECT a.vendor, a.os_id, a.os_major,
       count(DISTINCT a.id)                                  AS advisories,
       count(DISTINCT ac.cve_id)                             AS distinct_cves,
       count(DISTINCT a.id) FILTER (WHERE ac.cve_id IS NULL)  AS advisories_without_cves
  FROM advisories a
  LEFT JOIN advisory_cves ac ON ac.advisory_id = a.id
 GROUP BY a.vendor, a.os_id, a.os_major ORDER BY a.os_id, a.os_major;
SQL

  step "How Pulp reports references on this server"
  say "CVEs come from each advisory's reference list. This prints one advisory"
  say "exactly as your Pulp returns it, so the field names can be confirmed."
  PULP_PW="$(awk '/password:/{print $2; exit}' "$SECRETS_DIR/pulp-admin.txt" 2>/dev/null || true)"
  if [[ -z "$PULP_PW" ]]; then
    warn "Could not read the Pulp admin password; skipping."
  else
    curl -sk -u "admin:$PULP_PW" \
      "https://127.0.0.1/pulp/api/v3/content/rpm/advisories/?limit=1&type=security" \
      | python3 -c '
import json,sys
try: d=json.load(sys.stdin)
except Exception as e: print("  could not parse Pulp response:", e); raise SystemExit
r=(d.get("results") or [])
if not r:
    print("  no advisories returned by Pulp"); raise SystemExit
a=r[0]
print("  advisory:", a.get("id"), "| type:", a.get("type"), "| severity:", a.get("severity"))
refs=a.get("references") or []
print("  references:", len(refs))
for x in refs[:6]:
    print("   ", json.dumps(x))
keys=sorted({k for x in refs if isinstance(x,dict) for k in x})
print("  reference field names:", keys or "none")
cve_like=[x for x in refs if isinstance(x,dict) and "cve" in json.dumps(x).lower()]
print("  references mentioning a CVE:", len(cve_like))
'
  fi
  say ""
  say "If Pulp shows CVE references but the table above has none, the import"
  say "missed them. Re-import with:  ./scripts/phase4-cve.sh --import"
  say "If Pulp shows no CVE references at all, the repository metadata omits"
  say "them, and the CVE data must come from the vendor's security feed."
  exit 0
fi

# ---------------------------------------------------------------------------
# NVD API key
# ---------------------------------------------------------------------------
if [[ "$SET_KEY" == yes ]]; then
  step "NVD API key"
  say "Request one free at https://nvd.nist.gov/developers/request-an-api-key"
  say "It raises the limit from 5 to 50 requests per 30 seconds."
  read -r -s -p "  Paste the key (hidden): " K; echo
  K="$(printf '%s' "$K" | tr -d '[:space:]')"
  [[ "$K" =~ ^[A-Za-z0-9-]{20,80}$ ]] || die "That does not look like an NVD API key."
  printf '%s\n' "$K" > "$NVD_KEY_FILE"
  chmod 0600 "$NVD_KEY_FILE"; chown root:root "$NVD_KEY_FILE"
  unset K
  say "Stored in $NVD_KEY_FILE"
  exit 0
fi

# ---------------------------------------------------------------------------
# Run the engine
# ---------------------------------------------------------------------------
step "Preconditions"

docker image inspect "$API_IMAGE" >/dev/null 2>&1 \
  || die "$API_IMAGE not found. Run ./scripts/phase3b-api.sh first."

# The engine is new code: an image built before it existed will not have it
if ! docker run --rm --network none --entrypoint "" "$API_IMAGE" \
     python -c "import app.cve_engine, app.evr" >/dev/null 2>&1; then
  warn "$API_IMAGE does not contain the CVE engine yet."
  warn "Rebuild and redeploy the API image first:"
  warn "    ./scripts/phase3b-api.sh"
  die "Image is out of date."
fi
say "Image contains the engine."

for c in patch01-postgres patch01-pulp-api; do
  docker ps --format '{{.Names}}' | grep -qx "$c" || die "$c is not running."
done

[[ -f "$SECRETS_DIR/api.env" ]]        || die "Missing $SECRETS_DIR/api.env"
[[ -f "$SECRETS_DIR/pulp-admin.txt" ]] || die "Missing $SECRETS_DIR/pulp-admin.txt"

DB_PW="$(grep -E '^PATCHDB_PASSWORD=' "$SECRETS_DIR/api.env" | cut -d= -f2-)"
PULP_PW="$(awk '/password:/{print $2; exit}' "$SECRETS_DIR/pulp-admin.txt")"
[[ -n "$DB_PW"   ]] || die "Could not read PATCHDB_PASSWORD"
[[ -n "$PULP_PW" ]] || die "Could not read the Pulp admin password"

# CVE intelligence reaches the internet, so it needs the corporate proxy.
# The engine itself does not: it reads Pulp and PostgreSQL internally.
run_intel() {
  step "Fetching CVE data (NVD, CISA KEV, FIRST EPSS, Red Hat)"
  local ef; ef="$(mktemp)"; chmod 0600 "$ef"
  {
    echo "PATCHDB_HOST=postgres"
    echo "PATCHDB_NAME=patchdb"
    echo "PATCHDB_USER=patchapi"
    echo "PATCHDB_PASSWORD=$DB_PW"
    [[ -s "$NVD_KEY_FILE" ]] && echo "NVD_API_KEY=$(cat "$NVD_KEY_FILE")" || true
    if [[ -f "$ETC_DIR/proxy.env" ]]; then
      grep -E '^(HTTP_PROXY|HTTPS_PROXY|NO_PROXY|http_proxy|https_proxy|no_proxy)=' \
        "$ETC_DIR/proxy.env" || true
    fi
  } >"$ef"
  if [[ ! -s "$NVD_KEY_FILE" ]]; then
    warn "No NVD API key stored: imports are 13 times slower."
    warn "Get one free and store it with --set-nvd-key."
  fi
  set +e
  docker run --rm --network patchnet --env-file "$ef" --entrypoint "" "$API_IMAGE" \
    python -m app.cve_intel "${INTEL_ARGS[@]}" 2>&1 | tee -a "$LOG_FILE"
  local rc=${PIPESTATUS[0]}
  set -e
  rm -f "$ef"
  return "$rc"
}

if [[ "$INTEL" == yes ]]; then
  if ! docker run --rm --network none --entrypoint "" "$API_IMAGE" \
       python -c "import app.cve_intel" >/dev/null 2>&1; then
    warn "$API_IMAGE does not contain the CVE intelligence module."
    warn "Rebuild it first:  ./scripts/phase3b-api.sh"
    die "Image is out of date."
  fi
  run_intel || die "CVE data fetch reported errors. Log: $LOG_FILE"
  say ""
  say "Explanations now use these facts. Existing cached explanations are"
  say "regenerated automatically because the CVE data is part of their key."
  exit 0
fi

step "Running the CVE engine ${MODE_ARGS[*]:-(import + compute)}"
say "The first import reads every advisory from every synced repository"
say "and can take several minutes."

# Passwords via an env file rather than -e, so they do not appear in
# the process list
ENVF="$(mktemp)"; chmod 0600 "$ENVF"
trap 'rm -f "$ENVF"' EXIT
cat >"$ENVF" <<EOF
PATCHDB_HOST=postgres
PATCHDB_NAME=patchdb
PATCHDB_USER=patchapi
PATCHDB_PASSWORD=$DB_PW
PULP_URL=http://pulp-api:24817
PULP_USER=admin
PULP_PASSWORD=$PULP_PW
EOF

set +e
docker run --rm --network patchnet --env-file "$ENVF" \
  --entrypoint "" "$API_IMAGE" \
  python -m app.cve_engine "${MODE_ARGS[@]}" 2>&1 | tee "$LOG_FILE"
RC=${PIPESTATUS[0]}
set -e
chmod 0600 "$LOG_FILE"

(( RC == 0 )) || die "Engine exited with $RC. Log: $LOG_FILE"

echo
echo "================================================================"
echo " CVE ENGINE RUN COMPLETE"
echo "================================================================"
echo " Log:     $LOG_FILE"
echo " Report:  ./scripts/phase4-cve.sh --report"
echo " Host:    ./scripts/phase4-cve.sh --host <hostname>"
echo " CVE data: ./scripts/phase4-cve.sh --intel
 Nightly: ./scripts/phase4-cve.sh --install-timer"
