"""
PATCH-01 : the worker

Carries out changes and does the slow work of CVE assessments, in the
background, so nothing waits on a browser request.

Two threads, each with its own database connection:

  changes     starts changes when their window opens, moves each target
              through its steps, and records every step as an event
  enrichment  looks up assessed CVEs in NVD, matches their products against
              the inventory, and asks AI-01 for a brief on each

Only one worker acts at a time, guarded by a PostgreSQL advisory lock, so a
second copy started by mistake waits instead of doubling every action.

A patch target moves through:

  queued -> precheck -> [snapshot] -> install -> [reboot -> wait_boot]
         -> postcheck -> inventory -> [snapshot_cleanup] -> done

Any failure stops that server at the failing step, keeps its snapshot for
rollback, and leaves the other servers in the change to carry on.

Run:  python -m app.worker
"""

import json
import re
import logging
import os
import signal
import sys
import threading
import time
import traceback
from datetime import datetime, timedelta, timezone

from . import changes as ch

log = logging.getLogger("patchapi.worker")

TICK = int(os.environ.get("WORKER_TICK", "10"))
LOCK_ID = 7_310_442                       # advisory lock: one worker at a time
CLAIM_TIMEOUT = timedelta(minutes=int(os.environ.get("AGENT_CLAIM_MINUTES", "30")))
RUN_TIMEOUT = {"install_packages": timedelta(hours=2), "download_packages": timedelta(hours=1)}
DEFAULT_RUN_TIMEOUT = timedelta(minutes=30)
RUN_ENDED_GRACE = timedelta(seconds=45)


def _agent_tail(conn, host_id, since):
    """The agent's last log lines since a moment, for a failure message."""
    rows = conn.execute(
        """SELECT level, line FROM agent_logs WHERE host_id=%s AND at >= %s - interval '10 seconds'
            ORDER BY id DESC LIMIT 5""", (host_id, since)).fetchall()
    if not rows:
        return "No agent log lines arrived: see the agent's log on the server."
    return "Agent log: " + " | ".join(f"{r['level']} {r['line'][:240]}" for r in reversed(rows))
WINDOWS_INSTALL_TIMEOUT = timedelta(hours=3)
WINDOWS_PRECHECK_TIMEOUT = timedelta(minutes=110)     # cumulative updates are slow
BOOT_TIMEOUT = timedelta(minutes=int(os.environ.get("BOOT_TIMEOUT_MINUTES", "30")))

TERMINAL = {"done", "done_with_warnings", "failed", "skipped", "cancelled"}
AGENT_STEPS = {"precheck": "run_precheck", "install": "install_packages",
               "reboot": "reboot_host", "postcheck": "run_postcheck",
               "inventory": "collect_inventory"}

_stop = threading.Event()


# ---------------------------------------------------------------------------
# The patching sequence, as a pure function
# ---------------------------------------------------------------------------

def next_patch_state(state, params, result, has_snapshot):
    """The state after `state` finished successfully with `result`.

    Pure, so the whole sequence can be tested without servers or a database.
    """
    result = result or {}
    if state == "queued":
        return "precheck"
    if state == "precheck":
        return "snapshot" if params.get("snapshot", "none") != "none" else "install"
    if state == "snapshot":
        return "install"
    if state == "install":
        if result.get("nothing_to_do"):
            return "inventory"
        reboot = params.get("reboot", "if_required")
        if reboot == "always" or (reboot == "if_required" and result.get("reboot_required")):
            return "reboot"
        return "postcheck"
    if state == "reboot":
        return "wait_boot"
    if state == "wait_boot":
        return "postcheck"
    if state == "postcheck":
        return "inventory"
    if state == "inventory":
        if params.get("snapshot") == "remove_on_success" and has_snapshot:
            return "snapshot_cleanup"
        return "done"
    if state == "snapshot_cleanup":
        return "done"
    raise ValueError(f"no successor for state {state}")


_SVC_LINUX_RE = re.compile(r"^(?:post-check failed: )?(service [\w@.:-]+ is [\w-]+)(?:; service [\w@.:-]+ is [\w-]+)*$")


def service_only_problem(result):
    """The services that did not come back, when that is the postcheck's only
    problem; otherwise None. Windows agents list them as missing_services and
    "not running any more: ..."; Linux agents as "service X is Y"."""
    errs = [str(e) for e in (result.get("errors") or [])]
    missing = [str(x) for x in (result.get("missing_services") or []) if x]
    if missing and errs and all(e.startswith("not running any more:") for e in errs):
        return missing
    msg = str(result.get("message") or "").strip()
    if _SVC_LINUX_RE.match(msg):
        return re.findall(r"service ([\w@.:-]+) is", msg)
    if errs and all(re.fullmatch(r"service [\w@.:-]+ is [\w-]+", e) for e in errs):
        return [re.match(r"service (\S+)", e).group(1) for e in errs]
    return None


def change_outcome(target_states):
    """The final state of a change from the states of its targets."""
    # Patched, but a service did not come back: the patch itself succeeded
    done = sum(1 for s in target_states if s in ("done", "done_with_warnings"))
    failed = sum(1 for s in target_states if s == "failed")
    # A server skipped because the window closed was never patched. Calling
    # the change a success would hide it.
    skipped = sum(1 for s in target_states if s == "skipped")
    if done and not failed and not skipped:
        return "succeeded"
    if done and (failed or skipped):
        return "partially_succeeded"
    if failed:
        return "failed"
    return "cancelled"


def choose_fixed_versions(rows, pkg_manager):
    """One version per package: the highest fixed version any advisory needs.

    Several advisories can fix the same package at different versions;
    installing the newest satisfies all of them.
    """
    from .evr import rpm_label_compare, deb_compare
    cmp = deb_compare if pkg_manager == "apt" else rpm_label_compare

    def split(evr):
        e, _, rest = evr.partition(":") if ":" in evr else ("0", "", evr)
        v, _, r = rest.rpartition("-") if "-" in rest else (rest, "", "")
        return (e or "0", v, r)

    best = {}
    for r in rows:
        name, fixed = r["package_name"], r["fixed_evr"]
        if not name or not fixed:
            continue
        if name not in best or cmp(*split(fixed), *split(best[name])) > 0:
            best[name] = fixed
    return [{"name": n, "version": v} for n, v in sorted(best.items())]


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

def _db():
    import psycopg
    from psycopg.rows import dict_row
    return psycopg.connect(
        host=os.environ.get("PATCHDB_HOST", "postgres"),
        port=int(os.environ.get("PATCHDB_PORT", "5432")),
        dbname=os.environ.get("PATCHDB_NAME", "patchdb"),
        user=os.environ.get("PATCHDB_USER", "patchapi"),
        password=os.environ.get("PATCHDB_PASSWORD", ""),
        row_factory=dict_row, connect_timeout=15)


def beat(conn, name, **detail):
    conn.execute(
        """INSERT INTO worker_heartbeat (name, beat_at, detail) VALUES (%s, now(), %s)
           ON CONFLICT (name) DO UPDATE SET beat_at=now(), detail=EXCLUDED.detail""",
        (name, json.dumps(detail, default=str)))
    conn.commit()


def _set(conn, change_id, key, **fields):
    cols = ", ".join(f"{k}=%s" for k in fields)
    conn.execute(f"UPDATE change_targets SET {cols}, updated_at=now() "
                 f"WHERE change_id=%s AND target_key=%s",
                 list(fields.values()) + [change_id, key])


def _detail(conn, change_id, key, **more):
    conn.execute("""UPDATE change_targets SET detail = detail || %s::jsonb, updated_at=now()
                     WHERE change_id=%s AND target_key=%s""",
                 (json.dumps(more, default=str), change_id, key))


def _queue(conn, change, t, verb, params, hours=4):
    row = conn.execute(
        """INSERT INTO agent_commands (host_id, change_id, target_key, verb, params, expires_at)
           VALUES (%s, %s, %s, %s::agent_verb, %s, now() + make_interval(hours => %s))
           RETURNING id""",
        (t["host_id"], change["id"], t["target_key"], verb, json.dumps(params), hours)).fetchone()
    return row["id"]


# ---------------------------------------------------------------------------
# Starting and finishing changes
# ---------------------------------------------------------------------------

def start_due(conn):
    missed = conn.execute(
        """UPDATE changes SET state='cancelled', finished_at=now(),
                  summary = summary || '{"reason": "window missed"}'::jsonb
            WHERE state='scheduled' AND run_before IS NOT NULL AND run_before < now()
        RETURNING id, number""").fetchall()
    for m in missed:
        ch.event(conn, m["id"], None, "worker", "cancelled", False,
                 "The window closed before the change could start.")
        conn.execute("UPDATE change_targets SET state='cancelled' WHERE change_id=%s", (m["id"],))
    started = conn.execute(
        """UPDATE changes SET state='running', started_at=now()
            WHERE id IN (SELECT id FROM changes WHERE state='scheduled' AND run_after <= now()
                          ORDER BY run_after FOR UPDATE SKIP LOCKED LIMIT 20)
        RETURNING id, number, kind""").fetchall()
    for s in started:
        ch.event(conn, s["id"], None, "worker", "started", True, f"{ch.ref(s['number'])} started")
    conn.commit()


def finish_if_done(conn, change):
    states = [r["state"] for r in conn.execute(
        "SELECT state FROM change_targets WHERE change_id=%s", (change["id"],)).fetchall()]
    if not states or any(s not in TERMINAL for s in states):
        return False
    outcome = change_outcome(states)
    summary = {s: states.count(s) for s in set(states)}
    conn.execute("UPDATE changes SET state=%s, finished_at=now(), summary=summary || %s::jsonb "
                 "WHERE id=%s", (outcome, json.dumps(summary), change["id"]))
    ch.event(conn, change["id"], None, "worker", "finished", outcome == "succeeded",
             f"{ch.ref(change['number'])} {outcome.replace('_', ' ')}", summary)
    from . import vault
    vault.discard(change["id"])              # a run-time credential never outlives its change
    return True


def vault_housekeeping(conn):
    """Drop expired credentials, and any belonging to a change that is no
    longer running or about to run (cancelled, rejected, finished)."""
    from . import vault
    import os
    vault.sweep()
    if not os.path.isdir(vault.VAULT_DIR):
        return
    ids = [f[len("change-"):-len(".cred")] for f in os.listdir(vault.VAULT_DIR)
           if f.startswith("change-") and f.endswith(".cred")]
    if not ids:
        return
    live = {r["id"] for r in conn.execute(
        "SELECT id::text AS id FROM changes WHERE id::text = ANY(%s) AND state IN ('running', 'scheduled')",
        (ids,)).fetchall()}
    for i in ids:
        if i not in live:
            vault.discard(i)


# ---------------------------------------------------------------------------
# Patch changes
# ---------------------------------------------------------------------------

def _fail(conn, change, t, reason, detail=None):
    _set(conn, change["id"], t["target_key"], state="failed", error=reason[:2000],
         current_command=None)
    keep = f" Snapshot {t['snapshot_moref']} was kept for rollback." if t.get("snapshot_moref") else ""
    ch.event(conn, change["id"], t["target_key"], "worker", "failed", False,
             f"{t['label']}: {reason}{keep}", detail or {})


def windows_updates_for(rows, mode, advisory_ids, advisory_cves):
    """Which WSUS-approved missing updates a change installs on a Windows server.

    mode "all": every approved update the server still lacks.
    mode "advisories": updates whose KB was chosen, or that fix any CVE of the
    chosen advisories. Windows updates are cumulative, so the update WSUS has
    approved this month fixes last month's CVEs too, even under another KB.
    Pure, for testing.
    """
    if mode != "advisories":
        return [r for r in rows]
    kbs = {a.upper() for a in advisory_ids or []}
    cves = set(advisory_cves or [])
    return [r for r in rows if (r.get("kb") or "").upper() in kbs or cves & set(r.get("cves") or [])]


def _windows_chosen(conn, t, p):
    """The WSUS-approved missing updates this job installs on this server."""
    rows = conn.execute("SELECT update_id, kb, title, cves FROM windows_updates WHERE host_id=%s",
                        (t["host_id"],)).fetchall()
    cves = []
    if p.get("mode") == "advisories":
        cves = [r["cve_id"] for r in conn.execute(
            "SELECT cve_id FROM advisory_cves WHERE advisory_id = ANY(%s)", (p.get("advisories") or [],)).fetchall()]
    return windows_updates_for(rows, p.get("mode"), p.get("advisories"), cves)


def _is_windows(conn, host_id):
    return bool(conn.execute("SELECT 1 FROM hosts WHERE id=%s AND pkg_manager='wua'", (host_id,)).fetchone())


def _enter_windows_install(conn, change, t, p):
    cid, key = change["id"], t["target_key"]
    chosen = _windows_chosen(conn, t, p)
    if not chosen:
        why = ("nothing approved in WSUS is missing" if p.get("mode") != "advisories" else
               "WSUS has not approved an update that fixes the chosen advisories")
        ch.event(conn, cid, key, "worker", "install", True, f"{t['label']}: nothing to install, {why}")
        _detail(conn, cid, key, nothing_to_do=True, windows_note=why)
        return _enter(conn, change, t, next_patch_state("install", p, {"nothing_to_do": True},
                                                        bool(t.get("snapshot_moref"))))
    ids = [r["update_id"] for r in chosen]
    _detail(conn, cid, key, windows_updates=[{"kb": r["kb"], "title": r["title"]} for r in chosen])
    cmd = _queue(conn, change, t, "install_packages", {"windows_updates": ids}, hours=6)
    _set(conn, cid, key, current_command=cmd)
    ch.event(conn, cid, key, "worker", "install", None,
             f"{t['label']}: installing {len(ids)} Windows update(s): "
             + ", ".join(r["kb"] or r["title"][:40] for r in chosen[:4]) + (" and more" if len(ids) > 4 else ""))


CRED_TIMEOUT = timedelta(hours=4)


def _enter_software(conn, change, t, p):
    """Install, upgrade or remove one catalog entry. Nothing runs until the
    share credential has been entered for this change: the agents cannot read
    the share without it."""
    from . import software as sw, vault
    cid, key = change["id"], t["target_key"]
    if not vault.status(cid):
        _set(conn, cid, key, state="waiting_credential", step_started_at=datetime.now(timezone.utc),
             current_command=None)
        ch.event(conn, cid, key, "worker", "waiting_credential", None,
                 f"{t['label']}: waiting for the share credential (enter it on this change's page)")
        return
    entry = conn.execute("SELECT * FROM software_catalog WHERE id=%s", (p["catalog_id"],)).fetchone()
    if not entry or entry["state"] != "approved":
        return _fail(conn, change, t, "its catalog entry is no longer approved")
    plan = sw.command_plan(entry, p["action"])
    cmd = _queue(conn, change, t, "software_action", plan, hours=6)
    _set(conn, cid, key, current_command=cmd)
    ch.event(conn, cid, key, "worker", "install", None,
             f"{t['label']}: {p['action']} {entry['name']} {entry['version']}")


def _enter(conn, change, t, state):
    """Move a target into `state` and start whatever that state does."""
    p = change["params"]
    cid, key = change["id"], t["target_key"]
    _set(conn, cid, key, state=state, step_started_at=datetime.now(timezone.utc), current_command=None)
    t["state"] = state

    if state == "precheck":
        params = {"checks": ["disk", "locks", "history"], "capture_services": bool(p.get("check_services", True))}
        if change.get("kind") == "patch" and _is_windows(conn, t["host_id"]):
            # Windows: the precheck gets the job's updates, tests where their
            # files come from and downloads them, so the install only installs
            chosen = _windows_chosen(conn, t, p)
            params.update(windows_updates=[r["update_id"] for r in chosen], stall_minutes=10)
            _detail(conn, cid, key, windows_updates=[{"kb": r["kb"], "title": r["title"]} for r in chosen])
            ch.event(conn, cid, key, "worker", "precheck", None,
                     f"{t['label']}: pre-check, then download of {len(chosen)} update(s) before the install window")
        cmd = _queue(conn, change, t, "run_precheck", params, hours=3)
        _set(conn, cid, key, current_command=cmd)

    elif state == "snapshot":
        from . import vmware
        try:
            snap = vmware.snapshot_for_patch(t["vcenter"], t["vm_moref"], ch.ref(change["number"]))
        except Exception as e:  # noqa: BLE001 - reported on the target
            return _fail(conn, change, t, f"could not take the VM snapshot, so nothing was installed: {e}")
        _set(conn, cid, key, snapshot_moref=snap)
        t["snapshot_moref"] = snap
        ch.event(conn, cid, key, "worker", "snapshot", True, f"{t['label']}: snapshot taken", {"moref": snap})
        return _enter(conn, change, t, next_patch_state("snapshot", p, {}, True))

    elif state == "install" and change.get("kind") == "software":
        return _enter_software(conn, change, t, p)

    elif state == "install":
        host = conn.execute("SELECT pkg_manager FROM hosts WHERE id=%s", (t["host_id"],)).fetchone()
        if (host or {}).get("pkg_manager") == "wua":
            return _enter_windows_install(conn, change, t, p)
        sql = """SELECT package_name, fixed_evr FROM host_applicability
                  WHERE host_id=%s AND state='affected' AND fixed_evr IS NOT NULL"""
        args = [t["host_id"]]
        if p.get("mode") == "advisories":
            sql += " AND advisory_id = ANY(%s)"
            args.append(p.get("advisories") or [])
        pkgs = choose_fixed_versions(conn.execute(sql, args).fetchall(),
                                     (host or {}).get("pkg_manager"))
        if not pkgs:
            ch.event(conn, cid, key, "worker", "install", True,
                     f"{t['label']}: nothing to install, already up to date for this change")
            _detail(conn, cid, key, nothing_to_do=True)
            return _enter(conn, change, t, next_patch_state("install", p, {"nothing_to_do": True},
                                                            bool(t.get("snapshot_moref"))))
        _detail(conn, cid, key, packages=pkgs)
        cmd = _queue(conn, change, t, "install_packages", {"packages": pkgs, "mode": "exact"})
        _set(conn, cid, key, current_command=cmd)
        ch.event(conn, cid, key, "worker", "install", None,
                 f"{t['label']}: installing {len(pkgs)} package(s)")

    elif state == "reboot":
        _detail(conn, cid, key, reboot_requested_at=datetime.now(timezone.utc).isoformat())
        cmd = _queue(conn, change, t, "reboot_host", {"delay_seconds": 60})
        _set(conn, cid, key, current_command=cmd)

    elif state == "wait_boot":
        pass                          # checked each tick in _advance

    elif state == "postcheck":
        base = (t.get("detail") or {}).get("baseline_services") or []
        cmd = _queue(conn, change, t, "run_postcheck", {"baseline_services": base})
        _set(conn, cid, key, current_command=cmd)

    elif state == "inventory":
        cmd = _queue(conn, change, t, "collect_inventory", {})
        _set(conn, cid, key, current_command=cmd)

    elif state == "snapshot_cleanup":
        from . import vmware
        try:
            vmware.remove_snapshot(t["vcenter"], t["vm_moref"], t["snapshot_moref"],
                                   f"PATCH-01 {ch.ref(change['number'])} before patching")
            ch.event(conn, cid, key, "worker", "snapshot_removed", True,
                     f"{t['label']}: patched successfully, snapshot removed")
            _set(conn, cid, key, snapshot_moref=None)
        except Exception as e:  # noqa: BLE001
            # The patch succeeded; a snapshot left behind is a warning, not a failure
            ch.event(conn, cid, key, "worker", "snapshot_removed", False,
                     f"{t['label']}: patched, but the snapshot could not be removed: {e}")
        return _enter(conn, change, t, "done")

    elif state == "done":
        _recompute(conn, t["host_id"])
        row = conn.execute("SELECT detail FROM change_targets WHERE change_id=%s AND target_key=%s", (cid, key)).fetchone()
        warn = ((row or {}).get("detail") or {}).get("warnings") or (t.get("detail") or {}).get("warnings")
        if warn:
            _set(conn, cid, key, state="done_with_warnings", error="; ".join(warn)[:1000])
            ch.event(conn, cid, key, "worker", "done", True, f"{t['label']}: complete, with warnings: " + "; ".join(warn)[:400])
        else:
            ch.event(conn, cid, key, "worker", "done", True, f"{t['label']}: complete")


def _recompute(conn, host_id):
    """Fresh verdicts for a server straight after patching it."""
    try:
        from . import cve_engine
        host = conn.execute("SELECT * FROM hosts WHERE id=%s", (host_id,)).fetchone()
        if host:
            cve_engine.compute_host(conn, host)
    except Exception as e:  # noqa: BLE001 - the nightly run will catch up
        log.warning("recompute for %s failed: %s", host_id, e)


def _advance(conn, change, t):
    p = change["params"]
    cid, key, state = change["id"], t["target_key"], t["state"]
    now = datetime.now(timezone.utc)

    if state == "waiting_credential":
        from . import vault
        if vault.status(cid):
            ch.event(conn, cid, key, "worker", "credential", True, f"{t['label']}: credential entered, continuing")
            return _enter(conn, change, t, "install")
        if now - t["step_started_at"] > CRED_TIMEOUT:
            return _fail(conn, change, t, f"no share credential was entered within "
                                          f"{int(CRED_TIMEOUT.total_seconds() // 3600)} hours")
        return

    if state == "wait_boot":
        asked = (t.get("detail") or {}).get("reboot_requested_at")
        asked = datetime.fromisoformat(asked) if asked else t["step_started_at"]
        h = conn.execute("SELECT boot_time, last_checkin FROM hosts WHERE id=%s",
                         (t["host_id"],)).fetchone()
        if h and h["boot_time"] and h["boot_time"] > asked and h["last_checkin"] and h["last_checkin"] > asked:
            ch.event(conn, cid, key, "worker", "rebooted", True, f"{t['label']}: back up after reboot")
            return _enter(conn, change, t, "postcheck")
        if now - t["step_started_at"] > BOOT_TIMEOUT:
            return _fail(conn, change, t, f"did not come back within {BOOT_TIMEOUT.seconds // 60} "
                                          f"minutes of the reboot. Check its console.")
        return

    cmd_id = t.get("current_command")
    if not cmd_id:
        return
    cmd = conn.execute("SELECT verb::text AS verb, claimed_at, completed_at, ok, result, created_at "
                       "FROM agent_commands WHERE id=%s", (cmd_id,)).fetchone()
    if not cmd:
        return _fail(conn, change, t, "its command disappeared")
    if cmd["completed_at"] is None:
        if cmd["claimed_at"] is None and now - cmd["created_at"] > CLAIM_TIMEOUT:
            return _fail(conn, change, t, f"the agent did not pick up the {state} step within "
                                          f"{CLAIM_TIMEOUT.seconds // 60} minutes. Is it online?")
        limit = RUN_TIMEOUT.get(cmd["verb"], DEFAULT_RUN_TIMEOUT)
        if cmd["verb"] == "software_action":
            limit = WINDOWS_INSTALL_TIMEOUT
        elif cmd["verb"] == "install_packages" and _is_windows(conn, t["host_id"]):
            limit = WINDOWS_INSTALL_TIMEOUT
        elif cmd["verb"] == "run_precheck" and _is_windows(conn, t["host_id"]):
            limit = WINDOWS_PRECHECK_TIMEOUT    # includes the download; the agent stops a stalled one itself
        if cmd["claimed_at"]:
            # Agents never check in while running a command (one run at a time),
            # so a check-in after the claim means that run ended without
            # answering: say so now, with the agent's own last words, instead
            # of waiting out the time limit
            # last_run_at: only a check-in (the start of a run) sets it; an
            # inventory report mid-run does not
            h = conn.execute("SELECT last_run_at FROM hosts WHERE id=%s", (t["host_id"],)).fetchone()
            if h and h["last_run_at"] and h["last_run_at"] > cmd["claimed_at"] + RUN_ENDED_GRACE:
                return _fail(conn, change, t, f"the agent took the {state} step, but its run ended without "
                                              f"reporting it. {_agent_tail(conn, t['host_id'], cmd['claimed_at'])}")
        if cmd["claimed_at"] and now - cmd["claimed_at"] > limit:
            tail = _agent_tail(conn, t["host_id"], cmd["claimed_at"])
            return _fail(conn, change, t, f"the {state} step did not report back within "
                                          f"{int(limit.total_seconds() // 60)} minutes. {tail}")
        return

    result = cmd["result"] or {}
    if not cmd["ok"] and state == "postcheck":
        svcs = service_only_problem(result)
        if svcs:
            # The updates are in; only services did not come back. That is for
            # the operator to start, not a failed patch.
            note = "patched, but these services did not come back and need starting: " + ", ".join(svcs[:20])
            _detail(conn, cid, key, warnings=[note], services_not_running=svcs[:50])
            t.setdefault("detail", {})["warnings"] = [note]
            ch.event(conn, cid, key, "worker", "postcheck", None, f"{t['label']}: {note}", {"services": svcs[:50]})
            return _enter(conn, change, t, next_patch_state(state, p, result, bool(t.get("snapshot_moref"))))
    if not cmd["ok"]:
        msg = result.get("message") or result.get("error") or "the agent reported a failure"
        errs = result.get("errors")
        return _fail(conn, change, t, f"{state} failed: " + ("; ".join(errs) if errs else str(msg)[:600]),
                     {"result": result})

    ch.event(conn, cid, key, "worker", state, True, f"{t['label']}: {state} passed",
             {k: v for k, v in result.items() if k != "output"})
    if state == "precheck" and result.get("running_services"):
        _detail(conn, cid, key, baseline_services=result["running_services"][:300])
        t.setdefault("detail", {})["baseline_services"] = result["running_services"][:300]
    if state == "install":
        _detail(conn, cid, key, install=result)
    if change.get("cancel_requested") and state in ("precheck",):
        _set(conn, cid, key, state="cancelled", current_command=None)
        return ch.event(conn, cid, key, "worker", "cancelled", None,
                        f"{t['label']}: cancelled before installing")
    keep = bool((t.get("detail") or {}).get("warnings"))     # with warnings, the snapshot is kept
    _enter(conn, change, t, next_patch_state(state, p, result, bool(t.get("snapshot_moref")) and not keep))


def run_patch(conn, change):
    targets = conn.execute(
        """SELECT target_key, host_id::text AS host_id, vcenter, vm_moref, label, state,
                  step_started_at, current_command, snapshot_moref, detail
             FROM change_targets WHERE change_id=%s ORDER BY label""", (change["id"],)).fetchall()
    active = [t for t in targets if t["state"] not in TERMINAL and t["state"] != "queued"]
    for t in active:
        try:
            _advance(conn, change, dict(t))
        except Exception as e:  # noqa: BLE001 - one server must never stall the rest
            log.error("target %s: %s", t["label"], traceback.format_exc())
            _fail(conn, change, dict(t), f"internal error: {e}")
        conn.commit()

    queued = [t for t in targets if t["state"] == "queued"]
    if not queued:
        return
    window_closed = change["run_before"] and datetime.now(timezone.utc) > change["run_before"]
    if change["cancel_requested"] or window_closed:
        why = "cancelled" if change["cancel_requested"] else "the window closed before it started"
        for t in queued:
            _set(conn, change["id"], t["target_key"], state="cancelled" if change["cancel_requested"] else "skipped")
            ch.event(conn, change["id"], t["target_key"], "worker", "skipped", None, f"{t['label']}: {why}")
        conn.commit()
        return
    running_now = conn.execute(
        """SELECT count(*) AS n FROM change_targets WHERE change_id=%s
            AND state NOT IN ('queued','done','done_with_warnings','failed','skipped','cancelled')""",
        (change["id"],)).fetchone()["n"]
    for t in queued[:max(0, change["max_parallel"] - running_now)]:
        try:
            _enter(conn, change, dict(t), "precheck")
        except Exception as e:  # noqa: BLE001
            _fail(conn, change, dict(t), f"could not start: {e}")
        conn.commit()


# ---------------------------------------------------------------------------
# VMware changes
# ---------------------------------------------------------------------------

def run_vm(conn, change):
    from . import vmware
    t = conn.execute(
        """SELECT target_key, vcenter, vm_moref, label, state FROM change_targets
            WHERE change_id=%s AND state='queued' ORDER BY label LIMIT 1""",
        (change["id"],)).fetchone()
    if not t:
        return
    if change["cancel_requested"]:
        conn.execute("UPDATE change_targets SET state='cancelled' WHERE change_id=%s AND state='queued'",
                     (change["id"],))
        conn.commit()
        return
    _set(conn, change["id"], t["target_key"], state="vm_action", step_started_at=datetime.now(timezone.utc))
    conn.commit()
    try:
        result = vmware.vm_action(t["vcenter"], t["vm_moref"], change["kind"], change["params"])
        _set(conn, change["id"], t["target_key"], state="done", detail=json.dumps(result))
        msg = {"vm_snapshot_revert": f"reverted to '{result.get('reverted_to')}'. To undo, revert to "
                                     f"'{result.get('safety_snapshot_name')}'."}.get(change["kind"], "done")
        ch.event(conn, change["id"], t["target_key"], "worker", change["kind"], True,
                 f"{t['label']}: {msg}", result)
    except Exception as e:  # noqa: BLE001
        _fail(conn, change, dict(t), str(e))
    conn.commit()
    # Reflect the change in the inventory without waiting for the hourly sync
    try:
        vmware.sync(t["vcenter"])
    except Exception as e:  # noqa: BLE001
        log.warning("resync after VM action failed: %s", e)


def changes_loop():
    conn = _db()
    while not _stop.is_set():
        try:
            start_due(conn)
            running = conn.execute(
                """SELECT id, number, kind::text AS kind, params, run_before, max_parallel,
                          cancel_requested FROM changes WHERE state='running' ORDER BY started_at"""
            ).fetchall()
            try:
                vault_housekeeping(conn)
            except Exception:  # noqa: BLE001 - housekeeping must never stop the change loop
                log.exception("vault housekeeping failed")
            for c in running:
                c = dict(c)
                (run_patch if c["kind"] in ("patch", "software") else run_vm)(conn, c)
                finish_if_done(conn, c)
                conn.commit()
            beat(conn, "changes", running=len(running))
        except Exception:  # noqa: BLE001 - keep the loop alive; log and retry
            log.error("changes loop: %s", traceback.format_exc())
            try:
                conn.rollback()
            except Exception:  # noqa: BLE001
                conn = _db()
        _stop.wait(TICK)


# ---------------------------------------------------------------------------
# Assessment enrichment
# ---------------------------------------------------------------------------

def enrich_item(conn, assessment_id, item):
    from . import cve_intel, exposure, llm
    cid = item["cve_id"]
    d = conn.execute("SELECT * FROM cve_details WHERE cve_id=%s", (cid,)).fetchone()
    # Fetch from NVD when we have nothing, or only an older record without products
    if not d or not d.get("nvd_fetched_at") or (not d.get("cpes") and not d.get("fetch_error")):
        try:
            cve_intel.fetch_one(conn, cid)
            conn.commit()
        except Exception as e:  # noqa: BLE001
            log.warning("NVD lookup for %s failed: %s", cid, e)
            conn.rollback()
        time.sleep(cve_intel.NVD_PAUSE)
        d = conn.execute("SELECT * FROM cve_details WHERE cve_id=%s", (cid,)).fetchone()
    d = d or {}

    # In order: the CVE database (the NVD record above, and what Microsoft and
    # Red Hat published in the feeds), the software inventory (Linux packages,
    # Windows programs with version ranges), the machines' operating systems
    # (agents, WSUS computers and vCenter guests, so a Windows 10 Pro desktop
    # or a Server 2019 box counts even without an agent), hardware and
    # VMware, and the servers' package verdicts (item["status"]).
    from . import cve_impact
    cpes = d.get("cpes") or []
    if isinstance(cpes, str):
        cpes = json.loads(cpes)
    ms_products, rh_products = [], []
    try:
        with conn.transaction():
            for f in conn.execute("SELECT source, products FROM cve_feed_items WHERE cve_id = %s", (cid,)).fetchall():
                (ms_products if f["source"] == "msrc" else rh_products if f["source"] == "redhat" else []).extend(f["products"] or [])
    except Exception:  # noqa: BLE001 - feeds (schema 022) not installed
        pass
    products = exposure.products_from_cpes(cpes)
    _, _, found = cve_impact.analyse_one(conn, {"cve_id": cid, "cpes": cpes, "ms_products": ms_products,
                                                "rh_products": rh_products})
    # The package verdicts are reported separately (affected_hosts)
    matches = [m for m in found if m.get("certainty") not in ("confirmed", "pending_reboot")]
    word = exposure.overall_exposure(item["status"], matches)
    match_lines = [f"{m['where'] or m['kind']} {m['name'] or ''} {m.get('version') or ''} "
                   f"({m['certainty'].replace('_', ' ')})".strip()
                   for m in matches if m["certainty"] != "not_tracked"][:12]

    summary = model = None
    try:
        summary, model = llm.summarise_cve(conn, {
            "cve_id": cid, "cvss_score": d.get("cvss_score"), "cvss_severity": d.get("cvss_severity"),
            "cvss_vector": d.get("cvss_vector"), "attack_class": d.get("attack_class"),
            "attack_class_basis": d.get("attack_class_basis"), "kev": d.get("kev"),
            "epss": d.get("epss"), "description": d.get("description"), "exposure": word,
            "product_list": [f"{p['vendor']} {p['product']} ({p['kind']})" for p in products],
            "match_lines": match_lines})
    except Exception as e:  # noqa: BLE001 - the facts stand without the brief
        log.info("no AI brief for %s: %s", cid, e)

    conn.execute(
        """UPDATE cve_assessment_items SET
             description=%s, cvss_score=%s, cvss_vector=%s, cvss_severity=%s, kev=%s, epss=%s,
             attack_class=%s, published=%s, products=%s, product_classes=%s,
             inventory_matches=%s, exposure=%s, ai_summary=%s, ai_model=%s, enriched_at=now()
           WHERE assessment_id=%s AND cve_id=%s""",
        (d.get("description"), d.get("cvss_score"), d.get("cvss_vector"), d.get("cvss_severity"),
         bool(d.get("kev")), d.get("epss"), d.get("attack_class"), d.get("published"),
         json.dumps(products), sorted({p["kind"] for p in products}),
         json.dumps(matches[:60], default=str), word, summary, model,
         assessment_id, cid))


def enrich_loop():
    from . import cve_intel
    conn = _db()
    while not _stop.is_set():
        try:
            a = conn.execute("""SELECT id, progress FROM cve_assessments WHERE state='enriching'
                                 ORDER BY created_at LIMIT 1""").fetchone()
            if not a:
                beat(conn, "enrichment", idle=True)
                _stop.wait(15)
                continue
            if a["progress"] == 0:
                ids = [r["cve_id"] for r in conn.execute(
                    "SELECT cve_id FROM cve_assessment_items WHERE assessment_id=%s",
                    (a["id"],)).fetchall()]
                for cid in ids:
                    conn.execute("INSERT INTO cve_details (cve_id) VALUES (%s) ON CONFLICT DO NOTHING", (cid,))
                cve_intel.fetch_kev_epss_for(conn, ids)
                conn.commit()
            items = conn.execute(
                """SELECT cve_id, status FROM cve_assessment_items
                    WHERE assessment_id=%s AND enriched_at IS NULL ORDER BY cve_id LIMIT 3""",
                (a["id"],)).fetchall()
            if not items:
                conn.execute("UPDATE cve_assessments SET state='done' WHERE id=%s", (a["id"],))
                conn.commit()
                continue
            for it in items:
                try:
                    enrich_item(conn, a["id"], it)
                except Exception as e:  # noqa: BLE001 - mark it done with what we have
                    log.error("enrich %s: %s", it["cve_id"], traceback.format_exc())
                    conn.rollback()
                    conn.execute("""UPDATE cve_assessment_items SET enriched_at=now(),
                                           exposure=coalesce(exposure,'not_found')
                                     WHERE assessment_id=%s AND cve_id=%s""", (a["id"], it["cve_id"]))
                conn.execute("UPDATE cve_assessments SET progress=progress+1 WHERE id=%s", (a["id"],))
                conn.commit()
            beat(conn, "enrichment", assessment=str(a["id"]))
        except Exception:  # noqa: BLE001
            log.error("enrichment loop: %s", traceback.format_exc())
            try:
                conn.rollback()
            except Exception:  # noqa: BLE001
                conn = _db()
            _stop.wait(15)


# ---------------------------------------------------------------------------
# VMware live watcher: one thread per vCenter, reconnecting on failure
# ---------------------------------------------------------------------------

RESYNC_MIN_SECONDS = 600       # a full sync at most every 10 min per vCenter
CHANGE_KEEP_DAYS = 7


def _watch_vc(vc):
    from . import vmware
    last_resync = {"t": 0.0}

    def resync(name):
        # A VM appeared or vanished: pick up everything about it, rate-limited
        if time.time() - last_resync["t"] < RESYNC_MIN_SECONDS:
            return
        last_resync["t"] = time.time()
        try:
            vmware.sync(only=name)
        except Exception as e:  # noqa: BLE001
            log.warning("resync of %s failed: %s", name, e)

    backoff = 10
    while not _stop.is_set():
        try:
            vmware.watch(vc, _stop, _db, on_structural=resync)
            backoff = 10
        except Exception as e:  # noqa: BLE001 - keep watching whatever happens
            log.warning("watcher %s: %s; retrying in %ss", vc["name"], e, backoff)
            try:
                with _db() as conn:
                    conn.execute(
                        """INSERT INTO vmware_live (vcenter, connected, error, updated_at)
                           VALUES (%s, FALSE, %s, now())
                           ON CONFLICT (vcenter) DO UPDATE SET connected=FALSE,
                                  error=EXCLUDED.error, updated_at=now()""",
                        (vc["name"], str(e)[:500]))
            except Exception:  # noqa: BLE001
                pass
            _stop.wait(backoff)
            backoff = min(backoff * 2, 300)


def vmware_loop():
    """Start and supervise watchers. Never raises: the worker exits if a
    top-level thread dies, and a vCenter problem must not stop patching."""
    watchers = {}
    last_prune = 0.0
    while not _stop.is_set():
        try:
            try:
                from . import vmware
                import pyVmomi  # noqa: F401 - installed only once a vCenter is added
                vcs = vmware.load_vcenters()
            except ImportError:
                vcs = []
            for vc in vcs:
                th = watchers.get(vc["name"])
                if th is None or not th.is_alive():
                    th = threading.Thread(target=_watch_vc, args=(vc,), name="watch-" + vc["name"],
                                          daemon=True)
                    th.start()
                    watchers[vc["name"]] = th
            with _db() as conn:
                if time.time() - last_prune > 3600:
                    conn.execute("DELETE FROM vmware_changes WHERE at < now() - make_interval(days => %s)",
                                 (CHANGE_KEEP_DAYS,))
                    conn.execute("DELETE FROM vmware_events WHERE created_at < now() - interval '90 days'")
                    last_prune = time.time()
                beat(conn, "vmware_live", watchers=sorted(n for n, t in watchers.items() if t.is_alive()))
        except Exception as e:  # noqa: BLE001
            log.warning("vmware loop: %s", e)
        _stop.wait(30)


# ---------------------------------------------------------------------------
# Hardening schedule: a CIS Level 1 scan per server every N days
# ---------------------------------------------------------------------------

HARDENING_SCAN_DAYS = int(os.environ.get("HARDENING_SCAN_DAYS", "7") or 0)


def hardening_loop():
    """Queue due scans hourly, at most 50 at a time, so a fleet is spread
    across the day. HARDENING_SCAN_DAYS=0 turns the schedule off."""
    from . import hardening as hd
    while not _stop.is_set():
        try:
            with _db() as conn:
                queued = []
                if HARDENING_SCAN_DAYS > 0:
                    with conn.transaction():
                        queued = [r for r in hd.queue_due(conn, "l1", HARDENING_SCAN_DAYS) if r[1]]
                    if queued:
                        log.info("hardening: queued %d scheduled scans", len(queued))
                beat(conn, "hardening", every_days=HARDENING_SCAN_DAYS, queued=len(queued))
        except Exception as e:  # noqa: BLE001 - the schedule must never stop the worker
            log.warning("hardening schedule: %s", e)
        _stop.wait(3600)


# ---------------------------------------------------------------------------
# Mail alerts: detect every minute, digests on schedule, send the queue
# ---------------------------------------------------------------------------

def notify_loop():
    from . import notify as nt
    while not _stop.is_set():
        try:
            with _db() as conn:
                cfg = nt.config(conn)
                detail = {"enabled": cfg["enabled"]}
                if cfg["enabled"]:
                    detail.update(nt.cycle(conn, cfg))
                    detail["digests"] = nt.maybe_digests(conn, cfg)
                    sent, failed = nt.send_queued(conn, cfg)
                    detail.update(sent=sent, failed=failed)
                beat(conn, "mail", **detail)
        except Exception as e:  # noqa: BLE001 - mail must never stop the worker
            log.warning("mail alerts: %s", e)
        _stop.wait(60)


def feeds_loop():
    """CVE news from NIST, Microsoft and Red Hat, at the interval set in the
    console (Admin > CVE feeds), or at once when an admin asks."""
    from . import cve_feeds, cve_intel
    key = bool(cve_intel.NVD_KEY)
    while not _stop.is_set():
        try:
            with _db() as conn:
                if cve_feeds.due(conn):
                    beat(conn, "feeds", running=True, nvd_key=key)
                    done = cve_feeds.sync_all(conn, stop=_stop.is_set)
                    beat(conn, "feeds", last=done, nvd_key=key)
                else:
                    beat(conn, "feeds", idle=True, nvd_key=key)
        except Exception as e:  # noqa: BLE001 - feeds must never stop the worker
            log.warning("CVE feeds: %s", e)
        _stop.wait(60)


def impact_loop():
    """Match new serious CVEs against the inventory, then have AI-01 brief the
    impacted ones. Repeats when the inventory changes and at least daily."""
    from . import cve_impact
    while not _stop.is_set():
        try:
            with _db() as conn:
                n = cve_impact.analyse_pass(conn)
                beat(conn, "impact", analysed=n, briefing=True)
                ai = cve_impact.ai_pass(conn)
                beat(conn, "impact", analysed=n, ai_briefs=ai)
        except Exception as e:  # noqa: BLE001 - must never stop the worker
            log.warning("CVE impact: %s", e)
        _stop.wait(120)


def insights_loop():
    """AI-01's analysis of the servers, every 15 minutes."""
    from . import insights
    while not _stop.is_set():
        try:
            with _db() as conn:
                if insights.due(conn):
                    src = insights.run(conn)
                    beat(conn, "insights", last=src)
                else:
                    beat(conn, "insights", idle=True)
        except Exception as e:  # noqa: BLE001 - must never stop the worker
            log.warning("insights: %s", e)
        _stop.wait(60)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    lock_conn = _db()
    lock_conn.autocommit = True
    while not lock_conn.execute("SELECT pg_try_advisory_lock(%s) AS ok", (LOCK_ID,)).fetchone()["ok"]:
        log.info("another worker holds the lock; waiting")
        time.sleep(30)
    log.info("worker running")

    def stop(*_):
        _stop.set()
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    threads = [threading.Thread(target=changes_loop, name="changes", daemon=True),
               threading.Thread(target=enrich_loop, name="enrichment", daemon=True),
               threading.Thread(target=vmware_loop, name="vmware_live", daemon=True),
               threading.Thread(target=hardening_loop, name="hardening", daemon=True),
               threading.Thread(target=notify_loop, name="mail", daemon=True),
               threading.Thread(target=feeds_loop, name="feeds", daemon=True),
               threading.Thread(target=impact_loop, name="impact", daemon=True),
               threading.Thread(target=insights_loop, name="insights", daemon=True)]
    for th in threads:
        th.start()
    while not _stop.is_set():
        _stop.wait(5)
        for th in threads:
            if not th.is_alive():
                log.error("thread %s died; exiting so the container restarts", th.name)
                sys.exit(1)
    log.info("worker stopping")


if __name__ == "__main__":
    main()
