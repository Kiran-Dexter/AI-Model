"""Impacted CVEs: which new CVEs from the feeds touch our own machines.

For every critical, high or exploited ("0-day") CVE the feeds collected in
the dashboard's window, the worker looks for the affected products in the
software and hardware inventory:

  confirmed       the CVE engine's package check says a server is affected
  in_range        an installed version lies inside NVD's affected range
                  (Windows programs, ESXi, vCenter)
  release_match   the release matches but the exact build cannot be compared
  present         the product is installed or the OS matches; no version data
                  can decide (Windows editions, Red Hat components)
  not_tracked     a product PATCH-01 does not inventory (network gear)

and gives one verdict per CVE: affected, potentially affected, not found or
not tracked. Products come from NVD's CPE list (NIST items), Microsoft's
product names (MSRC items) and Red Hat's component names.

AI-01 then writes a short brief for the impacted ones, most serious first,
from the same facts the console shows. It never decides the verdict.

The analysis repeats when the inventory changes, and at least daily.
"""

import hashlib
import json
import logging
import re
from datetime import timedelta

log = logging.getLogger("patchapi.cve_impact")

BATCH = 150
AI_PER_PASS = 2
REANALYSE_HOURS = 24
STRONG = ("confirmed", "in_range")
WEAK = ("release_match", "present")

WIN_OS_RE = re.compile(r"windows (server )?(2008|2012|2016|2019|2022|2025|10|11|7|8\.1)( r2)?", re.I)
MS_NOISE = re.compile(r"\b(microsoft|for x64-based systems|for x86-based systems|for 32-bit systems|"
                      r"for arm64-based systems|\(server core installation\)|version \w+|\d{2}h\d|"
                      r"64-bit editions?|32-bit editions?|service pack \d|sp\d)\b", re.I)
STOP = {"the", "and", "for", "of", "server", "edition", "editions", "systems", "version", "based"}


# ---------------------------------------------------------------------------
# Inventory fingerprint: when it changes, everything is analysed again
# ---------------------------------------------------------------------------

def inventory_mark(conn):
    """Changes when machines or software come or go, not on every check-in
    (which would make every pass start again from the top)."""
    r = conn.execute(
        """SELECT (SELECT count(*) FROM hosts WHERE status <> 'decommissioned') AS h,
                  (SELECT count(*) FROM windows_software) AS w,
                  (SELECT count(*) FROM host_packages) AS p,
                  (SELECT count(*) FROM host_applicability WHERE state IN ('affected', 'fixed_pending_reboot')) AS a,
                  (SELECT count(*) || ':' || string_agg(DISTINCT coalesce(esxi_build, ''), ',') FROM esxi_hosts) AS e,
                  (SELECT count(*) FROM wsus_computers) AS u,
                  (SELECT count(*) FROM vm_inventory) AS v""").fetchone()
    return hashlib.sha256(json.dumps(r, default=str, sort_keys=True).encode()).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Matching (each returns match dicts like exposure.find_in_inventory)
# ---------------------------------------------------------------------------

MAX_PRODUCTS = 30


class Inventory:
    """The parts of the inventory every CVE is compared with, read once per pass."""

    def __init__(self, conn):
        self.conn = conn
        self._win_sw = self._win_os = self._esxi = None

    def win_software(self):
        if self._win_sw is None:
            self._win_sw = [dict(r) for r in self.conn.execute(
                """SELECT h.hostname, ws.name, ws.version
                     FROM windows_software ws JOIN hosts h ON h.id = ws.host_id AND h.status <> 'decommissioned'""").fetchall()]
        return self._win_sw

    def win_os(self):
        if self._win_os is None:
            self._win_os = [dict(r) for r in self.conn.execute(
                """SELECT hostname AS name, coalesce(os_edition, 'Windows') AS os, 'Windows server (agent)' AS where_
                     FROM hosts WHERE os_id = 'windows' AND status <> 'decommissioned'
                   UNION ALL SELECT name, os, 'WSUS computer' FROM wsus_computers
                   UNION ALL SELECT name, guest_os, 'VM guest OS' FROM vm_inventory
                    WHERE guest_os ILIKE '%windows%'""").fetchall()]
        return self._win_os

    def esxi(self):
        if self._esxi is None:
            self._esxi = [dict(r) for r in self.conn.execute(
                "SELECT name, vcenter, vendor, model FROM esxi_hosts").fetchall()]
        return self._esxi


def _words(text):
    return [w for w in re.findall(r"[a-z0-9][a-z0-9.+#-]*", (text or "").lower()) if w not in STOP]


def _norm_os(text):
    """'Microsoft Windows Server 2019 Datacenter' -> 'windows server 2019'."""
    m = WIN_OS_RE.search(text or "")
    if not m:
        return None
    return ("windows " + ("server " if m.group(1) else "") + m.group(2) + (" r2" if m.group(3) else "")).lower()


def match_windows_os(inv, os_label, product):
    """Windows servers (agents), WSUS computers and VM guests running this OS."""
    out, seen = [], set()
    for r in inv.win_os():
        if _norm_os(r["os"]) != os_label:
            continue
        key = (r["name"] or "").lower().split(".")[0]
        if key in seen:
            continue
        seen.add(key)
        out.append({"product": product, "kind": "Operating system", "where": r["where_"], "name": r["name"],
                    "version": r["os"], "certainty": "present",
                    "detail": "the Windows version matches; whether this month's update is installed is shown "
                              "by the server's missing updates"})
        if len(out) >= 200:
            break
    return out


def match_windows_software(inv, product, ranges=None):
    """Windows programs whose name contains every significant word of the
    product name ('google chrome' matches 'Google Chrome')."""
    from . import exposure
    if not isinstance(product, str):
        return []
    words = _words(MS_NOISE.sub(" ", re.sub(r"\([^)]*\)", " ", product)))[:4]
    if not words or (len(words) == 1 and len(words[0]) < 4):
        return []
    pats = [re.compile(r"(^|[^a-z0-9])" + re.escape(w) + r"($|[^a-z0-9])") for w in words]
    rows, seen = [], set()
    for r in inv.win_software():
        name = (r["name"] or "").lower()
        if all(p.search(name) for p in pats) and (r["hostname"], r["name"]) not in seen:
            seen.add((r["hostname"], r["name"]))
            rows.append(r)
            if len(rows) >= 200:
                break
    out = []
    for r in rows:
        cert, why = ("present", "installed; no affected version range to compare")
        if ranges:
            cert, why = exposure.match_versioned(r["version"] or "", ranges)
            if cert == "outside":
                continue
        out.append({"product": product, "kind": "Application", "where": "Windows server", "name": r["hostname"],
                    "version": f"{r['name']} {r['version'] or ''}".strip(), "certainty": cert, "detail": why})
    return out


def match_hardware(inv, vendor, product):
    """ESXi hosts whose server model matches a hardware CPE."""
    want = re.sub(r"[^a-z0-9]", "", str(product or "").lower())
    if len(want) < 4:
        return []
    out = []
    for r in inv.esxi():
        model = re.sub(r"[^a-z0-9]", "", (r["model"] or "").lower())
        if model and (want in model or model in want):
            out.append({"product": f"{vendor} {product}".replace("_", " "), "kind": "Hardware or firmware",
                        "where": "Server hardware (ESXi host)", "name": r["name"],
                        "version": f"{r['vendor'] or ''} {r['model'] or ''}".strip(), "certainty": "present",
                        "detail": "the server model matches; firmware versions are not inventoried"})
    return out


def match_linux_packages(conn, names):
    from . import exposure
    pkgs = set()
    for n in names:
        if not isinstance(n, str):
            continue
        n = n.lower().strip()
        if re.fullmatch(r"[a-z0-9][a-z0-9._+-]{1,60}", n):
            pkgs.add(n)
            pkgs.update(exposure.PACKAGE_ALIASES.get(n, []))
    if not pkgs:
        return []
    rows = conn.execute(
        """SELECT DISTINCT ON (h.hostname) h.hostname, hp.name, hp.version, hp.release
             FROM host_packages hp JOIN hosts h ON h.id = hp.host_id AND h.status <> 'decommissioned'
            WHERE hp.name = ANY(%s) ORDER BY h.hostname LIMIT 200""", (sorted(pkgs),)).fetchall()
    return [{"product": r["name"], "kind": "Application", "where": "Linux server", "name": r["hostname"],
             "version": f"{r['name']} {r['version']}-{r['release']}" if r["release"] else f"{r['name']} {r['version']}",
             "certainty": "present",
             "detail": "installed; the vendor advisory decides whether this build is fixed"} for r in rows]


def match_confirmed(conn, cve_id):
    rows = conn.execute(
        """SELECT DISTINCT h.hostname, ha.state::text AS state, ha.package_name, ha.installed_evr, ha.fixed_evr
             FROM advisory_cves ac
             JOIN host_applicability ha ON ha.advisory_id = ac.advisory_id
             JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'
            WHERE ac.cve_id = %s AND ha.state IN ('affected', 'fixed_pending_reboot')
            LIMIT 200""", (cve_id,)).fetchall()
    return [{"product": r["package_name"], "kind": "Application", "where": "Linux server", "name": r["hostname"],
             "version": r["installed_evr"],
             "certainty": "confirmed" if r["state"] == "affected" else "pending_reboot",
             "detail": ("the vendor's fix " + (r["fixed_evr"] or "") + " is not installed") if r["state"] == "affected"
                       else "the fix is installed; a reboot is needed to run it"} for r in rows]


def analyse_one(conn, cve, inv=None):
    """Matches and verdict for one CVE (a row grouped over its feed sources)."""
    from . import exposure
    inv = inv or Inventory(conn)
    matches = match_confirmed(conn, cve["cve_id"])
    cpes = [c for c in (cve.get("cpes") or []) if isinstance(c, dict)]
    products = exposure.products_from_cpes(cpes)[:MAX_PRODUCTS]
    if products:
        for m in exposure.find_in_inventory(conn, products):
            # Linux "OS matches" lines add nothing when the package check exists
            matches.append(m)
        for p in products:
            name = f"{p['vendor']} {p['product']}".replace("_", " ")
            if p["kind"] == "Hardware or firmware":
                matches.extend(match_hardware(inv, p["vendor"], p["product"]))
            elif p["vendor"] == "microsoft" and re.match(r"windows_(10|11|server_20\d\d)", p["product"]):
                # windows_10, windows_10_22h2, windows_server_2019 ...: the version, editions included
                label = _norm_os(re.match(r"windows_(10|11|server_20\d\d)", p["product"]).group(0).replace("_", " "))
                if label:
                    # exposure.find_in_inventory already lists VM guests for the exact names it knows
                    known = p["product"] in exposure.WINDOWS_GUESTS
                    matches.extend(m for m in match_windows_os(inv, label, name) if not (known and m["where"] == "VM guest OS"))
            elif p["kind"] == "Application":
                matches.extend(match_windows_software(inv, p["product"].replace("_", " "), p["ranges"]))
    for prod in [x for x in (cve.get("ms_products") or []) if isinstance(x, str)][:MAX_PRODUCTS]:
        label = _norm_os(prod)
        if label:
            matches.extend(match_windows_os(inv, label, prod))
        else:
            matches.extend(match_windows_software(inv, prod))
    if cve.get("rh_products"):
        matches.extend(match_linux_packages(conn, [x for x in cve["rh_products"] if isinstance(x, str)][:MAX_PRODUCTS]))
    # One line per machine and product, strongest certainty kept
    rank = {"confirmed": 6, "in_range": 5, "pending_reboot": 4, "release_match": 3, "present": 2, "not_tracked": 1}
    best = {}
    for m in matches:
        k = ((m.get("name") or "").lower().split(".")[0], (m.get("product") or "").lower())
        if k not in best or rank.get(m["certainty"], 0) > rank.get(best[k]["certainty"], 0):
            best[k] = m
    matches = sorted(best.values(), key=lambda m: (-rank.get(m["certainty"], 0), m.get("name") or ""))
    certs = {m["certainty"] for m in matches}
    if certs & set(STRONG):
        verdict = "affected"
    elif "pending_reboot" in certs:
        verdict = "pending_reboot"
    elif certs & set(WEAK):
        verdict = "potentially_affected"
    elif certs == {"not_tracked"}:
        verdict = "not_tracked"
    else:
        verdict = "not_found"
    machines = len({(m.get("name") or "").lower().split(".")[0] for m in matches
                    if m.get("name") and m["certainty"] != "not_tracked"})
    return verdict, machines, matches[:120]


# ---------------------------------------------------------------------------
# The worker's pass
# ---------------------------------------------------------------------------

CANDIDATES = """
    SELECT i.cve_id,
           max(i.cvss) AS cvss,
           (array_agg(i.severity ORDER BY i.cvss DESC NULLS LAST))[1] AS severity,
           bool_or(i.exploited) AS exploited,
           min(i.published) AS published,
           (array_agg(i.title ORDER BY (i.source = 'nist') DESC))[1] AS title,
           (array_agg(i.summary ORDER BY (i.source = 'nist') DESC))[1] AS summary,
           array_agg(DISTINCT i.source) AS sources,
           (array_agg(i.cpes) FILTER (WHERE i.cpes IS NOT NULL))[1] AS cpes,
           (SELECT x.products FROM cve_feed_items x WHERE x.cve_id = i.cve_id AND x.source = 'msrc') AS ms_products,
           (SELECT x.products FROM cve_feed_items x WHERE x.cve_id = i.cve_id AND x.source = 'redhat') AS rh_products
      FROM cve_feed_items i
     WHERE i.published >= now() - make_interval(days => %(days)s::int)
       AND (i.exploited OR coalesce(i.cvss, 0) >= 7
            OR lower(coalesce(i.severity, '')) IN ('critical', 'high', 'important'))
     GROUP BY i.cve_id"""


def analyse_pass(conn, limit=BATCH):
    """Analyse CVEs never analysed first, then those analysed before the
    inventory changed or more than a day ago, oldest first, so every CVE is
    reached. Returns how many were analysed."""
    from . import cve_feeds
    s = cve_feeds.settings(conn)
    mark = inventory_mark(conn)
    rows = conn.execute(
        f"""SELECT c.* FROM ({CANDIDATES}) c LEFT JOIN cve_impact x ON x.cve_id = c.cve_id
             WHERE x.cve_id IS NULL OR x.inventory_mark IS DISTINCT FROM %(mark)s
                OR x.analysed_at < now() - make_interval(hours => %(hours)s::int)
             ORDER BY (x.cve_id IS NULL) DESC, x.analysed_at NULLS FIRST,
                      c.exploited DESC, c.cvss DESC NULLS LAST, c.published DESC
             LIMIT %(limit)s::int""",
        {"days": int(s.get("days_back") or 14), "mark": mark, "hours": REANALYSE_HOURS,
         "limit": int(limit)}).fetchall()
    conn.commit()
    inv = Inventory(conn)
    n = 0
    for c in rows:
        c = dict(c)
        try:
            if isinstance(c.get("cpes"), str):
                c["cpes"] = json.loads(c["cpes"])
            if not isinstance(c.get("cpes"), list):
                c["cpes"] = []
            with conn.transaction():          # one bad CVE must not stop the others
                verdict, machines, matches = analyse_one(conn, c, inv)
        except Exception as e:  # noqa: BLE001 - recorded, and retried at the next re-analysis
            log.warning("impact: %s could not be analysed: %s", c.get("cve_id"), e)
            verdict, machines, matches = "not_found", 0, [{"certainty": "not_tracked", "kind": "Analysis",
                                                           "detail": "could not be analysed: " + str(e)[:160]}]
        conn.execute(
            """INSERT INTO cve_impact (cve_id, verdict, machines, matches, title, severity, cvss, exploited, sources,
                                       published, inventory_mark, analysed_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, now())
               ON CONFLICT (cve_id) DO UPDATE SET verdict=EXCLUDED.verdict, machines=EXCLUDED.machines,
                 matches=EXCLUDED.matches, title=EXCLUDED.title, severity=EXCLUDED.severity, cvss=EXCLUDED.cvss,
                 exploited=EXCLUDED.exploited, sources=EXCLUDED.sources, published=EXCLUDED.published,
                 inventory_mark=EXCLUDED.inventory_mark, analysed_at=now()""",
            (c["cve_id"], verdict, machines, json.dumps(matches, default=str), (c.get("title") or "")[:300],
             c.get("severity"), c.get("cvss"), bool(c.get("exploited")), c.get("sources") or [],
             c.get("published"), mark))
        n += 1
        if n % 25 == 0:
            conn.commit()
    conn.execute("DELETE FROM cve_impact WHERE coalesce(published, analysed_at) < now() - interval '120 days'")
    conn.commit()
    return n


def _ai_facts(conn, row):
    d = conn.execute("SELECT * FROM cve_details WHERE cve_id = %s", (row["cve_id"],)).fetchone() or {}
    f = conn.execute(
        """SELECT summary, title FROM cve_feed_items WHERE cve_id = %s
            ORDER BY (source = 'nist') DESC LIMIT 1""", (row["cve_id"],)).fetchone() or {}
    matches = row["matches"] if isinstance(row["matches"], list) else json.loads(row["matches"] or "[]")
    products = sorted({m.get("product") or "" for m in matches if m.get("product")})[:8]
    lines = [f"{m.get('where') or m.get('kind')} {m.get('name') or ''} {m.get('version') or ''} "
             f"({str(m.get('certainty')).replace('_', ' ')})".strip()
             for m in matches if m.get("certainty") != "not_tracked"][:12]
    word = {"affected": "affected", "pending_reboot": "pending_reboot",
            "potentially_affected": "potentially_affected"}.get(row["verdict"], "not_found")
    return {"cve_id": row["cve_id"], "cvss_score": row.get("cvss") or d.get("cvss_score"),
            "cvss_severity": row.get("severity") or d.get("cvss_severity"), "cvss_vector": d.get("cvss_vector"),
            "attack_class": d.get("attack_class"), "attack_class_basis": d.get("attack_class_basis"),
            "kev": bool(row.get("exploited") or d.get("kev")), "epss": d.get("epss"),
            "description": f.get("summary") or f.get("title") or row.get("title") or "",
            "exposure": word, "product_list": products, "match_lines": lines}


def ai_pass(conn, limit=AI_PER_PASS):
    """AI-01 briefs for impacted CVEs, most serious first. A brief is redone
    only when the facts it was written from change."""
    from . import llm
    if not llm.configured():
        return 0
    rows = conn.execute(
        """SELECT * FROM cve_impact WHERE verdict IN ('affected', 'pending_reboot', 'potentially_affected')
            ORDER BY (verdict = 'affected') DESC, exploited DESC, cvss DESC NULLS LAST, published DESC
            LIMIT 60""").fetchall()
    done = 0
    for r in rows:
        if done >= limit:
            break
        f = _ai_facts(conn, r)
        conn.commit()                         # no transaction held open while AI-01 writes
        key = hashlib.sha256(json.dumps([f["exposure"], f["match_lines"][:6], f["cvss_score"], f["kev"]],
                                        default=str).encode()).hexdigest()[:24]
        if r.get("ai_key") == key and r.get("ai_summary"):
            continue
        try:
            text, model = llm.summarise_cve(conn, f, wait=30)
        except Exception as e:  # noqa: BLE001 - the verdict stands without the brief
            log.info("impact: no AI brief for %s: %s", r["cve_id"], e)
            conn.rollback()
            break
        conn.execute("UPDATE cve_impact SET ai_summary=%s, ai_model=%s, ai_key=%s, ai_at=now() WHERE cve_id=%s",
                     (text, model, key, r["cve_id"]))
        conn.commit()
        done += 1
    return done


# ---------------------------------------------------------------------------
# Reading, for the console
# ---------------------------------------------------------------------------

def counts(conn, days):
    return conn.execute(
        """SELECT count(*) FILTER (WHERE verdict = 'affected') AS affected,
                  count(*) FILTER (WHERE verdict = 'pending_reboot') AS pending_reboot,
                  count(*) FILTER (WHERE verdict = 'potentially_affected') AS potentially_affected,
                  count(*) FILTER (WHERE verdict IN ('not_found', 'not_affected', 'patched')) AS not_found,
                  count(*) FILTER (WHERE verdict = 'not_tracked') AS not_tracked,
                  count(*) FILTER (WHERE verdict IN ('affected', 'potentially_affected') AND exploited) AS exploited_impacting,
                  max(analysed_at) AS analysed_at,
                  count(*) FILTER (WHERE ai_summary IS NOT NULL) AS ai_briefs
             FROM cve_impact WHERE published >= now() - make_interval(days => %s::int)""", (int(days),)).fetchone()


def listing(conn, days, verdict=None, limit=300):
    return conn.execute(
        """SELECT cve_id, verdict, machines, matches, title, severity, cvss, exploited, sources, published,
                  analysed_at, ai_summary, ai_model, ai_at
             FROM cve_impact
            WHERE published >= now() - make_interval(days => %s::int)
              AND (%s::text IS NULL OR verdict = %s::text)
            ORDER BY CASE verdict WHEN 'affected' THEN 0 WHEN 'pending_reboot' THEN 1
                                  WHEN 'potentially_affected' THEN 2 ELSE 3 END,
                     exploited DESC, cvss DESC NULLS LAST, published DESC
            LIMIT %s""", (int(days), verdict, verdict, int(limit))).fetchall()
