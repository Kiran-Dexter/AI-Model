/* Access review (r119): file and folder permissions, application and owning-team tags, reports.
 *
 *   #/access-review                      uploads, and the reports made
 *   #/access-review?ds=<id>&step=...     one upload, step by step: sheets and columns, tags, report
 *   #/access-review?report=<id>          a report: donuts, sorted tables, AI-01's summary, CSV
 *
 * Every figure is counted by PostgreSQL from the rows; AI-01 proposes (columns, tags, which
 * reports fit, a summary) and an admin confirms. Plain DOM, no innerHTML. */
"use strict";

const AR_STATE = { uploading: "Uploading", uploaded: "Waiting to be read", reading: "Reading the file", mapping: "Columns to confirm",
  normalising: "Making the rows plain", ready: "Ready", failed: "Failed" };
const AR_STEPS = [["upload", "Upload"], ["columns", "Sheets & columns"], ["tags", "Owners & departments"], ["report", "Report"]];
const AR_ROLE_HELP = {
  path: "the folder or file the entry is on", identity: "who has the access (user, group, SID)", rights: "what they may do (words, letters or an access mask)",
  access_type: "Allow or Deny (Allow when missing)", inherited: "inherited from the parent or set on the folder itself",
  owner: "the folder's owner", server: "the file server, when the path is a drive path (D:\\\u2026)", share: "the share name, when separate",
  account_type: "user, group or computer: makes \u201cpeople given rights directly\u201d exact",
  application: "the application, when the tool already has it", team: "the owning team, when the tool already has it" };
// Fixed colours: an entity keeps its colour wherever it appears (palette validated for light and dark, legend always shown)
const AR_CAT_CLS = { broad_write: "c-ar8", explicit_user: "c-ar1", orphan: "c-ar7", full_nonadmin: "c-ar2", deny: "c-ar4", broad_read: "c-ar5", can_change: "c-ar2",
  disabled: "c-ar6", stale: "c-ar3", has_access: "c-ar1" };
const AR_LEVEL_CLS = { unstated: "c-muted", full: "c-ar8", modify: "c-ar2", write: "c-ar4", read_execute: "c-ar3", read: "c-ar1", list: "c-ar7", special: "c-ar5", none: "c-ar-un" };
const AR_KIND_CLS = { user: "c-ar1", group: "c-ar3", computer: "c-ar7", broad: "c-ar8", admin: "c-ar2", system: "c-muted", orphan: "c-ar5", unknown: "c-ar-un" };
const AR_KIND_TEXT = { user: "Person", group: "Group", computer: "Computer", broad: "Everyone-type group", admin: "Admin group",
  system: "System account", orphan: "Orphaned (SID)", unknown: "Not stated in the file" };
const AR_LEVEL_TEXT = { full: "Full control", modify: "Modify", write: "Write", read_execute: "Read & execute", read: "Read", list: "List folder",
  special: "Special", unstated: "Not stated in the file", none: "None" };
let arTimer = null;
// replaceChildren would write null as the text "null"
const arPut = (el, ...nodes) => el.replaceChildren(...nodes.flat(3).filter(n => n !== null && n !== undefined && n !== false));
let arUpload = null;

const arNum = n => (Number(n) || 0).toLocaleString();
const arPct = (a, b) => b ? Math.round((a / b) * 100) : 0;

function arChip(text, cls) { return h("span", { class: "ar-chip " + (cls || "") }, text); }
function arTile(label, value, cls, note) {
  return h("div", { class: "ar-tile " + (cls || "") }, h("div", { class: "ar-tile-n" }, arNum(value)), h("div", { class: "ar-tile-l" }, label),
    note ? h("div", { class: "ar-tile-x" }, note) : null);
}
function arStop() { clearInterval(arTimer); arTimer = null; }
function arWatch(page, every, fn) {
  arStop();
  arTimer = setInterval(async () => {
    if (!document.body.contains(page)) { arStop(); return; }
    try { await fn(); } catch (e) { if (!(e instanceof StaleRoute)) { /* next time */ } }
  }, every);
}
function arHead(title, sub, ...actions) {
  return h("div", { class: "page-head ar-head" }, h("div", null, h("h1", null, title), sub ? h("p", { class: "muted ar-sub" }, sub) : null),
    actions.length ? h("div", { class: "ar-actions" }, actions) : null);
}

async function renderAccessReview(params) {
  setNav("access-review");
  arStop();
  if (!can("admin")) return render(h("div", { class: "empty" }, h("p", null, "Access review needs the admin role.")));
  const report = params.get("report"), ds = params.get("ds");
  if (report) return arReport(report);
  if (ds) return arDataset(ds, params.get("step"));
  return arHome();
}

/* ---- r127: is Access review working? (one line; the details only when something is wrong) ---- */

function arHealth() {
  const box = h("div", { class: "ar-health", role: "status" });
  const load = async () => {
    let x;
    try { x = await api("/admin/access/health"); } catch (e) { if (e instanceof StaleRoute) return; arPut(box, h("span", { class: "small muted" }, "Health not known: " + e.message)); return; }
    const w = x.worker || {};
    const probs = [];
    if (w.state === "never") probs.push(["bad", "The access-review worker has never reported. Restart it: sudo docker restart patch01-worker (or run phase3b-api.sh again)."]);
    if (w.state === "failing") probs.push(["bad", "The access-review worker fails on every pass (" + timeAgo(new Date(Date.now() - w.error_s * 1000).toISOString())
      + "): " + (w.error || "no message") + ". Nothing is read, tagged or counted until this is fixed."]);
    if (w.state === "stalled") probs.push(["bad", "The access-review worker last finished a pass " + Math.round(w.seen_s / 60) + " minutes ago. Restart it: sudo docker restart patch01-worker."]);
    if (x.schema !== null && x.schema < x.schema_wanted) probs.push(["bad", "The database schema is at " + x.schema + "; this version needs " + x.schema_wanted + ": run phase3a-schema.sh."]);
    if (w.state === "schema") probs.push(["bad", "The access-review tables are missing: run phase3a-schema.sh."]);
    if (x.ai && !x.ai.configured) probs.push(["info", "AI-01 is not set up: the rules still suggest owners and departments; AI-01's checks wait."]);
    else if (x.ai && !x.ai.reachable) probs.push(["warn", "AI-01 does not answer" + (x.ai.error ? " (" + x.ai.error + ")" : "") + ": the rules still suggest; AI-01's checks wait."]);
    if ((x.scanners_old || []).length) probs.push(["warn", "Scanner older than " + x.scanner_version + " on " + x.scanners_old.join(", ")
      + ": copy agent\\windows\\access-scan.ps1 from this package to C:\\Program Files\\PatchAgent\\ there."]);
    const good = "\u2714 Worker reading (" + (w.seen_s !== null && w.seen_s !== undefined ? w.seen_s + " s ago" : "\u2014") + ") \u00b7 schema " + x.schema
      + (x.ai && x.ai.reachable ? " \u00b7 AI-01 answers (slots of " + arNum(x.ai.slot_tokens) + " tokens)" : "");
    arPut(box, probs.some(p => p[0] === "bad") ? null : h("span", { class: "small ar-health-ok" }, good),
      probs.length ? h("ul", { class: "ar-health-list" }, probs.map(([k, t]) => h("li", { class: "ar-health-" + k }, t))) : null);
  };
  load();
  const id = setInterval(() => { if (!document.body.contains(box)) { clearInterval(id); return; } load(); }, 30000);
  return box;
}

/* ---- the start: upload, and what was uploaded -------------------------------------------- */

async function arHome() {
  let d;
  try { d = await api("/admin/access"); }
  catch (e) {
    if (e instanceof StaleRoute) throw e;
    return render(arHead("Access review"), h("div", { class: "empty" }, h("p", null, e.message)));
  }
  const page = h("div", { class: "ar" });
  const draw = d => {
    arPut(page, 
      arHead("Access review", "File and folder permissions: who can open and change what, which application and team each folder belongs to, and what to fix."),
      page._health || (page._health = arHealth()),
      arHowItWorks(),
      arScanners(),
      arUploadBox(d),
      h("section", { class: "ar-card" }, h("h2", null, "Uploads"),
        d.items.length ? table([
          { label: "Name", cell: r => h("a", { href: "#/access-review?ds=" + encodeURIComponent(r.id) }, r.name) },
          { label: "File", cell: r => h("span", { class: "mono small" }, r.file_name) },
          { label: "Rows", num: true, cell: r => r.row_count === null ? "" : arNum(r.row_count) },
          { label: "State", cell: r => arChip(AR_STATE[r.state] || r.state, "ar-s-" + r.state) },
          { label: "Reports", num: true, cell: r => String(r.reports || 0) },
          { label: "Uploaded", cell: r => h("span", { title: r.uploaded_at }, timeAgo(r.uploaded_at) + " by " + r.uploaded_by) },
        ], d.items, { onRow: r => { location.hash = "#/access-review?ds=" + encodeURIComponent(r.id); } })
          : h("p", { class: "muted" }, "Nothing uploaded yet.")));
  };
  render(page);
  draw(d);
  arWatch(page, 5000, async () => {
    if (!d.items.some(r => ["uploaded", "reading", "normalising"].includes(r.state)) || arUpload) return;
    d = await api("/admin/access"); draw(d);
  });
}

function arHowItWorks() {
  const steps = [["1", "Upload", "the CSV or Excel workbook your tool exports (NTFS Permissions Reporter, Netwrix, Varonis, ManageEngine, PowerShell Get-Acl\u2026)"],
    ["2", "Sheets & columns", "AI-01 and the rules say what each sheet holds and which column is which; you confirm. Junk characters are cleaned"],
    ["3", "Owners & departments", "Each folder's owner (a person such as jsmith, or a group) and department are suggested from its permissions at once; AI-01 checks the unsure ones; you accept, edit or reject. Kept for the next scan"],
    ["4", "Report", "choose what to report, step by step; charts and tables counted from every row; CSV of every finding"]];
  return h("ol", { class: "ar-how" }, steps.map(s => h("li", null, h("span", { class: "ar-how-n" }, s[0]),
    h("div", null, h("strong", null, s[1]), h("span", { class: "muted" }, " \u2014 " + s[2])))));
}

function arUploadBox(d) {
  const file = h("input", { type: "file", accept: ".csv,.txt,.tsv,.xlsx,.xlsm,.xls,text/csv", "aria-label": "Permissions report (CSV or Excel)" });
  const name = h("input", { type: "text", maxlength: 120, placeholder: "Name (optional), e.g. FS01 November", "aria-label": "Name of the upload" });
  const bar = h("progress", { max: 100, value: 0, hidden: true, class: "ar-bar" });
  const msg = h("p", { class: "small", role: "status", "aria-live": "polite" });
  const cancel = h("button", { type: "button", class: "btn btn-quiet", hidden: true, on: { click: () => { if (arUpload) arUpload.cancel = true; } } }, "Cancel");
  const go = h("button", { type: "button", class: "btn", on: { click: async () => {
    const f = file.files && file.files[0];
    if (!f) { msg.textContent = "Choose the CSV file first."; return; }
    if (f.size > d.max_mb * 1048576) { msg.textContent = "The file is larger than " + d.max_mb + " MB: export it in parts (for example per server)."; return; }
    const me = { cancel: false };
    arUpload = me;
    go.disabled = true; file.disabled = true; cancel.hidden = false; bar.hidden = false; msg.textContent = "";
    try {
      const id = await arSendFile(f, name.value.trim(), me, (done, total) => {
        bar.value = arPct(done, total);
        msg.textContent = "Sent " + (done / 1048576).toFixed(1) + " of " + (total / 1048576).toFixed(1) + " MB (" + arPct(done, total) + "%)";
      });
      location.hash = "#/access-review?ds=" + encodeURIComponent(id);
    } catch (e) {
      msg.textContent = "Upload failed: " + (e.message || e);
    } finally {
      if (arUpload === me) arUpload = null;
      go.disabled = false; file.disabled = false; cancel.hidden = true;
    }
  } } }, "Upload");
  return h("section", { class: "ar-card ar-up" }, h("h2", null, "Upload a permissions report"),
    h("div", { class: "ar-up-row" }, file, name, go, cancel), bar, msg,
    h("p", { class: "muted small" }, "A CSV or an Excel workbook (.xlsx or .xls, every sheet: permissions, drive information, group members). "
      + "CSV: comma, semicolon or tab; UTF-8, UTF-16 or Windows-1252; "
      + "a title above the header is skipped. Up to " + d.max_mb + " MB and " + arNum(d.max_rows) + " rows, sent in 16 MB pieces."));
}

async function arSendFile(file, name, me, progress) {
  const start = await apiPost("/admin/access/uploads", { file_name: file.name, size: file.size, name: name || null });
  const id = start.dataset_id, chunk = start.chunk_bytes || 16777216;
  let off = 0, tries = 0;
  progress(0, file.size);
  while (off < file.size) {
    if (me.cancel) {
      await apiSend("DELETE", "/admin/access/" + encodeURIComponent(id)).catch(() => {});
      throw new Error("cancelled; nothing was kept");
    }
    let res = null, detail = "";
    try {
      res = await fetch("/api/v1/admin/access/uploads/" + encodeURIComponent(id) + "?offset=" + off, {
        method: "PUT", body: file.slice(off, Math.min(file.size, off + chunk)), cache: "no-store",
        headers: { "Content-Type": "application/octet-stream", "X-Requested-With": "patch01-dashboard", ...authHeaders() } });
    } catch (e) { res = null; detail = "the network connection dropped"; }
    if (res && res.ok) { const r = await res.json(); off = r.received; tries = 0; progress(off, file.size); continue; }
    if (res) { try { detail = detailText((await res.json()).detail); } catch (e) { detail = httpReason(res); } }
    if (res && res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
    const m = /expected the bytes from (\d+)/.exec(detail);
    if (res && res.status === 400 && m) { off = Number(m[1]); progress(off, file.size); continue; }   // a piece that did arrive
    const retry = !res || res.status >= 500 || res.status === 408 || res.status === 429;
    if (!retry || ++tries > 4) throw new Error(detail || "the upload stopped");
    await new Promise(r => setTimeout(r, 2000 * tries));
  }
  await apiPost("/admin/access/uploads/" + encodeURIComponent(id) + "/complete", {});
  return id;
}

/* ---- one upload, step by step ------------------------------------------------------------- */

function arStepOf(d, asked) {
  if (d.state !== "ready") return d.headers && ["mapping", "failed", "normalising"].includes(d.state) ? "columns" : "upload";
  if (asked && AR_STEPS.some(s => s[0] === asked)) return asked;
  return "tags";
}

function arStepper(d, cur) {
  const reach = { upload: true, columns: !!d.headers, tags: d.state === "ready", report: d.state === "ready" };
  const idx = AR_STEPS.findIndex(s => s[0] === cur);
  return h("ol", { class: "ar-steps", "aria-label": "Steps" }, AR_STEPS.map(([k, label], i) => {
    const done = i < idx || (k === "upload" && d.headers);
    const inner = [h("span", { class: "ar-step-n" }, done && i !== idx ? "\u2713" : String(i + 1)), h("span", null, label)];
    return h("li", { class: "ar-step" + (i === idx ? " on" : "") + (done ? " done" : "") },
      reach[k] && i !== idx && k !== "upload"
        ? h("a", { href: "#/access-review?ds=" + encodeURIComponent(d.id) + "&step=" + k }, inner)
        : h("span", { "aria-current": i === idx ? "step" : null }, inner));
  }));
}

async function arDataset(id, asked) {
  let d;
  try { d = await api("/admin/access/" + encodeURIComponent(id)); }
  catch (e) {
    if (e instanceof StaleRoute) throw e;
    return render(arHead("Access review"), h("div", { class: "empty" }, h("p", null, e.message),
      h("p", null, h("a", { href: "#/access-review" }, "Back to the uploads"))));
  }
  const page = h("div", { class: "ar" });
  render(page);
  const draw = async () => {
    const step = arStepOf(d, asked);
    const body = step === "upload" ? arWaiting(d) : step === "columns" ? arColumns(d) : step === "tags" ? await arTags(d) : arWizard(d);
    arPut(page, 
      arHead(d.name, d.file_name + " \u00b7 " + (d.row_count !== null ? arNum(d.row_count) + " rows \u00b7 " : "") + "uploaded " + timeAgo(d.uploaded_at) + " by " + d.uploaded_by,
        h("a", { class: "btn btn-quiet", href: "#/access-review" }, "All uploads"),
        h("button", { type: "button", class: "btn btn-quiet ar-del", on: { click: async e => {
          const b = e.currentTarget;
          if (b.dataset.sure !== "1") { b.dataset.sure = "1"; b.textContent = "Click again to remove it and its reports"; return; }
          await apiSend("DELETE", "/admin/access/" + encodeURIComponent(d.id));
          location.hash = "#/access-review";
        } } }, "Remove")),
      page._health || (page._health = arHealth()),
      arStepper(d, step), d.source === "scan" ? arScanBanner(d) : null, body,
      d.reports && d.reports.length ? arReportList(d) : null);
    page._step = step;
  };
  await draw();
  arWatch(page, 4000, async () => {
    const busy = ["uploaded", "reading", "normalising"].includes(d.state) || (d.state === "mapping" && !d.proposal)
      || (d.state === "ready" && !d.advice && page._step === "report")
      || (d.reports || []).some(x => ["queued", "computing"].includes(x.state));
    if (page.querySelector(".ar-tags") && page.querySelector(".ar-tags")._dirty) return;     // never over what an admin is typing
    if (!busy) return;
    const was = d.state;
    d = await api("/admin/access/" + encodeURIComponent(id));
    if (was === "normalising" && d.state === "ready") asked = "tags";        // the rows are ready: on to the tags
    await draw();
  });
}

function arWaiting(d) {
  if (d.state === "failed") {
    return h("section", { class: "ar-card ar-fail", role: "alert" }, h("h2", null, "The file could not be read"), h("p", null, d.error || "Unknown error."),
      h("p", { class: "muted" }, "Check that it is the CSV export (not .xlsx), then upload it again."), h("a", { class: "btn", href: "#/access-review" }, "Upload again"));
  }
  if (d.state === "uploading") {
    return h("section", { class: "ar-card" }, h("h2", null, "The upload was not finished"),
      h("p", null, arNum(d.received) + " of " + arNum(d.size_bytes) + " bytes arrived. Remove it and upload the file again."));
  }
  const p = d.progress || {};
  return h("section", { class: "ar-card ar-wait" },
    hudRing({ pct: null, idle: d.state === "reading" ? "READING" : "QUEUED", title: "READING", sub: p.rows ? arNum(p.rows) + " rows" : "", live: true,
      key: "ar-read-" + d.id, label: "Reading the file" }),
    h("div", null, h("h2", null, d.state === "reading" ? "Reading the file" : "Waiting for the worker"),
      h("p", { class: "muted" }, p.rows ? arNum(p.rows) + " rows read so far." : "The encoding, the separator and the header row are found first."),
      h("p", { class: "muted small" }, "This page follows it; you can leave and come back.")));
}

/* Step 2: which column is which, and how deep folders are tagged */
const AR_SHEET_HELP = {
  permissions: "who has access to which folder, file or drive \u2014 one entry per row",
  drives: "drive letters: where each points (\\\\server\\share), label, owner \u2014 used to turn H:\\\u2026 into the real share",
  members: "a group and its members per row \u2014 used to tell groups from people and to open groups up",
  people: "user names with their department (and title, manager\u2026) \u2014 used to group people by department",
  skip: "a summary, totals or notes: not read" };
const AR_ROLE_HELP2 = {
  drive: "H:, P:\u2026 (or the sheet's name, e.g. \u201cH Drive members\u201d)", target: "\\\\server\\share the letter points to",
  label: "what the drive is for (shown to AI-01 when it suggests applications)", group: "the group", member: "one member of it",
  member_type: "user, group or computer: makes the kinds exact", owner: "who owns the drive (shown to AI-01)",
  person: "the account (jwatson, CORP\\jwatson or jwatson@corp.com: the same person)", department: "the department the person is in",
  display_name: "the person's full name", title: "job title", manager: "the person's manager", location: "office or site",
  email: "e-mail (also matches accounts by the part before the @)" };
const AR_CLEAN_TEXT = { invisible: "invisible characters removed", spaces: "odd spaces made plain", breaks: "line breaks inside a cell made spaces",
  excel_escapes: "Excel escapes (_x000D_) removed", repaired: "garbled text repaired", unreadable: "cells with an unreadable character left as they are" };

// Characters nobody can see, written out: "CORP\\Payroll\u27e8U+200B\u27e9"
function arShowHidden(t) {
  return String(t || "").replace(/[\u0000-\u001f\u007f-\u00a0\u00ad\u061c\u1680\u180e\u2000-\u200f\u2028-\u202f\u205f-\u2064\u2066-\u2069\u3000\ufeff\ufff9-\ufffb]/g,
    ch => "\u27e8U+" + ch.charCodeAt(0).toString(16).toUpperCase().padStart(4, "0") + "\u27e9");
}

function arCleaning(d) {
  const c = d.cleaning || {};
  const counts = c.counts || {};
  const keys = Object.keys(counts).filter(k => counts[k]);
  return h("section", { class: "ar-card ar-clean" }, h("h2", null, keys.length ? "\u2728 Cleaned while reading" : "\u2714 Clean text"),
    h("p", { class: "muted small" }, "Read as " + (d.encoding_text || d.encoding || "?") + (d.delimiter ? ", separator " + (d.delimiter === "tab" ? "tab" : "\u201c" + d.delimiter + "\u201d") : "")
      + ". " + (keys.length ? arNum(c.cells) + " cells were cleaned; nothing else was changed." : "No junk characters found: every cell is as in the file.")),
    keys.length ? h("ul", { class: "ar-clean-l" }, keys.map(k => h("li", null, h("strong", null, arNum(counts[k])), " " + (AR_CLEAN_TEXT[k] || k)))) : null,
    (c.examples || []).length ? h("details", null, h("summary", null, "Examples, before \u2192 after"),
      h("table", { class: "ar-prev-t no-enh" }, h("tbody", null, c.examples.map(e => h("tr", null,
        h("td", { class: "small" }, AR_CLEAN_TEXT[e.kind] || e.kind),
        h("td", { class: "mono small ar-before" }, arShowHidden(e.before)),
        h("td", { class: "mono small" }, e.after)))))) : null);
}

function arColumns(d) {
  if (d.state === "normalising") {
    const p = d.progress || {};
    return h("section", { class: "ar-card ar-wait" },
      hudRing({ pct: p.total ? arPct(p.rows, p.total) : null, idle: "STARTING", title: "ROWS", sub: p.total ? arNum(p.rows) + " / " + arNum(p.total) : "",
        live: true, key: "ar-norm-" + d.id, label: "Making the rows plain" }),
      h("div", null, h("h2", null, "Making the rows plain"),
        h("p", { class: "muted" }, "Drive letters resolved, groups opened up, then each row: server, share, folder, account and its kind, access level, allow or deny, inherited."
          + (p.sheet ? " Sheet \u201c" + p.sheet + "\u201d." : ""))));
  }
  if (d.state === "mapping" && !d.proposal) {
    return h("section", { class: "ar-card ar-wait" },
      hudRing({ pct: null, idle: "AI-01", title: "SHEETS", live: true, key: "ar-map-" + d.id, label: "AI-01 reads the sheets" }),
      h("div", null, h("h2", null, "AI-01 is reading the sheets"), h("p", { class: "muted" }, "What each sheet holds and which column is which, with the rules, from the columns and their values.")));
  }
  const R = d.sheet_roles || {};
  const sheets = (d.sheets || []);
  const state = sheets.map(sh => {
    const p = sh.proposal || { role: "skip", roles: {} };
    const role = sh.role || p.role || "skip";
    const cur = sh.role && sh.mapping ? sh.mapping : Object.fromEntries(Object.entries((p.role === role ? p.roles : {}) || {}).map(([k, v]) => [k, v.col]));
    return { sh, role, mapping: Object.assign({}, cur), p };
  });
  const depth = h("select", { "aria-label": "Tag depth" }, [0, 1, 2, 3, 4].map(n => h("option", { value: String(n) },
    n === 0 ? "The share (or drive) itself" : n + " folder level" + (n > 1 ? "s" : "") + " below the share")));
  depth.value = String(d.tag_depth);
  const prev = h("div", { class: "ar-prev", "aria-live": "polite" });
  const msg = h("p", { class: "small", role: "status" });
  const cfg = () => state.map(x => ({ sheet_no: x.sh.sheet_no, role: x.role, mapping: x.role === "skip" ? {} : x.mapping }));
  let pv = 0;
  const preview = async () => {
    const me = ++pv;
    try {
      const r = await apiPost("/admin/access/" + encodeURIComponent(d.id) + "/preview", { sheets: cfg(), tag_depth: Number(depth.value) });
      if (me !== pv) return;
      arPut(prev, h("table", { class: "ar-prev-t no-enh" }, h("thead", null, h("tr", null, h("th", null, "Depth"), h("th", { class: "num" }, "Folders"), h("th", null, "For example"))),
        h("tbody", null, r.depths.map(x => h("tr", { class: x.depth === Number(depth.value) ? "on" : null },
          h("td", null, String(x.depth)), h("td", { class: "num" }, arNum(x.folders)),
          h("td", { class: "mono small" }, x.examples.slice(0, 3).join("  \u00b7  ")))))),
        h("p", { class: "muted small" }, "From the first " + arNum(r.rows_looked_at) + " rows. Each folder at this depth is tagged with an application and a team; "
          + "everything under it belongs to it."
          + (r.drives_resolved ? " " + arNum(r.drives_resolved) + " drive paths resolved to their share." : "")),
        r.drives_ambiguous && r.drives_ambiguous.length ? h("p", { class: "ar-note" }, "Drive " + r.drives_ambiguous.join(", ")
          + " points to more than one share in the drive sheet: those paths are kept as written (add a server column to the drive sheet to tell them apart).") : null);
      msg.textContent = "";
    } catch (e) { if (me === pv) { arPut(prev); msg.textContent = e.message; } }
  };
  const card = x => {
    const sh = x.sh, box = h("div", { class: "ar-sheet-body" });
    const headers = sh.headers || [];
    const roleSel = h("select", { "aria-label": "What sheet " + sh.name + " holds", disabled: !sh.row_count },
      ["permissions", "drives", "members", "people", "skip"].map(k => h("option", { value: k }, (R[k] || {}).title || k)));
    roleSel.value = x.role;
    const drawBody = () => {
      if (x.role === "skip") { arPut(box, h("p", { class: "muted small" }, AR_SHEET_HELP.skip)); return; }
      const def = R[x.role] || { fields: [], name_roles: [] };
      const props = x.p.role === x.role ? (x.p.roles || {}) : {};
      const rows = def.fields.map(f => {
        const sel = h("select", { "aria-label": f.label + " in " + sh.name }, h("option", { value: "" }, f.required ? "\u2014 choose \u2014" : "(not in the sheet)"),
          headers.map((c, i) => h("option", { value: String(i) }, c)),
          def.name_roles.includes(f.key) ? h("option", { value: String(headers.length) }, "(the sheet's name: " + sh.name + ")") : null);
        sel.value = x.mapping[f.key] !== undefined && x.mapping[f.key] !== null ? String(x.mapping[f.key]) : "";
        sel.addEventListener("change", () => { if (sel.value === "") delete x.mapping[f.key]; else x.mapping[f.key] = Number(sel.value); preview(); });
        const p = props[f.key];
        return h("tr", null,
          h("th", { scope: "row" }, f.label, f.required ? h("span", { class: "ar-req", title: "needed" }, " *") : null,
            h("div", { class: "muted small" }, (x.role === "permissions" ? AR_ROLE_HELP[f.key] : AR_ROLE_HELP2[f.key] || AR_ROLE_HELP[f.key]) || "")),
          h("td", null, sel),
          h("td", { class: "small" }, p ? [arChip(p.by === "AI-01" ? "\u2605 AI-01" : "rules", p.by === "AI-01" ? "ar-ai" : "ar-rule"), " ", p.why] : h("span", { class: "muted" }, "nothing found")));
      });
      const sample = (sh.sample || []).slice(0, 6);
      arPut(box, h("table", { class: "ar-map no-enh" }, h("tbody", null, rows)),
        h("details", { class: "ar-sample-d" }, h("summary", null, "The first rows, as in the sheet"),
          h("div", { class: "table-wrap ar-sample" }, h("table", { class: "no-enh" },
            h("thead", null, h("tr", null, headers.map(c => h("th", null, c)))),
            h("tbody", null, sample.map(r => h("tr", null, headers.map((_, i) => h("td", { class: "small" }, (r[i] || "").slice(0, 80))))))))));
    };
    roleSel.addEventListener("change", () => {
      x.role = roleSel.value;
      x.mapping = x.p.role === x.role ? Object.fromEntries(Object.entries(x.p.roles || {}).map(([k, v]) => [k, v.col])) : {};
      drawBody(); preview();
    });
    drawBody();
    return h("section", { class: "ar-card ar-sheet ar-sheet-" + x.role },
      h("div", { class: "ar-sheet-top" },
        h("div", null, h("h3", null, "\ud83d\udcc4 " + sh.name, sh.hidden ? arChip("hidden sheet", "ar-rule") : null),
          h("div", { class: "muted small" }, sh.row_count ? arNum(sh.row_count) + (sh.row_count === 1 ? " row" : " rows") + " \u00b7 header on line " + sh.header_row + (sh.skipped ? " \u00b7 " + arNum(sh.skipped) + " lines skipped" : "") : "no rows")),
        h("label", { class: "ar-lab" }, "Holds ", roleSel)),
      h("p", { class: "small" }, arChip(x.p.by && x.p.by.includes("AI-01") ? "\u2605 " + x.p.by : "rules", x.p.by && x.p.by.includes("AI-01") ? "ar-ai" : "ar-rule"),
        " " + (SHEET_ROLE_WORD[x.p.role] || "") + (x.p.why ? ": " + x.p.why : "")),
      box);
  };
  depth.addEventListener("change", preview);
  const go = h("button", { type: "button", class: "btn", on: { click: async () => {
    go.disabled = true; msg.textContent = "";
    try {
      await apiSend("PUT", "/admin/access/" + encodeURIComponent(d.id) + "/mapping", { sheets: cfg(), tag_depth: Number(depth.value) });
      location.hash = "#/access-review?ds=" + encodeURIComponent(d.id) + "&step=columns&t=" + Date.now();
    } catch (e) { msg.textContent = e.message; go.disabled = false; }
  } } }, d.state === "ready" ? "Save and read the rows again" : (sheets.length > 1 ? "Confirm the sheets" : "Confirm the columns"));
  setTimeout(preview, 0);
  return h("div", { class: "ar-cols" },
    d.state === "failed" ? h("p", { class: "ar-fail", role: "alert" }, d.error) : null,
    arCleaning(d),
    h("section", { class: "ar-card" }, h("h2", null, sheets.length > 1 ? "What each sheet holds, and which column is which" : "Which column is which"),
      d.proposal && d.proposal.note ? h("p", { class: "ar-note" }, d.proposal.note) : null,
      h("p", { class: "muted small" }, sheets.length > 1 ? arNum(sheets.length) + " sheets. Told from their columns and rows, not from their names: change any choice. "
        + "Drive sheets turn drive letters into the share they point to; members sheets tell groups from people and open groups up; "
        + "people sheets give each person's department." : "")),
    ...state.map(card),
    h("section", { class: "ar-card" }, h("h3", null, "Tag folders at"), h("div", { class: "ar-row" }, depth), prev,
      h("div", { class: "ar-actions" }, go, msg)));
}
const SHEET_ROLE_WORD = { permissions: "permissions", drives: "drive information", members: "group members", people: "people", skip: "not used" };

/* Step 3 (r124): owner, department, owning team and application of each folder */
async function arTags(d, filter, q) {
  filter = filter || "all";
  const box = h("div", { class: "ar-tags" });
  const load = async () => {
    const qs = new URLSearchParams({ state: filter === "all" ? "" : filter, q: q || "", limit: "500" });
    const t = await api("/admin/access/" + encodeURIComponent(d.id) + "/tags?" + qs);
    arDrawTags(box, d, t, filter, q, (f, s) => { filter = f; q = s; load(); });
    return t;
  };
  const t = await load();
  if (["queued", "running"].includes(t.tag_ai)) {
    const id = setInterval(async () => {
      if (!document.body.contains(box)) { clearInterval(id); return; }
      if (box._dirty) return;                                  // never over what an admin is typing
      try { const n = await load(); if (!["queued", "running"].includes(n.tag_ai)) clearInterval(id); } catch (e) { /* next */ }
    }, 6000);
  }
  return box;
}

const AR_OWNER_KIND = { person: "Person", group: "Group / team" };

function arTagChip(it, sure) {
  const sug = it.own_state === "suggested" && (it.s_owner || it.s_department || it.s_application || it.s_team);
  const conf = it.confidence || 0;
  const cls = conf >= sure ? "ar-ai" : conf >= 50 ? "ar-ai-mid" : "ar-ai-low";
  if (it.own_state === "confirmed") return arChip("Confirmed", "ar-ok");
  if (sug && it.suggested_by === "rules") return arChip("Rules " + conf + "%", cls + " ar-rules");
  if (sug && it.suggested_by === "file") return arChip("From the file " + conf + "%", cls);
  if (sug && it.suggested_by === "last_year") return arChip("Last year's mapping " + conf + "%", cls + " ar-rules");
  if (sug) return arChip("\u2605 AI-01 " + conf + "%", cls);
  if (it.tag_key && it.tag_key !== it.key) return arChip((it.tag_state === "confirmed" ? "Confirmed on " : "From ") + it.tag_key, "ar-rule");
  if (it.own_state === "rejected") return arChip("Rejected", "ar-no");
  return arChip("No owner yet", "ar-none");
}

function arDrawTags(box, d, t, filter, q, reload) {
  const c = t.counts || {};
  const sure = t.sure_at || 80;
  const running = ["queued", "running"].includes(t.tag_ai);
  const msg = h("p", { class: "small", role: "status", "aria-live": "polite" }, box._note || "");   // kept over the redraw
  box._note = "";
  const base = "/admin/access/" + encodeURIComponent(d.id) + "/tags";
  const ask = (again, scope) => async () => {
    try { await apiPost(base + "/ask", { again: !!again, scope: scope || "all" }); reload(filter, q); }
    catch (e) { msg.textContent = e.message; }
  };
  const acceptSure = async e => {
    e.currentTarget.disabled = true;
    try { const r = await apiPost(base + "/accept-sure", { min_confidence: sure }); box._note = arNum(r.decided) + " confirmed."; reload(filter, q); }
    catch (err) { msg.textContent = err.message; }
  };
  const aiBox = h("section", { class: "ar-card ar-aibox" },
    hudRing({ pct: c.folders ? arPct(c.with_owner, c.folders) : null, idle: "IDLE", title: "OWNERS", size: "sm",
      sub: arNum(c.with_owner) + " / " + arNum(c.folders), live: running, key: "ar-tag-" + d.id, label: "Folders with an owner" }),
    h("div", null, h("h2", null, "\u2605 Owners & departments, suggested for you"),
      h("p", { class: "muted small" }, "Right after the import every folder gets a suggestion from its own permissions: the NTFS owner when it is a person, "
        + "else the one group (or person) given change rights on it directly; the department of that person, or of most of the people who can change it. "
        + "AI-01 then checks by itself the ones the rules are unsure of (below " + sure + "%), and only names accounts and departments that are in the folder's evidence. "
        + "Nothing counts as confirmed until you confirm it; confirmed owners are kept for the next scan."),
      t.tag_ai_note ? h("p", { class: "ar-note" }, t.tag_ai_note) : null,
      h("div", { class: "ar-actions" },
        c.sure ? h("button", { type: "button", class: "btn", on: { click: acceptSure } }, "\u2714 Accept all " + arNum(c.sure) + " of " + sure + "% or more") : null,
        running ? h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
          await apiPost(base + "/ask", { stop: true }); reload(filter, q); } } }, "Stop AI-01")
          : [c.to_check ? h("button", { type: "button", class: "btn btn-quiet", on: { click: ask(false, "unsure") } }, "\u2605 AI-01: check the " + arNum(c.to_check) + " unsure") : null,
             h("button", { type: "button", class: "btn btn-quiet", on: { click: ask(false, "all") } }, "\u2605 AI-01: every folder (teams and applications too)")],
        !running && c.suggested ? h("button", { type: "button", class: "btn btn-quiet", on: { click: ask(true, "all") } }, "Suggest the undecided ones again") : null,
        h("a", { class: "btn btn-quiet", href: "#/access-review?ds=" + encodeURIComponent(d.id) + "&step=report" }, "Next: the report \u2192")), msg));
  const tiles = h("div", { class: "ar-tiles" },
    arTile("Folders", c.folders), arTile("Confirmed", c.confirmed, "ar-t-ok"), arTile(sure + "% or more, to accept", c.sure, "ar-t-ai"),
    arTile("Unsure", c.unsure, "ar-t-warn", c.to_check ? arNum(c.to_check) + " for AI-01 to check" : "below " + sure + "%: your call"), arTile("No owner yet", c.folders - c.with_owner, "ar-t-bad"),
    arTile("With a department", c.with_department, null, arPct(c.with_department, c.folders) + "%"));
  const chips = h("div", { class: "ar-filters", role: "group", "aria-label": "Show" }, [["all", "All"], ["suggested", "To decide"], ["sure", sure + "% or more"],
    ["unsure", "Unsure"], ["confirmed", "Confirmed"], ["no_owner", "No owner"], ["inherited", "From a parent"]].map(([k, l]) =>
    h("button", { type: "button", class: "ar-f" + (k === filter ? " on" : ""), "aria-pressed": String(k === filter), on: { click: () => reload(k, q) } }, l)));
  const search = h("input", { type: "search", placeholder: "Search folder, owner, department, team, application", value: q || "", "aria-label": "Search" });
  search.addEventListener("keydown", e => { if (e.key === "Enter") reload(filter, search.value.trim()); });
  const lists = [["ar-apps", t.known_applications], ["ar-teams", t.known_teams], ["ar-owners", t.known_owners], ["ar-depts", t.known_departments]]
    .map(([id, xs]) => h("datalist", { id }, (xs || []).map(a => h("option", { value: a }))));
  const picked = new Map();
  const bulk = h("div", { class: "ar-bulk" });
  const decide = async items => {
    msg.textContent = "";
    try {
      const r = await apiPost("/admin/access/tags/decide", { items });
      box._note = r.decided + " saved.";
      reload(filter, q);
    } catch (e) { msg.textContent = e.message; }
  };
  const rowsEl = t.items.map(it => {
    const own = it.own_state === "confirmed" || (it.own_state === "suggested" && (it.s_owner || it.s_department || it.s_application || it.s_team));
    const val = k => (own ? it["s_" + k] : it[k]) || "";
    const field = (k, list, label, max) => h("input", { type: "text", list, maxlength: max || 120, "aria-label": label + " of " + it.label, value: val(k) });
    const owner = field("owner", "ar-owners", "Owner", 300), dept = field("department", "ar-depts", "Department");
    const team = field("team", "ar-teams", "Owning team"), app = field("application", "ar-apps", "Application");
    const kind = own ? it.s_owner_kind : it.owner_kind;
    const tick = h("input", { type: "checkbox", "aria-label": "Select " + it.label });
    const item = () => ({ key: it.key, decision: "confirm", owner: owner.value.trim() || null,
      owner_kind: owner.value.trim() === val("owner") && kind ? kind : null, department: dept.value.trim() || null,
      team: team.value.trim() || null, application: app.value.trim() || null, label: it.label });
    tick.addEventListener("change", () => { if (tick.checked) picked.set(it.key, item); else picked.delete(it.key); drawBulk(); });
    tick._it = it; tick._item = item;
    const why = [it.ntfs_owner ? h("div", { class: "small muted" }, "NTFS owner (Windows): ", h("span", { class: "mono" }, it.ntfs_owner)) : null,
      it.evidence && it.own_state !== "rejected" ? h("div", { class: "small ar-why" }, "Evidence: " + it.evidence) : null,
      it.reason && !["rules", "file", "last_year"].includes(it.suggested_by) ? h("div", { class: "small ar-why" }, "\u2605 AI-01: " + it.reason) : null,
      it.reason && it.suggested_by === "last_year" && it.reason !== "From last year's mapping" ? h("div", { class: "small ar-why" }, it.reason) : null,
      it.reason && it.suggested_by === "file" ? h("div", { class: "small ar-why" }, it.reason) : null];
    return h("tr", null, h("td", null, tick),
      h("td", null, h("div", { class: "mono small ar-folder" }, it.label),
        h("div", { class: "muted small" }, arNum(it.entries) + " entries \u00b7 " + arNum(it.identities) + " accounts"), ...why),
      h("td", null, arTagChip(it, sure)),
      h("td", null, owner, kind ? h("div", { class: "small muted" }, AR_OWNER_KIND[kind]) : null), h("td", null, dept), h("td", null, team), h("td", null, app),
      h("td", { class: "nowrap" },
        h("button", { type: "button", class: "btn ar-sm", on: { click: () => decide([item()]) } }, "Confirm"),
        it.own_state && it.own_state !== "rejected" ? h("button", { type: "button", class: "btn btn-quiet ar-sm", title: "Not this owner: not suggested again",
          on: { click: () => decide([{ key: it.key, decision: "reject" }]) } }, "Reject") : null,
        it.own_state ? h("button", { type: "button", class: "btn-link ar-sm", title: "Forget the tag on this folder",
          on: { click: () => decide([{ key: it.key, decision: "clear" }]) } }, "Clear") : null));
  });
  const ticks = () => [...box.querySelectorAll("tbody input[type=checkbox]")];
  function drawBulk() {
    bulk.replaceChildren(
      h("button", { type: "button", class: "btn btn-quiet ar-sm", on: { click: () => {
        ticks().forEach(x => { const i = x._it; const ok = i.own_state === "suggested" && (i.confidence || 0) >= sure && (i.s_owner || i.s_department || i.s_application || i.s_team);
          x.checked = !!ok; if (ok) picked.set(i.key, x._item); else picked.delete(i.key); });
        drawBulk(); } } }, "Select the suggestions of " + sure + "% or more"),
      h("button", { type: "button", class: "btn btn-quiet ar-sm", on: { click: () => { ticks().forEach(x => { x.checked = false; }); picked.clear(); drawBulk(); } } }, "Select none"),
      h("button", { type: "button", class: "btn ar-sm", disabled: !picked.size, on: { click: () => decide([...picked.values()].map(f => f())) } },
        "Confirm the " + picked.size + " selected"));
  }
  drawBulk();
  box._dirty = false;
  box.addEventListener("input", () => { box._dirty = true; }, { once: true });
  box._reload = () => reload(filter, q);
  arPut(box, aiBox, box._maps || (box._maps = arMapsCard(d, () => box._reload())), tiles,
    h("section", { class: "ar-card" }, h("div", { class: "ar-tools" }, chips, search), bulk, ...lists,
      t.items.length ? h("div", { class: "table-wrap" }, h("table", { class: "ar-tag-t no-enh" },
        h("thead", null, h("tr", null, h("th", { scope: "col" }, ""), h("th", { scope: "col" }, "Folder"), h("th", { scope: "col" }, "Suggested by"),
          h("th", { scope: "col" }, "Business owner"), h("th", { scope: "col" }, "Department"), h("th", { scope: "col" }, "Owning team"),
          h("th", { scope: "col" }, "Application"), h("th", { scope: "col" }, ""))),
        h("tbody", null, rowsEl))) : h("p", { class: "muted" }, "No folders here."),
      t.items.length >= 500 ? h("p", { class: "muted small" }, "The 500 biggest folders are shown: search to find the others.") : null));
}

/* ---- r127: last year's mapping workbook ------------------------------------------------------ */

const AR_MAP_STATUS = { matched: ["Matched", "ar-ok"], ambiguous: ["Ambiguous", "ar-ai-mid"], no_folder: ["No such folder now", "ar-no"],
  below: ["Below the folders tagged", "ar-none"], empty: ["Nothing to use", "ar-none"], no_location: ["No folder on the row", "ar-none"],
  lookup: ["Used through a linked sheet", "ar-rule"] };
const AR_MAP_STATE = { uploaded: "Waiting to be read", reading: "Reading", review: "Check the columns", analysing: "Analysing",
  analysed: "Analysed", failed: "Failed" };

async function arSendRaw(path, file) {
  const res = await fetch("/api/v1" + path, { method: "POST", body: file, cache: "no-store",
    headers: { "Content-Type": "application/octet-stream", "X-Requested-With": "patch01-dashboard", ...authHeaders() } });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || res.statusText);
  return data;
}

function arMapsCard(d, onApplied) {
  const box = h("section", { class: "ar-card ar-maps" });
  let open = null;
  const msg = h("p", { class: "small", role: "status", "aria-live": "polite" });
  const file = h("input", { type: "file", accept: ".xlsx,.xls,.csv,.txt", "aria-label": "Last year's mapping workbook" });
  const up = h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
    const f = file.files && file.files[0];
    if (!f) { msg.textContent = "Choose the workbook first."; return; }
    if (f.size > 60 * 1048576) { msg.textContent = "A mapping workbook is at most 60 MB."; return; }
    up.disabled = true; msg.textContent = "Sending\u2026";
    try { const r = await arSendRaw("/admin/access/maps?name=" + encodeURIComponent(f.name), f); open = r.id; msg.textContent = ""; await load(); }
    catch (e) { msg.textContent = "Upload failed: " + e.message; }
    finally { up.disabled = false; }
  } } }, "\u2b06 Upload last year's mapping");
  const panel = h("div");
  const list = h("div");
  async function load() {
    let ms;
    try { ms = (await api("/admin/access/maps")).items; } catch (e) { if (e instanceof StaleRoute) return; list.replaceChildren(h("p", { class: "small muted" }, e.message)); return; }
    list.replaceChildren(ms.length ? table([
      { label: "Workbook", cell: m => h("button", { type: "button", class: "btn-link", on: { click: () => { open = m.id; drawPanel(); } } }, m.file_name) },
      { label: "Sheets", num: true, cell: m => arNum(m.sheet_count) },
      { label: "State", cell: m => arChip(AR_MAP_STATE[m.state] || m.state, m.state === "failed" ? "ar-no" : m.state === "analysed" ? "ar-ok" : "ar-ai-mid") },
      { label: "Used", cell: m => m.applied_at ? h("span", { class: "small" }, arCount(m.applied, "folder") + " " + timeAgo(m.applied_at)) : "" },
      { label: "", cell: m => h("button", { type: "button", class: "btn-link ar-sm", on: { click: async e => {
        const b = e.currentTarget;
        if (b.dataset.sure !== "1") { b.dataset.sure = "1"; b.textContent = "Click again to remove it"; return; }
        await apiSend("DELETE", "/admin/access/maps/" + m.id); if (open === m.id) open = null; load(); } } }, "Remove") }], ms)
      : h("p", { class: "small muted" }, "None uploaded yet."));
    drawPanel();
  }
  async function drawPanel() {
    if (!open) { panel.replaceChildren(); return; }
    let m;
    try { m = await api("/admin/access/maps/" + open); } catch (e) { panel.replaceChildren(h("p", { class: "small" }, e.message)); return; }
    if (["uploaded", "reading", "analysing"].includes(m.state)) {
      panel.replaceChildren(h("p", { class: "small" }, (m.state === "analysing" ? "Analysing every row against this scan" : "Reading every sheet") + "\u2026"));
      setTimeout(() => { if (document.body.contains(panel)) drawPanel(); }, 3000);
      return;
    }
    if (m.state === "failed" && !m.sheets) { panel.replaceChildren(h("p", { class: "ar-fail small" }, m.error || "It could not be read.")); return; }
    arPut(panel, arMapColumns(d, m, () => drawPanel()), m.state === "failed" ? h("p", { class: "ar-fail small" }, m.error) : null,
      m.state === "analysed" && m.dataset_id === d.id ? await arMapResults(d, m, async () => { await load(); onApplied(); }) : null);
  }
  arPut(box, h("h2", null, "\ud83d\udcd2 Last year's mapping"),
    h("p", { class: "muted small" }, "Upload the workbook you mapped last time (xlsx, xls or csv, every sheet). Each column is said to hold a path, a server, a share, "
      + "an owner, a department, a team or an application, and why; you check it. Rows are matched to this scan's folders exactly (path, or server and share), "
      + "owners to accounts by account name, e-mail or display name. Nothing is guessed: every row shows what became of it, and confirmed owners are never changed."),
    h("div", { class: "ar-up-row" }, file, up), msg, list, panel);
  load();
  return box;
}

function arMapColumns(d, m, redraw) {
  const roleOpts = [["", "\u2014 nothing \u2014"]].concat(m.roles.map(r => [r.role, r.text]));
  const sheetsEl = [];
  const state = m.sheets.map(s => ({ sheet_no: s.sheet_no, roles: { ...s.roles }, use: s.use }));
  m.sheets.forEach((s, si) => {
    const st = state[si];
    const useBox = h("input", { type: "checkbox", checked: s.use, "aria-label": "Use sheet " + s.name });
    useBox.addEventListener("change", () => { st.use = useBox.checked; });
    const byCol = {};
    Object.entries(s.roles).forEach(([r, c]) => { byCol[c] = r; });
    const rows = s.headers.map((hd, c) => {
      const sel = h("select", { "aria-label": "Sheet " + s.name + ", column " + hd }, roleOpts.map(([v, t]) => h("option", { value: v }, t)));
      sel.value = byCol[c] || "";
      sel.addEventListener("change", () => {
        Object.keys(st.roles).forEach(r => { if (st.roles[r] === c) delete st.roles[r]; });
        if (sel.value) st.roles[sel.value] = c;
      });
      const samples = (s.sample || []).map(r => r[c]).filter(x => x).slice(0, 3);
      return { hd, sel, samples, why: byCol[c] ? (s.why || {})[byCol[c]] : "" };
    });
    sheetsEl.push(h("details", { class: "ar-map-sheet", open: s.use ? true : null },
      h("summary", null, h("strong", null, s.name), " \u00b7 " + arCount(s.rows, "row") + " \u00b7 header on row " + s.header_row + " ",
        s.use ? arChip("Used", "ar-ok") : arChip("Not used", "ar-none")),
      h("label", { class: "small" }, useBox, " use this sheet"),
      table([{ label: "Column", cell: x => x.hd }, { label: "Sample values", cell: x => h("span", { class: "mono small" }, x.samples.join(" \u00b7 ")) },
        { label: "Holds", cell: x => x.sel }, { label: "Why", cell: x => h("span", { class: "small muted" }, x.why || "") }], rows)));
  });
  const joins = (m.joins || []).map(j => {
    const a = m.sheets.find(s => s.sheet_no === j.sheet), b = m.sheets.find(s => s.sheet_no === j.to_sheet);
    const cb = h("input", { type: "checkbox", checked: j.use, "aria-label": "Link " + a.name + " to " + b.name });
    cb._j = j;
    return h("li", { class: "small" }, cb, " ", h("strong", null, a.name), " \u2192 ", h("strong", null, b.name), ": by \u201c" + a.headers[j.col] + "\u201d = \u201c"
      + b.headers[j.to_col] + "\u201d, " + j.matched + " of " + j.of + " values found; adds " + j.gives.map(g => (m.roles.find(r => r.role === g) || {}).text || g).join(", ").toLowerCase());
  });
  const covers = h("input", { type: "checkbox", checked: m.covers, "aria-label": "A share's row for its folders" });
  const msg = h("p", { class: "small", role: "status" });
  const go = h("button", { type: "button", class: "btn", on: { click: async () => {
    go.disabled = true; msg.textContent = "";
    try {
      await apiPost("/admin/access/maps/" + m.id + "/columns", { sheets: state, covers: covers.checked,
        joins: joins.map(li => li.querySelector("input")).map(x => ({ sheet: x._j.sheet, to_sheet: x._j.to_sheet, use: x.checked })) });
      await apiPost("/admin/access/maps/" + m.id + "/analyse", { dataset_id: d.id });
      redraw();
    } catch (e) { msg.textContent = e.message; go.disabled = false; }
  } } }, m.state === "analysed" ? "Save and analyse again" : "\u2714 These are right: analyse against this scan");
  return h("div", { class: "ar-map" }, h("h3", null, m.file_name),
    h("p", { class: "muted small" }, "What each column holds, and why. Change any that is wrong; columns left at \u201cnothing\u201d are not used."),
    sheetsEl, joins.length ? [h("h4", null, "Sheets linked by their values"), h("ul", { class: "ar-map-joins" }, joins)]
      : h("p", { class: "small muted" }, "No sheets are linked: no column's values are found in another sheet's."),
    h("label", { class: "small" }, covers, " A share's row is used for its folders that have no row of their own (shown as such)"),
    h("div", { class: "ar-actions" }, go), msg);
}

async function arMapResults(d, m, onApplied) {
  const res = m.result || {};
  const oc = res.outcomes || {};
  const box = h("div", { class: "ar-map-res" });
  let status = "";
  const body = h("div");
  const names = {};
  (m.sheets || []).forEach(s => { names[s.sheet_no] = s.name; });
  const load = async () => {
    const qs = new URLSearchParams({ status });
    const o = await api("/admin/access/maps/" + m.id + "/outcomes?" + qs);
    arPut(body,
      h("h4", null, "What it says of each folder"),
      o.targets.length ? table([
        { label: "Folder", cell: t => h("span", { class: "mono small" }, t.folder || t.folder_key) },
        { label: "Business owner", cell: t => t.owner ? [h("span", { class: "mono small" }, t.owner), h("div", { class: "small muted" }, t.owner_kind ? AR_OWNER_KIND[t.owner_kind] : "as written (no account matches)")] : "" },
        { label: "Department", cell: t => t.department || "" }, { label: "Team \u00b7 application", cell: t => [t.team || "", t.application ? h("div", { class: "small muted" }, t.application) : null] },
        { label: "Confidence", num: true, cell: t => h("span", { "data-sort": t.confidence }, t.confidence + "%") },
        { label: "Evidence", cell: t => [h("div", { class: "small" }, t.evidence), t.conflicts ? h("div", { class: "small ar-fail" }, "Conflict, not used: " + t.conflicts) : null] },
        { label: "This year", cell: t => t.now_state === "confirmed" ? arChip(t.same_as_now ? "Confirmed, the same" : "Confirmed, different: kept", t.same_as_now ? "ar-ok" : "ar-ai-mid")
          : t.now_state === "rejected" ? arChip("Rejected: kept", "ar-none") : arChip("Becomes a suggestion", "ar-rule") }], o.targets)
        : h("p", { class: "small muted" }, "No folder of this scan is named in the workbook."),
      h("h4", null, "Every row"),
      o.items.length ? table([
        { label: "Sheet \u00b7 row", cell: x => h("span", { class: "small" }, (names[x.sheet_no] || x.sheet_no) + " \u00b7 " + x.rn) },
        { label: "Where the row says", cell: x => h("span", { class: "mono small" }, x.location || "") },
        { label: "Folder", cell: x => x.folder ? [h("span", { class: "mono small" }, x.folder), x.how ? h("div", { class: "small muted" }, "by " + x.how) : null] : "" },
        { label: "Business owner", cell: x => x.owner_text ? [h("span", { class: "small" }, x.owner_text), x.owner && x.owner_how ? h("div", { class: "small muted" }, "\u2192 " + x.owner + " (by " + x.owner_how + ")") : null] : "" },
        { label: "Department", cell: x => x.department || "" },
        { label: "Outcome", cell: x => arChip(...(AR_MAP_STATUS[x.status] || [x.status, "ar-none"])) },
        { label: "Note", cell: x => h("span", { class: "small" }, x.note || "") }], o.items)
        : h("p", { class: "small muted" }, "No rows with this outcome."),
      o.items.length >= 1000 ? h("p", { class: "small muted" }, "The first 1,000 rows: the CSV has every one.") : null);
  };
  const chips = h("div", { class: "ar-filters", role: "group", "aria-label": "Rows" }, [["", "All rows"]].concat(Object.keys(AR_MAP_STATUS).filter(k => oc[k]).map(k => [k, AR_MAP_STATUS[k][0] + " (" + arNum(oc[k]) + ")"]))
    .map(([k, l]) => h("button", { type: "button", class: "ar-f" + (k === status ? " on" : ""), on: { click: e => {
      status = k; chips.querySelectorAll(".ar-f").forEach(b => b.classList.remove("on")); e.currentTarget.classList.add("on"); load(); } } }, l)));
  const msg = h("p", { class: "small", role: "status" });
  const apply = h("button", { type: "button", class: "btn", disabled: !res.to_apply, on: { click: async () => {
    apply.disabled = true;
    try { const r = await apiPost("/admin/access/maps/" + m.id + "/apply", {}); msg.textContent = arNum(r.applied) + " folders now have last year's owner as a suggestion: accept them below."; onApplied(); }
    catch (e) { msg.textContent = e.message; apply.disabled = false; }
  } } }, "\u2714 Use it for " + arCount(res.to_apply || 0, "folder") + " (as suggestions)");
  arPut(box, h("div", { class: "ar-tiles" }, arTile("Rows", res.rows), arTile("Matched", oc.matched, "ar-t-ok"), arTile("Folders it names", res.folders, null, "of " + arNum(res.folders_in_scan)),
      arTile("Conflicts", res.conflict_folders, "ar-t-warn", "folders"), arTile("No such folder now", oc.no_folder, "ar-t-bad"), arTile("Ambiguous", oc.ambiguous, "ar-t-warn"),
      arTile("Confirmed already", (res.confirmed_same || 0) + (res.confirmed_different || 0), null, arNum(res.confirmed_different || 0) + " different")),
    h("div", { class: "ar-actions" }, apply, h("button", { type: "button", class: "btn btn-quiet", on: { click: async e => {
      try { await downloadFile("/admin/access/maps/" + m.id + "/csv", "last-year-mapping-analysis.csv"); } catch (err) { e.currentTarget.textContent = err.message; } } } },
      "\u2b07 CSV of every row")), msg, chips, body);
  await load();
  return box;
}

/* Step 4: what to report, asked step by step */
function arWizard(d) {
  const kinds = d.kinds || [];
  const adv = (d.advice && d.advice.items) || [];
  const advBy = Object.fromEntries(adv.map(a => [a.report, a]));
  const st = { step: 0, kind: adv.length ? adv[0].report : "risk", title: "", servers: [], applications: [], teams: [], untagged: true,
    levels: ["full", "modify", "write"], inherited: true, tags: "confirmed" };
  const box = h("section", { class: "ar-card ar-wiz" });
  const prof = d.profile || {};
  const ch = d.choices || { servers: [], applications: [], teams: [] };
  const QS = ["What is the report for?", "Which part of the file?", "What counts as risky?", "Check and make it"];
  const pickList = (items, sel, label) => items.length ? h("div", { class: "ar-pick", role: "group", "aria-label": label },
    items.map(x => { const cb = h("input", { type: "checkbox", checked: sel.includes(x) });
      cb.addEventListener("change", () => { const i = sel.indexOf(x); if (cb.checked && i < 0) sel.push(x); if (!cb.checked && i >= 0) sel.splice(i, 1); });
      return h("label", { class: "ar-pick-i" }, cb, " ", x); })) : h("p", { class: "muted small" }, "None in this file.");
  const draw = () => {
    const nav = h("div", { class: "ar-actions" },
      st.step ? h("button", { type: "button", class: "btn btn-quiet", on: { click: () => { st.step--; draw(); } } }, "\u2190 Back") : null,
      st.step < 3 ? h("button", { type: "button", class: "btn", on: { click: () => { st.step++; draw(); } } }, "Next \u2192") : null);
    let body;
    if (st.step === 0) {
      const order = [...adv.map(a => a.report), ...kinds.map(k => k.key).filter(k => !advBy[k])];
      body = [d.advice ? h("p", { class: "muted small" }, d.advice.by === "AI-01" ? "\u2605 AI-01 read the counts of this file and recommends the first ones."
        : "Recommended from the counts of this file." + (d.advice.note ? " " + d.advice.note : "")) : h("p", { class: "muted small" }, "AI-01 is reading the counts\u2026"),
        h("div", { class: "ar-kinds", role: "radiogroup", "aria-label": QS[0] }, order.map(k => {
          const kd = kinds.find(x => x.key === k); if (!kd) return null;
          const a = advBy[k];
          return h("button", { type: "button", role: "radio", "aria-checked": String(st.kind === k), class: "ar-kind" + (st.kind === k ? " on" : "") + (a ? " rec" : ""),
            on: { click: () => { st.kind = k; draw(); } } },
            h("div", { class: "ar-kind-t" }, a ? h("span", { class: "ar-star", "aria-label": "recommended" }, "\u2605 ") : null, kd.title),
            h("div", { class: "muted small" }, kd.about), a ? h("div", { class: "small ar-kind-why" }, a.why) : null);
        }))];
    } else if (st.step === 1) {
      const untag = h("input", { type: "checkbox", checked: st.untagged });
      untag.addEventListener("change", () => { st.untagged = untag.checked; });
      body = [h("p", { class: "muted small" }, "Leave everything unticked for the whole file."),
        h("h3", null, "Servers"), pickList(ch.servers, st.servers, "Servers"),
        h("h3", null, "Applications"), pickList(ch.applications, st.applications, "Applications"),
        h("h3", null, "Owning teams"), pickList(ch.teams, st.teams, "Teams"),
        h("label", { class: "ar-pick-i" }, untag, " Include folders without an application or team")];
    } else if (st.step === 2) {
      const lv = ["full", "modify", "write", "read_execute", "read"].map(k => {
        const cb = h("input", { type: "checkbox", checked: st.levels.includes(k) });
        cb.addEventListener("change", () => { st.levels = cb.checked ? [...new Set([...st.levels, k])] : st.levels.filter(x => x !== k); });
        return h("label", { class: "ar-pick-i" }, cb, " ", AR_LEVEL_TEXT[k]);
      });
      const inh = h("input", { type: "checkbox", checked: st.inherited });
      inh.addEventListener("change", () => { st.inherited = inh.checked; });
      const tg = h("select", { "aria-label": "Which tags" }, h("option", { value: "confirmed" }, "Confirmed tags only (suggestions count as \u201cNot tagged\u201d)"),
        h("option", { value: "with_suggested" }, "Confirmed and AI-01's suggestions (marked as a draft)"));
      tg.value = st.tags;
      tg.addEventListener("change", () => { st.tags = tg.value; });
      body = [h("h3", null, "Access that counts as risky for Everyone-type groups"), h("div", { class: "ar-pick" }, lv),
        h("p", { class: "muted small" }, "People given rights directly, orphaned accounts, full control outside the admin groups and deny entries are always reported."),
        h("label", { class: "ar-pick-i" }, inh, " Include inherited entries" + (prof.inherit_unknown ? " (" + arNum(prof.inherit_unknown) + " entries do not say)" : "")),
        h("h3", null, "Applications and teams"), tg];
    } else {
      const kd = kinds.find(x => x.key === st.kind) || {};
      const title = h("input", { type: "text", maxlength: 120, value: st.title || kd.title || "", "aria-label": "Title of the report" });
      title.addEventListener("input", () => { st.title = title.value; });
      const msg = h("p", { class: "small", role: "status" });
      const go = h("button", { type: "button", class: "btn", on: { click: async () => {
        if (!st.levels.length) { msg.textContent = "Choose at least one access level that counts as risky."; return; }
        go.disabled = true;
        try {
          const r = await apiPost("/admin/access/" + encodeURIComponent(d.id) + "/reports", { kind: st.kind, title: st.title || null,
            scope: { servers: st.servers, applications: st.applications, teams: st.teams, untagged: st.untagged },
            options: { risky_levels: st.levels, include_inherited: st.inherited, tags: st.tags } });
          location.hash = "#/access-review?report=" + encodeURIComponent(r.id);
        } catch (e) { msg.textContent = e.message; go.disabled = false; }
      } } }, "Make the report");
      const all = a => a.length ? a.join(", ") : "all";
      body = [h("dl", { class: "ar-review" },
        h("dt", null, "Report"), h("dd", null, kd.title || st.kind),
        h("dt", null, "Servers"), h("dd", null, all(st.servers)),
        h("dt", null, "Applications"), h("dd", null, all(st.applications) + (st.untagged ? ", and folders without a tag" : "")),
        h("dt", null, "Teams"), h("dd", null, all(st.teams)),
        h("dt", null, "Risky for Everyone-type groups"), h("dd", null, st.levels.map(x => AR_LEVEL_TEXT[x]).join(", ") || "\u2014"),
        h("dt", null, "Inherited entries"), h("dd", null, st.inherited ? "included" : "left out"),
        h("dt", null, "Tags"), h("dd", null, st.tags === "confirmed" ? "confirmed only" : "confirmed and suggestions (draft)")),
        h("label", { class: "ar-lab" }, "Title ", title), h("div", { class: "ar-actions" }, go, msg),
        h("p", { class: "muted small" }, "Every figure is counted from all " + arNum(prof.entries) + " rows. AI-01 then writes a summary from those figures only.")];
      if (prof.tagged === 0 && st.tags === "confirmed" && ["by_app", "team_review"].includes(st.kind)) {
        body.unshift(h("p", { class: "ar-note" }, "No folder has a confirmed application yet: everything will show as \u201cNot tagged\u201d. Confirm tags first, or include the suggestions."));
      }
    }
    arPut(box, h("div", { class: "ar-wiz-top" }, h("span", { class: "ar-wiz-n" }, "Question " + (st.step + 1) + " of 4"),
      h("div", { class: "ar-wiz-dots", "aria-hidden": "true" }, QS.map((_, i) => h("span", { class: i <= st.step ? "on" : null })))),
      h("h2", null, QS[st.step]), ...[].concat(body).filter(Boolean), nav);
  };
  draw();
  return h("div", null, arProfile(prof), box);
}

function arProfile(p) {
  if (!p || !p.entries) return null;
  return h("div", { class: "ar-tiles" },
    arTile("Entries", p.entries), arTile("Folders tagged", p.tagged, "ar-t-ok", "of " + arNum(p.folders)),
    arTile("Open to everyone (change)", p.broad_write, "ar-t-bad"), arTile("People given rights directly", p.explicit_users, "ar-t-warn"),
    arTile("Orphaned accounts", p.orphans, "ar-t-warn"), arTile("Full control outside admins", p.full_nonadmin, "ar-t-bad"),
    p.drives ? arTile("Drive letters", p.drives, "ar-t-ai", "from the drive sheet") : null,
    p.groups_opened ? arTile("Groups opened up", p.groups_opened, "ar-t-ai", arNum(p.accounts_behind) + " accounts behind them") : null);
}

function arReportList(d) {
  return h("section", { class: "ar-card" }, h("h2", null, "Reports made from this upload"),
    table([{ label: "Report", cell: r => h("a", { href: "#/access-review?report=" + encodeURIComponent(r.id) }, r.title) },
      { label: "Findings", num: true, cell: r => r.findings === null ? (r.state === "failed" ? "failed" : "counting\u2026") : arNum(r.findings) },
      { label: "Made", cell: r => h("span", { title: r.created_at }, timeAgo(r.created_at) + " by " + r.created_by) }], d.reports));
}

/* ---- a report -------------------------------------------------------------------------------- */

// The donut, with its total written as the tiles write numbers (2,558, not 2558)
function arDonut(title, segs, opts = {}) {
  const total = segs.reduce((a, x) => a + (Number(x.value) || 0), 0);
  return donut(title, segs, Object.assign({ centre: arNum(total) }, opts));
}

function arSegs(list, labelKey, valueKey, clsOf) {
  return list.map((x, i) => ({ label: x[labelKey], value: x[valueKey], cls: clsOf(x, i) }));
}
function arNamedCls(s, i) { return s.untagged ? "c-ar-un" : s.other ? "c-muted" : "c-ar" + ((i % 8) + 1); }

async function arReport(id) {
  let r;
  try { r = await api("/admin/access/reports/" + encodeURIComponent(id)); }
  catch (e) {
    if (e instanceof StaleRoute) throw e;
    return render(arHead("Access review"), h("div", { class: "empty" }, h("p", null, e.message)));
  }
  const page = h("div", { class: "ar ar-rep" });
  render(page);
  const draw = () => arPut(page, ...arReportBody(r));
  draw();
  arWatch(page, 4000, async () => {
    if (!["queued", "computing"].includes(r.state) && !(r.state === "ready" && ["queued", "running"].includes(r.summary_state))) return;
    r = await api("/admin/access/reports/" + encodeURIComponent(id));
    draw();
  });
}

function arReportBody(r) {
  const back = h("a", { class: "btn btn-quiet", href: "#/access-review?ds=" + encodeURIComponent(r.dataset_id) + "&step=report" }, "\u2190 Another report");
  const head = arHead(r.title, r.dataset + " (" + r.file_name + ") \u00b7 made " + fmtDateTime(r.created_at) + " by " + r.created_by, back);
  if (r.state === "failed") return [head, h("p", { class: "ar-fail", role: "alert" }, r.error || "The figures could not be counted.")];
  if (r.state !== "ready" || !r.result) {
    return [head, h("section", { class: "ar-card ar-wait" }, hudRing({ pct: null, idle: "COUNTING", title: "REPORT", live: true, key: "ar-rep-" + r.id, label: "Counting" }),
      h("div", null, h("h2", null, "Counting every row"), h("p", { class: "muted" }, "A million rows take a few seconds.")))];
  }
  const res = r.result, k = res.kpis, spec = r.spec || {};
  const msg = h("span", { class: "small", role: "status" });
  const actions = h("div", { class: "ar-actions ar-noprint" },
    h("button", { type: "button", class: "btn", on: { click: async () => {
      msg.textContent = "Preparing the CSV\u2026";
      try { await downloadFile("/admin/access/reports/" + encodeURIComponent(r.id) + "/csv", "access-report.csv"); msg.textContent = ""; }
      catch (e) { msg.textContent = e.message; }
    } } }, "\u2b07 CSV of all " + arNum(res.findings_total) + (r.kind === "ownership" ? " entries giving access" : " findings")),
    r.kind === "ownership" ? h("button", { type: "button", class: "btn", on: { click: async () => {
      msg.textContent = "Preparing the CSV\u2026";
      try { await downloadFile("/admin/access/reports/" + encodeURIComponent(r.id) + "/csv?what=folders", "access-folders.csv"); msg.textContent = ""; }
      catch (e) { msg.textContent = e.message; }
    } } }, "\u2b07 CSV of all " + arNum(res.ownership.total) + " folders, one row each") : null,
    ["effective", "by_department"].includes(r.kind) ? h("button", { type: "button", class: "btn", on: { click: async () => {
      msg.textContent = "Preparing the CSV\u2026";
      try { await downloadFile("/admin/access/reports/" + encodeURIComponent(r.id) + "/csv?what=people", "access-accounts.csv"); msg.textContent = ""; }
      catch (e) { msg.textContent = e.message; }
    } } }, "\u2b07 CSV of all " + arNum(r.kind === "by_department" ? res.department_view.people_total : res.people_total)
      + (r.kind === "by_department" ? " people, folder by folder" : " accounts, folder by folder")) : null,
    h("button", { type: "button", class: "btn btn-quiet", on: { click: () => window.print() } }, "Print / PDF"), msg);
  const measure = res.measure === "entries" ? "entries" : "findings";
  const cats = Object.entries(res.categories).filter(([, v]) => v.in_report);
  const donuts = h("div", { class: "ar-donuts" },
    r.kind === "ownership" ? arDonut("Business owner", [{ label: "Person", value: res.ownership.counts.person_owner, cls: "c-ar1" },
      { label: "Group / team", value: res.ownership.counts.group_owner, cls: "c-ar2" },
      { label: "No owner yet", value: res.ownership.total - res.ownership.counts.with_owner, cls: "c-ar-un" }], { centreLabel: "folders" }) : null,
    r.kind === "ownership" ? arDonut("Everyone-type groups", [{ label: "Can change", value: res.ownership.counts.everyone_change, cls: AR_CAT_CLS.broad_write },
      { label: "Can read only", value: res.ownership.counts.everyone_any - res.ownership.counts.everyone_change, cls: AR_CAT_CLS.broad_read },
      { label: "No", value: res.ownership.total - res.ownership.counts.everyone_any, cls: "c-muted" }], { centreLabel: "folders", caption: "Highlighted in the table below." }) : null,
    res.owner_donut ? arDonut("Folders by department", res.owner_donut.map((x, i) => ({ label: x.label, value: x.value, cls: arNamedCls(x, i) })),
      { centreLabel: "folders" }) : null,
    !["untagged", "by_server", "effective", "by_department", "ownership"].includes(r.kind) ? arDonut("Kinds of risk", cats.map(([key, v]) => ({ label: v.label, value: v.n, cls: AR_CAT_CLS[key] })),
      { centre: arNum(k.findings), centreLabel: "findings", caption: "An entry can be of more than one kind." }) : null,
    res.dept_donut ? arDonut("People by department", res.dept_donut.map((x, i) => ({ label: x.label, value: x.value, cls: arNamedCls(x, i) })),
      { centreLabel: "people", caption: "Each person once, in their department." }) : null,
    arDonut("By application", res.donuts.applications.map((s, i) => ({ label: s.label, value: s.value, cls: arNamedCls(s, i) })),
      { centreLabel: measure, caption: spec.options && spec.options.tags === "with_suggested" ? "Draft: includes AI-01's suggestions." : "Confirmed tags." }),
    arDonut("By owning team", res.donuts.teams.map((s, i) => ({ label: s.label, value: s.value, cls: arNamedCls(s, i) })), { centreLabel: measure }),
    arDonut("Access level", res.levels.map(x => ({ label: x.label, value: x.n, cls: AR_LEVEL_CLS[x.level] })), { centreLabel: "allow entries" }),
    arDonut("Kind of account", res.kinds.map(x => ({ label: x.label, value: x.n, cls: AR_KIND_CLS[x.kind] })), { centreLabel: "entries" }),
    res.donuts.servers.length > 1 ? arDonut("By server and share", res.donuts.servers.map((s, i) => ({ label: s.label, value: s.value, cls: arNamedCls(s, i) })),
      { centreLabel: measure }) : null);
  const sm = r.summary;
  const summary = h("section", { class: "ar-card ar-sum" }, h("h2", null, "\u2605 Summary by AI-01"),
    r.summary_state === "done" && sm ? [h("p", { class: "ar-headline" }, sm.headline),
      sm.points.length ? h("ul", null, sm.points.map(p => h("li", null, p))) : null,
      sm.actions.length ? [h("h3", null, "First actions"), h("ol", null, sm.actions.map(p => h("li", null, p)))] : null,
      h("p", { class: "muted small" }, "Written from the figures below only; any sentence quoting a number that is not in this report was removed.")]
    : ["queued", "running"].includes(r.summary_state) ? h("p", { class: "muted" }, "AI-01 is writing it from the figures\u2026")
    : r.summary_state === "off" ? h("p", { class: "muted" }, "AI-01 is not configured on PATCH-01: the figures below are complete without it.")
    : [h("p", { class: "muted" }, "AI-01 could not write it this time."), h("button", { type: "button", class: "btn btn-quiet ar-noprint", on: { click: async e => {
        e.currentTarget.disabled = true; await apiPost("/admin/access/reports/" + encodeURIComponent(r.id) + "/summary", {});
        location.hash = "#/access-review?report=" + encodeURIComponent(r.id) + "&t=" + Date.now(); } } }, "Ask again")]);
  const why = f => h("div", { class: "ar-whys" }, (f.why || []).map(w => arChip(w, "ar-w")));
  const catCols = cats.map(([key, v]) => ({ label: v.label, num: true, cell: x => x[key] ? h("span", { "data-sort": x[key] }, arNum(x[key])) : h("span", { class: "muted", "data-sort": 0 }, "0") }));
  const groupTable = (title, rows, first) => rows.length ? h("section", { class: "ar-card" }, h("h2", null, title),
    table([{ label: first, cell: x => x.name === "Not tagged" ? h("em", null, "Not tagged") : x.name },
      { label: "Findings", num: true, cell: x => h("strong", { "data-sort": x.findings }, arNum(x.findings)) },
      { label: "Entries", num: true, cell: x => h("span", { "data-sort": x.entries }, arNum(x.entries)) },
      { label: "Folders", num: true, cell: x => h("span", { "data-sort": x.folders }, arNum(x.folders)) },
      { label: "Accounts", num: true, cell: x => h("span", { "data-sort": x.identities }, arNum(x.identities)) }, ...catCols], rows)) : null;
  const sections = [];
  if (["by_app", "team_review", "risk", "untagged"].includes(r.kind)) sections.push(groupTable("By application", res.applications, "Application"), groupTable("By owning team", res.teams, "Owning team"));
  if (r.kind === "by_server") sections.push(groupTable("By server and share", res.servers, "Server \u00b7 share"));
  if (r.kind === "ownership") { sections.push(arOwnership(r, res)); if ((res.shares || []).length) sections.push(arSharesCard(res)); return arReportFrame(r, head, actions, res, k, spec, summary, donuts, sections); }
  if (r.kind === "by_owner") sections.push(...arByOwner(r, res));
  if (r.kind === "by_department") { sections.push(...arDepartments(r, res)); if ((res.shares || []).length) sections.push(arSharesCard(res)); return arReportFrame(r, head, actions, res, k, spec, summary, donuts, sections); }
  if ((res.shares || []).length) sections.push(arSharesCard(res));
  sections.push(h("section", { class: "ar-card" }, h("h2", null, "Folders, most findings first"),
    table([{ label: "Folder", cell: x => h("span", { class: "mono small" }, x.folder) },
      { label: "Application", cell: x => x.application || h("em", { class: "muted" }, "Not tagged") }, { label: "Team", cell: x => x.team || "" },
      { label: r.kind === "untagged" || r.kind === "by_server" ? "Entries" : "Findings", num: true, cell: x => h("strong", { "data-sort": x[measure] }, arNum(x[measure])) },
      ...catCols], res.folders),
    res.folders.length >= 200 ? h("p", { class: "muted small" }, "The 200 folders with the most findings; the CSV has every finding.") : null));
  if (res.who.length) sections.push(h("section", { class: "ar-card" }, h("h2", null, "Accounts, most findings first"),
    table([{ label: "Account", cell: x => h("span", { class: "mono small" }, x.identity) }, { label: "Kind", cell: x => arChip(AR_KIND_TEXT[x.identity_kind] || x.identity_kind, "ar-k " + AR_KIND_CLS[x.identity_kind]) },
      { label: "Highest access", cell: x => AR_LEVEL_TEXT[x.worst] || x.worst },
      { label: "Findings", num: true, cell: x => h("strong", { "data-sort": x.findings }, arNum(x.findings)) },
      { label: "Folders", num: true, cell: x => h("span", { "data-sort": x.folders }, arNum(x.folders)) },
      res.has_members ? { label: "Accounts behind it", num: true, cell: x => x.behind ? h("span", { "data-sort": x.behind }, arNum(x.behind))
        : h("span", { class: "muted", "data-sort": -1 }, x.identity_kind === "broad" ? "everyone" : "\u2014") } : null].filter(Boolean), res.who)));
  if (r.kind === "effective") sections.unshift(h("section", { class: "ar-card" },
    h("h2", null, "Who really can change data" + (res.people_total > res.people.length ? " (first " + arNum(res.people.length) + " of " + arNum(res.people_total) + ")" : "")),
    h("p", { class: "muted small" }, "Every account with write access or more (admin and system accounts left out), given directly or through a group: "
      + "groups the members sheet lists are opened up, nested groups too. Everyone-type groups are not opened: they mean everyone."),
    res.people.length ? table([{ label: "Account", cell: x => h("span", { class: "mono small" }, x.account) },
      { label: "Kind", cell: x => arChip(AR_KIND_TEXT[x.kind] || x.kind, "ar-k " + (AR_KIND_CLS[x.kind] || "")) },
      ...(res.has_people ? [{ label: "Department", cell: x => x.department || h("em", { class: "muted" }, "not in the file") }] : []),
      { label: "How", cell: x => [x.direct ? arChip("directly", "ar-rule") : null, ...(x.through || []).map(g => h("div", { class: "mono small" }, "via " + g))] },
      { label: "Folders", num: true, cell: x => h("strong", { "data-sort": x.folders }, arNum(x.folders)) },
      { label: "Applications", num: true, cell: x => h("span", { "data-sort": x.applications }, arNum(x.applications)) },
      { label: "Highest access", cell: x => AR_LEVEL_TEXT[x.worst] || x.worst }], res.people)
      : h("p", { class: "muted" }, "Nobody outside the admin groups can change data in scope.")));
  (res.team_sections || []).forEach(t => sections.push(h("section", { class: "ar-card ar-team" },
    h("h2", null, "Review pack: " + t.team), h("p", { class: "muted small" }, "Every account (other than admin and system accounts) that can write or more on the team's folders. Keep or remove each one."),
    t.rows.length ? table([{ label: "Folder", cell: x => h("span", { class: "mono small" }, x.folder) }, { label: "Account", cell: x => [h("span", { class: "mono small" }, x.identity),
        x.members ? h("details", { class: "ar-mem" }, h("summary", { class: "small" }, arNum(x.members.n) + " account" + (x.members.n === 1 ? "" : "s") + " in it"),
          h("div", { class: "mono small" }, x.members.names.join(", ") + (x.members.n > x.members.names.length ? ", \u2026" : ""))) : null] },
      { label: "Kind", cell: x => AR_KIND_TEXT[x.kind] || x.kind }, { label: "Access", cell: x => AR_LEVEL_TEXT[x.level] || x.level },
      { label: "Risky", cell: x => x.risky ? arChip("Yes", "ar-w") : "" }, { label: "Keep / remove", cell: () => h("span", { class: "ar-box" }, "\u2610 keep   \u2610 remove") }], t.rows)
      : h("p", { class: "muted" }, "Nothing with write access or more."))));
  sections.push(h("section", { class: "ar-card" }, h("h2", null, "Findings" + (res.findings_total > res.findings.length ? " (first " + arNum(res.findings.length) + " of " + arNum(res.findings_total) + ")" : "")),
    res.findings.length ? table([{ label: "Path", cell: x => h("span", { class: "mono small" }, x.path) }, { label: "Account", cell: x => h("span", { class: "mono small" }, x.identity) },
      { label: "Kind", cell: x => AR_KIND_TEXT[x.identity_kind] || x.identity_kind }, { label: "Access", cell: x => (x.allow ? "" : "Deny ") + (AR_LEVEL_TEXT[x.level] || x.level) },
      { label: "Inherited", cell: x => x.inherited === null ? "?" : x.inherited ? "Yes" : "No" }, { label: "Application", cell: x => x.application || "" },
      { label: "Why", cell: why }], res.findings) : h("p", { class: "muted" }, "No findings: nothing in scope matches this report.")));
  return arReportFrame(r, head, actions, res, k, spec, summary, donuts, sections);
}

function arReportFrame(r, head, actions, res, k, spec, summary, donuts, sections) {
  const scope = spec.scope || {};
  const caveats = [k.kind_unknown ? arNum(k.kind_unknown) + " entries do not say whether the account is a person or a group (no account type column): those people are not counted as \u201cgiven rights directly\u201d." : null,
    k.inherit_unknown ? arNum(k.inherit_unknown) + " entries do not say whether they are inherited." : null,
    res.department_view && res.department_view.groups_not_opened ? arNum(res.department_view.groups_not_opened)
      + " groups with access have no members listed in the file: their people cannot be placed in a department." : null].filter(Boolean);
  const dv = res.department_view;
  return [head, actions,
    h("div", { class: "ar-tiles" }, arTile("Entries in scope", k.entries), arTile("Folders", k.folders), arTile("Accounts", k.identities),
      arTile(r.kind === "untagged" ? "Entries without a tag" : ["by_department", "ownership"].includes(r.kind) ? "Entries giving access" : "Findings", k.findings, "ar-t-bad", arPct(k.findings, k.entries) + "% of the entries"),
      arTile("Folders with findings", k.folders_with, "ar-t-warn"), arTile("Applications", k.applications), arTile("Teams", k.teams),
      k.accounts_behind !== undefined ? arTile("Accounts behind the groups", k.accounts_behind, "ar-t-ai", "from the members sheet") : null,
      r.kind === "effective" ? arTile("Accounts that can change data", res.people_total, "ar-t-bad", "directly or through groups") : null,
      dv ? arTile("People with access", dv.people_total, "ar-t-ai", "directly or through groups") : null,
      dv ? arTile("Departments", (res.departments || []).filter(x => x.name !== AR_NODEPT).length, "ar-t-ok") : null,
      dv ? arTile("Outside the owning department", dv.outside_total, "ar-t-bad", "people \u00d7 folders they can change") : null),
    h("p", { class: "muted small" }, "Scope: " + ["servers " + ((scope.servers || []).join(", ") || "all"), "applications " + ((scope.applications || []).join(", ") || "all"),
      "teams " + ((scope.teams || []).join(", ") || "all")].join(" \u00b7 ") + (scope.untagged === false ? " \u00b7 tagged folders only" : "")
      + " \u00b7 risky for Everyone-type groups: " + ((spec.options || {}).risky_levels || []).map(x => AR_LEVEL_TEXT[x]).join(", ")
      + ((spec.options || {}).include_inherited === false ? " \u00b7 inherited entries left out" : "")),
    caveats.length ? h("ul", { class: "ar-caveats" }, caveats.map(c => h("li", null, c))) : null,
    summary, donuts, ...sections.filter(Boolean)];
}

/* ---- r124: permissions & ownership; by department & owner ----------------------------------- */

const AR_EVERYONE = { change: ["Everyone can change", "ar-w"], read: ["Everyone can read", "ar-ai-mid"] };
const AR_ACCESS_GROUPS = [["people", "People and groups"], ["everyone", "Everyone-type groups"], ["admin", "Admin and system"],
  ["orphan", "Orphaned SIDs (accounts that no longer exist)"]];
const AR_HOW_CLS = { "given here": "ar-rule", inherited: "ar-none", "given here and inherited": "ar-rule", "not stated": "ar-none" };

function arOwnerCell(f) {
  return f.owner ? [h("span", { class: "mono small" }, f.owner), f.owner_kind ? h("div", { class: "small muted" }, AR_OWNER_KIND[f.owner_kind]) : null]
    : h("em", { class: "muted" }, "no owner yet");
}

function arOwnership(r, res) {
  const o = res.ownership;
  const find = h("input", { type: "search", placeholder: "Find a folder, owner, department or account", "aria-label": "Find" });
  const onlyEv = h("input", { type: "checkbox", "aria-label": "Only folders Everyone-type groups can get in" });
  const box = h("div");
  const draw = () => {
    const q = find.value.trim().toLowerCase();
    const rows = o.folders.filter(f => (!onlyEv.checked || f.everyone) && (!q || [f.folder, f.owner, f.department, f.team, f.application, f.ntfs_owner]
      .concat(f.access.map(a => a.account)).some(x => (x || "").toLowerCase().includes(q))));
    box.replaceChildren(rows.length ? table([
      { label: "Folder", cell: f => [h("span", { class: "mono small" }, f.folder), f.everyone ? h("div", null, arChip(...AR_EVERYONE[f.everyone])) : null,
        f.orphans ? h("div", null, arChip(arCount(f.orphans, "orphaned SID"), "ar-ai-mid")) : null] },
      { label: "NTFS owner (Windows)", cell: f => f.ntfs_owner ? h("span", { class: "mono small" }, f.ntfs_owner) : h("span", { class: "muted" }, "\u2014") },
      { label: "Business owner", cell: arOwnerCell },
      { label: "Department", cell: f => f.department || h("em", { class: "muted" }, "\u2014") },
      { label: "Team \u00b7 application", cell: f => [f.team || "", f.application ? h("div", { class: "small muted" }, f.application) : null] },
      { label: "Tag", cell: f => f.tag_state === "confirmed" ? arChip("Confirmed", "ar-ok") : f.tag_state === "suggested" ? arChip("Suggested", "ar-ai-mid") : arChip("None", "ar-none") },
      { label: "Who has access", cell: f => h("details", { class: "ar-mem" },
        h("summary", { class: "small" }, arCount(f.access_total, "account") + " \u00b7 " + arNum(f.explicit_entries) + " given here, " + arNum(f.inherited_entries) + " inherited"),
        AR_ACCESS_GROUPS.filter(([g]) => f.access.some(a => (a.group || "people") === g)).map(([g, title]) => [
          h("div", { class: "small ar-acc-g" + (g === "orphan" ? " ar-acc-orphan" : "") }, title),
          h("ul", { class: "ar-acc" }, f.access.filter(a => (a.group || "people") === g).map(a => h("li", null, h("span", { class: "mono small" }, a.account), " ",
            a.level ? h("strong", { class: "small" }, AR_LEVEL_TEXT[a.level] || a.level) : null, a.deny ? arChip("Deny", "ar-w") : null, " ",
            arChip(a.how, AR_HOW_CLS[a.how] || "ar-none"))))]),
        f.access_total > f.access.length ? h("p", { class: "muted small" }, "The first " + f.access.length + "; the CSV has all " + f.access_total + ".") : null) },
      { label: "Can change", num: true, cell: f => h("span", { "data-sort": f.can_change }, arNum(f.can_change)) }], rows)
      : h("p", { class: "muted" }, "No folder matches."));
  };
  find.addEventListener("input", draw);
  onlyEv.addEventListener("change", draw);
  draw();
  return h("section", { class: "ar-card ar-own" }, h("h2", null, "Permissions & ownership, one row per folder"),
    h("p", { class: "muted small" }, "Owner and department as confirmed" + ((r.spec.options || {}).tags === "with_suggested" ? " or suggested (draft)" : "")
      + "; the NTFS owner as the file server says. \u201cGiven here\u201d: set on the folder itself; \u201cinherited\u201d: from the folder above."),
    h("div", { class: "ar-tools ar-noprint" }, find, h("label", { class: "small" }, onlyEv, " only folders Everyone-type groups can get in")),
    box, o.more ? h("p", { class: "muted small" }, "The first " + arNum(o.folders.length) + " of " + arNum(o.total) + " folders; the folders CSV has every one.") : null,
    arOrphanList(r, o));
}

function arOrphanList(r, o) {
  const list = o.orphans || [];
  return h("div", { class: "ar-orphans" }, h("h3", null, "Orphaned SIDs, listed apart"),
    h("p", { class: "muted small" }, "Accounts that no longer exist: Windows shows only their SID. They are kept out of the lists above; each is listed once here with the folders it is on."),
    list.length ? [table([{ label: "Orphaned SID", cell: x => h("span", { class: "mono small" }, x.sid) },
      { label: "Folders", num: true, cell: x => h("strong", { "data-sort": x.folders }, arNum(x.folders)) },
      { label: "Highest level", cell: x => x.level ? (AR_LEVEL_TEXT[x.level] || x.level) : "Deny only" },
      { label: "Given here \u00b7 inherited", cell: x => arNum(x.explicit) + " \u00b7 " + arNum(x.inherited) },
      { label: "Some of its folders", cell: x => h("span", { class: "mono small" }, (x.some_folders || []).join(", ")) }], list),
      h("button", { type: "button", class: "btn btn-quiet ar-sm", on: { click: async e => {
        try { await downloadFile("/admin/access/reports/" + encodeURIComponent(r.id) + "/csv?what=orphans", "access-orphaned-sids.csv"); }
        catch (err) { e.currentTarget.textContent = err.message; } } } }, "\u2b07 CSV of every orphaned SID")]
      : h("p", { class: "muted small" }, "\u2714 No orphaned SIDs in this report."),
    o.orphans_more ? h("p", { class: "muted small" }, "The first 500; the CSV has them all.") : null);
}

function arByOwner(r, res) {
  return (res.owners_view || []).map(d => h("section", { class: "ar-card ar-dept" },
    h("h2", null, d.department === "(no department yet)" ? h("em", null, "No department yet") : d.department),
    h("p", { class: "muted small" }, arCount(d.folders, "folder") + " \u00b7 " + arCount(d.owner_count, "owner") + " \u00b7 " + arCount(d.findings, "finding")),
    d.owners.map(o => h("details", { class: "ar-person", open: d.owners.length <= 3 ? true : null },
      h("summary", null, o.owner === "(no owner yet)" ? h("em", null, "No owner yet") : h("span", { class: "mono" }, o.owner), " ",
        o.owner_kind ? arChip(AR_OWNER_KIND[o.owner_kind], "ar-rule") : null, " ",
        h("span", { class: "small muted" }, arCount(o.folders, "folder") + " \u00b7 " + arCount(o.findings, "finding")),
        o.broad_write ? arChip(arCount(o.broad_write, "folder") + " Everyone can change", "ar-w") : null),
      table([{ label: "Folder", cell: f => h("span", { class: "mono small" }, f.folder) },
        { label: "NTFS owner", cell: f => f.ntfs_owner ? h("span", { class: "mono small" }, f.ntfs_owner) : "" },
        { label: "Team", cell: f => f.team || "" }, { label: "Application", cell: f => f.application || "" },
        { label: "Accounts", num: true, cell: f => h("span", { "data-sort": f.accounts }, arNum(f.accounts)) },
        { label: "Findings", num: true, cell: f => h("strong", { "data-sort": f.findings }, arNum(f.findings)) },
        { label: "Risk", cell: f => [f.broad_write ? arChip("Everyone can change", "ar-w") : null, f.explicit_user ? arChip("People given rights directly", "ar-ai-mid") : null,
          f.orphan ? arChip("Orphaned", "ar-ai-mid") : null, f.full_nonadmin ? arChip("Full control", "ar-ai-mid") : null] }], o.list),
      o.folders > o.list.length ? h("p", { class: "muted small" }, "The first " + o.list.length + " of " + o.folders + " folders.") : null)),
    d.owners_total > d.owners.length ? h("p", { class: "muted small" }, "The first " + d.owners.length + " of " + d.owners_total + " owners.") : null));
}

/* ---- r122: access by department ------------------------------------------------------------ */

const AR_NODEPT = "(department not in the file)";
const arCount = (n, one, many) => arNum(n) + " " + (Number(n) === 1 ? one : (many || one + "s"));

function arHow(f) {
  return [f.direct ? arChip("directly", "ar-rule") : null, ...(f.via || []).map(g => h("span", { class: "mono small ar-via" }, "via " + g))];
}

function arDepartments(r, res) {
  const dv = res.department_view;
  const find = h("input", { type: "search", placeholder: "Find a person (name or account)", "aria-label": "Find a person" });
  const box = h("div", { class: "ar-depts" });
  const draw = () => {
    const q = find.value.trim().toLowerCase();
    const match = p => !q || [p.account, p.display_name, p.title].some(x => (x || "").toLowerCase().includes(q));
    const blocks = dv.view.map((d, di) => {
      const ppl = d.list.filter(match);
      if (q && !ppl.length) return null;
      const meta = (res.departments || []).find(x => x.name === d.department) || {};
      return h("details", { class: "ar-dept", open: q || di === 0 ? true : null },
        h("summary", null, h("span", { class: "ar-dept-n" }, d.department === AR_NODEPT ? h("em", null, "Department not in the file") : "\ud83c\udfe2 " + d.department),
          h("span", { class: "muted small" }, arCount(d.people, "person", "people") + " \u00b7 " + arCount(meta.shares, "share") + " \u00b7 "
            + arCount(meta.folders, "folder") + " \u00b7 " + arNum(meta.can_change) + " can change data"),
          meta.outside_people ? arChip(arNum(meta.outside_people) + " outside their department", "ar-w") : null),
        ppl.map(p => h("details", { class: "ar-person", open: q ? true : null },
          h("summary", null, h("span", { class: "mono" }, "\ud83d\udc64 " + p.account),
            p.display_name ? h("span", null, p.display_name) : null, p.title ? h("span", { class: "muted small" }, "\u00b7 " + p.title) : null,
            h("span", { class: "muted small" }, "\u2014 " + arNum(p.shares) + " share" + (p.shares === 1 ? "" : "s") + ", " + arNum(p.folders)
              + " folder" + (p.folders === 1 ? "" : "s") + " \u00b7 highest " + (AR_LEVEL_TEXT[p.worst] || p.worst)),
            p.dept_conflicts ? arChip("also listed in " + p.dept_conflicts, "ar-ai-low") : null),
          h("table", { class: "ar-pf no-enh" }, h("tbody", null, p.share_list.map(sh => [
            h("tr", { class: "ar-pf-share" }, h("td", { colspan: 4 }, h("strong", { class: "mono" }, "\ud83d\udcc1 " + sh.share),
              h("span", { class: "muted small" }, "  " + (AR_LEVEL_TEXT[sh.level] || sh.level) + " at most"))),
            ...sh.folders.map(f => h("tr", { class: f.outside ? "ar-out" : null },
              h("td", { class: "mono small" }, f.folder), h("td", null, AR_LEVEL_TEXT[f.level] || f.level), h("td", null, arHow(f)),
              h("td", { class: "small" }, f.team ? [(f.application ? f.application + " \u00b7 " : "") + f.team,
                f.outside ? arChip("owned by another team", "ar-w") : null] : h("span", { class: "muted" }, "not tagged"))))]).flat())))),
        d.people > d.shown && !q ? h("p", { class: "muted small" }, "The " + arNum(d.shown) + " people with the most folders shown; the CSV has all " + arNum(d.people) + ".") : null);
    }).filter(Boolean);
    arPut(box, blocks.length ? blocks : h("p", { class: "muted" }, "Nobody matches \u201c" + find.value + "\u201d."));
  };
  find.addEventListener("input", draw);
  draw();
  return [
    h("section", { class: "ar-card" }, h("div", { class: "ar-tools" }, h("h2", null, "Departments, their people and what they reach"), find),
      h("p", { class: "muted small" }, "Each person once, under their department; each folder once per person, with the highest access and every way in "
        + "(directly, or through which groups, nested groups opened up). Folders are the ones tagged (the tag depth): what is below a folder "
        + "is counted in it. Everyone-type groups are not opened."), box),
    h("section", { class: "ar-card" }, h("h2", null, "Access from outside the owning department (" + arNum(dv.outside_total) + ")"),
      h("p", { class: "muted small" }, "People who can change data in a folder whose confirmed owning team is not their department (names compared exactly)."),
      dv.outside.length ? table([{ label: "Person", cell: x => h("span", { class: "mono small" }, x.account) }, { label: "Their department", cell: x => x.dept },
        { label: "Folder", cell: x => h("span", { class: "mono small" }, x.folder) }, { label: "Owning team", cell: x => x.team },
        { label: "Access", cell: x => AR_LEVEL_TEXT[x.level] || x.level }, { label: "How", cell: arHow }], dv.outside)
        : h("p", { class: "muted" }, "None: everyone who can change a tagged folder is in its owning team.")),
    h("section", { class: "ar-card" }, h("h2", null, "Departments"), table([
      { label: "Department", cell: x => x.name === AR_NODEPT ? h("em", null, "Not in the file") : x.name },
      { label: "People", num: true, cell: x => h("strong", { "data-sort": x.people }, arNum(x.people)) },
      { label: "Shares", num: true, cell: x => h("span", { "data-sort": x.shares }, arNum(x.shares)) },
      { label: "Folders", num: true, cell: x => h("span", { "data-sort": x.folders }, arNum(x.folders)) },
      { label: "Can change data", num: true, cell: x => h("span", { "data-sort": x.can_change }, arNum(x.can_change)) },
      { label: "Outside their department", num: true, cell: x => h("span", { "data-sort": x.outside_people }, arNum(x.outside_people)) }], res.departments))];
}

/* ---- r123: the access scanner on the file servers ----------------------------------------------- */

const AR_SCAN_STATE = { queued: "Waiting for the server", started: "Started", running: "Scanning", uploading: "Sending the file",
  importing: "Reading the file", done: "Done", failed: "Failed", cancelled: "Stopped" };

function arScanners() {
  const box = h("section", { class: "ar-card ar-scan" }, h("h2", null, "\ud83d\udda5\ufe0f File-server scanners"), h("p", { class: "muted small" }, "Loading\u2026"));
  let data = null, openFor = null, timer = null;
  const load = async () => {
    if (!document.body.contains(box) && data) { clearInterval(timer); return; }
    try { data = await api("/admin/access/scanners"); }
    catch (e) { if (e instanceof StaleRoute) return; arPut(box, h("h2", null, "\ud83d\udda5\ufe0f File-server scanners"), h("p", { class: "muted small" }, e.message)); return; }
    draw();
  };
  const active = () => (data.scans || []).some(x => ["queued", "started", "running", "uploading", "importing"].includes(x.state));
  const form = sc => {
    const info = sc.share_info || {};
    const last = sc.state_options || {};
    const lastShares = (last.shares || []).map(x => x.toLowerCase());
    const picks = (sc.shares || []).map(n => {
      const cb = h("input", { type: "checkbox", checked: !lastShares.length || lastShares.includes(n.toLowerCase()), "aria-label": "Scan " + n });
      cb._n = n; return cb;
    });
    const depth = h("select", { "aria-label": "Folder levels read in full" }, [0, 1, 2, 3, 4, 5, 6].map(n => h("option", { value: String(n) },
      n === 0 ? "the share only" : n === 1 ? "1 level (recommended)" : n + " levels")));
    depth.value = String(last.depth != null ? last.depth : 1);
    const full = h("input", { type: "checkbox", checked: !sc.has_picture, disabled: !sc.has_picture, "aria-label": "Full scan" });
    const deeper = h("select", { "aria-label": "Deeper, where permissions change" }, [[0, "no"], [8, "to 8 levels"], [16, "to 16 levels"], [32, "to 32 levels"]].map(([v, l]) => h("option", { value: String(v) }, l)));
    deeper.value = String([0, 8, 16, 32].includes(last.max_depth) ? last.max_depth : 16);
    const mem = h("input", { type: "checkbox", checked: true });
    const msg = h("p", { class: "small", role: "status" });
    const go = h("button", { type: "button", class: "btn", on: { click: async () => {
      const shares = picks.filter(x => x.checked).map(x => x._n);
      if (picks.length && !shares.length) { msg.textContent = "Tick at least one share."; return; }
      go.disabled = true; msg.textContent = "";
      try {
        await apiPost("/admin/access/scans", { host_id: sc.host_id, shares: shares.length === picks.length ? [] : shares, depth: Number(depth.value),
          max_depth: Math.max(Number(depth.value), Number(deeper.value) || Number(depth.value)), members: mem.checked, full: full.checked });
        openFor = null; await load();
      } catch (e) { msg.textContent = e.message; go.disabled = false; }
    } } }, "Start the scan");
    const setAll = v => () => picks.forEach(cb => { cb.checked = v; });
    return h("div", { class: "ar-scan-form" },
      picks.length ? [h("div", { class: "ar-tools" }, h("div", { class: "small" }, "Shares on " + sc.hostname + " (as its last scan or -Register said)"),
          h("span", null, h("button", { type: "button", class: "btn-link ar-sm", on: { click: setAll(true) } }, "All"), " \u00b7 ",
            h("button", { type: "button", class: "btn-link ar-sm", on: { click: setAll(false) } }, "None"))),
        h("div", { class: "ar-pick" }, picks.map(cb => h("label", { class: "ar-pick-i" }, cb, " ", cb._n,
          (info[cb._n] || {}).scanned_at ? h("span", { class: "muted small" }, " \u00b7 scanned " + timeAgo(info[cb._n].scanned_at)) : null)))]
        : h("p", { class: "muted small" }, "Every share on the server (run access-scan.ps1 -Register there to pick shares here)."),
      h("div", { class: "ar-up-row" }, h("label", { class: "ar-lab" }, "Every folder, ", depth, " below each share"),
        h("label", { class: "ar-lab" }, "deeper, only where permissions change: ", deeper)),
      h("label", { class: "ar-pick-i" }, mem, " Read group members and people (department, enabled, last logon) from Active Directory"),
      h("label", { class: "ar-pick-i" }, full, sc.has_picture ? " Full scan: send every folder again (otherwise only the changes since the last scan)"
        : " Full scan (the first scan of a server is always full; after it, only the changes are sent)"),
      h("p", { class: "muted small" }, "Folders only: files are never read. Every folder is read on the server; a folder that only inherits "
        + "is the same as the folder above it, so it is listed only down to the levels chosen. Changing the shares or the levels makes the next scan full."),
      h("div", { class: "ar-actions" }, go, h("button", { type: "button", class: "btn btn-quiet", on: { click: () => { openFor = null; draw(); } } }, "Cancel"), msg));
  };
  const draw = () => {
    const scs = data.scanners || [], scans = data.scans || [];
    arPut(box, h("div", { class: "ar-tools" }, h("h2", null, "\ud83d\udda5\ufe0f File-server scanners"),
        h("details", { class: "ar-howto" }, h("summary", null, "How to add a file server"),
          h("ol", { class: "small" },
            h("li", null, "Copy ", h("code", null, "access-scan.ps1"), " (in the package, agent\\windows) to ", h("code", null, "C:\\Program Files\\PatchAgent\\"), " on that server only."),
            h("li", null, "As an administrator: ", h("code", null, "access-scan.ps1 -SelfTest"), " \u2014 every step must say ok."),
            h("li", null, h("code", null, "access-scan.ps1 -Register"), " \u2014 the server appears here."),
            h("li", null, "Scan from here (agent 1.10.0-win), or on the server: ", h("code", null, "access-scan.ps1 -Upload"), ", or from Task Scheduler as SYSTEM.")))),
      h("p", { class: "muted small" }, "The scanner reads the shares, the folders' permissions (never files) and, from Active Directory, the members of each group and each "
        + "person's department. Its file has exact columns: nothing to map, it goes straight to the owners & departments step. It only reads. "
        + "After the first scan, only what changed is sent, and PATCH-01 keeps the complete picture."),
      scs.length ? h("div", { class: "table-wrap" }, h("table", { class: "no-enh ar-scan-t" },
        h("thead", null, h("tr", null, ["Server", "Scanner", "Agent", "Shares", "Picture in PATCH-01", "Last seen", ""].map(x => h("th", { scope: "col" }, x)))),
        h("tbody", null, scs.map(sc => {
          const ok = /^1\.(1\d|[2-9]\d)\.\d+-win$|^[2-9]\.\d+\.\d+-win$/.test(sc.agent_version || "");
          return [h("tr", null, h("td", null, h("strong", null, sc.hostname)), h("td", null, sc.version),
            h("td", null, ok ? sc.agent_version : [sc.agent_version || "?", " ", arChip("1.10.0-win starts scans", "ar-ai-low")]),
            h("td", { class: "small" }, (sc.shares || []).join(", ") || h("span", { class: "muted" }, "none")),
            h("td", { class: "small" }, sc.has_picture ? [arNum(sc.picture_folders) + " folders, " + timeAgo(sc.state_at),
              sc.full_next ? h("div", null, arChip("next scan: full", "ar-ai-mid")) : null] : h("span", { class: "muted" }, "none yet: the first scan is full")),
            h("td", null, timeAgo(sc.last_seen)),
            h("td", null, ok ? h("button", { type: "button", class: "btn ar-sm", on: { click: () => { openFor = openFor === sc.host_id ? null : sc.host_id; draw(); } } }, "Scan now")
              : h("span", { class: "muted small" }, "run access-scan.ps1 -Upload there"))),
            openFor === sc.host_id ? h("tr", null, h("td", { colspan: 7 }, form(sc))) : null];
        }).flat())))
        : h("p", { class: "muted" }, "No file server has the scanner yet: see \u201cHow to add a file server\u201d."),
      scans.length ? [h("h3", null, "Scans"), table([
        { label: "Server", cell: x => x.hostname },
        { label: "State", cell: x => arChip(AR_SCAN_STATE[x.state] || x.state, x.state === "done" ? "ar-ok" : x.state === "failed" ? "ar-no" : "ar-ai-mid") },
        { label: "Kind", cell: x => x.mode === "delta" ? [arChip("Changes only", "ar-rule"), x.changes ? h("div", { class: "small muted" },
            arNum(x.changes.changed) + " changed or new \u00b7 " + arNum(x.changes.gone) + " removed") : null]
          : x.mode === "full" ? arChip("Full", "ar-none") : "" },
        { label: "Progress", cell: x => x.error ? h("span", { class: "ar-fail small" }, x.error)
          : x.state === "cancelled" ? h("span", { class: "small muted" }, x.note || "stopped")
          : h("span", { class: "small" }, [x.stage || "", x.progress && x.progress.folders ? " \u00b7 " + arNum(x.progress.folders) + " folders" : "",
            x.progress && x.progress.errors ? " \u00b7 " + arNum(x.progress.errors) + " not readable" : "",
            ["started", "running", "uploading"].includes(x.state) && x.updated_at ? " \u00b7 last word " + timeAgo(x.updated_at) : ""].join("")) },
        { label: "Asked", cell: x => h("span", { title: x.requested_at }, timeAgo(x.requested_at) + " by " + x.requested_by) },
        { label: "", cell: x => x.dataset_id && x.state === "done" ? h("a", { href: "#/access-review?ds=" + encodeURIComponent(x.dataset_id) + "&step=tags" }, "Open \u2192")
          : ["queued", "started", "running", "uploading"].includes(x.state) ? h("button", { type: "button", class: "btn-link ar-sm",
            title: x.state === "queued" ? "The server will not start it" : "Marked stopped now; the scanner stops within 30 seconds and its file is not taken",
            on: { click: async e => { const b = e.currentTarget; b.disabled = true;
              try { await apiPost("/admin/access/scans/" + x.id + "/cancel", {}); load(); } catch (err) { b.textContent = err.message; } } } },
            x.state === "queued" ? "Cancel" : "Stop") : "" }],
        scans.slice(0, 15))] : null);
  };
  load();
  timer = setInterval(() => { if (!document.body.contains(box)) { clearInterval(timer); return; } if (data && active() && !openFor) load(); }, 5000);
  return box;
}

function arScanBanner(d) {
  const se = d.scan_errors || {}, sc = se.scan || {};
  const items = se.items || [];
  return h("section", { class: "ar-card ar-scanned" },
    h("p", null, "\ud83d\udda5\ufe0f From the access scanner on ", h("strong", null, sc.server || "?"), sc.domain ? " (" + sc.domain + ")" : "",
      ": " + arCount(sc.shares || 0, "share") + ", " + arNum((sc.counts || {}).folders_listed) + " folders listed of " + arNum((sc.counts || {}).folders) + " read",
      sc.finished ? ", finished " + fmtDateTime(sc.finished) : "", ". Columns exact: nothing to map."),
    se.total ? h("details", null, h("summary", { class: "ar-fail" }, arNum(se.total) + " folder" + (se.total === 1 ? "" : "s") + " could not be read"),
      h("ul", { class: "small mono" }, items.slice(0, 200).map(e => h("li", null, e.path + " \u2014 " + e.error))),
      se.total > items.length ? h("p", { class: "muted small" }, "The first " + arNum(items.length) + " shown.") : null) : null);
}

function arSharesCard(res) {
  return h("section", { class: "ar-card" }, h("h2", null, "Shares and their own permissions"),
    h("p", { class: "muted small" }, "What the share itself allows; the folder permissions above apply inside it (the stricter of the two wins)."),
    table([{ label: "Share", cell: x => h("span", { class: "mono small" }, x.unc || x.name) }, { label: "Folder", cell: x => h("span", { class: "mono small" }, x.path || "") },
      { label: "Description", cell: x => x.description || "" },
      { label: "Share permissions", cell: x => x.access ? x.access.map(a => h("div", { class: "small" }, (a.type === "Deny" ? "Deny " : "") + a.right + " \u2014 " + a.account))
        : h("span", { class: "muted" }, "not read") }], res.shares));
}
