"""Access review (r127): last year's mapping workbook, used for this year's folders.

The admin uploads the workbook used last time: xlsx, xls or csv, with as many sheets as it has (share information,
ownership, departments, ...). Nothing in it is guessed:

1. Every sheet is read (header row found, cells cleaned as for the permission reports).
2. Each column is said to hold a folder path, a server, a share, a folder below the share, a folder on the server's
   disk, a business owner, an owner's e-mail, a department, a team or an application, or nothing, and why: its name
   ("the column is called Data Owner"), or what its values are ("9 of 10 values are paths like \\\\FS01\\Finance").
   AI-01 is asked only about the columns the rules cannot place, and what it says is checked against the values
   (a column it calls a path must hold paths). The admin confirms the columns before anything is used.
3. Sheets are joined only where one sheet's column values are found in a column of another sheet that holds each
   value once (a lookup table), shown with the numbers ("37 of 40 values").
4. Each row is matched to this scan's folders: the exact path, or server + share (+ the folder below it), or the
   folder on the server's disk through the share it is under. Matching is exact (case aside). A share name on two
   servers with no server written is ambiguous, never picked.
5. The owner is matched to an account by account name, e-mail or display name, exactly, among the people and groups
   of this scan. When no account matches, the owner is kept as written, and said so.
6. Rows that say different things of the same folder are a conflict: that field is not used, both are shown.
7. Every row keeps its outcome. Applying writes the folders matched as suggestions (suggested by "last year's
   mapping", with the sheet and row as evidence); confirmed and rejected tags are never changed.
"""
import csv
import io
import json
import re

from .perm_review import (PermError, LEVELS, Cleaner, bulk_insert, clean_cell, ident_key, identity_kind, norm_identity,
                          resolve_tags)

MAX_SHEETS, MAX_ROWS, MAX_COLS, MAX_BYTES = 60, 200_000, 120, 60 * 1024 * 1024
SURE = 80

ROLES = [
    ("folder", "Folder path", "The folder's full path: \\\\server\\share\\folder, or D:\\Shares\\Finance"),
    ("server", "Server", "The file server's name"),
    ("share", "Share", "The share's name"),
    ("subfolder", "Folder below the share", "The folder's path below the share: Finance\\Ledger"),
    ("local_path", "Folder on the server's disk", "The folder on the server itself: D:\\Shares\\Finance"),
    ("owner", "Business owner", "The person or team accountable: jsmith, CORP\\jsmith, John Smith, or a group"),
    ("owner_email", "Owner's e-mail", "The business owner's e-mail address"),
    ("department", "Department", "The department the folder belongs to"),
    ("team", "Owning team", "The team that owns or supports it"),
    ("application", "Application", "The business application it serves"),
]
ROLE_TEXT = {k: t for k, t, _ in ROLES}
LOCATION = ("folder", "share", "local_path")
VALUES = ("owner", "owner_email", "department", "team", "application")

# Column names as people write them (lower case, letters and digits only). A name in two lists is not used by name.
SYNONYMS = {
    "folder": ["path", "folderpath", "fullpath", "uncpath", "unc", "networkpath", "folder", "directory", "directorypath",
               "location", "dfspath", "sharepath", "fullsharepath", "foldername", "pfad", "ordner", "chemin", "dossier", "ruta"],
    "server": ["server", "servername", "fileserver", "host", "hostname", "computer", "computername", "nas", "filer",
               "machine", "device"],
    "share": ["share", "sharename", "sharedfolder", "netshare", "freigabe", "partage"],
    "subfolder": ["subfolder", "subfolders", "relativepath", "subpath", "pathbelowshare", "subdirectory"],
    "local_path": ["localpath", "sharelocalpath", "diskpath", "physicalpath", "sharerootpath", "rootpath", "localfolder",
                   "drivepath", "serverpath"],
    "owner": ["owner", "dataowner", "businessowner", "folderowner", "shareowner", "approver", "custodian", "responsible",
              "accountable", "ownername", "primaryowner", "owneraccount", "ownerid", "ownerusername", "datacustodian",
              "besitzer", "verantwortlich", "proprietaire"],
    "owner_email": ["owneremail", "ownermail", "owneremailaddress", "email", "mail", "emailaddress", "contactemail"],
    "department": ["department", "dept", "businessunit", "bu", "division", "orgunit", "organisation", "organization",
                   "function", "abteilung", "departement", "departamento"],
    "team": ["team", "owningteam", "supportteam", "ownerteam", "teamname", "resolvergroup", "assignmentgroup"],
    "application": ["application", "app", "appname", "applicationname", "system", "service", "businessapplication",
                    "anwendung"],
}
_BY_NAME = {}
for _r, _names in SYNONYMS.items():
    for _n in _names:
        _BY_NAME.setdefault(_n, []).append(_r)

UNC_RE = re.compile(r"^\\\\[^\\/\s]+\\[^\\/]+")
LOCAL_RE = re.compile(r"^[A-Za-z]:\\")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")
ACCOUNT_RE = re.compile(r"^[A-Za-z0-9._-]{1,30}\\[^\\\s]{1,64}$")
HOST_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9.-]{0,62}$")


def _norm_header(h):
    return re.sub(r"[^a-z0-9]", "", (h or "").lower())


def _path(v):
    """A path as written -> one form: backslashes, no quotes, no doubled or trailing backslash."""
    t = (v or "").strip().strip('"').strip("'").strip().replace("/", "\\")
    if t.startswith("\\\\"):
        t = "\\\\" + re.sub(r"\\{2,}", r"\\", t[2:])
    else:
        t = re.sub(r"\\{2,}", r"\\", t)
    if len(t) > 3 or t.startswith("\\\\"):
        t = t.rstrip("\\")
    return t


def _shape(values):
    """What the values of a column look like: {kind: share of the non-empty values}."""
    vals = [v for v in values if v][:200]
    if not vals:
        return {}, 0
    n = len(vals)
    c = {"unc": sum(1 for v in vals if UNC_RE.match(_path(v))), "local": sum(1 for v in vals if LOCAL_RE.match(_path(v))),
         "email": sum(1 for v in vals if EMAIL_RE.match(v.strip())), "account": sum(1 for v in vals if ACCOUNT_RE.match(v.strip())),
         "host": sum(1 for v in vals if HOST_RE.match(v.strip()) and not v.strip().isdigit()),
         "number": sum(1 for v in vals if re.fullmatch(r"[\d\s.,:/+-]+(T[\d:.]+Z?)?", v.strip()))}
    return {k: x / n for k, x in c.items()}, n


def _ex(values, pred):
    for v in values:
        if v and pred(v):
            return v[:60]
    return ""


def rule_roles(headers, rows):
    """{role: (col, why)} from the column names, then from the values; each column for one role at most."""
    cols = list(range(min(len(headers), MAX_COLS)))
    values = {i: [(r[i] if i < len(r) else "").strip() for r in rows] for i in cols}
    out, used = {}, set()
    for i in cols:                                        # by name: only a name that means one thing
        rs = _BY_NAME.get(_norm_header(headers[i]), [])
        if len(rs) != 1 or rs[0] in out:
            continue
        r = rs[0]
        shape, n = _shape(values[i])
        if r == "folder" and n and shape.get("unc", 0) + shape.get("local", 0) < 0.6:
            continue                                      # "Folder" holding names, not paths: not a path column
        if r == "local_path" and n and shape.get("local", 0) < 0.6:
            continue
        if r == "owner_email" and n and shape.get("email", 0) < 0.6:
            continue
        out[r] = (i, f'the column is called "{headers[i]}"')
        used.add(i)
    for i in cols:                                        # by the values
        if i in used:
            continue
        shape, n = _shape(values[i])
        if n < 2:
            continue
        if "folder" not in out and shape.get("unc", 0) >= 0.6:
            out["folder"] = (i, f"{round(shape['unc'] * n)} of {n} values are paths like {_ex(values[i], lambda v: UNC_RE.match(_path(v)))}")
            used.add(i)
        elif "folder" not in out and "local_path" not in out and shape.get("local", 0) >= 0.6:
            out["local_path"] = (i, f"{round(shape['local'] * n)} of {n} values are folders on a disk, like "
                                    f"{_ex(values[i], lambda v: LOCAL_RE.match(_path(v)))}")
            used.add(i)
        elif "owner_email" not in out and shape.get("email", 0) >= 0.6:
            out["owner_email"] = (i, f"{round(shape['email'] * n)} of {n} values are e-mail addresses")
            used.add(i)
    return out


def ai_messages(headers, rows, have):
    """The columns the rules left, with a few sample values: fewer and shorter for a wide sheet, so the question
    fits AI-01's slot whole (never cut)."""
    def build(nv, ln):
        cols = []
        for i, h in enumerate(headers[:MAX_COLS]):
            if i in have:
                continue
            vals = []
            for r in rows:
                v = (r[i] if i < len(r) else "").strip()
                if v and v[:ln] not in vals:
                    vals.append(v[:ln])
                if len(vals) >= nv:
                    break
            cols.append({"column": h[:60], "samples": vals})
        return cols
    for nv, ln in ((4, 40), (3, 30), (2, 24), (1, 20), (0, 0)):
        cols = build(nv, ln)
        if len(json.dumps(cols)) <= 7000:
            break
    roles = {k: d for k, _, d in ROLES}
    return [{"role": "system", "content": "You say what each column of a sheet holds, for a file-share ownership mapping. Answer only "
             "with JSON. For each column give one of the fields, or \"none\" when it holds none of them (notes, dates, numbers, "
             "anything else). Never give a field to a column whose values do not hold it. A field for one column at most."},
            {"role": "user", "content": "Fields: " + json.dumps(roles) + "\nColumns with sample values: " + json.dumps(cols)}], cols


def ai_schema(cols):
    return {"type": "object", "properties": {"columns": {"type": "array", "items": {"type": "object", "properties": {
        "column": {"type": "string", "enum": [c["column"] for c in cols]}, "field": {"type": "string", "enum": [k for k, _, _ in ROLES] + ["none"]},
        "reason": {"type": "string"}}, "required": ["column", "field", "reason"]}}}, "required": ["columns"]}


def ai_roles(ai, headers, rows, have):
    """AI-01's word on the columns the rules left, kept only where the values agree."""
    if not ai:
        return {}
    msgs, cols = ai_messages(headers, rows, {c for c, _ in have.values()})
    if not cols:
        return {}
    try:
        out = ai(msgs, ai_schema(cols))
        out = json.loads(out) if isinstance(out, str) else out
    except Exception:  # noqa: BLE001 - AI-01 busy or not there: the rules' roles stand
        return {}
    got = {}
    idx = {h[:60]: i for i, h in enumerate(headers[:MAX_COLS])}
    for it in (out or {}).get("columns") or []:
        f, i = it.get("field"), idx.get(str(it.get("column") or ""))
        if i is None or f not in ROLE_TEXT or f in have or f in got:
            continue
        shape, n = _shape([(r[i] if i < len(r) else "").strip() for r in rows])
        if f == "folder" and shape.get("unc", 0) + shape.get("local", 0) < 0.6:
            continue
        if f == "local_path" and shape.get("local", 0) < 0.6:
            continue
        if f == "owner_email" and shape.get("email", 0) < 0.6:
            continue
        if f in ("department", "team", "application", "owner", "share", "server", "subfolder") and \
                (shape.get("unc", 0) + shape.get("local", 0) >= 0.5 or shape.get("number", 0) >= 0.6):
            continue                                      # paths, dates and numbers are not names
        got[f] = (i, "AI-01: " + clean_cell(str(it.get("reason") or ""))[:160])
    return got


# ---- reading the workbook ----------------------------------------------------------------------------------

def sheets_of(data, file_name):
    """[(name, hidden, rows iterator)] of the file's bytes, whatever its kind."""
    from . import perm_read as rd
    kind = rd.kind_of(data[:65536], file_name)
    base = re.sub(r"\.[A-Za-z0-9]{1,5}$", "", file_name)[:80] or "Sheet"
    if kind == "xlsx":
        try:
            sheets, _ = rd.xlsx_sheets(io.BytesIO(data))
        except Exception as e:  # noqa: BLE001
            raise PermError("The .xlsx could not be opened (" + type(e).__name__ + "). Is it password-protected? Save it again without one.")
        return kind, sheets
    if kind == "xls":
        try:
            sheets, _ = rd.xls_sheets(data)
        except Exception as e:  # noqa: BLE001
            raise PermError("The .xls could not be opened (" + type(e).__name__ + "). Save it again as .xlsx.")
        return kind, sheets
    enc = rd.bom_or_utf16(data[:65536]) or rd.scan_encoding([data])
    if kind == "html":
        dec = rd.decoder_for(enc)
        sheets = rd.html_sheets(dec.decode(data) + dec.decode(b"", final=True), base)
        if not sheets:
            raise PermError("The file is a web page without a table.")
        return kind, sheets
    return "csv", [rd.csv_sheet(base, data[:262144], iter([data[262144:]]) if len(data) > 262144 else iter([]), enc)]


def read(conn, map_id, ai=None):
    """The workbook's sheets -> rows, headers, and each column's role with why. -> state 'review'."""
    from . import perm_read as rd
    m = conn.execute("SELECT file_name, data FROM perm_maps WHERE id = %s", (map_id,)).fetchone()
    data = bytes(m["data"] or b"")
    conn.execute("UPDATE perm_maps SET state = 'reading', error = NULL WHERE id = %s", (map_id,))
    conn.execute("DELETE FROM perm_map_rows WHERE map_id = %s", (map_id,))
    conn.commit()
    kind, sheets = sheets_of(data, m["file_name"])
    clean = Cleaner()
    out = []
    for sheet_no, sh in enumerate(sheets[:MAX_SHEETS]):
        it = iter(sh.rows)
        hdr_i, head = rd.split_head(it)
        headers, batch, n, sample = None, [], 0, []
        ri = 0

        def rows_of():
            yield from head
            yield from it
        for i, row in enumerate(rows_of()):
            if i < hdr_i:
                continue
            if headers is None:
                headers = [clean(c) or f"Column {j + 1}" for j, c in enumerate(row[:MAX_COLS])]
                ri = i + 1
                continue
            ri = i + 1
            cells = [clean(c) for c in row[:MAX_COLS]]
            if not any(cells):
                continue
            n += 1
            if n > MAX_ROWS:
                raise PermError(f"The sheet '{sh.name}' has more than {MAX_ROWS:,} rows: is it the mapping?")
            if len(sample) < 200:
                sample.append(cells)
            batch.append((map_id, sheet_no, ri + getattr(sh, "offset", 0), cells))
            if len(batch) >= 5000:
                bulk_insert(conn, "perm_map_rows", ("map_id", "sheet_no", "rn", "cells"), batch)
                batch = []
        bulk_insert(conn, "perm_map_rows", ("map_id", "sheet_no", "rn", "cells"), batch)
        headers = headers or []
        roles = rule_roles(headers, sample) if n else {}
        if n and ai:
            for r, v in ai_roles(ai, headers, sample[:25], roles).items():
                roles[r] = v
        useful = bool(n and len(headers) >= 1 and roles)
        out.append({"sheet_no": sheet_no, "name": clean_cell(sh.name)[:120] or f"Sheet {sheet_no + 1}", "hidden": bool(sh.hidden),
                    "header_row": hdr_i + 1 + getattr(sh, "offset", 0), "headers": headers, "rows": n, "sample": sample[:8],
                    "roles": {r: c for r, (c, _) in roles.items()}, "why": {r: w for r, (_, w) in roles.items()},
                    "use": useful})
        conn.commit()
    if not any(s["rows"] for s in out):
        raise PermError("No sheet with rows under a header was found in the file.")
    joins = find_joins(conn, map_id, out)
    conn.execute("""UPDATE perm_maps SET state = 'review', file_type = %s, sheets = %s::jsonb, joins = %s::jsonb, data = NULL
                     WHERE id = %s""", (kind, json.dumps(out), json.dumps(joins), map_id))
    conn.commit()


def _distinct(conn, map_id, sheet_no, col):
    vals = {}
    for r in conn.execute("SELECT cells[%s] AS v FROM perm_map_rows WHERE map_id = %s AND sheet_no = %s", (col + 1, map_id, sheet_no)).fetchall():
        v = (r["v"] or "").strip().lower()
        if v:
            vals[v] = vals.get(v, 0) + 1
    return vals


def find_joins(conn, map_id, sheets):
    """Sheets linked by a column: the values of one sheet's column found in a column of another sheet that holds
    each value once. Only those with 60% or more of the values found (and 2 at least), the best per pair of sheets."""
    cand = []
    usable = [s for s in sheets if s["rows"]]
    cache = {}

    def dv(s, c):
        k = (s["sheet_no"], c)
        if k not in cache:
            cache[k] = _distinct(conn, map_id, s["sheet_no"], c)
        return cache[k]
    for a in usable:
        for b in usable:
            if a is b:
                continue
            best = None
            # b is the lookup: it has something a lacks
            # only a sheet that names folders takes from another (its rows are the ones matched to folders); a lookup
            # keyed by an application id is not a list of folders
            if not any(r in a["roles"] for r in LOCATION):
                continue
            gives = [r for r in list(VALUES) + ["server", "share", "local_path"] if r in b["roles"] and r not in a["roles"]]
            if not gives:
                continue
            role_a = {c: r for r, c in a["roles"].items()}
            role_b = {c: r for r, c in b["roles"].items()}
            for ca in range(min(len(a["headers"]), 40)):
                va = dv(a, ca)
                if len(va) < 2 or len(va) > 50000:
                    continue
                for cb in range(min(len(b["headers"]), 40)):
                    if role_b.get(cb) in gives:
                        continue                          # the column it gives is not the key
                    if role_a.get(ca) != role_b.get(cb) and _norm_header(a["headers"][ca]) != _norm_header(b["headers"][cb]):
                        continue                          # a key is the same thing on both sides (a share and a share)
                    vb = dv(b, cb)
                    if len(vb) < 2 or sum(vb.values()) > len(vb) * 1.1:
                        continue                          # a lookup holds each value once
                    hit = sum(1 for v in va if v in vb)
                    if hit >= 2 and hit / len(va) >= 0.6 and (not best or hit / len(va) > best["matched"] / best["of"]):
                        best = {"sheet": a["sheet_no"], "col": ca, "to_sheet": b["sheet_no"], "to_col": cb, "matched": hit, "of": len(va),
                                "gives": gives, "use": True}
            if best:
                cand.append(best)
    # linked both ways: the sheet that holds the owners takes the share information, not the other way round
    by = {s["sheet_no"]: s for s in usable}
    pairs = {(j["sheet"], j["to_sheet"]) for j in cand}
    has_values = lambda s: any(r in s["roles"] for r in VALUES)          # noqa: E731
    return [j for j in cand if not ((j["to_sheet"], j["sheet"]) in pairs and not has_values(by[j["sheet"]])
                                    and has_values(by[j["to_sheet"]]))]


# ---- the admin's word on the columns -------------------------------------------------------------------------

def set_columns(conn, map_id, user, sheets, joins=None, covers=True):
    m = conn.execute("SELECT state, sheets, joins FROM perm_maps WHERE id = %s FOR UPDATE", (map_id,)).fetchone()
    if not m:
        raise PermError("That mapping file is not known.")
    if m["state"] not in ("review", "analysed", "failed") or not m["sheets"]:
        raise PermError("The file is still being read.")
    cur = {s["sheet_no"]: s for s in m["sheets"]}
    for s in sheets or []:
        sh = cur.get(int(s.get("sheet_no", -1)))
        if not sh:
            raise PermError("That sheet is not in the file.")
        roles = {}
        for r, c in (s.get("roles") or {}).items():
            if r not in ROLE_TEXT:
                raise PermError(f"'{r}' is not a field of the mapping.")
            if c is None or c == "":
                continue
            c = int(c)
            if not 0 <= c < len(sh["headers"]):
                raise PermError(f"Sheet {sh['name']}: there is no column {c + 1}.")
            if c in roles.values():
                raise PermError(f"Sheet {sh['name']}: the column \"{sh['headers'][c]}\" is given two fields.")
            roles[r] = c
        why = {r: (sh["why"].get(r) if sh["roles"].get(r) == c else f"chosen by {user}") for r, c in roles.items()}
        sh.update({"roles": roles, "why": why, "use": bool(s.get("use", True)) and bool(roles)})
    js = m["joins"] or []
    if joins is not None:
        on = {(int(j["sheet"]), int(j["to_sheet"])) for j in joins if j.get("use", True)}
        for j in js:
            j["use"] = (j["sheet"], j["to_sheet"]) in on
    conn.execute("""UPDATE perm_maps SET sheets = %s::jsonb, joins = %s::jsonb, covers = %s, confirmed_by = %s WHERE id = %s""",
                 (json.dumps(list(cur.values())), json.dumps(js), bool(covers), user, map_id))


# ---- this scan: its folders, shares, people ------------------------------------------------------------------

class Scan:
    """What a scan (an upload) has, to match the workbook's rows to: exact, case aside."""
    def __init__(self, conn, ds_id):
        self.folders = {}            # folder key -> label
        self.short = {}              # the key with the server's short name -> [keys]
        for r in conn.execute("SELECT folder_key, label, server FROM perm_folders WHERE dataset_id = %s", (ds_id,)).fetchall():
            self.folders[r["folder_key"]] = r["label"] or r["folder_key"]
            self.short.setdefault(self._shortkey(r["folder_key"]), []).append(r["folder_key"])
        self.depth = (conn.execute("SELECT tag_depth FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone() or {}).get("tag_depth") or 1
        self.shares = {}             # share lower -> {server short lower}
        self.local = []              # (server short lower, local path lower, unc lower)
        for k in self.folders:
            p = k.split("\\")
            if k.startswith("\\\\") and len(p) >= 4:
                self.shares.setdefault(p[3], set()).add(p[2].split(".")[0])
        for r in conn.execute("SELECT name, path, unc FROM perm_shares WHERE dataset_id = %s", (ds_id,)).fetchall():
            if r["path"] and r["unc"]:
                u = _path(r["unc"]).lower()
                self.local.append((u.split("\\")[2].split(".")[0], _path(r["path"]).lower().rstrip("\\"), u))
        self.people, self.names, self.mails, self.ids = {}, {}, {}, {}
        for p in conn.execute("""SELECT person_key, person, display_name, email, department, enabled FROM perm_people
                                  WHERE dataset_id = %s""", (ds_id,)).fetchall():
            self.people[p["person_key"]] = p
            for n in {(p["display_name"] or "").strip().lower(), _swap(p["display_name"])}:
                if n:
                    self.names.setdefault(n, set()).add(p["person_key"])
            if p["email"]:
                self.mails[p["email"].strip().lower()] = p["person_key"]
        for r in conn.execute("""SELECT DISTINCT ON (identity_key) identity_key, identity, identity_kind FROM perm_entries
                                  WHERE dataset_id = %s ORDER BY identity_key, identity""", (ds_id,)).fetchall():
            self.ids[r["identity_key"]] = (r["identity"], r["identity_kind"])
        self.depts = {}
        for p in self.people.values():
            if p["department"]:
                self.depts.setdefault(p["department"].strip().lower(), p["department"].strip())

    @staticmethod
    def _shortkey(k):
        if k.startswith("\\\\"):
            p = k.split("\\")
            if len(p) >= 3:
                p[2] = p[2].split(".")[0]
                return "\\".join(p)
        return k

    def find(self, key):
        """A folder key as the workbook writes it -> (key in the scan or None, how)."""
        k = key.lower()
        if k in self.folders:
            return k, None
        ks = self.short.get(self._shortkey(k), [])
        if len(ks) == 1:
            return ks[0], None
        if len(ks) > 1:
            return None, "ambiguous"
        return None, None

    def unit_of(self, key):
        """The folder being tagged that a path is in or is: \\\\fs01\\finance\\ledger\\2019 -> \\\\fs01\\finance\\ledger."""
        p = key.split("\\")
        return "\\".join(p[:4 + self.depth]) if key.startswith("\\\\") else key


def _swap(name):
    """"Smith, John" -> "john smith"."""
    t = (name or "").strip().lower()
    if t.count(",") == 1:
        a, b = [x.strip() for x in t.split(",")]
        if a and b:
            return b + " " + a
    return ""


def owner_of(scan, text, email=None):
    """(account, kind, how, note) for an owner as written: exact matches only."""
    t = (text or "").strip()
    e = (email or "").strip().lower()
    if not t and not e:
        return None, None, None, None
    first = re.split(r"\s*[;\n|]\s*", t)[0] if t else ""
    more = len([x for x in re.split(r"\s*[;\n|]\s*", t) if x.strip()]) - 1 if t else 0
    note = f"{more} more named after it: only the first is the owner" if more > 0 else None

    def person(k, how):
        p = scan.people[k]
        n = note
        if p["enabled"] is False:
            n = "; ".join(x for x in (n, "this account is disabled: they may have left") if x)
        return p["person"], "person", how, n
    cand = [first] if first else []
    for c in cand:
        if EMAIL_RE.match(c) and c.lower() in scan.mails:
            return person(scan.mails[c.lower()], "e-mail")
        if identity_kind(norm_identity(c))[0] in ("admin", "system", "broad", "orphan"):
            return None, None, None, f"'{c}' is an admin, system, Everyone-type or orphaned account: never the business owner"
        k = ident_key(norm_identity(c))
        if k in scan.people and (("\\" in c) or ("@" in c) or re.fullmatch(r"[A-Za-z0-9._-]+", c)):
            return person(k, "account name")
        if k in scan.ids and (("\\" in c) or re.fullmatch(r"[A-Za-z0-9._ -]+", c)):
            ident, kind = scan.ids[k]
            if kind in ("admin", "system", "broad", "orphan"):
                return None, None, None, f"'{c}' is an admin, system, Everyone-type or orphaned account: never the business owner"
            return ident, {"group": "group", "user": "person"}.get(kind), "account name", note
        n = c.strip().lower()
        if n in scan.names or _swap(c) in scan.names:
            keys = scan.names.get(n) or scan.names.get(_swap(c))
            if len(keys) == 1:
                return person(next(iter(keys)), "display name")
            return first, None, None, "; ".join(x for x in (note, f"{len(keys)} people have that name: kept as written") if x)
    if e and e in scan.mails:
        return person(scan.mails[e], "e-mail")
    return first or email, None, None, "; ".join(x for x in (note, "no account of this scan matches it: kept as written") if x)


# ---- the analysis ---------------------------------------------------------------------------------------------

def _cell(cells, c):
    return clean_cell(cells[c]) if c is not None and c < len(cells) else ""


def analyse(conn, map_id, ds_id):
    """Every row of the used sheets -> its outcome; every folder of the scan the workbook speaks of -> what it says."""
    m = conn.execute("SELECT sheets, joins, covers FROM perm_maps WHERE id = %s", (map_id,)).fetchone()
    sheets = {s["sheet_no"]: s for s in m["sheets"] or []}
    scan = Scan(conn, ds_id)
    conn.execute("DELETE FROM perm_map_outcomes WHERE map_id = %s", (map_id,))
    conn.execute("DELETE FROM perm_map_targets WHERE map_id = %s", (map_id,))
    # lookups: (to_sheet, to_col) -> value lower -> [row cells]
    looks = {}
    joins = [j for j in (m["joins"] or []) if j.get("use") and j["sheet"] in sheets and j["to_sheet"] in sheets
             and sheets[j["sheet"]]["use"] and sheets[j["to_sheet"]]["use"]]
    for j in joins:
        if (j["to_sheet"], j["to_col"]) in looks:
            continue
        idx = {}
        for r in conn.execute("SELECT rn, cells FROM perm_map_rows WHERE map_id = %s AND sheet_no = %s", (map_id, j["to_sheet"])).fetchall():
            v = _cell(r["cells"], j["to_col"]).lower()
            if v:
                idx.setdefault(v, []).append((r["rn"], r["cells"]))
        looks[(j["to_sheet"], j["to_col"])] = idx
    outcomes, said = [], {}                # said: folder key -> [(field, value, evidence, how, sheet, rn)]
    covers = []                            # (share root key, fields, evidence, sheet, rn)
    counts = {}

    def put(sh, rn, status, **k):
        counts[status] = counts.get(status, 0) + 1
        outcomes.append((map_id, sh, rn, status, k.get("location"), k.get("folder_key"), k.get("folder"), k.get("how"),
                         k.get("owner_text"), k.get("owner"), k.get("owner_kind"), k.get("owner_how"), k.get("department"),
                         k.get("team"), k.get("application"), (k.get("note") or None) and k["note"][:600]))
    for sh in sheets.values():
        if not sh.get("use"):
            continue
        roles = sh["roles"]
        my_joins = [j for j in joins if j["sheet"] == sh["sheet_no"]]
        for r in conn.execute("SELECT rn, cells FROM perm_map_rows WHERE map_id = %s AND sheet_no = %s ORDER BY rn",
                              (map_id, sh["sheet_no"])).fetchall():
            cells = r["cells"]
            v = {role: _cell(cells, c) for role, c in roles.items()}
            notes, ev_extra = [], []
            for j in my_joins:                             # what the linked sheet adds
                key = _cell(cells, j["col"]).lower()
                hits = looks[(j["to_sheet"], j["to_col"])].get(key) if key else None
                if not hits:
                    continue
                to = sheets[j["to_sheet"]]
                for role, c in to["roles"].items():
                    if v.get(role):
                        continue
                    vals = {_cell(cells2, c) for _, cells2 in hits if _cell(cells2, c)}
                    if len(vals) == 1:
                        v[role] = vals.pop()
                        ev_extra.append(f"{ROLE_TEXT[role].lower()} from sheet '{to['name']}' row {hits[0][0]} "
                                        f"({to['headers'][j['to_col']]} = {_cell(cells, j['col'])})")
                    elif len(vals) > 1:
                        notes.append(f"sheet '{to['name']}' gives {len(vals)} values for {ROLE_TEXT[role].lower()}: not used")
            loc, key, how, why = locate(scan, v)
            fields = {}
            ow, okind, ohow, onote = owner_of(scan, v.get("owner"), v.get("owner_email"))
            if ow:
                fields["owner"] = (ow, okind, ohow)
            if onote:
                notes.append(onote)
            if v.get("department"):
                d = scan.depts.get(v["department"].strip().lower())
                fields["department"] = d or v["department"].strip()
                if not d and scan.depts:
                    notes.append(f"department '{v['department'].strip()}' is not one in Active Directory: kept as written")
            for f in ("team", "application"):
                if v.get(f):
                    fields[f] = v[f].strip()
            base = dict(location=loc, owner_text=v.get("owner") or v.get("owner_email"), owner=ow, owner_kind=okind, owner_how=ohow,
                        department=fields.get("department"), team=fields.get("team"), application=fields.get("application"))
            if not key:
                if not loc:
                    if any(v.get(x) for x in VALUES) and any(j["to_sheet"] == sh["sheet_no"] for j in joins):
                        put(sh["sheet_no"], r["rn"], "lookup", note="used through the sheets linked to it", **base)
                    else:
                        put(sh["sheet_no"], r["rn"], "no_location", note="no folder, share or path on this row", **base)
                else:
                    put(sh["sheet_no"], r["rn"], why[0], note="; ".join([why[1]] + notes), **base)
                continue
            if not fields:
                if any(j["to_sheet"] == sh["sheet_no"] for j in joins):
                    put(sh["sheet_no"], r["rn"], "lookup", folder_key=key, folder=scan.folders.get(key), how=how,
                        note="; ".join(["information for the sheets linked to it"] + notes), **base)
                else:
                    put(sh["sheet_no"], r["rn"], "empty", folder_key=key, folder=scan.folders.get(key), how=how,
                        note="; ".join(["no owner, department, team or application on this row"] + notes), **base)
                continue
            ev = f"sheet '{sh['name']}' row {r['rn']} ({how})" + ("; " + "; ".join(ev_extra) if ev_extra else "")
            conf = 95 if how in ("path", "server and share", "share") else 90
            if ow and not okind:
                conf = min(conf, 75)
            if ow and okind == "person" and onote and "disabled" in onote:
                conf = min(conf, 60)
            if fields.get("department") and scan.depts and fields["department"].lower() not in scan.depts:
                conf = min(conf, 85)
            said.setdefault(key, []).append((fields, ev, conf, sh["sheet_no"], r["rn"]))
            put(sh["sheet_no"], r["rn"], "matched", folder_key=key, folder=scan.folders.get(key), how=how, note="; ".join(notes), **base)
            if m["covers"] and key.count("\\") == 3 and key.startswith("\\\\"):
                covers.append((key, fields, ev, conf))
    # covers: a share's row for its folders that have no row of their own
    for root, fields, ev, conf in covers:
        for k in scan.folders:
            if k.startswith(root + "\\") and k not in said:
                said.setdefault(k, []).append((fields, ev + "; the share's row (the folder has none of its own)", min(conf, 85), None, None))
                counts["covered"] = counts.get("covered", 0) + 1
    bulk_insert(conn, "perm_map_outcomes", ("map_id", "sheet_no", "rn", "status", "location", "folder_key", "folder", "how", "owner_text",
                                            "owner", "owner_kind", "owner_how", "department", "team", "application", "note"), outcomes)
    now = {r["key_l"]: r for r in conn.execute(
        """SELECT t.key_l, t.state, t.owner, t.department, t.team, t.application FROM perm_tags t JOIN perm_folders f
             ON f.folder_key = t.key_l WHERE f.dataset_id = %s""", (ds_id,)).fetchall()}
    targets, conflicts_n = [], 0
    for k, items in said.items():
        direct = [x for x in items if x[3] is not None] or items
        out, conf, conflicts, evid = {}, min(x[2] for x in direct), [], []
        for f in ("owner", "department", "team", "application"):
            vals = {}
            for fields, ev, _, sh_no, rn in direct:
                if f in fields:
                    val = fields[f]
                    key2 = (val[0] if f == "owner" else val).lower()
                    vals.setdefault(key2, (val, ev))
            if len(vals) == 1:
                out[f] = next(iter(vals.values()))[0]
            elif len(vals) > 1:
                conflicts.append(f"{ROLE_TEXT[f if f != 'owner' else 'owner']}: " + " / ".join(
                    f"'{(v[0][0] if f == 'owner' else v[0])}' ({v[1]})" for v in vals.values()))
        for fields, ev, _, _, _ in direct:
            if ev not in evid:
                evid.append(ev)
        if conflicts:
            conflicts_n += 1
        if not out:
            continue
        cur = now.get(k)
        owner = out.get("owner")
        same = None
        if cur and cur["state"] == "confirmed":
            same = all(((owner[0] if f == "owner" else out[f]) or "").lower() == (cur[f] or "").lower() for f in out)
        targets.append((map_id, k, scan.folders.get(k), owner[0] if owner else None, owner[1] if owner else None,
                        out.get("department"), out.get("team"), out.get("application"), conf, "; ".join(evid)[:2000],
                        "; ".join(conflicts)[:2000] or None, cur["state"] if cur else "none", same))
    bulk_insert(conn, "perm_map_targets", ("map_id", "folder_key", "folder", "owner", "owner_kind", "department", "team", "application",
                                           "confidence", "evidence", "conflicts", "now_state", "same_as_now"), targets)
    res = {"rows": sum(counts.values()) - counts.get("covered", 0), "outcomes": counts, "folders": len(targets),
           "folders_in_scan": len(scan.folders), "conflict_folders": conflicts_n,
           "sure": sum(1 for t in targets if t[8] >= SURE and t[11] not in ("confirmed", "rejected")),
           "confirmed_same": sum(1 for t in targets if t[11] == "confirmed" and t[12]),
           "confirmed_different": sum(1 for t in targets if t[11] == "confirmed" and t[12] is False),
           "to_apply": sum(1 for t in targets if t[11] not in ("confirmed", "rejected")),
           "owners": {"accounts": sum(1 for t in targets if t[4]), "as_written": sum(1 for t in targets if t[3] and not t[4])}}
    conn.execute("""UPDATE perm_maps SET state = 'analysed', dataset_id = %s, result = %s::jsonb, analysed_at = now(), error = NULL
                     WHERE id = %s""", (ds_id, json.dumps(res), map_id))
    conn.commit()
    return res


def locate(scan, v):
    """(where the row says as written, folder key in the scan or None, how, (status, why) when not found)."""
    folder, server, share = _path(v.get("folder")), (v.get("server") or "").strip(), (v.get("share") or "").strip().strip("\\")
    sub, local = _path(v.get("subfolder")).strip("\\"), _path(v.get("local_path"))
    srv = server.split(".")[0].lower() if server else ""
    if folder and not UNC_RE.match(folder) and LOCAL_RE.match(folder):
        local, folder = folder, ""
    if folder and UNC_RE.match(folder):
        return _found(scan, folder, folder, "path")
    if share:
        loc = ("\\\\" + server + "\\" if server else "") + share + ("\\" + sub if sub else "")
        if srv:
            return _found(scan, loc, "\\\\" + srv + "\\" + share + ("\\" + sub if sub else ""), "server and share")
        servers = scan.shares.get(share.lower(), set())
        if len(servers) == 1:
            return _found(scan, loc, "\\\\" + next(iter(servers)) + "\\" + share + ("\\" + sub if sub else ""), "share")
        if len(servers) > 1:
            return loc, None, None, ("ambiguous", f"a share named {share} is on {len(servers)} servers and no server is written")
        return loc, None, None, ("no_folder", f"no share named {share} in this scan")
    if local and LOCAL_RE.match(local):
        lp = local.lower()
        cands = [(s, p, u) for s, p, u in scan.local if (not srv or s == srv) and (lp == p or lp.startswith(p + "\\"))]
        best = {}
        for s, p, u in cands:                              # the deepest share it is under, per server
            if s not in best or len(p) > len(best[s][0]):
                best[s] = (p, u)
        if len(best) == 1:
            p, u = next(iter(best.values()))
            return _found(scan, local, u + lp[len(p):], "folder on the server's disk")
        if len(best) > 1:
            return local, None, None, ("ambiguous", f"{local} is under a share on {len(best)} servers and no server is written")
        return local, None, None, ("no_folder", f"{local} is not under a share of this scan" + (f" on {server}" if server else ""))
    if folder:
        return folder, None, None, ("no_folder", f"'{folder}' is not a path (\\\\server\\share\\... or D:\\...)")
    return "", None, None, None


def _found(scan, written, key, how):
    key = _path(key).lower()
    k, amb = scan.find(key)
    if k:
        return written, k, how, None
    if amb:
        return written, None, None, ("ambiguous", f"{written}: the server's name fits more than one server of this scan")
    unit = scan.unit_of(key)
    if unit != key:
        u, _ = scan.find(unit)
        if u:
            return written, None, None, ("below", f"{written} is below {scan.folders[u]}, the folder being tagged: not used "
                                                  "(the owner of a sub-folder is not taken for the folder above it)")
    said = written if _path(written).lower() == key else f"{written} ({key})"
    return written, None, None, ("no_folder", f"{said} is not a folder of this scan (removed, renamed, on the system drive, "
                                              "or not scanned)")


# ---- apply -----------------------------------------------------------------------------------------------------

def apply(conn, map_id, user):
    """The folders matched -> suggestions (suggested by last year's mapping), with their evidence. Confirmed and
    rejected tags stay as they are. Returns how many were written."""
    m = conn.execute("SELECT state, dataset_id::text AS ds FROM perm_maps WHERE id = %s FOR UPDATE", (map_id,)).fetchone()
    if not m or m["state"] != "analysed":
        raise PermError("Analyse the file against a scan first.")
    n = 0
    for t in conn.execute("""SELECT * FROM perm_map_targets WHERE map_id = %s AND now_state NOT IN ('confirmed', 'rejected')""",
                          (map_id,)).fetchall():
        conn.execute("""INSERT INTO perm_tags (key_l, label, owner, owner_kind, department, team, application, state, confidence, reason,
                                               evidence, suggested_by, suggested_at, ai_asked_at)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, 'suggested', %s, %s, %s, 'last_year', now(), now())
                        ON CONFLICT (key_l) DO UPDATE SET
                            owner = coalesce(EXCLUDED.owner, perm_tags.owner),
                            owner_kind = CASE WHEN EXCLUDED.owner IS NOT NULL THEN EXCLUDED.owner_kind ELSE perm_tags.owner_kind END,
                            department = coalesce(EXCLUDED.department, perm_tags.department),
                            team = coalesce(EXCLUDED.team, perm_tags.team),
                            application = coalesce(EXCLUDED.application, perm_tags.application),
                            confidence = EXCLUDED.confidence, reason = EXCLUDED.reason, evidence = EXCLUDED.evidence,
                            suggested_by = 'last_year', suggested_at = now(), ai_asked_at = now()
                        WHERE perm_tags.state = 'suggested'""",
                     (t["folder_key"], t["folder"] or t["folder_key"], t["owner"], t["owner_kind"], t["department"], t["team"],
                      t["application"], t["confidence"], ("Conflicts in the workbook, not used: " + t["conflicts"])[:300] if t["conflicts"] else
                      "From last year's mapping", t["evidence"][:500]))
        n += 1
    conn.execute("UPDATE perm_maps SET applied_by = %s, applied_at = now(), applied = %s WHERE id = %s", (user, n, map_id))
    resolve_tags(conn, m["ds"])
    return n


# ---- views ----------------------------------------------------------------------------------------------------

def maps(conn):
    return conn.execute("""SELECT id::text AS id, file_name, size_bytes, state, error, note, file_type, created_by, created_at,
                                  dataset_id::text AS dataset_id, analysed_at, applied_at, applied, result,
                                  jsonb_array_length(coalesce(sheets, '[]'::jsonb)) AS sheet_count
                             FROM perm_maps ORDER BY created_at DESC LIMIT 50""").fetchall()


def view(conn, map_id):
    m = conn.execute("""SELECT id::text AS id, file_name, size_bytes, state, error, note, file_type, sheets, joins, covers, created_by,
                               created_at, dataset_id::text AS dataset_id, result, analysed_at, applied_by, applied_at, applied, confirmed_by
                          FROM perm_maps WHERE id = %s""", (map_id,)).fetchone()
    if not m:
        raise PermError("That mapping file is not known.")
    m["roles"] = [{"role": k, "text": t, "what": d} for k, t, d in ROLES]
    return m


def outcomes(conn, map_id, status=None, q=None, limit=1000):
    where, args = ["o.map_id = %s"], [map_id]
    if status:
        where.append("o.status = %s")
        args.append(status)
    if q:
        cols = ("o.location", "o.folder", "o.owner_text", "o.owner", "o.department", "o.team", "o.application", "o.note")
        where.append("(" + " OR ".join(f"strpos(lower(coalesce({c}, '')), %s) > 0" for c in cols) + ")")
        args += [q.lower()] * len(cols)
    rows = conn.execute(f"""SELECT o.* FROM perm_map_outcomes o WHERE {' AND '.join(where)} ORDER BY o.sheet_no, o.rn LIMIT %s""",
                        args + [min(int(limit), 5000)]).fetchall()
    targets = conn.execute("""SELECT folder_key, folder, owner, owner_kind, department, team, application, confidence, evidence, conflicts,
                                     now_state, same_as_now FROM perm_map_targets WHERE map_id = %s ORDER BY folder LIMIT 2000""",
                           (map_id,)).fetchall()
    return {"items": rows, "targets": targets}


STATUS_TEXT = {"matched": "Matched", "ambiguous": "Ambiguous", "no_folder": "No such folder in this scan", "below": "Below the folders tagged",
               "empty": "Nothing to use on the row", "no_location": "No folder on the row", "lookup": "Used through a linked sheet"}
OUT_COLS = ["Sheet", "Row", "Where the row says", "Matched folder", "How", "Business owner (as written)", "Owner account",
            "Matched by", "Department", "Owning team", "Application", "Outcome", "Note"]


def outcomes_csv(conn, map_id):
    from .perm_review import safe_csv
    m = view(conn, map_id)
    names = {s["sheet_no"]: s["name"] for s in m["sheets"] or []}
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(OUT_COLS)
    for o in conn.execute("SELECT * FROM perm_map_outcomes WHERE map_id = %s ORDER BY sheet_no, rn", (map_id,)).fetchall():
        w.writerow([safe_csv(x) for x in (names.get(o["sheet_no"], o["sheet_no"]), o["rn"], o["location"] or "", o["folder"] or "", o["how"] or "",
                                          o["owner_text"] or "", o["owner"] if o["owner_kind"] else "", o["owner_how"] or "",
                                          o["department"] or "", o["team"] or "", o["application"] or "",
                                          STATUS_TEXT.get(o["status"], o["status"]), o["note"] or "")])
    return "\ufeff" + buf.getvalue()


def upload(conn, user, file_name, data):
    if not data:
        raise PermError("The file is empty.")
    if len(data) > MAX_BYTES:
        raise PermError("A mapping workbook is at most 60 MB.")
    name = clean_cell(file_name)[:200] or "mapping.xlsx"
    r = conn.execute("""INSERT INTO perm_maps (file_name, size_bytes, data, created_by) VALUES (%s, %s, %s, %s) RETURNING id::text AS id""",
                     (name, len(data), data, user)).fetchone()
    return r["id"]


def ask_analyse(conn, map_id, ds_id):
    m = conn.execute("SELECT state FROM perm_maps WHERE id = %s FOR UPDATE", (map_id,)).fetchone()
    if not m:
        raise PermError("That mapping file is not known.")
    if m["state"] not in ("review", "analysed", "failed"):
        raise PermError("The file is still being read.")
    d = conn.execute("SELECT state FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    if not d or d["state"] != "ready":
        raise PermError("Pick a scan or upload whose rows are ready.")
    conn.execute("UPDATE perm_maps SET state = 'analysing', dataset_id = %s, error = NULL WHERE id = %s", (ds_id, map_id))


def run_once(conn, ai_for):
    """The worker's turn: read uploaded workbooks, analyse the ones asked for. Returns [(what, id)]."""
    did = []
    for m in conn.execute("SELECT id::text AS id, state, dataset_id::text AS ds FROM perm_maps WHERE state IN ('uploaded', 'analysing') "
                          "ORDER BY created_at LIMIT 3").fetchall():
        try:
            if m["state"] == "uploaded":
                read(conn, m["id"], ai_for("map_columns") if ai_for else None)
                did.append(("map_read", m["id"]))
            else:
                analyse(conn, m["id"], m["ds"])
                did.append(("map_analysed", m["id"]))
        except Exception as e:  # noqa: BLE001 - one bad file never stops the others
            conn.rollback()
            msg = str(e) if isinstance(e, PermError) else f"{type(e).__name__}: {e}"
            conn.execute("UPDATE perm_maps SET state = 'failed', error = %s WHERE id = %s", (msg[:600], m["id"]))
            conn.commit()
            did.append(("map_failed", m["id"]))
    return did


__all__ = ["upload", "read", "set_columns", "analyse", "apply", "maps", "view", "outcomes", "outcomes_csv", "run_once",
           "rule_roles", "owner_of", "locate", "LEVELS"]
