<#
.SYNOPSIS
  Install, update or remove the PATCH-01 agent on this Windows server.

.EXAMPLE
  # 1. Check first: nothing is installed or enrolled
  .\install-agent.ps1 -Server https://SGPINFAPPXU01 -Pin <sha256> -SelfTest

  # 2. Install and enrol (the token is single use)
  .\install-agent.ps1 -Server https://SGPINFAPPXU01 -Pin <sha256> -Token <token>

  # Update the agent files only, keeping its enrolment
  .\install-agent.ps1 -Update

  # Remove it
  .\install-agent.ps1 -Uninstall

  Get the pin on PATCH-01 with:  ./scripts/phase10-windows.sh --pin
#>
[CmdletBinding(DefaultParameterSetName = "Install")]
param(
    [Parameter(ParameterSetName = "Install", Mandatory = $true)]
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][string]$Server,
    [Parameter(ParameterSetName = "Install", Mandatory = $true)]
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][string]$Pin,
    [Parameter(ParameterSetName = "Install", Mandatory = $true)][string]$Token,
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][switch]$SelfTest,
    [Parameter(ParameterSetName = "Update", Mandatory = $true)][switch]$Update,
    [Parameter(ParameterSetName = "Uninstall", Mandatory = $true)][switch]$Uninstall
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$InstallDir = Join-Path $env:ProgramFiles "PatchAgent"
$DataDir = Join-Path $env:ProgramData "PatchAgent"
$Agent = Join-Path $InstallDir "patch-agent.ps1"
$TaskName = "PATCH-01 agent"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path

$me = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw "Run PowerShell as administrator." }
if ($PSVersionTable.PSVersion.Major -lt 5) { throw "PowerShell 5.1 is needed (found $($PSVersionTable.PSVersion))." }
if ($Pin -and ($Pin -replace "[:\s]", "") -notmatch "^([0-9a-fA-F]{64}|system)$") { throw "The pin must be the 64-character SHA-256 from phase10-windows.sh --pin, or 'system'." }

function Lock-Folder([string]$Path) {
    # Only SYSTEM and Administrators may read the agent's data (its token lives here)
    if (-not (Test-Path $Path)) { New-Item -ItemType Directory -Path $Path | Out-Null }
    $acl = New-Object Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sid in @("S-1-5-18", "S-1-5-32-544")) {   # SYSTEM, Administrators
        $id = New-Object Security.Principal.SecurityIdentifier($sid)
        $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($id, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")))
    }
    Set-Acl -Path $Path -AclObject $acl
}

function Copy-Agent {
    Lock-Folder $InstallDir
    Copy-Item -Force (Join-Path $Here "patch-agent.ps1") $Agent
    Unblock-File $Agent -ErrorAction SilentlyContinue
}

function Register-AgentTask {
    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument ("-NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"" + $Agent + "`" -Run")
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5)
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
    $settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 4) -StartWhenAvailable -DontStopOnIdleEnd
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
}

switch ($PSCmdlet.ParameterSetName) {
    "SelfTest" {
        & (Join-Path $Here "patch-agent.ps1") -SelfTest -Server $Server -Pin $Pin
    }
    "Install" {
        Copy-Agent
        Lock-Folder $DataDir
        & $Agent -Enroll -Server $Server -Token $Token -Pin $Pin
        Register-AgentTask
        Write-Output "Sending the first inventory (the Windows Update search can take a few minutes)..."
        & $Agent -Inventory
        Write-Output "Installed. The agent runs every 5 minutes as SYSTEM; its log is $DataDir\agent.log"
    }
    "Update" {
        if (-not (Test-Path (Join-Path $DataDir "agent.json"))) { throw "Not installed here; use -Server -Pin -Token." }
        Copy-Agent; Register-AgentTask
        Write-Output "Agent files updated; the enrolment is unchanged."
    }
    "Uninstall" {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
        Remove-Item -Recurse -Force $InstallDir, $DataDir -ErrorAction SilentlyContinue
        Write-Output "Removed. Also remove the server from PATCH-01 (Servers page) if it is being retired."
    }
}
