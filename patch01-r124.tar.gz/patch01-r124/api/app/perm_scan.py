"""Access review (r123): files from the access scanner (access-scan.ps1) on a file server.

The scanner writes one exact format (patch01-access-scan/1: one JSON object per line, gzip), so
nothing is guessed: no column mapping, no AI-01 for the columns. The file becomes the same three
tables a workbook can give (permissions, group members, people), with their columns already set,
and goes straight to "making the rows plain".

Lines: header (first), share, folder (with its entries by SID), group (its members by SID),
identity (each SID: name, kind, and for people department, title, manager, office, e-mail,
enabled, last logon), error (a folder that could not be read), end (last; a file without it was cut).
"""
import gzip
import io
import json
import re

SCHEMA = "patch01-access-scan/1"
MAX_ERRORS_KEPT = 2000
KIND_TYPE = {"user": "User", "group": "Group", "computer": "Computer", "wellknown": "Everyone-type group",
             "system": "System account", "orphan": "Orphaned SID", "unknown": ""}

PERM_HEADERS = ["Path", "Account", "Account type", "Rights", "Access", "Inherited", "Applies to", "Owner", "Server", "SID"]
PERM_MAP = {"path": 0, "identity": 1, "account_type": 2, "rights": 3, "access_type": 4, "inherited": 5, "owner": 7, "server": 8}
MEMBER_HEADERS = ["Group", "Member", "Member type"]
MEMBER_MAP = {"group": 0, "member": 1, "member_type": 2}
PEOPLE_HEADERS = ["User", "Department", "Full name", "Title", "Manager", "Office", "E-mail", "Enabled", "Last logon"]
PEOPLE_MAP = {"person": 0, "department": 1, "display_name": 2, "title": 3, "manager": 4, "location": 5, "email": 6,
              "enabled": 7, "last_logon": 8}


class ScanError(ValueError):
    pass


def is_scan(head):
    """True when the bytes start a scanner file (gzip whose first line is our header)."""
    if not head.startswith(b"\x1f\x8b"):
        return False
    try:
        with gzip.GzipFile(fileobj=io.BytesIO(head)) as g:
            first = g.readline(65536)
    except (OSError, EOFError):
        return False
    try:
        rec = json.loads(first.decode("utf-8-sig"))
    except ValueError:
        return False
    return isinstance(rec, dict) and rec.get("t") == "header" and str(rec.get("schema", "")).startswith("patch01-access-scan/")


def _lines(open_file):
    with gzip.GzipFile(fileobj=open_file()) as g:
        for n, raw in enumerate(io.TextIOWrapper(g, encoding="utf-8-sig", newline="\n")):
            raw = raw.strip()
            if not raw:
                continue
            try:
                rec = json.loads(raw)
            except ValueError:
                raise ScanError(f"line {n + 1} of the scan is not JSON: the file is damaged")
            if not isinstance(rec, dict) or "t" not in rec:
                raise ScanError(f"line {n + 1} of the scan has no record type")
            yield rec


def read_scan(open_file):
    """First pass: everything but the folders (the names come at the end of the file).
    open_file() gives a fresh binary file object each time (the scan is read twice)."""
    out = {"header": None, "shares": [], "groups": {}, "ids": {}, "errors": [], "errors_total": 0, "end": None,
           "folders": 0, "lines": 0}
    for rec in _lines(open_file):
        out["lines"] += 1
        t = rec["t"]
        if out["lines"] == 1:
            if t != "header" or rec.get("schema") != SCHEMA:
                raise ScanError(f"not a {SCHEMA} file (its first line is not the scanner's header)")
            out["header"] = rec
        elif t == "share":
            out["shares"].append(rec)
        elif t == "folder":
            out["folders"] += 1
        elif t == "group":
            out["groups"][rec.get("sid")] = rec
        elif t == "identity":
            out["ids"][rec.get("sid")] = rec
        elif t == "error":
            out["errors_total"] += 1
            if len(out["errors"]) < MAX_ERRORS_KEPT:
                out["errors"].append({"path": str(rec.get("path") or "")[:600], "error": str(rec.get("error") or "")[:300]})
        elif t == "end":
            out["end"] = rec
    if not out["end"]:
        raise ScanError("the scan file is cut: it has no end line (the scan was stopped, or the upload is incomplete). Run the scan again.")
    want = (out["end"].get("counts") or {}).get("lines")
    if isinstance(want, int) and want != out["lines"]:
        raise ScanError(f"the scan file has {out['lines']} lines, its end line says {want}: it is damaged. Run the scan again.")
    return out


def _name(scan, sid):
    rec = scan["ids"].get(sid)
    return (rec.get("name") if rec else None) or sid or ""


def _type(scan, sid):
    rec = scan["ids"].get(sid)
    return KIND_TYPE.get((rec or {}).get("kind", "unknown"), "")


def permission_rows(scan, open_file):
    server = (scan["header"] or {}).get("server") or ""
    yield PERM_HEADERS
    for rec in _lines(open_file):
        if rec["t"] != "folder":
            continue
        path = rec.get("unc") or rec.get("path") or ""
        owner = _name(scan, rec.get("owner")) if rec.get("owner") else ""
        for a in rec.get("aces") or []:
            sid = a.get("sid")
            applies = ", ".join(x for x in (a.get("flags"), a.get("prop")) if x and x != "None")
            yield [path, _name(scan, sid), _type(scan, sid), str(int(a.get("rights") or 0)), "Deny" if a.get("deny") else "Allow",
                   "True" if a.get("inherited") else "False", applies, owner, "" if rec.get("unc") else server, sid or ""]


def member_rows(scan):
    yield MEMBER_HEADERS
    for g in scan["groups"].values():
        gname = _name(scan, g.get("sid"))
        for m in g.get("members") or []:
            yield [gname, _name(scan, m), _type(scan, m)]


def people_rows(scan):
    yield PEOPLE_HEADERS
    for rec in scan["ids"].values():
        if rec.get("kind") != "user":
            continue
        en = rec.get("enabled")
        yield [rec.get("name") or rec.get("sid"), rec.get("department") or "", rec.get("display_name") or "", rec.get("title") or "",
               rec.get("manager") or "", rec.get("office") or "", rec.get("mail") or "",
               "" if en is None else ("True" if en else "False"), rec.get("last_logon") or ""]


def sheets(scan, open_file, Sheet):
    """The scan as three sheets with their roles and columns already set: [(Sheet, role, mapping)]."""
    out = [(Sheet("Permissions (scanner)", permission_rows(scan, open_file)), "permissions", PERM_MAP)]
    if scan["groups"]:
        out.append((Sheet("Group members (scanner)", member_rows(scan)), "members", MEMBER_MAP))
    if any(r.get("kind") == "user" for r in scan["ids"].values()):
        out.append((Sheet("People (scanner)", people_rows(scan)), "people", PEOPLE_MAP))
    for sh, _, _ in out:
        sh.header_index = 0
    return out


def summary(scan):
    h, e = scan["header"] or {}, scan["end"] or {}
    return {"server": h.get("server"), "fqdn": h.get("fqdn"), "domain": h.get("domain"), "os": h.get("os"), "run_as": h.get("run_as"),
            "scanner": h.get("scanner"), "started": h.get("started"), "finished": e.get("finished"), "options": h.get("options"),
            "counts": e.get("counts"), "shares": len(scan["shares"]), "errors_total": scan["errors_total"]}


# ---- scans: asked for, started, uploaded, imported ---------------------------------------------------------

SHARE_RE = re.compile(r'^[^\\/:*?"<>|]{1,80}$')
PATH_RE = re.compile(r'^[A-Za-z]:\\[^*?"<>|]{0,250}$')
STALE_HOURS = 6          # no word from a running scan for this long: failed


def scanners(conn):
    """The servers with the scanner installed, and their recent scans."""
    rows = conn.execute("""SELECT s.host_id::text AS host_id, h.hostname, h.fqdn, h.agent_version, h.last_checkin, s.version, s.shares,
                                  s.registered_at, s.last_seen
                             FROM perm_scanners s JOIN hosts h ON h.id = s.host_id
                            WHERE h.status <> 'decommissioned' ORDER BY h.hostname""").fetchall()
    scans = conn.execute("""SELECT p.id::text AS id, p.host_id::text AS host_id, h.hostname, p.state, p.options, p.requested_by, p.requested_at,
                                   p.stage, p.progress, p.note, p.dataset_id::text AS dataset_id, p.error, p.updated_at
                              FROM perm_scans p JOIN hosts h ON h.id = p.host_id ORDER BY p.requested_at DESC LIMIT 40""").fetchall()
    return {"scanners": rows, "scans": scans}


def check_options(o):
    from .perm_review import PermError
    o = o or {}
    shares = [str(x).strip() for x in (o.get("shares") or []) if str(x).strip()]
    paths = [str(x).strip().rstrip("\\") for x in (o.get("paths") or []) if str(x).strip()]
    bad = [x for x in shares if not SHARE_RE.match(x)] + [x for x in paths if not PATH_RE.match(x + "\\")]
    if bad:
        raise PermError("Not a share name or a local folder (D:\\Data): " + ", ".join(bad[:5]))
    if len(shares) > 200 or len(paths) > 50:
        raise PermError("At most 200 shares and 50 folders in one scan.")
    try:
        depth, max_depth = int(o.get("depth", 3)), int(o.get("max_depth", 16))
    except (TypeError, ValueError):
        raise PermError("The depths are numbers.")
    if not 0 <= depth <= 8:
        raise PermError("Read every folder down to 0 to 8 levels.")
    if not depth <= max_depth <= 64:
        raise PermError("Below that, folders whose permissions change are read down to 64 levels at most, and not less than the first depth.")
    return {"shares": shares, "paths": paths, "depth": depth, "max_depth": max_depth, "members": bool(o.get("members", True))}


def ask(conn, host_id, options, user):
    """An admin asks for a scan of one server: queued for its agent (1.10.0-win starts the scanner)."""
    from .perm_review import PermError
    h = conn.execute("""SELECT h.id::text AS id, h.hostname, h.agent_version, s.version FROM hosts h
                          LEFT JOIN perm_scanners s ON s.host_id = h.id WHERE h.id = %s AND h.status <> 'decommissioned'""",
                     (host_id,)).fetchone()
    if not h:
        raise PermError("That server is not known.")
    if not h["version"]:
        raise PermError(f"{h['hostname']} has no access scanner: copy access-scan.ps1 next to its agent and run access-scan.ps1 -Register.")
    if not agent_starts_scans(h["agent_version"]):
        raise PermError(f"{h['hostname']}'s agent ({h['agent_version'] or 'unknown'}) cannot start a scan: update it to 1.10.0-win, "
                        "or run access-scan.ps1 -Upload on the server (or from Task Scheduler).")
    busy = conn.execute("""SELECT 1 FROM perm_scans WHERE host_id = %s AND state IN ('queued', 'started', 'running', 'uploading', 'importing')
                            AND updated_at > now() - make_interval(hours => %s)""", (host_id, STALE_HOURS)).fetchone()
    if busy:
        raise PermError(f"A scan of {h['hostname']} is already under way.")
    opt = check_options(options)
    sc = conn.execute("""INSERT INTO perm_scans (host_id, options, requested_by) VALUES (%s, %s::jsonb, %s) RETURNING id::text AS id""",
                      (host_id, json.dumps(opt), user)).fetchone()
    cmd = conn.execute("""INSERT INTO agent_commands (host_id, verb, params, expires_at)
                          VALUES (%s, 'access_scan', %s::jsonb, now() + interval '1 day') RETURNING id::text AS id""",
                       (host_id, json.dumps(dict(opt, scan_id=sc["id"])))).fetchone()
    conn.execute("UPDATE perm_scans SET command_id = %s WHERE id = %s", (cmd["id"], sc["id"]))
    return sc["id"]


def agent_starts_scans(version):
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)-win$", version or "")
    return bool(m) and tuple(int(x) for x in m.groups()) >= (1, 10, 0)


def cancel(conn, scan_id):
    from .perm_review import PermError
    r = conn.execute("""UPDATE perm_scans SET state = 'cancelled', note = 'cancelled before the server started it', updated_at = now()
                         WHERE id = %s AND state = 'queued' RETURNING command_id::text AS c""", (scan_id,)).fetchone()
    if not r:
        raise PermError("Only a scan the server has not started yet can be cancelled.")
    if r["c"]:
        conn.execute("DELETE FROM agent_commands WHERE id = %s AND claimed_at IS NULL", (r["c"],))


# ---- what the scanner sends (with the agent's token) ------------------------------------------------------

def register(conn, host_id, version, shares, check=False):
    v = str(version or "")[:40]
    if check:
        return {"message": "PATCH-01 answers this server's scanner"}
    conn.execute("""INSERT INTO perm_scanners (host_id, version, shares) VALUES (%s, %s, %s)
                    ON CONFLICT (host_id) DO UPDATE SET version = EXCLUDED.version, shares = EXCLUDED.shares, last_seen = now()""",
                 (host_id, v, [str(x)[:80] for x in (shares or [])][:500]))
    return {"message": f"registered: {len(shares or [])} shares; scans can now be started from PATCH-01 > Access review"}


def started_here(conn, host_id, version, options):
    """A scan run on the server itself (by hand or from Task Scheduler)."""
    try:
        opt = check_options(options) if options else {}
    except ValueError:
        opt = {}
    conn.execute("""INSERT INTO perm_scanners (host_id, version) VALUES (%s, %s)
                    ON CONFLICT (host_id) DO UPDATE SET version = EXCLUDED.version, last_seen = now()""", (host_id, str(version or "")[:40]))
    r = conn.execute("""INSERT INTO perm_scans (host_id, options, requested_by, state, stage) VALUES (%s, %s::jsonb, 'the server', 'running', 'starting')
                        RETURNING id::text AS id""", (host_id, json.dumps(opt))).fetchone()
    return r["id"]


def _mine(conn, host_id, scan_id):
    from .perm_review import PermError
    r = conn.execute("SELECT id::text AS id, state, dataset_id::text AS dataset_id FROM perm_scans WHERE id = %s AND host_id = %s FOR UPDATE",
                     (scan_id, host_id)).fetchone()
    if not r:
        raise PermError("no such scan for this server")
    return r


def progress(conn, host_id, scan_id, body):
    sc = _mine(conn, host_id, scan_id)
    if sc["state"] in ("done", "cancelled", "importing"):
        return {"ok": True}
    state = body.get("state") if body.get("state") in ("running", "uploading", "failed") else "running"
    counts = body.get("counts") if isinstance(body.get("counts"), dict) else {}
    counts = {str(k)[:30]: int(v) for k, v in list(counts.items())[:20] if isinstance(v, (int, float))}
    conn.execute("""UPDATE perm_scans SET state = %s, stage = %s, progress = %s::jsonb, note = coalesce(%s, note),
                           error = CASE WHEN %s = 'failed' THEN %s ELSE error END, updated_at = now() WHERE id = %s""",
                 (state, str(body.get("stage") or "")[:200], json.dumps(counts), (str(body.get("note") or "")[:500] or None),
                  state, (str(body.get("note") or "the scan stopped on the server")[:500]), scan_id))
    conn.execute("UPDATE perm_scanners SET last_seen = now() WHERE host_id = %s", (host_id,))
    return {"ok": True}


def upload_start(conn, host_id, hostname, scan_id, file_name, size):
    """The scan's file is about to be sent: one upload per scan (asked again, it resumes)."""
    from .perm_review import PermError, start_upload
    sc = _mine(conn, host_id, scan_id)
    if sc["state"] in ("done", "cancelled", "importing"):
        raise PermError("this scan is finished already")
    if sc["dataset_id"]:
        d = conn.execute("SELECT state, received, size_bytes FROM perm_datasets WHERE id = %s", (sc["dataset_id"],)).fetchone()
        if d and d["state"] == "uploading" and d["size_bytes"] == int(size):
            return {"received": d["received"], "dataset_id": sc["dataset_id"]}
        if d and d["state"] == "uploading":
            conn.execute("DELETE FROM perm_datasets WHERE id = %s", (sc["dataset_id"],))
    fn = str(file_name or "scan.ndjson.gz")
    if not fn.endswith(".ndjson.gz"):
        fn = "scan.ndjson.gz"
    up = start_upload(conn, f"scanner on {hostname}", fn, int(size), f"{hostname} scan")
    conn.execute("UPDATE perm_datasets SET source = 'scan', scan_id = %s, host_id = %s WHERE id = %s", (scan_id, host_id, up["dataset_id"]))
    conn.execute("UPDATE perm_scans SET dataset_id = %s, state = 'uploading', stage = 'uploading', updated_at = now() WHERE id = %s",
                 (up["dataset_id"], scan_id))
    return {"received": 0, "dataset_id": up["dataset_id"]}


def upload_piece(conn, host_id, scan_id, offset, data):
    from .perm_review import PermError, put_chunk
    sc = _mine(conn, host_id, scan_id)
    if not sc["dataset_id"]:
        raise PermError("start the upload first")
    r = put_chunk(conn, sc["dataset_id"], offset, data)
    conn.execute("UPDATE perm_scans SET updated_at = now() WHERE id = %s", (scan_id,))
    return r


def upload_done(conn, host_id, scan_id):
    from .perm_review import PermError, finish_upload
    sc = _mine(conn, host_id, scan_id)
    if not sc["dataset_id"]:
        raise PermError("start the upload first")
    finish_upload(conn, sc["dataset_id"])
    conn.execute("UPDATE perm_scans SET state = 'importing', stage = 'reading the file', updated_at = now() WHERE id = %s", (scan_id,))
    return {"ok": True, "dataset_id": sc["dataset_id"]}


def follow(conn):
    """The worker: scans whose upload is read become done (or failed); a scan with no word for hours fails."""
    conn.execute("""UPDATE perm_scans s SET state = CASE WHEN d.state = 'ready' THEN 'done' ELSE 'failed' END,
                           stage = CASE WHEN d.state = 'ready' THEN 'ready' ELSE 'failed' END,
                           error = CASE WHEN d.state = 'failed' THEN d.error ELSE s.error END, updated_at = now()
                      FROM perm_datasets d
                     WHERE s.dataset_id = d.id AND s.state = 'importing' AND d.state IN ('ready', 'failed')""")
    conn.execute("""UPDATE perm_scans SET state = 'failed', error = %s, updated_at = now()
                     WHERE state IN ('started', 'running', 'uploading') AND updated_at < now() - make_interval(hours => %s)""",
                 (f"no word from the scanner for {STALE_HOURS} hours (the server restarted, or the scan was stopped): run it again",
                  STALE_HOURS))
    conn.execute("""UPDATE perm_scans SET state = 'failed', error = 'the server never picked the scan up (its agent did not check in for a day)',
                           updated_at = now()
                     WHERE state = 'queued' AND requested_at < now() - interval '1 day'""")
