<#
.SYNOPSIS
  PATCH-01 access scanner for a Windows file server (PowerShell 5.1, Windows Server 2016 and later).

.DESCRIPTION
  Reads who has access to what, on THIS server, in one exact format PATCH-01 imports without any
  column mapping:
    - the shares (Get-SmbShare; the administrative C$, ADMIN$, IPC$ and print$ are left out) and
      each share's own permissions;
    - the NTFS permissions of every folder down to -Depth levels below each share, and deeper only
      where the permissions change (a folder that adds its own entries or stops inheriting), down
      to -MaxDepth; files are not read;
    - every account named: user, group, computer, well-known group, or an orphaned SID;
    - from Active Directory: the members of each group, nested groups opened up (Everyone-type
      groups such as Domain Users are not opened), and each person's department, title, manager,
      office, e-mail, whether the account is enabled and its last logon.
  The result is one file, access-scan-<server>-<time>.ndjson.gz, in C:\ProgramData\PatchAgent\access-scan.
  With -Upload it is sent to PATCH-01 over the agent's pinned connection with the agent's token
  (the PATCH-01 agent must be installed and enrolled on this server); without it, upload the file
  in PATCH-01 › Access review.

  Only reads. Nothing on the server is changed (the self-test writes and removes its own folder
  under C:\ProgramData\PatchAgent\access-scan\selftest).

  Install on the file servers to scan only (not every server):
      copy access-scan.ps1 to C:\Program Files\PatchAgent\ (next to patch-agent.ps1)
      access-scan.ps1 -SelfTest        checks every step on this server and prints ok / failed
      access-scan.ps1 -Register        tells PATCH-01 this server has the scanner ("Scan now" appears)
  Then run a scan from PATCH-01 (agent 1.10.0-win or later starts it), or here:
      access-scan.ps1 -Upload                      every share, 3 levels deep
      access-scan.ps1 -Shares Finance,HR -Depth 4 -Upload
      access-scan.ps1 -Paths D:\Data -Upload       folders that are not shared
  or from Task Scheduler, as SYSTEM:
      powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Program Files\PatchAgent\access-scan.ps1" -Upload

  Run as SYSTEM or as an administrator: folders an account cannot read are listed in the report
  as "could not be read", never skipped silently.
#>
[CmdletBinding(DefaultParameterSetName = "Scan")]
param(
    [Parameter(ParameterSetName = "Scan")][string[]]$Shares = @(),
    [Parameter(ParameterSetName = "Scan")][string[]]$Paths = @(),
    [Parameter(ParameterSetName = "Scan")][ValidateRange(0, 8)][int]$Depth = 3,
    [Parameter(ParameterSetName = "Scan")][ValidateRange(0, 64)][int]$MaxDepth = 16,
    [Parameter(ParameterSetName = "Scan")][ValidateRange(1, 5000000)][int]$MaxFolders = 1000000,
    [Parameter(ParameterSetName = "Scan")][switch]$NoMembers,
    [Parameter(ParameterSetName = "Scan")][switch]$Upload,
    [Parameter(ParameterSetName = "Scan")][string]$OutDir = "",
    # Written by the PATCH-01 agent when PATCH-01 asks for a scan (agent 1.10.0-win)
    [Parameter(ParameterSetName = "Job", Mandatory = $true)][string]$JobFile,
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][switch]$SelfTest,
    [Parameter(ParameterSetName = "Register", Mandatory = $true)][switch]$Register,
    [Parameter(ParameterSetName = "Check", Mandatory = $true)][switch]$Check
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$ScannerVersion = "1.0.0"
$Schema = "patch01-access-scan/1"
$DataDir = Join-Path $env:ProgramData "PatchAgent"
$ConfigFile = Join-Path $DataDir "agent.json"
$TokenFile = Join-Path $DataDir "token.bin"
$WorkDir = Join-Path $DataDir "access-scan"
$LogFile = Join-Path $WorkDir "access-scan.log"
$PieceBytes = 16MB
$MemberLimit = 20000            # members read for one group at most (the rest is said to be cut)
$script:Cfg = $null
$script:Token = $null
$script:ScanId = ""
$script:Writer = $null
$script:Counts = [ordered]@{ shares = 0; folders = 0; folders_listed = 0; entries = 0; identities = 0; groups = 0; members = 0; errors = 0; lines = 0 }
$script:Ids = @{}               # SID -> identity record
$script:SidObj = @{}            # SID -> SecurityIdentifier
$script:LastProgress = [datetime]::MinValue
$script:Stage = "starting"

# ---------------------------------------------------------------------------
# Log, and the agent's connection to PATCH-01 (same pin and token as patch-agent.ps1)
# ---------------------------------------------------------------------------
function Write-Log([string]$Message, [string]$Level = "INFO") {
    $line = "{0} {1} {2}" -f (Get-Date).ToString("yyyy-MM-dd HH:mm:ss", [Globalization.CultureInfo]::InvariantCulture), $Level, $Message
    Write-Host $line
    try {
        if (-not (Test-Path -LiteralPath $WorkDir)) { [void](New-Item -ItemType Directory -Path $WorkDir -Force) }
        if ((Test-Path -LiteralPath $LogFile) -and ((Get-Item -LiteralPath $LogFile).Length -gt 2MB)) {
            Move-Item -LiteralPath $LogFile -Destination ($LogFile + ".1") -Force
        }
        Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
    } catch { }
}

if (-not ("PatchScanPin" -as [type])) {
    Add-Type -TypeDefinition @"
using System;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
public static class PatchScanPin {
    public static string Pin = "";
    public static string Seen = "";
    public static bool Check(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors errors) {
        if (cert == null) { return false; }
        using (SHA256 sha = SHA256.Create()) {
            Seen = BitConverter.ToString(sha.ComputeHash(cert.GetRawCertData())).Replace("-", "").ToLowerInvariant();
        }
        if (Pin == "system") { return errors == SslPolicyErrors.None; }
        foreach (string one in Pin.Split(',')) { if (one.Length > 0 && Seen == one) { return true; } }
        return false;
    }
    public static void Use(string pin) {
        Pin = pin.Trim().ToLowerInvariant().Replace(":", "").Replace(" ", "");
        ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(Check);
    }
}
"@
}

function Initialize-Agent {
    # The PATCH-01 agent's settings and token, read the way the agent reads them
    if ($script:Token) { return }
    if (-not (Test-Path -LiteralPath $ConfigFile) -or -not (Test-Path -LiteralPath $TokenFile)) {
        throw "the PATCH-01 agent is not enrolled on this server (no $ConfigFile): install it, or scan without -Upload and upload the file in PATCH-01"
    }
    $script:Cfg = Get-Content -Raw -LiteralPath $ConfigFile | ConvertFrom-Json
    if ([string]$script:Cfg.server -notmatch '^https://[A-Za-z0-9.-]+(:\d{1,5})?/?$') { throw ("PATCH-01's address must be https://<name>[:port]; '" + $script:Cfg.server + "' was refused") }
    Add-Type -AssemblyName System.Security
    $bytes = [Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($TokenFile), $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
    $script:Token = [Text.Encoding]::UTF8.GetString($bytes)
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [PatchScanPin]::Use([string]$script:Cfg.pin)
    [Net.WebRequest]::DefaultWebProxy = $null
}

function Invoke-Api([string]$Method, [string]$Path, $Body = $null, [int]$Timeout = 60, [byte[]]$Raw = $null) {
    Initialize-Agent
    $uri = ([string]$script:Cfg.server).TrimEnd("/") + $Path
    $params = @{ Method = $Method; Uri = $uri; TimeoutSec = $Timeout; UseBasicParsing = $true
                 Headers = @{ "User-Agent" = "patch-access-scan/$ScannerVersion"; "Authorization" = "Bearer " + $script:Token } }
    if ($null -ne $Raw) { $params["Body"] = $Raw; $params["ContentType"] = "application/octet-stream" }
    elseif ($null -ne $Body) {
        $params["Body"] = [Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $Body -Depth 8 -Compress))
        $params["ContentType"] = "application/json; charset=utf-8"
    }
    try { return Invoke-RestMethod @params }
    catch {
        $detail = $_.Exception.Message
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
            $code = ""
            if ($_.Exception.PSObject.Properties["Response"] -and $_.Exception.Response) { $code = "HTTP " + [int]$_.Exception.Response.StatusCode + ": " }
            $detail = $code + $_.ErrorDetails.Message
        }
        if ([PatchScanPin]::Seen -and [PatchScanPin]::Pin -ne "system" -and ([PatchScanPin]::Pin.Split(",") -notcontains [PatchScanPin]::Seen)) {
            $detail = "PATCH-01's certificate does not match the agent's pin. It presented " + [PatchScanPin]::Seen
        }
        throw "$Method $Path failed: $detail"
    }
}

function Send-Progress([string]$State, [string]$Note = "", [switch]$Now) {
    # Every 30 seconds at most, and never stops the scan
    if (-not $script:ScanId -or -not $script:Token) { return }
    if (-not $Now -and ((Get-Date) - $script:LastProgress).TotalSeconds -lt 30) { return }
    $script:LastProgress = Get-Date
    try {
        Invoke-Api "POST" ("/api/v1/agent/access-scans/" + $script:ScanId + "/progress") @{
            state = $State; stage = $script:Stage; note = $Note; counts = $script:Counts; version = $ScannerVersion } -Timeout 30 | Out-Null
    } catch { Write-Log ("progress not sent: " + $_.Exception.Message) "WARN" }
}

# ---------------------------------------------------------------------------
# The output: one JSON object per line, gzip-compressed
# ---------------------------------------------------------------------------
function Open-Output([string]$Path) {
    $fs = [IO.File]::Create($Path)
    $gz = New-Object IO.Compression.GZipStream($fs, [IO.Compression.CompressionMode]::Compress)
    $script:Writer = New-Object IO.StreamWriter($gz, (New-Object Text.UTF8Encoding($false)))
    $script:Writer.NewLine = "`n"
}

function Write-Record($Record) {
    # -InputObject: a one-element list stays a list in PowerShell 5.1
    $script:Writer.WriteLine((ConvertTo-Json -InputObject $Record -Depth 6 -Compress))
    $script:Counts.lines++
}

function Close-Output {
    if ($script:Writer) { $script:Writer.Flush(); $script:Writer.Dispose(); $script:Writer = $null }
}

function Get-IsoUtc([datetime]$When = (Get-Date)) {
    return $When.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ", [Globalization.CultureInfo]::InvariantCulture)
}

# ---------------------------------------------------------------------------
# Accounts: names, kinds, and from Active Directory the members and people
# ---------------------------------------------------------------------------
# Everyone-type groups: they mean everyone, they are never opened
$BroadSids = @("S-1-1-0", "S-1-5-11", "S-1-5-4", "S-1-5-2", "S-1-5-32-545", "S-1-5-32-546", "S-1-5-7", "S-1-5-13", "S-1-5-14", "S-1-5-1")
$BroadRids = @(513, 514, 515)          # Domain Users, Domain Guests, Domain Computers
$SystemSids = @("S-1-5-18", "S-1-5-19", "S-1-5-20", "S-1-3-0", "S-1-3-1", "S-1-5-32-549", "S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464")

function Get-Rid([string]$Sid) {
    $p = $Sid.Split("-"); $r = 0
    if ($p.Count -gt 4 -and [int]::TryParse($p[$p.Count - 1], [ref]$r)) { return $r }
    return -1
}

function Test-Broad([string]$Sid) {
    if ($BroadSids -contains $Sid) { return $true }
    return ($Sid -like "S-1-5-21-*" -and ($BroadRids -contains (Get-Rid $Sid)))
}

function Get-SidObject([string]$Sid) {
    if (-not $script:SidObj.ContainsKey($Sid)) { $script:SidObj[$Sid] = New-Object Security.Principal.SecurityIdentifier($Sid) }
    return $script:SidObj[$Sid]
}

function Resolve-Sid([string]$Sid) {
    <# The account a SID names: {sid, name, kind}. kind: user, group, computer, wellknown,
       orphan (nothing answers for it: a deleted account), system. #>
    if ($script:Ids.ContainsKey($Sid)) { return $script:Ids[$Sid] }
    $rec = [ordered]@{ t = "identity"; sid = $Sid; name = $Sid; kind = "orphan" }
    try {
        $rec.name = (Get-SidObject $Sid).Translate([Security.Principal.NTAccount]).Value
        $rec.kind = "unknown"
    } catch { }
    if ($SystemSids -contains $Sid -or $Sid -like "S-1-5-80-*" -or $Sid -like "S-1-5-82-*" -or $Sid -like "S-1-15-*") { $rec.kind = "system" }
    elseif (Test-Broad $Sid) { $rec.kind = "wellknown" }
    elseif ($rec.kind -ne "orphan" -and $Sid -like "S-1-5-32-*") { $rec.kind = "group" }     # BUILTIN\...: local groups
    $script:Ids[$Sid] = $rec
    return $rec
}

function Get-Domain {
    try { return [DirectoryServices.ActiveDirectory.Domain]::GetComputerDomain() } catch { return $null }
}

function Convert-SidToLdap([string]$Sid) {
    $o = Get-SidObject $Sid
    $b = New-Object byte[] $o.BinaryLength
    $o.GetBinaryForm($b, 0)
    return (($b | ForEach-Object { "\{0:x2}" -f $_ }) -join "")
}

function Get-DnName([string]$Dn) {
    if ($Dn -match '^CN=((?:\\,|[^,])+)') { return ($Matches[1] -replace '\\,', ',') }
    return $Dn
}

function Read-DirectoryDetails([string[]]$Sids) {
    <# Kind, department, title, manager, office, e-mail, enabled and last logon for domain
       accounts, 40 at a time. Accounts the directory does not answer for keep what they had. #>
    $todo = @($Sids | Where-Object { $_ -like "S-1-5-21-*" })
    if (-not $todo.Count) { return }
    $dom = Get-Domain
    if (-not $dom) { Write-Log "this server is not in a domain: accounts are named, departments are not read" "WARN"; return }
    $root = $dom.GetDirectoryEntry()
    for ($i = 0; $i -lt $todo.Count; $i += 40) {
        $batch = $todo[$i..([Math]::Min($i + 39, $todo.Count - 1))]
        $filter = "(|" + (($batch | ForEach-Object { "(objectSid=" + (Convert-SidToLdap $_) + ")" }) -join "") + ")"
        $ds = New-Object DirectoryServices.DirectorySearcher($root, $filter)
        $ds.PageSize = 200
        foreach ($p in @("objectSid", "objectClass", "sAMAccountName", "displayName", "department", "title", "manager", "mail",
                         "physicalDeliveryOfficeName", "userAccountControl", "lastLogonTimestamp")) { [void]$ds.PropertiesToLoad.Add($p) }
        try {
            foreach ($r in $ds.FindAll()) {
                $sid = (New-Object Security.Principal.SecurityIdentifier($r.Properties["objectsid"][0], 0)).Value
                if (-not $script:Ids.ContainsKey($sid)) { continue }
                $rec = $script:Ids[$sid]
                $cls = @($r.Properties["objectclass"] | ForEach-Object { [string]$_ })
                if ($cls -contains "computer") { $rec.kind = "computer" }
                elseif ($cls -contains "group") { $rec.kind = "group" }
                elseif ($cls -contains "user") { $rec.kind = "user" }
                if ($rec.kind -eq "user") {
                    foreach ($pair in @(@("displayname", "display_name"), @("department", "department"), @("title", "title"),
                                        @("mail", "mail"), @("physicaldeliveryofficename", "office"))) {
                        if ($r.Properties[$pair[0]].Count) { $rec[$pair[1]] = [string]$r.Properties[$pair[0]][0] }
                    }
                    if ($r.Properties["manager"].Count) { $rec["manager"] = Get-DnName ([string]$r.Properties["manager"][0]) }
                    if ($r.Properties["useraccountcontrol"].Count) { $rec["enabled"] = -not ([int]$r.Properties["useraccountcontrol"][0] -band 2) }
                    if ($r.Properties["lastlogontimestamp"].Count) {
                        $ft = [long]$r.Properties["lastlogontimestamp"][0]
                        if ($ft -gt 0) { $rec["last_logon"] = [DateTime]::FromFileTimeUtc($ft).ToString("yyyy-MM-dd") }
                    }
                }
            }
        } catch { Write-Log ("the directory did not answer for some accounts: " + $_.Exception.Message) "WARN" }
        finally { $ds.Dispose() }
    }
}

function Read-Members([string[]]$GroupSids) {
    <# The members of each group, nested groups opened (each group read once; a loop stops by
       itself). Everyone-type groups are not opened. Writes one "group" line per group. #>
    Add-Type -AssemblyName System.DirectoryServices.AccountManagement
    $ctxD = $null; $ctxM = $null
    if (Get-Domain) { try { $ctxD = New-Object DirectoryServices.AccountManagement.PrincipalContext([DirectoryServices.AccountManagement.ContextType]::Domain) } catch { } }
    try { $ctxM = New-Object DirectoryServices.AccountManagement.PrincipalContext([DirectoryServices.AccountManagement.ContextType]::Machine) } catch { }
    $queue = New-Object Collections.Queue
    $seen = @{}
    foreach ($g in $GroupSids) { $queue.Enqueue($g) }
    while ($queue.Count) {
        $g = [string]$queue.Dequeue()
        if ($seen.ContainsKey($g) -or (Test-Broad $g)) { continue }
        $seen[$g] = $true
        $script:Stage = "members of " + (Resolve-Sid $g).name
        Send-Progress "running"
        $gp = $null
        foreach ($ctx in @($ctxD, $ctxM)) {
            if ($null -eq $ctx -or $gp) { continue }
            try { $gp = [DirectoryServices.AccountManagement.GroupPrincipal]::FindByIdentity($ctx, [DirectoryServices.AccountManagement.IdentityType]::Sid, $g) } catch { $gp = $null }
        }
        if (-not $gp) { continue }
        (Resolve-Sid $g).kind = "group"
        $members = New-Object Collections.ArrayList
        $cut = $false; $bad = 0
        try {
            $en = $gp.Members.GetEnumerator()
            while ($true) {
                $ok = $false
                try { $ok = $en.MoveNext() } catch {
                    # A member in a domain this server cannot reach: said, and the others are read (never for ever)
                    Write-Log ("a member of " + (Resolve-Sid $g).name + " could not be read: " + $_.Exception.Message) "WARN"
                    if (++$bad -ge 50) { $cut = $true; break }
                    continue
                }
                if (-not $ok) { break }
                if ($members.Count -ge $MemberLimit) { $cut = $true; break }
                try {
                    $m = $en.Current
                    if ($null -eq $m -or $null -eq $m.Sid) { continue }
                    $ms = $m.Sid.Value
                    $rec = Resolve-Sid $ms
                    if ($m -is [DirectoryServices.AccountManagement.GroupPrincipal]) { $rec.kind = "group"; $queue.Enqueue($ms) }
                    elseif ($m -is [DirectoryServices.AccountManagement.ComputerPrincipal]) { $rec.kind = "computer" }
                    elseif ($m -is [DirectoryServices.AccountManagement.UserPrincipal] -and $rec.kind -eq "unknown") { $rec.kind = "user" }
                    [void]$members.Add($ms)
                } catch {
                    Write-Log ("a member of " + (Resolve-Sid $g).name + " could not be read: " + $_.Exception.Message) "WARN"
                    if (++$bad -ge 50) { $cut = $true; break }
                }
            }
        } catch { Write-Log ("the members of " + (Resolve-Sid $g).name + " could not be read: " + $_.Exception.Message) "WARN" }
        finally { $gp.Dispose() }
        Write-Record ([ordered]@{ t = "group"; sid = $g; members = @($members); cut = $cut })
        $script:Counts.groups++
        $script:Counts.members += $members.Count
    }
}

# ---------------------------------------------------------------------------
# Shares and folders
# ---------------------------------------------------------------------------
function Get-ShareList([string[]]$Only) {
    <# The disk shares of this server: {name, path, description, access}. #>
    $out = @()
    $list = @()
    try { $list = @(Get-SmbShare -Special $false -ErrorAction Stop | Where-Object { $_.ShareType -eq "FileSystemDirectory" -and $_.Path }) }
    catch { $list = @(Get-CimInstance Win32_Share | Where-Object { $_.Type -eq 0 -and $_.Path } | ForEach-Object { [pscustomobject]@{ Name = $_.Name; Path = $_.Path; Description = $_.Description } }) }
    foreach ($s in $list) {
        if ($s.Name -match '^(ADMIN|IPC|print)\$$' -or $s.Name -match '^[A-Za-z]\$$') { continue }
        if ($Only.Count -and -not ($Only | Where-Object { $_ -ieq $s.Name })) { continue }
        $acc = @()
        try {
            foreach ($a in @(Get-SmbShareAccess -Name $s.Name -ErrorAction Stop)) {
                $sid = $null
                try { $sid = (New-Object Security.Principal.NTAccount($a.AccountName)).Translate([Security.Principal.SecurityIdentifier]).Value } catch { }
                $acc += [ordered]@{ account = [string]$a.AccountName; sid = $sid; right = [string]$a.AccessRight; type = [string]$a.AccessControlType }
            }
        } catch { $acc = $null }
        $p = ([string]$s.Path).TrimEnd("\")
        if ($p -match '^[A-Za-z]:$') { $p += "\" }          # a whole drive: "D:\" ("D:" alone is the current folder on D:)
        $out += [ordered]@{ name = [string]$s.Name; path = $p; description = [string]$s.Description; access = $acc }
    }
    foreach ($n in $Only) { if (-not ($out | Where-Object { $_.name -ieq $n })) { throw ("there is no disk share named '" + $n + "' on this server") } }
    return $out
}

function Get-LongPath([string]$Path) {
    # Paths over 247 characters need the \\?\ form (.NET 4.6.2 and later, built in to Server 2016)
    if ($Path.Length -lt 240 -or $Path.StartsWith("\\?\")) { return $Path }
    if ($Path.StartsWith("\\")) { return "\\?\UNC\" + $Path.Substring(2) }
    return "\\?\" + $Path
}

function Read-FolderAcl([string]$Path) {
    <# {owner, protected, aces[]} of one folder: every entry, inherited or not, by SID. #>
    $sec = [IO.Directory]::GetAccessControl((Get-LongPath $Path), [Security.AccessControl.AccessControlSections]"Access, Owner")
    $owner = $null
    try { $owner = $sec.GetOwner([Security.Principal.SecurityIdentifier]).Value } catch { }
    $aces = @()
    foreach ($r in $sec.GetAccessRules($true, $true, [Security.Principal.SecurityIdentifier])) {
        $sid = $r.IdentityReference.Value
        [void](Resolve-Sid $sid)
        $aces += [ordered]@{ sid = $sid; rights = [int]$r.FileSystemRights; deny = ([string]$r.AccessControlType -eq "Deny");
                             inherited = [bool]$r.IsInherited; flags = [string]$r.InheritanceFlags; prop = [string]$r.PropagationFlags }
    }
    if ($owner) { [void](Resolve-Sid $owner) }
    return @{ owner = $owner; protected = [bool]$sec.AreAccessRulesProtected; aces = $aces }
}

function Write-Error2([string]$Path, [string]$Why) {
    Write-Record ([ordered]@{ t = "error"; path = $Path; error = $Why })
    $script:Counts.errors++
}

function Scan-Root([string]$ShareName, [string]$Root, [string]$UncRoot, $SkipRoots) {
    <# Every folder below Root, breadth first. A folder is written when it is no deeper than
       -Depth, or when its permissions differ from its parent's (own entries, or not inheriting). #>
    $queue = New-Object Collections.Queue
    $queue.Enqueue(@($Root, 0))
    while ($queue.Count) {
        $item = $queue.Dequeue()
        $path = [string]$item[0]; $d = [int]$item[1]
        if ($script:Counts.folders -ge $MaxFolders) { Write-Error2 $path ("stopped: more than " + $MaxFolders + " folders (raise -MaxFolders)"); break }
        $script:Counts.folders++
        $rel = $path.Substring($Root.Length).TrimStart("\")
        $unc = if (-not $UncRoot) { $null } elseif ($rel) { $UncRoot + "\" + $rel } else { $UncRoot }
        $where = if ($unc) { $unc } else { $path }
        try {
            $acl = Read-FolderAcl $path
            $own = @($acl.aces | Where-Object { -not $_.inherited }).Count
            if ($d -le $Depth -or $own -gt 0 -or $acl.protected) {
                Write-Record ([ordered]@{ t = "folder"; share = $ShareName; path = $path; unc = $unc; depth = $d; owner = $acl.owner;
                                          protected = $acl.protected; aces = @($acl.aces) })
                $script:Counts.folders_listed++
                $script:Counts.entries += @($acl.aces).Count
            }
        } catch { Write-Error2 $where ("permissions could not be read: " + $_.Exception.Message) }
        if ($d -ge $MaxDepth) { continue }
        try {
            foreach ($sub in [IO.Directory]::EnumerateDirectories((Get-LongPath $path))) {
                $full = $sub
                if ($full.StartsWith("\\?\UNC\")) { $full = "\\" + $full.Substring(8) } elseif ($full.StartsWith("\\?\")) { $full = $full.Substring(4) }
                try {
                    if (([IO.File]::GetAttributes((Get-LongPath $full)) -band [IO.FileAttributes]::ReparsePoint) -ne 0) { continue }   # junctions and links: never followed
                } catch { continue }
                if ($SkipRoots -contains $full.ToLowerInvariant()) { continue }   # another share: scanned under its own name
                $queue.Enqueue(@($full, ($d + 1)))
            }
        } catch { Write-Error2 $where ("sub-folders could not be listed: " + $_.Exception.Message) }
        if (($script:Counts.folders % 500) -eq 0) { $script:Stage = "folders of " + $ShareName; Send-Progress "running" }
    }
}

# ---------------------------------------------------------------------------
# One scan
# ---------------------------------------------------------------------------
function Invoke-Scan($Opt) {
    $mutex = New-Object Threading.Mutex($false, "Global\PatchAccessScan")
    $owned = $false
    try { $owned = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owned = $true }
    if (-not $owned) { $mutex.Dispose(); throw "another access scan is running on this server" }
    $out = $null
    try {
        $script:Stage = "shares"
        Send-Progress "running" "started" -Now
        $server = $env:COMPUTERNAME
        $fqdn = $server
        try { $fqdn = [Net.Dns]::GetHostEntry($server).HostName } catch { }
        $dir = if ($Opt.out_dir) { $Opt.out_dir } else { $WorkDir }
        if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Path $dir -Force) }
        $name = "access-scan-" + $server + "-" + (Get-Date).ToString("yyyyMMdd-HHmmss", [Globalization.CultureInfo]::InvariantCulture) + ".ndjson.gz"
        $out = Join-Path $dir $name
        $tmp = $out + ".part"
        Open-Output $tmp
        $dom = Get-Domain
        Write-Record ([ordered]@{ t = "header"; schema = $Schema; scanner = $ScannerVersion; server = $server; fqdn = $fqdn;
                                  domain = $(if ($dom) { $dom.Name } else { $null }); os = [string](Get-CimInstance Win32_OperatingSystem).Caption;
                                  started = (Get-IsoUtc); run_as = [Security.Principal.WindowsIdentity]::GetCurrent().Name;
                                  options = [ordered]@{ shares = @($Opt.shares); paths = @($Opt.paths); depth = $Opt.depth; max_depth = $Opt.max_depth;
                                                        members = -not $Opt.no_members; max_folders = $MaxFolders } })
        $shares = @(Get-ShareList @($Opt.shares))
        if ($Opt.paths.Count -and -not $Opt.shares.Count) { $shares = @() }
        $roots = @($shares | ForEach-Object { $_.path.ToLowerInvariant() })
        foreach ($s in $shares) {
            Write-Record ([ordered]@{ t = "share"; name = $s.name; path = $s.path; unc = ("\\" + $server + "\" + $s.name); description = $s.description; access = $s.access })
            foreach ($a in @($s.access)) { if ($a -and $a.sid) { [void](Resolve-Sid $a.sid) } }
            $script:Counts.shares++
        }
        foreach ($s in $shares) {
            if (-not (Test-Path -LiteralPath $s.path)) { Write-Error2 ("\\" + $server + "\" + $s.name) ("the share's folder " + $s.path + " does not exist"); continue }
            Write-Log ("scanning share " + $s.name + " (" + $s.path + ")")
            Scan-Root $s.name $s.path ("\\" + $server + "\" + $s.name) @($roots | Where-Object { $_ -ne $s.path.ToLowerInvariant() })
        }
        foreach ($p in @($Opt.paths)) {
            $lp = ([string]$p).TrimEnd("\")
            if (-not (Test-Path -LiteralPath $lp)) { Write-Error2 $lp "this folder does not exist"; continue }
            Write-Log ("scanning folder " + $lp)
            Scan-Root "" $lp "" @()
        }
        if (-not $Opt.no_members) {
            Read-DirectoryDetails @($script:Ids.Keys)
            $groups = @($script:Ids.Values | Where-Object { $_.kind -eq "group" } | ForEach-Object { $_.sid })
            Read-Members $groups
            Read-DirectoryDetails @($script:Ids.Values | Where-Object { $_.kind -eq "unknown" -or ($_.kind -eq "user" -and -not $_.Contains("enabled")) } | ForEach-Object { $_.sid })
        }
        $script:Stage = "writing"
        foreach ($rec in $script:Ids.Values) { Write-Record $rec; $script:Counts.identities++ }
        $script:Counts.lines++
        Write-Record ([ordered]@{ t = "end"; finished = (Get-IsoUtc); counts = $script:Counts })
        Close-Output
        Move-Item -LiteralPath $tmp -Destination $out -Force
        Write-Log ("scan written: " + $out + " (" + $script:Counts.folders_listed + " folders listed of " + $script:Counts.folders + " read, " +
                   $script:Counts.entries + " entries, " + $script:Counts.errors + " could not be read)")
        return $out
    } catch {
        Close-Output
        throw
    } finally {
        $mutex.ReleaseMutex(); $mutex.Dispose()
    }
}

function Send-ScanFile([string]$File) {
    <# The file to PATCH-01 in 16 MB pieces, resuming where PATCH-01 says it is. #>
    $size = (Get-Item -LiteralPath $File).Length
    if (-not $script:ScanId) {
        $r = Invoke-Api "POST" "/api/v1/agent/access-scans" @{ version = $ScannerVersion; note = "run on the server" }
        $script:ScanId = [string]$r.scan_id
    }
    $start = Invoke-Api "POST" ("/api/v1/agent/access-scans/" + $script:ScanId + "/upload") @{ file_name = (Split-Path -Leaf $File); size = $size }
    $off = [long]$start.received
    $fs = [IO.File]::OpenRead($File)
    try {
        $buf = New-Object byte[] $PieceBytes
        $tries = 0
        while ($off -lt $size) {
            [void]$fs.Seek($off, [IO.SeekOrigin]::Begin)
            $n = $fs.Read($buf, 0, $buf.Length)
            $piece = New-Object byte[] $n
            [Array]::Copy($buf, $piece, $n)
            try {
                $r = Invoke-Api "PUT" ("/api/v1/agent/access-scans/" + $script:ScanId + "/piece?offset=" + $off) -Raw $piece -Timeout 300
                $off = [long]$r.received; $tries = 0
                $script:Stage = "uploading " + [Math]::Round(100 * $off / $size) + "%"
                Send-Progress "uploading"
            } catch {
                if ($_.Exception.Message -match 'expected the bytes from (\d+)') { $off = [long]$Matches[1]; continue }
                if (++$tries -gt 4) { throw }
                Write-Log ("upload piece failed, trying again: " + $_.Exception.Message) "WARN"
                Start-Sleep -Seconds (10 * $tries)
            }
        }
    } finally { $fs.Dispose() }
    Invoke-Api "POST" ("/api/v1/agent/access-scans/" + $script:ScanId + "/complete") @{} | Out-Null
    Write-Log ("sent to PATCH-01 (scan " + $script:ScanId + ", " + $size + " bytes)")
}

# ---------------------------------------------------------------------------
# Self-test: a small folder tree with known permissions, scanned and read back
# ---------------------------------------------------------------------------
function Invoke-SelfTest {
    $fail = 0
    function Step([string]$What, [scriptblock]$Do) {
        try { $r = & $Do; Write-Host ("  ok      " + $What + $(if ($r) { ": " + $r } else { "" })) }
        catch { Write-Host ("  FAILED  " + $What + ": " + $_.Exception.Message) -ForegroundColor Red; $script:SelfFail++ }
    }
    $script:SelfFail = 0
    $base = Join-Path $WorkDir "selftest"
    Write-Host ("PATCH-01 access scanner " + $ScannerVersion + " self-test")
    Step "PowerShell 5.1 or later" { if ($PSVersionTable.PSVersion.Major -lt 5) { throw ("this is " + $PSVersionTable.PSVersion) }; [string]$PSVersionTable.PSVersion }
    Step "running as an administrator or SYSTEM" {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        if (-not (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw "run it as an administrator (some folders will not be readable otherwise)" }
        $id.Name
    }
    Step "shares on this server" { $s = @(Get-ShareList @()); ($s.Count.ToString() + ": " + (($s | ForEach-Object { $_.name }) -join ", ")) }
    Step "Active Directory" { $d = Get-Domain; if (-not $d) { throw "not in a domain: departments and members will not be read" }; $d.Name }
    Step "a test tree with known permissions" {
        if (Test-Path -LiteralPath $base) { Remove-Item -LiteralPath $base -Recurse -Force }
        [void](New-Item -ItemType Directory -Path (Join-Path $base "Open\Deep\Deeper") -Force)
        [void](New-Item -ItemType Directory -Path (Join-Path $base "Closed") -Force)
        $acl = [IO.Directory]::GetAccessControl((Join-Path $base "Open"))
        $users = New-Object Security.Principal.SecurityIdentifier("S-1-5-32-545")
        $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($users, "Modify", "ContainerInherit, ObjectInherit", "None", "Allow")))
        [IO.Directory]::SetAccessControl((Join-Path $base "Open"), $acl)
        $acl = [IO.Directory]::GetAccessControl((Join-Path $base "Closed"))
        $acl.SetAccessRuleProtection($true, $true)
        [IO.Directory]::SetAccessControl((Join-Path $base "Closed"), $acl)
        "Open (BUILTIN\Users Modify), Closed (not inheriting)"
    }
    $file = $null
    Step "scan of the test tree" {
        $script:Ids = @{}
        $script:Counts = [ordered]@{ shares = 0; folders = 0; folders_listed = 0; entries = 0; identities = 0; groups = 0; members = 0; errors = 0; lines = 0 }
        $script:SelfFile = Invoke-Scan @{ shares = @(); paths = @($base); depth = 1; max_depth = 8; no_members = $true; out_dir = $base }
        (Split-Path -Leaf $script:SelfFile)
    }
    Step "the file reads back" {
        $fs = [IO.File]::OpenRead($script:SelfFile)
        try {
            $gz = New-Object IO.Compression.GZipStream($fs, [IO.Compression.CompressionMode]::Decompress)
            $rd = New-Object IO.StreamReader($gz, [Text.Encoding]::UTF8)
            $recs = @(); while ($null -ne ($l = $rd.ReadLine())) { $recs += ($l | ConvertFrom-Json) }
        } finally { $fs.Dispose() }
        if ($recs[0].t -ne "header" -or $recs[0].schema -ne $Schema) { throw "no header line" }
        if ($recs[$recs.Count - 1].t -ne "end") { throw "no end line: the file is cut" }
        $folders = @($recs | Where-Object { $_.t -eq "folder" })
        $names = @($folders | ForEach-Object { Split-Path -Leaf $_.path })
        # depth 1: the base and its two folders; Deep is depth 2 and only inherits (not listed); Deeper the same
        foreach ($want in @("selftest", "Open", "Closed")) { if ($names -notcontains $want) { throw ("folder " + $want + " is missing") } }
        if ($names -contains "Deep") { throw "a folder that only inherits, deeper than -Depth, was listed" }
        $open = @($folders | Where-Object { (Split-Path -Leaf $_.path) -eq "Open" })[0]
        $u = @($open.aces | Where-Object { $_.sid -eq "S-1-5-32-545" -and -not $_.inherited -and -not $_.deny })
        if (-not $u.Count -or ($u[0].rights -band 0x10000) -eq 0) { throw "the BUILTIN\Users Modify entry is missing" }
        $closed = @($folders | Where-Object { (Split-Path -Leaf $_.path) -eq "Closed" })[0]
        if (-not $closed.protected) { throw "Closed should not inherit" }
        $ids = @($recs | Where-Object { $_.t -eq "identity" -and $_.sid -eq "S-1-5-32-545" })
        if (-not $ids.Count -or $ids[0].kind -ne "wellknown") { throw "BUILTIN\Users was not named as an Everyone-type group" }
        ([string]$folders.Count + " folders, " + [string]$recs.Count + " lines")
    }
    Step "PATCH-01 reachable with the agent's pin and token" {
        Initialize-Agent
        $r = Invoke-Api "POST" "/api/v1/agent/access-scans/register" @{ version = $ScannerVersion; check = $true; shares = @() }
        [string]$r.message
    }
    try { Remove-Item -LiteralPath $base -Recurse -Force } catch { }
    if ($script:SelfFail) { Write-Host ("self-test: " + $script:SelfFail + " step(s) failed") -ForegroundColor Red; exit 1 }
    Write-Host "self-test: every step ok" -ForegroundColor Green
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
try {
    switch ($PSCmdlet.ParameterSetName) {
        "Check" {
            Write-Host ("PATCH-01 access scanner " + $ScannerVersion + " ready")
            exit 0
        }
        "SelfTest" { Invoke-SelfTest; exit 0 }
        "Register" {
            $names = @(Get-ShareList @() | ForEach-Object { $_.name })
            $r = Invoke-Api "POST" "/api/v1/agent/access-scans/register" @{ version = $ScannerVersion; shares = $names }
            Write-Log ("registered with PATCH-01: " + [string]$r.message)
            exit 0
        }
        "Job" {
            # From the PATCH-01 agent: the job's options, then the file is sent with the same pin and token
            $job = Get-Content -Raw -LiteralPath $JobFile | ConvertFrom-Json
            $script:ScanId = [string]$job.scan_id
            if ($script:ScanId -notmatch '^[0-9a-f-]{36}$') { throw "the job file has no scan id" }
            Initialize-Agent
            $opt = @{ shares = @($job.shares | Where-Object { $_ }); paths = @($job.paths | Where-Object { $_ }); depth = [int]$job.depth;
                      max_depth = [int]$job.max_depth; no_members = -not [bool]$job.members; out_dir = "" }
            if ($opt.depth -lt 0 -or $opt.depth -gt 8 -or $opt.max_depth -lt $opt.depth -or $opt.max_depth -gt 64) { throw "the job's depths are out of range" }
            try {
                $file = Invoke-Scan $opt
                Send-ScanFile $file
            } catch {
                Write-Log ("scan failed: " + $_.Exception.Message) "ERROR"
                try { Invoke-Api "POST" ("/api/v1/agent/access-scans/" + $script:ScanId + "/progress") @{ state = "failed"; stage = $script:Stage; note = [string]$_.Exception.Message; counts = $script:Counts; version = $ScannerVersion } | Out-Null } catch { }
                exit 1
            } finally { Remove-Item -LiteralPath $JobFile -Force -ErrorAction SilentlyContinue }
            exit 0
        }
        default {
            $opt = @{ shares = @($Shares | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim() } | Where-Object { $_ });
                      paths = @($Paths); depth = $Depth; max_depth = [Math]::Max($Depth, $MaxDepth); no_members = [bool]$NoMembers; out_dir = $OutDir }
            if ($Upload) {
                Initialize-Agent
                $r = Invoke-Api "POST" "/api/v1/agent/access-scans" @{ version = $ScannerVersion; note = "run on the server"; options = $opt }
                $script:ScanId = [string]$r.scan_id
            }
            try { $file = Invoke-Scan $opt }
            catch {
                if ($script:ScanId) { try { Invoke-Api "POST" ("/api/v1/agent/access-scans/" + $script:ScanId + "/progress") @{ state = "failed"; stage = $script:Stage; note = [string]$_.Exception.Message; counts = $script:Counts; version = $ScannerVersion } | Out-Null } catch { } }
                throw
            }
            if ($Upload) { Send-ScanFile $file } else { Write-Host ("Upload " + $file + " in PATCH-01 > Access review, or run again with -Upload") }
            exit 0
        }
    }
} catch {
    Write-Log ("access scan stopped: " + $_.Exception.Message) "ERROR"
    exit 1
}
