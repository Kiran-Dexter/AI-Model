# Access scanner: file and folder permissions straight from the file server

`access-scan.ps1` runs **on the file servers you choose** (not on every server). It reads the
shares, every folder's permissions and, from Active Directory, each group's members and each
person's department. Its file has exact columns, so PATCH-01 imports it with nothing to map, and
it goes straight to the Owners & departments step of Access review.

It only reads. Nothing on the server is changed.

## 1. Put it on a file server

Copy `agent\windows\access-scan.ps1` from the package to `C:\Program Files\PatchAgent\` (next
to `patch-agent.ps1`). If your agents run AllSigned, sign it the same way as the agent
(`Sign-Agent.ps1` signs every `.ps1` in its folder).

## 2. Check it (as an administrator, on that server)

```
& "C:\Program Files\PatchAgent\access-scan.ps1" -SelfTest
```

It builds a small folder tree with known permissions, scans it, reads the file back, checks
PATCH-01 answers with the agent's pin and token, and removes the tree. Every step must say `ok`.

## 3. Tell PATCH-01

```
& "C:\Program Files\PatchAgent\access-scan.ps1" -Register
```

The server now shows in **Access review › File-server scanners**.

## 4. Scan

Pick whichever way suits you:

| How | What to do |
|---|---|
| From PATCH-01 | **Scan now** on the server's row. Needs agent **1.10.0-win** on that server (Admin › Agent updates, choose only the file servers). |
| On the server | `access-scan.ps1 -Upload` (every share, 3 levels), or `-Shares Finance,HR -Depth 4 -Upload`, or `-Paths D:\Data -Upload` for folders that are not shared |
| On a schedule | Task Scheduler, as SYSTEM: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Program Files\PatchAgent\access-scan.ps1" -Upload` |
| No network to PATCH-01 | Run it without `-Upload` and upload `C:\ProgramData\PatchAgent\access-scan\access-scan-<server>-<time>.ndjson.gz` in Access review |

## What is read

- **Shares**: their folders, descriptions and share permissions. `C$`, `ADMIN$`, `IPC$` and `print$` are left out.
- **Folders**:
  - every folder down to `-Depth` levels (3 by default);
  - below that, only the folders whose permissions change (they add entries of their own, or stop inheriting), down to `-MaxDepth` (16);
  - files are not read;
  - junctions and links are not followed;
  - a share inside another share is scanned once, under its own name.
- **Accounts**: users, groups, computers, Everyone-type groups and orphaned SIDs. Names are always told by SID, so a German or French server is read the same way.
- **From Active Directory**:
  - members of each group, with nested groups opened up. Everyone-type groups such as Domain Users are not opened.
  - each person's department, title, manager, office, e-mail, whether the account is enabled, and their last logon (lastLogonTimestamp).

Folders the scanner cannot read are listed in the upload as "could not be read", never skipped silently.

## Files and logs on the server

- `C:\ProgramData\PatchAgent\access-scan\` holds the scan files and `access-scan.log`.
- Only one scan runs at a time.

## Owners & departments (r124)

Folders only: files are not read. Right after the import, every folder gets a suggestion:

| Owner (first that applies) | Confidence |
|---|---|
| The NTFS owner, when it is a person whose account is enabled | 85 (90 if they can also change it) |
| The only group given Modify or Full control on the folder directly | 80 (70 if people are also given rights directly) |
| The only person given change rights on the folder directly | 75 |
| The NTFS owner, when that account is disabled | 40 (never bulk-accepted) |
| Several groups or people, no single one | no owner: AI-01 looks |

**Department:** the owner's department; else the department of most (60% or more) of the enabled people who can change the folder, groups opened up.
Admin, system and Everyone-type accounts are never owners.

**AI-01:** after the import, AI-01 checks by itself the folders below 80% and the folders with no suggestion.
- It sees the NTFS owner, who has change rights directly, the departments with their numbers, and what the rules found.
- An owner it names must be in that folder's evidence, and a department must be in the file or in a confirmed tag. Anything else is dropped and said so.

**You decide:**
- **Accept all of 80% or more** confirms the sure suggestions in one click.
- You can edit any owner, department, team or application, then confirm.
- Confirmed owners stay for the next scan.
- A sub-folder whose evidence shows a different owner from its confirmed parent gets its own suggestion.

**Reports:**
- **Permissions & ownership:** one row per folder, with these columns:
  - NTFS owner
  - owner and whether it is a person or a group
  - department, team and application
  - who has access, and whether it was given on the folder or inherited
  - whether Everyone-type groups can get in

  It has a CSV with every folder.
- **By department & owner:** each department, its owners and their folders, with what is risky. The folders without an owner or department come last.
