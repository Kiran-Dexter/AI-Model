# Patch Platform

A self-hosted patch and vulnerability management platform for an estate of
about 200 Linux servers running RHEL 8/9, Oracle Linux 8 and Ubuntu.

It mirrors vendor patches, tracks which servers are exposed to which
security advisories, explains each verdict in plain language using a local
language model, and shows it all on a web console.

Nothing here reaches the internet except PATCH-01's repository syncs, which go
through the corporate proxy. AI-01 has no internet access at all.


## Architecture

```
                vendor repos (Red Hat CDN, Oracle, Ubuntu)
                               |
                         corporate proxy
                               |
+----------------------------- | -------------------------------------+
| PATCH-01  (RHEL 9, Docker)   v                                       |
|                                                                      |
|  NGINX :443  ── the only port open on this host                      |
|    /                 -> dashboard     static web console             |
|    /api/             -> patch-api     FastAPI: agents, admin, CVEs   |
|    /pulp/api/v3/     -> pulp-api      repository management          |
|    /pulp/content/    -> pulp-content  package downloads              |
|                                                                      |
|  pulp-worker   syncs and publishes repositories                      |
|  postgres      two databases: pulp, patchdb                          |
|  redis         job queue and cache                                   |
|                                                                      |
|  Every service except NGINX publishes NO host port. They talk over   |
|  the internal Docker network "patchnet" by container name.           |
+---------------------------|-----------------------------|------------+
                            | HTTPS 443                   | HTTPS 443
                            v                             v
        ~200 managed servers (agents)          AI-01 (RHEL 9, no internet)
        pull-only: check in, send               NGINX :443, allows PATCH-01 only
        inventory, poll for commands            llama-server on 127.0.0.1:8080
                                                Qwen3-8B Q4_K_M
```

Design rules that run through everything:

- **The verdict comes from a version check, never from the model.** The CVE
  engine decides; AI-01 only explains. Every explanation is labelled as
  advisory in the console.
- **Five applicability states**, stored as a database enum so every screen and
  report reads the same values: `affected`, `fixed_pending_reboot`,
  `fixed_active`, `unknown`, and `not_affected` (implied by absence). Only
  `fixed_active` counts as remediated. A server with the fixed kernel
  installed but not yet booted is **not** remediated.
- **A server that stops reporting shows as "unknown", never as zero.** Silence
  fails toward attention.
- **Agents accept a closed set of eight commands.** None takes a shell string,
  so a compromised PATCH-01 can install signed packages but cannot run
  arbitrary commands as root across the fleet.
- **The audit trail cannot be edited.** A database trigger rejects UPDATE and
  DELETE on the audit log and job events, for every role.
- **Scripts discover what is installed rather than assuming it.** Image names,
  user IDs, data paths, binary locations and supported options are all
  detected at run time.


## What is in this bundle

```
patch-platform/
├── README.md                 this file
├── MANIFEST.sha256           checksums of every file
├── patch01/                  everything for the master server
│   ├── scripts/              run these, in the order below
│   ├── compose/              templates; filled in by the scripts
│   ├── nginx/                ingress configuration
│   ├── sql/                  database schema, applied in order
│   ├── api/                  patch API, CVE engine, AI-01 client
│   ├── dashboard/            web console
│   ├── config/repos.conf     which repositories to mirror
│   └── agent/                copy of the client agent
├── client/                   the agents (Linux: setup-agent.sh; Windows: windows/)
│   ├── patch-agent.py
│   ├── setup-agent.sh, install-agent.sh, push-linux.sh
│   └── windows/
├── ai01/
│   └── ai01-setup.sh         run on AI-01
└── docs/
    └── proxy-allowlist.txt   for the network team
```


## PATCH-01: build order

Run as root from `patch01/`. Each script has `--dry-run`, and most have
`--check`, which you should run after each step.

| Step | Command | What it does |
|------|---------|--------------|
| 0 | `scripts/phase0-bootstrap.sh` | Packages, LVM volumes, `/patch` tree |
| 1 | `scripts/resolve-images.sh` | Finds which local images fill each role |
| 1a | `scripts/phase1a-ingress.sh` | NGINX and TLS on 443 |
| 1b | `scripts/phase1b-data.sh` | PostgreSQL and Redis |
| 1c | `scripts/phase1c-pulp.sh` | Pulp api, content, worker |
| 2 | `scripts/phase2-repos.py --setup`, `--sync`, `--publish` | Mirror the repositories |
| 3a | `scripts/phase3a-schema.sh` | Patch platform database schema |
| 3b | `scripts/phase3b-api.sh` | Build and run the patch API |
| 4 | `scripts/phase4-cve.sh` | Import advisories, compute verdicts |
| 5 | `scripts/phase5-dashboard.sh` | Web console |
| 6 | `scripts/phase6-llm.sh --ai01 <AI-01 IP>` | Connect to AI-01 |
| 7 | `scripts/phase7-vmware.sh --add <name> --host <vcenter>` | Read VM inventory from each vCenter |
| 8 | `scripts/phase4-cve.sh --set-nvd-key` then `--intel` | Fetch published CVE data |
| 9 | `scripts/phase7-vmware.sh --add-writer <name>` | Optional: write account for snapshots and power |
| 11 | `scripts/phase11-clamav.sh` | Optional: ClamAV scans packages uploaded in Deployment |
| 12 | `scripts/phase12-agents.sh` | Agent versions for "Update agents" (phase3b-api.sh publishes the bundle's) |

Step 3b runs two containers from the same image: the API, and the **worker**
that carries out scheduled changes and fills in CVE assessments. On its first
start the API creates the user `admin` from the `ADMIN_PASSWORD` already in
`/patch/secrets/api.env`, so the password you used before still signs in.

The **Assess** page and the chat need no setup beyond the API rebuild: they use
data the platform already holds.

Later schema changes are new files in `sql/` (`001`, `002`, `003`, ...).
Re-running `phase3a-schema.sh` applies any that are missing; it is safe to
run again at any time.

Before step 2, the corporate proxy must be recorded in
`/etc/patch-platform/proxy.env` (`HTTP_PROXY`, `HTTPS_PROXY`, `NO_PROXY`).
Step 2 reads it from there, not from your shell.

**Note on phase 0:** it was written when the plan was Podman, before Docker was
chosen. It installs Podman and moves Podman's image store onto `/patch`, which
is harmless but does not apply to Docker. Docker's own storage location is not
handled by phase 0; phase 1a detects if Docker is still storing images on the
root filesystem and prints the steps to move it.


## Upgrading from r11

```bash
./scripts/phase3a-schema.sh            # schema 009: users, sessions, changes
./scripts/phase3b-api.sh               # API and the new worker; creates 'admin'
./scripts/phase3b-api.sh --check       # confirms the worker is beating
./scripts/phase5-dashboard.sh          # sign-in page, Changes, Users
./scripts/phase7-vmware.sh --add-writer vc-uat   # only for snapshots and power
```

From r15, also run `./scripts/phase8-hardening.sh --fetch <version>` and
update agents to 1.4.0 for hardening scans.

From r14, also run `./scripts/phase7-vmware.sh --sync` once after
`phase3b-api.sh`, so health, alarms and application groups are filled in
before the map is first opened.

Then sign in as `admin` with the old password, open **Users** and create an
account for each person. Update the agents to 1.3.0 before scheduling the
first patch job (see Updating agents). Hard-refresh the browser once
(Ctrl+F5) so it loads the new console.


## The live VMware map

**VMware > Live map** draws the whole estate from vCenter: port groups on the
left, clusters with their ESXi hosts and VMs in the middle, datastores on the
right. Switch to **Applications** to group VMs by application instead.

| Colour | Means |
|--------|-------|
| Neon red | Host down or not responding; datastore 90%+ full or inaccessible; red vCenter alarm; exploited CVEs to patch; host CPU or memory 95%+ |
| Amber | Patches or a reboot due; maintenance mode; yellow alarm; VMware Tools not running; snapshot 7+ days old; datastore 80%+ full or over-provisioned; HA off |
| Green | Running, nothing to act on |
| Grey | Powered off |

A dashed ring round a VM means no patch agent, so its patch state is unknown.

**Blast radius.** Click a host, datastore or port group:

- **Host:** every VM on it, and whether HA restarts it. A VM stays down if the
  cluster has HA off, the host is standalone, a disk is on storage only that
  host sees, or the other hosts lack the memory. VMs are placed largest
  first, the way capacity actually runs out.
- **Datastore:** every VM with any disk on it goes down. HA cannot help.
- **Port group:** VMs with no other network are isolated; the rest degraded.

Each shows the applications hit. Click a VM to trace its host, datastores and
networks.

**Live updates.** The worker holds a change stream open to each vCenter with
the read-only account, and records vMotions, power changes, host failures,
maintenance mode and alarms as they happen. The page checks every 5 seconds;
changed objects ripple, and the side panel shows a live feed. The LIVE light
is green while every vCenter is streaming, amber if one is reconnecting.

**Application groups** come from a vSphere tag in a category called
Application (or App, Service, Workload, System), else the VM's folder. The
**Coverage** tab lists what is ungrouped, and which VMs are on standard
switches only (which cannot export flow records for dependency lines later).

The hourly `phase7-vmware.sh` sync still runs: it refreshes everything the
stream does not carry, such as disks, performance and tags.


## Hardening

Each server is compared with the CIS benchmark as published in the SCAP
Security Guide (ComplianceAsCode): CIS-aligned, not the licensed CIS-CAT
tool. One release is pinned on PATCH-01 and served to every agent, so every
server is judged by exactly the same rules.

**Setting up**

```bash
./scripts/phase8-hardening.sh --fetch 0.1.NN      # release number from the ComplianceAsCode
                                                  # GitHub releases page
./scripts/phase8-hardening.sh --status            # products, rules, CIS levels found
```

The proxy must allow github.com, objects.githubusercontent.com and
release-assets.githubusercontent.com. Without internet on PATCH-01, download
`scap-security-guide-0.1.NN.zip` and its `.sha512` elsewhere, copy both over,
and run `--import-zip scap-security-guide-0.1.NN.zip`.

On every server: agent 1.4.0 (`client/install-agent.sh`) and the OpenSCAP
scanner, from a mirrored repository:

| OS | Package |
|----|---------|
| RHEL 8/9, Oracle Linux 8/9 | `openscap-scanner` (AppStream) |
| Oracle Linux 7 | `openscap-scanner` (`yum`) |
| Ubuntu 24.04 | `openscap-scanner` (universe) |
| Ubuntu 20.04, 22.04 | `libopenscap8` (universe) |

A server without the scanner shows "last scan failed" with the install
command. Then scan from the console, or `./scripts/phase8-hardening.sh --scan`.

**What is scored.** Score = passed rules / (passed + failed). Not applicable
and not checked rules do not count either way. A product whose content has
no CIS profile at the chosen level shows "no L1 profile" rather than a score:
nothing is labelled CIS that is not.

**Evidence.** Every scan's full result file is kept in
`/patch/data/hardening/evidence`, with its SHA-256 shown in the console.

**Custom profiles.** A profile built from your own document checks only
the settings it lists. On the Hardening page, open the profile list and
choose *New or manage custom profiles*: name it, choose the benchmark its CIS
numbers follow (CIS numbering differs between RHEL 8, RHEL 9 and Ubuntu),
and upload the file or paste the list. Every line is shown with the check it
matched and how (CIS number, title, AI-01, or chosen by you). Lines marked
**?** matched by number but read differently, often a sign the document
follows another benchmark version; confirm them. Process items (access
reviews, backups) stay as manual checks and appear in reports as such. Scans
with a custom profile need agent 1.6.0.

**Risky rules** (SSH, PAM and passwords, firewall, sudo, audit, mount
options, boot loader, kernel modules) are marked: fixing them can cut off
access or stop services. Fixes arrive in increment 5, one server first.


## Rolling out agents

**Linux**, from PATCH-01 or a jump host with SSH keys to the servers:
```bash
cd client
./push-linux.sh -H servers.txt -s https://patch01.example --ca corp-ca.pem -u root --test-only
../patch01/scripts/phase10-windows.sh --tokens <N> <group> > tokens.txt     # N from the test run
./push-linux.sh -H servers.txt -s https://patch01.example --ca corp-ca.pem -u root -t tokens.txt
```
**Windows**, from a jump host with WinRM:
```powershell
.\push-agent.ps1 -Computers servers.txt -Server https://patch01.example -Pin system -TestOnly
.\push-agent.ps1 -Computers servers.txt -Tokens tokens.txt -Server https://patch01.example -Pin system
```
`-Pin system` trusts PATCH-01 through Windows' own certificate store, which
needs your CA there (usually by Group Policy); certificate renewals then need
no re-pin. Otherwise use the pin from Admin › Certificate.
Tokens last 72 hours: make them per batch.


## Windows servers

On PATCH-01:
```bash
./scripts/phase10-windows.sh --msrc          # Microsoft's CVE data, 24 months (proxy: api.msrc.microsoft.com)
./scripts/phase10-windows.sh --pin           # the certificate pin for the agents
./scripts/phase10-windows.sh --tokens 1      # one enrolment token (or 50 for push-agent.ps1)
```

On a Windows server, as administrator, from `client/windows`:
```powershell
.\install-agent.ps1 -Server https://patch01.example -Pin <pin> -SelfTest     # checks every step, installs nothing
.\install-agent.ps1 -Server https://patch01.example -Pin <pin> -Token <token>
```
For many servers, from a jump host with WinRM access (each server runs the
self-test first and is only enrolled if it passes):
```powershell
.\push-agent.ps1 -Computers servers.txt -Server https://patch01.example -Pin <pin> -TestOnly
.\push-agent.ps1 -Computers servers.txt -Tokens tokens.txt -Server https://patch01.example -Pin <pin>
```
The pin changes when PATCH-01's certificate is replaced (for example by the
CA-signed one): re-run `install-agent.ps1 -Update` after setting the new pin,
or reinstall. With a CA-signed certificate the pin can be `system`.

**Two views of what is missing.** The advisories come from the OS build and
Microsoft's data, so they include fixes WSUS has not approved. The Windows
Update section shows what WSUS has approved but the server has not installed.
Fixes that are not part of the OS build (.NET, SQL Server) appear only in the
second.


## Reports and branding

**Logo.** Copy a PNG to `/patch/data/branding/logo.png` on PATCH-01 (any
size; a transparent background looks best). Optionally add
`logo-white.png` for dark backgrounds. There is nothing to configure:
PATCH-01 trims, sizes and caches it, and uses the new file as soon as it
changes. **Admin › Branding** shows what it made of it, and any advice (for
example, if the logo is too small to print sharply).

**Company details** on the same page: name, the copyright line for every
footer, and the classification (CONFIDENTIAL, INTERNAL, RESTRICTED, PUBLIC).

**Making a report.** Hardening › **Export report**: choose the report type
(*Management summary*, or *Technical detail* with how to fix each finding),
the scope, an optional cover title, then **PDF** or **Word**. It is built
from each server's latest scan, downloads at once, and stays in the
**Reports** list below with its SHA-256, so a copy given to an auditor can
be matched to the original. Files are kept in `/patch/data/hardening/reports`.

**E-mailing it.** **Email this report** (or **Email** in the Reports list)
opens a window with the report's key figures and a draft from AI-01, which
takes up to a minute on AI-01's hardware. Edit it, add recipients, and send:
the report goes as an attachment, with the signature from Admin › Mail.
Mail must be set up under Admin › Mail first.

The Word version opens with an offer to update fields: say yes, and the
contents gain their page numbers.


## Mail alerts

Set up on the admin **Mail** page:

1. **Relay:** host, port and encryption (STARTTLS on 587 or 25, TLS on 465, or
   none for a plain internal relay). For a mailbox, give its login and
   password. If the relay's certificate comes from an internal CA, paste
   that CA under *Certificate checks*.
2. **Sender:** the mailbox address, and the name recipients see.
3. **Test connection.** Each step is shown, and a failure says what to fix.
4. **What to send** and **when**, then **Save settings**.
5. **Recipients:** add addresses and tick the kinds of mail each receives;
   use **Test** beside each. Then tick *Send mail alerts* and save.

SMTP goes straight from PATCH-01 to the relay, not through the web proxy:
the firewall must allow PATCH-01 to reach the relay's port.

| Mail | When |
|------|------|
| Critical | Within a minute: exploited CVE on a server, ESXi host not connected, vCenter unreachable, datastore at 90% (cleared below 85%), failed change, high-severity hardening drift, worker stopped |
| Task | A change starts or finishes; a scan someone requested completes |
| Daily digest | At the chosen time (Singapore): fleet state and the last 24 hours |
| Weekly summary | The chosen day: the week, and the servers with most to patch |

The relay password is write-only: the console can replace it but never shows
it. It is stored encrypted with `/patch/secrets/mail.key`, which exists only
on PATCH-01. If that key is lost, enter the password again.

From PATCH-01 itself: `./scripts/phase9-mail.sh --status`, `--check`,
`--test ADDRESS`, `--off`, `--on`.


## Users and roles

Everyone signs in with their own account, so the Activity log and every
change record name a person rather than a shared login.

| Role | Can |
|------|-----|
| Viewer | See every dashboard, server, advisory, VMware page, past assessment and change record. Changes nothing. |
| Operator | Everything a viewer can, plus schedule patch jobs and VMware actions, cancel them, run CVE assessments, use the chat and AI explanations. |
| Admin | Everything, plus users, enrolment tokens, decommissioning, and the B-Mode theme. |

Viewers and operators choose between Default and Dark. B-Mode is the
admin's theme only.

Accounts are created on the **Users** page with a temporary password; the
person must choose their own at first sign-in. Passwords need 12 or more
characters from at least three of: lower case, upper case, digits, symbols,
and may not contain the username. Five wrong passwords lock an account for 15
minutes; an admin can unlock it sooner. Sessions last 12 hours of activity and
end when the browser tab closes. The last active admin cannot be disabled or
demoted, so the platform can never be left without one.

Enforcement is in the API, not the console: hiding a button is convenience,
and a viewer calling an operator endpoint directly is refused.


## Patch jobs and VMware actions

Every action that changes something goes through **Changes**. Each change
has a number (`CHG-000042`), a required reason, a window, and a timeline of
every step with who did it. The record cannot be edited afterwards.

Operators do not need approval. If your change process later requires it, set
`REQUIRE_APPROVAL=true` in `/patch/secrets/api.env` and re-run
`phase3b-api.sh`; every change then waits until an admin other than the
requester approves it: **Approve** or **Reject** on the change's page (r90).

**A patch job** is created from **Changes > New patch job**, or from a
server's page with **Patch this server**. For each job you choose:

- What to install: all outstanding security fixes, or only named advisories.
- Reboot: never (the server is flagged instead), only if required, or always.
- VM snapshot: none, take one and keep it, or take one and remove it if
  patching succeeds. Needs the server to be linked to its VM and a write
  account for that vCenter.
- Whether services running before must still be running afterwards.
- The window, and how many servers run at once.

**Preview** shows the exact packages each server will install before anything
is scheduled. Each server then goes through the same steps, and stops at the
first failure without touching the rest:

pre-check (disk space, repositories, running services), snapshot, install,
reboot and wait for it to return, post-check, fresh inventory, snapshot
clean-up. Verdicts are recomputed straight after, so the dashboard reflects
the result at once. A server that fails keeps its snapshot for rollback.

**Cancelling** stops servers that have not started. A server part way through
finishes its current step and stops before installing.

**VMware actions**: take, remove or revert a snapshot; power on; shut down or
restart the guest cleanly through VMware Tools. There is no hard power-off:
PATCH-01 never pulls the power. Only actions valid for the VM's state are
offered.

**Reverting** discards everything since the snapshot. It requires typing the
VM's name, and PATCH-01 first takes a snapshot of the current state, so a
revert can itself be undone.

**Write account.** Syncing uses the read-only account. Snapshots and power use
a separate account per vCenter, added with `--add-writer`, which prints the
exact privileges its role needs and tests the login. Without one, the console
shows VMware actions as unavailable for that vCenter.

The worker must be running for anything to start. The Changes page shows a
warning if it has stopped; `phase3b-api.sh --check` reports it.


## Client servers

Copy `client/` to the server, then as root:

```bash
# On PATCH-01, get a single-use token
./scripts/phase3b-api.sh --token

# On the server
./install-agent.sh --server https://patch01.example --token <token> --insecure
```

The installer checks it can reach PATCH-01, tests inventory collection before
contacting it, enrolls, and installs a systemd timer that checks in every five
minutes. `--insecure` is only for while PATCH-01 has its self-signed
placeholder certificate; use `--ca <file>` once the CA-signed certificate is in
place.

Works on RHEL 8 (it uses the system Python 3.6), RHEL 9, Oracle Linux and
Ubuntu. The agent never routes its traffic to PATCH-01 through a proxy, even
if one is set in the environment.


## AI-01

1. Place the model and llama.cpp under `/llm`:
   `/llm/models/*.gguf` and `/llm/bin/llama.cpp-<tag>/`
2. If llama.cpp is source code, build it on AI-01. The compilers come from
   PATCH-01's own mirror, since AI-01 has no internet:

   ```bash
   # /etc/yum.repos.d/patch01.repo pointing at
   #   https://<PATCH-01>/pulp/content/rhel9-baseos/
   #   https://<PATCH-01>/pulp/content/rhel9-appstream/
   dnf --disablerepo='*' --enablerepo='patch01-*' install -y gcc-c++ cmake make nginx
   cd /llm/bin/llama.cpp-<tag>
   cmake -B build -DGGML_NATIVE=ON -DLLAMA_CURL=OFF -DCMAKE_BUILD_TYPE=Release
   cmake --build build -j"$(nproc)" --target llama-server
   ```
3. Run the setup, giving PATCH-01's address as the only allowed client:

   ```bash
   ./ai01-setup.sh --patch01-ip <PATCH-01 IP>
   ./ai01-setup.sh --check
   ./ai01-setup.sh --show-key
   ```
4. On PATCH-01, run step 6 and paste that key when asked.


## VMware vCenter

Read-only. PATCH-01 reads each vCenter's VMs and snapshots and links every
server to the VM it runs in. Nothing is changed in vCenter.

**Account.** Create a dedicated account, for example
`svc-patch01@vsphere.local`, in each vCenter, and give it the built-in
**Read-only** role at the top of the inventory with **Propagate to children**
ticked. That is all this needs. Snapshot rights are added only later, when
patch jobs take snapshots before patching.

**Add each vCenter** from `patch01/`:

```bash
./scripts/phase7-vmware.sh --add vc-sg01 --host vcenter01.corp.local
./scripts/phase7-vmware.sh --add vc-sg02 --host vcenter02.corp.local
./scripts/phase7-vmware.sh --install-timer        # sync every hour
```

`--add` shows vCenter's certificate thumbprint. Compare it with the one in
the vSphere Client under **Administration > Certificates > Certificate
Management > Machine SSL Certificate** before confirming. Use the vCenter's
name as it appears in its certificate, normally its FQDN, or the connection
is refused. The first `--add` also applies schema 004 and rebuilds the API
with VMware's Python library, which it downloads through the proxy.

**How servers are linked to VMs.** By hardware ID, which VMware sets as the
VM's BIOS UUID and the server reads from its firmware. That needs agent 1.2.0
or later. Older agents are linked by hostname or IP address instead, which is
weaker, and the console shows which method linked each one. A VM that shares
its hardware ID with another, usually a clone, is marked ambiguous rather
than guessed.

**Infrastructure and the map.** The VMware page has a **Map** tab showing
vCenter > datacenter > cluster > ESXi host > VM as an expandable tree, with
each VM marked by its patch and agent state, and a datastore summary. Separate
tabs list ESXi hosts (hardware, CPU model, ESXi version and build, connection
state, maintenance mode, uptime, CPU and memory load, VM count), datastores
(type, capacity, used, free, provisioned beyond capacity, hosts, VMs),
networks and clusters (DRS, HA, totals). Each VM also records its ESXi host,
folder path, datastores, networks, disks with sizes and thin provisioning,
hardware version, Tools version, boot time and provisioned storage.

**What the VMware page shows:** every VM across all vCenters, Windows
included, with a filter box for name, server, cluster or OS; Linux VMs running
without an agent; VMs with snapshots and their age; and ambiguous links.
Windows VMs appear as "not managed", since the Linux agent does not cover
them. Each server page
shows its VM, cluster, ESXi host, size and any snapshots.


## CVE intelligence

Advisories say which package to update; they rarely say what the flaw is.
These four sources fill that in, and every fact is shown with its source:

| Source | What it gives |
|--------|---------------|
| NIST NVD | Description, CVSS score and vector, weakness type (CWE) |
| CISA KEV | Whether the CVE is being exploited in the wild |
| FIRST EPSS | Probability of exploitation in the next 30 days |
| Red Hat | Red Hat's own severity, score and statement for RHEL |

**Get a free NVD API key** first. It raises the limit from 5 to 50 requests
every 30 seconds, and the first import is one request per CVE:

```bash
./scripts/phase4-cve.sh --set-nvd-key      # from nvd.nist.gov/developers/request-an-api-key
./scripts/phase4-cve.sh --estimate         # how long the first import will take
./scripts/phase4-cve.sh --intel
```

A few thousand CVEs takes roughly 30 to 40 minutes with a key, and several
hours without. Afterwards only new and changed CVEs are fetched, so the
nightly run is quick. This is the only part of the platform that reaches the
internet besides repository syncs; it needs four proxy allowlist entries,
listed in `docs/proxy-allowlist.txt`.

**Attack types are derived, not claimed.** "Remote code execution, no login
needed" comes from combining the weakness type with the CVSS vector, and the
console always shows what it was derived from, for example "CWE-362; attack
vector network, no login". Where the published data does not support a
label, it says "Unclassified" rather than guessing.

**This is what makes explanations specific.** Before, every CVE produced
roughly the same answer, because the model was only given an advisory title
such as "kernel security update". It now receives the score, how the flaw is
reached, whether it is exploited in the wild, and the CVE description.
Cached explanations are regenerated automatically when NVD rescores a CVE or
CISA adds it to the exploited list.


## Vulnerabilities

**Vulnerabilities** is one page with three tabs, so a CVE is looked at in one
place whether it came from the feeds, from outside or from a vendor advisory:

| Tab | What it shows |
|---|---|
| **Detected CVEs** | New critical, high and 0-day CVEs from NIST, Microsoft and Red Hat, already matched to our machines by the worker |
| **Advisories** | Vendor advisories (Red Hat, Oracle, Ubuntu...) and Windows updates still to install, with the servers waiting for each |
| **Assess CVEs** | A list given by a SOC, an auditor or a vendor: paste it or upload a text or CSV file |

Every row opens with **+**: for a CVE, the machines it was found on, where
(Linux package, Windows program, operating system, hardware), how certain the
match is and why, and AI-01's brief; for an advisory, its servers and CVEs and
a **Patch these servers** button that opens a patch job already filled in.
Each tab has a search, filters and 20 rows a page.

Every CVE, from any of the three, is checked in the same order:

1. **The CVE database**: what is vulnerable and on which platform.
   - NIST NVD: the affected products, their version ranges, and the platform
     each runs on (NVD's "for Windows" field and its "running on" entries),
     plus description, CVSS, attack type, CISA KEV and EPSS.
   - Microsoft: the products it lists as affected (not those it lists as not
     affected). Its Azure Linux and CBL-Mariner entries are not our platforms.
   - Red Hat: the packages it shipped a fix in, and its own answer per RHEL
     release (fixed in build X, affected with the fix deferred, not affected),
     read once a day per CVE. A component only named in Red Hat's title is
     never matched on its own: Red Hat also lists CVEs RHEL is not affected by.
2. **The assets**: every machine as one record, merged from the agents, WSUS
   and the vCenter guests (and ESXi hosts and vCenters): host name, address,
   operating system and where it is known from. The agent's own report of
   its OS wins over WSUS, and WSUS over the vCenter guest.
3. **Software**: Linux packages, and Windows programs against NVD's version
   ranges. On RHEL, Oracle Linux, Rocky and Alma the installed build is
   compared with Red Hat's fixed build for that machine's release.
4. **Operating systems**: a CVE for Windows 10 or Server 2019 finds a Windows
   10 Pro desktop or a Server 2019 box even without an agent; the edition
   does not hide it.
5. **Hardware and VMware**: server models, ESXi and vCenter versions.
6. **The platform check**: a match counts only when the machine runs a
   platform the vulnerable product runs on. A Windows-only CVE is never put
   on a Red Hat server because a package there has the same name (Windows
   OpenSSH and the openssh package, Git for Windows and git). The machines
   ruled out are listed under the CVE with the reason; a machine whose OS is
   not known is kept, marked so, and never counted as confirmed.
7. **AI-01** writes the brief from those facts, each machine with its OS. It
   never decides the verdict, and a brief written from earlier findings is
   withdrawn when the findings change.

Each machine a CVE is found on is shown with its address, operating system,
what was found, how certain, why, and the source of the match.

**Where the results appear.** The same results feed the Detected CVEs tab,
the Impacted CVEs donut on the Patch Dashboard, AI-01's 15-minute analysis,
each server's "Detected CVEs" on the Servers page, the assistant, and every
export. They are re-checked when a machine's installed versions or OS change
(a patch, an upgrade, a new machine), when Red Hat's per-release answer
arrives, and at least daily. A patched server drops off a CVE at the next
pass, within a few minutes of its agent reporting.

Saved assessments are the exception: each is a record of the answer on the
day it was run, kept as evidence. Run it again for today's answer.

| Verdict | Meaning |
|---|---|
| Affected | A version check confirms it: a package needs the fix, or a version is inside the affected range |
| Possibly affected | The product or OS is present but its exact patch level could not be compared (a Windows build, an ESXi build) |
| Needs reboot | Fixed, awaiting a reboot |
| Not in our inventory | Network devices and firmware: check with their owners |
| Not found | Nothing matching is in the inventory |
| Patched / Not affected | Found and already fixed, or present at a safe version |

"Possibly affected" is deliberately not "affected": it asks a person to
confirm. Each assessment is saved, so the answer can be reopened later and
exported to send back to whoever asked.

## Sorting, selecting, exporting and e-mailing (every page)

- **Sorting:** every table's column headings sort the rows (click again to
  reverse, a third time to undo). Paged lists sort the whole list before
  paging: Assets, Coverage, Antivirus, Detected CVEs, Advisories. Dates sort
  by time and severities by risk.
- **Selecting:** every table has tick boxes. Paged lists remember ticks
  across pages and filters; a filter hides ticked rows without dropping them
  ("+N hidden by the filter"), and actions and exports use only the visible
  ticked rows.
- **Export ▾** offers the whole table as PDF or CSV, and **PDF / CSV,
  selected rows** when rows are ticked.
- **E-mail…** (operators) offers:
  - the reports PATCH-01 builds itself for that page;
  - **This table, as shown**;
  - **Selected rows only**.

  Rows sent from a page are marked "as shown on <page> by <user>". As with
  the other report mails, they go only to the recipients in Admin > Mail,
  count in the 10-an-hour limit and are recorded in Activity before they are
  built.

**E-mail wording.** Every mail opens with "Dear Security Team," and a
security summary, states the **Required action** when there is one, and ends
with "Regards, Cyber-Secure Security Operations" (or the signature set in
Admin > Mail). It carries the line "Classification: INTERNAL – security
information about your environment. Do not forward outside the
organisation." Alerts, digests, reports, hardening and assistant mails all
use this tone.

## Exports

Every page with data has one **Export** button. It offers:

- **PDF report**: landscape A4 with the logo, the report name, organisation,
  date and time (SGT), who made it, the filter in use and the row count; the
  table repeats its heading on every page and each page is numbered.
- **CSV**: for Excel, starting with the same heading lines (a CSV is plain
  text and cannot hold a picture, so the logo is in the PDF).

What is exported is what the page shows with its filters, and every row, not
just the current page (Servers and the Vulnerabilities tabs export all
matching rows). Text that a spreadsheet would run as a formula is neutralised.
Hardening keeps its own formal CIS report (PDF or Word) under the same Export
button, plus CSV. Each export is recorded in Activity.

## Antivirus (Trend Micro Apex Central)

**Admin > Antivirus** holds one entry per Apex Central console: a name, the
console URL (`https://host` or `https://host:port`), the Application ID and
the API key. To get the ID and key, in Apex Central go to Administration >
Settings > Automation API Access Settings > Add, tick "Enable application
integration using Apex Central Automation APIs", and copy both values. Use
an account with a read-only role.

- **Test connection** signs in and lists the agents without saving anything,
  and shows the count, the products and a few names. Test works from the form
  before saving, and on a saved console with its saved key.
- **Read-only by construction.** PATCH-01 only sends GET requests: the
  agent list and the logs (definition status, detections). The code has no
  way to isolate, scan, update, move or uninstall.
- **The key.** It is encrypted with `av.key` (made by `phase3b-api.sh` in the
  secrets folder, kept with the other secrets in backups). It is decrypted
  only in memory to sign a request, never shown again, never logged, and
  never sent to Apex Central either: each request carries a short-lived
  token signed with it, as Trend Micro specifies.
- **The key stays with its console.** Changing a console's URL needs the
  key typed again, so a saved key never signs for another address.
- **Addresses.** The console must be a host name or a full address. Names
  are resolved and checked before connecting, and the connection goes to
  the address that was checked. This machine, link-local and cloud-metadata
  addresses are refused.
- **Self-signed certificate on Apex Central** (usual on IIS). Open
  "Certificate and network" and press **Get certificate**: PATCH-01 makes
  the TLS handshake only, sending nothing, and shows the certificate with
  its SHA-256 and SHA-1 fingerprints. SHA-1 is what Windows calls the
  Thumbprint. Compare it on the Apex Central server, either in IIS Manager >
  Server Certificates > the certificate > Details > Thumbprint, or with:

  ```powershell
  Get-ChildItem Cert:\LocalMachine\My | Select Subject, Thumbprint
  ```

  Then tick "trust exactly this certificate", test and save.
  - Every connection checks that exact fingerprint right after the
    handshake, before anything is sent.
  - If the certificate is renewed or replaced, the connection stops and
    shows the new fingerprint, so you can check it and trust it again.
  - This works even when the certificate is issued to the server's short
    name or lists no names.
  - Changing the console's URL removes the trust; it has to be given again.
- **Certificates.** These are always verified, with no switch to turn that
  off. If the console uses a certificate from your own CA (or IIS's
  self-signed one), paste the CA certificate (PEM) under "Certificate and
  network". Redirects are refused. Internal consoles are reached directly,
  not through the web proxy.
- **Firewall.** PATCH-01 needs HTTPS (443, or the console's port) to each
  Apex Central server.
- **Reading.** Every hour, and at once on **Sync now**. Agents a console no
  longer lists are kept for a week, marked "not listed".

The **Antivirus** page (Asset & Inventory and Patch modules) shows:
- the consoles and when each was last read;
- small tiles: Agents, Outdated definitions, Detections (24 h),
  Ransomware (24 h), No antivirus, Isolated, Not in inventory;
- every agent with its address, product, console, definition status ("up to
  date", "3 versions old"), isolation state, and the machine it is in our
  inventory (matched by address, then full name, then short name). **+**
  opens the domain, folder, MAC addresses, managing server and inventory
  sources;
- **Detections**: the latest AI-01 threat summary, then every detection of
  the last 24 hours or 7 days, filtered by type (virus/malware, ransomware,
  spyware/grayware, behaviour monitoring, machine learning, C&C callback,
  web threat) and "not cleaned only". **+** opens the file, SHA-1, user,
  result and console.

**No antivirus** lists the machines in the inventory (agents, WSUS, vCenter
guests) that no console reports. Each server's **+** on the Servers page
shows its antivirus console. Every view exports as PDF or CSV.

### Antivirus logs and the daily threat summary

Each hourly read also fetches two kinds of Apex Central log (read-only):

- **Pattern Update Status.** Apex Central's own judgement of how many
  versions behind each endpoint's pattern is (0 = up to date, up to 7 = seven
  or more). This is what "Outdated definitions" uses.
- **Detections.** Virus/malware, and where the console offers them:
  spyware/grayware, behaviour monitoring, predictive machine learning, C&C
  callback and web threat logs. Each detection is tagged by type.
  **Ransomware** is recognised by the threat name (Ransom, LockBit and so
  on) and by behaviour monitoring's "unauthorized file encryption".
  **Not cleaned** means the action failed or the file was only passed or
  logged.

Notes:
- Log types are discovered per console. A type the console does not offer is
  shown as unavailable in Admin > Antivirus (Logs column) and tried again
  daily.
- The first read goes back 7 days. Later reads continue from the last log
  read. Detections are kept for 90 days.

**Antivirus threats, daily summary** (Admin > Scheduled reports, 08:05 SGT,
on by default) mails the figures for the last day (or N days): detections,
machines, ransomware, not cleaned, outdated, offline, with the top threats,
the machines with most detections, the not-cleaned list and the full PDF.

- AI-01 writes a short summary from those figures.
- Every number in the summary must be one of the figures it was given.
  Otherwise the summary is dropped and the figures are written out as plain
  sentences instead.
- Threat and machine names come from the antivirus logs and are passed to
  AI-01 as fenced data, never as instructions.
- Each summary is kept with the figures it was written from.

The **AI-01 assistant** answers, from the same data:
- "which machines have outdated antivirus definitions";
- "antivirus agents offline";
- "which servers have no antivirus";
- "any ransomware today?";
- "malware not cleaned this week";
- "antivirus threat summary for 7 days".

**Pushing a definition update from the console is not available.** Trend
Micro's published Apex Central Automation API has no "update now" action
for agents. The only update-related action changes where agents download
updates from. Start the update from the Apex One server console's agent
management (select the agents, then update now), or let the scheduled update
run. PATCH-01 shows which agents are behind so you know where to start.

### Product servers under Apex Central (r69)

One Apex Central can manage several product servers: more Apex One servers,
Deep Security Managers, email security (IMSVA, DDEI, ScanMail) and others.

- **Discover.** Admin > Antivirus > *Products under <console>* > **Discover
  products** asks Apex Central for its product servers (one GET) and lists
  each with its type, address and how many agents it reports. Nothing changes
  until you choose.
- **Choose which to sync.** Tick the servers you want and **Save which to
  sync**. From then on only the ticked servers' agents are kept; agents under
  an unticked server are removed at once and skipped on every read. A server
  that appears later stays off until ticked (shown "new: not chosen yet"). The
  list is read again once a day; a server Apex Central no longer lists is
  shown "no longer listed" and leaves the inventory. Until a choice is saved,
  every agent is synced as before.
- **Deep Security Manager, read directly (optional).** Apex Central shows
  only part of what a Manager knows. **Add API key** on a Manager's row:
  - URL, usually `https://<manager>:4119`.
  - An API key from Deep Security > Administration > User Management > API
    Keys, with a role that can only view computers. Encrypted with `av.key`,
    never shown again, and only ever sent to the URL it was saved with.
  - **Get certificate** reads the Manager's certificate (handshake only) and
    says what it is: signed by a CA PATCH-01 already trusts (nothing to do),
    signed by your own CA (paste that CA, or trust the certificate by its
    fingerprint), self-signed (compare and trust it by its SHA-256
    fingerprint), or expired.
  - **Test** signs in and counts the computers; **Save** starts reading it
    every hour with its console (**Sync now** for at once).
  - Only GET requests are made. The Manager's computers then replace Apex
    Central's copies, with their status, OS, last contact and pattern version,
    but only while the direct read works: if it fails (key, certificate),
    Apex Central's list counts again, so no machine looks unprotected because
    of a settings problem. **Remove key** goes back to Apex Central's list.
- **Antivirus page > Product servers synced** tile and tab: every product
  server, whether it is synced, its agents and how it is read.
- **Inventory.** Ticked product servers join the asset list as seen by
  Apex: Apex One servers and Deep Security Managers as servers, email
  security as appliances (unless the OS or a person says otherwise).
- **Assistant.** "List the Deep Security Managers", "which Apex One servers
  are synced", "email security servers".
- Every discovery, choice, key save, test, certificate read and removal is in
  the audit log; tests and certificate reads count toward the 20 checks per
  10 minutes.

## Reports by e-mail

Every main report can be e-mailed in the branded mail, with a summary, the
first rows and the full report attached as PDF or CSV:

| Report | From the page |
|---|---|
| Antivirus threats, AI summary (malware, ransomware) | Antivirus |
| Antivirus health (outdated definitions, offline, no antivirus) | Antivirus |
| Antivirus agents; machines with no antivirus | Antivirus |
| Servers (with the page's filters) | Servers |
| Detected CVEs | Vulnerabilities |
| Advisories to install | Vulnerabilities > Advisories |
| Activity (admins) | Activity |

- **At once:** Export > **E-mail…** on the page (operators and admins).
  Choose the report, PDF or CSV, and the recipients.
- **On a schedule:** **Admin > Scheduled reports**, or **Schedule…** in the
  same panel (admins). Every day, week or month at a set time (SGT).
  Schedules can be turned on and off, sent now, edited and removed.
- **Antivirus health, daily** (08:00) and **Antivirus threats, daily
  summary** (08:05) are set up for the daily-digest recipients. Mail must be
  on (Admin > Mail).

Safeguards:
- Each report is built on PATCH-01 when it is sent, never from what a
  browser sends.
- Reports go only to the recipients set in Admin > Mail.
- At most ten e-mailed reports an hour per user. Each one is in Activity.
- The attachment is removed from the database once the mail is delivered.
- Failed sends are retried, like every other mail.

**Antivirus health** judges each agent:
- **Definitions outdated:** Apex Central's Pattern Update Status says the
  pattern is 2 or more versions old. If that log is not available, the
  version is compared instead: more than N releases (default 4) behind the
  newest version seen for that product.
- **Offline:** Apex Central's last-connected time is older than N hours
  (default 24), or Apex reports it offline.
- **No connection data from Apex:** the agent counts as offline when its
  machine has not been seen by our agent or WSUS for N hours, or is powered
  off in vCenter. The mail says which rule was used.
- **No longer listed:** Apex Central has stopped listing the agent.

Definition versions and connection times appear in Apex Central's agent
list only on some versions; they are not in Trend Micro's published API
reference. Admin > Antivirus shows, for each console, whether they are
present ("definitions ✓", "connection ✓") and the fields it sends. If they
are missing, the mail says so instead of guessing.

## Asset inventory

**Asset & Inventory > Assets** is the **master asset list**, one list with
tabs that are views of it, so they always agree:

- **Master:** every machine.
- **Servers**, **Laptop/Desktop**, **ESXi**, **Appliances**, **Network**,
  **Firewalls**, and **Unknown** (shown only when there are any).
- **Powered off:** VMs that vCenter reports powered off or suspended (and our
  agent has not reported from for 7 days). The tab shows power, vCenter,
  folder and the VM's created date. They are kept out of Master, the type
  tabs, the type counts and WSUS/Apex coverage. When a VM is switched back
  on, it returns to Master on the next vCenter read.
- **Templates:** vCenter VM templates, with OS, vCenter, folder, CPU,
  memory, disk, created date and notes. Templates are not machines: they
  never appear in Master, the VMware actions, patching or coverage. Export
  works; approve, decom and Set type do not apply.
- **Hardware:** only physical machines that a source actually describes
  (make, model, serial, CPU or memory), one row per physical box. Two names
  with the same serial number are shown once ("also <name>"). ESXi hosts get
  these details from vCenter; other machines from the sheet's Make, Model
  and Serial columns.

**VM created date:** vCenter's own creation date for each VM (vSphere 6.7
and later), shown as "VM created" on Master and the Powered off tab, in each
VM's **+**, and in exports.

At the top, four small charts:
- assets by type (click a type to open its tab);
- the share approved;
- the share of Windows machines in WSUS;
- the share of Windows machines in Apex. The last two open the Coverage page.

**How the type is decided, in this order:**
1. A person's choice: **Set type…** on ticked machines (Approve permission).
   Choosing "Automatic" hands them back.
2. vCenter's facts: ESXi hosts, and the vCenter appliance.
3. The OS: Windows Server or a Linux distribution is a Server; Windows 10/11
   or macOS is a Laptop/Desktop. FortiOS, PAN-OS, Check Point, Sophos or ASA
   is a Firewall. IOS, NX-OS, Junos, Arista EOS or ArubaOS is Network.
   Storage, load balancers, UPS and similar are Appliances.
4. The sheet's device column (Firewall, Switch, Laptop, Storage...).
5. The name (fw-, sw-, core-, ups-, ltp-...), only when nothing else says
   anything.
6. AI-01, for the machines still uncertain. It is shown the name, OS,
   sheet type, make/model, whether it is a VM and which sources see it, and
   must answer with one of the types and a short reason (shown on hover,
   marked "AI"). Each machine is asked once, and again only when those
   details change.

**Safeguards:**
- A machine with our agent, or one that WSUS or Apex sees, or that runs
  Windows, can only be a Server or Laptop/Desktop by rules, sheet, name or
  AI-01.
- Only a person can type it otherwise, with a reason, and it is still checked
  for WSUS and Apex.
- ESXi hosts, appliances, network devices and firewalls are never expected in
  WSUS or Apex.

**Export selected:** tick machines (on any tab, or "Select all matching") and
press PDF or CSV. Only the ticked rows are exported, with the logo, date and
your name, in that tab's columns. The page's **Export** still exports the
whole filtered list.

**Asset & Inventory > Assets** lists every machine, merged by host name from:
agents, vCenter (VMs, ESXi hosts, the vCenters), WSUS, Apex Central (every
antivirus agent), and the asset sheet an admin uploads. Decommissioned
machines move to their own page.

**Which OS is shown.** Servers: the agent's, then WSUS, then vCenter (these
are accurate for servers). Laptops and desktops: Apex Central's Windows 10/11
comes first, because WSUS can report the wrong desktop version. Apex's OS
never replaces one that vCenter or WSUS reports as a server. Apex's OS comes
from its agent list when the console sends it, or from its Pattern Update
Status log. **+** shows every source's OS.

**Approved automatically.** A New machine found in both WSUS and the uploaded
sheet is approved at once when a sheet is applied, and hourly after that. It
is recorded as approved by "auto", with the reason, in its history and in
Activity. A machine a person has revoked or decommissioned is never approved
automatically again.

Columns:
- **Hostname**.
- **Device:** Server, Laptop/Desktop, Appliance or Unknown, from the OS
  (hover for the reason). An OS name the rules cannot place is given to AI-01,
  marked "AI".
- **Operating system**.
- **IP:** clean addresses only, no brackets or quotes.
- **Detected:** Agent, Virtual (a vCenter VM), vCenter (ESXi host or
  appliance), WSUS, Apex, Manual (the uploaded sheet).
- **Location:**
  - a VM: the vCenter that runs it;
  - an ESXi host: its vCenter;
  - anything else: the sheet's location if given, otherwise Laptop/Desktop
    (Windows 10/11, macOS) or Physical server (not in any vCenter PATCH-01
    reads).
- **Status:** New (awaiting approval), Approved.
- **Last detected**.

20 machines a page. Tiles count Servers, Laptop/Desktop, Appliances,
Unknown, Awaiting approval, Approved and Decommissioned; clicking one filters.
**+** shows what each source reports (OS per source, vCenter, cluster, ESXi,
WSUS groups, the sheet's serial and owner) and the machine's history.

**Approve, Decom, Revoke.** Tick machines (or "Select all N matching"), then:
- **Approve:** the machine is confirmed as an asset (New → Approved).
- **Decom:** it moves to **Decommissioned** with who, when and a reason
  (required).
- **Revoke:** takes the last decision back. On Assets an approval goes back to
  New. On Decommissioned the machine returns to Assets with the status it had.

Who may do what is set per user in **Admin > Access** (Approve, Decom,
Revoke). Admins can always do all three. Each decision is kept in the asset's
history and in Activity, with the user, the time and the reason. The server
checks the permission on every request, whatever the browser shows.

**Decommissioned** lists each machine with who decommissioned it, the date
and time, the reason, and who approved it. A machine still detected by a
source after its decommission date is flagged ("still detected"). It is also
kept on the Antivirus "No antivirus" list while anything still shows it
running.

**Uploading a sheet** (admins: **Upload sheet**):
- **Files:** Excel `.xlsx` or CSV, up to 5 MB and 5,000 rows. Older `.xls`
  and macro workbooks: save as `.xlsx` or CSV.
- **Columns:** AI-01 is shown the headings and five rows, and says which
  column is the host name, IP, OS, device type, location, serial, owner and
  notes. Each choice is checked against the cells: a host-name column must
  hold host names, an IP column addresses. A choice that fails, or no
  answer, falls back to the heading rules. You can change any column in the
  preview.
- **Rows:** each row is checked and tidied before anything is saved:
  - "PC-002 (old)" is read as PC-002; a name with other spaces is refused;
  - addresses are split and checked; an invalid one is left out;
  - shorthand OS names are written out ("win10", "rhel 9", "2019");
  - device words are mapped (Laptop, Notebook → Laptop/Desktop; Switch,
    Firewall → Appliance);
  - duplicates keep the later row.
- **Preview:** each row shows what happens (New, Already found by a source,
  Update, Skipped) with every fix, problem, and difference from what the
  sources report (another OS, another address, decommissioned).
- **Apply** saves the rows as Manual assets. New machines wait for approval.
  "Also remove Manual assets from earlier sheets that are not in this one"
  names what it would remove first, and is refused when fewer than half the
  rows passed the checks.
- **Safety:** the file is read on PATCH-01 only, never by AI-01. Workbooks
  with DTDs or entities, UTF-16 parts, password protection, or that expand
  past 60 MB are refused. Excel is parsed with defusedxml. Cell text reaches
  AI-01 only as fenced data, never as instructions. At most 20 uploads an hour
  per admin. Each upload and apply is in Activity. The sheet's cells are
  dropped once it is applied or discarded.

**Check with AI-01** (anyone with an asset permission; also every 6 hours on
its own):
- AI-01 places the OS names the rules cannot (server, laptop/desktop,
  appliance, or unknown). Any other answer counts as unknown, and each name is
  asked once.
- The sources are then checked against each other, and the findings listed:
  - one address used by several names;
  - Windows on one source and Linux on another;
  - machines only in the sheet;
  - approved machines not detected for 30 days, or not at all now;
  - decommissioned machines still detected;
  - unknown device types.
- Findings are shown for a person to act on. Nothing is merged, approved or
  decommissioned automatically.

### Coverage: missing in WSUS or Apex

**Asset & Inventory > Coverage** lists every machine that should be in WSUS
or Apex Central but is not, with why and what to do.

**What is expected:**
- A Windows machine should be in both WSUS and Apex.
- A Linux machine should be in Apex, once Apex covers any Linux machine.
- Appliances, ESXi hosts, vCenters and decommissioned machines are left out.
- The machine's type comes from the OS the inventory trusts, so a wrong OS
  from one source does not create a gap.

**The reason** is taken from what the other sources show:

| Reason | Priority |
|---|---|
| Running (seen by our agent, vCenter powered on, WSUS or Apex) but not in it | High for Apex, medium for WSUS |
| Listed in Apex but not reporting for 2 days | High if running, else medium |
| The same address is known there under another name | Medium |
| Powered off in vCenter | Low |
| Only in the uploaded sheet | Low |
| Not seen recently | Low |

Each row says what to do. Examples: check the Windows Update policy points at
WSUS; install the Apex One agent, or Deep Security on Linux servers; check the
agent service; decommission the machine if it is gone.

**Tiles** show:
- the share of Windows machines in WSUS and in Apex;
- Missing in WSUS, Missing in Apex, Apex not reporting;
- High priority.

Filters: priority and reason. 20 a page. Export, and E-mail
("Asset coverage gaps"), which can also be scheduled in Admin > Scheduled
reports.

**Analyse with AI-01** (anyone with an asset permission; also on each
scheduled send of the report):
- AI-01 writes the coverage, the main patterns and what to fix first, from
  the counts.
- Every number it writes must be one of those figures. Names are not counted
  as figures, numbers written as words are refused, and if the check fails
  the figures are shown instead.
- Machine and location names reach AI-01 only as fenced data.
- Each summary is kept with its figures.
- The same check now also protects the antivirus threat summary.

The assistant answers "which machines are missing in Apex",
"WSUS coverage gaps" and "high-priority inventory gaps".

## Servers

**Servers** is one page for the servers and their agents (the old Agents page
opens it too):

- a green light is an agent online (checked in within 15 minutes), red is
  offline, not reporting or never reported; hover for when it was last seen;
- **+** opens a server's details in place (agent, last seen, uptime, reboot,
  what is still to install, worst CVSS, hardening score, VMware placement),
  with a link to the full server page;
- filters for name or address, operating system, agent state, patches, group
  and agent version, and a sort; the tiles filter on online or offline;
- 20 servers a page, computed on the server, so it stays fast with hundreds;
- **Export** (PDF report or CSV, see Exports) covers every server matching
  the filters, not just the page.
- **AI-01 analysis**: every 15 minutes the worker gathers the figures (agent
  states, patch backlog, reboots, impacted CVEs, and what changed since the
  last time) and AI-01 writes a short note: the state of the estate, what
  changed, what to do first. Each note is stored with its figures; if AI-01 is
  unavailable the figures are written as plain sentences instead, marked so.

Every other CSV the console exports (assessments, the assistant, inventory)
now starts with the same heading.

## Modules and access

The console has three modules, shown as glowing buttons on the welcome page
and on the home page after sign-in:

| Module | Opens | Pages |
|---|---|---|
| Patch Dashboard | `#/dashboard` | Dashboard, Servers, Vulnerabilities (Detected CVEs, Advisories, Assess), Hardening, Windows, patch changes |
| Asset & Inventory | `#/assets` | Inventory (assets, software), VMware |
| Software Lifecycle | `#/deployment` | Windows software, Linux packages, Deployment, software changes |

**Admin > Access** chooses which modules each user may open. A user's own
modules glow on the home page; the others are greyed out, their menu entries
are hidden, and the API refuses their data and actions on every request,
whatever the browser does (VMware changes need Patch or Inventory; software
changes need Lifecycle; patch changes need Patch). Admins always have all
three. Existing users keep all three when r54 is applied; **new users start
with none** until an admin grants them, and an admin who is made a viewer or
operator loses all three until granted again. The assistant answers only from
the modules the user has, and so do its exports and e-mails. Activity hides
other users' sign-ins, assistant questions and account changes from
non-admins.

## Impacted CVEs

Every new critical, high or 0-day (exploited) CVE from the feeds is matched
against the inventory by the worker: Linux packages and the CVE engine's
verdicts, Windows programs (with NVD's version ranges where given), Windows
editions (agents, WSUS, VM guests), ESXi and vCenter versions, and server
hardware models. Each gets a verdict (affected, fixed but reboot needed,
possibly affected, not in inventory, not inventoried) and the list of machines.
AI-01 then writes a short brief for the impacted ones, most serious first; it
never decides the verdict. The analysis repeats when the inventory changes and
at least daily; **Analyse again now** on Vulnerabilities > Detected CVEs redoes
all of them. The **Impacted CVEs** donut leads the Patch Dashboard.


## Cyber-Secure dashboard and CVE feeds

The console opens on the **Cyber-Secure** dashboard. Every figure is computed
live from the database and the page refreshes itself every minute, so a server
enrolled a minute ago is already counted. Six donuts, each with a legend that
names every slice (hover or tab to a slice for its count):

- **Servers**: patched, needs patches, needs a reboot, not reporting (each
  server once, by its worst state).
- **Updates**: per server and update, to install (Linux advisories and Windows
  updates), installed but waiting for a reboot, installed.
- **Outstanding by severity**: distinct advisories and Windows updates still
  to install.
- **Operating systems**, **Agents**, and **New CVEs (feeds)**.

Under them, **CVE news** lists new CVEs from **NIST NVD, Microsoft and Red Hat**
for the software you follow, and any CVE already linked to one of your servers.

**Admin > CVE feeds** chooses that software: type a name, or click one of the
suggestions taken from what your servers run (Windows programs, notable Linux
packages, your operating systems). There you also switch sources on or off,
set how many days to show, the lowest CVSS, how often to read, and press
**Read the feeds now**. The worker reads the feeds through the proxy
(services.nvd.nist.gov, api.msrc.microsoft.com, access.redhat.com, already in
docs/proxy-allowlist.txt). Without an NVD API key NIST is read slowly; save a
free key in `/patch/secrets/nvd-api-key` and run `phase3b-api.sh`.

The **sign-in page** shows the logo (the same one the mails use, from
`/patch/data/branding`), "Welcome to the Cyber-Secure Dashboard portal", and a
news board of the latest critical and high CVEs from NIST, Microsoft and Red
Hat. Before sign-in only the general feeds are shown, never your watch list,
so the page does not reveal what software runs here; it can be switched off
in Admin > CVE feeds. These unauthenticated answers are built at most every
two minutes, whoever asks.


## The assistant

The icon at the bottom right of the console opens the assistant. It is a
floating window: drag it by its title bar, resize it from the bottom-right
corner, enlarge it (⤢) or send it back to the corner (↵). Its place and size
are remembered in this browser.

**⧉ Pop out** lifts it into its own small window that stays **on top of every
other application** (Chrome and Edge 116 or later), so it can sit over Outlook,
vCenter or a remote desktop while you work. **Back to page**, or closing that
window, returns it. It is the same session in the same tab: nothing new is
signed in or stored.

Ask in plain words about servers, patches pending or installed on a server,
CVEs, Windows updates and KBs, WSUS, changes (CHG numbers), hardening scores,
VMs, ESXi hosts, datastores, installed software, agents, and the asset
inventory, including any operating system version or edition ("Windows 10 Pro
list", "how many Windows 11", "Windows Server 2019 without an agent", "RHEL 8").
Every answer shows the rows it came from.

- **Export**: add "export" or "csv" to a question, say "export that" after an
  answer, or press **Export CSV**. The server re-runs the same query with up to
  5000 rows; formula-like cells are neutralised.
- **E-mail**: add "email to ops team" or an address, or press **E-mail**. The
  assistant shows a draft (to, cc, subject, message, CSV attached) and
  **nothing is sent until you press Send**. It may mail only the configured
  mail recipients and addresses at their mail domains (and the sender's), at
  most ten mails an hour per user; each mail is in the audit log and the mail
  history. The server re-reads the data itself: the browser cannot change
  what is attached.
- **Speaking**: tick **Read answers aloud**, or press **Read** on an answer.
  Only the computer's offline voices are offered (on Windows, the installed
  Windows voices); voices that would send text to an online service are never
  used. Typing is the only input: browser voice input sends audio to an
  online service, so it is not offered.

It is **read-only**. Patching, snapshots, power and software actions go
through the approval flow, never from a sentence typed into the assistant.

How it answers, and why it can be trusted:

- AI-01 only chooses **which prepared query to run**, from a fixed list. It
  never writes database queries, never sees a row of data, and never supplies
  a figure that appears in an answer. Text stored in the database (a server
  name, a program name, a CVE description) therefore cannot instruct it.
- Parameters are rebuilt against a type and range before use, so a confused or
  manipulated model cannot widen a query.
- Export and e-mail are recognised by PATCH-01's own code, not by the model.
- If AI-01 is unreachable, keywords choose the query and it still works.

Operators and admins.


## Keeping the dashboard truthful

The console can only be as current as the last repository sync. If the mirror
is behind, the platform will report a server as patched because the newer
advisory is not in the mirror yet, while `dnf` talking to the vendor directly
sees it. Sync, import, then compute, in that order:

```bash
./scripts/phase2-repos.py --sync --publish
./scripts/phase4-cve.sh --import
./scripts/phase4-cve.sh --compute
```

`phase4-cve.sh --install-timer` runs the import and compute nightly; schedule
the repository sync a couple of hours earlier so the engine has fresh
advisories to read.


## Everyday operations

| Task | Where | Command |
|------|-------|---------|
| Open the console | browser | `https://patch01.example/` |
| Issue an enrollment token | PATCH-01 | `scripts/phase3b-api.sh --token` |
| Sync repositories | PATCH-01 | `scripts/phase2-repos.py --sync` then `--publish` |
| Recompute verdicts now | PATCH-01 | `scripts/phase4-cve.sh` |
| Verdicts for one server | PATCH-01 | `scripts/phase4-cve.sh --host <name>` |
| Fleet report in the terminal | PATCH-01 | `scripts/phase4-cve.sh --report` |
| Pre-generate explanations | PATCH-01 | `scripts/phase6-llm.sh --warm 20` |
| Nightly CVE run and explanations | PATCH-01 | `phase4-cve.sh --install-timer`, `phase6-llm.sh --install-timer` |
| After a Red Hat certificate refresh | PATCH-01 | `subscription-manager refresh`, then `phase2-repos.py --update-remotes` |
| Health of the whole stack | PATCH-01 | each script's `--check` |
| Agent status, one server | client | `install-agent.sh --status` |
| Agent status, whole fleet | browser | **Agents** page |
| Model server status and speed | AI-01 | `ai01-setup.sh --check`, `--bench` |
| vCenter status | PATCH-01 | `scripts/phase7-vmware.sh --check` |
| Start (or repair) everything, then health check | PATCH-01 | `scripts/patch01-start.sh` (`--install-boot`: at every boot) |
| Start (or repair) the model server and nginx | AI-01 | `ai01-start.sh` (`--install-boot`: at every boot) |
| Update PATCH-01 itself, then health check | PATCH-01 | `scripts/patch01-update.sh --all --reboot` (no option: health check only) |
| Update AI-01 itself, then health check | AI-01 | `ai01-update.sh --os --reboot` (no option: health check only) |
| Refresh CVE data | PATCH-01 | `scripts/phase4-cve.sh --intel` |
| What is exploited in the wild | PATCH-01 | `scripts/phase4-cve.sh --report` |
| Sync vCenters now | PATCH-01 | `scripts/phase7-vmware.sh --sync` |


## Updating agents

Re-run the installer on the server with the new `client/` files. It keeps the
server's existing identity, so no new token is needed:

```bash
./install-agent.sh --server https://patch01.example --insecure
```

The **Agents** page lists any server still on an older version. The current
agent is **1.5.0**, which patch jobs need: it installs exact versions,
records running services before patching so they can be checked afterwards,
and carries out a job's steps in sequence.

Agent states:

| State | Meaning |
|-------|---------|
| Online | Checked in within 15 minutes |
| Offline | Missed several check-ins, but under 24 hours |
| Not reporting | Silent over 24 hours; its verdicts show as unknown |
| No data yet | Enrolled but never checked in |

Agent 1.1.0 and later report boot time, from which uptime is shown. Older
agents keep working but show uptime as "not reported".


## Starting everything, and keeping it started

After a restart, an update, or whenever something is down, one command per
server starts every part in the right order, repairs what does not come up,
and runs the full health check:
```bash
sudo ./scripts/patch01-start.sh          # PATCH-01, from the bundle's patch01 folder
sudo ./ai01-start.sh                     # AI-01, from the bundle's ai01 folder
```
Make it happen at every boot (recommended, once per server):
```bash
sudo ./scripts/patch01-start.sh --install-boot
sudo ./ai01-start.sh --install-boot
```
PATCH-01's order is docker, ingress (nginx and the shared network), data
(PostgreSQL, Redis), pulp, API and worker, dashboard, then ClamAV if
installed; each part must be healthy before the next starts. A part that does
not come up is repaired once by re-running its own phase script; if it is
still down, the start stops there and names the part, with its last log lines
in `/var/log/patch-platform/patch01-start-*.log`. Docker is started (or
restarted once if it does not answer) and enabled at boot. On AI-01,
llama-server starts first, then nginx (only with a configuration that passes
`nginx -t`); if an OS update broke llama-server's libraries, it says so. The
update scripts below call these automatically after updating and after a
restart.

## Updating PATCH-01 and AI-01 themselves

Each server has its own update script. With no option it only checks health
and changes nothing; it exits 0 when healthy and 1 when not, so it can also be
run from monitoring.

PATCH-01, from the bundle's `patch01` folder:
```bash
sudo ./scripts/patch01-update.sh                         # health check only
sudo ./scripts/patch01-update.sh --dry-run --all         # what would be updated
sudo ./scripts/patch01-update.sh --all --reboot          # OS and images, restart if needed
sudo ./scripts/patch01-update.sh --os --security --yes   # security updates only, no questions
```
AI-01, from the bundle's `ai01` folder (next to `ai01-setup.sh`):
```bash
sudo ./ai01-update.sh                                    # health check only
sudo ./ai01-update.sh --os --reboot                      # OS updates, restart if needed
sudo ./ai01-update.sh --bench                            # health check with a speed test
```

What they do: refuse to run twice at once; on PATCH-01, refuse while patch jobs
are running; check health **before** (no update starts on a broken system);
back up (PATCH-01: every database, the image and package lists; AI-01: nginx's
configuration and the llama-server unit) to a root-only folder, keeping the
last 5; update; check health **after**. With `--reboot`, a restart happens
only if needed and only when healthy, and a one-shot service checks health
again after boot. The last result is in `update-last.txt` in each server's log
folder (`/var/log/patch-platform/`, `/llm/logs/`).

PATCH-01's health check covers disk, failed services, the clock, every
container (running and healthy), the API and console through the ingress, the
worker's heartbeat, the certificate's expiry and each phase script's own
`--check`. AI-01's covers `ai01-setup.sh --check` (loopback-only model server,
HTTPS, refusals without the key, model checksum) plus the model server's
network lock-down and sandbox, nginx's configuration and the listening ports.

Images: `--images` re-pulls each image by its current tag and redeploys only
the stacks whose image changed. A PostgreSQL **major** version change is
refused (that needs a dump and restore). Update AI-01 after PATCH-01: its
packages come from PATCH-01's mirrors.


## Change log

**r92: start, repair and keep started (PATCH-01 and AI-01)**
- **scripts/patch01-start.sh** and **ai01/ai01-start.sh**: start every part in
  order (each healthy before the next), repair once what does not come up,
  stop and name the part that still fails, then the full health check.
  `--install-boot` runs them at every boot. See "Starting everything, and
  keeping it started".
- The update scripts now start and repair every part after updating and
  after a restart, instead of only reporting what is down (r91 left the
  console down when an update stopped containers).
- A failed redeploy during `--images` no longer stops the update half-way:
  it is reported, every part is started and repaired, and the run exits 1.

**r91: update scripts for PATCH-01 and AI-01, with health checks**
- **scripts/patch01-update.sh** (PATCH-01) and **ai01/ai01-update.sh** (AI-01):
  OS updates (and on PATCH-01, container images), a backup first, and a
  health check before and after; `--reboot` restarts only when needed and
  checks health again after boot. With no option: a health check only. See
  "Updating PATCH-01 and AI-01 themselves".
- Safe to schedule: one run at a time, `--yes` for no questions, refused while
  patch jobs run, root-only logs and backups, and they refuse to run from
  files anyone but root could change.
- No change to the console, the API, the agents or the schema.

**r90: Clean-up and speed-up (pages look and work the same); schema 049; Windows agent 1.9.4**
- **Faster at fleet scale** (measured with 2,000 servers, 85,000 Windows
  programs, a million Linux packages): Servers 10.4 s to 0.4 s; Deployment's
  per-package server list 10.1 s to 0.2 s; Dashboard 1.7 s to 0.14 s;
  Overview 1.0 s to 0.2 s; Linux packages 1.4 s to 0.25 s; CVE feed
  suggestions 4.6 s to 1.7 s. Most of it was PostgreSQL's JIT compiler
  (7 s to compile a 0.1 s query): schema 049 turns it off for this database
  and adds two indexes.
- **Scripts and styles load about 4x lighter**: sent compressed (about 890 KB
  to 235 KB), and kept by the browser until the next upgrade (index.html
  names each file by its fingerprint). phase5 --check tests both.
- **Installers on a share removed for good**: the old page and job form, its
  API (catalog and share credentials), the worker steps, the credential store
  (/run/patch01-vault and run.key: phase3b removes both) and the agent's
  share copy (agent 1.9.4). Software jobs come from Deployment only; old
  links open Deployment. A share job booked before r90 that has not run yet
  fails with the reason instead of waiting.
- **Unused code removed**: 16 API endpoints nothing called (old agents list,
  old news, old VMware events, CVE-intel status, mark-stale and others);
  unused helpers, constants and imports in 20 Python modules; 13 dashboard
  functions (one a second "sevChip" that silently replaced the first) and 9
  unused variables; 59 style rules for classes no page uses.
- **One stylesheet**: shell.css merged into style.css in the same cascade
  order; every element of every page compared in all three themes at desktop
  and phone width: same look. phase5 removes the old shell.css.
- **The API code split by area**: main.py was one 8,000-line file; it is now
  core.py (app, sign-in, shared helpers) and 16 area modules (api_*.py).
  Statements moved unchanged; every endpoint keeps its path, role,
  parameters and code, and its order where order matters.
- **Approve / Reject on a change's page** when approval is switched on
  (REQUIRE_APPROVAL and similar): a waiting job had no button before.
- Deploy: phase3a-schema.sh (049), phase3b-api.sh, phase5-dashboard.sh. The
  Windows agent update to 1.9.4 is optional (Servers > Agent updates): 1.9.3
  keeps working.

**r89: Software reorganised and in sync with Deployment; end of support / end of life; the assistant knows the whole portal**
- **Software** is now **Windows software**, **Linux packages** and **Deployment**.
  "Installers on a share" is retired (its old link opens Deployment).
- **Windows software / Linux packages**: one row per program with its versions
  and server count; open it for each version and every server (patch group,
  address, installed date, 64/32-bit). No removal wording on the page: tick
  servers under a version and **Choose action** (Upgrade, Install, or Remove
  for admins) when you want to.
- **In sync with Deployment**: each Windows program is matched to the newest
  ready package in Deployment (by the package's "recognised by" name, as the
  agents do). Programs and versions older than the package are coloured amber
  ("upgrade available"), with a tile and filter; "Upgrade N older servers…"
  and "Install on more servers…" open Deployment's form with the package,
  the action and the servers already chosen.
- **End of support / end of life (the frame)**: rules per product (and
  optionally per version line) in **Admin › Software rules**; every version
  shows Supported, End of life soon (within 180 days), End of support or End
  of life, with a "Past end of support" tile and filter. A vendor feed can fill
  the same rules later. The removable-programs list moved to the same Admin
  page.
- **AI-01 assistant**: answers from the same data the pages use (patching from
  what each server reports, CVEs proven on our machines as Detected CVEs shows
  them) and now covers Nessus findings and scans, Deployment packages,
  upgrades available, end of support / end of life, installed patches, and
  "where is / how do I" questions for every page. A release test fails if a
  page in the menu is unknown to the assistant.
- **Removing software is admins only everywhere**, including Deployment's
  "Remove" (operators still install and upgrade packages), and follows the
  same rules: never critical software, only listed programs.
- phase5-dashboard.sh checks that the assistant knows every page in the menu
  (scripts/check-assistant-coverage.py) and stops if not.
- Schema **048**. Deploy: phase3a-schema.sh, phase3b-api.sh,
  phase5-dashboard.sh. No agent changes.

**r88: Software under one roof; installed software by program; removing listed tools (Windows agent 1.9.3)**
- **Software** now holds everything about software: **Installed software**
  (moved from Inventory), **Deployment**, **Installers on a share**, and the new
  **Removable tools**.
- **Installed software**, rebuilt for tracking: one row per program with its
  versions (and how many servers run each) and its server count; open a program
  to see each version, then every server that has it, with its patch group,
  address, installed date and 64/32-bit. Tiles (programs, machines, programs
  with several versions, removable tools found), filters by server name,
  removal state and "several versions only", and an export of every program,
  version and server. Windows programs and Linux packages.
- **Removing installed programs (admins only, no approval)**: tick servers
  under a version and press Remove; a job runs (now or at a set time) in
  Patching › Jobs, audited. Default deny:
  - only programs whose name starts with an entry of **Removable tools**
    (starts with common tools: 7-Zip, Notepad++, WinRAR, PuTTY, WinSCP,
    Wireshark, browsers, remote-support tools...; admins add or take off);
  - **critical software is never removable**, whatever the list says, and
    cannot be added to it: SQL Server and every other database, antivirus and
    EDR, backup agents, VMware Tools and drivers, .NET / Visual C++ / Java and
    other runtimes, server roles (Exchange, IIS, AD...), monitoring and
    management agents, the PATCH-01 agent. Fixed in the code; the agent checks
    it again on the server;
  - entries match whole words ("7-Zip" covers "7-Zip 23.01 (x64)"); a vendor
    or generic word alone ("Microsoft", "Windows", "Adobe") is refused as too
    broad; adding an entry shows which installed programs it makes removable;
  - only silently (MSI by product code, the program's own quiet command, Inno
    Setup, or an uninstaller verified as NSIS), only by the program's exact
    Programs and Features key, and only if the same name and version are still
    installed; never a program installed in, or removed from, a critical
    product's folder;
  - taking an entry off the list withdraws removals of it that no server has
    started yet. If the organisation sets REQUIRE_APPROVAL=true, removals
    need a second admin like every other job.
- **Windows agent 1.9.3-win**: reports each program's key and silent removal
  method, and removes listed tools as above. Servers on an older agent are
  listed but cannot be ticked until updated (Servers › Agent updates).
- Schema **047**. Deploy: phase3a-schema.sh, phase3b-api.sh (publishes Windows
  agent 1.9.3-win for Update agents), phase5-dashboard.sh. New installer zip
  `patch01-windows-installer-1.9.3.zip` for new installs and reinstalls.

**r87: fix for the Nessus pages (HTTP 500)**
- Vulnerabilities › Nessus and Admin › Nessus scanners failed with "The server
  hit an error (HTTP 500)": the API called a role check that does not exist.
  Fixed; the page endpoint itself is now under test, and every name the Nessus
  code uses is checked to exist. Deploy: phase3b-api.sh. No schema, dashboard or
  agent changes.

**r86: Nessus set up in Admin**
- Connecting a Nessus scanner (address, API keys, certificate, Test, Edit,
  Remove, Sync now) moves to **Admin › Nessus scanners**, next to Antivirus
  consoles. **Vulnerabilities › Nessus** keeps the scans, reports and findings,
  with a "Settings (Admin)" link for admins. Dashboard only: deploy with
  phase5-dashboard.sh. No schema, API or agent changes.

**r85: Nessus, under Vulnerabilities**
- **Vulnerabilities > Nessus** (new tab). Connect one or more Nessus scanners
  (admins; from r86 in Admin › Nessus scanners): address, API access key and secret key (Nessus: My Account > API
  Keys). The keys are encrypted with av.key and never shown again; saved keys
  are only ever sent to their own scanner. Nessus's self-signed certificate is
  trusted by its exact SHA-256 fingerprint (Get certificate, compare, trust);
  verification is never turned off. **Test connection** says what is wrong
  (port refused, no answer / firewall, certificate changed, keys refused) and
  which edition answered.
- **Scans, one button each**: Launch, Pause, Resume, Stop, Import now, Report
  (PDF, HTML, CSV or .nessus, built by Nessus and downloaded through PATCH-01,
  nothing kept), Edit, Open in Nessus; **New scan** (template, folder, targets
  typed or taken from patch groups, on demand / daily / weekly / monthly, start
  now). Scans are read every 15 minutes (Refresh: at once).
- **Nessus Professional**: Tenable lets outside tools only read scans and export
  reports on Professional ("API is not available" for the rest). There Launch,
  Pause, Stop, New scan and Edit show greyed out with the reason and an Open in
  Nessus link; Import, reports and findings work. On Nessus Manager every button
  works, with no change.
- **Findings**: the newest finished run of each scan is imported (low severity
  and up), matched to our servers by address or name, with tiles, graphs (by
  severity, hosts with most critical/high, findings on most hosts), filters and
  Excel / PDF / CSV. A CVE Nessus found on a machine in the last 30 days counts
  in **Detected CVEs** as proven on that machine.
- Schema **046**. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.
  Network: PATCH-01 to Nessus on TCP 8834 only. No agent changes.

**r84: Vulnerabilities, from proof only**
- **Detected CVEs now lists only what is proven on our machines.** A CVE counts
  as affecting a machine only when:
  - the installed version is older than the vendor's fixed build for that
    machine's own release (Linux packages; Windows Server's OS build against
    Microsoft's Security Update Guide; Red Hat's fixed build for each RHEL
    release, or Red Hat saying "affected, no fix yet");
  - Windows Update on the server reports the update that fixes it missing;
  - the installed version is inside NVD's affected range (Windows programs from
    the software inventory, ESXi and vCenter from vCenter).
  "Possibly affected", "Not in inventory", "Not inventoried" and "Reboot needed"
  are gone: a fix installed but waiting for a restart shows as affected, marked
  "restart only". A product that is merely installed, or an OS that merely
  matches, is not a finding. Each machine is listed once per CVE.
- **Appliances apart**: network devices, firewalls and appliances from the asset
  inventory have their own tab. "Affected" when the firmware version recorded
  for the device (OS column of the asset sheet) is in NVD's affected range; "To
  check" when the device matches the product but its version is not recorded.
- **Graphs**: affected CVEs over the last 30 days (with the exploited ones), by
  severity, machines by platform, and the products on most machines. Click a bar
  to filter the list.
- **Checked every 4 hours** (and whenever the inventory changes); Linux servers
  now send their inventory every 4 hours (Windows already did). **Scan now**
  (operators): every reporting server sends its inventory at once, vCenter is
  read again, and every CVE is checked again as the answers come in; the page
  shows how many servers have reported.
- **Assess CVEs** uses the same rules: Affected, Appliance: check, Not affected,
  Not in our environment, Cannot assess. Assessments made before r84 keep their
  old words until run again.
- **Export**: Excel with Summary, Affected CVEs, Affected machines (one row per
  CVE and machine, with the installed and fixed versions and the evidence) and
  Appliances; PDF grouped by CVE; the scheduled "Vulnerabilities" e-mail uses
  the same rules.
- Schema **045**. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.
  The first check under the new rules runs within minutes of the deploy. No
  agent changes.

**r83: Patching and vulnerabilities kept apart; Installed patches report**
- **Why**: a server could show a "missing patch" that pointed to a CVE although
  nothing was missing. A Linux server's "to install" was worked out from the CVE
  feeds, never asked of the server, and the server page opened on the CVE
  advisories. Now the patching pages show only what the servers themselves report.
- **Patching** (Servers, server page, Overview, Jobs, Patch reports, e-mails):
  - Windows: what Windows Update reports missing against WSUS (as before).
  - Linux: what the server's own package manager would install (dnf/yum
    check-update and its security notices, apt-get -s upgrade), sent by
    **Linux agent 1.8.2** (Servers > Update agents). Until a server runs 1.8.2
    it shows "patch state unknown" (a new filter and tile), never a CVE count,
    and is left out of the compliance rate.
  - A Linux "security updates" patch job installs the package manager's own
    security updates (servers on 1.8.2; older agents keep the previous selection).
  - The server page opens on **Patches**: missing updates, other updates, and what
    was installed in the last 90 days. The CVE advisories are a separate, folded
    "Vulnerabilities (CVE advisories)" section below.
  - Overview is split into **Patching** and **Vulnerabilities (CVE)**. The Servers
    export no longer carries CVE columns.
- **Installed patches** (Servers > Installed patches, also from a server page or
  from ticked servers): what each server installed and when, for a period (last
  N days or dates), group, OS or chosen servers. Windows: installed updates and
  Windows Update's history (Defender definition updates and failed attempts left
  out unless ticked). Linux: every package version with its install time (a
  server's first day of installs, its build, is not counted). Exports:
  - **Excel**: Summary per server; the period, grouped by server; everything
    installed, grouped by server; a flat sheet with filters.
  - **PDF**: the period, grouped by server, servers with nothing listed at the end.
  - Scheduled e-mail: Admin > Scheduled reports, "Installed patches".
- Schema **044**. Deploy: phase3a-schema.sh, phase3b-api.sh (publishes Linux
  agent 1.8.2 for Update agents), phase5-dashboard.sh; then send Linux agent
  1.8.2 to the Linux servers. Windows agent and installer unchanged (1.9.2).

**r82: Long installs fixed, real patch reports, admin-only restart jobs**
- **The long-install bug**: a large Windows update that ran for hours was
  stopped by the agent at 2 h 50 min and failed by PATCH-01 at 3 h, and the
  job said "nothing was installed" although Windows finished installing it.
  Now (Windows agent **1.9.2-win**):
  - the agent stops waiting only after 45 minutes with no Windows Update
    activity at all, or after 7 h 45 min in total; if Windows is still
    installing then, the server is **not** restarted and the job says
    "still installing" with what was installed so far;
  - PATCH-01 keeps waiting while the agent keeps reporting (up to 8 hours),
    and a result that arrives after it stopped waiting is still added to
    the job;
  - a single update is tracked like a batch, so its result is always kept;
  - an install that ends **after the job's window** does not restart the
    server in working hours: the restart is held, the server is checked as
    it is, and the job says "restart held" (use Servers > Restart… later).
    Jobs with their own restart time keep using it.
- **Patch reports, rebuilt** (Patching > Patch reports): four views, **By
  job** (each CHG), **By patch group**, **By server** and **Updates and
  packages**, with a group filter and exports of every view (also as
  scheduled reports). Every update is checked against what the server
  itself reports as installed (Windows installed-updates list by KB, Linux
  package versions), so an update the job missed but the server has is
  shown as installed ("confirmed on the server"), and one the job claimed
  but the server does not have is flagged. Updates the server already had
  before the job show as "Already installed", and updates WSUS replaced or
  declined since the job was planned are no longer listed as missing.
- **Restart servers (admins only)**: Servers > **Restart…** lists the
  servers that report needing a restart (offline agents unticked), or tick
  servers on the page and use **Restart them…**. Choose now or a time,
  servers at a time, the service check and a reason. Nothing is installed:
  a pre-check, the restart, a wait until it is back, and a check that the
  same services run again (no WSUS check and no Windows Update restart: a
  server with WSUS down can still be restarted). Operators do not see it
  and the API refuses it.
- **Fixes from the code review**: a job interrupted while taking a VM
  snapshot is reported, not left hanging; cancelling withdraws installs the
  agent has not picked up yet and jobs waiting for a credential; a job with
  cancelled servers is "partly succeeded", not "succeeded"; servers waiting
  to restart get freed slots before new installs start; approving a job
  whose restart time has passed is refused; an unused enrolment token can
  no longer take over another active server (re-enrolment checks the
  hardware ID, either byte order; servers without one recorded enrol as
  before); AI repair steps that download and run code are discarded; chat
  only lists job kinds the user's modules allow; an expired certificate
  upload is refused; an https AI-01 without its pinned certificate is not
  contacted; report e-mail goes only to configured recipients or your mail
  domains, with an hourly limit; 2FA failures are counted, a locked account
  cannot turn 2FA off, and a password change ends other sessions; Linux enrolment tokens never appear on a
  command line (environment or a private file; `--token` still works but
  warns); Windows agent folders and
  the push folder are admin-only.
- **Linux agent 1.8.1**: sends the hardware ID at enrolment, waits up to 4
  minutes after boot for services before the post-check, and leaves the rest
  of a batch for the next run after a restart command.
- Schema **043** (adds the "restart" job kind). Deploy: phase3a-schema.sh,
  phase3b-api.sh (publishes agents 1.9.2-win and 1.8.1 for Update agents),
  phase5-dashboard.sh. Use the new installer zip
  `patch01-windows-installer-1.9.2.zip` on your share for every install and
  reinstall. Includes r81.

**r81: Reinstalling agents: no more false "pin" errors**
- **The bug**: reinstalling the agent on a server that had been removed or
  decommissioned on PATCH-01 (or rebuilt, or cloned from another server)
  failed with "The new pin did not work". The pin was fine. The server still
  had its old agent identity, which PATCH-01 no longer accepts, so the
  installer tried to upgrade instead of enrolling again, and reported the
  failure as a pin problem.
- **Now (Windows agent 1.9.1, installer `patch01-windows-installer-1.9.1.zip`)**:
  - Before upgrading, the installer asks PATCH-01 whether it still accepts
    the server's saved identity (an empty check-in). If not, it says why,
    says the pin is fine, asks for an enrolment token and enrols again.
    PATCH-01 recognises the machine, so its history is kept.
  - The address is asked first, then the pin. The pin is checked at once
    against the certificate PATCH-01 presents at that address. A remembered
    pin that no longer fits (PATCH-01's certificate was replaced) is not
    offered, and you are told to get the current one with
    `phase10-windows.sh --pin`. If the agent's own pin fits, it is offered
    instead. A pasted pin that does not fit is refused before anything
    changes; after three it stops. The presented certificate is only
    compared, never trusted on its own.
  - When a re-pin check fails for another reason, the message says what
    really failed (identity refused, decommissioned, unreadable, network),
    not "pin".
  - Tokens typed by hand are hidden while typed.
- **Linux** (`setup-agent.sh`): reinstalling a server PATCH-01 no longer
  accepts now enrols it again with a token, instead of failing at the
  check-in. Tokens are hidden while typed. The Linux agent is unchanged.
- Servers already on 1.9.0 get agent 1.9.1 from Servers > Update agents
  (only the new identity check differs). No schema change. Deploy:
  phase3b-api.sh (publishes agent 1.9.1-win for Update agents). Use the new
  installer zip on your share.

**r80: A new look: menu on the left, a richer Overview, three themes, a new sign-in page**
- **Layout**: the sections are now a menu on the left, with the open section's
  pages listed under it. The bar on top shows where you are, the PATCH-01
  gauges, the theme, the live log and Refresh. Your name, role and Sign out sit
  at the foot of the menu (click your name for password and two-factor). On
  phones and narrow windows the menu slides in from the left.
- **Themes**: three only.
  - Default (light) and Dark for everyone.
  - B-Mode for admins: a neon control-room look (cyan, green, magenta and
    orange chrome, corner marks, angled buttons).
  - System is gone: a saved System choice becomes Default. A non-admin with
    B-Mode saved gets Dark.
- **Overview**: new top section, all computed from the database:
  - Four headline figures: servers online, servers to patch, critical and 0-day
    CVEs, patch success over 30 days. Each shows its change since last week.
    That change appears once a week of daily figures has been stored; until
    then it says so rather than guessing.
  - Updates installed per day, this month against last month, with a hover
    and keyboard tooltip.
  - Windows and Linux servers patched per week (8 weeks).
  - Compliance goals against targets (95% patched, 98% agents online, 95% jobs
    succeeding).
  - Live activity (the latest job steps, and servers that stopped reporting in
    the last 24 hours).
  - Recent jobs.
  - The existing donuts and the AI-analysed impacted CVEs follow under
    "Security posture".
- **Chat button**: drag it anywhere on the screen; it stays where you leave
  it. Double-click puts it back in the corner. The chat opens beside it.
- **Sign-in page**: rebuilt as a full-width page. It has a headline, a drawn
  network picture, the three modules, and a sign-in card with show-password.
  The critical and 0-day CVE board sits along the bottom. The theme choice is
  top right.
- Under the hood: a new `GET /api/v1/overview`. The worker stores one row of
  headline figures a day (`overview_daily`). New console files: `shell.css`
  and `overview.js`.
- Schema 042. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.

**r79: An AI that does the job, a faster console, restart at a set time**
- **Chat**: AI-01 now answers.
  - It chooses among the ~10 most likely reports, not all 40: a prompt a
    quarter the size, so it answers in seconds on a CPU. The answer is held to
    real report names (a JSON schema).
  - A question naming a CVE, KB or change number is answered at once.
  - Under the table, AI-01 answers in its own words from the rows. That answer
    is shown only if its numbers, server names, CVE/KB ids, links and commands
    are in the rows.
  - A how-to question gets a general answer, labelled as not coming from your
    data.
  - Limits: 60 questions and 30 AI answers per person per 10 minutes.
- **People first**: while someone uses the chat or Explain, background AI-01
  work (the 15-minute notes, failure explanations, CVE briefs) waits, with at
  least one turn every 10 minutes. No database connection is held while AI-01
  thinks, so other pages are never kept waiting. Database pool: 16.
- **Failure explanations**:
  - An explanation is reused only for the same job type, OS, error, warnings
    and failed updates.
  - AI-01 gets only that job's own warnings and errors.
  - An answer naming a KB, error code, CVE or file that is not in the log is
    not shown. "Ask again" gives a fresh reading.
- **Overview note**:
  - It now includes a log-event analysis: the agents' warnings and errors of
    the last hour, grouped.
  - Its numbers and server names are checked.
  - When nothing changed, AI-01 is not asked the same thing again.
- **Faster**:
  - The live log's query uses its index again. It was scanning the whole
    agent log every 3 seconds on a server page.
  - Software inventory is cached for 5 minutes.
- **Restart at a set time** (New patch > When to restart): the servers install
  from the start time, then wait. At the restart time they restart, as many at
  once as "Servers at a time" allows (one at a time for a cluster). Waiting
  servers take no slot.
  - The restart time must be at least 10 minutes after the start and within
    14 days (within 24 hours with a VM snapshot).
  - Cancelling the job before the restart time leaves the servers un-restarted,
    with a warning.
- Schema 041. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.
  Agents unchanged.

**r78: PATCH-01's own CPU, memory and network gauges**
- Three small neon gauges at the top right show PATCH-01's CPU, memory and
  network, with a needle. From 50% they turn amber. From 70% they turn red
  and glow, and smoke rises. At 90% and above the dial trembles. Click the
  gauges for the last 10 minutes and the exact figures.
- Measured by `patch01-metrics.service` on PATCH-01. It reads four small
  kernel files every 5 s and runs as the unprivileged user patch01m: no
  network, no capabilities, read-only system, at most 48 MB and 5% of one CPU.
  In practice it uses under 0.05% of one CPU and about 11 MB. It writes one
  snapshot to /run (memory), which the API reads, read-only. The API gets no
  access to the host or to Docker.
- The console asks every 5 s, only while signed in and while its tab is
  visible: about 2 KB per request, and about 0.2% of the browser's time. These
  requests do not extend the session: an unattended console still times out.
- Network % is of the network card's speed. When a VM's card does not report
  one, 1 Gbit/s is assumed, and the details say so.
- Deploy: phase3b-api.sh (installs and starts patch01-metrics and mounts its
  folder into the API) and phase5-dashboard.sh. No schema change. Agents
  unchanged.

**r77: Honest "To install", Windows updates in full, moving servers from a list, 30 rows a page (Windows agent 1.9.0)**
- **"To install" fixed for good.**
  - Linux: a server keeps old kernels installed beside the new one. PATCH-01
    could store an old one, so a fully patched server showed "1 to install".
    The newest version of each package is now kept. Every server stores its
    inventory once more after the upgrade, and "To install" is recalculated
    within minutes.
  - Windows: an update that is already installed (its KB is in the server's
    installed list), or installed and only waiting for the restart, is not
    "to install". After a full WSUS search, Windows Update decides, so a
    re-released update is still listed.
- **Windows installed updates in full** (server page): title, type, date
  installed, who installed it and the result, newest first, with a filter.
  Needs agent 1.9.0; older agents show the KBs and their type.
- **Move servers from a list** (Servers > Move from a list…, operators):
  upload a text file of server names (one per line, or paste them). PATCH-01
  shows which it found (by name, full name or short name), which it did not,
  and which names match more than one server. You choose the group, and
  nothing moves before you confirm. A full name never matches a different
  machine that has the same short name.
- **30 rows a page** in every list (servers, the servers in a group, reports,
  installed updates, packages to install...).
- **No overlapping text**: chart legends, server details and the server
  picker wrap long names. The welcome greeting sits at the top of the page
  instead of covering it.
- Schema 040. Deploy: phase3a-schema.sh, phase3b-api.sh (publishes Windows
  agent 1.9.0 for Update agents), phase5-dashboard.sh, then Servers > Update
  agents > Windows 1.9.0. New servers: patch01-windows-installer-1.9.0.zip.

**r76: Console clean-up, patch groups, two-factor sign-in**
- **One menu, no repeats**: seven sections (Overview, Servers,
  Vulnerabilities, Patching, Software, Inventory, Admin) with tabs under the
  top bar. Old links still work. Long page intros fold behind a "?".
- **Themes**: Light and Dark now have colour (gradient top bar, card
  shadows, tinted tables). System follows the computer. BOT-MODE unchanged.
- **Sign-in page**: sign-in on the left; on the right, news limited to
  0-day (exploited) and critical CVEs. The chat window shows only after
  sign-in. After sign-in: "Welcome, <name>".
- **Two-factor sign-in** (an authenticator app, TOTP): each user turns it on
  under their account (Two-factor). Recovery codes are shown once. Admins can
  reset a user's two-factor (Admin > Users). The secret is stored encrypted
  with `totp.key`, which phase3b-api.sh creates in the secrets folder and
  mounts read-only into the API only.
  - A password alone never signs in an account that has two-factor on:
    HTTP Basic is refused for it.
  - Optional, in api.env: `REQUIRE_2FA=true` makes every console account set
    it up. Script accounts (the phase scripts sign in with HTTP Basic) are
    listed in `TWO_FACTOR_EXEMPT=<account>,<account>`. Use a separate admin
    account for scripts, not a person's account.
  - Turning two-factor on or off ends that account's other sessions.
- **Patch groups**: SIT, UAT, PROD-1, PROD-2 and Cluster Servers (one
  server at a time), for Windows and Linux. Servers > By group shows each
  group folded, with counts; tick servers to "Move to group" or "Patch
  them". Admins add, change or remove groups (Servers > Groups). A group with
  servers, live enrolment tokens or maintenance windows is not removed.
  New patch: pick whole groups.
- **"To install" now means patches waiting to be installed** (Linux packages
  with a newer fixed version, plus missing Windows updates), not CVEs. A
  server's CVEs are on the Vulnerabilities page. Fixed: a server whose
  patches were all installed still showed "To install" until the nightly
  run. The worker now recomputes a server within about a minute of its new
  inventory.
- **Patch Reports grouped per server**: each server is one row; its jobs fold
  out under it (newest open, 20 at a time).
- Schema 039. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.
  Agents unchanged (1.8.0).

**r75: Update agents from PATCH-01 (agents 1.8.0)**
- **Servers > Update agents** (admins): pick the version per platform and
  the servers; PATCH-01 sends each server's agent the file over its pinned
  connection. Servers must already run agent 1.8.0: install 1.8.0 once by
  hand (Install-PatchAgent.bat / setup-agent.sh); every later version is
  sent from here.
- What each agent does: checks the SHA-256 frozen in the job, parses or
  compiles the file, checks the version written in it, on Windows checks
  its Authenticode signature whenever the running agent is signed or the
  server runs AllSigned (never signed -> unsigned), test-runs it
  (-Check / check), keeps the running version (patch-agent.prev.ps1 /
  patch-agent.prev) and swaps. PATCH-01 then sends a check job that only the
  new version can answer. If the new version has not answered within 10
  minutes (Linux: the agent's interval plus 5), the previous version puts
  itself back (a scheduled task / a systemd timer that also survives a
  restart), stopping a new version that hangs. Never a downgrade; a Linux
  agent with verify_tls=false is never updated.
- Never in the middle of another job: a server busy in a patch or software
  job is updated after it, and no patch or software job starts on a server
  while its agent is being replaced.
- What can be sent is published by root on PATCH-01 only
  (`scripts/phase12-agents.sh`; a signed Windows agent:
  `--windows <signed patch-agent.ps1>`); the folder is read-only to the API.
- Optional: AGENT_UPDATE_REQUIRE_APPROVAL=true in api.env needs a second
  admin to approve each agent update.
- Schema 038. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.
- client/ now holds the current agents (it held Windows 1.5.2).

**r74: Deployment removes software, upgrades only older versions, handles portable programs; AI-01 explains failures (agent 1.7.0)**
- **Remove** (Deployment, New deployment, Action "Remove", or "Remove from
  servers" on a package): MSI by its product or upgrade code (msiexec /x);
  EXE with the program's own quiet uninstall command, or its uninstaller with
  the package's silent uninstall options, or the documented options of Inno
  Setup and NSIS uninstallers; otherwise it is refused, never run blind. An
  uninstaller in a folder ordinary users can change is not run as SYSTEM.
  Nothing is downloaded to remove a program.
- **Version-aware**: the agent checks what is installed before downloading
  anything. Install skips servers already on that version or newer (never
  downgrades); Upgrade only touches servers with an older version and skips
  servers without it. MSI products are found by their upgrade code (every
  version); a name that matches several different programs is refused
  instead of guessed. The New deployment form shows each server's installed
  version (from its software inventory) and picks the right servers for the
  action.
- **Portable programs**: PATCH-01 (and AI-01) tell an installer from a
  portable program; a portable program is copied to
  C:\Program Files\PATCH01-Apps\<folder> and never run; upgrade replaces it,
  remove deletes its folder (only its own). Every installer has a time limit
  (default 30 minutes): one that hangs (waiting for a click) is stopped with
  everything it started, and the reason is reported.
- **Why it failed**: for every failed (or warned) server of a patch job or a
  deployment, the known Windows Update, servicing, network and installer
  codes (0x800f0985, 0x80070643, 1603...) are named with what usually fixes
  them, and AI-01 reads the error and the agent's log and says the likely
  cause and the steps, in order. Shown on the change page, Patch Reports and
  Deployments; "Ask AI-01 again" on request; identical errors are explained
  once.
- Schema 037. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.
  Windows servers: the 1.7.0 installer (removal and portable programs need it).

**r73: Deployment page; Windows agent 1.6.0 (faster, timed); one-click installer**
- **Deployment** (new menu item, Software Lifecycle access): upload an MSI or
  EXE in the console (sent in 16 MB pieces, up to 4000 MB, kept on PATCH-01
  under its SHA-256 in /patch/data/packages).
  - PATCH-01 reads the file itself: version, vendor, MSI product code, the
    installer type (Inno Setup, NSIS, InstallShield, WiX bundle) with its
    documented silent options, and whether an EXE is signed. Nothing runs.
  - AI-01 describes the software and suggests silent options and the
    Programs and Features name: suggestions only, shown as text.
  - ClamAV (optional, `scripts/phase11-clamav.sh`): every upload is scanned;
    malware can never be deployed; a scan that could not run blocks the
    package until "Scan again".
  - An operator checks and saves the details, then deploys to chosen Windows
    servers (install, or upgrade where an older version is installed), now
    or in a window. The deployment keeps the package as it was reviewed.
    No second approval (the operator who deploys reviewed it);
    `DEPLOY_REQUIRE_APPROVAL=true` in api.env asks for one.
  - On each server the agent downloads the file from PATCH-01 in pieces over
    its pinned connection (only while it holds that job's step), checks the
    SHA-256, saves it in C:\tmp\PATCH01 (D:\tmp\PATCH01 when C: is short of
    space; \tmp is created when missing; PATCH01 is locked to SYSTEM and
    Administrators), keeps it unchangeable until the installer ends, checks
    the signature when asked, and installs silently (MSI: msiexec /qn with a
    full log). "Another installation in progress" (1618) is waited out and
    retried. The file is removed after a success, kept after a failure.
  - Deployments tab: each server's step, result, exit code and its meaning,
    where the file went, download time, warnings, the MSI log lines where it
    failed, and the agent's own log for that job.
- **Windows agent 1.6.0-win**:
  - The next step of a job is picked up within seconds (the agent keeps
    asking for 2 minutes after a step instead of waiting for its next run);
    the task also runs 1 minute after start-up, so the postcheck after a
    restart starts at once.
  - The 4-hourly inventory reads Windows' own update list (seconds) when
    Windows checked WSUS within 24 hours, instead of searching WSUS (minutes).
  - The server's DNS name is looked up every 6 hours, not every run.
  - Every run reports how long it took and where; Servers, server details,
    "Last agent run", shows it ("inventory WSUS search 340 s").
  - Fixed: installing catalog software that was not yet installed failed
    with "The property 'Version' cannot be found".
- **Install-PatchAgent.bat**: keep it, the agent zip and your .pem in one
  folder (a share is fine); right-click, Run as administrator. It unzips to
  %ProgramFiles%\PatchAgent-Setup, unblocks the files and asks for the
  certificate pin, PATCH-01's address and (new servers) a token, then shows
  SUCCESS or FAILED with the reason. Pin and address are remembered in the
  folder for the next server (Enter to reuse). The server's execution policy
  is not changed.
- Schema 036. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh;
  optional phase11-clamav.sh. Windows servers: the 1.6.0 installer.

**r72: Patch Reports page; Servers tab follows patch jobs; vCenter read every 5 minutes**
- **Patch Reports** (new menu item): every finished patch job, filtered by
  period, Windows or Linux, result, server or change. Two views:
  - **Servers**: one row per server per job: result, updates installed and
    not installed, restart, snapshot (kept, removed), minutes; open a row
    (+) for its updates or packages, warnings and errors.
  - **Updates and packages**: one row per Windows update (KB, title) or
    Linux package (version, the advisories it fixes, with severity), with
    its status: installed, failed, or not found after the restart.
  - Export: PDF (landscape, logo) or CSV of every matching row, or only the
    ticked rows. E-mail: the server-built report, the table, or the ticked
    rows; the two server-built reports ("Patch report, servers" and
    "Patch report, installed updates and packages") can be scheduled
    (Admin > Report schedules), for example weekly.
- **Servers tab** now matches the patch jobs:
  - Windows updates installed by a job leave "To install" at once (not at
    the next inventory), and "Reboot" follows the job (set after the
    install, cleared after a clean restart).
  - New column **Last patched**: when, and the result; it opens that job
    in Patch Reports. The server's details show it too.
  - vCenter, cluster and power come from the same VM the snapshot uses
    (powered on, with the agent's address).
- **New VMs**: the worker now reads each vCenter every 5 minutes
  (`VMWARE_SYNC_MINUTES`, minimum 2), and at once when an agent enrols or
  a snapshot job is booked for a server not linked to its VM yet. The
  hourly timer stays as a backup; reads never overlap. Read history is
  kept 30 days.
- Schema 035 (one column, one index). Deploy: phase3a-schema.sh,
  phase3b-api.sh, phase5-dashboard.sh. No agent change.

**r71: no more "agent offline" during a patch job; Windows agent 1.5.2**
- A server in the middle of a long patch step is no longer shown as
  "agent offline": log lines and step results the agent sends count as
  contact (the agent does not check in while it works on a step).
- Windows agent 1.5.2-win: updates WSUS has already pushed to a server are
  installed first, without a WSUS search; "still working" is reported
  every 2 minutes during a long Windows Update search.
- Only the API changed since r70: phase3b-api.sh is enough.

**r70: Windows patch jobs fixed end to end; snapshots verified (with agent 1.5.0-win)**
- Snapshot before patching: taken on the VM that is the running server
  (powered on, with the agent's address), never on a replica or clone that
  shares its hardware UUID and name; then read back from the VM's own
  snapshot list. If it is not there, the job stops before installing. The
  event names the VM and the snapshot. When nothing needed installing, the
  removal says so.
- Windows jobs: the agent searches WSUS itself at install time (an old or
  failed inventory no longer skips a server); partial installs carry on to
  the restart; "done, with warnings" names failed or rolled-back KBs and
  services that did not come back; the inventory after patching never
  fails a patched server; longer limits for Windows restarts (75 min),
  precheck (130 min), postcheck and inventory (45 min).
- Faster Windows jobs: the job ends after the postcheck instead of waiting
  for the inventory report (a full WSUS search); with agent 1.5.0 the
  install reuses the precheck's search, installs the updates in one
  Windows Update session and checks them after the restart in seconds.
- Hardening from a pre-release audit: the snapshot is taken with nothing
  held open in the database and recorded at once (a restart never takes a
  second one); a snapshot vCenter created but the VM does not list is
  recorded and reported; a failed snapshot removal is a warning; "remove on
  success" keeps the snapshot only for warnings about the patch itself and
  says so; a database error on one server never stalls the other servers.
- Windows agent 1.5.1-win.
- Includes r68 and r69.

**r69: product servers under Apex Central; Deep Security Managers read directly**
- Admin > Antivirus discovers the Apex One servers, Deep Security Managers
  and email security each Apex Central manages; tick which to sync.
- A Deep Security Manager can be read directly with its own read-only API
  key; its certificate is detected as public CA, your CA, self-signed or
  expired, and trusted by CA or by fingerprint.
- Antivirus page: Product servers tab. Inventory: product servers as assets.
  Assistant: product server questions. Schema 034.
- Fix: tables with their own tick boxes no longer get a second set.

**r68: sorting, selection, export and e-mail on every page; security-tone mails; fixes**
- Every table sorts by its headings and has tick boxes. **Export** gains
  "selected rows". **E-mail** can send the table or the selected rows on
  every page (configured recipients only, rate-limited, audited).
- All mail templates rewritten in a security tone, with the team greeting,
  the required action, the sign-off and a classification line.
- Assistant: asset counts by type, hardware (make, model, serial), VM
  templates, decommissioned assets, powered-off VMs with created dates,
  firewalls and network devices.
- Fixed:
  - Assets: filtering no longer drops ticked rows.
  - Assets: ticking no longer rebuilds the table (no lost clicks or focus).
  - Assets: no double submits while an action runs.
  - Assets: the 2,000 cap applies to every way of ticking.
  - Inventory-only users can e-mail their reports (Coverage, Antivirus).
  - Rate limits on AI-01 checks and report mails hold when requests are sent
    together.
  - A sheet over 5,000 rows is refused instead of cut.
  - Mail is sent one by one, so a crash never re-sends delivered mail.
  - Scheduled reports run in their own loop, so security alerts are never
    held up behind an AI-01 summary.
  - The e-mailed coverage report matches the page's filter.
  - Fast navigation can no longer show an older page under a newer address.
  - The Export control no longer piles up click listeners on the Servers
    page.
  - The Antivirus tiles' counts match their lists.
  - The Assets status tiles no longer count powered-off VMs.
- Deploy: `phase3b-api.sh`, `phase5-dashboard.sh` (no schema change).

**r67: Powered off and Templates tabs, VM created date, Hardware only with hardware details**
- New **Powered off** tab. Powered-off and suspended VMs are kept out of
  Master, the type tabs and coverage.
- New **Templates** tab: vCenter VM templates, read into their own table
  (never into the VM list or VMware actions).
- VM created date from vCenter (config.createDate), with a fallback for
  older vCenters.
- Hardware tab lists only machines with hardware details, one row per serial
  number, showing only hardware columns.
- When a powered-on and a powered-off VM share a name, the running one
  describes the machine.
- Deploy: `phase3a-schema.sh` (schema 033), `phase3b-api.sh` (the worker
  reads templates and dates on its next vCenter sync), `phase5-dashboard.sh`.

**r66: master asset list by type, Hardware view, small donuts, export selected, AI-01 sorting**
- Master assets with type tabs: Servers, Laptop/Desktop, ESXi, Appliances,
  Network, Firewalls, Hardware. All are views of one list, so they always
  agree.
- Device types are decided by: a person, vCenter, the OS, the sheet, the
  name, then AI-01 (per machine, checked to be one of the types, with its
  reason).
- Machines with an agent, WSUS, Apex or Windows stay Server or
  Laptop/Desktop unless a person sets otherwise with a reason, and stay
  checked for WSUS and Apex.
- **Set type…** for ticked machines (Approve permission). It is kept in the
  history and Activity.
- Hardware view: make, model, serial, CPU, memory. The sheet upload now reads
  Make and Model columns.
- Small donuts: by type, approved, Windows in WSUS, Windows in Apex.
- Export selected rows as PDF or CSV.
- Appliances, network devices, firewalls and ESXi hosts are excluded from
  WSUS and Apex coverage.
- Deploy: `phase3a-schema.sh` (schema 032), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r65: Apex in the inventory; WSUS and Apex coverage gaps with AI-01; auto-approval**
- Apex Central's agents are an inventory source (Detected: Apex).
- Laptops and desktops take Apex's Windows 10/11 over WSUS's; servers keep
  vCenter/WSUS.
- New **Coverage** page:
  - every machine missing in WSUS or Apex, with the reason from the other
    sources, what to do, and a priority;
  - AI-01's analysis, its numbers checked against the figures;
  - export, e-mail and a schedulable report.
- Machines found in both WSUS and the uploaded sheet are approved
  automatically (recorded as "auto"). Never one a person revoked or
  decommissioned.
- The AI number check is stricter for the threat summary too: names are
  never counted as figures, and numbers in words are refused.
- If the API starts before schema 031, the antivirus sync still works.
- Assistant: inventory coverage questions.
- Deploy: `phase3a-schema.sh` (schema 031), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r64: asset inventory: approve, decommission, revoke; sheet upload read by AI-01**
- Assets page:
  - columns Hostname, Device, Operating system, IP (no brackets), Detected
    (Agent / Virtual / vCenter / WSUS / Manual), Location (the vCenter for a
    VM; Laptop/Desktop or Physical server otherwise), Status, Last detected;
  - 20 a page;
  - icon tiles;
  - tick boxes with "select all matching".
- Approve / Decom / Revoke, each granted per user in Admin > Access (admins
  always). Decom needs a reason. Every decision is in the asset's history and
  in Activity.
- New **Decommissioned** page: who, when, why, who approved; flags machines
  still detected afterwards.
- Admin **Upload sheet** (.xlsx or CSV):
  - AI-01 maps the columns, checked against the cells;
  - rows are checked and tidied;
  - a preview comes before anything is saved;
  - optional replace of earlier sheets, showing what it removes.
- **Check with AI-01** (and every 6 hours): device types for unknown OS
  names, and findings where the sources disagree.
- Odd names from sources ("DOMAIN\\pc", names with spaces, placeholder
  guest names such as localhost) no longer merge machines or break actions.
- Decommissioned machines leave the "No antivirus" list unless something
  still shows them running.
- The assistant leaves decommissioned machines out of asset answers.
- New Python packages: `openpyxl` and `defusedxml`, installed by
  `phase3b-api.sh` through the usual pip proxy.
- Deploy: `phase3a-schema.sh` (schema 030), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r63: antivirus detections, outdated definitions from Apex, daily AI threat summary**
- Each hourly read now also fetches Apex Central's Pattern Update Status
  and detection logs (virus/malware, ransomware, spyware, behaviour
  monitoring, machine learning, C&C, web). Log types are discovered per
  console.
- Antivirus page:
  - new tiles: Outdated definitions, Detections 24 h, Ransomware 24 h;
  - a Definitions column on each agent;
  - a Detections view with the AI-01 summary, filters and export.
- New daily mail "Antivirus threats, daily summary" (08:05). AI-01 writes
  the summary from the figures, and every number is checked against them.
  If the check fails, the plain figures are sent instead.
- AI-01 assistant: outdated definitions, offline agents, machines with no
  antivirus, detections (by type, period, machine, not cleaned) and the
  threat summary.
- Admin > Antivirus: a Logs column shows which logs each console offers.
- A definition update cannot be pushed from PATCH-01: Trend Micro's Apex
  Central API has no such action (see Antivirus logs).
- Deploy: `phase3a-schema.sh` (schema 029), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r62: fix "Could not save" when trusting an antivirus console's certificate**
- Saving a console with a trusted certificate (new or edited) failed with
  a database error: one value in the query had no type the database could
  infer. Fixed.
- Every query from r57 to r61 was re-checked the way the database driver
  sends them (typed, prepared statements). No other query had the problem.
- When the server hits an error, the console now says so with the HTTP code
  and where to read the reason, instead of a bare "Could not save".
- Deploy: `phase3b-api.sh`, `phase5-dashboard.sh` (no schema change).

**r61: trust an antivirus console's self-signed certificate by its fingerprint**
- Admin > Antivirus > Certificate and network > **Get certificate** shows
  the certificate Apex Central presents, with its SHA-256 and SHA-1
  (Windows Thumbprint) fingerprints, the names it covers and its dates.
  Tick to trust that exact certificate.
- Connections then check the fingerprint before sending anything, and stop
  if the certificate changes. Saving re-checks the fingerprint against the
  live console.
- A pasted self-signed certificate is now also accepted as its own CA, when
  its names match the URL.
- Deploy: `phase3a-schema.sh` (schema 028), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r60: reports by e-mail, at once or on a schedule; daily antivirus health mail**
- Export > E-mail… on Antivirus, Servers, Vulnerabilities (Detected CVEs,
  Advisories) and Activity: the report is built on the server and mailed with
  the PDF or CSV attached, to configured recipients only.
- Admin > Scheduled reports: daily, weekly or monthly schedules, send now,
  edit, remove.
- Built-in "Antivirus health, daily" at 08:00: outdated definitions, offline
  agents, agents no longer listed, machines with no antivirus.
- Antivirus: definition versions, last-connected times and online flags are
  read when the console sends them; Admin > Antivirus shows which fields
  each console sends.
- Deploy: `phase3a-schema.sh` (schema 027), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r59: antivirus consoles (Trend Micro Apex Central) and an Antivirus page**
- Admin > Antivirus: add each Apex Central console (URL, Application ID, API
  key, optional CA certificate), test the connection, sync now, edit, remove.
  Keys are encrypted with the new `av.key`; only GET requests are ever made.
- New Antivirus page: agents matched to the inventory, machines with no
  antivirus, isolated agents, filters, + rows, exports.
- Servers: each server's + row shows its antivirus console. Only agents
  from enabled consoles, listed in the last two days, count as protection.
- Security, whole console: a rejected form field is reported by name and
  reason only. The submitted value (a password, a key) is never echoed back.
- Deploy: `phase3a-schema.sh` (schema 026), `phase3b-api.sh` (makes av.key
  and mounts it), `phase5-dashboard.sh`.

**r58: CVE matching checks each machine's platform; address and OS on every match**
- A match counts only when the machine runs a platform the vulnerable product
  runs on, from NVD's platform data, Microsoft's product list and Red Hat's
  per-release state. Microsoft CVEs no longer land on Red Hat servers through
  a shared package name.
- Every machine is looked up in one asset record (agent, WSUS, vCenter guest,
  ESXi, vCenter): address, OS and sources are shown on each match, and the
  machines ruled out are listed with the reason.
- Red Hat: installed builds are compared with Red Hat's fixed build for the
  machine's RHEL release; "not affected" is respected; package names from
  Red Hat's list are now read correctly for builds without an epoch.
- Microsoft: products listed as "not affected" are no longer taken as affected.
- Detected CVEs: new "Applies to" column; exports carry address, OS and the
  machines ruled out. Assessments use the same rules and show the same detail.
- One answer everywhere: Detected CVEs, the Patch Dashboard donut, the AI-01
  analysis, the Servers page (new "Detected CVEs" per server, linking to its
  list) and the assistant ("which servers are affected by CVE-...") all read
  the same platform-checked results.
- Re-checked when installed versions change, not only counts: a package or
  program updated in place, a Windows upgrade or a new VM guest OS starts a
  new analysis within minutes, so a patched server drops off the CVE.
- Every CVE is analysed again with these rules after the upgrade.
- Deploy: `phase3a-schema.sh` (schema 025), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r57: Vulnerabilities in one place, one Export button (PDF or CSV), small module icons**
- **Vulnerabilities** merges Impacted CVEs, Advisories and Assess into three
  tabs (Detected CVEs, Advisories, Assess CVEs), each with + rows, search,
  filters and 20 rows a page. Advisories open to their servers and CVEs, with
  **Patch these servers**.
- An assessed CVE is now checked like a detected one: CVE database, software,
  every machine's operating system (agents, WSUS, vCenter guests, so Windows
  10 Pro or Server 2019 is found without an agent), hardware, then the
  servers' verdicts, then AI-01's brief.
- One **Export** button on every page: PDF report (logo, heading, page
  numbers) or CSV (heading lines). Replaces the separate CSV and "with logo"
  buttons.
- The module buttons on the welcome and home pages are small icons.
- Deploy: `phase3b-api.sh`, `phase5-dashboard.sh` (no schema change).

**r56: one Servers page (servers and agents), branded exports, AI analysis every 15 minutes**
- Servers and Agents merged into **Servers**: green/red lights, + to expand,
  filters, 20 a page, export to CSV and to Excel with the logo.
- Every CSV export starts with the portal, organisation, date and time, user,
  filter and row count.
- AI-01 analyses the servers every 15 minutes (schema 024, worker thread
  "insights"); the latest note heads the Servers page.
- Includes r55 (scripts ask for the admin password when the first-start one
  was changed).
- Deploy: `phase3a-schema.sh` (schema 024), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r55: scripts sign in after the admin password is changed**
- `phase3b-api.sh --check` no longer reports "admin auth HTTP 401" once the
  admin password has been changed in the console (expected and correct).
- `phase3b-api.sh --token`, `phase10-windows.sh --tokens` and `phase6-llm.sh`
  try the first-start password, and when it no longer works ask for an admin's
  user name and password at the terminal (not shown, not stored, and passed to
  curl through a pipe so it never appears in the process list).
- No API, dashboard or schema change.

**r54: modules and access, Impacted CVEs with AI briefs, new welcome page**
- **Welcome page**: logo, "Cyber-Secure Dashboard portal", **AI powered
  dashboard**, three glowing module buttons (Patch Dashboard, Asset &
  Inventory, Software Lifecycle), and a scrolling board of **critical, high and
  0-day** CVEs only (pauses on hover or focus; still for reduced motion).
- **Home after sign-in**: the same page, with the user's modules lit and the
  others greyed out.
- **Admin > Access**: grant each user modules; enforced by the API (schema 023).
- **Patch Dashboard**: CVE news removed; donuts kept; new **Impacted CVEs**
  donut with the CVEs needing attention and AI-01's briefs; new Impacted CVEs
  page with where each was found.
- Worker thread "impact"; AI-01 prompts now fence product and inventory text
  as untrusted data.
- The menu has its own row under the brand, so every entry is visible.
- Deploy: `phase3a-schema.sh` (schema 023), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r53: Cyber-Secure dashboard, CVE feeds from NIST, Microsoft and Red Hat, new sign-in page**
- The console is now **Cyber-Secure**, with your logo in the top bar (the same
  logo as the mails). The hacker theme's prompt no longer shows a user and host
  name.
- The Overview is the **Cyber-Secure dashboard**: six live donuts (servers,
  updates, severity, operating systems, agents, new CVEs), headline figures,
  and **CVE news**. Refreshes every minute.
- **CVE feeds** (schema 022, worker thread "feeds"): NIST NVD, Microsoft and Red
  Hat, filtered to the software you choose in **Admin > CVE feeds**, with
  suggestions from your servers' own software.
- **Sign-in page**: logo, "Welcome to the Cyber-Secure Dashboard portal", and a
  news board of the latest CVEs from the three sources (general feeds only).
- Feed responses are size-limited; public answers are cached and built once at
  a time.
- Deploy: `phase3a-schema.sh` (schema 022), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r52: assistant pops out on top of everything; finds any OS version or edition**
- **⧉ Pop out**: the assistant floats in its own always-on-top window over all
  other applications (Chrome/Edge 116+); **Back to page** returns it.
- Questions about an operating system now search every machine from agents,
  vCenter and WSUS by OS name: "Windows 10 Pro list", "win10", "Windows 11",
  "Windows Server 2019", "RHEL 9", with a count per edition. Machines whose
  edition no source reports (vCenter says only "Windows 10") are counted
  separately, not silently dropped.
- An assistant e-mail with no rows says it went without a CSV; the draft no
  longer ends with "Regards" (your signature closes it).
- Rebuild the API and dashboard: `phase3b-api.sh`, then `phase5-dashboard.sh`.

**r51: the assistant: floating, speaks, exports, e-mails, answers far more**
- The chat is now a **floating window**: drag, resize, enlarge, back to the
  corner; remembered per browser.
- It answers far more (29 prepared, read-only queries, up from 9): fleet
  overview; server list; one server's detail, **patches pending**, **patches
  installed** and installed software; where a program is installed; agents
  by state and version; servers waiting for a reboot; servers needing patches
  (Windows included); CVEs (one, exploited, most serious); recent advisories;
  Windows servers missing updates; servers missing a KB; WSUS computers
  needing attention; recent changes and one change in detail (warnings
  included); hardening scores; VMs by name or power state; old snapshots; VMs
  without an agent; ESXi hosts; datastores low on space; the asset inventory.
- Follow-ups refer back: "export that", "email it to the ops team".
- **Export CSV** and **E-mail** (draft, sent only when you press Send, to
  allowed recipients only, rate-limited, audited). See "The assistant".
- **Reads answers aloud** with offline voices only.
- Rebuild the API and dashboard: `phase3b-api.sh`, then `phase5-dashboard.sh`.
  No schema change.

**r50: service warnings, Inventory pages**
- **A service that does not come back after patching no longer fails the
  patch.** When the postcheck's only problem is services that were running
  before and are not now, the updates count as installed, the server ends as
  **Done, with warnings**, the services are named, and the snapshot is kept
  (even with "remove if it succeeds"). Any other postcheck problem still fails.
- A failure reported by the Linux agent kept its message: it was dropped, so
  failures read "the agent reported a failure".
- **Inventory** menu, two pages:
  - **Assets**: every machine from agents, vCenter (VMs, ESXi hosts, the
    vCenters) and WSUS, merged by name, each typed as server, client or
    appliance from its OS (hover the type for the reason), with where it runs,
    power, agent state, last seen; filters, search, and "without an agent".
  - **Software**: Windows programs and Linux packages by program and version,
    for servers or clients, with the machines that have each. Software comes
    only from agents (vCenter and WSUS do not report installed software).
  - Both export CSV; cells that a spreadsheet would run as formulas are
    neutralised. Windows > Software moved here.
- The top menu now tightens on narrower screens as intended (its narrow-screen
  rules were being overridden).

**r49: Windows agent 1.4.0-win: everything checked, and downloaded, before installing**
- PATCH-01 now chooses a Windows job's updates at the **precheck** and sends
  them with it. The precheck logs every check as it runs (disk; the Windows
  Update, BITS, Cryptographic and Modules Installer services; a pending
  reboot; WSUS reachable), looks the updates up by ID, tests **the exact
  address each update file downloads from**, and names it if it cannot be
  reached (with the usual cause: WSUS approving updates without storing their
  files). Then it **downloads the updates during the precheck**, with
  progress every 30 seconds, and stops with a clear reason if nothing arrives
  for 10 minutes. Nothing is installed in the precheck, so stopping is safe.
- The install step reports whether Windows is busy or idle, and stops a
  download that has not moved for 15 minutes.
- The Windows precheck may take up to 110 minutes (it includes the download).

**r48: Windows agent 1.3.2-win: visible, quicker installs**
- Updates install one at a time (servicing stack first), and every step is
  logged: looking up, downloading N of M, installing N of M, installed in
  X min, or FAILED with its result code. While Windows works, the agent copies
  this into its log and sends it to PATCH-01 every 30 seconds, with a "still
  working (N min so far)" line when Windows is quiet, so ">_ Log" shows where
  a long cumulative update is.
- The install looks up only the job's own updates by ID (seconds) instead of
  repeating a full Windows Update search (minutes); a full search is the
  fallback if the lookup by ID is refused.

**r47: Windows agent 1.3.1-win: commands were skipped**
- On PowerShell 5.1, Invoke-RestMethod returns a JSON list as one object.
  The agent wrapped it in another list, found no command id on it, and
  skipped every command without a word: PATCH-01 saw the step taken and
  never answered. The list is now unrolled whichever way it comes back; the
  agent logs how many commands it received; a command it cannot read is
  logged as an error and answered as failed instead of skipped.

**r46: fail-fast fix**
- The fail-fast check used the last check-in time, which an inventory report
  also moves: a Windows inventory step (its Windows Update search can take
  minutes) could have been failed while still running. It now uses the time
  the agent last started a run (`hosts.last_run_at`, set only by check-ins).
  Run phase3a (schema 21 gains the column) and phase3b.

**r45: visible, fast failures (agents 1.7.0 and 1.3.0-win)**
- **Live log** (`>_ Log` in the top bar): a small floating terminal with
  agent log lines and change steps as they happen; it follows the page (a
  change, a server, or everything), can be moved and resized, and stays open.
  Lines are shown as plain text only.
- **Agents send their log lines to PATCH-01** after every command and at the
  end of every run, including a run that crashed. PATCH-01 keeps the newest
  3000 lines per server for 14 days and masks anything that looks like a
  secret as it arrives.
- **Fail fast:** when an agent took a step and its run ended without
  answering, the step fails within minutes, quoting the agent's last log
  lines, instead of after the 30-minute limit. A timeout quotes them too.
- **Windows jobs no longer wait 5 minutes between steps:** the agent asks for
  the next step straight after finishing one, as the Linux agent does.
- Results are retried three times; a failed send is logged.
- The "worker is not running" banner was wrong for 58 minutes of every hour
  (the hardening thread reports hourly): each thread is now judged on its own
  pace, and the banner shows only when the change runner has stopped.
- Schema `021-agent-logs.sql`. Run phase3a, phase3b, phase5; update agents.

**r44: Windows software from a share (S2)**
- **Windows > Installers**: a catalog of approved installers (MSI, or EXE with
  reviewed silent options) on a share: path, SHA-256, the publisher whose
  Authenticode signature it must carry, the MSI product code or EXE uninstall
  options, and its name in Programs and Features. A different admin must
  approve each entry (enforced by the API and the database).
- **Software jobs** (Changes > New software job): install, upgrade or remove
  on Windows servers, through precheck, snapshot, install, reboot, postcheck
  and inventory. They always need a second person's approval.
- **The share credential is entered at run time** on the job's page: the job
  waits until then. It is kept encrypted in memory-backed storage on PATCH-01
  (`/run/patch01-vault`, emptied at boot), never in the database, logs or on
  disk; each server fetches it once; it is gone when the job ends (6 hours at
  most). Only the API holds its key.
- **Windows agent 1.2.0-win**: re-checks everything it is sent, copies the
  installer with the job's credential, verifies its SHA-256 and signature
  before anything runs, installs with fixed templates (never through a
  shell), confirms the result, and always deletes its copy.
- Windows patch jobs with "chosen advisories" now accept KB numbers.
- Schema `020-software.sql`. Run phase3a, phase3b (makes `run.key` and the
  memory-backed folder) and phase5; update Windows agents to 1.2.0-win.

**r43: no site host names**
- Examples and documents use the placeholder `patch01.example`; the setup
  scripts have no built-in address and ask for it (an upgrade offers the
  address the existing agent uses). Nothing site-specific is shipped.

**r42: one guided script per OS for installing or upgrading the agent**
- `client/setup-agent.sh` (Linux) and `client/windows/Setup-Agent.ps1`
  (Windows): find any existing agent, upgrade it in place keeping its
  identity, or install and enrol a new one; check DNS and the port; work out
  how to trust PATCH-01's certificate (the existing setting, the system's own
  trust, or your CA chain file, verified the way the agent verifies) before
  changing anything; then prove it with a check-in. Windows also sets the
  execution policy to RemoteSigned for the current user and unblocks the
  scripts. Both run unattended with --yes / -Yes.
- install-agent.sh no longer stops with "are the same file" when re-run with
  the CA it already has.

**r41: Linux precheck fix (agent 1.6.1)**
- Patch jobs on RHEL and Oracle Linux stopped at the precheck with
  "previous package transaction did not complete cleanly" on healthy
  servers: the check searched `dnf history` for "E", which is also the
  letter for Erase and appears after every kernel update. It now runs the
  package manager's own consistency check (`dnf check` / `yum check`) and
  stops only on real problems, naming the package; a failed last transaction
  is shown as a warning, since with dnf it does not block the next one.
  Update the agent with install-agent.sh (no token: the enrolment is kept).

**r40: vCenter write account fix**
- `phase7-vmware.sh --add-writer NAME` did nothing: an earlier edit had put
  the add-writer and remove-writer code inside the option-reading loop
  instead of the mode section, and swallowed `--install-timer`. All three
  work again. A failed or interrupted --add-writer now never leaves
  credentials on disk (the API is prepared first, and the file is removed
  on any exit before the login is proven). `--list` shows whether each
  vCenter has a write account.

**r39: rolling the agent out to many Linux servers**
- `client/push-linux.sh`: over SSH (keys, root or passwordless sudo), checks
  every server first (SSH, sudo, Python, and that the server can reach
  PATCH-01 and verify its certificate with your CA), then installs on those
  that passed: servers already enrolled switch to verified TLS and keep their
  identity; new ones get a token. Tokens go only to servers that passed and
  are not enrolled. `--test-only` checks without changing anything and says
  how many tokens are needed. Results in a CSV.

**r38: certificate install fix**
- Installing a certificate from the console rolled back with "cannot load
  certificate key ... Permission denied": the helper wrote the key as
  root-only (0600), but nginx runs as uid 1001 in group 0 and reads it
  through its group, as phase1a-ingress.sh sets it (root:0, 0640). The
  helper now overwrites the files in place, keeping their owner, group, mode
  and SELinux label. The rollback itself worked as designed.

**r37: PATCH-01's certificate from the console**
- **Admin › Certificate** shows the certificate nginx serves now (names,
  issuer, expiry, pin), takes an upload (certificate and key files, a DER
  .cer, or a .pfx with its password), and checks it before anything changes:
  the key matches, it is in date, it names the short name and FQDN, it is for
  TLS servers, the key is strong enough, and the chain is complete (put in
  order automatically). It gives the new pin and the exact Windows re-pin
  commands, and only installs once you confirm those were run.
- The console never installs anything itself. A root helper on PATCH-01
  (`patch01-cert-apply`, started by `patch01-cert.path`) checks the files
  again, installs them, restarts nginx, proves nginx serves exactly that
  certificate, and puts the previous one back if not. The private key is
  deleted from the hand-over folder once installed; it is never stored in
  the database. The five previous certificates are kept; **Roll back** goes
  to the one before the last change.
- `phase3b-api.sh` installs the helper. Log: `/var/log/patch01-cert.log`.
  `patch01-reip --cert` remains as the command-line way.

**r36: worker health check**
- The worker was always shown "unhealthy": it uses the API's image, whose
  built-in health check asks the API's web server, which the worker does not
  run. It now has its own check (`python -m app.health worker`): healthy when
  its main loop has reported within 3 minutes. Nothing was wrong with the
  worker itself; tools that rely on health (patch01ctl) now see it correctly.

**r35: certificate and IP change-over**
- Windows agents and the WSUS report accept **two pins** during a certificate
  change, so they keep working before and after the swap.
- `install-agent.ps1 -Repin -Pin <old>,<new>` and `push-agent.ps1 ... -Repin`
  change the pin without re-enrolling; they also bring the agent up to date
  (older agents accept only one pin), and test the new setting before keeping it. `wsus-report.ps1 -Repin` does the same for WSUS servers.
- `phase10-windows.sh --pin --cert FILE` gives a new certificate's pin before
  it is installed, with the exact re-pin commands.
- `docs/CHANGE-IP-AND-CERTIFICATE.md`: the steps, in order.

**r34: several WSUS servers**
- With more than one WSUS reporting, Windows › WSUS shows each with its own
  cards and adds a **WSUS** column to the computer list. A computer listed by
  two WSUS servers (usually reporting roll-up from a downstream WSUS) is
  marked rather than hidden. Each WSUS needs its own token:
  `phase10-windows.sh --wsus-token NAME`, once per server.

**r33: Windows patching (W3), WSUS view (W2), software inventory**
- **Patch jobs for Windows servers**, through the same change engine:
  precheck (disk, Windows Update service, running services), VM snapshot,
  install, reboot per the job's choice, postcheck (services back, no reboot
  pending), inventory. Only updates WSUS has approved can be installed: the
  agent installs from the server's own WSUS search. *All approved updates*
  installs everything WSUS approved that the server lacks; *chosen
  advisories* installs the approved updates with those KBs or that fix their
  CVEs (Windows updates are cumulative, so this month's update covers last
  month's). Installs may take up to 3 hours.
- **Software inventory:** every Windows server reports Programs and Features
  (name, version, publisher, install date, size). Each server's page lists
  it; **Windows › Software** shows every program across servers, the
  versions in use and which servers have each.
- **Windows › WSUS:** sync health, security updates not approved, and every
  computer WSUS knows with when it last reported and how many approved
  updates it still needs. Computers not reporting for 7 days, computers not
  in PATCH-01, and PATCH-01 servers unknown to WSUS are called out.
  `client/windows/wsus-report.ps1` runs on the WSUS server (read-only), every
  6 hours; `phase10-windows.sh --wsus-token NAME` makes its token (one per
  WSUS server; the same pin as the agents).
- Windows agent **1.1.0-win**; its scheduled task may now run 4 hours.
  Schema `019-windows-software-wsus.sql`.

**r32: Windows inventory accepted**
- Windows inventories were refused with "only 23 packages reported ...
  (minimum 50)": that safety check is for Linux, where fewer than 50
  packages means a broken collector. A Windows server reports its OS build
  and installed KBs, often fewer. For Windows servers (by their recorded OS)
  the check is now one well-formed OS build entry; Linux keeps its minimum.
  Because the inventory failed first, the Windows Update results were never
  sent either; both now arrive.

**r31: Windows agent fix**
- After enrolling, the Windows agent stopped with "The variable
  '$script:Cfg' cannot be retrieved because it has not been set": under
  strict mode it read its settings variable before anything had set it, so
  inventory and the scheduled runs failed. It is now declared up front.
  Update an installed agent with `install-agent.ps1 -Update`.

**r30: Windows enrolment fix**
- Windows enrolment failed with HTTP 422: the enrolment check still allowed
  only dnf, yum and apt. It now accepts wua (Windows Update).
- The Windows agent now shows PATCH-01's reason for any refusal (PowerShell
  5.1 keeps it in ErrorDetails, not in the response stream).
- Patch jobs refuse Windows servers with a clear reason until Windows
  patching (W3) exists, instead of failing on the server.

**r29: Windows token fix**
- `phase10-windows.sh --tokens` failed with "unknown host_group 'windows'":
  tokens must name an existing group, and `windows` was not one. It is now
  created the first time it is used (and by schema 018 on new installs); any
  other group that does not exist is refused with the list of those that do.

**r28: Windows servers (W1)**
- **Windows agent** (PowerShell 5.1, built in to Windows Server): enrols like
  the Linux agent, checks in every 5 minutes as SYSTEM, and every 4 hours
  reports the OS build, installed KBs, reboot state, the hardware ID that
  links it to its VM, and the updates Windows Update says are missing,
  searched against the server's WSUS. Read-only. The PATCH-01 certificate is
  pinned; the agent's token is encrypted for that machine only.
- **CVEs by build:** Microsoft's Security Update Guide is imported
  (`phase10-windows.sh --msrc`). Each cumulative update is an advisory for its
  Windows Server version, so Windows servers get verdicts, KEV and EPSS, and
  appear on the Overview, Advisories, Assess and in reports like Linux ones.
- **Windows Update** section on each Windows server's page.
- `client/windows/`: `install-agent.ps1` (with `-SelfTest`), `patch-agent.ps1`,
  and `push-agent.ps1` to install on a list of servers over WinRM.
- `phase10-windows.sh`: `--msrc`, `--pin`, `--tokens N`, `--status`.
  Proxy: allow `api.msrc.microsoft.com`. Schema `018-windows.sql`.

**r27: script reliability**
- `phase5-dashboard.sh` reported "Timed out" after r26 although the console
  was deployed: its final check looked for `src="app.js"`, which the new
  version stamp changes to `src="app.js?v=..."`. Both checks now accept it.
- Every script checked running containers with `docker ps | grep -q`. Under
  the scripts' strict error settings that can wrongly report a running
  container as stopped (grep stops reading early, and docker's unfinished
  write then fails the check). In testing it happened in 45 of 200 runs.
  25 such checks in nine scripts now read the whole output first.
- `phase5-dashboard.sh` was run end to end ten times against stand-ins: all
  succeeded.

**r26: fresh console after every update**
- `phase5-dashboard.sh` stamps each console file with its fingerprint, so
  browsers load the new version straight after an update, with no need for
  Ctrl+F5. (A browser still running an old copy explains, for example, the
  custom-profile option looking greyed out after moving to r25.)

**r25: custom profiles (H3), check boxes, cleaner report e-mail**
- **Custom profiles:** Hardening › profile list › *New or manage custom
  profiles*. Upload a .txt, .csv or .docx (your standard, an auditor's
  checklist). Each line is matched to benchmark checks, by CIS number first,
  then by wording; AI-01 can suggest a match for a line, choosing only from
  real rules. Review the matches, mark headings as "not a check", and choose
  **Use this profile**. It then appears in the profile list beside CIS L1 and
  L2; scans check only its settings, and reports list its results plus the
  requirements no scan can check as **Not checked automatically**. Editing a
  profile in use makes a new version.
- **Results by check** use drawn tick and cross boxes, with passed checks
  first and failed checks after, in both PDF and Word.
- **Report e-mail:** a white header with the logo, four figures (servers,
  checks passed, checks failed, score), three short sentences and the
  signature. Ready at once; **Polish with AI-01** rewrites it on request.
- Agent **1.6.0** is needed for custom-profile scans. Schema
  `017-custom-profiles.sql`.

**r24: management reports, report e-mails, signature**
- **Report type:** *Management summary* (no fixes: a pass/fail result for
  every check, as a grid for up to 6 servers, and each server's failed checks
  as evidence) or *Technical detail* (findings with how to fix them).
- The cover lists the servers in scope with their IP addresses; the server
  table has an IP column.
- **E-mail a report** from the console (operators and admins): a window with
  the report at a glance, a draft written by AI-01 from the report's own
  figures, To/Cc with quick picks, and the report attached. A draft that
  states any figure not in the report is discarded for a structured one; if
  AI-01 is unavailable the structured draft is used. Sent mail is recorded in
  Activity and in the mail history.
- **Signature:** one signature, set under Admin › Mail, added to every mail:
  alerts, digests and reports.
- Schema `016-signature.sql`.

**r23: schema re-run fix**
- Re-running `phase3a-schema.sh` stopped at 011 with "cannot change name of
  view column": the `v_hardening_latest` view was built on `s.*`, which
  PostgreSQL fixes at creation, and schema 012 added columns to the table
  underneath. The view now lists its columns and is recreated each run.
  012 to 015 had not been applied; nothing was lost. Builds now also refuse
  any view defined with `*`.

**r22: branded reports (H4)**
- **Export report** on the Hardening page: PDF or Word, for all servers, a
  host group, or the servers below 85%, with the findings in detail you
  choose. Both formats have a cover, contents, executive summary, results by
  server, findings with how to fix them, evidence, and method; every page
  carries the logo, title and classification in the header, and the
  copyright line and "Page X of Y" in the footer.
- Every report is kept in an archive with its SHA-256, and generating or
  downloading one is recorded in Activity. Viewers can export reports too.
- **Logo:** drop a PNG in `/patch/data/branding` on PATCH-01. PATCH-01 picks
  `logo.png`, or the largest PNG there; trims the margins; scales it for
  print; checks whether it is light or dark (a dark logo sits on a white
  plate on the navy cover); and takes the accent colour from it.
  `logo-white.png`, if present, is used on dark backgrounds.
- **Admin › Branding:** company name, copyright line, classification, and an
  optional accent colour, with a preview of the processed logo.
- Users, Mail and Branding are now tabs under one **Admin** menu item.
- Mail uses the same company name and, where it suits the navy header, logo.
- The image now includes reportlab, python-docx and Pillow (installed through
  the proxy at build time) and bundles its fonts. Schema `015-branding-reports.sql`.

**r21: mail set up in the console**
- The admin **Mail** page now holds everything: relay, port, encryption,
  mailbox login and password, the relay's CA certificate (pasted in), From
  address and name, what to send, and when.
- **Test connection** walks through name lookup, connection, TLS (showing
  the certificate), login and sender acceptance, using the values in the
  form before they are saved. It sends nothing.
- **Recipients** per kind of mail (critical, tasks, daily digest, weekly),
  each with its own test button. Every change is in Activity.
- The password is write-only in the console and stored encrypted, with a key
  kept only in `/patch/secrets/mail.key` (made by `phase3b-api.sh`). Keep that
  file in backups with the other secrets.
- `phase9-mail.sh` now only checks from the command line (`--status`,
  `--check`, `--test`, `--on`/`--off`). Schema `014-mail-settings.sql`.

**r20: mail alerts**
- Critical alerts within a minute: an exploited CVE newly affecting a server,
  an ESXi host not connected, a vCenter unreachable, a datastore 90% full, a
  change that failed or partly succeeded, hardening drift on a high-severity
  rule, and the worker stopping (checked from the host every 5 minutes).
- Task mails when changes start and finish and when requested scans complete.
- Daily digest at 07:00 SGT and a weekly summary on Mondays.
- Mail is queued and retried (1, 5, 15, 60, 240 minutes), so a relay outage
  delays it rather than losing it. Each alert is sent once; a condition that
  clears and returns alerts again. Several at once arrive as one mail.
- Turning mail on records what is already known without mailing it.
- `phase9-mail.sh`; admin page **Mail**; schema `013-notifications.sql`.

**r19: live scan progress (H1)**
- The Hardening page shows where each scan is, refreshing every 5 seconds:
  waiting for the agent's check-in, downloading the benchmark, scanning with
  rules done out of total, uploading, processing. A scan not picked up after
  two check-ins is flagged with the command to check the agent's timer.
- Agent **1.5.0** reports progress, and stops a hung scan together with any
  helper processes it started. Agents on 1.4.0 still scan; they just show
  "scanning" without figures.
- Schema `012-scan-progress.sql`.

**r18: hardening import, second fix**
- The import stopped with "No module named 'lxml'": the benchmark parser used
  a library that is not in the API image. It now uses Python's built-in XML
  parser, so nothing extra is installed. Tested in a Python without that
  library, and against hostile XML (entity expansion, local file entities),
  which is refused. Needs `phase3b-api.sh` to rebuild the image.

**r17: hardening import fix**
- `phase8-hardening.sh` stopped with "$2: unbound variable" just before
  importing, on both `--fetch` and `--import-zip`, so no content ever reached
  the database. The import step now runs; the script was also run end to
  end, not only syntax-checked.

**r16: two script fixes**
- `phase3b-api.sh --check` reported "worker running but not reporting" on a
  healthy worker. It judged the oldest heartbeat of all the worker's threads
  against two minutes, and the hardening schedule reports hourly by design.
  Each thread is now judged against its own interval.
- `phase8-hardening.sh --import-zip` stopped with "are the same file" when
  given the copy already kept in `/patch/data/hardening/releases`. The copy
  is now skipped in that case.

**r15: hardening, increment 1 (scan and see)**
- **Hardening** page: fleet score and trend, the most widely failing rules,
  per-server scores, and per-rule and per-server detail with what each check
  does and why it matters. Profile dropdown: CIS Level 1 Server, CIS Level 2
  Server (Custom arrives in increment 3).
- `phase8-hardening.sh`: downloads one pinned SCAP Security Guide release
  through the proxy, verifies its SHA-512, and imports the data streams for
  RHEL 8/9/10, Oracle Linux 7/8/9 and Ubuntu 20.04/22.04/24.04.
- Agent 1.4.0 scans with OpenSCAP (read-only, low priority) and uploads the
  full result, kept on PATCH-01 as audit evidence with its SHA-256.
- Weekly CIS Level 1 scan per server by the worker (`HARDENING_SCAN_DAYS`,
  0 turns it off), spread across the day.
- Schema `011-hardening.sql`.

**r14: live VMware map and blast radius**
- **Live map** is now the first VMware tab: networks, clusters, ESXi hosts,
  VMs and datastores on one canvas, graded neon red, amber, green or grey,
  with the legend below. Infrastructure and Applications layouts.
- **Blast radius**: click a host, datastore or port group to see what it
  takes down. For a host, whether HA can restart each VM: HA on, disks not
  on local storage, enough spare memory on the surviving hosts.
- **Live**: the worker follows each vCenter's change stream and events
  (vMotions, HA restarts, host failures, alarms); the map updates within 5
  seconds and the side panel shows a live feed.
- Application groups from vSphere tags (categories named Application, App,
  Service, Workload or System; override with `VMWARE_APP_CATEGORIES`), else
  from the VM folder.
- **Coverage** tab: Distributed vs standard switching, tagged vs ungrouped.
- Schema `010-vmware-live.sql`. Read-only vCenter account throughout;
  nothing is collected from inside a VM.

**r13: schema re-run fix**
- Re-running `phase3a-schema.sh` stopped at 007 with "cannot drop columns
  from view", so 009 (users and changes) was never applied. 007 still defined
  `v_vm_map` with its original, narrower column list, and on a re-run tried to
  replace the wider view 008 had created. The view is now defined in 008 only.
- Nothing was lost: each migration is its own transaction, and 007 rolled
  back cleanly. Re-run `phase3a-schema.sh`.

**r12: users and roles, changes, patch jobs, VMware actions, CVE assessment**
- Individual sign-in with viewer, operator and admin roles, enforced by the
  API; forced password change on first sign-in; lockout after five failures.
  BOT-MODE (formerly Hacker) is admin only.
- Change engine: every patch job and VMware action has a number, reason,
  window and a tamper-proof timeline. Approval optional
  (`REQUIRE_APPROVAL`), off by default.
- Background worker container: runs changes on schedule, recomputes verdicts
  after patching, and enriches assessments.
- Patch jobs with preview, per-job reboot choice, optional VM snapshot and a
  service check. Agent 1.3.0.
- VMware snapshots, revert (with typed confirmation and a safety snapshot),
  power on, guest shutdown and restart, using a separate write account.
- Assess looks up every CVE in NVD, classifies what it affects, checks ESXi,
  vCenter and VM guests as well as packages, adds an AI brief, and exports it
  all to CSV.
- Schema `009-users-changes.sql`.

**Advisory to CVE mapping fix**
- CVEs are linked to advisories through each advisory's reference list. Only
  one of the two field namings Pulp uses was handled, so on some versions no
  CVEs were recorded at all and every advisory appeared to have none.
- Both namings are now accepted, with fallbacks for a CVE that appears only
  in a reference link, is filed under another reference type, or is named in
  the advisory text. The import warns if an advisory set yields no CVEs.
- `./scripts/phase4-cve.sh --diagnose` prints the counts and one advisory
  exactly as your Pulp returns it, so the field names can be confirmed.
- To apply: `./scripts/phase4-cve.sh --import` then `--intel`.

**Fix: VMware page returned HTTP 500**
- The map endpoint asked `v_vm_map` for `esxi_moref`, which groups VMs under
  their ESXi host, but the view did not expose it. Schema
  `008-fix-vm-map.sql` recreates the view with that column and the remaining
  per-VM detail.
- Apply with `./scripts/phase3a-schema.sh`; no re-sync needed, since the data
  was already collected.

**VMware infrastructure map**
- Map tab: vCenter, datacenter, cluster, ESXi host and VM as an expandable
  tree, each VM coloured by patch and agent state.
- ESXi hosts, datastores, networks and clusters, with hardware, versions,
  state and load. Over-provisioned datastores and unresponsive hosts flagged.
- Per VM: ESXi host, folder, datastores, networks, disks, hardware version,
  Tools version, boot time and storage.
- Schema `007-vmware-infra.sql`. Needs a re-sync to populate:
  `./scripts/phase7-vmware.sh --sync`.

**Fixes**
- Agents page returned HTTP 500: its query selected `host_id` and
  `host_status` from the `hosts` table, where those columns are `id` and
  `status`. It now reads the `v_agents` view.
- Chat returned HTTP 500 on filtered questions such as "which rhel servers
  need patches": an untyped NULL filter makes PostgreSQL refuse the query
  ("could not determine data type of parameter"). Every placeholder now
  carries an explicit type.
- `phase4-cve.sh --diagnose` also reports verdict counts and table sizes, so
  an empty dashboard can be traced to a missing sync, import or compute.

**Assess a CVE list, and admin chat**
- New Assess page: paste or upload a CVE list from a SOC or auditor and get a
  per-CVE verdict across the fleet, saved and exportable as CSV.
- New chat, read-only, behind the icon at the bottom right. The model picks
  which prepared query to run; the database supplies every figure and the rows
  are always shown.
- Schema `006-assessments.sql`; `python-multipart` added to the API image.

**CVE intelligence**
- NVD, CISA KEV, FIRST EPSS and Red Hat data per CVE, with the attack type
  derived from the weakness and the CVSS vector.
- The console shows CVSS, an "Exploited" marker, how the flaw is reached, the
  exploitation probability and the CVE description, with sources.
- AI explanations now use these facts instead of an advisory title, which was
  why every CVE produced a similar answer.
- `phase4-cve.sh --intel`, `--set-nvd-key`, `--estimate`; schema
  `005-cve-intel.sql`; nightly timer now refreshes CVE data too.

**VMware, part 1: inventory**
- New VMware page: each vCenter's status, Linux VMs without an agent, VM
  snapshots and their age, and ambiguous links.
- Each server page shows its VM, cluster, ESXi host, size and snapshots.
- Agent 1.2.0 reports the hardware ID used to link servers to VMs.
- `phase7-vmware.sh`, schema `004-vmware.sql`, and pyVmomi 8.0.3.0.1 in the
  API image. Several vCenters are supported and one failing does not stop
  the others.

**Step 7: agent status**
- New Agents page: online, offline, not reporting, uptime, boot time, agent
  version and address for every server.
- Agent 1.1.0 reports boot time. Compatible both ways with older versions.
- "Hosts" is now "Servers". The Servers list has an Agent column, and each
  server page shows uptime.
- Schema `003-agent-status.sql`.

To apply on an existing PATCH-01:

```bash
./scripts/phase3a-schema.sh      # adds schema 003
./scripts/phase3b-api.sh         # API with boot time and the agents endpoint
./scripts/phase5-dashboard.sh    # Agents page
```

then update agents as above.


## Back these up, off both servers

These cannot be recreated. Losing them loses the data they protect.

| File | Why |
|------|-----|
| `/patch/secrets/postgres.env` | Database passwords. Pulp's 600 GB of packages are unnamed files without the database that maps them. |
| `/patch/config/pulp/certs/database_fields.symmetric.key` | Encrypts sensitive database fields. Without it they are unreadable. |
| `/patch/secrets/pulp-admin.txt` | Pulp admin password. |
| `/patch/secrets/api.env` | Console admin password and the AI-01 key. |
| `/etc/patch-platform/images.env` | Exact image digests this build was made from. |
| `/llm/config/api-key` on AI-01 | The key PATCH-01 uses. |
| `/patch/secrets/vcenter/` | vCenter accounts and pinned certificates. |


## Lessons already built into the scripts

Problems met during the first build, each now detected or prevented by the
script that caused it:

- A config value containing a space broke when the file was sourced. All
  generated values are quoted and the file is test-sourced before use.
- Containers running as non-root users could not read certificates, init
  scripts or keys in `0700` directories. Scripts now set the group to match
  each image's own user and prove access from inside a throwaway container
  before starting the real one.
- `lvcreate` waited forever on a hidden prompt. Commands now run with no
  input, so anything that prompts fails at once with a visible error.
- Pulp would not start without a database encryption key. It is generated,
  validated and mounted before migrations run.
- A build under a hardened `umask 077` left llama-server runnable by root
  only. The AI-01 script fixes permissions and runs the binary as the
  service user before starting the service.
- Pulp rejects keeping old package versions with a "mirror" sync. Syncs are
  additive, which also preserves the ability to downgrade.


## Not built yet

- **Reports** with your logo, exported to PDF.
- **Hardening dashboard** using OpenSCAP with CIS-aligned profiles.
- **Windows Server**: WSUS reporting, CVE assessment by build number, then a
  PowerShell agent and hardening.
- **Oracle Linux and Ubuntu advisories.** Verdicts currently come from Red Hat
  advisories synced into Pulp. Oracle's public repositories often omit errata
  data, so Oracle servers need the Oracle OVAL feed; Ubuntu needs the USN feed.
  Until then those servers show no advisories, and the engine's log says so.
- **RHEL 8 modular packages** are skipped and counted rather than compared, to
  avoid false results across module streams.
- **CA-signed certificates and agent mTLS.** PATCH-01 and AI-01 still use
  self-signed placeholders. Replace PATCH-01's before enrolling the full fleet,
  since agents trust the certificate present when they enroll.
- **Single sign-on** (Active Directory or SAML) in place of local accounts.
- **Hardening fixes through the change engine**, once the OpenSCAP dashboard
  exists.
- **Trend Micro.** Apex One protects Windows and macOS, so it adds little to a
  Linux platform. Worth integrating only if the Linux servers appear in Apex
  Central, or if Trend's server product (Server & Workload Protection) is in use.
- **Read-only MCP query layer.** (Step 12.)
