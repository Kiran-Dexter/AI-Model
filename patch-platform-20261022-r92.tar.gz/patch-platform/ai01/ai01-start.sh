#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# AI-01 : start the model server and nginx, repair what does not come up, check health
#
# Usage:
#   sudo ./ai01-start.sh                  start (or confirm) both, then health check
#   sudo ./ai01-start.sh --install-boot   also do this at every boot (systemd service)
#   sudo ./ai01-start.sh --remove-boot    stop doing it at boot
#
# Order: llama-server first (it takes a few minutes to load the model), then
# nginx in front of it. Each is enabled at boot if it was not. A service that
# does not come up is restarted once; if it still fails, the start stops and
# says why: the last lines of its log, and for llama-server whether the binary
# still runs on this OS (an OS update can change the libraries it was built
# against: then rebuild it, see ai01-setup.sh). nginx is only (re)started with
# a configuration that passes nginx -t. Then the full health check runs
# (ai01-update.sh). Nothing secret is printed; the log is root-only.
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 077
export LC_ALL=C

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
HERE="$(dirname "$SELF")"
BASE=/llm
LOG_DIR=$BASE/logs
LISTEN_PORT=8080
UNIT="ai01-start"
LOCK="/run/ai01-start.lock"

HEALTH=yes; INSTALL=no; REMOVE=no
while (($#)); do
  case "$1" in
    --no-health)    HEALTH=no ;;
    --install-boot) INSTALL=yes ;;
    --remove-boot)  REMOVE=yes ;;
    --boot)         ;;
    -h|--help)      sed -n '2,19p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done
[[ $EUID -eq 0 ]] || { echo "Run as root." >&2; exit 1; }

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/ai01-start-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"
log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }

exec 8>"$LOCK"
flock -n 8 || die "Another ai01-start.sh is running."

safe_path() {
  [[ "$(stat -c %u "$1")" == 0 ]] || die "$1 is not owned by root: refusing to run from it as root."
  (( ( 8#$(stat -c %a "$1") & 8#022 ) == 0 )) || die "$1 is writable by others than root: fix with chmod go-w $1"
}
d="$HERE"; while [[ "$d" != / ]]; do safe_path "$d"; d="$(dirname "$d")"; done
for f in "$SELF" "$HERE"/*.sh; do [[ -e "$f" ]] && safe_path "$f"; done

if [[ "$REMOVE" == yes ]]; then
  systemctl disable --now "$UNIT.service" >/dev/null 2>&1 || true
  rm -f "/etc/systemd/system/$UNIT.service"; systemctl daemon-reload
  say "Removed: AI-01 no longer checks itself at boot (llama-server and nginx still start on their own)."
  exit 0
fi
if [[ "$INSTALL" == yes ]]; then
  cat > "/etc/systemd/system/$UNIT.service" <<EOF
[Unit]
Description=AI-01: start llama-server and nginx, repair, health check
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=$SELF --boot
TimeoutStartSec=1800
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
  chmod 0644 "/etc/systemd/system/$UNIT.service"
  systemctl daemon-reload; systemctl enable "$UNIT.service" >/dev/null 2>&1
  say "Installed: at every boot AI-01 starts and checks itself (result: systemctl status $UNIT)."
  say "Running it once now:"
fi

ready() { curl -sf --max-time 5 "http://127.0.0.1:$LISTEN_PORT/health" >/dev/null 2>&1; }
wait_model() {   # the model takes a while to load
  local t=0
  while (( t <= $1 )); do ready && return 0; sleep 10; t=$((t + 10)); done
  return 1
}
binary_runs() {  # does llama-server still load its libraries after an OS update?
  local exe; exe="$(systemctl show -p ExecStart --value llama-server 2>/dev/null | grep -oE 'path=[^ ;]+' | head -1 | cut -d= -f2)"
  [[ -n "$exe" && -x "$exe" ]] || return 0
  ! LD_LIBRARY_PATH="$(dirname "$(readlink -f "$exe")")" ldd "$(readlink -f "$exe")" 2>&1 | grep -q 'not found'
}

RC=0
# ---------------------------------------------------------------------------
step "llama-server"
systemctl is-enabled --quiet llama-server 2>/dev/null || { systemctl enable llama-server >/dev/null 2>&1; say "  enabled at boot (it was not)"; }
if ready; then say "  already up"
else
  systemctl start llama-server || true
  if wait_model 600; then say "  up"
  else
    warn "llama-server did not answer within 10 minutes: restarting it once"
    systemctl restart llama-server || true
    if wait_model 600; then say "  up after a restart"
    else
      journalctl -u llama-server --no-pager -n 40 >>"$LOG_FILE" 2>&1 || true
      tail -n 40 "$LOG_DIR/llama-server.log" >>"$LOG_FILE" 2>/dev/null || true
      if ! binary_runs; then
        say "  llama-server cannot load its libraries any more (an OS update changed them):"
        say "  rebuild it on this server (see ai01-setup.sh, 'Finding llama-server'), then run ai01-setup.sh again."
      else
        say "  llama-server does not start: its last messages are in $LOG_FILE"
      fi
      RC=1
    fi
  fi
fi

# ---------------------------------------------------------------------------
step "nginx"
systemctl is-enabled --quiet nginx 2>/dev/null || { systemctl enable nginx >/dev/null 2>&1; say "  enabled at boot (it was not)"; }
if ! nginx -t >>"$LOG_FILE" 2>&1; then
  say "  nginx's configuration does not pass nginx -t: not (re)started. Details in $LOG_FILE."
  say "  ai01-setup.sh writes a fresh one (run it with the same --patch01-ip as at install)."
  RC=1
elif systemctl is-active --quiet nginx; then say "  already up"
else
  systemctl start nginx || true
  sleep 2
  if systemctl is-active --quiet nginx; then say "  up"
  else
    systemctl restart nginx || true; sleep 2
    if systemctl is-active --quiet nginx; then say "  up after a restart"
    else journalctl -u nginx --no-pager -n 30 >>"$LOG_FILE" 2>&1 || true; say "  nginx does not start: see $LOG_FILE"; RC=1; fi
  fi
fi

say ""
(( RC == 0 )) && say "Both are up." || say "Not everything is up: see above and $LOG_FILE"

if [[ "$HEALTH" == yes ]]; then
  step "Health check"
  "$HERE/ai01-update.sh" </dev/null || RC=1
fi
exit "$RC"
