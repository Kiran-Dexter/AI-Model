#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# AI-01 : update this server (OS packages) and check its health
#
# Usage:
#   ./ai01-update.sh                     health check only (changes nothing)
#   ./ai01-update.sh --os                OS updates (dnf), then health check
#   ./ai01-update.sh --os --security     only security updates
#   ./ai01-update.sh --os --reboot       and restart if needed (health checked after boot)
#   ./ai01-update.sh --dry-run --os      show what would be updated, change nothing
#   ./ai01-update.sh --bench             add a speed test to the health check
#
# Options:
#   --yes        no questions (for a scheduled run)
#   --force      go on although the system is unhealthy before
#   --keep N     configuration backups to keep (default 5)
#
# What it does, in order:
#   1. Refuses to run twice at once, or as non-root.
#   2. Health check BEFORE (unless --force, an update never starts on a broken system).
#   3. Backup of the configuration that dnf could touch (nginx's configuration,
#      the llama-server unit) and the package list, in /llm/backups/ (root only).
#      Keys and certificates are not copied: dnf does not change them.
#   4. OS: dnf upgrade (packages come from PATCH-01's mirrors). nginx's
#      configuration is tested before nginx restarts; llama-server restarts so
#      it runs on the updated libraries.
#   5. Health check AFTER: ai01-setup.sh --check (service, loopback-only binding,
#      HTTPS through nginx, unexposed endpoints refused, a request without the
#      API key refused, model checksum) plus: the service's network lock-down
#      (IPAddressDeny=any) and sandbox are still in force, no unexpected
#      listening ports, disk, clock, failed services.
#   6. With --reboot and a restart needed: a one-shot service runs the health
#      check after boot and removes itself.
#
# Nothing secret is printed or logged; logs and backups are root-only.
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 077
export LC_ALL=C

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
HERE="$(dirname "$SELF")"
BASE=/llm
LOG_DIR=$BASE/logs
BACKUP_ROOT=$BASE/backups
LISTEN_PORT=8080
UNIT="ai01-postboot-check"
LOCK="/run/ai01-update.lock"

DO_OS=no; SECURITY=no; DO_REBOOT=no; DRY_RUN=no; YES=no; FORCE=no; KEEP=5; BENCH=no; POST_BOOT=no
while (($#)); do
  case "$1" in
    --os)        DO_OS=yes ;;
    --security)  SECURITY=yes ;;
    --reboot)    DO_REBOOT=yes ;;
    --dry-run)   DRY_RUN=yes ;;
    --yes)       YES=yes ;;
    --force)     FORCE=yes ;;
    --keep)      KEEP="${2:-}"; shift ;;
    --bench)     BENCH=yes ;;
    --check)     ;;
    --post-boot) POST_BOOT=yes ;;
    -h|--help)   sed -n '2,36p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done
[[ "$KEEP" =~ ^[1-9][0-9]?$ ]] || { echo "--keep takes 1 to 99" >&2; exit 2; }
[[ "$SECURITY" == no || "$DO_OS" == yes ]] || { echo "--security goes with --os" >&2; exit 2; }
[[ $EUID -eq 0 ]] || { echo "Run as root." >&2; exit 1; }

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/ai01-update-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"
log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }
trap 'die "Stopped at line $LINENO (exit $?)."' ERR

confirm() {
  [[ "$YES" == yes ]] && return 0
  [[ -t 0 ]] || die "Not a terminal: add --yes to run without questions."
  local r; read -r -p "$1 [y/N]: " r || true
  [[ "${r,,}" =~ ^(y|yes)$ ]]
}

exec 8>"$LOCK"
flock -n 8 || die "Another ai01-update.sh is running."

# Run as root, and with --reboot from a boot-time service: only from root-owned files
safe_path() {
  [[ "$(stat -c %u "$1")" == 0 ]] || die "$1 is not owned by root: refusing to run from it as root."
  (( ( 8#$(stat -c %a "$1") & 8#022 ) == 0 )) || die "$1 is writable by others than root: fix with chmod go-w $1"
}
d="$HERE"; while [[ "$d" != / ]]; do safe_path "$d"; d="$(dirname "$d")"; done
safe_path "$SELF"
SETUP="$HERE/ai01-setup.sh"
[[ -x "$SETUP" ]] || die "ai01-setup.sh must be in the same folder as this script ($HERE)."
safe_path "$SETUP"
[[ -e "$HERE/ai01-start.sh" ]] && safe_path "$HERE/ai01-start.sh"

# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------
HC_FAIL=0; HC_WARN=0
ok()   { say "  ok    $*"; }
bad()  { say "  FAIL  $*"; HC_FAIL=$((HC_FAIL+1)); }
note() { say "  warn  $*"; HC_WARN=$((HC_WARN+1)); }

health() {
  local when="$1"
  step "Health check ($when)"
  HC_FAIL=0; HC_WARN=0
  local pct
  for m in / "$BASE"; do
    [[ -d "$m" ]] || continue
    pct="$(df -P "$m" | awk 'NR==2 {gsub("%","",$5); print $5}')"
    if (( pct >= 90 )); then bad "disk $m ${pct}% used"; elif (( pct >= 80 )); then note "disk $m ${pct}% used"; else ok "disk $m ${pct}% used"; fi
  done
  local failed; failed="$(systemctl --failed --no-legend --plain 2>/dev/null | awk '{print $1}' | tr '\n' ' ')"
  [[ -z "${failed// }" ]] && ok "no failed system services" || note "failed system services: $failed"
  [[ "$(timedatectl show -p NTPSynchronized --value 2>/dev/null)" == yes ]] && ok "clock synchronised" \
    || note "clock not synchronised (TLS with PATCH-01 depends on it)"

  # The model server's own checks: service, loopback binding, HTTPS, refusals, model checksum
  if "$SETUP" --check </dev/null >>"$LOG_FILE" 2>&1; then ok "ai01-setup.sh --check: all passed"
  else bad "ai01-setup.sh --check failed (details in $LOG_FILE)"; fi

  # The lock-down set up by ai01-setup.sh is still in force after any update
  local deny allow nnp prot
  deny="$(systemctl show -p IPAddressDeny --value llama-server 2>/dev/null || true)"
  allow="$(systemctl show -p IPAddressAllow --value llama-server 2>/dev/null || true)"
  nnp="$(systemctl show -p NoNewPrivileges --value llama-server 2>/dev/null || true)"
  prot="$(systemctl show -p ProtectSystem --value llama-server 2>/dev/null || true)"
  [[ "$deny" == *"0.0.0.0/0"* || "$deny" == *any* ]] && [[ "$allow" =~ 127\.0\.0\.0/8|localhost|::1 ]] \
    && ok "llama-server network lock-down: loopback only" || bad "llama-server network lock-down missing (IPAddressDeny='$deny')"
  [[ "$nnp" == yes && "$prot" == strict ]] && ok "llama-server sandbox in force" \
    || bad "llama-server sandbox weakened (NoNewPrivileges=$nnp, ProtectSystem=$prot)"
  nginx -t >>"$LOG_FILE" 2>&1 && ok "nginx configuration valid" || bad "nginx configuration invalid"

  # Nothing listening that should not be: ssh, nginx on 443 (and 80 if used), llama-server on loopback
  local extra
  extra="$(ss -ltnH 2>/dev/null | awk '{print $4}' | grep -vE "^(127\.0\.0\.1|\[::1\]):|:(22|443|80)$" | sort -u | tr '\n' ' ' || true)"
  [[ -z "${extra// }" ]] && ok "listening ports: only ssh, nginx and loopback" || note "other listening ports: $extra"

  local mem; mem="$(awk '/MemAvailable/ {printf "%d", $2/1024}' /proc/meminfo)"
  (( mem > 1024 )) && ok "memory available: ${mem} MB" || note "memory available only ${mem} MB"

  if [[ "$BENCH" == yes ]]; then
    "$SETUP" --bench </dev/null 2>&1 | grep -E 'tokens/s|wall clock' | sed 's/^/  /' | tee -a "$LOG_FILE" || note "speed test did not finish"
  fi

  say ""
  if (( HC_FAIL == 0 )); then say "Health ($when): PASS ($HC_WARN warning(s))"; else say "Health ($when): FAIL: $HC_FAIL problem(s), $HC_WARN warning(s)"; fi
  printf '%s  %s  %s failed, %s warnings  (log %s)\n' "$(date '+%F %T')" "$when" "$HC_FAIL" "$HC_WARN" "$LOG_FILE" > "$LOG_DIR/update-last.txt"
  chmod 0640 "$LOG_DIR/update-last.txt"
}

wait_settled() {   # the model takes a while to load after a start
  local i
  for i in $(seq 1 60); do
    curl -sf --max-time 5 "http://127.0.0.1:$LISTEN_PORT/health" >/dev/null 2>&1 && return 0
    sleep 10
  done
  warn "llama-server was not ready after 10 minutes."
}

# Start both in order and repair what does not come up (ai01-start.sh)
start_all() {
  say "  starting llama-server and nginx (ai01-start.sh)"
  if "$HERE/ai01-start.sh" --no-health </dev/null >>"$LOG_FILE" 2>&1; then say "  both are up"
  else warn "ai01-start.sh could not bring everything up (details in $LOG_FILE)"; fi
}

needs_restart() {
  if command -v needs-restarting >/dev/null 2>&1; then
    ! needs-restarting -r >/dev/null 2>&1
  else
    local newest; newest="$(rpm -q --last kernel 2>/dev/null | head -1 | awk '{print $1}' | sed 's/^kernel-//')"
    [[ -n "$newest" && "$newest" != "$(uname -r)" ]]
  fi
}

if [[ "$POST_BOOT" == yes ]]; then
  trap - ERR
  start_all
  health "after the restart"
  systemctl disable "$UNIT.service" >/dev/null 2>&1 || true
  rm -f "/etc/systemd/system/$UNIT.service"; systemctl daemon-reload || true
  (( HC_FAIL == 0 )) || exit 1
  exit 0
fi

if [[ "$DO_OS" == no && "$DO_REBOOT" == no ]]; then
  trap - ERR
  health "now"
  (( HC_FAIL == 0 )) || exit 1
  exit 0
fi

# ---------------------------------------------------------------------------
# Before updating
# ---------------------------------------------------------------------------
command -v dnf >/dev/null || die "dnf not found: this script is for AI-01 (RHEL 9)."
trap - ERR
health "before"
trap 'die "Stopped at line $LINENO (exit $?)."' ERR
if (( HC_FAIL > 0 )); then
  [[ "$FORCE" == yes ]] || die "AI-01 is not healthy before the update: run $HERE/ai01-start.sh to start and repair it, then update (or add --force)."
  warn "Updating an unhealthy system (--force)."
fi

OS_COUNT=0
if [[ "$DO_OS" == yes ]]; then
  step "OS updates available"
  DNF_ARGS=(--refresh -q); [[ "$SECURITY" == yes ]] && DNF_ARGS+=(--security)
  rc=0; dnf "${DNF_ARGS[@]}" check-update >"$LOG_DIR/.dnf-check" 2>>"$LOG_FILE" || rc=$?   # 100: updates available
  case "$rc" in
    0)   say "None." ;;
    100) OS_COUNT="$(grep -cE '^[A-Za-z0-9_.+-]+\.(x86_64|noarch|i686|aarch64)\s' "$LOG_DIR/.dnf-check" || true)"
         say "$OS_COUNT package(s) to update$([[ "$SECURITY" == yes ]] && echo ' (security)')"
         grep -E '^(kernel|nginx|openssl|glibc|libstdc\+\+|libgomp|systemd)[.-]' "$LOG_DIR/.dnf-check" | awk '{print "  " $1 "  " $2}' | head -15 || true ;;
    *)   die "dnf could not read the repositories (exit $rc): AI-01's packages come from PATCH-01's mirrors; is PATCH-01 up?" ;;
  esac
  rm -f "$LOG_DIR/.dnf-check"
fi
if [[ "$DRY_RUN" == yes ]]; then say ""; say "Dry run: nothing changed."; exit 0; fi

if [[ "$DO_OS" == yes && "$OS_COUNT" != 0 ]]; then
  confirm "Update AI-01 now? AI explanations pause for a few minutes" || die "Not confirmed."

  step "Backup"
  BK="$BACKUP_ROOT/update-$(date +%Y%m%d-%H%M%S)"
  mkdir -p "$BK"; chmod 0700 "$BACKUP_ROOT" "$BK"
  # Configuration only: no keys, no certificates (dnf does not touch those)
  tar -C / -czf "$BK/config.tar.gz" --exclude='*.key' --exclude='*.pem' \
      etc/nginx/nginx.conf etc/nginx/conf.d etc/systemd/system/llama-server.service 2>>"$LOG_FILE" || true
  rpm -qa --qf '%{NAME}-%{EPOCHNUM}:%{VERSION}-%{RELEASE}.%{ARCH}\n' | sort > "$BK/packages-before.txt"
  chmod 0600 "$BK"/*
  say "Saved in $BK"
  mapfile -t OLD < <(ls -1d "$BACKUP_ROOT"/update-* 2>/dev/null | sort | head -n -"$KEEP")
  for d in "${OLD[@]}"; do rm -rf --one-file-system -- "$d"; say "Removed old backup $(basename "$d")"; done

  step "OS updates"
  DNF_ARGS=(-y); [[ "$SECURITY" == yes ]] && DNF_ARGS+=(--security)
  dnf "${DNF_ARGS[@]}" upgrade >>"$LOG_FILE" 2>&1 || die "dnf upgrade failed. Configuration backup: $BK."
  rpm -qa --qf '%{NAME}-%{EPOCHNUM}:%{VERSION}-%{RELEASE}.%{ARCH}\n' | sort > "$BK/packages-after.txt"; chmod 0600 "$BK/packages-after.txt"
  say "Updated $(comm -13 "$BK/packages-before.txt" "$BK/packages-after.txt" | wc -l | tr -d ' ') package(s)"

  # Services onto the updated packages: nginx only with a valid configuration
  nginx -t >>"$LOG_FILE" 2>&1 || die "nginx's configuration fails its test after the update: nginx was NOT restarted (it still runs). Compare with $BK/config.tar.gz."
  systemctl restart nginx || true
  systemctl restart llama-server || true
  start_all
fi

# ---------------------------------------------------------------------------
# After updating
# ---------------------------------------------------------------------------
trap - ERR
health "after the update"
RESULT=$HC_FAIL

if needs_restart; then
  if [[ "$DO_REBOOT" == yes && "$RESULT" -gt 0 && "$FORCE" == no ]]; then
    say ""
    say "A restart is needed, but the health check failed: not restarting. Fix the problems above, then run $SELF --reboot"
  elif [[ "$DO_REBOOT" == yes ]]; then
    step "Restart"
    cat > "/etc/systemd/system/$UNIT.service" <<EOF
[Unit]
Description=AI-01 health check after an update restart (runs once, then removes itself)
After=network-online.target llama-server.service nginx.service
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=$SELF --post-boot
TimeoutStartSec=1800

[Install]
WantedBy=multi-user.target
EOF
    chmod 0644 "/etc/systemd/system/$UNIT.service"
    systemctl daemon-reload; systemctl enable "$UNIT.service" >/dev/null 2>&1
    say "Restarting in 1 minute. The health check runs after boot: see $LOG_DIR/update-last.txt"
    shutdown -r +1 "AI-01 restarts after its update" >/dev/null 2>&1 || systemctl reboot
  else
    say ""
    say "A restart is needed to finish the update (new kernel or core libraries)."
    say "Restart in a quiet moment with:  $SELF --reboot --yes"
  fi
fi
say "Log: $LOG_FILE"
(( RESULT == 0 )) || exit 1
exit 0
