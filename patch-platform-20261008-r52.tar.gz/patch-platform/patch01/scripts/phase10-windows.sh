#!/usr/bin/env bash
# ===========================================================================
# PATCH-01 : phase 10 - Windows servers
#
#   ./phase10-windows.sh --msrc [MONTHS]   import Microsoft's Security Update
#                                          Guide (default 24 months), then
#                                          recompute every server's verdicts
#   ./phase10-windows.sh --pin             the certificate pin for Windows agents
#   ./phase10-windows.sh --tokens N [GROUP]  N single-use enrolment tokens, one
#                                          per line, for push-agent.ps1
#   ./phase10-windows.sh --wsus-token NAME a reporting token for wsus-report.ps1
#                                          on the WSUS server called NAME
#   ./phase10-windows.sh --status          Windows servers and what is imported
#
# The Microsoft import goes through the proxy, like the other feeds: allow
# api.msrc.microsoft.com (docs/proxy-allowlist.txt).
# ===========================================================================
set -Eeuo pipefail

gq() { grep "$@" >/dev/null; }
PATCH_BASE="${PATCH_BASE:-/patch}"
SECRETS_DIR="$PATCH_BASE/secrets"
CERT="$PATCH_BASE/certs/patch01.crt"
WORKER=patch01-worker
API=patch01-api
say()  { printf '%s\n' "$*"; }
step() { printf '\n==> %s\n' "$*" >&2; }
die()  { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
usage() { sed -n '4,17p' "$0" | sed 's/^# \{0,1\}//'; exit "${1:-0}"; }

[[ $EUID -eq 0 ]] || die "Run as root."
[[ $# -ge 1 ]] || usage 1

running() { docker ps --format '{{.Names}}' | gq -x "$1"; }

case "$1" in
  --msrc)
    MONTHS="${2:-24}"
    [[ "$MONTHS" =~ ^[0-9]{1,3}$ ]] || die "Months must be a number."
    running "$WORKER" || die "$WORKER is not running."
    step "Importing Microsoft's Security Update Guide ($MONTHS months)"
    docker exec -i "$WORKER" python -m app.msrc import --months "$MONTHS" \
      || die "The import failed. Is api.msrc.microsoft.com allowed through the proxy?"
    step "Recomputing verdicts for every server"
    docker exec -i "$WORKER" python -m app.cve_engine --compute
    ;;
  --pin)
    # --pin               the certificate PATCH-01 serves now
    # --pin --cert FILE   a certificate not installed yet, e.g. the CA-signed one
    C="$CERT"
    [[ "${2:-}" == --cert ]] && C="${3:-}"
    [[ -f "$C" ]] || die "No certificate at ${C:-(none given)}"
    PIN="$(openssl x509 -in "$C" -outform der | sha256sum | cut -d' ' -f1)" || die "$C is not a PEM certificate."
    say "$PIN"
    if [[ "$C" != "$CERT" && -f "$CERT" ]]; then
      OLD="$(openssl x509 -in "$CERT" -outform der | sha256sum | cut -d' ' -f1)"
      printf '\nBefore installing it, give Windows agents both pins, so they work before and after:\n' >&2
      printf '  .\\push-agent.ps1 -Computers servers.txt -Server https://patch01.example -Pin %s,%s -Repin\n' "$OLD" "$PIN" >&2
      printf '  .\\wsus-report.ps1 -Repin -Pin %s,%s      (on each WSUS server)\n' "$OLD" "$PIN" >&2
    else
      printf '\nUse it as -Pin on Windows.\n' >&2
    fi
    ;;
  --tokens)
    N="${2:-}"; GROUP="${3:-windows}"
    [[ "$N" =~ ^[0-9]{1,3}$ && "$N" -ge 1 ]] || die "Give the number of tokens, e.g. --tokens 50"
    [[ "$GROUP" =~ ^[A-Za-z0-9_.-]{1,60}$ ]] || die "Group names are letters, digits, . _ -"
    ADMIN_PW="$(grep -E '^ADMIN_PASSWORD=' "$SECRETS_DIR/api.env" | cut -d= -f2-)"
    [[ -n "$ADMIN_PW" ]] || die "Could not read the admin password."
    psqlq() { docker exec -i patch01-postgres psql -U postgres -d patchdb -qtAX -v ON_ERROR_STOP=1 "$@"; }
    if [[ "$GROUP" == windows ]]; then
      # The default group for Windows servers, made the first time it is used
      psqlq -c "INSERT INTO host_groups (name, description, environment, max_concurrent, patch_order)
                VALUES ('windows', 'Windows servers', 'prod', 5, 100) ON CONFLICT (name) DO NOTHING;" >/dev/null \
        || die "Could not create the windows host group."
    elif [[ -z "$(psqlq -c "SELECT 1 FROM host_groups WHERE name='$GROUP'")" ]]; then
      die "No host group called $GROUP. Existing groups: $(psqlq -c "SELECT string_agg(name, ', ' ORDER BY patch_order, name) FROM host_groups")"
    fi
    for i in $(seq 1 "$N"); do
      RESP="$(curl -sk -u "admin:$ADMIN_PW" -H 'Content-Type: application/json' \
        -d "{\"host_group\":\"$GROUP\",\"ttl_hours\":72}" https://127.0.0.1/api/v1/admin/enrollment-tokens)"
      T="$(printf '%s' "$RESP" | python3 -c 'import json,sys
try: print(json.load(sys.stdin)["enrollment_token"])
except Exception: pass')"
      [[ -n "$T" ]] || die "Token $i failed: $RESP"
      say "$T"
    done
    printf '\n%s tokens for group %s, valid 72 hours, one per server.\n' "$N" "$GROUP" >&2
    ;;
  --wsus-token)
    NAME="$(printf '%s' "${2:-}" | tr '[:upper:]' '[:lower:]')"
    [[ "$NAME" =~ ^[a-z0-9][a-z0-9.-]{0,120}$ ]] || die "Give the WSUS server's name, e.g. --wsus-token wsus01"
    TOKEN="$(openssl rand -base64 36 | tr '+/' '-_' | tr -d '=\n')"
    HASH="$(printf '%s' "$TOKEN" | sha256sum | cut -d' ' -f1)"
    docker exec -i patch01-postgres psql -U postgres -d patchdb -qtAX -v ON_ERROR_STOP=1 -c \
      "INSERT INTO wsus_sources (name, token_hash) VALUES ('$NAME', '$HASH')
       ON CONFLICT (name) DO UPDATE SET token_hash = EXCLUDED.token_hash;" >/dev/null || die "Could not store the token."
    say "$TOKEN"
    printf '\nReporting token for WSUS %s. Making a new one replaces the old.\n' "$NAME" >&2
    ;;
  --status)
    running "$WORKER" || die "$WORKER is not running."
    docker exec -i "$WORKER" python -m app.msrc status
    docker exec -i patch01-postgres psql -U postgres -d patchdb -c \
      "SELECT hostname, os_edition, kernel_running AS build, wu_source, wu_searched_at, coalesce(wu_error,'') AS problem,
              (SELECT count(*) FROM windows_updates w WHERE w.host_id=h.id) AS missing
         FROM hosts h WHERE os_id='windows' ORDER BY hostname;"
    ;;
  -h|--help) usage 0 ;;
  *) usage 1 ;;
esac
