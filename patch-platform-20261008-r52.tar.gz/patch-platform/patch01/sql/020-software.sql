-- ===========================================================================
-- PATCH-01 : schema 020 - software catalog (Windows installers from a share)
--
-- Applied after 019. Idempotent.
--
-- software_catalog: each installer registered once: where it is (a UNC path
-- on a share the agents cannot read by themselves), its SHA-256, the
-- publisher whose Authenticode signature it must carry, how to install,
-- upgrade and remove it (fixed templates, no free-form commands) and how to
-- recognise it once installed. A different admin must approve an entry
-- before any job can use it.
--
-- The share credential is NEVER stored here: it is entered when a job runs,
-- kept encrypted in memory-backed storage on the host for that job only.
-- ===========================================================================

ALTER TYPE agent_verb ADD VALUE IF NOT EXISTS 'software_action';
ALTER TYPE change_kind ADD VALUE IF NOT EXISTS 'software';

CREATE TABLE IF NOT EXISTS software_catalog (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name             TEXT NOT NULL,
    version          TEXT NOT NULL,
    kind             TEXT NOT NULL CHECK (kind IN ('msi', 'exe')),
    unc_path         TEXT NOT NULL,                -- \\fileserver\share\folder\setup.msi
    sha256           TEXT NOT NULL CHECK (sha256 ~ '^[0-9a-f]{64}$'),
    publisher        TEXT,                         -- Authenticode signer subject that must match
    require_signature BOOLEAN NOT NULL DEFAULT true,
    install_args     TEXT,                         -- EXE only: silent options, reviewed with the entry
    uninstall_args   TEXT,                         -- EXE only: silent options for its own uninstaller
    product_code     TEXT,                         -- MSI: {GUID}, used to remove and to verify
    detect_name      TEXT NOT NULL,                -- DisplayName in Programs and Features
    replaces_below   TEXT,                         -- upgrade: only servers with an older version
    state            TEXT NOT NULL DEFAULT 'pending' CHECK (state IN ('pending', 'approved', 'disabled')),
    created_by       TEXT NOT NULL,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    approved_by      TEXT,
    approved_at      TIMESTAMPTZ,
    notes            TEXT,
    CHECK (approved_by IS NULL OR approved_by <> created_by),     -- two people, always
    UNIQUE (name, version, kind)
);

INSERT INTO schema_version (version, description)
VALUES (20, 'Software catalog for Windows installers')
ON CONFLICT (version) DO NOTHING;
