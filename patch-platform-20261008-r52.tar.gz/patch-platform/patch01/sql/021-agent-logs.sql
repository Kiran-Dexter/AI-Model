-- ===========================================================================
-- PATCH-01 : schema 021 - agent log lines in the console
--
-- Applied after 020. Idempotent.
--
-- Each agent sends the lines it writes to its own log, so failures can be
-- read in the console instead of on the server. Bounded: the newest 3000
-- lines per server, at most 14 days. Lines are scrubbed of anything that
-- looks like a secret when they arrive, whatever the agent sent.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS agent_logs (
    id        BIGSERIAL PRIMARY KEY,
    host_id   UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    at        TIMESTAMPTZ NOT NULL,
    level     TEXT NOT NULL DEFAULT 'INFO',
    line      TEXT NOT NULL,
    received  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_agent_logs_host ON agent_logs (host_id, id);
CREATE INDEX IF NOT EXISTS idx_agent_logs_id ON agent_logs (id);

-- When the agent last started a run (its check-in). Unlike last_checkin, an
-- inventory report sent in the middle of a run does not move it, so it tells
-- reliably whether a run that took a command has ended.
ALTER TABLE hosts ADD COLUMN IF NOT EXISTS last_run_at TIMESTAMPTZ;

INSERT INTO schema_version (version, description)
VALUES (21, 'Agent log lines in the console')
ON CONFLICT (version) DO NOTHING;
