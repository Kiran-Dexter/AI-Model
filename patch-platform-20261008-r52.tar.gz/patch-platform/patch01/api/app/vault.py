"""Run-time credentials: a share account entered when a job runs.

Never in the database, never in a log, never on disk. Each credential is
encrypted (Fernet, with a key kept separately in the secrets folder) and
written to /run/patch01-vault on the host, which is memory-backed and emptied
at every reboot. It belongs to one change, expires with it (at most
MAX_HOURS), and each server's command may fetch it exactly once.
"""

import json
import os
import re
import time

VAULT_DIR = os.environ.get("VAULT_DIR", "/vault")
KEY_FILE = os.environ.get("RUN_KEY_FILE", "/etc/patch01/run.key")
MAX_HOURS = 6
USER_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}([\\@][A-Za-z0-9._-]{1,128})?$")
ID_RE = re.compile(r"^[0-9a-f-]{36}$")


class VaultError(ValueError):
    pass


def _fernet():
    from cryptography.fernet import Fernet
    with open(KEY_FILE, "rb") as fh:
        return Fernet(fh.read().strip())


def _path(change_id):
    if not ID_RE.match(str(change_id)):
        raise VaultError("bad change id")
    return os.path.join(VAULT_DIR, f"change-{change_id}.cred")


def available():
    """The vault can be used: memory-backed folder present, key readable."""
    return os.path.isdir(VAULT_DIR) and os.access(KEY_FILE, os.R_OK)


def put(change_id, username, password, by, hours=MAX_HOURS):
    if not available():
        raise VaultError("The credential store is not set up on PATCH-01: run phase3b-api.sh.")
    username = (username or "").strip()
    if not USER_RE.match(username):
        raise VaultError("The user must look like DOMAIN\\user or user@domain.")
    if not password or len(password) > 256 or any(c in password for c in "\r\n\x00"):
        raise VaultError("The password is empty, too long, or contains a line break.")
    hours = max(1, min(int(hours), MAX_HOURS))
    token = _fernet().encrypt(json.dumps({"u": username, "p": password}).encode())
    rec = {"exp": int(time.time()) + hours * 3600, "by": by, "at": int(time.time()), "t": token.decode()}
    path = _path(change_id)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        json.dump(rec, fh)
    os.replace(tmp, path)
    return {"expires_at": rec["exp"], "user": username}


def status(change_id):
    """Whether a live credential is held for this change (never the secret)."""
    try:
        with open(_path(change_id)) as fh:
            rec = json.load(fh)
    except (OSError, ValueError):
        return None
    if rec.get("exp", 0) < time.time():
        discard(change_id)
        return None
    return {"by": rec.get("by"), "at": rec.get("at"), "expires_at": rec.get("exp")}


def fetch_once(change_id, command_id):
    """The credential for one command, once. A second fetch is refused."""
    if not ID_RE.match(str(command_id)):
        raise VaultError("bad command id")
    marker = os.path.join(VAULT_DIR, f"fetched-{command_id}")
    try:
        fd = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)   # atomic: first caller wins
        os.close(fd)
    except FileExistsError:
        raise VaultError("This command has already fetched its credential.")
    try:
        with open(_path(change_id)) as fh:
            rec = json.load(fh)
    except (OSError, ValueError):
        raise VaultError("No credential is held for this job (it expired or was discarded).")
    if rec.get("exp", 0) < time.time():
        discard(change_id)
        raise VaultError("The credential for this job has expired.")
    ttl = max(1, rec["exp"] - int(time.time()))
    data = json.loads(_fernet().decrypt(rec["t"].encode(), ttl=MAX_HOURS * 3600 + 60))
    return {"username": data["u"], "password": data["p"], "expires_in": ttl}


def discard(change_id):
    try:
        os.remove(_path(change_id))
    except (OSError, VaultError):
        pass


def sweep():
    """Remove expired credentials and markers older than the longest job."""
    if not os.path.isdir(VAULT_DIR):
        return
    now = time.time()
    for f in os.listdir(VAULT_DIR):
        p = os.path.join(VAULT_DIR, f)
        try:
            if f.startswith("change-") and f.endswith(".cred"):
                with open(p) as fh:
                    if json.load(fh).get("exp", 0) < now:
                        os.remove(p)
            elif f.startswith("fetched-") and os.path.getmtime(p) < now - MAX_HOURS * 3600:
                os.remove(p)
        except (OSError, ValueError):
            pass
