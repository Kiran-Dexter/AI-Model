"""Software catalog: Windows installers from a share.

Each entry describes one installer completely, so a job carries no free-form
input: where it is, its SHA-256, whose signature it must carry, and how to
install, upgrade, remove and recognise it. A different admin approves an
entry before any job can use it.

Every field is matched against a strict pattern. Installer options never go
through a shell (the agent starts the installer directly), and characters a
shell or Windows would treat as command separators are refused anyway.
"""

import re

KINDS = ("msi", "exe")
ACTIONS = ("install", "upgrade", "uninstall")

NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._()+,-]{0,79}$")
VERSION_RE = re.compile(r"^[0-9A-Za-z][0-9A-Za-z._-]{0,39}$")
# \\server\share\folder\file.msi : no "..", no drive letters, no URLs
UNC_RE = re.compile(r"^\\\\[A-Za-z0-9][A-Za-z0-9.-]{0,252}\\[A-Za-z0-9$_.-]{1,80}(\\[A-Za-z0-9 _.()+-]{1,120}){1,12}$")
SHA_RE = re.compile(r"^[0-9a-f]{64}$")
GUID_RE = re.compile(r"^\{[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}$")
# Silent options: letters, digits, paths (\\ and brackets) and the punctuation installers use;
# no & | ; < > ^ % ` $ or newlines
ARGS_RE = re.compile(r'^[A-Za-z0-9 /\\_.:=,+()\-"]{0,300}$')
DETECT_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._()+,&-]{0,119}$")
PUBLISHER_RE = re.compile(r"^[^\x00-\x1f]{1,200}$")


class Invalid(ValueError):
    pass


def validate_entry(d):
    """A clean catalog entry from submitted fields, or Invalid with a reason."""
    def need(key, rx, label, optional=False):
        v = (d.get(key) or "").strip()
        if not v and optional:
            return None
        if not rx.match(v):
            raise Invalid(f"{label}: not valid.")
        return v
    kind = (d.get("kind") or "").lower()
    if kind not in KINDS:
        raise Invalid("The installer type must be MSI or EXE.")
    out = {
        "name": need("name", NAME_RE, "The name"),
        "version": need("version", VERSION_RE, "The version"),
        "kind": kind,
        "unc_path": need("unc_path", UNC_RE, "The share path (\\\\server\\share\\folder\\file)"),
        "sha256": (d.get("sha256") or "").strip().lower(),
        "detect_name": need("detect_name", DETECT_RE, "The name in Programs and Features"),
        "require_signature": bool(d.get("require_signature", True)),
        "publisher": None, "install_args": None, "uninstall_args": None, "product_code": None,
        "replaces_below": need("replaces_below", VERSION_RE, "The 'upgrades versions below' value", optional=True),
        "notes": (d.get("notes") or "").strip()[:500] or None,
    }
    if ".." in out["unc_path"]:
        raise Invalid("The share path must not contain '..'.")
    if not out["unc_path"].lower().endswith("." + kind):
        raise Invalid(f"The share path must end in .{kind} for an {kind.upper()} installer.")
    if not SHA_RE.match(out["sha256"]):
        raise Invalid("The SHA-256 must be 64 hexadecimal characters (Get-FileHash -Algorithm SHA256).")
    pub = (d.get("publisher") or "").strip()
    if out["require_signature"]:
        if not PUBLISHER_RE.match(pub):
            raise Invalid("Give the publisher whose signature the installer must carry (its certificate subject).")
        out["publisher"] = pub
    if kind == "msi":
        out["product_code"] = need("product_code", GUID_RE, "The MSI product code ({XXXXXXXX-XXXX-...})")
        if (d.get("install_args") or d.get("uninstall_args")):
            raise Invalid("MSI installers use fixed options; extra options are not accepted.")
    else:
        out["install_args"] = need("install_args", ARGS_RE, "The silent install options")
        if not out["install_args"]:
            raise Invalid("Give the EXE's silent install options (for example /S or /quiet /norestart).")
        out["uninstall_args"] = need("uninstall_args", ARGS_RE, "The silent uninstall options", optional=True)
    return out


def actions_for(entry):
    """What this entry can do: removing an EXE needs its silent uninstall options."""
    acts = ["install", "upgrade"]
    if entry["kind"] == "msi" or entry.get("uninstall_args"):
        acts.append("uninstall")
    return acts


def command_plan(entry, action):
    """Everything the agent needs, as data. The agent builds the command line
    from these fields with fixed templates; nothing here is run by a shell."""
    if action not in actions_for(entry):
        raise Invalid(f"'{action}' is not available for this entry.")
    return {
        "action": action, "kind": entry["kind"], "name": entry["name"], "version": entry["version"],
        "unc_path": entry["unc_path"], "sha256": entry["sha256"],
        "require_signature": entry["require_signature"], "publisher": entry["publisher"],
        "install_args": entry["install_args"], "uninstall_args": entry["uninstall_args"],
        "product_code": entry["product_code"], "detect_name": entry["detect_name"],
    }
