#!/usr/bin/env bash
# ===========================================================================
# push-linux.sh - install the PATCH-01 agent on many Linux servers over SSH,
# or switch already-enrolled ones to verify PATCH-01's CA-signed certificate.
#
#   ./push-linux.sh -H servers.txt -s https://patch01.example --ca corp-ca.pem --test-only
#   ./push-linux.sh -H servers.txt -s https://patch01.example --ca corp-ca.pem -t tokens.txt
#
#   -H FILE      servers, one per line (# comments allowed)
#   -s URL       PATCH-01, as the servers should reach it
#   --ca FILE    your CA certificate(s), PEM: servers verify PATCH-01 with it
#   -t FILE      enrolment tokens, one per line (phase10-windows.sh --tokens N
#                GROUP makes them); only servers not yet enrolled use one
#   -u USER      SSH user (default root; others need passwordless sudo)
#   -P N         servers at a time (default 5)
#   --test-only  only the checks; changes nothing
#
# Each server is checked first: SSH and sudo, a Python for the agent, and
# that it can reach PATCH-01 and verify its certificate with --ca. Only then
# is anything copied or installed. Servers already enrolled keep their
# identity and use no token. Results: push-linux-<time>.csv beside this script.
# Needs SSH keys (BatchMode): no password prompts, so it can run unattended.
# ===========================================================================
set -Eeuo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOSTS=""; SERVER=""; CA=""; TOKENS=""; SSH_USER=root; PAR=5; TEST=no
while [[ $# -gt 0 ]]; do
  case "$1" in
    -H) HOSTS="$2"; shift ;; -s) SERVER="${2%/}"; shift ;; --ca) CA="$2"; shift ;;
    -t) TOKENS="$2"; shift ;; -u) SSH_USER="$2"; shift ;; -P) PAR="$2"; shift ;;
    --test-only) TEST=yes ;; -h|--help) sed -n '4,25p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Unknown option $1 (see --help)" >&2; exit 1 ;;
  esac; shift
done
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
[[ -f "$HOSTS" ]] || die "Give the server list with -H."
[[ "$SERVER" =~ ^https://[A-Za-z0-9.-]+$ ]] || die "Give PATCH-01's address with -s, e.g. https://patch01.example"
[[ -f "$CA" ]] || die "Give your CA certificate with --ca (PEM)."
openssl x509 -in "$CA" -noout 2>/dev/null || die "$CA is not a PEM certificate."
[[ -f "$HERE/install-agent.sh" && -f "$HERE/patch-agent.py" ]] || die "Run it from the client folder (install-agent.sh and patch-agent.py beside it)."
[[ "$PAR" =~ ^[0-9]+$ && "$PAR" -ge 1 && "$PAR" -le 20 ]] || die "-P must be 1 to 20."
# Prove the CA verifies PATCH-01 from here before touching 100 servers
curl -s --noproxy '*' --cacert "$CA" -o /dev/null --max-time 10 "$SERVER/api/v1/health" \
  || die "This CA file does not verify $SERVER from here (wrong CA, or the name is not in the certificate)."

mapfile -t LIST < <(sed 's/#.*//; s/[[:space:]]//g' "$HOSTS" | awk 'NF && !seen[$0]++')
((${#LIST[@]})) || die "No servers in $HOSTS."
declare -a TOK=()
[[ -n "$TOKENS" ]] && mapfile -t TOK < <(sed 's/[[:space:]]//g' "$TOKENS" | awk 'NF')
OUT="$HERE/push-linux-$(date +%Y%m%d-%H%M).csv"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
SSH=(ssh -o BatchMode=yes -o ConnectTimeout=10 -o StrictHostKeyChecking=accept-new -o LogLevel=ERROR)
SCP=(scp -q -o BatchMode=yes -o ConnectTimeout=10 -o StrictHostKeyChecking=accept-new -o LogLevel=ERROR)
SUDO=""; [[ "$SSH_USER" != root ]] && SUDO="sudo -n"

# Run on each server as the first step: facts as key=value lines, nothing changed
read -r -d '' PRECHECK <<'REMOTE' || true
set -u
S="$1"; CAF="$2"
echo "os=$( . /etc/os-release 2>/dev/null && echo "$ID $VERSION_ID" || uname -s)"
PY=""; for c in /usr/bin/python3 /usr/libexec/platform-python /usr/bin/python3.6; do [ -x "$c" ] && { PY="$c"; break; }; done
echo "python=${PY:-none}"
[ -f /etc/patch-agent/token ] && echo "enrolled=yes" || echo "enrolled=no"
code=$(curl -s --noproxy '*' --cacert "$CAF" -o /dev/null -w '%{http_code}' --max-time 10 "$S/api/v1/health" 2>/dev/null || true)
echo "reach=${code:-000}"
if [ "${code:-000}" != 200 ]; then
  raw=$(curl -sk --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 10 "$S/api/v1/health" 2>/dev/null || true)
  echo "reach_unverified=${raw:-000}"
fi
REMOTE

# Phase 1, on every server: can it take the agent? Nothing is installed.
check() {   # check <index> <host>  ->  host|os|state|detail|enrolled
  local i="$1" h="$2" facts os py enr reach raw tmp t="$SSH_USER@$2"
  if ! "${SSH[@]}" "$t" "$SUDO true" >/dev/null 2>&1; then
    if "${SSH[@]}" "$t" true >/dev/null 2>&1; then echo "$h|?|failed|SSH works but sudo needs a password: give $SSH_USER passwordless sudo, or use -u root|"
    else echo "$h|?|failed|no SSH as $SSH_USER (key not accepted, or host unreachable)|"; fi
    return
  fi
  tmp="/tmp/patch-agent-check.$$.$i"
  "${SSH[@]}" "$t" "mkdir -p $tmp && chmod 700 $tmp" && "${SCP[@]}" "$CA" "$t:$tmp/ca.pem" \
    || { echo "$h|?|failed|could not copy the CA file to $tmp|"; return; }
  facts="$("${SSH[@]}" "$t" "bash -s -- '$SERVER' '$tmp/ca.pem'; rm -rf $tmp" <<<"$PRECHECK" 2>/dev/null || true)"
  os="$(sed -n 's/^os=//p' <<<"$facts")"; py="$(sed -n 's/^python=//p' <<<"$facts")"
  enr="$(sed -n 's/^enrolled=//p' <<<"$facts")"; reach="$(sed -n 's/^reach=//p' <<<"$facts")"
  raw="$(sed -n 's/^reach_unverified=//p' <<<"$facts")"
  if [[ -z "$py" || "$py" == none ]]; then echo "$h|$os|failed|no Python 3 (install python3 first)|$enr"; return; fi
  if [[ "$reach" != 200 ]]; then
    if [[ "$raw" =~ ^[1-5][0-9][0-9]$ ]]; then echo "$h|$os|failed|reaches PATCH-01 but cannot verify its certificate with this CA|$enr"
    else echo "$h|$os|failed|cannot reach $SERVER on 443 (DNS or firewall)|$enr"; fi
    return
  fi
  [[ "$enr" == yes ]] && echo "$h|$os|ready|enrolled; will switch to verified TLS|yes" \
                      || echo "$h|$os|ready|not enrolled; will install and enrol|no"
}

# Phase 2, on servers that passed: install, or switch an enrolled one to the CA
install_one() {   # install_one <index> <host> <token or empty>
  local i="$1" h="$2" tok="$3" out tmp t="$SSH_USER@$2"
  tmp="/tmp/patch-agent-setup.$$.$i"
  "${SSH[@]}" "$t" "mkdir -p $tmp && chmod 700 $tmp" \
    && "${SCP[@]}" "$CA" "$HERE/install-agent.sh" "$HERE/patch-agent.py" "$t:$tmp/" \
    || { echo "failed|copy to $tmp failed"; return; }
  out="$("${SSH[@]}" "$t" "cd $tmp && mv ca.pem patch01-ca.pem && $SUDO bash ./install-agent.sh --server '$SERVER' --ca $tmp/patch01-ca.pem ${tok:+--token '$tok'} 2>&1; echo \"rc=\$?\"; rm -rf $tmp" 2>&1 || true)"
  if grep -q '^rc=0$' <<<"$out"; then
    if grep -qi 'already enrolled' <<<"$out"; then echo "switched|verifies PATCH-01 with the CA now; identity kept"
    else echo "installed|enrolled, and verifies PATCH-01 with the CA"; fi
  else
    echo "failed|installer: $(grep -iE 'error|fail' <<<"$out" | tail -1 | cut -c1-140)"
  fi
}

run_parallel() {   # run_parallel <function> : over LIST, results in $WORK/<fn>.<i>
  local fn="$1" i=0 h
  for h in "${LIST[@]}"; do
    if [[ "$fn" == check ]] || [[ -f "$WORK/go.$i" ]]; then
      ( if [[ "$fn" == check ]]; then check "$i" "$h"; else install_one "$i" "$h" "$(cat "$WORK/go.$i")"; fi >"$WORK/$fn.$i" ) &
      while (( $(jobs -rp | wc -l) >= PAR )); do sleep 0.3; done
    fi
    i=$((i + 1))
  done
  wait
}

printf '%s servers, %s at a time%s\n\n' "${#LIST[@]}" "$PAR" "$( [[ $TEST == yes ]] && echo ', checks only' )"
echo "Phase 1: checking every server"
run_parallel check
# Tokens go only to servers that passed and are not yet enrolled
need=0; next=0
for ((j = 0; j < ${#LIST[@]}; j++)); do
  IFS='|' read -r h os st det enr <"$WORK/check.$j"
  [[ "$st" == ready ]] || continue
  if [[ "$enr" == yes ]]; then : >"$WORK/go.$j"; continue; fi
  need=$((need + 1))
  if [[ "$TEST" != yes ]]; then
    if (( next < ${#TOK[@]} )); then printf '%s' "${TOK[$next]}" >"$WORK/go.$j"; next=$((next + 1))
    else printf '%s|%s|failed|not enrolled, and no token left for it (-t)|no\n' "$h" "$os" >"$WORK/check.$j"; fi
  fi
done
if [[ "$TEST" != yes ]] && ls "$WORK"/go.* >/dev/null 2>&1; then
  echo "Phase 2: installing on the servers that passed"
  run_parallel install_one
fi
printf 'host,os,result,detail\n' >"$OUT"
for ((j = 0; j < ${#LIST[@]}; j++)); do
  IFS='|' read -r h os res det enr <"$WORK/check.$j"
  [[ -f "$WORK/install_one.$j" ]] && IFS='|' read -r res det <"$WORK/install_one.$j"
  printf '%-32s %-14s %-10s %s\n' "$h" "${os:-?}" "$res" "$det"
  printf '"%s","%s","%s","%s"\n' "$h" "$os" "$res" "${det//\"/\'}" >>"$OUT"
done
[[ "$TEST" == yes ]] && echo && echo "Not enrolled yet: $need (make that many tokens: phase10-windows.sh --tokens $need <group>)"
echo
awk -F'","' 'NR>1 {gsub(/"/,"",$3); c[$3]++} END {for (k in c) printf "  %-10s %d\n", k, c[k]}' "$OUT" | sort
echo "Results: $OUT"
