#!/usr/bin/env bash
# ===========================================================================
# setup-agent.sh - install or upgrade the PATCH-01 agent on this Linux server.
#
#   sudo ./setup-agent.sh
#
# It works out what is needed and asks only for that:
#   1. checks this server (root, Python 3, systemd)
#   2. finds any existing agent: its version, whether it is enrolled, its settings
#   3. PATCH-01's address (the existing one is offered)
#   4. the CA chain (PEM) that verifies PATCH-01's certificate, tested right
#      away; the server's own trust store is used if it already trusts PATCH-01
#   5. a new server: asks for an enrolment token and enrols
#      an existing one: upgrades in place and keeps its identity (no token)
#   6. proves it works: version, timer, a check-in to PATCH-01
#
# Without questions (for scripts):  --server URL --ca FILE [--token TOKEN] --yes
# Keep install-agent.sh and patch-agent.py beside this script.
# ===========================================================================
set -Eeuo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN=/usr/local/bin/patch-agent
CONF_DIR=/etc/patch-agent
CONF="$CONF_DIR/agent.conf"
DEFAULT_SERVER=""
SYSTEM_BUNDLES=(/etc/pki/tls/certs/ca-bundle.crt /etc/ssl/certs/ca-certificates.crt /etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem)
SERVER=""; CA=""; TOKEN=""; YES=no

while [[ $# -gt 0 ]]; do
  case "$1" in
    --server) SERVER="${2%/}"; shift ;; --ca) CA="$2"; shift ;; --token) TOKEN="$2"; shift ;;
    --yes|-y) YES=yes ;; -h|--help) sed -n '4,20p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Unknown option $1 (see --help)" >&2; exit 1 ;;
  esac; shift
done

B=$'\033[1m'; G=$'\033[32m'; R=$'\033[31m'; Y=$'\033[33m'; N=$'\033[0m'
[[ -t 1 ]] || { B=""; G=""; R=""; Y=""; N=""; }
step() { printf '\n%s[%s] %s%s\n' "$B" "$1" "$2" "$N"; }
ok()   { printf '  %sok%s    %s\n' "$G" "$N" "$*"; }
warn() { printf '  %swarn%s  %s\n' "$Y" "$N" "$*"; }
die()  { printf '\n  %sSTOP%s  %s\n\n' "$R" "$N" "$*" >&2; exit 1; }
ask()  {  # ask VAR "question" default
  local __v="$1" q="$2" d="${3:-}" a=""
  if [[ "$YES" == yes ]]; then printf -v "$__v" '%s' "$d"; return; fi
  read -r -p "  $q${d:+ [$d]}: " a || true
  printf -v "$__v" '%s' "${a:-$d}"
}
conf_val() { [[ -f "$CONF" ]] && sed -n "s/^$1=//p" "$CONF" | tail -1 | tr -d "\"'" || true; }
# Verify exactly as the agent will: the same Python, with the same rules. curl
# is not used here: it accepts an intermediate CA as an anchor, the agent's
# Python does not, so curl could pass a CA file the agent then rejects.
health() {   # health <server> [cafile] -> 200, or "verify:<reason>" / "error:<reason>"
  "$PY" - "$1" "${2:-}" 2>/dev/null <<'PYV' || echo "error:python failed"
import ssl, sys
import urllib.request as ur
url, ca = sys.argv[1], (sys.argv[2] or None)
ctx = ssl.create_default_context(cafile=ca) if ca else ssl.create_default_context()
ctx.verify_flags &= ~getattr(ssl, "VERIFY_X509_PARTIAL_CHAIN", 0)   # an intermediate is not a root
op = ur.build_opener(ur.ProxyHandler({}), ur.HTTPSHandler(context=ctx))
verr = getattr(ssl, "SSLCertVerificationError", ssl.SSLError)
try:
    print(op.open(url + "/api/v1/health", timeout=10).getcode())
except verr as e:
    print("verify:" + str(getattr(e, "verify_message", "") or e)[:150])
except Exception as e:
    r = getattr(e, "reason", e)
    if isinstance(r, verr):
        print("verify:" + str(getattr(r, "verify_message", "") or r)[:150])
    else:
        code = getattr(e, "code", None)
        print(str(code) if code else "error:" + str(r)[:150])
PYV
}
answers() {  # does PATCH-01 answer at all, certificate aside?
  local c; c="$(curl -sk --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 10 "$1/api/v1/health" 2>/dev/null || true)"
  [[ "${c:-000}" == 200 ]]
}

# ---------------------------------------------------------------------------
step 1/6 "This server"
[[ $EUID -eq 0 ]] || die "Run it as root: sudo $0"
[[ -f "$HERE/install-agent.sh" && -f "$HERE/patch-agent.py" ]] \
  || die "install-agent.sh and patch-agent.py must be in the same folder as this script."
OS="$( . /etc/os-release 2>/dev/null && echo "$PRETTY_NAME" || uname -sr)"
ok "$OS"
PY=""
for c in /usr/bin/python3 /usr/libexec/platform-python /usr/bin/python3.6; do [[ -x "$c" ]] && { PY="$c"; break; }; done
[[ -n "$PY" ]] || die "No Python 3. Install it first (RHEL/OL: dnf install -y python3; OL7: yum install -y python3)."
ok "Python: $PY ($("$PY" -c 'import sys; print("%d.%d" % sys.version_info[:2])'))"
command -v systemctl >/dev/null || die "systemd is needed: the agent runs from a systemd timer."
command -v curl >/dev/null || die "curl is needed."
NEW_VER="$(sed -n 's/^AGENT_VERSION = "\(.*\)"$/\1/p' "$HERE/patch-agent.py" | head -1)"
ok "Agent in this folder: ${NEW_VER:-unknown}"

# ---------------------------------------------------------------------------
step 2/6 "Existing agent"
HAVE=no; ENROLLED=no; OLD_VER=""
if [[ -f "$BIN" ]]; then
  HAVE=yes
  OLD_VER="$(sed -n 's/^AGENT_VERSION = "\(.*\)"$/\1/p' "$BIN" | head -1)"
  [[ -s "$CONF_DIR/token" ]] && ENROLLED=yes
  ok "Installed: version ${OLD_VER:-unknown}, $( [[ $ENROLLED == yes ]] && echo enrolled || echo 'not enrolled')"
  ok "Talks to: $(conf_val server) (TLS check: $(conf_val verify_tls)$( [[ -n "$(conf_val ca_file)" ]] && echo ", CA $(conf_val ca_file)"))"
  [[ "$OLD_VER" == "$NEW_VER" ]] && ok "Already this version: settings will be refreshed" || ok "Will upgrade ${OLD_VER:-?} -> $NEW_VER, keeping its identity"
else
  ok "None: this will be a new install"
fi

# ---------------------------------------------------------------------------
step 3/6 "PATCH-01"
D="${SERVER:-$(conf_val server)}"; D="${D:-$DEFAULT_SERVER}"
[[ -n "$SERVER" ]] || ask SERVER "PATCH-01 address" "$D"
SERVER="${SERVER%/}"
[[ -n "$SERVER" ]] || die "Give PATCH-01's address, e.g. https://<patch01 name> (or --server)."
[[ "$SERVER" =~ ^https://[A-Za-z0-9.-]+(:[0-9]+)?$ ]] || die "'$SERVER' is not an https:// address."
HOSTNAME_="$(sed -E 's#^https://##; s#[:/].*$##' <<<"$SERVER")"
PORT_="$(sed -nE 's#^https://[^:/]+:([0-9]+).*#\1#p' <<<"$SERVER")"; PORT_="${PORT_:-443}"
IP="$(getent ahostsv4 "$HOSTNAME_" 2>/dev/null | awk '{print $1; exit}' || true)"
[[ -n "$IP" ]] || die "$HOSTNAME_ does not resolve on this server. Fix DNS (or /etc/hosts) first."
ok "$HOSTNAME_ is $IP"
if timeout 6 bash -c "exec 3<>/dev/tcp/$IP/$PORT_" 2>/dev/null; then ok "Port $PORT_ reachable"
else die "Cannot connect to $IP:$PORT_. Ask for the firewall rule from this server to PATCH-01 on $PORT_."; fi
answers "$SERVER" || die "Something listens on $IP:$PORT_ but it is not PATCH-01 answering at $SERVER/api/v1/health."
ok "PATCH-01 answers at $SERVER"

# ---------------------------------------------------------------------------
step 4/6 "Trusting PATCH-01's certificate"
CA_USE=""
pick_ca() {   # pick_ca <file> : set CA_USE if this file verifies PATCH-01
  local f="$1" code
  [[ -f "$f" ]] || { warn "No file $f"; return 1; }
  openssl x509 -in "$f" -noout 2>/dev/null || { warn "$f is not a PEM certificate file"; return 1; }
  code="$(health "$SERVER" "$f")"
  if [[ "$code" == 200 ]]; then CA_USE="$f"; return 0; fi
  warn "$f does not verify PATCH-01's certificate (${code#verify:})."
  warn "It needs the ROOT CA that PATCH-01's certificate chains to: root and intermediate together in"
  warn "one file is safest. An intermediate alone is not enough for the agent."
  return 1
}
if [[ -n "$CA" ]]; then
  pick_ca "$CA" || die "The CA file given does not verify PATCH-01."
else
  # 1. the CA this agent already uses; 2. the system trust store; 3. ask
  cur="$(conf_val ca_file)"
  if [[ -n "$cur" && -f "$cur" ]] && [[ "$(health "$SERVER" "$cur")" == 200 ]]; then
    CA_USE="$cur"; ok "The CA this agent already uses still verifies PATCH-01"
  else
    for bfile in "${SYSTEM_BUNDLES[@]}"; do
      if [[ -f "$bfile" && "$(health "$SERVER" "$bfile")" == 200 ]]; then
        CA_USE="$bfile"; ok "This server already trusts PATCH-01 (system trust store $bfile)"; break
      fi
    done
  fi
  tries=0
  while [[ -z "$CA_USE" ]]; do
    [[ "$YES" == yes ]] && die "Nothing on this server verifies PATCH-01: give --ca with your CA chain (PEM)."
    ask CA "Path to the CA chain file (PEM: root, or root + intermediate)" ""
    [[ -n "$CA" ]] || die "A CA file is needed to verify PATCH-01."
    pick_ca "$CA" && break
    tries=$((tries + 1)); (( tries < 3 )) || die "Three files tried; none verifies PATCH-01."
    CA=""
  done
fi
ok "Verified the way the agent verifies: PATCH-01's certificate checks out with $CA_USE"
SUBJ="$(echo | timeout 10 openssl s_client -connect "$IP:443" -servername "$HOSTNAME_" 2>/dev/null \
        | openssl x509 -noout -subject -enddate 2>/dev/null | tr '\n' ' ' | sed 's/subject=//; s/notAfter=/, valid until /' || true)"
[[ -n "$SUBJ" ]] && ok "PATCH-01 presents: $SUBJ"

# ---------------------------------------------------------------------------
step 5/6 "$( [[ $ENROLLED == yes ]] && echo 'Upgrading the agent (identity kept, no token needed)' || echo 'Installing and enrolling' )"
ARGS=(--server "$SERVER" --ca "$CA_USE")
if [[ "$ENROLLED" != yes ]]; then
  [[ -n "$TOKEN" ]] || ask TOKEN "Enrolment token (from PATCH-01: phase10-windows.sh --tokens 1 <group>)" ""
  [[ -n "$TOKEN" ]] || die "A new server needs an enrolment token."
  ARGS+=(--token "$TOKEN")
fi
if [[ "$YES" != yes ]]; then
  a=""; read -r -p "  Go ahead? [Y/n]: " a || true
  [[ -z "$a" || "$a" =~ ^[Yy] ]] || die "Stopped; nothing was changed."
fi
LOG="/var/log/patch-agent-setup.log"
if bash "$HERE/install-agent.sh" "${ARGS[@]}" >"$LOG" 2>&1; then
  ok "Installer finished (details in $LOG)"
else
  tail -15 "$LOG" | sed 's/^/        /'
  die "The installer stopped (above; full log $LOG)."
fi

# ---------------------------------------------------------------------------
step 6/6 "Proving it works"
NOW_VER="$(sed -n 's/^AGENT_VERSION = "\(.*\)"$/\1/p' "$BIN" | head -1)"
[[ "$NOW_VER" == "$NEW_VER" ]] && ok "Agent version $NOW_VER" || die "Installed version is $NOW_VER, expected $NEW_VER."
[[ -s "$CONF_DIR/token" ]] && ok "Enrolled with PATCH-01" || die "Not enrolled: the enrolment did not complete (see $LOG)."
[[ "$(sed -n 's/^verify_tls=//p' "$CONF")" == true ]] && ok "Verifies PATCH-01's certificate" || warn "TLS verification is off"
systemctl is-active --quiet patch-agent.timer && ok "Timer active: checks in every 5 minutes" \
  || warn "patch-agent.timer is not active: systemctl enable --now patch-agent.timer"
if env -u HTTP_PROXY -u HTTPS_PROXY -u http_proxy -u https_proxy "$BIN" checkin >>"$LOG" 2>&1; then
  ok "Checked in with PATCH-01 just now"
else
  tail -5 "$LOG" | sed 's/^/        /'; die "The check-in failed (above)."
fi
printf '\n  %sDone.%s This server is on agent %s and appears on PATCH-01'"'"'s Agents page.\n\n' "$G" "$N" "$NOW_VER"
