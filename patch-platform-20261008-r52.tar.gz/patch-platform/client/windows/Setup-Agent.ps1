<#
.SYNOPSIS
  Install or upgrade the PATCH-01 agent on this Windows server.

.DESCRIPTION
  Run in PowerShell as administrator, from the folder holding this script,
  install-agent.ps1 and patch-agent.ps1:

      powershell -ExecutionPolicy Bypass -File .\Setup-Agent.ps1

  It works out what is needed and asks only for that:
    1. checks this server; sets the execution policy to RemoteSigned for the
       current user and unblocks the downloaded scripts
    2. finds any existing agent: its version, whether it is enrolled, its settings
    3. PATCH-01's address (the existing one is offered), DNS and port 443
    4. how to trust PATCH-01's certificate:
         - Windows already trusts it          -> pin "system" (renewals need nothing)
         - the agent's current pin still fits -> kept
         - otherwise asks for your CA chain (PEM), checks PATCH-01's
           certificate chains to the root in it, and pins that certificate
    5. a new server: self-test, asks for an enrolment token, installs
       an existing one: upgrades in place, keeps its identity (no token)
    6. proves it works: version, scheduled task, a check-in to PATCH-01

  Without questions: -Server URL -CaFile FILE [-Token TOKEN] -Yes
#>
param(
    [string]$Server,
    [string]$CaFile,
    [string]$Token,
    [switch]$Yes
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDir = Join-Path $env:ProgramFiles "PatchAgent"
$DataDir = Join-Path $env:ProgramData "PatchAgent"
$TaskName = "PATCH-01 agent"
$DefaultServer = ""

function Step([string]$N, [string]$T) { Write-Host ""; Write-Host ("[" + $N + "] " + $T) -ForegroundColor White }
function Ok([string]$T) { Write-Host ("  ok    " + $T) -ForegroundColor Green }
function Warn([string]$T) { Write-Host ("  warn  " + $T) -ForegroundColor Yellow }
function Stop-Setup([string]$T) { Write-Host ""; Write-Host ("  STOP  " + $T) -ForegroundColor Red; Write-Host ""; exit 1 }
function Ask([string]$Q, [string]$Default) {
    if ($Yes) { return $Default }
    $p = "  " + $Q
    if ($Default) { $p += " [" + $Default + "]" }
    $a = Read-Host $p
    if ([string]::IsNullOrWhiteSpace($a)) { return $Default }
    return $a.Trim()
}
function Get-VersionIn([string]$Path) {
    if (-not (Test-Path $Path)) { return $null }
    $m = Select-String -Path $Path -Pattern '^\$AgentVersion\s*=\s*"([^"]+)"' | Select-Object -First 1
    if ($m) { return $m.Matches[0].Groups[1].Value }
    return $null
}

# A TLS handshake with PATCH-01 that accepts any certificate, so it can be
# looked at: the certificate, and what Windows itself thinks of it
function Get-ServerCertificate([string]$HostName, [int]$Port) {
    $tcp = New-Object Net.Sockets.TcpClient
    try {
        $iar = $tcp.BeginConnect($HostName, $Port, $null, $null)
        if (-not $iar.AsyncWaitHandle.WaitOne(8000)) { throw ("no answer from " + $HostName + ":" + $Port + " within 8 seconds") }
        $tcp.EndConnect($iar)
        $script:SeenErrors = $null
        $cb = [Net.Security.RemoteCertificateValidationCallback] { param($s, $c, $ch, $e) $script:SeenErrors = $e; return $true }
        $ssl = New-Object Net.Security.SslStream($tcp.GetStream(), $false, $cb)
        try {
            $ssl.AuthenticateAsClient($HostName, $null, [Security.Authentication.SslProtocols]::Tls12, $false)
            $cert = New-Object Security.Cryptography.X509Certificates.X509Certificate2($ssl.RemoteCertificate)
            return [pscustomobject]@{ Cert = $cert; Errors = [string]$script:SeenErrors }
        } finally { $ssl.Dispose() }
    } finally { $tcp.Close() }
}

function Get-Pin($Cert) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return (([BitConverter]::ToString($sha.ComputeHash($Cert.RawData))) -replace "-", "").ToLowerInvariant() }
    finally { $sha.Dispose() }
}

function Read-CaFile([string]$Path) {
    $text = [IO.File]::ReadAllText($Path)
    $found = [regex]::Matches($text, '-----BEGIN CERTIFICATE-----([A-Za-z0-9+/=\s]+?)-----END CERTIFICATE-----')
    $out = @()
    foreach ($m in $found) {
        $bytes = [Convert]::FromBase64String(($m.Groups[1].Value -replace '\s', ''))
        $out += New-Object Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList (, $bytes)
    }
    if ($out.Count -eq 0) {
        # Not PEM: perhaps a single binary (DER) .cer
        $out += New-Object Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList $Path
    }
    return , $out
}

# Does PATCH-01's certificate chain to a root in the CA file? Returns a reason, or "" when it does
function Test-ChainTo($Leaf, $CaCerts) {
    $chain = New-Object Security.Cryptography.X509Certificates.X509Chain
    $chain.ChainPolicy.RevocationMode = [Security.Cryptography.X509Certificates.X509RevocationMode]::NoCheck
    $chain.ChainPolicy.VerificationFlags = [Security.Cryptography.X509Certificates.X509VerificationFlags]::AllowUnknownCertificateAuthority
    foreach ($c in $CaCerts) { [void]$chain.ChainPolicy.ExtraStore.Add($c) }
    [void]$chain.Build($Leaf)
    $top = $chain.ChainElements[$chain.ChainElements.Count - 1].Certificate
    if ($top.Subject -ne $top.Issuer) {
        return ("the chain stops at '" + $top.Subject + "': the file has no root CA above it (an intermediate alone is not enough)")
    }
    $inFile = @($CaCerts | Where-Object { $_.Thumbprint -eq $top.Thumbprint }).Count -gt 0
    $inStore = @(Get-ChildItem Cert:\LocalMachine\Root | Where-Object { $_.Thumbprint -eq $top.Thumbprint }).Count -gt 0
    if (-not ($inFile -or $inStore)) { return ("its root '" + $top.Subject + "' is not in the file") }
    foreach ($st in $chain.ChainStatus) {
        $n = [string]$st.Status
        if ($n -ne "UntrustedRoot" -and $n -ne "NoError" -and $n -ne "RevocationStatusUnknown" -and $n -ne "OfflineRevocation") {
            return ("the chain is not valid: " + $n + " (" + $st.StatusInformation.Trim() + ")")
        }
    }
    return ""
}

# ---------------------------------------------------------------------------
Step "1/6" "This server"
$me = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { Stop-Setup "Run PowerShell as administrator." }
if ($PSVersionTable.PSVersion.Major -lt 5) { Stop-Setup ("PowerShell 5.1 is needed (found " + $PSVersionTable.PSVersion + ").") }
$os = Get-CimInstance Win32_OperatingSystem
Ok ($os.Caption + " (build " + $os.BuildNumber + ")")
foreach ($f in @("install-agent.ps1", "patch-agent.ps1")) {
    if (-not (Test-Path (Join-Path $Here $f))) { Stop-Setup ($f + " must be in the same folder as this script.") }
}
# Started with -ExecutionPolicy Bypass, setting the user's policy reports that
# the session's own policy overrides it: harmless, so judge by the result
try { Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser -Force -ErrorAction SilentlyContinue } catch { }
if ((Get-ExecutionPolicy -Scope CurrentUser) -eq "RemoteSigned") { Ok "Execution policy: RemoteSigned for the current user" }
else { Warn ("Execution policy for the current user is " + (Get-ExecutionPolicy -Scope CurrentUser) + " (Group Policy may set it). The agent's task does not depend on it.") }
Get-ChildItem -Path $Here -Filter *.ps1 | Unblock-File -ErrorAction SilentlyContinue
Ok "Scripts in this folder unblocked"
$NewVer = Get-VersionIn (Join-Path $Here "patch-agent.ps1")
Ok ("Agent in this folder: " + $NewVer)

# ---------------------------------------------------------------------------
Step "2/6" "Existing agent"
$CfgFile = Join-Path $DataDir "agent.json"
$Enrolled = (Test-Path $CfgFile) -and (Test-Path (Join-Path $DataDir "token.bin"))
$OldVer = Get-VersionIn (Join-Path $InstallDir "patch-agent.ps1")
$OldCfg = $null
if ($Enrolled) {
    $OldCfg = Get-Content -Raw $CfgFile | ConvertFrom-Json
    Ok ("Installed: version " + $OldVer + ", enrolled")
    Ok ("Talks to: " + $OldCfg.server)
    if ($OldVer -eq $NewVer) { Ok "Already this version: its settings will be refreshed" }
    else { Ok ("Will upgrade " + $OldVer + " -> " + $NewVer + ", keeping its identity") }
} elseif ($OldVer) {
    Warn ("Agent files (version " + $OldVer + ") are here, but it never enrolled: it will be installed afresh")
} else {
    Ok "None: this will be a new install"
}

# ---------------------------------------------------------------------------
Step "3/6" "PATCH-01"
$def = $DefaultServer
if ($OldCfg -and $OldCfg.server) { $def = [string]$OldCfg.server }
if (-not $Server) { $Server = Ask "PATCH-01 address" $def }
if (-not $Server) { Stop-Setup "Give PATCH-01's address, e.g. https://<patch01 name> (or -Server)." }
$Server = $Server.TrimEnd("/")
if (-not ($Server -match '^https://([A-Za-z0-9.-]+)(:(\d+))?$')) { Stop-Setup ("'" + $Server + "' is not an https:// address.") }
$HostName = $Matches[1]
$Port = 443
if ($Matches[3]) { $Port = [int]$Matches[3] }
try { $ips = @([Net.Dns]::GetHostAddresses($HostName) | Where-Object { $_.AddressFamily -eq "InterNetwork" }) } catch { $ips = @() }
if ($ips.Count -eq 0) { Stop-Setup ($HostName + " does not resolve on this server. Fix DNS first.") }
Ok ($HostName + " is " + $ips[0].IPAddressToString)
try { $seen = Get-ServerCertificate $HostName $Port }
catch { Stop-Setup ("Cannot reach " + $HostName + ":" + $Port + " (" + $_.Exception.Message + "). Ask for the firewall rule to PATCH-01 on " + $Port + ".") }
Ok ("Port " + $Port + " reachable; PATCH-01 presents '" + $seen.Cert.Subject + "', valid until " + $seen.Cert.NotAfter.ToString("dd MMM yyyy"))
if ($seen.Errors -match "RemoteCertificateNameMismatch") {
    Stop-Setup ("PATCH-01's certificate does not name '" + $HostName + "'. Use the name it was issued for, or ask for a certificate that names it.")
}
$ServerPin = Get-Pin $seen.Cert

# ---------------------------------------------------------------------------
Step "4/6" "Trusting PATCH-01's certificate"
$Pin = $null
if ($seen.Errors -eq "None") {
    $Pin = "system"
    Ok "Windows already trusts PATCH-01's certificate: pin 'system' (certificate renewals need nothing here)"
} elseif ($OldCfg -and $OldCfg.pin -and ([string]$OldCfg.pin).Split(",") -contains $ServerPin) {
    $Pin = $ServerPin
    Ok "The agent's current pin matches PATCH-01's certificate: kept (the old one is dropped)"
} else {
    $tries = 0
    while (-not $Pin) {
        if (-not $CaFile) {
            if ($Yes) { Stop-Setup "Windows does not trust PATCH-01's certificate: give -CaFile with your CA chain (PEM)." }
            $CaFile = Ask "Path to your CA chain file (PEM: root, or root + intermediate)" ""
            if (-not $CaFile) { Stop-Setup "A CA chain file is needed to trust PATCH-01." }
        }
        $CaFile = $CaFile.Trim('"')
        $why = ""
        if (-not (Test-Path $CaFile)) { $why = "no such file" }
        else {
            try { $why = Test-ChainTo $seen.Cert (Read-CaFile $CaFile) }
            catch { $why = ("the file could not be read as certificates (" + $_.Exception.Message + ")") }
        }
        if ($why -eq "") {
            $Pin = $ServerPin
            Ok ("PATCH-01's certificate chains to the root in " + (Split-Path -Leaf $CaFile) + ": pinned")
            Warn "When PATCH-01's certificate is renewed, run this script again. To avoid that, have your CA trusted by Windows (Group Policy)."
        } else {
            Warn ((Split-Path -Leaf $CaFile) + ": " + $why)
            $CaFile = $null
            $tries++
            if ($Yes -or $tries -ge 3) { Stop-Setup "No CA file given verifies PATCH-01's certificate." }
        }
    }
}

# ---------------------------------------------------------------------------
$install = Join-Path $Here "install-agent.ps1"
if ($Enrolled) {
    Step "5/6" "Upgrading the agent (identity kept, no token needed)"
    if (-not $Yes) { $a = Read-Host "  Go ahead? [Y/n]"; if ($a -and $a -notmatch '^[Yy]') { Stop-Setup "Stopped; nothing was changed." } }
    if ([string]$OldCfg.server -ne $Server) {
        # -Repin keeps the address it has; a new one is written first
        $OldCfg.server = $Server
        ConvertTo-Json -InputObject $OldCfg | Set-Content -Path $CfgFile -Encoding UTF8
        Ok ("Address changed to " + $Server)
    }
    try { & $install -Repin -Pin $Pin | ForEach-Object { Write-Host ("        " + $_) } }
    catch { Stop-Setup ("The upgrade stopped: " + $_.Exception.Message) }
} else {
    Step "5/6" "Installing and enrolling"
    Write-Host "  Self-test first (nothing installed yet; the Windows Update search can take a few minutes)..."
    $test = (& $install -Server $Server -Pin $Pin -SelfTest | Out-String)
    if ($test -notmatch "All steps passed") {
        Write-Host $test
        Stop-Setup "The self-test found a problem (above)."
    }
    Ok "Self-test passed"
    if (-not $Token) { $Token = Ask "Enrolment token (from PATCH-01: phase10-windows.sh --tokens 1 <group>)" "" }
    if (-not $Token) { Stop-Setup "A new server needs an enrolment token." }
    try { & $install -Server $Server -Pin $Pin -Token $Token | ForEach-Object { Write-Host ("        " + $_) } }
    catch { Stop-Setup ("The install stopped: " + $_.Exception.Message) }
}

# ---------------------------------------------------------------------------
Step "6/6" "Proving it works"
$NowVer = Get-VersionIn (Join-Path $InstallDir "patch-agent.ps1")
if ($NowVer -ne $NewVer) { Stop-Setup ("Installed version is " + $NowVer + ", expected " + $NewVer + ".") }
Ok ("Agent version " + $NowVer)
if (-not (Test-Path (Join-Path $DataDir "token.bin"))) { Stop-Setup "Not enrolled: the enrolment did not complete." }
Ok "Enrolled with PATCH-01"
$cfg = Get-Content -Raw (Join-Path $DataDir "agent.json") | ConvertFrom-Json
Ok ("Pin: " + $(if ($cfg.pin -eq "system") { "system (Windows' own trust)" } else { ([string]$cfg.pin).Substring(0, 16) + "..." }))
$task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($task) { Ok ("Scheduled task: " + $task.State + ", every 5 minutes as SYSTEM") } else { Stop-Setup "The scheduled task is missing." }
try {
    & (Join-Path $InstallDir "patch-agent.ps1") -Run
    $last = Get-Content (Join-Path $DataDir "agent.log") -Tail 1 -ErrorAction SilentlyContinue
    if ($last -match "still busy") { Ok "The scheduled run was already busy talking to PATCH-01; it carries on by itself" }
    else { Ok "Checked in with PATCH-01 just now" }
} catch {
    Stop-Setup ("The check-in failed: " + $_.Exception.Message + "  (log: " + (Join-Path $DataDir "agent.log") + ")")
}
Write-Host ""
Write-Host ("  Done. This server is on agent " + $NowVer + " and appears on PATCH-01's Agents page.") -ForegroundColor Green
Write-Host ""
