-- ===========================================================================
-- PATCH-01 : schema 010 - live VMware state, alarms, application groups
--
-- Applied after 009. Idempotent: safe to re-apply on every run.
--
-- Everything here comes from vCenter alone. Nothing is collected from inside
-- a VM: application groups come from vSphere tags and folders, health from
-- vCenter's own status and alarms, and changes from vCenter's update stream.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Health and alarms, as vCenter reports them
-- overall_status: green, yellow, red or gray, vCenter's own roll-up
-- alarms: [{name, status, time, acknowledged}] for alarms currently firing
-- ---------------------------------------------------------------------------
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS overall_status TEXT;
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS alarms JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE esxi_hosts   ADD COLUMN IF NOT EXISTS overall_status TEXT;
ALTER TABLE esxi_hosts   ADD COLUMN IF NOT EXISTS alarms JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE datastores   ADD COLUMN IF NOT EXISTS overall_status TEXT;
ALTER TABLE datastores   ADD COLUMN IF NOT EXISTS alarms JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE vm_clusters  ADD COLUMN IF NOT EXISTS overall_status TEXT;
ALTER TABLE vm_clusters  ADD COLUMN IF NOT EXISTS alarms JSONB NOT NULL DEFAULT '[]'::jsonb;

-- ---------------------------------------------------------------------------
-- Application grouping, from vCenter: a tag in an application category if
-- there is one, else the VM folder. app_group_source says which, or NULL.
-- ---------------------------------------------------------------------------
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS tags JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS app_group TEXT;
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS app_group_source TEXT;

-- ---------------------------------------------------------------------------
-- The live watcher's state, one row per vCenter
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vmware_live (
    vcenter         TEXT PRIMARY KEY REFERENCES vcenters(name) ON DELETE CASCADE,
    connected       BOOLEAN NOT NULL DEFAULT FALSE,
    connected_since TIMESTAMPTZ,
    last_update_at  TIMESTAMPTZ,
    last_event_at   TIMESTAMPTZ,
    last_event_key  BIGINT,
    error           TEXT,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- vCenter events worth seeing: vMotions, HA restarts, host failures,
-- power changes, maintenance mode, alarm changes
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vmware_events (
    id            BIGSERIAL PRIMARY KEY,
    vcenter       TEXT NOT NULL REFERENCES vcenters(name) ON DELETE CASCADE,
    event_key     BIGINT NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL,
    kind          TEXT NOT NULL,
    severity      TEXT NOT NULL DEFAULT 'info',     -- info, warning, critical
    object_type   TEXT,                             -- vm, host, datastore, cluster
    object_moref  TEXT,
    object_name   TEXT,
    user_name     TEXT,
    message       TEXT,
    UNIQUE (vcenter, event_key)
);
CREATE INDEX IF NOT EXISTS idx_vmware_events_at ON vmware_events (created_at DESC);

-- ---------------------------------------------------------------------------
-- The change feed: each state change the watcher applied, oldest first.
-- The console polls this by id to update the map without reloading it.
-- Kept for seven days by the worker.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vmware_changes (
    id           BIGSERIAL PRIMARY KEY,
    at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    vcenter      TEXT NOT NULL,
    object_type  TEXT NOT NULL,
    moref        TEXT NOT NULL,
    name         TEXT,
    field        TEXT NOT NULL,
    old_value    TEXT,
    new_value    TEXT
);
CREATE INDEX IF NOT EXISTS idx_vmware_changes_at ON vmware_changes (at DESC);

INSERT INTO schema_version (version, description)
VALUES (10, 'live VMware state: alarms, application groups, events, change feed')
ON CONFLICT (version) DO NOTHING;
