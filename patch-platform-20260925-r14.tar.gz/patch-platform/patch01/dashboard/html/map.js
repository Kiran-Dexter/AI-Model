/* PATCH-01 live VMware map.
 *
 * Hand-built SVG: the console's policy allows no external or inline script,
 * and the map must work with no internet. Everything comes from vCenter.
 *
 * Two layouts over the same objects:
 *   Infrastructure  clusters > ESXi hosts > VMs, networks left, datastores right
 *   Applications    application groups (vSphere tag, else folder) > VMs
 *
 * Click a host, datastore or port group to see its blast radius. Click a VM
 * to trace what it depends on. Polls for live changes every 5 seconds.
 */
(function () {
  "use strict";
  const NS = "http://www.w3.org/2000/svg";
  const POLL_MS = 5000;
  const COL = { red: "#ff2e4d", amber: "#ffb020", green: "#19ff8c", grey: "#5b6673", cyan: "#29d9ff" };

  function s(tag, attrs, ...kids) {
    const el = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === null || v === undefined || v === false) continue;
      if (k === "on") { for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn); continue; }
      el.setAttribute(k, v === true ? "" : String(v));
    }
    for (const c of kids.flat()) if (c !== null && c !== undefined) el.append(c.nodeType ? c : document.createTextNode(String(c)));
    return el;
  }
  function e(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === null || v === undefined || v === false) continue;
      if (k === "on") { for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn); continue; }
      if (k === "class") el.className = v; else el.setAttribute(k, v === true ? "" : String(v));
    }
    for (const c of kids.flat()) if (c !== null && c !== undefined) el.append(c.nodeType ? c : document.createTextNode(String(c)));
    return el;
  }
  const gb = mb => mb == null ? "" : (mb >= 1024 ? Math.round(mb / 1024) + " GB" : mb + " MB");
  const tb = mb => mb == null ? "" : (mb >= 1048576 ? (mb / 1048576).toFixed(1) + " TB" : Math.round(mb / 1024) + " GB");
  const lvl = g => (g && g.level) || "grey";
  const first = g => (g && g.reasons && g.reasons[0] && g.reasons[0].text) || "";
  function ago(ts) {
    if (!ts) return "never";
    const sec = Math.max(0, Math.round((Date.now() - new Date(ts).getTime()) / 1000));
    if (sec < 60) return sec + "s ago";
    if (sec < 3600) return Math.round(sec / 60) + " min ago";
    if (sec < 86400) return Math.round(sec / 3600) + " h ago";
    return Math.round(sec / 86400) + " d ago";
  }
  const short = n => { const x = String(n || ""); return x.length > 22 ? x.slice(0, 21) + "\u2026" : x; };
  const hostShort = n => String(n || "").split(".")[0];

  // ---- shapes -----------------------------------------------------------
  function hexPath(cx, cy, r) {
    const p = [];
    for (let i = 0; i < 6; i++) {
      const a = Math.PI / 180 * (60 * i - 30);
      p.push((cx + r * Math.cos(a)).toFixed(1) + "," + (cy + r * Math.sin(a)).toFixed(1));
    }
    return "M" + p.join("L") + "Z";
  }
  function cylinder(x, y, w, h) {
    const ry = 5;
    return "M" + x + "," + (y + ry) + " A" + (w / 2) + "," + ry + " 0 0,1 " + (x + w) + "," + (y + ry)
      + " L" + (x + w) + "," + (y + h - ry) + " A" + (w / 2) + "," + ry + " 0 0,1 " + x + "," + (y + h - ry) + " Z";
  }
  function curve(x1, y1, x2, y2) {
    const dx = Math.abs(x2 - x1) * 0.5;
    return "M" + x1 + "," + y1 + " C" + (x1 + (x2 > x1 ? dx : -dx)) + "," + y1 + " "
      + (x2 - (x2 > x1 ? dx : -dx)) + "," + y2 + " " + x2 + "," + y2;
  }

  // ---- layout -------------------------------------------------------------
  const L = { vmR: 6.5, vmGap: 19, vmCols: 5, hostR: 17, rail: 190, gap: 70, panelPad: 18, wrap: 1180 };

  function shelf(groups, startX, wrap) {
    let x = startX, y = 30, rowH = 0;
    const maxX = startX + wrap;
    for (const g of groups) {
      if (x > startX && x + g.w > maxX) { x = startX; y += rowH + 34; rowH = 0; }
      g.x = x; g.y = y;
      x += g.w + 34;
      rowH = Math.max(rowH, g.h);
    }
    return { w: Math.max(...groups.map(g => g.x + g.w), startX + 300) - startX, h: y + rowH + 30 };
  }

  function packPanels(groups, startX, aspect, railsW, railsH) {
    // Try every wrap width that changes the result, and keep the layout
    // whose overall shape is closest to the stage's. A handful of large
    // panels packs badly by formula; trying them all is cheap at this size.
    if (!groups.length) return { w: 300, h: 200 };
    const widest = Math.max(...groups.map(g => g.w));
    const total = groups.reduce((a, g) => a + g.w + 34, 0);
    const cands = new Set([widest, total]);
    let run = 0;
    for (const g of groups) { run += g.w + 34; cands.add(Math.max(widest, run)); }
    for (let w = widest; w < total; w += 80) cands.add(w);
    let best = null;
    for (const wrap of cands) {
      const box = shelf(groups, startX, wrap);
      const W = box.w + railsW, H = Math.max(box.h, railsH);
      const score = Math.abs(Math.log((W / H) / aspect)) + 0.02 * Math.log(Math.max(W, H * aspect) / 1000 + 1);
      if (!best || score < best.score) best = { wrap, score };
    }
    return shelf(groups, startX, best.wrap);
  }

  function layoutInfra(d) {
    const byCl = new Map();
    for (const hst of d.hosts) {
      const k = hst.vcenter + "|" + (hst.cluster || "\u0000standalone");
      if (!byCl.has(k)) byCl.set(k, []);
      byCl.get(k).push(hst);
    }
    const vmsByHost = new Map();
    const unplaced = [];
    for (const v of d.vms) {
      if (v.host_key) { if (!vmsByHost.has(v.host_key)) vmsByHost.set(v.host_key, []); vmsByHost.get(v.host_key).push(v); }
      else unplaced.push(v);
    }
    const clByKey = new Map(d.clusters.map(c => [c.vcenter + "|" + c.name, c]));
    const panels = [];
    const keys = [...byCl.keys()].sort((a, b) => (a.includes("\u0000") - b.includes("\u0000")) || a.localeCompare(b));
    for (const k of keys) {
      const hosts = byCl.get(k).sort((a, b) => String(a.name).localeCompare(b.name));
      const cols = hosts.map(hst => {
        const vms = (vmsByHost.get(hst.key) || []).sort((a, b) =>
          (ORDER[lvl(b.grade)] - ORDER[lvl(a.grade)]) || String(a.name).localeCompare(b.name));
        const rows = Math.max(1, Math.ceil(vms.length / L.vmCols));
        return { host: hst, vms, rows };
      });
      const colW = L.vmCols * L.vmGap + 16;
      const maxRows = Math.max(...cols.map(c => c.rows));
      const standalone = k.includes("\u0000");
      panels.push({
        key: k, standalone, cluster: standalone ? null : clByKey.get(k), vcenter: k.split("|")[0],
        title: standalone ? "Standalone hosts" : k.split("|")[1], cols,
        w: Math.max(210, L.panelPad * 2 + cols.length * colW), h: 58 + 56 + maxRows * L.vmGap + 18, colW,
      });
    }
    if (unplaced.length) {
      const rows = Math.ceil(unplaced.length / (L.vmCols * 2));
      panels.push({ key: "unplaced", title: "No host recorded", cols: [{ host: null, vms: unplaced, rows, wide: true }],
        w: L.panelPad * 2 + L.vmCols * 2 * L.vmGap + 16, h: 58 + 20 + rows * L.vmGap + 18, colW: L.vmCols * 2 * L.vmGap + 16 });
    }
    return panels;
  }

  function layoutApps(d) {
    const byApp = new Map();
    for (const v of d.vms) {
      const k = v.app_group || "\u0000Ungrouped";
      if (!byApp.has(k)) byApp.set(k, []);
      byApp.get(k).push(v);
    }
    const keys = [...byApp.keys()].sort((a, b) =>
      (a.startsWith("\u0000") - b.startsWith("\u0000")) || (byApp.get(b).length - byApp.get(a).length) || a.localeCompare(b));
    return keys.map(k => {
      const vms = byApp.get(k).sort((a, b) => (ORDER[lvl(b.grade)] - ORDER[lvl(a.grade)]) || String(a.name).localeCompare(b.name));
      const cols = Math.min(10, Math.max(4, Math.ceil(Math.sqrt(vms.length * 2))));
      const rows = Math.ceil(vms.length / cols);
      const src = vms[0] && vms[0].app_group_source;
      return { key: k, app: true, title: k.startsWith("\u0000") ? "Ungrouped" : k,
        subtitle: k.startsWith("\u0000") ? "no application tag or folder" : (src === "tag" ? "vSphere tag" : "folder"),
        cols: [{ host: null, vms, rows, perRow: cols }], w: Math.max(230, L.panelPad * 2 + cols * L.vmGap + 10),
        h: 62 + rows * L.vmGap + 16, colW: cols * L.vmGap + 10 };
    });
  }
  const ORDER = { grey: -1, green: 0, amber: 1, red: 2 };

  // ---- the component ------------------------------------------------------
  function mount(container, ctx) {
    const st = {
      data: null, mode: localStorage.getItem("patch01.map.mode") || "infra",
      sel: null, blast: null, pos: new Map(), view: null, since: 0, sinceEv: 0,
      feed: [], flash: new Set(), pollOk: true, lastPoll: null, q: "",
    };

    const svg = s("svg", { class: "nm-svg", role: "img", "aria-label": "Live VMware infrastructure map" });
    const tip = e("div", { class: "nm-tip", hidden: true });
    const side = e("aside", { class: "nm-side" });
    const liveDot = e("span", { class: "nm-live-dot" });
    const liveText = e("span", { class: "nm-live-text" }, "connecting");
    const chips = e("span", { class: "nm-chips" });
    const search = e("input", { type: "search", class: "nm-search", placeholder: "Find a VM, host, datastore\u2026",
                                "aria-label": "Find on the map" });
    const modeBtns = [["infra", "Infrastructure"], ["apps", "Applications"]].map(([k, label]) =>
      e("button", { type: "button", class: "nm-btn", "data-k": k, "aria-pressed": String(st.mode === k),
        on: { click: () => { st.mode = k; localStorage.setItem("patch01.map.mode", k); st.view = null;
          modeBtns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === k))); draw(); } } }, label));
    const zoomBtns = [["+", 0.8, "Zoom in"], ["\u2212", 1.25, "Zoom out"], ["\u2922", 0, "Fit to screen"]].map(([t, f, label]) =>
      e("button", { type: "button", class: "nm-btn nm-icon", title: label, "aria-label": label,
        on: { click: () => f ? zoom(f) : fit() } }, t));

    const head = e("div", { class: "nm-head" },
      e("div", { class: "nm-live" }, liveDot, e("strong", null, "LIVE"), liveText),
      chips,
      e("div", { class: "nm-tools" }, search, e("div", { class: "nm-seg" }, modeBtns), e("div", { class: "nm-seg" }, zoomBtns)));
    const stage = e("div", { class: "nm-stage" }, svg, tip);
    const root = e("div", { class: "nm" }, head, e("div", { class: "nm-body" }, stage, side), legend());
    container.replaceChildren(root);

    // ---- data ----
    async function load() {
      const d = await ctx.api("/admin/vmware/graph");
      st.data = d;
      st.since = Math.max(st.since, d.change_id || 0);
      if (!st.sinceEv) st.sinceEv = Math.max(0, (d.event_id || 0) - 30);
      index();
    }
    function index() {
      const d = st.data;
      st.by = new Map();
      for (const k of ["hosts", "vms", "datastores", "networks", "clusters"]) for (const x of d[k]) st.by.set(x.key, Object.assign(x, { _t: k }));
    }

    // ---- drawing ----
    function defs() {
      const glow = (id, sd) => s("filter", { id, x: "-80%", y: "-80%", width: "260%", height: "260%" },
        s("feGaussianBlur", { stdDeviation: sd, result: "b" }),
        s("feMerge", null, s("feMergeNode", { in: "b" }), s("feMergeNode", { in: "b" }), s("feMergeNode", { in: "SourceGraphic" })));
      return s("defs", null,
        glow("nm-glow", 3), glow("nm-glow-hot", 5.5),
        s("pattern", { id: "nm-grid", width: 28, height: 28, patternUnits: "userSpaceOnUse" },
          s("path", { d: "M28 0H0V28", fill: "none", stroke: "#0e1a26", "stroke-width": 1 })),
        s("radialGradient", { id: "nm-vignette", cx: "50%", cy: "45%", r: "75%" },
          s("stop", { offset: "0%", "stop-color": "#0a1320", "stop-opacity": 0 }),
          s("stop", { offset: "100%", "stop-color": "#000", "stop-opacity": 0.75 })));
    }

    function vmNode(v, x, y) {
      st.pos.set(v.key, [x, y]);
      const g = lvl(v.grade);
      const managed = !!v.host_id;
      const cls = "nm-node nm-vm nm-" + g + (st.flash.has(v.key) ? " nm-flash" : "");
      return s("g", { class: cls, "data-key": v.key, transform: "translate(" + x + "," + y + ")",
        on: { click: ev => { ev.stopPropagation(); select(v.key); }, mouseenter: ev => showTip(ev, v), mouseleave: hideTip } },
        s("circle", { class: "nm-halo", r: L.vmR + 5 }),
        s("circle", { class: "nm-core", r: L.vmR, filter: g === "red" ? "url(#nm-glow-hot)" : (g === "grey" ? null : "url(#nm-glow)") }),
        managed ? null : s("circle", { class: "nm-unmanaged", r: L.vmR + 2.8 }));
    }

    function draw() {
      if (!st.data) return;
      const d = st.data;
      st.pos = new Map();
      const layers = { back: s("g"), edges: s("g", { class: "nm-edges" }), nodes: s("g") };
      const panels = st.mode === "apps" ? layoutApps(d) : layoutInfra(d);
      const railL = 20, cx0 = railL + L.rail + L.gap;
      const r = svg.getBoundingClientRect();
      const railsH = Math.max(60 + d.networks.length * 34, 60 + d.datastores.length * 50);
      const box = packPanels(panels, cx0, r.width && r.height ? r.width / r.height : 1.5,
                             2 * (L.rail + L.gap) + 70, railsH);
      const railR = cx0 + box.w + L.gap;

      // networks, left rail
      const nets = d.networks.slice().sort((a, b) => (b.vm_count || 0) - (a.vm_count || 0) || String(a.name).localeCompare(b.name));
      const railTitle = (x, t, n) => s("text", { class: "nm-rail-title", x, y: 20 }, t + " \u00b7 " + n);
      layers.nodes.append(railTitle(railL, "NETWORKS", nets.length));
      nets.forEach((n, i) => {
        const y = 40 + i * 34, g = lvl(n.grade);
        st.pos.set(n.key, [railL + L.rail, y + 11]);
        layers.nodes.append(s("g", { class: "nm-node nm-net nm-" + g, "data-key": n.key,
          on: { click: ev => { ev.stopPropagation(); select(n.key); }, mouseenter: ev => showTip(ev, n), mouseleave: hideTip } },
          s("rect", { class: "nm-pill", x: railL, y, width: L.rail, height: 22, rx: 11 }),
          s("rect", { class: "nm-pill-bar", x: railL + 6, y: y + 6, width: 3, height: 10, rx: 1.5, filter: "url(#nm-glow)" }),
          s("text", { class: "nm-label", x: railL + 16, y: y + 15 }, short(n.name)),
          s("text", { class: "nm-count", x: railL + L.rail - 10, y: y + 15, "text-anchor": "end" },
            n.kind === "DistributedVirtualPortgroup" ? "VDS " + (n.vm_count || 0) : "STD " + (n.vm_count || 0))));
      });

      // datastores, right rail
      const dss = d.datastores.slice().sort((a, b) => (b.used_pct || 0) - (a.used_pct || 0));
      layers.nodes.append(railTitle(railR, "DATASTORES", dss.length));
      dss.forEach((x, i) => {
        const y = 36 + i * 50, g = lvl(x.grade), w = L.rail;
        st.pos.set(x.key, [railR, y + 20]);
        const used = Math.max(0, Math.min(100, x.used_pct || 0));
        layers.nodes.append(s("g", { class: "nm-node nm-ds nm-" + g, "data-key": x.key,
          on: { click: ev => { ev.stopPropagation(); select(x.key); }, mouseenter: ev => showTip(ev, x), mouseleave: hideTip } },
          s("path", { class: "nm-cyl", d: cylinder(railR, y, w, 40) }),
          s("rect", { class: "nm-ds-track", x: railR + 10, y: y + 27, width: w - 20, height: 5, rx: 2.5 }),
          s("rect", { class: "nm-ds-fill", x: railR + 10, y: y + 27, width: Math.max(2, (w - 20) * used / 100), height: 5, rx: 2.5,
                      filter: "url(#nm-glow)" }),
          s("text", { class: "nm-label", x: railR + 10, y: y + 20 }, short(x.name)),
          s("text", { class: "nm-count", x: railR + w - 10, y: y + 20, "text-anchor": "end" }, used + "%")));
      });

      // panels
      for (const p of panels) {
        const gr = p.cluster ? lvl(p.cluster.grade) : null;
        layers.back.append(s("g", { class: "nm-panel" + (gr ? " nm-" + gr : "") },
          s("rect", { class: "nm-panel-box", x: p.x, y: p.y, width: p.w, height: p.h, rx: 6 }),
          s("path", { class: "nm-bracket", d: "M" + p.x + "," + (p.y + 16) + "V" + p.y + "H" + (p.x + 16)
                      + "M" + (p.x + p.w - 16) + "," + (p.y + p.h) + "H" + (p.x + p.w) + "V" + (p.y + p.h - 16) }),
          s("text", { class: "nm-panel-title", x: p.x + L.panelPad, y: p.y + 24 }, String(p.title).toUpperCase()),
          s("text", { class: "nm-panel-sub", x: p.x + L.panelPad, y: p.y + 42 },
            p.app ? p.cols[0].vms.length + " VMs \u00b7 " + p.subtitle
              : p.cluster ? (p.cols.length + (p.cols.length === 1 ? " host" : " hosts") + " \u00b7 HA " + (p.cluster.ha_enabled ? "on" : "OFF")
                             + " \u00b7 DRS " + (p.cluster.drs_enabled ? "on" : "off") + " \u00b7 " + p.vcenter)
              : p.cols.length + (p.cols.length === 1 ? " host" : " hosts") + " \u00b7 no HA \u00b7 " + (p.vcenter || "")),
          gr ? s("circle", { class: "nm-panel-dot", cx: p.x + p.w - 20, cy: p.y + 20, r: 4.5, filter: "url(#nm-glow)" }) : null));
        p.cols.forEach((c, ci) => {
          const x0 = p.x + L.panelPad + ci * p.colW;
          let vy = p.y + 62;
          if (c.host) {
            const hx = x0 + (p.colW - 16) / 2, hy = p.y + 84, g = lvl(c.host.grade);
            st.pos.set(c.host.key, [hx, hy]);
            layers.nodes.append(s("g", { class: "nm-node nm-host nm-" + g, "data-key": c.host.key,
              on: { click: ev => { ev.stopPropagation(); select(c.host.key); }, mouseenter: ev => showTip(ev, c.host), mouseleave: hideTip } },
              s("path", { class: "nm-hex-halo", d: hexPath(hx, hy, L.hostR + 6) }),
              s("path", { class: "nm-hex", d: hexPath(hx, hy, L.hostR), filter: g === "red" ? "url(#nm-glow-hot)" : "url(#nm-glow)" }),
              s("text", { class: "nm-hex-n", x: hx, y: hy + 4, "text-anchor": "middle" }, c.vms.length),
              s("text", { class: "nm-host-label", x: hx, y: hy + L.hostR + 14, "text-anchor": "middle" }, short(hostShort(c.host.name)))));
            vy = p.y + 128;
          }
          const per = c.perRow || (c.wide ? L.vmCols * 2 : L.vmCols);
          c.vms.forEach((v, i) => {
            const vx = x0 + 10 + (i % per) * L.vmGap, yy = vy + Math.floor(i / per) * L.vmGap;
            layers.nodes.append(vmNode(v, vx, yy));
            if (c.host) layers.edges.append(s("path", { class: "nm-tether", d: "M" + vx + "," + (yy - L.vmR) + "L" + vx + "," + (yy - L.vmR - 3) }));
          });
        });
      }

      const W = railR + L.rail + 30, H = Math.max(box.h, 60 + nets.length * 34, 60 + dss.length * 50);
      st.bounds = { w: W, h: H };
      if (!st.view) st.view = { x: 0, y: 0, w: W, h: H };
      svg.replaceChildren(defs(),
        s("rect", { x: -5000, y: -5000, width: 10000 + W, height: 10000 + H, fill: "url(#nm-grid)" }),
        layers.back, layers.edges, layers.nodes,
        s("rect", { class: "nm-vignette", x: -5000, y: -5000, width: 10000 + W, height: 10000 + H, fill: "url(#nm-vignette)" }));
      st.nodesLayer = layers.nodes; st.edgesLayer = layers.edges;
      applyView();
      applySelection();
      renderChips();
      if (!st.sel) renderOverview();
      st.flash.clear();
    }

    // ---- view: pan and zoom ----
    function applyView() { const v = st.view; svg.setAttribute("viewBox", v.x + " " + v.y + " " + v.w + " " + v.h); }
    function zoom(f, cx, cy) {
      const v = st.view;
      cx = cx === undefined ? v.x + v.w / 2 : cx; cy = cy === undefined ? v.y + v.h / 2 : cy;
      const nw = Math.max(200, Math.min(v.w * f, st.bounds.w * 4));
      const nh = nw * v.h / v.w;
      st.view = { x: cx - (cx - v.x) * nw / v.w, y: cy - (cy - v.y) * nh / v.h, w: nw, h: nh };
      applyView();
    }
    function fit() { st.view = { x: 0, y: 0, w: st.bounds.w, h: st.bounds.h }; applyView(); }
    function toSvg(ev) {
      const r = svg.getBoundingClientRect(), v = st.view;
      const k = Math.max(v.w / r.width, v.h / r.height);
      const ox = (r.width * k - v.w) / 2, oy = (r.height * k - v.h) / 2;
      return [v.x - ox + (ev.clientX - r.left) * k, v.y - oy + (ev.clientY - r.top) * k, k];
    }
    svg.addEventListener("wheel", ev => { ev.preventDefault(); const [x, y] = toSvg(ev); zoom(ev.deltaY > 0 ? 1.12 : 0.89, x, y); }, { passive: false });
    let drag = null;
    svg.addEventListener("pointerdown", ev => { if (ev.target.closest(".nm-node")) return; drag = { x: ev.clientX, y: ev.clientY, v: Object.assign({}, st.view), moved: false }; svg.setPointerCapture(ev.pointerId); });
    svg.addEventListener("pointermove", ev => {
      if (!drag) return;
      const [, , k] = toSvg(ev);
      const dx = (ev.clientX - drag.x) * k, dy = (ev.clientY - drag.y) * k;
      if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
      st.view = Object.assign({}, drag.v, { x: drag.v.x - dx, y: drag.v.y - dy }); applyView();
    });
    svg.addEventListener("pointerup", () => { if (drag && !drag.moved) select(null); drag = null; });
    root.addEventListener("keydown", ev => { if (ev.key === "Escape") select(null); });
    root.tabIndex = -1;

    // ---- tooltips ----
    function showTip(ev, x) {
      const g = x.grade || {};
      tip.replaceChildren(...[
        e("div", { class: "nm-tip-name" }, x.name),
        e("div", { class: "nm-tip-kind" }, {
          vms: (x.guest_os || "VM") + (x.esxi_host ? " \u00b7 " + hostShort(x.esxi_host) : ""),
          hosts: "ESXi " + (x.esxi_version || "") + " \u00b7 " + (x.cpu_cores || "?") + " cores \u00b7 " + gb(x.memory_mb),
          datastores: (x.type || "") + " \u00b7 " + tb(x.capacity_mb) + (x.local ? " \u00b7 local" : ""),
          networks: x.kind === "DistributedVirtualPortgroup" ? "Distributed port group" : "Standard port group",
          clusters: "Cluster" }[x._t] || ""),
        ...(g.reasons || []).slice(0, 4).map(r => e("div", { class: "nm-tip-r nm-t-" + r.level }, r.text)),
        (g.reasons || []).length ? null : e("div", { class: "nm-tip-r nm-t-green" }, "healthy")].filter(Boolean));
      tip.hidden = false;
      const r = stage.getBoundingClientRect();
      tip.style.left = Math.min(r.width - 250, ev.clientX - r.left + 14) + "px";
      tip.style.top = Math.max(4, ev.clientY - r.top - 10) + "px";
    }
    function hideTip() { tip.hidden = true; }

    // ---- selection and blast radius ----
    async function select(key) {
      st.sel = key; st.blast = null;
      if (!key) { applySelection(); renderOverview(); return; }
      const x = st.by.get(key);
      if (!x) return;
      const kind = { hosts: "host", datastores: "datastore", networks: "network" }[x._t];
      if (kind) {
        side.replaceChildren(e("p", { class: "nm-muted" }, "Working out the blast radius\u2026"));
        applySelection();
        try {
          st.blast = await ctx.api("/admin/vmware/blast?kind=" + kind + "&key=" + encodeURIComponent(key));
        } catch (err) {
          side.replaceChildren(e("p", { class: "nm-t-red" }, err.message)); return;
        }
        if (st.sel !== key) return;
        applySelection(); renderBlast(x);
      } else { applySelection(); renderVm(x); }
    }

    function applySelection() {
      const layer = st.nodesLayer;
      if (!layer) return;
      st.edgesLayer.querySelectorAll(".nm-link").forEach(n => n.remove());
      layer.querySelectorAll(".nm-node").forEach(n => n.classList.remove("nm-dim", "nm-sel", "nm-hit-down",
        "nm-hit-restarts", "nm-hit-isolated", "nm-hit-degraded", "nm-hit-offline", "nm-hit-link", "nm-match"));
      root.classList.toggle("nm-focused", !!st.sel);
      if (st.q) layer.querySelectorAll(".nm-node").forEach(n => {
        const x = st.by.get(n.dataset.key);
        if (x && String(x.name).toLowerCase().includes(st.q)) n.classList.add("nm-match");
      });
      if (!st.sel) return;
      const node = k => layer.querySelector('.nm-node[data-key="' + CSS.escape(k) + '"]');
      const link = (a, b, cls) => {
        const p = st.pos.get(a), q = st.pos.get(b);
        if (!p || !q) return;
        st.edgesLayer.append(s("path", { class: "nm-link " + cls, d: curve(p[0], p[1], q[0], q[1]),
          filter: "url(#nm-glow)" }));
      };
      layer.querySelectorAll(".nm-node").forEach(n => n.classList.add("nm-dim"));
      const me = node(st.sel);
      if (me) me.classList.remove("nm-dim"), me.classList.add("nm-sel");
      const x = st.by.get(st.sel);
      if (st.blast) {
        for (const r of st.blast.vms) {
          const n = node(r.key);
          if (n) { n.classList.remove("nm-dim"); n.classList.add("nm-hit-" + r.outcome); }
          link(st.sel, r.key, "nm-link-" + r.outcome);
        }
      } else if (x && x._t === "vms") {
        const deps = [x.host_key, ...(x.ds_keys || []), ...(x.net_keys || [])].filter(Boolean);
        for (const k of deps) { const n = node(k); if (n) { n.classList.remove("nm-dim"); n.classList.add("nm-hit-link"); } link(st.sel, k, "nm-link-dep"); }
      }
    }

    // ---- side panel ----
    const fill = (...kids) => side.replaceChildren(...kids.flat().filter(k => k !== null && k !== undefined && k !== false));
    function badge(level, text) { return e("span", { class: "nm-badge nm-b-" + level }, text); }
    function kv(rows) {
      return e("dl", { class: "nm-kv" }, rows.filter(r => r && r[1] !== null && r[1] !== undefined && r[1] !== "")
        .map(([k, v]) => [e("dt", null, k), e("dd", null, v)]).flat());
    }
    function reasons(g) {
      const rs = (g && g.reasons) || [];
      return rs.length ? e("ul", { class: "nm-reasons" }, rs.map(r => e("li", { class: "nm-t-" + r.level }, r.text)))
        : e("p", { class: "nm-t-green" }, "Healthy. Nothing to act on.");
    }
    function stat(n, label, level) {
      return e("div", { class: "nm-stat nm-s-" + level }, e("div", { class: "nm-stat-n" }, n), e("div", { class: "nm-stat-l" }, label));
    }

    function renderOverview() {
      const d = st.data;
      const count = (arr, l) => arr.filter(x => lvl(x.grade) === l).length;
      const worst = d.vms.concat(d.hosts, d.datastores).filter(x => lvl(x.grade) === "red")
        .concat(d.vms.concat(d.hosts, d.datastores).filter(x => lvl(x.grade) === "amber")).slice(0, 12);
      fill(
        e("h3", { class: "nm-side-h" }, "Estate"),
        e("div", { class: "nm-stats" },
          stat(count(d.vms, "red") + count(d.hosts, "red") + count(d.datastores, "red"), "critical", "red"),
          stat(count(d.vms, "amber") + count(d.hosts, "amber") + count(d.datastores, "amber"), "warning", "amber"),
          stat(count(d.vms, "green"), "VMs healthy", "green"),
          stat(count(d.vms, "grey"), "VMs off", "grey")),
        e("p", { class: "nm-muted" }, d.hosts.length + " ESXi hosts, " + d.vms.length + " VMs, " + d.datastores.length
          + " datastores. Click a host, datastore or network to see what it would take down; click a VM to trace what it depends on."),
        worst.length ? e("h3", { class: "nm-side-h" }, "Needs attention") : null,
        worst.length ? e("ul", { class: "nm-list" }, worst.map(x => e("li", { on: { click: () => select(x.key) } },
          badge(lvl(x.grade), lvl(x.grade) === "red" ? "CRIT" : "WARN"), e("span", { class: "nm-list-n" }, x.name),
          e("span", { class: "nm-muted" }, first(x.grade))))) : e("p", { class: "nm-t-green" }, "Nothing red or amber."),
        feedBlock());
    }

    function renderVm(v) {
      fill(
        e("div", { class: "nm-side-top" }, badge(lvl(v.grade), lvl(v.grade).toUpperCase()), e("span", { class: "nm-muted" }, "Virtual machine")),
        e("h3", { class: "nm-side-title" }, v.name),
        reasons(v.grade),
        kv([["Guest OS", v.guest_os], ["Power", v.power_state], ["Size", (v.num_cpu || "?") + " vCPU, " + gb(v.memory_mb)],
            ["ESXi host", v.esxi_host], ["Cluster", v.cluster], ["Application", v.app_group ? v.app_group + " (" + v.app_group_source + ")" : "not grouped"],
            ["Datastores", (v.ds_keys || []).map(k => (st.by.get(k) || {}).name).join(", ")],
            ["Networks", (v.net_keys || []).map(k => (st.by.get(k) || {}).name).join(", ")],
            ["VMware Tools", v.tools_running], ["Snapshots", v.snapshot_count],
            ["Patch agent", v.host_id ? (v.server + (v.agent_state ? ", " + v.agent_state : "")) : (v.is_linux ? "no agent" : "not managed")],
            ["To patch", v.host_id ? (v.needs_patch || 0) + " advisories" + (v.kev_advisories ? ", " + v.kev_advisories + " exploited" : "") : null]]),
        v.host_id ? e("a", { class: "nm-cta", href: "#/host/" + v.host_id }, "Open server page \u2192") : null,
        e("p", { class: "nm-muted nm-small" }, "Lines show what this VM depends on: its host, datastores and networks."));
    }

    function renderBlast(x) {
      const b = st.blast, sm = b.summary;
      const what = { host: "If this ESXi host fails", datastore: "If this datastore fails", network: "If this port group fails" }[b.type];
      const statsRow = b.type === "network"
        ? [stat(sm.isolated || 0, "isolated", "red"), stat(sm.degraded || 0, "degraded", "amber"), stat(sm.offline || 0, "already off", "grey")]
        : [stat(sm.down || 0, "go down", "red"), stat(sm.restarts || 0, "HA restarts", "amber"), stat(sm.offline || 0, "already off", "grey")];
      const order = { down: 0, isolated: 0, restarts: 1, degraded: 1, offline: 2 };
      const list = b.vms.slice().sort((a, c) => order[a.outcome] - order[c.outcome] || String(a.name).localeCompare(c.name));
      fill(
        e("div", { class: "nm-side-top" }, badge(lvl(x.grade), lvl(x.grade).toUpperCase()),
          e("span", { class: "nm-muted" }, { host: "ESXi host", datastore: "Datastore", network: "Port group" }[b.type])),
        e("h3", { class: "nm-side-title" }, x.name),
        reasons(x.grade),
        e("h3", { class: "nm-side-h nm-blast-h" }, "Blast radius"),
        e("p", { class: "nm-muted" }, what + ", " + sm.affected + " VM" + (sm.affected === 1 ? " is" : "s are") + " affected."),
        e("div", { class: "nm-stats" }, statsRow),
        b.type === "host" ? kv([["HA", b.ha_enabled ? "on" : (b.cluster ? "OFF" : "standalone host")],
          ["Hosts that could take VMs", b.peer_hosts], ["Spare memory there", gb(b.spare_memory_mb)],
          ["Memory to restart", gb(b.needed_memory_mb)]]) : null,
        b.type === "datastore" ? e("p", { class: "nm-muted nm-small" }, "HA cannot help here: the storage itself is gone.") : null,
        b.apps.length ? e("h3", { class: "nm-side-h" }, "Applications hit") : null,
        b.apps.length ? e("ul", { class: "nm-list" }, b.apps.map(a => e("li", null,
          badge(a.down ? "red" : "amber", a.hit + "/" + a.total), e("span", { class: "nm-list-n" }, a.app),
          e("span", { class: "nm-muted" }, a.down ? a.down + " down" + (a.restarts ? ", " + a.restarts + " restart" : "") : a.restarts ? a.restarts + " restart" : "")))) : null,
        list.length ? e("h3", { class: "nm-side-h" }, "VMs") : null,
        e("ul", { class: "nm-list" }, list.map(r => e("li", { on: { click: () => select(r.key) } },
          badge({ down: "red", isolated: "red", restarts: "amber", degraded: "amber", offline: "grey" }[r.outcome],
            { down: "DOWN", isolated: "ISOL", restarts: "HA", degraded: "DEGR", offline: "OFF" }[r.outcome]),
          e("span", { class: "nm-list-n" }, r.name), e("span", { class: "nm-muted" }, r.why)))));
    }

    // ---- live feed ----
    function feedBlock() {
      if (!st.feed.length) return e("div", null, e("h3", { class: "nm-side-h" }, "Live feed"),
        e("p", { class: "nm-muted nm-small" }, "Changes and vCenter events appear here as they happen."));
      return e("div", null, e("h3", { class: "nm-side-h" }, "Live feed"),
        e("ul", { class: "nm-feed" }, st.feed.slice(0, 25).map(f => e("li", { class: "nm-f-" + f.level,
          on: f.key ? { click: () => select(f.key) } : {} },
          e("span", { class: "nm-f-t" }, new Date(f.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })),
          e("span", { class: "nm-f-m" }, f.text)))));
    }
    const FIELD = { "runtime.powerState": "power", "runtime.host": "host", "runtime.connectionState": "connection",
      "runtime.inMaintenanceMode": "maintenance", "overallStatus": "status", "triggeredAlarmState": "alarms",
      "guest.toolsRunningStatus": "Tools", "summary.accessible": "accessible", "name": "name" };
    function changeText(c) {
      if (c.field === "created") return c.name + " appeared";
      if (c.field === "removed") return (c.name || c.moref) + " removed";
      if (c.field === "runtime.host") return c.name + " moved " + hostShort(c.old_value) + " \u2192 " + hostShort(c.new_value);
      return c.name + ": " + (FIELD[c.field] || c.field) + " " + (c.old_value ? c.old_value + " \u2192 " : "") + c.new_value;
    }
    function changeLevel(c) {
      const v = String(c.new_value || "");
      if (/notResponding|disconnected|red|poweredOff|^no$|removed/.test(v) || c.field === "removed") return "red";
      if (/yellow|maintenance|^on$|NotRunning|suspended/.test(v) || c.field === "runtime.host") return "amber";
      return "green";
    }

    async function poll() {
      if (!document.body.contains(root)) return ctx.clearTimer();
      try {
        const r = await ctx.api("/admin/vmware/live?since=" + st.since + "&since_event=" + st.sinceEv);
        st.pollOk = true; st.lastPoll = Date.now(); st.live = r.live;
        const mk = (vc, mo) => vc + "|" + mo;
        for (const c of r.changes) {
          st.feed.unshift({ at: c.at, text: changeText(c), level: changeLevel(c), key: mk(c.vcenter, c.moref),
                            move: c.field === "runtime.host" });
          st.flash.add(mk(c.vcenter, c.moref));
        }
        for (const ev of r.events.slice().reverse()) {
          if (ev.id <= st.sinceEv) continue;
          st.feed.unshift({ at: ev.created_at, text: ev.message, level: { critical: "red", warning: "amber" }[ev.severity] || "green",
            key: ev.object_moref ? mk(ev.vcenter, ev.object_moref) : null, ev: true });
        }
        // Newest first; a vMotion arrives as a vCenter event and as a host
        // change, so keep the event and drop the matching change line
        const evKeys = new Set(st.feed.filter(f => f.ev).map(f => f.key + "@" + Math.round(new Date(f.at) / 120000)));
        st.feed = st.feed.filter(f => f.ev || !f.move || !evKeys.has(f.key + "@" + Math.round(new Date(f.at) / 120000)))
          .sort((a, b) => new Date(b.at) - new Date(a.at)).slice(0, 80);
        st.sinceEv = Math.max(st.sinceEv, r.event_id || 0);
        if (r.changes.length) {
          st.since = r.change_id;
          await load();
          const keep = st.sel;
          draw();
          if (keep && st.by.has(keep)) select(keep);
        } else if (!st.sel) {
          const f = side.querySelector(".nm-feed, .nm-muted.nm-small");
          if (f && r.events.length) renderOverview();
        }
      } catch (err) { st.pollOk = false; }
      renderChips();
    }

    function renderChips() {
      const lv = (st.live || (st.data && st.data.live) || []);
      const allUp = lv.length && lv.every(x => x.connected);
      const anyUp = lv.some(x => x.connected);
      const state = !st.pollOk ? "red" : allUp ? "green" : anyUp ? "amber" : (lv.length ? "amber" : "grey");
      liveDot.className = "nm-live-dot nm-ld-" + state;
      liveText.textContent = !st.pollOk ? "console lost contact with PATCH-01"
        : allUp ? "streaming from vCenter \u00b7 checked " + (st.lastPoll ? ago(st.lastPoll) : "just now")
        : anyUp ? "some vCenters not streaming" : lv.length ? "watcher connecting; showing last sync" : "no vCenter added";
      chips.replaceChildren(...lv.map(x => e("span", { class: "nm-chip nm-c-" + (x.connected ? "green" : "amber"),
        title: x.error || ("last change " + ago(x.last_update_at)) }, x.vcenter, " ",
        e("span", { class: "nm-muted" }, x.connected ? "live" : "sync " + ago(x.last_sync_at)))));
    }

    search.addEventListener("input", () => {
      st.q = search.value.trim().toLowerCase();
      applySelection();
      if (!st.q) return;
      const hit = [...st.by.values()].find(x => String(x.name).toLowerCase().includes(st.q) && st.pos.has(x.key));
      if (hit) { const [x, y] = st.pos.get(hit.key); const v = st.view;
        st.view = { x: x - v.w / 2, y: y - v.h / 2, w: v.w, h: v.h }; applyView(); }
    });
    search.addEventListener("keydown", ev => {
      if (ev.key === "Enter") { const hit = [...st.by.values()].find(x => String(x.name).toLowerCase().includes(st.q) && st.pos.has(x.key)); if (hit) select(hit.key); }
    });

    // ---- go ----
    side.replaceChildren(e("p", { class: "nm-muted" }, "Loading the map\u2026"));
    load().then(() => { draw(); ctx.setTimer(poll, POLL_MS); poll(); })
      .catch(err => side.replaceChildren(e("p", { class: "nm-t-red" }, err.message)));
  }

  function legend() {
    const dot = (cls) => { const v = s("svg", { width: 18, height: 18, viewBox: "-9 -9 18 18", class: "nm-lg-ico nm-" + cls });
      v.append(s("circle", { class: "nm-core", r: 5.5 })); return v; };
    const shape = (kind) => {
      const v = s("svg", { width: 30, height: 20, viewBox: "0 0 30 20", class: "nm-lg-ico nm-lg-shape" });
      if (kind === "host") v.append(s("path", { d: hexPath(15, 10, 8) }));
      if (kind === "vm") v.append(s("circle", { cx: 15, cy: 10, r: 5 }));
      if (kind === "unmanaged") { v.append(s("circle", { cx: 15, cy: 10, r: 5 })); v.append(s("circle", { cx: 15, cy: 10, r: 8, class: "nm-lg-dash" })); }
      if (kind === "ds") v.append(s("path", { d: cylinder(4, 2, 22, 16) }));
      if (kind === "net") v.append(s("rect", { x: 2, y: 5, width: 26, height: 10, rx: 5 }));
      if (kind === "down") v.append(s("path", { d: "M2 10H28", class: "nm-lg-line nm-lg-red" }));
      if (kind === "restart") v.append(s("path", { d: "M2 10H28", class: "nm-lg-line nm-lg-amber" }));
      if (kind === "dep") v.append(s("path", { d: "M2 10H28", class: "nm-lg-line nm-lg-cyan" }));
      return v;
    };
    const item = (ico, t, d) => e("div", { class: "nm-lg-item" }, ico, e("div", null, e("strong", null, t), e("span", null, d)));
    return e("section", { class: "nm-legend", "aria-label": "Map legend" },
      e("div", { class: "nm-lg-col" }, e("h4", null, "Status"),
        item(dot("red"), "Neon red: critical", "host down or not responding, datastore 90%+ full or inaccessible, red vCenter alarm, exploited CVEs to patch, CPU or memory 95%+"),
        item(dot("amber"), "Amber: warning", "patches or a reboot due, maintenance mode, yellow alarm, Tools not running, snapshot 7+ days old, datastore 80%+ full, HA off"),
        item(dot("green"), "Green: healthy", "running, nothing to act on"),
        item(dot("grey"), "Grey: powered off", "or nothing to judge by")),
      e("div", { class: "nm-lg-col" }, e("h4", null, "Objects"),
        item(shape("host"), "ESXi host", "number inside is its VM count"),
        item(shape("vm"), "Virtual machine", "inside its host, or its application group"),
        item(shape("unmanaged"), "Dashed ring", "no patch agent: patch state not known"),
        item(shape("ds"), "Datastore", "bar shows how full it is"),
        item(shape("net"), "Port group", "VDS: Distributed switch, STD: standard vSwitch")),
      e("div", { class: "nm-lg-col" }, e("h4", null, "Blast radius"),
        item(shape("down"), "Red line: goes down", "or loses its only network"),
        item(shape("restart"), "Amber line: HA restarts it", "short outage while it boots elsewhere; or degraded, still has another network"),
        item(shape("dep"), "Cyan line: depends on", "a selected VM's host, datastores and networks"),
        e("p", { class: "nm-lg-note" }, "Scroll to zoom, drag to pan, Esc to clear. Updates every 5 seconds.")));
  }

  window.NeonMap = { mount };
})();
