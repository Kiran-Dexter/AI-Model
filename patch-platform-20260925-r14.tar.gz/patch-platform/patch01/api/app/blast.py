"""Blast radius and health grading for the VMware map.

Everything here works on rows already collected from vCenter, and nothing
comes from inside a VM. Pure functions, so every rule is tested without a
vCenter or a database.

Grades:
  red    something is broken or dangerous now
  amber  needs attention
  green  healthy
  grey   powered off, or nothing to judge by
"""

from datetime import datetime, timezone

ORDER = {"grey": -1, "green": 0, "amber": 1, "red": 2}
SNAPSHOT_OLD_DAYS = 7
HOST_LOAD_AMBER, HOST_LOAD_RED = 85, 95
DS_USED_AMBER, DS_USED_RED = 80, 90


class Grade:
    def __init__(self):
        self.level = "green"
        self.reasons = []

    def up(self, level, why):
        if ORDER[level] > ORDER[self.level]:
            self.level = level
        self.reasons.append({"level": level, "text": why})

    def out(self):
        # Worst first, so the first reason explains the colour
        self.reasons.sort(key=lambda r: -ORDER[r["level"]])
        return {"level": self.level, "reasons": self.reasons}


def _alarms(g, alarms):
    for a in alarms or []:
        if a.get("acknowledged"):
            continue
        if a.get("status") == "red":
            g.up("red", "alarm: " + (a.get("name") or "unnamed"))
        elif a.get("status") == "yellow":
            g.up("amber", "alarm: " + (a.get("name") or "unnamed"))


def _vc_status(g, status):
    if status == "red":
        g.up("red", "vCenter reports red")
    elif status == "yellow":
        g.up("amber", "vCenter reports yellow")


def _days(ts, now=None):
    if not ts:
        return None
    if isinstance(ts, str):
        ts = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    now = now or datetime.now(timezone.utc)
    return (now - ts).days


def pct(used, total):
    try:
        return round(100.0 * float(used) / float(total)) if total else None
    except (TypeError, ValueError):
        return None


def grade_host(h):
    g = Grade()
    cs = h.get("connection_state")
    if cs and cs != "connected":
        g.up("red", "host is " + {"notResponding": "not responding",
                                  "disconnected": "disconnected"}.get(cs, cs))
    _vc_status(g, h.get("overall_status"))
    _alarms(g, h.get("alarms"))
    if h.get("maintenance_mode"):
        g.up("amber", "in maintenance mode")
    cpu = pct(h.get("cpu_usage_mhz"), (h.get("cpu_mhz") or 0) * (h.get("cpu_cores") or 0))
    mem = pct(h.get("memory_usage_mb"), h.get("memory_mb"))
    for label, v in (("CPU", cpu), ("memory", mem)):
        if v is not None and v >= HOST_LOAD_RED:
            g.up("red", f"{label} at {v}%")
        elif v is not None and v >= HOST_LOAD_AMBER:
            g.up("amber", f"{label} at {v}%")
    return g.out()


def grade_datastore(d):
    g = Grade()
    if d.get("accessible") is False:
        g.up("red", "not accessible")
    used = pct((d.get("capacity_mb") or 0) - (d.get("free_mb") or 0), d.get("capacity_mb"))
    if used is not None and used >= DS_USED_RED:
        g.up("red", f"{used}% full")
    elif used is not None and used >= DS_USED_AMBER:
        g.up("amber", f"{used}% full")
    prov = pct((d.get("capacity_mb") or 0) - (d.get("free_mb") or 0) + (d.get("uncommitted_mb") or 0),
               d.get("capacity_mb"))
    if prov is not None and prov > 100:
        g.up("amber", f"thin disks provisioned to {prov}% of capacity")
    _vc_status(g, d.get("overall_status"))
    _alarms(g, d.get("alarms"))
    return g.out()


def grade_network(n):
    g = Grade()
    if n.get("accessible") is False:
        g.up("red", "not accessible")
    return g.out()


def grade_vm(v, host_grade=None, now=None):
    g = Grade()
    ps = v.get("power_state")
    if ps != "poweredOn":
        return {"level": "grey", "reasons": [{"level": "grey", "text":
                {"poweredOff": "powered off", "suspended": "suspended"}.get(ps, ps or "state unknown")}]}
    if host_grade and any(r["text"].startswith("host is ") for r in host_grade["reasons"]):
        g.up("red", "its ESXi " + host_grade["reasons"][0]["text"])
    _vc_status(g, v.get("overall_status"))
    _alarms(g, v.get("alarms"))
    kev = int(v.get("kev_advisories") or 0)
    need = int(v.get("needs_patch") or 0)
    if kev:
        g.up("red", f"{kev} advisor{'y' if kev == 1 else 'ies'} with exploited CVEs to patch")
    elif need:
        g.up("amber", f"{need} advisor{'y' if need == 1 else 'ies'} to patch")
    if int(v.get("needs_reboot") or 0):
        g.up("amber", "reboot pending to finish patching")
    tr = v.get("tools_running")
    if tr and tr != "guestToolsRunning":
        g.up("amber", "VMware Tools not running")
    age = _days(v.get("oldest_snapshot_at"), now)
    if age is not None and age >= SNAPSHOT_OLD_DAYS:
        g.up("amber", f"snapshot {age} days old")
    return g.out()


def grade_cluster(c, host_grades):
    g = Grade()
    if c.get("ha_enabled") is False:
        g.up("amber", "HA is off: a host failure means downtime")
    _vc_status(g, c.get("overall_status"))
    _alarms(g, c.get("alarms"))
    bad = [hg for hg in host_grades if hg["level"] in ("red", "amber")]
    red = sum(1 for hg in bad if hg["level"] == "red")
    if red:
        g.up("red", f"{red} host{'' if red == 1 else 's'} red")
    elif bad:
        g.up("amber", f"{len(bad)} host{'' if len(bad) == 1 else 's'} need attention")
    return g.out()


# ---------------------------------------------------------------------------
# Model: everything indexed once, so each blast question is a lookup
# ---------------------------------------------------------------------------

def key(vcenter, moref):
    return f"{vcenter}|{moref}"


def build_model(hosts, vms, datastores, networks, clusters):
    m = {"hosts": {}, "vms": {}, "datastores": {}, "networks": {}, "clusters": {}}
    for h in hosts:
        h = dict(h, key=key(h["vcenter"], h["moref"]))
        h["grade"] = grade_host(h)
        m["hosts"][h["key"]] = h
    for d in datastores:
        d = dict(d, key=key(d["vcenter"], d["moref"]))
        d["grade"] = grade_datastore(d)
        d["local"] = (d.get("host_count") or 0) == 1 and d.get("type") not in ("NFS", "NFS41", "vsan", "VVOL")
        m["datastores"][d["key"]] = d
    for n in networks:
        n = dict(n, key=key(n["vcenter"], n["moref"]))
        n["grade"] = grade_network(n)
        m["networks"][n["key"]] = n
    ds_by_name = {(d["vcenter"], d["name"]): d for d in m["datastores"].values()}
    net_by_name = {(n["vcenter"], n["name"]): n for n in m["networks"].values()}
    for v in vms:
        v = dict(v, key=key(v["vcenter"], v["moref"]))
        v["host_key"] = key(v["vcenter"], v["esxi_moref"]) if v.get("esxi_moref") else None
        hg = m["hosts"].get(v["host_key"], {}).get("grade") if v["host_key"] else None
        v["grade"] = grade_vm(v, hg)
        v["ds_keys"] = [ds_by_name[(v["vcenter"], n)]["key"] for n in (v.get("datastore_names") or [])
                        if (v["vcenter"], n) in ds_by_name]
        v["net_keys"] = [net_by_name[(v["vcenter"], n)]["key"] for n in (v.get("network_names") or [])
                         if (v["vcenter"], n) in net_by_name]
        m["vms"][v["key"]] = v
    for c in clusters:
        c = dict(c, key=key(c["vcenter"], c["moref"]))
        hg = [h["grade"] for h in m["hosts"].values()
              if h["vcenter"] == c["vcenter"] and h.get("cluster") == c["name"]]
        c["grade"] = grade_cluster(c, hg)
        m["clusters"][c["key"]] = c
    m["cluster_by_name"] = {(c["vcenter"], c["name"]): c for c in m["clusters"].values()}
    return m


def _app_rollup(m, hit):
    """Per application group: VMs it has, VMs hit, and how many come back."""
    total = {}
    for v in m["vms"].values():
        if v.get("app_group"):
            total[v["app_group"]] = total.get(v["app_group"], 0) + 1
    out = {}
    for r in hit:
        grp = m["vms"][r["key"]].get("app_group")
        if not grp:
            continue
        a = out.setdefault(grp, {"app": grp, "total": total.get(grp, 0), "hit": 0, "down": 0, "restarts": 0})
        a["hit"] += 1
        if r["outcome"] in ("down", "restarts"):
            a[r["outcome"]] += 1
    return sorted(out.values(), key=lambda a: (-a["down"], -a["hit"], a["app"]))


def _vm_line(v, outcome, why):
    return {"key": v["key"], "name": v.get("name"), "outcome": outcome, "why": why,
            "memory_mb": v.get("memory_mb"), "app_group": v.get("app_group"),
            "host_id": v.get("host_id"), "server": v.get("server")}


def _summary(lines):
    s = {"down": 0, "restarts": 0, "isolated": 0, "degraded": 0, "offline": 0}
    for r in lines:
        s[r["outcome"]] = s.get(r["outcome"], 0) + 1
    s["affected"] = len(lines)
    return s


def host_blast(m, host_key):
    """What an ESXi host failure takes down, and what HA brings back.

    HA restarts a VM elsewhere only if the cluster has HA on, the VM's disks
    are not on storage only this host sees, and the surviving hosts have the
    memory. VMs are placed largest first, the way capacity runs out.
    """
    h = m["hosts"].get(host_key)
    if not h:
        return None
    vms = [v for v in m["vms"].values() if v.get("host_key") == host_key]
    cl = m["cluster_by_name"].get((h["vcenter"], h.get("cluster"))) if h.get("cluster") else None
    ha = bool(cl and cl.get("ha_enabled"))
    peers = [p for p in m["hosts"].values()
             if p["key"] != host_key and p["vcenter"] == h["vcenter"] and h.get("cluster")
             and p.get("cluster") == h.get("cluster") and p.get("connection_state") == "connected"
             and not p.get("maintenance_mode")]
    spare = sum(max(0, (p.get("memory_mb") or 0) - (p.get("memory_usage_mb") or 0)) for p in peers)
    pool = spare
    lines, need = [], 0
    on = sorted((v for v in vms if v.get("power_state") == "poweredOn"),
                key=lambda v: -(v.get("memory_mb") or 0))
    for v in on:
        mem = v.get("memory_mb") or 0
        need += mem
        local = [m["datastores"][k]["name"] for k in v["ds_keys"] if m["datastores"][k].get("local")]
        if not h.get("cluster"):
            lines.append(_vm_line(v, "down", "standalone host: no HA"))
        elif not ha:
            lines.append(_vm_line(v, "down", "HA is off in " + h["cluster"]))
        elif local:
            lines.append(_vm_line(v, "down", "disk on local datastore " + local[0]))
        elif not peers:
            lines.append(_vm_line(v, "down", "no other host in the cluster can take it"))
        elif mem <= pool:
            pool -= mem
            lines.append(_vm_line(v, "restarts", "HA restarts it on another host"))
        else:
            lines.append(_vm_line(v, "down", "not enough spare memory left in the cluster"))
    for v in vms:
        if v.get("power_state") != "poweredOn":
            lines.append(_vm_line(v, "offline", "already powered off"))
    return {"type": "host", "key": host_key, "name": h.get("name"), "cluster": h.get("cluster"),
            "ha_enabled": ha, "peer_hosts": len(peers), "spare_memory_mb": spare,
            "needed_memory_mb": need, "summary": _summary(lines), "vms": lines,
            "apps": _app_rollup(m, lines)}


def datastore_blast(m, ds_key):
    """A datastore failing stops every VM with any disk on it. HA does not
    help: the storage itself is gone."""
    d = m["datastores"].get(ds_key)
    if not d:
        return None
    lines = []
    for v in m["vms"].values():
        if ds_key in v["ds_keys"]:
            if v.get("power_state") == "poweredOn":
                others = len(v["ds_keys"]) - 1
                lines.append(_vm_line(v, "down", "disks here" + (f" and on {others} other datastore"
                                                                  + ("s" if others > 1 else "") if others else "")))
            else:
                lines.append(_vm_line(v, "offline", "powered off; cannot start while this is down"))
    return {"type": "datastore", "key": ds_key, "name": d.get("name"), "summary": _summary(lines),
            "vms": lines, "apps": _app_rollup(m, lines)}


def network_blast(m, net_key):
    """A port group failing isolates VMs that have no other network, and
    degrades those that do."""
    n = m["networks"].get(net_key)
    if not n:
        return None
    lines = []
    for v in m["vms"].values():
        if net_key in v["net_keys"]:
            if v.get("power_state") != "poweredOn":
                lines.append(_vm_line(v, "offline", "powered off"))
            elif len(v["net_keys"]) > 1:
                lines.append(_vm_line(v, "degraded", f"still has {len(v['net_keys']) - 1} other network"
                                                     + ("s" if len(v["net_keys"]) > 2 else "")))
            else:
                lines.append(_vm_line(v, "isolated", "this is its only network"))
    return {"type": "network", "key": net_key, "name": n.get("name"), "summary": _summary(lines),
            "vms": lines, "apps": _app_rollup(m, lines)}


def blast(m, kind, k):
    return {"host": host_blast, "datastore": datastore_blast, "network": network_blast}[kind](m, k)
