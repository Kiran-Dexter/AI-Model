"""The Servers page: every server with an agent, its agent state and patch
position, filtered and paged on the server (20 a page), plus the facets the
filters offer and the full filtered list for export.

Filters are validated here and passed as parameters: nothing from the
request is ever put into the SQL text.
"""

import re

PAGE_SIZE = 30
EXPORT_MAX = 5000
AGENT_STATES = ("online", "offline", "not_reporting", "no_data")
PATCH_STATES = ("needs_patch", "needs_reboot", "up_to_date")
SORTS = {
    "name": "lower(hostname)",
    "agent": "CASE agent WHEN 'online' THEN 1 ELSE 0 END, lower(hostname)",
    "last_seen": "last_checkin DESC NULLS LAST",
    "patches": "packages_to_install + windows_updates_missing DESC, lower(hostname)",
    "os": "os_label, lower(hostname)",
}
NAME_RE = re.compile(r"^[A-Za-z0-9 ._()/+-]{1,80}$")

OS_LABEL = """CASE
    WHEN h.os_id = 'windows' THEN coalesce(nullif(regexp_replace(h.os_edition, '^Microsoft ', ''), ''), 'Windows')
    WHEN h.os_id = 'rhel' THEN 'RHEL ' || coalesce(h.os_major::text, split_part(h.os_version, '.', 1))
    WHEN h.os_id = 'ol' THEN 'Oracle Linux ' || coalesce(h.os_major::text, split_part(h.os_version, '.', 1))
    WHEN h.os_id = 'ubuntu' THEN 'Ubuntu ' || coalesce(h.os_version, '')
    ELSE coalesce(h.os_id, 'unknown') || ' ' || coalesce(h.os_version, '') END"""

_BASE_T = f"""
WITH imp AS (
  -- Detected CVEs (Vulnerabilities page): each machine's platform-checked matches, read once
  SELECT lower(split_part(m->>'name', '.', 1)) AS n,
         count(DISTINCT ci.cve_id) FILTER (WHERE ci.verdict = 'affected' AND m->>'certainty' IN ('confirmed', 'in_range')) AS cves_affected,
         count(DISTINCT ci.cve_id) AS cves_detected,
         bool_or(ci.exploited) AS cves_zero_day
    FROM cve_impact ci, jsonb_array_elements(ci.matches) m
   WHERE ci.verdict IN ('affected', 'potentially_affected', 'pending_reboot')
     AND m->>'name' IS NOT NULL AND m->>'certainty' <> 'not_tracked'
   GROUP BY 1),
@@AVCTE@@s AS (
  SELECT h.id::text AS host_id, h.hostname, h.fqdn, h.os_id, h.os_version, h.os_edition,
         {OS_LABEL} AS os_label, h.host_group, h.agent_version, host(h.agent_ip) AS agent_ip,
         agent_state(h.last_checkin, h.status) AS agent, h.last_checkin, h.last_inventory, h.enrolled_at,
         h.boot_time, CASE WHEN h.boot_time IS NOT NULL
                           THEN extract(epoch FROM now() - h.boot_time)::bigint END AS uptime_seconds,
         h.kernel_running, h.reboot_required, h.reboot_reason, h.wu_source, h.wu_searched_at, h.agent_run,
         (SELECT count(*) FROM host_applicability ha WHERE ha.host_id = h.id AND ha.state = 'affected') AS needs_patch,
         -- What a patch job would install: one line per package (Linux), whatever the number of advisories it fixes
         (SELECT count(DISTINCT ha.package_name) FROM host_applicability ha
           WHERE ha.host_id = h.id AND ha.state = 'affected' AND ha.fixed_evr IS NOT NULL) AS packages_to_install,
         (SELECT count(*) FROM host_applicability ha WHERE ha.host_id = h.id AND ha.state = 'fixed_pending_reboot') AS pending_reboot,
         (SELECT count(*) FROM windows_updates wu WHERE wu.host_id = h.id) AS windows_updates_missing,
         (SELECT max(r.max_cvss) FROM host_applicability ha JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id
           WHERE ha.host_id = h.id AND ha.state = 'affected') AS worst_cvss,
         (SELECT bool_or(coalesce(r.any_kev, false)) FROM host_applicability ha JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id
           WHERE ha.host_id = h.id AND ha.state = 'affected') AS exploited,
         (SELECT v.vcenter FROM vm_inventory v WHERE v.host_id = h.id
           ORDER BY (v.power_state = 'poweredOn') IS TRUE DESC,
                  (h.agent_ip IS NOT NULL AND host(h.agent_ip) = ANY(coalesce(v.guest_ips, '{{}}'))) IS TRUE DESC,
                  v.synced_at DESC NULLS LAST, v.vcenter, v.moref LIMIT 1) AS vcenter,
         (SELECT v.cluster FROM vm_inventory v WHERE v.host_id = h.id
           ORDER BY (v.power_state = 'poweredOn') IS TRUE DESC,
                  (h.agent_ip IS NOT NULL AND host(h.agent_ip) = ANY(coalesce(v.guest_ips, '{{}}'))) IS TRUE DESC,
                  v.synced_at DESC NULLS LAST, v.vcenter, v.moref LIMIT 1) AS cluster,
         (SELECT v.power_state FROM vm_inventory v WHERE v.host_id = h.id
           ORDER BY (v.power_state = 'poweredOn') IS TRUE DESC,
                  (h.agent_ip IS NOT NULL AND host(h.agent_ip) = ANY(coalesce(v.guest_ips, '{{}}'))) IS TRUE DESC,
                  v.synced_at DESC NULLS LAST, v.vcenter, v.moref LIMIT 1) AS power,
         (SELECT round(l.score) FROM v_hardening_latest l WHERE l.host_id = h.id
           ORDER BY l.finished_at DESC NULLS LAST LIMIT 1) AS hardening_score,
         lp.finished_at AS last_patch_at, lp.state AS last_patch_state, lp.ref AS last_patch_ref,
         lp.patches AS last_patch_count,
         coalesce(imp.cves_detected, 0) AS cves_detected, coalesce(imp.cves_affected, 0) AS cves_affected,
         coalesce(imp.cves_zero_day, false) AS cves_zero_day,
@@AVCOLS@@    FROM hosts h LEFT JOIN imp ON imp.n = lower(split_part(h.hostname, '.', 1))
    LEFT JOIN LATERAL (
      -- The last patch job that finished on this server (Patch Reports has the detail)
      SELECT coalesce(c.finished_at, ct.updated_at) AS finished_at, ct.state,
             'CHG-' || lpad(c.number::text, 6, '0') AS ref,
             CASE WHEN ct.detail ? 'install' AND jsonb_typeof(ct.detail->'install'->'installed') = 'array'
                  THEN jsonb_array_length(ct.detail->'install'->'installed')
                  WHEN ct.state IN ('done', 'done_with_warnings') AND jsonb_typeof(ct.detail->'packages') = 'array'
                  THEN jsonb_array_length(ct.detail->'packages') END AS patches
        FROM change_targets ct JOIN changes c ON c.id = ct.change_id
       WHERE ct.host_id = h.id AND c.kind = 'patch'
         AND ct.state IN ('done', 'done_with_warnings', 'failed')
       ORDER BY coalesce(c.finished_at, ct.updated_at) DESC LIMIT 1) lp ON true
@@AVJOIN@@
   WHERE h.status <> 'decommissioned')
SELECT s.*, packages_to_install + windows_updates_missing AS to_install FROM s
 WHERE (%(q)s::text IS NULL OR strpos(lower(hostname || ' ' || coalesce(fqdn, '') || ' ' || coalesce(agent_ip, '')), lower(%(q)s::text)) > 0)
   AND (%(os)s::text IS NULL OR os_label = %(os)s::text)
   AND (%(group)s::text IS NULL OR host_group = %(group)s::text)
   AND (%(version)s::text IS NULL OR coalesce(agent_version, 'unknown') = %(version)s::text)
   AND (%(agent)s::text IS NULL
        OR (%(agent)s::text = 'offline' AND agent <> 'online')
        OR agent = %(agent)s::text)
   AND (%(patch)s::text IS NULL
        OR (%(patch)s::text = 'needs_patch' AND (packages_to_install > 0 OR windows_updates_missing > 0))
        OR (%(patch)s::text = 'needs_reboot' AND (reboot_required OR pending_reboot > 0))
        OR (%(patch)s::text = 'up_to_date' AND packages_to_install = 0 AND windows_updates_missing = 0
            AND NOT reboot_required AND pending_reboot = 0))
"""

# Antivirus agents (Apex Central): only current ones (console on, listed in the
# last two days) count, matched by address first, then by short name
AV_CTE = """avn AS (
  SELECT lower(split_part(a.host_name, '.', 1)) AS n, string_agg(DISTINCT c.name, ', ') AS consoles
    FROM av_agents a JOIN av_consoles c ON c.id = a.console_id AND c.enabled
   WHERE a.last_seen > now() - interval '48 hours' GROUP BY 1),
avi AS (
  SELECT ip, string_agg(DISTINCT c.name, ', ') AS consoles
    FROM av_agents a JOIN av_consoles c ON c.id = a.console_id AND c.enabled, unnest(a.ip_addresses) ip
   WHERE a.last_seen > now() - interval '48 hours' GROUP BY 1),
"""
AV_COLS = """         coalesce(avi.consoles, avn.consoles) AS antivirus,
         (SELECT EXISTS (SELECT 1 FROM av_consoles WHERE enabled AND last_sync_ok)) AS av_active
"""
AV_JOIN = """    LEFT JOIN avi ON avi.ip = host(h.agent_ip)
    LEFT JOIN avn ON avi.ip IS NULL AND avn.n = lower(split_part(h.hostname, '.', 1))"""
BASE_AV = _BASE_T.replace("@@AVCTE@@", AV_CTE).replace("@@AVCOLS@@", AV_COLS).replace("@@AVJOIN@@", AV_JOIN)
# Before schema 026 (antivirus) is applied, the page works without it
BASE_NO_AV = _BASE_T.replace("@@AVCTE@@", "").replace("@@AVCOLS@@", "         NULL::text AS antivirus, false AS av_active\n") \
                 .replace("@@AVJOIN@@", "")
BASE = BASE_AV
_HAS_AV = {"ok": False}


def base(conn):
    if not _HAS_AV["ok"]:
        r = conn.execute("SELECT to_regclass('av_agents') IS NOT NULL AND to_regclass('av_consoles') IS NOT NULL AS ok").fetchone()
        _HAS_AV["ok"] = bool(r and r["ok"])
    return BASE_AV if _HAS_AV["ok"] else BASE_NO_AV


def clean_filters(q=None, os=None, group=None, version=None, agent=None, patch=None):
    """Validated filters; anything malformed is ignored, never passed on."""
    def name(v):
        v = (v or "").strip()
        return v if v and NAME_RE.match(v) else None
    q = (q or "").strip()
    return {
        "q": q[:80] if q and re.fullmatch(r"[A-Za-z0-9 ._:-]{1,80}", q) else None,
        "os": name(os), "group": name(group), "version": name(version),
        "agent": agent if agent in AGENT_STATES else None,
        "patch": patch if patch in PATCH_STATES else None,
    }


def page(conn, filters, page_no=1, size=PAGE_SIZE, sort="agent"):
    order = SORTS.get(sort, SORTS["agent"])
    total = conn.execute("SELECT count(*) AS n FROM (" + base(conn) + ") x", filters).fetchone()["n"]
    pages = max(1, (total + size - 1) // size)
    page_no = max(1, min(int(page_no or 1), pages))
    rows = conn.execute(base(conn) + f" ORDER BY {order} LIMIT %(limit)s OFFSET %(offset)s",
                        dict(filters, limit=size, offset=(page_no - 1) * size)).fetchall()
    return {"total": total, "page": page_no, "pages": pages, "size": size, "rows": rows}


def all_rows(conn, filters, sort="name"):
    order = SORTS.get(sort, SORTS["name"])
    return conn.execute(base(conn) + f" ORDER BY {order} LIMIT %(limit)s", dict(filters, limit=EXPORT_MAX)).fetchall()


def facets(conn):
    """The values each filter offers, with counts, over all servers."""
    none = clean_filters()
    rows = conn.execute("SELECT os_label, host_group, coalesce(agent_version, 'unknown') AS version, agent, "
                        "to_install, reboot_required, pending_reboot FROM (" + base(conn) + ") x",
                        none).fetchall()

    def count(key):
        out = {}
        for r in rows:
            k = r[key] or "(none)"
            out[k] = out.get(k, 0) + 1
        return [{"value": k, "n": v} for k, v in sorted(out.items(), key=lambda kv: (-kv[1], kv[0]))]
    online = sum(1 for r in rows if r["agent"] == "online")
    return {
        "os": count("os_label"), "group": count("host_group"), "version": count("version"),
        "agent": {"online": online, "offline": len(rows) - online,
                  **{s: sum(1 for r in rows if r["agent"] == s) for s in AGENT_STATES}},
        "patch": {
            "needs_patch": sum(1 for r in rows if r["to_install"]),
            "needs_reboot": sum(1 for r in rows if r["reboot_required"] or r["pending_reboot"]),
            "up_to_date": sum(1 for r in rows if not (r["to_install"] or r["reboot_required"] or r["pending_reboot"])),
        },
        "total": len(rows),
    }


EXPORT_COLUMNS = [
    ("hostname", "Server"), ("agent", "Agent"), ("os_label", "Operating system"), ("host_group", "Group"),
    ("agent_version", "Agent version"), ("agent_ip", "Address"), ("last_checkin", "Last seen"),
    ("to_install", "Patches to install"), ("packages_to_install", "Linux packages to update"),
    ("windows_updates_missing", "Windows updates missing"), ("needs_patch", "Advisories these fix"),
    ("pending_reboot", "Installed, reboot needed"), ("reboot_required", "Reboot pending"),
    ("worst_cvss", "Worst CVSS"), ("exploited", "Exploited CVE"),
    ("antivirus", "Antivirus console"), ("cves_detected", "Detected CVEs"), ("cves_affected", "Detected CVEs confirmed"), ("cves_zero_day", "Detected 0-day"),
    ("last_patch_at", "Last patched"), ("last_patch_state", "Last patch result"), ("last_patch_ref", "Last patch change"),
    ("kernel_running", "Running kernel"),
    ("uptime_seconds", "Uptime (days)"), ("hardening_score", "Hardening score"),
    ("vcenter", "vCenter"), ("cluster", "Cluster"), ("power", "Power"), ("fqdn", "FQDN"),
]


def export_value(key, v):
    if v is None:
        return ""
    if key == "uptime_seconds":
        return round(int(v) / 86400, 1)
    if key == "agent":
        return "online" if v == "online" else "offline (" + str(v).replace("_", " ") + ")" if v != "offline" else "offline"
    if isinstance(v, bool):
        return "yes" if v else "no"
    if hasattr(v, "astimezone") and getattr(v, "tzinfo", None):
        from .exports import TZ, TZ_LABEL
        return v.astimezone(TZ).strftime("%Y-%m-%d %H:%M ") + TZ_LABEL   # same zone as the report heading
    if hasattr(v, "isoformat"):
        return v.strftime("%Y-%m-%d %H:%M")
    return v


def describe_filters(f):
    words = {"q": "name contains", "os": "OS", "group": "group", "version": "agent version",
             "agent": "agent", "patch": "patch state"}
    parts = [f"{words[k]} {str(v).replace('_', ' ')}" for k, v in f.items() if v]
    return "; ".join(parts) or "all servers"


GROUP_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._()+-]{0,39}$")
NO_GROUP = "(no group)"


def group_list(conn):
    """Every patch group, in patch order, with its server counts (all servers, not filtered)."""
    return conn.execute(
        """SELECT g.name, g.description, g.environment::text AS environment, g.max_concurrent, g.patch_order,
                  count(h.id) AS servers,
                  count(h.id) FILTER (WHERE h.os_id = 'windows') AS windows,
                  count(h.id) FILTER (WHERE h.os_id IS DISTINCT FROM 'windows') AS linux
             FROM host_groups g LEFT JOIN hosts h ON h.host_group = g.name AND h.status <> 'decommissioned'
            GROUP BY g.name ORDER BY g.patch_order, lower(g.name)""").fetchall()


def grouped(conn, filters, sort="name"):
    """The filtered servers, in their patch groups (patch order), each group with its totals.
    Groups with no matching server are left out, unless nothing is filtered."""
    order = SORTS.get(sort, SORTS["name"])
    rows = conn.execute(base(conn) + f" ORDER BY {order} LIMIT %(limit)s", dict(filters, limit=EXPORT_MAX)).fetchall()
    meta = {g["name"]: g for g in group_list(conn)}
    buckets = {}
    for r in rows:
        buckets.setdefault(r["host_group"] or NO_GROUP, []).append(r)
    filtered = any(filters.values())
    names = [g for g in meta if buckets.get(g) or not filtered]
    names += sorted(k for k in buckets if k not in meta)          # a group no longer in the list
    out = []
    for n in names:
        rs = buckets.get(n, [])
        g = meta.get(n) or {}
        out.append({
            "name": n, "description": g.get("description"), "environment": g.get("environment"),
            "max_concurrent": g.get("max_concurrent"), "known": n in meta,
            "servers": len(rs),
            "windows": sum(1 for r in rs if r["os_id"] == "windows"),
            "linux": sum(1 for r in rs if r["os_id"] != "windows"),
            "online": sum(1 for r in rs if r["agent"] == "online"),
            "to_install_servers": sum(1 for r in rs if r["to_install"]),
            "to_install": sum(int(r["to_install"] or 0) for r in rs),
            "reboot": sum(1 for r in rs if r["reboot_required"] or r["pending_reboot"]),
            "rows": rs,
        })
    return {"groups": out, "total": len(rows)}


PENDING_LINUX_SQL = """
SELECT ha.package_name AS name, max(ha.installed_evr) AS installed,
       array_agg(DISTINCT ha.fixed_evr) AS fixed_versions,
       array_agg(DISTINCT ha.advisory_id::text ORDER BY ha.advisory_id::text) AS advisories,
       max(r.max_cvss) AS cvss, bool_or(coalesce(r.any_kev, false)) AS exploited
  FROM host_applicability ha LEFT JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id
 WHERE ha.host_id = %s AND ha.state = 'affected' AND ha.fixed_evr IS NOT NULL
 GROUP BY ha.package_name ORDER BY max(r.max_cvss) DESC NULLS LAST, ha.package_name"""


def pending(conn, host_id):
    """What a patch job would install on this server now: Linux packages (with the
    version each moves to) or Windows updates. CVEs are on the Vulnerabilities page."""
    from .worker import choose_fixed_versions
    h = conn.execute("SELECT id, hostname, os_id, pkg_manager::text AS pkg_manager, last_inventory FROM hosts WHERE id = %s",
                     (host_id,)).fetchone()
    if not h:
        return None
    if h["pkg_manager"] == "wua" or h["os_id"] == "windows":
        items = conn.execute(
            """SELECT kb, title, severity, cves FROM windows_updates WHERE host_id = %s
                ORDER BY CASE lower(coalesce(severity, '')) WHEN 'critical' THEN 0 WHEN 'important' THEN 1
                              WHEN 'moderate' THEN 2 ELSE 3 END, kb""", (host_id,)).fetchall()
        return {"kind": "windows", "items": [{"kb": i["kb"], "title": i["title"], "severity": i["severity"],
                                              "cves": len(i["cves"] or [])} for i in items],
                "as_of": h["last_inventory"]}
    rows = conn.execute(PENDING_LINUX_SQL, (host_id,)).fetchall()
    target = {p["name"]: p["version"] for p in choose_fixed_versions(
        [{"package_name": r["name"], "fixed_evr": f} for r in rows for f in (r["fixed_versions"] or [])], h["pkg_manager"])}
    return {"kind": "linux", "as_of": h["last_inventory"],
            "items": [{"name": r["name"], "installed": r["installed"], "to": target.get(r["name"]),
                       "advisories": (r["advisories"] or [])[:8], "advisory_count": len(r["advisories"] or []),
                       "cvss": r["cvss"], "exploited": r["exploited"]} for r in rows]}
