"""
The Overview page's figures, in one request: the headline figures with their
change since last week, installs per day (this month against last month),
Windows and Linux servers patched per week, compliance goals, recent jobs and
recent events.

Every figure is computed here from the database. The changes since last week
come from overview_daily, one row a day written by the worker (snapshot());
until a week of rows exists, a change is reported as unknown, never invented.
"""

import logging
from datetime import date, timedelta

log = logging.getLogger("patchapi.overview")

GOAL_TARGETS = {"compliance": 95, "agents": 98, "success": 95}

KPI_SQL = """
WITH h AS (
  SELECT h.id, h.os_id, agent_state(h.last_checkin, h.status) AS agent,
         EXISTS (SELECT 1 FROM host_applicability ha WHERE ha.host_id = h.id AND ha.state = 'affected'
                   AND ha.fixed_evr IS NOT NULL)
         OR EXISTS (SELECT 1 FROM windows_updates wu WHERE wu.host_id = h.id) AS needs
    FROM hosts h WHERE h.status <> 'decommissioned')
SELECT count(*) AS servers,
       count(*) FILTER (WHERE agent = 'online') AS online,
       count(*) FILTER (WHERE needs) AS to_patch,
       count(*) FILTER (WHERE os_id = 'windows') AS windows,
       count(*) FILTER (WHERE os_id <> 'windows') AS linux
  FROM h"""

CVE_SQL = """
SELECT count(*) FILTER (WHERE verdict = 'affected' AND (exploited OR lower(coalesce(severity, '')) = 'critical')) AS critical,
       count(*) FILTER (WHERE verdict = 'affected' AND exploited) AS zero_day
  FROM cve_impact"""

JOBS_SQL = """
SELECT count(*) FILTER (WHERE ct.state IN ('done', 'done_with_warnings')) AS ok,
       count(*) FILTER (WHERE ct.state = 'failed') AS failed
  FROM change_targets ct JOIN changes c ON c.id = ct.change_id
 WHERE c.kind = 'patch' AND ct.updated_at > now() - make_interval(days => %s)
   AND ct.state IN ('done', 'done_with_warnings', 'failed')"""

# Updates installed per day: Windows updates listed by the job, Linux packages installed
INSTALLS_SQL = """
SELECT (ct.updated_at AT TIME ZONE %(tz)s)::date AS day,
       sum(CASE WHEN jsonb_typeof(ct.detail->'install'->'installed') = 'array'
                THEN jsonb_array_length(ct.detail->'install'->'installed')
                WHEN jsonb_typeof(ct.detail->'packages') = 'array' THEN jsonb_array_length(ct.detail->'packages')
                ELSE 0 END) AS installs
  FROM change_targets ct JOIN changes c ON c.id = ct.change_id
 WHERE c.kind = 'patch' AND ct.state IN ('done', 'done_with_warnings')
   AND ct.updated_at >= (%(since)s::date::timestamp AT TIME ZONE %(tz)s)
 GROUP BY 1"""

WEEKLY_SQL = """
SELECT date_trunc('week', ct.updated_at AT TIME ZONE %(tz)s)::date AS week,
       count(DISTINCT ct.host_id) FILTER (WHERE h.os_id = 'windows') AS windows,
       count(DISTINCT ct.host_id) FILTER (WHERE h.os_id <> 'windows') AS linux
  FROM change_targets ct JOIN changes c ON c.id = ct.change_id JOIN hosts h ON h.id = ct.host_id
 WHERE c.kind = 'patch' AND ct.state IN ('done', 'done_with_warnings')
   AND ct.updated_at >= ((date_trunc('week', now() AT TIME ZONE %(tz)s) - interval '7 weeks') AT TIME ZONE %(tz)s)
 GROUP BY 1 ORDER BY 1"""

RECENT_SQL = """
SELECT c.id::text AS id, 'CHG-' || lpad(c.number::text, 6, '0') AS ref, c.kind::text AS kind, c.title,
       c.state::text AS state, c.requested_by, coalesce(c.finished_at, c.started_at, c.run_after, c.requested_at) AS at,
       (SELECT count(*) FROM change_targets ct WHERE ct.change_id = c.id) AS servers,
       (SELECT count(*) FROM change_targets ct WHERE ct.change_id = c.id AND ct.state = 'failed') AS failed
  FROM changes c
 ORDER BY coalesce(c.finished_at, c.started_at, c.run_after, c.requested_at) DESC
 LIMIT 8"""

EVENTS_SQL = """
SELECT e.at, e.event, e.ok, left(e.message, 240) AS message, 'CHG-' || lpad(c.number::text, 6, '0') AS ref,
       c.id::text AS change_id
  FROM change_events e JOIN changes c ON c.id = e.change_id
 WHERE e.id > (SELECT coalesce(max(id), 0) - 5000 FROM change_events)
   AND e.event NOT IN ('precheck', 'inventory')
 ORDER BY e.id DESC LIMIT 12"""

OFFLINE_SQL = """
SELECT hostname, last_checkin FROM hosts
 WHERE status <> 'decommissioned' AND agent_state(last_checkin, status) <> 'online'
   AND last_checkin > now() - interval '24 hours'
 ORDER BY last_checkin DESC LIMIT 5"""


def _pct(a, b):
    return round(100.0 * a / b, 1) if b else None


def current(conn):
    """Today's headline figures (also what snapshot() stores)."""
    k = dict(conn.execute(KPI_SQL).fetchone())
    try:
        with conn.transaction():
            cv = dict(conn.execute(CVE_SQL).fetchone())
    except Exception:  # noqa: BLE001 - schema 023 (CVE impact) not applied
        cv = {"critical": None, "zero_day": None}
    j = dict(conn.execute(JOBS_SQL, (30,)).fetchone())
    done = (j["ok"] or 0) + (j["failed"] or 0)
    return {
        "servers": int(k["servers"] or 0), "online": int(k["online"] or 0),
        "to_patch": int(k["to_patch"] or 0), "windows": int(k["windows"] or 0), "linux": int(k["linux"] or 0),
        "critical_cves": cv["critical"], "zero_day": cv["zero_day"],
        "jobs_30d": done, "success_pct": _pct(j["ok"] or 0, done),
    }


def snapshot(conn, today=None):
    """Store today's figures once a day (the worker calls this; repeated calls do nothing)."""
    today = today or date.today()
    c = current(conn)
    conn.execute(
        """INSERT INTO overview_daily (day, servers, online, to_patch, critical_cves, success_pct)
           VALUES (%s, %s, %s, %s, %s, %s) ON CONFLICT (day) DO NOTHING""",
        (today, c["servers"], c["online"], c["to_patch"], c["critical_cves"], c["success_pct"]))


def _week_ago(conn, today):
    try:
        with conn.transaction():
            r = conn.execute("""SELECT * FROM overview_daily WHERE day BETWEEN %s AND %s ORDER BY day DESC LIMIT 1""",
                             (today - timedelta(days=9), today - timedelta(days=6))).fetchone()
        return dict(r) if r else None
    except Exception:  # noqa: BLE001 - schema 042 not applied
        return None


def build(conn, tz="UTC", today=None):
    today = today or date.today()
    c = current(conn)
    prev = _week_ago(conn, today)

    def delta(key, cur):
        if not prev or prev.get(key) is None or cur is None:
            return None
        return round(float(cur) - float(prev[key]), 1)

    kpis = [
        {"key": "online", "label": "Servers online", "value": c["online"], "of": c["servers"],
         "delta": delta("online", c["online"]), "good": "up"},
        {"key": "to_patch", "label": "Servers to patch", "value": c["to_patch"], "of": c["servers"],
         "delta": delta("to_patch", c["to_patch"]), "good": "down"},
        {"key": "critical_cves", "label": "Critical and 0-day CVEs", "value": c["critical_cves"],
         "extra": c["zero_day"], "delta": delta("critical_cves", c["critical_cves"]), "good": "down"},
        {"key": "success_pct", "label": "Patch success, 30 days", "value": c["success_pct"], "unit": "%",
         "extra": c["jobs_30d"], "delta": delta("success_pct", c["success_pct"]), "good": "up"},
    ]

    # Installs per day: this month and last month, by day of the month
    first = today.replace(day=1)
    last_first = (first - timedelta(days=1)).replace(day=1)
    iso = lambda d_: str(d_)[:10]                  # dates as YYYY-MM-DD, whatever the driver returns
    per_day = {iso(r["day"]): int(r["installs"] or 0) for r in conn.execute(INSTALLS_SQL, {"tz": tz, "since": last_first}).fetchall()}
    days = 31
    this_m = [per_day.get(iso(first + timedelta(days=i)), 0) if first + timedelta(days=i) <= today else None
              for i in range(days) if (first + timedelta(days=i)).month == first.month]
    last_m = [per_day.get(iso(last_first + timedelta(days=i)), 0) for i in range(days)
              if (last_first + timedelta(days=i)).month == last_first.month]

    weekly = [{"week": r["week"], "windows": int(r["windows"] or 0), "linux": int(r["linux"] or 0)}
              for r in conn.execute(WEEKLY_SQL, {"tz": tz}).fetchall()]
    # Every one of the last 8 weeks, also those with no patching
    start = today - timedelta(days=today.weekday()) - timedelta(weeks=7)
    have = {iso(w["week"]): w for w in weekly}
    weekly = [dict(have.get(iso(start + timedelta(weeks=i)), {"windows": 0, "linux": 0}), week=iso(start + timedelta(weeks=i)))
              for i in range(8)]

    goals = [
        {"key": "compliance", "label": "Servers fully patched", "pct": _pct(c["servers"] - c["to_patch"], c["servers"]),
         "target": GOAL_TARGETS["compliance"]},
        {"key": "agents", "label": "Agents online", "pct": _pct(c["online"], c["servers"]), "target": GOAL_TARGETS["agents"]},
        {"key": "success", "label": "Patch jobs succeeding (30 days)", "pct": c["success_pct"], "target": GOAL_TARGETS["success"]},
    ]
    known = [g["pct"] for g in goals if g["pct"] is not None]
    overall = round(sum(min(100.0, 100.0 * g["pct"] / g["target"]) for g in goals if g["pct"] is not None) / len(known), 1) if known else None

    events = [dict(r) for r in conn.execute(EVENTS_SQL).fetchall()]
    offline = [dict(r) for r in conn.execute(OFFLINE_SQL).fetchall()]
    return {
        "today": today, "kpis": kpis, "has_history": prev is not None,
        "installs": {"this_month": this_m, "last_month": last_m, "month": first, "last": last_first,
                     "total_this": sum(x for x in this_m if x), "total_last": sum(last_m)},
        "weekly": weekly,
        "split": {"windows": c["windows"], "linux": c["linux"]},
        "goals": goals, "goals_overall": overall,
        "recent": [dict(r) for r in conn.execute(RECENT_SQL).fetchall()],
        "events": events, "went_offline": offline,
    }
