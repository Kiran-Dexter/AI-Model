"""Antivirus: Trend Micro Apex Central consoles, read-only.

Apex Central's Automation API authenticates every request with a JSON Web
Token signed (HMAC-SHA256) with the console's API key. The token carries the
Application ID, the time it was made, and a SHA-256 checksum of the request
itself (method, path, "API" headers and body), so a token cannot be replayed
for another request, and Apex Central refuses it once its communication
time-out has passed. The API key itself never leaves PATCH-01.

PATCH-01 only ever sends GET requests: it lists the security agents. The
same API can isolate or uninstall agents; nothing here can, by construction
(the one request function refuses any method but GET). Use an Apex Central
account with a read-only role for the API key all the same.

Secrets: the API key is encrypted (Fernet) with av.key from the secrets
folder before it is stored, decrypted only in memory to sign a request, and
never returned to the browser or written to a log.
"""

import base64
import hashlib
import hmac
import ipaddress
import json
import logging
import os
import re
import socket
import ssl
import time
import http.client
import urllib.parse

log = logging.getLogger("patchapi.antivirus")

KEY_FILE = os.environ.get("AV_KEY_FILE", "/etc/patch01/av.key")
AGENTS_PATH = "/WebApp/API/AgentResource/ProductAgents"
MAX_RESPONSE = 64 * 2 ** 20
MAX_AGENTS = 100000
TIMEOUT = 30                 # each network step
DEADLINE = 180               # the whole answer
SYNC_MINUTES = 60
URL_RE = re.compile(r"^https://(?P<host>[A-Za-z0-9.-]{1,253}|\[[0-9A-Fa-f:]{2,39}\])(?::(?P<port>\d{1,5}))?/?$")
APP_ID_RE = re.compile(r"^[A-Za-z0-9-]{8,80}$")
NAME_RE = re.compile(r"^[A-Za-z0-9 ._()-]{1,60}$")
PRODUCTS = (
    (re.compile(r"OFFICESCAN|APEX_?ONE", re.I), "Apex One security agent"),
    (re.compile(r"DEEP_?SECURITY|DSM|DSA", re.I), "Deep Security agent"),
    (re.compile(r"SERVER_?PROTECT", re.I), "ServerProtect"),
    (re.compile(r"PORTABLE|SAFE_?LOCK|TXONE", re.I), "Safe Lock"),
    (re.compile(r"ENDPOINT_?SENSOR|EDR", re.I), "Endpoint Sensor"),
)


class AvError(RuntimeError):
    """A problem worth showing to the admin as it is."""


# ---------------------------------------------------------------------------
# Secrets
# ---------------------------------------------------------------------------

def _fernet():
    from cryptography.fernet import Fernet
    try:
        with open(KEY_FILE, "rb") as fh:
            return Fernet(fh.read().strip())
    except FileNotFoundError:
        raise AvError("The antivirus key av.key is missing on PATCH-01: re-run phase3b-api.sh.")
    except ValueError:
        raise AvError("av.key is not a valid key: remove it, re-run phase3b-api.sh and enter the API keys again.")


def encrypt(secret):
    return _fernet().encrypt(secret.encode()).decode()


def decrypt(token):
    from cryptography.fernet import InvalidToken
    try:
        return _fernet().decrypt(token.encode()).decode()
    except InvalidToken:
        raise AvError("The saved API key cannot be read with this PATCH-01's av.key: enter it again.")


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def _blocked(ip):
    """Addresses that can never be an Apex Central console: this machine, link-local
    (cloud metadata), multicast, unspecified, reserved."""
    ip = getattr(ip, "ipv4_mapped", None) or ip
    return ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_unspecified or ip.is_reserved


def clean_url(url):
    """https://host[:port] only: no path, no user, no query; a host name, a
    dotted IPv4 address or a bracketed IPv6 address (no 127.1, 0x7f000001...)."""
    u = (url or "").strip().rstrip("/")
    m = URL_RE.match(u)
    if not m:
        raise AvError("The URL must be https://host or https://host:port, with no path.")
    port = int(m.group("port") or 443)
    if not 1 <= port <= 65535:
        raise AvError("The port must be between 1 and 65535.")
    host = m.group("host")
    if host.startswith("["):
        try:
            ip = ipaddress.IPv6Address(host[1:-1])
        except ValueError:
            raise AvError("That IPv6 address is not valid.")
        if _blocked(ip):
            raise AvError("That address cannot be an Apex Central console.")
        return u
    h = host.lower()
    if h.endswith(".") or ".." in h or h.startswith(".") or h.startswith("-"):
        raise AvError("That host name is not valid.")
    if re.fullmatch(r"[0-9.]+|0x[0-9a-f.x]+", h):            # only a full dotted address counts as numeric
        try:
            ip = ipaddress.IPv4Address(h)
        except ValueError:
            raise AvError("Write the address in full, for example 10.20.30.40.")
        if _blocked(ip):
            raise AvError("That address cannot be an Apex Central console.")
        return u
    if not all(re.fullmatch(r"[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?", lab) for lab in h.split(".")) \
            or h.split(".")[-1].isdigit() or h in ("localhost", "localhost.localdomain") or h.endswith(".localhost"):
        raise AvError("That host name is not valid, or cannot be an Apex Central console.")
    return u


def resolve(host, port):
    """The console's addresses, each checked; the first is the one connected to."""
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except (socket.gaierror, UnicodeError):
        raise AvError(f"The name {host} does not resolve on PATCH-01: check it, or use the console's address.")
    ips = []
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if _blocked(ip):
            raise AvError(f"{host} resolves to an address that cannot be an Apex Central console.")
        if ip not in ips:
            ips.append(ip)
    if not ips:
        raise AvError(f"The name {host} does not resolve on PATCH-01.")
    return ips


def clean_app_id(v):
    v = (v or "").strip()
    if not APP_ID_RE.match(v):
        raise AvError("The Application ID is the value shown in Apex Central's Automation API Access Settings "
                      "(letters, digits and dashes).")
    return v


def clean_key(v):
    v = (v or "").strip()
    if not 16 <= len(v) <= 200 or any(c.isspace() or ord(c) < 33 for c in v):
        raise AvError("The API key looks wrong: copy it again from Apex Central's Automation API Access Settings.")
    return v


def clean_ca(pem):
    pem = (pem or "").strip()
    if not pem:
        return None
    if "-----BEGIN CERTIFICATE-----" not in pem or len(pem) > 20000 or "PRIVATE KEY" in pem:
        raise AvError("The CA certificate must be PEM text (-----BEGIN CERTIFICATE-----), and never a private key.")
    try:
        ssl.create_default_context(cadata=pem)
    except ssl.SSLError:
        raise AvError("The CA certificate could not be read.")
    return pem


# ---------------------------------------------------------------------------
# Apex Central request signing
# ---------------------------------------------------------------------------

def _b64url(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def checksum(method, raw_url, api_headers="", body=""):
    """SHA-256 of METHOD|lowercase path and query|"API" headers|body, base64."""
    s = method.upper() + "|" + raw_url.lower() + "|" + api_headers + "|" + body
    return base64.b64encode(hashlib.sha256(s.encode("utf-8")).digest()).decode()


def token(app_id, api_key, method, raw_url, body="", now=None):
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {"appid": app_id, "iat": now if now is not None else time.time(), "version": "V1",
               "checksum": checksum(method, raw_url, "", body)}
    signing = (_b64url(json.dumps(header, separators=(",", ":")).encode()) + "."
               + _b64url(json.dumps(payload, separators=(",", ":")).encode()))
    sig = hmac.new(api_key.encode(), signing.encode(), hashlib.sha256).digest()
    return signing + "." + _b64url(sig)


class _PinnedHTTPS(http.client.HTTPSConnection):
    """HTTPS to an address already checked, with the certificate verified
    against the console's host name (SNI and name check use the host)."""

    def __init__(self, host, port, ip, context, timeout):
        super().__init__(host, port, context=context, timeout=timeout)
        self._ip = str(ip)

    def connect(self):
        sock = socket.create_connection((self._ip, self.port), self.timeout)
        self.sock = self._context.wrap_socket(sock, server_hostname=self.host)


def _proxy():
    p = urllib.parse.urlsplit(os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy") or "")
    return (p.hostname, p.port or 3128) if p.hostname else None


def _context(console):
    ctx = ssl.create_default_context(cadata=console["ca_pem"]) if console.get("ca_pem") else ssl.create_default_context()
    if console.get("ca_pem") and hasattr(ssl, "VERIFY_X509_STRICT"):
        # Many Apex Central servers use an IIS self-signed certificate without the key-usage extension that
        # strict RFC 5280 checking demands. For the CA the admin pasted, that one rule is relaxed; the chain,
        # the expiry and the host name are still verified.
        ctx.verify_flags &= ~ssl.VERIFY_X509_STRICT
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.check_hostname, ctx.verify_mode = True, ssl.CERT_REQUIRED
    return ctx


def _fail_text(e):
    """A plain reason, without echoing what a far end said."""
    if isinstance(e, ssl.SSLCertVerificationError):
        return (f"The console's certificate is not trusted ({e.verify_message}): paste its CA certificate (PEM) in the "
                "console's settings. Verification is never turned off.")
    if isinstance(e, ssl.SSLError):
        return "The TLS connection to the console failed (it must offer TLS 1.2 or newer on this port)."
    if isinstance(e, (socket.timeout, TimeoutError)):
        return "The console did not answer in time: check the address, the port and the firewall from PATCH-01."
    if isinstance(e, ConnectionRefusedError):
        return "The console refused the connection on this port: check the port."
    if isinstance(e, OSError):
        return "Cannot reach the console: check the address, the port and the firewall from PATCH-01."
    return "The console's answer could not be read."


def _get(console, api_key, raw_url):
    """One GET to an Apex Central console. Only GET exists here."""
    u = urllib.parse.urlsplit(clean_url(console["url"]))
    host, port = u.hostname, u.port or 443
    deadline = time.monotonic() + DEADLINE
    headers = {"Authorization": "Bearer " + token(console["app_id"], api_key, "GET", raw_url),
               "Content-Type": "application/json;charset=utf-8", "Accept": "application/json",
               "User-Agent": "PATCH-01 inventory (read-only)", "Host": u.netloc}
    ctx = _context(console)
    try:
        if console.get("use_proxy") and _proxy():
            ph, pp = _proxy()
            resolve(host, port)                                  # checked here too; the proxy connects
            conn = http.client.HTTPSConnection(ph, pp, context=ctx, timeout=TIMEOUT)
            conn.set_tunnel(host, port)
        else:
            conn = _PinnedHTTPS(host, port, resolve(host, port)[0], ctx, TIMEOUT)
        try:
            conn.request("GET", raw_url, headers=headers)
            r = conn.getresponse()
            if r.status in (301, 302, 303, 307, 308):
                raise AvError(f"Apex Central answered with a redirect ({r.status}): use the console's own https address.")
            if r.status == 401:
                raise AvError("Apex Central refused the request (401): check the Application ID and API key, that the "
                              "application is enabled in Automation API Access Settings, and that the clocks on "
                              "PATCH-01 and Apex Central agree (the token expires after the communication time-out).")
            if r.status == 403:
                raise AvError("Apex Central refused the request (403): the API account is not allowed to list agents.")
            if r.status == 404:
                raise AvError("Apex Central has no Automation API at this address (404): check the URL.")
            if r.status != 200:
                raise AvError(f"Apex Central answered HTTP {r.status}.")
            chunks, size = [], 0
            while True:
                if time.monotonic() > deadline:
                    raise AvError(f"Apex Central took longer than {DEADLINE} seconds to answer.")
                b = r.read(65536)
                if not b:
                    break
                size += len(b)
                if size > MAX_RESPONSE:
                    raise AvError(f"Apex Central's answer is larger than {MAX_RESPONSE // 2 ** 20} MB.")
                chunks.append(b)
        finally:
            conn.close()
    except AvError:
        raise
    except Exception as e:  # noqa: BLE001 - every network failure becomes one plain message
        log.info("antivirus: %s: %s", console.get("url"), type(e).__name__)
        raise AvError(_fail_text(e))
    try:
        doc = json.loads(b"".join(chunks).decode("utf-8-sig"))
    except Exception:  # noqa: BLE001 - not JSON, too deep, bad encoding
        raise AvError("Apex Central's answer is not JSON: check the URL points at Apex Central.")
    if not isinstance(doc, dict):
        raise AvError("Apex Central's answer has an unexpected shape.")
    if doc.get("result_code") not in (1, "1"):
        raise AvError("Apex Central reported an error (result code "
                      + re.sub(r"[^0-9-]", "", str(doc.get("result_code")))[:6] + "): check the API account's rights.")
    return doc


# ---------------------------------------------------------------------------
# Agents
# ---------------------------------------------------------------------------

def _strs(v, n=16, size=80):
    if isinstance(v, str):
        v = [v]
    if not isinstance(v, list):
        return []
    return [str(x).strip()[:size] for x in v[:n] if isinstance(x, (str, int)) and str(x).strip()]


def product_name(code):
    c = str(code or "")
    for rx, name in PRODUCTS:
        if rx.search(c):
            return name
    return re.sub(r"^SLF_PRODUCT_", "", c).replace("_", " ").title()[:60] or "Unknown"


def parse_agents(doc):
    rc = doc.get("result_content") or []
    if not isinstance(rc, list):
        raise AvError("Apex Central's agent list has an unexpected shape.")
    out = []
    for a in rc[:MAX_AGENTS]:
        if not isinstance(a, dict) or not a.get("entity_id"):
            continue
        ips = [ip for ip in _strs(a.get("ip_address_list"), 16, 45) if _is_ip(ip)]
        out.append({
            "entity_id": str(a["entity_id"])[:120],
            "product": str(a.get("product") or "")[:80],
            "host_name": str(a.get("host_name") or "")[:255],
            "ad_domain": str(a.get("ad_domain") or "")[:255] or None,
            "folder_path": str(a.get("folder_path") or "")[:500] or None,
            "ip_addresses": ips,
            "mac_addresses": [m for m in _strs(a.get("mac_address_list"), 16, 32)
                              if re.fullmatch(r"[0-9A-Fa-f]{2}([:-][0-9A-Fa-f]{2}){5}", m)],
            "managing_server_id": str(a.get("managing_server_id") or "")[:120] or None,
            "isolation_status": str(a.get("isolation_status") or "")[:40] or None,
            "capabilities": _strs(a.get("capabilities"), 40, 60),
            **_health_fields(a),
        })
    return out


# Fields some Apex Central versions add to the agent list. They are not in Trend
# Micro's published reference, so they are recognised by name and used only when
# present; the names each console sends are recorded (fields_seen).
PATTERN_KEY = re.compile(r"(virus|vsapi|smart.?scan|scan|av|malware)?.?pattern.?(ver|version)?$|^pattern", re.I)
CONNECTED_KEY = re.compile(r"last.?(connect|connection|contact|communicat|seen|online|check.?in)", re.I)
ONLINE_KEY = re.compile(r"^(is.?online|online|connection.?status|online.?status|connect.?status)$", re.I)
VERSION_RE = re.compile(r"^\d{1,4}(\.\d{1,6}){1,3}$")


def _when(v):
    """An ISO date, an epoch (seconds or milliseconds) or 'MM/DD/YYYY hh:mm:ss' -> aware datetime, else None."""
    from datetime import datetime, timezone
    try:
        if isinstance(v, (int, float)) or (isinstance(v, str) and re.fullmatch(r"\d{9,13}", v.strip())):
            n = float(v)
            n = n / 1000 if n > 1e11 else n
            return datetime.fromtimestamp(n, timezone.utc) if 946684800 < n < 4102444800 else None
        t = str(v).strip()[:40]
        for fmt in ("%m/%d/%Y %H:%M:%S", "%Y/%m/%d %H:%M:%S", "%Y-%m-%d %H:%M:%S"):
            try:
                return datetime.strptime(t, fmt).replace(tzinfo=timezone.utc)
            except ValueError:
                pass
        d = datetime.fromisoformat(t.replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except (ValueError, OverflowError, OSError):
        return None


def _health_fields(a):
    out = {"pattern_version": None, "last_connected": None, "online": None}
    for k, v in a.items():
        if not isinstance(k, str) or isinstance(v, (dict, list)) or v in (None, ""):
            continue
        if out["pattern_version"] is None and PATTERN_KEY.search(k) and VERSION_RE.match(str(v).strip()):
            out["pattern_version"] = str(v).strip()[:30]
        elif out["last_connected"] is None and CONNECTED_KEY.search(k):
            out["last_connected"] = _when(v)
        elif out["online"] is None and ONLINE_KEY.match(k):
            w = str(v).strip().lower()
            out["online"] = True if w in ("true", "1", "online", "connected", "yes") else \
                False if w in ("false", "0", "offline", "disconnected", "no") else None
    return out


def fields_seen(doc):
    """The field names a console sends for its agents (names only, never values)."""
    names = set()
    for a in (doc.get("result_content") or [])[:200]:
        if isinstance(a, dict):
            names.update(k for k in a if isinstance(k, str) and re.fullmatch(r"[A-Za-z0-9_]{1,40}", k))
    return sorted(names)[:80]


def pattern_key(v):
    """'18.555.00' -> (18, 555, 0) for comparing definition versions."""
    return tuple(int(x) for x in str(v).split(".")) if v and VERSION_RE.match(str(v)) else None


def _is_ip(s):
    """A usable address for matching: not loopback, link-local or unspecified."""
    try:
        return not _blocked(ipaddress.ip_address(s))
    except ValueError:
        return False


def list_agents(console, api_key, with_fields=False):
    doc = _get(console, api_key, AGENTS_PATH)
    agents = parse_agents(doc)
    rc = doc.get("result_content") or []
    if with_fields:
        return agents, len(rc) > MAX_AGENTS, fields_seen(doc)
    return agents, len(rc) > MAX_AGENTS


def summary(agents):
    prods = {}
    for a in agents:
        k = product_name(a["product"])
        prods[k] = prods.get(k, 0) + 1
    return {"agents": len(agents), "products": sorted(prods.items(), key=lambda kv: -kv[1]),
            "isolated": sum(1 for a in agents if (a["isolation_status"] or "").lower() not in ("", "normal", "none"))}


# ---------------------------------------------------------------------------
# Stored consoles
# ---------------------------------------------------------------------------

VIEW_COLS = """id, name, vendor, url, app_id, ca_pem IS NOT NULL AS has_ca, use_proxy, enabled, created_by, created_at,
               updated_by, updated_at, last_test_at, last_test_ok, last_test_msg, last_sync_at, last_sync_ok,
               last_sync_msg, agents, sync_requested_at, fields_seen"""


def masked(app_id):
    a = app_id or ""
    return a[:4] + "…" + a[-4:] if len(a) > 10 else "…"


def consoles(conn):
    rows = [dict(r) for r in conn.execute(f"SELECT {VIEW_COLS} FROM av_consoles ORDER BY name").fetchall()]
    for r in rows:
        r["app_id"] = masked(r["app_id"])       # the full ID and the key never go to the browser
    return rows


def sync_one(conn, cid):
    c = conn.execute("SELECT * FROM av_consoles WHERE id = %s", (cid,)).fetchone()
    if not c:
        return 0
    c = dict(c)
    conn.commit()                                # no transaction held while Apex Central answers
    try:
        agents, truncated, seen = list_agents(c, decrypt(c["api_key_enc"]), with_fields=True)
    except Exception as e:  # noqa: BLE001 - any failure is recorded, and the request cleared
        msg = str(e) if isinstance(e, AvError) else "The console's answer could not be read."
        if not isinstance(e, AvError):
            log.warning("antivirus: sync of %s failed: %s", c["name"], type(e).__name__)
        conn.rollback()
        conn.execute("""UPDATE av_consoles SET last_sync_at = now(), last_sync_ok = false, last_sync_msg = %s,
                               sync_requested_at = NULL WHERE id = %s""", (msg[:400], cid))
        conn.commit()
        return 0
    rows = [(cid, a["entity_id"], a["product"], a["host_name"], a["ad_domain"], a["folder_path"], a["ip_addresses"],
             a["mac_addresses"], a["managing_server_id"], a["isolation_status"], a["capabilities"],
             a["pattern_version"], a["last_connected"], a["online"]) for a in agents]
    with conn.transaction():
        with conn.cursor() as cur:
            cur.executemany(
                """INSERT INTO av_agents (console_id, entity_id, product, host_name, ad_domain, folder_path, ip_addresses,
                                          mac_addresses, managing_server_id, isolation_status, capabilities,
                                          pattern_version, last_connected, online, last_seen)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, now())
                   ON CONFLICT (console_id, entity_id) DO UPDATE SET product = EXCLUDED.product,
                     host_name = EXCLUDED.host_name, ad_domain = EXCLUDED.ad_domain, folder_path = EXCLUDED.folder_path,
                     ip_addresses = EXCLUDED.ip_addresses, mac_addresses = EXCLUDED.mac_addresses,
                     managing_server_id = EXCLUDED.managing_server_id, isolation_status = EXCLUDED.isolation_status,
                     capabilities = EXCLUDED.capabilities, pattern_version = EXCLUDED.pattern_version,
                     last_connected = EXCLUDED.last_connected, online = EXCLUDED.online, last_seen = now()""", rows)
        if not truncated:
            # Agents the console no longer lists are kept for a week (shown as "not listed"), then dropped
            conn.execute("DELETE FROM av_agents WHERE console_id = %s AND last_seen < now() - interval '7 days'", (cid,))
        conn.execute("""UPDATE av_consoles SET last_sync_at = now(), last_sync_ok = true, last_sync_msg = %s, agents = %s,
                               sync_requested_at = NULL, fields_seen = %s WHERE id = %s""",
                     (f"{len(agents)} agents" + (f" (only the first {MAX_AGENTS} are kept)" if truncated else ""),
                      len(agents), seen, cid))
    conn.commit()
    return len(agents)


def due(conn):
    return [r["id"] for r in conn.execute(
        """SELECT id FROM av_consoles WHERE enabled
              AND (sync_requested_at IS NOT NULL OR last_sync_at IS NULL
                   OR last_sync_at < now() - make_interval(mins => %s))
            ORDER BY sync_requested_at NULLS LAST, last_sync_at NULLS FIRST""", (SYNC_MINUTES,)).fetchall()]


# ---------------------------------------------------------------------------
# Coverage: our machines with and without an antivirus agent
# ---------------------------------------------------------------------------

def coverage(conn):
    """Every agent with the machine it is in our inventory (by address, full
    name, then short name), and the machines with no agent at all."""
    from . import cve_impact
    assets = cve_impact.build_assets(conn)
    agents = [dict(r) for r in conn.execute(
        """SELECT a.*, c.name AS console,
                  -- not listed any more by the console's last good read, or not read for two days
                  -- (console off or failing): shown, but not counted as protection
                  (NOT c.enabled OR a.last_seen < now() - interval '48 hours'
                   OR coalesce(c.last_sync_ok AND a.last_seen < c.last_sync_at - interval '1 minute', false)) AS not_reported
             FROM av_agents a JOIN av_consoles c ON c.id = a.console_id
            ORDER BY lower(a.host_name)""").fetchall()]
    covered = set()
    for a in agents:
        hit = None
        for ip in a["ip_addresses"] or []:
            hit = assets.by_ip.get(ip)
            if hit:
                break
        if not hit and a["host_name"]:
            hit = assets.lookup(a["host_name"])
        a["product_name"] = product_name(a["product"])
        if hit and not a["not_reported"]:
            covered.add(id(hit))
        if hit:
            a["asset"] = {"name": hit["name"], "os": hit["os"], "family": hit["family"], "sources": hit["sources"],
                          "agent": hit.get("agent"), "agent_seen": hit.get("agent_seen"),
                          "wsus_seen": hit.get("wsus_seen"), "power": hit.get("power")}
        else:
            a["asset"] = None
    unprotected = [{"name": x["name"], "ips": x["ips"], "os": x["os"], "family": x["family"], "sources": x["sources"]}
                   for x in assets.items
                   if id(x) not in covered and x["family"] in ("windows", "linux", "unknown")
                   and any(s in x["sources"] for s in ("agent", "WSUS", "vCenter guest"))]
    return agents, unprotected
