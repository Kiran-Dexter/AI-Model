"""
PATCH-01 : patch platform API

Endpoints fall into three groups:

  /api/v1/agent/*   called by agents on managed hosts, bearer-token auth
  /api/v1/admin/*   called by operators, basic auth
  /api/v1/health    unauthenticated liveness

Design notes:

  * Agents authenticate with a per-host bearer token obtained by redeeming a
    single-use enrollment token. Only the SHA-256 of each token is stored, so
    a database dump does not yield working credentials.

  * The agent may only submit data about ITSELF. The host identity comes from
    the authenticated token, never from the request body, so agent A cannot
    overwrite agent B's inventory.

  * Commands returned to agents are a bounded verb plus JSON parameters.
    There is no endpoint that accepts or returns a shell command.

  * Inventory replaces the package set wholesale inside a transaction. A diff
    based approach loses packages removed outside the agent's knowledge.

  * Package versions are stored as separate epoch/version/release columns.
    Epoch is parsed explicitly because dropping it silently inverts version
    comparisons later.
"""

import hashlib
import hmac
import ipaddress
import json
import logging
import os
import re
import secrets
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import psycopg
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

from fastapi import (Body, Depends, FastAPI, File, Form, Header, HTTPException,
                     Request, UploadFile, status)
from fastapi.responses import PlainTextResponse
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel, Field, field_validator

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
logging.basicConfig(
    level=LOG_LEVEL,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("patchapi")

DB_HOST = os.environ.get("PATCHDB_HOST", "postgres")
DB_PORT = int(os.environ.get("PATCHDB_PORT", "5432"))
DB_NAME = os.environ.get("PATCHDB_NAME", "patchdb")
DB_USER = os.environ.get("PATCHDB_USER", "patchapi")
DB_PASS = os.environ.get("PATCHDB_PASSWORD", "")

ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")

# How long before a silent host is considered stale. Must match what the
# applicability engine uses, or a host can read as compliant while its
# inventory is too old to judge.
STALE_HOURS = int(os.environ.get("STALE_HOURS", "24"))

# A host is online if it checked in within this many minutes. Agents check in
# every 5 minutes with up to a minute of jitter, so 15 tolerates two misses.
ONLINE_MINUTES = int(os.environ.get("ONLINE_MINUTES", "15"))

# Bounds on submitted data. A host reporting 200k packages is a bug or an
# attack, not a real inventory.
MAX_PACKAGES = int(os.environ.get("MAX_PACKAGES", "20000"))
MIN_PLAUSIBLE_PACKAGES = 50

ENROLL_TOKEN_TTL_HOURS = int(os.environ.get("ENROLL_TOKEN_TTL_HOURS", "24"))

app = FastAPI(
    title="PATCH-01 Patch Platform API",
    version="1.0.0",
    docs_url="/api/v1/docs",
    openapi_url="/api/v1/openapi.json",
)


from fastapi.exceptions import RequestValidationError  # noqa: E402


@app.exception_handler(RequestValidationError)
async def _validation_error(request: Request, exc: RequestValidationError):
    """A rejected field is reported by name and reason only: never echo what
    was sent, which may be a password or an API key."""
    errs = [{k: e.get(k) for k in ("loc", "msg", "type") if k in e} for e in exc.errors()]
    return JSONResponse(status_code=422, content={"detail": errs})

pool: Optional[ConnectionPool] = None


@app.on_event("startup")
def startup() -> None:
    global pool
    conninfo = (
        f"host={DB_HOST} port={DB_PORT} dbname={DB_NAME} "
        f"user={DB_USER} password={DB_PASS} connect_timeout=10"
    )
    pool = ConnectionPool(conninfo, min_size=2, max_size=10, open=True,
                          kwargs={"row_factory": dict_row})
    log.info("connected to %s@%s:%s/%s", DB_USER, DB_HOST, DB_PORT, DB_NAME)
    from . import auth
    try:
        with pool.connection() as conn:
            if auth.bootstrap_admin(conn, ADMIN_PASSWORD):
                log.info("created the admin user from ADMIN_PASSWORD")
    except Exception as e:  # noqa: BLE001 - schema 009 may not be applied yet
        log.warning("could not bootstrap the admin user: %s", e)


@app.on_event("shutdown")
def shutdown() -> None:
    if pool:
        pool.close()


@contextmanager
def db():
    if pool is None:
        raise HTTPException(status_code=503, detail="database pool not ready")
    with pool.connection() as conn:
        yield conn


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def sha256(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def now() -> datetime:
    return datetime.now(timezone.utc)


def client_ip(request: Request) -> Optional[str]:
    """Real client address, trusting NGINX's X-Forwarded-For.

    NGINX is the only thing that can reach this service, so its header is
    trustworthy here. The leftmost entry is the original client.
    """
    xff = request.headers.get("x-forwarded-for")
    if xff:
        candidate = xff.split(",")[0].strip()
        try:
            ipaddress.ip_address(candidate)
            return candidate
        except ValueError:
            pass
    return request.client.host if request.client else None


def audit(conn, actor: str, actor_type: str, action: str,
          host_id: Optional[str] = None, object_type: Optional[str] = None,
          object_id: Optional[str] = None, detail: Optional[Dict] = None,
          source_ip: Optional[str] = None) -> None:
    """Append to the audit log. Never raises: a failed audit write must not
    silently succeed, but it also must not lose the caller's work, so it is
    logged loudly and re-raised only on programming errors."""
    conn.execute(
        """INSERT INTO audit_log
             (actor, actor_type, action, host_id, object_type, object_id,
              detail, source_ip)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
        (actor, actor_type, action, host_id, object_type, object_id,
         json.dumps(detail or {}), source_ip),
    )


NEVRA_RE = re.compile(r"^[A-Za-z0-9._+\-~^]+$")


def parse_evr(version_string: str) -> tuple:
    """Split an RPM or DEB version string into (epoch, version, release).

    Epoch is returned explicitly, defaulting to 0 rather than None, because
    a dropped epoch silently inverts comparisons. RPM release is the part
    after the last '-'; DEB revision is treated the same way.
    """
    s = (version_string or "").strip()
    epoch = 0
    if ":" in s:
        head, _, s = s.partition(":")
        try:
            epoch = int(head)
        except ValueError:
            epoch = 0
    if "-" in s:
        version, _, release = s.rpartition("-")
    else:
        version, release = s, ""
    return epoch, version, release


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------

basic = HTTPBasic(auto_error=False)


def _challenge(request: Request) -> dict:
    # The dashboard has its own sign-in form. Sending WWW-Authenticate to it
    # would also pop the browser's native dialog, so omit it for its requests.
    return ({} if request.headers.get("x-requested-with") == "patch01-dashboard"
            else {"WWW-Authenticate": "Basic"})


def _resolve_user(request: Request, creds: Optional[HTTPBasicCredentials]) -> dict:
    """The signed-in user, from a session token (the console) or HTTP Basic
    (scripts on PATCH-01). Both are checked against the users table."""
    from . import auth
    header = request.headers.get("authorization") or ""
    with db() as conn:
        if header.lower().startswith("bearer "):
            u = auth.session_user(conn, header[7:].strip())
            if u:
                return u
            raise HTTPException(status_code=401, detail="Your session has ended. Sign in again.",
                                headers=_challenge(request))
        if creds is not None:
            try:
                return auth.authenticate(conn, creds.username, creds.password)
            except auth.LoginError as e:
                raise HTTPException(status_code=401, detail=str(e), headers=_challenge(request))
    raise HTTPException(status_code=401, detail="authentication required",
                        headers=_challenge(request))


# Which module each part of the API belongs to. A user needs at least one of
# the listed modules (admins have all). Paths not listed here need no module:
# sign-in, the user's own account, admin pages (role-checked), the assistant
# (which filters its own queries by module), and the public sign-in data.
MODULE_RULES = [
    # E-mailing: each report checks its own modules (report_jobs.allowed); a table goes only to configured recipients
    (re.compile(r"^/api/v1/reports/(email|email-options|email-table)$"), {"patch", "inventory", "lifecycle"}),
    (re.compile(r"^/api/v1/inventory/"), {"inventory"}),
    (re.compile(r"^/api/v1/admin/vmware/"), {"inventory", "patch"}),
    (re.compile(r"^/api/v1/(software|admin/software)(/|$)"), {"lifecycle"}),
    # Which kinds of change each module may see and make is checked per change (_change_ok)
    (re.compile(r"^/api/v1/changes(/|$)"), {"patch", "inventory", "lifecycle"}),
    (re.compile(r"^/api/v1/console/stream$"), {"patch", "lifecycle"}),
    (re.compile(r"^/api/v1/admin/compliance$"), {"patch", "lifecycle"}),
    (re.compile(r"^/api/v1/admin/hosts/[^/]+/software$"), {"patch", "inventory", "lifecycle"}),
    (re.compile(r"^/api/v1/admin/audit$"), {"patch", "inventory", "lifecycle"}),
    (re.compile(r"^/api/v1/antivirus(/|$)"), {"inventory", "patch"}),
    (re.compile(r"^/api/v1/(admin/(hosts|advisories|agents|applicability|assessments|compliance|cve-intel|"
                r"fleet-summary|llm|mark-stale)|hardening|reports|wsus|dashboard|feeds/news|impact|servers|insights)(/|$)"), {"patch"}),
]


def _kind_modules(kind):
    """The modules that may see and make a change of this kind."""
    if kind == "software":
        return {"lifecycle"}
    if str(kind).startswith("vm_"):
        return {"patch", "inventory"}
    return {"patch"}


def _change_ok(request, kind):
    from . import auth
    if not (_kind_modules(kind) & set(auth.user_modules(request.state.user))):
        raise HTTPException(403, "Your account does not have access to this kind of change. Ask an admin (Admin > Access).")


def _allowed_kinds(request):
    from . import auth
    mods = set(auth.user_modules(request.state.user))
    kinds = ["patch", "software", "vm_snapshot_create", "vm_snapshot_remove", "vm_snapshot_revert",
             "vm_power_on", "vm_guest_shutdown", "vm_guest_restart"]
    return [k for k in kinds if _kind_modules(k) & mods]


def module_for_path(path):
    for rx, mods in MODULE_RULES:
        if rx.match(path):
            return mods
    return None


def _require(needed: str):
    """A dependency admitting users whose role is at least `needed`, and who
    may use the module the requested path belongs to.
    Returns the username, which endpoints record as the actor."""
    from . import auth

    def dep(request: Request, creds: Optional[HTTPBasicCredentials] = Depends(basic)) -> str:
        u = _resolve_user(request, creds)
        if u.get("must_change_password") and not request.url.path.startswith("/api/v1/auth/"):
            raise HTTPException(status_code=403, detail="password_change_required")
        if not auth.role_at_least(u["role"], needed):
            raise HTTPException(status_code=403,
                                detail=f"This needs the {needed} role; you are signed in as {u['role']}.")
        mods = module_for_path(request.url.path)
        if mods and not (mods & set(auth.user_modules(u))):
            raise HTTPException(status_code=403,
                                detail="Your account does not have access to this part of the console. "
                                       "Ask an admin (Admin > Access).")
        request.state.user = u
        return u["username"]
    return dep


require_viewer = _require("viewer")
require_operator = _require("operator")
require_admin = _require("admin")


class AgentIdentity(BaseModel):
    host_id: str
    hostname: str
    host_group: str


def require_agent(
    request: Request,
    authorization: Optional[str] = Header(default=None),
) -> AgentIdentity:
    """Resolve the calling agent from its bearer token.

    The host identity comes from here and nowhere else. No endpoint accepts a
    host_id from the request body, which is what prevents one agent writing
    another's data.
    """
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="bearer token required")
    token = authorization[7:].strip()
    if not token:
        raise HTTPException(status_code=401, detail="empty token")

    th = sha256(token)
    with db() as conn:
        row = conn.execute(
            """SELECT id, hostname, host_group, status
                 FROM hosts
                WHERE token_hash = %s""",
            (th,),
        ).fetchone()

        if not row:
            raise HTTPException(status_code=401, detail="unknown or revoked token")
        if row["status"] == "decommissioned":
            raise HTTPException(status_code=403, detail="host is decommissioned")

        return AgentIdentity(
            host_id=str(row["id"]),
            hostname=row["hostname"],
            host_group=row["host_group"] or "default",
        )


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class EnrollRequest(BaseModel):
    enrollment_token: str = Field(min_length=16, max_length=128)
    machine_id: str = Field(min_length=8, max_length=128)
    hostname: str = Field(min_length=1, max_length=253)
    fqdn: Optional[str] = Field(default=None, max_length=253)
    os_id: str = Field(max_length=32)
    os_version: str = Field(max_length=32)
    arch: str = Field(max_length=16)
    pkg_manager: str = Field(max_length=8)
    agent_version: str = Field(max_length=32)

    @field_validator("hostname", "fqdn")
    @classmethod
    def valid_hostname(cls, v):
        if v is None:
            return v
        # Lowercase and validate: uppercase hostnames break TLS SAN matching
        # and some apt tooling later.
        v = v.strip().lower()
        if not re.match(r"^[a-z0-9]([a-z0-9.\-]{0,251}[a-z0-9])?$", v):
            raise ValueError("invalid hostname")
        return v

    @field_validator("pkg_manager")
    @classmethod
    def valid_pkg_manager(cls, v):
        if v not in ("dnf", "yum", "apt", "wua"):
            raise ValueError("pkg_manager must be dnf, yum, apt or wua")
        return v

    @field_validator("os_id")
    @classmethod
    def valid_os(cls, v):
        v = v.strip().lower()
        if not re.match(r"^[a-z0-9_\-]+$", v):
            raise ValueError("invalid os_id")
        return v


class EnrollResponse(BaseModel):
    host_id: str
    agent_token: str
    checkin_interval_sec: int


class PackageIn(BaseModel):
    name: str = Field(max_length=256)
    version: str = Field(max_length=128)
    arch: str = Field(default="noarch", max_length=32)
    from_repo: Optional[str] = Field(default=None, max_length=128)

    @field_validator("name", "arch")
    @classmethod
    def safe_chars(cls, v):
        if not NEVRA_RE.match(v):
            raise ValueError(f"unsafe characters in {v!r}")
        return v


class InventoryIn(BaseModel):
    collected_at: datetime
    kernel_running: str = Field(max_length=128)
    kernel_latest: Optional[str] = Field(default=None, max_length=128)
    reboot_required: bool = False
    reboot_reason: Optional[str] = Field(default=None, max_length=512)
    os_version: Optional[str] = Field(default=None, max_length=32)
    agent_version: Optional[str] = Field(default=None, max_length=32)
    duration_ms: Optional[int] = None
    boot_time: Optional[datetime] = None
    hardware_uuid: Optional[str] = Field(default=None, max_length=36,
                                         pattern=r"^[0-9a-fA-F-]{32,36}$")
    packages: List[PackageIn]

    @field_validator("packages")
    @classmethod
    def bounded(cls, v):
        if len(v) > MAX_PACKAGES:
            raise ValueError(f"too many packages ({len(v)} > {MAX_PACKAGES})")
        if not v:
            raise ValueError("package list is empty")
        return v


class CheckinIn(BaseModel):
    agent_version: Optional[str] = Field(default=None, max_length=32)
    kernel_running: Optional[str] = Field(default=None, max_length=128)
    reboot_required: Optional[bool] = None
    # Agent 1.1.0+. Optional so older agents keep working unchanged.
    boot_time: Optional[datetime] = None
    # Agent 1.2.0+: links the server to its VM in vCenter
    hardware_uuid: Optional[str] = Field(default=None, max_length=36,
                                         pattern=r"^[0-9a-fA-F-]{32,36}$")


class CommandOut(BaseModel):
    id: str
    verb: str
    params: Dict[str, Any]
    job_id: Optional[str] = None


class CommandResultIn(BaseModel):
    ok: bool
    result: Dict[str, Any] = Field(default_factory=dict)
    # Free-form message, bounded so a runaway agent cannot fill the database
    message: Optional[str] = Field(default=None, max_length=8192)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/api/v1/health")
def health():
    try:
        with db() as conn:
            conn.execute("SELECT 1").fetchone()
        return {"status": "ok", "database": "connected"}
    except Exception as e:
        log.error("health check failed: %s", e)
        return JSONResponse(
            status_code=503,
            content={"status": "degraded", "database": "unreachable"},
        )


# ---------------------------------------------------------------------------
# Agent endpoints
# ---------------------------------------------------------------------------

@app.post("/api/v1/agent/enroll", response_model=EnrollResponse)
def enroll(request: Request, body: EnrollRequest):
    """Redeem a single-use enrollment token for a per-host agent token.

    machine_id is the identity key rather than hostname, so a host that is
    renamed keeps its history instead of appearing as a new machine.
    """
    ip = client_ip(request)
    eth = sha256(body.enrollment_token)

    with db() as conn:
        with conn.transaction():
            tok = conn.execute(
                """SELECT id, host_group, expires_at, used_at, revoked_at
                     FROM enrollment_tokens
                    WHERE token_hash = %s
                    FOR UPDATE""",
                (eth,),
            ).fetchone()

            if not tok:
                log.warning("enroll rejected: unknown token from %s", ip)
                raise HTTPException(status_code=401, detail="invalid enrollment token")
            if tok["revoked_at"]:
                raise HTTPException(status_code=401, detail="enrollment token revoked")
            if tok["used_at"]:
                raise HTTPException(status_code=409, detail="enrollment token already used")
            if tok["expires_at"] < now():
                raise HTTPException(status_code=401, detail="enrollment token expired")

            agent_token = secrets.token_urlsafe(32)
            ath = sha256(agent_token)

            # Re-enrolment of a known machine keeps its id and history
            existing = conn.execute(
                "SELECT id FROM hosts WHERE machine_id = %s",
                (body.machine_id,),
            ).fetchone()

            os_major = None
            m = re.match(r"^(\d+)", body.os_version or "")
            if m:
                os_major = int(m.group(1))

            if existing:
                host_id = existing["id"]
                conn.execute(
                    """UPDATE hosts
                          SET hostname=%s, fqdn=%s, os_id=%s, os_version=%s,
                              os_major=%s, arch=%s, pkg_manager=%s,
                              agent_version=%s, token_hash=%s,
                              host_group=%s, status='active',
                              enrolled_at=now(), updated_at=now()
                        WHERE id=%s""",
                    (body.hostname, body.fqdn, body.os_id, body.os_version,
                     os_major, body.arch, body.pkg_manager, body.agent_version,
                     ath, tok["host_group"], host_id),
                )
                action = "re_enroll"
            else:
                row = conn.execute(
                    """INSERT INTO hosts
                         (hostname, fqdn, machine_id, os_id, os_version, os_major,
                          arch, pkg_manager, agent_version, token_hash,
                          host_group, status)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'active')
                       RETURNING id""",
                    (body.hostname, body.fqdn, body.machine_id, body.os_id,
                     body.os_version, os_major, body.arch, body.pkg_manager,
                     body.agent_version, ath, tok["host_group"]),
                ).fetchone()
                host_id = row["id"]
                action = "enroll"

            conn.execute(
                """UPDATE enrollment_tokens
                      SET used_at=now(), used_by_host=%s
                    WHERE id=%s""",
                (host_id, tok["id"]),
            )

            audit(conn, actor=body.hostname, actor_type="agent", action=action,
                  host_id=str(host_id), object_type="host",
                  object_id=str(host_id),
                  detail={"os": f"{body.os_id} {body.os_version}",
                          "arch": body.arch,
                          "machine_id": body.machine_id},
                  source_ip=ip)

    log.info("%s: host %s (%s)", action, body.hostname, host_id)
    return EnrollResponse(
        host_id=str(host_id),
        agent_token=agent_token,
        checkin_interval_sec=300,
    )


@app.post("/api/v1/agent/checkin")
def checkin(request: Request, body: CheckinIn,
            agent: AgentIdentity = Depends(require_agent)):
    """Lightweight heartbeat. Returns whether a full inventory is wanted."""
    ip = client_ip(request)
    with db() as conn:
        with conn.transaction():
            conn.execute(
                """UPDATE hosts
                      SET last_checkin=now(), last_run_at=now(), status='active', updated_at=now(),
                          agent_version=COALESCE(%s, agent_version),
                          kernel_running=COALESCE(%s, kernel_running),
                          reboot_required=COALESCE(%s, reboot_required),
                          boot_time=COALESCE(%s, boot_time),
                          agent_ip=COALESCE(%s::inet, agent_ip),
                          hardware_uuid=COALESCE(lower(%s), hardware_uuid)
                    WHERE id=%s""",
                (body.agent_version, body.kernel_running,
                 body.reboot_required, body.boot_time, ip, body.hardware_uuid,
                 agent.host_id),
            )
            row = conn.execute(
                "SELECT last_inventory FROM hosts WHERE id=%s",
                (agent.host_id,),
            ).fetchone()

    last_inv = row["last_inventory"] if row else None
    want_inventory = last_inv is None or (now() - last_inv) > timedelta(hours=12)

    return {
        "ok": True,
        "want_inventory": want_inventory,
        "checkin_interval_sec": 300,
    }


@app.post("/api/v1/agent/inventory")
def submit_inventory(request: Request, body: InventoryIn,
                     agent: AgentIdentity = Depends(require_agent)):
    """Replace this host's package set.

    Wholesale replacement inside one transaction: a diff would miss packages
    removed outside the agent's knowledge, and a partial write would leave
    the applicability engine reading a half-updated inventory.
    """
    ip = client_ip(request)
    pkgs = body.packages

    # A suspiciously small inventory usually means a broken collector. Record
    # the run as failed rather than destroying good data with bad.
    # Windows lists its OS build plus installed KBs, often fewer than 50, so
    # there the test is one well-formed OS build entry. Which test applies is
    # decided by the server's recorded OS, not by the shape of the report.
    with db() as conn:
        os_row = conn.execute("SELECT os_id FROM hosts WHERE id=%s", (agent.host_id,)).fetchone()
    if (os_row or {}).get("os_id") == "windows":
        builds = [p_ for p_ in pkgs if p_.name == "windows-os-build"]
        plausible = len(builds) == 1 and re.fullmatch(r"10\.0\.\d+\.\d+-0", builds[0].version or "") is not None
        why = (f"expected one windows-os-build entry with a build like 10.0.17763.6414, got "
               f"{len(builds)}" + (f" ({builds[0].version})" if builds else ""))
    else:
        plausible = len(pkgs) >= MIN_PLAUSIBLE_PACKAGES
        why = (f"only {len(pkgs)} packages reported; refusing to replace inventory "
               f"(minimum {MIN_PLAUSIBLE_PACKAGES})")
    if not plausible:
        with db() as conn:
            with conn.transaction():
                conn.execute(
                    """INSERT INTO inventory_runs
                         (host_id, collected_at, package_count, ok, error,
                          agent_version)
                       VALUES (%s,%s,%s,FALSE,%s,%s)""",
                    (agent.host_id, body.collected_at, len(pkgs),
                     f"implausible inventory: {why}",
                     body.agent_version),
                )
                audit(conn, actor=agent.hostname, actor_type="agent",
                      action="inventory_rejected", host_id=agent.host_id,
                      detail={"package_count": len(pkgs)}, source_ip=ip)
        raise HTTPException(status_code=422, detail=why)

    # Hash the sorted set so unchanged inventories can skip recomputation
    canonical = "\n".join(
        sorted(f"{p.name}|{p.arch}|{p.version}" for p in pkgs)
    )
    content_hash = sha256(canonical)

    rows = []
    for p in pkgs:
        epoch, version, release = parse_evr(p.version)
        rows.append((agent.host_id, p.name, p.arch, epoch, version, release,
                     p.version, p.from_repo))

    os_major = None
    if body.os_version:
        m = re.match(r"^(\d+)", body.os_version)
        if m:
            os_major = int(m.group(1))

    with db() as conn:
        with conn.transaction():
            prev = conn.execute(
                """SELECT content_hash FROM inventory_runs
                    WHERE host_id=%s AND ok
                    ORDER BY collected_at DESC LIMIT 1""",
                (agent.host_id,),
            ).fetchone()
            unchanged = bool(prev and prev["content_hash"] == content_hash)

            if not unchanged:
                conn.execute("DELETE FROM host_packages WHERE host_id=%s",
                             (agent.host_id,))
                with conn.cursor() as cur:
                    cur.executemany(
                        """INSERT INTO host_packages
                             (host_id, name, arch, epoch, version, release,
                              full_nevra, from_repo)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
                           ON CONFLICT (host_id, name, arch) DO UPDATE
                             SET epoch=EXCLUDED.epoch,
                                 version=EXCLUDED.version,
                                 release=EXCLUDED.release,
                                 full_nevra=EXCLUDED.full_nevra,
                                 from_repo=EXCLUDED.from_repo""",
                        rows,
                    )
                from . import cve_impact
                cve_impact.inventory_changed(conn)     # Detected CVEs are re-checked against the new versions

            conn.execute(
                """INSERT INTO inventory_runs
                     (host_id, collected_at, package_count, content_hash,
                      agent_version, duration_ms, ok)
                   VALUES (%s,%s,%s,%s,%s,%s,TRUE)""",
                (agent.host_id, body.collected_at, len(pkgs), content_hash,
                 body.agent_version, body.duration_ms),
            )

            conn.execute(
                """UPDATE hosts
                      SET last_inventory=now(), last_checkin=now(),
                          status='active', updated_at=now(),
                          kernel_running=%s,
                          kernel_latest=COALESCE(%s, kernel_latest),
                          reboot_required=%s,
                          reboot_reason=%s,
                          os_version=COALESCE(%s, os_version),
                          os_major=COALESCE(%s, os_major),
                          agent_version=COALESCE(%s, agent_version),
                          boot_time=COALESCE(%s, boot_time),
                          agent_ip=COALESCE(%s::inet, agent_ip),
                          hardware_uuid=COALESCE(lower(%s), hardware_uuid)
                    WHERE id=%s""",
                (body.kernel_running, body.kernel_latest,
                 body.reboot_required, body.reboot_reason,
                 body.os_version, os_major, body.agent_version,
                 body.boot_time, ip, body.hardware_uuid, agent.host_id),
            )

            audit(conn, actor=agent.hostname, actor_type="agent",
                  action="inventory", host_id=agent.host_id,
                  detail={"packages": len(pkgs), "unchanged": unchanged,
                          "kernel": body.kernel_running,
                          "reboot_required": body.reboot_required},
                  source_ip=ip)

    log.info("inventory from %s: %d packages%s", agent.hostname, len(pkgs),
             " (unchanged)" if unchanged else "")
    return {"ok": True, "packages_received": len(pkgs), "unchanged": unchanged}


@app.get("/api/v1/agent/commands", response_model=List[CommandOut])
def poll_commands(agent: AgentIdentity = Depends(require_agent)):
    """Claim pending commands for this host.

    Returns a bounded verb and JSON parameters. There is deliberately no
    verb that carries a shell command: the agent's own implementation maps
    each verb to a fixed action.
    """
    with db() as conn:
        with conn.transaction():
            rows = conn.execute(
                """UPDATE agent_commands
                      SET claimed_at = now()
                    WHERE id IN (
                        SELECT id FROM agent_commands
                         WHERE host_id = %s
                           AND claimed_at IS NULL
                           AND expires_at > now()
                         ORDER BY created_at
                         LIMIT 10
                         FOR UPDATE SKIP LOCKED
                    )
                RETURNING id, verb, params, job_id""",
                (agent.host_id,),
            ).fetchall()
            scans = [(r["params"] or {}).get("scan_id") for r in rows if r["verb"] == "run_hardening_scan"]
            if scans:
                conn.execute(
                    """UPDATE hardening_scans SET state='running', started_at=now(),
                              stage='picked_up', stage_at=now()
                        WHERE id = ANY(%s::uuid[]) AND host_id=%s AND state='queued'""",
                    ([x for x in scans if x], agent.host_id))

    return [
        CommandOut(
            id=str(r["id"]),
            verb=r["verb"],
            params=r["params"] or {},
            job_id=str(r["job_id"]) if r["job_id"] else None,
        )
        for r in rows
    ]


def _with_message(result, message):
    """Keep the agent's message with its result: for a failure it is often the
    only explanation (the Linux agent sends its errors there)."""
    out = dict(result or {})
    if message and "message" not in out:
        out["message"] = str(message)[:4000]
    return out


@app.post("/api/v1/agent/commands/{command_id}/result")
def command_result(command_id: str, body: CommandResultIn,
                   request: Request,
                   agent: AgentIdentity = Depends(require_agent)):
    """Report the outcome of a claimed command.

    Scoped to the calling host, so an agent cannot complete another's work.
    """
    ip = client_ip(request)
    with db() as conn:
        with conn.transaction():
            row = conn.execute(
                """UPDATE agent_commands
                      SET completed_at=now(), ok=%s, result=%s
                    WHERE id=%s AND host_id=%s AND completed_at IS NULL
                RETURNING id, verb, job_id""",
                (body.ok, json.dumps(_with_message(body.result, body.message)), command_id, agent.host_id),
            ).fetchone()

            if not row:
                raise HTTPException(
                    status_code=404,
                    detail="no such pending command for this host",
                )

            if row["verb"] == "run_hardening_scan" and not body.ok:
                conn.execute(
                    """UPDATE hardening_scans SET state='failed', finished_at=now(), error=%s
                        WHERE id = (SELECT (params->>'scan_id')::uuid FROM agent_commands WHERE id=%s)
                          AND host_id=%s AND state IN ('queued','running')""",
                    ((body.result or {}).get("error") or body.message or "scan failed on the server",
                     command_id, agent.host_id))

            # Evidence is written as work progresses, not only at the end, so
            # a job that dies midway still shows how far it got.
            if row["job_id"]:
                stage_map = {
                    "run_precheck": "precheck",
                    "download_packages": "download",
                    "install_packages": "install",
                    "reboot_host": "reboot",
                    "run_postcheck": "postcheck",
                    "report_evidence": "evidence",
                }
                stage = stage_map.get(row["verb"], "queued")
                conn.execute(
                    """INSERT INTO job_events
                         (job_id, host_id, stage, ok, message, detail)
                       VALUES (%s,%s,%s,%s,%s,%s)""",
                    (row["job_id"], agent.host_id, stage, body.ok,
                     body.message, json.dumps(body.result)),
                )

            audit(conn, actor=agent.hostname, actor_type="agent",
                  action=f"command_result:{row['verb']}",
                  host_id=agent.host_id, object_type="command",
                  object_id=str(command_id),
                  detail={"ok": body.ok}, source_ip=ip)

    return {"ok": True}


# ---------------------------------------------------------------------------
# Admin endpoints
# ---------------------------------------------------------------------------

@app.post("/api/v1/admin/enrollment-tokens")
def create_enrollment_token(
    request: Request,
    label: Optional[str] = Body(default=None),
    host_group: str = Body(default="default"),
    ttl_hours: int = Body(default=ENROLL_TOKEN_TTL_HOURS),
    admin: str = Depends(require_admin),
):
    """Issue a single-use enrollment token.

    Returned in full exactly once; only its hash is stored. A shared secret
    baked into an image would let any host that ever held it impersonate any
    other host indefinitely, which is why these expire and are single-use.
    """
    if not 1 <= ttl_hours <= 720:
        raise HTTPException(status_code=422, detail="ttl_hours must be 1..720")

    token = secrets.token_urlsafe(32)
    expires = now() + timedelta(hours=ttl_hours)

    with db() as conn:
        with conn.transaction():
            grp = conn.execute(
                "SELECT name FROM host_groups WHERE name=%s", (host_group,)
            ).fetchone()
            if not grp:
                raise HTTPException(
                    status_code=422,
                    detail=f"unknown host_group '{host_group}'",
                )
            row = conn.execute(
                """INSERT INTO enrollment_tokens
                     (token_hash, label, host_group, expires_at)
                   VALUES (%s,%s,%s,%s) RETURNING id""",
                (sha256(token), label, host_group, expires),
            ).fetchone()
            audit(conn, actor=admin, actor_type="user",
                  action="create_enrollment_token",
                  object_type="enrollment_token", object_id=str(row["id"]),
                  detail={"host_group": host_group, "ttl_hours": ttl_hours,
                          "label": label},
                  source_ip=client_ip(request))

    return {
        "id": str(row["id"]),
        "enrollment_token": token,
        "host_group": host_group,
        "expires_at": expires.isoformat(),
        "note": "shown once; only the hash is stored",
    }


@app.get("/api/v1/admin/hosts")
def list_hosts(status_filter: Optional[str] = None,
               os_id: Optional[str] = None,
               admin: str = Depends(require_viewer)):
    sql = """SELECT id, hostname, fqdn, os_id, os_version, arch, status,
                    kernel_running, reboot_required, host_group,
                    agent_version, last_checkin, last_inventory, enrolled_at
               FROM hosts WHERE TRUE"""
    params: List[Any] = []
    if status_filter:
        sql += " AND status = %s"
        params.append(status_filter)
    if os_id:
        sql += " AND os_id = %s"
        params.append(os_id)
    sql += " ORDER BY hostname"

    with db() as conn:
        rows = conn.execute(sql, params).fetchall()

    return {"count": len(rows), "hosts": [
        {**r, "id": str(r["id"])} for r in rows
    ]}


@app.get("/api/v1/admin/hosts/{host_id}")
def get_host(host_id: str, admin: str = Depends(require_viewer)):
    with db() as conn:
        host = conn.execute(
            """SELECT id, hostname, fqdn, machine_id, os_id, os_version,
                      os_major, arch, pkg_manager, kernel_running,
                      kernel_latest, reboot_required, reboot_reason,
                      agent_version, status, host_group, tags,
                      enrolled_at, last_checkin, last_inventory,
                      boot_time, host(agent_ip) AS agent_ip
                 FROM hosts WHERE id=%s""",
            (host_id,)).fetchone()
        if not host:
            raise HTTPException(status_code=404, detail="host not found")
        pkg_count = conn.execute(
            "SELECT count(*) AS n FROM host_packages WHERE host_id=%s",
            (host_id,)).fetchone()["n"]
        runs = conn.execute(
            """SELECT collected_at, package_count, ok, error
                 FROM inventory_runs WHERE host_id=%s
                ORDER BY collected_at DESC LIMIT 5""",
            (host_id,)).fetchall()

    return {
        "host": {**host, "id": str(host["id"])},
        "package_count": pkg_count,
        "recent_inventory_runs": runs,
    }


@app.get("/api/v1/admin/hosts/{host_id}/packages")
def get_host_packages(host_id: str, name: Optional[str] = None,
                      admin: str = Depends(require_viewer)):
    sql = """SELECT name, arch, epoch, version, release, full_nevra, from_repo
               FROM host_packages WHERE host_id=%s"""
    params: List[Any] = [host_id]
    if name:
        sql += " AND name ILIKE %s"
        params.append(f"%{name}%")
    sql += " ORDER BY name LIMIT 5000"

    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"count": len(rows), "packages": rows}


@app.get("/api/v1/admin/fleet-summary")
def fleet_summary(admin: str = Depends(require_viewer)):
    with db() as conn:
        summary = conn.execute("SELECT * FROM v_fleet_summary").fetchall()
        totals = conn.execute(
            """SELECT count(*) AS hosts,
                      count(*) FILTER (WHERE status='active')  AS active,
                      count(*) FILTER (WHERE status='stale')   AS stale,
                      count(*) FILTER (WHERE status='pending') AS pending,
                      count(*) FILTER (WHERE reboot_required)  AS awaiting_reboot
                 FROM hosts WHERE status <> 'decommissioned'"""
        ).fetchone()
    return {"totals": totals, "by_os": summary}


@app.post("/api/v1/admin/mark-stale")
def mark_stale(admin: str = Depends(require_admin),
               staleness_hours: int = Body(default=STALE_HOURS)):
    """Mark silent hosts stale and their verdicts unknown.

    A host that stops reporting must fail toward attention, never read as
    compliant. Normally driven by the scheduler; exposed here for operators.
    """
    with db() as conn:
        with conn.transaction():
            n = conn.execute("SELECT mark_stale_hosts(%s) AS n",
                             (staleness_hours,)).fetchone()["n"]
            audit(conn, actor=admin, actor_type="user", action="mark_stale",
                  detail={"hosts_marked": n, "staleness_hours": staleness_hours})
    return {"hosts_marked_stale": n}


@app.post("/api/v1/admin/hosts/{host_id}/decommission")
def decommission(host_id: str, request: Request,
                 admin: str = Depends(require_admin)):
    """Retire a host. History is retained: the audit log has no foreign key
    to hosts precisely so decommissioning does not erase evidence."""
    with db() as conn:
        with conn.transaction():
            row = conn.execute(
                """UPDATE hosts
                      SET status='decommissioned', token_hash=NULL,
                          updated_at=now()
                    WHERE id=%s RETURNING hostname""",
                (host_id,),
            ).fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="host not found")
            # Revoking the token is the actual access removal
            conn.execute("DELETE FROM agent_commands WHERE host_id=%s",
                         (host_id,))
            audit(conn, actor=admin, actor_type="user", action="decommission",
                  host_id=host_id, detail={"hostname": row["hostname"]},
                  source_ip=client_ip(request))
    return {"ok": True, "hostname": row["hostname"]}


@app.get("/api/v1/admin/audit")
def get_audit(request: Request, limit: int = 100, host_id: Optional[str] = None,
              action: Optional[str] = None,
              admin: str = Depends(require_viewer)):
    limit = max(1, min(limit, 1000))
    sql = "SELECT * FROM audit_log WHERE TRUE"
    params: List[Any] = []
    is_admin = request.state.user.get("role") == "admin"
    if not is_admin:
        # Other users' questions, sign-ins and account changes are for admins only
        sql += (" AND action !~ '^(chat_|assistant_|login|logout|user_|password|session|feeds_|impact_|"
                "branding|mail_|certificate|credential|av_|report_schedule)'")
    if host_id:
        sql += " AND host_id = %s"
        params.append(host_id)
    if action:
        sql += " AND action = %s"
        params.append(action)
    sql += " ORDER BY occurred_at DESC LIMIT %s"
    params.append(limit)

    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
    if not is_admin:
        for r in rows:
            r["source_ip"] = None
    return {"count": len(rows), "events": rows}


# ---------------------------------------------------------------------------
# Applicability (read-only; written by app.cve_engine)
# ---------------------------------------------------------------------------

@app.get("/api/v1/admin/applicability/summary")
def applicability_summary(admin: str = Depends(require_viewer)):
    """Fleet-wide verdict counts. Only fixed_active counts as remediated."""
    with db() as conn:
        by_state = conn.execute(
            """SELECT state, count(*) AS n, count(DISTINCT host_id) AS hosts
                 FROM host_applicability GROUP BY state ORDER BY state"""
        ).fetchall()
        top = conn.execute(
            """SELECT ha.advisory_id, a.severity, a.title, a.issued_at,
                      count(DISTINCT ha.host_id) AS hosts_affected,
                      array_agg(DISTINCT ac.cve_id) FILTER (WHERE ac.cve_id IS NOT NULL) AS cves
                 FROM host_applicability ha
                 JOIN advisories a ON a.id = ha.advisory_id
                 LEFT JOIN advisory_cves ac ON ac.advisory_id = a.id
                WHERE ha.state = 'affected'
                GROUP BY ha.advisory_id, a.severity, a.title, a.issued_at
                ORDER BY CASE a.severity WHEN 'critical' THEN 1 WHEN 'important' THEN 2
                                         WHEN 'moderate' THEN 3 ELSE 4 END,
                         hosts_affected DESC, a.issued_at DESC
                LIMIT 25"""
        ).fetchall()
        last = conn.execute(
            "SELECT max(computed_at) AS at FROM host_applicability").fetchone()
    return {"computed_at": last["at"], "by_state": by_state,
            "top_affected": top}


@app.get("/api/v1/admin/hosts/{host_id}/advisories")
def host_advisories(host_id: str, state: Optional[str] = None,
                    admin: str = Depends(require_viewer)):
    valid = {"affected", "fixed_active", "fixed_pending_reboot", "unknown"}
    if state and state not in valid:
        raise HTTPException(status_code=422,
                            detail=f"state must be one of {sorted(valid)}")
    sql = """SELECT ha.advisory_id, ha.state, ha.fix_available,
                    ha.package_name, ha.installed_evr, ha.fixed_evr,
                    ha.reason, ha.computed_at,
                    a.severity, a.title, a.issued_at,
                    r.max_cvss, r.any_kev, r.max_epss, r.attack_classes,
                    r.cves_with_details,
                    array_agg(DISTINCT ac.cve_id) FILTER (WHERE ac.cve_id IS NOT NULL) AS cves
               FROM host_applicability ha
               JOIN advisories a ON a.id = ha.advisory_id
               LEFT JOIN advisory_cves ac ON ac.advisory_id = a.id
               LEFT JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id
              WHERE ha.host_id = %s"""
    params: List[Any] = [host_id]
    if state:
        sql += " AND ha.state = %s"
        params.append(state)
    sql += """ GROUP BY ha.advisory_id, ha.state, ha.fix_available, ha.package_name,
                        ha.installed_evr, ha.fixed_evr, ha.reason, ha.computed_at,
                        a.severity, a.title, a.issued_at,
                        r.max_cvss, r.any_kev, r.max_epss, r.attack_classes,
                        r.cves_with_details
               ORDER BY r.any_kev DESC NULLS LAST,
                        CASE ha.state WHEN 'affected' THEN 1
                          WHEN 'fixed_pending_reboot' THEN 2 WHEN 'unknown' THEN 3
                          ELSE 4 END,
                        CASE a.severity WHEN 'critical' THEN 1 WHEN 'important' THEN 2
                          WHEN 'moderate' THEN 3 ELSE 4 END,
                        a.issued_at DESC
               LIMIT 2000"""
    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"count": len(rows), "advisories": rows}


@app.get("/api/v1/admin/compliance")
def compliance(admin: str = Depends(require_viewer)):
    """One row per host with its verdict counts."""
    with db() as conn:
        rows = conn.execute(
            """SELECT v.host_id, v.hostname, v.os_id, v.os_major,
                      v.host_status, v.last_checkin,
                      v.affected, v.pending_reboot, v.remediated, v.unknown,
                      v.blocked_not_mirrored,
                      h.os_version, h.kernel_running, h.reboot_required,
                      h.host_group, h.last_inventory, h.boot_time,
                      agent_state(h.last_checkin, h.status, %s) AS agent_state
                 FROM v_compliance v JOIN hosts h ON h.id = v.host_id
                ORDER BY v.affected DESC, v.pending_reboot DESC, v.hostname""",
            (ONLINE_MINUTES,),
        ).fetchall()
    return {"count": len(rows), "hosts": rows, "online_minutes": ONLINE_MINUTES}


# ---------------------------------------------------------------------------
# Explanations from AI-01 (advisory only; the verdict is the CVE engine's)
# ---------------------------------------------------------------------------

@app.post("/api/v1/admin/hosts/{host_id}/advisories/{advisory_id}/explain")
def explain_verdict(host_id: str, advisory_id: str, request: Request,
                    admin: str = Depends(require_operator)):
    from . import llm
    with db() as conn:
        try:
            return llm.explain(conn, host_id, advisory_id, requested_by=admin)
        except llm.NotFound as e:
            raise HTTPException(status_code=404, detail=str(e))
        except llm.LLMBusy as e:
            raise HTTPException(status_code=429, detail=str(e))
        except llm.LLMUnavailable as e:
            log.warning("explain failed for %s: %s", advisory_id, e)
            raise HTTPException(status_code=503, detail=str(e))


@app.get("/api/v1/admin/llm/status")
def llm_status(admin: str = Depends(require_viewer)):
    from . import llm
    h = llm.health()
    with db() as conn:
        s = llm.stats(conn)
    return {**h, **s, "prompt_version": llm.PROMPT_VERSION,
            "model_tag": llm.AI01_MODEL_TAG}


@app.get("/api/v1/admin/agents")
def list_agents(admin: str = Depends(require_viewer)):
    """Agent health for every server. Online/offline is computed now, from
    the last check-in, so it cannot be out of date."""
    with db() as conn:
        # From v_agents, which already exposes host_id, host_status and the
        # computed agent_state. Selecting these names from the hosts table
        # itself fails: there the columns are id and status.
        rows = conn.execute(
            """SELECT host_id, hostname, fqdn, os_id, os_version, host_group,
                      agent_version, host(agent_ip) AS agent_ip, host_status,
                      agent_state, last_checkin, last_inventory, boot_time,
                      uptime_seconds, reboot_required, enrolled_at
                 FROM v_agents
                ORDER BY CASE agent_state
                           WHEN 'offline' THEN 1 WHEN 'not_reporting' THEN 2
                           WHEN 'no_data' THEN 3 ELSE 4 END,
                         hostname"""
        ).fetchall()
        versions = conn.execute(
            """SELECT coalesce(agent_version, 'unknown') AS version, count(*) AS n
                 FROM hosts WHERE status <> 'decommissioned'
                GROUP BY 1 ORDER BY 2 DESC"""
        ).fetchall()
    counts = {}
    for r in rows:
        counts[r["agent_state"]] = counts.get(r["agent_state"], 0) + 1
    return {"count": len(rows), "online_minutes": ONLINE_MINUTES,
            "by_state": counts, "versions": versions, "agents": rows}


# ---------------------------------------------------------------------------
# VMware (read-only; written by app.vmware)
# ---------------------------------------------------------------------------

SNAPSHOT_OLD_DAYS = int(os.environ.get("SNAPSHOT_OLD_DAYS", "7"))


@app.get("/api/v1/admin/vmware/summary")
def vmware_summary(admin: str = Depends(require_viewer)):
    with db() as conn:
        vcs = conn.execute(
            """SELECT name, host, version, last_sync_at, last_ok, last_error, vm_count
                 FROM vcenters ORDER BY name""").fetchall()
        c = conn.execute(
            """SELECT count(*)                                             AS vms,
                      count(*) FILTER (WHERE is_linux)                     AS linux,
                      count(*) FILTER (WHERE host_id IS NOT NULL)          AS matched,
                      count(*) FILTER (WHERE is_linux AND host_id IS NULL
                                         AND power_state='poweredOn')       AS unmanaged,
                      count(*) FILTER (WHERE match_method='ambiguous')     AS ambiguous,
                      count(*) FILTER (WHERE snapshot_count > 0
                        AND oldest_snapshot_at < now() - make_interval(days => %s)) AS old_snapshots
                 FROM vm_inventory""", (SNAPSHOT_OLD_DAYS,)).fetchone()
        unmatched_hosts = conn.execute(
            """SELECT count(*) AS n FROM hosts h
                WHERE h.status <> 'decommissioned'
                  AND NOT EXISTS (SELECT 1 FROM vm_inventory v WHERE v.host_id = h.id)"""
        ).fetchone()["n"]
    return {"vcenters": vcs, "counts": c, "servers_without_vm": unmatched_hosts,
            "snapshot_old_days": SNAPSHOT_OLD_DAYS}


@app.get("/api/v1/admin/vmware/vms")
def vmware_vms(view: str = "unmanaged", admin: str = Depends(require_viewer)):
    where = {
        "unmanaged": "v.is_linux AND v.host_id IS NULL AND v.power_state='poweredOn'",
        "snapshots": "v.snapshot_count > 0",
        "ambiguous": "v.match_method = 'ambiguous'",
        "linux": "v.is_linux",
        "all": "TRUE",
    }.get(view)
    if where is None:
        raise HTTPException(status_code=422, detail="unknown view")
    order = "v.oldest_snapshot_at NULLS LAST" if view == "snapshots" else "v.vcenter, v.name"
    with db() as conn:
        rows = conn.execute(
            f"""SELECT v.vcenter, v.moref, v.name, v.power_state, v.guest_os, v.is_linux,
                       v.guest_hostname, v.guest_ips, v.tools_running, v.esxi_host,
                       v.cluster, v.datacenter, v.num_cpu, v.memory_mb,
                       v.snapshot_count, v.oldest_snapshot_at, v.snapshots,
                       v.match_method, v.synced_at, v.host_id, h.hostname AS server
                  FROM vm_inventory v LEFT JOIN hosts h ON h.id = v.host_id
                 WHERE {where}
                 ORDER BY {order}
                 LIMIT 5000""").fetchall()
    return {"count": len(rows), "view": view, "vms": rows}


@app.get("/api/v1/admin/hosts/{host_id}/vm")
def host_vm(host_id: str, admin: str = Depends(require_viewer)):
    with db() as conn:
        row = conn.execute(
            """SELECT vcenter, moref, name, power_state, guest_os, esxi_host, cluster,
                      datacenter, num_cpu, memory_mb, tools_running, tools_version_status,
                      snapshot_count, oldest_snapshot_at, snapshots, match_method, synced_at
                 FROM vm_inventory WHERE host_id = %s
                 ORDER BY synced_at DESC LIMIT 1""", (host_id,)).fetchone()
    return {"vm": row, "snapshot_old_days": SNAPSHOT_OLD_DAYS}


ADVISORY_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9:._-]{1,60}$")


@app.get("/api/v1/admin/advisories")
def advisories_list(user: str = Depends(require_viewer)):
    """Every advisory still to install somewhere: vendor advisories from the
    CVE engine (Linux, and Windows builds from Microsoft's guide) and the
    Windows updates the servers themselves report missing, by KB."""
    with db() as conn:
        from . import report_jobs
        rows = conn.execute(report_jobs.ADVISORIES_SQL).fetchall()
    return jsonable({"count": len(rows), "advisories": rows})


@app.get("/api/v1/admin/advisories/{advisory_id}/hosts")
def advisory_hosts(advisory_id: str, user: str = Depends(require_viewer)):
    """The servers one advisory (or a Windows update, by KB) is still to be
    installed on, with what they have and what fixes it."""
    if not ADVISORY_ID_RE.match(advisory_id):
        raise HTTPException(404, "No such advisory.")
    with db() as conn:
        rows = conn.execute(
            """SELECT h.id::text AS host_id, h.hostname, agent_state(h.last_checkin, h.status) AS agent,
                      ha.state::text AS state, ha.package_name AS package, ha.installed_evr AS installed, ha.fixed_evr AS fixed_in
                 FROM host_applicability ha JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'
                WHERE ha.advisory_id = %(id)s AND ha.state IN ('affected', 'fixed_pending_reboot')
               UNION ALL
               SELECT h.id::text, h.hostname, agent_state(h.last_checkin, h.status), 'affected', 'Windows update',
                      CASE WHEN wu.downloaded THEN 'downloaded' ELSE 'not downloaded' END, wu.kb
                 FROM windows_updates wu JOIN hosts h ON h.id = wu.host_id AND h.status <> 'decommissioned'
                WHERE coalesce(wu.kb, wu.update_id) = %(id)s
                ORDER BY 2 LIMIT 1000""", {"id": advisory_id}).fetchall()
    return jsonable({"advisory_id": advisory_id, "hosts": rows})


@app.get("/api/v1/admin/advisories/{advisory_id}/cves")
def advisory_cves(advisory_id: str, admin: str = Depends(require_viewer)):
    """Published facts for every CVE in one advisory: score, how it is
    reached, whether it is being exploited, and the derived attack type with
    the data it was derived from."""
    with db() as conn:
        rows = conn.execute(
            """SELECT ac.cve_id, cd.cvss_score, cd.cvss_severity, cd.cvss_vector,
                      cd.cvss_version, cd.cvss_source, cd.attack_class, cd.attack_class_basis,
                      cd.attack_vector, cd.attack_complexity, cd.privileges_required,
                      cd.user_interaction, cd.cwes, cd.description,
                      cd.kev, cd.kev_added, cd.kev_due, cd.kev_ransomware,
                      cd.epss, cd.epss_percentile,
                      cd.rh_severity, cd.rh_cvss_score, cd.rh_statement,
                      cd.published, cd.last_modified, cd.nvd_fetched_at, cd.fetch_error
                 FROM advisory_cves ac
                 LEFT JOIN cve_details cd ON cd.cve_id = ac.cve_id
                WHERE ac.advisory_id = %s
                ORDER BY cd.kev DESC NULLS LAST, cd.cvss_score DESC NULLS LAST, ac.cve_id""",
            (advisory_id,)).fetchall()
    have = sum(1 for r in rows if r["nvd_fetched_at"])
    return {"advisory_id": advisory_id, "count": len(rows), "with_details": have, "cves": rows}


@app.get("/api/v1/admin/cve-intel/status")
def cve_intel_status(admin: str = Depends(require_viewer)):
    with db() as conn:
        c = conn.execute(
            """SELECT count(*) AS cves,
                      count(*) FILTER (WHERE nvd_fetched_at IS NOT NULL) AS with_nvd,
                      count(*) FILTER (WHERE kev)                        AS exploited,
                      count(*) FILTER (WHERE epss IS NOT NULL)           AS with_epss,
                      count(*) FILTER (WHERE attack_class IS NOT NULL)   AS classified
                 FROM cve_details""").fetchone()
        tracked = conn.execute("SELECT count(DISTINCT cve_id) AS n FROM advisory_cves").fetchone()["n"]
        syncs = conn.execute(
            """SELECT DISTINCT ON (source) source, started_at, finished_at, ok, items, error
                 FROM intel_syncs ORDER BY source, started_at DESC""").fetchall()
    return {"cves_referenced": tracked, **dict(c), "last_syncs": syncs}


# ---------------------------------------------------------------------------
# CVE assessments: evaluate a list that arrived from outside
# ---------------------------------------------------------------------------

MAX_UPLOAD_BYTES = 2 * 1024 * 1024


@app.post("/api/v1/admin/assessments")
async def create_assessment(request: Request,
                            name: str = Form(...),
                            source: Optional[str] = Form(default=None),
                            note: Optional[str] = Form(default=None),
                            text: Optional[str] = Form(default=None),
                            file: Optional[UploadFile] = File(default=None),
                            admin: str = Depends(require_operator)):
    """Take a CVE list, as an uploaded file or pasted text, and evaluate it."""
    from . import assess

    body = text or ""
    if file is not None:
        raw = await file.read(MAX_UPLOAD_BYTES + 1)
        if len(raw) > MAX_UPLOAD_BYTES:
            raise HTTPException(status_code=413,
                                detail=f"file larger than {MAX_UPLOAD_BYTES // 1024 // 1024} MB")
        # Any text format: a pasted list, CSV, or an exported bulletin
        body += "\n" + raw.decode("utf-8", errors="replace")

    cves, rejected = assess.parse_cve_list(body)
    if not cves:
        raise HTTPException(
            status_code=422,
            detail="No CVE identifiers found. Expected text containing CVE-YYYY-NNNN. "
                   "Spreadsheets must be saved as CSV or the list pasted in.")

    name = (name or "").strip()[:200] or "Untitled assessment"
    with db() as conn:
        with conn.transaction():
            items, in_scope = assess.evaluate(conn, cves)
            aid = assess.save(conn, name, (source or "").strip()[:100] or None,
                              (note or "").strip()[:2000] or None, admin,
                              cves, rejected, items, in_scope)
            # The worker now looks each CVE up in NVD, matches what it affects
            # against the inventory, and writes the AI brief
            conn.execute("""UPDATE cve_assessments SET state='enriching', progress=0,
                                   progress_total=%s WHERE id=%s""", (len(cves), aid))
            audit(conn, actor=admin, actor_type="user", action="cve_assessment",
                  object_type="assessment", object_id=aid,
                  detail={"name": name, "cves": len(cves),
                          **assess.summarise(items)},
                  source_ip=client_ip(request))
    return {"id": aid, "name": name, "cve_count": len(cves), "rejected": rejected,
            "hosts_in_scope": in_scope, "summary": assess.summarise(items),
            "items": items, "state": "enriching"}


@app.get("/api/v1/admin/assessments")
def list_assessments(admin: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT a.id, a.name, a.source, a.created_by, a.created_at, a.cve_count,
                      a.hosts_in_scope, a.state, a.progress, a.progress_total,
                      count(*) FILTER (WHERE i.status='affected')       AS affected,
                      count(*) FILTER (WHERE i.status='pending_reboot') AS pending_reboot,
                      count(*) FILTER (WHERE i.status='patched')        AS patched,
                      count(*) FILTER (WHERE i.status='unknown')        AS unknown,
                      count(*) FILTER (WHERE i.status='not_applicable') AS not_applicable,
                      count(*) FILTER (WHERE i.status='no_vendor_data') AS no_vendor_data,
                      count(*) FILTER (WHERE i.kev AND i.status='affected') AS exploited_affected,
                      count(*) FILTER (WHERE i.exposure IN ('affected','potentially_affected')) AS exposed
                 FROM cve_assessments a
                 LEFT JOIN cve_assessment_items i ON i.assessment_id = a.id
                GROUP BY a.id ORDER BY a.created_at DESC LIMIT 200""").fetchall()
    return {"count": len(rows), "assessments": rows}


@app.get("/api/v1/admin/assessments/{assessment_id}")
def get_assessment(assessment_id: str, admin: str = Depends(require_viewer)):
    with db() as conn:
        head = conn.execute("SELECT * FROM cve_assessments WHERE id=%s",
                            (assessment_id,)).fetchone()
        if not head:
            raise HTTPException(status_code=404, detail="assessment not found")
        items = conn.execute(
            """SELECT * FROM cve_assessment_items WHERE assessment_id=%s
                ORDER BY CASE coalesce(exposure, status)
                           WHEN 'affected' THEN 1 WHEN 'potentially_affected' THEN 2
                           WHEN 'pending_reboot' THEN 3 WHEN 'unknown' THEN 4
                           WHEN 'not_tracked' THEN 5 WHEN 'no_vendor_data' THEN 6
                           WHEN 'not_found' THEN 6 WHEN 'patched' THEN 7 ELSE 8 END,
                         kev DESC, cvss_score DESC NULLS LAST, cve_id""",
            (assessment_id,)).fetchall()
    return {"assessment": head, "items": items}


@app.get("/api/v1/admin/assessments/{assessment_id}/export.csv",
         response_class=PlainTextResponse)
def export_assessment(assessment_id: str, request: Request, admin: str = Depends(require_viewer)):
    """CSV to send back to whoever asked the question, with the branded heading."""
    from . import exports as ex
    with db() as conn:
        company = ex.company_name(conn)
        head = conn.execute("SELECT name, created_at FROM cve_assessments WHERE id=%s",
                            (assessment_id,)).fetchone()
        if not head:
            raise HTTPException(status_code=404, detail="assessment not found")
        items = conn.execute(
            """SELECT cve_id, status, exposure, cvss_score, cvss_severity, cvss_vector, kev, epss,
                      attack_class, published, description, product_classes, products,
                      inventory_matches, affected, pending_reboot, patched, unknown,
                      advisories, packages, affected_hosts, ai_summary, platforms, excluded
                 FROM cve_assessment_items WHERE assessment_id=%s ORDER BY cve_id""",
            (assessment_id,)).fetchall()
    out_rows = []
    headers = (["cve", "exposure", "package_verdict", "cvss", "severity", "vector",
                "exploited_in_wild", "epss", "attack_type", "published", "affects",
                "affected_products", "platforms", "found_in_inventory", "ruled_out", "servers_affected",
                "servers_awaiting_reboot", "servers_patched", "advisories", "packages",
                "affected_server_names", "description", "ai_summary"])
    for i in items:
        names = ";".join(h.get("hostname", "") for h in (i["affected_hosts"] or [])
                         if h.get("state") == "affected")
        prods = ";".join(f"{p.get('vendor')} {p.get('product')}" for p in (i["products"] or []))
        found = ";".join(f"{m.get('where') or m.get('kind')}: {m.get('name') or '-'}"
                         + (f" [{m['ip']}]" if m.get("ip") else "") + (f" {m['os']}" if m.get("os") else "")
                         + f" ({m.get('certainty')})" for m in (i["inventory_matches"] or [])
                         if m.get("certainty") != "not_tracked")
        ex_ = i.get("excluded") or {}
        ruled_out = ";".join(f"{e.get('name')}: {e.get('reason')}" for e in (ex_.get("machines") or [])[:30])
        out_rows.append([i["cve_id"], i["exposure"] or "", i["status"], i["cvss_score"] or "",
                    i["cvss_severity"] or "", i["cvss_vector"] or "",
                    "yes" if i["kev"] else "no",
                    f"{float(i['epss']):.4f}" if i["epss"] is not None else "",
                    i["attack_class"] or "", (i["published"].date().isoformat() if i["published"] else ""),
                    ";".join(i["product_classes"] or []), prods, ";".join(i.get("platforms") or []), found, ruled_out,
                    i["affected"], i["pending_reboot"], i["patched"],
                    ";".join(i["advisories"] or []), ";".join(i["packages"] or []), names,
                    (i["description"] or "").replace("\n", " "),
                    (i["ai_summary"] or "").replace("\n", " ")])
    fn = re.sub(r"[^A-Za-z0-9_-]+", "-", head["name"])[:60] or "assessment"
    m = ex.meta("CVE assessment: " + head["name"][:80], admin, "assessment " + head["name"][:80], len(out_rows), company)
    return PlainTextResponse(
        ex.csv_text(m, headers, out_rows), media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{ex.file_name(fn, "csv")}"'})


@app.delete("/api/v1/admin/assessments/{assessment_id}")
def delete_assessment(assessment_id: str, request: Request,
                      admin: str = Depends(require_operator)):
    with db() as conn:
        with conn.transaction():
            row = conn.execute("DELETE FROM cve_assessments WHERE id=%s RETURNING name",
                               (assessment_id,)).fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="assessment not found")
            audit(conn, actor=admin, actor_type="user", action="delete_assessment",
                  object_type="assessment", object_id=assessment_id,
                  detail={"name": row["name"]}, source_ip=client_ip(request))
    return {"ok": True}


# ---------------------------------------------------------------------------
# The assistant: read-only questions, CSV export, e-mail on confirmation
# ---------------------------------------------------------------------------

class ChatContext(BaseModel):
    tool: str = Field(..., max_length=40)
    args: Dict[str, Any] = Field(default_factory=dict)


class ChatIn(BaseModel):
    question: str = Field(..., min_length=1, max_length=400)
    context: Optional[ChatContext] = None


@app.post("/api/v1/admin/chat")
def chat(request: Request, body: ChatIn, admin: str = Depends(require_operator)):
    """Answer a question from prepared read-only queries.

    The model only selects which query to run; the figures come from the
    database and the rows are returned so the operator can check them.
    Nothing here can change a server, and nothing here sends mail: an e-mail
    is returned as a draft for the operator to send.
    """
    from . import chat as chatmod
    from . import llm

    use_model = None
    try:
        if llm.configured():
            use_model = lambda messages: llm.choose(messages, max_tokens=100)  # noqa: E731
    except Exception:  # noqa: BLE001
        use_model = None

    from . import auth
    ctx = body.context.model_dump() if body.context else None
    modules = auth.user_modules(request.state.user)
    with db() as conn:
        try:
            res = chatmod.ask(conn, body.question, ask_model=use_model, requested_by=admin, context=ctx,
                              modules=modules)
        except ValueError as e:
            raise HTTPException(status_code=422, detail=str(e))
        if res.get("action") == "email":
            res["email"]["allowed"] = _assistant_mail_policy(conn)["describe"]
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="chat_query",
                  detail={"question": body.question[:300], "tool": res.get("tool"), "args": res.get("args"),
                          "how": res.get("how"), "action": res.get("action"),
                          "rows": len(res.get("rows") or [])},
                  source_ip=client_ip(request))
    return jsonable(res)


def jsonable(obj):
    """Dates, decimals and addresses as JSON-friendly values."""
    return json.loads(json.dumps(obj, default=lambda o: o.isoformat() if hasattr(o, "isoformat") else str(o)))


class AssistantQuery(BaseModel):
    tool: str = Field(..., max_length=40)
    args: Dict[str, Any] = Field(default_factory=dict)


@app.post("/api/v1/assistant/export")
def assistant_export(request: Request, body: AssistantQuery, user: str = Depends(require_operator)):
    """The same validated query as an answer, re-run on the server with up to
    5000 rows, as CSV. Cells that a spreadsheet would run as a formula are
    neutralised."""
    from fastapi.responses import Response
    from . import auth, chat as chatmod
    if not chatmod.tool_allowed(body.tool, auth.user_modules(request.state.user)):
        raise HTTPException(403, "Your account does not have access to this information.")
    with db() as conn:
        try:
            args, rows, cols, missing = chatmod.run_tool(conn, body.tool, body.args, chatmod.EXPORT_ROWS)
        except ValueError:
            raise HTTPException(422, "Unknown query.")
        if missing:
            raise HTTPException(422, "The query needs: " + ", ".join(missing))
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="assistant_export",
                  detail={"tool": body.tool, "args": args, "rows": len(rows)}, source_ip=client_ip(request))
    from . import exports as ex
    with db() as conn:
        company = ex.company_name(conn)
    cols = cols or ["result"]
    m = ex.meta("Assistant: " + chatmod.title_for(body.tool, args), user, chatmod.title_for(body.tool, args), len(rows), company)
    data = ex.csv_text(m, [c.replace("_", " ") for c in cols],
                       [[r.get(c) for c in cols] for r in rows]).encode("utf-8")
    name = ex.file_name(chatmod.file_name(body.tool, args), "csv")
    return Response(data, media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{name}"',
                             "X-Rows": str(len(rows)), "Cache-Control": "no-store"})


ASSISTANT_MAIL_PER_HOUR = 10


def _assistant_mail_policy(conn):
    """Who the assistant may mail: the configured recipients, and anyone at
    the same mail domains as them or as the sender. Worked out from the mail
    settings each time, never stored."""
    recs = [r["address"].strip().lower() for r in conn.execute("SELECT address FROM mail_recipients").fetchall()]
    s = conn.execute("SELECT from_addr FROM mail_settings WHERE id = 1").fetchone() or {}
    domains = {a.split("@")[-1] for a in recs if "@" in a}
    if s.get("from_addr") and "@" in s["from_addr"]:
        domains.add(s["from_addr"].strip().lower().split("@")[-1].strip(">"))
    return {"addresses": set(recs), "domains": domains,
            "describe": {"recipients": sorted(recs), "domains": sorted(domains)}}


class AssistantMailIn(BaseModel):
    tool: str = Field(..., max_length=40)
    args: Dict[str, Any] = Field(default_factory=dict)
    to: List[str] = Field(..., min_length=1, max_length=20)
    cc: List[str] = Field(default_factory=list, max_length=20)
    subject: str = Field(..., min_length=3, max_length=200)
    body: str = Field(..., min_length=1, max_length=10000)
    attach: bool = True


@app.post("/api/v1/assistant/email")
def assistant_email(request: Request, body: AssistantMailIn, user: str = Depends(require_operator)):
    """Send an answer by mail, after the operator pressed Send.

    The data is re-read here from the same validated query: nothing the
    browser sends back is put in the mail except the text the operator wrote.
    Recipients must be allowed by the mail policy above. At most ten mails an
    hour per user, every one in the audit log."""
    from . import auth, chat as chatmod
    from . import notify as nt
    if not chatmod.tool_allowed(body.tool, auth.user_modules(request.state.user)):
        raise HTTPException(403, "Your account does not have access to this information.")
    if any(c in body.subject for c in "\r\n"):
        raise HTTPException(422, "The subject cannot contain a line break.")
    to = [a.strip() for a in body.to if a.strip()]
    cc = [a.strip() for a in body.cc if a.strip() and a.strip().lower() not in {x.lower() for x in to}]
    bad = [a for a in to + cc if not re.match(EMAIL_RE, a)]
    if bad:
        raise HTTPException(422, "Not e-mail addresses: " + ", ".join(bad))
    with db() as conn:
        pol = _assistant_mail_policy(conn)
        refused = [a for a in to + cc if a.lower() not in pol["addresses"] and a.lower().split("@")[-1] not in pol["domains"]]
        if refused:
            raise HTTPException(403, "The assistant may only mail the configured recipients or addresses at "
                                     + (", ".join(sorted(pol["domains"])) or "your mail domain")
                                     + ". Not allowed: " + ", ".join(refused))
        sent_recently = conn.execute(
            """SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'assistant_email'
                AND occurred_at > now() - interval '1 hour'""", (user,)).fetchone()["n"]
        if sent_recently >= ASSISTANT_MAIL_PER_HOUR:
            raise HTTPException(429, f"At most {ASSISTANT_MAIL_PER_HOUR} assistant e-mails an hour: try again later.")
        cfg = nt.config(conn)
        if not (cfg["host"] and cfg["from"]):
            raise HTTPException(409, "Mail is not set up yet: an admin can do it under Admin, Mail.")
        try:
            args, rows, cols, missing = chatmod.run_tool(conn, body.tool, body.args, chatmod.EXPORT_ROWS)
        except ValueError:
            raise HTTPException(422, "Unknown query.")
        if missing:
            raise HTTPException(422, "The query needs: " + ", ".join(missing))
        title = chatmod.title_for(body.tool, args)
        shown = rows[:25]
        blocks = [("text", body.body)]
        if shown:
            blocks.append(("table", [c.replace("_", " ") for c in cols],
                           [[chatmod._cell(r.get(c)).lstrip("'") for c in cols] for r in shown]))
            if len(rows) > len(shown):
                blocks.append(("p", f"The first {len(shown)} of {len(rows)} rows; all are in the attached file."))
        text, html = nt.render(cfg, body.subject, "info", "", blocks, link=None, label="Cyber-Secure assistant",
                               greeting=False)            # the editable draft carries its own greeting
        files = []
        if body.attach and rows:
            from . import exports as ex
            m = ex.meta("Assistant: " + title, user, title, len(rows), ex.company_name(conn))
            files.append((ex.file_name(chatmod.file_name(body.tool, args), "csv"),
                          ex.csv_text(m, [c.replace("_", " ") for c in cols],
                                      [[r.get(c) for c in cols] for r in rows]).encode("utf-8"), "text/csv"))
        state, err = "sent", None
        try:
            nt.send(cfg, to, body.subject, text, html, cc=cc, attachments=files)
        except Exception as e:  # noqa: BLE001 - reported back and recorded
            state, err = "failed", str(e)
        with conn.transaction():
            conn.execute(
                """INSERT INTO notifications (category, severity, subject, body_text, body_html, recipients, state,
                                              attempts, sent_at, last_error, event_keys)
                   VALUES ('assistant', 'info', %s, %s, %s, %s, %s, 1, CASE WHEN %s THEN now() END, %s, %s)""",
                (body.subject, text, html, to + cc, state, state == "sent", err, [f"assistant:{body.tool}"]))
            audit(conn, actor=user, actor_type="user", action="assistant_email",
                  detail={"tool": body.tool, "args": args, "title": title, "to": to, "cc": cc,
                          "subject": body.subject, "rows": len(rows), "attached": bool(files),
                          "state": state, "error": err}, source_ip=client_ip(request))
    if err:
        raise HTTPException(502, err)
    return {"ok": True, "to": to, "cc": cc, "rows": len(rows), "attached": bool(files)}


# ---------------------------------------------------------------------------
# Cyber-Secure dashboard: fleet figures for the donuts (viewers and up)
# ---------------------------------------------------------------------------

OS_LABEL_SQL = """CASE
    WHEN h.os_id = 'windows' THEN coalesce(nullif(regexp_replace(h.os_edition, '^Microsoft ', ''), ''), 'Windows')
    WHEN h.os_id = 'rhel' THEN 'RHEL ' || coalesce(h.os_major::text, split_part(h.os_version, '.', 1))
    WHEN h.os_id = 'ol' THEN 'Oracle Linux ' || coalesce(h.os_major::text, split_part(h.os_version, '.', 1))
    WHEN h.os_id = 'ubuntu' THEN 'Ubuntu ' || coalesce(h.os_version, '')
    ELSE coalesce(h.os_id, 'unknown') || ' ' || coalesce(h.os_version, '') END"""


@app.get("/api/v1/dashboard/summary")
def dashboard_summary(user: str = Depends(require_viewer)):
    """Everything the dashboard's donuts show, computed live from the
    database, so a server enrolled a minute ago is already counted."""
    from . import cve_feeds
    with db() as conn:
        servers = conn.execute(
            """WITH h AS (
                 SELECT agent_state(h.last_checkin, h.status) AS st,
                        EXISTS (SELECT 1 FROM host_applicability ha WHERE ha.host_id = h.id AND ha.state = 'affected')
                          OR EXISTS (SELECT 1 FROM windows_updates wu WHERE wu.host_id = h.id) AS needs,
                        h.reboot_required
                          OR EXISTS (SELECT 1 FROM host_applicability ha
                                      WHERE ha.host_id = h.id AND ha.state = 'fixed_pending_reboot') AS reboot
                   FROM hosts h WHERE h.status <> 'decommissioned')
               SELECT count(*) AS total,
                      count(*) FILTER (WHERE st <> 'online') AS not_reporting,
                      count(*) FILTER (WHERE st = 'online' AND needs) AS needs_patch,
                      count(*) FILTER (WHERE st = 'online' AND NOT needs AND reboot) AS needs_reboot,
                      count(*) FILTER (WHERE st = 'online' AND NOT needs AND NOT reboot) AS patched,
                      count(*) FILTER (WHERE reboot) AS reboot_any
                 FROM h""").fetchone()
        advisories = conn.execute(
            """SELECT count(*) FILTER (WHERE ha.state = 'affected') AS to_install,
                      count(*) FILTER (WHERE ha.state = 'fixed_pending_reboot') AS awaiting_reboot,
                      count(*) FILTER (WHERE ha.state = 'fixed_active') AS installed,
                      (SELECT count(*) FROM windows_updates wu JOIN hosts x ON x.id = wu.host_id
                        WHERE x.status <> 'decommissioned') AS windows_to_install,
                      count(DISTINCT ha.advisory_id) FILTER (WHERE ha.state = 'affected') AS distinct_outstanding
                 FROM host_applicability ha JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'""").fetchone()
        severity = conn.execute(
            """WITH o AS (
                 SELECT DISTINCT a.id, lower(coalesce(a.severity, '')) AS sev
                   FROM host_applicability ha JOIN advisories a ON a.id = ha.advisory_id
                   JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'
                  WHERE ha.state = 'affected'
                 UNION
                 SELECT DISTINCT coalesce(wu.kb, wu.update_id), lower(coalesce(wu.severity, ''))
                   FROM windows_updates wu JOIN hosts h ON h.id = wu.host_id AND h.status <> 'decommissioned')
               SELECT count(*) FILTER (WHERE sev = 'critical') AS critical,
                      count(*) FILTER (WHERE sev IN ('important', 'high')) AS important,
                      count(*) FILTER (WHERE sev IN ('moderate', 'medium')) AS moderate,
                      count(*) FILTER (WHERE sev NOT IN ('critical', 'important', 'high', 'moderate', 'medium')) AS low_or_unrated
                 FROM o""").fetchone()
        os_rows = conn.execute(
            f"""SELECT {OS_LABEL_SQL} AS os, count(*) AS n
                  FROM hosts h WHERE h.status <> 'decommissioned' GROUP BY 1 ORDER BY 2 DESC, 1""").fetchall()
        agents = conn.execute(
            """SELECT agent_state(last_checkin, status) AS state, count(*) AS n
                 FROM hosts WHERE status <> 'decommissioned' GROUP BY 1""").fetchall()
    def feeds_build():
        from . import cve_impact
        with db() as c2:
            out = cve_feeds.summary(c2)
            out["impact"] = cve_impact.counts(c2, out["days"])
            return jsonable(out)
    try:
        feeds = _public_cached("feeds-summary", feeds_build, ttl=60)
    except HTTPException:                 # schema 022 not applied yet, or the feeds tables unreadable
        feeds = None
    top, other = os_rows[:6], sum(r["n"] for r in os_rows[6:])
    if other:
        top.append({"os": "Other", "n": other})
    online = (servers["total"] or 0) - (servers["not_reporting"] or 0)
    return jsonable({"servers": servers, "advisories": advisories, "severity": severity, "os": top,
                     "agents": {r["state"]: r["n"] for r in agents}, "feeds": feeds,
                     "compliance_pct": round(100.0 * servers["patched"] / online) if online else None,
                     "at": datetime.now(timezone.utc)})


# ---------------------------------------------------------------------------
# CVE news feeds: NIST, Microsoft, Red Hat
# ---------------------------------------------------------------------------

@app.get("/api/v1/servers")
def servers_list(request: Request, page: int = 1, q: Optional[str] = None, os: Optional[str] = None,
                 group: Optional[str] = None, version: Optional[str] = None, agent: Optional[str] = None,
                 patch: Optional[str] = None, sort: str = "agent", user: str = Depends(require_viewer)):
    """Servers and their agents in one list: 20 a page, filtered here, with
    the values each filter offers and AI-01's latest analysis."""
    from . import servers as sv, insights
    f = sv.clean_filters(q, os, group, version, agent, patch)
    with db() as conn:
        res = sv.page(conn, f, page, sort=sort if sort in sv.SORTS else "agent")
        res["facets"] = sv.facets(conn)
        try:
            res["insight"] = insights.latest(conn, "servers")
        except Exception:  # noqa: BLE001 - schema 024 not applied yet
            conn.rollback()
            res["insight"] = None
    res["filters"] = f
    return jsonable(res)


@app.get("/api/v1/servers/export")
def servers_export(request: Request, format: str = "csv", q: Optional[str] = None, os: Optional[str] = None,
                   group: Optional[str] = None, version: Optional[str] = None, agent: Optional[str] = None,
                   patch: Optional[str] = None, sort: str = "name", user: str = Depends(require_viewer)):
    """Every server matching the filters (not just one page), as CSV or as an
    Excel file with the logo. Both carry the organisation, the time it was
    made, who made it and the filter."""
    from fastapi.responses import Response
    from . import servers as sv, exports as ex, branding as br
    if format not in ("csv", "pdf", "xlsx"):
        raise HTTPException(422, "format must be pdf or csv")
    f = sv.clean_filters(q, os, group, version, agent, patch)
    with db() as conn:
        rows = sv.all_rows(conn, f, sort if sort in sv.SORTS else "name")
        company = ex.company_name(conn)
        cols = sv.EXPORT_COLUMNS if format != "pdf" else sv.EXPORT_COLUMNS[:12]   # a page is only so wide
        heads = [label for _, label in cols]
        data_rows = [[sv.export_value(k, r.get(k)) for k, _ in cols] for r in rows]
        m = ex.meta("Servers report", user, sv.describe_filters(f), len(rows), company)
        body, mime, ext = ex.render(format, m, heads, data_rows, conn)
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="servers_exported",
                  detail={"format": format, "filters": f, "rows": len(rows)}, source_ip=client_ip(request))
    return Response(body, media_type=mime, headers={
        "Content-Disposition": f'attachment; filename="{ex.file_name("servers", ext)}"',
        "Cache-Control": "no-store", "X-Rows": str(len(rows))})


@app.get("/api/v1/insights/{scope}")
def insight_history(scope: str, user: str = Depends(require_viewer)):
    """AI-01's analyses for a part of the console, newest first (one day)."""
    from . import insights
    if scope not in insights.SCOPES:
        raise HTTPException(404, "No such analysis.")
    with db() as conn:
        return jsonable({"items": insights.history(conn, scope)})


@app.get("/api/v1/impact")
def impact_list(verdict: Optional[str] = None, user: str = Depends(require_viewer)):
    """New critical, high and exploited CVEs matched against the inventory,
    with where each was found and AI-01's brief."""
    from . import cve_feeds, cve_impact
    if verdict not in (None, "", "affected", "pending_reboot", "potentially_affected", "not_found", "not_tracked"):
        raise HTTPException(422, "unknown verdict")
    with db() as conn:
        days = int(cve_feeds.settings(conn).get("days_back") or 14)
        return jsonable({"days": days, "counts": cve_impact.counts(conn, days),
                         "items": cve_impact.listing(conn, days, verdict or None)})


@app.post("/api/v1/admin/impact/reanalyse")
def impact_reanalyse(request: Request, admin: str = Depends(require_admin)):
    """Ask the worker to match every CVE in the window again (within two minutes)."""
    with db() as conn:
        with conn.transaction():
            # Every CVE becomes due; the worker goes through them oldest first
            conn.execute("UPDATE cve_impact SET inventory_mark = NULL")
            conn.execute("UPDATE cve_feed_settings SET impact_requested_at = now() WHERE id = 1")
            audit(conn, actor=admin, actor_type="user", action="impact_reanalyse_requested", detail={},
                  source_ip=client_ip(request))
    _feeds_cache_clear()
    return {"ok": True}


@app.get("/api/v1/feeds/news")
def feeds_news(source: Optional[str] = None, scope: str = "watched", user: str = Depends(require_viewer)):
    """New CVEs from the feeds. 'watched': those naming software on the watch
    list, or already linked to one of your servers. 'all': everything read."""
    from . import cve_feeds
    if source not in (None, "", "nist", "msrc", "redhat"):
        raise HTTPException(422, "source must be nist, msrc or redhat")
    if scope not in ("watched", "all"):
        raise HTTPException(422, "scope must be watched or all")
    def build():
        with db() as conn:
            return jsonable(cve_feeds.news(conn, source or None, watched_only=(scope == "watched")))
    return _public_cached(f"feeds-news-{source or 'all'}-{scope}", build, ttl=60)


_PUBLIC_CACHE = {}
_PUBLIC_TTL = 120
_PUBLIC_FAIL_TTL = 15
import threading as _threading  # noqa: E402
_PUBLIC_LOCK = _threading.Lock()


def _public_cached(key, build, ttl=None):
    """Answers built at most every two minutes (or ttl seconds), whoever asks
    and however often: one request builds while the others wait and then share
    it, and a failure is remembered briefly too. So neither the sign-in page
    nor many open dashboards can load the database."""
    import time as _t
    ttl = _PUBLIC_TTL if ttl is None else ttl
    hit = _PUBLIC_CACHE.get(key)
    if hit and _t.monotonic() - hit[0] < (ttl if hit[2] else _PUBLIC_FAIL_TTL):
        if not hit[2]:
            raise HTTPException(503, "Temporarily unavailable.")
        return hit[1]
    with _PUBLIC_LOCK:
        hit = _PUBLIC_CACHE.get(key)          # built by another request while we waited
        if hit and _t.monotonic() - hit[0] < (ttl if hit[2] else _PUBLIC_FAIL_TTL):
            if not hit[2]:
                raise HTTPException(503, "Temporarily unavailable.")
            return hit[1]
        try:
            val = build()
        except HTTPException:
            raise
        except Exception:  # noqa: BLE001 - remembered briefly, so a broken database is not hammered
            _PUBLIC_CACHE[key] = (_t.monotonic(), None, False)
            raise HTTPException(503, "Temporarily unavailable.")
        _PUBLIC_CACHE[key] = (_t.monotonic(), val, True)
        return val


def _feeds_cache_clear():
    for k in [k for k in _PUBLIC_CACHE if k.startswith(("feeds-", "news"))]:
        _PUBLIC_CACHE.pop(k, None)


@app.get("/api/v1/public/brand")
def public_brand():
    """What the sign-in page needs before anyone has signed in: the portal's
    name and whether a logo exists. Nothing else about this installation."""
    def build():
        from . import branding as br
        try:
            with db() as conn:
                b = br.settings(conn)
            return {"portal": "Cyber-Secure", "has_logo": bool(b.get("logo")), "has_logo_white": bool(b.get("logo_white"))}
        except Exception:  # noqa: BLE001
            return {"portal": "Cyber-Secure", "has_logo": False, "has_logo_white": False}
    return JSONResponse(_public_cached("brand", build), headers={"Cache-Control": "public, max-age=120"})


@app.get("/api/v1/public/logo")
def public_logo(variant: str = "main"):
    """The same processed logo as the mails and reports use."""
    from fastapi.responses import Response
    if variant not in ("main", "white"):
        raise HTTPException(422, "variant must be main or white")

    def build():
        from . import branding as br
        with db() as conn:
            b = br.settings(conn)
        return b.get("logo_white") if variant == "white" else b.get("logo")
    data = _public_cached("logo-" + variant, build)
    if not data:
        raise HTTPException(404, "No logo.")
    return Response(data, media_type="image/png",
                    headers={"Cache-Control": "public, max-age=300", "X-Content-Type-Options": "nosniff"})


@app.get("/api/v1/public/news")
def public_news():
    """The sign-in page's news board: the latest CVEs NIST, Microsoft and Red
    Hat published, from the general feeds only. The watch list is never used
    here, so nothing on this page says what software runs behind it."""
    from . import cve_feeds

    def build():
        try:
            with db() as conn:
                return jsonable(cve_feeds.public_news(conn))
        except Exception:  # noqa: BLE001 - schema 022 not applied yet
            return {"enabled": False, "sources": {}}
    return JSONResponse(_public_cached("news", build), headers={"Cache-Control": "public, max-age=120"})


def _feeds_admin_view(conn):
    from . import cve_feeds
    return jsonable({
        "settings": cve_feeds.settings(conn),
        "watch": conn.execute("SELECT id, term, kind, enabled, added_by, added_at FROM cve_feed_watch ORDER BY lower(term)").fetchall(),
        "state": conn.execute("SELECT * FROM cve_feed_state ORDER BY source").fetchall(),
        "stored": conn.execute("SELECT source, count(*) AS n, max(published) AS newest FROM cve_feed_items GROUP BY 1 ORDER BY 1").fetchall(),
        # The worker reads the feeds, so it is the worker's key that counts
        "nvd_api_key": bool(((conn.execute("SELECT detail FROM worker_heartbeat WHERE name = 'feeds'").fetchone()
                              or {}).get("detail") or {}).get("nvd_key")),
        "worker_seen": bool(conn.execute("SELECT 1 FROM worker_heartbeat WHERE name = 'feeds'").fetchone())})


@app.get("/api/v1/admin/feeds")
def feeds_admin(admin: str = Depends(require_admin)):
    with db() as conn:
        return _feeds_admin_view(conn)


class FeedSettingsIn(BaseModel):
    nist: bool = True
    msrc: bool = True
    redhat: bool = True
    days_back: int = Field(14, ge=1, le=90)
    min_cvss: float = Field(0, ge=0, le=10)
    interval_minutes: int = Field(60, ge=15, le=1440)
    signin_board: bool = True
    signin_min_cvss: float = Field(7.0, ge=0, le=10)


@app.put("/api/v1/admin/feeds/settings")
def feeds_settings_put(body: FeedSettingsIn, request: Request, admin: str = Depends(require_admin)):
    with db() as conn:
        with conn.transaction():
            conn.execute(
                """UPDATE cve_feed_settings SET nist=%s, msrc=%s, redhat=%s, days_back=%s, min_cvss=%s,
                          interval_minutes=%s, signin_board=%s, signin_min_cvss=%s,
                          updated_by=%s, updated_at=now() WHERE id=1""",
                (body.nist, body.msrc, body.redhat, body.days_back, body.min_cvss, body.interval_minutes,
                 body.signin_board, body.signin_min_cvss, admin))
            audit(conn, actor=admin, actor_type="user", action="feeds_settings_saved",
                  detail=body.model_dump(), source_ip=client_ip(request))
        _feeds_cache_clear()
        return _feeds_admin_view(conn)


class FeedWatchIn(BaseModel):
    term: str = Field(..., min_length=2, max_length=60)
    kind: str = Field("software", pattern="^(software|vendor|keyword)$")


@app.post("/api/v1/admin/feeds/watch")
def feeds_watch_add(body: FeedWatchIn, request: Request, admin: str = Depends(require_admin)):
    from . import cve_feeds
    try:
        term = cve_feeds.clean_term(body.term)
    except ValueError as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        try:
            with conn.transaction():
                # One change to the list at a time, so the checks below hold
                conn.execute("SELECT pg_advisory_xact_lock(hashtext('cve_feed_watch'))")
                if conn.execute("SELECT 1 FROM cve_feed_watch WHERE lower(term) = lower(%s)", (term,)).fetchone():
                    raise HTTPException(409, f"{term} is already on the watch list.")
                if conn.execute("SELECT count(*) AS n FROM cve_feed_watch").fetchone()["n"] >= 200:
                    raise HTTPException(409, "The watch list holds at most 200 entries.")
                conn.execute("INSERT INTO cve_feed_watch (term, pattern, kind, added_by) VALUES (%s, %s, %s, %s)",
                             (term, cve_feeds.term_pattern(term), body.kind, admin))
                audit(conn, actor=admin, actor_type="user", action="feeds_watch_added",
                      detail={"term": term, "kind": body.kind}, source_ip=client_ip(request))
        except psycopg.errors.UniqueViolation:
            raise HTTPException(409, f"{term} is already on the watch list.")
        _feeds_cache_clear()
        return _feeds_admin_view(conn)


@app.patch("/api/v1/admin/feeds/watch/{wid}")
def feeds_watch_toggle(wid: int, request: Request, enabled: bool = Body(..., embed=True),
                       admin: str = Depends(require_admin)):
    with db() as conn:
        with conn.transaction():
            r = conn.execute("UPDATE cve_feed_watch SET enabled=%s WHERE id=%s RETURNING term", (enabled, wid)).fetchone()
            if not r:
                raise HTTPException(404, "No such entry.")
            audit(conn, actor=admin, actor_type="user", action="feeds_watch_" + ("enabled" if enabled else "disabled"),
                  detail={"term": r["term"]}, source_ip=client_ip(request))
        _feeds_cache_clear()
        return _feeds_admin_view(conn)


@app.delete("/api/v1/admin/feeds/watch/{wid}")
def feeds_watch_remove(wid: int, request: Request, admin: str = Depends(require_admin)):
    with db() as conn:
        with conn.transaction():
            r = conn.execute("DELETE FROM cve_feed_watch WHERE id=%s RETURNING term", (wid,)).fetchone()
            if not r:
                raise HTTPException(404, "No such entry.")
            audit(conn, actor=admin, actor_type="user", action="feeds_watch_removed",
                  detail={"term": r["term"]}, source_ip=client_ip(request))
        _feeds_cache_clear()
        return _feeds_admin_view(conn)


@app.post("/api/v1/admin/feeds/sync")
def feeds_sync_now(request: Request, admin: str = Depends(require_admin)):
    """Ask the worker to read the feeds now (within a minute)."""
    with db() as conn:
        with conn.transaction():
            conn.execute("UPDATE cve_feed_settings SET run_requested_at=now() WHERE id=1")
            audit(conn, actor=admin, actor_type="user", action="feeds_sync_requested", detail={},
                  source_ip=client_ip(request))
        return _feeds_admin_view(conn)


# Server software worth following that is commonly installed on Linux; offered
# as suggestions when one of your servers has it.
LINUX_NOTABLE = ["openssl", "openssh", "httpd", "nginx", "tomcat", "java", "postgresql", "mysql", "mariadb", "php",
                 "python3", "bind", "samba", "docker", "podman", "curl", "sudo", "glibc", "kernel", "systemd",
                 "polkit", "git", "redis", "haproxy", "squid", "postfix", "dovecot", "vim", "bash", "rsync"]


@app.get("/api/v1/admin/feeds/suggestions")
def feeds_suggestions(admin: str = Depends(require_admin)):
    """Software to choose from: what your servers run, most common first."""
    with db() as conn:
        win = conn.execute(
            r"""SELECT regexp_replace(regexp_replace(name, '\s*\(?\d[\d.]*(\s*\(?(x64|x86|64-bit|32-bit)\)?)?\)?\s*$', ''),
                                      '\s+', ' ', 'g') AS name, count(DISTINCT host_id) AS servers
                  FROM windows_software
                 WHERE name !~* '^(security update|update for|hotfix|microsoft visual c\+\+ 20\d\d (x64|x86) (minimum|additional) runtime)'
                 GROUP BY 1
                 ORDER BY 2 DESC, 1 LIMIT 80""").fetchall()
        lin = conn.execute(
            """SELECT n AS name, count(DISTINCT hp.host_id) AS servers
                 FROM unnest(%s::text[]) n
                 JOIN host_packages hp ON hp.name = n OR hp.name LIKE n || '-%%'
                GROUP BY 1 ORDER BY 2 DESC, 1""", (LINUX_NOTABLE,)).fetchall()
        oses = conn.execute(
            f"""SELECT DISTINCT {OS_LABEL_SQL} AS name FROM hosts h WHERE h.status <> 'decommissioned' ORDER BY 1""").fetchall()
        have = {r["term"].lower() for r in conn.execute("SELECT term FROM cve_feed_watch").fetchall()}
    import re as _re
    ok = _re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._+-]{1,59}$")

    seen = set()

    def keep(rows, kind):
        out = []
        for r in rows:
            n = _re.sub(r"\s*\((x64|x86|64-bit|32-bit)\)\s*$", "", (r["name"] or "").strip(), flags=_re.I)
            if ok.match(n) and n.lower() not in have and n.lower() not in seen:
                seen.add(n.lower())
                out.append({"name": n, "servers": r.get("servers"), "kind": kind})
        return out
    return {"windows": keep(win, "software"), "linux": keep(lin, "software"),
            "os": keep([{"name": r["name"].replace("RHEL", "Red Hat Enterprise Linux")} for r in oses], "software")}


# ---------------------------------------------------------------------------
# VMware infrastructure (read-only)
# ---------------------------------------------------------------------------

@app.get("/api/v1/admin/vmware/hosts")
def vmware_hosts(admin: str = Depends(require_viewer)):
    """Every ESXi host: hardware, version, state and load."""
    with db() as conn:
        rows = conn.execute(
            """SELECT e.*,
                      CASE WHEN e.memory_mb > 0
                           THEN round(100.0 * e.memory_usage_mb / e.memory_mb) END AS memory_pct,
                      CASE WHEN (e.cpu_mhz * e.cpu_cores) > 0
                           THEN round(100.0 * e.cpu_usage_mhz / (e.cpu_mhz * e.cpu_cores)) END AS cpu_pct
                 FROM esxi_hosts e
                ORDER BY e.vcenter, e.cluster NULLS LAST, e.name""").fetchall()
    return {"count": len(rows), "hosts": rows}


@app.get("/api/v1/admin/vmware/datastores")
def vmware_datastores(admin: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT *,
                      capacity_mb - free_mb AS used_mb,
                      CASE WHEN capacity_mb > 0
                           THEN round(100.0 * (capacity_mb - free_mb) / capacity_mb) END AS used_pct,
                      CASE WHEN capacity_mb > 0
                           THEN round(100.0 * (capacity_mb - free_mb + coalesce(uncommitted_mb,0))
                                      / capacity_mb) END AS provisioned_pct
                 FROM datastores
                ORDER BY used_pct DESC NULLS LAST, name""").fetchall()
    return {"count": len(rows), "datastores": rows}


@app.get("/api/v1/admin/vmware/networks")
def vmware_networks(admin: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT * FROM vm_networks ORDER BY vcenter, name""").fetchall()
    return {"count": len(rows), "networks": rows}


@app.get("/api/v1/admin/vmware/clusters")
def vmware_clusters(admin: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT c.*,
                      (SELECT count(*) FROM esxi_hosts e
                        WHERE e.vcenter = c.vcenter AND e.cluster = c.name) AS hosts_seen,
                      (SELECT count(*) FROM vm_inventory v
                        WHERE v.vcenter = c.vcenter AND v.cluster = c.name) AS vms
                 FROM vm_clusters c ORDER BY c.vcenter, c.name""").fetchall()
    return {"count": len(rows), "clusters": rows}


@app.get("/api/v1/admin/vmware/map")
def vmware_map(admin: str = Depends(require_viewer)):
    """The infrastructure tree, assembled for drawing:
    vCenter > datacenter > cluster > ESXi host > VM, plus datastores."""
    with db() as conn:
        hosts = conn.execute(
            """SELECT vcenter, moref, name, cluster, datacenter, connection_state,
                      power_state, maintenance_mode, esxi_version, cpu_cores,
                      memory_mb, cpu_usage_mhz, memory_usage_mb, cpu_mhz, vm_count,
                      uptime_seconds
                 FROM esxi_hosts ORDER BY vcenter, datacenter, cluster NULLS LAST, name"""
        ).fetchall()
        vms = conn.execute(
            """SELECT vcenter, datacenter, cluster, esxi_host, esxi_moref, moref, vm,
                      power_state, guest_os, is_linux, num_cpu, memory_mb, tools_running,
                      snapshot_count, oldest_snapshot_at, datastore_names, network_names,
                      host_id, server, agent_state, needs_patch, needs_reboot
                 FROM v_vm_map ORDER BY vm"""
        ).fetchall()
        ds = conn.execute(
            """SELECT vcenter, name, type, datacenter, capacity_mb, free_mb, vm_count,
                      CASE WHEN capacity_mb > 0
                           THEN round(100.0 * (capacity_mb - free_mb) / capacity_mb) END AS used_pct
                 FROM datastores ORDER BY name"""
        ).fetchall()
        vcs = conn.execute("SELECT name, host, version, last_sync_at, last_ok FROM vcenters ORDER BY name").fetchall()
    return {"vcenters": vcs, "hosts": hosts, "vms": vms, "datastores": ds}


# ---------------------------------------------------------------------------
# Sign in, sign out, password
# ---------------------------------------------------------------------------

class LoginIn(BaseModel):
    username: str = Field(..., max_length=64)
    password: str = Field(..., max_length=256)


@app.post("/api/v1/auth/login")
def login(body: LoginIn, request: Request):
    from . import auth
    ip = client_ip(request)
    with db() as conn:
        try:
            u = auth.authenticate(conn, body.username, body.password)
        except auth.LoginError as e:
            conn.commit()   # keep the failed-attempt count even though we refuse
            audit(conn, actor=(body.username or "")[:64] or "unknown", actor_type="user",
                  action="login_failed", detail={}, source_ip=ip)
            conn.commit()
            raise HTTPException(status_code=401, detail=str(e))
        token = auth.new_session(conn, u["id"], ip, request.headers.get("user-agent"))
        audit(conn, actor=u["username"], actor_type="user", action="login",
              detail={"role": u["role"]}, source_ip=ip)
    return {"token": token, "user": {"username": u["username"], "role": u["role"],
            "display_name": u["display_name"],
            "must_change_password": u["must_change_password"],
            "modules": auth.user_modules(u)}}


@app.post("/api/v1/auth/logout")
def logout(request: Request, user: str = Depends(require_viewer)):
    from . import auth
    header = request.headers.get("authorization") or ""
    if header.lower().startswith("bearer "):
        with db() as conn:
            auth.end_session(conn, header[7:].strip())
    return {"ok": True}


@app.get("/api/v1/auth/me")
def whoami(request: Request, user: str = Depends(require_viewer)):
    from . import auth
    u = request.state.user
    return {"username": u["username"], "role": u["role"],
            "display_name": u.get("display_name"),
            "must_change_password": u.get("must_change_password", False),
            "modules": auth.user_modules(u), "asset_perms": _asset_perms_me(u)}


def _asset_perms_me(u):
    with db() as conn:
        return _asset_perms(conn, u)


class PasswordIn(BaseModel):
    current_password: str = Field(..., max_length=256)
    new_password: str = Field(..., max_length=256)


@app.post("/api/v1/auth/password")
def change_password(body: PasswordIn, request: Request, user: str = Depends(require_viewer)):
    from . import auth
    with db() as conn:
        try:
            auth.authenticate(conn, user, body.current_password)
        except auth.LoginError:
            raise HTTPException(status_code=401, detail="The current password is not correct.")
        problem = auth.password_problem(body.new_password, user)
        if problem:
            raise HTTPException(status_code=422, detail=problem)
        uid = request.state.user["id"]
        conn.execute("""UPDATE users SET password_hash=%s, must_change_password=FALSE,
                               password_changed_at=now() WHERE id=%s""",
                     (auth.hash_password(body.new_password), uid))
        # Other sessions end: a password change is often a response to a leak
        header = request.headers.get("authorization") or ""
        keep = header[7:].strip() if header.lower().startswith("bearer ") else None
        if keep:
            conn.execute("DELETE FROM user_sessions WHERE user_id=%s AND token_hash <> %s",
                         (uid, auth._token_hash(keep)))
        audit(conn, actor=user, actor_type="user", action="password_changed",
              detail={}, source_ip=client_ip(request))
    return {"ok": True}


# ---------------------------------------------------------------------------
# User management (admin)
# ---------------------------------------------------------------------------

class UserIn(BaseModel):
    username: str = Field(..., max_length=64)
    display_name: Optional[str] = Field(default=None, max_length=120)
    role: str
    password: str = Field(..., max_length=256)
    modules: List[str] = Field(default_factory=list, max_length=3)    # none until an admin grants them


class UserPatch(BaseModel):
    display_name: Optional[str] = Field(default=None, max_length=120)
    role: Optional[str] = None
    active: Optional[bool] = None
    new_password: Optional[str] = Field(default=None, max_length=256)
    unlock: Optional[bool] = None
    modules: Optional[List[str]] = Field(default=None, max_length=3)
    asset_perms: Optional[List[str]] = Field(default=None, max_length=3)


def _active_admins(conn, excluding=None):
    return conn.execute(
        "SELECT count(*) AS n FROM users WHERE role='admin' AND active AND username <> %s",
        (excluding or "",)).fetchone()["n"]


@app.get("/api/v1/admin/users")
def list_users(user: str = Depends(require_admin)):
    with db() as conn:
        perms = {}
        try:
            with conn.transaction():
                perms = {r["username"]: r["asset_perms"] for r in conn.execute("SELECT username, asset_perms FROM users").fetchall()}
        except psycopg.errors.UndefinedColumn:
            pass
        rows = conn.execute(
            """SELECT username, display_name, role::text AS role, active, must_change_password, modules,
                      locked_until > now() AS locked, created_at, created_by, last_login_at,
                      password_changed_at,
                      (SELECT count(*) FROM user_sessions s
                        WHERE s.user_id = u.id AND s.expires_at > now()) AS sessions
                 FROM users u ORDER BY role DESC, username""").fetchall()
    rows = [{**dict(r), "asset_perms": perms.get(r["username"]) or []} for r in rows]
    return {"count": len(rows), "users": rows, "asset_perms_installed": bool(perms) or not rows}


@app.post("/api/v1/admin/users")
def create_user(body: UserIn, request: Request, user: str = Depends(require_admin)):
    from . import auth
    name = body.username.strip().lower()
    if not auth.USERNAME_RE.match(name):
        raise HTTPException(status_code=422,
                            detail="Usernames are 2 to 63 lowercase letters, digits, dots, dashes or underscores.")
    if body.role not in auth.ROLES:
        raise HTTPException(status_code=422, detail="Role must be viewer, operator or admin.")
    problem = auth.password_problem(body.password, name)
    if problem:
        raise HTTPException(status_code=422, detail=problem)
    mods = sorted(set(body.modules))
    if any(m not in auth.MODULES for m in mods):
        raise HTTPException(status_code=422, detail="Modules are patch, inventory and lifecycle.")
    with db() as conn:
        if conn.execute("SELECT 1 FROM users WHERE username=%s", (name,)).fetchone():
            raise HTTPException(status_code=409, detail="That username is taken.")
        # A password an admin chose is known to the admin: the user changes it
        conn.execute(
            """INSERT INTO users (username, display_name, role, password_hash,
                                  must_change_password, created_by, modules)
               VALUES (%s, %s, %s, %s, TRUE, %s, %s)""",
            (name, (body.display_name or "").strip() or None, body.role,
             auth.hash_password(body.password), user, mods))
        audit(conn, actor=user, actor_type="user", action="user_created",
              object_type="user", object_id=name, detail={"role": body.role, "modules": mods},
              source_ip=client_ip(request))
    return {"ok": True, "username": name}


@app.patch("/api/v1/admin/users/{username}")
def update_user(username: str, body: UserPatch, request: Request,
                user: str = Depends(require_admin)):
    from . import auth
    with db() as conn:
        row = conn.execute("SELECT id, role::text AS role, active FROM users WHERE username=%s",
                           (username,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="No such user.")
        # Never leave the platform without an active admin
        losing_admin = row["role"] == "admin" and (
            (body.role is not None and body.role != "admin") or body.active is False)
        if losing_admin and _active_admins(conn, excluding=username) == 0:
            raise HTTPException(status_code=409,
                                detail="This is the last active admin. Make someone else an admin first.")
        changes = {}
        if body.role is not None:
            if body.role not in auth.ROLES:
                raise HTTPException(status_code=422, detail="Role must be viewer, operator or admin.")
            conn.execute("UPDATE users SET role=%s WHERE id=%s", (body.role, row["id"]))
            changes["role"] = body.role
            if row["role"] == "admin" and body.role != "admin" and body.modules is None:
                # A former admin starts with no modules; an admin grants them under Access
                conn.execute("UPDATE users SET modules='{}' WHERE id=%s", (row["id"],))
                changes["modules"] = []
        if body.display_name is not None:
            conn.execute("UPDATE users SET display_name=%s WHERE id=%s",
                         (body.display_name.strip() or None, row["id"]))
            changes["display_name"] = True
        if body.active is not None:
            conn.execute("UPDATE users SET active=%s WHERE id=%s", (body.active, row["id"]))
            if not body.active:
                auth.end_all_sessions(conn, row["id"])
            changes["active"] = body.active
        if body.new_password:
            problem = auth.password_problem(body.new_password, username)
            if problem:
                raise HTTPException(status_code=422, detail=problem)
            conn.execute("""UPDATE users SET password_hash=%s, must_change_password=TRUE,
                                   password_changed_at=now(), failed_logins=0, locked_until=NULL
                             WHERE id=%s""", (auth.hash_password(body.new_password), row["id"]))
            auth.end_all_sessions(conn, row["id"])
            changes["password_reset"] = True
        if body.unlock:
            conn.execute("UPDATE users SET failed_logins=0, locked_until=NULL WHERE id=%s", (row["id"],))
            changes["unlocked"] = True
        if body.modules is not None:
            mods = sorted(set(body.modules))
            if any(m not in auth.MODULES for m in mods):
                raise HTTPException(status_code=422, detail="Modules are patch, inventory and lifecycle.")
            conn.execute("UPDATE users SET modules=%s WHERE id=%s", (mods, row["id"]))
            changes["modules"] = mods
        if body.asset_perms is not None:
            perms = sorted(set(body.asset_perms))
            if any(p not in ASSET_PERMS for p in perms):
                raise HTTPException(status_code=422, detail="Asset permissions are approve, decom and revoke.")
            try:
                with conn.transaction():
                    conn.execute("UPDATE users SET asset_perms=%s WHERE id=%s", (perms, row["id"]))
            except psycopg.errors.UndefinedColumn:
                raise HTTPException(503, "Asset permissions are not installed yet: run phase3a-schema.sh.")
            changes["asset_perms"] = perms
        audit(conn, actor=user, actor_type="user", action="user_updated",
              object_type="user", object_id=username, detail=changes,
              source_ip=client_ip(request))
        stored = conn.execute("SELECT modules FROM users WHERE id=%s", (row["id"],)).fetchone()
        stored_perms = changes.get("asset_perms")
    return {"ok": True, "changed": changes, "modules": (stored or {}).get("modules"), "asset_perms": stored_perms}


# ---------------------------------------------------------------------------
# Changes: patch jobs and VMware actions
# ---------------------------------------------------------------------------

class ChangeIn(BaseModel):
    kind: str
    title: Optional[str] = Field(default=None, max_length=200)
    reason: str = Field(..., max_length=2000)
    targets: List[Any]
    params: Dict[str, Any] = Field(default_factory=dict)
    run_after: Optional[str] = None
    run_before: Optional[str] = None
    max_parallel: int = 5


@app.post("/api/v1/changes/preview")
def preview_change(body: ChangeIn, request: Request, user: str = Depends(require_operator)):
    """What a change would do, before it is scheduled: for patching, the
    exact packages per server."""
    from . import changes as ch
    from .worker import choose_fixed_versions
    _change_ok(request, body.kind)
    with db() as conn:
        try:
            targets, params, ra, rb, mp = ch.validate(conn, body.kind, body.targets, body.params,
                                                      body.run_after, body.run_before, body.max_parallel)
        except ch.Invalid as e:
            raise HTTPException(status_code=422, detail=str(e))
        out = []
        if body.kind == "patch":
            for t in targets:
                pm = conn.execute("SELECT pkg_manager FROM hosts WHERE id=%s", (t["host_id"],)).fetchone()
                sql = """SELECT package_name, fixed_evr, advisory_id FROM host_applicability
                          WHERE host_id=%s AND state='affected' AND fixed_evr IS NOT NULL"""
                args = [t["host_id"]]
                if params["mode"] == "advisories":
                    sql += " AND advisory_id = ANY(%s)"
                    args.append(params["advisories"])
                rows = conn.execute(sql, args).fetchall()
                out.append({"label": t["label"], "host_id": t["host_id"],
                            "linked_vm": bool(t.get("vm_moref")),
                            "advisories": sorted({r["advisory_id"] for r in rows}),
                            "packages": choose_fixed_versions(rows, (pm or {}).get("pkg_manager"))})
        else:
            out = [{"label": t["label"], "vcenter": t["vcenter"], "vm_moref": t["vm_moref"]}
                   for t in targets]
    return {"kind": body.kind, "params": params, "targets": out,
            "run_after": ra, "run_before": rb, "max_parallel": mp}


@app.post("/api/v1/changes")
def create_change(body: ChangeIn, request: Request, user: str = Depends(require_operator)):
    from . import changes as ch
    _change_ok(request, body.kind)
    with db() as conn:
        try:
            targets, params, ra, rb, mp = ch.validate(conn, body.kind, body.targets, body.params,
                                                      body.run_after, body.run_before, body.max_parallel)
            with conn.transaction():
                cid, number = ch.create(conn, body.kind, body.title, body.reason, targets, params,
                                        ra, rb, mp, user, request.state.user["role"])
                audit(conn, actor=user, actor_type="user", action="change_created",
                      object_type="change", object_id=cid,
                      detail={"ref": ch.ref(number), "kind": body.kind, "targets": len(targets),
                              "reason": body.reason[:300]},
                      source_ip=client_ip(request))
        except ch.Invalid as e:
            raise HTTPException(status_code=422, detail=str(e))
    return {"id": cid, "ref": ch.ref(number), "number": number}


@app.get("/api/v1/changes")
def list_changes(request: Request, state: Optional[str] = None, limit: int = 100,
                 user: str = Depends(require_viewer)):
    limit = max(1, min(limit, 500))
    kinds = _allowed_kinds(request)
    with db() as conn:
        rows = conn.execute(
            """SELECT c.id, c.number, c.kind::text AS kind, c.title, c.reason, c.state::text AS state,
                      c.requested_by, c.requested_at, c.run_after, c.run_before, c.started_at,
                      c.finished_at, c.max_parallel, c.summary,
                      count(t.*) AS targets,
                      count(t.*) FILTER (WHERE t.state IN ('done','done_with_warnings'))   AS done,
                      count(t.*) FILTER (WHERE t.state='failed') AS failed,
                      count(t.*) FILTER (WHERE t.state NOT IN
                            ('queued','done','done_with_warnings','failed','skipped','cancelled')) AS in_progress
                 FROM changes c LEFT JOIN change_targets t ON t.change_id = c.id
                WHERE (%s::text IS NULL OR c.state::text = %s::text) AND c.kind::text = ANY(%s)
                GROUP BY c.id ORDER BY c.requested_at DESC LIMIT %s::int""",
            (state, state, kinds, limit)).fetchall()
    return {"count": len(rows), "changes": rows}


@app.get("/api/v1/changes/{change_id}")
def get_change(change_id: str, request: Request, user: str = Depends(require_viewer)):
    with db() as conn:
        c = conn.execute(
            """SELECT id, number, kind::text AS kind, title, reason, state::text AS state, params,
                      requested_by, requested_role::text AS requested_role, requested_at,
                      approval_required, approved_by, approved_at, run_after, run_before,
                      max_parallel, started_at, finished_at, cancel_requested, summary
                 FROM changes WHERE id::text=%s""", (change_id,)).fetchone()
        if not c:
            raise HTTPException(status_code=404, detail="No such change.")
        _change_ok(request, c["kind"])
        targets = conn.execute(
            """SELECT target_key, host_id, vcenter, vm_moref, label, state, step_started_at,
                      updated_at, snapshot_moref, detail, error
                 FROM change_targets WHERE change_id=%s ORDER BY label""", (c["id"],)).fetchall()
        events = conn.execute(
            """SELECT id, target_key, at, actor, event, ok, message
                 FROM change_events WHERE change_id=%s ORDER BY id""", (c["id"],)).fetchall()
    return {"change": c, "targets": targets, "events": events}


@app.post("/api/v1/changes/{change_id}/cancel")
def cancel_change(change_id: str, request: Request, user: str = Depends(require_operator)):
    """Stops a change. Servers not yet started are cancelled; a server part way
    through finishes its current step and stops before installing."""
    from . import changes as ch
    with db() as conn:
        with conn.transaction():
            c = conn.execute("SELECT id, number, state::text AS state, kind::text AS kind FROM changes "
                             "WHERE id::text=%s FOR UPDATE", (change_id,)).fetchone()
            if not c:
                raise HTTPException(status_code=404, detail="No such change.")
            _change_ok(request, c["kind"])
            if c["state"] in ("scheduled", "pending_approval"):
                conn.execute("UPDATE changes SET state='cancelled', finished_at=now() WHERE id=%s", (c["id"],))
                conn.execute("UPDATE change_targets SET state='cancelled' WHERE change_id=%s", (c["id"],))
            elif c["state"] == "running":
                conn.execute("UPDATE changes SET cancel_requested=TRUE WHERE id=%s", (c["id"],))
            else:
                raise HTTPException(status_code=409, detail=f"A {c['state']} change cannot be cancelled.")
            ch.event(conn, c["id"], None, user, "cancel_requested", None,
                     f"{ch.ref(c['number'])} cancelled by {user}")
            audit(conn, actor=user, actor_type="user", action="change_cancelled",
                  object_type="change", object_id=str(c["id"]), detail={"ref": ch.ref(c["number"])},
                  source_ip=client_ip(request))
    return {"ok": True}


@app.post("/api/v1/changes/{change_id}/decide")
def decide_change(change_id: str, request: Request, approve: bool = Body(..., embed=True),
                  note: Optional[str] = Body(default=None, embed=True),
                  user: str = Depends(require_admin)):
    """Only used when REQUIRE_APPROVAL is switched on."""
    from . import changes as ch
    with db() as conn:
        with conn.transaction():
            c = conn.execute("""SELECT id, number, requested_by, state::text AS state FROM changes
                                 WHERE id::text=%s FOR UPDATE""", (change_id,)).fetchone()
            if not c or c["state"] != "pending_approval":
                raise HTTPException(status_code=409, detail="This change is not waiting for approval.")
            if c["requested_by"] == user:
                raise HTTPException(status_code=403, detail="Nobody approves their own change.")
            conn.execute("""UPDATE changes SET state=%s, approved_by=%s, approved_at=now(),
                                   decision_note=%s WHERE id=%s""",
                         ("scheduled" if approve else "rejected", user, (note or "")[:1000], c["id"]))
            ch.event(conn, c["id"], None, user, "approved" if approve else "rejected", approve, note)
    return {"ok": True}


@app.get("/api/v1/worker/status")
def worker_status(user: str = Depends(require_viewer)):
    with db() as conn:
        beats = conn.execute("""SELECT name, beat_at, started_at, detail,
                                       extract(epoch FROM now() - beat_at)::int AS seconds_ago
                                  FROM worker_heartbeat ORDER BY name""").fetchall()
    # Each thread reports at its own pace (hardening only hourly), so each is
    # judged against its own interval. "alive" is the change runner alone:
    # that is what decides whether scheduled changes start.
    limit = {"changes": 90, "enrichment": 180, "vmware_live": 180, "mail": 300, "hardening": 2 * 3600 + 300,
             "feeds": 3 * 3600, "impact": 3600, "insights": 1800, "antivirus": 1800}
    for b in beats:
        b["stale"] = b["seconds_ago"] > limit.get(b["name"], 600)
    ch = next((b for b in beats if b["name"] == "changes"), None)
    alive = bool(ch) and not ch["stale"]
    return {"alive": alive, "threads": beats, "stale": [b["name"] for b in beats if b["stale"]]}


@app.get("/api/v1/admin/vmware/writers")
def vmware_writers(user: str = Depends(require_viewer)):
    """Which vCenters have a write account, so the console only offers
    actions that can actually be carried out."""
    from . import vmware
    import glob as _g
    names = [v["name"] for v in vmware.load_vcenters()]
    have = {os.path.basename(f)[:-len(vmware.WRITE_SUFFIX) - 4]
            for f in _g.glob(os.path.join(vmware.CONFIG_DIR, "*" + vmware.WRITE_SUFFIX + ".env"))}
    return {"vcenters": [{"name": n, "can_write": n in have} for n in names]}


@app.get("/api/v1/admin/vmware/vm/{vcenter}/{moref}")
def vmware_vm_detail(vcenter: str, moref: str, user: str = Depends(require_viewer)):
    with db() as conn:
        row = conn.execute("SELECT * FROM v_vm_map WHERE vcenter=%s AND moref=%s",
                           (vcenter, moref)).fetchone()
        snaps = conn.execute("SELECT snapshots FROM vm_inventory WHERE vcenter=%s AND moref=%s",
                             (vcenter, moref)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="No such VM.")
    return {"vm": row, "snapshots": (snaps or {}).get("snapshots") or []}


# ---------------------------------------------------------------------------
# VMware live map, blast radius, coverage (read-only, vCenter data only)
# ---------------------------------------------------------------------------

def _vmware_model(conn):
    from . import blast as bl
    hosts = conn.execute("SELECT * FROM esxi_hosts").fetchall()
    vms = conn.execute(
        """SELECT v.vcenter, v.moref, v.name, v.power_state, v.guest_os, v.is_linux, v.num_cpu,
                  v.memory_mb, v.tools_running, v.snapshot_count, v.oldest_snapshot_at,
                  v.datastore_names, v.network_names, v.esxi_moref, v.esxi_host, v.cluster,
                  v.datacenter, v.folder_path, v.overall_status, v.alarms, v.tags, v.app_group,
                  v.app_group_source, v.host_id, h.hostname AS server,
                  agent_state(h.last_checkin, h.status) AS agent_state,
                  (SELECT count(*) FROM host_applicability ha
                    WHERE ha.host_id = v.host_id AND ha.state = 'affected') AS needs_patch,
                  (SELECT count(*) FROM host_applicability ha
                    WHERE ha.host_id = v.host_id AND ha.state = 'fixed_pending_reboot') AS needs_reboot,
                  (SELECT count(*) FROM host_applicability ha
                     JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id
                    WHERE ha.host_id = v.host_id AND ha.state = 'affected' AND r.any_kev) AS kev_advisories
             FROM vm_inventory v LEFT JOIN hosts h ON h.id = v.host_id""").fetchall()
    ds = conn.execute("SELECT * FROM datastores").fetchall()
    nets = conn.execute("SELECT * FROM vm_networks").fetchall()
    cls = conn.execute("SELECT * FROM vm_clusters").fetchall()
    return bl.build_model(hosts, vms, ds, nets, cls)


def _live_meta(conn):
    return conn.execute(
        """SELECT c.name AS vcenter, l.connected, l.connected_since, l.last_update_at,
                  l.last_event_at, l.error, c.last_sync_at, c.last_ok
             FROM vcenters c LEFT JOIN vmware_live l ON l.vcenter = c.name
            ORDER BY c.name""").fetchall()


@app.get("/api/v1/admin/vmware/graph")
def vmware_graph(user: str = Depends(require_viewer)):
    """Everything the live map draws, graded red, amber, green or grey."""
    with db() as conn:
        m = _vmware_model(conn)
        live = _live_meta(conn)
        last = conn.execute("SELECT coalesce(max(id), 0) AS id FROM vmware_changes").fetchone()["id"]
        last_ev = conn.execute("SELECT coalesce(max(id), 0) AS id FROM vmware_events").fetchone()["id"]
    pick = lambda d, ks: {k: d.get(k) for k in ks}  # noqa: E731
    return {
        "live": live, "change_id": last, "event_id": last_ev,
        "clusters": [pick(c, ["key", "vcenter", "name", "datacenter", "ha_enabled", "drs_enabled",
                              "num_hosts", "grade"]) for c in m["clusters"].values()],
        "hosts": [dict(pick(h, ["key", "vcenter", "moref", "name", "cluster", "datacenter",
                                "connection_state", "maintenance_mode", "esxi_version", "esxi_build",
                                "cpu_cores", "memory_mb", "vm_count", "uptime_seconds", "grade"]),
                       cpu_pct=_pct(h.get("cpu_usage_mhz"), (h.get("cpu_mhz") or 0) * (h.get("cpu_cores") or 0)),
                       mem_pct=_pct(h.get("memory_usage_mb"), h.get("memory_mb")))
                  for h in m["hosts"].values()],
        "datastores": [dict(pick(d, ["key", "vcenter", "name", "type", "capacity_mb", "free_mb",
                                     "host_count", "vm_count", "local", "grade"]),
                            used_pct=_pct((d.get("capacity_mb") or 0) - (d.get("free_mb") or 0),
                                          d.get("capacity_mb")))
                       for d in m["datastores"].values()],
        "networks": [pick(n, ["key", "vcenter", "name", "kind", "vm_count", "grade"])
                     for n in m["networks"].values()],
        "vms": [pick(v, ["key", "vcenter", "moref", "name", "power_state", "guest_os", "is_linux",
                         "num_cpu", "memory_mb", "tools_running", "snapshot_count", "host_key",
                         "esxi_host", "cluster", "ds_keys", "net_keys", "app_group", "app_group_source",
                         "host_id", "server", "agent_state", "needs_patch", "kev_advisories", "grade"])
                for v in m["vms"].values()],
    }


def _pct(used, total):
    from . import blast as bl
    return bl.pct(used, total)


@app.get("/api/v1/admin/vmware/blast")
def vmware_blast(kind: str, key: str, user: str = Depends(require_viewer)):
    """What fails with this host, datastore or port group."""
    if kind not in ("host", "datastore", "network"):
        raise HTTPException(422, "kind must be host, datastore or network")
    from . import blast as bl
    with db() as conn:
        m = _vmware_model(conn)
    r = bl.blast(m, kind, key)
    if r is None:
        raise HTTPException(404, "Not found. It may have been removed since the map loaded.")
    return r


@app.get("/api/v1/admin/vmware/live")
def vmware_live(since: int = 0, since_event: int = 0, user: str = Depends(require_viewer)):
    """Changes and events after the given ids. The map polls this."""
    with db() as conn:
        changes = conn.execute(
            """SELECT id, at, vcenter, object_type, moref, name, field, old_value, new_value
                 FROM vmware_changes WHERE id > %s::bigint ORDER BY id LIMIT 500""", (since,)).fetchall()
        events = conn.execute(
            """SELECT id, vcenter, created_at, kind, severity, object_type, object_moref,
                      object_name, user_name, message
                 FROM vmware_events WHERE id > %s::bigint ORDER BY id DESC LIMIT 100""",
            (since_event,)).fetchall()
        live = _live_meta(conn)
        last = conn.execute("SELECT coalesce(max(id), 0) AS id FROM vmware_changes").fetchone()["id"]
        last_ev = conn.execute("SELECT coalesce(max(id), 0) AS id FROM vmware_events").fetchone()["id"]
    return {"changes": changes, "events": events, "live": live,
            "change_id": last, "event_id": last_ev}


@app.get("/api/v1/admin/vmware/events")
def vmware_events(limit: int = 100, user: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT id, vcenter, created_at, kind, severity, object_type, object_moref,
                      object_name, user_name, message
                 FROM vmware_events ORDER BY created_at DESC LIMIT %s::int""",
            (max(1, min(limit, 500)),)).fetchall()
    return {"events": rows}


@app.get("/api/v1/admin/vmware/coverage")
def vmware_coverage(user: str = Depends(require_viewer)):
    """How much of the estate the map can fully describe: Distributed vs
    standard switches (flow data needs Distributed), and application grouping."""
    with db() as conn:
        rows = conn.execute(
            """WITH per_vm AS (
                 SELECT v.vcenter, v.moref, v.name, v.power_state, v.app_group, v.app_group_source,
                        v.cluster, v.folder_path,
                        count(n.moref) FILTER (WHERE n.kind = 'DistributedVirtualPortgroup') AS vds,
                        count(n.moref) FILTER (WHERE n.kind = 'Network') AS std,
                        count(n.moref) FILTER (WHERE n.kind NOT IN ('DistributedVirtualPortgroup','Network')) AS other
                   FROM vm_inventory v
                   LEFT JOIN vm_networks n ON n.vcenter = v.vcenter AND n.name = ANY(v.network_names)
                  GROUP BY v.vcenter, v.moref, v.name, v.power_state, v.app_group,
                           v.app_group_source, v.cluster, v.folder_path)
               SELECT *, CASE WHEN vds > 0 AND std = 0 THEN 'distributed'
                              WHEN vds > 0 AND std > 0 THEN 'mixed'
                              WHEN std > 0 THEN 'standard'
                              WHEN other > 0 THEN 'other'
                              ELSE 'none' END AS switching
                 FROM per_vm ORDER BY name""").fetchall()
    sw = {"distributed": 0, "mixed": 0, "standard": 0, "other": 0, "none": 0}
    grp = {"tag": 0, "folder": 0, "none": 0}
    for r in rows:
        sw[r["switching"]] += 1
        grp[r["app_group_source"] or "none"] += 1
    apps = {}
    for r in rows:
        if r["app_group"]:
            a = apps.setdefault(r["app_group"], {"app": r["app_group"], "source": r["app_group_source"], "vms": 0})
            a["vms"] += 1
    return {"total": len(rows), "switching": sw, "grouping": grp,
            "apps": sorted(apps.values(), key=lambda a: (-a["vms"], a["app"])),
            "standard_only": [dict(vcenter=r["vcenter"], name=r["name"], cluster=r["cluster"])
                              for r in rows if r["switching"] == "standard"],
            "ungrouped": [dict(vcenter=r["vcenter"], name=r["name"], cluster=r["cluster"],
                               folder=r["folder_path"]) for r in rows if not r["app_group"]]}


# ---------------------------------------------------------------------------
# Hardening (OpenSCAP, CIS-aligned)
# ---------------------------------------------------------------------------

HARDENING_LEVELS = ("l1", "l2")
SCAN_STALE_HOURS = 5


@app.get("/api/v1/agent/hardening/content/{product}")
def agent_hardening_content(product: str, agent: AgentIdentity = Depends(require_agent)):
    """The active benchmark data stream for this product, as a file."""
    from fastapi.responses import FileResponse
    from . import hardening as hd
    with db() as conn:
        c = hd.active_content(conn, product)
    if not c:
        raise HTTPException(404, f"no active hardening content for {product}")
    path = os.path.join(hd.CONTENT_DIR, c["file_name"]) if not c["file_name"].startswith("/") else c["file_name"]
    if not os.path.exists(path):
        raise HTTPException(503, "hardening content is registered but its file is missing on PATCH-01")
    return FileResponse(path, media_type="application/xml",
                        headers={"X-Content-SHA256": c["sha256"], "X-Content-Version": c["content_version"]})


class HardeningProgressIn(BaseModel):
    scan_id: str
    stage: str = Field(..., pattern="^(downloading|scanning|uploading)$")
    done: Optional[int] = Field(default=None, ge=0, le=100000)
    total: Optional[int] = Field(default=None, ge=0, le=100000)


@app.post("/api/v1/agent/hardening/progress")
def agent_hardening_progress(body: HardeningProgressIn, agent: AgentIdentity = Depends(require_agent)):
    """Where a running scan has got to. Best effort: a lost update only
    means the console shows the previous figure a little longer."""
    with db() as conn:
        cur = conn.execute(
            """UPDATE hardening_scans SET stage=%s, stage_at=now(),
                      progress_done=coalesce(%s, progress_done), progress_total=coalesce(%s, progress_total)
                WHERE id=%s AND host_id=%s AND state IN ('queued','running')""",
            (body.stage, body.done, body.total, body.scan_id, agent.host_id))
        conn.commit()
    return {"ok": bool(cur.rowcount)}


class HardeningResultIn(BaseModel):
    scan_id: str
    arf_gz_b64: str = Field(..., max_length=60_000_000)
    oscap_version: Optional[str] = Field(default=None, max_length=200)
    exit_code: Optional[int] = None


@app.post("/api/v1/agent/hardening/result")
def agent_hardening_result(body: HardeningResultIn, agent: AgentIdentity = Depends(require_agent)):
    """The agent's scan result. Kept as evidence, then parsed."""
    import base64
    from . import hardening as hd
    with db() as conn:
        scan = conn.execute("SELECT id, state FROM hardening_scans WHERE id=%s AND host_id=%s",
                            (body.scan_id, agent.host_id)).fetchone()
        if not scan:
            raise HTTPException(404, "no such scan for this host")
        conn.execute("UPDATE hardening_scans SET stage='processing', stage_at=now() WHERE id=%s",
                     (body.scan_id,))
        conn.commit()
        try:
            data = base64.b64decode(body.arf_gz_b64, validate=True)
            r = hd.ingest(conn, body.scan_id, data, body.oscap_version)
        except Exception as e:  # noqa: BLE001 - the reason is shown on the scan
            conn.execute("UPDATE hardening_scans SET state='failed', finished_at=now(), error=%s WHERE id=%s",
                         (f"result could not be read: {e}"[:500], body.scan_id))
            conn.commit()
            raise HTTPException(422, f"result could not be read: {e}")
    return {"ok": True, **r}


def _host_product(h):
    from . import hardening as hd
    return hd.product_for(h["os_id"], h["os_version"])


def queue_hardening_scan(conn, host, level, requested_by):
    from . import hardening as hd
    return hd.queue_scan(conn, host, level, requested_by)


class HardeningScanIn(BaseModel):
    level: str = "l1"
    host_ids: Optional[List[str]] = None       # none means every active server


@app.post("/api/v1/hardening/scans")
def hardening_scan(body: HardeningScanIn, request: Request, user: str = Depends(require_operator)):
    _level(body.level)
    queued, skipped = [], []
    with db() as conn:
        with conn.transaction():
            hosts = conn.execute(
                """SELECT id, hostname, os_id, os_version FROM hosts
                    WHERE status <> 'decommissioned' AND (%s::uuid[] IS NULL OR id = ANY(%s::uuid[]))
                    ORDER BY hostname""", (body.host_ids, body.host_ids)).fetchall()
            for hst in hosts:
                sid, why = queue_hardening_scan(conn, hst, body.level, user)
                (queued if sid else skipped).append({"host_id": str(hst["id"]), "hostname": hst["hostname"],
                                                     "scan_id": sid, "reason": why})
            conn.execute(
                """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
                   VALUES (%s,'user','hardening_scan_requested','hardening',%s,%s,%s)""",
                (user, body.level, json.dumps({"queued": len(queued), "skipped": len(skipped)}),
                 client_ip(request)))
    return {"queued": queued, "skipped": skipped}


def _level(level):
    if level in HARDENING_LEVELS:
        return level
    if re.match(r"^custom:[0-9a-f-]{36}$", level or ""):
        return level
    raise HTTPException(422, "level must be l1, l2 or a custom profile")


@app.get("/api/v1/hardening/summary")
def hardening_summary(level: str = "l1", user: str = Depends(require_viewer)):
    _level(level)
    with db() as conn:
        latest = conn.execute("SELECT * FROM v_hardening_latest WHERE level=%s", (level,)).fetchall()
        hosts = conn.execute("SELECT id, os_id, os_version FROM hosts WHERE status <> 'decommissioned'").fetchall()
        content = conn.execute(
            """SELECT c.content_version, c.product, c.benchmark_version,
                      array_remove(array_agg(DISTINCT p.level), NULL) AS levels
                 FROM hardening_content c LEFT JOIN hardening_profiles p USING (content_version, product)
                WHERE c.active GROUP BY 1,2,3 ORDER BY 2""").fetchall()
        top = conn.execute(
            """SELECT r.rule_id, hr.title, hr.severity, hr.cis_ref, hr.risky, hr.fix_available,
                      count(*) AS servers
                 FROM v_hardening_latest l
                 JOIN hardening_results r ON r.scan_id = l.id AND r.result = 'fail'
                 LEFT JOIN hardening_rules hr ON hr.content_version = l.content_version
                      AND hr.product = l.product AND hr.rule_id = r.rule_id
                WHERE l.level = %s
                GROUP BY 1,2,3,4,5,6
                ORDER BY servers DESC,
                         CASE hr.severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 WHEN 'low' THEN 2 ELSE 3 END, 2
                LIMIT 15""", (level,)).fetchall()
        trend = conn.execute(
            """SELECT date_trunc('day', finished_at)::date AS day, round(avg(score), 1) AS score, count(*) AS scans
                 FROM hardening_scans WHERE level=%s AND state='done' AND finished_at > now() - interval '90 days'
                GROUP BY 1 ORDER BY 1""", (level,)).fetchall()
    have = {c["product"]: c for c in content}
    from . import hardening as hd
    custom = level.startswith("custom:")
    no_content = sum(1 for h in hosts
                     if not (hd.product_for(h["os_id"], h["os_version"]) in have
                             and (custom or level in (have[hd.product_for(h["os_id"], h["os_version"])]["levels"] or []))))
    scores = [float(x["score"]) for x in latest if x["score"] is not None]
    return {
        "level": level, "servers": len(hosts), "scanned": len(latest), "no_content": no_content,
        "fleet_score": round(sum(scores) / len(scores), 1) if scores else None,
        "failed_rules_total": sum(x["failed"] or 0 for x in latest),
        "bands": {"good": sum(1 for x in scores if x >= 85), "fair": sum(1 for x in scores if 70 <= x < 85),
                  "poor": sum(1 for x in scores if x < 70)},
        "content": content, "top_failing": top, "trend": trend,
    }


@app.get("/api/v1/hardening/hosts")
def hardening_hosts(level: str = "l1", user: str = Depends(require_viewer)):
    _level(level)
    from . import hardening as hd
    with db() as conn:
        rows = conn.execute(
            """SELECT h.id, h.hostname, h.os_id, h.os_version, h.host_group,
                      l.id AS scan_id, l.score, l.passed, l.failed, l.not_applicable, l.finished_at,
                      l.content_version, l.product,
                      n.state AS last_state, n.error AS last_error, n.requested_at AS last_requested,
                      n.stage, n.stage_at, n.progress_done, n.progress_total, n.agent_version,
                      (SELECT count(*) FROM hardening_results r
                         JOIN hardening_rules hr ON hr.content_version = l.content_version
                              AND hr.product = l.product AND hr.rule_id = r.rule_id
                        WHERE r.scan_id = l.id AND r.result = 'fail' AND hr.severity = 'high') AS high_failed
                 FROM hosts h
                 LEFT JOIN v_hardening_latest l ON l.host_id = h.id AND l.level = %s
                 LEFT JOIN LATERAL (SELECT s.state, s.error, s.requested_at, s.stage, s.stage_at,
                                           s.progress_done, s.progress_total, h.agent_version
                                      FROM hardening_scans s
                                     WHERE s.host_id = h.id AND s.level = %s
                                     ORDER BY requested_at DESC LIMIT 1) n ON TRUE
                WHERE h.status <> 'decommissioned'
                ORDER BY l.score NULLS LAST, h.hostname""", (level, level)).fetchall()
    for r in rows:
        r["product"] = r["product"] or hd.product_for(r["os_id"], r["os_version"])
        if r["last_state"] in ("queued", "running") and r["last_requested"]:
            from datetime import datetime, timezone, timedelta
            if datetime.now(timezone.utc) - r["last_requested"] > timedelta(hours=SCAN_STALE_HOURS):
                r["last_state"], r["last_error"] = "failed", "the agent did not pick the scan up in time"
    return {"level": level, "hosts": rows}


@app.get("/api/v1/hardening/hosts/{host_id}")
def hardening_host(host_id: str, level: str = "l1", user: str = Depends(require_viewer)):
    _level(level)
    with db() as conn:
        host = conn.execute("SELECT id, hostname, os_id, os_version, host_group FROM hosts WHERE id=%s",
                            (host_id,)).fetchone()
        if not host:
            raise HTTPException(404, "No such server.")
        scan = conn.execute("SELECT * FROM v_hardening_latest WHERE host_id=%s AND level=%s",
                            (host_id, level)).fetchone()
        results = []
        if scan:
            results = conn.execute(
                """SELECT r.rule_id, r.result, coalesce(hr.severity, r.severity) AS severity, hr.title,
                          hr.cis_ref, hr.description, hr.rationale, hr.fix_available, hr.risky
                     FROM hardening_results r
                     LEFT JOIN hardening_rules hr ON hr.content_version=%s AND hr.product=%s AND hr.rule_id=r.rule_id
                    WHERE r.scan_id=%s
                    ORDER BY CASE r.result WHEN 'fail' THEN 0 WHEN 'error' THEN 1 WHEN 'pass' THEN 3 ELSE 2 END,
                             CASE hr.severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 WHEN 'low' THEN 2 ELSE 3 END,
                             hr.cis_ref NULLS LAST, hr.title""",
                (scan["content_version"], scan["product"], scan["id"])).fetchall()
        history = conn.execute(
            """SELECT id, state, score, passed, failed, requested_at, finished_at, requested_by, error,
                      stage, stage_at, progress_done, progress_total
                 FROM hardening_scans WHERE host_id=%s AND level=%s ORDER BY requested_at DESC LIMIT 12""",
            (host_id, level)).fetchall()
    return {"host": host, "level": level, "scan": scan, "results": results, "history": history}


@app.get("/api/v1/hardening/rules/{rule_id}")
def hardening_rule(rule_id: str, level: str = "l1", user: str = Depends(require_viewer)):
    _level(level)
    with db() as conn:
        rule = conn.execute(
            """SELECT r.* FROM hardening_rules r JOIN hardening_content c USING (content_version, product)
                WHERE c.active AND r.rule_id=%s ORDER BY r.product LIMIT 1""", (rule_id,)).fetchone()
        if not rule:
            raise HTTPException(404, "No such rule in the active content.")
        servers = conn.execute(
            """SELECT l.host_id, l.hostname, l.product, l.finished_at, r.result
                 FROM v_hardening_latest l JOIN hardening_results r ON r.scan_id = l.id AND r.rule_id = %s
                WHERE l.level = %s
                ORDER BY CASE r.result WHEN 'fail' THEN 0 WHEN 'error' THEN 1 ELSE 2 END, l.hostname""",
            (rule_id, level)).fetchall()
    rule.pop("fix_script", None)
    return {"rule": rule, "level": level, "servers": servers}


# ---------------------------------------------------------------------------
# Mail alerts (admin): settings, recipients, tests
# ---------------------------------------------------------------------------

EMAIL_RE = r"^[^@\s,;<>]+@[^@\s,;<>]+\.[^@\s,;<>]+$"


def _mail_audit(conn, admin, request, action, obj, detail):
    conn.execute(
        """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
           VALUES (%s,'user',%s,'mail',%s,%s,%s)""",
        (admin, action, obj, json.dumps(detail), client_ip(request)))


def _mail_view(conn):
    from . import notify as nt
    cfg = nt.config(conn, with_password=False)
    recips = conn.execute("SELECT * FROM mail_recipients ORDER BY lower(address)").fetchall()
    recent = conn.execute(
        """SELECT id, created_at, category, severity, subject, recipients, state, attempts,
                  sent_at, last_error FROM notifications ORDER BY id DESC LIMIT 60""").fetchall()
    counts = conn.execute("""SELECT state, count(*) AS n FROM notifications
                              WHERE created_at > now() - interval '7 days' GROUP BY 1""").fetchall()
    beat = conn.execute("SELECT beat_at, detail FROM worker_heartbeat WHERE name='mail'").fetchone()
    pub = nt.public_config(cfg)
    pub["key_present"] = os.path.exists(nt.KEY_FILE)
    return {"settings": pub, "recipients": recips, "recent": recent,
            "counts_7d": {r["state"]: r["n"] for r in counts}, "worker": beat}


@app.get("/api/v1/admin/mail")
def mail_get(admin: str = Depends(require_admin)):
    with db() as conn:
        return _mail_view(conn)


class MailSettingsIn(BaseModel):
    enabled: bool = False
    host: str = Field(default="", max_length=253)
    port: int = Field(default=25, ge=1, le=65535)
    tls: str = Field(default="starttls", pattern="^(starttls|tls|none)$")
    verify: bool = True
    ca_pem: Optional[str] = Field(default=None, max_length=20000)
    username: str = Field(default="", max_length=320)
    # None keeps the saved password; "" removes it; anything else replaces it
    password: Optional[str] = Field(default=None, max_length=512)
    from_addr: str = Field(default="", max_length=320)
    from_name: str = Field(default="", max_length=120)
    send_critical: bool = True
    send_tasks: bool = True
    send_digest: bool = True
    send_weekly: bool = True
    digest_time: str = Field(default="07:00", pattern="^([01][0-9]|2[0-3]):[0-5][0-9]$")
    weekly_day: str = Field(default="mon", pattern="^(mon|tue|wed|thu|fri|sat|sun)$")
    console_url: str = Field(default="", max_length=300)
    company: str = Field(default="", max_length=120)
    signature: str = Field(default="", max_length=2000)


def _cfg_from_form(conn, body):
    """A config built from form values not yet saved, for testing before saving."""
    from . import notify as nt
    cfg = nt.config(conn)
    cfg.update(host=body.host.strip(), port=body.port, tls=body.tls, verify=body.verify,
               ca_pem=(body.ca_pem or "").strip() or None, user=body.username.strip(),
               **{"from": body.from_addr.strip()}, from_name=body.from_name.strip(),
               console=body.console_url.strip().rstrip("/"), company=body.company.strip() or "PATCH-01",
               signature=body.signature.strip())
    if body.password is not None:
        cfg["password"] = body.password
    return cfg


@app.put("/api/v1/admin/mail")
def mail_save(body: MailSettingsIn, request: Request, admin: str = Depends(require_admin)):
    import re as _re
    from . import notify as nt
    if body.from_addr and not _re.match(EMAIL_RE, body.from_addr.strip()):
        raise HTTPException(422, "The From address is not an e-mail address.")
    if body.enabled and not (body.host.strip() and body.from_addr.strip()):
        raise HTTPException(422, "To turn mail on, enter the relay host and the From address.")
    if body.ca_pem and "BEGIN CERTIFICATE" not in body.ca_pem:
        raise HTTPException(422, "The CA certificate must be PEM text starting with -----BEGIN CERTIFICATE-----.")
    with db() as conn:
        with conn.transaction():
            enc = None
            if body.password:
                try:
                    enc = nt.encrypt(body.password)
                except RuntimeError as e:
                    raise HTTPException(503, str(e))
            if body.enabled and not conn.execute("SELECT 1 FROM mail_recipients LIMIT 1").fetchone():
                raise HTTPException(422, "Add at least one recipient before turning mail on.")
            conn.execute(
                """UPDATE mail_settings SET enabled=%s, host=%s, port=%s, tls=%s, verify=%s, ca_pem=%s,
                          username=%s, from_addr=%s, from_name=%s, send_critical=%s, send_tasks=%s,
                          send_digest=%s, send_weekly=%s, digest_time=%s, weekly_day=%s, console_url=%s,
                          company=%s, signature=%s, updated_by=%s, updated_at=now(),
                          password_enc = CASE WHEN %s::boolean THEN %s
                                              WHEN %s::boolean THEN NULL ELSE password_enc END
                    WHERE id = 1""",
                (body.enabled, body.host.strip(), body.port, body.tls, body.verify, (body.ca_pem or "").strip() or None,
                 body.username.strip(), body.from_addr.strip(), body.from_name.strip(), body.send_critical,
                 body.send_tasks, body.send_digest, body.send_weekly, body.digest_time, body.weekly_day,
                 body.console_url.strip().rstrip("/"), body.company.strip(), body.signature.strip(), admin,
                 enc is not None, enc, body.password == "" and enc is None))
            _mail_audit(conn, admin, request, "mail_settings_saved", body.host.strip() or "-",
                        {"enabled": body.enabled, "host": body.host, "port": body.port, "tls": body.tls,
                         "verify": body.verify, "login": bool(body.username),
                         "password": "replaced" if enc else ("removed" if body.password == "" else "unchanged")})
        return _mail_view(conn)


@app.post("/api/v1/admin/mail/check")
def mail_check(body: MailSettingsIn, request: Request, admin: str = Depends(require_admin)):
    """Test the relay with the values in the form, saved or not. Sends nothing."""
    from . import notify as nt
    with db() as conn:
        try:
            cfg = _cfg_from_form(conn, body)
        except RuntimeError as e:
            return {"ok": False, "steps": [{"step": "Password", "ok": False, "detail": str(e)}]}
        steps = nt.test_connection(cfg)
        _mail_audit(conn, admin, request, "mail_connection_test", cfg["host"] or "-",
                    {"ok": all(x["ok"] for x in steps), "failed_at": next((x["step"] for x in steps if not x["ok"]), None)})
        conn.commit()
    return {"ok": all(x["ok"] for x in steps), "steps": steps}


class MailTestIn(BaseModel):
    to: Optional[str] = Field(default=None, max_length=320)


@app.post("/api/v1/admin/mail/test")
def mail_test(body: MailTestIn, request: Request, admin: str = Depends(require_admin)):
    """Send a real test mail with the saved settings."""
    import re as _re
    from . import notify as nt
    with db() as conn:
        cfg = nt.config(conn)
        to = [body.to.strip()] if body.to and _re.match(EMAIL_RE, body.to.strip()) else cfg["to"]
        try:
            nt.test_mail(cfg, to)
            ok, err = True, None
        except Exception as e:  # noqa: BLE001 - the reason is the point of a test
            ok, err = False, str(e)
        _mail_audit(conn, admin, request, "mail_test", ", ".join(to) or "-", {"ok": ok, "error": err})
        conn.commit()
    if not ok:
        raise HTTPException(502, err)
    return {"ok": True, "to": to}


class RecipientIn(BaseModel):
    address: str = Field(..., max_length=320)
    name: str = Field(default="", max_length=120)
    critical: bool = True
    tasks: bool = True
    digest: bool = True
    weekly: bool = True


@app.post("/api/v1/admin/mail/recipients")
def mail_recipient_add(body: RecipientIn, request: Request, admin: str = Depends(require_admin)):
    import re as _re
    addr = body.address.strip()
    if not _re.match(EMAIL_RE, addr):
        raise HTTPException(422, f"'{addr}' is not an e-mail address.")
    with db() as conn:
        with conn.transaction():
            if conn.execute("SELECT 1 FROM mail_recipients WHERE lower(address)=lower(%s)", (addr,)).fetchone():
                raise HTTPException(409, f"{addr} is already a recipient.")
            conn.execute(
                """INSERT INTO mail_recipients (address, name, critical, tasks, digest, weekly, added_by)
                   VALUES (%s,%s,%s,%s,%s,%s,%s)""",
                (addr, body.name.strip() or None, body.critical, body.tasks, body.digest, body.weekly, admin))
            _mail_audit(conn, admin, request, "mail_recipient_added", addr,
                        {"critical": body.critical, "tasks": body.tasks, "digest": body.digest, "weekly": body.weekly})
        return _mail_view(conn)


class RecipientPatch(BaseModel):
    name: Optional[str] = Field(default=None, max_length=120)
    critical: Optional[bool] = None
    tasks: Optional[bool] = None
    digest: Optional[bool] = None
    weekly: Optional[bool] = None


@app.patch("/api/v1/admin/mail/recipients/{rid}")
def mail_recipient_update(rid: int, body: RecipientPatch, request: Request, admin: str = Depends(require_admin)):
    changes = {k: v for k, v in body.model_dump().items() if v is not None}
    if not changes:
        raise HTTPException(422, "Nothing to change.")
    with db() as conn:
        with conn.transaction():
            row = conn.execute("SELECT address FROM mail_recipients WHERE id=%s", (rid,)).fetchone()
            if not row:
                raise HTTPException(404, "No such recipient.")
            sets = ", ".join(f"{k}=%s" for k in changes)
            conn.execute(f"UPDATE mail_recipients SET {sets} WHERE id=%s", (*changes.values(), rid))
            _mail_audit(conn, admin, request, "mail_recipient_changed", row["address"], changes)
        return _mail_view(conn)


@app.delete("/api/v1/admin/mail/recipients/{rid}")
def mail_recipient_delete(rid: int, request: Request, admin: str = Depends(require_admin)):
    with db() as conn:
        with conn.transaction():
            row = conn.execute("DELETE FROM mail_recipients WHERE id=%s RETURNING address", (rid,)).fetchone()
            if not row:
                raise HTTPException(404, "No such recipient.")
            left = conn.execute("SELECT count(*) AS n FROM mail_recipients").fetchone()["n"]
            if left == 0:
                conn.execute("UPDATE mail_settings SET enabled=FALSE, updated_by=%s, updated_at=now() WHERE id=1", (admin,))
            _mail_audit(conn, admin, request, "mail_recipient_removed", row["address"], {"remaining": left})
        return _mail_view(conn)


# ---------------------------------------------------------------------------
# Branding (admin) and reports
# ---------------------------------------------------------------------------

def _brand_public(b):
    return {k: v for k, v in b.items() if k not in ("logo", "logo_white")} | {
        "has_logo": bool(b["logo"]), "has_logo_white": bool(b["logo_white"])}


@app.get("/api/v1/admin/branding")
def branding_get(admin: str = Depends(require_admin)):
    from . import branding as br
    with db() as conn:
        b = br.settings(conn)
        row = conn.execute("SELECT company, copyright, classification, accent FROM branding WHERE id=1").fetchone()
    return {"effective": _brand_public(b), "saved": row, "folder": "/patch/data/branding"}


class BrandingIn(BaseModel):
    company: str = Field(default="", max_length=120)
    copyright: str = Field(default="", max_length=200)
    classification: str = Field(default="CONFIDENTIAL", min_length=1, max_length=40)
    accent: Optional[str] = Field(default=None, pattern="^#[0-9A-Fa-f]{6}$")


@app.put("/api/v1/admin/branding")
def branding_put(body: BrandingIn, request: Request, admin: str = Depends(require_admin)):
    from . import branding as br
    with db() as conn:
        with conn.transaction():
            conn.execute(
                """UPDATE branding SET company=%s, copyright=%s, classification=%s, accent=%s,
                          updated_by=%s, updated_at=now() WHERE id=1""",
                (body.company.strip(), body.copyright.strip(), body.classification.strip().upper(),
                 body.accent, admin))
            conn.execute(
                """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
                   VALUES (%s,'user','branding_saved','branding','1',%s,%s)""",
                (admin, json.dumps(body.model_dump()), client_ip(request)))
        return {"effective": _brand_public(br.settings(conn))}


TABLE_REPORT_MAX_CHARS = 3_000_000     # all cell text in one report (about 1,500 PDF pages)
TABLE_REPORTS_PER_10MIN = 30


class TableReportIn(BaseModel):
    title: str = Field(..., min_length=1, max_length=120)
    filter: str = Field(default="", max_length=300)
    columns: List[str] = Field(..., min_length=1, max_length=30)
    rows: List[List[Any]] = Field(default_factory=list, max_length=5000)
    format: str = Field("pdf", pattern="^(pdf|csv)$")

    @field_validator("columns")
    @classmethod
    def _cols(cls, v):
        return [str(c)[:60] for c in v]


@app.post("/api/v1/export/table")
def export_table(body: TableReportIn, request: Request, user: str = Depends(require_viewer)):
    """A report of the table a page is showing, as PDF (with the logo) or CSV,
    both with the organisation, date and time, user and filter. The browser
    sends only what this user is already looking at; every value is written as
    plain text (no markup in the PDF, no formulas in the CSV)."""
    from fastapi.responses import Response
    from . import exports as ex
    n = len(body.columns)
    rows, budget = [], TABLE_REPORT_MAX_CHARS
    for r in body.rows:
        out = []
        for v in r[:n]:
            if v is None or isinstance(v, (bool, int, float)):
                out.append(v)
            else:
                out.append(str(v)[:1000])
                budget -= len(out[-1])
        if budget < 0:
            raise HTTPException(413, "This table is too large for one report: narrow it with the filters.")
        rows.append(out + [""] * (n - len(out)))
    title = re.sub(r"[\r\n\t]+", " ", body.title).strip()
    with db() as conn:
        recent = conn.execute(
            """SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'report_exported'
                AND occurred_at > now() - interval '10 minutes'""", (user,)).fetchone()["n"]
        if recent >= TABLE_REPORTS_PER_10MIN:
            raise HTTPException(429, f"At most {TABLE_REPORTS_PER_10MIN} exports in 10 minutes: try again shortly.")
        m = ex.meta(title, user, re.sub(r"[\r\n\t]+", " ", body.filter).strip(), len(rows), ex.company_name(conn))
        data, mime, ext = ex.render(body.format, m, body.columns, rows, conn)
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="report_exported",
                  detail={"title": title, "format": body.format, "rows": len(rows)}, source_ip=client_ip(request))
    base = re.sub(r"[^A-Za-z0-9]+", "-", title.lower()).strip("-")[:40] or "report"
    return Response(data, media_type=mime, headers={
        "Content-Disposition": f'attachment; filename="{ex.file_name(base, ext)}"',
        "Cache-Control": "no-store", "X-Rows": str(len(rows))})


@app.get("/api/v1/branding/info")
def branding_info(user: str = Depends(require_viewer)):
    """The organisation's name, for the heading of exports made in the browser."""
    from . import exports as ex
    with db() as conn:
        return {"company": ex.company_name(conn), "portal": ex.PORTAL, "tz": ex.TZ_LABEL}


@app.get("/api/v1/branding/logo")
def branding_logo(variant: str = "main", user: str = Depends(require_viewer)):
    """The processed logo, as reports use it."""
    from fastapi.responses import Response
    from . import branding as br
    with db() as conn:
        b = br.settings(conn)
    data = b["logo_white"] if variant == "white" else b["logo"]
    if not data:
        raise HTTPException(404, "No logo found in /patch/data/branding.")
    return Response(data, media_type="image/png", headers={"Cache-Control": "no-store"})


class ReportIn(BaseModel):
    level: str = Field(default="l1", pattern="^(l1|l2|custom:[0-9a-f-]{36})$")
    format: str = Field(default="pdf", pattern="^(pdf|docx)$")
    host_ids: Optional[List[str]] = None
    host_group: Optional[str] = Field(default=None, max_length=120)
    scope_label: Optional[str] = Field(default=None, max_length=80)
    detail: str = Field(default="high_medium", pattern="^(all|high_medium|high)$")
    style: str = Field(default="management", pattern="^(management|technical)$")


@app.post("/api/v1/reports/hardening")
def report_hardening(body: ReportIn, request: Request, user: str = Depends(require_viewer)):
    """Build a branded hardening report and keep it in the archive."""
    from . import branding as br, reports as rp
    with db() as conn:
        host_ids = body.host_ids
        label = body.scope_label
        if body.host_group:
            host_ids = [str(r["id"]) for r in conn.execute(
                "SELECT id FROM hosts WHERE host_group=%s AND status <> 'decommissioned'", (body.host_group,)).fetchall()]
            label = label or f"Group {body.host_group}"
            if not host_ids:
                raise HTTPException(422, f"No servers in group {body.host_group}.")
        role = getattr(request.state, "user", {}) or {}
        who = f"{user} ({role.get('role')})" if isinstance(role, dict) and role.get("role") else user
        try:
            with conn.transaction():
                r = rp.generate(conn, br.settings(conn), body.level, body.format, host_ids, label, body.detail, who,
                                body.style)
                conn.execute(
                    """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
                       VALUES (%s,'user','report_generated','report',%s,%s,%s)""",
                    (user, r["id"], json.dumps({"report": r["report_id"], "format": body.format, "level": body.level,
                                                "servers": r["servers"], "sha256": r["sha256"]}), client_ip(request)))
        except ValueError as e:
            raise HTTPException(422, str(e))
    return r


@app.get("/api/v1/reports")
def reports_list(user: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT id, number, kind, level, format, title, generated_by, generated_at, pages, servers, score,
                      size_bytes, sha256, facts->>'report_id' AS report_ref, scope->>'style' AS style
                 FROM reports WHERE path IS NOT NULL ORDER BY generated_at DESC LIMIT 100""").fetchall()
    return {"reports": rows}


@app.get("/api/v1/reports/{report_id}/download")
def report_download(report_id: str, request: Request, user: str = Depends(require_viewer)):
    from fastapi.responses import FileResponse
    with db() as conn:
        r = conn.execute("SELECT * FROM reports WHERE id=%s", (report_id,)).fetchone()
        if not r or not r["path"] or not os.path.exists(r["path"]):
            raise HTTPException(404, "This report file is no longer on PATCH-01.")
        conn.execute(
            """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
               VALUES (%s,'user','report_downloaded','report',%s,%s,%s)""",
            (user, report_id, json.dumps({"file": os.path.basename(r["path"])}), client_ip(request)))
        conn.commit()
    media = "application/pdf" if r["format"] == "pdf" else \
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    return FileResponse(r["path"], media_type=media, filename=os.path.basename(r["path"]))


# ---------------------------------------------------------------------------
# E-mailing a report (operators and admins)
# ---------------------------------------------------------------------------

@app.get("/api/v1/mail/recipients")
def mail_recipients(user: str = Depends(require_operator)):
    """Addresses to pick from when sending a report. Addresses only."""
    with db() as conn:
        rows = conn.execute("SELECT address, name FROM mail_recipients ORDER BY lower(address)").fetchall()
    return {"recipients": rows}


def _report_row(conn, report_id):
    r = conn.execute("SELECT * FROM reports WHERE id=%s", (report_id,)).fetchone()
    if not r or not r["path"] or not os.path.exists(r["path"]):
        raise HTTPException(404, "This report file is no longer on PATCH-01.")
    if not r.get("facts"):
        raise HTTPException(409, "This report was made before e-mailing was possible: generate it again.")
    return r


@app.post("/api/v1/reports/{report_id}/email/draft")
def report_email_draft(report_id: str, user: str = Depends(require_operator)):
    """A summary of the report and a draft e-mail for it. AI-01 drafts from
    the report's own figures; if it cannot, a structured template does."""
    from . import notify as nt, report_mail as rm
    with db() as conn:
        r = _report_row(conn, report_id)
        cfg = nt.config(conn, with_password=False)
    f = r["facts"]
    subject, body = rm.template(f)
    return {"summary": rm.summary(f), "stats": rm.stats(f), "subject": subject, "body": body, "source": "template",
            "note": "A short summary of the report. Edit it as you like, or ask AI-01 to polish it.",
            "attachment": {"file": os.path.basename(r["path"]), "size_bytes": r["size_bytes"], "format": r["format"]},
            "signature": cfg["signature"], "from": cfg["from"], "from_name": cfg["from_name"],
            "ready": bool(cfg["host"] and cfg["from"])}


@app.post("/api/v1/reports/{report_id}/email/polish")
def report_email_polish(report_id: str, user: str = Depends(require_operator)):
    """AI-01's version of the short e-mail, checked against the report's figures."""
    from . import report_mail as rm
    with db() as conn:
        r = _report_row(conn, report_id)
    subject, body, source, note = rm.draft(r["facts"])
    return {"subject": subject, "body": body, "source": source, "note": note}


class ReportMailIn(BaseModel):
    to: List[str] = Field(..., min_length=1, max_length=30)
    cc: List[str] = Field(default_factory=list, max_length=30)
    subject: str = Field(..., min_length=3, max_length=200)
    body: str = Field(..., min_length=20, max_length=20000)


@app.post("/api/v1/reports/{report_id}/email")
def report_email_send(report_id: str, body: ReportMailIn, request: Request, user: str = Depends(require_operator)):
    """Send the report, attached, with the body as written and the signature."""
    import re as _re
    from . import notify as nt
    bad = [a for a in body.to + body.cc if not _re.match(EMAIL_RE, a.strip())]
    if bad:
        raise HTTPException(422, "Not e-mail addresses: " + ", ".join(bad))
    to = [a.strip() for a in body.to]
    cc = [a.strip() for a in body.cc if a.strip().lower() not in {x.lower() for x in to}]
    with db() as conn:
        r = _report_row(conn, report_id)
        cfg = nt.config(conn)
        if not (cfg["host"] and cfg["from"]):
            raise HTTPException(409, "Mail is not set up yet: an admin can do it under Admin, Mail.")
        with open(r["path"], "rb") as fh:
            data = fh.read()
        mime = "application/pdf" if r["format"] == "pdf" else \
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        from . import report_mail as rm
        text, html = nt.render(cfg, body.subject, "info", "", [("stats", rm.stats(r["facts"])), ("text", body.body)],
                               link=None, label="Hardening report", greeting=False)   # the editable draft carries its own greeting
        state, err = "sent", None
        try:
            nt.send(cfg, to, body.subject, text, html, cc=cc, attachments=[(os.path.basename(r["path"]), data, mime)])
        except Exception as e:  # noqa: BLE001 - reported back and recorded
            state, err = "failed", str(e)
        with conn.transaction():
            conn.execute(
                """INSERT INTO notifications (category, severity, subject, body_text, body_html, recipients, state,
                                              attempts, sent_at, last_error, event_keys)
                   VALUES ('report', 'info', %s, %s, %s, %s, %s, 1, CASE WHEN %s THEN now() END, %s, %s)""",
                (body.subject, text, html, to + cc, state, state == "sent", err, [f"report:{report_id}"]))
            conn.execute(
                """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
                   VALUES (%s,'user','report_emailed','report',%s,%s,%s)""",
                (user, report_id, json.dumps({"to": to, "cc": cc, "subject": body.subject, "state": state, "error": err,
                                              "file": os.path.basename(r["path"])}), client_ip(request)))
    if err:
        raise HTTPException(502, err)
    return {"ok": True, "to": to, "cc": cc}


# ---------------------------------------------------------------------------
# Custom hardening profiles (from an uploaded document)
# ---------------------------------------------------------------------------

@app.get("/api/v1/agent/hardening/tailoring/{name}")
def agent_tailoring(name: str, agent: AgentIdentity = Depends(require_agent)):
    from fastapi.responses import FileResponse
    from . import custom_profiles as cp
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,120}\.xml", name):
        raise HTTPException(404, "no such file")
    path = os.path.join(cp.TAILOR_DIR, name)
    if not os.path.exists(path):
        raise HTTPException(404, "no such file")
    return FileResponse(path, media_type="application/xml")


def _cp_view(conn, pid):
    from . import custom_profiles as cp
    prof = conn.execute("SELECT * FROM custom_profiles WHERE id=%s", (pid,)).fetchone()
    if not prof:
        raise HTTPException(404, "No such custom profile.")
    items = conn.execute("SELECT * FROM custom_profile_items WHERE profile_id=%s ORDER BY line_no", (pid,)).fetchall()
    ids = sorted({r for it in items for r in (it["rule_ids"] or [])})
    rules = {r["rule_id"]: r for r in conn.execute(
        """SELECT DISTINCT ON (r.rule_id) r.rule_id, r.title, r.cis_ref, r.severity FROM hardening_rules r
             JOIN hardening_content c USING (content_version, product)
            WHERE c.active AND r.product=%s AND r.rule_id = ANY(%s)""", (prof["product"], ids)).fetchall()}
    for it in items:
        it["rules"] = [rules.get(r, {"rule_id": r, "title": r.replace(cp.RULE_PREFIX, ""), "cis_ref": None,
                                     "severity": None}) for r in (it["rule_ids"] or [])]
    counts = {"lines": len(items), "checks": len(ids),
              "matched": sum(1 for it in items if it["rule_ids"]),
              "manual": sum(1 for it in items if not it["rule_ids"] and it["matched_by"] != "skipped"),
              "skipped": sum(1 for it in items if it["matched_by"] == "skipped"),
              "to_review": sum(1 for it in items if it["confidence"] in ("low", "medium") and it["matched_by"] in ("cis", "title", "ai"))}
    return {"profile": prof, "items": items, "counts": counts, "product_name": cp.PRODUCT_NAME.get(prof["product"], prof["product"])}


@app.get("/api/v1/hardening/custom")
def custom_list(user: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT p.*, (SELECT count(*) FROM custom_profile_items i WHERE i.profile_id = p.id) AS lines,
                      (SELECT count(*) FROM custom_profile_items i WHERE i.profile_id = p.id AND cardinality(i.rule_ids) > 0) AS matched
                 FROM custom_profiles p WHERE p.status <> 'retired' ORDER BY p.updated_at DESC""").fetchall()
    return {"profiles": rows}


@app.post("/api/v1/hardening/custom")
async def custom_create(request: Request, name: str = Form(...), product: str = Form("rhel9"),
                        description: str = Form(""), text: str = Form(""), file: Optional[UploadFile] = File(None),
                        user: str = Depends(require_operator)):
    from . import custom_profiles as cp
    name = name.strip()[:120]
    if not name:
        raise HTTPException(422, "Give the profile a name.")
    if not re.fullmatch(r"[a-z0-9]{2,20}", product):
        raise HTTPException(422, "Choose the benchmark the document follows.")
    if file is not None and file.filename:
        fn = file.filename
        if not fn.lower().endswith((".txt", ".csv", ".docx")):
            raise HTTPException(422, "Upload a .txt, .csv or .docx file.")
        data = await file.read()
        if len(data) > 5 * 1024 * 1024:
            raise HTTPException(413, "The file is over 5 MB.")
    elif text.strip():
        fn, data = "pasted.txt", text.encode()
    else:
        raise HTTPException(422, "Upload a file or paste the list.")
    with db() as conn:
        try:
            with conn.transaction():
                pid, counts = cp.build(conn, name, product, fn, data, user, description.strip() or None)
                conn.execute(
                    """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
                       VALUES (%s,'user','custom_profile_created','custom_profile',%s,%s,%s)""",
                    (user, pid, json.dumps({"name": name, "file": fn, **counts}), client_ip(request)))
        except ValueError as e:
            raise HTTPException(422, str(e))
    return {"id": pid, **counts}


@app.get("/api/v1/hardening/custom/{pid}")
def custom_get(pid: str, user: str = Depends(require_viewer)):
    with db() as conn:
        return _cp_view(conn, pid)


class CustomItemIn(BaseModel):
    rule_ids: Optional[List[str]] = None
    skip: Optional[bool] = None


@app.patch("/api/v1/hardening/custom/{pid}/items/{item_id}")
def custom_item_update(pid: str, item_id: int, body: CustomItemIn, user: str = Depends(require_operator)):
    with db() as conn:
        with conn.transaction():
            prof = conn.execute("SELECT status, product FROM custom_profiles WHERE id=%s", (pid,)).fetchone()
            if not prof:
                raise HTTPException(404, "No such custom profile.")
            if prof["status"] == "active":
                # Scans and reports refer to this version: edits make a new one
                raise HTTPException(409, "The profile is in use. Choose Edit (back to draft) first; that makes a new version.")
            if body.skip is not None:
                conn.execute("""UPDATE custom_profile_items SET rule_ids='{}', matched_by=%s, confidence=NULL, note=%s
                                 WHERE id=%s AND profile_id=%s""",
                             ("skipped" if body.skip else "none",
                              "Not part of the checks (a heading or note)." if body.skip else "Left as a manual check.",
                              item_id, pid))
            if body.rule_ids is not None:
                ok = {r["rule_id"] for r in conn.execute(
                    """SELECT r.rule_id FROM hardening_rules r JOIN hardening_content c USING (content_version, product)
                        WHERE c.active AND r.product=%s AND r.rule_id = ANY(%s)""", (prof["product"], body.rule_ids)).fetchall()}
                ids = [r for r in body.rule_ids if r in ok]
                conn.execute("""UPDATE custom_profile_items SET rule_ids=%s, matched_by=%s, confidence=%s, note=%s
                                 WHERE id=%s AND profile_id=%s""",
                             (ids, "manual" if ids else "none", "high" if ids else None,
                              f"Chosen by {user}." if ids else "Left as a manual check.", item_id, pid))
            conn.execute("UPDATE custom_profiles SET updated_by=%s, updated_at=now() WHERE id=%s", (user, pid))
        return _cp_view(conn, pid)


@app.post("/api/v1/hardening/custom/{pid}/items/{item_id}/suggest")
def custom_item_suggest(pid: str, item_id: int, user: str = Depends(require_operator)):
    from . import custom_profiles as cp
    with db() as conn:
        try:
            with conn.transaction():
                rule, note = cp.suggest(conn, pid, item_id)
        except ValueError as e:
            raise HTTPException(404, str(e))
        except Exception as e:  # noqa: BLE001 - AI-01 down is an answer, not a crash
            return {"ok": False, "note": f"AI-01 could not help: {str(e)[:140]}", "view": _cp_view(conn, pid)}
        return {"ok": bool(rule), "note": note, "view": _cp_view(conn, pid)}


@app.get("/api/v1/hardening/custom/{pid}/search")
def custom_search(pid: str, q: str = "", user: str = Depends(require_operator)):
    from . import custom_profiles as cp
    with db() as conn:
        prof = conn.execute("SELECT product FROM custom_profiles WHERE id=%s", (pid,)).fetchone()
        if not prof:
            raise HTTPException(404, "No such custom profile.")
        res = cp.search(conn, prof["product"], q)
    return {"rules": [{"rule_id": r["rule_id"], "title": r["title"], "cis_ref": r["cis"], "severity": r["severity"]}
                      for r in res]}


class CustomStateIn(BaseModel):
    status: str = Field(..., pattern="^(active|draft|retired)$")
    name: Optional[str] = Field(default=None, max_length=120)


@app.post("/api/v1/hardening/custom/{pid}/state")
def custom_state(pid: str, body: CustomStateIn, request: Request, user: str = Depends(require_operator)):
    with db() as conn:
        with conn.transaction():
            prof = conn.execute("SELECT * FROM custom_profiles WHERE id=%s", (pid,)).fetchone()
            if not prof:
                raise HTTPException(404, "No such custom profile.")
            if body.status == "active":
                n = conn.execute("SELECT count(*) AS n FROM custom_profile_items WHERE profile_id=%s AND cardinality(rule_ids) > 0",
                                 (pid,)).fetchone()["n"]
                if not n:
                    raise HTTPException(422, "Match at least one line to a check before using the profile.")
            bump = prof["status"] == "active" and body.status == "draft"
            conn.execute("""UPDATE custom_profiles SET status=%s, name=coalesce(%s, name), updated_by=%s, updated_at=now(),
                                   version = version + %s WHERE id=%s""",
                         (body.status, body.name, user, 1 if bump else 0, pid))
            conn.execute(
                """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
                   VALUES (%s,'user','custom_profile_state','custom_profile',%s,%s,%s)""",
                (user, pid, json.dumps({"status": body.status}), client_ip(request)))
        return _cp_view(conn, pid)


# ---------------------------------------------------------------------------
# Windows servers: Windows Update results from the PowerShell agent
# ---------------------------------------------------------------------------

class WinUpdateIn(BaseModel):
    update_id: str = Field(..., max_length=80)
    kb: Optional[str] = Field(default=None, max_length=20)
    title: str = Field(..., max_length=500)
    severity: Optional[str] = Field(default=None, max_length=20)
    categories: List[str] = Field(default_factory=list, max_length=20)
    cves: List[str] = Field(default_factory=list, max_length=500)
    downloaded: Optional[bool] = None
    reboot_behaviour: Optional[str] = Field(default=None, max_length=40)
    size_mb: Optional[int] = Field(default=None, ge=0, le=100000)


class WinUpdatesIn(BaseModel):
    searched_at: datetime
    source: Optional[str] = Field(default=None, max_length=20)      # wsus or microsoft
    server: Optional[str] = Field(default=None, max_length=300)     # the WSUS address
    os_edition: Optional[str] = Field(default=None, max_length=120)
    error: Optional[str] = Field(default=None, max_length=1000)
    updates: List[WinUpdateIn] = Field(default_factory=list, max_length=2000)


@app.post("/api/v1/agent/windows/updates")
def agent_windows_updates(body: WinUpdatesIn, agent: AgentIdentity = Depends(require_agent)):
    """What Windows Update says is not yet installed, searched against the
    server's own WSUS, so it reflects your approvals. Replaces the last report."""
    cve_re = re.compile(r"^CVE-\d{4}-\d{4,7}$")
    with db() as conn:
        with conn.transaction():
            conn.execute(
                """UPDATE hosts SET wu_source=%s, wu_server=%s, wu_searched_at=%s, wu_error=%s,
                          os_edition=coalesce(%s, os_edition) WHERE id=%s""",
                (body.source, body.server, body.searched_at, body.error, body.os_edition, agent.host_id))
            if body.error is None:
                conn.execute("DELETE FROM windows_updates WHERE host_id=%s", (agent.host_id,))
                with conn.cursor() as cur:
                    cur.executemany(
                        """INSERT INTO windows_updates (host_id, update_id, kb, title, severity, categories, cves,
                                                        downloaded, reboot_behaviour, size_mb, reported_at)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,now())
                           ON CONFLICT (host_id, update_id) DO NOTHING""",
                        [(agent.host_id, u.update_id, u.kb, u.title[:500], u.severity, u.categories[:20],
                          [c for c in u.cves if cve_re.match(c)], u.downloaded, u.reboot_behaviour, u.size_mb)
                         for u in body.updates])
    return {"ok": True, "stored": 0 if body.error else len(body.updates)}


@app.get("/api/v1/admin/hosts/{host_id}/windows")
def host_windows(host_id: str, user: str = Depends(require_viewer)):
    with db() as conn:
        h = conn.execute(
            """SELECT id, hostname, os_id, os_version, os_edition, kernel_running AS build, wu_source, wu_server,
                      wu_searched_at, wu_error, reboot_required FROM hosts WHERE id=%s""", (host_id,)).fetchone()
        if not h or h["os_id"] != "windows":
            raise HTTPException(404, "Not a Windows server.")
        ups = conn.execute(
            """SELECT update_id, kb, title, severity, categories, cves, downloaded, reboot_behaviour, size_mb, reported_at
                 FROM windows_updates WHERE host_id=%s
                ORDER BY CASE severity WHEN 'Critical' THEN 0 WHEN 'Important' THEN 1 WHEN 'Moderate' THEN 2
                                       WHEN 'Low' THEN 3 ELSE 4 END, kb""", (host_id,)).fetchall()
        kbs = [r["name"].upper() for r in conn.execute(
            "SELECT name FROM host_packages WHERE host_id=%s AND name LIKE 'kb%%' ORDER BY name", (host_id,)).fetchall()]
    return {"host": h, "missing": ups, "installed_kbs": kbs}


# ---------------------------------------------------------------------------
# Windows software inventory
# ---------------------------------------------------------------------------

class WinSoftwareItem(BaseModel):
    name: str = Field(..., min_length=1, max_length=300)
    version: str = Field(default="", max_length=120)
    publisher: Optional[str] = Field(default=None, max_length=200)
    installed_on: Optional[str] = Field(default=None, max_length=10)     # yyyymmdd, as Windows keeps it
    size_mb: Optional[int] = Field(default=None, ge=0, le=10_000_000)
    arch: Optional[str] = Field(default=None, max_length=10)


class WinSoftwareIn(BaseModel):
    software: List[WinSoftwareItem] = Field(default_factory=list, max_length=5000)


@app.post("/api/v1/agent/windows/software")
def agent_windows_software(body: WinSoftwareIn, agent: AgentIdentity = Depends(require_agent)):
    """Programs and Features on this server. Replaces the last report."""
    from datetime import date as _date
    def day(v):
        if v and re.fullmatch(r"\d{8}", v):
            try:
                return _date(int(v[:4]), int(v[4:6]), int(v[6:]))
            except ValueError:
                return None
        return None
    seen, rows = set(), []
    for it in body.software:
        k = (it.name.strip(), it.version.strip(), it.arch or "")
        if k in seen:
            continue
        seen.add(k)
        rows.append((agent.host_id, k[0], k[1], (it.publisher or "").strip() or None, day(it.installed_on),
                     it.size_mb, it.arch))
    with db() as conn:
        with conn.transaction():
            before = {(r["name"], r["version"]) for r in conn.execute(
                "SELECT name, version FROM windows_software WHERE host_id=%s", (agent.host_id,)).fetchall()}
            conn.execute("DELETE FROM windows_software WHERE host_id=%s", (agent.host_id,))
            with conn.cursor() as cur:
                cur.executemany(
                    """INSERT INTO windows_software (host_id, name, version, publisher, installed_on, size_mb, arch)
                       VALUES (%s,%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING""", rows)
            if before != {(r[1], r[2]) for r in rows}:
                from . import cve_impact
                cve_impact.inventory_changed(conn)     # a program installed, removed or updated
    return {"ok": True, "stored": len(rows)}


@app.get("/api/v1/admin/hosts/{host_id}/software")
def host_software(host_id: str, user: str = Depends(require_viewer)):
    with db() as conn:
        rows = conn.execute(
            """SELECT name, version, publisher, installed_on, size_mb, arch, reported_at
                 FROM windows_software WHERE host_id=%s ORDER BY lower(name), version""", (host_id,)).fetchall()
    return {"software": rows}


@app.get("/api/v1/software")
def software_fleet(q: str = "", user: str = Depends(require_viewer)):
    """Software across all Windows servers: each program, its versions, and
    how many servers have each. With q, only names containing it."""
    q = q.strip()[:100]
    with db() as conn:
        rows = conn.execute(
            """SELECT s.name, s.publisher, s.version, count(DISTINCT s.host_id) AS servers,
                      array_agg(DISTINCT h.hostname ORDER BY h.hostname) AS hosts
                 FROM windows_software s JOIN hosts h ON h.id = s.host_id
                WHERE h.status <> 'decommissioned' AND (%s = '' OR s.name ILIKE '%%' || %s || '%%'
                                                        OR s.publisher ILIKE '%%' || %s || '%%')
                GROUP BY s.name, s.publisher, s.version
                ORDER BY lower(s.name), s.version DESC
                LIMIT 2000""", (q, q, q)).fetchall()
        total = conn.execute("SELECT count(DISTINCT host_id) AS n FROM windows_software").fetchone()["n"]
    progs = {}
    for r in rows:
        p = progs.setdefault((r["name"], r["publisher"]), {"name": r["name"], "publisher": r["publisher"],
                                                            "servers": 0, "versions": []})
        p["versions"].append({"version": r["version"], "servers": r["servers"], "hosts": r["hosts"][:200]})
        p["servers"] += r["servers"]
    return {"programs": list(progs.values()), "servers_reporting": total}


# ---------------------------------------------------------------------------
# WSUS: summaries sent by a read-only script on each WSUS server
# ---------------------------------------------------------------------------

def _wsus_source(conn, authorization):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "missing token")
    th = hashlib.sha256(authorization[7:].strip().encode()).hexdigest()
    src = conn.execute("SELECT name FROM wsus_sources WHERE token_hash=%s", (th,)).fetchone()
    if not src:
        raise HTTPException(401, "unknown WSUS reporting token")
    return src["name"]


class WsusComputerIn(BaseModel):
    name: str = Field(..., max_length=260)
    ip: Optional[str] = Field(default=None, max_length=64)
    os: Optional[str] = Field(default=None, max_length=200)
    groups: List[str] = Field(default_factory=list, max_length=50)
    last_reported: Optional[datetime] = None
    last_synced: Optional[datetime] = None
    needed: Optional[int] = Field(default=None, ge=0)
    failed: Optional[int] = Field(default=None, ge=0)
    pending_reboot: Optional[int] = Field(default=None, ge=0)


class WsusReportIn(BaseModel):
    server: Dict[str, Any] = Field(default_factory=dict)          # version, sync state, counts, groups
    computers: List[WsusComputerIn] = Field(default_factory=list, max_length=20000)
    error: Optional[str] = Field(default=None, max_length=2000)


@app.post("/api/v1/wsus/report")
def wsus_report(body: WsusReportIn, authorization: Optional[str] = Header(default=None)):
    with db() as conn:
        name = _wsus_source(conn, authorization)
        with conn.transaction():
            conn.execute("UPDATE wsus_sources SET reported_at=now(), report=%s, error=%s WHERE name=%s",
                         (json.dumps(body.server, default=str), body.error, name))
            if body.error is None:
                conn.execute("DELETE FROM wsus_computers WHERE source=%s", (name,))
                with conn.cursor() as cur:
                    cur.executemany(
                        """INSERT INTO wsus_computers (source, name, ip, os, groups, last_reported, last_synced,
                                                       needed, failed, pending_reboot)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING""",
                        [(name, c.name.lower(), c.ip, c.os, c.groups[:50], c.last_reported, c.last_synced,
                          c.needed, c.failed, c.pending_reboot) for c in body.computers])
    return {"ok": True, "computers": len(body.computers)}


@app.get("/api/v1/wsus")
def wsus_view(user: str = Depends(require_viewer)):
    """Each WSUS, its computers, and how they line up with PATCH-01's servers."""
    with db() as conn:
        srcs = conn.execute("SELECT name, reported_at, report, error FROM wsus_sources ORDER BY name").fetchall()
        comps = conn.execute(
            """SELECT c.*, h.id AS host_id, h.hostname AS patch01_name
                 FROM wsus_computers c
                 LEFT JOIN hosts h ON h.status <> 'decommissioned'
                      AND (lower(h.hostname) = split_part(c.name, '.', 1) OR lower(h.fqdn) = c.name)
                ORDER BY c.needed DESC NULLS LAST, c.name""").fetchall()
        win = conn.execute(
            """SELECT h.id, h.hostname, h.fqdn FROM hosts h
                WHERE h.os_id='windows' AND h.status <> 'decommissioned'""").fetchall()
    known = {c["patch01_name"] for c in comps if c["patch01_name"]}
    return {"sources": srcs, "computers": comps,
            "not_in_wsus": [w for w in win if w["hostname"] not in known] if srcs else []}


# ---------------------------------------------------------------------------
# PATCH-01's certificate (admin): check uploads here; a root helper installs
# ---------------------------------------------------------------------------

def _host_names():
    fq = (os.environ.get("PATCH01_FQDN") or "").lower()
    short = (os.environ.get("PATCH01_SHORT") or (fq.split(".")[0] if fq else "")).lower()
    return short or "patch01.example", fq or short or "patch01.example"


@app.get("/api/v1/admin/certificate")
def cert_get(admin: str = Depends(require_admin)):
    from . import certs as cm
    try:
        cur = cm.served()
    except Exception as e:  # noqa: BLE001 - shown, not fatal
        cur = {"error": f"could not read the served certificate: {e}"}
    short, fq = _host_names()
    return {"served": cur, "status": cm.status(), "names": {"short": short, "fqdn": fq}}


@app.post("/api/v1/admin/certificate/check")
async def cert_check(request: Request, cert: Optional[UploadFile] = File(None), key: Optional[UploadFile] = File(None),
                     chain: Optional[UploadFile] = File(None), pfx: Optional[UploadFile] = File(None),
                     password: str = Form(""), admin: str = Depends(require_admin)):
    """Check an upload thoroughly. Nothing changes; a checked upload is kept for one hour."""
    from . import certs as cm
    async def read(f):
        if f is None or not f.filename:
            return None
        data = await f.read()
        if len(data) > 200_000:
            raise HTTPException(413, f"{f.filename} is too large for a certificate file.")
        return data
    try:
        leaf, k, others = cm.parse_upload(await read(cert), await read(key), await read(chain), await read(pfx),
                                          password or None)
        short, fq = _host_names()
        errors, warnings, ordered = cm.check(leaf, k, others, short, fq)
    except cm.CertError as e:
        return {"ok": False, "errors": [str(e)], "warnings": []}
    info = cm.describe(leaf)
    out = {"ok": not errors, "errors": errors, "warnings": warnings, "certificate": info,
           "chain": [cm.describe(c) for c in ordered]}
    if not errors:
        out["id"] = cm.stage(leaf, k, ordered, admin)
        try:
            old = cm.served()["pin"]
        except Exception:  # noqa: BLE001
            old = None
        out["pins"] = {"old": old, "new": info["pin"]}
    with db() as conn:
        conn.execute(
            """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
               VALUES (%s,'user','certificate_checked','certificate',%s,%s,%s)""",
            (admin, info["pin"][:16], json.dumps({"subject": info["subject"], "issuer": info["issuer"],
                                                  "ok": not errors, "errors": errors}), client_ip(request)))
        conn.commit()
    return out


class CertApplyIn(BaseModel):
    id: str = Field(..., pattern="^[0-9a-f]{16}$")
    windows_repinned: bool = False


@app.post("/api/v1/admin/certificate/apply")
def cert_apply(body: CertApplyIn, request: Request, admin: str = Depends(require_admin)):
    from . import certs as cm
    if not cm.status()["helper_ready"]:
        raise HTTPException(503, "The certificate helper is not installed on PATCH-01: run phase3b-api.sh.")
    try:
        req = cm.request_apply(body.id, admin)
    except cm.CertError as e:
        raise HTTPException(409, str(e))
    with db() as conn:
        conn.execute(
            """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
               VALUES (%s,'user','certificate_install_requested','certificate',%s,%s,%s)""",
            (admin, req["pin"][:16], json.dumps({"pin": req["pin"], "windows_repinned": body.windows_repinned}),
             client_ip(request)))
        conn.commit()
    return {"ok": True, "request": req["id"]}


@app.post("/api/v1/admin/certificate/rollback")
def cert_rollback(request: Request, admin: str = Depends(require_admin)):
    from . import certs as cm
    if not cm.status()["helper_ready"]:
        raise HTTPException(503, "The certificate helper is not installed on PATCH-01: run phase3b-api.sh.")
    try:
        req = cm.request_rollback(admin)
    except cm.CertError as e:
        raise HTTPException(409, str(e))
    with db() as conn:
        conn.execute(
            """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
               VALUES (%s,'user','certificate_rollback_requested','certificate','-','{}',%s)""",
            (admin, client_ip(request)))
        conn.commit()
    return {"ok": True, "request": req["id"]}


# ---------------------------------------------------------------------------
# Software catalog (Windows installers from a share) and run-time credentials
# ---------------------------------------------------------------------------

class CatalogIn(BaseModel):
    name: str = Field(..., max_length=80)
    version: str = Field(..., max_length=40)
    kind: str = Field(..., max_length=4)
    unc_path: str = Field(..., max_length=400)
    sha256: str = Field(..., max_length=64)
    detect_name: str = Field(..., max_length=120)
    require_signature: bool = True
    publisher: Optional[str] = Field(default=None, max_length=200)
    product_code: Optional[str] = Field(default=None, max_length=38)
    install_args: Optional[str] = Field(default=None, max_length=300)
    uninstall_args: Optional[str] = Field(default=None, max_length=300)
    replaces_below: Optional[str] = Field(default=None, max_length=40)
    notes: Optional[str] = Field(default=None, max_length=500)


def _audit(conn, actor, action, obj_type, obj_id, detail, ip, actor_type="user"):
    conn.execute(
        """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
           VALUES (%s,%s,%s,%s,%s,%s,%s)""",
        (actor, actor_type, action, obj_type, str(obj_id), json.dumps(detail), ip))


@app.get("/api/v1/software/catalog")
def catalog_list(user: str = Depends(require_viewer)):
    from . import software as sw
    with db() as conn:
        rows = conn.execute(
            """SELECT id, name, version, kind, unc_path, sha256, publisher, require_signature, install_args,
                      uninstall_args, product_code, detect_name, replaces_below, state, created_by, created_at,
                      approved_by, approved_at, notes
                 FROM software_catalog ORDER BY lower(name), version DESC""").fetchall()
    for r in rows:
        r["actions"] = sw.actions_for(r) if r["state"] == "approved" else []
    return {"catalog": rows}


@app.post("/api/v1/admin/software/catalog")
def catalog_add(body: CatalogIn, request: Request, admin: str = Depends(require_admin)):
    from . import software as sw
    try:
        e = sw.validate_entry(body.model_dump())
    except sw.Invalid as x:
        raise HTTPException(422, str(x))
    with db() as conn:
        try:
            row = conn.execute(
                """INSERT INTO software_catalog (name, version, kind, unc_path, sha256, publisher, require_signature,
                                                 install_args, uninstall_args, product_code, detect_name,
                                                 replaces_below, notes, created_by)
                   VALUES (%(name)s,%(version)s,%(kind)s,%(unc_path)s,%(sha256)s,%(publisher)s,%(require_signature)s,
                           %(install_args)s,%(uninstall_args)s,%(product_code)s,%(detect_name)s,%(replaces_below)s,
                           %(notes)s,%(by)s) RETURNING id""", dict(e, by=admin)).fetchone()
        except psycopg.errors.UniqueViolation:
            raise HTTPException(409, "That name, version and type are already in the catalog.")
        _audit(conn, admin, "software_registered", "software", row["id"],
               {k: e[k] for k in ("name", "version", "kind", "unc_path", "sha256", "publisher", "install_args",
                                  "uninstall_args")}, client_ip(request))
        conn.commit()
    return {"ok": True, "id": row["id"], "state": "pending"}


@app.post("/api/v1/admin/software/catalog/{entry_id}/{verb}")
def catalog_decide(entry_id: str, verb: str, request: Request, admin: str = Depends(require_admin)):
    if verb not in ("approve", "disable") or not re.match(r"^[0-9a-f-]{36}$", entry_id):
        raise HTTPException(404, "Not found.")
    with db() as conn:
        e = conn.execute("SELECT created_by, state FROM software_catalog WHERE id=%s", (entry_id,)).fetchone()
        if not e:
            raise HTTPException(404, "No such catalog entry.")
        if verb == "approve":
            if e["created_by"] == admin:
                raise HTTPException(403, "A different admin must approve an entry: you registered this one.")
            if e["state"] != "pending":
                raise HTTPException(409, f"This entry is {e['state']}, not waiting for approval.")
            conn.execute("UPDATE software_catalog SET state='approved', approved_by=%s, approved_at=now() WHERE id=%s",
                         (admin, entry_id))
        else:
            conn.execute("UPDATE software_catalog SET state='disabled' WHERE id=%s", (entry_id,))
        _audit(conn, admin, f"software_{verb}d", "software", entry_id, {}, client_ip(request))
        conn.commit()
    return {"ok": True}


class CredentialIn(BaseModel):
    username: str = Field(..., max_length=200)
    password: str = Field(..., max_length=256)
    hours: int = Field(default=6, ge=1, le=6)


def _software_change(conn, change_id):
    if not re.match(r"^[0-9a-f-]{36}$", change_id):
        raise HTTPException(404, "Not found.")
    c = conn.execute("SELECT id::text AS id, kind::text AS kind, state::text AS state FROM changes WHERE id=%s",
                     (change_id,)).fetchone()
    if not c or c["kind"] != "software":
        raise HTTPException(404, "No such software change.")
    return c


@app.get("/api/v1/changes/{change_id}/credential")
def credential_status(change_id: str, request: Request, user: str = Depends(require_viewer)):
    from . import vault
    _change_ok(request, "software")
    with db() as conn:
        c = _software_change(conn, change_id)
    st = vault.status(c["id"])
    return {"held": bool(st), "by": (st or {}).get("by"), "expires_at": (st or {}).get("expires_at"),
            "vault_ready": vault.available()}


@app.post("/api/v1/changes/{change_id}/credential")
def credential_put(change_id: str, body: CredentialIn, request: Request, op: str = Depends(require_operator)):
    """The share credential for this job: encrypted, memory-backed, gone when the job ends."""
    from . import vault
    _change_ok(request, "software")
    with db() as conn:
        c = _software_change(conn, change_id)
        if c["state"] not in ("scheduled", "running"):
            raise HTTPException(409, f"This change is {c['state'].replace('_', ' ')}: a credential can only be "
                                     "given to an approved change that is scheduled or running.")
        try:
            r = vault.put(c["id"], body.username, body.password, op, body.hours)
        except vault.VaultError as e:
            raise HTTPException(422, str(e))
        _audit(conn, op, "credential_entered", "change", c["id"],
               {"user": r["user"], "expires_at": r["expires_at"]}, client_ip(request))      # never the password
        conn.commit()
    return {"ok": True, "expires_at": r["expires_at"]}


@app.delete("/api/v1/changes/{change_id}/credential")
def credential_drop(change_id: str, request: Request, op: str = Depends(require_operator)):
    from . import vault
    _change_ok(request, "software")
    with db() as conn:
        c = _software_change(conn, change_id)
        vault.discard(c["id"])
        _audit(conn, op, "credential_discarded", "change", c["id"], {}, client_ip(request))
        conn.commit()
    return {"ok": True}


@app.get("/api/v1/agent/commands/{command_id}/credential")
def agent_credential(command_id: str, request: Request, agent: AgentIdentity = Depends(require_agent)):
    """For one software command of this server, once: the share credential."""
    from . import vault
    if not re.match(r"^[0-9a-f-]{36}$", command_id):
        raise HTTPException(404, "Not found.")
    with db() as conn:
        cmd = conn.execute(
            """SELECT c.id::text AS id, c.change_id::text AS change_id, c.verb::text AS verb,
                      c.claimed_at, c.completed_at, ch.state::text AS change_state
                 FROM agent_commands c JOIN changes ch ON ch.id = c.change_id
                WHERE c.id=%s AND c.host_id=%s""", (command_id, agent.host_id)).fetchone()
        # Only this server's own running software command, claimed and not finished
        if (not cmd or cmd["verb"] != "software_action" or cmd["claimed_at"] is None
                or cmd["completed_at"] is not None or cmd["change_state"] != "running"):
            raise HTTPException(403, "No credential for this command.")
        try:
            cred = vault.fetch_once(cmd["change_id"], cmd["id"])
        except vault.VaultError as e:
            raise HTTPException(403, str(e))
        _audit(conn, agent.hostname, "credential_fetched", "change", cmd["change_id"],
               {"command": cmd["id"]}, client_ip(request), actor_type="agent")
        conn.commit()
    return JSONResponse(cred, headers={"Cache-Control": "no-store", "Pragma": "no-cache"})


# ---------------------------------------------------------------------------
# Agent log lines, and the console's live log
# ---------------------------------------------------------------------------

# "Authorization: Bearer <t>" and "Basic <t>" first: masking only the word after
# "Authorization:" would leave the token itself in the line
_AUTH_RE = re.compile(r"(?i)\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]+")
_SECRET_RE = re.compile(r"(?i)\b((?:password|passwd|pwd|secret|token|api[_-]?key|credential)s?)(\s*[:=]\s*|\s+)"
                        r"(\"[^\"]*\"|'[^']*'|\S+)")
LOG_KEEP_PER_HOST = 3000


def scrub(line):
    """Anything that looks like a secret is masked, whatever the sender did."""
    line = _AUTH_RE.sub(lambda m: m.group(1) + " [hidden]", line)
    return _SECRET_RE.sub(lambda m: m.group(1) + m.group(2) + "[hidden]", line)


class LogLineIn(BaseModel):
    at: datetime
    level: str = Field(default="INFO", max_length=8)
    msg: str = Field(..., max_length=2000)


class LogBatchIn(BaseModel):
    lines: List[LogLineIn] = Field(default_factory=list, max_length=500)


@app.post("/api/v1/agent/log")
def agent_log(body: LogBatchIn, agent: AgentIdentity = Depends(require_agent)):
    rows = []
    for l in body.lines:
        lvl = l.level.upper() if l.level.upper() in ("DEBUG", "INFO", "WARN", "WARNING", "ERROR") else "INFO"
        msg = scrub(l.msg.replace("\r", " ").replace("\n", " "))[:2000]
        if msg.strip():
            rows.append((agent.host_id, l.at, "WARN" if lvl == "WARNING" else lvl, msg))
    with db() as conn:
        with conn.transaction():
            with conn.cursor() as cur:
                cur.executemany("INSERT INTO agent_logs (host_id, at, level, line) VALUES (%s,%s,%s,%s)", rows)
            # bounded: the newest lines per server, and nothing older than 14 days
            conn.execute(
                """DELETE FROM agent_logs WHERE host_id=%s AND (received < now() - interval '14 days' OR id <
                       (SELECT id FROM agent_logs WHERE host_id=%s ORDER BY id DESC OFFSET %s LIMIT 1))""",
                (agent.host_id, agent.host_id, LOG_KEEP_PER_HOST))
    return {"ok": True, "stored": len(rows)}


@app.get("/api/v1/console/stream")
def console_stream(request: Request, after_log: int = 0, after_event: int = 0, host: Optional[str] = None,
                   change: Optional[str] = None, user: str = Depends(require_viewer)):
    """New agent log lines and change events since the given ids, oldest first,
    for the console's live log. With host or change, only those. Without the
    patch module, only one change of a kind the user may see."""
    from . import auth
    uid = r"^[0-9a-f-]{36}$"
    host = host if host and re.match(uid, host) else None
    change = change if change and re.match(uid, change) else None
    if "patch" not in auth.user_modules(request.state.user):
        if not change:
            return {"logs": [], "events": []}
        host = None
    with db() as conn:
        if change and "patch" not in auth.user_modules(request.state.user):
            k = conn.execute("SELECT kind::text AS kind FROM changes WHERE id::text=%s", (change,)).fetchone()
            if not k:
                return {"logs": [], "events": []}
            _change_ok(request, k["kind"])
        hosts = None
        if change:
            hosts = [r["host_id"] for r in conn.execute(
                "SELECT host_id::text AS host_id FROM change_targets WHERE change_id=%s AND host_id IS NOT NULL",
                (change,)).fetchall()]
        elif host:
            hosts = [host]
        first = after_log == 0 and after_event == 0
        logs = conn.execute(
            f"""SELECT * FROM (
                  SELECT l.id, l.at, l.level, l.line, h.hostname FROM agent_logs l JOIN hosts h ON h.id = l.host_id
                   WHERE l.id > %s {"AND l.host_id::text = ANY(%s)" if hosts is not None else ""}
                   ORDER BY l.id DESC LIMIT %s) x ORDER BY id""",
            ((after_log, hosts, 80 if first else 400) if hosts is not None else (after_log, 80 if first else 400))).fetchall()
        evs = conn.execute(
            f"""SELECT * FROM (
                  SELECT e.id, e.at, e.actor, e.event, e.ok, e.message, c.number
                    FROM change_events e JOIN changes c ON c.id = e.change_id
                   WHERE e.id > %s {"AND e.change_id = %s" if change else ""}
                   ORDER BY e.id DESC LIMIT %s) x ORDER BY id""",
            ((after_event, change, 60 if first else 300) if change else (after_event, 60 if first else 300))).fetchall()
    return {"logs": logs, "events": evs}


# ---------------------------------------------------------------------------
# Inventory: assets (agents, vCenter, WSUS) and software (agents)
# ---------------------------------------------------------------------------

ASSET_PERMS = ("approve", "decom", "revoke")
ASSET_UPLOADS_PER_HOUR = 20
ASSET_ACTION_MAX = 2000


def _asset_perms(conn, u):
    """What this user may do to assets: admins everything, others what an
    admin ticked in Admin > Access."""
    if u.get("role") == "admin":
        return list(ASSET_PERMS)
    try:
        with conn.transaction():
            r = conn.execute("SELECT asset_perms FROM users WHERE username = %s AND active", (u["username"],)).fetchone()
    except psycopg.errors.UndefinedColumn:
        return []
    return [p for p in ((r or {}).get("asset_perms") or []) if p in ASSET_PERMS]


def _asset_view(a):
    """One asset as the pages show it: no raw source records beyond what
    the expanded row needs."""
    from . import inventory as inv
    vm, es, ws, ma = a.get("vm") or {}, a.get("esxi") or {}, a.get("wsus") or {}, a.get("manual") or {}
    return {"key": a["key"], "name": a["name"], "device": a["category"], "device_reason": a["category_reason"],
            "device_from": a.get("device_from"), "os": a["os"], "os_from": a["os_from"],
            "os_by": {inv.SOURCE_LABEL.get(k, k): v for k, v in (a.get("os_by") or {}).items()},
            "ips": a["ips"], "detected": [inv.SOURCE_LABEL.get(x, x) for x in a["sources"]], "sources": a["sources"],
            "location": a["location"], "location_kind": a["location_kind"], "last_detected": a["last_seen"],
            "status": a["status"], "gone": a.get("gone", False), "managed": a["managed"], "powered_off": a.get("powered_off", False),
            "host_id": (a.get("agent") or {}).get("host_id"), "agent_version": (a.get("agent") or {}).get("version"),
            "approved_by": a.get("approved_by"), "approved_at": a.get("approved_at"),
            "decom_by": a.get("decom_by"), "decom_at": a.get("decom_at"), "decom_reason": a.get("decom_reason"),
            "vm": {"name": vm.get("vm_name"), "vcenter": vm.get("vcenter_host"), "cluster": vm.get("cluster"),
                   "esxi": vm.get("esxi_host"), "power": vm.get("power"), "folder": vm.get("folder"),
                   "created": vm.get("created")} if vm else None,
            "esxi": {"vcenter": es.get("vcenter_host"), "cluster": es.get("cluster"), "model": es.get("model"),
                     "version": es.get("version")} if es else None,
            "wsus": {"server": ws.get("source"), "groups": ws.get("groups"), "last_reported": ws.get("last_reported")} if ws else None,
            "apex": {k: (a.get("apex") or {}).get(k) for k in ("console", "product", "os", "not_reported", "last_connected")}
            if a.get("apex") else None,
            "sheet": {k: ma.get(k) for k in ("location", "serial", "manufacturer", "model", "owner", "notes", "updated_by", "updated_at")}
            if ma else None,
            "hardware": a.get("hardware") or {}}


@app.get("/api/v1/inventory/assets")
def inventory_assets(request: Request, view: str = "active", user: str = Depends(require_viewer)):
    """Every machine from every source with its status. view=active (new and
    approved) or decommissioned."""
    from . import inventory as inv
    if view not in ("active", "decommissioned"):
        raise HTTPException(422, "view is active or decommissioned")
    with db() as conn:
        d = inv.load_assets(conn)
        perms = _asset_perms(conn, request.state.user)
        last_upload = None
        try:
            with conn.transaction():
                last_upload = conn.execute(
                    """SELECT file_name, uploaded_by, uploaded_at, applied_by, applied_at, result FROM asset_uploads
                        WHERE status = 'applied' ORDER BY applied_at DESC LIMIT 1""").fetchone()
        except psycopg.errors.UndefinedTable:
            pass
    allv = d["assets"]
    status = {s: sum(1 for a in allv if a["status"] == s) for s in inv.STATUSES}
    rows = [a for a in allv if (a["status"] == "decommissioned") == (view == "decommissioned")]
    from . import asset_coverage as cov
    gap_rows = cov.gaps(allv)
    gap_count = len({(g["key"], g["missing"]) for g in gap_rows})
    cf = cov.facts(allv, gap_rows)
    templates = (d.get("templates") or []) if view == "active" else []
    return jsonable({"view": view, "assets": [_asset_view(a) for a in rows], "summary": d["summary"], "status": status, "gaps": gap_count,
                     "templates": templates, "powered_off": sum(1 for a in rows if a.get("powered_off")),
                     "coverage": {k: cf[k] for k in ("windows", "windows_in_wsus", "windows_in_apex", "windows_in_wsus_pct", "windows_in_apex_pct")},
                     "sources": d["sources"], "findings": inv.findings(allv), "perms": perms,
                     "last_upload": last_upload, "is_admin": request.state.user.get("role") == "admin"})


@app.get("/api/v1/inventory/assets/{key}/history")
def inventory_asset_history(key: str, user: str = Depends(require_viewer)):
    from . import inventory as inv
    key = (key or "").lower()
    if not inv.KEY_RE.match(key):
        raise HTTPException(422, "Not an asset name.")
    with db() as conn:
        try:
            with conn.transaction():
                rows = conn.execute(
                    """SELECT action, from_status, to_status, actor, at, reason, detail FROM asset_events
                        WHERE asset_key = %s ORDER BY at DESC, id DESC LIMIT 100""", (key,)).fetchall()
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Asset approval is not installed yet: run phase3a-schema.sh.")
    return jsonable({"key": key, "events": rows})


class AssetActionIn(BaseModel):
    action: str = Field(..., pattern="^(approve|decom|revoke)$")
    keys: List[str] = Field(..., min_length=1, max_length=ASSET_ACTION_MAX)
    reason: Optional[str] = Field(default=None, max_length=500)


@app.post("/api/v1/inventory/assets/action")
def inventory_asset_action(body: AssetActionIn, request: Request, user: str = Depends(require_viewer)):
    """Approve, decommission or revoke the chosen assets. Each user needs the
    permission for that action (admins have all three)."""
    from . import inventory as inv
    perm = body.action
    reason = re.sub(r"\s+", " ", (body.reason or "")).strip() or None
    if perm == "decom" and (not reason or len(reason) < 3):
        raise HTTPException(422, "Give a reason for the decommission.")
    keys = sorted({(k or "").strip().lower() for k in body.keys})
    bad = {k: "not a valid asset name" for k in keys if not inv.KEY_RE.match(k)}
    keys = [k for k in keys if k not in bad]
    with db() as conn:
        if perm not in _asset_perms(conn, request.state.user):
            raise HTTPException(403, f"You do not have the {perm.replace('decom', 'decommission')} permission. "
                                     "Ask an admin (Admin > Access).")
        current = {a["key"]: a for a in inv.load_assets(conn)["assets"]}
        done, skipped = [], dict(bad)
        try:
            with conn.transaction():
                # Every key gets a row first, so two people acting on the same new machine queue on its lock
                present = [k for k in keys if k in current]
                if present:
                    conn.cursor().executemany(
                        """INSERT INTO asset_records (asset_key, name, status, updated_by) VALUES (%s, %s, 'new', %s)
                           ON CONFLICT (asset_key) DO NOTHING""", [(k, current[k]["name"][:255], user) for k in present])
                recs = {r["asset_key"]: dict(r) for r in conn.execute(
                    "SELECT asset_key, status, prev_status FROM asset_records WHERE asset_key = ANY(%s) ORDER BY asset_key FOR UPDATE",
                    (keys,)).fetchall()}
                for k in keys:
                    a = current.get(k)
                    if a is None:
                        skipped[k] = "not in the inventory"
                        continue
                    st = (recs.get(k) or {}).get("status") or "new"
                    snap = json.dumps(inv.snapshot(a), default=str)
                    if perm == "approve":
                        if st != "new":
                            skipped[k] = "already approved" if st == "approved" else "decommissioned: revoke it first"
                            continue
                        to = "approved"
                        conn.execute(
                            """INSERT INTO asset_records (asset_key, name, status, prev_status, approved_by, approved_at, snapshot,
                                                          updated_by, updated_at)
                               VALUES (%s, %s, 'approved', 'new', %s, now(), %s, %s, now())
                               ON CONFLICT (asset_key) DO UPDATE SET name = EXCLUDED.name, status = 'approved', prev_status = 'new',
                                   approved_by = EXCLUDED.approved_by, approved_at = now(), snapshot = EXCLUDED.snapshot,
                                   updated_by = EXCLUDED.updated_by, updated_at = now()""",
                            (k, a["name"][:255], user, snap, user))
                    elif perm == "decom":
                        if st == "decommissioned":
                            skipped[k] = "already decommissioned"
                            continue
                        to = "decommissioned"
                        conn.execute(
                            """INSERT INTO asset_records (asset_key, name, status, prev_status, decom_by, decom_at, decom_reason,
                                                          snapshot, updated_by, updated_at)
                               VALUES (%s, %s, 'decommissioned', %s, %s, now(), %s, %s, %s, now())
                               ON CONFLICT (asset_key) DO UPDATE SET name = EXCLUDED.name, status = 'decommissioned',
                                   prev_status = EXCLUDED.prev_status, decom_by = EXCLUDED.decom_by, decom_at = now(),
                                   decom_reason = EXCLUDED.decom_reason, snapshot = EXCLUDED.snapshot,
                                   updated_by = EXCLUDED.updated_by, updated_at = now()""",
                            (k, a["name"][:255], st, user, reason, snap, user))
                    else:
                        if st == "new":
                            skipped[k] = "nothing to revoke"
                            continue
                        if st == "approved":
                            to = "new"
                            conn.execute(
                                """UPDATE asset_records SET status = 'new', prev_status = NULL, approved_by = NULL, approved_at = NULL,
                                          updated_by = %s, updated_at = now() WHERE asset_key = %s""", (user, k))
                        else:
                            to = (recs[k].get("prev_status") or "new")
                            conn.execute(
                                """UPDATE asset_records SET status = %s, prev_status = NULL, decom_by = NULL, decom_at = NULL,
                                          decom_reason = NULL, updated_by = %s, updated_at = now() WHERE asset_key = %s""",
                                (to, user, k))
                    conn.execute(
                        """INSERT INTO asset_events (asset_key, action, from_status, to_status, actor, reason, detail)
                           VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                        (k, {"approve": "approved", "decom": "decommissioned", "revoke": "revoked"}[perm], st, to, user, reason,
                         json.dumps({"name": a["name"], "ips": a["ips"][:5], "location": a["location"]})))
                    done.append(k)
                if done:
                    audit(conn, actor=user, actor_type="user", action="asset_" + perm, object_type="asset",
                          object_id=done[0] if len(done) == 1 else None,
                          detail={"count": len(done), "assets": done[:50], "reason": reason},
                          source_ip=client_ip(request))
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Asset approval is not installed yet: run phase3a-schema.sh.")
    return {"done": len(done), "skipped": len(skipped),
            "skipped_why": [f"{k}: {v}" for k, v in list(skipped.items())[:20]]}


class AssetTypeIn(BaseModel):
    keys: List[str] = Field(..., min_length=1, max_length=ASSET_ACTION_MAX)
    device: str = Field(..., pattern="^(server|client|esxi|appliance|network|firewall|unknown|auto)$")
    reason: Optional[str] = Field(default=None, max_length=500)


@app.post("/api/v1/inventory/assets/type")
def inventory_asset_type(body: AssetTypeIn, request: Request, user: str = Depends(require_viewer)):
    """A person sets the device type of the chosen machines (it wins over the
    rules and AI-01), or hands them back to automatic ("auto"). Needs the
    Approve permission."""
    from . import inventory as inv
    keys = sorted({(k or "").strip().lower() for k in body.keys})
    bad = [k for k in keys if not inv.KEY_RE.match(k)]
    keys = [k for k in keys if k not in bad]
    reason = re.sub(r"\s+", " ", (body.reason or "")).strip() or None
    with db() as conn:
        if "approve" not in _asset_perms(conn, request.state.user):
            raise HTTPException(403, "Setting a device type needs the Approve permission. Ask an admin (Admin > Access).")
        current = {a["key"]: a for a in inv.load_assets(conn)["assets"]}
        keys = [k for k in keys if k in current]
        # Taking a server or PC out of the server/PC types needs a reason (it is kept in the history)
        leaving = body.device not in ("auto",) + inv.EXPECTED_PATCHED and any(current[k]["category"] in inv.EXPECTED_PATCHED for k in keys)
        if leaving and (not reason or len(reason) < 3):
            raise HTTPException(422, "Give a reason: this takes a server or laptop/desktop out of those types.")
        try:
            with conn.transaction():
                if body.device == "auto":
                    conn.execute("DELETE FROM asset_type_overrides WHERE asset_key = ANY(%s)", (keys,))
                else:
                    conn.cursor().executemany(
                        """INSERT INTO asset_type_overrides (asset_key, device, set_by, reason) VALUES (%s, %s, %s, %s)
                           ON CONFLICT (asset_key) DO UPDATE SET device = EXCLUDED.device, set_by = EXCLUDED.set_by,
                               set_at = now(), reason = EXCLUDED.reason""", [(k, body.device, user, reason) for k in keys])
                conn.cursor().executemany(
                    """INSERT INTO asset_events (asset_key, action, actor, reason, detail) VALUES (%s, 'type_set', %s, %s, %s)""",
                    [(k, user, reason, json.dumps({"from": current[k]["category"], "to": body.device})) for k in keys])
                if keys:
                    audit(conn, actor=user, actor_type="user", action="asset_type_set", object_type="asset",
                          object_id=keys[0] if len(keys) == 1 else None,
                          detail={"count": len(keys), "device": body.device, "assets": keys[:50], "reason": reason},
                          source_ip=client_ip(request))
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Device types are not installed yet: run phase3a-schema.sh.")
    return {"done": len(keys), "skipped": len(body.keys) - len(keys)}


@app.post("/api/v1/inventory/check")
def inventory_check(request: Request, user: str = Depends(require_viewer)):
    """AI-01 places the OS names the rules cannot, then the findings are
    worked out again. Open to anyone who may approve, decommission or revoke."""
    from . import inventory as inv, asset_import as ai
    with db() as conn:
        if not _asset_perms(conn, request.state.user):
            raise HTTPException(403, "This needs an asset permission. Ask an admin (Admin > Access).")
        n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'asset_ai_check'
                              AND occurred_at > now() - interval '10 minutes'""", (user,)).fetchone()["n"]
        if n >= 5:
            raise HTTPException(429, "At most 5 checks in 10 minutes: try again shortly.")
        # Recorded before AI-01 is asked, so requests sent together count against the limit
        audit(conn, actor=user, actor_type="user", action="asset_ai_check", object_type="asset", detail={}, source_ip=client_ip(request))
        conn.commit()
        assets = inv.load_assets(conn)["assets"]
        conn.commit()
        try:
            r = ai.classify_unknown(conn, assets)
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Asset approval is not installed yet: run phase3a-schema.sh.")
        assets = inv.load_assets(conn)["assets"]
    return jsonable({**r, "findings": inv.findings(assets)})


@app.get("/api/v1/inventory/coverage")
def inventory_coverage(request: Request, user: str = Depends(require_viewer)):
    """Machines missing in WSUS or Apex, with the evidence and what to do,
    and the latest AI-01 summary."""
    from . import inventory as inv, asset_coverage as cov
    with db() as conn:
        assets = inv.load_assets(conn)["assets"]
        rows = cov.gaps(assets)
        f = cov.facts(assets, rows)
        latest = cov.latest(conn)
        perms = _asset_perms(conn, request.state.user)
        n_apex = sum(1 for a in assets if a.get("apex"))
    return jsonable({"rows": rows, "facts": f, "summary": latest, "perms": perms, "apex_agents": n_apex,
                     "reasons": cov.REASON_TEXT})


@app.post("/api/v1/inventory/coverage/analyse")
def inventory_coverage_analyse(request: Request, user: str = Depends(require_viewer)):
    """A fresh AI-01 summary of the gaps (anyone with an asset permission)."""
    from . import inventory as inv, asset_coverage as cov
    with db() as conn:
        if not _asset_perms(conn, request.state.user):
            raise HTTPException(403, "This needs an asset permission. Ask an admin (Admin > Access).")
        n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'asset_coverage_analysed'
                              AND occurred_at > now() - interval '10 minutes'""", (user,)).fetchone()["n"]
        if n >= 5:
            raise HTTPException(429, "At most 5 analyses in 10 minutes: try again shortly.")
        # Recorded before AI-01 is asked, so requests sent together count against the limit
        audit(conn, actor=user, actor_type="user", action="asset_coverage_analysed", object_type="asset",
              detail={}, source_ip=client_ip(request))
        conn.commit()
        assets = inv.load_assets(conn)["assets"]
        rows = cov.gaps(assets)
        text, source, model, f = cov.summarise(conn, assets, rows, user)
    return jsonable({"text": text, "source": source, "model": model, "facts": f})


# ---- Uploaded asset sheets (admins) --------------------------------------------------

def _upload_view(conn, up, rows_shown=300):
    """An upload with its preview, worked out from the stored cells and mapping."""
    from . import inventory as inv, asset_import as ai
    headers = up["headers"] if isinstance(up["headers"], list) else json.loads(up["headers"] or "[]")
    mapping = up["mapping"] if isinstance(up["mapping"], dict) else json.loads(up["mapping"] or "{}")
    cells = up["rows"] if isinstance(up["rows"], list) else json.loads(up["rows"] or "[]")
    mapping = ai.valid_mapping({k: int(v) for k, v in mapping.items() if v is not None}, len(headers)) or {}
    out = {k: up[k] for k in ("id", "file_name", "uploaded_by", "uploaded_at", "sheet", "header_row", "mapped_by", "status",
                               "applied_by", "applied_at", "result")}
    out.update({"headers": headers, "mapping": mapping, "fields": [{"key": f, "label": ai.FIELD_LABEL[f]} for f in ai.FIELDS],
                "samples": cells[:3]})
    if up["status"] != "preview":
        return out
    checked = ai.check_rows(cells, mapping) if "hostname" in mapping else []
    assets = inv.load_assets(conn)["assets"]
    manual_keys = {r["asset_key"] for r in conn.execute("SELECT asset_key FROM manual_assets").fetchall()}
    counts, rows = ai.preview(checked, assets, manual_keys)
    order = {"skip": 0, "new": 1, "update": 2, "known": 3}
    rows.sort(key=lambda r: (order[r["action"]], -len(r["fixes"]) - len(r["compare"]), r["row"]))
    in_sheet = {c["key"] for c in checked if c.get("key")}          # every row's machine, passed or not
    remove = sorted(manual_keys - in_sheet)
    out.update({"counts": counts, "rows": rows[:rows_shown], "need_hostname": "hostname" not in mapping,
                "would_remove": len(remove), "would_remove_names": remove[:20],
                "replace_allowed": counts["valid"] >= max(1, counts["rows"] // 2)})
    return out


def _upload_row(conn, uid):
    try:
        uid = str(uuid.UUID(str(uid)))
    except ValueError:
        raise HTTPException(404, "No such upload.")
    try:
        with conn.transaction():
            r = conn.execute("SELECT * FROM asset_uploads WHERE id = %s", (uid,)).fetchone()
    except psycopg.errors.UndefinedTable:
        raise HTTPException(503, "Asset upload is not installed yet: run phase3a-schema.sh.")
    if not r:
        raise HTTPException(404, "No such upload.")
    return dict(r)


@app.post("/api/v1/inventory/uploads")
def inventory_upload(request: Request, file: UploadFile = File(...), admin: str = Depends(require_admin)):
    """An Excel or CSV sheet of assets: read here, columns mapped (AI-01,
    checked against the cells), every row checked, shown as a preview."""
    from . import asset_import as ai
    data = file.file.read(ai.MAX_BYTES + 1)     # a plain def: FastAPI runs it in a thread, AI-01 may take a minute
    fn = os.path.basename((file.filename or "").replace("\\", "/"))[:120] or "upload"
    with db() as conn:
        try:
            with conn.transaction():
                n = conn.execute("""SELECT count(*) AS n FROM asset_uploads WHERE uploaded_by = %s
                                      AND uploaded_at > now() - interval '1 hour'""", (admin,)).fetchone()["n"]
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Asset upload is not installed yet: run phase3a-schema.sh.")
        if n >= ASSET_UPLOADS_PER_HOUR:
            raise HTTPException(429, f"At most {ASSET_UPLOADS_PER_HOUR} uploads an hour: try again later.")
        try:
            sheet, rows = ai.read_file(fn, data)
        except ai.SheetError as e:
            raise HTTPException(422, str(e))
        hr = ai.header_row(rows)
        if len(rows) - hr - 1 > ai.MAX_ROWS:              # never cut silently: a cut-off row could be removed by "replace"
            raise HTTPException(422, f"The sheet has more than {ai.MAX_ROWS} asset rows. Split it into smaller files.")
        headers, cells = rows[hr], rows[hr + 1:]
        conn.commit()                                     # nothing held open while AI-01 reads the headers
        mapping, mapped_by, notes = ai.choose_mapping(headers, cells)
        with conn.transaction():
            r = conn.execute(
                """INSERT INTO asset_uploads (file_name, sha256, uploaded_by, sheet, header_row, headers, mapping, mapped_by, rows)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING *""",
                (fn, ai.sha256(data), admin, sheet, hr + 1, json.dumps(headers), json.dumps(mapping), mapped_by,
                 json.dumps(cells))).fetchone()
            audit(conn, actor=admin, actor_type="user", action="asset_sheet_uploaded", object_type="asset_upload",
                  object_id=str(r["id"]), detail={"file": fn, "rows": len(cells), "mapped_by": mapped_by},
                  source_ip=client_ip(request))
        v = _upload_view(conn, dict(r))
        v["notes"] = notes
        return jsonable(v)


@app.get("/api/v1/inventory/uploads")
def inventory_uploads(admin: str = Depends(require_admin)):
    with db() as conn:
        try:
            with conn.transaction():
                rows = conn.execute(
                    """SELECT id, file_name, uploaded_by, uploaded_at, status, mapped_by, applied_by, applied_at, result
                         FROM asset_uploads ORDER BY uploaded_at DESC LIMIT 20""").fetchall()
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Asset upload is not installed yet: run phase3a-schema.sh.")
    return jsonable({"uploads": rows})


@app.get("/api/v1/inventory/uploads/{uid}")
def inventory_upload_get(uid: str, admin: str = Depends(require_admin)):
    with db() as conn:
        return jsonable(_upload_view(conn, _upload_row(conn, uid)))


class UploadMappingIn(BaseModel):
    mapping: Dict[str, Optional[int]]


@app.patch("/api/v1/inventory/uploads/{uid}")
def inventory_upload_map(uid: str, body: UploadMappingIn, request: Request, admin: str = Depends(require_admin)):
    """The admin corrects which column holds what."""
    from . import asset_import as ai
    with db() as conn:
        up = _upload_row(conn, uid)
        if up["status"] != "preview":
            raise HTTPException(409, "This upload was already applied or discarded.")
        headers = up["headers"] if isinstance(up["headers"], list) else json.loads(up["headers"] or "[]")
        m = ai.valid_mapping({k: v for k, v in body.mapping.items() if v is not None}, len(headers))
        if m is None:
            raise HTTPException(422, "Each column can be used once, and only columns of the sheet.")
        with conn.transaction():
            conn.execute("UPDATE asset_uploads SET mapping = %s, mapped_by = 'admin' WHERE id = %s AND status = 'preview'",
                         (json.dumps(m), up["id"]))
        up["mapping"], up["mapped_by"] = m, "admin"
        return jsonable(_upload_view(conn, up))


class UploadApplyIn(BaseModel):
    replace: bool = False


@app.post("/api/v1/inventory/uploads/{uid}/apply")
def inventory_upload_apply(uid: str, body: UploadApplyIn, request: Request, admin: str = Depends(require_admin)):
    """Save the valid rows as Manual assets. replace: also remove Manual
    assets from earlier sheets that are not in this one."""
    from . import asset_import as ai
    with db() as conn:
        up = _upload_row(conn, uid)
        if up["status"] != "preview":
            raise HTTPException(409, "This upload was already applied or discarded.")
        v = _upload_view(conn, up, rows_shown=ai.MAX_ROWS)
        if v.get("need_hostname"):
            raise HTTPException(422, "Choose the column that holds the host name first.")
        good = [r for r in v["rows"] if r["ok"]]
        if not good:
            raise HTTPException(422, "No row passed the checks: nothing to save.")
        with conn.transaction():
            st = conn.execute("SELECT status FROM asset_uploads WHERE id = %s FOR UPDATE", (up["id"],)).fetchone()
            if st["status"] != "preview":
                raise HTTPException(409, "This upload was already applied or discarded.")
            if not conn.execute("SELECT 1 FROM schema_version WHERE version = 32").fetchone():
                raise HTTPException(503, "The asset sheet needs schema 032: run phase3a-schema.sh, then apply again.")
            conn.cursor().executemany(
                """INSERT INTO manual_assets (asset_key, name, ips, os, device, location, serial, manufacturer, model, owner, notes,
                                              upload_id, updated_by, updated_at)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now())
                   ON CONFLICT (asset_key) DO UPDATE SET name = EXCLUDED.name, ips = EXCLUDED.ips, os = EXCLUDED.os,
                       device = EXCLUDED.device, location = EXCLUDED.location, serial = EXCLUDED.serial,
                       manufacturer = EXCLUDED.manufacturer, model = EXCLUDED.model, owner = EXCLUDED.owner,
                       notes = EXCLUDED.notes, upload_id = EXCLUDED.upload_id, updated_by = EXCLUDED.updated_by, updated_at = now()""",
                [(r["key"], r["name"][:255], r["ips"][:20], r["os"], r["device"], r["location"], r["serial"], r.get("manufacturer"),
                  r.get("model"), r["owner"], r["notes"], up["id"], admin) for r in good])
            removed = 0
            if body.replace:
                if not v["replace_allowed"]:
                    raise HTTPException(422, "Fewer than half the rows passed the checks, so earlier Manual assets are not removed. "
                                             "Fix the sheet or the columns, or apply without removing.")
                keep = sorted({c["key"] for c in ai.check_rows(
                    up["rows"] if isinstance(up["rows"], list) else json.loads(up["rows"] or "[]"), v["mapping"]) if c.get("key")})
                removed = len(conn.execute("DELETE FROM manual_assets WHERE asset_key <> ALL(%s) RETURNING asset_key",
                                           (keep,)).fetchall())
            conn.cursor().executemany(
                """INSERT INTO asset_events (asset_key, action, actor, reason, detail) VALUES (%s, 'uploaded', %s, %s, %s)""",
                [(r["key"], admin, "from " + up["file_name"], json.dumps({"row": r["row"], "action": r["action"]}))
                 for r in good if r["action"] == "new"])
            result = {**v["counts"], "saved": len(good), "removed": removed}
            conn.execute("""UPDATE asset_uploads SET status = 'applied', applied_by = %s, applied_at = now(), result = %s,
                                   rows = '[]'::jsonb WHERE id = %s""", (admin, json.dumps(result), up["id"]))
            audit(conn, actor=admin, actor_type="user", action="asset_sheet_applied", object_type="asset_upload",
                  object_id=str(up["id"]), detail={"file": up["file_name"], **result}, source_ip=client_ip(request))
        # Machines now in both WSUS and the sheet are approved at once (also hourly by the worker)
        try:
            from . import inventory as inv, asset_coverage as cov
            result["auto_approved"] = cov.auto_approve(conn, inv.load_assets(conn)["assets"])
        except Exception as e:  # noqa: BLE001 - the sheet is saved; the worker approves within the hour
            log.warning("auto-approval after upload: %s", type(e).__name__)
            result["auto_approved"] = 0
    return result


@app.post("/api/v1/inventory/uploads/{uid}/discard")
def inventory_upload_discard(uid: str, request: Request, admin: str = Depends(require_admin)):
    with db() as conn:
        up = _upload_row(conn, uid)
        with conn.transaction():
            r = conn.execute("""UPDATE asset_uploads SET status = 'discarded', rows = '[]'::jsonb
                                 WHERE id = %s AND status = 'preview' RETURNING id""", (up["id"],)).fetchone()
            if not r:
                raise HTTPException(409, "This upload was already applied or discarded.")
            audit(conn, actor=admin, actor_type="user", action="asset_sheet_discarded", object_type="asset_upload",
                  object_id=str(up["id"]), detail={"file": up["file_name"]}, source_ip=client_ip(request))
    return {"ok": True}


@app.get("/api/v1/inventory/software")
def inventory_software(platform: str = "windows", category: str = "all", q: str = "",
                       user: str = Depends(require_viewer)):
    """Installed software across machines with an agent, by program and
    version. Windows: Programs and Features. Linux: installed packages."""
    from . import inventory as inv
    if platform not in ("windows", "linux"):
        raise HTTPException(422, "platform must be windows or linux")
    if category != "all" and category not in inv.CATEGORIES:
        raise HTTPException(422, "unknown category")
    q = q.strip()[:100]
    with db() as conn:
        hosts = conn.execute(
            """SELECT id::text AS id, hostname, os_id, os_version, os_edition FROM hosts
                WHERE status <> 'decommissioned' AND (%s = 'windows') = (os_id = 'windows')""", (platform,)).fetchall()
        cats = {h["id"]: inv.classify(inv._agent_os(h))[0] for h in hosts}
        ids = [i for i, c in cats.items() if category == "all" or c == category]
        names = {h["id"]: h["hostname"] for h in hosts}
        if not ids:
            return {"programs": [], "machines": 0, "platform": platform, "category": category,
                    "counts": {c: sum(1 for x in cats.values() if x == c) for c in inv.CATEGORIES}}
        if platform == "windows":
            rows = conn.execute(
                """SELECT name, publisher, version, array_agg(DISTINCT host_id::text) AS hosts
                     FROM windows_software WHERE host_id::text = ANY(%s)
                      AND (%s = '' OR name ILIKE '%%' || %s || '%%' OR publisher ILIKE '%%' || %s || '%%')
                    GROUP BY name, publisher, version ORDER BY lower(name), version DESC LIMIT 3000""",
                (ids, q, q, q)).fetchall()
        else:
            rows = conn.execute(
                """SELECT name, NULL::text AS publisher, version || '-' || release AS version,
                          array_agg(DISTINCT host_id::text) AS hosts
                     FROM host_packages WHERE host_id::text = ANY(%s) AND (%s = '' OR name ILIKE '%%' || %s || '%%')
                    GROUP BY name, version, release ORDER BY lower(name), 3 DESC LIMIT 3000""",
                (ids, q, q)).fetchall()
    progs = {}
    for r in rows:
        k = (r["name"], r["publisher"])
        p = progs.setdefault(k, {"name": r["name"], "publisher": r["publisher"], "machines": 0, "versions": []})
        hs = sorted(names.get(h, h) for h in r["hosts"])
        p["versions"].append({"version": r["version"], "machines": len(hs), "hosts": hs[:300]})
        p["machines"] += len(hs)
    return {"programs": list(progs.values()), "machines": len(ids), "platform": platform, "category": category,
            "truncated": len(rows) >= 3000,
            "counts": {c: sum(1 for x in cats.values() if x == c) for c in inv.CATEGORIES}}



# ---------------------------------------------------------------------------
# Antivirus: Trend Micro Apex Central consoles (read-only)
# ---------------------------------------------------------------------------

AV_TESTS_PER_10MIN = 20


class AvConsoleIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=60)
    url: str = Field(..., min_length=9, max_length=300)
    app_id: Optional[str] = Field(None, max_length=80)        # blank on edit: keep the saved one
    api_key: Optional[str] = Field(None, max_length=200)      # blank on edit: keep the saved one
    ca_pem: Optional[str] = Field(None, max_length=20000)
    use_proxy: bool = False
    enabled: bool = True
    pin_sha256: Optional[str] = Field(None, max_length=120)   # None: keep; "": remove; value: trust this certificate


class AvTestIn(BaseModel):
    id: Optional[str] = Field(None, max_length=36)            # test a saved console (its saved key) ...
    url: Optional[str] = Field(None, max_length=300)          # ... or what is typed in the form
    app_id: Optional[str] = Field(None, max_length=80)
    api_key: Optional[str] = Field(None, max_length=200)
    ca_pem: Optional[str] = Field(None, max_length=20000)
    use_proxy: bool = False
    pin_sha256: Optional[str] = Field(None, max_length=120)   # None: keep; "": remove; value: trust this certificate


def _av_view(conn):
    from . import antivirus as av
    cons = av.consoles(conn)
    try:
        with conn.transaction():
            from . import av_logs
            for c in cons:
                c["logs"] = av_logs.availability(conn, c["id"])
    except psycopg.errors.UndefinedTable:
        pass
    return {"consoles": cons, "key_ready": os.access(av.KEY_FILE, os.R_OK),
            "sync_minutes": av.SYNC_MINUTES}


def _av_id(cid):
    if not re.fullmatch(r"[0-9a-f-]{36}", cid or ""):
        raise HTTPException(404, "No such console.")
    return cid


class AvCertIn(BaseModel):
    id: Optional[str] = Field(None, max_length=36)
    url: Optional[str] = Field(None, max_length=300)
    use_proxy: bool = False


def _av_pin_check(url, use_proxy, pin):
    """The console must present the pinned certificate now, so a typo or a
    certificate changed in the meantime is caught when saving."""
    from . import antivirus as av
    cert = av.fetch_certificate({"url": url, "use_proxy": use_proxy})
    if cert["sha256"] != pin:
        raise av.AvError("The console now presents a different certificate (SHA-256 " + cert["sha256_text"]
                         + "): get it again and compare.")
    return cert


@app.post("/api/v1/admin/antivirus/certificate")
def av_certificate(body: AvCertIn, request: Request, admin: str = Depends(require_admin)):
    """The certificate the console presents (handshake only: nothing is sent),
    with both fingerprints, for the admin to compare and trust."""
    from . import antivirus as av
    with db() as conn:
        n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action IN ('av_console_tested', 'av_certificate_read')
                              AND occurred_at > now() - interval '10 minutes'""", (admin,)).fetchone()["n"]
        if n >= AV_TESTS_PER_10MIN:
            raise HTTPException(429, f"At most {AV_TESTS_PER_10MIN} checks in 10 minutes: try again shortly.")
        saved = conn.execute("SELECT url, use_proxy, pin_sha256 FROM av_consoles WHERE id = %s", (_av_id(body.id),)).fetchone() \
            if body.id else None
        try:
            url = av.clean_url(body.url) if body.url else (saved or {}).get("url")
            if not url:
                raise av.AvError("Enter the console URL.")
        except av.AvError as e:
            raise HTTPException(422, str(e))
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="av_certificate_read", object_type="av_console",
                  object_id=body.id, detail={"url": url}, source_ip=client_ip(request))
    try:
        cert = av.fetch_certificate({"url": url, "use_proxy": body.use_proxy if body.url or not saved else saved["use_proxy"]})
    except av.AvError as e:
        raise HTTPException(422, str(e))
    cert["pinned_now"] = bool(saved and saved["pin_sha256"] == cert["sha256"])
    return cert


@app.get("/api/v1/admin/antivirus")
def av_admin(admin: str = Depends(require_admin)):
    with db() as conn:
        return jsonable(_av_view(conn))


@app.post("/api/v1/admin/antivirus/test")
def av_test(body: AvTestIn, request: Request, admin: str = Depends(require_admin)):
    """Sign in to Apex Central and list its agents, without saving them. With
    an id and no key typed, the saved key is used (it never leaves PATCH-01)."""
    from . import antivirus as av
    with db() as conn:
        n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'av_console_tested'
                              AND occurred_at > now() - interval '10 minutes'""", (admin,)).fetchone()["n"]
        if n >= AV_TESTS_PER_10MIN:
            raise HTTPException(429, f"At most {AV_TESTS_PER_10MIN} tests in 10 minutes: try again shortly.")
        saved = None
        if body.id:
            saved = conn.execute("SELECT * FROM av_consoles WHERE id = %s", (_av_id(body.id),)).fetchone()
            if not saved:
                raise HTTPException(404, "No such console.")
        try:
            url = av.clean_url(body.url) if body.url else (saved or {}).get("url")
            console = {"url": url,
                       "app_id": av.clean_app_id(body.app_id) if body.app_id else (saved or {}).get("app_id"),
                       # None: the saved CA; "": none (the form's "remove"); text: this CA
                       "ca_pem": (saved or {}).get("ca_pem") if body.ca_pem is None else av.clean_ca(body.ca_pem),
                       "use_proxy": body.use_proxy,
                       "pin_sha256": (saved or {}).get("pin_sha256") if body.pin_sha256 is None else av.clean_pin(body.pin_sha256)}
            if saved and url != saved["url"] and body.pin_sha256 is None:
                console["pin_sha256"] = None              # a pinned certificate belongs to its own address
            if not console["url"] or not console["app_id"]:
                raise av.AvError("Enter the console URL and the Application ID.")
            if body.api_key:
                key = av.clean_key(body.api_key)
            elif saved and url == saved["url"]:
                key = av.decrypt(saved["api_key_enc"])          # the saved key only ever signs for its own console
            elif saved:
                raise av.AvError("The URL differs from the saved one: enter the API key again to test it.")
            else:
                raise av.AvError("Enter the API key.")
        except av.AvError as e:
            raise HTTPException(422, str(e))
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="av_console_tested", object_type="av_console",
                  object_id=body.id, detail={"url": console["url"]}, source_ip=client_ip(request))
        conn.commit()
    started = datetime.now(timezone.utc)
    try:
        agents, truncated, fields = av.list_agents(console, key, with_fields=True)
        sm = av.summary(agents)
        sm["fields"] = fields
        sm["health"] = {"definitions": sum(1 for a in agents if a.get("pattern_version")),
                        "connection": sum(1 for a in agents if a.get("last_connected") or a.get("online") is not None)}
        result = {"ok": True, "message": f"Signed in. Apex Central lists {sm['agents']}"
                                         + ("+" if truncated else "") + " agents.", **sm,
                  "sample": [a["host_name"] for a in agents[:5]],
                  "ms": int((datetime.now(timezone.utc) - started).total_seconds() * 1000)}
    except av.AvError as e:
        result = {"ok": False, "message": str(e)}
    except Exception as e:  # noqa: BLE001 - never a 500 with a stack trace from a far end's answer
        log.warning("antivirus test: %s", type(e).__name__)
        result = {"ok": False, "message": "The console's answer could not be read."}
    finally:
        key = None
    if saved:
        with db() as conn:
            conn.execute("UPDATE av_consoles SET last_test_at = now(), last_test_ok = %s, last_test_msg = %s WHERE id = %s",
                         (result["ok"], result["message"][:400], saved["id"]))
            conn.commit()
    return result


@app.post("/api/v1/admin/antivirus")
def av_create(body: AvConsoleIn, request: Request, admin: str = Depends(require_admin)):
    from . import antivirus as av
    try:
        name = body.name.strip()
        if not av.NAME_RE.match(name):
            raise av.AvError("The name may use letters, digits, spaces and . _ ( ) -")
        url, app_id = av.clean_url(body.url), av.clean_app_id(body.app_id)
        key_enc = av.encrypt(av.clean_key(body.api_key))
        ca = av.clean_ca(body.ca_pem)
        pin = av.clean_pin(body.pin_sha256)
        pin_cert = _av_pin_check(url, body.use_proxy, pin) if pin else None
    except av.AvError as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        with conn.transaction():
            if conn.execute("SELECT 1 FROM av_consoles WHERE lower(name) = lower(%s) OR url = %s", (name, url)).fetchone():
                raise HTTPException(409, "A console with this name or URL is already added.")
            try:
                with conn.transaction():
                    r = conn.execute(
                        """INSERT INTO av_consoles (name, url, app_id, api_key_enc, ca_pem, use_proxy, enabled, created_by,
                                                    sync_requested_at, pin_sha256, pin_subject, pin_not_after, pinned_by, pinned_at)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s, now(), %s,%s,%s,%s, CASE WHEN %s::text IS NULL THEN NULL ELSE now() END)
                           RETURNING id""",
                        (name, url, app_id, key_enc, ca, body.use_proxy, body.enabled, admin, pin,
                         (pin_cert or {}).get("subject"), (pin_cert or {}).get("not_after"), admin if pin else None, pin)).fetchone()
            except psycopg.errors.UniqueViolation:
                raise HTTPException(409, "A console with this name is already added.")
            audit(conn, actor=admin, actor_type="user", action="av_console_added", object_type="av_console",
                  object_id=str(r["id"]), detail={"name": name, "url": url, "ca": bool(ca), "proxy": body.use_proxy,
                                                  "pinned_sha256": pin},
                  source_ip=client_ip(request))
        return jsonable(_av_view(conn))


@app.put("/api/v1/admin/antivirus/{cid}")
def av_update(cid: str, body: AvConsoleIn, request: Request, admin: str = Depends(require_admin)):
    from . import antivirus as av
    cid = _av_id(cid)
    try:
        name = body.name.strip()
        if not av.NAME_RE.match(name):
            raise av.AvError("The name may use letters, digits, spaces and . _ ( ) -")
        url = av.clean_url(body.url)
        app_id = av.clean_app_id(body.app_id) if body.app_id else None
        key_enc = av.encrypt(av.clean_key(body.api_key)) if body.api_key else None
        ca = av.clean_ca(body.ca_pem) if body.ca_pem is not None else None
        pin = av.clean_pin(body.pin_sha256) if body.pin_sha256 else None
        pin_cert = _av_pin_check(url, body.use_proxy, pin) if pin else None
    except av.AvError as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        with conn.transaction():
            cur = conn.execute("SELECT url FROM av_consoles WHERE id = %s", (cid,)).fetchone()
            if not cur:
                raise HTTPException(404, "No such console.")
            if url != cur["url"] and not key_enc:
                # The saved key never signs for another address
                raise HTTPException(422, "The URL has changed: enter the API key again.")
            if conn.execute("SELECT 1 FROM av_consoles WHERE id <> %s AND (lower(name) = lower(%s) OR url = %s)",
                            (cid, name, url)).fetchone():
                raise HTTPException(409, "Another console has this name or URL.")
            try:
                with conn.transaction():
                    conn.execute(
                        """UPDATE av_consoles SET name = %s, url = %s, app_id = coalesce(%s, app_id),
                                  api_key_enc = coalesce(%s, api_key_enc),
                                  ca_pem = CASE WHEN %s::boolean THEN %s ELSE ca_pem END,
                                  use_proxy = %s, enabled = %s, updated_by = %s, updated_at = now(),
                                  sync_requested_at = now(),
                                  pin_sha256 = CASE WHEN %s THEN %s WHEN url <> %s THEN NULL ELSE pin_sha256 END,
                                  pin_subject = CASE WHEN %s THEN %s WHEN url <> %s THEN NULL ELSE pin_subject END,
                                  pin_not_after = CASE WHEN %s THEN %s::timestamptz WHEN url <> %s THEN NULL ELSE pin_not_after END,
                                  pinned_by = CASE WHEN %s THEN %s WHEN url <> %s THEN NULL ELSE pinned_by END,
                                  pinned_at = CASE WHEN %s THEN (CASE WHEN %s::text IS NULL THEN NULL ELSE now() END)
                                                   WHEN url <> %s THEN NULL ELSE pinned_at END
                            WHERE id = %s""",
                        (name, url, app_id, key_enc, body.ca_pem is not None, ca, body.use_proxy, body.enabled, admin,
                         body.pin_sha256 is not None, pin, url,
                         body.pin_sha256 is not None, (pin_cert or {}).get("subject"), url,
                         body.pin_sha256 is not None, (pin_cert or {}).get("not_after"), url,
                         body.pin_sha256 is not None, admin if pin else None, url,
                         body.pin_sha256 is not None, pin, url, cid))
            except psycopg.errors.UniqueViolation:
                raise HTTPException(409, "Another console has this name.")
            audit(conn, actor=admin, actor_type="user", action="av_console_changed", object_type="av_console",
                  object_id=cid, detail={"name": name, "url": url, "app_id": "replaced" if app_id else "unchanged",
                                         "api_key": "replaced" if key_enc else "unchanged",
                                         "ca": "changed" if body.ca_pem is not None else "unchanged",
                                         "pinned_sha256": pin if body.pin_sha256 else ("removed" if body.pin_sha256 == "" else "unchanged"),
                                         "enabled": body.enabled}, source_ip=client_ip(request))
        return jsonable(_av_view(conn))


@app.delete("/api/v1/admin/antivirus/{cid}")
def av_delete(cid: str, request: Request, admin: str = Depends(require_admin)):
    cid = _av_id(cid)
    with db() as conn:
        with conn.transaction():
            r = conn.execute("DELETE FROM av_consoles WHERE id = %s RETURNING name, url", (cid,)).fetchone()
            if not r:
                raise HTTPException(404, "No such console.")
            audit(conn, actor=admin, actor_type="user", action="av_console_removed", object_type="av_console",
                  object_id=cid, detail=dict(r), source_ip=client_ip(request))
        return jsonable(_av_view(conn))


@app.post("/api/v1/admin/antivirus/{cid}/sync")
def av_sync(cid: str, request: Request, admin: str = Depends(require_admin)):
    cid = _av_id(cid)
    with db() as conn:
        with conn.transaction():
            r = conn.execute("UPDATE av_consoles SET sync_requested_at = now() WHERE id = %s AND enabled RETURNING name",
                             (cid,)).fetchone()
            if not r:
                raise HTTPException(404, "No such console, or it is turned off.")
            audit(conn, actor=admin, actor_type="user", action="av_sync_requested", object_type="av_console",
                  object_id=cid, detail={"name": r["name"]}, source_ip=client_ip(request))
        return jsonable(_av_view(conn))


@app.get("/api/v1/antivirus")
def av_page(user: str = Depends(require_viewer)):
    """Every antivirus agent the consoles report, the machine it is in our
    inventory, and our machines with no antivirus agent."""
    from . import antivirus as av
    with db() as conn:
        try:
            with conn.transaction():
                cons = av.consoles(conn)
                agents, unprotected = av.coverage(conn)
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Antivirus is not installed yet: run phase3a-schema.sh.")
    for c in cons:
        c.pop("last_test_msg", None)
    # Detections, definition status and the latest threat summary (schema 029)
    detections, summary, pstat = [], None, {}
    with db() as conn:
        try:
            with conn.transaction():
                detections = [dict(r) for r in conn.execute(
                    """SELECT d.occurred_at, d.host_name, d.ip, d.user_name, d.threat, d.category, d.action, d.result,
                              d.unresolved, d.file_path, d.sha1, d.count, c.name AS console,
                              d.occurred_at > now() - interval '24 hours' AS last_day
                         FROM av_detections d JOIN av_consoles c ON c.id = d.console_id
                        WHERE d.occurred_at > now() - interval '7 days'
                        ORDER BY d.occurred_at DESC LIMIT 2000""").fetchall()]
                for r in conn.execute("""SELECT console_id::text AS cid, lower(split_part(host_name, '.', 1)) AS h, pattern,
                                                version, versions_old FROM av_pattern_status""").fetchall():
                    k = (r["cid"], r["h"])
                    if k not in pstat or (r["versions_old"] or 0) > (pstat[k]["versions_old"] or 0):
                        pstat[k] = {"pattern": r["pattern"], "version": r["version"], "versions_old": r["versions_old"]}
                from . import av_threats
                summary = av_threats.latest(conn)
        except psycopg.errors.UndefinedTable:
            pass
    for a in agents:
        a["definitions"] = pstat.get((str(a.get("console_id")), (a["host_name"] or "").lower().split(".")[0]))
    day = [d for d in detections if d.pop("last_day", False)]
    for d in detections:
        d.pop("last_day", None)
    return jsonable({"consoles": [{k: c[k] for k in ("id", "name", "enabled", "last_sync_at", "last_sync_ok",
                                                     "last_sync_msg", "agents")} for c in cons],
                     "agents": agents, "unprotected": unprotected, "detections": detections, "summary": summary,
                     "counts": {"agents": len(agents),
                                "matched": sum(1 for a in agents if a["asset"]),
                                "unmatched": sum(1 for a in agents if not a["asset"]),
                                "isolated": sum(1 for a in agents
                                                if (a["isolation_status"] or "").lower() not in ("", "normal", "none")),
                                "not_reported": sum(1 for a in agents if a["not_reported"]),
                                "unprotected": len(unprotected),
                                "outdated": sum(1 for a in agents if a["definitions"] and (a["definitions"]["versions_old"] or 0) >= 2),
                                "detections_24h": len(day),
                                "ransomware_24h": sum(1 for d in day if d["category"] == "ransomware"),
                                "unresolved_24h": sum(1 for d in day if d["unresolved"])}})



# ---------------------------------------------------------------------------
# Reports by e-mail: at once (operators) or on a schedule (admins)
# ---------------------------------------------------------------------------

REPORT_MAILS_PER_HOUR = 10
TIME_RE = r"^([01][0-9]|2[0-3]):[0-5][0-9]$"


def _report_params(p):
    """Report parameters: a few plain values, checked again by each report."""
    out = {}
    for k, v in list((p or {}).items())[:10]:
        if not re.fullmatch(r"[a-z][a-z_]{0,29}", str(k)):       # "_..." keys are set by the scheduler only
            continue
        if isinstance(v, bool) or (isinstance(v, int) and -10**6 < v < 10**6):
            out[k] = v
        elif isinstance(v, str) and len(v) <= 80 and re.fullmatch(r"[A-Za-z0-9 ._:()/+-]*", v):
            out[k] = v
    return out


class ReportMailIn(BaseModel):
    report: str = Field(..., max_length=40)
    params: Dict[str, Any] = Field(default_factory=dict)
    format: str = Field("pdf", pattern="^(pdf|csv)$")
    recipients: List[str] = Field(..., min_length=1, max_length=30)


class ReportScheduleIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=80)
    report: str = Field(..., max_length=40)
    params: Dict[str, Any] = Field(default_factory=dict)
    format: str = Field("pdf", pattern="^(pdf|csv)$")
    frequency: str = Field("daily", pattern="^(daily|weekly|monthly)$")
    at_time: str = Field("08:00", pattern=TIME_RE)
    weekday: str = Field("mon", pattern="^(mon|tue|wed|thu|fri|sat|sun)$")
    monthday: int = Field(1, ge=1, le=28)
    recipients: Optional[List[str]] = Field(None, max_length=30)   # None: the daily digest recipients
    skip_empty: bool = False
    enabled: bool = True


def _mail_recipients(conn):
    return [dict(r) for r in conn.execute(
        "SELECT address, name, digest FROM mail_recipients ORDER BY lower(address)").fetchall()]


@app.get("/api/v1/reports/email-options")
def report_mail_options(request: Request, user: str = Depends(require_operator)):
    """What this user may e-mail, and to whom (the configured recipients only)."""
    from . import auth, notify as nt, report_jobs
    is_admin = request.state.user.get("role") == "admin"
    with db() as conn:
        cfg = nt.config(conn, with_password=False)
        return {"reports": report_jobs.catalog(auth.user_modules(request.state.user), is_admin),
                "recipients": [{"address": r["address"], "name": r["name"]} for r in _mail_recipients(conn)],
                "mail_ready": bool(cfg["enabled"] and cfg["host"] and cfg["from"]), "can_schedule": is_admin}


@app.post("/api/v1/reports/email")
def report_mail_now(body: ReportMailIn, request: Request, user: str = Depends(require_operator)):
    """Build a report on the server now and queue it, branded, with the PDF or
    CSV attached. Never contains anything sent by the browser."""
    from . import auth, notify as nt, report_jobs
    is_admin = request.state.user.get("role") == "admin"
    if not report_jobs.allowed(body.report, auth.user_modules(request.state.user), is_admin):
        raise HTTPException(403, "Your account cannot send this report.")
    with db() as conn:
        n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'report_emailed'
                              AND occurred_at > now() - interval '1 hour'""", (user,)).fetchone()["n"]
        if n >= REPORT_MAILS_PER_HOUR:
            raise HTTPException(429, f"At most {REPORT_MAILS_PER_HOUR} report e-mails an hour: try again later.")
        cfg = nt.config(conn, with_password=False)
        if not (cfg["enabled"] and cfg["host"] and cfg["from"]):
            raise HTTPException(409, "Mail is not turned on: an admin can do it under Admin > Mail.")
        known = {a.lower() for a in cfg["to"]}
        refused = [a for a in body.recipients if a.lower() not in known]
        if refused:
            raise HTTPException(403, "Reports go only to the recipients set in Admin > Mail. Not on that list: "
                                     + ", ".join(a[:80] for a in refused[:5]))
        params = _report_params(body.params)
        # Recorded before the report is built, so requests sent together count against the hourly limit
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="report_emailed", object_type="report", object_id=body.report,
                  detail={"format": body.format, "to": body.recipients[:30], "params": params}, source_ip=client_ip(request))
        try:
            rows, to = report_jobs.queue(conn, cfg, body.report, params, body.format, body.recipients, user)
        except report_jobs.ReportError as e:
            raise HTTPException(422, str(e))
    return {"ok": True, "rows": rows, "to": to,
            "message": f"Queued for {len(to)} recipient(s); it goes out within a minute."}


class TableMailIn(TableReportIn):
    recipients: List[str] = Field(..., min_length=1, max_length=30)
    page: str = Field("", max_length=80)


@app.post("/api/v1/reports/email-table")
def report_mail_table(body: TableMailIn, request: Request, user: str = Depends(require_operator)):
    """E-mail the table a page shows (or its selected rows) as PDF or CSV, in
    the branded mail. The rows come from the browser, so the mail says so:
    'as shown on <page> by <user>'. Only to the recipients set in Admin >
    Mail, counted in the same hourly limit as other report mails, recorded in
    Activity before it is built."""
    from . import notify as nt, report_jobs
    n = len(body.columns)
    rows, budget = [], TABLE_REPORT_MAX_CHARS
    for r in body.rows:
        out = []
        for v in r[:n]:
            out.append(v if v is None or isinstance(v, (bool, int, float)) else str(v)[:1000])
            budget -= len(str(out[-1] or ""))
        if budget < 0:
            raise HTTPException(413, "This table is too large to e-mail: narrow it with the filters or select fewer rows.")
        rows.append(out + [""] * (n - len(out)))
    title = re.sub(r"[\r\n\t]+", " ", body.title).strip()[:120]
    page = re.sub(r"[^A-Za-z0-9 ,.:/()&+-]", "", body.page or "").strip()[:80] or title
    with db() as conn:
        cnt = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action IN ('report_emailed', 'table_emailed')
                                AND occurred_at > now() - interval '1 hour'""", (user,)).fetchone()["n"]
        if cnt >= REPORT_MAILS_PER_HOUR:
            raise HTTPException(429, f"At most {REPORT_MAILS_PER_HOUR} report e-mails an hour: try again later.")
        cfg = nt.config(conn, with_password=False)
        if not (cfg["enabled"] and cfg["host"] and cfg["from"]):
            raise HTTPException(409, "Mail is not turned on: an admin can do it under Admin > Mail.")
        known = {a.lower() for a in cfg["to"]}
        refused = [a for a in body.recipients if a.lower() not in known]
        if refused:
            raise HTTPException(403, "Reports go only to the recipients set in Admin > Mail. Not on that list: "
                                     + ", ".join(a[:80] for a in refused[:5]))
        with conn.transaction():
            audit(conn, actor=user, actor_type="user", action="table_emailed", object_type="report", object_id=title[:80],
                  detail={"format": body.format, "rows": len(rows), "to": body.recipients[:30], "page": page}, source_ip=client_ip(request))
        filt = re.sub(r"[\r\n\t]+", " ", body.filter).strip()[:300]
        rep_ = {"title": title, "headers": [str(c)[:60] for c in body.columns], "rows": rows, "filter": filt,
                "intro": f"{len(rows)} row{'s' if len(rows) != 1 else ''} as shown on the {page} page of Cyber-Secure by {user}"
                         + (f" (filter: {filt})" if filt else "") + ". The data is attached and summarised below.",
                "severity": "info", "preview": ([str(c)[:60] for c in body.columns][:6], [r[:6] for r in rows])}
        to = report_jobs.recipients_for(cfg, body.recipients)
        subject, text, html, att = report_jobs.compose(conn, cfg, rep_, body.format, user)
        with conn.transaction():
            nt.enqueue(conn, "report", "info", subject, text, html, to, attachment=att)
    return {"ok": True, "rows": len(rows), "to": to, "message": f"Queued for {len(to)} recipient(s); it goes out within a minute."}


def _schedules(conn):
    from . import notify as nt
    cfg = nt.config(conn, with_password=False)
    rows = [dict(r) for r in conn.execute("SELECT * FROM report_schedules ORDER BY builtin DESC, lower(name)").fetchall()]
    from . import report_jobs
    return {"schedules": rows, "recipients": _mail_recipients(conn),
            "mail_ready": bool(cfg["enabled"] and cfg["host"] and cfg["from"]),
            "digest_recipients": cfg["to_digest"],
            "reports": [{"key": k, "title": v[0]} for k, v in report_jobs.REPORTS.items()]}


def _schedule_values(conn, body):
    from . import report_jobs
    if body.report not in report_jobs.REPORTS:
        raise HTTPException(422, "Unknown report.")
    if body.recipients is not None:
        known = {r["address"].lower(): r["address"] for r in _mail_recipients(conn)}
        refused = [a for a in body.recipients if a.lower() not in known]
        if refused:
            raise HTTPException(422, "Reports go only to the recipients set in Admin > Mail. Not on that list: "
                                     + ", ".join(a[:80] for a in refused[:5]))
        if not body.recipients:
            raise HTTPException(422, "Choose at least one recipient, or the daily digest recipients.")
        recips = [known[a.lower()] for a in body.recipients]
    else:
        recips = None
    if any(c in body.name for c in "\r\n"):
        raise HTTPException(422, "The name cannot contain a line break.")
    return (body.name.strip(), body.report, body.format, body.frequency, body.at_time, body.weekday, body.monthday,
            recips, json.dumps(_report_params(body.params)), body.skip_empty, body.enabled)


@app.get("/api/v1/admin/report-schedules")
def report_schedules(admin: str = Depends(require_admin)):
    with db() as conn:
        return jsonable(_schedules(conn))


@app.post("/api/v1/admin/report-schedules")
def report_schedule_add(body: ReportScheduleIn, request: Request, admin: str = Depends(require_admin)):
    with db() as conn:
        with conn.transaction():
            v = _schedule_values(conn, body)
            r = conn.execute(
                """INSERT INTO report_schedules (name, report, format, frequency, at_time, weekday, monthday, recipients,
                                                 params, skip_empty, enabled, created_by)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id""", v + (admin,)).fetchone()
            audit(conn, actor=admin, actor_type="user", action="report_schedule_added", object_type="report_schedule",
                  object_id=str(r["id"]), detail={"name": v[0], "report": v[1], "frequency": v[3], "at": v[4],
                                                  "to": v[7] or "digest recipients"}, source_ip=client_ip(request))
        return jsonable(_schedules(conn))


def _sched_id(sid):
    if not re.fullmatch(r"[0-9a-f-]{36}", sid or ""):
        raise HTTPException(404, "No such schedule.")
    return sid


@app.put("/api/v1/admin/report-schedules/{sid}")
def report_schedule_edit(sid: str, body: ReportScheduleIn, request: Request, admin: str = Depends(require_admin)):
    sid = _sched_id(sid)
    with db() as conn:
        with conn.transaction():
            v = _schedule_values(conn, body)
            r = conn.execute(
                """UPDATE report_schedules SET name=%s, report=%s, format=%s, frequency=%s, at_time=%s, weekday=%s,
                          monthday=%s, recipients=%s, params=%s, skip_empty=%s, enabled=%s, updated_by=%s, updated_at=now()
                    WHERE id=%s RETURNING id""", v + (admin, sid)).fetchone()
            if not r:
                raise HTTPException(404, "No such schedule.")
            audit(conn, actor=admin, actor_type="user", action="report_schedule_changed", object_type="report_schedule",
                  object_id=sid, detail={"name": v[0], "report": v[1], "frequency": v[3], "at": v[4],
                                         "to": v[7] or "digest recipients", "enabled": v[10]}, source_ip=client_ip(request))
        return jsonable(_schedules(conn))


@app.delete("/api/v1/admin/report-schedules/{sid}")
def report_schedule_delete(sid: str, request: Request, admin: str = Depends(require_admin)):
    sid = _sched_id(sid)
    with db() as conn:
        with conn.transaction():
            r = conn.execute("DELETE FROM report_schedules WHERE id=%s RETURNING name", (sid,)).fetchone()
            if not r:
                raise HTTPException(404, "No such schedule.")
            audit(conn, actor=admin, actor_type="user", action="report_schedule_removed", object_type="report_schedule",
                  object_id=sid, detail={"name": r["name"]}, source_ip=client_ip(request))
        return jsonable(_schedules(conn))


@app.post("/api/v1/admin/report-schedules/{sid}/run")
def report_schedule_run(sid: str, request: Request, admin: str = Depends(require_admin)):
    """Send this scheduled report now (within a minute), whatever its schedule."""
    sid = _sched_id(sid)
    with db() as conn:
        with conn.transaction():
            r = conn.execute("UPDATE report_schedules SET run_requested_at = now() WHERE id=%s RETURNING name", (sid,)).fetchone()
            if not r:
                raise HTTPException(404, "No such schedule.")
            audit(conn, actor=admin, actor_type="user", action="report_schedule_run", object_type="report_schedule",
                  object_id=sid, detail={"name": r["name"]}, source_ip=client_ip(request))
        return jsonable(_schedules(conn))
