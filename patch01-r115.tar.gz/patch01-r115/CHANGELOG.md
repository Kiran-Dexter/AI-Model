# Patch Platform change log

Newest first. Each entry says what changed and how to deploy it.

**r115: end of support / end of life dates fill in by themselves (PATCH-01)**
- Why they did not: PATCH-01 only had the rules an admin typed in Admin ›
  Software rules; nothing filled them in.
- Now the worker reads endoflife.date once a day (through the proxy, like the
  CVE feeds) and fills the rules for Windows programs whose names are known
  for sure: SQL Server, .NET and .NET Framework, Office, Exchange, Visual
  Studio, Java (Oracle, Temurin, Corretto), Python, Node.js, PowerShell,
  PostgreSQL, MySQL, MariaDB, MongoDB, Tomcat, Firefox, Veeam, Zabbix agent.
  End of support is the end of mainstream support, end of life the end of
  security fixes; paid extended support (ESU) is written in the rule's note.
- A rule an admin typed always wins and is never changed; editing a filled-in
  rule makes it the admin's own. Linux packages keep the dates admins set.
- Admin › Software rules: the feed's state, Read now, Turn off, a filter, and
  where each rule came from.
- PATCH-01 must reach https://endoflife.date through the proxy.
- MONITOR-01 is unchanged (monitor01-r115 is the same as r114).

Install the package, then: phase3a-schema.sh (schema 058), phase3b-api.sh,
phase5-dashboard.sh. The first read starts within a minute of the worker starting.

**r114: MONITOR-01, VM monitoring from vCenter (new, its own package)**
- A new system, monitor01-r114.tar.gz, with its own address (https://<name>:9443),
  containers, database, key and certificate. It can run on the PATCH-01 server
  now and move to its own server later (--backup / --restore). PATCH-01 itself
  is unchanged in r114: there is no need to install patch01-r114.
- Every VM in vCenter, nothing installed in them: CPU, memory, CPU ready,
  drives (VMware Tools), network, uptime, snapshots; split into Windows VMs,
  Linux VMs and appliances; ESXi hosts and datastores; 1 h to 30 days of history.
- Critical alerts stay on the screen (strip, bell, toast, sound) until
  acknowledged or cleared: drive 89% used or more, CPU or memory 89% or more for
  5 minutes, CPU ready 10% or more. Warnings at 80%.
- Sign in with the PATCH-01 account (two-factor included); a local break-glass
  admin for when PATCH-01 is down. vCenter is only read: a read-only role, and an
  allow-list of read calls in MONITOR-01 itself.

Install: see monitor01/README.md, "Install".

**r113: fixes r112's install stopping at "050-verdict-fixes.sql FAILED"**
- Every install runs every database migration again, in order. Migration 050
  put back an older list of CVE verdicts without "no_data" (added by r110),
  and a database that already holds such CVEs refused it: "check constraint
  cve_impact_verdict_check ... is violated". 050 now allows every later
  verdict. Nothing was changed by the failed run: 050 was rolled back.
- Each release now applies every migration on a real PostgreSQL, then again
  over a database holding live values, before it is built.
- Includes r109 to r112.

Install the package, then the same steps as r112 (from phase3a-schema.sh on).

**r112: HUD progress rings that show the real progress of scans and jobs**
- A neon HUD ring, in each theme's own colours, wherever work runs: a patch,
  software or VMware job (its page, and the Jobs list), Deployment jobs, the
  full CVE sync (with each step and its count: feeds, servers reported, CVEs
  checked), hardening scans (rules checked), assessments (CVEs looked up),
  package uploads (16 MB pieces confirmed), and Nessus reports.
- Only real progress: one segment per server or step in its state's colour
  (done, failed, working, waiting), the ticks the share done, the figure and
  what it counts in the middle. A new figure slides from the last one; only
  the front tick glows while work runs. Where there is no figure (Nessus
  building a report), it says how long it has waited, never a made-up %.
- The page follows the work by itself: a job and the Jobs list every 10-15
  seconds, the full sync every 10 seconds while it runs.
- Fixed: r111's new Carbon Black EDR page was not known to the AI-01
  assistant, so phase5-dashboard.sh refused to install the console. The
  package test now checks this.

Deploy on PATCH-01. Install the package, then:

```bash
/opt/patch01/scripts/phase3b-api.sh
/opt/patch01/scripts/phase5-dashboard.sh
/opt/patch01/scripts/patch01-update.sh
```

If r111 is not installed yet, run its steps instead (they include these).

**r111: Carbon Black EDR, the tools cross-checked, a plan per CVE, sharper AI-01 briefs (schema 057)**
- Admin > Carbon Black EDR: connect your on-premises Carbon Black EDR server
  (address, a read-only user's API token, its certificate trusted by
  fingerprint). Read-only: PATCH-01 only sends GET requests. It reads the
  machines Carbon Black sees, and for the products the CVEs name, on which
  machine each version last ran this week (its process search), every hour
  and at each full sync. Test says if the user may search processes.
- A program Carbon Black saw counts only when it is proven to be the CVE's
  product. On each machine the version that ran last decides: affected when
  it is in the range and no fixed version ran after it. Carbon Black never
  proves a machine fixed, and never outweighs PATCH-01's own evidence.
- The tools are cross-checked on every machine: each affected line shows who
  found it (PATCH-01, Windows Update, Nessus, Carbon Black).
  - Carbon Black saw the affected version run before PATCH-01's newer proof
    that the same product is fixed: set aside as "fixed since".
  - A Nessus finding older than PATCH-01's newer proof of the fix: "cannot
    tell" until Nessus scans again (it may have found another copy, so it is
    never called clean). Before, it counted as affected for 30 days.
  - A finding newer than PATCH-01's proof stands and is flagged to check.
- Each affected CVE has a priority (Patch now / This week / Next patch
  cycle) with the reasons, and what to do on which machines (the update,
  the KB, a restart): worked out from the facts, never by AI-01.
- AI-01's brief is rewritten: it gets each machine (group, OS, versions,
  which tools found it) and what the tools disagree about, and answers in
  four parts (what it is, why it matters here, first steps, take care).
  Generic text ("apply the latest patches") is refused and not shown.

Deploy on PATCH-01 (take a VM snapshot first). Install the package, then:

```bash
/opt/patch01/scripts/phase3a-schema.sh
/opt/patch01/scripts/phase3b-api.sh
/opt/patch01/scripts/phase5-dashboard.sh
/opt/patch01/scripts/patch01-update.sh
```

**r110: CVE impact by proof, a full sync at 08:00 and 12:00, AI-01 reading data only (schema 056)**
- Full sync every day at 08:00 and 12:00 Singapore time (admins can change
  the times; "Sync now" runs it at once). Each run: the CVE feeds (NIST,
  Microsoft, Red Hat) read again, Microsoft's updates imported (the Windows
  build check needs them), CISA's exploited list, every server asked for its
  inventory, every server compared with the advisories again, every CVE
  checked again. Every problem is named on the page (a feed that failed, a
  server that did not answer, old Red Hat / Oracle advisories). The hourly
  news check stays between runs.
- A Windows program counts for a CVE only when it is proven to be the
  product: the same name and the same maker, or an admin's "Same product".
  Before, any program whose name held the product's words was compared
  (Chrome Remote Desktop Host against Chrome's versions).
- Programs that may be the product (another maker, a longer name, or the same
  maker under another name such as Java for Oracle's JRE) are listed under
  "Programs to confirm". The CVE is "cannot tell" on those servers until an
  admin decides; a decision holds for every version.
- AI-01 suggests for each of them, from the names only (no server names,
  addresses or credentials; it reaches nothing). Its suggestion never counts.
- A CVE no source has described the products of yet (NVD's analysis can take
  days), or whose Microsoft update is not imported, is "No product data yet",
  never "not in our environment". New tab "Cannot tell yet", each with why.
- Servers checked and found at a fixed version are listed as such.

Deploy on PATCH-01 (take a VM snapshot first). Install the package, then:

```bash
/opt/patch01/scripts/phase3a-schema.sh
/opt/patch01/scripts/phase3b-api.sh
/opt/patch01/scripts/phase5-dashboard.sh
/opt/patch01/scripts/patch01-update.sh
```

**r109: Chrome-type upgrades fixed; "Remove and install"; fresh software lists (schema 055, Windows agent 1.9.7-win)**
- Fixed: a program installed by its own EXE installer (Chrome from
  google.com) and upgraded with the maker's MSI was shown "older" but the
  agent answered "not installed here". PATCH-01 now tells the agent to look
  for it by the name matched on that server (works with the agents already
  installed), and agent 1.9.7-win falls back to the name when the MSI codes
  find nothing.
- New action "Remove and install" (admins only): on each server the program
  PATCH-01 matched there is removed with its own silent uninstaller, then the
  package is installed. Only where the match is certain, sure or confirmed by
  a person (not AI-01 alone), never critical software. If the removal fails,
  nothing is installed.
- "Refresh installed programs" on New deployment: the chosen servers send
  their list within about 5 minutes (else every 4 hours). Each server shows
  how old its list is. When the list says installed but the server does not
  find it, a fresh list is asked for by itself.
- A removal is called a removal in the record ("removal passed", "Removing"),
  never "install passed".
- Includes r106 to r108.

Deploy on PATCH-01 (take a VM snapshot first). Install the package, then:

```bash
/opt/patch01/scripts/phase3a-schema.sh
/opt/patch01/scripts/phase3b-api.sh
/opt/patch01/scripts/phase5-dashboard.sh
/opt/patch01/scripts/phase12-agents.sh
/opt/patch01/scripts/patch01-update.sh
```

**r108: no "failed system services" warning after `--disable`**
- `patch01-vault.sh --disable` clears the failed state of the save service
  (left when saves failed while Vault did not answer). Includes r107.
- Already disabled? Once: `systemctl reset-failed patch01-secrets-save.service`

**r107: Vault: "bind: permission denied" fixed**
- Vault could not create its socket (and write its audit log) when its
  folders were owned by root or not labelled for containers (SELinux, when
  `semanage` is not installed). Docker now labels Vault's folders itself
  (`:Z`), and their owners are put right at every start, not only at setup.
  An existing Vault is repaired by itself by `--boot` (or any start):
  its compose file is brought up to date; its data is kept.
- No database change.

On PATCH-01, install the package, then:

```bash
/opt/patch01/scripts/patch01-vault.sh --boot
/opt/patch01/scripts/patch01-vault.sh --status
```

**r106: Vault: a safe way back when it does not answer**
- `patch01-vault.sh --disable` works even when Vault does not answer: it
  writes back the credentials PATCH-01 has loaded now (RAM, the newest copy),
  or, if nothing is loaded, the plain files kept from before the move.
- `patch01-vault.sh --doctor`: one report of why Vault does not answer
  (container, mounts, socket folder, Vault's own log, SELinux), with no
  passwords or keys in it.
- No database change.

On PATCH-01, install the package, then:

```bash
/opt/patch01/scripts/patch01-vault.sh --doctor
/opt/patch01/scripts/patch01-vault.sh --disable
/opt/patch01/scripts/patch01-update.sh
```

**r105: packages matched to installed programs by evidence, not a typed name (schema 054)**
- Deployment, the Software page and the assistant decide which installed
  program is a package's product from the MSI product code, the product
  names (typed, MSI, EXE), the publisher and 32/64-bit, after removing
  versions, architecture and language words and the maker's own name.
- Each server shows the program matched, how sure, and why. Programs that
  look alike but are not certain are "maybe": never ticked or upgraded until
  an operator says Same product / Different, or AI-01 judges them (an
  operator's word wins; decisions are kept per package).
- The agent is given the exact program matched on its server (works with the
  agents already installed). Removals check the critical-software rule on it.
- Includes r103 (Vault, optional) and r104 (one folder layout in /opt).

Deploy on PATCH-01 (take a VM snapshot first). Install the package, then:

```bash
/opt/patch01/scripts/phase3a-schema.sh
/opt/patch01/scripts/phase3b-api.sh
/opt/patch01/scripts/phase5-dashboard.sh
/opt/patch01/scripts/patch01-update.sh
```

**r104: one standard folder layout in /opt**
- install.sh (both packages) now removes the unpacked package folders
  (`patch01-rNN`, `ai01-rNN`) and their `.tar.gz` files once installed, in
  /opt and wherever the package was unpacked; it asks first. /opt keeps only
  `/opt/patch01` (in use) and `/opt/patch01.prev` (for rollback), whatever the
  version. Nothing else changes; no deploy commands needed.

**r103: credentials in Vault (optional)**
- New: `patch01-vault.sh --setup` moves every file of /patch/secrets into
  HashiCorp Vault in Docker on PATCH-01 (no network port: a Unix socket for
  root only). While PATCH-01 runs, /patch/secrets is RAM filled from Vault;
  nothing is on disk in clear. Changes are saved back by themselves. Every
  read is in Vault's audit log.
- Vault unseals by itself at boot (keys encrypted for this machine with
  systemd-creds on RHEL 9), or with `--manual` someone types 3 of the 5 keys.
- Keys and token are kept in /var/lib/patch01-vault, outside /patch (never in
  the same backup as Vault's data). The kept token cannot delete; `--forget`
  removes a credential with the unseal keys.
- `--status`, `--forget-old` (delete the old plain files), `--disable`
  (back to plain files), `--new-token [--typed]`. The health check includes
  Vault. A `--setup` that stops part way is undone, and continues when run
  again.
- The setup scripts refuse to run while Vault holds the credentials and they
  are not loaded (so nothing is ever made again from an empty folder).
- Nothing changes unless you run `--setup`. See the README section
  "Credentials in Vault".

Deploy on PATCH-01 (take a VM snapshot first). Install the package, then:

```bash
/opt/patch01/scripts/patch01-update.sh
/opt/patch01/scripts/patch01-vault.sh --setup
```

**r102: agent bugs fixed (Linux agent 1.8.5, Windows agent 1.9.6-win)**

Linux agent 1.8.5:
- Ubuntu/Debian: kernel updates are listed and installed. They are new
  packages, which the update check never listed (`--with-new-pkgs`). A new
  kernel stays "automatic", so apt still clears old kernels from /boot.
- Debian: "restart needed" is detected (Debian has no reboot-required flag):
  newer kernel installed, or the same kernel rebuilt.
- Newest installed kernel chosen by version (RHEL, Oracle UEK, Ubuntu,
  Debian), not by install order or text order.
- A failed install sends its details (error, restart needed) to PATCH-01.
- A result PATCH-01 refused is no longer taken as delivered.
- A hardening scan no longer hangs when the scanner prints many warnings.
- Hardening content with script checks (OpenSCAP SCE) is refused: scans
  stay read-only.
- The restart delay reported is the one actually used.

Windows agent 1.9.6-win:
- Removing EXE programs works again (7-Zip, Notepad++, WinSCP...): the
  folder-safety check counted the normal "Users: read" as write access.
- Very long result messages are shortened instead of failing the job.
- A program with an over-long name no longer stops the software list.
- Windows Update dates are no longer shifted by the time zone.

PATCH-01:
- A check-in run by hand (`patch-agent checkin`, setup-agent.sh, the Windows
  setup and upgrade tools) no longer fails a job that is still running.
  Works for the agents already installed.

Deploy on PATCH-01 (take a VM snapshot first). Install the package, then:

```bash
/opt/patch01/scripts/phase3b-api.sh
/opt/patch01/scripts/phase12-agents.sh
/opt/patch01/scripts/patch01-update.sh
```

Then roll the agents out from Servers > Agent updates: one test server of
each kind first. If you sign agent releases, sign the two new files before
`phase12-agents.sh`.

**r101: a deployment that changed nothing is no longer "successful"**
- Deployment (install or upgrade of an uploaded package): when the installer
  ends with code 0 but the program is still the same version, or still older
  than the package, the server now fails with the reason ("nothing changed:
  the program is still version X, not Y") instead of "Done" and "Succeeded".
  Works with the agents already installed; nothing to roll out for it.
  Left as before: an install that a restart completes, portable copies, and
  versions without numbers.
- Includes r100 (below), which was not installed yet.

Deploy on PATCH-01 (take a VM snapshot first). Install the package, then:

```bash
/opt/patch01/scripts/phase3b-api.sh
/opt/patch01/scripts/phase12-agents.sh
/opt/patch01/scripts/phase7-vmware.sh --check-writer vc01
/opt/patch01/scripts/patch01-update.sh
```

**r100: banned actions (Linux agent 1.8.4)**
- Delete VM and other dangerous vCenter actions are banned in PATCH-01 itself.
  Every vCenter connection refuses them before they are sent, whatever the
  account may do: delete/unregister VM, hard power-off/reset/suspend,
  reconfigure/move/clone, programs or files inside a VM, remove-all-snapshots,
  anything that deletes/formats, and hosts, datastores, permissions, roles.
- `phase7-vmware.sh --check-writer vc01`: lists dangerous rights the write
  account holds in vCenter (also run by `--add-writer`), to tighten its role.
- Linux agent 1.8.4: patching on Ubuntu/Debian stops instead of removing a
  package (apt `--no-remove`). Old agents keep working.
- No database change. AI-01: no change.

Deploy on PATCH-01 (from `/opt/patch01`, after `./install.sh` of the package):

```bash
/opt/patch01/scripts/phase3b-api.sh
/opt/patch01/scripts/phase12-agents.sh
/opt/patch01/scripts/phase7-vmware.sh --check-writer vc01
/opt/patch01/scripts/patch01-update.sh
```


- New: **Changes > Remove snapshots by name or age**. Filter snapshots by
  name (contains / starts with / exact / pattern) and by age (older than N
  days), see every match across all VMs, tick which to remove, and schedule it
  as a normal change with a reason, window, live progress and a record.
  Each snapshot is re-checked on the VM just before removal and skipped if it
  changed. Children are never removed. Optional approval:
  `SNAPSHOT_CLEANUP_REQUIRE_APPROVAL=true`. See the README section
  "Patch jobs and VMware actions".
- Cancel or the end of the window stops a removal between snapshots. A
  single remove or revert is refused while a clean-up holds that snapshot.
  Any failed removal shows as a warning with the error, never as success.
- All VMware actions: queued VMs no longer start after the change window
  has closed (same rule as patch jobs).
- AI-01: no change (version number only).

Deploy on PATCH-01 (take a VM snapshot first), from `/opt/patch01`:

```bash
./scripts/phase3a-schema.sh           # schema 053
./scripts/phase3b-api.sh              # API and worker
./scripts/phase5-dashboard.sh         # console
./scripts/patch01-update.sh           # health check
```

**r98: two packages, one per server**
- The release is now two install packages built from one source folder:
  `patch01-r98.tar.gz` (PATCH-01, with the agents to roll out) and
  `ai01-r98.tar.gz` (AI-01). Each has its own README, MANIFEST.sha256, VERSION
  and `install.sh`, which checks the files and installs them to `/opt/patch01`
  or `/opt/ai01`, keeping the previous version as `/opt/<server>.prev`
  (`./install.sh --rollback` puts it back). Paths no longer change between
  releases.
- Source: `tools/build-packages.sh` builds both packages (and refuses while the
  agent copy in patch01/agent differs from client/; `tools/sync-agent-copy.sh`
  copies it). Tests stay in the source folder and are not shipped.
- No change to what runs. First time only: install the packages, then point the
  boot services at the new location (install.sh tells you if needed):
  `/opt/patch01/scripts/patch01-start.sh --install-boot` and
  `/opt/ai01/ai01-start.sh --install-boot`.

**r97: 71 bugs fixed from the full code review (schema 050-052; Linux agent 1.8.3, Windows 1.9.5-win)**

Deploy on PATCH-01, in this order (take a VM snapshot first):

```bash
./scripts/phase1a-ingress.sh          # nginx: client address from nginx only
./scripts/phase3a-schema.sh           # schema 050, 051, 052 and database ownership
./scripts/phase3a-schema.sh --check
./scripts/phase3b-api.sh              # API and worker (refuses to run before phase3a)
./scripts/phase5-dashboard.sh         # console
./scripts/patch01-start.sh --install-boot   # longer boot timeouts
./scripts/patch01-update.sh           # health check
```

On AI-01: copy the new `ai01/` folder, then `./ai01-start.sh --install-boot`
and `./ai01-harden.sh --check`. Agents: publish 1.8.3 / 1.9.5-win with
`phase12-agents.sh` and use Servers > Agent updates when convenient; old
agents keep working. Signed updates are optional (see "Signed agent
updates"): publish the `.sig` files and upgrade PATCH-01 before pinning a key
on any agent, because an agent with a pinned key refuses unsigned updates.

What changed, by area:
- **Results you can trust.** Servers silent for over 24 h turn their CVEs
  "unknown" (every 15 min). Windows OS-build verdicts are computed on schedule.
  "Unknown" is never shown as patched, clean or "not in our environment"
  (assessments, CVE impact with a new "Cannot tell" count, compliance, AI-01's
  notes). A fixed kernel installed but not running is "pending reboot" on every
  Red Hat-family system. Versions with letters (1.1.1k) compare correctly. A
  failed analysis is retried, not stored as clean. NVD keeps the newest CVEs.
  Windows servers with no successful Windows Update search show unknown, not
  up to date. Servers sharing a short name (web01.prod, web01.dr) are kept apart.
  Expect lower compliance and more "unknown"/"Cannot tell": that is the truth
  the old figures hid.
- **Patch jobs.** Set restart times respect the window; cancel is honoured
  right up to the install; installs never start after the window closes;
  vCenter snapshots and actions no longer freeze other jobs (up to 4 at once);
  restarts are detected on PATCH-01's clock; reports and their schedules fixed.
- **Sign-in and API.** Client addresses can no longer be faked; 2FA setup obeys
  the lock; last admin cannot be removed by two admins at once; the temporary
  password cannot be reused; malformed ids give 404; hardening uploads are
  size-limited and only accepted for pending scans; the assistant never repeats
  links or commands found in data; Nessus export, sorting and the VMware live
  feed fixed.
- **Install and operations.** The API's database role owns nothing and cannot
  TRUNCATE or drop the audit tables; the certificate helper refuses symlinks;
  re-running phase 0 no longer breaks the data folders; no passwords, keys or
  proxy credentials on command lines; loopback calls never use the proxy;
  failed repository syncs are reported; boot-time start and post-update checks
  no longer collide.
- **Agents.** Package names can never be read as options; signed agent updates
  (offline key); Windows installers checked against your own publisher list;
  push-linux.sh uses private temporary folders. Check-ins report whether the
  release key is pinned (hosts.release_key).
- **AI-01.** Hardening steps that were being confirmed when the session or the
  server went down are undone at the next run or boot; undo timers can always be
  re-armed; rollbacks only use kept steps and leave nginx valid; ai01-start.sh
  stops at the first failed part and finds broken libraries.
- Tests: 185+ unit tests and 380+ scenario checks (`ai01/tests/run-tests.sh`,
  `patch01/tests/`). The SQL was reviewed but could not be run against
  PostgreSQL here: run phase3a on a copy or snapshot first if you can.

**r96: Pulp starts reliably (the "pulp (mirrors)" step no longer hangs)**
- **Pulp's health checks were wrong**, so Docker could call a working Pulp
  unhealthy and patch01-start.sh waited 10 minutes, repaired, and waited again:
  the content app's check failed on its normal 404 answer; the API and content
  checks needed curl and the worker's needed pgrep inside the image; and the
  worker's `pgrep -f` matched its own shell, so it never noticed a dead worker.
  The checks are now small Python commands (Python is always in a Pulp image),
  never go through a proxy, and accept 404 on the content app.
  **patch01-start.sh updates the deployed compose file by itself** (backup
  kept, validated with `docker compose config`, only if python3 is in the
  image); compose then recreates the Pulp containers once.
- **patch01-start.sh waits visibly and gives up early**: progress every 30 s,
  and it stops waiting at once on a stopped, missing or unhealthy container or
  one restarting for 2 minutes (it used to wait the full 10 minutes in silence).
  `docker compose up` has a 15-minute limit.
- The settings fix (r95) checks the result is valid Python before restarting
  Pulp, sets **both** `TELEMETRY = False` and `ANALYTICS = False` (older Pulp
  reads only the first, newer only the second), and also restarts containers
  that are still starting; it says the worker may take up to 5 minutes to
  finish its current task.
- **The automatic repair is safe with nobody at the keyboard**: phase1c-pulp.sh
  no longer runs a recursive chown on the artifact volume without a terminal
  (it could take hours), and never generates a new database encryption key on
  a server where Pulp already ran (that would make stored repository
  credentials unreadable); it stops and says what to do.
- Tests: `patch01/tests/test_pulp_start.py` (16, real health-check commands
  against local servers), `patch01/tests/test-pulp-settings.sh` (17).
- Deploy: copy `patch01/scripts` and `patch01/compose` to PATCH-01, then
  `./scripts/patch01-start.sh`.

**r95: Pulp's usage-data setting fixed by itself on existing servers**
- r93 changed the setting for NEW installs only. Now **scripts/patch01-start.sh**
  also fixes existing servers: before starting Pulp it makes sure
  /patch/config/pulp/settings.py has `TELEMETRY = False` and
  `ANALYTICS = False` (backup kept next to it), and restarts the three Pulp
  containers only if it changed something. patch01-start.sh runs at every
  boot (if `--install-boot` was used), after every `patch01-update.sh` run, and
  whenever it is run by hand, so nothing has to be done manually.
- `phase1c-pulp.sh --check` (part of the update health check) shows
  "Usage data to the Pulp project: off", or a warning while the old name is
  still there.
- Test: `patch01/tests/test-pulp-settings.sh` (13 checks), also run by
  `ai01/tests/run-tests.sh`.
- Deploy: copy the bundle's `patch01/scripts` to PATCH-01. It applies at the
  next start, boot or update; to apply it now: `./scripts/patch01-start.sh`.

**r94: AI-01 hardening without downtime (ai01-harden.sh); client certificates for PATCH-01**
- **ai01/ai01-harden.sh**: interactive, one step at a time, each tested on the
  portal's own path and undone automatically if a test fails. See "Hardening
  AI-01". `--check` runs 37 tests and changes nothing. tls13 and
  mtls-enforce are kept only once PATCH-01's own requests succeed under them.
- **patch01/scripts/ai01-client.sh**: PATCH-01's half: imports the client
  certificate, tests the link end to end (including that a request without
  the certificate is refused), switches to a rotated API key.
- **llm.py**: presents PATCH-01's client certificate when
  `/patch/secrets/ai01/client.{crt,key}` exist (nothing changes without them);
  TLS 1.2 minimum; `python -m app.llm --ping` asks the model for one real answer;
  `--health` reports `client_cert`.
- **ai01-setup.sh**: no longer saves conversations to disk (`--slot-save-path`
  removed); keeps ai01-harden.sh's settings when re-run; reads only the first
  API key line (a rotation holds two); lifts and restores the model's
  immutable mark around its permission changes.
- Deploy: on PATCH-01 `./scripts/phase3b-api.sh` (or let `ai01-client.sh
  --import` do it); on AI-01 copy the `ai01/` folder. No schema change.

**r93: Pulp setting renamed (no usage data sent)**
- phase1c-pulp.sh writes `ANALYTICS = False` instead of the deprecated
  `TELEMETRY = False`, so a future Pulp that stops reading the old name cannot
  start sending usage data. Existing servers: re-run phase1c-pulp.sh, or edit
  /patch/config/pulp/settings.py and restart the three Pulp containers.

**r92: start, repair and keep started (PATCH-01 and AI-01)**
- **scripts/patch01-start.sh** and **ai01/ai01-start.sh**: start every part in
  order (each healthy before the next), repair once what does not come up,
  stop and name the part that still fails, then the full health check.
  `--install-boot` runs them at every boot. See "Starting everything, and
  keeping it started".
- The update scripts now start and repair every part after updating and
  after a restart, instead of only reporting what is down (r91 left the
  console down when an update stopped containers).
- A failed redeploy during `--images` no longer stops the update half-way:
  it is reported, every part is started and repaired, and the run exits 1.

**r91: update scripts for PATCH-01 and AI-01, with health checks**
- **scripts/patch01-update.sh** (PATCH-01) and **ai01/ai01-update.sh** (AI-01):
  OS updates (and on PATCH-01, container images), a backup first, and a
  health check before and after; `--reboot` restarts only when needed and
  checks health again after boot. With no option: a health check only. See
  "Updating PATCH-01 and AI-01 themselves".
- Safe to schedule: one run at a time, `--yes` for no questions, refused while
  patch jobs run, root-only logs and backups, and they refuse to run from
  files anyone but root could change.
- No change to the console, the API, the agents or the schema.

**r90: Clean-up and speed-up (pages look and work the same); schema 049; Windows agent 1.9.4**
- **Faster at fleet scale** (measured with 2,000 servers, 85,000 Windows
  programs, a million Linux packages): Servers 10.4 s to 0.4 s; Deployment's
  per-package server list 10.1 s to 0.2 s; Dashboard 1.7 s to 0.14 s;
  Overview 1.0 s to 0.2 s; Linux packages 1.4 s to 0.25 s; CVE feed
  suggestions 4.6 s to 1.7 s. Most of it was PostgreSQL's JIT compiler
  (7 s to compile a 0.1 s query): schema 049 turns it off for this database
  and adds two indexes.
- **Scripts and styles load about 4x lighter**: sent compressed (about 890 KB
  to 235 KB), and kept by the browser until the next upgrade (index.html
  names each file by its fingerprint). phase5 --check tests both.
- **Installers on a share removed for good**: the old page and job form, its
  API (catalog and share credentials), the worker steps, the credential store
  (/run/patch01-vault and run.key: phase3b removes both) and the agent's
  share copy (agent 1.9.4). Software jobs come from Deployment only; old
  links open Deployment. A share job booked before r90 that has not run yet
  fails with the reason instead of waiting.
- **Unused code removed**: 16 API endpoints nothing called (old agents list,
  old news, old VMware events, CVE-intel status, mark-stale and others);
  unused helpers, constants and imports in 20 Python modules; 13 dashboard
  functions (one a second "sevChip" that silently replaced the first) and 9
  unused variables; 59 style rules for classes no page uses.
- **One stylesheet**: shell.css merged into style.css in the same cascade
  order; every element of every page compared in all three themes at desktop
  and phone width: same look. phase5 removes the old shell.css.
- **The API code split by area**: main.py was one 8,000-line file; it is now
  core.py (app, sign-in, shared helpers) and 16 area modules (api_*.py).
  Statements moved unchanged; every endpoint keeps its path, role,
  parameters and code, and its order where order matters.
- **Approve / Reject on a change's page** when approval is switched on
  (REQUIRE_APPROVAL and similar): a waiting job had no button before.
- Deploy: phase3a-schema.sh (049), phase3b-api.sh, phase5-dashboard.sh. The
  Windows agent update to 1.9.4 is optional (Servers > Agent updates): 1.9.3
  keeps working.

**r89: Software reorganised and in sync with Deployment; end of support / end of life; the assistant knows the whole portal**
- **Software** is now **Windows software**, **Linux packages** and **Deployment**.
  "Installers on a share" is retired (its old link opens Deployment).
- **Windows software / Linux packages**: one row per program with its versions
  and server count; open it for each version and every server (patch group,
  address, installed date, 64/32-bit). No removal wording on the page: tick
  servers under a version and **Choose action** (Upgrade, Install, or Remove
  for admins) when you want to.
- **In sync with Deployment**: each Windows program is matched to the newest
  ready package in Deployment (by the package's "recognised by" name, as the
  agents do). Programs and versions older than the package are coloured amber
  ("upgrade available"), with a tile and filter; "Upgrade N older servers…"
  and "Install on more servers…" open Deployment's form with the package,
  the action and the servers already chosen.
- **End of support / end of life (the frame)**: rules per product (and
  optionally per version line) in **Admin › Software rules**; every version
  shows Supported, End of life soon (within 180 days), End of support or End
  of life, with a "Past end of support" tile and filter. A vendor feed can fill
  the same rules later. The removable-programs list moved to the same Admin
  page.
- **AI-01 assistant**: answers from the same data the pages use (patching from
  what each server reports, CVEs proven on our machines as Detected CVEs shows
  them) and now covers Nessus findings and scans, Deployment packages,
  upgrades available, end of support / end of life, installed patches, and
  "where is / how do I" questions for every page. A release test fails if a
  page in the menu is unknown to the assistant.
- **Removing software is admins only everywhere**, including Deployment's
  "Remove" (operators still install and upgrade packages), and follows the
  same rules: never critical software, only listed programs.
- phase5-dashboard.sh checks that the assistant knows every page in the menu
  (scripts/check-assistant-coverage.py) and stops if not.
- Schema **048**. Deploy: phase3a-schema.sh, phase3b-api.sh,
  phase5-dashboard.sh. No agent changes.

**r88: Software under one roof; installed software by program; removing listed tools (Windows agent 1.9.3)**
- **Software** now holds everything about software: **Installed software**
  (moved from Inventory), **Deployment**, **Installers on a share**, and the new
  **Removable tools**.
- **Installed software**, rebuilt for tracking: one row per program with its
  versions (and how many servers run each) and its server count; open a program
  to see each version, then every server that has it, with its patch group,
  address, installed date and 64/32-bit. Tiles (programs, machines, programs
  with several versions, removable tools found), filters by server name,
  removal state and "several versions only", and an export of every program,
  version and server. Windows programs and Linux packages.
- **Removing installed programs (admins only, no approval)**: tick servers
  under a version and press Remove; a job runs (now or at a set time) in
  Patching › Jobs, audited. Default deny:
  - only programs whose name starts with an entry of **Removable tools**
    (starts with common tools: 7-Zip, Notepad++, WinRAR, PuTTY, WinSCP,
    Wireshark, browsers, remote-support tools...; admins add or take off);
  - **critical software is never removable**, whatever the list says, and
    cannot be added to it: SQL Server and every other database, antivirus and
    EDR, backup agents, VMware Tools and drivers, .NET / Visual C++ / Java and
    other runtimes, server roles (Exchange, IIS, AD...), monitoring and
    management agents, the PATCH-01 agent. Fixed in the code; the agent checks
    it again on the server;
  - entries match whole words ("7-Zip" covers "7-Zip 23.01 (x64)"); a vendor
    or generic word alone ("Microsoft", "Windows", "Adobe") is refused as too
    broad; adding an entry shows which installed programs it makes removable;
  - only silently (MSI by product code, the program's own quiet command, Inno
    Setup, or an uninstaller verified as NSIS), only by the program's exact
    Programs and Features key, and only if the same name and version are still
    installed; never a program installed in, or removed from, a critical
    product's folder;
  - taking an entry off the list withdraws removals of it that no server has
    started yet. If the organisation sets REQUIRE_APPROVAL=true, removals
    need a second admin like every other job.
- **Windows agent 1.9.3-win**: reports each program's key and silent removal
  method, and removes listed tools as above. Servers on an older agent are
  listed but cannot be ticked until updated (Servers › Agent updates).
- Schema **047**. Deploy: phase3a-schema.sh, phase3b-api.sh (publishes Windows
  agent 1.9.3-win for Update agents), phase5-dashboard.sh. New installer zip
  `patch01-windows-installer-1.9.3.zip` for new installs and reinstalls.

**r87: fix for the Nessus pages (HTTP 500)**
- Vulnerabilities › Nessus and Admin › Nessus scanners failed with "The server
  hit an error (HTTP 500)": the API called a role check that does not exist.
  Fixed; the page endpoint itself is now under test, and every name the Nessus
  code uses is checked to exist. Deploy: phase3b-api.sh. No schema, dashboard or
  agent changes.

**r86: Nessus set up in Admin**
- Connecting a Nessus scanner (address, API keys, certificate, Test, Edit,
  Remove, Sync now) moves to **Admin › Nessus scanners**, next to Antivirus
  consoles. **Vulnerabilities › Nessus** keeps the scans, reports and findings,
  with a "Settings (Admin)" link for admins. Dashboard only: deploy with
  phase5-dashboard.sh. No schema, API or agent changes.

**r85: Nessus, under Vulnerabilities**
- **Vulnerabilities > Nessus** (new tab). Connect one or more Nessus scanners
  (admins; from r86 in Admin › Nessus scanners): address, API access key and secret key (Nessus: My Account > API
  Keys). The keys are encrypted with av.key and never shown again; saved keys
  are only ever sent to their own scanner. Nessus's self-signed certificate is
  trusted by its exact SHA-256 fingerprint (Get certificate, compare, trust);
  verification is never turned off. **Test connection** says what is wrong
  (port refused, no answer / firewall, certificate changed, keys refused) and
  which edition answered.
- **Scans, one button each**: Launch, Pause, Resume, Stop, Import now, Report
  (PDF, HTML, CSV or .nessus, built by Nessus and downloaded through PATCH-01,
  nothing kept), Edit, Open in Nessus; **New scan** (template, folder, targets
  typed or taken from patch groups, on demand / daily / weekly / monthly, start
  now). Scans are read every 15 minutes (Refresh: at once).
- **Nessus Professional**: Tenable lets outside tools only read scans and export
  reports on Professional ("API is not available" for the rest). There Launch,
  Pause, Stop, New scan and Edit show greyed out with the reason and an Open in
  Nessus link; Import, reports and findings work. On Nessus Manager every button
  works, with no change.
- **Findings**: the newest finished run of each scan is imported (low severity
  and up), matched to our servers by address or name, with tiles, graphs (by
  severity, hosts with most critical/high, findings on most hosts), filters and
  Excel / PDF / CSV. A CVE Nessus found on a machine in the last 30 days counts
  in **Detected CVEs** as proven on that machine.
- Schema **046**. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.
  Network: PATCH-01 to Nessus on TCP 8834 only. No agent changes.

**r84: Vulnerabilities, from proof only**
- **Detected CVEs now lists only what is proven on our machines.** A CVE counts
  as affecting a machine only when:
  - the installed version is older than the vendor's fixed build for that
    machine's own release (Linux packages; Windows Server's OS build against
    Microsoft's Security Update Guide; Red Hat's fixed build for each RHEL
    release, or Red Hat saying "affected, no fix yet");
  - Windows Update on the server reports the update that fixes it missing;
  - the installed version is inside NVD's affected range (Windows programs from
    the software inventory, ESXi and vCenter from vCenter).
  "Possibly affected", "Not in inventory", "Not inventoried" and "Reboot needed"
  are gone: a fix installed but waiting for a restart shows as affected, marked
  "restart only". A product that is merely installed, or an OS that merely
  matches, is not a finding. Each machine is listed once per CVE.
- **Appliances apart**: network devices, firewalls and appliances from the asset
  inventory have their own tab. "Affected" when the firmware version recorded
  for the device (OS column of the asset sheet) is in NVD's affected range; "To
  check" when the device matches the product but its version is not recorded.
- **Graphs**: affected CVEs over the last 30 days (with the exploited ones), by
  severity, machines by platform, and the products on most machines. Click a bar
  to filter the list.
- **Checked every 4 hours** (and whenever the inventory changes); Linux servers
  now send their inventory every 4 hours (Windows already did). **Scan now**
  (operators): every reporting server sends its inventory at once, vCenter is
  read again, and every CVE is checked again as the answers come in; the page
  shows how many servers have reported.
- **Assess CVEs** uses the same rules: Affected, Appliance: check, Not affected,
  Not in our environment, Cannot assess. Assessments made before r84 keep their
  old words until run again.
- **Export**: Excel with Summary, Affected CVEs, Affected machines (one row per
  CVE and machine, with the installed and fixed versions and the evidence) and
  Appliances; PDF grouped by CVE; the scheduled "Vulnerabilities" e-mail uses
  the same rules.
- Schema **045**. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.
  The first check under the new rules runs within minutes of the deploy. No
  agent changes.

**r83: Patching and vulnerabilities kept apart; Installed patches report**
- **Why**: a server could show a "missing patch" that pointed to a CVE although
  nothing was missing. A Linux server's "to install" was worked out from the CVE
  feeds, never asked of the server, and the server page opened on the CVE
  advisories. Now the patching pages show only what the servers themselves report.
- **Patching** (Servers, server page, Overview, Jobs, Patch reports, e-mails):
  - Windows: what Windows Update reports missing against WSUS (as before).
  - Linux: what the server's own package manager would install (dnf/yum
    check-update and its security notices, apt-get -s upgrade), sent by
    **Linux agent 1.8.2** (Servers > Update agents). Until a server runs 1.8.2
    it shows "patch state unknown" (a new filter and tile), never a CVE count,
    and is left out of the compliance rate.
  - A Linux "security updates" patch job installs the package manager's own
    security updates (servers on 1.8.2; older agents keep the previous selection).
  - The server page opens on **Patches**: missing updates, other updates, and what
    was installed in the last 90 days. The CVE advisories are a separate, folded
    "Vulnerabilities (CVE advisories)" section below.
  - Overview is split into **Patching** and **Vulnerabilities (CVE)**. The Servers
    export no longer carries CVE columns.
- **Installed patches** (Servers > Installed patches, also from a server page or
  from ticked servers): what each server installed and when, for a period (last
  N days or dates), group, OS or chosen servers. Windows: installed updates and
  Windows Update's history (Defender definition updates and failed attempts left
  out unless ticked). Linux: every package version with its install time (a
  server's first day of installs, its build, is not counted). Exports:
  - **Excel**: Summary per server; the period, grouped by server; everything
    installed, grouped by server; a flat sheet with filters.
  - **PDF**: the period, grouped by server, servers with nothing listed at the end.
  - Scheduled e-mail: Admin > Scheduled reports, "Installed patches".
- Schema **044**. Deploy: phase3a-schema.sh, phase3b-api.sh (publishes Linux
  agent 1.8.2 for Update agents), phase5-dashboard.sh; then send Linux agent
  1.8.2 to the Linux servers. Windows agent and installer unchanged (1.9.2).

**r82: Long installs fixed, real patch reports, admin-only restart jobs**
- **The long-install bug**: a large Windows update that ran for hours was
  stopped by the agent at 2 h 50 min and failed by PATCH-01 at 3 h, and the
  job said "nothing was installed" although Windows finished installing it.
  Now (Windows agent **1.9.2-win**):
  - the agent stops waiting only after 45 minutes with no Windows Update
    activity at all, or after 7 h 45 min in total; if Windows is still
    installing then, the server is **not** restarted and the job says
    "still installing" with what was installed so far;
  - PATCH-01 keeps waiting while the agent keeps reporting (up to 8 hours),
    and a result that arrives after it stopped waiting is still added to
    the job;
  - a single update is tracked like a batch, so its result is always kept;
  - an install that ends **after the job's window** does not restart the
    server in working hours: the restart is held, the server is checked as
    it is, and the job says "restart held" (use Servers > Restart… later).
    Jobs with their own restart time keep using it.
- **Patch reports, rebuilt** (Patching > Patch reports): four views, **By
  job** (each CHG), **By patch group**, **By server** and **Updates and
  packages**, with a group filter and exports of every view (also as
  scheduled reports). Every update is checked against what the server
  itself reports as installed (Windows installed-updates list by KB, Linux
  package versions), so an update the job missed but the server has is
  shown as installed ("confirmed on the server"), and one the job claimed
  but the server does not have is flagged. Updates the server already had
  before the job show as "Already installed", and updates WSUS replaced or
  declined since the job was planned are no longer listed as missing.
- **Restart servers (admins only)**: Servers > **Restart…** lists the
  servers that report needing a restart (offline agents unticked), or tick
  servers on the page and use **Restart them…**. Choose now or a time,
  servers at a time, the service check and a reason. Nothing is installed:
  a pre-check, the restart, a wait until it is back, and a check that the
  same services run again (no WSUS check and no Windows Update restart: a
  server with WSUS down can still be restarted). Operators do not see it
  and the API refuses it.
- **Fixes from the code review**: a job interrupted while taking a VM
  snapshot is reported, not left hanging; cancelling withdraws installs the
  agent has not picked up yet and jobs waiting for a credential; a job with
  cancelled servers is "partly succeeded", not "succeeded"; servers waiting
  to restart get freed slots before new installs start; approving a job
  whose restart time has passed is refused; an unused enrolment token can
  no longer take over another active server (re-enrolment checks the
  hardware ID, either byte order; servers without one recorded enrol as
  before); AI repair steps that download and run code are discarded; chat
  only lists job kinds the user's modules allow; an expired certificate
  upload is refused; an https AI-01 without its pinned certificate is not
  contacted; report e-mail goes only to configured recipients or your mail
  domains, with an hourly limit; 2FA failures are counted, a locked account
  cannot turn 2FA off, and a password change ends other sessions; Linux enrolment tokens never appear on a
  command line (environment or a private file; `--token` still works but
  warns); Windows agent folders and
  the push folder are admin-only.
- **Linux agent 1.8.1**: sends the hardware ID at enrolment, waits up to 4
  minutes after boot for services before the post-check, and leaves the rest
  of a batch for the next run after a restart command.
- Schema **043** (adds the "restart" job kind). Deploy: phase3a-schema.sh,
  phase3b-api.sh (publishes agents 1.9.2-win and 1.8.1 for Update agents),
  phase5-dashboard.sh. Use the new installer zip
  `patch01-windows-installer-1.9.2.zip` on your share for every install and
  reinstall. Includes r81.

**r81: Reinstalling agents: no more false "pin" errors**
- **The bug**: reinstalling the agent on a server that had been removed or
  decommissioned on PATCH-01 (or rebuilt, or cloned from another server)
  failed with "The new pin did not work". The pin was fine. The server still
  had its old agent identity, which PATCH-01 no longer accepts, so the
  installer tried to upgrade instead of enrolling again, and reported the
  failure as a pin problem.
- **Now (Windows agent 1.9.1, installer `patch01-windows-installer-1.9.1.zip`)**:
  - Before upgrading, the installer asks PATCH-01 whether it still accepts
    the server's saved identity (an empty check-in). If not, it says why,
    says the pin is fine, asks for an enrolment token and enrols again.
    PATCH-01 recognises the machine, so its history is kept.
  - The address is asked first, then the pin. The pin is checked at once
    against the certificate PATCH-01 presents at that address. A remembered
    pin that no longer fits (PATCH-01's certificate was replaced) is not
    offered, and you are told to get the current one with
    `phase10-windows.sh --pin`. If the agent's own pin fits, it is offered
    instead. A pasted pin that does not fit is refused before anything
    changes; after three it stops. The presented certificate is only
    compared, never trusted on its own.
  - When a re-pin check fails for another reason, the message says what
    really failed (identity refused, decommissioned, unreadable, network),
    not "pin".
  - Tokens typed by hand are hidden while typed.
- **Linux** (`setup-agent.sh`): reinstalling a server PATCH-01 no longer
  accepts now enrols it again with a token, instead of failing at the
  check-in. Tokens are hidden while typed. The Linux agent is unchanged.
- Servers already on 1.9.0 get agent 1.9.1 from Servers > Update agents
  (only the new identity check differs). No schema change. Deploy:
  phase3b-api.sh (publishes agent 1.9.1-win for Update agents). Use the new
  installer zip on your share.

**r80: A new look: menu on the left, a richer Overview, three themes, a new sign-in page**
- **Layout**: the sections are now a menu on the left, with the open section's
  pages listed under it. The bar on top shows where you are, the PATCH-01
  gauges, the theme, the live log and Refresh. Your name, role and Sign out sit
  at the foot of the menu (click your name for password and two-factor). On
  phones and narrow windows the menu slides in from the left.
- **Themes**: three only.
  - Default (light) and Dark for everyone.
  - B-Mode for admins: a neon control-room look (cyan, green, magenta and
    orange chrome, corner marks, angled buttons).
  - System is gone: a saved System choice becomes Default. A non-admin with
    B-Mode saved gets Dark.
- **Overview**: new top section, all computed from the database:
  - Four headline figures: servers online, servers to patch, critical and 0-day
    CVEs, patch success over 30 days. Each shows its change since last week.
    That change appears once a week of daily figures has been stored; until
    then it says so rather than guessing.
  - Updates installed per day, this month against last month, with a hover
    and keyboard tooltip.
  - Windows and Linux servers patched per week (8 weeks).
  - Compliance goals against targets (95% patched, 98% agents online, 95% jobs
    succeeding).
  - Live activity (the latest job steps, and servers that stopped reporting in
    the last 24 hours).
  - Recent jobs.
  - The existing donuts and the AI-analysed impacted CVEs follow under
    "Security posture".
- **Chat button**: drag it anywhere on the screen; it stays where you leave
  it. Double-click puts it back in the corner. The chat opens beside it.
- **Sign-in page**: rebuilt as a full-width page. It has a headline, a drawn
  network picture, the three modules, and a sign-in card with show-password.
  The critical and 0-day CVE board sits along the bottom. The theme choice is
  top right.
- Under the hood: a new `GET /api/v1/overview`. The worker stores one row of
  headline figures a day (`overview_daily`). New console files: `shell.css`
  and `overview.js`.
- Schema 042. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.

**r79: An AI that does the job, a faster console, restart at a set time**
- **Chat**: AI-01 now answers.
  - It chooses among the ~10 most likely reports, not all 40: a prompt a
    quarter the size, so it answers in seconds on a CPU. The answer is held to
    real report names (a JSON schema).
  - A question naming a CVE, KB or change number is answered at once.
  - Under the table, AI-01 answers in its own words from the rows. That answer
    is shown only if its numbers, server names, CVE/KB ids, links and commands
    are in the rows.
  - A how-to question gets a general answer, labelled as not coming from your
    data.
  - Limits: 60 questions and 30 AI answers per person per 10 minutes.
- **People first**: while someone uses the chat or Explain, background AI-01
  work (the 15-minute notes, failure explanations, CVE briefs) waits, with at
  least one turn every 10 minutes. No database connection is held while AI-01
  thinks, so other pages are never kept waiting. Database pool: 16.
- **Failure explanations**:
  - An explanation is reused only for the same job type, OS, error, warnings
    and failed updates.
  - AI-01 gets only that job's own warnings and errors.
  - An answer naming a KB, error code, CVE or file that is not in the log is
    not shown. "Ask again" gives a fresh reading.
- **Overview note**:
  - It now includes a log-event analysis: the agents' warnings and errors of
    the last hour, grouped.
  - Its numbers and server names are checked.
  - When nothing changed, AI-01 is not asked the same thing again.
- **Faster**:
  - The live log's query uses its index again. It was scanning the whole
    agent log every 3 seconds on a server page.
  - Software inventory is cached for 5 minutes.
- **Restart at a set time** (New patch > When to restart): the servers install
  from the start time, then wait. At the restart time they restart, as many at
  once as "Servers at a time" allows (one at a time for a cluster). Waiting
  servers take no slot.
  - The restart time must be at least 10 minutes after the start and within
    14 days (within 24 hours with a VM snapshot).
  - Cancelling the job before the restart time leaves the servers un-restarted,
    with a warning.
- Schema 041. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.
  Agents unchanged.

**r78: PATCH-01's own CPU, memory and network gauges**
- Three small neon gauges at the top right show PATCH-01's CPU, memory and
  network, with a needle. From 50% they turn amber. From 70% they turn red
  and glow, and smoke rises. At 90% and above the dial trembles. Click the
  gauges for the last 10 minutes and the exact figures.
- Measured by `patch01-metrics.service` on PATCH-01. It reads four small
  kernel files every 5 s and runs as the unprivileged user patch01m: no
  network, no capabilities, read-only system, at most 48 MB and 5% of one CPU.
  In practice it uses under 0.05% of one CPU and about 11 MB. It writes one
  snapshot to /run (memory), which the API reads, read-only. The API gets no
  access to the host or to Docker.
- The console asks every 5 s, only while signed in and while its tab is
  visible: about 2 KB per request, and about 0.2% of the browser's time. These
  requests do not extend the session: an unattended console still times out.
- Network % is of the network card's speed. When a VM's card does not report
  one, 1 Gbit/s is assumed, and the details say so.
- Deploy: phase3b-api.sh (installs and starts patch01-metrics and mounts its
  folder into the API) and phase5-dashboard.sh. No schema change. Agents
  unchanged.

**r77: Honest "To install", Windows updates in full, moving servers from a list, 30 rows a page (Windows agent 1.9.0)**
- **"To install" fixed for good.**
  - Linux: a server keeps old kernels installed beside the new one. PATCH-01
    could store an old one, so a fully patched server showed "1 to install".
    The newest version of each package is now kept. Every server stores its
    inventory once more after the upgrade, and "To install" is recalculated
    within minutes.
  - Windows: an update that is already installed (its KB is in the server's
    installed list), or installed and only waiting for the restart, is not
    "to install". After a full WSUS search, Windows Update decides, so a
    re-released update is still listed.
- **Windows installed updates in full** (server page): title, type, date
  installed, who installed it and the result, newest first, with a filter.
  Needs agent 1.9.0; older agents show the KBs and their type.
- **Move servers from a list** (Servers > Move from a list…, operators):
  upload a text file of server names (one per line, or paste them). PATCH-01
  shows which it found (by name, full name or short name), which it did not,
  and which names match more than one server. You choose the group, and
  nothing moves before you confirm. A full name never matches a different
  machine that has the same short name.
- **30 rows a page** in every list (servers, the servers in a group, reports,
  installed updates, packages to install...).
- **No overlapping text**: chart legends, server details and the server
  picker wrap long names. The welcome greeting sits at the top of the page
  instead of covering it.
- Schema 040. Deploy: phase3a-schema.sh, phase3b-api.sh (publishes Windows
  agent 1.9.0 for Update agents), phase5-dashboard.sh, then Servers > Update
  agents > Windows 1.9.0. New servers: patch01-windows-installer-1.9.0.zip.

**r76: Console clean-up, patch groups, two-factor sign-in**
- **One menu, no repeats**: seven sections (Overview, Servers,
  Vulnerabilities, Patching, Software, Inventory, Admin) with tabs under the
  top bar. Old links still work. Long page intros fold behind a "?".
- **Themes**: Light and Dark now have colour (gradient top bar, card
  shadows, tinted tables). System follows the computer. BOT-MODE unchanged.
- **Sign-in page**: sign-in on the left; on the right, news limited to
  0-day (exploited) and critical CVEs. The chat window shows only after
  sign-in. After sign-in: "Welcome, <name>".
- **Two-factor sign-in** (an authenticator app, TOTP): each user turns it on
  under their account (Two-factor). Recovery codes are shown once. Admins can
  reset a user's two-factor (Admin > Users). The secret is stored encrypted
  with `totp.key`, which phase3b-api.sh creates in the secrets folder and
  mounts read-only into the API only.
  - A password alone never signs in an account that has two-factor on:
    HTTP Basic is refused for it.
  - Optional, in api.env: `REQUIRE_2FA=true` makes every console account set
    it up. Script accounts (the phase scripts sign in with HTTP Basic) are
    listed in `TWO_FACTOR_EXEMPT=<account>,<account>`. Use a separate admin
    account for scripts, not a person's account.
  - Turning two-factor on or off ends that account's other sessions.
- **Patch groups**: SIT, UAT, PROD-1, PROD-2 and Cluster Servers (one
  server at a time), for Windows and Linux. Servers > By group shows each
  group folded, with counts; tick servers to "Move to group" or "Patch
  them". Admins add, change or remove groups (Servers > Groups). A group with
  servers, live enrolment tokens or maintenance windows is not removed.
  New patch: pick whole groups.
- **"To install" now means patches waiting to be installed** (Linux packages
  with a newer fixed version, plus missing Windows updates), not CVEs. A
  server's CVEs are on the Vulnerabilities page. Fixed: a server whose
  patches were all installed still showed "To install" until the nightly
  run. The worker now recomputes a server within about a minute of its new
  inventory.
- **Patch Reports grouped per server**: each server is one row; its jobs fold
  out under it (newest open, 20 at a time).
- Schema 039. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.
  Agents unchanged (1.8.0).

**r75: Update agents from PATCH-01 (agents 1.8.0)**
- **Servers > Update agents** (admins): pick the version per platform and
  the servers; PATCH-01 sends each server's agent the file over its pinned
  connection. Servers must already run agent 1.8.0: install 1.8.0 once by
  hand (Install-PatchAgent.bat / setup-agent.sh); every later version is
  sent from here.
- What each agent does: checks the SHA-256 frozen in the job, parses or
  compiles the file, checks the version written in it, on Windows checks
  its Authenticode signature whenever the running agent is signed or the
  server runs AllSigned (never signed -> unsigned), test-runs it
  (-Check / check), keeps the running version (patch-agent.prev.ps1 /
  patch-agent.prev) and swaps. PATCH-01 then sends a check job that only the
  new version can answer. If the new version has not answered within 10
  minutes (Linux: the agent's interval plus 5), the previous version puts
  itself back (a scheduled task / a systemd timer that also survives a
  restart), stopping a new version that hangs. Never a downgrade; a Linux
  agent with verify_tls=false is never updated.
- Never in the middle of another job: a server busy in a patch or software
  job is updated after it, and no patch or software job starts on a server
  while its agent is being replaced.
- What can be sent is published by root on PATCH-01 only
  (`scripts/phase12-agents.sh`; a signed Windows agent:
  `--windows <signed patch-agent.ps1>`); the folder is read-only to the API.
- Optional: AGENT_UPDATE_REQUIRE_APPROVAL=true in api.env needs a second
  admin to approve each agent update.
- Schema 038. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.
- client/ now holds the current agents (it held Windows 1.5.2).

**r74: Deployment removes software, upgrades only older versions, handles portable programs; AI-01 explains failures (agent 1.7.0)**
- **Remove** (Deployment, New deployment, Action "Remove", or "Remove from
  servers" on a package): MSI by its product or upgrade code (msiexec /x);
  EXE with the program's own quiet uninstall command, or its uninstaller with
  the package's silent uninstall options, or the documented options of Inno
  Setup and NSIS uninstallers; otherwise it is refused, never run blind. An
  uninstaller in a folder ordinary users can change is not run as SYSTEM.
  Nothing is downloaded to remove a program.
- **Version-aware**: the agent checks what is installed before downloading
  anything. Install skips servers already on that version or newer (never
  downgrades); Upgrade only touches servers with an older version and skips
  servers without it. MSI products are found by their upgrade code (every
  version); a name that matches several different programs is refused
  instead of guessed. The New deployment form shows each server's installed
  version (from its software inventory) and picks the right servers for the
  action.
- **Portable programs**: PATCH-01 (and AI-01) tell an installer from a
  portable program; a portable program is copied to
  C:\Program Files\PATCH01-Apps\<folder> and never run; upgrade replaces it,
  remove deletes its folder (only its own). Every installer has a time limit
  (default 30 minutes): one that hangs (waiting for a click) is stopped with
  everything it started, and the reason is reported.
- **Why it failed**: for every failed (or warned) server of a patch job or a
  deployment, the known Windows Update, servicing, network and installer
  codes (0x800f0985, 0x80070643, 1603...) are named with what usually fixes
  them, and AI-01 reads the error and the agent's log and says the likely
  cause and the steps, in order. Shown on the change page, Patch Reports and
  Deployments; "Ask AI-01 again" on request; identical errors are explained
  once.
- Schema 037. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh.
  Windows servers: the 1.7.0 installer (removal and portable programs need it).

**r73: Deployment page; Windows agent 1.6.0 (faster, timed); one-click installer**
- **Deployment** (new menu item, Software Lifecycle access): upload an MSI or
  EXE in the console (sent in 16 MB pieces, up to 4000 MB, kept on PATCH-01
  under its SHA-256 in /patch/data/packages).
  - PATCH-01 reads the file itself: version, vendor, MSI product code, the
    installer type (Inno Setup, NSIS, InstallShield, WiX bundle) with its
    documented silent options, and whether an EXE is signed. Nothing runs.
  - AI-01 describes the software and suggests silent options and the
    Programs and Features name: suggestions only, shown as text.
  - ClamAV (optional, `scripts/phase11-clamav.sh`): every upload is scanned;
    malware can never be deployed; a scan that could not run blocks the
    package until "Scan again".
  - An operator checks and saves the details, then deploys to chosen Windows
    servers (install, or upgrade where an older version is installed), now
    or in a window. The deployment keeps the package as it was reviewed.
    No second approval (the operator who deploys reviewed it);
    `DEPLOY_REQUIRE_APPROVAL=true` in api.env asks for one.
  - On each server the agent downloads the file from PATCH-01 in pieces over
    its pinned connection (only while it holds that job's step), checks the
    SHA-256, saves it in C:\tmp\PATCH01 (D:\tmp\PATCH01 when C: is short of
    space; \tmp is created when missing; PATCH01 is locked to SYSTEM and
    Administrators), keeps it unchangeable until the installer ends, checks
    the signature when asked, and installs silently (MSI: msiexec /qn with a
    full log). "Another installation in progress" (1618) is waited out and
    retried. The file is removed after a success, kept after a failure.
  - Deployments tab: each server's step, result, exit code and its meaning,
    where the file went, download time, warnings, the MSI log lines where it
    failed, and the agent's own log for that job.
- **Windows agent 1.6.0-win**:
  - The next step of a job is picked up within seconds (the agent keeps
    asking for 2 minutes after a step instead of waiting for its next run);
    the task also runs 1 minute after start-up, so the postcheck after a
    restart starts at once.
  - The 4-hourly inventory reads Windows' own update list (seconds) when
    Windows checked WSUS within 24 hours, instead of searching WSUS (minutes).
  - The server's DNS name is looked up every 6 hours, not every run.
  - Every run reports how long it took and where; Servers, server details,
    "Last agent run", shows it ("inventory WSUS search 340 s").
  - Fixed: installing catalog software that was not yet installed failed
    with "The property 'Version' cannot be found".
- **Install-PatchAgent.bat**: keep it, the agent zip and your .pem in one
  folder (a share is fine); right-click, Run as administrator. It unzips to
  %ProgramFiles%\PatchAgent-Setup, unblocks the files and asks for the
  certificate pin, PATCH-01's address and (new servers) a token, then shows
  SUCCESS or FAILED with the reason. Pin and address are remembered in the
  folder for the next server (Enter to reuse). The server's execution policy
  is not changed.
- Schema 036. Deploy: phase3a-schema.sh, phase3b-api.sh, phase5-dashboard.sh;
  optional phase11-clamav.sh. Windows servers: the 1.6.0 installer.

**r72: Patch Reports page; Servers tab follows patch jobs; vCenter read every 5 minutes**
- **Patch Reports** (new menu item): every finished patch job, filtered by
  period, Windows or Linux, result, server or change. Two views:
  - **Servers**: one row per server per job: result, updates installed and
    not installed, restart, snapshot (kept, removed), minutes; open a row
    (+) for its updates or packages, warnings and errors.
  - **Updates and packages**: one row per Windows update (KB, title) or
    Linux package (version, the advisories it fixes, with severity), with
    its status: installed, failed, or not found after the restart.
  - Export: PDF (landscape, logo) or CSV of every matching row, or only the
    ticked rows. E-mail: the server-built report, the table, or the ticked
    rows; the two server-built reports ("Patch report, servers" and
    "Patch report, installed updates and packages") can be scheduled
    (Admin > Report schedules), for example weekly.
- **Servers tab** now matches the patch jobs:
  - Windows updates installed by a job leave "To install" at once (not at
    the next inventory), and "Reboot" follows the job (set after the
    install, cleared after a clean restart).
  - New column **Last patched**: when, and the result; it opens that job
    in Patch Reports. The server's details show it too.
  - vCenter, cluster and power come from the same VM the snapshot uses
    (powered on, with the agent's address).
- **New VMs**: the worker now reads each vCenter every 5 minutes
  (`VMWARE_SYNC_MINUTES`, minimum 2), and at once when an agent enrols or
  a snapshot job is booked for a server not linked to its VM yet. The
  hourly timer stays as a backup; reads never overlap. Read history is
  kept 30 days.
- Schema 035 (one column, one index). Deploy: phase3a-schema.sh,
  phase3b-api.sh, phase5-dashboard.sh. No agent change.

**r71: no more "agent offline" during a patch job; Windows agent 1.5.2**
- A server in the middle of a long patch step is no longer shown as
  "agent offline": log lines and step results the agent sends count as
  contact (the agent does not check in while it works on a step).
- Windows agent 1.5.2-win: updates WSUS has already pushed to a server are
  installed first, without a WSUS search; "still working" is reported
  every 2 minutes during a long Windows Update search.
- Only the API changed since r70: phase3b-api.sh is enough.

**r70: Windows patch jobs fixed end to end; snapshots verified (with agent 1.5.0-win)**
- Snapshot before patching: taken on the VM that is the running server
  (powered on, with the agent's address), never on a replica or clone that
  shares its hardware UUID and name; then read back from the VM's own
  snapshot list. If it is not there, the job stops before installing. The
  event names the VM and the snapshot. When nothing needed installing, the
  removal says so.
- Windows jobs: the agent searches WSUS itself at install time (an old or
  failed inventory no longer skips a server); partial installs carry on to
  the restart; "done, with warnings" names failed or rolled-back KBs and
  services that did not come back; the inventory after patching never
  fails a patched server; longer limits for Windows restarts (75 min),
  precheck (130 min), postcheck and inventory (45 min).
- Faster Windows jobs: the job ends after the postcheck instead of waiting
  for the inventory report (a full WSUS search); with agent 1.5.0 the
  install reuses the precheck's search, installs the updates in one
  Windows Update session and checks them after the restart in seconds.
- Hardening from a pre-release audit: the snapshot is taken with nothing
  held open in the database and recorded at once (a restart never takes a
  second one); a snapshot vCenter created but the VM does not list is
  recorded and reported; a failed snapshot removal is a warning; "remove on
  success" keeps the snapshot only for warnings about the patch itself and
  says so; a database error on one server never stalls the other servers.
- Windows agent 1.5.1-win.
- Includes r68 and r69.

**r69: product servers under Apex Central; Deep Security Managers read directly**
- Admin > Antivirus discovers the Apex One servers, Deep Security Managers
  and email security each Apex Central manages; tick which to sync.
- A Deep Security Manager can be read directly with its own read-only API
  key; its certificate is detected as public CA, your CA, self-signed or
  expired, and trusted by CA or by fingerprint.
- Antivirus page: Product servers tab. Inventory: product servers as assets.
  Assistant: product server questions. Schema 034.
- Fix: tables with their own tick boxes no longer get a second set.

**r68: sorting, selection, export and e-mail on every page; security-tone mails; fixes**
- Every table sorts by its headings and has tick boxes. **Export** gains
  "selected rows". **E-mail** can send the table or the selected rows on
  every page (configured recipients only, rate-limited, audited).
- All mail templates rewritten in a security tone, with the team greeting,
  the required action, the sign-off and a classification line.
- Assistant: asset counts by type, hardware (make, model, serial), VM
  templates, decommissioned assets, powered-off VMs with created dates,
  firewalls and network devices.
- Fixed:
  - Assets: filtering no longer drops ticked rows.
  - Assets: ticking no longer rebuilds the table (no lost clicks or focus).
  - Assets: no double submits while an action runs.
  - Assets: the 2,000 cap applies to every way of ticking.
  - Inventory-only users can e-mail their reports (Coverage, Antivirus).
  - Rate limits on AI-01 checks and report mails hold when requests are sent
    together.
  - A sheet over 5,000 rows is refused instead of cut.
  - Mail is sent one by one, so a crash never re-sends delivered mail.
  - Scheduled reports run in their own loop, so security alerts are never
    held up behind an AI-01 summary.
  - The e-mailed coverage report matches the page's filter.
  - Fast navigation can no longer show an older page under a newer address.
  - The Export control no longer piles up click listeners on the Servers
    page.
  - The Antivirus tiles' counts match their lists.
  - The Assets status tiles no longer count powered-off VMs.
- Deploy: `phase3b-api.sh`, `phase5-dashboard.sh` (no schema change).

**r67: Powered off and Templates tabs, VM created date, Hardware only with hardware details**
- New **Powered off** tab. Powered-off and suspended VMs are kept out of
  Master, the type tabs and coverage.
- New **Templates** tab: vCenter VM templates, read into their own table
  (never into the VM list or VMware actions).
- VM created date from vCenter (config.createDate), with a fallback for
  older vCenters.
- Hardware tab lists only machines with hardware details, one row per serial
  number, showing only hardware columns.
- When a powered-on and a powered-off VM share a name, the running one
  describes the machine.
- Deploy: `phase3a-schema.sh` (schema 033), `phase3b-api.sh` (the worker
  reads templates and dates on its next vCenter sync), `phase5-dashboard.sh`.

**r66: master asset list by type, Hardware view, small donuts, export selected, AI-01 sorting**
- Master assets with type tabs: Servers, Laptop/Desktop, ESXi, Appliances,
  Network, Firewalls, Hardware. All are views of one list, so they always
  agree.
- Device types are decided by: a person, vCenter, the OS, the sheet, the
  name, then AI-01 (per machine, checked to be one of the types, with its
  reason).
- Machines with an agent, WSUS, Apex or Windows stay Server or
  Laptop/Desktop unless a person sets otherwise with a reason, and stay
  checked for WSUS and Apex.
- **Set type…** for ticked machines (Approve permission). It is kept in the
  history and Activity.
- Hardware view: make, model, serial, CPU, memory. The sheet upload now reads
  Make and Model columns.
- Small donuts: by type, approved, Windows in WSUS, Windows in Apex.
- Export selected rows as PDF or CSV.
- Appliances, network devices, firewalls and ESXi hosts are excluded from
  WSUS and Apex coverage.
- Deploy: `phase3a-schema.sh` (schema 032), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r65: Apex in the inventory; WSUS and Apex coverage gaps with AI-01; auto-approval**
- Apex Central's agents are an inventory source (Detected: Apex).
- Laptops and desktops take Apex's Windows 10/11 over WSUS's; servers keep
  vCenter/WSUS.
- New **Coverage** page:
  - every machine missing in WSUS or Apex, with the reason from the other
    sources, what to do, and a priority;
  - AI-01's analysis, its numbers checked against the figures;
  - export, e-mail and a schedulable report.
- Machines found in both WSUS and the uploaded sheet are approved
  automatically (recorded as "auto"). Never one a person revoked or
  decommissioned.
- The AI number check is stricter for the threat summary too: names are
  never counted as figures, and numbers in words are refused.
- If the API starts before schema 031, the antivirus sync still works.
- Assistant: inventory coverage questions.
- Deploy: `phase3a-schema.sh` (schema 031), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r64: asset inventory: approve, decommission, revoke; sheet upload read by AI-01**
- Assets page:
  - columns Hostname, Device, Operating system, IP (no brackets), Detected
    (Agent / Virtual / vCenter / WSUS / Manual), Location (the vCenter for a
    VM; Laptop/Desktop or Physical server otherwise), Status, Last detected;
  - 20 a page;
  - icon tiles;
  - tick boxes with "select all matching".
- Approve / Decom / Revoke, each granted per user in Admin > Access (admins
  always). Decom needs a reason. Every decision is in the asset's history and
  in Activity.
- New **Decommissioned** page: who, when, why, who approved; flags machines
  still detected afterwards.
- Admin **Upload sheet** (.xlsx or CSV):
  - AI-01 maps the columns, checked against the cells;
  - rows are checked and tidied;
  - a preview comes before anything is saved;
  - optional replace of earlier sheets, showing what it removes.
- **Check with AI-01** (and every 6 hours): device types for unknown OS
  names, and findings where the sources disagree.
- Odd names from sources ("DOMAIN\\pc", names with spaces, placeholder
  guest names such as localhost) no longer merge machines or break actions.
- Decommissioned machines leave the "No antivirus" list unless something
  still shows them running.
- The assistant leaves decommissioned machines out of asset answers.
- New Python packages: `openpyxl` and `defusedxml`, installed by
  `phase3b-api.sh` through the usual pip proxy.
- Deploy: `phase3a-schema.sh` (schema 030), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r63: antivirus detections, outdated definitions from Apex, daily AI threat summary**
- Each hourly read now also fetches Apex Central's Pattern Update Status
  and detection logs (virus/malware, ransomware, spyware, behaviour
  monitoring, machine learning, C&C, web). Log types are discovered per
  console.
- Antivirus page:
  - new tiles: Outdated definitions, Detections 24 h, Ransomware 24 h;
  - a Definitions column on each agent;
  - a Detections view with the AI-01 summary, filters and export.
- New daily mail "Antivirus threats, daily summary" (08:05). AI-01 writes
  the summary from the figures, and every number is checked against them.
  If the check fails, the plain figures are sent instead.
- AI-01 assistant: outdated definitions, offline agents, machines with no
  antivirus, detections (by type, period, machine, not cleaned) and the
  threat summary.
- Admin > Antivirus: a Logs column shows which logs each console offers.
- A definition update cannot be pushed from PATCH-01: Trend Micro's Apex
  Central API has no such action (see Antivirus logs).
- Deploy: `phase3a-schema.sh` (schema 029), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r62: fix "Could not save" when trusting an antivirus console's certificate**
- Saving a console with a trusted certificate (new or edited) failed with
  a database error: one value in the query had no type the database could
  infer. Fixed.
- Every query from r57 to r61 was re-checked the way the database driver
  sends them (typed, prepared statements). No other query had the problem.
- When the server hits an error, the console now says so with the HTTP code
  and where to read the reason, instead of a bare "Could not save".
- Deploy: `phase3b-api.sh`, `phase5-dashboard.sh` (no schema change).

**r61: trust an antivirus console's self-signed certificate by its fingerprint**
- Admin > Antivirus > Certificate and network > **Get certificate** shows
  the certificate Apex Central presents, with its SHA-256 and SHA-1
  (Windows Thumbprint) fingerprints, the names it covers and its dates.
  Tick to trust that exact certificate.
- Connections then check the fingerprint before sending anything, and stop
  if the certificate changes. Saving re-checks the fingerprint against the
  live console.
- A pasted self-signed certificate is now also accepted as its own CA, when
  its names match the URL.
- Deploy: `phase3a-schema.sh` (schema 028), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r60: reports by e-mail, at once or on a schedule; daily antivirus health mail**
- Export > E-mail… on Antivirus, Servers, Vulnerabilities (Detected CVEs,
  Advisories) and Activity: the report is built on the server and mailed with
  the PDF or CSV attached, to configured recipients only.
- Admin > Scheduled reports: daily, weekly or monthly schedules, send now,
  edit, remove.
- Built-in "Antivirus health, daily" at 08:00: outdated definitions, offline
  agents, agents no longer listed, machines with no antivirus.
- Antivirus: definition versions, last-connected times and online flags are
  read when the console sends them; Admin > Antivirus shows which fields
  each console sends.
- Deploy: `phase3a-schema.sh` (schema 027), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r59: antivirus consoles (Trend Micro Apex Central) and an Antivirus page**
- Admin > Antivirus: add each Apex Central console (URL, Application ID, API
  key, optional CA certificate), test the connection, sync now, edit, remove.
  Keys are encrypted with the new `av.key`; only GET requests are ever made.
- New Antivirus page: agents matched to the inventory, machines with no
  antivirus, isolated agents, filters, + rows, exports.
- Servers: each server's + row shows its antivirus console. Only agents
  from enabled consoles, listed in the last two days, count as protection.
- Security, whole console: a rejected form field is reported by name and
  reason only. The submitted value (a password, a key) is never echoed back.
- Deploy: `phase3a-schema.sh` (schema 026), `phase3b-api.sh` (makes av.key
  and mounts it), `phase5-dashboard.sh`.

**r58: CVE matching checks each machine's platform; address and OS on every match**
- A match counts only when the machine runs a platform the vulnerable product
  runs on, from NVD's platform data, Microsoft's product list and Red Hat's
  per-release state. Microsoft CVEs no longer land on Red Hat servers through
  a shared package name.
- Every machine is looked up in one asset record (agent, WSUS, vCenter guest,
  ESXi, vCenter): address, OS and sources are shown on each match, and the
  machines ruled out are listed with the reason.
- Red Hat: installed builds are compared with Red Hat's fixed build for the
  machine's RHEL release; "not affected" is respected; package names from
  Red Hat's list are now read correctly for builds without an epoch.
- Microsoft: products listed as "not affected" are no longer taken as affected.
- Detected CVEs: new "Applies to" column; exports carry address, OS and the
  machines ruled out. Assessments use the same rules and show the same detail.
- One answer everywhere: Detected CVEs, the Patch Dashboard donut, the AI-01
  analysis, the Servers page (new "Detected CVEs" per server, linking to its
  list) and the assistant ("which servers are affected by CVE-...") all read
  the same platform-checked results.
- Re-checked when installed versions change, not only counts: a package or
  program updated in place, a Windows upgrade or a new VM guest OS starts a
  new analysis within minutes, so a patched server drops off the CVE.
- Every CVE is analysed again with these rules after the upgrade.
- Deploy: `phase3a-schema.sh` (schema 025), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r57: Vulnerabilities in one place, one Export button (PDF or CSV), small module icons**
- **Vulnerabilities** merges Impacted CVEs, Advisories and Assess into three
  tabs (Detected CVEs, Advisories, Assess CVEs), each with + rows, search,
  filters and 20 rows a page. Advisories open to their servers and CVEs, with
  **Patch these servers**.
- An assessed CVE is now checked like a detected one: CVE database, software,
  every machine's operating system (agents, WSUS, vCenter guests, so Windows
  10 Pro or Server 2019 is found without an agent), hardware, then the
  servers' verdicts, then AI-01's brief.
- One **Export** button on every page: PDF report (logo, heading, page
  numbers) or CSV (heading lines). Replaces the separate CSV and "with logo"
  buttons.
- The module buttons on the welcome and home pages are small icons.
- Deploy: `phase3b-api.sh`, `phase5-dashboard.sh` (no schema change).

**r56: one Servers page (servers and agents), branded exports, AI analysis every 15 minutes**
- Servers and Agents merged into **Servers**: green/red lights, + to expand,
  filters, 20 a page, export to CSV and to Excel with the logo.
- Every CSV export starts with the portal, organisation, date and time, user,
  filter and row count.
- AI-01 analyses the servers every 15 minutes (schema 024, worker thread
  "insights"); the latest note heads the Servers page.
- Includes r55 (scripts ask for the admin password when the first-start one
  was changed).
- Deploy: `phase3a-schema.sh` (schema 024), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r55: scripts sign in after the admin password is changed**
- `phase3b-api.sh --check` no longer reports "admin auth HTTP 401" once the
  admin password has been changed in the console (expected and correct).
- `phase3b-api.sh --token`, `phase10-windows.sh --tokens` and `phase6-llm.sh`
  try the first-start password, and when it no longer works ask for an admin's
  user name and password at the terminal (not shown, not stored, and passed to
  curl through a pipe so it never appears in the process list).
- No API, dashboard or schema change.

**r54: modules and access, Impacted CVEs with AI briefs, new welcome page**
- **Welcome page**: logo, "Cyber-Secure Dashboard portal", **AI powered
  dashboard**, three glowing module buttons (Patch Dashboard, Asset &
  Inventory, Software Lifecycle), and a scrolling board of **critical, high and
  0-day** CVEs only (pauses on hover or focus; still for reduced motion).
- **Home after sign-in**: the same page, with the user's modules lit and the
  others greyed out.
- **Admin > Access**: grant each user modules; enforced by the API (schema 023).
- **Patch Dashboard**: CVE news removed; donuts kept; new **Impacted CVEs**
  donut with the CVEs needing attention and AI-01's briefs; new Impacted CVEs
  page with where each was found.
- Worker thread "impact"; AI-01 prompts now fence product and inventory text
  as untrusted data.
- The menu has its own row under the brand, so every entry is visible.
- Deploy: `phase3a-schema.sh` (schema 023), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r53: Cyber-Secure dashboard, CVE feeds from NIST, Microsoft and Red Hat, new sign-in page**
- The console is now **Cyber-Secure**, with your logo in the top bar (the same
  logo as the mails). The hacker theme's prompt no longer shows a user and host
  name.
- The Overview is the **Cyber-Secure dashboard**: six live donuts (servers,
  updates, severity, operating systems, agents, new CVEs), headline figures,
  and **CVE news**. Refreshes every minute.
- **CVE feeds** (schema 022, worker thread "feeds"): NIST NVD, Microsoft and Red
  Hat, filtered to the software you choose in **Admin > CVE feeds**, with
  suggestions from your servers' own software.
- **Sign-in page**: logo, "Welcome to the Cyber-Secure Dashboard portal", and a
  news board of the latest CVEs from the three sources (general feeds only).
- Feed responses are size-limited; public answers are cached and built once at
  a time.
- Deploy: `phase3a-schema.sh` (schema 022), `phase3b-api.sh`, `phase5-dashboard.sh`.

**r52: assistant pops out on top of everything; finds any OS version or edition**
- **⧉ Pop out**: the assistant floats in its own always-on-top window over all
  other applications (Chrome/Edge 116+); **Back to page** returns it.
- Questions about an operating system now search every machine from agents,
  vCenter and WSUS by OS name: "Windows 10 Pro list", "win10", "Windows 11",
  "Windows Server 2019", "RHEL 9", with a count per edition. Machines whose
  edition no source reports (vCenter says only "Windows 10") are counted
  separately, not silently dropped.
- An assistant e-mail with no rows says it went without a CSV; the draft no
  longer ends with "Regards" (your signature closes it).
- Rebuild the API and dashboard: `phase3b-api.sh`, then `phase5-dashboard.sh`.

**r51: the assistant: floating, speaks, exports, e-mails, answers far more**
- The chat is now a **floating window**: drag, resize, enlarge, back to the
  corner; remembered per browser.
- It answers far more (29 prepared, read-only queries, up from 9): fleet
  overview; server list; one server's detail, **patches pending**, **patches
  installed** and installed software; where a program is installed; agents
  by state and version; servers waiting for a reboot; servers needing patches
  (Windows included); CVEs (one, exploited, most serious); recent advisories;
  Windows servers missing updates; servers missing a KB; WSUS computers
  needing attention; recent changes and one change in detail (warnings
  included); hardening scores; VMs by name or power state; old snapshots; VMs
  without an agent; ESXi hosts; datastores low on space; the asset inventory.
- Follow-ups refer back: "export that", "email it to the ops team".
- **Export CSV** and **E-mail** (draft, sent only when you press Send, to
  allowed recipients only, rate-limited, audited). See "The assistant".
- **Reads answers aloud** with offline voices only.
- Rebuild the API and dashboard: `phase3b-api.sh`, then `phase5-dashboard.sh`.
  No schema change.

**r50: service warnings, Inventory pages**
- **A service that does not come back after patching no longer fails the
  patch.** When the postcheck's only problem is services that were running
  before and are not now, the updates count as installed, the server ends as
  **Done, with warnings**, the services are named, and the snapshot is kept
  (even with "remove if it succeeds"). Any other postcheck problem still fails.
- A failure reported by the Linux agent kept its message: it was dropped, so
  failures read "the agent reported a failure".
- **Inventory** menu, two pages:
  - **Assets**: every machine from agents, vCenter (VMs, ESXi hosts, the
    vCenters) and WSUS, merged by name, each typed as server, client or
    appliance from its OS (hover the type for the reason), with where it runs,
    power, agent state, last seen; filters, search, and "without an agent".
  - **Software**: Windows programs and Linux packages by program and version,
    for servers or clients, with the machines that have each. Software comes
    only from agents (vCenter and WSUS do not report installed software).
  - Both export CSV; cells that a spreadsheet would run as formulas are
    neutralised. Windows > Software moved here.
- The top menu now tightens on narrower screens as intended (its narrow-screen
  rules were being overridden).

**r49: Windows agent 1.4.0-win: everything checked, and downloaded, before installing**
- PATCH-01 now chooses a Windows job's updates at the **precheck** and sends
  them with it. The precheck logs every check as it runs (disk; the Windows
  Update, BITS, Cryptographic and Modules Installer services; a pending
  reboot; WSUS reachable), looks the updates up by ID, tests **the exact
  address each update file downloads from**, and names it if it cannot be
  reached (with the usual cause: WSUS approving updates without storing their
  files). Then it **downloads the updates during the precheck**, with
  progress every 30 seconds, and stops with a clear reason if nothing arrives
  for 10 minutes. Nothing is installed in the precheck, so stopping is safe.
- The install step reports whether Windows is busy or idle, and stops a
  download that has not moved for 15 minutes.
- The Windows precheck may take up to 110 minutes (it includes the download).

**r48: Windows agent 1.3.2-win: visible, quicker installs**
- Updates install one at a time (servicing stack first), and every step is
  logged: looking up, downloading N of M, installing N of M, installed in
  X min, or FAILED with its result code. While Windows works, the agent copies
  this into its log and sends it to PATCH-01 every 30 seconds, with a "still
  working (N min so far)" line when Windows is quiet, so ">_ Log" shows where
  a long cumulative update is.
- The install looks up only the job's own updates by ID (seconds) instead of
  repeating a full Windows Update search (minutes); a full search is the
  fallback if the lookup by ID is refused.

**r47: Windows agent 1.3.1-win: commands were skipped**
- On PowerShell 5.1, Invoke-RestMethod returns a JSON list as one object.
  The agent wrapped it in another list, found no command id on it, and
  skipped every command without a word: PATCH-01 saw the step taken and
  never answered. The list is now unrolled whichever way it comes back; the
  agent logs how many commands it received; a command it cannot read is
  logged as an error and answered as failed instead of skipped.

**r46: fail-fast fix**
- The fail-fast check used the last check-in time, which an inventory report
  also moves: a Windows inventory step (its Windows Update search can take
  minutes) could have been failed while still running. It now uses the time
  the agent last started a run (`hosts.last_run_at`, set only by check-ins).
  Run phase3a (schema 21 gains the column) and phase3b.

**r45: visible, fast failures (agents 1.7.0 and 1.3.0-win)**
- **Live log** (`>_ Log` in the top bar): a small floating terminal with
  agent log lines and change steps as they happen; it follows the page (a
  change, a server, or everything), can be moved and resized, and stays open.
  Lines are shown as plain text only.
- **Agents send their log lines to PATCH-01** after every command and at the
  end of every run, including a run that crashed. PATCH-01 keeps the newest
  3000 lines per server for 14 days and masks anything that looks like a
  secret as it arrives.
- **Fail fast:** when an agent took a step and its run ended without
  answering, the step fails within minutes, quoting the agent's last log
  lines, instead of after the 30-minute limit. A timeout quotes them too.
- **Windows jobs no longer wait 5 minutes between steps:** the agent asks for
  the next step straight after finishing one, as the Linux agent does.
- Results are retried three times; a failed send is logged.
- The "worker is not running" banner was wrong for 58 minutes of every hour
  (the hardening thread reports hourly): each thread is now judged on its own
  pace, and the banner shows only when the change runner has stopped.
- Schema `021-agent-logs.sql`. Run phase3a, phase3b, phase5; update agents.

**r44: Windows software from a share (S2)**
- **Windows > Installers**: a catalog of approved installers (MSI, or EXE with
  reviewed silent options) on a share: path, SHA-256, the publisher whose
  Authenticode signature it must carry, the MSI product code or EXE uninstall
  options, and its name in Programs and Features. A different admin must
  approve each entry (enforced by the API and the database).
- **Software jobs** (Changes > New software job): install, upgrade or remove
  on Windows servers, through precheck, snapshot, install, reboot, postcheck
  and inventory. They always need a second person's approval.
- **The share credential is entered at run time** on the job's page: the job
  waits until then. It is kept encrypted in memory-backed storage on PATCH-01
  (`/run/patch01-vault`, emptied at boot), never in the database, logs or on
  disk; each server fetches it once; it is gone when the job ends (6 hours at
  most). Only the API holds its key.
- **Windows agent 1.2.0-win**: re-checks everything it is sent, copies the
  installer with the job's credential, verifies its SHA-256 and signature
  before anything runs, installs with fixed templates (never through a
  shell), confirms the result, and always deletes its copy.
- Windows patch jobs with "chosen advisories" now accept KB numbers.
- Schema `020-software.sql`. Run phase3a, phase3b (makes `run.key` and the
  memory-backed folder) and phase5; update Windows agents to 1.2.0-win.

**r43: no site host names**
- Examples and documents use the placeholder `patch01.example`; the setup
  scripts have no built-in address and ask for it (an upgrade offers the
  address the existing agent uses). Nothing site-specific is shipped.

**r42: one guided script per OS for installing or upgrading the agent**
- `client/setup-agent.sh` (Linux) and `client/windows/Setup-Agent.ps1`
  (Windows): find any existing agent, upgrade it in place keeping its
  identity, or install and enrol a new one; check DNS and the port; work out
  how to trust PATCH-01's certificate (the existing setting, the system's own
  trust, or your CA chain file, verified the way the agent verifies) before
  changing anything; then prove it with a check-in. Windows also sets the
  execution policy to RemoteSigned for the current user and unblocks the
  scripts. Both run unattended with --yes / -Yes.
- install-agent.sh no longer stops with "are the same file" when re-run with
  the CA it already has.

**r41: Linux precheck fix (agent 1.6.1)**
- Patch jobs on RHEL and Oracle Linux stopped at the precheck with
  "previous package transaction did not complete cleanly" on healthy
  servers: the check searched `dnf history` for "E", which is also the
  letter for Erase and appears after every kernel update. It now runs the
  package manager's own consistency check (`dnf check` / `yum check`) and
  stops only on real problems, naming the package; a failed last transaction
  is shown as a warning, since with dnf it does not block the next one.
  Update the agent with install-agent.sh (no token: the enrolment is kept).

**r40: vCenter write account fix**
- `phase7-vmware.sh --add-writer NAME` did nothing: an earlier edit had put
  the add-writer and remove-writer code inside the option-reading loop
  instead of the mode section, and swallowed `--install-timer`. All three
  work again. A failed or interrupted --add-writer now never leaves
  credentials on disk (the API is prepared first, and the file is removed
  on any exit before the login is proven). `--list` shows whether each
  vCenter has a write account.

**r39: rolling the agent out to many Linux servers**
- `client/push-linux.sh`: over SSH (keys, root or passwordless sudo), checks
  every server first (SSH, sudo, Python, and that the server can reach
  PATCH-01 and verify its certificate with your CA), then installs on those
  that passed: servers already enrolled switch to verified TLS and keep their
  identity; new ones get a token. Tokens go only to servers that passed and
  are not enrolled. `--test-only` checks without changing anything and says
  how many tokens are needed. Results in a CSV.

**r38: certificate install fix**
- Installing a certificate from the console rolled back with "cannot load
  certificate key ... Permission denied": the helper wrote the key as
  root-only (0600), but nginx runs as uid 1001 in group 0 and reads it
  through its group, as phase1a-ingress.sh sets it (root:0, 0640). The
  helper now overwrites the files in place, keeping their owner, group, mode
  and SELinux label. The rollback itself worked as designed.

**r37: PATCH-01's certificate from the console**
- **Admin › Certificate** shows the certificate nginx serves now (names,
  issuer, expiry, pin), takes an upload (certificate and key files, a DER
  .cer, or a .pfx with its password), and checks it before anything changes:
  the key matches, it is in date, it names the short name and FQDN, it is for
  TLS servers, the key is strong enough, and the chain is complete (put in
  order automatically). It gives the new pin and the exact Windows re-pin
  commands, and only installs once you confirm those were run.
- The console never installs anything itself. A root helper on PATCH-01
  (`patch01-cert-apply`, started by `patch01-cert.path`) checks the files
  again, installs them, restarts nginx, proves nginx serves exactly that
  certificate, and puts the previous one back if not. The private key is
  deleted from the hand-over folder once installed; it is never stored in
  the database. The five previous certificates are kept; **Roll back** goes
  to the one before the last change.
- `phase3b-api.sh` installs the helper. Log: `/var/log/patch01-cert.log`.
  `patch01-reip --cert` remains as the command-line way.

**r36: worker health check**
- The worker was always shown "unhealthy": it uses the API's image, whose
  built-in health check asks the API's web server, which the worker does not
  run. It now has its own check (`python -m app.health worker`): healthy when
  its main loop has reported within 3 minutes. Nothing was wrong with the
  worker itself; tools that rely on health (patch01ctl) now see it correctly.

**r35: certificate and IP change-over**
- Windows agents and the WSUS report accept **two pins** during a certificate
  change, so they keep working before and after the swap.
- `install-agent.ps1 -Repin -Pin <old>,<new>` and `push-agent.ps1 ... -Repin`
  change the pin without re-enrolling; they also bring the agent up to date
  (older agents accept only one pin), and test the new setting before keeping it. `wsus-report.ps1 -Repin` does the same for WSUS servers.
- `phase10-windows.sh --pin --cert FILE` gives a new certificate's pin before
  it is installed, with the exact re-pin commands.
- `docs/CHANGE-IP-AND-CERTIFICATE.md`: the steps, in order.

**r34: several WSUS servers**
- With more than one WSUS reporting, Windows › WSUS shows each with its own
  cards and adds a **WSUS** column to the computer list. A computer listed by
  two WSUS servers (usually reporting roll-up from a downstream WSUS) is
  marked rather than hidden. Each WSUS needs its own token:
  `phase10-windows.sh --wsus-token NAME`, once per server.

**r33: Windows patching (W3), WSUS view (W2), software inventory**
- **Patch jobs for Windows servers**, through the same change engine:
  precheck (disk, Windows Update service, running services), VM snapshot,
  install, reboot per the job's choice, postcheck (services back, no reboot
  pending), inventory. Only updates WSUS has approved can be installed: the
  agent installs from the server's own WSUS search. *All approved updates*
  installs everything WSUS approved that the server lacks; *chosen
  advisories* installs the approved updates with those KBs or that fix their
  CVEs (Windows updates are cumulative, so this month's update covers last
  month's). Installs may take up to 3 hours.
- **Software inventory:** every Windows server reports Programs and Features
  (name, version, publisher, install date, size). Each server's page lists
  it; **Windows › Software** shows every program across servers, the
  versions in use and which servers have each.
- **Windows › WSUS:** sync health, security updates not approved, and every
  computer WSUS knows with when it last reported and how many approved
  updates it still needs. Computers not reporting for 7 days, computers not
  in PATCH-01, and PATCH-01 servers unknown to WSUS are called out.
  `client/windows/wsus-report.ps1` runs on the WSUS server (read-only), every
  6 hours; `phase10-windows.sh --wsus-token NAME` makes its token (one per
  WSUS server; the same pin as the agents).
- Windows agent **1.1.0-win**; its scheduled task may now run 4 hours.
  Schema `019-windows-software-wsus.sql`.

**r32: Windows inventory accepted**
- Windows inventories were refused with "only 23 packages reported ...
  (minimum 50)": that safety check is for Linux, where fewer than 50
  packages means a broken collector. A Windows server reports its OS build
  and installed KBs, often fewer. For Windows servers (by their recorded OS)
  the check is now one well-formed OS build entry; Linux keeps its minimum.
  Because the inventory failed first, the Windows Update results were never
  sent either; both now arrive.

**r31: Windows agent fix**
- After enrolling, the Windows agent stopped with "The variable
  '$script:Cfg' cannot be retrieved because it has not been set": under
  strict mode it read its settings variable before anything had set it, so
  inventory and the scheduled runs failed. It is now declared up front.
  Update an installed agent with `install-agent.ps1 -Update`.

**r30: Windows enrolment fix**
- Windows enrolment failed with HTTP 422: the enrolment check still allowed
  only dnf, yum and apt. It now accepts wua (Windows Update).
- The Windows agent now shows PATCH-01's reason for any refusal (PowerShell
  5.1 keeps it in ErrorDetails, not in the response stream).
- Patch jobs refuse Windows servers with a clear reason until Windows
  patching (W3) exists, instead of failing on the server.

**r29: Windows token fix**
- `phase10-windows.sh --tokens` failed with "unknown host_group 'windows'":
  tokens must name an existing group, and `windows` was not one. It is now
  created the first time it is used (and by schema 018 on new installs); any
  other group that does not exist is refused with the list of those that do.

**r28: Windows servers (W1)**
- **Windows agent** (PowerShell 5.1, built in to Windows Server): enrols like
  the Linux agent, checks in every 5 minutes as SYSTEM, and every 4 hours
  reports the OS build, installed KBs, reboot state, the hardware ID that
  links it to its VM, and the updates Windows Update says are missing,
  searched against the server's WSUS. Read-only. The PATCH-01 certificate is
  pinned; the agent's token is encrypted for that machine only.
- **CVEs by build:** Microsoft's Security Update Guide is imported
  (`phase10-windows.sh --msrc`). Each cumulative update is an advisory for its
  Windows Server version, so Windows servers get verdicts, KEV and EPSS, and
  appear on the Overview, Advisories, Assess and in reports like Linux ones.
- **Windows Update** section on each Windows server's page.
- `client/windows/`: `install-agent.ps1` (with `-SelfTest`), `patch-agent.ps1`,
  and `push-agent.ps1` to install on a list of servers over WinRM.
- `phase10-windows.sh`: `--msrc`, `--pin`, `--tokens N`, `--status`.
  Proxy: allow `api.msrc.microsoft.com`. Schema `018-windows.sql`.

**r27: script reliability**
- `phase5-dashboard.sh` reported "Timed out" after r26 although the console
  was deployed: its final check looked for `src="app.js"`, which the new
  version stamp changes to `src="app.js?v=..."`. Both checks now accept it.
- Every script checked running containers with `docker ps | grep -q`. Under
  the scripts' strict error settings that can wrongly report a running
  container as stopped (grep stops reading early, and docker's unfinished
  write then fails the check). In testing it happened in 45 of 200 runs.
  25 such checks in nine scripts now read the whole output first.
- `phase5-dashboard.sh` was run end to end ten times against stand-ins: all
  succeeded.

**r26: fresh console after every update**
- `phase5-dashboard.sh` stamps each console file with its fingerprint, so
  browsers load the new version straight after an update, with no need for
  Ctrl+F5. (A browser still running an old copy explains, for example, the
  custom-profile option looking greyed out after moving to r25.)

**r25: custom profiles (H3), check boxes, cleaner report e-mail**
- **Custom profiles:** Hardening › profile list › *New or manage custom
  profiles*. Upload a .txt, .csv or .docx (your standard, an auditor's
  checklist). Each line is matched to benchmark checks, by CIS number first,
  then by wording; AI-01 can suggest a match for a line, choosing only from
  real rules. Review the matches, mark headings as "not a check", and choose
  **Use this profile**. It then appears in the profile list beside CIS L1 and
  L2; scans check only its settings, and reports list its results plus the
  requirements no scan can check as **Not checked automatically**. Editing a
  profile in use makes a new version.
- **Results by check** use drawn tick and cross boxes, with passed checks
  first and failed checks after, in both PDF and Word.
- **Report e-mail:** a white header with the logo, four figures (servers,
  checks passed, checks failed, score), three short sentences and the
  signature. Ready at once; **Polish with AI-01** rewrites it on request.
- Agent **1.6.0** is needed for custom-profile scans. Schema
  `017-custom-profiles.sql`.

**r24: management reports, report e-mails, signature**
- **Report type:** *Management summary* (no fixes: a pass/fail result for
  every check, as a grid for up to 6 servers, and each server's failed checks
  as evidence) or *Technical detail* (findings with how to fix them).
- The cover lists the servers in scope with their IP addresses; the server
  table has an IP column.
- **E-mail a report** from the console (operators and admins): a window with
  the report at a glance, a draft written by AI-01 from the report's own
  figures, To/Cc with quick picks, and the report attached. A draft that
  states any figure not in the report is discarded for a structured one; if
  AI-01 is unavailable the structured draft is used. Sent mail is recorded in
  Activity and in the mail history.
- **Signature:** one signature, set under Admin › Mail, added to every mail:
  alerts, digests and reports.
- Schema `016-signature.sql`.

**r23: schema re-run fix**
- Re-running `phase3a-schema.sh` stopped at 011 with "cannot change name of
  view column": the `v_hardening_latest` view was built on `s.*`, which
  PostgreSQL fixes at creation, and schema 012 added columns to the table
  underneath. The view now lists its columns and is recreated each run.
  012 to 015 had not been applied; nothing was lost. Builds now also refuse
  any view defined with `*`.

**r22: branded reports (H4)**
- **Export report** on the Hardening page: PDF or Word, for all servers, a
  host group, or the servers below 85%, with the findings in detail you
  choose. Both formats have a cover, contents, executive summary, results by
  server, findings with how to fix them, evidence, and method; every page
  carries the logo, title and classification in the header, and the
  copyright line and "Page X of Y" in the footer.
- Every report is kept in an archive with its SHA-256, and generating or
  downloading one is recorded in Activity. Viewers can export reports too.
- **Logo:** drop a PNG in `/patch/data/branding` on PATCH-01. PATCH-01 picks
  `logo.png`, or the largest PNG there; trims the margins; scales it for
  print; checks whether it is light or dark (a dark logo sits on a white
  plate on the navy cover); and takes the accent colour from it.
  `logo-white.png`, if present, is used on dark backgrounds.
- **Admin › Branding:** company name, copyright line, classification, and an
  optional accent colour, with a preview of the processed logo.
- Users, Mail and Branding are now tabs under one **Admin** menu item.
- Mail uses the same company name and, where it suits the navy header, logo.
- The image now includes reportlab, python-docx and Pillow (installed through
  the proxy at build time) and bundles its fonts. Schema `015-branding-reports.sql`.

**r21: mail set up in the console**
- The admin **Mail** page now holds everything: relay, port, encryption,
  mailbox login and password, the relay's CA certificate (pasted in), From
  address and name, what to send, and when.
- **Test connection** walks through name lookup, connection, TLS (showing
  the certificate), login and sender acceptance, using the values in the
  form before they are saved. It sends nothing.
- **Recipients** per kind of mail (critical, tasks, daily digest, weekly),
  each with its own test button. Every change is in Activity.
- The password is write-only in the console and stored encrypted, with a key
  kept only in `/patch/secrets/mail.key` (made by `phase3b-api.sh`). Keep that
  file in backups with the other secrets.
- `phase9-mail.sh` now only checks from the command line (`--status`,
  `--check`, `--test`, `--on`/`--off`). Schema `014-mail-settings.sql`.

**r20: mail alerts**
- Critical alerts within a minute: an exploited CVE newly affecting a server,
  an ESXi host not connected, a vCenter unreachable, a datastore 90% full, a
  change that failed or partly succeeded, hardening drift on a high-severity
  rule, and the worker stopping (checked from the host every 5 minutes).
- Task mails when changes start and finish and when requested scans complete.
- Daily digest at 07:00 SGT and a weekly summary on Mondays.
- Mail is queued and retried (1, 5, 15, 60, 240 minutes), so a relay outage
  delays it rather than losing it. Each alert is sent once; a condition that
  clears and returns alerts again. Several at once arrive as one mail.
- Turning mail on records what is already known without mailing it.
- `phase9-mail.sh`; admin page **Mail**; schema `013-notifications.sql`.

**r19: live scan progress (H1)**
- The Hardening page shows where each scan is, refreshing every 5 seconds:
  waiting for the agent's check-in, downloading the benchmark, scanning with
  rules done out of total, uploading, processing. A scan not picked up after
  two check-ins is flagged with the command to check the agent's timer.
- Agent **1.5.0** reports progress, and stops a hung scan together with any
  helper processes it started. Agents on 1.4.0 still scan; they just show
  "scanning" without figures.
- Schema `012-scan-progress.sql`.

**r18: hardening import, second fix**
- The import stopped with "No module named 'lxml'": the benchmark parser used
  a library that is not in the API image. It now uses Python's built-in XML
  parser, so nothing extra is installed. Tested in a Python without that
  library, and against hostile XML (entity expansion, local file entities),
  which is refused. Needs `phase3b-api.sh` to rebuild the image.

**r17: hardening import fix**
- `phase8-hardening.sh` stopped with "$2: unbound variable" just before
  importing, on both `--fetch` and `--import-zip`, so no content ever reached
  the database. The import step now runs; the script was also run end to
  end, not only syntax-checked.

**r16: two script fixes**
- `phase3b-api.sh --check` reported "worker running but not reporting" on a
  healthy worker. It judged the oldest heartbeat of all the worker's threads
  against two minutes, and the hardening schedule reports hourly by design.
  Each thread is now judged against its own interval.
- `phase8-hardening.sh --import-zip` stopped with "are the same file" when
  given the copy already kept in `/patch/data/hardening/releases`. The copy
  is now skipped in that case.

**r15: hardening, increment 1 (scan and see)**
- **Hardening** page: fleet score and trend, the most widely failing rules,
  per-server scores, and per-rule and per-server detail with what each check
  does and why it matters. Profile dropdown: CIS Level 1 Server, CIS Level 2
  Server (Custom arrives in increment 3).
- `phase8-hardening.sh`: downloads one pinned SCAP Security Guide release
  through the proxy, verifies its SHA-512, and imports the data streams for
  RHEL 8/9/10, Oracle Linux 7/8/9 and Ubuntu 20.04/22.04/24.04.
- Agent 1.4.0 scans with OpenSCAP (read-only, low priority) and uploads the
  full result, kept on PATCH-01 as audit evidence with its SHA-256.
- Weekly CIS Level 1 scan per server by the worker (`HARDENING_SCAN_DAYS`,
  0 turns it off), spread across the day.
- Schema `011-hardening.sql`.

**r14: live VMware map and blast radius**
- **Live map** is now the first VMware tab: networks, clusters, ESXi hosts,
  VMs and datastores on one canvas, graded neon red, amber, green or grey,
  with the legend below. Infrastructure and Applications layouts.
- **Blast radius**: click a host, datastore or port group to see what it
  takes down. For a host, whether HA can restart each VM: HA on, disks not
  on local storage, enough spare memory on the surviving hosts.
- **Live**: the worker follows each vCenter's change stream and events
  (vMotions, HA restarts, host failures, alarms); the map updates within 5
  seconds and the side panel shows a live feed.
- Application groups from vSphere tags (categories named Application, App,
  Service, Workload or System; override with `VMWARE_APP_CATEGORIES`), else
  from the VM folder.
- **Coverage** tab: Distributed vs standard switching, tagged vs ungrouped.
- Schema `010-vmware-live.sql`. Read-only vCenter account throughout;
  nothing is collected from inside a VM.

**r13: schema re-run fix**
- Re-running `phase3a-schema.sh` stopped at 007 with "cannot drop columns
  from view", so 009 (users and changes) was never applied. 007 still defined
  `v_vm_map` with its original, narrower column list, and on a re-run tried to
  replace the wider view 008 had created. The view is now defined in 008 only.
- Nothing was lost: each migration is its own transaction, and 007 rolled
  back cleanly. Re-run `phase3a-schema.sh`.

**r12: users and roles, changes, patch jobs, VMware actions, CVE assessment**
- Individual sign-in with viewer, operator and admin roles, enforced by the
  API; forced password change on first sign-in; lockout after five failures.
  BOT-MODE (formerly Hacker) is admin only.
- Change engine: every patch job and VMware action has a number, reason,
  window and a tamper-proof timeline. Approval optional
  (`REQUIRE_APPROVAL`), off by default.
- Background worker container: runs changes on schedule, recomputes verdicts
  after patching, and enriches assessments.
- Patch jobs with preview, per-job reboot choice, optional VM snapshot and a
  service check. Agent 1.3.0.
- VMware snapshots, revert (with typed confirmation and a safety snapshot),
  power on, guest shutdown and restart, using a separate write account.
- Assess looks up every CVE in NVD, classifies what it affects, checks ESXi,
  vCenter and VM guests as well as packages, adds an AI brief, and exports it
  all to CSV.
- Schema `009-users-changes.sql`.

**Advisory to CVE mapping fix**
- CVEs are linked to advisories through each advisory's reference list. Only
  one of the two field namings Pulp uses was handled, so on some versions no
  CVEs were recorded at all and every advisory appeared to have none.
- Both namings are now accepted, with fallbacks for a CVE that appears only
  in a reference link, is filed under another reference type, or is named in
  the advisory text. The import warns if an advisory set yields no CVEs.
- `./scripts/phase4-cve.sh --diagnose` prints the counts and one advisory
  exactly as your Pulp returns it, so the field names can be confirmed.
- To apply: `./scripts/phase4-cve.sh --import` then `--intel`.

**Fix: VMware page returned HTTP 500**
- The map endpoint asked `v_vm_map` for `esxi_moref`, which groups VMs under
  their ESXi host, but the view did not expose it. Schema
  `008-fix-vm-map.sql` recreates the view with that column and the remaining
  per-VM detail.
- Apply with `./scripts/phase3a-schema.sh`; no re-sync needed, since the data
  was already collected.

**VMware infrastructure map**
- Map tab: vCenter, datacenter, cluster, ESXi host and VM as an expandable
  tree, each VM coloured by patch and agent state.
- ESXi hosts, datastores, networks and clusters, with hardware, versions,
  state and load. Over-provisioned datastores and unresponsive hosts flagged.
- Per VM: ESXi host, folder, datastores, networks, disks, hardware version,
  Tools version, boot time and storage.
- Schema `007-vmware-infra.sql`. Needs a re-sync to populate:
  `./scripts/phase7-vmware.sh --sync`.

**Fixes**
- Agents page returned HTTP 500: its query selected `host_id` and
  `host_status` from the `hosts` table, where those columns are `id` and
  `status`. It now reads the `v_agents` view.
- Chat returned HTTP 500 on filtered questions such as "which rhel servers
  need patches": an untyped NULL filter makes PostgreSQL refuse the query
  ("could not determine data type of parameter"). Every placeholder now
  carries an explicit type.
- `phase4-cve.sh --diagnose` also reports verdict counts and table sizes, so
  an empty dashboard can be traced to a missing sync, import or compute.

**Assess a CVE list, and admin chat**
- New Assess page: paste or upload a CVE list from a SOC or auditor and get a
  per-CVE verdict across the fleet, saved and exportable as CSV.
- New chat, read-only, behind the icon at the bottom right. The model picks
  which prepared query to run; the database supplies every figure and the rows
  are always shown.
- Schema `006-assessments.sql`; `python-multipart` added to the API image.

**CVE intelligence**
- NVD, CISA KEV, FIRST EPSS and Red Hat data per CVE, with the attack type
  derived from the weakness and the CVSS vector.
- The console shows CVSS, an "Exploited" marker, how the flaw is reached, the
  exploitation probability and the CVE description, with sources.
- AI explanations now use these facts instead of an advisory title, which was
  why every CVE produced a similar answer.
- `phase4-cve.sh --intel`, `--set-nvd-key`, `--estimate`; schema
  `005-cve-intel.sql`; nightly timer now refreshes CVE data too.

**VMware, part 1: inventory**
- New VMware page: each vCenter's status, Linux VMs without an agent, VM
  snapshots and their age, and ambiguous links.
- Each server page shows its VM, cluster, ESXi host, size and snapshots.
- Agent 1.2.0 reports the hardware ID used to link servers to VMs.
- `phase7-vmware.sh`, schema `004-vmware.sql`, and pyVmomi 8.0.3.0.1 in the
  API image. Several vCenters are supported and one failing does not stop
  the others.

**Step 7: agent status**
- New Agents page: online, offline, not reporting, uptime, boot time, agent
  version and address for every server.
- Agent 1.1.0 reports boot time. Compatible both ways with older versions.
- "Hosts" is now "Servers". The Servers list has an Agent column, and each
  server page shows uptime.
- Schema `003-agent-status.sql`.

To apply on an existing PATCH-01:

```bash
./scripts/phase3a-schema.sh      # adds schema 003
./scripts/phase3b-api.sh         # API with boot time and the agents endpoint
./scripts/phase5-dashboard.sh    # Agents page
```

then update agents as above.
