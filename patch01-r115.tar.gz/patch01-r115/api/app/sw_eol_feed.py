"""End of support / end of life dates filled in from endoflife.date (r114).

Why the dates did not fill in before: PATCH-01 had only the rules an admin typed in
(Admin › Software rules). This module fills the same table from endoflife.date, a public,
maintained list of vendor support dates, once a day through the proxy (as the CVE feeds).

Only products whose names in Windows "Programs and Features" are known and unambiguous are
taken (PRODUCTS below), and only release lines with a dated end. A rule an admin typed for the
same product and version line is never overwritten, and wins over a feed rule that matches as
closely. Linux packages are left alone: a distribution supports its own packages for the life of
the distribution, whatever the upstream project's dates say.

What the dates mean (the vendor's own terms, as endoflife.date lists them):
  End of support  "support"  end of mainstream / active support
  End of life     "eol"      end of security fixes
  a paid extension ("extendedSupport", e.g. Microsoft ESU, Oracle Extended Support) is written in
  the rule's note, not used as the end of life.
"""
import json
import logging
import re
from datetime import date

log = logging.getLogger("patchapi.sw_eol_feed")

SOURCE = "endoflife"
BASE_URL = "https://endoflife.date/api/"
DAY_HOURS = 24

# endoflife.date product -> the program names it covers in Windows (as the name starts, whole words).
# The version line is the release cycle: matched in the reported version (8.0 covers 8.0.31) or
# written as a word of its own in the name ("Microsoft Office Professional Plus 2016").
PRODUCTS = {
    "mssqlserver": ["Microsoft SQL Server"],
    "dotnetfx": ["Microsoft .NET Framework"],
    "dotnet": ["Microsoft .NET Runtime", "Microsoft .NET Core Runtime", "Microsoft ASP.NET Core", "Microsoft Windows Desktop Runtime",
               "Microsoft .NET SDK", "Microsoft .NET Core SDK", "Microsoft .NET Host"],
    "office": ["Microsoft Office"],
    "msexchange": ["Microsoft Exchange Server"],
    "visual-studio": ["Visual Studio"],
    "oracle-jdk": ["Java"],
    "eclipse-temurin": ["Eclipse Temurin"],
    "amazon-corretto": ["Amazon Corretto"],
    "python": ["Python"],
    "nodejs": ["Node.js"],
    "powershell": ["PowerShell"],
    "postgresql": ["PostgreSQL"],
    "mysql": ["MySQL Server"],
    "mariadb": ["MariaDB"],
    "mongodb": ["MongoDB"],
    "tomcat": ["Apache Tomcat"],
    "firefox": ["Mozilla Firefox"],
    "veeam-backup-and-replication": ["Veeam Backup & Replication"],
    "zabbix": ["Zabbix Agent"],
}
CYCLE_RE = re.compile(r"^[0-9]+(\.[0-9]+){0,2}$")


def _day(v):
    if isinstance(v, str) and re.fullmatch(r"\d{4}-\d\d-\d\d", v):
        try:
            return date.fromisoformat(v)
        except ValueError:
            return None
    return None


def _base(cycle):
    """The release line a cycle belongs to: '13.0-sp3' -> '13.0', '2024-ltsc' -> '2024',
    '10.00' -> '10.0'; None for anything else ('subscription', '2011-for-mac' kept as 2011)."""
    c = str(cycle or "").strip().lower().split("-")[0]
    if not CYCLE_RE.match(c):
        return None
    parts = c.split(".")
    if len(parts) > 1 and parts[1] == "00":
        parts[1] = "0"
    return ".".join(parts)


def lines(cycles):
    """endoflife.date cycles -> {version line: (eos, eol, paid_until)}. A line listed several
    times (SQL Server 2016 RTM, SP1, SP2, SP3) takes its newest entry: the one supported longest."""
    out = {}
    for c in cycles or []:
        if not isinstance(c, dict):
            continue
        b = _base(c.get("cycle"))
        if not b:
            continue
        eol, eos, paid = _day(c.get("eol")), _day(c.get("support")), _day(c.get("extendedSupport"))
        if not eol and not eos:
            continue                                  # no dated end (still supported, or not said): no rule
        if eos and eol and eos > eol:
            eos = eol
        key = eol or eos
        cur = out.get(b)
        if cur is None or key > (cur[1] or cur[0]):
            out[b] = (eos, eol, paid if paid and (not eol or paid > eol) else None)
    return out


def rules_from(product, cycles):
    """The rules one product gives: [{platform, name_prefix, version_prefix, eos, eol, note}]."""
    out = []
    for vp, (eos, eol, paid) in sorted(lines(cycles).items()):
        note = "endoflife.date/" + product + (f" · paid extended support until {paid.isoformat()}" if paid else "")
        for name in PRODUCTS[product]:
            out.append({"platform": "windows", "name_prefix": name, "version_prefix": vp, "eos": eos, "eol": eol,
                        "note": note[:300]})
    return out


UPSERT = """
INSERT INTO software_lifecycle (platform, name_prefix, version_prefix, eos, eol, note, source, created_by)
VALUES (%(platform)s, %(name_prefix)s, %(version_prefix)s, %(eos)s, %(eol)s, %(note)s, 'endoflife', 'endoflife.date')
ON CONFLICT (platform, lower(name_prefix), lower(version_prefix)) DO UPDATE
   SET eos = EXCLUDED.eos, eol = EXCLUDED.eol, note = EXCLUDED.note, updated_by = 'endoflife.date', updated_at = now()
 WHERE software_lifecycle.source = 'endoflife'
   AND (software_lifecycle.eos IS DISTINCT FROM EXCLUDED.eos OR software_lifecycle.eol IS DISTINCT FROM EXCLUDED.eol
        OR software_lifecycle.note IS DISTINCT FROM EXCLUDED.note)"""


def save(conn, rules):
    """Insert or update feed rules; an admin's own rule for the same line is left as it is.
    Returns (added or changed, kept because an admin's rule exists)."""
    n = kept = 0
    for r in rules:
        with conn.transaction():
            cur = conn.execute(UPSERT + " RETURNING id", r).fetchone()
        if cur:
            n += 1
        else:
            own = conn.execute("""SELECT source FROM software_lifecycle WHERE platform = %s AND lower(name_prefix) = lower(%s)
                                   AND lower(version_prefix) = lower(%s)""",
                               (r["platform"], r["name_prefix"], r["version_prefix"])).fetchone()
            kept += 1 if own and own["source"] != SOURCE else 0
    return n, kept


# ---- state, and the daily run --------------------------------------------------------------------

def status(conn):
    try:
        with conn.transaction():
            r = conn.execute("SELECT * FROM lifecycle_feed WHERE id = 1").fetchone()
            n = conn.execute("SELECT count(*) AS n FROM software_lifecycle WHERE source = 'endoflife'").fetchone()["n"]
    except Exception:  # noqa: BLE001 - schema 058 not applied yet
        return None
    if not r:
        return None
    out = dict(r)
    out["rules"] = n
    out["products"] = len(PRODUCTS)
    return out


def due(conn):
    s = status(conn)
    if not s or not s["enabled"]:
        return False
    if s.get("requested_at") and (not s.get("last_run_at") or s["requested_at"] > s["last_run_at"]):
        return True
    if not s.get("last_run_at"):
        return True
    from datetime import datetime, timezone
    age = (datetime.now(timezone.utc) - s["last_run_at"]).total_seconds() / 3600
    # after a failure, try again in an hour rather than a day
    return age >= (1 if s.get("last_error") else DAY_HOURS)


def fetch(product):
    from . import cve_intel
    doc = cve_intel._get(BASE_URL + product + ".json")
    if not isinstance(doc, list):
        raise RuntimeError(f"endoflife.date gave no list for {product}")
    return doc


def run(conn, fetch_fn=None, stop=lambda: False):
    """One pass over every product. The network is read first, then the rules are written."""
    fetch_fn = fetch_fn or fetch
    got, failed = {}, []
    conn.commit()                               # nothing held open while the network is read
    for p in PRODUCTS:
        if stop():
            break
        try:
            got[p] = fetch_fn(p)
        except Exception as e:  # noqa: BLE001 - one product failing does not stop the others
            failed.append(p)
            log.warning("endoflife.date %s: %s", p, e)
    added = kept = 0
    for p, cycles in got.items():
        a, k = save(conn, rules_from(p, cycles))
        added, kept = added + a, kept + k
    err = None
    if failed and not got:
        err = "endoflife.date could not be reached from PATCH-01 (through the proxy): allow https://endoflife.date"
    elif failed:
        err = "not read this time: " + ", ".join(failed)
    conn.execute("""UPDATE lifecycle_feed SET last_run_at = now(), last_ok_at = CASE WHEN %s THEN now() ELSE last_ok_at END,
                           last_error = %s, last_counts = %s::jsonb WHERE id = 1""",
                 (bool(got), err, json.dumps({"products": len(got), "changed": added, "kept_admin": kept,
                                                            "failed": failed})))
    conn.commit()
    return {"products": len(got), "changed": added, "kept_admin": kept, "failed": failed}
