#!/usr/bin/env python3
"""PATCH-01's credentials in Vault (r103). Called by patch01-vault.sh and patch01-start.sh.

Vault (the hashicorp/vault image, in Docker on PATCH-01) is the only place the credentials
are kept on disk, encrypted. It listens on a Unix socket only (no network port); this
program, run as root on the host, talks to it over that socket.

While PATCH-01 runs, the credentials are in /patch/secrets as before, but that folder is
RAM (tmpfs): every script and container finds the same files at the same paths, and
nothing is written to disk in clear. What changes there is saved back into Vault (a
systemd path unit, a 5-minute timer, and at shutdown).

  status                         sealed or not, saved or not
  setup [--manual]               first time: initialise, unseal keys, KV store, policy, token
  unseal [--auto]                --auto: with the keys kept for this server; else typed
  import --src DIR               every file under DIR into Vault (verified)
  render --dest DIR              Vault -> DIR (in place: open files and bind mounts see it)
  skeleton --dest DIR            empty files and folders only (at boot, before Docker)
  save --src DIR [--quiet]       what changed in DIR -> Vault (never deletes from Vault)
  verify --src DIR               DIR and Vault hold the same
  forget RELPATH                 delete one file from Vault (the only way anything is deleted)
  seal-mode auto|manual          keep the unseal keys for this server, or not
  new-token                      a new access token, with the unseal keys (if it expired)
  export --dest DIR              Vault -> a folder on disk (to stop using Vault)

Only the Python standard library: it runs on RHEL 8 and 9 as they are.
"""
import argparse
import base64
import getpass
import hashlib
import hmac
import http.client
import json
import os
import re
import shutil
import socket
import stat
import subprocess
import sys
import time
from urllib.parse import quote

SOCKET = os.environ.get("PATCH01_VAULT_SOCKET", "/run/patch01-vault/vault.sock")
# Outside /patch on purpose: a backup or copy of /patch (Vault's data) never holds the keys too
KEYS_DIR = os.environ.get("PATCH01_VAULT_KEYS", "/var/lib/patch01-vault")
STATE = os.environ.get("PATCH01_VAULT_STATE", "/run/patch01-vault-state.json")   # RAM: what was last saved
MOUNT = "patch01"
FILES = "files"
META = "meta/folders"
POLICY = "patch01-ops"
LOADED = ".vault-loaded"          # in the secrets folder: it was filled from Vault (never saved)
SHARES, THRESHOLD = 5, 3
TOKEN_PERIOD = "768h"
RENEW_EVERY = 86400
MAX_FILE = 1 << 20                # a credential file larger than 1 MB is not a credential
MAX_TOTAL = 32 << 20              # all of them: well inside the 64 MB RAM folder
# Never saved: editors' and scripts' temporary files (a save may run while a script writes)
# (.bak files are kept: the scripts' own dated backups of certificates and keys)
SKIP_RE = re.compile(r"(^\.|~$|\.(tmp|swp|swx|rej)$)")
MKTEMP_RE = re.compile(r"^(.+)\.[A-Za-z0-9]{4,10}$")    # mktemp "$FILE.XXXX" beside FILE

POLICY_HCL = """# PATCH-01's own credentials, and nothing else (r103). No delete: the token kept on the
# server can never erase anything; forget uses a temporary root token from the unseal keys
path "%(m)s/data/*"     { capabilities = ["create", "read", "update"] }
path "%(m)s/metadata/*" { capabilities = ["list", "read"] }
path "%(m)s/metadata"   { capabilities = ["list"] }
""" % {"m": MOUNT}


class VaultError(RuntimeError):
    pass


class SealedNoKeys(VaultError):
    """Sealed, and this server keeps no unseal keys (manual mode): someone types them."""


def say(msg):
    print(msg, flush=True)


# ---------------------------------------------------------------------------
# HTTP over the Unix socket
# ---------------------------------------------------------------------------

class _UnixConnection(http.client.HTTPConnection):
    def __init__(self, path, timeout=30):
        http.client.HTTPConnection.__init__(self, "localhost", timeout=timeout)
        self._path = path

    def connect(self):
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(self.timeout)
        s.connect(self._path)
        self.sock = s


class Vault:
    def __init__(self, sock=SOCKET, token=None):
        self.sock, self.token = sock, token

    def call(self, method, path, body=None, ok=(200, 204), token=True):
        conn = _UnixConnection(self.sock)
        headers = {"Content-Type": "application/json"}
        if token and self.token:
            headers["X-Vault-Token"] = self.token
        data = json.dumps(body).encode() if body is not None else None
        try:
            conn.request(method, "/v1/" + path.lstrip("/"), body=data, headers=headers)
            r = conn.getresponse()
            raw = r.read()
        except OSError as e:
            raise VaultError("Vault does not answer on %s (%s). Is the patch01-vault container running?"
                             % (self.sock, e))
        finally:
            conn.close()
        try:
            doc = json.loads(raw) if raw else {}
        except ValueError:
            doc = {}
        if r.status not in ok:
            errs = "; ".join(doc.get("errors") or []) or raw.decode("utf-8", "replace")[:300]
            raise VaultError("Vault refused %s %s (HTTP %d): %s" % (method, path.split("?")[0], r.status, errs))
        return doc, r.status

    # -- state
    def initialized(self):
        return bool(self.call("GET", "sys/init", token=False)[0].get("initialized"))

    def seal_status(self):
        return self.call("GET", "sys/seal-status", token=False)[0]

    def sealed(self):
        return bool(self.seal_status().get("sealed", True))

    def unseal(self, key):
        return self.call("PUT", "sys/unseal", {"key": key}, token=False)[0]

    # -- KV v2
    def kv_put(self, rel, data):
        return self.call("POST", "%s/data/%s" % (MOUNT, quote(rel, safe="/")), {"data": data})[0]

    def kv_get(self, rel):
        doc, status = self.call("GET", "%s/data/%s" % (MOUNT, quote(rel, safe="/")), ok=(200, 404))
        if status == 404:
            return None
        return ((doc.get("data") or {}).get("data")) or None

    def kv_list(self, prefix=""):
        """Every key under prefix, recursively (folders end with / in Vault's answer)."""
        out = []
        doc, status = self.call("LIST", "%s/metadata/%s" % (MOUNT, quote(prefix, safe="/")), ok=(200, 404))
        if status == 404:
            return out
        for k in (doc.get("data") or {}).get("keys") or []:
            if k.endswith("/"):
                out += self.kv_list(prefix + k)
            else:
                out.append(prefix + k)
        return out

    def kv_delete(self, rel):
        self.call("DELETE", "%s/metadata/%s" % (MOUNT, quote(rel, safe="/")))


# ---------------------------------------------------------------------------
# The keys kept for this server (auto unseal) and the access token
# ---------------------------------------------------------------------------

class Keys:
    """Files in KEYS_DIR (root only). Encrypted for this machine with systemd-creds when the
    OS has it (RHEL 9: TPM2 if present, else the host key in /var/lib/systemd, outside /patch):
    a copy of /patch, or of a backup, cannot unseal Vault on its own. Without systemd-creds
    (RHEL 8): files readable by root only, and status says so."""

    def __init__(self, d=KEYS_DIR):
        self.d = d

    def path(self, name):
        return os.path.join(self.d, name)

    def ensure_dir(self):
        os.makedirs(self.d, mode=0o700, exist_ok=True)
        os.chmod(self.d, 0o700)

    @staticmethod
    def creds_tool():
        return shutil.which("systemd-creds")

    def write(self, name, text):
        self.ensure_dir()
        tool = self.creds_tool()
        tmp = self.path(name + ".tmp")
        if tool:
            p = subprocess.run([tool, "encrypt", "--name=patch01-" + name, "-", tmp],
                               input=text.encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if p.returncode != 0:
                raise VaultError("systemd-creds could not encrypt %s: %s" % (name, p.stderr.decode()[-300:]))
            os.chmod(tmp, 0o400)
            final, other = self.path(name + ".cred"), self.path(name + ".plain")
        else:
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o400)
            with os.fdopen(fd, "w") as fh:
                fh.write(text)
            final, other = self.path(name + ".plain"), self.path(name + ".cred")
        os.replace(tmp, final)
        if os.path.exists(other):
            os.remove(other)

    def read(self, name):
        c, p = self.path(name + ".cred"), self.path(name + ".plain")
        if os.path.exists(c):
            tool = self.creds_tool()
            if not tool:
                raise VaultError("%s is encrypted with systemd-creds, which is not on this server" % c)
            r = subprocess.run([tool, "decrypt", "--name=patch01-" + name, c, "-"],
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if r.returncode != 0:
                raise VaultError("%s cannot be decrypted on this server (another machine's, or its key changed): %s"
                                 % (c, r.stderr.decode()[-200:]))
            return r.stdout.decode()
        if os.path.exists(p):
            with open(p) as fh:
                return fh.read()
        return None

    def remove(self, name):
        for suffix in (".cred", ".plain"):
            f = self.path(name + suffix)
            if os.path.exists(f):
                _shred(f)

    def protection(self):
        names = os.listdir(self.d) if os.path.isdir(self.d) else []
        if any(n.endswith(".plain") for n in names):
            return "root-only files (systemd-creds is not on this server)"
        if any(n.endswith(".cred") for n in names):
            return "encrypted for this server (systemd-creds)"
        return "none kept"

    def token(self):
        t = self.read("token")
        return t.strip() if t else None

    def shares(self):
        s = self.read("unseal")
        return json.loads(s) if s else None

    def mode(self):
        try:
            with open(self.path("mode")) as fh:
                return fh.read().strip() or "auto"
        except OSError:
            return "auto"

    def set_mode(self, mode):
        self.ensure_dir()
        with open(self.path("mode"), "w") as fh:
            fh.write(mode + "\n")


def _shred(path):
    try:
        size = os.path.getsize(path)
        with open(path, "r+b") as fh:
            fh.write(os.urandom(size))
            fh.flush()
            os.fsync(fh.fileno())
    except OSError:
        pass
    os.remove(path)


def client(keys):
    try:
        tok = keys.token()
    except VaultError as e:
        raise VaultError("%s. Make a new one with the unseal keys: patch01-vault.sh --new-token --typed" % e)
    if not tok:
        raise VaultError("No access token for Vault on this server (%s). Run: patch01-vault.sh --new-token --typed"
                         % keys.d)
    return Vault(token=tok)


# ---------------------------------------------------------------------------
# Unseal
# ---------------------------------------------------------------------------

def do_unseal(v, keys, auto):
    if not v.initialized():
        raise VaultError("Vault is not set up yet: run patch01-vault.sh --setup")
    st = v.seal_status()
    if not st.get("sealed"):
        return "already unsealed"
    if auto:
        shares = keys.shares() if keys.mode() == "auto" else None
        if not shares:
            raise SealedNoKeys("Vault is sealed and this server keeps no unseal keys (manual mode): "
                             "run patch01-vault.sh --unseal and type " + str(st.get("t", THRESHOLD)) + " of the keys")
        for k in shares:
            st = v.unseal(k)
            if not st.get("sealed"):
                return "unsealed with the keys kept for this server"
        raise VaultError("the unseal keys kept for this server did not unseal Vault (Vault was re-initialised?)")
    need = st.get("t", THRESHOLD)
    say("Vault is sealed. Type %d of the %d unseal keys (hidden), one at a time." % (need, st.get("n", SHARES)))
    while st.get("sealed"):
        k = getpass.getpass("  unseal key %d of %d: " % (st.get("progress", 0) + 1, need)).strip()
        if not k:
            continue
        try:
            st = v.unseal(k)
        except VaultError as e:
            say("  not accepted: %s" % e)
    return "unsealed"


# ---------------------------------------------------------------------------
# Files <-> Vault
# ---------------------------------------------------------------------------

SKIPPED = []


def walk(src):
    """(folders, files) under src as relative paths. Links, odd files, files over 1 MB and
    temporary files are left out (listed in SKIPPED, warned about): one of them never stops
    everything else from being saved."""
    del SKIPPED[:]
    folders, files, total = [], [], 0
    for root, dirs, names in os.walk(src):
        rel_root = os.path.relpath(root, src)
        keep = []
        for d in sorted(dirs):
            p = os.path.join(root, d)
            if os.path.islink(p):
                SKIPPED.append("%s (a link)" % p)
                continue
            keep.append(d)
            folders.append(os.path.normpath(os.path.join(rel_root, d)))
        dirs[:] = keep
        for n in sorted(names):
            p = os.path.join(root, n)
            rel = os.path.normpath(os.path.join(rel_root, n))
            if rel == LOADED:
                continue
            m = MKTEMP_RE.match(n)
            if SKIP_RE.search(n) or (m and m.group(1) in names):
                SKIPPED.append("%s (a temporary file)" % p)
                continue
            try:
                st = os.lstat(p)
            except OSError:
                continue                          # gone while looking (a script's mv): nothing to save
            if not stat.S_ISREG(st.st_mode):
                SKIPPED.append("%s (not a plain file)" % p)
            elif st.st_size > MAX_FILE:
                SKIPPED.append("%s (larger than 1 MB: not a credential)" % p)
            else:
                total += st.st_size
                files.append(rel)
    if total > MAX_TOTAL:
        raise VaultError("%s holds %d MB: more than credentials (limit 32 MB)" % (src, total >> 20))
    for w in SKIPPED:
        print("WARNING: not in Vault: %s" % w, file=sys.stderr)
    return folders, files


def _safe_rel(rel):
    rel = os.path.normpath(rel)
    if rel.startswith("..") or os.path.isabs(rel) or rel in (".", LOADED):
        raise VaultError("refusing the path %r" % rel)
    return rel


def file_record(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as fh:
        st = os.fstat(fh.fileno())
        data = fh.read()
    return {"b64": base64.b64encode(data).decode(), "mode": "%o" % stat.S_IMODE(st.st_mode),
            "uid": st.st_uid, "gid": st.st_gid, "sha256": hashlib.sha256(data).hexdigest()}


def folder_records(src, folders):
    out = {}
    for rel in folders:
        st = os.lstat(os.path.join(src, rel))
        out[rel] = {"mode": "%o" % stat.S_IMODE(st.st_mode), "uid": st.st_uid, "gid": st.st_gid}
    return out


def do_import(v, src):
    folders, files = walk(src)
    if not files:
        raise VaultError("nothing to import in %s" % src)
    v.kv_put(META, {"folders": json.dumps(folder_records(src, folders))})
    for rel in files:
        v.kv_put("%s/%s" % (FILES, rel), file_record(os.path.join(src, rel)))
    bad = verify(v, src)
    if bad:
        raise VaultError("after the import, Vault and %s differ: %s" % (src, "; ".join(bad[:10])))
    return len(files), len(folders)


def verify(v, src):
    """Differences between src and Vault, in words (empty: the same)."""
    folders, files = walk(src)
    stored = {k[len(FILES) + 1:] for k in v.kv_list(FILES + "/")}
    bad = []
    for rel in files:
        if rel not in stored:
            bad.append("%s: only on this server" % rel)
            continue
        rec = v.kv_get("%s/%s" % (FILES, rel)) or {}
        with open(os.path.join(src, rel), "rb") as fh:
            if hashlib.sha256(fh.read()).hexdigest() != rec.get("sha256"):
                bad.append("%s: different" % rel)
    for rel in sorted(stored - set(files)):
        bad.append("%s: only in Vault" % rel)
    return bad


def _write_in_place(path, data, mode, uid, gid):
    """Same file (inode) when it exists: a container that bind-mounted it sees the new content."""
    if os.path.isdir(path) and not os.path.islink(path):
        # Docker made a folder for a file that was not there yet: replaced (that container restarts)
        try:
            os.rmdir(path)
        except OSError:
            raise VaultError("%s is a folder with files in it, where a file belongs" % path)
    if os.path.islink(path):
        os.remove(path)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        os.fchmod(fd, int(mode, 8))
        os.fchown(fd, uid, gid)
        os.ftruncate(fd, 0)
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)


def load_all(v):
    meta = v.kv_get(META) or {}
    folders = json.loads(meta.get("folders") or "{}")
    files = {}
    for k in v.kv_list(FILES + "/"):
        rel = _safe_rel(k[len(FILES) + 1:])
        rec = v.kv_get(k)
        if rec:
            files[rel] = rec
    return folders, files


def _owner(rec):
    return int(rec.get("uid", 0)), int(rec.get("gid", 0))


def do_render(v, dest, keys):
    folders, files = load_all(v)
    if not files:
        raise VaultError("Vault holds no PATCH-01 credentials yet (run --import first)")
    for rel in sorted(folders, key=lambda r: r.count("/")):
        p = os.path.join(dest, _safe_rel(rel))
        os.makedirs(p, mode=0o700, exist_ok=True)
        f = folders[rel]
        os.chmod(p, int(f.get("mode", "700"), 8))
        os.chown(p, *_owner(f))
    digests = {}
    for rel, rec in sorted(files.items()):
        p = os.path.join(dest, rel)
        os.makedirs(os.path.dirname(p), mode=0o700, exist_ok=True)
        data = base64.b64decode(rec["b64"])
        if hashlib.sha256(data).hexdigest() != rec.get("sha256"):
            raise VaultError("%s in Vault does not match its own checksum" % rel)
        _write_in_place(p, data, rec.get("mode", "600"), *_owner(rec))
        digests[rel] = rec["sha256"]
    _write_skeleton(keys, folders, files)
    with open(os.path.join(dest, LOADED), "w") as fh:
        fh.write("filled from Vault at %s\n" % time.strftime("%Y-%m-%d %H:%M:%S"))
    _save_state(digests)
    return len(files)


def _write_skeleton(keys, folders, files):
    """Names, modes and owners only (no content): to make the empty files before Docker starts."""
    keys.ensure_dir()
    sk = {"folders": folders,
          "files": {rel: {"mode": r.get("mode", "600"), "uid": r.get("uid", 0), "gid": r.get("gid", 0)}
                    for rel, r in files.items()}}
    tmp = keys.path("skeleton.json.tmp")
    with open(tmp, "w") as fh:
        json.dump(sk, fh, indent=1, sort_keys=True)
    os.chmod(tmp, 0o600)
    os.replace(tmp, keys.path("skeleton.json"))


def do_skeleton(dest, keys):
    try:
        with open(keys.path("skeleton.json")) as fh:
            sk = json.load(fh)
    except OSError:
        return 0
    for rel, f in sorted(sk.get("folders", {}).items(), key=lambda kv: kv[0].count("/")):
        p = os.path.join(dest, _safe_rel(rel))
        os.makedirs(p, mode=0o700, exist_ok=True)
        os.chmod(p, int(f.get("mode", "700"), 8))
        os.chown(p, *_owner(f))
    n = 0
    for rel, f in sorted(sk.get("files", {}).items()):
        p = os.path.join(dest, _safe_rel(rel))
        os.makedirs(os.path.dirname(p), mode=0o700, exist_ok=True)
        if not os.path.exists(p):
            fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW, int(f.get("mode", "600"), 8))
            os.fchown(fd, *_owner(f))
            os.close(fd)
            n += 1
    return n


def _load_state():
    try:
        with open(STATE) as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def _save_state(digests, extra=None):
    """What was last saved to / loaded from Vault, as HMACs (RAM only, root only)."""
    st = _load_state()
    key = base64.b64decode(st["key"]) if st.get("key") else os.urandom(32)
    doc = {"key": base64.b64encode(key).decode(),
           "files": {rel: hmac.new(key, d.encode(), "sha256").hexdigest() for rel, d in digests.items()},
           "renewed": st.get("renewed", 0)}
    doc.update(extra or {})
    fd = os.open(STATE + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        json.dump(doc, fh)
    os.replace(STATE + ".tmp", STATE)


def do_save(v, src, keys, quiet=False):
    if not os.path.exists(os.path.join(src, LOADED)):
        raise VaultError("%s was not filled from Vault (%s missing): nothing saved, so Vault cannot be "
                         "overwritten with empty or wrong files" % (src, LOADED))
    folders, files = walk(src)
    st = _load_state()
    key = base64.b64decode(st["key"]) if st.get("key") else None
    known = st.get("files") or {}
    digests, changed = {}, []
    for rel in files:
        try:
            rec = file_record(os.path.join(src, rel))
        except OSError:
            continue                              # gone or replaced while saving: the next save takes it
        digests[rel] = rec["sha256"]
        mark = hmac.new(key, rec["sha256"].encode(), "sha256").hexdigest() if key else None
        if mark is None or known.get(rel) != mark:
            old = v.kv_get("%s/%s" % (FILES, rel))
            if old is not None and not rec["b64"] and old.get("b64"):
                # Emptied: almost always a write cut short ("x > file" that failed). Kept as it was
                print("WARNING: %s is empty here but not in Vault: not saved (if it really is meant to "
                      "be empty: patch01-vault.sh --forget %s, then save)" % (rel, rel), file=sys.stderr)
                digests[rel] = old.get("sha256")
                continue
            if old is None or {k: old.get(k) for k in rec} != rec:
                v.kv_put("%s/%s" % (FILES, rel), rec)
                changed.append(rel)
    meta = json.dumps(folder_records(src, folders))
    if st.get("folders") != meta:
        v.kv_put(META, {"folders": meta})
    if changed or st.get("folders") != meta:
        recs = {}
        for rel in files:
            try:
                recs[rel] = file_record(os.path.join(src, rel))
            except OSError:
                pass
        _write_skeleton(keys, folder_records(src, folders), recs)
    _save_state(digests, {"folders": meta})
    if changed and not quiet:
        say("saved to Vault: " + ", ".join(changed))
    return changed


def renew_token(v):
    st = _load_state()
    if time.time() - st.get("renewed", 0) < RENEW_EVERY:
        return False
    v.call("POST", "auth/token/renew-self", {})
    st["renewed"] = int(time.time())
    fd = os.open(STATE + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        json.dump(st, fh)
    os.replace(STATE + ".tmp", STATE)
    return True


def do_export(v, dest):
    folders, files = load_all(v)
    os.makedirs(dest, mode=0o700, exist_ok=True)
    for rel in sorted(folders, key=lambda r: r.count("/")):
        p = os.path.join(dest, rel)
        os.makedirs(p, mode=0o700, exist_ok=True)
        os.chmod(p, int(folders[rel].get("mode", "700"), 8))
        os.chown(p, *_owner(folders[rel]))
    for rel, rec in files.items():
        p = os.path.join(dest, rel)
        os.makedirs(os.path.dirname(p), mode=0o700, exist_ok=True)
        _write_in_place(p, base64.b64decode(rec["b64"]), rec.get("mode", "600"), *_owner(rec))
    return len(files)


# ---------------------------------------------------------------------------
# Setup and the access token
# ---------------------------------------------------------------------------

def make_token(root_v):
    doc = root_v.call("POST", "auth/token/create-orphan",
                      {"policies": [POLICY], "period": TOKEN_PERIOD, "renewable": True,
                       "display_name": "patch01-ops", "no_default_policy": False})[0]
    tok = ((doc.get("auth") or {}).get("client_token"))
    if not tok:
        raise VaultError("Vault did not return a token")
    return tok


def configure(root_v):
    mounts = root_v.call("GET", "sys/mounts")[0]
    if (MOUNT + "/") not in mounts and (MOUNT + "/") not in (mounts.get("data") or {}):
        root_v.call("POST", "sys/mounts/" + MOUNT, {"type": "kv", "options": {"version": "2"},
                                                     "description": "PATCH-01 credentials (r103)"})
    root_v.call("PUT", "sys/policies/acl/" + POLICY, {"policy": POLICY_HCL})
    audits = root_v.call("GET", "sys/audit")[0]
    if "file/" not in audits and "file/" not in (audits.get("data") or {}):
        # Every request, with secret values HMAC'd (never in clear): who read what, when
        root_v.call("PUT", "sys/audit/file", {"type": "file", "options": {"file_path": "/vault/logs/audit.log"}})


def do_setup(v, keys, manual, out=print):
    if v.initialized():
        raise VaultError("Vault is already initialised. To change how it unseals: --manual / --auto")
    doc = v.call("PUT", "sys/init", {"secret_shares": SHARES, "secret_threshold": THRESHOLD}, token=False)[0]
    shares, root = doc.get("keys_base64") or doc.get("keys"), doc.get("root_token")
    if not shares or not root:
        raise VaultError("Vault did not return the unseal keys")
    out("")
    out("=" * 72)
    out(" VAULT UNSEAL KEYS - shown ONCE. Store them apart, offline (e.g. 5 sealed")
    out(" envelopes, or your password safe). Any %d of the %d unseal Vault. Without" % (THRESHOLD, SHARES))
    out(" them, a Vault that cannot unseal by itself is LOST, with every credential.")
    out("=" * 72)
    for i, k in enumerate(shares, 1):
        out("  Unseal key %d: %s" % (i, k))
    out("=" * 72)
    for k in shares[:THRESHOLD]:
        v.unseal(k)
    root_v = Vault(v.sock, root)
    configure(root_v)
    tok = make_token(root_v)
    keys.write("token", tok)
    keys.set_mode("manual" if manual else "auto")
    if not manual:
        keys.write("unseal", json.dumps(shares[:THRESHOLD]))
    # The root token is never kept: with the unseal keys, --new-token makes what is needed
    root_v.call("POST", "auth/token/revoke-self", {})
    return shares


def _decode_root(encoded, otp):
    raw = base64.b64decode(encoded + "=" * (-len(encoded) % 4))
    o = otp.encode()
    if len(raw) != len(o):
        raise VaultError("the generated root token does not match its one-time password (length)")
    return bytes(a ^ b for a, b in zip(raw, o)).decode()


def temp_root(v, shares):
    """A root token made from the unseal keys, for one task; the caller revokes it."""
    if v.sealed():
        raise VaultError("Vault is sealed: unseal it first")
    if not shares:
        raise VaultError("no unseal keys kept for this server: type them (--typed)")
    v.call("DELETE", "sys/generate-root/attempt", token=False)
    att = v.call("PUT", "sys/generate-root/attempt", {}, token=False)[0]
    nonce, otp = att.get("nonce"), att.get("otp")
    if not nonce or not otp:
        raise VaultError("Vault did not start a root token generation (old Vault without server-side OTP?)")
    res = {}
    for k in shares:
        res = v.call("PUT", "sys/generate-root/update", {"key": k, "nonce": nonce}, token=False)[0]
        if res.get("complete"):
            break
    if not res.get("complete"):
        raise VaultError("the unseal keys did not complete the root token generation")
    return Vault(v.sock, _decode_root(res["encoded_token"], otp))


def with_root(v, shares, fn):
    root_v = temp_root(v, shares)
    try:
        return fn(root_v)
    finally:
        try:
            root_v.call("POST", "auth/token/revoke-self", {})
        except VaultError:
            pass


def kept_shares(keys):
    """The unseal keys kept for this server, or None (manual mode, or they cannot be read here)."""
    if keys.mode() != "auto":
        return None
    try:
        return keys.shares()
    except VaultError as e:
        print("WARNING: %s" % e, file=sys.stderr)
        return None


def do_new_token(v, keys, typed=None):
    """A fresh access token: a temporary root token from the unseal keys, used once, revoked."""
    shares = typed or kept_shares(keys)
    if not shares:
        raise VaultError("no unseal keys usable on this server: run patch01-vault.sh --new-token --typed")

    def make(root_v):
        configure(root_v)
        return make_token(root_v)
    tok = with_root(v, shares, make)
    try:
        old = keys.token()
    except VaultError:
        old = None
    keys.write("token", tok)
    if old and old != tok:
        try:
            Vault(v.sock, old).call("POST", "auth/token/revoke-self", {}, ok=(200, 204, 403))
        except VaultError:
            pass
    return tok


def type_shares(n):
    out = []
    say("Type %d of the unseal keys (hidden)." % n)
    while len(out) < n:
        k = getpass.getpass("  unseal key %d of %d: " % (len(out) + 1, n)).strip()
        if k:
            out.append(k)
    return out


# ---------------------------------------------------------------------------

def status(v, keys, src):
    lines = []
    try:
        if not v.initialized():
            return ["Vault: running, NOT set up (run --setup)"], 1
        st = v.seal_status()
    except VaultError as e:
        return ["Vault: not reachable: %s" % e], 2
    lines.append("Vault: %s (unseal keys: %d of %d)" % ("SEALED" if st.get("sealed") else "unsealed",
                                                          st.get("t", 0), st.get("n", 0)))
    lines.append("Unseals at boot: %s" % ("by itself (keys kept for this server)" if keys.mode() == "auto"
                                           else "no: someone runs patch01-vault.sh --unseal"))
    lines.append("Keys kept on this server: %s" % keys.protection())
    rc = 1 if st.get("sealed") else 0
    if not st.get("sealed"):
        loaded = os.path.exists(os.path.join(src, LOADED))
        lines.append("%s: %s" % (src, "filled from Vault (RAM)" if loaded else "NOT filled from Vault"))
        if loaded:
            try:
                bad = verify(client(keys), src)
            except VaultError as e:
                bad = ["could not compare: %s" % e]
            unsaved = [b for b in bad if not b.endswith("only in Vault")]
            lines.append("Saved: " + ("everything" if not unsaved else "; ".join(unsaved[:8])))
            extra = [b for b in bad if b.endswith("only in Vault")]
            if extra:
                lines.append("In Vault but not here (deleted here? remove with --forget): "
                             + ", ".join(b.split(":")[0] for b in extra[:8]))
            if SKIPPED:
                lines.append("Not saved (not credentials): " + "; ".join(SKIPPED[:5]))
            rc = rc or (1 if unsaved else 0)
        else:
            rc = 1
    return lines, rc


def main(argv=None):
    ap = argparse.ArgumentParser(prog="patch01_vault.py")
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("status"); p.add_argument("--src", default="/patch/secrets")
    p = sub.add_parser("ping"); p.add_argument("--wait", type=int, default=60)
    p = sub.add_parser("setup"); p.add_argument("--manual", action="store_true")
    p = sub.add_parser("unseal"); p.add_argument("--auto", action="store_true")
    for name in ("import", "save", "verify"):
        p = sub.add_parser(name); p.add_argument("--src", required=True)
        if name == "save":
            p.add_argument("--quiet", action="store_true")
    for name in ("render", "skeleton", "export"):
        p = sub.add_parser(name); p.add_argument("--dest", required=True)
    p = sub.add_parser("forget"); p.add_argument("rel"); p.add_argument("--typed", action="store_true")
    sub.add_parser("initialized")
    p = sub.add_parser("seal-mode"); p.add_argument("mode", choices=("auto", "manual"))
    p = sub.add_parser("new-token"); p.add_argument("--typed", action="store_true")
    a = ap.parse_args(argv)
    if not a.cmd:
        ap.print_help()
        return 2
    keys = Keys()
    v = Vault()
    try:
        if a.cmd == "status":
            lines, rc = status(v, keys, a.src)
            for l in lines:
                say(l)
            return rc
        if a.cmd == "ping":
            # The socket file alone proves nothing: after a container restart the old one is still there
            end = time.time() + a.wait
            while True:
                try:
                    v.seal_status()
                    return 0
                except VaultError as e:
                    if time.time() >= end:
                        raise VaultError("Vault did not answer within %ds: %s" % (a.wait, e))
                    time.sleep(1)
        if a.cmd == "setup":
            do_setup(v, keys, a.manual)
            return 0
        if a.cmd == "unseal":
            say(do_unseal(v, keys, a.auto))
            return 0
        if a.cmd == "skeleton":
            n = do_skeleton(a.dest, keys)
            say("%d empty file(s) made for the containers until Vault fills them" % n)
            return 0
        if a.cmd == "seal-mode":
            if a.mode == "manual":
                keys.remove("unseal")
                keys.set_mode("manual")
                say("This server no longer keeps unseal keys: after each restart, run patch01-vault.sh --unseal")
            else:
                if v.sealed():
                    raise VaultError("unseal Vault first")
                shares = type_shares(v.seal_status().get("t", THRESHOLD))
                # Proven before they are kept: a key generation that completes needs valid keys
                do_new_token(v, keys, typed=shares)
                keys.write("unseal", json.dumps(shares))
                keys.set_mode("auto")
                say("This server keeps %d unseal keys (%s): Vault unseals by itself at boot"
                    % (len(shares), keys.protection()))
            return 0
        if a.cmd == "initialized":
            return 0 if v.initialized() else 1
        if a.cmd == "new-token":
            typed = None
            if a.typed or (not kept_shares(keys) and sys.stdin.isatty()):
                typed = type_shares(v.seal_status().get("t", THRESHOLD))
            do_new_token(v, keys, typed=typed)
            say("New access token made and kept for this server; the old one was revoked")
            return 0
        if a.cmd == "forget":
            # The kept token cannot delete (by design): a temporary root token from the unseal keys
            rel = _safe_rel(a.rel)
            shares = None if a.typed else kept_shares(keys)
            if not shares:
                shares = type_shares(v.seal_status().get("t", THRESHOLD))
            with_root(v, shares, lambda r: r.kv_delete("%s/%s" % (FILES, rel)))
            say("%s deleted from Vault (every version)" % rel)
            return 0
        c = client(keys)
        if a.cmd == "import":
            n, f = do_import(c, a.src)
            say("Imported and checked: %d file(s), %d folder(s)" % (n, f))
        elif a.cmd == "render":
            renew_token(c)
            say("Filled %s from Vault: %d file(s)" % (a.dest, do_render(c, a.dest, keys)))
        elif a.cmd == "save":
            if v.sealed() and keys.mode() == "auto":
                # Docker restarted (an OS update) and Vault with it: unsealed again by itself
                say(do_unseal(v, keys, True))
            renew_token(c)
            do_save(c, a.src, keys, a.quiet)
        elif a.cmd == "verify":
            bad = verify(c, a.src)
            for b in bad:
                say(b)
            say("Vault and %s hold the same" % a.src if not bad else "%d difference(s)" % len(bad))
            return 1 if bad else 0
        elif a.cmd == "export":
            say("Wrote %d file(s) to %s" % (do_export(c, a.dest), a.dest))
        return 0
    except SealedNoKeys as e:
        print("ERROR: %s" % e, file=sys.stderr)
        return 3
    except VaultError as e:
        print("ERROR: %s" % e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
