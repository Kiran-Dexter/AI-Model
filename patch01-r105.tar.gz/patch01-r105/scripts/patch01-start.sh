#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 : start everything, in order, repair what does not come up, check health
#
# Usage:
#   sudo ./scripts/patch01-start.sh                  start (or confirm) everything, then health check
#   sudo ./scripts/patch01-start.sh --install-boot   also do this at every boot (systemd service)
#   sudo ./scripts/patch01-start.sh --remove-boot    stop doing it at boot
#   sudo ./scripts/patch01-start.sh --no-repair      start only; never re-run a phase script
#   --wait-lock   wait (up to 30 min) for a start already running instead of stopping;
#                 implied by --boot (used by the boot service and the post-update boot check)
#
# Order (each part must be healthy before the next starts, because each needs
# the one before it):
#   1. docker        started and enabled; restarted once if it does not answer
#   1b. vault        only when the credentials are in Vault (r103): unsealed, and
#                    /patch/secrets (RAM) filled from it before anything else
#   2. ingress       nginx, and the shared network "patchnet" the others join
#   3. data          PostgreSQL and Redis
#   4. pulp          the repository mirrors (runs its migrations first). Its
#                    settings are brought up to date first: usage data off
#                    under Pulp's current name (ANALYTICS), see fix_pulp_settings
#   5. api           the API and the worker
#   6. dashboard     the console
#   7. clamav        only if it was installed (phase11)
# A part that does not become healthy is repaired once: its own phase script is
# re-run (it rebuilds that part's configuration from the saved settings and
# starts it). If it is still not healthy, the start stops there and says which
# part, with the last lines of its log; the parts after it are not started on
# a broken base. Then the full health check runs (patch01-update.sh).
#
# Already-running parts are left alone (docker compose up -d changes nothing
# that is up to date). Nothing secret is printed; the log is root-only.
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 077
export LC_ALL=C

SELF="$(readlink -f "${BASH_SOURCE[0]}")"
SCRIPTS="$(dirname "$SELF")"
PATCH_BASE="/patch"
COMPOSE_DIR="$PATCH_BASE/compose"
LOG_DIR="/var/log/patch-platform"
UNIT="patch01-start"
LOCK="/run/patch01-start.lock"

REPAIR=yes; HEALTH=yes; INSTALL=no; REMOVE=no; BOOT=no; WAIT_LOCK=no
while (($#)); do
  case "$1" in
    --no-repair)    REPAIR=no ;;
    --no-health)    HEALTH=no ;;
    --install-boot) INSTALL=yes ;;
    --remove-boot)  REMOVE=yes ;;
    --boot)         BOOT=yes; WAIT_LOCK=yes ;;
    --wait-lock)    WAIT_LOCK=yes ;;
    -h|--help)      sed -n '2,31p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done
[[ $EUID -eq 0 ]] || { echo "Run as root." >&2; exit 1; }

mkdir -p "$LOG_DIR"; chmod 0750 "$LOG_DIR"
LOG_FILE="$LOG_DIR/patch01-start-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"
log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }

exec 8>"$LOCK"
# At boot this service and the post-update check (patch01-update.sh --post-boot)
# can both start PATCH-01: the second waits for the first instead of failing
if [[ "$WAIT_LOCK" == yes ]]; then
  flock -n 8 || { say "Another patch01-start.sh is running: waiting for it to finish (up to 30 minutes)"
                  flock -w 1800 8 || die "Another patch01-start.sh is still running after 30 minutes."; }
else
  flock -n 8 || die "Another patch01-start.sh is running."
fi

# Runs as root, and at boot from a service: only from files only root can change
safe_path() {
  [[ "$(stat -c %u "$1")" == 0 ]] || die "$1 is not owned by root: refusing to run from it as root."
  (( ( 8#$(stat -c %a "$1") & 8#022 ) == 0 )) || die "$1 is writable by others than root: fix with chmod go-w $1"
}
d="$SCRIPTS"; while [[ "$d" != / ]]; do safe_path "$d"; d="$(dirname "$d")"; done
for f in "$SELF" "$SCRIPTS"/*.sh "$SCRIPTS"/*.py; do [[ -e "$f" ]] && safe_path "$f"; done

# ---------------------------------------------------------------------------
# Boot service
# ---------------------------------------------------------------------------
if [[ "$REMOVE" == yes ]]; then
  systemctl disable --now "$UNIT.service" >/dev/null 2>&1 || true
  rm -f "/etc/systemd/system/$UNIT.service"; systemctl daemon-reload
  say "Removed: PATCH-01 no longer starts and checks itself at boot (docker still restarts its containers)."
  exit 0
fi
if [[ "$INSTALL" == yes ]]; then
  cat > "/etc/systemd/system/$UNIT.service" <<EOF
[Unit]
Description=PATCH-01: start every part in order, repair, health check
After=docker.service network-online.target
Wants=docker.service network-online.target

[Service]
Type=oneshot
ExecStart=$SELF --boot
# Up to 30 min waiting for a start already running, the start itself (up to
# ~40 min with repairs), then up to 30 min for the update lock and the health check
TimeoutStartSec=7200
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
  chmod 0644 "/etc/systemd/system/$UNIT.service"
  systemctl daemon-reload; systemctl enable "$UNIT.service" >/dev/null 2>&1
  say "Installed: at every boot PATCH-01 starts its parts in order and checks itself"
  say "(result: systemctl status $UNIT, and $LOG_DIR/update-last.txt)."
  say "Running it once now:"
fi

# ---------------------------------------------------------------------------
# Waiting for containers
# ---------------------------------------------------------------------------
cstate() {   # running+healthy | running | starting | unhealthy | exited | missing
  local st hs
  st="$(docker inspect -f '{{.State.Status}}' "$1" 2>/dev/null || echo missing)"
  [[ "$st" == running ]] || { echo "$st"; return; }
  hs="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$1" 2>/dev/null || echo none)"
  case "$hs" in healthy) echo "running+healthy" ;; none) echo running ;; *) echo "$hs" ;; esac
}

wait_ready() {   # seconds, containers...: true when all are up (healthy where they have a health check)
  # Says what it is waiting for every 30 s, and stops early on a state that
  # will not change by itself: stopped, missing, unhealthy (Docker only says
  # unhealthy after the start period and all retries), restarting for 2 minutes
  local limit="$1" t=0 c s all now restarting=0; shift
  while (( t <= limit )); do
    all=yes; now=""
    for c in "$@"; do
      s="$(cstate "$c")"; now+=" ${c#patch01-}=$s"
      [[ "$s" == running+healthy || "$s" == running ]] || all=no
      case "$s" in
        exited|dead|missing|created|unhealthy)
          (( limit > 0 )) && say "  $c is $s: not waiting any longer"
          return 1 ;;
        restarting) restarting=$((restarting + 5)) ;;
      esac
    done
    [[ "$all" == yes ]] && return 0
    (( restarting >= 120 )) && { say "  a container keeps restarting:$now"; return 1; }
    (( limit > 0 && t > 0 && t % 30 == 0 )) && say "  waiting ${t}s/${limit}s:$now"
    sleep 5; t=$((t + 5))
  done
  return 1
}

why() {   # what is wrong, for the screen (states) and the log (last lines of each container's log)
  local c
  for c in "$@"; do
    say "    $c: $(cstate "$c")"
    docker logs --tail 25 "$c" >>"$LOG_FILE" 2>&1 || true
  done
}

# A time limit: Pulp's compose waits for its migrations, which must not hang the start forever
compose_up() { (cd "$COMPOSE_DIR" && timeout 900 docker compose -f "$1" up -d) >>"$LOG_FILE" 2>&1; }

# Pulp renamed TELEMETRY to ANALYTICS. Servers set up before r93 still have the
# old name, which a future Pulp would ignore (and send usage data). Fixed here,
# so it happens by itself at the next boot, update or start: nobody has to
# remember it. Idempotent; a backup is kept; Pulp restarts only if it changed.
PULP_SETTINGS="$PATCH_BASE/config/pulp/settings.py"
# Both names, both False: older Pulp reads only TELEMETRY, newer only ANALYTICS
# (the old name there just logs a deprecation warning). Off on every version.
pulp_settings_ok() {
  grep -qE '^ANALYTICS[[:space:]]*=[[:space:]]*False[[:space:]]*$' "$PULP_SETTINGS" \
    && grep -qE '^TELEMETRY[[:space:]]*=[[:space:]]*False[[:space:]]*$' "$PULP_SETTINGS" \
    && ! grep -qE '^(TELEMETRY|ANALYTICS)[[:space:]]*=[[:space:]]*True' "$PULP_SETTINGS"
}
fix_pulp_settings() {   # true when the file was changed
  [[ -f "$PULP_SETTINGS" ]] || return 1
  pulp_settings_ok && return 1
  local bk; bk="$PULP_SETTINGS.$(date +%Y%m%d-%H%M%S).bak"
  cp -a "$PULP_SETTINGS" "$bk" || { warn "could not back up $PULP_SETTINGS: left unchanged"; return 1; }
  # sed -i keeps the file's owner, group and mode (the Pulp containers read it as their group)
  sed -i -E -e '/^TELEMETRY[[:space:]]*=/d' -e '/^ANALYTICS[[:space:]]*=/d' "$PULP_SETTINGS"
  printf '\n# Never send usage data to the Pulp project (set by patch01-start.sh).\n# Both names: older Pulp reads TELEMETRY, newer ANALYTICS.\nTELEMETRY = False\nANALYTICS = False\n' >>"$PULP_SETTINGS"
  # settings.py is Python: never restart Pulp on a file it cannot read
  if pulp_settings_ok && python3 -c 'import ast,sys; ast.parse(open(sys.argv[1]).read())' "$PULP_SETTINGS" 2>>"$LOG_FILE"; then
    say "  Pulp settings updated: usage data off under both names (TELEMETRY, ANALYTICS). Backup: $bk"
    return 0
  fi
  cp -a "$bk" "$PULP_SETTINGS"
  warn "could not update $PULP_SETTINGS: put back as it was"
  return 1
}

FAILED=""
start_part() {   # name, compose file, seconds to wait, repair script, containers...
  local name="$1" file="$2" limit="$3" repair="$4"; shift 4
  step "$name"
  if [[ ! -f "$COMPOSE_DIR/$file" ]]; then
    warn "$COMPOSE_DIR/$file is missing: this part was never installed, or its files were removed. Run scripts/$repair."
    FAILED="$name"; return 1
  fi
  if wait_ready 0 "$@"; then say "  already up"; return 0; fi
  if compose_up "$file"; then
    if wait_ready "$limit" "$@"; then say "  up"; return 0; fi
  else
    warn "docker compose up failed or took over 15 minutes for $name (details in the log)"
  fi
  warn "$name did not come up within ${limit}s:"; why "$@"
  if [[ "$REPAIR" == yes ]]; then
    say "  repairing: re-running $repair (rebuilds this part from its saved settings)"
    if "$SCRIPTS/$repair" </dev/null >>"$LOG_FILE" 2>&1 && wait_ready "$limit" "$@"; then
      say "  up after the repair"; return 0
    fi
    warn "$name is still not up after re-running $repair:"; why "$@"
  fi
  FAILED="$name"; return 1
}

# ---------------------------------------------------------------------------
# 1. docker
# ---------------------------------------------------------------------------
step "docker"
systemctl is-enabled --quiet docker 2>/dev/null || { systemctl enable docker >/dev/null 2>&1; say "  enabled at boot (it was not)"; }
docker_ok() { timeout 20 docker info >/dev/null 2>&1; }
if ! systemctl is-active --quiet docker; then
  say "  not running: starting it"; systemctl start docker || true
fi
for i in $(seq 1 12); do docker_ok && break; sleep 5; done
if ! docker_ok; then
  say "  not answering: restarting it once"
  systemctl restart docker || true
  for i in $(seq 1 12); do docker_ok && break; sleep 5; done
fi
docker_ok || { journalctl -u docker --no-pager -n 40 >>"$LOG_FILE" 2>&1 || true
               die "docker does not start (its last messages are in $LOG_FILE). After an OS update: check 'systemctl status docker'."; }
docker compose version >/dev/null 2>&1 || die "The docker compose plugin is missing (an update may have removed it): dnf install docker-compose-plugin"
say "  running"

# ---------------------------------------------------------------------------
# 1b. the credentials vault (r103): when the credentials are in Vault, every
#     part below needs them, so Vault is unsealed and /patch/secrets filled first
# ---------------------------------------------------------------------------
if [[ -e /var/lib/patch01-vault/enabled ]]; then
  vrc=0; "$SCRIPTS/patch01-vault.sh" --boot </dev/null 8>&- || vrc=$?
  if (( vrc != 0 )); then
    (( vrc == 3 )) && die "Vault is sealed (manual mode): run $SCRIPTS/patch01-vault.sh --unseal (it then starts PATCH-01)."
    die "Vault did not start or could not fill /patch/secrets (see the patch01-vault log in $LOG_DIR)."
  fi
fi

# ---------------------------------------------------------------------------
# 2-7. the parts, in order
# ---------------------------------------------------------------------------
RC=0
if start_part "ingress (nginx)" docker-compose.yml 120 phase1a-ingress.sh patch01-nginx; then
  docker network inspect patchnet >/dev/null 2>&1 || { warn "the shared network patchnet is missing after the ingress started"; FAILED="network"; }
fi
[[ -z "$FAILED" ]] && start_part "data (PostgreSQL, Redis)" docker-compose.data.yml 180 phase1b-data.sh patch01-postgres patch01-redis || true
# Pulp's health checks: the old ones needed curl and pgrep in the image, failed
# on the content app's normal 404, and the worker's matched itself (r96).
# Deployed compose files are brought up to date here; compose then recreates
# the Pulp containers once.
fix_pulp_healthchecks() {   # true when the deployed file was changed
  local f="$COMPOSE_DIR/docker-compose.pulp.yml" t="$SCRIPTS/../compose/docker-compose.pulp.yml.tmpl" bk rc=0
  [[ -f "$f" && -f "$t" ]] || return 1
  # The new checks run python3 in the Pulp container: only switch if it is there
  docker exec patch01-pulp-api python3 -c 'pass' >/dev/null 2>&1 \
    || docker run --rm --network none --entrypoint python3 "$(awk '/^ *image:/ {print $2; exit}' "$f")" -c 'pass' >/dev/null 2>&1 \
    || { warn "python3 not found in the Pulp image: health checks left as they are"; return 1; }
  bk="$f.$(date +%Y%m%d-%H%M%S).bak"
  cp -a "$f" "$bk" || return 1
  python3 "$SCRIPTS/pulp-healthcheck-migrate.py" "$f" "$t" >>"$LOG_FILE" 2>&1 || rc=$?
  if (( rc == 1 )); then rm -f "$bk"; return 1; fi
  if (( rc == 0 )) && (cd "$COMPOSE_DIR" && docker compose -f "$f" config -q) >>"$LOG_FILE" 2>&1; then
    say "  Pulp health checks updated (no curl or pgrep needed; 404 accepted on the content app). Backup: $bk"
    return 0
  fi
  cp -a "$bk" "$f"; warn "could not update the Pulp health checks: put back as they were"
  return 1
}

if [[ -z "$FAILED" ]]; then
  fix_pulp_healthchecks || true    # compose up -d (below) recreates the containers when it changed
  if fix_pulp_settings; then
    # Running containers read settings.py only when they start, healthy or not yet
    say "  restarting Pulp to read it (the worker first finishes its current task: up to 5 minutes)"
    for c in patch01-pulp-api patch01-pulp-content patch01-pulp-worker; do
      [[ "$(docker inspect -f '{{.State.Running}}' "$c" 2>/dev/null)" == true ]] \
        && { docker restart "$c" >>"$LOG_FILE" 2>&1 || warn "could not restart $c"; }
    done
  fi
fi
[[ -z "$FAILED" ]] && start_part "pulp (mirrors)" docker-compose.pulp.yml 600 phase1c-pulp.sh patch01-pulp-api patch01-pulp-content patch01-pulp-worker || true
[[ -z "$FAILED" ]] && start_part "api and worker" docker-compose.api.yml 300 phase3b-api.sh patch01-api patch01-worker || true
[[ -z "$FAILED" ]] && start_part "dashboard" docker-compose.dashboard.yml 120 phase5-dashboard.sh patch01-dashboard || true
if [[ -z "$FAILED" ]] && docker inspect patch01-clamav >/dev/null 2>&1; then
  step "clamav (optional)"
  [[ "$(cstate patch01-clamav)" =~ ^running ]] || docker start patch01-clamav >>"$LOG_FILE" 2>&1 || true
  wait_ready 300 patch01-clamav && say "  up" || warn "ClamAV is not up (uploads are not malware-scanned until it is): scripts/phase11-clamav.sh"
fi

if [[ -n "$FAILED" ]]; then
  say ""
  say "STOPPED at: $FAILED. The parts after it were not started (they need it)."
  say "Details: $LOG_FILE"
  RC=1
else
  say ""
  say "Every part is up."
fi

if [[ "$HEALTH" == yes ]]; then
  step "Health check"
  # At boot, a post-update check may be running its own health check: wait for it
  HC_ARGS=(); [[ "$BOOT" == yes ]] && HC_ARGS=(--wait-lock)
  "$SCRIPTS/patch01-update.sh" "${HC_ARGS[@]}" </dev/null 8>&- || RC=1
fi
exit "$RC"
