"""Banned vCenter operations (r100).

PATCH-01 only ever takes, removes or reverts snapshots, powers a VM on, and asks
the guest OS to shut down or restart. Everything below is banned outright: every
vCenter connection PATCH-01 opens (read-only and write) is fitted with a guard
that refuses these calls before they leave PATCH-01, whatever the account's
rights in vCenter and whatever code calls them. Nothing in the console or the
API can switch it off.

It works at pyVmomi's single exit point: every vCenter method call goes through
the connection's SOAP stub (`stub.InvokeMethod(mo, info, args)`), with the
method's vCenter name in `info.wsdlName`. Property reads do not go through it.

`check_rights` reports which dangerous privileges an account holds in vCenter
(phase7-vmware.sh --add-writer / --check-writer), so the role can be tightened
there too: the guard protects against PATCH-01, the role against everything else.
"""
import logging
import re

log = logging.getLogger("patch01.vc_guard")

# By name. Grouped for reading; all equally banned.
BANNED = frozenset({
    # Deleting or removing VMs and other inventory (Destroy_Task works on any object)
    "Destroy_Task", "UnregisterVM", "UnregisterAndDestroy_Task", "UnregisterVApp_Task",
    # Hard power actions: PATCH-01 only asks the guest OS, through VMware Tools
    "PowerOffVM_Task", "ResetVM_Task", "SuspendVM_Task", "TerminateVM", "PowerOffVApp_Task", "SuspendVApp_Task",
    "PowerOnMultiVM_Task", "StandbyGuest",
    # Changing a VM's hardware, disks, location or identity
    "ReconfigVM_Task", "RelocateVM_Task", "MigrateVM_Task", "CloneVM_Task", "InstantClone_Task",
    "CreateVM_Task", "RegisterVM_Task", "MarkAsTemplate", "MarkAsVirtualMachine", "Rename_Task",
    "MoveIntoFolder_Task", "MoveInto_Task", "UpgradeVM_Task", "UpgradeTools_Task", "ResetGuestInformation",
    "ExtendVirtualDisk_Task", "ShrinkVirtualDisk_Task", "ZeroFillVirtualDisk_Task", "SetVirtualDiskUuid",
    "MoveVirtualDisk_Task", "CopyVirtualDisk_Task", "DefragmentVirtualDisk_Task",
    # Snapshot shortcuts that skip PATCH-01's own checks (single removal, and revert
    # with its safety snapshot, are the only snapshot actions)
    "RemoveAllSnapshots_Task", "RevertToCurrentSnapshot_Task",
    # Hosts, clusters and storage
    "ShutdownHost_Task", "RebootHost_Task", "PowerDownHostToStandBy_Task", "EnterMaintenanceMode_Task",
    "DisconnectHost_Task", "ReconfigureCluster_Task", "ReconfigureComputeResource_Task",
    "RemoveDatastore", "RemoveDatastoreEx_Task", "UnmountVmfsVolume", "UnmountVmfsVolumeEx_Task",
    "DetachScsiLun", "DetachScsiLunEx_Task", "UnmountForceMountedVmfsVolume", "MoveDatastoreFile_Task",
    # Permissions, roles and sessions
    "SetEntityPermissions", "RemoveEntityPermission", "ResetEntityPermissions", "MergePermissions",
    "AddAuthorizationRole", "UpdateAuthorizationRole", "RemoveAuthorizationRole", "TerminateSession",
    "UpdateOptions",
})

# By pattern: anything that deletes, wipes or formats, and every guest operation
# (running programs or touching files inside a VM)
BANNED_RE = re.compile(r"Delete|Erase|Wipe|Format|Unregister|InGuest(_Task)?$|Destroy_Task$")

# What PATCH-01 itself calls to change anything; a test keeps the code to these
ALLOWED_CHANGES = frozenset({"CreateSnapshot_Task", "RemoveSnapshot_Task", "RevertToSnapshot_Task",
                             "PowerOnVM_Task", "ShutdownGuest", "RebootGuest"})


class Banned(RuntimeError):
    """A banned vCenter operation was refused before it was sent."""


def why_banned(method):
    """The reason `method` (vCenter's name for it) is banned, or None when it is allowed."""
    m = str(method or "")
    if m in ALLOWED_CHANGES:
        return None
    if m in BANNED:
        return "on the banned list"
    if BANNED_RE.search(m):
        return "deletes, wipes, formats, or acts inside a VM"
    return None


def _method_name(info):
    return getattr(info, "wsdlName", None) or getattr(info, "name", None) or ""


def guard(si):
    """Fit the guard to a connection (pyVmomi ServiceInstance). Returns si."""
    stub = getattr(si, "_stub", None)
    real = getattr(stub, "InvokeMethod", None)
    if real is None:
        # Never seen with pyVmomi 6.7-8.x; logged loudly, the code-level rules still hold
        log.error("vCenter guard: this pyVmomi has no stub.InvokeMethod; banned calls are not checked at the connection")
        return si
    if getattr(real, "_patch01_guard", False):
        return si

    def invoke(mo, info, args, *more, **kw):
        name = _method_name(info)
        why = why_banned(name)
        if why:
            target = getattr(mo, "_moId", "?")
            log.error("BANNED vCenter call refused: %s on %s (%s)", name, target, why)
            raise Banned(f"PATCH-01 refused to send {name} to vCenter: it is banned ({why}). Nothing was done.")
        return real(mo, info, args, *more, **kw)
    invoke._patch01_guard = True
    stub.InvokeMethod = invoke
    return si


# ---------------------------------------------------------------------------
# What the account itself may do in vCenter
# ---------------------------------------------------------------------------

RISKY_PRIVILEGES = {
    "VirtualMachine.Inventory.Delete": "delete VMs",
    "VirtualMachine.Inventory.Unregister": "remove VMs from the inventory",
    "VirtualMachine.Config.RemoveDisk": "remove VM disks",
    "VirtualMachine.Config.EditDevice": "change VM hardware",
    "VirtualMachine.GuestOperations.Execute": "run programs inside VMs",
    "VirtualMachine.GuestOperations.Modify": "change files inside VMs",
    "VirtualMachine.Provisioning.MarkAsTemplate": "turn VMs into templates",
    "Datastore.DeleteFile": "delete files on datastores",
    "Folder.Delete": "delete folders",
    "Host.Config.Maintenance": "reboot or shut down ESXi hosts",
    "Authorization.ModifyPermissions": "change permissions",
    "Authorization.ModifyRoles": "change roles",
}
BATCH = 200
MAX_VMS = 20000


def check_rights(si):
    """Which risky privileges this connection's account holds on its VMs (and the root).
    {"checked": number of VMs looked at, "granted": {privilege: number of objects}, "error": text or None}"""
    out = {"checked": 0, "granted": {}, "error": None}
    try:
        from pyVmomi import vim
        content = si.RetrieveContent()
        key = content.sessionManager.currentSession.key
        view = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
        try:
            vms = list(view.view)[:MAX_VMS]
        finally:
            view.Destroy()
        out["checked"] = len(vms)
        privs = sorted(RISKY_PRIVILEGES)
        entities = [content.rootFolder] + vms
        for i in range(0, len(entities), BATCH):
            for ep in content.authorizationManager.HasPrivilegeOnEntities(
                    entity=entities[i:i + BATCH], sessionId=key, privId=privs) or []:
                for pa in getattr(ep, "privAvailability", None) or []:
                    if pa.isGranted:
                        out["granted"][pa.privId] = out["granted"].get(pa.privId, 0) + 1
    except Exception as e:  # noqa: BLE001 - a report, never a reason to fail
        out["error"] = f"{type(e).__name__}: {e}"[:300]
    return out


def rights_text(report):
    """The report in words, for the scripts."""
    if report.get("error"):
        return [f"Could not check the account's rights in vCenter ({report['error']}).",
                "Check its role by hand: it should hold only the privileges listed above."]
    if not report.get("granted"):
        return [f"OK: across {report.get('checked', 0)} VMs the account holds none of the dangerous rights."]
    lines = ["WARNING: in vCenter this account can also:"]
    for p, n in sorted(report["granted"].items()):
        lines.append(f"  - {RISKY_PRIVILEGES.get(p, p)}  ({p}, on {n} object(s))")
    lines += ["PATCH-01 refuses all of these itself (banned list), but anyone with this",
              "account's password could do them. Remove these privileges from its role in vCenter."]
    return lines
