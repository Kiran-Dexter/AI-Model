"""
PATCH-01 : removing VM snapshots chosen by name and age (change kind vm_snapshot_cleanup)

The operator filters snapshots across the vCenters (by name, by how old they
are, or both), sees every match, untick any to keep, confirms the count, and
schedules the removal as an ordinary change: approval, window, live log and
history like every other change.

Safety, in order:
  - search: snapshots in use by a change that is still to run or running (a
    patch job's own snapshot, another removal or revert) and VMs on a vCenter
    with no write account are shown but cannot be ticked
  - scheduling: every ticked snapshot is checked again against the inventory
    and the filter; the operator types the number of snapshots; the exact list
    (id, name, date) is frozen in the change
  - running: each snapshot is checked again on the VM itself just before it
    is removed: still there, same name, still matches the filter. Anything else
    is skipped with the reason. Only that one snapshot is removed: its children
    and the VM's current state are kept (vCenter merges its changes into them).

Pure functions here (filters, matching, planning) are tested without vCenter
or a database (tests/test_snapshot_cleanup.py).
"""

import fnmatch
import re
from datetime import datetime, timezone

NAME_MODES = {
    "any":      "any name",
    "contains": "name contains",
    "starts":   "name starts with",
    "exact":    "name is exactly",
    "pattern":  "name matches",
}
MAX_DAYS = 3650
MAX_SNAPSHOTS = 1000          # in one change
MAX_PER_VM = 100
MAX_RESULTS = 3000            # shown by a search
NAME_FILTER_RE = re.compile(r"^[^\x00-\x1f\x7f]{1,80}$")
VCENTER_RE = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
MOREF_RE = re.compile(r"^snapshot-\d+$")
ACTIVE_STATES = ("pending_approval", "scheduled", "running")


class FilterError(ValueError):
    """A filter or selection that cannot be used. The message is for the operator."""


# ---------------------------------------------------------------------------
# The filter
# ---------------------------------------------------------------------------

def norm_filter(raw):
    """Check and normalise a filter. At least one of name or age is required:
    'every snapshot everywhere' is never a filter."""
    raw = raw if isinstance(raw, dict) else {}
    mode = str(raw.get("name_mode") or "any")
    if mode not in NAME_MODES:
        raise FilterError("Choose how to match the name: any, contains, starts with, is exactly, or matches a pattern.")
    name = str(raw.get("name") or "").strip()
    if mode == "any":
        name = ""
    elif not NAME_FILTER_RE.match(name):
        raise FilterError("Type the name to match (1 to 80 characters).")
    if mode == "pattern" and not any(c in name for c in "*?["):
        raise FilterError("A pattern needs * (any text) or ? (one character), e.g. 'Before patch*'.")

    days = raw.get("older_than_days")
    if days in (None, "", False):
        days = None
    else:
        try:
            days = int(str(days).strip())
        except (TypeError, ValueError):
            raise FilterError("'Older than' must be a whole number of days.")
        if not 1 <= days <= MAX_DAYS:
            raise FilterError(f"'Older than' must be between 1 and {MAX_DAYS} days.")
    if mode == "any" and days is None:
        raise FilterError("Filter by name, by age, or both: every snapshot everywhere is not offered.")
    if mode == "pattern" and days is None and not re.sub(r"\[[^\]]*\]|[*?\[\]]", "", name).strip():
        raise FilterError("A pattern of only * and ? matches every snapshot: add some text "
                          "(e.g. 'Before patch*') or an age.")

    vc = str(raw.get("vcenter") or "").strip() or None
    if vc and not VCENTER_RE.match(vc):
        raise FilterError("Unknown vCenter.")
    vm = str(raw.get("vm") or "").strip()[:80] or None
    return {"name_mode": mode, "name": name, "older_than_days": days, "vcenter": vc, "vm": vm}


def describe(f):
    """The filter in words, for the change record."""
    parts = []
    if f["name_mode"] != "any":
        parts.append(f"{NAME_MODES[f['name_mode']]} '{f['name']}'")
    if f["older_than_days"]:
        parts.append(f"older than {f['older_than_days']} day" + ("" if f["older_than_days"] == 1 else "s"))
    if f.get("vcenter"):
        parts.append(f"on {f['vcenter']}")
    if f.get("vm"):
        parts.append(f"VM name contains '{f['vm']}'")
    return ", ".join(parts)


def name_matches(f, name):
    """Case does not matter for any mode."""
    mode, want, have = f["name_mode"], (f["name"] or "").casefold(), (name or "").casefold()
    if mode == "any":
        return True
    if mode == "contains":
        return want in have
    if mode == "starts":
        return have.startswith(want)
    if mode == "exact":
        return have == want
    if mode == "pattern":
        return fnmatch.fnmatchcase(have, want)
    return False


def parse_created(v):
    if not v:
        return None
    if isinstance(v, datetime):
        return v if v.tzinfo else v.replace(tzinfo=timezone.utc)
    try:
        t = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except ValueError:
        return None
    return t if t.tzinfo else t.replace(tzinfo=timezone.utc)


def age_days(created, now):
    t = parse_created(created)
    if t is None:
        return None
    return (now - t).total_seconds() / 86400.0


def snapshot_matches(f, snap, now):
    """(matches, why not). A snapshot with no known date never matches an age
    filter: unknown is never treated as old enough."""
    if not name_matches(f, snap.get("name")):
        return False, "the name does not match"
    if f["older_than_days"]:
        a = age_days(snap.get("created"), now)
        if a is None:
            return False, "its creation date is not known"
        if a < f["older_than_days"]:
            return False, f"it is only {int(a)} day(s) old"
    return True, None


# ---------------------------------------------------------------------------
# Snapshots in use elsewhere
# ---------------------------------------------------------------------------

def in_use(conn):
    """{(vcenter, snapshot_moref): 'CHG-000123'} for snapshots that a change still
    to run, or running, depends on: a patch job's own snapshot, a single removal
    or revert, or another snapshot removal."""
    from .changes import ref
    out = {}
    for r in conn.execute(
            """SELECT c.number, c.kind::text AS kind, c.params, ct.vcenter, ct.target_key, ct.snapshot_moref
                 FROM changes c JOIN change_targets ct ON ct.change_id = c.id
                WHERE c.state::text = ANY(%s)""", (list(ACTIVE_STATES),)).fetchall():
        tag = ref(r["number"])
        p = r["params"] if isinstance(r["params"], dict) else {}
        if r["snapshot_moref"]:
            out[(r["vcenter"], r["snapshot_moref"])] = tag
        if r["kind"] in ("vm_snapshot_remove", "vm_snapshot_revert") and p.get("snapshot_moref"):
            out[(r["vcenter"], p["snapshot_moref"])] = tag
        if r["kind"] == "vm_snapshot_cleanup":
            for s in (p.get("selection") or {}).get(r["target_key"], []):
                if isinstance(s, dict) and s.get("moref"):
                    out[(r["vcenter"], s["moref"])] = tag
    return out


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

def search(conn, raw_filter, writers, now=None):
    """Every snapshot matching the filter, newest VM data from the inventory.
    `writers` is the set of vCenters with a write account."""
    f = norm_filter(raw_filter)
    now = now or datetime.now(timezone.utc)
    busy = in_use(conn)
    sql = """SELECT vcenter, moref, name, power_state, snapshots, synced_at
               FROM vm_inventory WHERE snapshot_count > 0"""
    args = []
    if f["vcenter"]:
        sql += " AND vcenter = %s"
        args.append(f["vcenter"])
    if f["vm"]:
        sql += " AND name ILIKE %s"
        args.append("%" + f["vm"].replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
    sql += " ORDER BY vcenter, name"
    matches, vms, truncated = [], set(), False
    for v in conn.execute(sql, args).fetchall():
        for s in v["snapshots"] or []:
            if not isinstance(s, dict) or not s.get("moref"):
                continue
            ok, _ = snapshot_matches(f, s, now)
            if not ok:
                continue
            if len(matches) >= MAX_RESULTS:
                truncated = True
                break
            blocked = None
            if v["vcenter"] not in writers:
                blocked = f"no write account for {v['vcenter']}"
            elif (v["vcenter"], s["moref"]) in busy:
                blocked = f"in use by {busy[(v['vcenter'], s['moref'])]}"
            a = age_days(s.get("created"), now)
            matches.append({
                "vcenter": v["vcenter"], "vm_moref": v["moref"], "vm": v["name"],
                "power_state": v["power_state"], "synced_at": v["synced_at"],
                "snapshot_moref": s["moref"], "name": s.get("name") or "",
                "description": (s.get("description") or "")[:200], "created": s.get("created"),
                "age_days": None if a is None else int(a), "current": bool(s.get("current")),
                "depth": int(s.get("depth") or 0), "quiesced": bool(s.get("quiesced")),
                "blocked": blocked,
            })
            vms.add((v["vcenter"], v["moref"]))
        if truncated:
            break
    return {"filter": f, "described": describe(f), "matches": matches,
            "vms": len(vms), "selectable": sum(1 for m in matches if not m["blocked"]),
            "blocked": sum(1 for m in matches if m["blocked"]), "truncated": truncated,
            "max_per_change": MAX_SNAPSHOTS}


# ---------------------------------------------------------------------------
# Scheduling: the ticked snapshots, checked again and frozen in the change
# ---------------------------------------------------------------------------

def validate(conn, raw_params, targets, writers, now=None):
    """`targets` come from changes._validate_vms (each with its _snapshots).
    Returns the params stored in the change."""
    now = now or datetime.now(timezone.utc)
    p = raw_params if isinstance(raw_params, dict) else {}
    f = norm_filter(p.get("filter"))
    sel = p.get("selection")
    if not isinstance(sel, dict) or not sel:
        raise FilterError("Tick at least one snapshot to remove.")
    by_key = {t["target_key"]: t for t in targets}
    extra = [k for k in sel if k not in by_key]
    if extra:
        raise FilterError("Snapshots were ticked on a VM that is not in the change.")
    busy = in_use(conn)
    out, total = {}, 0
    for t in targets:
        chosen = sel.get(t["target_key"])
        if not isinstance(chosen, list) or not chosen:
            raise FilterError(f"{t['label']}: no snapshot ticked. Leave the VM out instead.")
        if len(chosen) > MAX_PER_VM:
            raise FilterError(f"{t['label']}: at most {MAX_PER_VM} snapshots per VM in one change.")
        if f["vcenter"] and t["vcenter"] != f["vcenter"]:
            raise FilterError(f"{t['label']} is on {t['vcenter']}, outside the filter ({f['vcenter']}). Search again.")
        if f["vm"] and f["vm"].casefold() not in (t["label"] or "").casefold():
            raise FilterError(f"{t['label']} does not match the VM filter ('{f['vm']}'). Search again.")
        if t["vcenter"] not in writers:
            raise FilterError(f"No write account for {t['vcenter']}: snapshots there cannot be removed. "
                              f"On PATCH-01: ./scripts/phase7-vmware.sh --add-writer {t['vcenter']}")
        known = {s.get("moref"): s for s in t.get("_snapshots") or [] if isinstance(s, dict)}
        items, seen = [], set()
        for m in chosen:
            m = str(m or "")
            if not MOREF_RE.match(m) or m in seen:
                raise FilterError(f"{t['label']}: a ticked snapshot was not recognised.")
            seen.add(m)
            s = known.get(m)
            if s is None:
                raise FilterError(f"{t['label']}: a ticked snapshot is no longer on the VM. Search again.")
            ok, why = snapshot_matches(f, s, now)
            if not ok:
                raise FilterError(f"{t['label']}: '{s.get('name')}' no longer matches the filter ({why}). Search again.")
            if (t["vcenter"], m) in busy:
                raise FilterError(f"{t['label']}: '{s.get('name')}' is in use by {busy[(t['vcenter'], m)]}.")
            items.append({"moref": m, "name": s.get("name") or "", "created": s.get("created")})
        items.sort(key=lambda x: x["created"] or "")
        out[t["target_key"]] = items
        total += len(items)
    if total > MAX_SNAPSHOTS:
        raise FilterError(f"At most {MAX_SNAPSHOTS} snapshots in one change: narrow the filter or split it.")
    try:
        confirm = int(p.get("confirm_count"))
    except (TypeError, ValueError):
        confirm = None
    if confirm != total:
        raise FilterError(f"Type the number of snapshots to remove ({total}) to confirm.")
    return {"filter": f, "described": describe(f), "selection": out, "total": total, "vms": len(out)}


def target_params(params, target_key):
    """What the vCenter call for one VM gets: the filter and that VM's snapshots."""
    return {"filter": params["filter"], "snapshots": (params.get("selection") or {}).get(target_key, [])}


# ---------------------------------------------------------------------------
# Running: decide each snapshot again against the VM itself
# ---------------------------------------------------------------------------

def plan_removal(f, chosen, live, now):
    """[(chosen item, 'remove' | 'skip', reason)] in the frozen order. `live` is
    the VM's snapshot list read from vCenter just now (vmware.flatten_snapshots)."""
    by_ref = {s.get("moref"): s for s in live or [] if isinstance(s, dict)}
    plan = []
    for c in chosen or []:
        s = by_ref.get(c.get("moref"))
        if s is None:
            plan.append((c, "skip", "already removed"))
            continue
        if (s.get("name") or "") != (c.get("name") or ""):
            plan.append((c, "skip", f"renamed to '{s.get('name')}' since it was chosen"))
            continue
        ok, why = snapshot_matches(f, s, now)
        if not ok:
            plan.append((c, "skip", f"no longer matches the filter ({why})"))
            continue
        plan.append((c, "remove", None))
    return plan


def outcome(result):
    """Target state and message for a VM's result."""
    removed = result.get("removed") or []
    skipped = result.get("skipped") or []
    failed = result.get("failed") or []
    n = len(removed) + len(skipped) + len(failed)
    msg = f"removed {len(removed)} of {n} snapshot(s)"
    if skipped:
        msg += "; skipped " + ", ".join(f"'{s['name']}' ({s['reason']})" for s in skipped[:5])
    if failed:
        msg += "; failed " + ", ".join(f"'{s['name']}' ({s['error']})" for s in failed[:5])
    if failed and not removed:
        return "failed", msg
    if failed:
        return "done_with_warnings", msg + f" ({len(failed)} failed: check them in vCenter)"
    if failed or skipped:
        return "done_with_warnings", msg
    return "done", msg
