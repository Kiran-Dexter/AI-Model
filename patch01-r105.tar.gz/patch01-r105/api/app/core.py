"""
PATCH-01 : patch platform API

Endpoints fall into three groups:

  /api/v1/agent/*   called by agents on managed hosts, bearer-token auth
  /api/v1/admin/*   called by operators, basic auth
  /api/v1/health    unauthenticated liveness

Design notes:

  * Agents authenticate with a per-host bearer token obtained by redeeming a
    single-use enrollment token. Only the SHA-256 of each token is stored, so
    a database dump does not yield working credentials.

  * The agent may only submit data about ITSELF. The host identity comes from
    the authenticated token, never from the request body, so agent A cannot
    overwrite agent B's inventory.

  * Commands returned to agents are a bounded verb plus JSON parameters.
    There is no endpoint that accepts or returns a shell command.

  * Inventory replaces the package set wholesale inside a transaction. A diff
    based approach loses packages removed outside the agent's knowledge.

  * Package versions are stored as separate epoch/version/release columns.
    Epoch is parsed explicitly because dropping it silently inverts version
    comparisons later.
"""


import hashlib


import ipaddress


import json


import logging


import os


import re


import secrets


import time


import uuid


from contextlib import contextmanager


from datetime import datetime, timedelta, timezone


from typing import Any, Dict, List, Optional


import psycopg


from psycopg.rows import dict_row


from psycopg_pool import ConnectionPool


from fastapi import (Body, Depends, FastAPI, File, Form, Header, HTTPException,
                     Request, Response, UploadFile, status)


from fastapi.responses import PlainTextResponse


from fastapi.responses import JSONResponse


from fastapi.security import HTTPBasic, HTTPBasicCredentials


from pydantic import BaseModel, Field, field_validator


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")


logging.basicConfig(
    level=LOG_LEVEL,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)


log = logging.getLogger("patchapi")


DB_HOST = os.environ.get("PATCHDB_HOST", "postgres")


DB_PORT = int(os.environ.get("PATCHDB_PORT", "5432"))


DB_NAME = os.environ.get("PATCHDB_NAME", "patchdb")


DB_USER = os.environ.get("PATCHDB_USER", "patchapi")


DB_PASS = os.environ.get("PATCHDB_PASSWORD", "")


ADMIN_USER = os.environ.get("ADMIN_USER", "admin")


ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")


# A host is online if it checked in within this many minutes. Agents check in
# every 5 minutes with up to a minute of jitter, so 15 tolerates two misses.
ONLINE_MINUTES = int(os.environ.get("ONLINE_MINUTES", "15"))


# Bounds on submitted data. A host reporting 200k packages is a bug or an
# attack, not a real inventory.
MAX_PACKAGES = int(os.environ.get("MAX_PACKAGES", "20000"))


MIN_PLAUSIBLE_PACKAGES = 50


ENROLL_TOKEN_TTL_HOURS = int(os.environ.get("ENROLL_TOKEN_TTL_HOURS", "24"))


app = FastAPI(
    title="PATCH-01 Patch Platform API",
    version="1.0.0",
    docs_url="/api/v1/docs",
    openapi_url="/api/v1/openapi.json",
)


from fastapi.exceptions import RequestValidationError  # noqa: E402


@app.exception_handler(RequestValidationError)
async def _validation_error(request: Request, exc: RequestValidationError):
    """A rejected field is reported by name and reason only: never echo what
    was sent, which may be a password or an API key."""
    errs = [{k: e.get(k) for k in ("loc", "msg", "type") if k in e} for e in exc.errors()]
    return JSONResponse(status_code=422, content={"detail": errs})


pool: Optional[ConnectionPool] = None


@app.on_event("startup")
def startup() -> None:
    global pool
    conninfo = (
        f"host={DB_HOST} port={DB_PORT} dbname={DB_NAME} "
        f"user={DB_USER} password={DB_PASS} connect_timeout=10"
    )
    pool = ConnectionPool(conninfo, min_size=2, max_size=int(os.environ.get("PATCHDB_POOL_MAX", "16")), open=True,
                          kwargs={"row_factory": dict_row})
    log.info("connected to %s@%s:%s/%s", DB_USER, DB_HOST, DB_PORT, DB_NAME)
    from . import auth
    try:
        with pool.connection() as conn:
            if auth.bootstrap_admin(conn, ADMIN_PASSWORD):
                log.info("created the admin user from ADMIN_PASSWORD")
    except Exception as e:  # noqa: BLE001 - schema 009 may not be applied yet
        log.warning("could not bootstrap the admin user: %s", e)


@app.on_event("shutdown")
def shutdown() -> None:
    if pool:
        pool.close()


@contextmanager
def db():
    if pool is None:
        raise HTTPException(status_code=503, detail="database pool not ready")
    with pool.connection() as conn:
        yield conn


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def sha256(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def now() -> datetime:
    return datetime.now(timezone.utc)


UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")


def uuid_or_404(value, detail: str = "not found") -> str:
    """A path id for a uuid column, lower-cased; anything else is a 404 (as
    deploy.ID_RE does) rather than a database error and a 500."""
    v = str(value or "").strip().lower()
    if not UUID_RE.match(v):
        raise HTTPException(status_code=404, detail=detail)
    return v


def client_ip(request: Request) -> Optional[str]:
    """Real client address: the peer NGINX itself saw.

    NGINX is the only thing that can reach this service and sets
    X-Real-IP to $remote_addr, overwriting anything the client sent. The
    client CAN put anything in X-Forwarded-For (NGINX appends to it), so the
    leftmost XFF entry is never trusted: it would let anyone forge audit and
    session addresses and the agent_ip used for VM and Nessus matching.
    Fallback order: X-Real-IP, then the rightmost XFF entry (the one NGINX
    appended), then the socket peer.
    """
    def _ip(v):
        v = (v or "").strip()
        try:
            return str(ipaddress.ip_address(v)) if v else None
        except ValueError:
            return None

    real = _ip(request.headers.get("x-real-ip"))
    if real:
        return real
    xff = request.headers.get("x-forwarded-for")
    if xff:
        right = _ip(xff.split(",")[-1])
        if right:
            return right
    return request.client.host if request.client else None


def audit(conn, actor: str, actor_type: str, action: str,
          host_id: Optional[str] = None, object_type: Optional[str] = None,
          object_id: Optional[str] = None, detail: Optional[Dict] = None,
          source_ip: Optional[str] = None) -> None:
    """Append to the audit log. Never raises: a failed audit write must not
    silently succeed, but it also must not lose the caller's work, so it is
    logged loudly and re-raised only on programming errors."""
    conn.execute(
        """INSERT INTO audit_log
             (actor, actor_type, action, host_id, object_type, object_id,
              detail, source_ip)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
        (actor, actor_type, action, host_id, object_type, object_id,
         json.dumps(detail or {}), source_ip),
    )


NEVRA_RE = re.compile(r"^[A-Za-z0-9._+\-~^]+$")


def parse_evr(version_string: str) -> tuple:
    """Split an RPM or DEB version string into (epoch, version, release).

    Epoch is returned explicitly, defaulting to 0 rather than None, because
    a dropped epoch silently inverts comparisons. RPM release is the part
    after the last '-'; DEB revision is treated the same way.
    """
    s = (version_string or "").strip()
    epoch = 0
    if ":" in s:
        head, _, s = s.partition(":")
        try:
            epoch = int(head)
        except ValueError:
            epoch = 0
    if "-" in s:
        version, _, release = s.rpartition("-")
    else:
        version, release = s, ""
    return epoch, version, release


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------


basic = HTTPBasic(auto_error=False)


def _challenge(request: Request) -> dict:
    # The dashboard has its own sign-in form. Sending WWW-Authenticate to it
    # would also pop the browser's native dialog, so omit it for its requests.
    return ({} if request.headers.get("x-requested-with") == "patch01-dashboard"
            else {"WWW-Authenticate": "Basic"})


def mfa_exempt() -> set:
    """Script accounts (TWO_FACTOR_EXEMPT, comma separated, set by root in the API's
    environment file): not asked to set up two-factor sign-in when REQUIRE_2FA is on.
    Their use is audited on every request with HTTP Basic."""
    raw = os.environ.get("TWO_FACTOR_EXEMPT", "")
    return {x.strip() for x in raw.split(",") if re.fullmatch(r"[A-Za-z0-9._-]{1,64}", x.strip())}


def _resolve_user(request: Request, creds: Optional[HTTPBasicCredentials]) -> dict:
    """The signed-in user, from a session token (the console) or HTTP Basic
    (scripts on PATCH-01). Both are checked against the users table."""
    from . import auth
    header = request.headers.get("authorization") or ""
    with db() as conn:
        if header.lower().startswith("bearer "):
            u = auth.session_user(conn, header[7:].strip())
            if u:
                return u
            raise HTTPException(status_code=401, detail="Your session has ended. Sign in again.",
                                headers=_challenge(request))
        if creds is not None:
            try:
                u = auth.authenticate(conn, creds.username, creds.password)
            except auth.LoginError as e:
                conn.commit()                      # the failure count is kept (account lock)
                raise HTTPException(status_code=401, detail=str(e), headers=_challenge(request))
            if u.get("totp_enabled") and u["username"] not in mfa_exempt():
                # A password alone never signs in an account that has two-factor sign-in
                raise HTTPException(status_code=401, headers=_challenge(request),
                                    detail="This account uses two-factor sign-in: HTTP Basic is refused for it. "
                                           "Use the console, or a script account listed in TWO_FACTOR_EXEMPT.")
            return u
    raise HTTPException(status_code=401, detail="authentication required",
                        headers=_challenge(request))


# Which module each part of the API belongs to. A user needs at least one of
# the listed modules (admins have all). Paths not listed here need no module:
# sign-in, the user's own account, admin pages (role-checked), the assistant
# (which filters its own queries by module), and the public sign-in data.
MODULE_RULES = [
    # E-mailing: each report checks its own modules (report_jobs.allowed); a table goes only to configured recipients
    (re.compile(r"^/api/v1/reports/(email|email-options|email-table)$"), {"patch", "inventory", "lifecycle"}),
    # Installed software lives under Software now: inventory or lifecycle users see it
    (re.compile(r"^/api/v1/inventory/software(/|$)"), {"inventory", "lifecycle"}),
    (re.compile(r"^/api/v1/software/(removable|remove|lifecycle)(/|$)"), {"inventory", "lifecycle"}),
    (re.compile(r"^/api/v1/inventory/"), {"inventory"}),
    (re.compile(r"^/api/v1/admin/vmware/"), {"inventory", "patch"}),
    (re.compile(r"^/api/v1/(software|admin/software|deploy)(/|$)"), {"lifecycle"}),
    # Which kinds of change each module may see and make is checked per change (_change_ok)
    (re.compile(r"^/api/v1/changes(/|$)"), {"patch", "inventory", "lifecycle"}),
    # inventory: vm_* change logs; console_stream still checks each change (_change_ok)
    (re.compile(r"^/api/v1/console/stream$"), {"patch", "inventory", "lifecycle"}),
    (re.compile(r"^/api/v1/admin/compliance$"), {"patch", "lifecycle"}),
    (re.compile(r"^/api/v1/admin/hosts/[^/]+/software$"), {"patch", "inventory", "lifecycle"}),
    (re.compile(r"^/api/v1/admin/audit$"), {"patch", "inventory", "lifecycle"}),
    (re.compile(r"^/api/v1/antivirus(/|$)"), {"inventory", "patch"}),
    (re.compile(r"^/api/v1/(admin/(hosts|advisories|agent-updates|assessments|compliance|"
                r"fleet-summary|llm|server-groups)|hardening|reports|wsus|dashboard|impact|servers|server-groups|patch-reports|installed-patches|nessus|overview)(/|$)"), {"patch"}),
]


def _kind_modules(kind):
    """The modules that may see and make a change of this kind."""
    if kind == "software":
        return {"lifecycle"}
    if str(kind).startswith("vm_"):
        return {"patch", "inventory"}
    return {"patch"}


def _change_ok(request, kind):
    from . import auth
    if not (_kind_modules(kind) & set(auth.user_modules(request.state.user))):
        raise HTTPException(403, "Your account does not have access to this kind of change. Ask an admin (Admin > Access).")


def _agent_update_ok(request, kind):
    # New code running as SYSTEM or root on every chosen server: admins only
    if kind == "agent_update" and (request.state.user or {}).get("role") != "admin":
        raise HTTPException(403, "Updating agents needs the admin role.")
    # Restarting servers outside a patch job: admins only
    if kind == "restart" and (request.state.user or {}).get("role") != "admin":
        raise HTTPException(403, "Restarting servers needs the admin role.")


def _removal_ok(request, kind, params):
    # Removing software from servers, by its own uninstaller or with a Deployment package: admins only
    if kind == "software" and isinstance(params, dict) \
            and (params.get("source") == "installed" or (params.get("source") == "package" and params.get("action") == "uninstall")) \
            and (request.state.user or {}).get("role") != "admin":
        raise HTTPException(403, "Removing software needs the admin role.")


def _allowed_kinds(request):
    from . import auth
    mods = set(auth.user_modules(request.state.user))
    kinds = ["patch", "software", "agent_update", "restart", "vm_snapshot_create", "vm_snapshot_remove",
             "vm_snapshot_cleanup", "vm_snapshot_revert",
             "vm_power_on", "vm_guest_shutdown", "vm_guest_restart"]
    return [k for k in kinds if _kind_modules(k) & mods]


def module_for_path(path):
    for rx, mods in MODULE_RULES:
        if rx.match(path):
            return mods
    return None


def _require(needed: str):
    """A dependency admitting users whose role is at least `needed`, and who
    may use the module the requested path belongs to.
    Returns the username, which endpoints record as the actor."""
    from . import auth

    def dep(request: Request, creds: Optional[HTTPBasicCredentials] = Depends(basic)) -> str:
        u = _resolve_user(request, creds)
        if u.get("must_change_password") and not request.url.path.startswith("/api/v1/auth/"):
            raise HTTPException(status_code=403, detail="password_change_required")
        from . import mfa
        if mfa.REQUIRE_2FA and not u.get("totp_enabled") and u["username"] not in mfa_exempt() \
                and not request.url.path.startswith("/api/v1/auth/"):
            raise HTTPException(status_code=403, detail="two_factor_setup_required")
        if not auth.role_at_least(u["role"], needed):
            raise HTTPException(status_code=403,
                                detail=f"This needs the {needed} role; you are signed in as {u['role']}.")
        mods = module_for_path(request.url.path)
        if mods and not (mods & set(auth.user_modules(u))):
            raise HTTPException(status_code=403,
                                detail="Your account does not have access to this part of the console. "
                                       "Ask an admin (Admin > Access).")
        request.state.user = u
        return u["username"]
    return dep


require_viewer = _require("viewer")


require_operator = _require("operator")


require_admin = _require("admin")


class AgentIdentity(BaseModel):
    host_id: str
    hostname: str
    host_group: str


def require_agent(
    request: Request,
    authorization: Optional[str] = Header(default=None),
) -> AgentIdentity:
    """Resolve the calling agent from its bearer token.

    The host identity comes from here and nowhere else. No endpoint accepts a
    host_id from the request body, which is what prevents one agent writing
    another's data.
    """
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="bearer token required")
    token = authorization[7:].strip()
    if not token:
        raise HTTPException(status_code=401, detail="empty token")

    th = sha256(token)
    with db() as conn:
        row = conn.execute(
            """SELECT id, hostname, host_group, status
                 FROM hosts
                WHERE token_hash = %s""",
            (th,),
        ).fetchone()

        if not row:
            raise HTTPException(status_code=401, detail="unknown or revoked token")
        if row["status"] == "decommissioned":
            raise HTTPException(status_code=403, detail="host is decommissioned")

        return AgentIdentity(
            host_id=str(row["id"]),
            hostname=row["hostname"],
            host_group=row["host_group"] or "default",
        )


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class EnrollRequest(BaseModel):
    enrollment_token: str = Field(min_length=16, max_length=128)
    machine_id: str = Field(min_length=8, max_length=128)
    hostname: str = Field(min_length=1, max_length=253)
    fqdn: Optional[str] = Field(default=None, max_length=253)
    os_id: str = Field(max_length=32)
    os_version: str = Field(max_length=32)
    arch: str = Field(max_length=16)
    pkg_manager: str = Field(max_length=8)
    agent_version: str = Field(max_length=32)
    # Agent 1.9.2-win / 1.8.1 and later: the SMBIOS (VM BIOS) UUID, so a re-enrolment of an active
    # server is accepted only from the same machine, never from a copy holding its machine ID
    hardware_uuid: Optional[str] = Field(default=None, max_length=36, pattern=r"^[0-9a-fA-F-]{32,36}$")

    @field_validator("hostname", "fqdn")
    @classmethod
    def valid_hostname(cls, v):
        if v is None:
            return v
        # Lowercase and validate: uppercase hostnames break TLS SAN matching
        # and some apt tooling later.
        v = v.strip().lower()
        if not re.match(r"^[a-z0-9]([a-z0-9.\-]{0,251}[a-z0-9])?$", v):
            raise ValueError("invalid hostname")
        return v

    @field_validator("pkg_manager")
    @classmethod
    def valid_pkg_manager(cls, v):
        if v not in ("dnf", "yum", "apt", "wua"):
            raise ValueError("pkg_manager must be dnf, yum, apt or wua")
        return v

    @field_validator("os_id")
    @classmethod
    def valid_os(cls, v):
        v = v.strip().lower()
        if not re.match(r"^[a-z0-9_\-]+$", v):
            raise ValueError("invalid os_id")
        return v


class EnrollResponse(BaseModel):
    host_id: str
    agent_token: str
    checkin_interval_sec: int


class PackageIn(BaseModel):
    name: str = Field(max_length=256)
    version: str = Field(max_length=128)
    arch: str = Field(default="noarch", max_length=32)
    from_repo: Optional[str] = Field(default=None, max_length=128)
    install_time: Optional[datetime] = None          # agent 1.8.2+: when this version was installed

    @field_validator("name", "arch")
    @classmethod
    def safe_chars(cls, v):
        if not NEVRA_RE.match(v):
            raise ValueError(f"unsafe characters in {v!r}")
        return v


class UpdateItemIn(BaseModel):
    """One update the server's package manager would install now (agent 1.8.2+)."""
    name: str = Field(max_length=256)
    arch: str = Field(default="noarch", max_length=32)
    installed: Optional[str] = Field(default=None, max_length=128)
    available: str = Field(max_length=128)
    repo: Optional[str] = Field(default=None, max_length=128)
    security: Optional[bool] = None
    advisory: Optional[str] = Field(default=None, max_length=64)
    severity: Optional[str] = Field(default=None, max_length=32)

    @field_validator("name", "arch")
    @classmethod
    def safe_name(cls, v):
        if not NEVRA_RE.match(v):
            raise ValueError(f"unsafe characters in {v!r}")
        return v

    @field_validator("installed", "available")
    @classmethod
    def safe_version(cls, v):
        # Versions carry an epoch (1:3.0.7-27.el9, 1:8.9p1-3ubuntu0.10)
        if v is not None and not UPDATE_VER_RE.match(v):
            raise ValueError(f"unsafe characters in {v!r}")
        return v


UPDATE_VER_RE = re.compile(r"^[0-9][A-Za-z0-9._+~^:\-]{0,127}$")


class UpdatesIn(BaseModel):
    checked_at: datetime
    items: List[UpdateItemIn] = Field(default_factory=list, max_length=5000)
    error: Optional[str] = Field(default=None, max_length=500)
    source: Optional[str] = Field(default=None, max_length=64)


def _updates_from(raw):
    """The agent's update list, checked item by item: an item that does not pass is left
    out (and a malformed list is ignored), never the whole inventory refused for it."""
    if not isinstance(raw, dict):
        return None
    items = []
    for it in (raw.get("items") or [])[:5000] if isinstance(raw.get("items"), list) else []:
        try:
            items.append(UpdateItemIn.model_validate(it))
        except Exception:  # noqa: BLE001 - one odd line from a package manager
            continue
    try:
        return UpdatesIn(checked_at=raw.get("checked_at"), items=items,
                         error=(str(raw["error"])[:500] if raw.get("error") else None),
                         source=(str(raw.get("source"))[:64] if raw.get("source") else None))
    except Exception:  # noqa: BLE001
        return None


class InventoryIn(BaseModel):
    collected_at: datetime
    kernel_running: str = Field(max_length=128)
    kernel_latest: Optional[str] = Field(default=None, max_length=128)
    reboot_required: bool = False
    reboot_reason: Optional[str] = Field(default=None, max_length=512)
    os_version: Optional[str] = Field(default=None, max_length=32)
    agent_version: Optional[str] = Field(default=None, max_length=32)
    duration_ms: Optional[int] = None
    boot_time: Optional[datetime] = None
    hardware_uuid: Optional[str] = Field(default=None, max_length=36,
                                         pattern=r"^[0-9a-fA-F-]{32,36}$")
    packages: List[PackageIn]
    updates: Optional[Dict[str, Any]] = None          # checked by _updates_from, item by item

    @field_validator("packages")
    @classmethod
    def bounded(cls, v):
        if len(v) > MAX_PACKAGES:
            raise ValueError(f"too many packages ({len(v)} > {MAX_PACKAGES})")
        if not v:
            raise ValueError("package list is empty")
        return v


class CheckinIn(BaseModel):
    agent_version: Optional[str] = Field(default=None, max_length=32)
    kernel_running: Optional[str] = Field(default=None, max_length=128)
    reboot_required: Optional[bool] = None
    # Agent 1.1.0+. Optional so older agents keep working unchanged.
    boot_time: Optional[datetime] = None
    # Agent 1.2.0+: links the server to its VM in vCenter
    hardware_uuid: Optional[str] = Field(default=None, max_length=36,
                                         pattern=r"^[0-9a-fA-F-]{32,36}$")
    # Linux 1.8.3+ / Windows 1.9.5+: whether agent updates must carry the offline
    # release signature (pinned), are checked by SHA-256 only (none), or are all
    # refused because the pinned key cannot be used (invalid)
    release_key: Optional[str] = Field(default=None, max_length=16, pattern=r"^(none|pinned|invalid)$")
    # Linux 1.8.5+: a check-in run by hand (patch-agent checkin, setup-agent.sh), not the start of a run
    manual: Optional[bool] = None


class CommandOut(BaseModel):
    id: str
    verb: str
    params: Dict[str, Any]
    job_id: Optional[str] = None


class CommandResultIn(BaseModel):
    ok: bool
    result: Dict[str, Any] = Field(default_factory=dict)
    # Free-form message, bounded so a runaway agent cannot fill the database
    message: Optional[str] = Field(default=None, max_length=8192)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


@app.get("/api/v1/health")
def health():
    try:
        with db() as conn:
            conn.execute("SELECT 1").fetchone()
        return {"status": "ok", "database": "connected"}
    except Exception as e:
        log.error("health check failed: %s", e)
        return JSONResponse(
            status_code=503,
            content={"status": "degraded", "database": "unreachable"},
        )


# ---------------------------------------------------------------------------
# Shared by several areas (moved here when main.py was split, r90)
# ---------------------------------------------------------------------------

def jsonable(obj):
    """Dates, decimals and addresses as JSON-friendly values."""
    return json.loads(json.dumps(obj, default=lambda o: o.isoformat() if hasattr(o, "isoformat") else str(o)))


OS_LABEL_SQL = """CASE
    WHEN h.os_id = 'windows' THEN coalesce(nullif(regexp_replace(h.os_edition, '^Microsoft ', ''), ''), 'Windows')
    WHEN h.os_id = 'rhel' THEN 'RHEL ' || coalesce(h.os_major::text, split_part(h.os_version, '.', 1))
    WHEN h.os_id = 'ol' THEN 'Oracle Linux ' || coalesce(h.os_major::text, split_part(h.os_version, '.', 1))
    WHEN h.os_id = 'ubuntu' THEN 'Ubuntu ' || coalesce(h.os_version, '')
    ELSE coalesce(h.os_id, 'unknown') || ' ' || coalesce(h.os_version, '') END"""


_PUBLIC_CACHE = {}
_PUBLIC_TTL = 120
_PUBLIC_FAIL_TTL = 15
import threading as _threading  # noqa: E402
_PUBLIC_LOCK = _threading.Lock()


def _public_cached(key, build, ttl=None):
    """Answers built at most every two minutes (or ttl seconds), whoever asks
    and however often: one request builds while the others wait and then share
    it, and a failure is remembered briefly too. So neither the sign-in page
    nor many open dashboards can load the database."""
    import time as _t
    ttl = _PUBLIC_TTL if ttl is None else ttl
    hit = _PUBLIC_CACHE.get(key)
    if hit and _t.monotonic() - hit[0] < (ttl if hit[2] else _PUBLIC_FAIL_TTL):
        if not hit[2]:
            raise HTTPException(503, "Temporarily unavailable.")
        return hit[1]
    with _PUBLIC_LOCK:
        hit = _PUBLIC_CACHE.get(key)          # built by another request while we waited
        if hit and _t.monotonic() - hit[0] < (ttl if hit[2] else _PUBLIC_FAIL_TTL):
            if not hit[2]:
                raise HTTPException(503, "Temporarily unavailable.")
            return hit[1]
        try:
            val = build()
        except HTTPException:
            raise
        except Exception:  # noqa: BLE001 - remembered briefly, so a broken database is not hammered
            _PUBLIC_CACHE[key] = (_t.monotonic(), None, False)
            raise HTTPException(503, "Temporarily unavailable.")
        _PUBLIC_CACHE[key] = (_t.monotonic(), val, True)
        return val


EMAIL_RE = r"^[^@\s,;<>]+@[^@\s,;<>]+\.[^@\s,;<>]+$"


# ---------------------------------------------------------------------------
# Audit helper
# ---------------------------------------------------------------------------


def _audit(conn, actor, action, obj_type, obj_id, detail, ip, actor_type="user"):
    conn.execute(
        """INSERT INTO audit_log (actor, actor_type, action, object_type, object_id, detail, source_ip)
           VALUES (%s,%s,%s,%s,%s,%s,%s)""",
        (actor, actor_type, action, obj_type, str(obj_id), json.dumps(detail), ip))


ASSET_PERMS = ("approve", "decom", "revoke")


def _asset_perms(conn, u):
    """What this user may do to assets: admins everything, others what an
    admin ticked in Admin > Access."""
    if u.get("role") == "admin":
        return list(ASSET_PERMS)
    try:
        with conn.transaction():
            r = conn.execute("SELECT asset_perms FROM users WHERE username = %s AND active", (u["username"],)).fetchone()
    except psycopg.errors.UndefinedColumn:
        return []
    return [p for p in ((r or {}).get("asset_perms") or []) if p in ASSET_PERMS]
