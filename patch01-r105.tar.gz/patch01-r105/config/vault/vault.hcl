# PATCH-01 credentials vault (r103). Copied to /patch/vault/config by patch01-vault.sh.
#
# Storage: Vault's own encrypted files (barrier: AES-256-GCM). Unreadable without
# the unseal keys.
storage "file" {
  path = "/vault/file"
}

# A Unix socket only: no TCP listener, so nothing on the network can reach it.
listener "unix" {
  address     = "/vault/sock/vault.sock"
  socket_mode = "0600"
}

# The container is not given IPC_LOCK; swap is the host's concern (see README)
disable_mlock = true
ui            = false
log_level     = "warn"
