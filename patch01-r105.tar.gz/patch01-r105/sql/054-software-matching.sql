-- ---------------------------------------------------------------------------
-- PATCH-01 : schema 054 - matching uploaded packages to installed programs (r105)
--
-- Which installed program (as Programs and Features names it, with its
-- publisher) is the product of an uploaded package is decided by
-- api/app/swmatch.py from the evidence both sides carry. Where the evidence is
-- not enough, an operator says "same" or "different", or AI-01 is asked; those
-- verdicts are kept here, per package. An operator's verdict wins over AI-01's.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS deploy_match (
    package_id      UUID NOT NULL REFERENCES deploy_packages(id) ON DELETE CASCADE,
    prog_name       TEXT NOT NULL,                       -- exactly as the servers report it
    prog_publisher  TEXT NOT NULL DEFAULT '',
    source          TEXT NOT NULL CHECK (source IN ('operator', 'ai')),
    verdict         TEXT NOT NULL CHECK (verdict IN ('same', 'different')),
    confidence      REAL CHECK (confidence IS NULL OR (confidence >= 0 AND confidence <= 1)),
    reason          TEXT,
    decided_by      TEXT,
    decided_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (package_id, prog_name, prog_publisher, source)
);

-- Asking AI-01 about the uncertain matches: done by the worker, like the description
ALTER TABLE deploy_packages ADD COLUMN IF NOT EXISTS match_ai_state TEXT NOT NULL DEFAULT 'off'
    CHECK (match_ai_state IN ('off', 'pending', 'done', 'failed'));
ALTER TABLE deploy_packages ADD COLUMN IF NOT EXISTS match_ai_error TEXT;
ALTER TABLE deploy_packages ADD COLUMN IF NOT EXISTS match_ai_at TIMESTAMPTZ;

INSERT INTO schema_version (version, description)
VALUES (54, 'Matching uploaded packages to installed programs (deploy_match)')
ON CONFLICT (version) DO NOTHING;
