-- ---------------------------------------------------------------------------
-- PATCH-01 : schema 053 - remove VM snapshots by name or age (r99)
--
-- A new kind of change: snapshots chosen by a name and/or age filter across
-- many VMs, each checked again on the VM just before it is removed
-- (api/app/snapshot_cleanup.py). Nothing else changes.
--
-- ADD VALUE runs inside phase3a's transaction (PostgreSQL 12+); the new value
-- is not used in this file.
-- ---------------------------------------------------------------------------

ALTER TYPE change_kind ADD VALUE IF NOT EXISTS 'vm_snapshot_cleanup';

INSERT INTO schema_version (version, description)
VALUES (53, 'Remove VM snapshots by name or age (change kind vm_snapshot_cleanup)')
ON CONFLICT (version) DO NOTHING;
