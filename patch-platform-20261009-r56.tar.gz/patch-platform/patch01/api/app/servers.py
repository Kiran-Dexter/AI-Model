"""The Servers page: every server with an agent, its agent state and patch
position, filtered and paged on the server (20 a page), plus the facets the
filters offer and the full filtered list for export.

Filters are validated here and passed as parameters: nothing from the
request is ever put into the SQL text.
"""

import re

PAGE_SIZE = 20
EXPORT_MAX = 5000
AGENT_STATES = ("online", "offline", "not_reporting", "no_data")
PATCH_STATES = ("needs_patch", "needs_reboot", "up_to_date")
SORTS = {
    "name": "lower(hostname)",
    "agent": "CASE agent WHEN 'online' THEN 1 ELSE 0 END, lower(hostname)",
    "last_seen": "last_checkin DESC NULLS LAST",
    "patches": "needs_patch DESC, windows_updates_missing DESC, lower(hostname)",
    "os": "os_label, lower(hostname)",
}
NAME_RE = re.compile(r"^[A-Za-z0-9 ._()/+-]{1,80}$")

OS_LABEL = """CASE
    WHEN h.os_id = 'windows' THEN coalesce(nullif(regexp_replace(h.os_edition, '^Microsoft ', ''), ''), 'Windows')
    WHEN h.os_id = 'rhel' THEN 'RHEL ' || coalesce(h.os_major::text, split_part(h.os_version, '.', 1))
    WHEN h.os_id = 'ol' THEN 'Oracle Linux ' || coalesce(h.os_major::text, split_part(h.os_version, '.', 1))
    WHEN h.os_id = 'ubuntu' THEN 'Ubuntu ' || coalesce(h.os_version, '')
    ELSE coalesce(h.os_id, 'unknown') || ' ' || coalesce(h.os_version, '') END"""

BASE = f"""
WITH s AS (
  SELECT h.id::text AS host_id, h.hostname, h.fqdn, h.os_id, h.os_version, h.os_edition,
         {OS_LABEL} AS os_label, h.host_group, h.agent_version, host(h.agent_ip) AS agent_ip,
         agent_state(h.last_checkin, h.status) AS agent, h.last_checkin, h.last_inventory, h.enrolled_at,
         h.boot_time, CASE WHEN h.boot_time IS NOT NULL
                           THEN extract(epoch FROM now() - h.boot_time)::bigint END AS uptime_seconds,
         h.kernel_running, h.reboot_required, h.reboot_reason, h.wu_source, h.wu_searched_at,
         (SELECT count(*) FROM host_applicability ha WHERE ha.host_id = h.id AND ha.state = 'affected') AS needs_patch,
         (SELECT count(*) FROM host_applicability ha WHERE ha.host_id = h.id AND ha.state = 'fixed_pending_reboot') AS pending_reboot,
         (SELECT count(*) FROM windows_updates wu WHERE wu.host_id = h.id) AS windows_updates_missing,
         (SELECT max(r.max_cvss) FROM host_applicability ha JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id
           WHERE ha.host_id = h.id AND ha.state = 'affected') AS worst_cvss,
         (SELECT bool_or(coalesce(r.any_kev, false)) FROM host_applicability ha JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id
           WHERE ha.host_id = h.id AND ha.state = 'affected') AS exploited,
         (SELECT v.vcenter FROM vm_inventory v WHERE v.host_id = h.id LIMIT 1) AS vcenter,
         (SELECT v.cluster FROM vm_inventory v WHERE v.host_id = h.id LIMIT 1) AS cluster,
         (SELECT v.power_state FROM vm_inventory v WHERE v.host_id = h.id LIMIT 1) AS power,
         (SELECT round(l.score) FROM v_hardening_latest l WHERE l.host_id = h.id
           ORDER BY l.finished_at DESC NULLS LAST LIMIT 1) AS hardening_score
    FROM hosts h
   WHERE h.status <> 'decommissioned')
SELECT * FROM s
 WHERE (%(q)s::text IS NULL OR strpos(lower(hostname || ' ' || coalesce(fqdn, '') || ' ' || coalesce(agent_ip, '')), lower(%(q)s::text)) > 0)
   AND (%(os)s::text IS NULL OR os_label = %(os)s::text)
   AND (%(group)s::text IS NULL OR host_group = %(group)s::text)
   AND (%(version)s::text IS NULL OR coalesce(agent_version, 'unknown') = %(version)s::text)
   AND (%(agent)s::text IS NULL
        OR (%(agent)s::text = 'offline' AND agent <> 'online')
        OR agent = %(agent)s::text)
   AND (%(patch)s::text IS NULL
        OR (%(patch)s::text = 'needs_patch' AND (needs_patch > 0 OR windows_updates_missing > 0))
        OR (%(patch)s::text = 'needs_reboot' AND (reboot_required OR pending_reboot > 0))
        OR (%(patch)s::text = 'up_to_date' AND needs_patch = 0 AND windows_updates_missing = 0
            AND NOT reboot_required AND pending_reboot = 0))
"""


def clean_filters(q=None, os=None, group=None, version=None, agent=None, patch=None):
    """Validated filters; anything malformed is ignored, never passed on."""
    def name(v):
        v = (v or "").strip()
        return v if v and NAME_RE.match(v) else None
    q = (q or "").strip()
    return {
        "q": q[:80] if q and re.fullmatch(r"[A-Za-z0-9 ._:-]{1,80}", q) else None,
        "os": name(os), "group": name(group), "version": name(version),
        "agent": agent if agent in AGENT_STATES else None,
        "patch": patch if patch in PATCH_STATES else None,
    }


def page(conn, filters, page_no=1, size=PAGE_SIZE, sort="agent"):
    order = SORTS.get(sort, SORTS["agent"])
    total = conn.execute("SELECT count(*) AS n FROM (" + BASE + ") x", filters).fetchone()["n"]
    pages = max(1, (total + size - 1) // size)
    page_no = max(1, min(int(page_no or 1), pages))
    rows = conn.execute(BASE + f" ORDER BY {order} LIMIT %(limit)s OFFSET %(offset)s",
                        dict(filters, limit=size, offset=(page_no - 1) * size)).fetchall()
    return {"total": total, "page": page_no, "pages": pages, "size": size, "rows": rows}


def all_rows(conn, filters, sort="name"):
    order = SORTS.get(sort, SORTS["name"])
    return conn.execute(BASE + f" ORDER BY {order} LIMIT %(limit)s", dict(filters, limit=EXPORT_MAX)).fetchall()


def facets(conn):
    """The values each filter offers, with counts, over all servers."""
    none = clean_filters()
    rows = conn.execute("SELECT os_label, host_group, coalesce(agent_version, 'unknown') AS version, agent, "
                        "needs_patch, windows_updates_missing, reboot_required, pending_reboot FROM (" + BASE + ") x",
                        none).fetchall()

    def count(key):
        out = {}
        for r in rows:
            k = r[key] or "(none)"
            out[k] = out.get(k, 0) + 1
        return [{"value": k, "n": v} for k, v in sorted(out.items(), key=lambda kv: (-kv[1], kv[0]))]
    online = sum(1 for r in rows if r["agent"] == "online")
    return {
        "os": count("os_label"), "group": count("host_group"), "version": count("version"),
        "agent": {"online": online, "offline": len(rows) - online,
                  **{s: sum(1 for r in rows if r["agent"] == s) for s in AGENT_STATES}},
        "patch": {
            "needs_patch": sum(1 for r in rows if r["needs_patch"] or r["windows_updates_missing"]),
            "needs_reboot": sum(1 for r in rows if r["reboot_required"] or r["pending_reboot"]),
            "up_to_date": sum(1 for r in rows if not (r["needs_patch"] or r["windows_updates_missing"]
                                                       or r["reboot_required"] or r["pending_reboot"])),
        },
        "total": len(rows),
    }


EXPORT_COLUMNS = [
    ("hostname", "Server"), ("agent", "Agent"), ("os_label", "Operating system"), ("host_group", "Group"),
    ("agent_version", "Agent version"), ("agent_ip", "Address"), ("last_checkin", "Last seen"),
    ("needs_patch", "Advisories to install"), ("windows_updates_missing", "Windows updates missing"),
    ("pending_reboot", "Installed, reboot needed"), ("reboot_required", "Reboot pending"),
    ("worst_cvss", "Worst CVSS"), ("exploited", "Exploited CVE"), ("kernel_running", "Running kernel"),
    ("uptime_seconds", "Uptime (days)"), ("hardening_score", "Hardening score"),
    ("vcenter", "vCenter"), ("cluster", "Cluster"), ("power", "Power"), ("fqdn", "FQDN"),
]


def export_value(key, v):
    if v is None:
        return ""
    if key == "uptime_seconds":
        return round(int(v) / 86400, 1)
    if key == "agent":
        return "online" if v == "online" else "offline (" + str(v).replace("_", " ") + ")" if v != "offline" else "offline"
    if isinstance(v, bool):
        return "yes" if v else "no"
    if hasattr(v, "isoformat"):
        return v.strftime("%Y-%m-%d %H:%M")
    return v


def describe_filters(f):
    words = {"q": "name contains", "os": "OS", "group": "group", "version": "agent version",
             "agent": "agent", "patch": "patch state"}
    parts = [f"{words[k]} {str(v).replace('_', ' ')}" for k, v in f.items() if v]
    return "; ".join(parts) or "all servers"
