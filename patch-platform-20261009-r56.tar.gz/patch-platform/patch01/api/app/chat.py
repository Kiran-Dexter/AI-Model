"""
PATCH-01 : the assistant

Answers questions about the whole estate in plain language (Linux and Windows
servers, CVEs, changes, VMware, WSUS, hardening, inventory), exports what it
found as CSV, and drafts an e-mail of it. Operators and admins only.

How it works, and why it is safe:

  * The model is asked to choose ONE prepared query and its parameters, and
    nothing else. It never writes SQL, never sees the database, never sees a
    row of data, and never supplies a number that appears in an answer. So
    text stored in the database (a host name, a program name, a CVE
    description) cannot instruct the model: the model never reads it.
  * Every query below is fixed, parameterised and read-only. There is no
    path from this module to an UPDATE, INSERT or DELETE.
  * Parameters are validated against a type and a range before use, so a
    confused or manipulated model cannot widen a query beyond its shape.
  * The reply is worded here, from the rows returned, and the rows are shown
    alongside it. A wrong choice produces a visibly wrong table, not a lie.
  * Export and e-mail are detected from the question by this code, not by
    the model. An export re-runs the same validated query on the server. An
    e-mail is only ever a draft here: it is sent when a person presses Send,
    to recipients the server allows, and the server re-runs the query itself
    rather than trusting data sent back by the browser.
  * If the model is unreachable or answers nonsense, a keyword fallback
    picks the query, so the assistant still works without AI-01.

Changing servers is deliberately absent. Patching, snapshots, power and
software actions go through the approval flow, never from a typed sentence.
"""

import csv
import io
import json
import logging
import re

log = logging.getLogger("patchapi.chat")

MAX_ROWS = 60            # shown in the chat
EXPORT_ROWS = 5000       # in an export or an e-mail attachment
MAX_QUESTION = 400

CVE_IN_TEXT = re.compile(r"\bCVE[-–_ ]?(\d{4})[-–_ ]?(\d{4,7})\b", re.I)
KB_IN_TEXT = re.compile(r"\bKB ?(\d{6,8})\b", re.I)
CHG_IN_TEXT = re.compile(r"\b(?:CHG[- ]?0*(\d{1,9})|change (?:number |no\.? |#)?0*(\d{1,9}))\b", re.I)
EMAIL_IN_TEXT = re.compile(r"[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9-]{1,63}(?:\.[A-Za-z0-9-]{1,63})+")
WORD_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{1,62}")

HOST_MATCH = """(lower(h.hostname) = lower(%(hostname)s::text)
                 OR lower(split_part(h.hostname, '.', 1)) = lower(split_part(%(hostname)s::text, '.', 1)))"""


# ---------------------------------------------------------------------------
# The complete set of things the assistant can ask the database
# ---------------------------------------------------------------------------
#   what    one line, shown to the model and to the operator
#   params  name -> (type, default); validated before use
#   needs   parameters with no sensible default
#   sql     fixed, parameterised, read-only     (or)
#   fn      a read-only Python function (conn, args, limit) -> rows
# Every placeholder carries an explicit type: an untyped NULL makes
# PostgreSQL refuse the query ("could not determine data type of parameter").
# ---------------------------------------------------------------------------

TOOLS = {
    # ---- the fleet --------------------------------------------------------
    "fleet_summary": {
        "what": "Overall counts: servers, Linux and Windows, agents online, servers needing patches or a reboot.",
        "params": {},
        "sql": """SELECT count(*) AS servers,
                         count(*) FILTER (WHERE os_id <> 'windows') AS linux,
                         count(*) FILTER (WHERE os_id = 'windows')  AS windows,
                         count(*) FILTER (WHERE agent_state(last_checkin, status) = 'online') AS agents_online,
                         count(*) FILTER (WHERE agent_state(last_checkin, status) IN ('offline','not_reporting','no_data')) AS agents_not_online,
                         count(*) FILTER (WHERE EXISTS (SELECT 1 FROM host_applicability ha
                                                         WHERE ha.host_id = hosts.id AND ha.state = 'affected')
                                             OR EXISTS (SELECT 1 FROM windows_updates wu WHERE wu.host_id = hosts.id)) AS need_patches,
                         count(*) FILTER (WHERE reboot_required) AS awaiting_reboot
                    FROM hosts WHERE status <> 'decommissioned'""",
    },
    "servers_list": {
        "what": "List servers with an agent, optionally by OS or group: OS, group, agent state and version, address.",
        "params": {"os_id": ("os", None), "host_group": ("name", None)},
        "sql": """SELECT h.hostname, coalesce(h.os_edition, h.os_id || ' ' || coalesce(h.os_version,'')) AS os,
                         h.host_group, agent_state(h.last_checkin, h.status) AS agent, h.agent_version,
                         host(h.agent_ip) AS ip, h.last_checkin, h.reboot_required
                    FROM hosts h
                   WHERE h.status <> 'decommissioned'
                     AND (%(os_id)s::text IS NULL OR h.os_id = %(os_id)s::text)
                     AND (%(host_group)s::text IS NULL OR h.host_group = %(host_group)s::text)
                   ORDER BY h.hostname LIMIT %(limit)s::int""",
    },
    "host_detail": {
        "what": "One server: OS, kernel, agent, uptime, address, and how many patches it needs.",
        "params": {"hostname": ("name", None)},
        "needs": ["hostname"],
        "sql": """SELECT h.hostname, coalesce(h.os_edition, h.os_id || ' ' || coalesce(h.os_version,'')) AS os,
                         h.os_id, h.kernel_running, h.reboot_required, h.host_group,
                         agent_state(h.last_checkin, h.status) AS agent, h.agent_version,
                         host(h.agent_ip) AS ip, h.last_checkin, h.boot_time,
                         (SELECT count(*) FROM host_applicability ha WHERE ha.host_id = h.id AND ha.state = 'affected') AS needs_patch,
                         (SELECT count(*) FROM host_applicability ha WHERE ha.host_id = h.id AND ha.state = 'fixed_pending_reboot') AS needs_reboot,
                         (SELECT count(*) FROM windows_updates wu WHERE wu.host_id = h.id) AS windows_updates_missing
                    FROM hosts h
                   WHERE h.status <> 'decommissioned' AND """ + HOST_MATCH,
    },
    "host_pending_updates": {
        "what": "Patches still to install on one server (Linux advisories, or missing Windows updates).",
        "params": {"hostname": ("name", None)},
        "needs": ["hostname"],
        "sql": """SELECT * FROM (
                    SELECT 'advisory' AS kind, ha.advisory_id AS update, a.title, a.severity,
                           ha.package_name AS package, ha.installed_evr AS installed, ha.fixed_evr AS fixed_in,
                           CASE ha.state WHEN 'affected' THEN 'to install' ELSE 'installed, needs reboot' END AS status
                      FROM hosts h
                      JOIN host_applicability ha ON ha.host_id = h.id AND ha.state IN ('affected','fixed_pending_reboot')
                      LEFT JOIN advisories a ON a.id = ha.advisory_id
                     WHERE h.status <> 'decommissioned' AND h.os_id <> 'windows' AND """ + HOST_MATCH + """
                    UNION ALL
                    SELECT 'windows update', coalesce(wu.kb, wu.update_id), wu.title, wu.severity,
                           NULL, NULL, NULL,
                           CASE WHEN wu.downloaded THEN 'to install (downloaded)' ELSE 'to install' END
                      FROM hosts h JOIN windows_updates wu ON wu.host_id = h.id
                     WHERE h.status <> 'decommissioned' AND """ + HOST_MATCH + """
                  ) x
                  ORDER BY CASE lower(coalesce(severity,'')) WHEN 'critical' THEN 1 WHEN 'important' THEN 2
                           WHEN 'moderate' THEN 3 ELSE 4 END, update
                  LIMIT %(limit)s::int""",
    },
    "host_installed_patches": {
        "what": "Patches already installed on one server (advisories it is fixed for).",
        "params": {"hostname": ("name", None)},
        "needs": ["hostname"],
        "sql": """SELECT ha.advisory_id AS update, a.title, a.severity, a.issued_at,
                         ha.package_name AS package, ha.installed_evr AS installed
                    FROM hosts h
                    JOIN host_applicability ha ON ha.host_id = h.id AND ha.state = 'fixed_active'
                    LEFT JOIN advisories a ON a.id = ha.advisory_id
                   WHERE h.status <> 'decommissioned' AND """ + HOST_MATCH + """
                   ORDER BY a.issued_at DESC NULLS LAST, ha.advisory_id
                   LIMIT %(limit)s::int""",
    },
    "host_software": {
        "what": "Software or packages installed on one server, optionally only names containing a word.",
        "params": {"hostname": ("name", None), "name": ("text", None)},
        "needs": ["hostname"],
        "sql": """SELECT * FROM (
                    SELECT ws.name, ws.version, ws.publisher, ws.installed_on::text AS installed
                      FROM hosts h JOIN windows_software ws ON ws.host_id = h.id
                     WHERE h.status <> 'decommissioned' AND """ + HOST_MATCH + """
                       AND (%(name)s::text IS NULL OR strpos(lower(ws.name), lower(%(name)s::text)) > 0)
                    UNION ALL
                    SELECT hp.name, concat_ws('-', hp.version, hp.release), hp.from_repo, hp.install_time::date::text
                      FROM hosts h JOIN host_packages hp ON hp.host_id = h.id
                     WHERE h.status <> 'decommissioned' AND """ + HOST_MATCH + """
                       AND (%(name)s::text IS NULL OR strpos(lower(hp.name), lower(%(name)s::text)) > 0)
                  ) x ORDER BY lower(name) LIMIT %(limit)s::int""",
    },
    "software_search": {
        "what": "Which servers have a program or package installed, and which versions (name contains a word).",
        "params": {"name": ("text", None)},
        "needs": ["name"],
        "sql": """SELECT * FROM (
                    SELECT h.hostname, 'windows' AS platform, ws.name, ws.version, ws.publisher
                      FROM windows_software ws JOIN hosts h ON h.id = ws.host_id AND h.status <> 'decommissioned'
                     WHERE strpos(lower(ws.name), lower(%(name)s::text)) > 0
                    UNION ALL
                    SELECT h.hostname, 'linux', hp.name, concat_ws('-', hp.version, hp.release), hp.from_repo
                      FROM host_packages hp JOIN hosts h ON h.id = hp.host_id AND h.status <> 'decommissioned'
                     WHERE strpos(lower(hp.name), lower(%(name)s::text)) > 0
                  ) x ORDER BY lower(name), version, hostname LIMIT %(limit)s::int""",
    },
    "agents_by_state": {
        "what": "Servers whose agent is offline, not reporting, online, or has never reported.",
        "params": {"state": ("agent_state", "offline")},
        "sql": """SELECT hostname, coalesce(os_edition, os_id || ' ' || coalesce(os_version,'')) AS os,
                         agent_state(last_checkin, status) AS agent,
                         last_checkin, agent_version, host_group
                    FROM hosts
                   WHERE status <> 'decommissioned'
                     AND agent_state(last_checkin, status) = %(state)s::text
                   ORDER BY last_checkin NULLS FIRST
                   LIMIT %(limit)s::int""",
    },
    "agent_versions": {
        "what": "How many servers run each agent version, per operating system.",
        "params": {},
        "sql": """SELECT CASE WHEN os_id = 'windows' THEN 'windows' ELSE 'linux' END AS platform,
                         coalesce(agent_version, 'unknown') AS agent_version, count(*) AS servers
                    FROM hosts WHERE status <> 'decommissioned'
                   GROUP BY 1, 2 ORDER BY 1, 2 DESC LIMIT %(limit)s::int""",
    },
    "reboot_pending": {
        "what": "Servers waiting for a reboot to finish patching.",
        "params": {},
        "sql": """SELECT hostname, coalesce(os_edition, os_id || ' ' || coalesce(os_version,'')) AS os,
                         reboot_reason, boot_time, host_group
                    FROM hosts WHERE status <> 'decommissioned' AND reboot_required
                   ORDER BY boot_time NULLS FIRST LIMIT %(limit)s::int""",
    },

    # ---- patches and CVEs -------------------------------------------------
    "hosts_needing_patch": {
        "what": "Servers that need patches, optionally by OS (rhel, ol, ubuntu, windows), group, or only exploited CVEs.",
        "params": {"os_id": ("os", None), "host_group": ("name", None), "exploited_only": ("bool", False)},
        "sql": """SELECT h.hostname, coalesce(h.os_edition, h.os_id || ' ' || coalesce(h.os_version,'')) AS os,
                         h.host_group,
                         count(DISTINCT ha.advisory_id) AS advisories_outstanding,
                         (SELECT count(*) FROM windows_updates wu WHERE wu.host_id = h.id) AS windows_updates_missing,
                         max(r.max_cvss) AS worst_cvss,
                         bool_or(coalesce(r.any_kev, false)) AS any_exploited
                    FROM hosts h
                    LEFT JOIN host_applicability ha ON ha.host_id = h.id AND ha.state = 'affected'
                    LEFT JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id
                   WHERE h.status <> 'decommissioned'
                     AND (%(os_id)s::text IS NULL OR h.os_id = %(os_id)s::text)
                     AND (%(host_group)s::text IS NULL OR h.host_group = %(host_group)s::text)
                   GROUP BY h.id, h.hostname, h.os_edition, h.os_id, h.os_version, h.host_group
                  HAVING (count(ha.advisory_id) > 0
                          OR (NOT %(exploited_only)s::boolean
                              AND EXISTS (SELECT 1 FROM windows_updates wu WHERE wu.host_id = h.id)))
                     AND (NOT %(exploited_only)s::boolean OR bool_or(coalesce(r.any_kev, false)))
                   ORDER BY any_exploited DESC, advisories_outstanding DESC, windows_updates_missing DESC
                   LIMIT %(limit)s::int""",
    },
    "hosts_affected_by_cve": {
        "what": "Which servers are affected by one CVE.",
        "params": {"cve_id": ("cve", None)},
        "needs": ["cve_id"],
        "sql": """SELECT h.hostname, coalesce(h.os_edition, h.os_id || ' ' || coalesce(h.os_version,'')) AS os,
                         ha.state, ha.advisory_id AS advisory, ha.package_name AS package,
                         ha.installed_evr AS installed, ha.fixed_evr AS fixed_in, h.host_group
                    FROM advisory_cves ac
                    JOIN host_applicability ha ON ha.advisory_id = ac.advisory_id
                    JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'
                   WHERE ac.cve_id = %(cve_id)s::text
                   ORDER BY CASE ha.state WHEN 'affected' THEN 1
                              WHEN 'fixed_pending_reboot' THEN 2 ELSE 3 END, h.hostname
                   LIMIT %(limit)s::int""",
    },
    "cve_summary": {
        "what": "Published facts about one CVE: score, attack type, whether it is exploited, how many servers need it.",
        "params": {"cve_id": ("cve", None)},
        "needs": ["cve_id"],
        "sql": """SELECT cd.cve_id, cd.cvss_score, cd.cvss_severity, cd.attack_class,
                         cd.kev AS exploited_in_wild, cd.kev_due, cd.epss, cd.published, cd.description,
                         cd.rh_severity,
                         (SELECT count(DISTINCT ha.host_id)
                            FROM advisory_cves ac2
                            JOIN host_applicability ha ON ha.advisory_id = ac2.advisory_id
                           WHERE ac2.cve_id = cd.cve_id AND ha.state = 'affected') AS servers_affected
                    FROM cve_details cd WHERE cd.cve_id = %(cve_id)s::text""",
    },
    "exploited_cves": {
        "what": "CVEs known to be exploited in the wild that still affect servers.",
        "params": {},
        "sql": """SELECT cd.cve_id, cd.cvss_score, cd.attack_class, cd.kev_due,
                         count(DISTINCT ha.host_id) AS servers_affected
                    FROM cve_details cd
                    JOIN advisory_cves ac ON ac.cve_id = cd.cve_id
                    JOIN host_applicability ha ON ha.advisory_id = ac.advisory_id AND ha.state = 'affected'
                   WHERE cd.kev
                   GROUP BY cd.cve_id, cd.cvss_score, cd.attack_class, cd.kev_due
                   ORDER BY servers_affected DESC, cd.cvss_score DESC NULLS LAST
                   LIMIT %(limit)s::int""",
    },
    "top_cves": {
        "what": "The most serious CVEs still affecting servers, at or above a CVSS score (default 9).",
        "params": {"min_cvss": ("score", 9.0)},
        "sql": """SELECT cd.cve_id, cd.cvss_score, cd.kev AS exploited_in_wild, cd.attack_class,
                         count(DISTINCT ha.host_id) AS servers_affected
                    FROM cve_details cd
                    JOIN advisory_cves ac ON ac.cve_id = cd.cve_id
                    JOIN host_applicability ha ON ha.advisory_id = ac.advisory_id AND ha.state = 'affected'
                   WHERE coalesce(cd.cvss_score, 0) >= %(min_cvss)s::numeric
                   GROUP BY cd.cve_id, cd.cvss_score, cd.kev, cd.attack_class
                   ORDER BY cd.kev DESC, cd.cvss_score DESC NULLS LAST, servers_affected DESC
                   LIMIT %(limit)s::int""",
    },
    "recent_advisories": {
        "what": "Advisories and Windows updates published in the last N days (default 30), optionally by severity or OS, with servers affected.",
        "params": {"days": ("int", 30), "severity": ("severity", None), "os_id": ("os", None)},
        "sql": """SELECT a.id AS advisory, a.vendor, a.title, a.severity, a.issued_at,
                         (SELECT count(*) FROM host_applicability ha
                           WHERE ha.advisory_id = a.id AND ha.state = 'affected') AS servers_affected
                    FROM advisories a
                   WHERE a.issued_at >= (now() - make_interval(days => %(days)s::int))::date
                     AND (%(severity)s::text IS NULL OR lower(a.severity) = %(severity)s::text)
                     AND (%(os_id)s::text IS NULL OR a.os_id = %(os_id)s::text)
                   ORDER BY a.issued_at DESC, a.id LIMIT %(limit)s::int""",
    },

    # ---- Windows and WSUS -------------------------------------------------
    "windows_missing_updates": {
        "what": "Windows servers with missing Windows updates: how many, how many critical, how many downloaded.",
        "params": {},
        "sql": """SELECT h.hostname, coalesce(h.os_edition, 'Windows') AS os, count(*) AS missing,
                         count(*) FILTER (WHERE lower(wu.severity) = 'critical') AS critical,
                         count(*) FILTER (WHERE wu.downloaded) AS downloaded,
                         h.wu_source AS update_source, h.wu_searched_at AS last_search
                    FROM hosts h JOIN windows_updates wu ON wu.host_id = h.id
                   WHERE h.status <> 'decommissioned'
                   GROUP BY h.id, h.hostname, h.os_edition, h.wu_source, h.wu_searched_at
                   ORDER BY critical DESC, missing DESC LIMIT %(limit)s::int""",
    },
    "servers_missing_kb": {
        "what": "Which Windows servers are missing one update, by its KB number.",
        "params": {"kb": ("kb", None)},
        "needs": ["kb"],
        "sql": """SELECT h.hostname, coalesce(h.os_edition, 'Windows') AS os, wu.kb, wu.title, wu.severity,
                         wu.downloaded, wu.reported_at
                    FROM windows_updates wu JOIN hosts h ON h.id = wu.host_id AND h.status <> 'decommissioned'
                   WHERE upper(wu.kb) = %(kb)s::text
                   ORDER BY h.hostname LIMIT %(limit)s::int""",
    },
    "wsus_computers": {
        "what": "Computers WSUS reports as needing updates, with failed updates or a pending reboot.",
        "params": {},
        "sql": """SELECT name, source AS wsus, os, needed, failed, pending_reboot, last_reported,
                         array_to_string(groups, ', ') AS groups
                    FROM wsus_computers
                   WHERE coalesce(needed,0) > 0 OR coalesce(failed,0) > 0 OR coalesce(pending_reboot,0) > 0
                   ORDER BY failed DESC NULLS LAST, needed DESC NULLS LAST, name
                   LIMIT %(limit)s::int""",
    },

    # ---- changes ----------------------------------------------------------
    "recent_changes": {
        "what": "Changes (patch jobs, snapshots, software) in the last N days (default 7), optionally by state such as failed, running, pending_approval.",
        "params": {"days": ("int", 7), "state": ("change_state", None)},
        "sql": """SELECT 'CHG-' || lpad(c.number::text, 6, '0') AS change, c.kind::text AS kind, c.title,
                         c.state::text AS state, c.requested_by, c.requested_at, c.finished_at,
                         (SELECT count(*) FROM change_targets t WHERE t.change_id = c.id) AS targets,
                         (SELECT count(*) FROM change_targets t WHERE t.change_id = c.id AND t.state = 'failed') AS failed_targets
                    FROM changes c
                   WHERE c.requested_at > now() - make_interval(days => %(days)s::int)
                     AND (%(state)s::text IS NULL OR c.state::text = %(state)s::text)
                   ORDER BY c.requested_at DESC LIMIT %(limit)s::int""",
    },
    "change_detail": {
        "what": "One change by its number (CHG-000012): each server's state, error and warnings.",
        "params": {"number": ("chg", None)},
        "needs": ["number"],
        "sql": """SELECT 'CHG-' || lpad(c.number::text, 6, '0') AS change, c.title, c.state::text AS change_state,
                         t.label AS target, t.state AS target_state, t.error,
                         (SELECT string_agg(x, '; ') FROM jsonb_array_elements_text(
                             CASE WHEN jsonb_typeof(t.detail -> 'warnings') = 'array'
                                  THEN t.detail -> 'warnings' ELSE '[]'::jsonb END) x) AS warnings,
                         t.updated_at
                    FROM changes c LEFT JOIN change_targets t ON t.change_id = c.id
                   WHERE c.number = %(number)s::bigint
                   ORDER BY t.label LIMIT %(limit)s::int""",
    },

    # ---- hardening --------------------------------------------------------
    "hardening_scores": {
        "what": "Latest hardening (CIS) scores per server, optionally only below a score.",
        "params": {"below": ("score", None)},
        "sql": """SELECT hostname, os_id || ' ' || coalesce(os_version,'') AS os, profile_id AS profile, level,
                         score, passed, failed, finished_at
                    FROM v_hardening_latest
                   WHERE score IS NOT NULL
                     AND (%(below)s::numeric IS NULL OR score < %(below)s::numeric)
                   ORDER BY score, hostname LIMIT %(limit)s::int""",
    },

    # ---- VMware -----------------------------------------------------------
    "vm_search": {
        "what": "Virtual machines whose name or guest host name contains a word: power, cluster, OS, addresses, size.",
        "params": {"name": ("text", None)},
        "needs": ["name"],
        "sql": """SELECT v.name AS vm, v.vcenter, v.cluster, v.esxi_host, v.power_state, v.guest_os,
                         array_to_string(v.guest_ips, ', ') AS ips, v.num_cpu AS cpu, v.memory_mb,
                         v.snapshot_count AS snapshots, (v.host_id IS NOT NULL) AS has_agent
                    FROM vm_inventory v
                   WHERE strpos(lower(v.name), lower(%(name)s::text)) > 0
                      OR strpos(lower(coalesce(v.guest_hostname,'')), lower(%(name)s::text)) > 0
                   ORDER BY v.name LIMIT %(limit)s::int""",
    },
    "vms_by_power": {
        "what": "Virtual machines that are powered off, powered on, or suspended.",
        "params": {"power": ("power", "poweredOff")},
        "sql": """SELECT name AS vm, vcenter, cluster, guest_os, power_state, synced_at
                    FROM vm_inventory WHERE power_state = %(power)s::text
                   ORDER BY vcenter, name LIMIT %(limit)s::int""",
    },
    "vms_old_snapshots": {
        "what": "Virtual machines carrying snapshots older than a number of days (default 7).",
        "params": {"days": ("int", 7)},
        "sql": """SELECT name AS vm, vcenter, cluster, snapshot_count,
                         oldest_snapshot_at,
                         extract(day FROM now() - oldest_snapshot_at)::int AS days_old
                    FROM vm_inventory
                   WHERE snapshot_count > 0
                     AND oldest_snapshot_at < now() - make_interval(days => %(days)s::int)
                   ORDER BY oldest_snapshot_at
                   LIMIT %(limit)s::int""",
    },
    "vms_without_agent": {
        "what": "Running Linux virtual machines with no agent, so not covered by patching.",
        "params": {},
        "sql": """SELECT name AS vm, vcenter, cluster, guest_os, guest_hostname, guest_ips
                    FROM v_vm_unmanaged ORDER BY vcenter, name LIMIT %(limit)s::int""",
    },
    "esxi_hosts": {
        "what": "ESXi hosts: version, connection state, maintenance mode, CPU and memory use, VM count.",
        "params": {},
        "sql": """SELECT name, vcenter, cluster, coalesce(esxi_full_name, esxi_version) AS version,
                         connection_state, maintenance_mode, vm_count,
                         CASE WHEN (cpu_mhz * cpu_cores) > 0 THEN round(100.0 * cpu_usage_mhz / (cpu_mhz * cpu_cores)) END AS cpu_pct,
                         CASE WHEN memory_mb > 0 THEN round(100.0 * memory_usage_mb / memory_mb) END AS memory_pct
                    FROM esxi_hosts
                   ORDER BY (connection_state = 'connected') , maintenance_mode DESC, vcenter, name
                   LIMIT %(limit)s::int""",
    },
    "datastores_low_space": {
        "what": "Datastores with less free space than a percentage (default 20).",
        "params": {"pct": ("pct", 20)},
        "sql": """SELECT name, vcenter, type, round(capacity_mb / 1024.0) AS capacity_gb,
                         round(free_mb / 1024.0) AS free_gb,
                         round(100.0 * free_mb / capacity_mb, 1) AS free_pct, vm_count
                    FROM datastores
                   WHERE capacity_mb > 0 AND 100.0 * free_mb / capacity_mb < %(pct)s::numeric
                   ORDER BY free_pct LIMIT %(limit)s::int""",
    },

    # ---- inventory --------------------------------------------------------
    "assets": {
        "what": "Every machine from agents, vCenter and WSUS (servers, desktops, appliances): filter by category, by operating system text such as 'windows 10 pro' or 'windows server 2019' or 'rhel 8', by name, or only those without an agent. Use it for any question about an OS version or edition.",
        "params": {"category": ("category", None), "os": ("text", None), "name": ("name", None),
                   "unmanaged_only": ("bool", False)},
        "fn": "_assets",
    },
}

TOOL_NAMES = [k for k, v in TOOLS.items() if v.get("sql") or v.get("fn")]

# The console module each query belongs to; a user sees only the answers of
# the modules an admin granted (Admin > Access).
TOOL_MODULES = {
    "host_software": {"inventory", "patch", "lifecycle"}, "software_search": {"inventory", "lifecycle"},
    "vm_search": {"inventory", "patch"}, "vms_by_power": {"inventory", "patch"},
    "vms_without_agent": {"inventory", "patch"}, "esxi_hosts": {"inventory", "patch"},
    "datastores_low_space": {"inventory", "patch"}, "assets": {"inventory"},
    "vms_old_snapshots": {"patch", "inventory"},
}


def tool_allowed(tool, modules):
    if tool not in TOOL_NAMES:
        return False
    return bool(TOOL_MODULES.get(tool, {"patch"}) & set(modules or []))


EDITION_WORDS = {"pro", "professional", "enterprise", "standard", "datacenter", "datacentre", "home",
                 "education", "ltsc", "ltsb", "essentials", "core", "server-core", "workstation", "64-bit", "32-bit"}


def os_tokens(text):
    """'Win10 Pro' -> ['windows', '10', 'pro']: words to find in an OS name."""
    t = (text or "").lower()
    t = re.sub(r"\bwin(?:dows)?\s*(\d{1,4})\b", r"windows \1", t)
    t = re.sub(r"\bw(10|11)\b", r"windows \1", t)
    t = re.sub(r"\bred ?hat( enterprise linux)?\b", "rhel", t)
    t = re.sub(r"\brhel ?(\d)", r"rhel \1", t)
    t = re.sub(r"\boracle linux\b|\bol ?(?=\d)", "oracle ", t)
    t = re.sub(r"\bsrv\b", "server", t)
    return [w for w in re.findall(r"[a-z0-9.-]+", t) if w]


def _os_hit(os_text, words):
    o = (os_text or "").lower()
    o = o.replace("red hat enterprise linux", "rhel").replace("oracle linux", "oracle")
    o = re.sub(r"\bwindows(\d)", r"windows \1", o)
    have = set(re.findall(r"[a-z0-9.-]+", o))
    # "10" must match "10" or "10.0", not "100"
    return all(any(h == w or h.startswith(w + ".") or (not w.isdigit() and w in h) for h in have) for w in words)


def _assets(conn, args, limit):
    from . import inventory as inv
    words = os_tokens(args.get("os")) if args.get("os") else []
    found = inv.load_assets(conn)["assets"]

    def pick(req):
        out = []
        for a in found:
            if args.get("category") and a["category"] != args["category"]:
                continue
            if args.get("unmanaged_only") and a["managed"]:
                continue
            if args.get("name") and args["name"].lower() not in (a["name"] or "").lower():
                continue
            if req and not _os_hit(a["os"], req):
                continue
            out.append(a)
        return out

    hits = pick(words)
    loosened = False
    core = [w for w in words if w not in EDITION_WORDS]
    if not hits and core and core != words:
        # vCenter names "Microsoft Windows 10 (64-bit)" without the edition: match on the version
        hits, loosened = pick(core), True
    rows = []
    for a in hits[:limit]:
        vm = a.get("vm") or {}
        ws = a.get("wsus") or {}
        rows.append({"name": a["name"], "category": a["category"], "os": a["os"], "os_from": a["os_from"],
                     "seen_by": ", ".join(a["sources"]), "has_agent": a["managed"],
                     "ip": ", ".join(a["ips"][:3]), "vcenter": vm.get("vcenter") or (a.get("esxi") or {}).get("vcenter"),
                     "cluster": vm.get("cluster") or (a.get("esxi") or {}).get("cluster"),
                     "power": vm.get("power"), "wsus_last_report": ws.get("last_reported"),
                     "last_seen": a["last_seen"]})
    if loosened:
        args["_loosened"] = " ".join(core)
    elif core != words:
        # Machines of that version whose edition no source reports (vCenter does not)
        extra = [a for a in pick(core) if a not in hits and not any(w in (a["os"] or "").lower() for w in EDITION_WORDS - {"64-bit", "32-bit", "core"})]
        if extra:
            args["_unknown_edition"] = len(extra)
    if words:
        args["_os_words"] = " ".join(words)
    return rows


# ---------------------------------------------------------------------------
# Parameter validation
# ---------------------------------------------------------------------------

VALID_OS = {"rhel", "ol", "ubuntu", "windows"}
VALID_AGENT = {"online", "offline", "not_reporting", "no_data"}
VALID_CHANGE = {"pending_approval", "scheduled", "running", "succeeded", "partially_succeeded",
                "failed", "cancelled", "rejected"}
VALID_SEVERITY = {"critical", "important", "moderate", "low"}
VALID_POWER = {"poweredOn", "poweredOff", "suspended"}
NAME_OK = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,62}$")
TEXT_OK = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._+()-]{0,59}$")


def coerce(kind, value, default):
    """Force a parameter into its declared shape, or fall back to the default.

    A model that returns nonsense, or a question that tries to smuggle SQL,
    cannot get past this: values are rebuilt, never passed through.
    """
    if value is None or value == "" or isinstance(value, (list, dict)):
        return default
    v = str(value).strip()
    low = v.lower()
    if kind == "cve":
        m = CVE_IN_TEXT.search(v)
        return f"CVE-{m.group(1)}-{m.group(2)}" if m else default
    if kind == "kb":
        m = KB_IN_TEXT.search(v) or re.fullmatch(r"(\d{6,8})", v)
        return f"KB{m.group(1)}" if m else default
    if kind == "chg":
        m = re.search(r"(\d{1,9})", v)
        return int(m.group(1)) if m else default
    if kind == "os":
        low = {"redhat": "rhel", "red hat": "rhel", "oracle": "ol", "oraclelinux": "ol", "oracle linux": "ol",
               "win": "windows", "windows server": "windows", "microsoft": "windows"}.get(low, low)
        return low if low in VALID_OS else default
    if kind == "agent_state":
        low = low.replace(" ", "_").replace("-", "_")
        low = {"silent": "not_reporting", "down": "offline", "up": "online", "never": "no_data"}.get(low, low)
        return low if low in VALID_AGENT else default
    if kind == "change_state":
        low = low.replace(" ", "_").replace("-", "_")
        low = {"pending": "pending_approval", "waiting": "pending_approval", "awaiting_approval": "pending_approval",
               "done": "succeeded", "success": "succeeded", "successful": "succeeded", "partial": "partially_succeeded",
               "partially": "partially_succeeded", "canceled": "cancelled", "in_progress": "running"}.get(low, low)
        return low if low in VALID_CHANGE else default
    if kind == "severity":
        low = {"high": "important", "medium": "moderate"}.get(low, low)
        return low if low in VALID_SEVERITY else default
    if kind == "power":
        low = low.replace(" ", "").replace("-", "").replace("_", "")
        low = {"off": "poweredOff", "poweredoff": "poweredOff", "down": "poweredOff", "stopped": "poweredOff",
               "on": "poweredOn", "poweredon": "poweredOn", "running": "poweredOn", "suspended": "suspended"}.get(low)
        return low if low in VALID_POWER else default
    if kind == "category":
        low = {"servers": "server", "clients": "client", "desktop": "client", "desktops": "client",
               "workstation": "client", "appliances": "appliance"}.get(low, low)
        return low if low in ("server", "client", "appliance", "unknown") else default
    if kind == "name":
        return v if NAME_OK.match(v) else default
    if kind == "text":
        return v if TEXT_OK.match(v) else default
    if kind == "bool":
        if isinstance(value, bool):
            return value
        return low in ("1", "true", "yes", "y", "on")
    if kind == "int":
        try:
            return max(0, min(3650, int(float(v))))
        except (TypeError, ValueError):
            return default
    if kind == "pct":
        try:
            return max(0, min(100, int(float(v))))
        except (TypeError, ValueError):
            return default
    if kind == "score":
        try:
            return max(0.0, min(100.0, round(float(v), 1)))
        except (TypeError, ValueError):
            return default
    return default


def build_args(tool, raw_args, limit=MAX_ROWS):
    spec = TOOLS[tool]
    raw_args = raw_args if isinstance(raw_args, dict) else {}
    args = {}
    for name, (kind, default) in spec["params"].items():
        args[name] = coerce(kind, raw_args.get(name), default)
    missing = [n for n in spec.get("needs", []) if args.get(n) is None]
    args["limit"] = int(limit)
    return args, missing


def run_tool(conn, tool, raw_args, limit=MAX_ROWS):
    """Run one prepared query with validated arguments. Read-only.
    Returns (args without limit, rows, columns, missing)."""
    if tool not in TOOL_NAMES:
        raise ValueError("unknown query")
    args, missing = build_args(tool, raw_args, limit)
    if missing:
        return {k: v for k, v in args.items() if k != "limit"}, [], [], missing
    spec = TOOLS[tool]
    if spec.get("fn"):
        rows = globals()[spec["fn"]](conn, args, limit)
    else:
        rows = [dict(r) for r in conn.execute(spec["sql"], args).fetchall()]
    cols = list(rows[0].keys()) if rows else []
    return {k: v for k, v in args.items() if k != "limit"}, rows, cols, []


# ---------------------------------------------------------------------------
# Choosing a query: the model, with a keyword fallback
# ---------------------------------------------------------------------------

def _param_doc(v):
    return ", ".join(f"{n} ({t})" for n, (t, _) in v["params"].items()) or "none"


SELECT_PROMPT = """You choose which prepared database query answers a question about an IT estate: Linux and Windows servers, patches, CVEs, changes, VMware, WSUS, hardening and inventory.

Reply with ONE line of JSON and nothing else:
{"tool": "<name>", "args": {...}}

Available tools and their arguments:
""" + "\n".join(f'- {k}: {v["what"]} args: {_param_doc(v)}' for k, v in TOOLS.items() if k in TOOL_NAMES) + """

Argument values: os is rhel, ol, ubuntu or windows. agent_state is online, offline, not_reporting or no_data.
change_state is pending_approval, scheduled, running, succeeded, partially_succeeded, failed, cancelled or rejected.
severity is critical, important, moderate or low. power is poweredOn, poweredOff or suspended.
category is server, client or appliance. kb is like KB5044277. chg is a change number.

Rules:
- Use only a tool from the list. Never invent one.
- Copy identifiers such as CVE numbers, KB numbers, host names and program names from the question exactly.
- The question may also ask to export, download, e-mail or send the result: ignore that part and choose the data.
- If the question refers to the previous answer ("that", "it", "those") and asks nothing new, reply {"tool": "same", "args": {}}.
- If no tool covers the question, reply {"tool": "none", "args": {}}.
- Reply with the JSON only. No explanation."""


EXPORT_WORDS = re.compile(r"\b(export|download|csv|excel|spreadsheet|xlsx)\b", re.I)
EMAIL_WORDS = re.compile(r"\b(e-?mail|mail|send)\b", re.I)
REFERS_BACK = re.compile(r"\b(that|this|it|these|those|them|above|same|result|results|answer|list|table)\b", re.I)
FILLER = {"please", "can", "you", "could", "would", "the", "a", "an", "to", "me", "as", "and", "of", "in", "for",
          "now", "also", "pls", "kindly", "file", "report", "send", "mail", "email", "e-mail", "export", "download",
          "csv", "excel", "spreadsheet", "xlsx", "it", "that", "this", "these", "those", "them", "above", "same",
          "result", "results", "answer", "list", "table", "with", "attached", "attachment", "copy", "cc", "i", "want",
          "need", "give", "share", "him", "her", "team", "us", "my", "our", "data", "info", "information"}


def detect_action(q):
    """What to do with the answer: show it, export it, or draft an e-mail."""
    if EMAIL_WORDS.search(q) or EMAIL_IN_TEXT.search(q):
        return "email"
    if EXPORT_WORDS.search(q):
        return "export"
    return "show"


def only_action(q):
    """The question asks only to export or e-mail the previous answer."""
    rest = EMAIL_IN_TEXT.sub(" ", q)
    words = [w.lower() for w in re.findall(r"[A-Za-z0-9-]+", rest)]
    meaningful = [w for w in words if w not in FILLER]
    return len(meaningful) <= 1 or (REFERS_BACK.search(rest) and len(meaningful) <= 3)


def _hostname_in(q, known):
    """A server named in the question, matched against enrolled names."""
    for w in WORD_RE.findall(q):
        lw = w.lower().rstrip(".")
        if lw in known:
            return known[lw]
        short = lw.split(".")[0]
        if short in known:
            return known[short]
    return None


def _after(t, words):
    """The word or phrase after one of the given words: 'servers with openssl' -> openssl."""
    m = re.search(r"\b(?:" + words + r")\s+([A-Za-z0-9][A-Za-z0-9._+-]{1,59})", t, re.I)
    return m.group(1) if m else None


OS_IN_TEXT = re.compile(
    r"\b(?:microsoft\s+)?(?:win(?:dows)?\s*(?:server\s*)?(?:10|11|7|8\.1|8|xp|20(?:08|12|16|19|22|25))(?:\s*r2)?"
    r"(?:\s+(?:pro(?:fessional)?|enterprise|standard|datacenter|home|education|ltsc|essentials))?"
    r"|w(?:10|11)\b(?:\s+(?:pro|enterprise))?"
    r"|windows\s+server(?:\s+(?:standard|datacenter))?"
    r"|(?:rhel|red\s?hat(?:\s+enterprise\s+linux)?)\s*\d{1,2}(?:\.\d+)?"
    r"|oracle\s+linux\s*\d{1,2}|ubuntu\s*\d{2}(?:\.\d{2})?|centos\s*\d?|photon(?:\s*os)?(?:\s*\d)?|esxi\s*\d?(?:\.\d)?)",
    re.I)


def keyword_pick(q, known_hosts=None):
    """Choose a query without the model. Used when AI-01 is unavailable, and
    when the model's choice is unusable."""
    t = q.lower()
    known_hosts = known_hosts or {}
    host = _hostname_in(q, known_hosts)
    m = CVE_IN_TEXT.search(q)
    if m:
        cve = f"CVE-{m.group(1)}-{m.group(2)}"
        if any(w in t for w in ("what is", "explain", "detail", "severity", "score", "about", "tell me")):
            return "cve_summary", {"cve_id": cve}
        return "hosts_affected_by_cve", {"cve_id": cve}
    m = KB_IN_TEXT.search(q)
    if m:
        return "servers_missing_kb", {"kb": "KB" + m.group(1)}
    m = CHG_IN_TEXT.search(q)
    if m:
        return "change_detail", {"number": m.group(1) or m.group(2)}
    if host:
        if any(w in t for w in ("installed patch", "patches installed", "already installed", "applied", "fixed")):
            return "host_installed_patches", {"hostname": host}
        if any(w in t for w in ("software", "program", "package", "application", "installed")):
            return "host_software", {"hostname": host, "name": _after(t, "named|called|containing|like")}
        if any(w in t for w in ("pending", "missing", "to install", "need", "outstanding", "patch", "update")):
            return "host_pending_updates", {"hostname": host}
        return "host_detail", {"hostname": host}
    if "snapshot" in t:
        d = re.search(r"(\d{1,4})\s*day", t)
        return "vms_old_snapshots", {"days": d.group(1) if d else 7}
    if "datastore" in t or "storage" in t or "disk space" in t:
        p = re.search(r"(\d{1,2})\s*%", t)
        return "datastores_low_space", {"pct": p.group(1) if p else 20}
    if "esxi" in t or "hypervisor" in t:
        return "esxi_hosts", {}
    if ("powered off" in t or "power off" in t or "switched off" in t or "suspended" in t
            or ("vm" in t and (" off" in t or "stopped" in t))):
        return "vms_by_power", {"power": "suspended" if "suspended" in t else "poweredOff"}
    if "wsus" in t:
        return "wsus_computers", {}
    osq = OS_IN_TEXT.search(t)
    if osq and not any(w in t for w in ("need patch", "needs patch", "missing", "pending", "update", "cve")):
        cat = next((c for w, c in (("appliance", "appliance"), ("client", "client"), ("desktop", "client"),
                                   ("workstation", "client")) if w in t), None)
        return "assets", {"os": osq.group(0), "category": cat,
                          "unmanaged_only": any(w in t for w in ("without", "no agent", "unmanaged"))}
    if any(w in t for w in ("asset", "inventory", "appliance", "client", "desktop", "workstation")):
        cat = next((c for w, c in (("appliance", "appliance"), ("client", "client"), ("desktop", "client"),
                                   ("workstation", "client"), ("server", "server")) if w in t), None)
        return "assets", {"category": cat, "unmanaged_only": any(w in t for w in ("without", "no agent", "unmanaged"))}
    if ("without an agent" in t or "no agent" in t or "unmanaged" in t or ("vm" in t and "agent" in t)):
        return "vms_without_agent", {}
    if re.search(r"\b(vm|vms|virtual machine)\b", t):
        name = _after(t, "named|called|vm|machine")
        if name and name not in ("with", "that", "which", "are", "is", "list", "in"):
            return "vm_search", {"name": name}
    if "agent version" in t or ("version" in t and "agent" in t):
        return "agent_versions", {}
    if "offline" in t or "not reporting" in t or "silent" in t or "agent" in t:
        state = ("not_reporting" if ("not reporting" in t or "silent" in t)
                 else "no_data" if "never" in t else "online" if "online" in t else "offline")
        return "agents_by_state", {"state": state}
    if "reboot" in t or "restart" in t:
        return "reboot_pending", {}
    if any(w in t for w in ("change", "job", "chg")):
        st = next((s for s in ("failed", "running", "pending", "scheduled", "succeeded", "cancelled", "rejected",
                               "partial") if s in t), None)
        d = re.search(r"(\d{1,4})\s*day", t)
        return "recent_changes", {"state": st, "days": d.group(1) if d else (30 if "month" in t else 7)}
    if "hardening" in t or "cis" in t or "benchmark" in t or "compliance" in t:
        b = re.search(r"(?:below|under|less than)\s*(\d{1,3})", t)
        return "hardening_scores", {"below": b.group(1) if b else None}
    if any(w in t for w in ("software", "program", "package", "installed")):
        name = _after(t, "with|has|have|running|named|called|of|for")
        if name and name not in ("the", "a", "an", "installed", "software", "program", "package"):
            return "software_search", {"name": name}
    if "exploited" in t or "kev" in t or "in the wild" in t:
        if any(w in t for w in ("server", "host", "machine")) and "cve" not in t:
            return "hosts_needing_patch", {"exploited_only": True}
        return "exploited_cves", {}
    if "advisor" in t or "released" in t or "published" in t or "new patch" in t:
        d = re.search(r"(\d{1,4})\s*day", t)
        sev = next((s for s in ("critical", "important", "moderate", "low") if s in t), None)
        return "recent_advisories", {"days": d.group(1) if d else 30, "severity": sev}
    if "critical cve" in t or "top cve" in t or "worst" in t or ("cve" in t and "cvss" in t):
        return "top_cves", {}
    if "windows" in t and any(w in t for w in ("update", "missing", "patch")):
        return "windows_missing_updates", {}
    if any(w in t for w in ("need patch", "needs patch", "outstanding", "to patch", "unpatched", "vulnerable",
                            "affected", "pending", "missing")):
        args = {}
        for k, v in (("rhel", "rhel"), ("red hat", "rhel"), ("oracle", "ol"), ("ubuntu", "ubuntu"),
                     ("windows", "windows")):
            if k in t:
                args["os_id"] = v
        g = re.search(r"\b(prod|production|test|dev|staging|default)\b", t)
        if g:
            args["host_group"] = {"production": "prod"}.get(g.group(1), g.group(1))
        return "hosts_needing_patch", args
    if any(w in t for w in ("how many", "summary", "overall", "fleet", "total", "status", "overview")):
        return "fleet_summary", {}
    if any(w in t for w in ("list", "all servers", "servers", "hosts")):
        args = {}
        for k, v in (("rhel", "rhel"), ("oracle", "ol"), ("ubuntu", "ubuntu"), ("windows", "windows"),
                     ("linux", None)):
            if k in t and v:
                args["os_id"] = v
        return "servers_list", args
    return None, {}


def pick_tool(question, ask_model, known_hosts=None):
    """Returns (tool, args, how). tool may be "same" (the previous answer's
    query). The model chooses; keywords are the fallback."""
    if ask_model:
        try:
            raw = ask_model([{"role": "system", "content": SELECT_PROMPT},
                             {"role": "user", "content": question[:MAX_QUESTION]}])
            txt = re.sub(r"<think>.*?</think>", "", (raw or ""), flags=re.S | re.I).strip()
            m = re.search(r"\{.*\}", txt, re.S)
            if m:
                d = json.loads(m.group(0))
                tool = str(d.get("tool") or "").strip()
                args = d.get("args") if isinstance(d.get("args"), dict) else {}
                if tool in TOOL_NAMES:
                    # A model that names a host-specific query without a usable host: try the question
                    if "hostname" in TOOLS[tool]["params"] and not coerce("name", args.get("hostname"), None):
                        h = _hostname_in(question, known_hosts or {})
                        if h:
                            args["hostname"] = h
                    return tool, args, "model"
                if tool == "same":
                    return "same", {}, "model"
                if tool == "none":
                    kw, kwargs = keyword_pick(question, known_hosts)
                    return (kw, kwargs, "keywords") if kw else (None, {}, "model")
        except Exception as e:  # noqa: BLE001 - fall back rather than fail
            log.warning("query choice via AI-01 failed: %s", e)
    kw, kwargs = keyword_pick(question, known_hosts)
    return kw, kwargs, "keywords"


# ---------------------------------------------------------------------------
# Wording the answer from the rows
# ---------------------------------------------------------------------------

def _plural(n, one, many=None):
    return f"{n} {one if n == 1 else (many or one + 's')}"


def phrase(tool, args, rows):
    n = len(rows)
    a = args
    if tool == "fleet_summary" and rows:
        r = rows[0]
        return (f"{_plural(r['servers'], 'server')} ({r['linux']} Linux, {r['windows']} Windows). {r['agents_online']} "
                f"online, {r['agents_not_online']} not. {r['need_patches']} need patches and "
                f"{r['awaiting_reboot']} wait for a reboot.")
    if tool == "servers_list":
        what = f"{a['os_id']} " if a.get("os_id") else ""
        return (f"No {what}servers are enrolled" + (f" in group {a['host_group']}." if a.get("host_group") else ".")
                if not n else f"{_plural(n, what + 'server')}" + (f" in group {a['host_group']}" if a.get("host_group") else "") + ".")
    if tool == "host_detail":
        if not n:
            return f"No server named {a.get('hostname')} is enrolled."
        r = rows[0]
        s = f"{r['hostname']} runs {r['os']}, agent {r['agent'].replace('_', ' ')}"
        s += f" (version {r['agent_version']})." if r.get("agent_version") else "."
        if r.get("os_id") == "windows":
            s += f" It is missing {_plural(r['windows_updates_missing'], 'Windows update')}."
        else:
            s += f" Kernel {r['kernel_running']}. It needs {_plural(r['needs_patch'], 'advisory', 'advisories')}"
            s += f", and {r['needs_reboot']} wait on a reboot." if r["needs_reboot"] else "."
        if r.get("reboot_required"):
            s += " A reboot is pending."
        return s
    if tool == "host_pending_updates":
        if not n:
            return f"Nothing is pending on {a.get('hostname')}: it has every patch PATCH-01 knows about, or it is not enrolled."
        todo = sum(1 for r in rows if r["status"].startswith("to install"))
        crit = sum(1 for r in rows if (r.get("severity") or "").lower() == "critical")
        s = f"{a.get('hostname')} has {_plural(todo, 'patch', 'patches')} to install"
        if n - todo:
            s += f" and {n - todo} installed but waiting for a reboot"
        s += "."
        if crit:
            s += f" {crit} critical."
        return s
    if tool == "host_installed_patches":
        return (f"No installed advisories are recorded for {a.get('hostname')}." if not n
                else f"{a.get('hostname')} has {_plural(n, 'advisory', 'advisories')} installed and active, newest first.")
    if tool == "host_software":
        what = f" matching {a['name']}" if a.get("name") else ""
        return (f"No software{what} is recorded for {a.get('hostname')}." if not n
                else f"{a.get('hostname')} has {_plural(n, 'program or package', 'programs and packages')}{what}.")
    if tool == "software_search":
        if not n:
            return f"Nothing matching {a.get('name')} is installed on any server with an agent."
        hosts = len({r["hostname"] for r in rows})
        versions = sorted({r["version"] or "?" for r in rows})
        s = f"{a.get('name')} is installed on {_plural(hosts, 'server')}"
        s += f", in {_plural(len(versions), 'version')}." if len(versions) > 1 else f", version {versions[0]}."
        return s
    if tool == "agents_by_state":
        st = a.get("state").replace("_", " ")
        st = "never reported" if st == "no data" else st
        return f"No agent is {st}." if not n else f"{_plural(n, 'agent is', 'agents are')} {st}."
    if tool == "agent_versions":
        return "No servers are enrolled." if not n else "Agent versions in use: " + "; ".join(
            f"{r['platform']} {r['agent_version']} on {r['servers']}" for r in rows[:6]) + "."
    if tool == "reboot_pending":
        return "No server is waiting for a reboot." if not n else f"{_plural(n, 'server is', 'servers are')} waiting for a reboot."
    if tool == "hosts_needing_patch":
        if not n:
            return "No server has outstanding patches for that filter."
        exploited = sum(1 for r in rows if r.get("any_exploited"))
        s = f"{_plural(n, 'server needs', 'servers need')} patches"
        if a.get("os_id"):
            s += f" on {a['os_id']}"
        if a.get("host_group"):
            s += f" in group {a['host_group']}"
        s += "."
        if exploited:
            s += f" {exploited} with a CVE exploited in the wild."
        return s
    if tool == "hosts_affected_by_cve":
        cve = a.get("cve_id")
        if not n:
            return (f"No server is linked to {cve}. Either no advisory mentions it, or no server has the "
                    f"affected package. Run an assessment for a definite answer.")
        need = sum(1 for r in rows if r["state"] == "affected")
        reboot = sum(1 for r in rows if r["state"] == "fixed_pending_reboot")
        done = sum(1 for r in rows if r["state"] == "fixed_active")
        bits = []
        if need:
            bits.append(f"{need} still need the patch")
        if reboot:
            bits.append(f"{reboot} have it installed but need a reboot")
        if done:
            bits.append(f"{done} are patched")
        return f"{cve} touches {_plural(n, 'server')}: " + ", ".join(bits) + "."
    if tool == "cve_summary":
        if not n:
            return (f"No published data has been collected for {a.get('cve_id')} yet. Run the CVE data fetch, "
                    f"or no advisory references it.")
        r = rows[0]
        parts = [r["cve_id"]]
        if r.get("cvss_score") is not None:
            parts.append(f"CVSS {r['cvss_score']} ({(r.get('cvss_severity') or '').lower()})")
        if r.get("attack_class"):
            parts.append(str(r["attack_class"]).lower())
        s = ", ".join(parts) + "."
        if r.get("exploited_in_wild"):
            s += " It is on CISA's exploited list, so attackers are using it now."
        s += f" {_plural(r.get('servers_affected') or 0, 'of your servers needs', 'of your servers need')} the fix."
        return s
    if tool == "exploited_cves":
        return ("No CVE known to be exploited in the wild affects your servers." if not n else
                f"{_plural(n, 'CVE')} known to be exploited in the wild: still on your servers, most widespread first.")
    if tool == "top_cves":
        return (f"No CVE with CVSS {a.get('min_cvss')} or more affects your servers." if not n else
                f"{_plural(n, 'CVE')} with CVSS {a.get('min_cvss')} or more still on your servers, exploited ones first.")
    if tool == "recent_advisories":
        sev = f"{a['severity']} " if a.get("severity") else ""
        hit = sum(1 for r in rows if r.get("servers_affected"))
        return (f"No {sev}advisories were published in the last {a.get('days')} days." if not n else
                f"{_plural(n, sev + 'advisory', sev + 'advisories')} in the last {a.get('days')} days; "
                f"{hit} affect your servers.")
    if tool == "windows_missing_updates":
        if not n:
            return "No Windows server reports a missing update."
        total = sum(r["missing"] for r in rows)
        crit = sum(r["critical"] for r in rows)
        return (f"{_plural(n, 'Windows server is', 'Windows servers are')} missing {_plural(total, 'update')}"
                + (f", {crit} critical." if crit else "."))
    if tool == "servers_missing_kb":
        return (f"No Windows server reports {a.get('kb')} as missing." if not n else
                f"{_plural(n, 'Windows server is', 'Windows servers are')} missing {a.get('kb')}.")
    if tool == "wsus_computers":
        if not n:
            return "WSUS reports no computer needing updates."
        failed = sum(1 for r in rows if (r.get("failed") or 0) > 0)
        return (f"WSUS reports {_plural(n, 'computer')} needing attention"
                + (f"; {failed} with failed updates." if failed else "."))
    if tool == "recent_changes":
        st = f"{a['state'].replace('_', ' ')} " if a.get("state") else ""
        return (f"No {st}changes in the last {a.get('days')} days." if not n else
                f"{_plural(n, st + 'change')} in the last {a.get('days')} days, newest first.")
    if tool == "change_detail":
        if not n:
            return f"There is no change CHG-{int(a.get('number') or 0):06d}."
        r = rows[0]
        targets = [x for x in rows if x.get("target")]
        failed = sum(1 for x in targets if x.get("target_state") == "failed")
        warned = sum(1 for x in targets if x.get("warnings"))
        s = f"{r['change']} ({r['title']}) is {r['change_state'].replace('_', ' ')}, {_plural(len(targets), 'target')}"
        if failed:
            s += f", {failed} failed"
        if warned:
            s += f", {warned} with warnings"
        return s + "."
    if tool == "hardening_scores":
        if not n:
            return "No hardening scan results" + (f" below {a['below']:g}." if a.get("below") is not None else " yet.")
        avg = round(sum(float(r["score"]) for r in rows) / n, 1)
        return (f"{_plural(n, 'hardening result')}" + (f" below {a['below']:g}" if a.get("below") is not None else "")
                + f", lowest first; average score {avg}.")
    if tool == "vm_search":
        return (f"No VM name contains {a.get('name')}." if not n else
                f"{_plural(n, 'VM')} found for {a.get('name')}.")
    if tool == "vms_by_power":
        p = {"poweredOff": "powered off", "poweredOn": "powered on"}.get(a.get("power"), a.get("power"))
        return f"No VM is {p}." if not n else f"{_plural(n, 'VM is', 'VMs are')} {p}."
    if tool == "vms_old_snapshots":
        return (f"No VM has a snapshot older than {a.get('days')} days." if not n
                else f"{_plural(n, 'VM carries', 'VMs carry')} snapshots older than {a.get('days')} days, oldest first.")
    if tool == "vms_without_agent":
        return ("Every running Linux VM has an agent." if not n
                else f"{_plural(n, 'running Linux VM has', 'running Linux VMs have')} no agent, so not patched or assessed.")
    if tool == "esxi_hosts":
        if not n:
            return "No ESXi hosts have been collected from vCenter."
        bad = sum(1 for r in rows if r.get("connection_state") != "connected")
        maint = sum(1 for r in rows if r.get("maintenance_mode"))
        s = f"{_plural(n, 'ESXi host')}"
        if bad:
            s += f", {bad} not connected"
        if maint:
            s += f", {maint} in maintenance mode"
        return s + "."
    if tool == "datastores_low_space":
        return (f"No datastore has less than {a.get('pct')}% free." if not n else
                f"{_plural(n, 'datastore has', 'datastores have')} less than {a.get('pct')}% free, fullest first.")
    if tool == "assets" and a.get("os"):
        if not n:
            return (f"No machine with {a['os']} was found in agents, vCenter or WSUS."
                    + (" It may be named differently there; try a shorter name, such as windows 10." if len(a["os"].split()) > 2 else ""))
        from collections import Counter
        kinds = Counter((r["os"] or "unknown") for r in rows).most_common(4)
        label = a.get("_os_words") or a["os"]
        s = f"{_plural(n, 'machine')} with {label}"
        if a.get("_loosened"):
            s = (f"No source names the edition \"{a['os']}\", so these are all {_plural(n, 'machine')} with "
                 f"{a['_loosened']}")
        s += (" without an agent" if a.get("unmanaged_only") else "") + ": " + "; ".join(f"{k} {v}" for k, v in kinds) + "."
        managed = sum(1 for r in rows if r.get("has_agent"))
        if not a.get("unmanaged_only"):
            s += (" None has an agent." if not managed else " All have an agent." if managed == n
                  else f" {managed} {'has' if managed == 1 else 'have'} an agent.")
        if a.get("_unknown_edition"):
            s += (f" {_plural(a['_unknown_edition'], 'more machine')} with that version but no edition reported "
                  f"(vCenter does not report editions); ask without the edition to include them.")
        return s
    if tool == "assets":
        cat = f"{a['category']} " if a.get("category") else ""
        return (f"No {cat}assets found." if not n else
                f"{_plural(n, cat + 'asset')}" + (" without an agent" if a.get("unmanaged_only") else "")
                + ", from agents, vCenter and WSUS.")
    return f"{_plural(n, 'row')}."


# ---------------------------------------------------------------------------
# Export and e-mail helpers (pure)
# ---------------------------------------------------------------------------

def _cell(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "yes" if v else "no"
    if isinstance(v, (list, tuple)):
        v = ", ".join(str(x) for x in v)
    elif isinstance(v, dict):
        v = json.dumps(v, default=str)
    s = str(v)
    # A spreadsheet runs a cell that starts with these as a formula
    if s[:1] in ("=", "+", "-", "@", "\t", "\r"):
        s = "'" + s
    return s


def to_csv(columns, rows):
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow([c.replace("_", " ") for c in columns])
    for r in rows:
        w.writerow([_cell(r.get(c)) for c in columns])
    return "﻿" + buf.getvalue()          # BOM: Excel then reads UTF-8 correctly


def file_name(tool, args):
    bits = [tool] + [str(v) for k, v in sorted(args.items()) if v not in (None, False, "") and not k.startswith("_")]
    name = "-".join(bits)
    return re.sub(r"[^A-Za-z0-9._-]+", "-", name)[:80].strip("-") or "export"


TITLES = {
    "fleet_summary": "Fleet summary", "servers_list": "Servers", "host_detail": "Server detail",
    "host_pending_updates": "Patches pending", "host_installed_patches": "Patches installed",
    "host_software": "Installed software", "software_search": "Where software is installed",
    "agents_by_state": "Agents", "agent_versions": "Agent versions", "reboot_pending": "Servers waiting for a reboot",
    "hosts_needing_patch": "Servers needing patches", "hosts_affected_by_cve": "Servers affected by a CVE",
    "cve_summary": "CVE summary", "exploited_cves": "Exploited CVEs on your servers", "top_cves": "Most serious CVEs",
    "recent_advisories": "Recent advisories", "windows_missing_updates": "Windows servers missing updates",
    "servers_missing_kb": "Servers missing an update", "wsus_computers": "WSUS computers needing attention",
    "recent_changes": "Recent changes", "change_detail": "Change detail", "hardening_scores": "Hardening scores",
    "vm_search": "Virtual machines", "vms_by_power": "Virtual machines by power state",
    "vms_old_snapshots": "VMs with old snapshots", "vms_without_agent": "VMs without an agent",
    "esxi_hosts": "ESXi hosts", "datastores_low_space": "Datastores low on space", "assets": "Asset inventory",
}


def title_for(tool, args):
    t = TITLES.get(tool) or tool.replace("_", " ").capitalize()
    extra = ", ".join(f"{k.replace('_', ' ')} {v}" for k, v in args.items() if v not in (None, False, "") and not k.startswith("_"))
    return (t + (f" ({extra})" if extra else ""))[:150]


def draft_email(tool, args, answer, n_rows, to):
    subject = "PATCH-01: " + title_for(tool, args)
    body = (f"Hello,\n\n{answer}\n\n"
            f"The details are attached as a CSV file ({_plural(n_rows, 'row')}), and the first rows are "
            f"shown below.")
    return {"to": to, "subject": subject[:200], "body": body}


def recipients_in(conn, q):
    """Addresses named in the question: written out, or the name of a
    configured mail recipient. Returned for the draft only; the server checks
    them again when the mail is sent."""
    found = []
    for m in EMAIL_IN_TEXT.findall(q):
        if m.lower() not in [x.lower() for x in found]:
            found.append(m)
    try:
        recs = conn.execute("SELECT address, name FROM mail_recipients").fetchall()
    except Exception:  # noqa: BLE001 - mail tables from a later schema
        recs = []
    t = " " + re.sub(r"[^a-z0-9 ]", " ", q.lower()) + " "
    for r in recs:
        names = {(r.get("name") or "").strip().lower(), r["address"].split("@")[0].lower()}
        names |= {n.split()[0] for n in names if n and " " in n}
        if any(n and len(n) >= 3 and f" {n} " in t for n in names):
            if r["address"].lower() not in [x.lower() for x in found]:
                found.append(r["address"])
    return found[:10]


# ---------------------------------------------------------------------------
# One question
# ---------------------------------------------------------------------------

def _known_hosts(conn):
    known = {}
    for r in conn.execute("SELECT hostname FROM hosts WHERE status <> 'decommissioned'").fetchall():
        hn = (r["hostname"] or "").lower()
        if hn:
            known[hn] = r["hostname"]
            known.setdefault(hn.split(".")[0], r["hostname"])
    return known


def _valid_context(context):
    if not isinstance(context, dict):
        return None
    tool = context.get("tool")
    if tool not in TOOL_NAMES:
        return None
    return tool, context.get("args") if isinstance(context.get("args"), dict) else {}


def help_text():
    return [{"name": k, "what": TOOLS[k]["what"]} for k in TOOL_NAMES]


def ask(conn, question, ask_model=None, requested_by="operator", context=None, modules=()):
    """Answer one question. Read-only throughout.

    context is the previous answer's query ({"tool", "args"}), so "export
    that" or "mail it to the team" can refer back to it. It is validated like
    anything else from the browser."""
    q = (question or "").strip()
    if not q:
        raise ValueError("empty question")
    q = q[:MAX_QUESTION]
    action = detect_action(q)
    prev = _valid_context(context)
    known = _known_hosts(conn)

    if action != "show" and prev and only_action(q):
        tool, raw_args, how = prev[0], prev[1], "previous answer"
    else:
        tool, raw_args, how = pick_tool(q, ask_model, known)
        if tool == "same":
            tool, raw_args, how = (prev[0], prev[1], "previous answer") if prev else (None, {}, how)
        if not tool and prev and action != "show":
            tool, raw_args, how = prev[0], prev[1], "previous answer"

    if not tool:
        return {"answer": "I cannot answer that one yet. I can report on servers, patches pending or installed, "
                          "CVEs, Windows updates, WSUS, changes, hardening scores, VMs, ESXi hosts, datastores, "
                          "installed software and the asset inventory.",
                "tool": None, "rows": [], "columns": [], "how": how, "action": "show", "tools": help_text()}

    if not tool_allowed(tool, modules):
        return {"answer": "That information is in a part of the console your account cannot open. "
                          "Ask an admin for access (Admin > Access).",
                "tool": None, "rows": [], "columns": [], "how": how, "action": "show"}
    args, rows, cols, missing = run_tool(conn, tool, raw_args, MAX_ROWS + 1)
    if missing:
        need = " and ".join(missing).replace("_", " ").replace("number", "change number")
        return {"answer": f"I need the {need} to answer that. For example: " + {
                    "hostname": "\"what is pending on <server name>?\"",
                    "cve_id": "\"which servers are affected by CVE-2026-31337?\"",
                    "kb": "\"which servers are missing KB5044277?\"",
                    "number": "\"what happened in CHG-000012?\"",
                    "name": "\"which servers have openssl installed?\""}.get(missing[0], "name it in the question."),
                "tool": tool, "args": args, "rows": [], "columns": [], "how": how, "action": "show"}

    truncated = len(rows) > MAX_ROWS
    rows = rows[:MAX_ROWS]
    answer = phrase(tool, args, rows)
    if truncated:
        answer += f" Showing the first {MAX_ROWS}; an export has them all."
    out = {"answer": answer, "tool": tool, "args": args, "rows": rows, "columns": cols, "how": how,
           "truncated": truncated, "action": action, "title": title_for(tool, args),
           "file": file_name(tool, args) + ".csv"}
    if action == "email":
        out["email"] = draft_email(tool, args, answer, len(rows) if not truncated else EXPORT_ROWS,
                                   recipients_in(conn, q))
        if truncated:
            out["email"]["body"] = out["email"]["body"].replace(f"({EXPORT_ROWS} rows)", "(all rows)")
    return out
