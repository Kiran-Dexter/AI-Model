"""Branded exports: every CSV and Excel file the console produces carries the
portal's name, the organisation, when it was made, by whom, and what it was
filtered on; the Excel file carries the logo as well.

A CSV file is plain text and cannot hold a picture, so the logo is in the
Excel version; the CSV has the same heading lines as text, above the table.

Both are safe to open in a spreadsheet: CSV cells that would run as a
formula are neutralised, and the Excel file stores every value as a literal
(no formulas are ever written). The Excel file is built here with the
standard library (zip + XML), so nothing new has to be installed.
"""

import csv
import io
import re
import zipfile
from datetime import datetime, timedelta, timezone
from xml.sax.saxutils import escape

PORTAL = "Cyber-Secure"
TZ = timezone(timedelta(hours=8))           # the console's time zone, as the mails use
TZ_LABEL = "SGT"
_BAD_XML = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]")


def stamp(now=None):
    return (now or datetime.now(TZ)).astimezone(TZ).strftime("%d %b %Y %H:%M ") + TZ_LABEL


def meta(title, user, filters_text, n_rows, company=None, now=None):
    return {"title": f"{PORTAL} — {title}", "company": company or "", "generated": stamp(now),
            "by": user or "", "filter": filters_text or "", "rows": str(n_rows)}


def file_name(base, ext, now=None):
    t = (now or datetime.now(TZ)).astimezone(TZ).strftime("%Y%m%d-%H%M")
    return re.sub(r"[^A-Za-z0-9._-]+", "-", f"cyber-secure-{base}-{t}")[:90] + "." + ext


def company_name(conn):
    try:
        r = conn.execute("SELECT company FROM branding WHERE id = 1").fetchone()
        return ((r or {}).get("company") or "").strip()
    except Exception:  # noqa: BLE001 - older schema
        return ""


# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------

def safe_cell(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "yes" if v else "no"
    if isinstance(v, (list, tuple)):
        v = ", ".join(str(x) for x in v)
    s = _BAD_XML.sub(" ", str(v))
    if s[:1] in ("=", "+", "-", "@", "\t", "\r"):
        s = "'" + s                           # a spreadsheet would run it as a formula
    return s


def header_lines(m):
    lines = [[m["title"]]]
    if m.get("company"):
        lines.append(["Organisation", m["company"]])
    lines += [["Generated", m["generated"]], ["By", m["by"]], ["Filter", m["filter"]], ["Rows", str(m["rows"])], []]
    return lines


def csv_text(m, headers, rows):
    """The heading lines, a blank line, then the table. UTF-8 with a BOM so
    Excel reads accents correctly."""
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    for line in header_lines(m):
        w.writerow([safe_cell(x) for x in line])
    w.writerow([safe_cell(x) for x in headers])
    for r in rows:
        w.writerow([safe_cell(x) for x in r])
    return "﻿" + buf.getvalue()


# ---------------------------------------------------------------------------
# Excel (.xlsx), with the logo
# ---------------------------------------------------------------------------

def _col(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _x(v):
    return escape(_BAD_XML.sub(" ", str(v)), {'"': "&quot;"})


def _cell(ref, v, style=0):
    st = f' s="{style}"' if style else ""
    if isinstance(v, bool):
        v = "yes" if v else "no"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return f'<c r="{ref}"{st}><v>{v}</v></c>'
    if v is None or v == "":
        return f'<c r="{ref}"{st}/>' if style else ""
    return f'<c r="{ref}"{st} t="inlineStr"><is><t xml:space="preserve">{_x(v)[:32000]}</t></is></c>'


def _png_size(data):
    if data and data[:8] == b"\x89PNG\r\n\x1a\n" and len(data) > 24:
        return int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")
    return None


STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="4"><font><sz val="10"/><name val="Calibri"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
<font><b/><sz val="15"/><color rgb="FF0B1F3A"/><name val="Calibri"/></font><font><sz val="10"/><color rgb="FF555F66"/><name val="Calibri"/></font></fonts>
<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF0B1F3A"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="2"><border/><border><bottom style="thin"><color rgb="FFC9D1D6"/></bottom></border></borders>
<cellStyleXfs count="1"><xf/></cellStyleXfs>
<cellXfs count="5"><xf/><xf fontId="1" fillId="2" applyFont="1" applyFill="1"/><xf fontId="2" applyFont="1"/>
<xf fontId="3" applyFont="1"/><xf borderId="1" applyBorder="1"/></cellXfs>
</styleSheet>"""


def xlsx_bytes(m, headers, rows, logo_png=None, sheet="Report"):
    """One worksheet: logo, heading lines, then the table with a filter and
    the heading row frozen."""
    size = _png_size(logo_png) if logo_png else None
    lines = []                                # (row number, [cells])
    r = 1
    if size:
        r = 5                                 # the logo sits over rows 1 to 4
    lines.append((r, [_cell(f"A{r}", m["title"], 2)])); r += 1
    for k, label in (("company", "Organisation"), ("generated", "Generated"), ("by", "By"),
                     ("filter", "Filter"), ("rows", "Rows")):
        if k == "company" and not m.get(k):
            continue
        lines.append((r, [_cell(f"A{r}", label, 3), _cell(f"B{r}", m[k], 3)])); r += 1
    r += 1
    head_row = r
    lines.append((r, [_cell(f"{_col(i)}{r}", h, 1) for i, h in enumerate(headers)])); r += 1
    for row in rows:
        lines.append((r, [_cell(f"{_col(i)}{r}", v, 4) for i, v in enumerate(row)])); r += 1
    last = r - 1
    widths = []
    for i, h in enumerate(headers):
        longest = max([len(str(h))] + [len(str(x[i])) for x in rows[:500] if i < len(x) and x[i] is not None])
        widths.append(min(60, max(10, longest + 2)))
    cols = "".join(f'<col min="{i + 1}" max="{i + 1}" width="{w}" customWidth="1"/>' for i, w in enumerate(widths))
    sheet_rows = "".join(f'<row r="{n}">{"".join(c)}</row>' for n, c in lines)
    end_col = _col(max(0, len(headers) - 1))
    sheet_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f'<sheetViews><sheetView workbookViewId="0"><pane ySplit="{head_row}" topLeftCell="A{head_row + 1}" '
        'activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
        f'<cols>{cols}</cols><sheetData>{sheet_rows}</sheetData>'
        + (f'<autoFilter ref="A{head_row}:{end_col}{max(head_row, last)}"/>' if headers else "")
        + ('<drawing r:id="rId1"/>' if size else "") + '</worksheet>')
    files = {
        "[Content_Types].xml": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Default Extension="png" ContentType="image/png"/>'
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            + ('<Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>' if size else "")
            + '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
            '</Types>'),
        "_rels/.rels": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
            '</Relationships>'),
        "docProps/core.xml": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            f'<dc:title>{_x(m["title"])}</dc:title><dc:creator>{_x(PORTAL)}</dc:creator>'
            f'<dcterms:created xsi:type="dcterms:W3CDTF">{datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}</dcterms:created>'
            '</cp:coreProperties>'),
        "xl/workbook.xml": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            f'<sheets><sheet name="{_x(sheet[:31])}" sheetId="1" r:id="rId1"/></sheets>'
            + (f'<definedNames><definedName name="_xlnm._FilterDatabase" localSheetId="0" hidden="1">'
               f"'{_x(sheet[:31])}'!$A${head_row}:${end_col}${max(head_row, last)}</definedName></definedNames>" if headers else "")
            + '</workbook>'),
        "xl/_rels/workbook.xml.rels": (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            '</Relationships>'),
        "xl/styles.xml": STYLES,
        "xl/worksheets/sheet1.xml": sheet_xml,
    }
    if size:
        w, h = size
        target_h = 64                         # pixels: about four rows
        target_w = max(1, round(w * target_h / max(1, h)))
        if target_w > 320:
            target_w, target_h = 320, max(1, round(h * 320 / w))
        emu = 9525
        files["xl/worksheets/_rels/sheet1.xml.rels"] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/>'
            '</Relationships>')
        files["xl/drawings/drawing1.xml"] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" '
            'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<xdr:oneCellAnchor><xdr:from><xdr:col>0</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>0</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>'
            f'<xdr:ext cx="{target_w * emu}" cy="{target_h * emu}"/>'
            '<xdr:pic><xdr:nvPicPr><xdr:cNvPr id="2" name="Logo"/><xdr:cNvPicPr><a:picLocks noChangeAspect="1"/></xdr:cNvPicPr></xdr:nvPicPr>'
            '<xdr:blipFill><a:blip r:embed="rId1"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill>'
            f'<xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{target_w * emu}" cy="{target_h * emu}"/></a:xfrm>'
            '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor></xdr:wsDr>')
        files["xl/drawings/_rels/drawing1.xml.rels"] = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image1.png"/>'
            '</Relationships>')
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name, text in files.items():
            z.writestr(name, text.encode("utf-8"))
        if size:
            z.writestr("xl/media/image1.png", logo_png)
    return buf.getvalue()
