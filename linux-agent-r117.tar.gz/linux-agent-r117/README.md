# PATCH-01 agent for Linux servers

RHEL 8 and 9, Oracle Linux 8, Ubuntu 22.04 and 24.04. One agent per server: it checks in
with PATCH-01 every 5 minutes, reports what is installed and what can be updated, and runs
the patch jobs PATCH-01 sends (with the server's own package manager).

## What you need on each server

* root, Python 3, systemd
* HTTPS from the server to PATCH-01 (443)
* PATCH-01's CA certificate (PEM), unless the server already trusts PATCH-01's certificate
* an enrolment token, for a new server. On PATCH-01:  `./phase10-windows.sh --tokens 1 <group>`

## One server

    tar -xzf linux-agent-rNNN.tar.gz && cd linux-agent-rNNN
    sudo ./setup-agent.sh

It asks for PATCH-01's address, checks the certificate, asks for the token, installs, enrols,
and offers to point the package manager at PATCH-01's repositories (below). Upgrading an
enrolled server keeps its identity and needs no token.

## Many servers (over SSH)

    ./push-linux.sh -H servers.txt -s https://patch01.corp.local --ca corp-ca.pem --test-only
    ./push-linux.sh -H servers.txt -s https://patch01.corp.local --ca corp-ca.pem -t tokens.txt

## PATCH-01's repositories: do I need a repository file?

**Yes, for patching through PATCH-01.** The agent installs updates with the server's own
package manager (dnf or apt), from whatever repositories the server has. To have every
server install what PATCH-01 synced and assessed, point them at PATCH-01:

| Server | File in `repos/` | Goes to |
|---|---|---|
| RHEL 8 | `patch01-rhel8.repo` | `/etc/yum.repos.d/patch01.repo` |
| RHEL 9 | `patch01-rhel9.repo` | `/etc/yum.repos.d/patch01.repo` |
| Oracle Linux 8 | `patch01-ol8.repo` | `/etc/yum.repos.d/patch01.repo` |
| Ubuntu 22.04 | `patch01-ubuntu2204.list` | `/etc/apt/sources.list.d/patch01.list` |
| Ubuntu 24.04 | `patch01-ubuntu2404.list` | `/etc/apt/sources.list.d/patch01.list` |

The only thing to fill in is **`PATCH01_HOST`** (PATCH-01's name, as servers reach it). The
installer fills it in by itself from `--server`:

    sudo ./install-agent.sh --server https://patch01.corp.local --ca corp-ca.pem --repo-file repos/patch01-rhel9.repo

or `setup-agent.sh` asks. PATCH-01 also shows each file ready to copy, with its own address,
in **Admin › Repositories**.

The repositories must exist and be published on PATCH-01 first (**Admin › Repositories**:
Sync and publish). Then turn the server's own vendor repositories off, so every update comes
through PATCH-01 (each file's comments say how). Packages keep the vendor's signature, which
the server checks (gpgcheck=1, apt with Ubuntu's key).

## Check, remove

    sudo ./install-agent.sh --status
    sudo ./install-agent.sh --uninstall
