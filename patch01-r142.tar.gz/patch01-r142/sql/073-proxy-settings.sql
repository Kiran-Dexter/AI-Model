-- ---------------------------------------------------------------------------
-- 073 (r138) The corporate proxy, set under Admin > Proxy
--
-- proxy_settings  one row: install (proxy.env, as before), direct (no proxy) or proxy (this address,
--                 a login only if the proxy asks; the password Fernet-encrypted, never shown again).
--                 The worker applies it within 30 seconds and records what it uses (worker_*) and
--                 what it set on the Pulp repositories (pulp_*).
-- proxy_tests     a test asked for on the page and run by the worker: every outside source tried
--                 with the given settings; the password is removed once the test has run
-- Re-run safe.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS proxy_settings (
    id              SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    mode            TEXT NOT NULL DEFAULT 'install' CHECK (mode IN ('install', 'direct', 'proxy')),
    url             TEXT CHECK (url IS NULL OR url ~ '^https?://[A-Za-z0-9.-]{1,253}(:[0-9]{1,5})?$'),
    username        TEXT,
    password_enc    TEXT,
    no_proxy        TEXT NOT NULL DEFAULT '',
    updated_by      TEXT,
    updated_at      TIMESTAMPTZ,
    worker_url      TEXT,
    worker_source   TEXT,
    worker_error    TEXT,
    worker_seen_at  TIMESTAMPTZ,
    install_url     TEXT,
    pulp_applied_at TIMESTAMPTZ,
    pulp_result     TEXT,
    CHECK (mode <> 'proxy' OR url IS NOT NULL)
);
INSERT INTO proxy_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS proxy_tests (
    id            BIGSERIAL PRIMARY KEY,
    requested_by  TEXT NOT NULL,
    requested_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    mode          TEXT NOT NULL CHECK (mode IN ('install', 'direct', 'proxy')),
    url           TEXT,
    username      TEXT,
    password_enc  TEXT,
    no_proxy      TEXT NOT NULL DEFAULT '',
    started_at    TIMESTAMPTZ,
    done_at       TIMESTAMPTZ,
    results       JSONB,
    error         TEXT
);

INSERT INTO schema_version (version, description)
VALUES (73, 'The corporate proxy, set under Admin > Proxy')
ON CONFLICT (version) DO NOTHING;
