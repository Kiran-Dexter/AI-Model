-- ---------------------------------------------------------------------------
-- 072 (r137) One CVE pipeline: assessments kept up to date, new sources, appliances of any maker
--
-- cve_assessments.closed_*      an assessment is checked again with the Detected CVEs (same analysis, same
--                               result) until it is closed, or for 90 days
-- cve_assessment_items.first    what the assessment found when it was submitted (kept for the record)
-- cve_assessment_changes        each change since: a CVE's word or its count of machines, when, and why
-- cve_org                       CVE.org's record of a CVE: the vendor's own versions, its score, CISA's
--                               assessment (exploitation, automatable, technical impact, KEV)
-- advisories.origin             'repo' (the Pulp mirror) or 'oval' (Oracle's OVAL file)
-- cve_feed_settings.new_sources off, shadow (read and compared, verdicts unchanged) or on
-- cve_impact.shadow             what the new sources would make of a CVE while they are in shadow
-- manual_assets.firmware        an appliance's firmware version, from the asset sheet
-- appliance_decisions           an admin's word that a device model is (or is not) a CVE's product
-- Re-run safe.
-- ---------------------------------------------------------------------------

ALTER TABLE cve_assessments ADD COLUMN IF NOT EXISTS closed_at TIMESTAMPTZ;
ALTER TABLE cve_assessments ADD COLUMN IF NOT EXISTS closed_by TEXT;
ALTER TABLE cve_assessments ADD COLUMN IF NOT EXISTS refreshed_at TIMESTAMPTZ;
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS first JSONB;
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS refreshed_at TIMESTAMPTZ;

CREATE TABLE IF NOT EXISTS cve_assessment_changes (
    id            BIGSERIAL PRIMARY KEY,
    assessment_id UUID NOT NULL REFERENCES cve_assessments(id) ON DELETE CASCADE,
    cve_id        TEXT NOT NULL,
    at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    from_word     TEXT,
    to_word       TEXT,
    from_n        INTEGER,
    to_n          INTEGER,
    detail        TEXT
);
CREATE INDEX IF NOT EXISTS idx_assess_changes ON cve_assessment_changes (assessment_id, at DESC);

CREATE TABLE IF NOT EXISTS cve_org (
    cve_id             TEXT PRIMARY KEY CHECK (cve_id ~ '^CVE-[0-9]{4}-[0-9]{4,7}$'),
    state              TEXT,
    assigner           TEXT,
    date_updated       TIMESTAMPTZ,
    products           JSONB NOT NULL DEFAULT '[]',
    cvss               NUMERIC(3,1),
    cvss_severity      TEXT,
    cvss_vector        TEXT,
    cvss_source        TEXT,
    ssvc_exploitation  TEXT,
    ssvc_automatable   TEXT,
    ssvc_impact        TEXT,
    kev_added          DATE,
    fetched_at         TIMESTAMPTZ,
    error              TEXT,
    not_found          BOOLEAN NOT NULL DEFAULT false
);

ALTER TABLE advisories ADD COLUMN IF NOT EXISTS origin TEXT NOT NULL DEFAULT 'repo';
DO $$ BEGIN
    ALTER TABLE advisories ADD CONSTRAINT advisories_origin_chk CHECK (origin IN ('repo', 'oval'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE cve_feed_settings ADD COLUMN IF NOT EXISTS new_sources TEXT NOT NULL DEFAULT 'shadow';
DO $$ BEGIN
    ALTER TABLE cve_feed_settings ADD CONSTRAINT cve_feed_new_sources_chk CHECK (new_sources IN ('off', 'shadow', 'on'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
ALTER TABLE cve_feed_settings ADD COLUMN IF NOT EXISTS new_sources_by TEXT;
ALTER TABLE cve_feed_settings ADD COLUMN IF NOT EXISTS new_sources_at TIMESTAMPTZ;
ALTER TABLE cve_feed_settings ADD COLUMN IF NOT EXISTS oval_imported_at TIMESTAMPTZ;
ALTER TABLE cve_feed_settings ADD COLUMN IF NOT EXISTS oval_result JSONB;

ALTER TABLE cve_impact ADD COLUMN IF NOT EXISTS shadow JSONB;

ALTER TABLE manual_assets ADD COLUMN IF NOT EXISTS firmware TEXT;

CREATE TABLE IF NOT EXISTS appliance_decisions (
    model_key  TEXT NOT NULL CHECK (length(model_key) BETWEEN 1 AND 200),
    vendor     TEXT NOT NULL CHECK (length(vendor) BETWEEN 1 AND 100),
    product    TEXT NOT NULL CHECK (length(product) BETWEEN 1 AND 150),
    decision   TEXT NOT NULL CHECK (decision IN ('same', 'different')),
    decided_by TEXT NOT NULL,
    decided_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (model_key, vendor, product)
);

INSERT INTO schema_version (version, description)
VALUES (72, 'One CVE pipeline: live assessments, CVE.org, Oracle OVAL, appliances of any maker')
ON CONFLICT (version) DO NOTHING;
