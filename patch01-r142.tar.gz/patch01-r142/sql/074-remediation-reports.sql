-- ---------------------------------------------------------------------------
-- 074 (r141) Remediation > Reports: who gets each team's or PIC's report
--
-- rem_recipients  per team (key 'application|Team A', as the Hosts tab sets it) or per PIC (key: the PIC as the
--                 file writes it), the addresses its report goes to, set once; and the last time it was sent
-- Re-run safe.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS rem_recipients (
    by_kind     TEXT NOT NULL CHECK (by_kind IN ('team', 'pic')),
    key         TEXT NOT NULL CHECK (length(key) <= 400),
    emails      TEXT[] NOT NULL DEFAULT '{}',
    updated_by  TEXT,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    sent_at     TIMESTAMPTZ,
    sent_by     TEXT,
    sent_rows   INT,
    sent_error  TEXT,
    PRIMARY KEY (by_kind, key)
);

INSERT INTO schema_version (version, description)
VALUES (74, 'Remediation reports: addresses per team or PIC')
ON CONFLICT (version) DO NOTHING;
