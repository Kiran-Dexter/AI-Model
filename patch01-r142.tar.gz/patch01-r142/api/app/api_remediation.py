"""Vulnerabilities > Remediation (r131): the quarterly Nessus scan workbook. The work is in remediation.py."""

import re
from typing import Dict, List, Optional

from fastapi import Depends, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field

from .core import app, audit, client_ip, db, jsonable, require_operator, require_viewer
from . import remediation as rm

BASE = "/api/v1/nessus/remediation"
FILTER_KEYS = ("quarter", "sev", "status", "open", "action", "pic", "cat1", "cat2", "env", "kind", "team_type", "host", "overdue",
               "came_back", "new", "q", "group_by", "group", "due", "team", "hosts")


def _filters(request: Request):
    """The page's filters from the query string. "(blank)" is sent as an empty value of *_blank=1."""
    p = {}
    for k in FILTER_KEYS:
        v = request.query_params.get(k)
        if v is not None:
            if re.search(r"[\x00-\x08\x0b-\x1f\x7f]", v):
                raise HTTPException(400, f"{k}: control characters are not allowed.")
            p[k] = v[:600]
    for k in ("pic", "cat1", "cat2", "env", "team"):
        if request.query_params.get(k + "_blank") == "1":
            p[k] = "\x00"
    return p


def _call(fn):
    try:
        return fn()
    except rm.RemError as e:
        raise HTTPException(400, str(e))
    except rm.NotFound as e:
        raise HTTPException(404, str(e))


def _uid(v, what="upload"):
    v = str(v or "").strip().lower()
    if not re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", v):
        raise HTTPException(404, f"No such {what}.")
    return v


def _audit(conn, user, request, action, detail):
    audit(conn, actor=user, actor_type="user", action=action, object_type="remediation", detail=detail,
          source_ip=client_ip(request))
    conn.commit()


def _can_edit(request):
    from . import auth
    return auth.role_at_least((request.state.user or {}).get("role") or "viewer", "operator")


@app.get(BASE)
def rem_home(request: Request, user: str = Depends(require_viewer)):
    """The quarters there are, the uploads (the latest first), and what this user may do."""
    with db() as conn:
        return jsonable({"quarters": rm.quarters(conn), "uploads": rm.uploads(conn), "can_edit": _can_edit(request),
                         "statuses": [{"key": k, "label": l} for k, l in rm.STATUSES],
                         "severities": [{"key": k, "label": l} for k, l in rm.SEVERITIES],
                         "kinds": [{"key": k, "label": l} for k, l in rm.KINDS.items()],
                         "groups": [{"key": k, "label": v[1]} for k, v in rm.GROUPS.items()]})


@app.get(BASE + "/summary")
def rem_summary(request: Request, user: str = Depends(require_viewer)):
    p = _filters(request)
    with db() as conn:
        return jsonable(_call(lambda: rm.summary(conn, p)))


@app.get(BASE + "/categories")
def rem_categories(request: Request, user: str = Depends(require_viewer)):
    """Categorization2 -> Categorization1 -> severity, with the page's other filters."""
    p = _filters(request)
    with db() as conn:
        return jsonable(_call(lambda: rm.categories(conn, p)))


@app.get(BASE + "/groups")
def rem_groups(request: Request, user: str = Depends(require_viewer)):
    p = _filters(request)
    with db() as conn:
        return jsonable(_call(lambda: rm.groups(conn, p)))


@app.get(BASE + "/findings")
def rem_findings(request: Request, offset: int = 0, limit: int = 200, user: str = Depends(require_viewer)):
    p = _filters(request)
    with db() as conn:
        return jsonable(_call(lambda: rm.findings(conn, p, offset, limit)))


@app.get(BASE + "/findings/{fid}")
def rem_finding(fid: int, user: str = Depends(require_viewer)):
    with db() as conn:
        return jsonable(_call(lambda: rm.finding(conn, fid)))


class BulkIn(BaseModel):
    ids: Optional[List[int]] = Field(None, max_length=50000)
    all: bool = False                                  # every finding the filters show (the filters are in the query)
    set: Dict[str, Optional[str]] = Field(default_factory=dict)
    note: Optional[str] = Field(None, max_length=500)


@app.post(BASE + "/findings/bulk")
def rem_bulk(body: BulkIn, request: Request, user: str = Depends(require_operator)):
    p = _filters(request)
    if not body.all and not body.ids:
        raise HTTPException(400, "Choose at least one finding.")
    with db() as conn:
        r = _call(lambda: rm.bulk_edit(conn, user, ids=None if body.all else body.ids, params=p if body.all else None,
                                       changes=body.set, note=body.note))
        _audit(conn, user, request, "remediation_edited", {"set": {k: v for k, v in body.set.items()}, "note": body.note,
                                                           "findings": r["findings"], "changed": r["changed"],
                                                           "by_filter": bool(body.all), "quarter": p.get("quarter")})
    return r


@app.get(BASE + "/targets")
def rem_targets(request: Request, by: str = "team", user: str = Depends(require_viewer)):
    """r141: what is still to fix (Open, Pending review, Pending deviation approval), by team or PIC, each host under
    it, with the due dates: how many passed, how many have none."""
    p = _filters(request)
    with db() as conn:
        return jsonable(_call(lambda: rm.targets(conn, p, by)))


@app.get(BASE + "/hosts")
def rem_hosts(request: Request, user: str = Depends(require_viewer)):
    p = _filters(request)
    with db() as conn:
        return jsonable(_call(lambda: rm.hosts(conn, p)))


class HostsIn(BaseModel):
    keys: List[str] = Field(..., min_length=1, max_length=5000)
    team_type: Optional[str] = Field(None, max_length=20)
    team: Optional[str] = Field(None, max_length=120)
    kind: Optional[str] = Field(None, max_length=20)


@app.put(BASE + "/hosts")
def rem_hosts_set(body: HostsIn, request: Request, user: str = Depends(require_operator)):
    keys = [k[:255] for k in body.keys if k]
    with db() as conn:
        n = _call(lambda: rm.set_hosts(conn, user, keys, body.team_type, body.team, body.kind))
        _audit(conn, user, request, "remediation_hosts_set", {"hosts": len(keys), "team_type": body.team_type,
                                                              "team": body.team, "kind": body.kind})
    return {"hosts": n}


@app.post(BASE + "/hosts/refresh")
def rem_hosts_refresh(request: Request, user: str = Depends(require_operator)):
    """Each host's device type looked up in the inventory again (after an asset was added or its type set)."""
    with db() as conn:
        n = _call(lambda: rm.refresh_hosts(conn))
    return {"hosts": n}


# ---- uploads ---------------------------------------------------------------------------------------------------

@app.post(BASE + "/uploads")
async def rem_upload(request: Request, name: str = "scan.xlsx", gz: int = 0, user: str = Depends(require_operator)):
    """The file itself as the request body (xlsx or csv; a big csv gzipped by the browser, gz=1). At most 60 MB."""
    from starlette.concurrency import run_in_threadpool
    data = bytearray()
    async for chunk in request.stream():
        data += chunk
        if len(data) > rm.MAX_BYTES:
            raise HTTPException(413, "The file is larger than 60 MB. Save it as .xlsx (it is much smaller than .csv) and try again.")

    def work():
        with db() as conn:
            uid = _call(lambda: rm.start_upload(conn, user, name, bytes(data), bool(gz)))
            _audit(conn, user, request, "remediation_uploaded", {"upload": uid, "file": name[:200], "bytes": len(data)})
            return uid
    uid = await run_in_threadpool(work)
    rm.run_in_background(rm.read_upload, uid)
    return {"id": uid}


@app.get(BASE + "/uploads")
def rem_uploads(user: str = Depends(require_viewer)):
    with db() as conn:
        return jsonable({"items": rm.uploads(conn, 50)})


@app.get(BASE + "/uploads/{uid}")
def rem_upload_view(uid: str, user: str = Depends(require_viewer)):
    uid = _uid(uid)
    with db() as conn:
        return jsonable(_call(lambda: rm.upload_view(conn, uid)))


@app.post(BASE + "/uploads/{uid}/suggest")
def rem_upload_suggest(uid: str, request: Request, user: str = Depends(require_operator)):
    """AI-01 reads the columns PATCH-01's rules could not place (heading and a few values each)."""
    from . import llm
    uid = _uid(uid)
    if not llm.configured():
        raise HTTPException(503, "AI-01 is not set up: place the columns yourself.")

    def ask(messages, schema):
        return llm.choose(messages, max_tokens=900, timeout=50, schema=schema, temperature=0.1, wait=20)
    with db() as conn:
        llm.mark_interactive(conn)
        try:
            n = _call(lambda: rm.suggest(conn, uid, ask))
        except llm.LLMBusy:
            raise HTTPException(429, "AI-01 is busy: try again in a moment, or place the columns yourself.")
        except llm.LLMUnavailable as e:
            raise HTTPException(503, f"AI-01 could not be reached ({str(e)[:160]}): place the columns yourself.")
        _audit(conn, user, request, "remediation_ai_columns", {"upload": uid, "placed": n})
        return jsonable(dict(rm.upload_view(conn, uid), ai_placed=n))


class ConfirmSheet(BaseModel):
    name: str = Field(..., max_length=200)
    use: bool = True
    quarter: Optional[str] = Field(None, max_length=20)
    columns: Optional[List[Optional[str]]] = Field(None, max_length=rm.MAX_COLS)


class ConfirmIn(BaseModel):
    sheets: List[ConfirmSheet] = Field(..., max_length=100)
    status_words: Dict[str, str] = Field(default_factory=dict)
    date_order: Optional[str] = Field(None, pattern="^(dmy|mdy)$")
    remove_missing: bool = False


@app.post(BASE + "/uploads/{uid}/confirm")
def rem_upload_confirm(uid: str, body: ConfirmIn, request: Request, user: str = Depends(require_operator)):
    uid = _uid(uid)
    if len(body.status_words) > 200:
        raise HTTPException(400, "Too many status words.")
    with db() as conn:
        qs = _call(lambda: rm.confirm(conn, uid, user, body.model_dump()))
        _audit(conn, user, request, "remediation_import_started", {"upload": uid, "quarters": qs,
                                                                   "remove_missing": body.remove_missing})
    rm.run_in_background(rm.run_import, uid)
    return {"ok": True, "quarters": qs}


@app.post(BASE + "/uploads/{uid}/retry")
def rem_upload_retry(uid: str, request: Request, user: str = Depends(require_operator)):
    uid = _uid(uid)
    with db() as conn:
        state = _call(lambda: rm.retry(conn, uid))
        _audit(conn, user, request, "remediation_retried", {"upload": uid, "state": state})
    rm.run_in_background(rm.run_import if state == "importing" else rm.read_upload, uid)
    return {"ok": True, "state": state}


@app.delete(BASE + "/uploads/{uid}")
def rem_upload_discard(uid: str, request: Request, user: str = Depends(require_operator)):
    uid = _uid(uid)
    with db() as conn:
        _call(lambda: rm.discard(conn, uid))
        _audit(conn, user, request, "remediation_discarded", {"upload": uid})
    return {"ok": True}


# ---- export ----------------------------------------------------------------------------------------------------

@app.get(BASE + "/export")
def rem_export(request: Request, user: str = Depends(require_viewer)):
    """The quarter (as filtered) in the file's own columns and headings, with a Summary sheet."""
    from . import exports as ex
    p = _filters(request)
    p.pop("group_by", None)
    p.pop("group", None)
    with db() as conn:
        body, n = _call(lambda: rm.export_xlsx(conn, p, user, ex.company_name(conn)))
        _audit(conn, user, request, "remediation_exported", {"quarter": p.get("quarter"), "rows": n})
    q = rm.short_label(p.get("quarter") or "")
    return Response(body, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={
        "Content-Disposition": f'attachment; filename="{ex.file_name("remediation-" + q, "xlsx")}"',
        "Cache-Control": "no-store", "X-Rows": str(n)})


# ---- AI-01's summary of a view ---------------------------------------------------------------------------------

def _summary_ask():
    from . import llm

    def ask(messages, schema):
        # a CPU host writes a long answer slowly: up to 5 minutes; a busy AI-01 is waited for by run_summary
        return llm.choose(messages, max_tokens=rm.SUM_ANSWER, timeout=300, schema=schema, temperature=0.2, wait=30)
    return ask


@app.get(BASE + "/ai-summary")
def rem_summary_latest(request: Request, user: str = Depends(require_viewer)):
    """The newest summary of the view the filters describe, or null."""
    p = _filters(request)
    p.pop("group_by", None)
    p.pop("group", None)
    with db() as conn:
        return jsonable({"summary": _call(lambda: rm.latest_summary(conn, p))})


@app.post(BASE + "/ai-summary")
def rem_summary_start(request: Request, user: str = Depends(require_viewer)):
    """AI-01 summarises the view (in the background: a CPU host takes a few minutes). One at a time per view."""
    from . import llm
    if not llm.configured():
        raise HTTPException(503, "AI-01 is not set up.")
    p = _filters(request)
    p.pop("group_by", None)
    p.pop("group", None)
    with db() as conn:
        running = rm.summary_running(conn, p)
        if running:
            return {"id": running["id"], "already": True}
        llm.mark_interactive(conn)
        sid = _call(lambda: rm.start_summary(conn, user, p))
        _audit(conn, user, request, "remediation_ai_summary", {"summary": sid, "quarter": p.get("quarter"),
                                                              "view": rm.view_of(p)[1]})
    rm.run_summary_in_background(sid, _summary_ask())
    return {"id": sid}


@app.get(BASE + "/ai-summary/{sid}")
def rem_summary_view(sid: str, user: str = Depends(require_viewer)):
    sid = _uid(sid, "summary")
    with db() as conn:
        return jsonable(_call(lambda: rm.summary_view(conn, sid)))


# ---- the target date -------------------------------------------------------------------------------------------

class TargetIn(BaseModel):
    quarter: str = Field(..., max_length=20)            # "2026 Q3", or "default" (every quarter without its own)
    date: Optional[str] = Field(None, max_length=10)    # YYYY-MM-DD; empty removes a quarter's own date


@app.put(BASE + "/target")
def rem_target_set(body: TargetIn, request: Request, user: str = Depends(require_operator)):
    with db() as conn:
        d = _call(lambda: rm.set_target(conn, user, body.quarter, body.date or ""))
        _audit(conn, user, request, "remediation_target_set", {"quarter": body.quarter, "date": d.isoformat() if d else None})
        t = rm.target_of(conn, body.quarter) if body.quarter != "default" else None
    return jsonable({"quarter": body.quarter, "date": d, "now": t})


# ---- r141: Reports: each team's or PIC's findings to fix, to its own addresses --------------------------------

REPORT_MAILS_PER_HOUR = 120
REPORT_GROUPS_MAX = 100
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def _mail_policy(cfg):
    """Remediation reports list weaknesses: only addresses in the organisation's mail domains (the sender's and the
    recipients' set under Admin > Mail), or those recipients themselves."""
    domains = {a.rsplit("@", 1)[-1].lower() for a in [cfg.get("from") or ""] + list(cfg.get("to") or []) if "@" in a}
    known = {a.lower() for a in cfg.get("to") or []}
    return domains, known


def _outside(addresses, domains, known):
    return [a for a in addresses if a.lower() not in known and a.rsplit("@", 1)[-1].lower() not in domains]


@app.get(BASE + "/reports")
def rem_reports(request: Request, by: str = "team", user: str = Depends(require_viewer)):
    from . import notify as nt
    p = _filters(request)
    with db() as conn:
        d = _call(lambda: rm.report_groups(conn, p, by))
        cfg = nt.config(conn, with_password=False)
        domains, _known = _mail_policy(cfg)
        d["mail"] = {"ready": bool(cfg.get("host") and cfg.get("from")), "domains": sorted(domains)[:10]}
        return jsonable(d)


class RecipientsIn(BaseModel):
    by: str = Field(..., pattern="^(team|pic)$")
    key: str = Field(..., max_length=400)
    emails: List[str] = Field(default_factory=list, max_length=rm.MAX_RECIPIENTS)


@app.put(BASE + "/reports/recipients")
def rem_recipients_set(body: RecipientsIn, request: Request, user: str = Depends(require_operator)):
    from . import notify as nt
    with db() as conn:
        emails = _call(lambda: rm.clean_emails(body.emails))
        domains, known = _mail_policy(nt.config(conn, with_password=False))
        bad = _outside(emails, domains, known)
        if bad and domains:
            raise HTTPException(403, "Remediation reports go only to addresses in your organisation's mail domains ("
                                     + ", ".join(sorted(domains)[:5]) + "). Not allowed: " + ", ".join(bad[:5]))
        emails = _call(lambda: rm.set_recipients(conn, user, body.by, body.key, emails))
        _audit(conn, user, request, "remediation_recipients_set", {"by": body.by, "key": body.key, "emails": emails})
    return {"key": body.key, "emails": emails}


class ReportSendIn(BaseModel):
    quarter: str = Field(..., max_length=20)
    by: str = Field("team", pattern="^(team|pic)$")
    keys: List[str] = Field(default_factory=list, max_length=REPORT_GROUPS_MAX)     # the groups to send to (own addresses)
    full_to: List[str] = Field(default_factory=list, max_length=rm.MAX_RECIPIENTS)   # the master report, to these
    subject: Optional[str] = Field(None, max_length=200)
    message: Optional[str] = Field(None, max_length=4000)
    set_shared: bool = True                                                         # Report Shared Date = today


def _send_one(nt, cfg, conn, to, subject, intro, blocks, files):
    text, html = nt.render(cfg, subject, "info", intro, blocks, link="/#/remediation?tab=targets", label="Remediation report",
                           greeting=True)
    state, err = "sent", None
    try:
        nt.send(cfg, to, subject, text, html, attachments=files)
    except Exception as e:  # noqa: BLE001 - reported back and recorded
        state, err = "failed", str(e)
    with conn.transaction():
        conn.execute("""INSERT INTO notifications (category, severity, subject, body_text, body_html, recipients, state,
                                                   attempts, sent_at, last_error, event_keys)
                        VALUES ('report', 'info', %s, %s, %s, %s, %s, 1, CASE WHEN %s THEN now() END, %s, %s)""",
                     (subject, text, html, to, state, state == "sent", err, ["remediation-report"]))
    conn.commit()
    return err


@app.post(BASE + "/reports/send")
def rem_reports_send(body: ReportSendIn, request: Request, user: str = Depends(require_operator)):
    """Each chosen team (or PIC) gets its own findings to fix (Excel attached, the worst in the mail), at the addresses
    set for it; the master report (the whole quarter, every status, in the file's own columns) goes to full_to.
    Report Shared Date is set to today on what each team was sent (set_shared)."""
    from . import exports as ex, notify as nt
    if any(c in (body.subject or "") for c in "\r\n"):
        raise HTTPException(422, "The subject cannot contain a line break.")
    if not body.keys and not body.full_to:
        raise HTTPException(400, "Choose the teams to send to, or type the addresses for the master report.")
    q = body.quarter
    with db() as conn:
        _call(lambda: rm.where({"quarter": q}))
        cfg = nt.config(conn)
        if not (cfg["host"] and cfg["from"]):
            raise HTTPException(409, "Mail is not set up yet: an admin can do it under Admin, Mail.")
        domains, known = _mail_policy(cfg)
        full_to = _call(lambda: rm.clean_emails(body.full_to))
        rec = rm.recipients(conn, body.by)
        plan = []
        for k in dict.fromkeys(body.keys):
            emails = list((rec.get(k) or {}).get("emails") or [])
            plan.append((k, emails))
        bad = _outside(full_to + [a for _k, e in plan for a in e], domains, known)
        if bad:
            raise HTTPException(403, "Remediation reports go only to addresses in your organisation's mail domains ("
                                     + ", ".join(sorted(domains)[:5]) + "). Not allowed: " + ", ".join(bad[:5]))
        mails = sum(1 for _k, e in plan if e) + (1 if full_to else 0)
        n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'remediation_report_sent'
                              AND occurred_at > now() - interval '1 hour'""", (user,)).fetchone()["n"]
        if n + mails > REPORT_MAILS_PER_HOUR:
            raise HTTPException(429, f"At most {REPORT_MAILS_PER_HOUR} report e-mails an hour: {n} sent in the last hour.")
        company = ex.company_name(conn)
        short = rm.short_label(q)
        message = (body.message or "").strip()
        results = []
        labels = {g["key"]: g for g in rm.targets(conn, {"quarter": q}, body.by)["groups"]}
        for key, emails in plan:
            g = labels.get(key)
            label = g["label"] if g else (key or "(blank)")
            if not emails:
                results.append({"key": key, "label": label, "state": "skipped", "error": "no address set for it"})
                continue
            if not g:
                results.append({"key": key, "label": label, "state": "skipped", "error": "nothing to fix"})
                continue
            params = dict(rm.target_params({"quarter": q}), **rm.group_params(body.by, key))
            data, rows_n = _call(lambda: rm.export_xlsx(conn, params, user, company))
            top = rm.report_rows(conn, params)
            subject = (body.subject or f"Remediation {q}: findings to fix") + f" · {label}"
            blocks = []
            if message:
                blocks.append(("text", message))
            blocks.append(("kv", [("Findings to fix", str(g["findings"])), ("Hosts", str(g["host_count"])),
                                  ("Target date passed", str(g["expired"])), ("No target date", str(g["no_date"])),
                                  ("Critical / High", f"{g['s4']} / {g['s3']}")]))
            blocks.append(("table", ["Host", "Severity", "Finding", "Status", "Due"],
                           [[r["hostname"] or r["ip"] or "", rm.SEV.get(r["severity"], ""), (r["plugin_name"] or "")[:90],
                             rm.STATUS.get(r["status"], r["status"]), (r["due_on"] or "none") + (" (passed)" if r["expired"] else "")]
                            for r in top]))
            if rows_n > len(top):
                blocks.append(("p", f"The {len(top)} most urgent of {rows_n}; every one is in the attached Excel file."))
            err = _send_one(nt, cfg, conn, emails, subject,
                            f"{label}: {g['findings']} finding(s) to fix in {q}, {g['expired']} past the target date.",
                            blocks, [(ex.file_name(f"remediation-{short}-{label}"[:80], "xlsx"), data, XLSX)])
            shared = None
            if not err and body.set_shared:
                shared = rm.mark_shared(conn, user, params)["changed"]
            rm.note_sent(conn, user, body.by, key, rows_n, err)
            audit(conn, actor=user, actor_type="user", action="remediation_report_sent", object_type="remediation",
                  detail={"quarter": q, "by": body.by, "key": key, "to": emails, "rows": rows_n, "error": err,
                          "report_shared_set": shared}, source_ip=client_ip(request))
            conn.commit()
            results.append({"key": key, "label": label, "to": emails, "rows": rows_n, "state": "failed" if err else "sent",
                            "error": err, "report_shared_set": shared})
        if full_to:
            data, rows_n = _call(lambda: rm.export_xlsx(conn, {"quarter": q}, user, company))
            t = rm.targets(conn, {"quarter": q}, body.by)["totals"]
            subject = body.subject or f"Remediation {q}: master report"
            blocks = ([("text", message)] if message else []) + [("kv", [
                ("Findings in the quarter", str(rows_n)), ("To fix", str(t["findings"])), ("Hosts with findings to fix", str(t["hosts"])),
                ("Target date passed", str(t["expired"])), ("No target date", str(t["no_date"]))])]
            err = _send_one(nt, cfg, conn, full_to, subject, f"The master report of {q}: every finding, every status, with the target dates.",
                            blocks, [(ex.file_name(f"remediation-{short}-master", "xlsx"), data, XLSX)])
            audit(conn, actor=user, actor_type="user", action="remediation_report_sent", object_type="remediation",
                  detail={"quarter": q, "master": True, "to": full_to, "rows": rows_n, "error": err}, source_ip=client_ip(request))
            conn.commit()
            results.append({"key": None, "label": "Master report", "to": full_to, "rows": rows_n,
                            "state": "failed" if err else "sent", "error": err})
    return {"results": results, "sent": sum(1 for r in results if r["state"] == "sent"),
            "failed": sum(1 for r in results if r["state"] == "failed")}


# ---- r141: Ask AI-01 ---------------------------------------------------------------------------------------------

class AskIn(BaseModel):
    quarter: str = Field(..., max_length=20)
    question: str = Field(..., min_length=1, max_length=500)


def _ask_call(fn):
    from . import rem_ask
    try:
        return _call(fn)
    except rem_ask.AskError as e:
        raise HTTPException(400, str(e))


@app.post(BASE + "/ask")
def rem_ask_q(body: AskIn, request: Request, user: str = Depends(require_viewer)):
    """A request in words: the findings (show), a consolidated view (report) or a change, previewed only (update)."""
    from . import llm, rem_ask
    ask = None
    if llm.configured():
        def ask(messages, schema):
            return llm.choose(messages, max_tokens=400, timeout=120, schema=schema, temperature=0.1, wait=20)
    with db() as conn:
        if ask:
            llm.mark_interactive(conn)
        r = _ask_call(lambda: rem_ask.answer(conn, user, body.question, body.quarter, ask))
        r["can_apply"] = _can_edit(request)
        _audit(conn, user, request, "remediation_ask", {"quarter": body.quarter, "question": body.question[:300],
                                                        "intent": r["intent"], "how": r["how"], "count": r.get("count")})
        return jsonable(r)


class AskApplyIn(BaseModel):
    view: Dict = Field(...)
    set: Dict[str, Optional[str]] = Field(...)
    expect: int = Field(..., ge=1, le=50000)


@app.post(BASE + "/ask/apply")
def rem_ask_apply(body: AskApplyIn, request: Request, user: str = Depends(require_operator)):
    """The change the assistant previewed, applied after the operator pressed Apply (the same findings, checked again)."""
    from . import rem_ask
    with db() as conn:
        r = _ask_call(lambda: rem_ask.apply(conn, user, body.view, body.set, body.expect))
        _audit(conn, user, request, "remediation_edited", {"set": body.set, "note": "AI-01 assistant", "findings": r["findings"],
                                                           "changed": r["changed"], "by_filter": True,
                                                           "quarter": body.view.get("quarter"), "assistant": True})
    return r


class AskExportIn(BaseModel):
    view: Dict = Field(...)


@app.post(BASE + "/ask/export")
def rem_ask_export(body: AskExportIn, request: Request, user: str = Depends(require_viewer)):
    """The assistant's view as Excel, in the file's own columns."""
    from . import exports as ex, rem_ask
    with db() as conn:
        view = _ask_call(lambda: rem_ask.clean_view(conn, body.view))
        data, n = _call(lambda: rm.export_xlsx(conn, view, user, ex.company_name(conn)))
        _audit(conn, user, request, "remediation_exported", {"quarter": view.get("quarter"), "rows": n, "assistant": True})
    return Response(data, media_type=XLSX, headers={
        "Content-Disposition": f'attachment; filename="{ex.file_name("remediation-" + rm.short_label(view["quarter"]) + "-view", "xlsx")}"',
        "Cache-Control": "no-store", "X-Rows": str(n)})
