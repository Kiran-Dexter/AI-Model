"""Remediation > Ask AI-01 (r141): the quarter's findings in words.

  "show the critical findings of web01 and web02 still open"            show       the findings, the first 50, and how many
  "consolidated report of the overdue ones by team"                     report     grouped (team, PIC, host, severity, status,
                                                                                   Categorization2) with the tally, and an Excel file
  "set target date 31 Dec 2026 for Team Payments where it has passed"   update     what would change and on how many findings;
  "mark db01 findings as fixed"                                                    nothing changes until the operator presses Apply

AI-01 reads the question into a plan (a JSON schema it must follow). PATCH-01's rules read the same question for what
they can be sure of (host names and IPs of the quarter, dates, severities, statuses), and every value of the plan is
checked against the quarter itself: a host, team or PIC that is not in it is never guessed. An update whose
findings cannot all be named exactly is refused rather than applied to more than was meant. Apply goes through the
same checks again and through the same bulk change as the Findings tab (each change kept with who and when), and is
refused when the findings it would change are no longer the ones previewed. AI-01 never writes anything itself.
"""

import json
import re
from datetime import date, timedelta

from . import remediation as rm

MAX_QUESTION = 500
SHOW_ROWS = 50
SEV_WORDS = {"critical": 4, "crit": 4, "high": 3, "medium": 2, "med": 2, "moderate": 2, "low": 1, "info": 0, "informational": 0}
STATUS_WORDS = {
    "open": "open", "not fixed": "open", "unfixed": "open", "outstanding": None,
    "pending review": "pending_review", "pending approval": "pending_deviation", "pending deviation": "pending_deviation",
    "deviation approved": "deviation_approved", "approved deviation": "deviation_approved",
    "false positive": "false_positive", "false positives": "false_positive", "fp": "false_positive",
    "fixed": "fixed", "resolved": "fixed", "remediated": "fixed", "decommission": "decommission", "decommissioned": "decommission",
    "decom": "decommission",
}
GROUP_BY = {"team": "team", "pic": "pic", "host": "host", "severity": "severity", "status": "status", "cat2": "cat2",
            "category": "cat2", "er": "cat2"}
SETTABLE = ("status", "target_on", "pic", "completed_on", "exception")
UPDATE_WORDS = re.compile(r"\b(set|change|update|mark|move|put|assign|reassign|extend)\b", re.I)
REPORT_WORDS = re.compile(r"\b(report|consolidat\w*|summar\w*|group\w*|by team|by pic|by host|per team|per pic|per host|breakdown|count)\b", re.I)


# words that follow "team", "PIC" or "host" without being a name ("by team and severity", "hosts with critical")
NOT_NAMES = frozenset("""and or the a an with where whose which that is are was to as for in on of by per each every all any
    findings finding report summary list count name names list type types tab its their them this these those has have
    without no not still open fixed high critical medium low info overdue expired passed""".split())


class AskError(Exception):
    """A reason, in words, the question cannot be answered or applied."""


# ---------------------------------------------------------------------------
# What the quarter holds, to check every value against
# ---------------------------------------------------------------------------

def context(conn, quarter):
    rm.where({"quarter": quarter})
    hosts = conn.execute("""SELECT f.host_key, max(f.hostname) AS hostname, array_agg(DISTINCT f.ip) AS ips
                              FROM rem_findings f WHERE f.quarter = %s GROUP BY f.host_key""", (quarter,)).fetchall()
    teams = conn.execute(f"""SELECT {rm.GROUPS['team'][0]} AS k, max(h.team_type) AS team_type, max(h.team) AS team, count(*) AS n
                               FROM rem_findings f LEFT JOIN rem_hosts h ON h.host_key = f.host_key
                              WHERE f.quarter = %s GROUP BY 1 ORDER BY 4 DESC""", (quarter,)).fetchall()
    pics = conn.execute("""SELECT coalesce(pic, '') AS k, count(*) AS n FROM rem_findings WHERE quarter = %s
                            GROUP BY 1 ORDER BY 2 DESC""", (quarter,)).fetchall()
    by_name = {}
    for r in hosts:
        names = {r["host_key"].lower()}
        if r["hostname"]:
            names |= {r["hostname"].lower(), r["hostname"].lower().split(".")[0]}
        names |= {i.lower() for i in (r["ips"] or []) if i}
        for n in names:
            by_name.setdefault(n, set()).add(r["host_key"])
    return {"quarter": quarter, "hosts": {r["host_key"]: r["hostname"] or r["host_key"] for r in hosts}, "by_name": by_name,
            "teams": [dict(r) for r in teams], "pics": [dict(r) for r in pics]}


def team_label(t):
    return rm.group_label("team", {"k": t["k"]})


# ---------------------------------------------------------------------------
# PATCH-01's own reading: what can be read for certain
# ---------------------------------------------------------------------------

DATE_RES = (re.compile(r"\b(\d{4}-\d{1,2}-\d{1,2})\b"), re.compile(r"\b(\d{1,2}[/.-]\d{1,2}[/.-]\d{4})\b"),
            re.compile(r"\b(\d{1,2} (?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]* \d{4})\b", re.I),
            re.compile(r"\b((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]* \d{1,2},? \d{4})\b", re.I))


def rule_read(question, ctx):
    q = question.lower()
    out = {"hosts": set(), "dates": [], "sev": set(), "status": set(), "due": None, "intent": None, "teams": set(), "pics": set(),
           "named": []}
    # teams and PICs of the quarter named in it, as whole words
    for t in ctx["teams"]:
        if t.get("team") and re.search(r"(?<![\w-])" + re.escape(t["team"].lower()) + r"(?![\w-])", q):
            out["teams"].add(t["k"])
    for p in ctx["pics"]:
        if p["k"] and len(p["k"]) > 2 and re.search(r"(?<![\w-])" + re.escape(p["k"].lower()) + r"(?![\w-])", q):
            out["pics"].add(p["k"])
    # what the request names by kind ("team X", "PIC X", "host X"), to be sure each one is in the view
    for m in re.finditer(r"\b(team|pic|host|server)s?\s+(?:named\s+|called\s+)?([a-z0-9][\w.-]*)", q):
        if m.group(2) not in NOT_NAMES:
            out["named"].append((m.group(1).replace("server", "host"), m.group(2)))
    for tok in re.findall(r"[a-z0-9][a-z0-9._-]*[a-z0-9]|[a-z0-9]", q):
        for k in ctx["by_name"].get(tok, ()):
            out["hosts"].add(k)
    for rx in DATE_RES:
        for m in rx.finditer(question):
            d = rm.parse_date(m.group(1), "dmy")
            if d and d not in out["dates"]:
                out["dates"].append(d)
    for w, n in SEV_WORDS.items():
        if re.search(r"\b" + w + r"\b", q):
            out["sev"].add(n)
    # the longest phrase first, and taken out once read: "not fixed" is Open, not Open and Fixed
    rest = q
    for w, st in sorted(STATUS_WORDS.items(), key=lambda x: -len(x[0])):
        rx = re.compile(r"\b" + re.escape(w) + r"\b")
        if rx.search(rest):
            if st:
                out["status"].add(st)
            rest = rx.sub(" ", rest)
    if re.search(r"\b(expired|passed|past (?:the )?(?:due|target)|overdue)\b", q):
        out["due"] = "expired"
    elif re.search(r"\bno (?:target )?date\b|\bwithout (?:a )?(?:target )?date\b", q):
        out["due"] = "none"
    # a change only when the request says what to set ("as fixed", a date, a PIC, an exception); a report when it
    # asks for one; else the findings
    says_what = bool(re.search(r"\b(?:as|to)\s+(?:" + "|".join(re.escape(w) for w in STATUS_WORDS if STATUS_WORDS[w]) + r")\b", q)
                     or out["dates"] or re.search(r"\b(?:pic|owner)\s+(?:to|as)\b|\b(?:re)?assign\b|\bexception\b", q))
    out["intent"] = ("update" if UPDATE_WORDS.search(q) and says_what
                     else "report" if REPORT_WORDS.search(q) else "update" if UPDATE_WORDS.search(q) else "show")
    return out


# ---------------------------------------------------------------------------
# AI-01's reading
# ---------------------------------------------------------------------------

SCHEMA = {"type": "object", "properties": {
    "intent": {"type": "string", "enum": ["show", "report", "update"]},
    "hosts": {"type": "array", "items": {"type": "string"}},
    "teams": {"type": "array", "items": {"type": "string"}},
    "pics": {"type": "array", "items": {"type": "string"}},
    "team_type": {"type": "string", "enum": ["", "application", "infra"]},
    "severities": {"type": "array", "items": {"type": "string", "enum": ["critical", "high", "medium", "low", "info"]}},
    "statuses": {"type": "array", "items": {"type": "string", "enum": [k for k, _l in rm.STATUSES]}},
    "due": {"type": "string", "enum": ["", "expired", "none"]},
    "search": {"type": "string"},
    "group_by": {"type": "string", "enum": ["", "team", "pic", "host", "severity", "status", "cat2"]},
    "set": {"type": "object", "properties": {
        "status": {"type": "string", "enum": [""] + [k for k, _l in rm.STATUSES]},
        "target_on": {"type": "string"}, "completed_on": {"type": "string"}, "pic": {"type": "string"},
        "exception": {"type": "string"}}},
}, "required": ["intent"]}


def messages(question, ctx, today):
    teams = ", ".join(f'"{team_label(t)}"' for t in ctx["teams"][:60] if t["k"] not in ("|", ""))
    pics = ", ".join(f'"{p["k"]}"' for p in ctx["pics"][:80] if p["k"])
    statuses = ", ".join(f"{k} ({label})" for k, label in rm.STATUSES)
    sys_ = (
        "You turn a request about a quarter's vulnerability findings (Nessus) into a JSON plan. Fill only what the request "
        "says; leave the rest empty. intent: show (list findings), report (a consolidated, grouped view: group_by), "
        "update (change findings: set). hosts: host names or IP addresses exactly as written. teams: from the teams listed. "
        "pics: from the PICs listed. severities and statuses: only those named. due: expired when the request is about a "
        "passed / expired target date or overdue findings, none when about findings without a target date. search: a "
        "plugin name, CVE or words to look for, only when named. set (update only): status, target_on and completed_on "
        "as YYYY-MM-DD, pic, exception. Work out relative dates from today. Never invent a host, team or PIC.")
    user = (f"Today is {today.isoformat()} ({today.strftime('%A')}). Quarter {ctx['quarter']}.\n"
            f"Teams: {teams or 'none set'}.\nPICs: {pics or 'none'}.\nStatuses: {statuses}.\n\nRequest: {question}")
    return [{"role": "system", "content": sys_}, {"role": "user", "content": user}]


def ai_read(ask, question, ctx, today):
    raw = ask(messages(question, ctx, today), SCHEMA)
    try:
        plan = json.loads(raw)
    except (ValueError, TypeError):
        raise AskError("AI-01 gave an answer that is not the expected JSON: ask again, in other words.")
    return plan if isinstance(plan, dict) else {}


# ---------------------------------------------------------------------------
# One plan, every value checked
# ---------------------------------------------------------------------------

def _match_team(word, ctx):
    """A team as the request names it ("Payments", "Application Payments", "payments team"), when exactly one fits."""
    w = rm.norm(re.sub(r"\bteam\b", "", str(word or ""), flags=re.I))
    if not w:
        return None
    named = [t for t in ctx["teams"] if t["k"] not in ("|", "")]
    hits = [t["k"] for t in named if w in (rm.norm(team_label(t)), rm.norm(t.get("team")),
                                          rm.norm((t.get("team_type") or "") + (t.get("team") or "")))]
    if not hits:
        hits = [t["k"] for t in named if t.get("team") and (w in rm.norm(t["team"]) or rm.norm(t["team"]) in w)]
    return hits[0] if len(set(hits)) == 1 else None


def _match_pic(word, ctx):
    w = rm.norm(word)
    hits = [p["k"] for p in ctx["pics"] if p["k"] and rm.norm(p["k"]) == w]
    if not hits:
        hits = [p["k"] for p in ctx["pics"] if p["k"] and w and w in rm.norm(p["k"])]
    return hits[0] if len(hits) == 1 else None


def _date(v):
    if not v:
        return None
    d = rm.parse_date(str(v), "dmy")
    return d


def build(question, ctx, ai, rules, today):
    """(view, set, intent, group_by, notes, unresolved). The view holds only checked values."""
    notes, unresolved = [], []
    view = {"quarter": ctx["quarter"]}
    # hosts: the rules' (exact names in the question) and AI-01's, each found in the quarter
    hosts = set(rules["hosts"])
    for hname in ai.get("hosts") or []:
        ks = ctx["by_name"].get(str(hname).strip().lower()) or ctx["by_name"].get(str(hname).strip().lower().split(".")[0])
        if ks:
            hosts |= ks
        else:
            unresolved.append(f"host {str(hname)[:60]}")
    if hosts:
        view["hosts"] = sorted(hosts)
    teams = list(rules["teams"])
    for t in ai.get("teams") or []:
        k = _match_team(t, ctx)
        (teams.append(k) if k else unresolved.append(f"team {str(t)[:60]}"))
    if teams:
        view["teams"] = sorted(set(teams))
    pics = list(rules["pics"])
    for p in ai.get("pics") or []:
        k = _match_pic(p, ctx)
        (pics.append(k) if k else unresolved.append(f"PIC {str(p)[:60]}"))
    if pics:
        view["pics"] = sorted(set(pics))
    if ai.get("team_type") in ("application", "infra"):
        view["team_type"] = ai["team_type"]
    # "team X", "PIC X", "host X" in the request with nothing of that kind in the view: never left out (a change
    # without it would reach every team, PIC or host)
    has = {"team": bool(view.get("teams")), "pic": bool(view.get("pics")), "host": bool(view.get("hosts"))}
    for kind, word in rules["named"]:
        if not has[kind] and not (kind == "team" and word in ("application", "app", "infra", "infrastructure")
                                  and view.get("team_type")):
            unresolved.append(f"{'PIC' if kind == 'pic' else kind} {word}")
    sev = set(rules["sev"]) | {SEV_WORDS[x] for x in ai.get("severities") or [] if x in SEV_WORDS}
    if sev:
        view["sev"] = ",".join(str(x) for x in sorted(sev, reverse=True))
    intent = ai.get("intent") if ai.get("intent") in ("show", "report", "update") else rules["intent"]
    if rules["intent"] == "update" and intent != "update" and UPDATE_WORDS.search(question) and (ai.get("set") or {}):
        intent = "update"
    # what to set (update): the rules' date wins over AI-01's when the question has exactly one
    setv = {}
    if intent == "update":
        s = dict(ai.get("set") or {})
        if not s.get("status"):            # "as fixed", "to false positive": the rules' reading, when AI-01 gave none
            m = re.search(r"\b(?:as|to)\s+(" + "|".join(re.escape(w) for w in sorted(STATUS_WORDS, key=len, reverse=True)
                                                    if STATUS_WORDS[w]) + r")\b", question, re.I)
            if m:
                s["status"] = STATUS_WORDS[m.group(1).lower()]
        if s.get("status") in rm.STATUS:
            setv["status"] = s["status"]
        for k in ("target_on", "completed_on"):
            if s.get(k):
                d = rules["dates"][0] if len(rules["dates"]) == 1 else _date(s[k])
                if not d:
                    unresolved.append(f"the date {str(s[k])[:30]}")
                else:
                    setv[k] = d.isoformat()
        if not setv.get("target_on") and not setv.get("completed_on") and len(rules["dates"]) == 1 \
                and re.search(r"\b(target|due|deadline|date)\b", question, re.I):
            setv["target_on"] = rules["dates"][0].isoformat()
        if s.get("pic"):
            k = _match_pic(s["pic"], ctx)
            setv["pic"] = k or str(s["pic"]).strip()[:120]
            if not k:
                notes.append(f"PIC {setv['pic']} is new in this quarter")
        if s.get("exception"):
            setv["exception"] = str(s["exception"]).strip()[:2000]
    # the statuses filtered on: AI-01's, else the rules'; an update's new status is not a filter
    sts = [x for x in ai.get("statuses") or [] if x in rm.STATUS]
    if not sts:
        sts = sorted(rules["status"])
    if intent == "update" and setv.get("status"):
        sts = [x for x in sts if x != setv["status"]]
    if sts:
        view["status"] = ",".join(sts)
    due = ai.get("due") if ai.get("due") in ("expired", "none") else rules["due"]
    if due:
        view["due"] = due
    if ai.get("search"):
        q = str(ai["search"]).strip()[:100]
        nq = rm.norm(q)
        taken = ({rm.norm(h) for h in ctx["hosts"].values()} | {rm.norm(team_label(t)) for t in ctx["teams"]}
                 | {rm.norm(t.get("team")) for t in ctx["teams"]} | {rm.norm(p["k"]) for p in ctx["pics"]}
                 | {rm.norm(w) for w in list(SEV_WORDS) + list(STATUS_WORDS)}
                 | {"expired", "overdue", "passed", "targetdate", "notargetdate", "findings", "finding"})
        # a host, team, PIC, severity or status AI-01 put in the search box would hide every finding: not a search
        if nq and nq not in taken and not ctx["by_name"].get(q.lower()):
            view["q"] = q
    gb = GROUP_BY.get(str(ai.get("group_by") or "").lower()) or ("team" if intent == "report" else None)
    if setv.get("target_on") and date.fromisoformat(setv["target_on"]) < today:
        notes.append(f"the new target date {setv['target_on']} is already past")
    return view, setv, intent, gb, notes, unresolved


def words(view, ctx):
    out = []
    if view.get("hosts"):
        names = [ctx["hosts"].get(k, k) for k in view["hosts"]]
        out.append("host" + ("s " if len(names) > 1 else " ") + ", ".join(names[:8]) + (f" and {len(names) - 8} more" if len(names) > 8 else ""))
    if view.get("teams"):
        out.append("team " + ", ".join(rm.group_label("team", {"k": k}) for k in view["teams"]))
    if view.get("pics"):
        out.append("PIC " + ", ".join(k or "(blank)" for k in view["pics"]))
    w = rm.view_words({k: v for k, v in view.items() if k in rm.SUM_KEYS and k not in ("hosts",)})
    if w != "every finding":
        out.append(w)
    return "; ".join(out) or "every finding of the quarter"


def set_words(setv):
    parts = []
    for k, v in setv.items():
        label = rm.FIELD[k][0] if k in rm.FIELD else k
        if k == "status":
            v = rm.STATUS.get(v, v)
        elif k in ("target_on", "completed_on"):
            v = date.fromisoformat(v).strftime("%d %b %Y")
        parts.append(f"{label} → {v}")
    return ", ".join(parts)


# ---------------------------------------------------------------------------
# The answer
# ---------------------------------------------------------------------------

def count(conn, view):
    w, val = rm.where(view)
    rm._with_prev(conn, val)
    return int(conn.execute(f"SELECT count(*) AS n {rm.FROM_SQL} WHERE {w}", val).fetchone()["n"])


def clean_view(conn, view, ctx=None):
    """A view sent back by the page (Apply, Export), checked again: only known keys, and every host, team and PIC
    in the quarter."""
    if not isinstance(view, dict):
        raise AskError("No view.")
    q = str(view.get("quarter") or "")
    rm.where({"quarter": q})
    ctx = ctx or context(conn, q)
    out = {"quarter": q}
    for k in ("sev", "status", "team_type", "due", "q"):
        v = view.get(k)
        if v not in (None, ""):
            out[k] = str(v)[:300]
    if out.get("due") not in (None, "expired", "none", "set"):
        raise AskError("Unknown due filter.")
    for k, known in (("hosts", set(ctx["hosts"])), ("teams", {t["k"] for t in ctx["teams"]}), ("pics", {p["k"] for p in ctx["pics"]})):
        vs = view.get(k)
        if vs:
            if not isinstance(vs, list) or any(str(x) not in known for x in vs):
                raise AskError(f"A {k[:-1]} of this view is not in {q} any more: ask again.")
            out[k] = [str(x) for x in vs]
    rm.where(out)                                   # every value checked as the Findings tab checks it
    return out


def answer(conn, user, question, quarter, ask=None, today=None):
    """The plan, read and checked, and what it means: the findings (show), the groups (report) or the change
    (update: previewed, never applied here)."""
    question = re.sub(r"\s+", " ", str(question or "")).strip()
    if len(question) < 3:
        raise AskError("Ask in a few words what you want.")
    if len(question) > MAX_QUESTION:
        raise AskError(f"At most {MAX_QUESTION} characters.")
    today = today or conn.execute("SELECT current_date AS d").fetchone()["d"]
    ctx = context(conn, quarter)
    rules = rule_read(question, ctx)
    how, ai = "ai", {}
    if ask:
        try:
            ai = ai_read(ask, question, ctx, today)
        except AskError:
            raise
        except Exception as e:  # noqa: BLE001 - AI-01 away or busy: PATCH-01's rules read it alone
            how, ai = "rules", {}
            reason = str(e)[:120]
    else:
        how, reason = "rules", "AI-01 is not set up"
    view, setv, intent, gb, notes, unresolved = build(question, ctx, ai, rules, today)
    out = {"question": question, "how": how, "intent": intent, "view": view, "words": words(view, ctx), "notes": notes,
           "unresolved": unresolved}
    if how == "rules":
        out["notes"].insert(0, f"read by PATCH-01's rules ({reason}): check the view below")
    if unresolved:
        out["notes"].append("not found in " + quarter + ": " + ", ".join(unresolved))
    if intent == "update":
        out["set"], out["set_words"] = setv, set_words(setv)
        if not setv:
            out["refused"] = "Say what to change: a status, a target date, a completion date, a PIC or an exception."
        elif unresolved:
            out["refused"] = ("Not changed: " + ", ".join(unresolved) + " is not in " + quarter
                              + ". Name the findings exactly, so nothing else is changed.")
        elif not any(view.get(k) for k in ("hosts", "teams", "pics", "team_type", "sev", "status", "due", "q")):
            out["refused"] = ("Name which findings to change (a host, team, PIC, status, severity or the expired ones): "
                              "every finding of the quarter at once is changed on the Findings tab.")
        n = count(conn, view)
        out["count"] = n
        if not n and not out.get("refused"):
            out["refused"] = "No finding matches: nothing to change."
        if n > 50000:
            out["refused"] = "More than 50,000 findings: name them more narrowly."
        out["rows"] = rm.findings(conn, view, 0, SHOW_ROWS)["items"] if n and not out.get("refused") else []
        return out
    if unresolved:
        # a host, team or PIC not in the quarter: no answer for every finding instead
        out.update(count=0, rows=[], groups=[], refused="Not in " + quarter + ": " + ", ".join(unresolved)
                   + ". Check the name (the Hosts tab lists them).")
        return out
    if intent == "report":
        g = rm.groups(conn, dict(view, group_by=gb or "team"), limit=200)
        out.update(group_by=gb or "team", groups=g["groups"], total=g["total"], more=g["more"],
                   group_label=rm.GROUPS[gb or "team"][1])
        out["count"] = g["total"]["total"]
        return out
    f = rm.findings(conn, view, 0, SHOW_ROWS)
    out.update(count=f["total"], rows=f["items"], more=f["more"])
    return out


def apply(conn, user, view, setv, expect):
    """The previewed change, applied: the view checked again, the same findings as previewed, then the Findings
    tab's bulk change (each change with who and when)."""
    view = clean_view(conn, view)
    setv = {k: v for k, v in (setv or {}).items() if k in SETTABLE and v not in (None, "")}
    if not setv:
        raise AskError("Nothing to change.")
    if not any(view.get(k) for k in ("hosts", "teams", "pics", "team_type", "sev", "status", "due", "q")):
        raise AskError("Name which findings to change.")
    n = count(conn, view)
    if n != int(expect):
        raise AskError(f"The findings changed since the preview ({expect} then, {n} now): ask again.")
    r = rm.bulk_edit(conn, user, params=view, changes=setv, note="AI-01 assistant (previewed and applied by " + user + ")")
    return dict(r, words=set_words(setv))
