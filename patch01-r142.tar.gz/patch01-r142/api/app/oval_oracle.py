"""Oracle Linux ELSA advisories from Oracle's OVAL files (r137).

Oracle's public yum repositories often leave the advisory data (updateinfo) out, so the Pulp
mirror can hold no ELSA at all and Oracle Linux servers get no verdict. Oracle publishes every
ELSA as OVAL, one file per release:

    https://linux.oracle.com/security/oval/com.oracle.elsa-ol8.xml.bz2   (OL8; ol9, ol10 likewise)

Each definition is one ELSA: its CVEs, its severity, and for each architecture the packages and
the version that fixes them ("python3-libs is earlier than 0:3.6.8-78.0.1.el8_10"). They become
advisories like the mirror's (vendor oracle, origin 'oval'), and the CVE engine compares them
with each server's packages exactly as it does Red Hat's: nothing else changes.

  * only the releases our servers run are read, and an ELSA the mirror already holds is left as
    the mirror has it (origin 'repo' wins)
  * packages under a module stream ("Module nodejs:18 is enabled") are skipped and counted, as
    the mirror import skips modular content: comparing across streams gives false findings
  * the file is untrusted: parsed with defusedxml (no DTD, no entities), with size limits on the
    download and on what it unpacks to
"""
import bz2
import logging
import os
import re
import tempfile
import urllib.error
import urllib.request

from defusedxml.ElementTree import iterparse

log = logging.getLogger("patchapi.oval_oracle")

URL = os.environ.get("ORACLE_OVAL_URL", "https://linux.oracle.com/security/oval/com.oracle.elsa-ol{major}.xml.bz2")
MAX_DOWNLOAD = 96 * 2 ** 20
MAX_UNPACKED = 1536 * 2 ** 20
REFRESH_HOURS = 20
D = "{http://oval.mitre.org/XMLSchema/oval-definitions-5}"
L = "{http://oval.mitre.org/XMLSchema/oval-definitions-5#linux}"
ELSA_RE = re.compile(r"^ELSA-\d{4}-\d{1,7}$")
CVE_RE = re.compile(r"^CVE-\d{4}-\d{4,7}$")
EVR_RE = re.compile(r"^(?:(\d+):)?([^:\s-]+)-([^:\s]+)$")
OS_RE = re.compile(r"^Oracle Linux (\d+) is installed$")
ARCH_RE = re.compile(r"^Oracle Linux arch is (\S+)$")
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+-]{0,199}$")
ARCH_OK = re.compile(r"^[a-z0-9_]{2,20}$")


class Unavailable(RuntimeError):
    pass


def download(major, dest):
    """Oracle's OVAL file for one release into dest (a path). Raises Unavailable."""
    url = URL.format(major=int(major))
    req = urllib.request.Request(url, headers={"User-Agent": "PATCH-01"})
    try:
        with urllib.request.build_opener().open(req, timeout=120) as r, open(dest, "wb") as f:
            n = 0
            while True:
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                n += len(chunk)
                if n > MAX_DOWNLOAD:
                    raise Unavailable(f"Oracle's OVAL file for OL{major} is larger than {MAX_DOWNLOAD // 2**20} MB")
                f.write(chunk)
    except urllib.error.HTTPError as e:
        raise Unavailable(f"HTTP {e.code} for Oracle's OVAL file for OL{major}")
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise Unavailable(f"cannot reach linux.oracle.com: {e}")


class _Capped:
    """A file object that refuses to unpack past MAX_UNPACKED (a bz2 bomb stops here)."""
    def __init__(self, f):
        self.f, self.n = f, 0

    def read(self, size=-1):
        b = self.f.read(size if size and size > 0 else 1 << 20)
        self.n += len(b)
        if self.n > MAX_UNPACKED:
            raise Unavailable(f"Oracle's OVAL file unpacks to more than {MAX_UNPACKED // 2**20} MB")
        return b


def _walk(node, arch, out, os_major):
    """Criteria tree -> [(test_ref, arch, modular)]; the 'Oracle Linux N is installed' number."""
    kids = list(node)
    here_arch, modular = arch, False
    for k in kids:
        if k.tag == D + "criterion":
            c = k.get("comment") or ""
            m = ARCH_RE.match(c)
            if m:
                here_arch = m.group(1)
            if c.startswith("Module "):
                modular = True
            m = OS_RE.match(c)
            if m:
                os_major.add(int(m.group(1)))
    for k in kids:
        if k.tag == D + "criterion":
            out.append((k.get("test_ref"), here_arch, modular))
        elif k.tag == D + "criteria":
            sub = []
            _walk(k, here_arch, sub, os_major)
            out.extend((t, a, mod or modular) for t, a, mod in sub)


def parse(fileobj):
    """One OVAL file -> [{id, title, severity, issued, os_major, cves, packages: [(name, arch, e, v, r)],
    modular_skipped}]."""
    defs, tests, objects, states = [], {}, {}, {}
    for _, el in iterparse(fileobj, events=("end",), forbid_dtd=True):
        tag = el.tag
        if tag == D + "definition":
            md = el.find(D + "metadata")
            elsa, cves = None, []
            title = sev = issued = None
            if md is not None:
                title = (md.findtext(D + "title") or "").strip()[:500]
                for ref in md.findall(D + "reference"):
                    src, rid = (ref.get("source") or "").lower(), (ref.get("ref_id") or "").strip()
                    if src == "elsa" and ELSA_RE.match(rid):
                        elsa = rid
                    elif src == "cve" and CVE_RE.match(rid):
                        cves.append(rid)
                adv = md.find(D + "advisory")
                if adv is not None:
                    sev = (adv.findtext(D + "severity") or "").strip().lower()[:20] or None
                    iss = adv.find(D + "issued")
                    issued = (iss.get("date") if iss is not None else None) or None
                    for c in adv.findall(D + "cve"):
                        t = (c.text or "").strip()
                        if CVE_RE.match(t) and t not in cves:
                            cves.append(t)
            crit, majors = [], set()
            top = el.find(D + "criteria")
            if top is not None:
                _walk(top, None, crit, majors)
            if elsa and len(majors) == 1:
                defs.append({"id": elsa, "title": title, "severity": sev, "issued": issued,
                             "os_major": majors.pop(), "cves": cves[:500], "crit": crit})
            el.clear()
        elif tag == L + "rpminfo_test":
            o, s = el.find(L + "object"), el.find(L + "state")
            if o is not None and s is not None:
                tests[el.get("id")] = (o.get("object_ref"), s.get("state_ref"))
            el.clear()
        elif tag == L + "rpminfo_object":
            n = (el.findtext(L + "name") or "").strip()
            if NAME_RE.match(n):
                objects[el.get("id")] = n
            el.clear()
        elif tag == L + "rpminfo_state":
            evr = el.find(L + "evr")
            if evr is not None and (evr.get("operation") or "") == "less than" and (evr.get("datatype") or "") == "evr_string":
                m = EVR_RE.match((evr.text or "").strip())
                if m:
                    states[el.get("id")] = (int(m.group(1) or 0), m.group(2), m.group(3))
            el.clear()
    out = []
    for d in defs:
        pk, skipped = {}, 0
        for tref, arch, modular in d.pop("crit"):
            t = tests.get(tref)
            if not t:
                continue
            name, evr = objects.get(t[0]), states.get(t[1])
            if not name or not evr:
                continue                         # a signature or OS test, not a package version
            if modular:
                skipped += 1
                continue
            a = arch if arch and ARCH_OK.match(arch) else "noarch"
            pk.setdefault((name, a), evr)
        out.append(dict(d, packages=[(n, a) + evr for (n, a), evr in pk.items()], modular_skipped=skipped))
    return out


def import_defs(conn, defs):
    """Advisories from parsed definitions. An ELSA the mirror holds (origin 'repo') is left alone.
    Returns {"advisories", "packages", "cves", "kept_from_mirror", "modular_skipped"}."""
    res = {"advisories": 0, "packages": 0, "cves": 0, "kept_from_mirror": 0, "modular_skipped": 0}
    repo = {r["id"] for r in conn.execute(
        "SELECT id FROM advisories WHERE id = ANY(%s) AND origin = 'repo'", ([d["id"] for d in defs],)).fetchall()}
    for d in defs:
        res["modular_skipped"] += d["modular_skipped"]
        if d["id"] in repo:
            res["kept_from_mirror"] += 1
            continue
        if not d["packages"]:
            continue
        conn.execute("""INSERT INTO advisories (id, vendor, title, severity, issued_at, os_id, os_major, origin)
                        VALUES (%s, 'oracle', %s, %s, %s, 'ol', %s, 'oval')
                        ON CONFLICT (id) DO UPDATE SET title = EXCLUDED.title, severity = EXCLUDED.severity,
                          issued_at = EXCLUDED.issued_at, imported_at = now()
                        WHERE advisories.origin = 'oval'""",
                     (d["id"], d["title"], d["severity"], d["issued"], d["os_major"]))
        for c in d["cves"]:
            conn.execute("INSERT INTO advisory_cves (advisory_id, cve_id) VALUES (%s, %s) ON CONFLICT DO NOTHING", (d["id"], c))
        for name, arch, e, v, r in d["packages"]:
            conn.execute("""INSERT INTO advisory_packages (advisory_id, name, arch, epoch, version, release)
                            VALUES (%s, %s, %s, %s, %s, %s)
                            ON CONFLICT (advisory_id, name, arch) DO UPDATE SET epoch = EXCLUDED.epoch,
                              version = EXCLUDED.version, release = EXCLUDED.release""", (d["id"], name, arch, e, v, r))
        res["advisories"] += 1
        res["packages"] += len(d["packages"])
        res["cves"] += len(d["cves"])
    return res


def majors_in_use(conn):
    return sorted({int(r["os_major"]) for r in conn.execute(
        """SELECT DISTINCT os_major FROM hosts WHERE os_id = 'ol' AND status <> 'decommissioned'
             AND os_major IS NOT NULL""").fetchall()})


def refresh(conn, force=False, downloader=None):
    """Read Oracle's OVAL file for each Oracle Linux release our servers run, when the last read is
    REFRESH_HOURS old (or force). Returns {major: result or {"error"}}; {} when nothing was due."""
    downloader = downloader or download
    s = conn.execute("SELECT oval_imported_at FROM cve_feed_settings WHERE id = 1").fetchone() or {}
    last = s.get("oval_imported_at")
    if not force and last is not None and conn.execute(
            "SELECT %s > now() - make_interval(hours => %s::int) AS fresh", (last, REFRESH_HOURS)).fetchone()["fresh"]:
        return {}
    out, ok = {}, True
    for major in majors_in_use(conn):
        fd, path = tempfile.mkstemp(prefix="oval-ol%d-" % major, suffix=".xml.bz2")
        os.close(fd)
        try:
            downloader(major, path)
            with bz2.open(path, "rb") as f:
                defs = parse(_Capped(f))
            with conn.transaction():
                out[major] = import_defs(conn, defs)
            out[major]["definitions"] = len(defs)
        except Exception as e:  # noqa: BLE001 - the other releases still read; recorded for the sync report
            ok = False
            out[major] = {"error": str(e)[:300]}
            log.warning("Oracle OVAL for OL%s: %s", major, e)
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass
    conn.execute("UPDATE cve_feed_settings SET oval_imported_at = CASE WHEN %s THEN now() ELSE oval_imported_at END, "
                 "oval_result = %s::jsonb WHERE id = 1", (ok, __import__("json").dumps(out, default=str)))
    return out
