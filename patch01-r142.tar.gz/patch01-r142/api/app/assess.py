"""
PATCH-01 : assess an external CVE list against the fleet

Given a list of CVEs from a SOC bulletin, an auditor or a vendor notice,
report per CVE which servers need the fix, which are already patched, which
are awaiting a reboot, and which cannot be judged.

The verdicts come from the same version comparison the CVE engine already
performed. Nothing here re-decides anything.

Honesty about the limits matters as much as the answer:

  * A CVE no advisory in our mirrors mentions is reported as
    "no_vendor_data", never as "not affected". Without a vendor's fixed-in
    version there is nothing to compare an installed package against.
  * A CVE whose advisories exist but touch no installed package is
    "not_applicable", which is a real answer, unlike silence.
  * Servers with stale inventory contribute "unknown", so a silent server is
    never counted as safe.
"""

import json
import re

CVE_RE = re.compile(r"\bCVE[-–—_ ]?(\d{4})[-–—_ ]?(\d{4,7})\b", re.I)
# Something that looks like it was meant to be a CVE but is not usable
NEARLY_RE = re.compile(r"\bCVE\b[-–—_ ]?[0-9]{0,3}\b", re.I)

MAX_CVES = 5000
MAX_HOSTS_RECORDED = 200


class TooMany(ValueError):
    """A list with more distinct CVEs than one assessment takes."""
    def __init__(self, n):
        super().__init__(f"The list has {n} different CVEs; one assessment takes up to {MAX_CVES}. "
                         "Split it into smaller lists.")
        self.n = n


def parse_cve_list(text):
    """Pull CVE ids out of anything: a pasted list, CSV, or an email body.

    Accepts the punctuation variations that survive copy and paste, such as
    an en dash instead of a hyphen or a stray space, and normalises them.
    Returns (ids in input order, rejected fragments).
    """
    text = text or ""
    found, seen = [], set()
    for m in CVE_RE.finditer(text):
        cid = f"CVE-{m.group(1)}-{m.group(2)}"
        if cid not in seen:
            seen.add(cid)
            found.append(cid)
    # r136: never a silent cut; the caller refuses a list over the limit and says so
    if len(found) > MAX_CVES:
        raise TooMany(len(found))

    # Fragments that mention CVE but produced no id, so the caller can see
    # that something in the file was not understood
    rejected = []
    for m in NEARLY_RE.finditer(text):
        frag = m.group(0).strip()
        if CVE_RE.match(frag):
            continue
        window = text[m.start():m.start() + 24].split("\n")[0].strip()
        if not CVE_RE.search(window) and window not in rejected:
            rejected.append(window[:40])
    return found, rejected[:20]


STATE_FIELD = {
    "affected": "affected",
    "fixed_pending_reboot": "pending_reboot",
    "fixed_active": "patched",
    "unknown": "unknown",
}


def _status(counts, has_advisory):
    """One word per CVE. Servers needing action come first; then any server
    that cannot be judged: "patched" is only said when every server holding
    the package is proven fixed, so a silent server never reads as safe."""
    if counts["affected"]:
        return "affected"
    if counts["pending_reboot"]:
        return "pending_reboot"
    if counts["unknown"]:
        return "unknown"
    if counts["patched"]:
        return "patched"
    return "not_applicable" if has_advisory else "no_vendor_data"


# A verdict read from a server that has gone silent (status 'stale', or an
# inventory older than the staleness window) is 'unknown', whatever is stored,
# even before the worker's staleness sweep has rewritten it. %(stale_h)s: hours.
EFFECTIVE_STATE = """CASE WHEN h.status = 'stale' OR h.last_inventory IS NULL
                           OR h.last_inventory < now() - make_interval(hours => %(stale_h)s::int)
                          THEN 'unknown'::applicability_state ELSE ha.state END"""


def _stale_hours():
    import os
    try:
        return int(os.environ.get("STALE_HOURS", "24"))
    except ValueError:
        return 24


def evaluate(conn, cve_ids):
    """Evaluate a list of CVEs. Returns (items, hosts_in_scope)."""
    if not cve_ids:
        return [], 0

    hosts_in_scope = conn.execute(
        "SELECT count(*) AS n FROM hosts WHERE status <> 'decommissioned'"
    ).fetchone()["n"]

    # Which advisories mention each CVE, and which packages they fix
    adv_rows = conn.execute(
        """SELECT ac.cve_id, ac.advisory_id, array_agg(DISTINCT ap.name) AS packages
             FROM advisory_cves ac
             LEFT JOIN advisory_packages ap ON ap.advisory_id = ac.advisory_id
            WHERE ac.cve_id = ANY(%s)
            GROUP BY ac.cve_id, ac.advisory_id""",
        (cve_ids,)).fetchall()

    advisories, packages = {}, {}
    for r in adv_rows:
        advisories.setdefault(r["cve_id"], []).append(r["advisory_id"])
        for p in r["packages"] or []:
            if p:
                packages.setdefault(r["cve_id"], set()).add(p)

    # Verdicts already computed per host, grouped by CVE and state
    # One state per server and CVE (the worst of its advisories), so a server is
    # counted once: affected > pending reboot > unknown > fixed
    params = {"ids": cve_ids, "stale_h": _stale_hours()}
    verdict_rows = conn.execute(
        f"""WITH s AS (
              SELECT ac.cve_id, ha.host_id,
                     min(CASE {EFFECTIVE_STATE} WHEN 'affected' THEN 1 WHEN 'fixed_pending_reboot' THEN 2
                              WHEN 'unknown' THEN 3 WHEN 'fixed_active' THEN 4 ELSE 5 END) AS r
                FROM advisory_cves ac
                JOIN host_applicability ha ON ha.advisory_id = ac.advisory_id
                JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'
               WHERE ac.cve_id = ANY(%(ids)s)
               GROUP BY ac.cve_id, ha.host_id)
            SELECT cve_id, (CASE r WHEN 1 THEN 'affected' WHEN 2 THEN 'fixed_pending_reboot'
                                   WHEN 3 THEN 'unknown' WHEN 4 THEN 'fixed_active' ELSE 'not_affected' END) AS state,
                   count(*) AS n
              FROM s GROUP BY 1, 2""",
        params).fetchall()

    counts = {}
    for r in verdict_rows:
        c = counts.setdefault(r["cve_id"], {"affected": 0, "pending_reboot": 0,
                                            "patched": 0, "unknown": 0})
        field = STATE_FIELD.get(r["state"])
        if field:
            c[field] += r["n"]

    # The servers needing action, recorded with the assessment
    host_rows = conn.execute(
        f"""SELECT * FROM (
              SELECT ac.cve_id, h.id AS host_id, h.hostname, h.os_id, h.os_version,
                     {EFFECTIVE_STATE} AS state, ha.package_name, ha.installed_evr, ha.fixed_evr
                FROM advisory_cves ac
                JOIN host_applicability ha ON ha.advisory_id = ac.advisory_id
                JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'
               WHERE ac.cve_id = ANY(%(ids)s)) x
            WHERE state IN ('affected', 'fixed_pending_reboot', 'unknown')
            ORDER BY cve_id,
                     CASE state WHEN 'affected' THEN 1
                          WHEN 'fixed_pending_reboot' THEN 2 ELSE 3 END,
                     hostname""",
        params).fetchall()

    hosts = {}
    for r in host_rows:
        lst = hosts.setdefault(r["cve_id"], [])
        if len(lst) < MAX_HOSTS_RECORDED:
            lst.append({"host_id": str(r["host_id"]), "hostname": r["hostname"],
                        "os": f"{r['os_id']} {r['os_version'] or ''}".strip(),
                        "state": r["state"], "package": r["package_name"],
                        "installed": r["installed_evr"], "fixed": r["fixed_evr"]})

    # Published facts, where collected
    detail_rows = conn.execute(
        """SELECT cve_id, cvss_score, kev, attack_class, description
             FROM cve_details WHERE cve_id = ANY(%s)""", (cve_ids,)).fetchall()
    details = {r["cve_id"]: r for r in detail_rows}

    items = []
    for cid in cve_ids:
        c = counts.get(cid, {"affected": 0, "pending_reboot": 0, "patched": 0, "unknown": 0})
        d = details.get(cid) or {}
        items.append({
            "cve_id": cid,
            "status": _status(c, cid in advisories),
            **c,
            "advisories": sorted(advisories.get(cid, [])),
            "packages": sorted(packages.get(cid, set())),
            "affected_hosts": hosts.get(cid, []),
            "cvss_score": d.get("cvss_score"),
            "kev": bool(d.get("kev")),
            "attack_class": d.get("attack_class"),
        })
    return items, hosts_in_scope


def save(conn, name, source, note, created_by, cve_ids, rejected, items, hosts_in_scope):
    row = conn.execute(
        """INSERT INTO cve_assessments
             (name, source, note, created_by, cve_count, rejected, hosts_in_scope, evaluated_at)
           VALUES (%s,%s,%s,%s,%s,%s,%s, now()) RETURNING id""",
        (name, source, note, created_by, len(cve_ids), rejected, hosts_in_scope)).fetchone()
    aid = row["id"]
    with conn.cursor() as cur:
        cur.executemany(
            """INSERT INTO cve_assessment_items
                 (assessment_id, cve_id, status, affected, pending_reboot, patched,
                  unknown, advisories, packages, affected_hosts, cvss_score, kev, attack_class)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            [(aid, i["cve_id"], i["status"], i["affected"], i["pending_reboot"],
              i["patched"], i["unknown"], i["advisories"], i["packages"],
              json.dumps(i["affected_hosts"]), i["cvss_score"], i["kev"], i["attack_class"])
             for i in items])
    return str(aid)


def summarise(items):
    """Counts by status, plus the servers and CVEs that need action."""
    by = {}
    for i in items:
        by[i["status"]] = by.get(i["status"], 0) + 1
    # Each server once, by its id (two servers can share a name); the lists are capped at
    # MAX_HOSTS_RECORDED per CVE, so when one was cut the figure is a floor and says so
    servers, capped = set(), False
    for i in items:
        if i["status"] in ("affected", "pending_reboot"):
            listed = [h for h in i["affected_hosts"] if h["state"] in ("affected", "fixed_pending_reboot")]
            servers.update(h.get("host_id") or h["hostname"] for h in listed)
            if i.get("affected", 0) + i.get("pending_reboot", 0) > len(listed):
                capped = True
    return {"by_status": by, "cves": len(items),
            "cves_needing_action": by.get("affected", 0) + by.get("pending_reboot", 0),
            "servers_needing_action": len(servers), "servers_at_least": capped,
            "exploited_and_affected": sum(1 for i in items if i["kev"] and i["status"] == "affected")}


# ---------------------------------------------------------------------------
# r137: an assessment kept up to date. The Detected CVEs pass analyses every CVE of an open
# assessment with the same analysis (cve_impact.analyse_store) and calls refresh_cve: the
# package check is run again, the word worked out by the same rule, and each change recorded.
# ---------------------------------------------------------------------------

PROVEN = ("confirmed", "in_range", "no_fix", "pending_reboot", "seen_running")


def _short(n):
    n = str(n or "").strip().lower()
    return n if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", n) else n.split(".")[0]


def machines_of(affected_hosts, matches):
    """The machines a CVE is proven on: servers the package check flags (a restart to finish the fix
    counts), and the inventory's proven matches (appliances with an affected firmware too)."""
    names = {_short(h.get("hostname")) for h in affected_hosts or []
             if h.get("state") in ("affected", "fixed_pending_reboot") and h.get("hostname")}
    names |= {_short(m.get("name")) for m in matches or [] if m.get("certainty") in PROVEN and m.get("name")}
    return names


def matches_for_item(lines, info):
    """What an assessment item keeps of the analysis: the proven matches, then the appliances."""
    appl = [dict(x, where="Appliance", certainty="in_range" if x["state"] == "affected" else "check")
            for x in info.get("appliances") or []]
    return (list(lines) + appl)[:60]


def first_of(item):
    """What an item found when the assessment was submitted (kept for the record)."""
    return {"at": item.get("at"), "status": item.get("status"), "exposure": item.get("exposure"),
            "affected": item.get("affected"), "pending_reboot": item.get("pending_reboot"),
            "machines": sorted(machines_of(item.get("affected_hosts"), item.get("inventory_matches")))[:200]}


def _detail(before, now):
    gone, new = sorted(before - now), sorted(now - before)
    parts = []
    if gone:
        parts.append("no longer affected: " + ", ".join(gone[:10]) + (f" and {len(gone) - 10} more" if len(gone) > 10 else ""))
    if new:
        parts.append("newly affected: " + ", ".join(new[:10]) + (f" and {len(new) - 10} more" if len(new) > 10 else ""))
    return "; ".join(parts) or None


def refresh_cve(conn, cve_id, verdict, lines, info, has_data):
    """Bring every open assessment holding this CVE up to date with the one analysis. Items not yet
    looked at for the first time (enrichment) are left to it. Returns how many items changed."""
    from . import cve_impact
    rows = conn.execute(
        """SELECT ai.assessment_id, ai.status, ai.exposure, ai.affected_hosts, ai.inventory_matches
             FROM cve_assessment_items ai JOIN cve_assessments a ON a.id = ai.assessment_id
            WHERE ai.cve_id = %s AND ai.enriched_at IS NOT NULL AND a.closed_at IS NULL
              AND a.created_at > now() - make_interval(days => %s::int)""",
        (cve_id, cve_impact.ASSESS_KEEP_DAYS)).fetchall()
    if not rows:
        return 0
    it = evaluate(conn, [cve_id])[0][0]
    word = cve_impact.exposure_word(it["status"], verdict, lines, info.get("appliances") or [], has_data)
    matches = matches_for_item(lines, info)
    now_names = machines_of(it["affected_hosts"], matches)
    changed = 0
    for r in rows:
        before = machines_of(_json(r["affected_hosts"]), _json(r["inventory_matches"]))
        conn.execute(
            """UPDATE cve_assessment_items SET status = %s, affected = %s, pending_reboot = %s, patched = %s, unknown = %s,
                      advisories = %s, packages = %s, affected_hosts = %s, exposure = %s, inventory_matches = %s,
                      platforms = %s, excluded = %s, refreshed_at = now()
                WHERE assessment_id = %s AND cve_id = %s""",
            (it["status"], it["affected"], it["pending_reboot"], it["patched"], it["unknown"], it["advisories"],
             it["packages"], json.dumps(it["affected_hosts"]), word, json.dumps(matches, default=str),
             info.get("platforms") or [], json.dumps({"machines": info.get("excluded") or [], "notes": info.get("notes") or []},
                                                     default=str), r["assessment_id"], cve_id))
        if word != r["exposure"] or before != now_names:
            changed += 1
            conn.execute("""INSERT INTO cve_assessment_changes (assessment_id, cve_id, from_word, to_word, from_n, to_n, detail)
                            VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                         (r["assessment_id"], cve_id, r["exposure"], word, len(before), len(now_names),
                          _detail(before, now_names)))
        conn.execute("UPDATE cve_assessments SET refreshed_at = now() WHERE id = %s", (r["assessment_id"],))
    return changed


def _json(v):
    if isinstance(v, str):
        try:
            return json.loads(v)
        except ValueError:
            return []
    return v or []
