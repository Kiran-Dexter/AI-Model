"""The corporate proxy, set in one place (r138: Admin > Proxy).

Every request PATCH-01 makes to the internet goes through the worker: the CVE feeds (NIST,
Microsoft, Red Hat), CISA's list, FIRST's EPSS, CVE.org, Oracle's OVAL, and the repository syncs
(Pulp). Before r138 the proxy came only from /etc/patch-platform/proxy.env, copied into the
worker when phase3b-api.sh ran: a change needed a script, and nothing showed which proxy was in use.

Three choices, saved here:
  install   the proxy recorded at install (proxy.env), as before r138
  direct    no proxy: straight to the internet
  proxy     this address, with a username and password only if the proxy asks for one
            (the password is kept encrypted with PATCH-01's key, never shown again)

The worker applies the saved choice within 30 seconds: to its own requests, and to every Pulp
repository's remote ('install' gives them proxy.env's proxy, as phase2-repos.py does). Internal names
(the database, Pulp, AI-01) never go through a proxy, whatever is saved.

Test runs in the worker (where the requests really go): it tries each outside source with the
given settings and reports what answered: the source (200), the proxy refusing (403, or 407: "a
login is needed or this site is not allowed"), or nothing.
"""
import concurrent.futures
import logging
import os
import re
import socket
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

log = logging.getLogger("patchapi.netproxy")

MODES = ("install", "direct", "proxy")
URL_RE = re.compile(r"^https?://[A-Za-z0-9.-]{1,253}(:\d{1,5})?/?$")
NAME_RE = re.compile(r"^[A-Za-z0-9.*_-]{1,253}$")
USER_RE = re.compile(r"^[^\s:@/]{1,128}$")
INTERNAL = ["localhost", "127.0.0.1", "postgres", "redis", "patch01-postgres", "patch01-redis", "patch01-api",
            "pulp-api", "pulp-content", "patch01-pulp-api", "patch01-pulp-content", "ai01"]
# What the process was started with (proxy.env, through worker.env): the 'install' choice
INSTALL = {k: os.environ.get(k) or os.environ.get(k.lower()) for k in ("HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY")}
_KEYS = ("HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY", "https_proxy", "http_proxy", "no_proxy")

# The outside sources PATCH-01 reads, as Test tries them (a small read of each)
TARGETS = [
    ("NIST NVD", "https://services.nvd.nist.gov/rest/json/cves/2.0?cveId=CVE-2024-3400", "CVE feed, CVE details"),
    ("CISA exploited list", "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json", "Exploited CVEs"),
    ("CVE.org", "https://cveawg.mitre.org/api/cve/CVE-2024-3400", "The vendor's versions, CISA's assessment (r137)"),
    ("FIRST EPSS", "https://api.first.org/data/v1/epss?cve=CVE-2024-3400", "Exploit likelihood"),
    ("Red Hat security data", "https://access.redhat.com/hydra/rest/securitydata/cve/CVE-2024-3400.json", "Red Hat's CVE states"),
    ("Microsoft Update Guide", "https://api.msrc.microsoft.com/cvrf/v3.0/updates", "Microsoft's CVEs and KBs"),
    ("Oracle OVAL", "https://linux.oracle.com/security/oval/", "Oracle Linux ELSA advisories (r137)"),
    ("Oracle Linux repositories", "https://yum.oracle.com/repo/OracleLinux/OL8/baseos/latest/x86_64/repodata/repomd.xml", "Repository sync"),
    ("Red Hat CDN", "https://cdn.redhat.com/content/dist/rhel9/9/x86_64/baseos/os/repodata/repomd.xml",
     "Repository sync (403 is expected here: Red Hat needs the entitlement certificate)"),
    ("Ubuntu archive", "http://archive.ubuntu.com/ubuntu/dists/noble/Release", "Repository sync"),
]


class ProxyError(ValueError):
    pass


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------

def load(conn):
    """The saved row, or the 'install' default before schema 073."""
    try:
        with conn.transaction():
            r = conn.execute("SELECT * FROM proxy_settings WHERE id = 1").fetchone()
        return dict(r) if r else {"mode": "install"}
    except Exception:  # noqa: BLE001 - schema 073 not applied
        return {"mode": "install"}


def validate(mode, url, username, no_proxy):
    if mode not in MODES:
        raise ProxyError("Choose: as set at install, no proxy, or this proxy.")
    if mode != "proxy":
        return None, None, []
    url = (url or "").strip()
    if "@" in url:
        raise ProxyError("Put the username and password in their own boxes, not in the address.")
    if not URL_RE.match(url):
        raise ProxyError("The proxy address is like http://proxy.corp.example:8080 (http or https, a name, a port).")
    user = (username or "").strip() or None
    if user and not USER_RE.match(user):
        raise ProxyError("The username has no spaces, ':' '@' or '/'.")
    names = [n.strip() for n in re.split(r"[,\s]+", no_proxy or "") if n.strip()]
    bad = [n for n in names if not NAME_RE.match(n)]
    if bad:
        raise ProxyError("Not a host or domain name: " + ", ".join(bad[:5]))
    if len(names) > 100:
        raise ProxyError("At most 100 names that bypass the proxy.")
    return url.rstrip("/"), user, names


def proxy_url(url, username=None, password=None):
    """The address with the login in it, percent-encoded, for the libraries that take it that way."""
    if not url:
        return None
    if not username:
        return url
    p = urllib.parse.urlsplit(url)
    cred = urllib.parse.quote(username, safe="") + (":" + urllib.parse.quote(password, safe="") if password else "")
    return urllib.parse.urlunsplit((p.scheme, cred + "@" + p.netloc, p.path, "", ""))


def masked(url):
    return re.sub(r"//[^/@]*@", "//***@", url or "") or None


def effective(conn, row=None, secret=None):
    """{"mode", "url" (with the login, for use), "shown" (without it), "no_proxy" [..], "source"}."""
    from . import antivirus
    row = row or load(conn)
    mode = row.get("mode") or "install"
    if mode == "direct":
        return {"mode": mode, "url": None, "shown": None, "no_proxy": [], "source": "Admin > Proxy"}
    if mode == "proxy":
        pw = secret
        if pw is None and row.get("password_enc"):
            pw = antivirus.decrypt(row["password_enc"])
        names = [n for n in (row.get("no_proxy") or "").split(",") if n]
        return {"mode": mode, "url": proxy_url(row.get("url"), row.get("username"), pw), "shown": row.get("url"),
                "user": row.get("username"), "no_proxy": names, "source": "Admin > Proxy"}
    u = INSTALL.get("HTTPS_PROXY") or INSTALL.get("HTTP_PROXY")
    names = [n for n in (INSTALL.get("NO_PROXY") or "").split(",") if n and n not in INTERNAL]
    return {"mode": "install", "url": u, "shown": masked(u), "no_proxy": names,
            "source": "proxy.env (set at install)" if u else "proxy.env: none recorded (straight to the internet)"}


def apply_env(eff):
    """Point this process's requests at the chosen proxy (urllib and requests read these)."""
    np = ",".join(INTERNAL + [n for n in eff.get("no_proxy") or [] if n not in INTERNAL])
    if eff.get("url"):
        for k in ("HTTPS_PROXY", "HTTP_PROXY", "https_proxy", "http_proxy"):
            os.environ[k] = eff["url"]
    else:
        for k in ("HTTPS_PROXY", "HTTP_PROXY", "https_proxy", "http_proxy"):
            os.environ.pop(k, None)
    os.environ["NO_PROXY"] = os.environ["no_proxy"] = np
    urllib.request.install_opener(None)        # urlopen builds its opener again, with these


_applied = {"key": None}


def apply(conn):
    """The worker, every 30 seconds: use the saved choice. Returns what it uses (shown without the login)."""
    row = load(conn)
    try:
        eff = effective(conn, row)
    except Exception as e:  # noqa: BLE001 - a password that cannot be read: keep what was in use, say why
        _record(conn, None, f"the saved password cannot be read: {e}")
        return None
    key = (eff.get("url"), tuple(eff.get("no_proxy") or []))
    if key != _applied["key"]:
        apply_env(eff)
        _applied["key"] = key
        log.info("proxy: %s (%s)", masked(eff.get("url")) or "none", eff["source"])
    _record(conn, eff, None)
    return eff


_last_record = {"at": 0.0, "what": None}


def _record(conn, eff, error):
    """What the worker uses, for the page (without the login); written when it changes, else once a minute."""
    what = ((masked(eff.get("url")) if eff else None), (eff or {}).get("source"), error)
    if what == _last_record["what"] and time.monotonic() - _last_record["at"] < 60:
        return
    try:
        with conn.transaction():
            conn.execute("""UPDATE proxy_settings SET worker_url = %s, worker_source = %s, worker_error = %s,
                                   install_url = %s, worker_seen_at = now() WHERE id = 1""",
                         what + (masked(INSTALL.get("HTTPS_PROXY") or INSTALL.get("HTTP_PROXY")),))
        _last_record.update(at=time.monotonic(), what=what)
    except Exception:  # noqa: BLE001 - schema 073 not applied
        pass


# ---------------------------------------------------------------------------
# Pulp: every repository's remote takes the same proxy
# ---------------------------------------------------------------------------

def _split(url):
    """(address without the login, username, password) from a proxy URL that may carry a login."""
    if not url:
        return None, None, None
    p = urllib.parse.urlsplit(url)
    host = p.hostname + (f":{p.port}" if p.port else "") if p.hostname else ""
    bare = urllib.parse.urlunsplit((p.scheme, host, "", "", "")) or None
    return bare, (urllib.parse.unquote(p.username) if p.username else None), (urllib.parse.unquote(p.password) if p.password else None)


def pulp_target(row):
    """(proxy_url, username, password) every Pulp remote should have for the saved choice."""
    mode = row.get("mode") or "install"
    if mode == "direct":
        return None, None, None
    if mode == "proxy":
        return row.get("url"), row.get("username"), (_password(row) if row.get("username") else None)
    return _split(INSTALL.get("HTTPS_PROXY") or INSTALL.get("HTTP_PROXY"))


def sync_pulp(conn, eff=None, force=False):
    """Give every Pulp remote the chosen proxy when the saved choice changed since the last time, or a
    remote shows another address (phase2-repos.py run again, say). 'install' gives them proxy.env's,
    as phase2-repos.py does."""
    from . import pulp_repos
    row = load(conn)
    if not row.get("updated_at") or not pulp_repos.configured():
        return None                               # never saved on the page: Pulp stays as the install set it
    want, user, pw = pulp_target(row)
    changed = force or not row.get("pulp_applied_at") or row["updated_at"] > row["pulp_applied_at"]
    try:
        p = pulp_repos.Pulp()
        done, errors = 0, []
        for path in pulp_repos.REMOTES.values():
            for rem in p.paged(path + "?limit=200"):
                have = _split(rem.get("proxy_url"))[0]
                if not changed and have == want:
                    continue
                body = {"proxy_url": want, "proxy_username": user if want else None, "proxy_password": pw if want and user else None}
                try:
                    res = p.request("PATCH", rem["pulp_href"], body)
                    if res.get("task"):
                        p.wait(res["task"], timeout=120)
                    done += 1
                except Exception as e:  # noqa: BLE001 - the other remotes still change
                    errors.append(f"{rem.get('name')}: {str(e)[:150]}")
        if done or errors or changed:
            with conn.transaction():
                conn.execute("UPDATE proxy_settings SET pulp_applied_at = CASE WHEN %s THEN now() ELSE pulp_applied_at END, "
                             "pulp_result = %s WHERE id = 1",
                             (not errors, f"{done} repository remote(s) set to " + (masked(want) or "no proxy")
                              + ("; problems: " + "; ".join(errors[:5]) if errors else "")))
        return {"changed": done, "errors": errors}
    except Exception as e:  # noqa: BLE001 - recorded, tried again in 30 seconds
        with conn.transaction():
            conn.execute("UPDATE proxy_settings SET pulp_result = %s WHERE id = 1", (f"Pulp could not be set: {str(e)[:250]}",))
        return {"error": str(e)}


def _password(row):
    from . import antivirus
    return antivirus.decrypt(row["password_enc"]) if row.get("password_enc") else None


# ---------------------------------------------------------------------------
# Test
# ---------------------------------------------------------------------------

def _probe(name, url, why, proxy, no_proxy):
    host = urllib.parse.urlsplit(url).hostname or ""
    bypass = any(host == n or (n.startswith(".") and host.endswith(n)) or host.endswith("." + n.lstrip("*.")) for n in no_proxy)
    handler = urllib.request.ProxyHandler({} if not proxy or bypass else {"http": proxy, "https": proxy})
    opener = urllib.request.build_opener(handler, urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    t0 = time.monotonic()
    out = {"name": name, "url": url, "why": why, "via": "direct" if not proxy or bypass else "proxy"}
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "PATCH-01 proxy test", "Range": "bytes=0-1023"})
        with opener.open(req, timeout=20) as r:
            r.read(1024)
            out.update(status=r.status, ok=True, answer="reached")
    except urllib.error.HTTPError as e:
        out.update(status=e.code, ok=e.code < 500 and e.code not in (403, 407) or (e.code == 403 and "cdn.redhat.com" in url),
                   answer=_words(e.code, url, e.headers.get("Proxy-Authenticate") if e.headers else None))
    except urllib.error.URLError as e:
        msg = str(e.reason)
        m = re.search(r"Tunnel connection failed: (\d{3})", msg)
        if m:
            code = int(m.group(1))
            out.update(status=code, ok=False, answer=_words(code, url, None, tunnel=True))
        elif isinstance(e.reason, socket.timeout) or "timed out" in msg:
            out.update(status=None, ok=False, answer="no answer within 20 seconds (blocked, or the proxy address is wrong)")
        elif isinstance(e.reason, ssl.SSLError):
            out.update(status=None, ok=False, answer="TLS failed: the proxy may be inspecting HTTPS with its own certificate ("
                                                     + msg[:120] + ")")
        else:
            out.update(status=None, ok=False, answer="cannot connect: " + msg[:160])
    except (TimeoutError, socket.timeout):
        out.update(status=None, ok=False, answer="no answer within 20 seconds (blocked, or the proxy address is wrong)")
    except Exception as e:  # noqa: BLE001 - reported, the other sources still run
        out.update(status=None, ok=False, answer=str(e)[:200])
    out["ms"] = int((time.monotonic() - t0) * 1000)
    return out


def _words(code, url, auth, tunnel=False):
    if code == 407:
        return ("the proxy answered 407: it wants a login for this site, or it does not allow this site without one "
                "(ask the network team to allow " + (urllib.parse.urlsplit(url).hostname or "it") + ")"
                + (f"; it asks for: {auth.split()[0]}" if auth else ""))
    if code == 403:
        if "cdn.redhat.com" in url:
            return "reached Red Hat: 403 is expected without the entitlement certificate (the repository sync sends it)"
        return "refused (403)" + (" by the proxy" if tunnel else ": by the proxy or the site")
    if code in (200, 206, 301, 302, 304):
        return "reached"
    if code == 404:
        return "reached the site (404 for this test path: the site is reachable)"
    if code == 429:
        return "reached the site; it asks to slow down (429)"
    return f"answered HTTP {code}"


def test(eff):
    """Try every outside source with these settings, at the same time. [{name, url, status, ok, answer, via, ms}]"""
    proxy, names = eff.get("url"), eff.get("no_proxy") or []
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(TARGETS)) as ex:
        futs = [ex.submit(_probe, n, u, w, proxy, names) for n, u, w in TARGETS]
        return [f.result() for f in futs]


def run_pending_test(conn):
    """The worker: run the oldest test asked for under Admin > Proxy. Returns its id, or None."""
    from . import antivirus
    try:
        with conn.transaction():
            t = conn.execute("""UPDATE proxy_tests SET started_at = now()
                                 WHERE id = (SELECT id FROM proxy_tests WHERE started_at IS NULL ORDER BY id LIMIT 1
                                             FOR UPDATE SKIP LOCKED)
                                 RETURNING *""").fetchone()
    except Exception:  # noqa: BLE001 - schema 073 not applied
        return None
    if not t:
        return None
    t = dict(t)
    try:
        if t["mode"] == "proxy":
            pw = antivirus.decrypt(t["password_enc"]) if t.get("password_enc") else None
            eff = {"url": proxy_url(t["url"], t.get("username"), pw), "no_proxy": [n for n in (t.get("no_proxy") or "").split(",") if n]}
        elif t["mode"] == "direct":
            eff = {"url": None, "no_proxy": []}
        else:
            eff = effective(conn, {"mode": "install"})
        res, err = test(eff), None
    except Exception as e:  # noqa: BLE001 - reported on the page
        res, err = [], str(e)[:300]
    import json as _json
    with conn.transaction():
        conn.execute("UPDATE proxy_tests SET done_at = now(), results = %s, error = %s, password_enc = NULL WHERE id = %s",
                     (_json.dumps(res), err, t["id"]))
    return t["id"]
