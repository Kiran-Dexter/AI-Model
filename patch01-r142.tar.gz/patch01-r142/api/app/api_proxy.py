"""Admin > Proxy (r138): the corporate proxy in one place, and a test of every outside source."""
from typing import Optional

from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field

from .core import app, audit, client_ip, db, jsonable, require_admin


class ProxyIn(BaseModel):
    mode: str = Field(..., pattern="^(install|direct|proxy)$")
    url: Optional[str] = Field(None, max_length=300)
    username: Optional[str] = Field(None, max_length=128)
    # None: keep the saved password; "": remove it; text: the new password
    password: Optional[str] = Field(None, max_length=256)
    no_proxy: Optional[str] = Field("", max_length=4000)


def _need_schema(conn):
    if not conn.execute("SELECT 1 FROM schema_version WHERE version = 73").fetchone():
        raise HTTPException(503, "This needs schema 073: run phase3a-schema.sh first.")


def _secret(body, row):
    """(password_enc to store, the clear password for a test) from what was typed and what is saved."""
    from . import antivirus
    if body.mode != "proxy" or not (body.username or "").strip():
        return None, None
    if body.password is None:                     # kept: only for the same username
        if row.get("password_enc") and (row.get("username") or "") == body.username.strip():
            return row["password_enc"], None
        return None, None
    if body.password == "":
        return None, None
    try:
        return antivirus.encrypt(body.password), body.password
    except Exception as e:  # noqa: BLE001 - the key is missing
        raise HTTPException(503, f"The password cannot be stored: {e}")


def _view(conn):
    from . import netproxy
    row = netproxy.load(conn)
    test = conn.execute("""SELECT id, requested_by, requested_at, mode, url, username, started_at, done_at, results, error
                             FROM proxy_tests ORDER BY id DESC LIMIT 1""").fetchone()
    return jsonable({
        "settings": {k: row.get(k) for k in ("mode", "url", "username", "no_proxy", "updated_by", "updated_at")},
        "has_password": bool(row.get("password_enc")),
        "worker": {k: row.get(k) for k in ("worker_url", "worker_source", "worker_error", "worker_seen_at", "install_url")},
        "pulp": {"applied_at": row.get("pulp_applied_at"), "result": row.get("pulp_result")},
        "last_test": dict(test) if test else None,
        "sources": [{"name": n, "url": u, "why": w} for n, u, w in netproxy.TARGETS]})


@app.get("/api/v1/admin/proxy")
def proxy_get(admin: str = Depends(require_admin)):
    with db() as conn:
        _need_schema(conn)
        return _view(conn)


@app.put("/api/v1/admin/proxy")
def proxy_put(body: ProxyIn, request: Request, admin: str = Depends(require_admin)):
    from . import netproxy
    try:
        url, user, names = netproxy.validate(body.mode, body.url, body.username, body.no_proxy)
    except netproxy.ProxyError as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        with conn.transaction():
            _need_schema(conn)
            row = netproxy.load(conn)
            enc, _ = _secret(body, row)
            conn.execute("""UPDATE proxy_settings SET mode = %s, url = %s, username = %s, password_enc = %s, no_proxy = %s,
                                   updated_by = %s, updated_at = now() WHERE id = 1""",
                         (body.mode, url, user, enc, ",".join(names), admin))
            audit(conn, actor=admin, actor_type="user", action="proxy_saved",
                  detail={"mode": body.mode, "url": url, "username": user, "password": "set" if enc else "none",
                          "no_proxy": names[:20], "from": row.get("mode")}, source_ip=client_ip(request))
        return _view(conn)


@app.post("/api/v1/admin/proxy/test")
def proxy_test(body: ProxyIn, request: Request, admin: str = Depends(require_admin)):
    """Ask the worker to try every outside source with these settings (saved or not); it starts within
    5 seconds. The password typed for a test is kept only until the test has run."""
    from . import netproxy
    try:
        url, user, names = netproxy.validate(body.mode, body.url, body.username, body.no_proxy)
    except netproxy.ProxyError as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        with conn.transaction():
            _need_schema(conn)
            if conn.execute("SELECT 1 FROM proxy_tests WHERE done_at IS NULL AND requested_at > now() - interval '2 minutes'").fetchone():
                raise HTTPException(429, "A test is already running: its results show in a few seconds.")
            row = netproxy.load(conn)
            enc, _ = _secret(body, row)
            t = conn.execute("""INSERT INTO proxy_tests (requested_by, mode, url, username, password_enc, no_proxy)
                                VALUES (%s, %s, %s, %s, %s, %s) RETURNING id""",
                             (admin, body.mode, url, user, enc, ",".join(names))).fetchone()
            audit(conn, actor=admin, actor_type="user", action="proxy_tested", detail={"mode": body.mode, "url": url},
                  source_ip=client_ip(request))
    return {"ok": True, "id": t["id"]}


@app.get("/api/v1/admin/proxy/test/{test_id}")
def proxy_test_result(test_id: int, admin: str = Depends(require_admin)):
    with db() as conn:
        t = conn.execute("""SELECT id, requested_by, requested_at, mode, url, username, started_at, done_at, results, error
                              FROM proxy_tests WHERE id = %s""", (test_id,)).fetchone()
    if not t:
        raise HTTPException(404, "No such test.")
    return jsonable(dict(t))
