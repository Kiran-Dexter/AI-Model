"""Appliance firmware versions compared by each vendor's own numbering (r137).

A firmware version is only compared with another when both are written in the same known way.
Anything else is "to check", never guessed:

  plain        7.2.5, 9.16.4.57                     numbers, part by part (any maker)
  fortinet     v7.2.5 build1517, 7.4.3              x.y.z; the build number belongs to that x.y.z
  paloalto     10.2.9-h1, 11.1.2                    x.y.z then the hotfix (-hN; none is h0)
  cisco_xe     17.9.4a, 17.9.4                      x.y.z then the rebuild letter (none, a, b ...)
  cisco_paren  9.16(4)57, 9.3(10), 9.3(5a)          x.y(z[letter]) then the interim build (ASA, NX-OS)
  juniper      21.4R3-S6, 22.2R1, 21.4R3-S6.1       x.yRn then the service release (-Sn) and its respin
  sonicwall    7.0.1-5145                           x.y.z then the build
  checkpoint   R81.20, R81                          Rx.y

Cisco IOS trains (15.2(4)M7), Junos X or D releases (15.1X49-D200) and the like are not ordered
here: a vendor's own list of exact affected releases (a CVE record) can still match them exactly.
"""
import re

_P = {
    "plain": re.compile(r"^(\d+)(?:\.(\d+))?(?:\.(\d+))?(?:\.(\d+))?(?:\.(\d+))?$"),
    "fortinet": re.compile(r"^v?(\d+)\.(\d+)\.(\d+)(?:\s*,?\s*build\s*0*\d+)?(?:\s*\([^)]*\))?$", re.I),
    "paloalto": re.compile(r"^(\d+)\.(\d+)\.(\d+)(?:-h(\d+))?$", re.I),
    "cisco_xe": re.compile(r"^(\d+)\.(\d+)\.(\d+)([a-z]?)$", re.I),
    "cisco_paren": re.compile(r"^(\d+)\.(\d+)\((\d+)([a-z]?)\)(\d+)?$", re.I),
    "juniper": re.compile(r"^(\d+)\.(\d+)R(\d+)(?:-S(\d+))?(?:\.(\d+))?$", re.I),
    "sonicwall": re.compile(r"^(\d+)\.(\d+)\.(\d+)-(\d+)$", re.I),
    "checkpoint": re.compile(r"^R(\d+)(?:\.(\d+))?$", re.I),
}
# Which numberings a maker uses, most specific first ("plain" is tried last for every maker)
VENDOR_SCHEMES = {
    "fortinet": ("fortinet",), "paloaltonetworks": ("paloalto",), "cisco": ("cisco_xe", "cisco_paren"),
    "juniper": ("juniper",), "sonicwall": ("sonicwall",), "checkpoint": ("checkpoint",),
}


def vendor_key(v):
    """'Palo Alto Networks' / 'paloaltonetworks' / 'palo_alto_networks' -> 'paloaltonetworks'."""
    k = re.sub(r"[^a-z0-9]+", "", str(v or "").lower())
    for name in ("paloalto", "checkpoint", "fortinet", "juniper", "sonicwall", "cisco"):
        if k.startswith(name):
            return "paloaltonetworks" if name == "paloalto" else name
    return k


def clean(v):
    """The version as written, tidied: no leading 'v' before a digit, single spaces, trimmed."""
    s = re.sub(r"\s+", " ", str(v or "").strip())
    return re.sub(r"^[vV](?=\d)", "", s)


def _key(scheme, m):
    g = m.groups()
    if scheme == "plain":
        return tuple(int(x) for x in g if x is not None)
    if scheme == "fortinet":
        return (int(g[0]), int(g[1]), int(g[2]))
    if scheme == "paloalto":
        return (int(g[0]), int(g[1]), int(g[2]), int(g[3] or 0))
    if scheme == "cisco_xe":
        return (int(g[0]), int(g[1]), int(g[2]), (ord(g[3].lower()) - 96) if g[3] else 0)
    if scheme == "cisco_paren":
        return (int(g[0]), int(g[1]), int(g[2]), (ord(g[3].lower()) - 96) if g[3] else 0, int(g[4] or 0))
    if scheme == "juniper":
        return (int(g[0]), int(g[1]), int(g[2]), int(g[3] or 0), int(g[4] or 0))
    if scheme == "sonicwall":
        return tuple(int(x) for x in g)
    if scheme == "checkpoint":
        return (int(g[0]), int(g[1] or 0))
    return None


def parse(version, vendor=None):
    """(scheme, key) for a version written in a numbering this maker uses, else None."""
    v = clean(version)
    if not v:
        return None
    for scheme in VENDOR_SCHEMES.get(vendor_key(vendor), ()) + ("plain",):
        m = _P[scheme].match(v)
        if m:
            return scheme, _key(scheme, m)
    return None


def _pad(a, b):
    n = max(len(a), len(b))
    return a + (0,) * (n - len(a)), b + (0,) * (n - len(b))


def compare(a, b, vendor=None):
    """-1, 0 or 1 when both are written the same known way; None when they cannot be ordered."""
    pa, pb = parse(a, vendor), parse(b, vendor)
    if not pa or not pb:
        return None
    if pa[0] != pb[0]:
        # 7.2.5 (plain) against v7.2.5 build1517 (fortinet): the same numbers, so comparable as plain
        both = {pa[0], pb[0]}
        if both <= {"plain", "fortinet"} or both <= {"plain", "cisco_xe"} or both <= {"plain", "paloalto"}:
            ka, kb = _pad(pa[1], pb[1])
            if pa[0] == "plain" and len(pa[1]) > 3 or pb[0] == "plain" and len(pb[1]) > 3:
                return None               # 9.16.4.57 is not a hotfix or a rebuild letter
            return (ka > kb) - (ka < kb)
        return None
    ka, kb = _pad(pa[1], pb[1])
    return (ka > kb) - (ka < kb)


def same(a, b, vendor=None):
    """Exact equality: compared when both parse, else the tidied text (case-insensitive)."""
    c = compare(a, b, vendor)
    if c is not None:
        return c == 0
    return clean(a).lower() == clean(b).lower() and bool(clean(a))
