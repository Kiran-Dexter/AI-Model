"""CVE.org records (r137): the vendor's own affected versions, and CISA's assessment.

NIST stopped adding product lists and scores to most CVEs in April 2026 (only CVEs in CISA's KEV
list, or in "critical software", are still worked on). The record a vendor writes when it
publishes a CVE (Fortinet, Cisco, Palo Alto, Google ...) carries what NIST no longer adds:

  cna      the vendor's products and versions: ranges (version .. lessThan / lessThanOrEqual),
           exact releases, the status of anything not listed (defaultStatus), and its score
  adp      CISA's assessment, added to the same record: exploitation (none, poc, active),
           automatable (yes, no), technical impact (partial, total), and the KEV entry

Read one CVE at a time from the CVE Services API (no account is needed to read a published
record): only the CVEs PATCH-01 checks (the feeds' window and the open assessments), again
when a day old. Nothing about our servers is sent: the request is the CVE number.

How it is used (cve_impact): a vendor's range is compared only with Windows programs proven to
be the product (name and maker, or an admin's word) and with appliances, by the maker's own
version numbering (fwver). Never with Linux packages: distributions backport fixes, so an
upstream version says nothing about a distribution's build (their advisories decide those).
Never for ESXi, vCenter, Windows itself or Microsoft's programs: Microsoft's and VMware's own
data and Windows Update decide those.
"""
import json
import logging
import os
import re
import time
import urllib.error
import urllib.request

from . import exposure, fwver

log = logging.getLogger("patchapi.cve_org")

API = os.environ.get("CVE_ORG_API", "https://cveawg.mitre.org/api/cve").rstrip("/")
CVE_RE = re.compile(r"^CVE-\d{4}-\d{4,7}$")
MAX_RESPONSE = 8 * 2 ** 20
PAUSE = 0.4                      # between requests
REFRESH_HOURS = 24               # a record is read again when this old
MAX_PRODUCTS = 50
MAX_VERSIONS = 300
UA = "PATCH-01"
# Makers whose CVE records are not used for versions: the distributions (their advisories decide,
# fixes are backported), Microsoft and VMware (their own update data decides), the Linux kernel
SKIP_VENDORS = {"redhat", "canonical", "debian", "suse", "opensuse", "ubuntu", "almalinux", "rockylinux", "fedora",
                "fedoraproject", "centos", "microsoft", "vmware", "broadcom", "linux", "kernel", "linuxfoundation"}
NETWORK = {re.sub(r"[^a-z0-9]", "", v) for v in exposure.NETWORK_VENDORS}
OPEN_WORDS = {"", "0", "*", "-", "n/a", "na", "unspecified", "unknown", "all", "all versions", "any"}


class Unavailable(RuntimeError):
    """CVE.org could not be read now (network, rate limit): tried again later."""


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

def fetch(cve_id):
    """The published record (dict), None when CVE.org has none. Raises Unavailable."""
    if not CVE_RE.match(cve_id or ""):
        raise ValueError("not a CVE number")
    req = urllib.request.Request(f"{API}/{cve_id}", headers={"User-Agent": UA, "Accept": "application/json"})
    try:
        with urllib.request.build_opener().open(req, timeout=40) as r:      # through HTTPS_PROXY
            body = r.read(MAX_RESPONSE + 1)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise Unavailable(f"HTTP {e.code} from CVE.org")
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise Unavailable(f"cannot reach CVE.org: {e}")
    if len(body) > MAX_RESPONSE:
        raise Unavailable(f"the record for {cve_id} is larger than {MAX_RESPONSE // 2**20} MB")
    try:
        return json.loads(body.decode("utf-8"))
    except ValueError as e:
        raise Unavailable(f"CVE.org's answer for {cve_id} is not JSON: {e}")


def _text(v, n=200):
    return re.sub(r"\s+", " ", str(v or "")).strip()[:n]


def _score(metrics):
    """(score, severity, vector) from a container's metrics: CVSS 3.1, then 3.0, then 4.0."""
    for key in ("cvssV3_1", "cvssV3_0", "cvssV4_0"):
        for m in metrics or []:
            d = (m or {}).get(key) if isinstance(m, dict) else None
            if isinstance(d, dict) and isinstance(d.get("baseScore"), (int, float)):
                return float(d["baseScore"]), _text(d.get("baseSeverity"), 20).lower() or None, _text(d.get("vectorString"), 200) or None
    return None, None, None


def _versions(entries):
    out = []
    for e in (entries or [])[:MAX_VERSIONS]:
        if not isinstance(e, dict):
            continue
        st = str(e.get("status") or "").lower()
        if st not in ("affected", "unaffected", "unknown"):
            continue
        ch = []
        for c in (e.get("changes") or [])[:20]:
            if isinstance(c, dict) and c.get("at") and str(c.get("status") or "").lower() in ("affected", "unaffected"):
                ch.append([_text(c["at"], 60), str(c["status"]).lower()])
        out.append({"v": _text(e.get("version"), 60), "st": st, "lt": _text(e.get("lessThan"), 60) or None,
                    "le": _text(e.get("lessThanOrEqual"), 60) or None, "type": _text(e.get("versionType"), 20).lower() or None,
                    "ch": ch})
    return out


def parse(record):
    """The fields PATCH-01 keeps from one CVE record."""
    meta = (record or {}).get("cveMetadata") or {}
    cont = (record or {}).get("containers") or {}
    cna = cont.get("cna") or {}
    products = []
    for a in (cna.get("affected") or [])[:MAX_PRODUCTS]:
        if not isinstance(a, dict):
            continue
        vendor, product = _text(a.get("vendor"), 100), _text(a.get("product"), 150)
        if not vendor or not product or vendor.lower() in ("n/a", "unknown") or product.lower() in ("n/a", "unknown"):
            continue
        products.append({"vendor": vendor, "product": product,
                         "default": str(a.get("defaultStatus") or "unknown").lower(),
                         "versions": _versions(a.get("versions")),
                         "cpes": [_text(c, 200) for c in (a.get("cpes") or [])[:10] if isinstance(c, str)],
                         "platforms": [_text(p, 40) for p in (a.get("platforms") or [])[:10] if isinstance(p, str)]})
    score, sev, vec = _score(cna.get("metrics"))
    src = "cna" if score is not None else None
    ssvc = {}
    kev_added = None
    for adp in cont.get("adp") or []:
        pm = (adp or {}).get("providerMetadata") or {}
        if str(pm.get("shortName") or "").upper() != "CISA-ADP":
            continue
        if score is None:
            score, sev, vec = _score(adp.get("metrics"))
            src = "cisa" if score is not None else None
        for m in adp.get("metrics") or []:
            o = (m or {}).get("other") if isinstance(m, dict) else None
            if not isinstance(o, dict):
                continue
            c = o.get("content") or {}
            if o.get("type") == "ssvc":
                for opt in c.get("options") or []:
                    if isinstance(opt, dict):
                        for k, v in opt.items():
                            ssvc[_text(k, 40).lower()] = _text(v, 20).lower()
            elif o.get("type") == "kev" and c.get("dateAdded"):
                kev_added = _text(c["dateAdded"], 10)
    return {"cve_id": _text(meta.get("cveId"), 20), "state": _text(meta.get("state"), 20).lower() or None,
            "assigner": _text(meta.get("assignerShortName"), 60) or None, "date_updated": meta.get("dateUpdated"),
            "products": products, "cvss": score, "cvss_severity": sev, "cvss_vector": vec, "cvss_source": src,
            "ssvc_exploitation": ssvc.get("exploitation"), "ssvc_automatable": ssvc.get("automatable"),
            "ssvc_impact": ssvc.get("technical impact"), "kev_added": kev_added}


SAVE_SQL = """INSERT INTO cve_org (cve_id, state, assigner, date_updated, products, cvss, cvss_severity, cvss_vector,
                                   cvss_source, ssvc_exploitation, ssvc_automatable, ssvc_impact, kev_added,
                                   fetched_at, error, not_found)
              VALUES (%(cve_id)s, %(state)s, %(assigner)s, %(date_updated)s, %(products)s, %(cvss)s, %(cvss_severity)s,
                      %(cvss_vector)s, %(cvss_source)s, %(ssvc_exploitation)s, %(ssvc_automatable)s, %(ssvc_impact)s,
                      %(kev_added)s, now(), NULL, %(not_found)s)
              ON CONFLICT (cve_id) DO UPDATE SET state = EXCLUDED.state, assigner = EXCLUDED.assigner,
                date_updated = EXCLUDED.date_updated, products = EXCLUDED.products, cvss = EXCLUDED.cvss,
                cvss_severity = EXCLUDED.cvss_severity, cvss_vector = EXCLUDED.cvss_vector, cvss_source = EXCLUDED.cvss_source,
                ssvc_exploitation = EXCLUDED.ssvc_exploitation, ssvc_automatable = EXCLUDED.ssvc_automatable,
                ssvc_impact = EXCLUDED.ssvc_impact, kev_added = EXCLUDED.kev_added, fetched_at = now(),
                error = NULL, not_found = EXCLUDED.not_found"""


def save(conn, cve_id, record):
    if record is None:
        row = {"cve_id": cve_id, "state": None, "assigner": None, "date_updated": None, "products": "[]", "cvss": None,
               "cvss_severity": None, "cvss_vector": None, "cvss_source": None, "ssvc_exploitation": None,
               "ssvc_automatable": None, "ssvc_impact": None, "kev_added": None, "not_found": True}
    else:
        row = parse(record)
        if row["cve_id"] != cve_id:
            raise ValueError(f"CVE.org answered {row['cve_id']!r} for {cve_id}")
        row = dict(row, products=json.dumps(row["products"]), not_found=False)
    conn.execute(SAVE_SQL, row)


# The CVEs PATCH-01 checks: the feeds' window (as cve_impact.CANDIDATES takes them) and the open assessments
WATCHED_SQL = """
    SELECT DISTINCT cve_id FROM (
        SELECT i.cve_id FROM cve_feed_items i WHERE i.published >= now() - make_interval(days => %(days)s::int)
           -- the serious ones, and those nobody has scored yet (the vendor's record may score them)
           AND (i.cvss IS NULL OR i.cvss >= 7 OR i.exploited
                OR lower(coalesce(i.severity, '')) IN ('critical', 'high', 'important'))
        UNION
        SELECT ai.cve_id FROM cve_assessment_items ai JOIN cve_assessments a ON a.id = ai.assessment_id
         WHERE a.closed_at IS NULL AND a.created_at > now() - make_interval(days => %(keep)s::int)) w
     WHERE cve_id ~ '^CVE-[0-9]{4}-[0-9]{4,7}$'"""


def due(conn, days, keep_days, limit=500):
    """The watched CVEs to read now: never read, read before the feed changed, or a day old."""
    return [r["cve_id"] for r in conn.execute(
        f"""SELECT w.cve_id FROM ({WATCHED_SQL}) w LEFT JOIN cve_org o ON o.cve_id = w.cve_id
             WHERE o.cve_id IS NULL OR o.fetched_at IS NULL
                OR o.fetched_at < now() - make_interval(hours => %(hours)s::int)
                OR EXISTS (SELECT 1 FROM cve_feed_items f WHERE f.cve_id = w.cve_id AND f.modified > o.fetched_at)
             ORDER BY (o.cve_id IS NULL) DESC, o.fetched_at NULLS FIRST, w.cve_id DESC
             LIMIT %(limit)s::int""",
        {"days": int(days), "keep": int(keep_days), "hours": REFRESH_HOURS, "limit": int(limit)}).fetchall()]


def refresh(conn, cve_ids, budget_s=600, stop=lambda: False, fetcher=None):
    """Read these CVEs from CVE.org. Returns {"read", "not_found", "failed", "error"}; stops at the
    first sign CVE.org cannot be reached (the rest are read next time), and within budget_s."""
    fetcher = fetcher or fetch
    t0 = time.monotonic()
    res = {"read": 0, "not_found": 0, "failed": 0, "error": None}
    for cid in cve_ids:
        if stop() or time.monotonic() - t0 > budget_s:
            break
        try:
            rec = fetcher(cid)
            with conn.transaction():
                save(conn, cid, rec)
            res["not_found" if rec is None else "read"] += 1
        except Unavailable as e:
            res["error"] = str(e)[:300]
            break
        except Exception as e:  # noqa: BLE001 - one odd record never stops the rest
            res["failed"] += 1
            log.warning("CVE.org record %s: %s", cid, e)
            try:
                with conn.transaction():
                    conn.execute("""INSERT INTO cve_org (cve_id, fetched_at, error) VALUES (%s, now(), %s)
                                    ON CONFLICT (cve_id) DO UPDATE SET fetched_at = now(), error = EXCLUDED.error""",
                                 (cid, str(e)[:300]))
            except Exception:  # noqa: BLE001
                pass
        if fetcher is fetch:
            time.sleep(PAUSE)
    return res


# ---------------------------------------------------------------------------
# Products for the analysis
# ---------------------------------------------------------------------------

def _words_key(text):
    return re.sub(r"[^a-z0-9]+", "_", str(text or "").lower()).strip("_")


def products(row):
    """The record's products as cve_impact matches them: [{vendor, product, kind, label, cna, source}].
    vendor/product are word keys ('palo_alto_networks', 'pan_os'), as a CPE names them, for the
    identity rules; the versions stay the vendor's own (cna)."""
    out = []
    plist = (row or {}).get("products") or []
    if isinstance(plist, str):
        plist = json.loads(plist)
    for p in plist:
        vk = fwver.vendor_key(p.get("vendor"))
        if vk in SKIP_VENDORS or not p.get("versions"):
            continue
        pkey = _words_key(p.get("product"))
        vwords = _words_key(p.get("vendor"))
        # The product often repeats the maker ("Fortinet FortiOS"): the product words without it
        if pkey.startswith(vwords + "_"):
            pkey = pkey[len(vwords) + 1:]
        if "linux" in pkey.split("_") and vk in ("oracle",):
            continue                                   # Oracle Linux: its ELSA advisories decide
        part = None
        for c in p.get("cpes") or []:
            pc = exposure.parse_cpe(c)
            if pc:
                part = pc["part"]
                break
        if part == "o" and vk not in NETWORK:
            continue                                   # an operating system: its own vendor's updates decide
        kind = "Hardware or firmware" if part == "h" else "Network device or appliance" if vk in NETWORK else "Application"
        out.append({"vendor": vwords, "product": pkey, "vendor_key": vk, "kind": kind, "part": part or "a",
                    "label": f"{p.get('vendor')} {p.get('product')}", "ranges": [], "cfgs": [],
                    "cna": {"versions": p["versions"], "default": p.get("default") or "unknown"},
                    "platforms": p.get("platforms") or [], "source": "cve.org",
                    # A network maker's program (FortiClient, Secure Client, GlobalProtect) runs on Windows too
                    "also_program": vk in NETWORK and part != "h"})
    return out


def _open(v):
    return str(v or "").strip().lower() in OPEN_WORDS


def judge(version, cna, cmp, eq):
    """The vendor's word on one installed version: ("in_range" | "outside" | "unknown", detail, fixed).
    cmp(a, b) -> -1/0/1 or None (cannot be ordered); eq(a, b) -> bool. The most specific entry
    decides: an exact release, then a range, then "all versions", then the status of anything not
    listed. When entries of one kind disagree, affected wins (never clean on doubt)."""
    tiers = {"exact": set(), "range": set(), "all": set()}
    fixed, why, doubt = None, {}, False
    for e in cna.get("versions") or []:
        st = e.get("st")
        if st not in ("affected", "unaffected"):
            continue
        if e.get("type") == "git":
            doubt = True
            continue
        end = e.get("lt") or e.get("le")
        if end and not _open(end):
            start = None if _open(e.get("v")) else e.get("v")
            if start:
                c = cmp(version, start)
                if c is None:
                    doubt = True
                    continue
                if c < 0:
                    continue
            c = cmp(version, end)
            if c is None:
                doubt = True
                continue
            if c > 0 or (c == 0 and e.get("lt")):
                continue
            s = st
            best = None
            for at, cst in e.get("ch") or []:
                ca = cmp(version, at)
                if ca is None:
                    doubt = True
                    continue
                if ca >= 0 and (best is None or (cmp(at, best[0]) or 0) > 0):
                    best = (at, cst)
            if best:
                s = best[1]
            tiers["range"].add(s)
            if s == "affected":
                fixed = e.get("lt") or (best and best[0]) or fixed
                why.setdefault("range", f"version {version} is inside the vendor's affected range "
                                        f"{start or 'any'} to {'before ' + e['lt'] if e.get('lt') else e.get('le') + ' (included)'}")
            else:
                why.setdefault("range_out", f"version {version} is in a range the vendor lists as not affected")
        elif _open(e.get("v")):
            tiers["all"].add(st)
        elif eq(version, e.get("v")):
            tiers["exact"].add(st)
            if st == "affected":
                why.setdefault("exact", f"version {version} is one of the releases the vendor lists as affected")
    for t in ("exact", "range", "all"):
        if "affected" in tiers[t]:
            return "in_range", why.get(t) or f"the vendor lists every version as affected", fixed
        if "unaffected" in tiers[t]:
            return "outside", why.get("range_out") or f"version {version} is listed by the vendor as not affected", None
    if cna.get("default") == "unaffected" and not doubt:
        return "outside", f"version {version} is not among the versions the vendor lists as affected", None
    if doubt:
        return "unknown", f"version {version} cannot be compared with the vendor's versions (written another way)", None
    return "unknown", f"version {version} is not in the vendor's list, and the vendor does not say others are safe", None


def program_cmp(a, b):
    """For Windows programs: both must hold digits to be ordered (exposure.vcmp)."""
    if not re.search(r"\d", str(a or "")) or not re.search(r"\d", str(b or "")):
        return None
    return exposure.vcmp(a, b)


def program_eq(a, b):
    c = program_cmp(a, b)
    return c == 0 if c is not None else str(a or "").strip().lower() == str(b or "").strip().lower()


def device_cmp(vendor):
    return lambda a, b: fwver.compare(a, b, vendor)


def device_eq(vendor):
    return lambda a, b: fwver.same(a, b, vendor)
