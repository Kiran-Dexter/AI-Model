"""Vulnerabilities > Remediation (r131): the quarterly Nessus scan workbook.

An operator uploads the workbook (xlsx or csv; one sheet per quarter, e.g. "26Q3"). It is handled in two steps,
each in the background with its progress in the database:

  reading    every sheet is read once: its heading row, five sample rows, the number of rows and, per column, its
             different values (for the status words) and how its dates are written. The columns are placed by
             PATCH-01's rules (exact names, then a close spelling: the files have their own spellings), then by
             what a person chose for that heading before; AI-01 is asked only about the columns still unplaced.
  review     the operator sees every column with its sample values, what it was taken as and why, and confirms
             (or changes) it; status words the rules do not know and day/month order are asked, never guessed.
  importing  the file is read again with the confirmed columns and merged into the quarter: a finding is one
             plugin on one host, port and protocol. A value in the file wins; a blank keeps what PATCH-01 has
             (a re-upload of a quarter never wipes the statuses set here); a finding new to the quarter takes its
             PIC, status, exception, target date and categorisation from the previous quarter when the file
             leaves them blank (a finding fixed last quarter comes back as open).

Overdue, "seen in the previous quarter" and "fixed last quarter but found again" are worked out when they are
shown, from the data, so they are always right after an edit. Every change of a tracking field is kept with who
and when. The export writes the quarter back in the file's own columns and headings.
"""

import csv
import difflib
import gzip
import io
import ipaddress
import json
import re
import threading
import time
import zipfile
from datetime import date, datetime, timedelta, timezone

from .inventory import short_name


class RemError(Exception):
    """A reason the request cannot be done, in words for the operator (HTTP 400)."""


class NotFound(Exception):
    pass


# ---------------------------------------------------------------------------
# Fields, statuses, severities
# ---------------------------------------------------------------------------

# key, label, kind. The order is the template's: the export writes the columns in this order.
FIELDS = [
    ("uuid", "UUID", "text"),
    ("plugin_id", "Plugin", "text"),
    ("plugin_name", "Plugin name", "text"),
    ("severity", "Severity", "severity"),
    ("ip", "IP address", "ip"),
    ("env", "UAT/Prod", "text"),
    ("hostname", "Hostname", "text"),
    ("pic", "PIC", "text"),
    ("port", "Port", "port"),
    ("plugin_output", "Plugin output", "long"),
    ("synopsis", "Synopsis", "long"),
    ("description", "Description", "long"),
    ("solution", "Steps to Remediate", "long"),
    ("prev_finding", "Previous Finding", "text"),
    ("prev_fixed", "Previous Fixed but discovered", "text"),
    ("exception", "Exception", "text"),
    ("status", "Status", "status"),
    ("overdue", "Overdue?", "text"),
    ("report_shared", "Report Shared Date", "date"),
    ("completed_on", "Completion Date of Remediation", "date"),
    ("target_on", "New Target Completion Date of Remediation", "date"),
    ("protocol", "Protocol", "text"),
    ("first_seen", "First Discovered", "date"),
    ("last_seen", "Last observed", "date"),
    ("cve", "CVE", "text"),
    ("vuln_pub", "Vul Publication Date", "date"),
    ("plugin_pub", "Plugin publication date", "date"),
    ("cat1", "Categorization1", "text"),
    ("cat2", "Categorization2", "text"),
    ("cvss3", "CVSS v3.0 Base Score", "num"),
    ("cvss2", "CVSS v2.0 Base Score", "num"),
]
FIELD = {k: (label, kind) for k, label, kind in FIELDS}
FIELD_KEYS = [k for k, _l, _k in FIELDS]
DATE_FIELDS = [k for k, _l, kind in FIELDS if kind == "date"]
TRACKED = ("status", "pic", "exception", "target_on", "completed_on", "report_shared", "cat1", "cat2", "env")
CARRY = ("status", "pic", "exception", "target_on", "cat1", "cat2", "env")     # from the previous quarter, when blank

STATUSES = [("open", "Open"), ("fixed", "Fixed"), ("pending_review", "Pending review"), ("false_positive", "False positive"),
            ("pending_deviation", "Pending deviation approval"), ("deviation_approved", "Deviation approved"),
            ("decommission", "Decommission")]
STATUS = dict(STATUSES)
OPEN_STATUSES = ("open", "pending_review", "pending_deviation")
NO_ACTION = ("fixed", "decommission")             # kept in their own section: nothing left to do
SEVERITIES = [(4, "Critical"), (3, "High"), (2, "Medium"), (1, "Low"), (0, "Info")]
SEV = dict(SEVERITIES)
KINDS = {"server": "Server", "network": "Network device", "appliance": "Appliance", "unknown": "Type not known",
         "not_in_inventory": "Not in the inventory"}

MAX_BYTES = 60 * 1024 * 1024               # one request (nginx takes 64 MB): a big CSV is gzipped by the browser
MAX_UNPACKED = 800 * 1024 * 1024           # what an xlsx or a gzipped CSV may unpack to
MAX_COLS = 200
MAX_ROWS = 500_000                          # per sheet
MAX_DISTINCT = 60
EXCEL_CELL_MAX = 32767
STALL_S = 180                               # no heartbeat for this long: the reading / import stopped


def norm(text):
    """A heading or a word, compared: lower case, letters and digits only ("Severity " = "severity")."""
    return re.sub(r"[^a-z0-9]+", "", str(text or "").lower())


def norm_word(text):
    """A status word, compared: lower case, single spaces ("Pending  Review" = "pending review")."""
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", str(text or "").lower())).strip()


# Headings each field is known by: the template's (as written, with its own spellings) and Nessus's own exports
SYNONYMS = {
    "uuid": ["UUID", "Finding ID", "Unique ID"],
    "plugin_id": ["Plugin", "Plugin ID", "PluginID", "Plugin No", "Nessus Plugin ID"],
    "plugin_name": ["Plugin name", "Name", "Plugin Title", "Vulnerability", "Vulnerability Name", "Finding", "Title"],
    "severity": ["Severity", "Risk", "Risk Factor", "Severity Level", "Risk Rating"],
    "ip": ["IP address", "IP", "Host", "IP Address(es)", "Host IP", "Target", "IPv4"],
    "env": ["UAT/Prod", "Environment", "Env", "Prod/UAT", "UAT / Prod"],
    "hostname": ["Hostname", "Host name", "DNS Name", "NetBIOS Name", "FQDN", "Server", "Server Name", "Asset Name"],
    "pic": ["PIC", "Engineer", "Owner", "Assigned To", "Assignee", "Person in charge", "Responsible"],
    "port": ["port", "Port Number"],
    "plugin_output": ["Plugin output", "Output", "Plugin Text"],
    "synopsis": ["Synopsis", "Summary"],
    "description": ["Description", "Details"],
    "solution": ["Steps to Remediate", "Solution", "Remediation", "Fix", "Recommendation", "Remediation Steps"],
    "prev_finding": ["Previous Finding", "Previously Found", "Repeat Finding", "Prev Finding"],
    "prev_fixed": ["Previous Fixed but discovered", "Previously Fixed but discovered", "Reopened", "Fixed but rediscovered",
                   "Previous Fixed but rediscovered"],
    "exception": ["Exception", "Exception ID", "Exception Reference", "Deviation", "Deviation Reference"],
    "status": ["Status", "Remediation Status", "Finding Status", "State"],
    "overdue": ["Overdue?", "Overdue", "Is Overdue"],
    "report_shared": ["Report Shared Date", "Report Date", "Shared Date", "Date Shared"],
    "completed_on": ["Completion Date of Remediation", "Completion Date", "Remediation Date", "Date Fixed", "Fixed Date",
                     "Closed Date"],
    "target_on": ["New Target Completion Date of Remediation", "New Target Completion Date", "Target Date",
                  "Target Completion Date", "Due Date", "New Target Date"],
    "protocol": ["Protocol"],
    "first_seen": ["First Discovered", "First Seen", "First Found"],
    "last_seen": ["Last observed", "Last Seen", "Last Found"],
    "cve": ["CVE", "CVEs", "CVE ID"],
    "vuln_pub": ["Vul Publication Date", "Vuln Publication Date", "Vulnerability Publication Date"],
    "plugin_pub": ["Plugin publication date", "Plugin Published"],
    "cat1": ["Categorization1", "Categorization 1", "Category 1", "Category1", "Categorisation1"],
    "cat2": ["Categorization2", "Categorization 2", "Category 2", "Category2", "Categorisation2"],
    "cvss3": ["CVSS v3.0 Base Score", "CVSS v3 Base Score", "CVSS3", "CVSS v3.1 Base Score", "CVSS 3"],
    "cvss2": ["CVSS v2.0 Base Score", "CVSS v2 Base Score", "CVSS2", "CVSS"],
}
EXACT = {}
for _f, _names in SYNONYMS.items():
    for _n in _names:
        EXACT.setdefault(norm(_n), _f)
CLOSE_MIN = 0.88                            # a heading this close to a known one (and long enough) is that field


def rule_field(header):
    """(field, how, why) by PATCH-01's own rules, or (None, None, None)."""
    n = norm(header)
    if not n:
        return None, None, None
    if n in EXACT:
        return EXACT[n], "rule", "the heading is a known name for " + FIELD[EXACT[n]][0]
    if len(n) >= 6:
        best, score = None, 0.0
        for known, f in EXACT.items():
            if len(known) < 6:
                continue
            s = difflib.SequenceMatcher(None, n, known).ratio()
            if s > score:
                best, score = (known, f), s
        if best and score >= CLOSE_MIN:
            return best[1], "close", f"the heading is a close spelling of a known name for {FIELD[best[1]][0]}"
    return None, None, None


STATUS_WORDS = {
    "": "open", "open": "open", "new": "open", "not fixed": "open", "outstanding": "open", "unresolved": "open",
    "fixed": "fixed", "closed": "fixed", "resolved": "fixed", "remediated": "fixed", "done": "fixed", "patched": "fixed",
    "pending review": "pending_review", "under review": "pending_review", "in review": "pending_review",
    "review": "pending_review", "to review": "pending_review",
    "false positive": "false_positive", "fp": "false_positive", "false positives": "false_positive",
    "pending deviation approval": "pending_deviation", "pending deviation": "pending_deviation",
    "deviation pending": "pending_deviation", "pending deviation approved": "pending_deviation",
    "pending exception approval": "pending_deviation", "deviation approval pending": "pending_deviation",
    "deviation approved": "deviation_approved", "approved deviation": "deviation_approved",
    "exception approved": "deviation_approved", "risk accepted": "deviation_approved",
    "decommission": "decommission", "decommissioned": "decommission", "decom": "decommission",
    "to be decommissioned": "decommission", "decommissioning": "decommission",
}


def severity_of(v):
    """4..0 from a word or a number, or None when the value says nothing."""
    s = norm(v)
    if s in ("critical", "crit", "4", "40", "p1"):
        return 4
    if s in ("high", "3", "30"):
        return 3
    if s in ("medium", "med", "moderate", "2", "20"):
        return 2
    if s in ("low", "1", "10"):
        return 1
    if s in ("info", "informational", "none", "0", "00", "information"):
        return 0
    return None


# ---------------------------------------------------------------------------
# Values
# ---------------------------------------------------------------------------

def text(v):
    """A cell as text: numbers without a stray .0, dates as YYYY-MM-DD, spaces trimmed."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, float):
        if v != v:                                          # NaN
            return ""
        return str(int(v)) if v.is_integer() else repr(v)
    if isinstance(v, datetime):
        return v.date().isoformat() if (v.hour, v.minute, v.second) == (0, 0, 0) else v.isoformat(sep=" ")
    if isinstance(v, date):
        return v.isoformat()
    return str(v).replace("\x00", "").strip()


_MONTHS = {m: i + 1 for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"])}
_DMY = re.compile(r"^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2}|\d{4})(?:[ T].*)?$")
_YMD = re.compile(r"^(\d{4})[/.\-](\d{1,2})[/.\-](\d{1,2})(?:[ T].*)?$")
_DMONY = re.compile(r"^(\d{1,2})[ \-/]([A-Za-z]{3,9})[ \-/,]+(\d{2}|\d{4})(?:[ T].*)?$")
_MONDY = re.compile(r"^([A-Za-z]{3,9})\.? (\d{1,2}),? (\d{4})(?:[ T,].*)?$")       # Nessus: "Nov 13, 2026 10:00:00 UTC"


def _year(y):
    y = int(y)
    return y + 2000 if y < 100 else y


def slash_order(v):
    """For a d/m/y-or-m/d/y date written as text: 'dmy' or 'mdy' when the numbers prove it, 'either' when both
    could be meant, None when it is not such a date."""
    if isinstance(v, (date, datetime)):
        return None
    m = _DMY.match(text(v))
    if not m:
        return None
    a, b = int(m.group(1)), int(m.group(2))
    if a > 12 and b <= 12:
        return "dmy"
    if b > 12 and a <= 12:
        return "mdy"
    return "either" if a <= 12 and b <= 12 else None


def parse_date(v, order=None):
    """A date from a cell, or None. order ('dmy' / 'mdy') decides 03/04/2026; without it such a value is None."""
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if 20000 <= v <= 80000:                             # an Excel day number (1954 .. 2119)
            return date(1899, 12, 30) + timedelta(days=int(v))
        return None
    s = text(v)
    if re.fullmatch(r"\d{5}(\.\d+)?", s):
        return parse_date(float(s))
    try:
        m = _YMD.match(s)
        if m:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        m = _DMY.match(s)
        if m:
            a, b, y = int(m.group(1)), int(m.group(2)), _year(m.group(3))
            o = slash_order(s)
            if o == "either":
                o = order
            if o == "dmy":
                return date(y, b, a)
            if o == "mdy":
                return date(y, a, b)
            return None
        m = _DMONY.match(s)
        if m and m.group(2)[:3].lower() in _MONTHS:
            return date(_year(m.group(3)), _MONTHS[m.group(2)[:3].lower()], int(m.group(1)))
        m = _MONDY.match(s)
        if m and m.group(1)[:3].lower() in _MONTHS:
            return date(int(m.group(3)), _MONTHS[m.group(1)[:3].lower()], int(m.group(2)))
    except ValueError:                                      # 31/02/2026 and the like
        return None
    return None


def is_ip(v):
    try:
        ipaddress.ip_address(text(v))
        return True
    except ValueError:
        return False


def split_cat2(v):
    """"ER-2026Q3-M07:OS Patch & Core Security" -> ("ER-2026Q3-M07", "OS Patch & Core Security"); else (None, None)."""
    m = re.match(r"^\s*([A-Za-z]{1,8}-[A-Za-z0-9][A-Za-z0-9\-_.]*)\s*[:|]\s*(.+?)\s*$", text(v))
    return (m.group(1), m.group(2)) if m else (None, None)


def quarter_of(name):
    """"26Q3", "2026 Q3", "Q3-2026", "2026-Q3" -> "2026 Q3"; anything else -> None."""
    s = re.sub(r"\s+", " ", text(name)).strip()
    m = re.fullmatch(r"(?i)(?:FY\s?)?(\d{2}|\d{4})\s?[-_ ]?\s?Q([1-4])", s) \
        or re.fullmatch(r"(?i)Q([1-4])\s?[-_ ]?\s?(?:FY\s?)?(\d{2}|\d{4})", s)
    if not m:
        return None
    y, q = (m.group(1), m.group(2)) if s[:1].isdigit() or s[:2].upper() == "FY" else (m.group(2), m.group(1))
    y = _year(y)
    return f"{y} Q{q}" if 2000 <= y <= 2099 else None


def qkey(quarter):
    m = re.fullmatch(r"(\d{4}) Q([1-4])", quarter or "")
    return int(m.group(1)) * 10 + int(m.group(2)) if m else 0


def short_label(quarter):
    """"2026 Q3" -> "26Q3" (the sheet name the files use)."""
    m = re.fullmatch(r"\d{2}(\d{2}) Q([1-4])", quarter or "")
    return f"{m.group(1)}Q{m.group(2)}" if m else (quarter or "")


# ---------------------------------------------------------------------------
# Reading files
# ---------------------------------------------------------------------------

def file_type_of(name):
    n = (name or "").lower()
    if n.endswith((".xlsx", ".xlsm")):
        return "xlsx"
    if n.endswith((".csv", ".csv.gz", ".txt")):
        return "csv"
    if n.endswith(".xls"):
        raise RemError("Old .xls files cannot be read: open it in Excel and save it as .xlsx (Excel Workbook), then upload that.")
    raise RemError("Upload the scan workbook as .xlsx or .csv.")


def unpack(data, gz):
    """The file as uploaded; a gzipped body (the browser packs big CSV files) is unpacked, with a size limit."""
    if not gz:
        return data
    try:
        with gzip.GzipFile(fileobj=io.BytesIO(data)) as g:
            out = g.read(MAX_UNPACKED + 1)
    except (OSError, EOFError) as e:
        raise RemError(f"The upload could not be unpacked: {e}")
    if len(out) > MAX_UNPACKED:
        raise RemError("The file is larger than 800 MB unpacked.")
    return out


def _check_xlsx(data):
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise RemError("This is not an Excel .xlsx file (it is not a zip package). Save it from Excel as .xlsx and upload again.")
    if sum(i.file_size for i in z.infolist()) > MAX_UNPACKED:
        raise RemError("The workbook is larger than 800 MB unpacked.")
    if "xl/workbook.xml" not in z.namelist():
        raise RemError("This zip file is not an Excel workbook.")


def _decode(data):
    if data[:3] == b"\xef\xbb\xbf":
        return data[3:].decode("utf-8", "replace")
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return data.decode("utf-16", "replace")
    if len(data) > 3 and data[1:2] == b"\x00" and data[3:4] == b"\x00":
        return data.decode("utf-16-le", "replace")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("cp1252", "replace")


def sheets_of(data, ftype, csv_name="Sheet1"):
    """[(sheet name, hidden, row iterator)], the rows as lists of cell values."""
    if ftype == "xlsx":
        import openpyxl
        _check_xlsx(data)
        try:
            wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        except Exception as e:  # noqa: BLE001 - a damaged workbook
            raise RemError(f"The workbook could not be opened: {type(e).__name__}: {str(e)[:200]}")
        return [(ws.title, getattr(ws, "sheet_state", "visible") != "visible", ws.iter_rows(values_only=True))
                for ws in wb.worksheets]
    body = _decode(data)
    first = body.split("\n", 1)[0]
    delim = max([",", ";", "\t", "|"], key=first.count)
    csv.field_size_limit(10 * 1024 * 1024)
    return [(csv_name, False, csv.reader(io.StringIO(body, newline=""), delimiter=delim))]


def _cells(row):
    row = list(row or ())
    while row and (row[-1] is None or text(row[-1]) == ""):
        row.pop()
    return row[:MAX_COLS]


def _header_score(row):
    """(known fields matched, whether it has a finding's identity) for a candidate heading row."""
    fields = set()
    for v in row:
        f, _h, _w = rule_field(v)
        if f:
            fields.add(f)
    ident = ("plugin_id" in fields or "uuid" in fields) and bool(fields & {"ip", "hostname", "uuid"})
    return len(fields), ident


def scan_sheet(name, hidden, rows):
    """One pass over a sheet: heading, samples, row count, per-column distinct values and date order."""
    head, head_rn, pre = None, None, []
    best = (0, False, None, None)
    for rn, row in enumerate(rows, start=1):
        cells = _cells(row)
        if rn <= 30:
            pre.append((rn, cells))
            n, ident = _header_score(cells)
            if ident and n > best[0]:
                best = (n, ident, rn, cells)
            if rn < 30:
                continue
        break
    else:
        rn = None
    findings = best[2] is not None and best[0] >= 3
    if findings:
        head_rn, head = best[2], best[3]
    else:                                              # not a findings sheet (a summary): its first non-empty row
        for r0, cells in pre:
            if any(text(c) for c in cells):
                head_rn, head = r0, cells
                break
    info = {"name": name, "hidden": hidden, "findings": findings, "header_row": head_rn,
            "headers": [text(h) for h in (head or [])], "rows": 0, "samples": [],
            "distinct": [], "date_order": [], "too_many_rows": False, "too_many_cols": False}
    if head is None:
        return info
    ncol = len(head)
    distinct = [dict() for _ in range(ncol)]
    over = [False] * ncol
    orders = [set() for _ in range(ncol)]

    def take(cells):
        if not any(text(c) for c in cells):
            return
        info["rows"] += 1
        if len(cells) > ncol and any(text(c) for c in cells[ncol:]):
            info["too_many_cols"] = True
        if len(info["samples"]) < 5:
            info["samples"].append([text(c)[:160] for c in cells[:ncol]] + [""] * (ncol - min(len(cells), ncol)))
        for i in range(min(ncol, len(cells))):
            v = cells[i]
            t = text(v)
            if not t:
                continue
            o = slash_order(v)
            if o:
                orders[i].add(o)
            if not over[i]:
                k = t[:80]
                d = distinct[i]
                if k in d:
                    d[k] += 1
                elif len(d) < MAX_DISTINCT:
                    d[k] = 1
                else:
                    over[i] = True

    for r0, cells in pre:
        if r0 > head_rn:
            take(cells)
    if rn is not None:                                  # the 30 rows were not the end: read on
        for row in rows:
            take(_cells(row))
            if info["rows"] > MAX_ROWS:
                info["too_many_rows"] = True
                break
    info["distinct"] = [{"values": sorted(d.items(), key=lambda x: -x[1])[:MAX_DISTINCT], "more": over[i]}
                        for i, d in enumerate(distinct)]
    info["date_order"] = [("mixed" if {"dmy", "mdy"} <= o else "dmy" if "dmy" in o else "mdy" if "mdy" in o
                           else "either" if "either" in o else None) for o in orders]
    return info


# ---------------------------------------------------------------------------
# Column mapping
# ---------------------------------------------------------------------------

def place_columns(info, memory):
    """Fills info["map"]: per column {field, how, why}. A person's earlier choice for the heading first, then the rules.
    A field is given to one column only (the first that claims it); a second is left for the operator."""
    used, out = set(), []
    for i, h in enumerate(info["headers"]):
        n = norm(h)
        f, how, why = None, None, None
        if n and n in memory:
            f, how, why = memory[n], "saved", "chosen for this heading before"
            if f == "ignore":
                f, why = None, "chosen before: not used"
        if not how:
            f, how, why = rule_field(h)
        if f and f in used:
            f, why = None, f"{FIELD[f][0]} is already taken by an earlier column"
            how = "clash"
        if f:
            used.add(f)
        out.append({"field": f, "how": how, "why": why})
    info["map"] = out
    return info


def _shape_ok(field, values):
    """Whether sample values look like the field (AI-01's suggestions are checked against them)."""
    vals = [v for v in values if v][:12]
    if not vals:
        return True
    kind = FIELD[field][1]
    hit = 0
    for v in vals:
        if kind == "date":
            hit += bool(parse_date(v, "dmy") or slash_order(v))
        elif kind == "severity":
            hit += severity_of(v) is not None
        elif kind == "ip":
            hit += is_ip(v) or bool(re.fullmatch(r"[A-Za-z0-9.\-]+", v))
        elif kind == "port":
            hit += bool(re.fullmatch(r"\d{1,5}(/(tcp|udp))?", v.lower()))
        elif kind == "num":
            hit += bool(re.fullmatch(r"\d{1,2}(\.\d+)?", v))
        else:
            hit += 1
    return hit * 2 >= len(vals)


AI_SYSTEM = ("You read the column headings of a Nessus vulnerability scan workbook that a security team keeps, with a "
             "few sample values of each column, and say which field each column holds. Choose only from the fields "
             "given; answer \"none\" when no field fits or you are not sure. Base each answer on the heading and the "
             "values together, and say why in a few words. Answer with JSON only.")


def ai_messages(cols):
    fields = [{"field": k, "means": FIELD[k][0]} for k in FIELD_KEYS]
    data = {"fields": fields, "columns": cols}
    return [{"role": "system", "content": AI_SYSTEM},
            {"role": "user", "content": json.dumps(data, ensure_ascii=False)}]


AI_SCHEMA = {"type": "object", "properties": {"columns": {"type": "array", "items": {
    "type": "object", "properties": {"col": {"type": "integer"}, "field": {"enum": FIELD_KEYS + ["none"]},
                                     "why": {"type": "string", "maxLength": 160}},
    "required": ["col", "field", "why"]}}}, "required": ["columns"]}
AI_BATCH = 12


def ai_place(info, ask):
    """AI-01 for the columns no rule or earlier choice placed. ask(messages, schema) -> JSON text. Each suggestion is
    checked: the field must exist, be free, and fit the sample values; else the column stays unplaced, with why.
    Returns how many were placed."""
    todo = [i for i, m in enumerate(info["map"]) if not m["field"] and m["how"] not in ("saved", "you") and info["headers"][i]]
    placed = 0
    used = {m["field"] for m in info["map"] if m["field"]}
    for s in range(0, len(todo), AI_BATCH):
        part = todo[s:s + AI_BATCH]
        cols = []
        for i in part:
            vals = [v for v, _n in (info["distinct"][i]["values"] if i < len(info["distinct"]) else [])][:3]
            cols.append({"col": i, "heading": info["headers"][i][:80], "values": [str(v)[:60] for v in vals]})
        raw = ask(ai_messages(cols), AI_SCHEMA)
        try:
            ans = json.loads(raw)["columns"]
        except (ValueError, KeyError, TypeError):
            raise RemError("AI-01 gave an answer that is not the expected JSON. Place these columns yourself, or ask again.")
        for a in ans if isinstance(ans, list) else []:
            try:
                i, f, why = int(a.get("col")), a.get("field"), str(a.get("why") or "")[:160]
            except (TypeError, ValueError, AttributeError):
                continue
            if i not in part or info["map"][i]["field"]:
                continue
            m = info["map"][i]
            if f == "none" or f not in FIELD:
                m.update(how="ai", why="AI-01: no field fits" + (" (" + why + ")" if why else ""))
                continue
            vals = [v for v, _n in info["distinct"][i]["values"]]
            if f in used:
                m.update(how="ai", why=f"AI-01 said {FIELD[f][0]}, but another column already holds it")
            elif not _shape_ok(f, vals):
                m.update(how="ai", why=f"AI-01 said {FIELD[f][0]}, but the values do not look like it")
            else:
                m.update(field=f, how="ai", why="AI-01: " + (why or FIELD[f][0]))
                used.add(f)
                placed += 1
    return placed


def status_column(info):
    for i, m in enumerate(info.get("map") or []):
        if m["field"] == "status":
            return i
    return None


def status_words_found(info, words):
    """The status column's words: [{word, count, status (known or None), how}]."""
    i = status_column(info)
    if i is None or i >= len(info["distinct"]):
        return []
    out = []
    for v, n in info["distinct"][i]["values"]:
        w = norm_word(v)
        st, how = (words.get(w), "saved") if w in words else (STATUS_WORDS.get(w), "rule") if w in STATUS_WORDS else (None, None)
        out.append({"word": v, "norm": w, "count": n, "status": st, "how": how})
    return out


def check_sheet(info, words, given_words=None, date_order=None):
    """What stops this sheet from being imported, as sentences (empty: it can be)."""
    problems = []
    fields = [m["field"] for m in info["map"] if m["field"]]
    dup = sorted({f for f in fields if fields.count(f) > 1})
    for f in dup:
        problems.append(f"Two columns are set to {FIELD[f][0]}: choose one.")
    have = set(fields)
    if "severity" not in have:
        problems.append("No column is set to Severity.")
    if not have & {"plugin_id", "uuid"}:
        problems.append("No column is set to Plugin (or UUID).")
    if not have & {"ip", "hostname", "uuid"}:
        problems.append("No column is set to IP address or Hostname (or UUID).")
    if not quarter_of(info.get("quarter") or ""):
        problems.append("Say which quarter this sheet is (for example 2026 Q3).")
    allw = dict(words)
    allw.update({norm_word(k): v for k, v in (given_words or {}).items() if v in STATUS})
    unknown = [w["word"] for w in status_words_found(info, allw) if not w["status"] and w["norm"] not in STATUS_WORDS]
    if unknown:
        problems.append("Say what these status words mean: " + ", ".join(repr(w) for w in unknown[:12]) + ".")
    i = status_column(info)
    if i is not None and i < len(info["distinct"]) and info["distinct"][i]["more"]:
        problems.append(f"The status column has more than {MAX_DISTINCT} different values: is it really the status?")
    for j, m in enumerate(info["map"]):
        if m["field"] in DATE_FIELDS and j < len(info["date_order"]):
            o = info["date_order"][j]
            if o in ("either", "mixed") and date_order not in ("dmy", "mdy"):
                problems.append("Some dates could be day/month or month/day (for example 03/04/2026): say which.")
                break
    return problems


# ---------------------------------------------------------------------------
# Rows -> findings
# ---------------------------------------------------------------------------

def row_values(cells, mapping, order, headers):
    """One sheet row as {field: value} plus the file's other columns and the dates that were not dates."""
    out, extra, raw = {}, {}, {}
    for i, m in enumerate(mapping):
        v = cells[i] if i < len(cells) else None
        f = m.get("field")
        if not f:
            t = text(v)
            if t and i < len(headers) and headers[i]:
                extra[headers[i][:120]] = t[:EXCEL_CELL_MAX]
            continue
        kind = FIELD[f][1]
        if kind == "date":
            d = parse_date(v, order)
            out[f] = d
            if d is None and text(v):
                raw[f] = text(v)[:200]
        elif kind == "long":
            out[f] = text(v)[:200_000]
        else:
            out[f] = text(v)[:2000]
    if raw:
        extra["_raw"] = raw
    return out, extra


def finding_of(vals, words):
    """The finding's columns from one row's values, or (None, why) when the row has no plugin or host."""
    v = dict(vals)
    uid = v.get("uuid") or ""
    if uid and "|" in uid:
        parts = [p.strip() for p in uid.split("|")]
        if not v.get("plugin_id") and parts[0]:
            v["plugin_id"] = parts[0]
        if not v.get("ip") and not v.get("hostname") and len(parts) > 1 and parts[1]:
            v["ip"] = parts[1]
    ip, host = (v.get("ip") or "").strip(), (v.get("hostname") or "").strip()
    if ip and not is_ip(ip) and not host:                 # Nessus's "Host" is a name when scanned by name
        host, ip = ip, ""
    plugin = (v.get("plugin_id") or "").strip()
    if not plugin or not (ip or host):
        return None, "no plugin" if not plugin else "no IP address or host name"
    port, proto = (v.get("port") or "").strip(), (v.get("protocol") or "").strip()
    m = re.fullmatch(r"(\d{1,5})\s*/\s*(tcp|udp|icmp)", port.lower())
    if m and not proto:
        port, proto = m.group(1), m.group(2)
    hk = short_name(host) if host else (ip.lower() if ip else "")
    if not hk:
        hk = (host or ip).lower()[:200]
    sev_text = (v.get("severity") or "").strip()
    st_text = (v.get("status") or "").strip()
    w = norm_word(st_text)
    status = (words.get(w) or STATUS_WORDS.get(w)) if st_text else None
    er_code, er_title = split_cat2(v.get("cat2"))
    f = {
        "fkey": "|".join([plugin, ip or host, port, proto]).lower()[:600],
        "host_key": hk[:255], "uuid_text": uid or None, "plugin_id": plugin, "plugin_name": v.get("plugin_name") or None,
        "severity": severity_of(sev_text), "severity_text": sev_text or None, "ip": ip or None, "hostname": host or None,
        "env": v.get("env") or None, "pic": v.get("pic") or None, "port": port or None, "protocol": proto or None,
        "plugin_output": v.get("plugin_output") or None, "synopsis": v.get("synopsis") or None,
        "description": v.get("description") or None, "solution": v.get("solution") or None, "cve": v.get("cve") or None,
        "cvss3": v.get("cvss3") or None, "cvss2": v.get("cvss2") or None,
        "prev_finding": v.get("prev_finding") or None, "prev_fixed": v.get("prev_fixed") or None,
        "exception": v.get("exception") or None, "status": status, "status_text": st_text or None,
        "overdue_text": v.get("overdue") or None, "cat1": v.get("cat1") or None, "cat2": v.get("cat2") or None,
        "er_code": er_code, "er_title": er_title,
    }
    for k in DATE_FIELDS:
        f[k] = v.get(k)
    return f, None


# ---------------------------------------------------------------------------
# Database helpers (the same code runs on psycopg and on the tests' psql shim)
# ---------------------------------------------------------------------------

def _iso(v):
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.isoformat()
    if isinstance(v, date):
        return v.isoformat()
    return str(v)


def _day(v):
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    return date.fromisoformat(str(v)[:10])


def _bytes(v):
    if v is None:
        return None
    if isinstance(v, memoryview):
        return v.tobytes()
    if isinstance(v, (bytes, bytearray)):
        return bytes(v)
    s = str(v)
    return bytes.fromhex(s[2:]) if s.startswith("\\x") else s.encode()


def _json(v):
    if v is None or isinstance(v, (dict, list)):
        return v
    return json.loads(v)


def _words(conn):
    return {r["word_norm"]: r["status"] for r in conn.execute("SELECT word_norm, status FROM rem_status_words").fetchall()}


def _memory(conn):
    return {r["header_norm"]: r["field"] for r in conn.execute("SELECT header_norm, field FROM rem_header_memory").fetchall()}


UPLOAD_COLS = ("id, file_name, size_bytes, file_type, state, sheets, progress, options, result, error, created_by, created_at, "
               "updated_at, imported_by, imported_at, (data IS NOT NULL) AS kept")


def _upload(conn, uid, data=False):
    """One upload; its file (up to 60 MB) only when the reading or the import needs it, never for a progress poll."""
    r = conn.execute("SELECT " + UPLOAD_COLS + (", data" if data else "") + " FROM rem_uploads WHERE id = %s", (uid,)).fetchone()
    if not r:
        raise NotFound("No such upload.")
    return dict(r)


def _beat(conn, uid, phase, done, total):
    conn.execute("UPDATE rem_uploads SET progress = %s::jsonb, updated_at = now() WHERE id = %s",
                 (json.dumps({"phase": phase, "done": done, "total": total}), uid))
    conn.commit()


# ---------------------------------------------------------------------------
# Upload lifecycle
# ---------------------------------------------------------------------------

def start_upload(conn, user, name, data, gz=False):
    """Stores the file and returns its id; the reading runs next (read_upload), in the background."""
    name = re.sub(r"[\x00-\x1f\\/]+", " ", (name or "scan.xlsx")).strip()[:200] or "scan.xlsx"
    ftype = file_type_of(name[:-3] if name.lower().endswith(".gz") else name)
    if not data:
        raise RemError("The file is empty.")
    data = unpack(data, gz or name.lower().endswith(".gz"))
    if ftype == "xlsx":
        _check_xlsx(data)
    # uploads left unconfirmed for a week, and failed ones: their files are let go
    conn.execute("""UPDATE rem_uploads SET data = NULL, state = 'discarded'
                     WHERE state IN ('review', 'failed') AND created_at < now() - interval '7 days'""")
    r = conn.execute("""INSERT INTO rem_uploads (file_name, size_bytes, file_type, data, state, created_by, progress)
                        VALUES (%s, %s, %s, %s, 'reading', %s, %s::jsonb) RETURNING id""",
                     (name, len(data), ftype, data, user, json.dumps({"phase": "reading", "done": 0, "total": 0}))).fetchone()
    conn.commit()
    return str(r["id"])


def read_upload(conn, uid):
    """Reading: every sheet once. Ends in 'review' (or 'failed' with the reason)."""
    u = _upload(conn, uid, data=True)
    if u["state"] != "reading":
        return
    try:
        data = _bytes(u["data"])
        if data is None:
            raise RemError("The file is no longer kept: upload it again.")
        memory, words = _memory(conn), _words(conn)
        base = re.sub(r"\.(csv|txt)(\.gz)?$", "", u["file_name"], flags=re.I)
        sheets = []
        found = sheets_of(data, u["file_type"], csv_name=base[:31] or "Sheet1")
        for n, (name, hidden, rows) in enumerate(found, start=1):
            _beat(conn, uid, "reading", n - 1, len(found))
            info = scan_sheet(name, hidden, rows)
            place_columns(info, memory)
            info["quarter"] = quarter_of(name) or ""
            info["quarter_from"] = "sheet name" if info["quarter"] else None
            info["use"] = bool(info["findings"]) and not hidden
            info["words"] = status_words_found(info, words)
            sheets.append(info)
        if not any(s["findings"] for s in sheets):
            note = ("No sheet has the columns of a scan (a Plugin or UUID column, and an IP address or Hostname "
                    "column). Check the file, or set its columns yourself below.")
        else:
            note = None
        conn.execute("""UPDATE rem_uploads SET sheets = %s::jsonb, state = 'review', error = %s, updated_at = now(),
                               progress = %s::jsonb WHERE id = %s AND state = 'reading'""",
                     (json.dumps(sheets, default=str), note, json.dumps({"phase": "read", "done": len(found), "total": len(found)}), uid))
        conn.commit()
    except Exception as e:  # noqa: BLE001 - every failure ends the reading with its reason
        conn.rollback()
        msg = str(e) if isinstance(e, RemError) else f"The file could not be read: {type(e).__name__}: {str(e)[:300]}"
        conn.execute("UPDATE rem_uploads SET state = 'failed', error = %s, updated_at = now() WHERE id = %s", (msg, uid))
        conn.commit()


def suggest(conn, uid, ask):
    """AI-01 for the columns still unplaced, in every sheet. Returns how many it placed."""
    u = _upload(conn, uid)
    if u["state"] != "review":
        raise RemError("This upload is not waiting for its columns to be confirmed.")
    sheets = _json(u["sheets"]) or []
    placed = 0
    for info in sheets:
        if info.get("headers"):
            placed += ai_place(info, ask)
            info["words"] = status_words_found(info, _words(conn))
    conn.execute("UPDATE rem_uploads SET sheets = %s::jsonb, updated_at = now() WHERE id = %s",
                 (json.dumps(sheets, default=str), uid))
    conn.commit()
    return placed


def confirm(conn, uid, user, body):
    """The operator's confirmation: per sheet use, quarter and columns; status words; day/month order.
    Checks everything, remembers the choices, and sets the upload to 'importing'. Raises RemError with every problem."""
    u = _upload(conn, uid)
    if u["state"] != "review":
        raise RemError("This upload is not waiting for its columns to be confirmed.")
    sheets = _json(u["sheets"]) or []
    by_name = {s["name"]: s for s in sheets}
    given = {s.get("name"): s for s in body.get("sheets") or []}
    words_given = {norm_word(k): v for k, v in (body.get("status_words") or {}).items()}
    bad = [v for v in words_given.values() if v not in STATUS]
    if bad:
        raise RemError("Unknown status: " + ", ".join(map(str, bad[:5])))
    order = body.get("date_order") or None
    if order not in (None, "dmy", "mdy"):
        raise RemError("Day/month order is dmy or mdy.")
    words = _words(conn)
    problems, used_quarters = [], {}
    for name, g in given.items():
        if name not in by_name:
            raise RemError(f"The file has no sheet named {name!r}.")
    for info in sheets:
        g = given.get(info["name"])
        if g is None:
            info["use"] = False
            continue
        info["use"] = bool(g.get("use"))
        if not info["use"]:
            continue
        q = quarter_of(g.get("quarter") or info.get("quarter") or "")
        info["quarter"] = q or (g.get("quarter") or "")
        cols = g.get("columns")
        if cols is not None:
            if len(cols) != len(info["headers"]):
                raise RemError(f"Sheet {info['name']}: the columns sent do not match the file's.")
            for i, f in enumerate(cols):
                f = f or None
                if f is not None and f not in FIELD:
                    raise RemError(f"Sheet {info['name']}: unknown field {f!r}.")
                m = info["map"][i]
                if f != m["field"]:
                    m.update(field=f, how="you", why="chosen by " + user)
        p = check_sheet(info, words, words_given, order)
        problems += [f"Sheet {info['name']}: {x}" for x in p]
        if q:
            used_quarters.setdefault(q, []).append(info["name"])
    if not any(s.get("use") for s in sheets):
        problems.append("Choose at least one sheet to import.")
    if problems:
        raise RemError(" ".join(problems))
    # remembered for every later file: the headings a person (or AI-01, confirmed) placed, and the status words
    for info in sheets:
        if not info.get("use"):
            continue
        for h, m in zip(info["headers"], info["map"]):
            n = norm(h)
            if not n:
                continue
            # a person's choice (a column left out too), and AI-01's and the close spellings once confirmed
            if m["how"] == "you" or (m["how"] in ("ai", "close") and m["field"]):
                conn.execute("""INSERT INTO rem_header_memory (header_norm, field, set_by) VALUES (%s, %s, %s)
                                ON CONFLICT (header_norm) DO UPDATE SET field = EXCLUDED.field, set_by = EXCLUDED.set_by,
                                                                        set_at = now()""",
                             (n, m["field"] or "ignore", user))
    for w, st in words_given.items():
        if STATUS_WORDS.get(w) != st:
            conn.execute("""INSERT INTO rem_status_words (word_norm, status, set_by) VALUES (%s, %s, %s)
                            ON CONFLICT (word_norm) DO UPDATE SET status = EXCLUDED.status, set_by = EXCLUDED.set_by,
                                                                  set_at = now()""", (w, st, user))
    opts = {"remove_missing": bool(body.get("remove_missing")), "date_order": order}
    conn.execute("""UPDATE rem_uploads SET sheets = %s::jsonb, options = %s::jsonb, state = 'importing', error = NULL,
                           imported_by = %s, updated_at = now(), progress = %s::jsonb WHERE id = %s AND state = 'review'""",
                 (json.dumps(sheets, default=str), json.dumps(opts), user,
                  json.dumps({"phase": "importing", "done": 0, "total": sum(s["rows"] for s in sheets if s.get("use"))}), uid))
    conn.commit()
    return sorted(used_quarters)


def discard(conn, uid):
    u = _upload(conn, uid)
    if u["state"] in ("imported", "discarded"):
        raise RemError("This upload is already " + u["state"] + ".")
    if u["state"] in ("reading", "importing") and not stalled(u):
        raise RemError("This upload is being " + ("read" if u["state"] == "reading" else "imported") + ": wait for it to finish.")
    conn.execute("UPDATE rem_uploads SET state = 'discarded', data = NULL, updated_at = now() WHERE id = %s", (uid,))
    conn.commit()


def stalled(u):
    if u["state"] not in ("reading", "importing"):
        return False
    t = u["updated_at"]
    if isinstance(t, str):
        t = datetime.fromisoformat(t)
    return (datetime.now(timezone.utc) - t).total_seconds() > STALL_S


def retry(conn, uid):
    """A reading or import that stopped (the API restarted) is started again from the start."""
    u = _upload(conn, uid)
    if not (stalled(u) or u["state"] == "failed"):
        raise RemError("This upload has not stopped.")
    if not u["kept"]:
        raise RemError("The file is no longer kept: upload it again.")
    state = "importing" if u.get("options") else "reading"          # confirmed: import again; else read again
    conn.execute("UPDATE rem_uploads SET state = %s, error = NULL, updated_at = now() WHERE id = %s", (state, uid))
    conn.commit()
    return state


def upload_view(conn, uid):
    u = _upload(conn, uid)
    sheets = _json(u["sheets"]) or []
    words = _words(conn)
    for s in sheets:
        if s.get("map") is not None:
            s["words"] = status_words_found(s, words)
            s["problems"] = check_sheet(s, words, None, (_json(u.get("options")) or {}).get("date_order")) if s.get("use") else []
            s["ambiguous_dates"] = any(m["field"] in DATE_FIELDS and j < len(s["date_order"]) and s["date_order"][j] in ("either", "mixed")
                                       for j, m in enumerate(s["map"]))
            s.pop("distinct", None)
    return {"id": str(u["id"]), "file_name": u["file_name"], "size_bytes": u["size_bytes"], "file_type": u["file_type"],
            "state": u["state"], "stalled": stalled(u), "sheets": sheets, "progress": _json(u["progress"]),
            "options": _json(u["options"]), "result": _json(u["result"]), "error": u["error"],
            "created_by": u["created_by"], "created_at": _iso(u["created_at"]), "imported_by": u["imported_by"],
            "imported_at": _iso(u["imported_at"]), "fields": [{"key": k, "label": l} for k, l, _k in FIELDS],
            "statuses": [{"key": k, "label": l} for k, l in STATUSES], "kept": bool(u["kept"])}


def uploads(conn, limit=20):
    rows = conn.execute("""SELECT id, file_name, size_bytes, state, created_by, created_at, imported_by, imported_at, result,
                                  error, updated_at
                             FROM rem_uploads WHERE state <> 'discarded' ORDER BY created_at DESC LIMIT %s""", (limit,)).fetchall()
    return [dict(r, id=str(r["id"]), result=_json(r["result"]), stalled=stalled(r), created_at=_iso(r["created_at"]),
                 imported_at=_iso(r["imported_at"]), updated_at=_iso(r["updated_at"])) for r in rows]


# ---------------------------------------------------------------------------
# Import
# ---------------------------------------------------------------------------

COLS = ["fkey", "host_key", "uuid_text", "plugin_id", "plugin_name", "severity", "severity_text", "ip", "hostname", "env",
        "pic", "port", "protocol", "plugin_output", "synopsis", "description", "solution", "cve", "cvss3", "cvss2",
        "prev_finding", "prev_fixed", "exception", "status", "status_text", "overdue_text", "report_shared",
        "completed_on", "target_on", "first_seen", "last_seen", "vuln_pub", "plugin_pub", "cat1", "cat2", "er_code",
        "er_title"]
BATCH = 1000


def _prev_quarter(conn, quarter):
    r = conn.execute("SELECT max(quarter) AS q FROM rem_findings WHERE quarter < %s", (quarter,)).fetchone()
    return r["q"] if r else None


def run_import(conn, uid, inventory=None):
    """Importing: the file read again with the confirmed columns, merged quarter by quarter. Ends in 'imported'
    (or 'failed' with the reason). Safe to run again: it gives the same result."""
    u = _upload(conn, uid, data=True)
    if u["state"] != "importing":
        return
    who = "import: " + (u["imported_by"] or u["created_by"])
    # one import at a time (two files of the same quarter must not merge into each other)
    waited = 0
    while not conn.execute("SELECT pg_try_advisory_lock(%s) AS ok", (IMPORT_LOCK,)).fetchone()["ok"]:
        _beat(conn, uid, "waiting", 0, 0)
        time.sleep(3)
        waited += 3
        if waited > 1800:
            conn.execute("UPDATE rem_uploads SET state = 'failed', error = %s, updated_at = now() WHERE id = %s",
                         ("Another import ran for more than 30 minutes; this one did not start. Try again.", uid))
            conn.commit()
            return
    try:
        _import(conn, uid, u, who, inventory)
    finally:
        try:
            conn.execute("SELECT pg_advisory_unlock(%s)", (IMPORT_LOCK,)).fetchone()
            conn.commit()
        except Exception:  # noqa: BLE001 - a lost connection takes its lock with it
            pass


IMPORT_LOCK = 7_461_301


def _import(conn, uid, u, who, inventory):
    try:
        data = _bytes(u["data"])
        if data is None:
            raise RemError("The file is no longer kept: upload it again.")
        sheets = _json(u["sheets"]) or []
        opts = _json(u["options"]) or {}
        order = opts.get("date_order")
        words = _words(conn)
        base = re.sub(r"\.(csv|txt)(\.gz)?$", "", u["file_name"], flags=re.I)
        files = {name: rows for name, _h, rows in sheets_of(data, u["file_type"], csv_name=base[:31] or "Sheet1")}
        total = sum(s["rows"] for s in sheets if s.get("use"))
        done = 0
        per_q = {}
        for info in sorted([s for s in sheets if s.get("use")], key=lambda s: qkey(s["quarter"])):
            rows = files.get(info["name"])
            if rows is None:
                raise RemError(f"The sheet {info['name']} is no longer in the file.")
            q = info["quarter"]
            st = per_q.setdefault(q, {"sheets": [], "rows": 0, "new": 0, "updated": 0, "unchanged": 0, "carried": 0,
                                      "skipped": [], "duplicates": [], "no_severity": 0, "fkeys": set()})
            st["sheets"].append(info["name"])
            batch = []
            for rn, row in enumerate(rows, start=1):
                if rn <= info["header_row"]:
                    continue
                cells = _cells(row)
                if not any(text(c) for c in cells):
                    continue
                vals, extra = row_values(cells, info["map"], order, info["headers"])
                f, why = finding_of(vals, words)
                st["rows"] += 1
                done += 1
                if f is None:
                    if len(st["skipped"]) < 200:
                        st["skipped"].append({"sheet": info["name"], "row": rn, "why": why})
                    else:
                        st["skipped_more"] = st.get("skipped_more", 0) + 1
                    continue
                if f["fkey"] in st["fkeys"]:
                    if len(st["duplicates"]) < 200:
                        st["duplicates"].append({"sheet": info["name"], "row": rn, "key": f["fkey"]})
                    continue
                st["fkeys"].add(f["fkey"])
                if f["severity"] is None:
                    st["no_severity"] += 1
                f.update(sheet=info["name"], row_no=rn, extra=extra or None)
                batch.append(f)
                if len(batch) >= BATCH:
                    _merge(conn, uid, q, batch, st, who)
                    batch = []
                    _beat(conn, uid, "importing", done, total)
                if st["rows"] > MAX_ROWS:
                    raise RemError(f"The sheet {info['name']} has more than {MAX_ROWS:,} rows.")
            _merge(conn, uid, q, batch, st, who)
            _beat(conn, uid, "importing", done, total)
        removed = {}
        if opts.get("remove_missing"):
            for q, st in per_q.items():
                keep = list(st["fkeys"])
                if not keep:
                    continue
                n = conn.execute("""DELETE FROM rem_findings WHERE quarter = %s AND NOT (fkey = ANY(%s::text[]))
                                    RETURNING id""", (q, keep)).fetchall()
                removed[q] = len(n)
        missing = {}
        for q, st in per_q.items():
            r = conn.execute("SELECT count(*) AS n FROM rem_findings WHERE quarter = %s", (q,)).fetchone()
            missing[q] = max(0, int(r["n"]) - len(st["fkeys"]))
        conn.commit()
        hosts = sorted({hk for q in per_q for hk in _hosts_of(conn, q)})
        try:
            refresh_hosts(conn, hosts, inventory)
        except Exception as e:  # noqa: BLE001 - the findings are in; the device types can be checked again
            conn.rollback()
            for st in per_q.values():
                st["inventory_error"] = f"{type(e).__name__}: {str(e)[:200]}"
        result = {q: {("findings" if k == "fkeys" else k): (len(v) if k == "fkeys" else v) for k, v in st.items()}
                  for q, st in per_q.items()}
        for q in result:
            result[q]["removed"] = removed.get(q, 0)
            result[q]["not_in_file"] = 0 if opts.get("remove_missing") else missing.get(q, 0)
            result[q]["previous"] = _prev_quarter(conn, q)
        conn.execute("""UPDATE rem_uploads SET state = 'imported', result = %s::jsonb, data = NULL, imported_at = now(),
                               updated_at = now(), progress = %s::jsonb WHERE id = %s""",
                     (json.dumps(result, default=str), json.dumps({"phase": "imported", "done": done, "total": total}), uid))
        conn.commit()
    except Exception as e:  # noqa: BLE001
        conn.rollback()
        msg = str(e) if isinstance(e, RemError) else f"The import stopped: {type(e).__name__}: {str(e)[:300]}"
        conn.execute("UPDATE rem_uploads SET state = 'failed', error = %s, updated_at = now() WHERE id = %s", (msg, uid))
        conn.commit()


def _hosts_of(conn, q):
    return [r["host_key"] for r in conn.execute("SELECT DISTINCT host_key FROM rem_findings WHERE quarter = %s", (q,)).fetchall()]


def _merge(conn, uid, quarter, batch, st, who):
    """One batch into the quarter: new findings (with blanks taken from the previous quarter), and the ones already
    there (the file's values win; a blank keeps PATCH-01's; each change of a tracked field is kept in the history)."""
    if not batch:
        return
    keys = [f["fkey"] for f in batch]
    have = {r["fkey"]: dict(r) for r in conn.execute(
        "SELECT id, fkey, " + ", ".join(TRACKED) + " FROM rem_findings WHERE quarter = %s AND fkey = ANY(%s::text[])",
        (quarter, keys)).fetchall()}
    prevq = _prev_quarter(conn, quarter)
    prev = {}
    if prevq:
        prev = {r["fkey"]: dict(r) for r in conn.execute(
            "SELECT fkey, status_text, " + ", ".join(CARRY) + " FROM rem_findings WHERE quarter = %s AND fkey = ANY(%s::text[])",
            (prevq, keys)).fetchall()}
    for f in batch:
        old = have.get(f["fkey"])
        carried = []
        if old is None:
            p = prev.get(f["fkey"])
            if p:
                for k in CARRY:
                    if f.get(k) in (None, ""):
                        pv = p.get(k)
                        if k == "status":
                            pv = None if pv in (None, "fixed") else pv
                        if pv not in (None, ""):
                            f[k] = _day(pv) if k == "target_on" else pv
                            carried.append(k)
                            if k == "status":
                                f["status_text"] = p.get("status_text")        # the file's own word for it, too
                if "cat2" in carried:
                    f["er_code"], f["er_title"] = split_cat2(f["cat2"])
            if not f.get("status"):
                f["status"] = "open"
            vals = [_db_val(k, f.get(k)) for k in COLS]
            conn.execute("INSERT INTO rem_findings (quarter, upload_id, sheet, row_no, extra, carried, " + ", ".join(COLS)
                         + ") VALUES (%s, %s, %s, %s, %s::jsonb, %s::text[], " + ", ".join(["%s"] * len(COLS)) + ")",
                         [quarter, uid, f["sheet"], f["row_no"], json.dumps(f.get("extra")) if f.get("extra") else None,
                          carried] + vals)
            st["new"] += 1
            st["carried"] += bool(carried)
            continue
        changes = []
        for k in TRACKED:
            nv = f.get(k)
            if nv in (None, ""):
                f[k] = old.get(k)                                  # a blank in the file keeps PATCH-01's value
                if k in ("target_on", "completed_on", "report_shared"):
                    f[k] = _day(f[k])
                continue
            ov = old.get(k)
            if _iso(_day(ov) if k in ("target_on", "completed_on", "report_shared") else ov) != _iso(nv):
                changes.append((k, _iso(ov) if ov is not None else None, _iso(nv)))
        if f.get("cat2") and not f.get("er_code"):
            f["er_code"], f["er_title"] = split_cat2(f["cat2"])
        if not f.get("status"):
            f["status"] = old.get("status") or "open"
        sets = ", ".join(f"{k} = %s" for k in COLS if k != "fkey")
        conn.execute("UPDATE rem_findings SET upload_id = %s, sheet = %s, row_no = %s, extra = %s::jsonb, " + sets
                     + ", updated_at = now(), updated_by = %s WHERE id = %s",
                     [uid, f["sheet"], f["row_no"], json.dumps(f.get("extra")) if f.get("extra") else None]
                     + [_db_val(k, f.get(k)) for k in COLS if k != "fkey"] + [who, old["id"]])
        for k, ov, nv in changes:
            conn.execute("""INSERT INTO rem_history (finding_id, field, old_value, new_value, changed_by, source)
                            VALUES (%s, %s, %s, %s, %s, 'import')""", (old["id"], k, ov, nv, who))
        st["updated" if changes else "unchanged"] += 1


def _db_val(k, v):
    if k in DATE_FIELDS:
        return _day(v)
    return v


# ---------------------------------------------------------------------------
# Hosts: device type from the inventory, Application / Infra, team
# ---------------------------------------------------------------------------

def _inventory_assets(conn):
    from . import inventory
    return inventory.load_assets(conn)["assets"]


def refresh_hosts(conn, host_keys=None, assets=None):
    """Each host's device type as the inventory decides it (by name, else by IP). host_keys None: every host."""
    if host_keys is None:
        host_keys = [r["host_key"] for r in conn.execute("SELECT DISTINCT host_key FROM rem_findings").fetchall()]
    if not host_keys:
        return 0
    if assets is None:
        assets = _inventory_assets(conn)
    by_key, by_ip = {}, {}
    for a in assets:
        if a.get("status") == "decommissioned":
            continue
        by_key.setdefault((a.get("key") or "").lower(), a)
        for ip in a.get("ips") or []:
            by_ip.setdefault(str(ip), a)
    info = {}
    for r in conn.execute("""SELECT host_key, max(hostname) AS hostname, array_agg(DISTINCT ip) AS ips
                               FROM rem_findings WHERE host_key = ANY(%s::text[]) GROUP BY host_key""",
                          (list(host_keys),)).fetchall():
        info[r["host_key"]] = r
    n = 0
    for hk in host_keys:
        r = info.get(hk) or {"hostname": None, "ips": []}
        ips = [i for i in (r["ips"] or []) if i]
        a = by_key.get(hk) or next((by_ip[i] for i in ips if i in by_ip), None)
        conn.execute("""INSERT INTO rem_hosts (host_key, hostname, ips, inv_kind, inv_name, inv_reason, checked_at)
                        VALUES (%s, %s, %s::text[], %s, %s, %s, now())
                        ON CONFLICT (host_key) DO UPDATE SET hostname = EXCLUDED.hostname, ips = EXCLUDED.ips,
                               inv_kind = EXCLUDED.inv_kind, inv_name = EXCLUDED.inv_name, inv_reason = EXCLUDED.inv_reason,
                               checked_at = now()""",
                     (hk, r["hostname"], ips, a.get("category") if a else None, a.get("name") if a else None,
                      (a.get("category_reason") or "")[:200] if a else None))
        n += 1
    conn.commit()
    return n


def set_hosts(conn, user, keys, team_type=None, team=None, kind=None):
    """For each host: Application / Infra ('' clears), team ('' clears), device type ('' back to the inventory's).
    None leaves a value as it is."""
    if not keys:
        raise RemError("Choose at least one host.")
    if team_type not in (None, "", "application", "infra"):
        raise RemError("Application or Infra.")
    if kind not in (None, "", "server", "network", "appliance"):
        raise RemError("The device type is server, network or appliance.")
    if team is not None and len(team) > 120:
        raise RemError("A team name is at most 120 characters.")
    n = 0
    for k in keys:
        conn.execute("""INSERT INTO rem_hosts (host_key, team_type, team, kind, set_by, set_at)
                        VALUES (%s, %s, %s, %s, %s, now())
                        ON CONFLICT (host_key) DO UPDATE SET
                          team_type = CASE WHEN %s THEN EXCLUDED.team_type ELSE rem_hosts.team_type END,
                          team = CASE WHEN %s THEN EXCLUDED.team ELSE rem_hosts.team END,
                          kind = CASE WHEN %s THEN EXCLUDED.kind ELSE rem_hosts.kind END,
                          set_by = EXCLUDED.set_by, set_at = now()""",
                     (k, team_type or None, (team or "").strip() or None, kind or None, user,
                      team_type is not None, team is not None, kind is not None))
        n += 1
    conn.commit()
    return n


# ---------------------------------------------------------------------------
# Reading the findings: filters, summary, groups, list, one finding
# ---------------------------------------------------------------------------

KIND_SQL = """coalesce(h.kind, CASE h.inv_kind WHEN 'server' THEN 'server' WHEN 'client' THEN 'server' WHEN 'esxi' THEN 'server'
                                    WHEN 'network' THEN 'network' WHEN 'firewall' THEN 'network'
                                    WHEN 'appliance' THEN 'appliance' WHEN 'unknown' THEN 'unknown'
                                    ELSE 'not_in_inventory' END)"""
OPEN_SQL = "f.status IN ('open', 'pending_review', 'pending_deviation')"
ACTION_SQL = "f.status NOT IN ('fixed', 'decommission')"
# Due: the finding's own New Target Completion Date, else the target date (rem_targets: the quarter's, else 'default').
# Overdue: still outstanding (anything but Fixed / Decommission) after it; with no date at all, the file's Overdue?.
DUE_SQL = "coalesce(f.target_on, %(due)s::date)"
OVERDUE_SQL = f"""(CASE WHEN NOT ({ACTION_SQL}) THEN false
                       WHEN {DUE_SQL} IS NOT NULL THEN {DUE_SQL} < current_date
                       ELSE lower(trim(coalesce(f.overdue_text, ''))) IN ('yes', 'y', 'true', 'overdue') END)"""
# The tally every section shows: outstanding (all but Fixed / Decommission) by severity, outstanding, fixed, decom,
# all, overdue, open, hosts. s4..s0 are outstanding Critical..Info, sx outstanding without a severity.
TALLY_SQL = (f"""count(*) AS total, count(*) FILTER (WHERE f.status = 'fixed') AS fixed,
                 count(*) FILTER (WHERE f.status = 'decommission') AS decom,
                 count(*) FILTER (WHERE {ACTION_SQL}) AS outstanding, count(*) FILTER (WHERE {OPEN_SQL}) AS open,
                 count(*) FILTER (WHERE {OVERDUE_SQL}) AS overdue, count(DISTINCT f.host_key) AS hosts, """
             + ", ".join(f"count(*) FILTER (WHERE {ACTION_SQL} AND coalesce(f.severity, -1) = {n}) AS s{n if n >= 0 else 'x'}"
                         for n in (4, 3, 2, 1, 0, -1)))
TALLY_ORDER = "s4 DESC, s3 DESC, s2 DESC, s1 DESC, outstanding DESC, total DESC"
TALLY_INTS = ("total", "fixed", "decom", "outstanding", "open", "overdue", "hosts", "s4", "s3", "s2", "s1", "s0", "sx")


def pct(part, whole):
    """part of whole in %, one decimal, rounded half up - but never 0.0 while part > 0, never 100.0 while part < whole
    (so "0%" and "100%" are only ever exact). None when whole is 0."""
    from decimal import Decimal, ROUND_HALF_UP
    part, whole = int(part or 0), int(whole or 0)
    if not whole:
        return None
    v = float((Decimal(part) * 100 / Decimal(whole)).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP))
    if part and v == 0.0:
        return 0.1
    if part < whole and v == 100.0:
        return 99.9
    return v


def tally(r):
    """A row of TALLY_SQL with done (fixed + decommission) and the percentages."""
    r = dict(r)
    for k in TALLY_INTS:
        if k in r:
            r[k] = int(r[k] or 0)
    r["done"] = r.get("fixed", 0) + r.get("decom", 0)
    r["pct_outstanding"] = pct(r.get("outstanding"), r.get("total"))
    r["pct_done"] = pct(r["done"], r.get("total"))
    return r
FROM_SQL = """FROM rem_findings f
              LEFT JOIN rem_hosts h ON h.host_key = f.host_key
              LEFT JOIN rem_findings p ON p.quarter = %(prev)s AND p.fkey = f.fkey"""
GROUPS = {
    "host": ("f.host_key", "Host"), "severity": ("coalesce(f.severity, -1)::text", "Severity"),
    "status": ("f.status", "Status"), "pic": ("coalesce(f.pic, '')", "PIC"), "cat1": ("coalesce(f.cat1, '')", "Categorization1"),
    "cat2": ("coalesce(f.cat2, '')", "Categorization2"), "env": ("coalesce(f.env, '')", "UAT/Prod"),
    "kind": (KIND_SQL, "Device type"), "team": ("coalesce(h.team_type, '') || '|' || coalesce(h.team, '')", "Team"),
    "plugin": ("f.plugin_id", "Plugin"),
}


def quarters(conn):
    return [dict(r) for r in conn.execute(
        """SELECT quarter, count(*) AS findings, count(*) FILTER (WHERE status IN ('open', 'pending_review', 'pending_deviation')) AS open,
                  max(updated_at) AS updated_at
             FROM rem_findings GROUP BY quarter ORDER BY quarter DESC""").fetchall()]


def where(params):
    """SQL conditions and their values from the page's filters (every value checked here)."""
    q = (params.get("quarter") or "").strip()
    if not re.fullmatch(r"\d{4} Q[1-4]", q):
        raise RemError("Choose a quarter.")
    cond, val = ["f.quarter = %(quarter)s"], {"quarter": q}
    sev = [int(x) for x in re.findall(r"-?\d", params.get("sev") or "") if int(x) in (-1, 0, 1, 2, 3, 4)]
    if sev:
        cond.append("coalesce(f.severity, -1) = ANY(%(sev)s::int[])")
        val["sev"] = sev
    sts = [s for s in (params.get("status") or "").split(",") if s in STATUS]
    if sts:
        cond.append("f.status = ANY(%(status)s::text[])")
        val["status"] = sts
    elif params.get("open") in ("1", "true"):
        cond.append(OPEN_SQL)
    elif params.get("action") in ("1", "true"):                     # needs action: everything but Fixed / Decommission
        cond.append(ACTION_SQL)
    for k, col in (("pic", "f.pic"), ("cat1", "f.cat1"), ("cat2", "f.cat2"), ("env", "f.env")):
        v = params.get(k)
        if v is not None and v != "":
            if v == "\x00":                                         # "(blank)"
                cond.append(f"coalesce({col}, '') = ''")
            else:
                cond.append(f"{col} = %({k})s")
                val[k] = v[:300]
    kind = params.get("kind")
    if kind in KINDS:
        cond.append(f"{KIND_SQL} = %(kind)s")
        val["kind"] = kind
    tt = params.get("team_type")
    if tt in ("application", "infra"):
        cond.append("h.team_type = %(team_type)s")
        val["team_type"] = tt
    elif tt == "none":
        cond.append("h.team_type IS NULL")
    if params.get("host"):
        cond.append("f.host_key = %(host)s")
        val["host"] = params["host"][:255]
    # r141: several hosts, teams or PICs at once (the assistant; hosts also from the address, comma-separated)
    hs = params.get("hosts")
    if hs:
        hs = [x.strip()[:255] for x in (hs.split(",") if isinstance(hs, str) else hs) if str(x).strip()][:2000]
        if hs:
            cond.append("f.host_key = ANY(%(hosts)s::text[])")
            val["hosts"] = hs
    for k, expr in (("teams", GROUPS["team"][0]), ("pics", "coalesce(f.pic, '')")):
        vs = params.get(k)
        if isinstance(vs, (list, tuple)) and vs:
            cond.append(f"{expr} = ANY(%({k})s::text[])")
            val[k] = [str(x)[:400] for x in vs][:500]
    if params.get("overdue") in ("1", "true"):
        cond.append(OVERDUE_SQL)
    # r141: by its due date (its own New Target date, else the target date): passed, none, or set
    due = params.get("due")
    if due == "expired":                                            # still needing action, and its date has passed
        cond.append(f"({ACTION_SQL}) AND {DUE_SQL} < current_date")
    elif due == "none":
        cond.append(f"{DUE_SQL} IS NULL")
    elif due == "set":
        cond.append(f"{DUE_SQL} IS NOT NULL")
    # r141: one team by its name (the Hosts tab's Team), "(blank)" for none
    team = params.get("team")
    if team is not None and team != "":
        if team == "\x00":
            cond.append("coalesce(h.team, '') = ''")
        else:
            cond.append("h.team = %(team)s")
            val["team"] = team[:120]
    if params.get("came_back") in ("1", "true"):
        cond.append("p.status = 'fixed'")
    if params.get("new") in ("1", "true"):
        cond.append("p.id IS NULL")
    s = (params.get("q") or "").strip()
    if s:
        cond.append("""(f.hostname ILIKE %(q)s OR f.ip ILIKE %(q)s OR f.plugin_name ILIKE %(q)s OR f.plugin_id = %(qx)s
                        OR f.cve ILIKE %(q)s OR f.pic ILIKE %(q)s)""")
        val["q"] = "%" + s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")[:100] + "%"
        val["qx"] = s[:100]
    gb, gv = params.get("group_by"), params.get("group")
    if gb in GROUPS and gv is not None:
        cond.append(f"{GROUPS[gb][0]} = %(group)s")
        val["group"] = gv[:600]
    return " AND ".join(cond), val


def _with_prev(conn, val):
    val["prev"] = _prev_quarter(conn, val["quarter"])
    t = target_of(conn, val["quarter"])
    val["due"] = _iso(t["date"]) if t else None
    return val


def target_of(conn, quarter):
    """The quarter's target date: its own, else the default; {date, from: 'quarter' | 'default', set_by, set_at} or None."""
    r = conn.execute("""SELECT quarter, target_on, set_by, set_at FROM rem_targets WHERE quarter IN (%s, 'default')
                         ORDER BY (quarter = 'default') LIMIT 1""", (quarter,)).fetchone()
    if not r:
        return None
    return {"date": _day(r["target_on"]), "from": "default" if r["quarter"] == "default" else "quarter",
            "set_by": r["set_by"], "set_at": _iso(r["set_at"])}


def set_target(conn, user, quarter, value):
    """quarter "2026 Q3" (its own date) or "default" (every quarter without one); value YYYY-MM-DD, or "" to remove
    a quarter's own date (it then uses the default)."""
    if quarter != "default" and not re.fullmatch(r"\d{4} Q[1-4]", quarter or ""):
        raise RemError("Choose a quarter.")
    value = (value or "").strip()
    if not value:
        if quarter == "default":
            raise RemError("The default target date cannot be removed: change it instead.")
        conn.execute("DELETE FROM rem_targets WHERE quarter = %s", (quarter,))
        conn.commit()
        return None
    try:
        d = date.fromisoformat(value)
    except ValueError:
        raise RemError("The target date as YYYY-MM-DD.")
    if not 2000 <= d.year <= 2099:
        raise RemError("The target date is not a real date.")
    conn.execute("""INSERT INTO rem_targets (quarter, target_on, set_by) VALUES (%s, %s, %s)
                    ON CONFLICT (quarter) DO UPDATE SET target_on = EXCLUDED.target_on, set_by = EXCLUDED.set_by, set_at = now()""",
                 (quarter, d, user))
    conn.commit()
    return d


def progress(conn, val, outstanding):
    """Days to the target date and the pace it needs: {date, from, days_left, per_week, per_day, today}."""
    t = target_of(conn, val["quarter"])
    today = _day(conn.execute("SELECT current_date AS d").fetchone()["d"])
    if not t:
        return {"date": None, "today": _iso(today)}
    days = (t["date"] - today).days
    import math
    return {"date": _iso(t["date"]), "from": t["from"], "set_by": t["set_by"], "today": _iso(today), "days_left": days,
            "per_week": math.ceil(outstanding * 7 / days) if days > 0 and outstanding else (0 if days > 0 else None),
            "per_day": math.ceil(outstanding / days) if days > 0 and outstanding else (0 if days > 0 else None)}


def summary(conn, params):
    w, val = where(params)
    _with_prev(conn, val)
    def base(cols):
        return f"SELECT {cols} {FROM_SQL} WHERE {w}"
    tot = tally(conn.execute(base(f"""{TALLY_SQL}, count(*) FILTER (WHERE p.status = 'fixed') AS came_back,
                                   count(*) FILTER (WHERE p.id IS NULL) AS new"""), val).fetchone())
    tot["action"] = tot["outstanding"]
    for k in ("came_back", "new"):
        tot[k] = int(tot[k] or 0)
    matrix = conn.execute(base("coalesce(f.severity, -1) AS severity, f.status, count(*) AS n")
                          + " GROUP BY 1, 2", val).fetchall()

    def by(expr):
        # every value (no cut-off), so a section always adds up to the totals
        return [tally(r) for r in conn.execute(base(f"{expr} AS k, {TALLY_SQL}") + f" GROUP BY 1 ORDER BY {TALLY_ORDER}, 1",
                                               val).fetchall()]
    gone = 0
    if val["prev"]:
        gone = conn.execute("""SELECT count(*) AS n FROM rem_findings p WHERE p.quarter = %(prev)s
                                 AND NOT EXISTS (SELECT 1 FROM rem_findings f WHERE f.quarter = %(quarter)s AND f.fkey = p.fkey)""",
                            val).fetchone()["n"]
    by_sev = {int(r["k"]): r for r in by("coalesce(f.severity, -1)")}
    return {"quarter": val["quarter"], "previous": val["prev"], "totals": tot, "gone_since_previous": int(gone),
            "target": progress(conn, val, tot["outstanding"]),
            "by_sev": [by_sev[n] for n in (4, 3, 2, 1, 0, -1) if n in by_sev],
            "matrix": [dict(r) for r in matrix], "by_pic": by("coalesce(f.pic, '')"), "by_cat1": by("coalesce(f.cat1, '')"),
            "by_cat2": by("coalesce(f.cat2, '')"), "by_env": by("coalesce(f.env, '')"), "by_kind": by(KIND_SQL),
            "by_team": by("coalesce(h.team_type, '')")}


def categories(conn, params):
    """Categorization2 -> Categorization1 -> severity: per pair, per Categorization2 and in all (one query, so the
    hosts are counted right at every level). Each level has the tally (TALLY_SQL: outstanding per severity, outstanding,
    fixed, decom, all, overdue, hosts, % outstanding). Blank categories are "" (shown as "(blank)")."""
    p2 = {k: v for k, v in params.items() if k not in ("cat1", "cat2", "group_by", "group")}
    w, val = where(p2)
    _with_prev(conn, val)
    rows = conn.execute(f"""SELECT coalesce(f.cat2, '') AS cat2, coalesce(f.cat1, '') AS cat1,
                                   GROUPING(coalesce(f.cat2, '')) AS g2, GROUPING(coalesce(f.cat1, '')) AS g1, {TALLY_SQL}
                              {FROM_SQL} WHERE {w}
                             GROUP BY GROUPING SETS ((coalesce(f.cat2, ''), coalesce(f.cat1, '')), (coalesce(f.cat2, '')), ())""",
                        val).fetchall()
    total, tops, kids = None, {}, {}
    for r in rows:
        r = tally(r)
        if r["g2"]:
            total = r
        elif r["g1"]:
            tops[r["cat2"]] = r
        else:
            kids.setdefault(r["cat2"], []).append(r)

    def rank(r):                                    # the worst outstanding first, then the most; blank last
        return (r["cat2" if "children" in r else "cat1"] == "", -r["s4"], -r["s3"], -r["s2"], -r["s1"], -r["outstanding"],
                -r["total"], r.get("cat2", "") if "children" in r else r["cat1"])
    tree = []
    for c2, top in tops.items():
        top["children"] = sorted(kids.get(c2, []), key=rank)
        top["er_code"], top["er_title"] = split_cat2(c2)
        tree.append(top)
    tree.sort(key=rank)
    for r in [total] + tree + [k for t in tree for k in t["children"]]:
        if r:
            for k in ("g1", "g2"):
                r.pop(k, None)
    return {"quarter": val["quarter"], "previous": val["prev"], "tree": tree,
            "total": total or tally({k: 0 for k in TALLY_INTS})}


def groups(conn, params, limit=300):
    gb = params.get("group_by") or "host"
    if gb not in GROUPS:
        raise RemError("Unknown grouping.")
    p2 = dict(params)
    p2.pop("group", None)
    w, val = where(p2)
    _with_prev(conn, val)
    expr = GROUPS[gb][0]
    rows = conn.execute(f"""SELECT {expr} AS k, {TALLY_SQL}, max(f.severity) AS worst,
                                   max(f.hostname) AS hostname, min(f.ip) AS ip, max(h.team_type) AS team_type,
                                   max(h.team) AS team, max({KIND_SQL}) AS kind
                              {FROM_SQL} WHERE {w}
                             GROUP BY 1 ORDER BY {TALLY_ORDER}, max(coalesce(f.severity, -1)) DESC, 1
                             LIMIT %(limit)s""", dict(val, limit=limit + 1)).fetchall()
    out = [tally(r) for r in rows[:limit]]
    total = tally(conn.execute(f"SELECT {TALLY_SQL} {FROM_SQL} WHERE {w}", val).fetchone())   # every group, shown or not
    for g in out:
        g["label"] = group_label(gb, g)
    return {"group_by": gb, "groups": out, "more": len(rows) > limit, "total": total}


# ---------------------------------------------------------------------------
# r141: Target dates: what is still to fix, grouped, with its due dates
# ---------------------------------------------------------------------------

TARGET_BY = ("team", "pic")
TARGET_STATUSES = OPEN_STATUSES             # Open, Pending review, Pending deviation approval (the others are left out)
TARGET_COLS = f"""count(*) AS findings, count(*) FILTER (WHERE {DUE_SQL} < current_date) AS expired,
                  count(*) FILTER (WHERE {DUE_SQL} IS NULL) AS no_date,
                  count(*) FILTER (WHERE f.target_on IS NULL AND {DUE_SQL} IS NOT NULL) AS from_target,
                  count(*) FILTER (WHERE coalesce(f.severity, -1) = 4) AS s4, count(*) FILTER (WHERE f.severity = 3) AS s3,
                  count(*) FILTER (WHERE f.severity = 2) AS s2, count(*) FILTER (WHERE coalesce(f.severity, -1) <= 1) AS s1,
                  min({DUE_SQL}) AS due_min, max({DUE_SQL}) AS due_max"""
TARGET_INTS = ("findings", "expired", "no_date", "from_target", "s4", "s3", "s2", "s1")


def target_params(params):
    """The view's filters, held to the statuses that still need a date (a narrower status choice is kept)."""
    p = {k: v for k, v in params.items() if k not in ("group_by", "group", "open", "action", "overdue")}
    sts = [x for x in (p.get("status") or "").split(",") if x in TARGET_STATUSES]
    p["status"] = ",".join(sts or TARGET_STATUSES)
    return p


def targets(conn, params, by="team", limit=500):
    """The findings still to fix (TARGET_STATUSES), grouped by team (Application / Infra and the team, as set on the
    Hosts tab) or by PIC, each host under its group: how many, by severity, how many have a passed due date
    (expired), how many have none, and the due dates themselves. Every count from the rows."""
    if by not in TARGET_BY:
        raise RemError("Group by team or PIC.")
    p = target_params(params)
    w, val = where(p)
    _with_prev(conn, val)
    gexpr = GROUPS["team"][0] if by == "team" else "coalesce(f.pic, '')"
    rows = conn.execute(f"""SELECT {gexpr} AS g, f.host_key, max(f.hostname) AS hostname, min(f.ip) AS ip,
                                   max(h.team_type) AS team_type, max(h.team) AS team, {TARGET_COLS}
                              {FROM_SQL} WHERE {w}
                             GROUP BY 1, 2""", val).fetchall()
    dates = conn.execute(f"""SELECT {gexpr} AS g, {DUE_SQL} AS d, count(*) AS n {FROM_SQL} WHERE {w}
                              GROUP BY 1, 2 ORDER BY 1, 2 NULLS LAST""", val).fetchall()
    total = conn.execute(f"SELECT {TARGET_COLS}, count(DISTINCT f.host_key) AS hosts, current_date AS today {FROM_SQL} WHERE {w}",
                         val).fetchone()
    groups_ = {}
    for r in rows:
        r = dict(r)
        for k in TARGET_INTS:
            r[k] = int(r[k] or 0)
        for k in ("due_min", "due_max"):
            r[k] = _iso(_day(r[k]))
        g = groups_.setdefault(r["g"], {"key": r["g"], "hosts": [], "dates": [],
                                        **{k: 0 for k in TARGET_INTS}, "due_min": None, "due_max": None})
        for k in TARGET_INTS:
            g[k] += r[k]
        for k, pick in (("due_min", min), ("due_max", max)):
            if r[k]:
                g[k] = pick(g[k], r[k]) if g[k] else r[k]
        g["hosts"].append({k: r[k] for k in ("host_key", "hostname", "ip", "team_type", "team", "due_min", "due_max",
                                             *TARGET_INTS)})
    for d in dates:
        if d["g"] in groups_:
            groups_[d["g"]]["dates"].append({"date": _iso(_day(d["d"])), "n": int(d["n"])})
    out = []
    for g in groups_.values():
        if by == "team":
            tt, _s, team = (g["key"] or "").partition("|")
            g.update(team_type=tt or None, team=team or None, label=group_label("team", {"k": g["key"]}))
        else:
            g.update(pic=g["key"] or None, label=g["key"] or "(blank)")
        g["hosts"].sort(key=lambda x: (-x["expired"], -x["s4"], -x["s3"], -x["findings"], (x["hostname"] or x["host_key"]).lower()))
        g["host_count"] = len(g["hosts"])
        out.append(g)
    out.sort(key=lambda g: (g["key"] in ("", "|"), -g["expired"], -g["s4"], -g["s3"], -g["findings"], g["label"].lower()))
    t = dict(total)
    for k in TARGET_INTS + ("hosts",):
        t[k] = int(t[k] or 0)
    for k in ("due_min", "due_max"):
        t[k] = _iso(_day(t[k]))
    return {"quarter": val["quarter"], "by": by, "statuses": p["status"].split(","), "groups": out[:limit],
            "more": len(out) > limit, "totals": t, "target": _iso(_day(val["due"])) if val["due"] else None,
            "today": _iso(_day(t.pop("today")))}


# ---------------------------------------------------------------------------
# r141: Reports: each team's (or PIC's) findings to fix, to its own addresses
# ---------------------------------------------------------------------------

EMAIL_OK = re.compile(r"^[A-Za-z0-9._%+'-]{1,64}@[A-Za-z0-9-]{1,63}(?:\.[A-Za-z0-9-]{1,63})+$")
MAX_RECIPIENTS = 20


def clean_emails(raw):
    """Addresses from a list or a text (commas, semicolons, spaces, lines), each checked; duplicates removed."""
    items = raw if isinstance(raw, list) else re.split(r"[,;\s]+", str(raw or ""))
    out, bad = [], []
    for a in items:
        a = str(a or "").strip().strip("<>")
        if not a:
            continue
        if not EMAIL_OK.match(a):
            bad.append(a[:80])
        elif a.lower() not in {x.lower() for x in out}:
            out.append(a)
    if bad:
        raise RemError("Not e-mail addresses: " + ", ".join(bad[:5]))
    if len(out) > MAX_RECIPIENTS:
        raise RemError(f"At most {MAX_RECIPIENTS} addresses.")
    return out


def recipients(conn, by):
    if by not in TARGET_BY:
        raise RemError("Group by team or PIC.")
    return {r["key"]: dict(r) for r in conn.execute(
        "SELECT key, emails, updated_by, updated_at, sent_at, sent_by, sent_rows, sent_error FROM rem_recipients WHERE by_kind = %s",
        (by,)).fetchall()}


def set_recipients(conn, user, by, key, emails):
    if by not in TARGET_BY:
        raise RemError("Group by team or PIC.")
    key = str(key or "")[:400]
    emails = clean_emails(emails)
    conn.execute("""INSERT INTO rem_recipients (by_kind, key, emails, updated_by, updated_at) VALUES (%s, %s, %s, %s, now())
                    ON CONFLICT (by_kind, key) DO UPDATE SET emails = EXCLUDED.emails, updated_by = EXCLUDED.updated_by,
                                                             updated_at = now()""", (by, key, emails, user))
    conn.commit()
    return emails


def group_params(by, key):
    """The filters of one group of the Target dates / Reports tabs."""
    if by == "pic":
        return {"pic": "\x00"} if key == "" else {"pic": key}
    return {"group_by": "team", "group": key}


def report_groups(conn, params, by):
    """The groups to report on (as Target dates, every finding to fix), each with its addresses and last sending."""
    d = targets(conn, {k: v for k, v in params.items() if k in ("quarter",)}, by)
    rec = recipients(conn, by)
    for g in d["groups"]:
        r = rec.get(g["key"]) or {}
        g["emails"] = list(r.get("emails") or [])
        for k in ("sent_at", "sent_by", "sent_rows", "sent_error"):
            g[k] = _iso(r.get(k)) if k == "sent_at" else r.get(k)
        g.pop("hosts", None)
    return d


def report_rows(conn, params, limit=25):
    """The findings of a report's mail body: the worst and the most overdue first."""
    w, val = where(params)
    _with_prev(conn, val)
    rows = conn.execute(f"""SELECT f.hostname, f.ip, f.severity, f.plugin_name, f.status, {DUE_SQL} AS due_on,
                                   ({DUE_SQL} < current_date) AS expired
                              {FROM_SQL} WHERE {w}
                             ORDER BY ({DUE_SQL} < current_date) DESC, coalesce(f.severity, -1) DESC, {DUE_SQL} NULLS LAST,
                                      f.hostname, f.plugin_id
                             LIMIT %(lim)s""", dict(val, lim=limit)).fetchall()
    return [dict(r, due_on=_iso(_day(r["due_on"]))) for r in rows]


def mark_shared(conn, user, params):
    """Report Shared Date set to today on the findings a report carried (each change kept, as an edit)."""
    today = conn.execute("SELECT current_date AS d").fetchone()["d"]
    return bulk_edit(conn, user, params=params, changes={"report_shared": _iso(_day(today))},
                     note="Report sent (Reports tab)")


def note_sent(conn, user, by, key, rows, error):
    conn.execute("""INSERT INTO rem_recipients (by_kind, key, sent_at, sent_by, sent_rows, sent_error) VALUES (%s, %s, now(), %s, %s, %s)
                    ON CONFLICT (by_kind, key) DO UPDATE SET sent_at = now(), sent_by = EXCLUDED.sent_by,
                                                             sent_rows = EXCLUDED.sent_rows, sent_error = EXCLUDED.sent_error""",
                 (by, key[:400], user, rows, (error or None) and str(error)[:300]))
    conn.commit()


def group_label(gb, g):
    k = g["k"]
    if gb == "host":
        return (g.get("hostname") or g.get("ip") or k) + (f" ({g['ip']})" if g.get("hostname") and g.get("ip") else "")
    if gb == "severity":
        return SEV.get(int(k), "Not given") if str(k).lstrip("-").isdigit() else k
    if gb == "status":
        return STATUS.get(k, k)
    if gb == "kind":
        return KINDS.get(k, k)
    if gb == "team":
        tt, _s, team = (k or "").partition("|")
        return ({"application": "Application", "infra": "Infra"}.get(tt, "Not set") + (" · " + team if team else ""))
    return k if k else "(blank)"


LIST_COLS = f"""f.id, f.severity, f.plugin_id, f.plugin_name, f.hostname, f.ip, f.host_key, f.port, f.protocol, f.env, f.pic,
                f.status, f.status_text, f.exception, f.target_on, f.completed_on, f.report_shared, f.cat1, f.cat2, f.er_code,
                left(f.cve, 200) AS cve, f.cvss3, f.carried, f.row_no, f.sheet,
                {OVERDUE_SQL} AS overdue, {DUE_SQL} AS due_on, (f.target_on IS NULL AND %(due)s::date IS NOT NULL) AS due_from_target,
                (p.id IS NOT NULL) AS in_previous, (p.status = 'fixed') AS came_back,
                p.status AS previous_status, {KIND_SQL} AS kind, h.team_type, h.team"""


def findings(conn, params, offset=0, limit=200):
    w, val = where(params)
    _with_prev(conn, val)
    limit = max(1, min(int(limit), 1000))
    offset = max(0, int(offset))
    rows = conn.execute(f"""SELECT {LIST_COLS} {FROM_SQL} WHERE {w}
                            ORDER BY coalesce(f.severity, -1) DESC, f.host_key, f.plugin_id, f.port, f.id
                            LIMIT %(limit)s OFFSET %(offset)s""", dict(val, limit=limit + 1, offset=offset)).fetchall()
    total = conn.execute(f"SELECT count(*) AS n {FROM_SQL} WHERE {w}", val).fetchone()["n"]
    return {"items": [_row_out(r) for r in rows[:limit]], "more": len(rows) > limit, "total": int(total),
            "offset": offset, "previous": val["prev"]}


def _row_out(r):
    r = dict(r)
    for k in ("target_on", "completed_on", "report_shared", "first_seen", "last_seen", "vuln_pub", "plugin_pub",
              "created_at", "updated_at", "due_on"):
        if k in r:
            r[k] = _iso(r[k])
    if r.get("previous_status") is None:
        r["came_back"] = False
    r["carried"] = list(r.get("carried") or [])
    return r


def finding(conn, fid):
    r = conn.execute("SELECT f.*, h.team_type, h.team, h.inv_kind, h.inv_name, h.inv_reason, h.kind AS kind_set, "
                     + KIND_SQL + " AS kind FROM rem_findings f LEFT JOIN rem_hosts h ON h.host_key = f.host_key WHERE f.id = %s",
                     (fid,)).fetchone()
    if not r:
        raise NotFound("No such finding.")
    out = _row_out(r)
    out["extra"] = _json(out.get("extra"))
    out.pop("upload_id", None)
    hist = conn.execute("""SELECT field, old_value, new_value, changed_by, changed_at, source, note FROM rem_history
                            WHERE finding_id = %s ORDER BY changed_at DESC, id DESC LIMIT 100""", (fid,)).fetchall()
    out["history"] = [dict(x, changed_at=_iso(x["changed_at"])) for x in hist]
    other = conn.execute("""SELECT id, quarter, status, pic, target_on, exception FROM rem_findings
                             WHERE fkey = %s AND id <> %s ORDER BY quarter DESC""", (r["fkey"], fid)).fetchall()
    out["other_quarters"] = [_row_out(x) for x in other]
    val = _with_prev(conn, {"quarter": r["quarter"]})
    d = conn.execute(f"SELECT {OVERDUE_SQL} AS o, {DUE_SQL} AS due_on FROM rem_findings f WHERE f.id = %(fid)s",
                     dict(val, fid=fid)).fetchone()
    out["overdue"], out["due_on"] = d["o"], _iso(_day(d["due_on"]))
    out["due_from_target"] = r["target_on"] is None and val["due"] is not None
    return out


# ---------------------------------------------------------------------------
# Changes
# ---------------------------------------------------------------------------

EDITABLE = {"status": 40, "pic": 120, "exception": 2000, "target_on": 10, "completed_on": 10, "report_shared": 10,
            "cat1": 300, "cat2": 300, "env": 40}


def bulk_edit(conn, user, ids=None, params=None, changes=None, note=None):
    """Sets fields on the chosen findings (ids, or every finding the filters show). Each change kept with who and when.
    Returns {"findings": n chosen, "changed": n changed}."""
    changes = {k: v for k, v in (changes or {}).items() if k in EDITABLE}
    if not changes:
        raise RemError("Choose what to change.")
    clean = {}
    for k, v in changes.items():
        v = "" if v is None else str(v).strip()
        if len(v) > EDITABLE[k]:
            raise RemError(f"{FIELD[k][0]} is at most {EDITABLE[k]} characters.")
        if k == "status":
            if v not in STATUS:
                raise RemError("Unknown status.")
        elif k in DATE_FIELDS and v:
            try:
                date.fromisoformat(v)
            except ValueError:
                raise RemError(f"{FIELD[k][0]}: a date as YYYY-MM-DD.")
        clean[k] = v or None
    if note is not None and len(note) > 500:
        raise RemError("A note is at most 500 characters.")
    if ids is not None:
        ids = sorted({int(i) for i in ids})[:50000]
        if not ids:
            raise RemError("Choose at least one finding.")
        rows = conn.execute("SELECT id, " + ", ".join(clean) + " FROM rem_findings WHERE id = ANY(%s::bigint[])", (ids,)).fetchall()
    else:
        w, val = where(params or {})
        _with_prev(conn, val)
        rows = conn.execute("SELECT f.id, " + ", ".join("f." + k for k in clean) + f" {FROM_SQL} WHERE {w}", val).fetchall()
        if len(rows) > 50000:
            raise RemError("More than 50,000 findings: narrow the filters first.")
    changed = 0
    for r in rows:
        diff = []
        for k, nv in clean.items():
            ov = r.get(k)
            ovs = _iso(_day(ov)) if k in DATE_FIELDS else ov
            if (ovs or None) != (nv or None):
                diff.append((k, ovs, nv))
        if not diff:
            continue
        sets = ", ".join(f"{k} = %s" + ("::date" if k in DATE_FIELDS else "") for k, _o, _n in diff)
        vals = [n for _k, _o, n in diff]
        extra = ""
        if any(k == "cat2" for k, _o, _n in diff):
            code, title = split_cat2(clean["cat2"])
            extra = ", er_code = %s, er_title = %s"
            vals += [code, title]
        conn.execute(f"UPDATE rem_findings SET {sets}{extra}, updated_by = %s, updated_at = now() WHERE id = %s",
                     vals + [user, r["id"]])
        for k, ov, nv in diff:
            conn.execute("""INSERT INTO rem_history (finding_id, field, old_value, new_value, changed_by, source, note)
                            VALUES (%s, %s, %s, %s, %s, 'edit', %s)""", (r["id"], k, ov, nv, user, (note or None)))
        changed += 1
    conn.commit()
    return {"findings": len(rows), "changed": changed}


def hosts(conn, params):
    p2 = {k: v for k, v in params.items() if k in ("quarter", "q", "kind", "team_type")}
    w, val = where(p2)
    _with_prev(conn, val)
    rows = conn.execute(f"""SELECT f.host_key, max(f.hostname) AS hostname, array_agg(DISTINCT f.ip) AS ips, {TALLY_SQL},
                                   array_agg(DISTINCT f.pic) AS pics, array_agg(DISTINCT f.env) AS envs,
                                   max({KIND_SQL}) AS kind, max(h.kind) AS kind_set, max(h.inv_kind) AS inv_kind,
                                   max(h.inv_name) AS inv_name, max(h.inv_reason) AS inv_reason, max(h.team_type) AS team_type,
                                   max(h.team) AS team, max(h.set_by) AS set_by
                              {FROM_SQL} WHERE {w}
                             GROUP BY f.host_key ORDER BY {TALLY_ORDER}, f.host_key LIMIT 5000""", val).fetchall()
    out = []
    for r in rows:
        r = tally(r)
        for k in ("ips", "pics", "envs"):
            r[k] = sorted(x for x in (r.get(k) or []) if x)
        out.append(r)
    return {"quarter": val["quarter"], "hosts": out}


# ---------------------------------------------------------------------------
# Export: the quarter in the file's own columns and headings
# ---------------------------------------------------------------------------

def _headings(conn, quarter):
    """Field -> the heading the latest imported file used for it (else the template's), and that sheet's name."""
    heads, sheet = {}, None
    for u in conn.execute("""SELECT sheets FROM rem_uploads WHERE state = 'imported' ORDER BY imported_at DESC LIMIT 20""").fetchall():
        for s in _json(u["sheets"]) or []:
            if s.get("use") and s.get("quarter") == quarter:
                for h, m in zip(s.get("headers") or [], s.get("map") or []):
                    if m.get("field") and m["field"] not in heads:
                        heads[m["field"]] = h
                sheet = sheet or s.get("name")
        if heads:
            break
    return heads, sheet


def _cell_text(v):
    t = text(v)
    if len(t) > EXCEL_CELL_MAX:
        t = t[:EXCEL_CELL_MAX - 60] + " … (cut: an Excel cell holds at most 32,767 characters)"
    return t


EXPORT_PAGE = 2000


def export_rows(conn, params):
    """(rows, previous quarter, extra column names). The rows come in pages of EXPORT_PAGE, in the order they were
    imported, so a quarter of any size is written without holding it all in memory."""
    w, val = where(params)
    _with_prev(conn, val)
    extra = [r["k"] for r in conn.execute(f"""SELECT k FROM (SELECT k, min(f.id) AS first
                                                 FROM rem_findings f LEFT JOIN rem_hosts h ON h.host_key = f.host_key
                                                      LEFT JOIN rem_findings p ON p.quarter = %(prev)s AND p.fkey = f.fkey
                                                      CROSS JOIN LATERAL jsonb_object_keys(coalesce(f.extra, '{{}}'::jsonb)) k
                                                WHERE {w} GROUP BY k) x WHERE k <> '_raw' ORDER BY first, k""", val).fetchall()]

    def pages():
        after = 0
        while True:
            rows = conn.execute(f"""SELECT f.*, {OVERDUE_SQL} AS overdue_calc, (p.id IS NOT NULL) AS in_previous,
                                           (p.status = 'fixed') AS came_back, {KIND_SQL} AS kind, h.team_type, h.team
                                      {FROM_SQL} WHERE {w} AND f.id > %(after)s
                                     ORDER BY f.id LIMIT %(page)s""", dict(val, after=after, page=EXPORT_PAGE)).fetchall()
            yield from rows
            if len(rows) < EXPORT_PAGE:
                return
            after = rows[-1]["id"]
    return pages(), val["prev"], extra, val["due"]


def export_xlsx(conn, params, user, company=""):
    import openpyxl
    from openpyxl.cell import WriteOnlyCell
    from openpyxl.styles import Font, PatternFill
    rows, prev, extra_cols, due = export_rows(conn, params)
    q = params["quarter"]
    known = _words(conn)                                # the status words as confirmed, read once for this export
    heads, sheet_name = _headings(conn, q)
    wb = openpyxl.Workbook(write_only=True)
    bold = Font(bold=True)
    fill = PatternFill("solid", fgColor="DDE4EE")

    def head_row(ws, names):
        out = []
        for n in names:
            c = WriteOnlyCell(ws, value=n)
            c.font, c.fill = bold, fill
            out.append(c)
        ws.append(out)

    def cell(ws, v, as_date=False):
        if as_date and isinstance(v, date):
            c = WriteOnlyCell(ws, value=v)
            c.number_format = "dd-mmm-yyyy"
            return c
        t = _cell_text(v)
        c = WriteOnlyCell(ws, value=t)
        if t.startswith("="):
            c.data_type = "s"                           # a value, never a formula
        return c

    # Summary
    s = summary(conn, params)
    ws = wb.create_sheet("Summary")
    ws.append([f"Nessus remediation — {q}" + (f" — {company}" if company else "")])
    ws.append([f"Exported by {user} on {datetime.now().strftime('%d %b %Y %H:%M')}" + (f"; compared with {prev}" if prev else "")])
    ws.append([])
    t = s["totals"]
    tg = s["target"]

    def pc(v):                                          # a % cell (Excel shows 0.0%)
        c = WriteOnlyCell(ws, value=None if v is None else v / 100)
        c.number_format = "0.0%"
        return c
    TALLY_HEAD = ["Outstanding critical", "Outstanding high", "Outstanding medium", "Outstanding low", "Outstanding info",
                  "Outstanding", "Fixed / Decom", "All", "% outstanding", "Overdue"]

    def tally_line(r):
        return [r["s4"], r["s3"], r["s2"], r["s1"], r["s0"], r["outstanding"], r["done"], r["total"], pc(r["pct_outstanding"]),
                r["overdue"]]
    ws.append(["Findings", t["total"]])
    ws.append(["Outstanding (all but Fixed / Decommission)", t["outstanding"], pc(t["pct_outstanding"])])
    ws.append(["Fixed / Decommission", t["done"], pc(t["pct_done"])])
    ws.append(["Overdue", t["overdue"]])
    ws.append(["Hosts", t["hosts"]])
    if tg.get("date"):
        ws.append(["Target date", _day(tg["date"]).strftime("%d %b %Y") + (" (default)" if tg.get("from") == "default" else "")])
        ws.append(["Days left (from " + _day(tg["today"]).strftime("%d %b %Y") + ")", tg["days_left"]])
        if tg.get("per_week") is not None:
            ws.append(["To fix per week to meet it", tg["per_week"]])
    if prev:
        ws.append(["New since " + prev, int(t["new"])])
        ws.append(["Fixed in " + prev + " but found again", int(t["came_back"])])
        ws.append(["In " + prev + " but not in " + q, int(s["gone_since_previous"])])
    ws.append([])
    order = [k for k in ("open", "pending_review", "pending_deviation", "false_positive", "deviation_approved", "fixed", "decommission")]
    head_row(ws, ["Severity"] + [STATUS[k] for k in order] + ["Outstanding", "All", "% outstanding"])
    grid = {}
    for m in s["matrix"]:
        grid[(int(m["severity"]), m["status"])] = int(m["n"])
    cols = [0] * len(order)
    for sv, sl in SEVERITIES + [(-1, "Not given")]:
        line = [grid.get((sv, k), 0) for k in order]
        if sv == -1 and not any(line):
            continue
        cols = [a + b for a, b in zip(cols, line)]
        out = sum(n for k, n in zip(order, line) if k not in NO_ACTION)
        ws.append([sl] + line + [out, sum(line), pc(pct(out, sum(line)))])
    ws.append(["Total"] + cols + [t["outstanding"], t["total"], pc(t["pct_outstanding"])])

    def section(title, rows, label):
        ws.append([])
        head_row(ws, [title] + TALLY_HEAD)
        for g in rows:
            ws.append([label(g["k"])] + tally_line(g))
        ws.append(["Total"] + tally_line(t))
    blank = lambda k: k or "(blank)"  # noqa: E731
    section("PIC", s["by_pic"], blank)
    section("Device type", s["by_kind"], lambda k: KINDS.get(k, k))
    section("UAT/Prod", s["by_env"], blank)
    section("Application / Infra", s["by_team"], lambda k: {"application": "Application", "infra": "Infra"}.get(k, "Not set"))
    # Categorization2 -> Categorization1
    ws.append([])
    head_row(ws, ["Categorization2", "Categorization1"] + TALLY_HEAD + ["Hosts"])
    c = categories(conn, params)
    for tt in c["tree"]:
        for r, c1 in [(tt, "")] + [(k, k["cat1"] or "(blank)") for k in tt["children"]]:
            ws.append([(tt["cat2"] or "(blank)") if r is tt else "", c1] + tally_line(r) + [r["hosts"]])
    ws.append(["Total", ""] + tally_line(c["total"]) + [c["total"]["hosts"]])
    # Findings, in the file's own columns
    ws = wb.create_sheet((sheet_name or short_label(q))[:31])
    order = [k for k in FIELD_KEYS if k not in ("cvss3", "cvss2") or k in heads]
    names = [heads.get(k) or FIELD[k][0] for k in order]
    head_row(ws, names + ["Device type (PATCH-01)", "Application / Infra", "Team"] + extra_cols)

    def yesno(b):
        return "Yes" if b else "No"
    n = 0
    for r in rows:
        n += 1
        raw = (_json(r["extra"]) or {}).get("_raw") or {}
        line = []
        for k in order:
            if k in DATE_FIELDS:
                d = r[k]
                line.append(cell(ws, _day(d), True) if d else cell(ws, raw.get(k, "")))
                continue
            if k == "severity":
                v = r["severity_text"] if r["severity_text"] and severity_of(r["severity_text"]) == r["severity"] \
                    else SEV.get(r["severity"], r["severity_text"] or "")
            elif k == "status":
                w = norm_word(r["status_text"] or "")
                v = r["status_text"] if r["status_text"] and (known.get(w) or STATUS_WORDS.get(w)) == r["status"] \
                    else STATUS.get(r["status"], r["status"])
            elif k == "overdue":
                # worked out when there is a date (its own, or the target date) or nothing is left to do; else the file's
                v = yesno(r["overdue_calc"]) if (r["target_on"] or due or r["status"] in NO_ACTION) else (r["overdue_text"] or "")
            elif k == "prev_finding":
                v = yesno(r["in_previous"]) if prev else (r["prev_finding"] or "")
            elif k == "prev_fixed":
                v = yesno(r["came_back"]) if prev else (r["prev_fixed"] or "")
            elif k == "uuid":
                v = r["uuid_text"] or ""
            else:
                v = r[k]
            line.append(cell(ws, v))
        line += [cell(ws, KINDS.get(r["kind"], r["kind"])),
                 cell(ws, {"application": "Application", "infra": "Infra"}.get(r["team_type"], "")), cell(ws, r["team"])]
        ex = _json(r["extra"]) or {}
        line += [cell(ws, ex.get(k, "")) for k in extra_cols]
        ws.append(line)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue(), n


# ---------------------------------------------------------------------------
# Background runs (API process)
# ---------------------------------------------------------------------------

def run_in_background(fn, uid):
    """Runs read_upload / run_import on its own connection, off the request."""
    from . import core

    def go():
        try:
            with core.pool.connection() as conn:
                fn(conn, uid)
        except Exception as e:  # noqa: BLE001 - the upload shows it stopped; it can be started again
            core.log.error("remediation %s %s: %s", fn.__name__, uid, e)
    threading.Thread(target=go, name="rem-" + fn.__name__, daemon=True).start()


# ---------------------------------------------------------------------------
# AI-01's summary of a view (r134): what the issues are, how to fix them, what first - from the file's own text
# ---------------------------------------------------------------------------

SUM_SYSTEM = (
    "You summarise vulnerability scan findings for the engineers who fix them. Use ONLY the text given for each issue "
    "(its synopsis, description, steps to remediate and sample output, all copied from the team's scan file). Do not add "
    "products, versions, CVEs, causes or advice that are not in that text. Group the issues into at most 5 themes: issues "
    "about the same product or fixed the same way. For each theme write a short title, what is wrong (summary) and how to "
    "fix it (fix), taken from the issues' steps to remediate. Refer to issues only by their number n. Never write host "
    "names, IP addresses or counts of hosts or findings: the system adds them. Then give up to 3 issue numbers to fix "
    "first, each with a short reason taken from the given data (its severity, how many hosts it is on, overdue). "
    "Answer with JSON only.")
SUM_SCHEMA = {"type": "object", "properties": {
    "overview": {"type": "string", "maxLength": 500},
    "themes": {"type": "array", "maxItems": 5, "items": {"type": "object", "properties": {
        "title": {"type": "string", "maxLength": 80}, "issues": {"type": "array", "maxItems": 60, "items": {"type": "integer"}},
        "summary": {"type": "string", "maxLength": 300}, "fix": {"type": "string", "maxLength": 300}},
        "required": ["title", "issues", "summary", "fix"]}},
    "first": {"type": "array", "maxItems": 3, "items": {"type": "object", "properties": {
        "issue": {"type": "integer"}, "why": {"type": "string", "maxLength": 160}}, "required": ["issue", "why"]}}},
    "required": ["overview", "themes", "first"]}
SUM_CTX = 4096                  # AI-01's tokens per request (8192 context / 2 slots)
SUM_ANSWER = 900                # tokens kept for the answer
SUM_CHARS_PER_TOKEN = 3.0       # a cautious count for English and JSON
SUM_STALL_S = 900               # a summary with no sign of life for this long has stopped
SUM_PARTS = 4                   # requests per summary at most (worst issues first); the rest are listed, not read
SUM_KEYS = ("sev", "status", "open", "action", "pic", "cat1", "cat2", "env", "kind", "team_type", "host", "overdue",
            "came_back", "new", "q", "due", "team")


def view_of(params):
    """The view, the same way each time: (quarter, its filters, a key for it)."""
    q = (params.get("quarter") or "").strip()
    f = {k: params[k] for k in SUM_KEYS if params.get(k) not in (None, "")}
    return q, f, json.dumps({"quarter": q, **f}, sort_keys=True)


def view_words(f):
    """The view's filters in words, for the summary's heading."""
    out = []
    if f.get("sev"):
        out.append(" + ".join(SEV.get(int(x), "Not given") for x in re.findall(r"-?\d", f["sev"]) if x.lstrip("-").isdigit()))
    if f.get("status"):
        out.append(" / ".join(STATUS.get(s, s) for s in f["status"].split(",")))
    elif f.get("open"):
        out.append("open")
    elif f.get("action"):
        out.append("needs action")
    for k, label in (("cat2", "Categorization2"), ("cat1", "Categorization1"), ("pic", "PIC"), ("env", "UAT/Prod"), ("host", "host"),
                     ("team", "team")):
        if f.get(k):
            out.append(f"{label} {'(blank)' if f[k] == chr(0) else f[k]}")
    if f.get("kind"):
        out.append(KINDS.get(f["kind"], f["kind"]))
    if f.get("team_type"):
        out.append({"application": "Application", "infra": "Infra", "none": "team not set"}.get(f["team_type"], f["team_type"]))
    if f.get("due"):
        out.append({"expired": "target date passed", "none": "no target date", "set": "with a target date"}.get(f["due"], f["due"]))
    for k, label in (("overdue", "overdue"), ("came_back", "found again"), ("new", "new"), ("q", "search")):
        if f.get(k):
            out.append(label if k != "q" else f"search “{f[k]}”")
    return ", ".join(out) or "every finding"


def issues_of(conn, params):
    """The view's findings grouped by plugin, worst first: exact counts and hosts, and the file's own text."""
    w, val = where(params)
    _with_prev(conn, val)
    rows = conn.execute(f"""SELECT f.plugin_id, max(f.plugin_name) AS name, max(f.severity) AS severity, count(*) AS findings,
                                   count(DISTINCT f.host_key) AS host_count,
                                   array_agg(DISTINCT coalesce(f.hostname, f.ip)) AS hosts,
                                   array_agg(DISTINCT f.pic) AS pics, count(*) FILTER (WHERE {OVERDUE_SQL}) AS overdue,
                                   count(*) FILTER (WHERE {OPEN_SQL}) AS open,
                                   max(f.cat1) AS cat1, max(f.cat2) AS cat2, max(f.cve) AS cve, max(f.cvss3) AS cvss3,
                                   max(f.synopsis) AS synopsis, max(left(f.description, 2000)) AS description,
                                   max(f.solution) AS solution, max(left(f.plugin_output, 400)) AS output,
                                   array_agg(DISTINCT f.ip) AS ips
                              {FROM_SQL} WHERE {w}
                             GROUP BY f.plugin_id
                             ORDER BY max(coalesce(f.severity, -1)) DESC, count(DISTINCT f.host_key) DESC, count(*) DESC, f.plugin_id""",
                        val).fetchall()
    out = []
    for r in rows:
        r = dict(r)
        for k in ("hosts", "pics", "ips"):
            r[k] = sorted(x for x in (r.get(k) or []) if x)
        for k in ("findings", "host_count", "overdue", "open"):
            r[k] = int(r[k])
        out.append(r)
    return out


def _clip(t, n):
    t = re.sub(r"\s+", " ", (t or "").replace('"""', "'''")).strip()
    t = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", " ", t)
    return t if len(t) <= n else t[:n - 1].rstrip() + "…"


def digest(issues, start=0):
    """(messages, how many issues went in) for one request, from issues[start:], worst first, until AI-01's request
    would be full. In the request the issues are numbered from 1."""
    budget = int((SUM_CTX - SUM_ANSWER) * SUM_CHARS_PER_TOKEN) - len(SUM_SYSTEM) - len(json.dumps(SUM_SCHEMA)) - 400
    items, used = [], 0
    for n, r in enumerate(issues[start:], start=1):
        it = {"n": n, "issue": _clip(f"{r['plugin_id']} {r['name'] or ''}", 100), "severity": SEV.get(r["severity"], "Not given"),
              "hosts": r["host_count"], "overdue": r["overdue"], "category": _clip(r["cat1"], 60),
              "synopsis": _clip(r["synopsis"] or r["description"], 200), "steps_to_remediate": _clip(r["solution"], 280)}
        if r["output"]:
            it["sample_output"] = _clip(r["output"], 100)
        size = len(json.dumps(it, ensure_ascii=False)) + 2
        if used + size > budget and items:
            break
        items.append(it)
        used += size
    user = json.dumps({"issues": items, "issues_not_shown": len(issues) - start - len(items)}, ensure_ascii=False)
    return [{"role": "system", "content": SUM_SYSTEM}, {"role": "user", "content": user}], len(items)


IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
CVE_RE = re.compile(r"\bCVE-\d{4}-\d{4,}\b", re.I)
COUNT_RE = re.compile(r"\b\d+\s+(?:hosts?|servers?|machines?|findings?|devices?|systems?)\b", re.I)


def check_answer(raw, issues, covered):
    """AI-01's answer about issues[:covered] (numbered from 1) checked against them. Returns (themes, first, overview,
    warnings)."""
    try:
        ans = json.loads(raw)
    except ValueError:
        raise RemError("AI-01 gave an answer that is not the expected JSON. Try again.")
    if not isinstance(ans, dict):
        raise RemError("AI-01 gave an answer that is not the expected JSON. Try again.")
    known_ips = {ip for r in issues[:covered] for ip in r["ips"]}
    known_cves = {c.upper() for r in issues[:covered] for c in CVE_RE.findall(r["cve"] or "")
                  + CVE_RE.findall((r["synopsis"] or "") + " " + (r["description"] or "") + " " + (r["solution"] or ""))}
    warnings, seen, themes = [], set(), []

    def look(t, where_):
        t = _clip(str(t or ""), 600)
        for ip in IP_RE.findall(t):
            if ip not in known_ips:
                warnings.append(f"{where_}: the address {ip} is not in these findings.")
        for c in CVE_RE.findall(t):
            if c.upper() not in known_cves:
                warnings.append(f"{where_}: {c.upper()} is not in these issues' text in the file.")
        if COUNT_RE.search(t):
            warnings.append(f"{where_}: AI-01 wrote a count (“{COUNT_RE.search(t).group(0)}”); the exact counts are in the table.")
        return t
    for i, th in enumerate(ans.get("themes") or []):
        if not isinstance(th, dict):
            continue
        ids = []
        for x in th.get("issues") or []:
            try:
                x = int(x)
            except (TypeError, ValueError):
                continue
            if 1 <= x <= covered and x not in seen:
                ids.append(x)
                seen.add(x)
        if not ids:
            continue
        title = _clip(th.get("title"), 80) or f"Theme {i + 1}"
        themes.append({"title": look(title, title), "summary": look(th.get("summary"), title), "fix": look(th.get("fix"), title),
                       "issues": ids})
    first = []
    for x in ans.get("first") or []:
        try:
            n = int(x.get("issue"))
        except (TypeError, ValueError, AttributeError):
            continue
        if 1 <= n <= covered and n not in [f["issue"] for f in first]:
            first.append({"issue": n, "why": look(x.get("why"), "Fix first")})
    overview = look(ans.get("overview"), "Overview")
    return themes, first[:3], overview, warnings


def summarise(conn, params, ask, progress=None):
    """AI-01's summary of the view. ask(messages, schema) -> JSON text; progress(part, parts) is told each request.
    The issues are read worst first in up to SUM_PARTS requests that each fit AI-01; themes of the same title are
    merged. Returns the result to keep."""
    issues = issues_of(conn, params)
    q, f, _key = view_of(params)
    scope = {"quarter": q, "filters": f, "words": view_words(f), "issues": len(issues),
             "findings": sum(r["findings"] for r in issues),
             "hosts": int(conn.execute("SELECT count(DISTINCT f.host_key) AS n " + FROM_SQL + " WHERE " + where(params)[0],
                                       _with_prev(conn, where(params)[1])).fetchone()["n"])}
    if not issues:
        raise RemError("No findings in this view: nothing to summarise.")
    parts, start = [], 0
    while start < len(issues) and len(parts) < SUM_PARTS:
        messages, n = digest(issues, start)
        parts.append((start, n, messages))
        start += n
    covered = start
    themes, first, overview, warnings, by_title = [], [], "", [], {}
    for i, (base, n, messages) in enumerate(parts):
        if progress:
            progress(i + 1, len(parts))
        raw = ask(messages, SUM_SCHEMA)
        t_part, f_part, o_part, w_part = check_answer(raw, issues[base:base + n], n)
        warnings += w_part
        if i == 0:
            overview, first = o_part, [dict(x, issue=x["issue"] + base) for x in f_part]
        for th in t_part:
            th["issues"] = [x + base for x in th["issues"]]
            k = norm(th["title"])
            if k in by_title:                                # the same theme in a later part: one theme
                by_title[k]["issues"] += th["issues"]
            else:
                by_title[k] = th
                themes.append(th)

    def issue_out(n):
        r = issues[n - 1]
        return {"n": n, "plugin_id": r["plugin_id"], "name": r["name"], "severity": r["severity"], "findings": r["findings"],
                "host_count": r["host_count"], "hosts": r["hosts"], "overdue": r["overdue"], "open": r["open"],
                "pics": r["pics"], "cat1": r["cat1"], "cat2": r["cat2"], "cve": (r["cve"] or "")[:400],
                "synopsis": (r["synopsis"] or "")[:1200], "solution": (r["solution"] or "")[:3000]}
    for th in themes:
        th["issues"] = [issue_out(n) for n in th["issues"]]
        th["findings"] = sum(x["findings"] for x in th["issues"])
        th["hosts"] = sorted({h for x in th["issues"] for h in x["hosts"]})
    placed = {x["n"] for th in themes for x in th["issues"]}
    other = [issue_out(n) for n in range(1, covered + 1) if n not in placed]
    if other:
        themes.append({"title": "Other issues", "summary": "", "fix": "", "issues": other, "other": True,
                       "findings": sum(x["findings"] for x in other), "hosts": sorted({h for x in other for h in x["hosts"]})})
    left = [issue_out(n) for n in range(covered + 1, len(issues) + 1)]
    for x in first:
        r = issues[x["issue"] - 1]
        x.update(plugin_id=r["plugin_id"], name=r["name"], severity=r["severity"], host_count=r["host_count"])
    scope["covered_issues"] = covered
    scope["covered_findings"] = sum(r["findings"] for r in issues[:covered])
    scope["parts"] = len(parts)
    return {"scope": scope, "overview": overview, "themes": themes, "first": first, "not_read": left[:500],
            "not_read_count": len(left), "warnings": warnings}


def start_summary(conn, user, params):
    q, f, key = view_of(params)
    where(params)                                       # the filters are checked before anything starts
    r = conn.execute("""INSERT INTO rem_ai_summaries (quarter, filters, filter_key, created_by, phase)
                        VALUES (%s, %s::jsonb, %s, %s, 'waiting') RETURNING id""", (q, json.dumps(f), key, user)).fetchone()
    conn.commit()
    return str(r["id"])


def run_summary(conn, sid, ask):
    """The background part: waits for AI-01 while it is busy (a person's question goes first), then writes."""
    r = conn.execute("SELECT * FROM rem_ai_summaries WHERE id = %s", (sid,)).fetchone()
    if not r or r["state"] != "running":
        return
    params = dict(_json(r["filters"]) or {}, quarter=r["quarter"])
    started = time.time()
    while True:
        try:
            def progress(part, parts):
                conn.execute("UPDATE rem_ai_summaries SET phase = %s, updated_at = now() WHERE id = %s",
                             (f"writing {part}/{parts}", sid))
                conn.commit()
            progress(1, 1)
            res = summarise(conn, params, ask, progress)
            conn.execute("""UPDATE rem_ai_summaries SET state = 'done', result = %s::jsonb, phase = NULL, updated_at = now(),
                                   finished_at = now() WHERE id = %s""", (json.dumps(res, default=str), sid))
            conn.commit()
            return
        except Exception as e:  # noqa: BLE001
            conn.rollback()
            busy = type(e).__name__ == "LLMBusy"
            if busy and time.time() - started < 600:
                conn.execute("UPDATE rem_ai_summaries SET phase = 'waiting', updated_at = now() WHERE id = %s", (sid,))
                conn.commit()
                time.sleep(5)
                continue
            msg = (str(e) if isinstance(e, RemError) else
                   "AI-01 stayed busy for 10 minutes. Try again later." if busy else
                   f"AI-01 could not write the summary: {type(e).__name__}: {str(e)[:240]}")
            conn.execute("""UPDATE rem_ai_summaries SET state = 'failed', error = %s, phase = NULL, updated_at = now(),
                                   finished_at = now() WHERE id = %s""", (msg, sid))
            conn.commit()
            return


def summary_view(conn, sid):
    r = conn.execute("SELECT * FROM rem_ai_summaries WHERE id = %s", (sid,)).fetchone()
    if not r:
        raise NotFound("No such summary.")
    return _summary_out(r)


def _summary_out(r):
    r = dict(r)
    t = r["updated_at"]
    if isinstance(t, str):
        t = datetime.fromisoformat(t)
    stalled = r["state"] == "running" and (datetime.now(timezone.utc) - t).total_seconds() > SUM_STALL_S
    return {"id": str(r["id"]), "quarter": r["quarter"], "filters": _json(r["filters"]), "state": r["state"], "phase": r["phase"],
            "stalled": stalled, "result": _json(r["result"]), "error": r["error"], "created_by": r["created_by"],
            "created_at": _iso(r["created_at"]), "finished_at": _iso(r["finished_at"]),
            "words": view_words(_json(r["filters"]) or {})}


def latest_summary(conn, params):
    """The newest summary of this view (done, or still being written), or None."""
    _q, _f, key = view_of(params)
    r = conn.execute("""SELECT * FROM rem_ai_summaries WHERE filter_key = %s AND state IN ('done', 'running')
                         ORDER BY created_at DESC LIMIT 1""", (key,)).fetchone()
    return _summary_out(r) if r else None


def summary_running(conn, params):
    """A summary of this view being written now (not stopped), or None: a second press does not start another."""
    s = latest_summary(conn, params)
    return s if s and s["state"] == "running" and not s["stalled"] else None


def run_summary_in_background(sid, ask):
    from . import core

    def go():
        try:
            with core.pool.connection() as conn:
                run_summary(conn, sid, ask)
        except Exception as e:  # noqa: BLE001
            core.log.error("remediation summary %s: %s", sid, e)
    threading.Thread(target=go, name="rem-summary", daemon=True).start()
