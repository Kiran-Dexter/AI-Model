#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Why does Vulnerabilities > Detected CVEs show what it shows? Every step from the feeds to the
# tiles, as counts: the feeds' window, what each feed last read (and its error), the CVEs in the
# window, the ones analysed and their verdicts, the inventory they are matched against, and the
# worker's last passes.
#
#   sudo ./scripts/check-detected-cves.sh
#
# Read only: it changes nothing. It prints counts and times, no host names and no CVE lists,
# so its output can be shared.
# ---------------------------------------------------------------------------
set -Eeuo pipefail
PSQL=(docker exec -i patch01-postgres psql -U postgres -d patchdb -P pager=off -v ON_ERROR_STOP=0 -q)
[[ "${CHECK_PSQL:-}" ]] && read -r -a PSQL <<< "$CHECK_PSQL"      # the tests point it at their own database

"${PSQL[@]}" <<'SQL'
\pset footer off
\echo
\echo '== 1. The window (Admin > CVE feeds)'
SELECT days_back AS "days of CVEs read and checked",
       coalesce((SELECT new_sources FROM cve_feed_settings WHERE id = 1), 'off') AS "new sources",
       now()::timestamp(0) AS "now (database clock)"
  FROM cve_feed_settings WHERE id = 1;

\echo '== 2. Each feed: when it last ran, last worked, and its error'
SELECT source, last_run::timestamp(0) AS "last run", last_ok::timestamp(0) AS "last worked",
       items AS "items last read", left(coalesce(error, ''), 140) AS error
  FROM cve_feed_state ORDER BY source;

\echo '== 3. CVEs held from the feeds'
WITH s AS (SELECT days_back FROM cve_feed_settings WHERE id = 1)
SELECT count(DISTINCT cve_id) AS "all",
       max(published)::timestamp(0) AS "newest published",
       count(DISTINCT cve_id) FILTER (WHERE published >= now() - make_interval(days => (SELECT days_back FROM s))) AS "in the window",
       count(DISTINCT cve_id) FILTER (WHERE published >= now() - make_interval(days => (SELECT days_back FROM s))
                                        AND (exploited OR coalesce(cvss, 0) >= 7
                                             OR lower(coalesce(severity, '')) IN ('critical', 'high', 'important'))) AS "in the window, critical / high / exploited",
       max(fetched_at)::timestamp(0) AS "last item fetched"
  FROM cve_feed_items;

\echo '== 4. CVEs analysed against the inventory (what the tiles count)'
WITH s AS (SELECT days_back FROM cve_feed_settings WHERE id = 1),
     w AS (SELECT * FROM cve_impact
            WHERE published >= now() - make_interval(days => (SELECT days_back FROM s))
              AND EXISTS (SELECT 1 FROM cve_feed_items f WHERE f.cve_id = cve_impact.cve_id))
SELECT (SELECT count(*) FROM cve_impact) AS "analysed, all",
       count(*) AS "in the window (CVEs checked tile)",
       count(*) FILTER (WHERE verdict = 'affected') AS affected,
       count(*) FILTER (WHERE verdict = 'not_affected') AS "not affected (fixed)",
       count(*) FILTER (WHERE verdict = 'not_found') AS "not in our environment",
       count(*) FILTER (WHERE verdict IN ('unknown', 'no_data')) AS "cannot tell",
       count(*) FILTER (WHERE appliance_state IS NOT NULL) AS appliances,
       max(analysed_at)::timestamp(0) AS "last analysed"
  FROM w;

\echo '== 5. The inventory the CVEs are matched against'
SELECT (SELECT count(*) FROM hosts WHERE status <> 'decommissioned') AS "servers (agents)",
       (SELECT count(*) FROM hosts WHERE status <> 'decommissioned' AND last_checkin > now() - interval '1 day') AS "reported in the last day",
       (SELECT count(DISTINCT host_id) FROM host_packages) AS "Linux servers with packages",
       (SELECT count(DISTINCT host_id) FROM windows_software) AS "Windows servers with programs",
       (SELECT count(*) FROM vm_inventory) AS "vCenter VMs";

\echo '== 6. The worker (a loop not seen for long is stopped or stuck)'
SELECT name, beat_at::timestamp(0) AS "last seen", (now() - beat_at)::interval(0) AS ago, left(detail::text, 120) AS detail
  FROM worker_heartbeat WHERE name IN ('impact', 'cve_sync', 'feeds', 'cve_feeds', 'proxy') ORDER BY name;

\echo '== 7. The last full syncs'
SELECT slot, state, step, finished_at::timestamp(0) AS finished,
       left(coalesce(report->>'problems', ''), 160) AS problems
  FROM cve_sync_runs ORDER BY id DESC LIMIT 3;
SQL
cat <<'EOF'

How to read it:
  * 3 "in the window" 0, or 2 shows an error  -> the feeds have not read anything recent (e.g. the proxy):
    fix the feed, then Sync now. Nothing reaches the page until the feeds have CVEs in the window.
  * 3 has CVEs but 4 "in the window" is 0     -> the worker has not analysed them: look at 6 and 7.
  * 4 has CVEs, "affected" 0                  -> analysed, and none is proven on a machine in this window;
    "not in our environment" / "not affected" say why. A short window (a few days) is often 0.
  * 5 has 0 servers with packages / programs  -> there is nothing to match against: the agents' inventory.
EOF
