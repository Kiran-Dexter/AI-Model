#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 phase 3b : patch API
#
# Builds the API image from the local UBI Python base and deploys it behind
# the existing NGINX ingress. No host port is published: NGINX reaches it by
# container name on patchnet and routes /api/ to it.
#
# Usage:
#   ./phase3b-api.sh --dry-run     show the plan
#   ./phase3b-api.sh               build and deploy
#   ./phase3b-api.sh --build-only  build the image, do not deploy
#   ./phase3b-api.sh --check       validate a running deployment
#   ./phase3b-api.sh --down        stop the API
#   ./phase3b-api.sh --logs        tail the API log
#   ./phase3b-api.sh --token       issue an enrollment token
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 027

VERSION="1.0.0"
PATCH_BASE="/patch"
ETC_DIR="/etc/patch-platform"
LOG_DIR="/var/log/patch-platform"
IMAGES_MANIFEST="$ETC_DIR/images.env"
API_IMAGE="patch01/api:$VERSION"
CONTAINER="patch01-api"

DRY_RUN=no; CHECK_ONLY=no; DO_DOWN=no; BUILD_ONLY=no; SHOW_LOGS=no; MAKE_TOKEN=no
TOKEN_GROUP="default"; TOKEN_TTL=24

while (($#)); do
  case "$1" in
    --dry-run)    DRY_RUN=yes ;;
    --check)      CHECK_ONLY=yes ;;
    --down)       DO_DOWN=yes ;;
    --build-only) BUILD_ONLY=yes ;;
    --logs)       SHOW_LOGS=yes ;;
    --token)      MAKE_TOKEN=yes ;;
    --group)      TOKEN_GROUP="${2:-default}"; shift ;;
    --ttl)        TOKEN_TTL="${2:-24}"; shift ;;
    -h|--help)    sed -n '2,18p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/phase3b-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"

log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Run as root."

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
COMPOSE_DIR="$PATCH_BASE/compose"
SECRETS_DIR="$PATCH_BASE/secrets"
COMPOSE_FILE="$COMPOSE_DIR/docker-compose.api.yml"

# ---------------------------------------------------------------------------
# Simple modes
# ---------------------------------------------------------------------------
if [[ "$SHOW_LOGS" == yes ]]; then
  exec docker logs -f --tail 50 "$CONTAINER"
fi

if [[ "$DO_DOWN" == yes ]]; then
  step "Stopping the API"
  [[ -f "$COMPOSE_FILE" ]] && \
    (cd "$COMPOSE_DIR" && docker compose -f "$COMPOSE_FILE" down) || true
  docker rm -f "$CONTAINER" >/dev/null 2>&1 || true
  say "Stopped. Data is untouched."
  exit 0
fi

# ---------------------------------------------------------------------------
# Issue an enrollment token
# ---------------------------------------------------------------------------
if [[ "$MAKE_TOKEN" == yes ]]; then
  step "Issuing an enrollment token"
  docker ps --format '{{.Names}}' | grep -qx "$CONTAINER" \
    || die "$CONTAINER is not running."
  [[ -f "$SECRETS_DIR/api.env" ]] || die "Missing $SECRETS_DIR/api.env"
  ADMIN_PW="$(grep -E '^ADMIN_PASSWORD=' "$SECRETS_DIR/api.env" | cut -d= -f2-)"
  [[ -n "$ADMIN_PW" ]] || die "Could not read the admin password."

  RESP="$(curl -sk -u "admin:$ADMIN_PW" \
    -H 'Content-Type: application/json' \
    -d "{\"host_group\":\"$TOKEN_GROUP\",\"ttl_hours\":$TOKEN_TTL}" \
    "https://127.0.0.1/api/v1/admin/enrollment-tokens" 2>>"$LOG_FILE" || true)"

  TOKEN="$(printf '%s' "$RESP" | python3 -c \
    'import json,sys
try: print(json.load(sys.stdin)["enrollment_token"])
except Exception: pass' 2>/dev/null || true)"

  if [[ -z "$TOKEN" ]]; then
    warn "Could not obtain a token. Response:"
    printf '%s\n' "$RESP" >&2
    die "Token creation failed."
  fi

  echo
  echo "================================================================"
  echo " ENROLLMENT TOKEN  (shown once)"
  echo "================================================================"
  printf ' group:   %s\n ttl:     %s hours\n\n token:   %s\n\n' \
    "$TOKEN_GROUP" "$TOKEN_TTL" "$TOKEN"
  echo " On the managed host:"
  echo "   patch-agent enroll --token $TOKEN"
  echo
  exit 0
fi

# ---------------------------------------------------------------------------
# Preconditions
# ---------------------------------------------------------------------------
step "Checking preconditions"

command -v docker >/dev/null 2>&1 || die "Docker is not installed."
docker info >/dev/null 2>&1 || die "The Docker daemon is not responding."

[[ -f "$IMAGES_MANIFEST" ]] || die "No $IMAGES_MANIFEST. Run resolve-images.sh"
# shellcheck disable=SC1090
source "$IMAGES_MANIFEST"

PY_IMAGE="${IMG_PYTHON:-}"
[[ -n "$PY_IMAGE" ]] || die "The manifest has no python image. Re-run resolve-images.sh"
docker image inspect "$PY_IMAGE" >/dev/null 2>&1 \
  || die "$PY_IMAGE is not present locally."
say "Build base: $PY_IMAGE (${VER_PYTHON:-unknown})"

docker ps --format '{{.Names}}' | grep -qx patch01-postgres \
  || die "patch01-postgres is not running. Run phase1b-data.sh first."
docker network inspect patchnet >/dev/null 2>&1 \
  || die "The patchnet network is missing. Run phase1a-ingress.sh first."

# The schema must exist, or the API starts and fails on every query
PG_ENV="$SECRETS_DIR/postgres.env"
[[ -f "$PG_ENV" ]] || die "Missing $PG_ENV"
# shellcheck disable=SC1090
source "$PG_ENV"
PATCHDB_NAME="${PATCHAPI_DB_NAME:-patchdb}"
PATCHDB_USER="${PATCHAPI_DB_USER:-patchapi}"

SCHEMA_OK="$(docker exec patch01-postgres psql -U postgres -d "$PATCHDB_NAME" -qtAX \
  -c "SELECT count(*) FROM information_schema.tables
       WHERE table_schema='public' AND table_name='hosts'" 2>/dev/null || echo 0)"
[[ "$SCHEMA_OK" == "1" ]] \
  || die "The 'hosts' table is missing. Run phase3a-schema.sh first."
say "Schema present in $PATCHDB_NAME"

# ---------------------------------------------------------------------------
# Check mode
# ---------------------------------------------------------------------------
if [[ "$CHECK_ONLY" == yes ]]; then
  step "Validating the deployment"
  FAILS=0

  if docker ps --format '{{.Names}}' | grep -qx "$CONTAINER"; then
    st="$(docker inspect "$CONTAINER" --format '{{.State.Health.Status}}' 2>/dev/null || echo none)"
    say "$CONTAINER: running, health=$st"
    [[ "$st" == healthy || "$st" == none ]] || FAILS=$((FAILS+1))
  else
    warn "$CONTAINER is not running"; FAILS=$((FAILS+1))
  fi

  step "API through the ingress"
  CODE="$(curl -sk -o /tmp/apihealth.$$ -w '%{http_code}' --max-time 15 \
    https://127.0.0.1/api/v1/health 2>/dev/null || echo 000)"
  if [[ "$CODE" == "200" ]]; then
    say "health: $(cat /tmp/apihealth.$$)"
  else
    warn "health returned HTTP $CODE"; FAILS=$((FAILS+1))
  fi
  rm -f /tmp/apihealth.$$

  step "Admin authentication"
  if [[ -f "$SECRETS_DIR/api.env" ]]; then
    ADMIN_PW="$(grep -E '^ADMIN_PASSWORD=' "$SECRETS_DIR/api.env" | cut -d= -f2-)"
    CODE="$(curl -sk -o /dev/null -w '%{http_code}' --max-time 15 \
      -u "admin:$ADMIN_PW" https://127.0.0.1/api/v1/admin/fleet-summary || echo 000)"
    [[ "$CODE" == "200" ]] && say "admin auth ok" \
      || { warn "admin auth returned HTTP $CODE"; FAILS=$((FAILS+1)); }

    # An unauthenticated admin call must be refused
    CODE="$(curl -sk -o /dev/null -w '%{http_code}' --max-time 15 \
      https://127.0.0.1/api/v1/admin/hosts || echo 000)"
    [[ "$CODE" == "401" ]] && say "unauthenticated admin access correctly refused" \
      || { warn "unauthenticated admin call returned HTTP $CODE, expected 401"
           FAILS=$((FAILS+1)); }
  fi

  step "Agent endpoint authentication"
  CODE="$(curl -sk -o /dev/null -w '%{http_code}' --max-time 15 \
    -X POST https://127.0.0.1/api/v1/agent/checkin \
    -H 'Content-Type: application/json' -d '{}' || echo 000)"
  [[ "$CODE" == "401" ]] && say "unauthenticated agent call correctly refused" \
    || { warn "unauthenticated agent call returned HTTP $CODE, expected 401"
         FAILS=$((FAILS+1)); }

  step "Exposure"
  pmap="$(docker port "$CONTAINER" 2>/dev/null || true)"
  [[ -z "$pmap" ]] && say "$CONTAINER publishes no host port - correct" \
    || { warn "$CONTAINER publishes: $pmap"; FAILS=$((FAILS+1)); }

  # The worker carries out changes; if it is down they simply never start
  if docker ps --format '{{.Names}}' | grep -qx patch01-worker; then
    AGE="$(docker exec -i patch01-postgres psql -U postgres -d patchdb -qtAX -c \
      "SELECT coalesce(max(extract(epoch FROM now()-beat_at))::int, -1) FROM worker_heartbeat" 2>/dev/null || echo -1)"
    if [[ "$AGE" =~ ^[0-9]+$ ]] && (( AGE < 120 )); then
      say "patch01-worker: running, last heartbeat ${AGE}s ago"
    else
      warn "patch01-worker is running but not reporting: docker logs patch01-worker"
      FAILS=$((FAILS+1))
    fi
  else
    warn "patch01-worker is not running: scheduled changes will not start"
    FAILS=$((FAILS+1))
  fi

  (( FAILS == 0 )) && say "
All checks passed." || die "$FAILS check(s) failed."
  exit 0
fi

# ---------------------------------------------------------------------------
# Secrets
# ---------------------------------------------------------------------------
step "Preparing secrets"

API_ENV="$SECRETS_DIR/api.env"
if [[ -f "$API_ENV" ]]; then
  say "Existing $API_ENV found; reusing it."
else
  if [[ "$DRY_RUN" == yes ]]; then
    say "[dry-run] would generate $API_ENV"
  else
    ADMIN_PW="$(openssl rand -base64 24 | tr -d '/+=\n' | cut -c1-24)"
    cat >"$API_ENV" <<EOF
# PATCH-01 API credentials. Generated $(date -Is). Mode 0600.
ADMIN_USER=admin
ADMIN_PASSWORD=$ADMIN_PW
PATCHDB_PASSWORD=${PATCHAPI_DB_PASSWORD:-}
EOF
    chmod 0600 "$API_ENV"; chown root:root "$API_ENV"
    say "Generated $API_ENV"
  fi
fi

# AI-01 certificate directory, mounted read-only into the API container.
# Created empty if absent so the mount exists; phase6-llm.sh fills it. The
# API runs as uid 1001 in group 0, so group-root read is what it needs.
if [[ "$DRY_RUN" != yes ]]; then
  for d in ai01 vcenter; do
    mkdir -p "$SECRETS_DIR/$d"
    chown root:0 "$SECRETS_DIR/$d"
    chmod 0750 "$SECRETS_DIR/$d"
  done
fi

# Worker environment: the corporate proxy (for NVD, CISA and FIRST) and the
# NVD key. Internal names are always excluded from the proxy, whatever
# proxy.env says, so database and AI-01 traffic never leaves the host.
if [[ "$DRY_RUN" != yes ]]; then
  WENV="$SECRETS_DIR/worker.env"
  INTERNAL="localhost,127.0.0.1,postgres,redis,patch01-postgres,patch01-redis,patch01-api,pulp-api,pulp-content,patch01-pulp-api,patch01-pulp-content"
  {
    echo "# Generated by phase3b-api.sh. Do not edit; edit /etc/patch-platform/proxy.env"
    if [[ -f "$ETC_DIR/proxy.env" ]]; then
      for k in HTTP_PROXY HTTPS_PROXY; do
        v="$(grep -E "^$k=" "$ETC_DIR/proxy.env" | cut -d= -f2- | tr -d '"' || true)"
        [[ -n "$v" ]] && { echo "$k=$v"; echo "${k,,}=$v"; }
      done
      np="$(grep -E '^NO_PROXY=' "$ETC_DIR/proxy.env" | cut -d= -f2- | tr -d '"' || true)"
    else
      np=""
    fi
    echo "NO_PROXY=$INTERNAL${np:+,$np}"
    echo "no_proxy=$INTERNAL${np:+,$np}"
    for kf in "$SECRETS_DIR/nvd-api-key" "$SECRETS_DIR/intel/nvd-api-key"; do
      if [[ -s "$kf" ]]; then echo "NVD_API_KEY=$(tr -d '[:space:]' < "$kf")"; break; fi
    done
  } > "$WENV"
  chmod 0600 "$WENV"
fi

# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------
step "Building $API_IMAGE"

PROXY_ARGS=()
if [[ -f "$ETC_DIR/proxy.env" ]]; then
  P_HTTP="$(grep -E '^HTTP_PROXY=' "$ETC_DIR/proxy.env" | cut -d= -f2- || true)"
  P_HTTPS="$(grep -E '^HTTPS_PROXY=' "$ETC_DIR/proxy.env" | cut -d= -f2- || true)"
  P_NO="$(grep -E '^NO_PROXY=' "$ETC_DIR/proxy.env" | cut -d= -f2- || true)"
  [[ -n "$P_HTTP"  ]] && PROXY_ARGS+=(--build-arg "HTTP_PROXY=$P_HTTP")   || true
  [[ -n "$P_HTTPS" ]] && PROXY_ARGS+=(--build-arg "HTTPS_PROXY=$P_HTTPS") || true
  [[ -n "$P_NO"    ]] && PROXY_ARGS+=(--build-arg "NO_PROXY=$P_NO")       || true
  say "Using the corporate proxy for pip during the build."
else
  warn "No proxy configured; pip will need direct internet access."
fi

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] docker build -t $API_IMAGE --build-arg BASE_IMAGE=$PY_IMAGE $SRC_DIR/api"
else
  if docker build -t "$API_IMAGE" \
      --build-arg "BASE_IMAGE=$PY_IMAGE" \
      "${PROXY_ARGS[@]}" \
      "$SRC_DIR/api" >>"$LOG_FILE" 2>&1; then
    say "Built $API_IMAGE"
  else
    warn "Build failed. Last 40 lines:"
    tail -40 "$LOG_FILE" >&2
    die "Image build failed."
  fi
fi

[[ "$BUILD_ONLY" == yes ]] && { say "Built only, as requested."; exit 0; } || true

# ---------------------------------------------------------------------------
# Generate compose
# ---------------------------------------------------------------------------
step "Generating the compose file"

TMPL="$SRC_DIR/compose/docker-compose.api.yml.tmpl"
[[ -f "$TMPL" ]] || die "Template not found: $TMPL"

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] would generate $COMPOSE_FILE"
else
  [[ -f "$COMPOSE_FILE" ]] && \
    cp -a "$COMPOSE_FILE" "$COMPOSE_FILE.$(date +%Y%m%d-%H%M%S).bak" || true
  sed -e "s|@@API_IMAGE@@|$API_IMAGE|g" \
      -e "s|@@SECRETS_DIR@@|$SECRETS_DIR|g" \
      -e "s|@@PG_HOST@@|postgres|g" \
      -e "s|@@PG_PORT@@|5432|g" \
      -e "s|@@PATCHDB_NAME@@|$PATCHDB_NAME|g" \
      -e "s|@@PATCHDB_USER@@|$PATCHDB_USER|g" \
      "$TMPL" >"$COMPOSE_FILE"
  chmod 0640 "$COMPOSE_FILE"

  grep -q '@@' "$COMPOSE_FILE" && {
    warn "Unfilled placeholders:"; grep -n '@@' "$COMPOSE_FILE" >&2
    die "Compose generation incomplete."
  } || true

  docker compose -f "$COMPOSE_FILE" config >/dev/null 2>>"$LOG_FILE" \
    || { tail -20 "$LOG_FILE" >&2; die "Generated compose file is invalid."; }
  say "Generated and validated $COMPOSE_FILE"
fi

# ---------------------------------------------------------------------------
# Deploy
# ---------------------------------------------------------------------------
step "Starting the API"

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] docker compose up -d"
else
  (cd "$COMPOSE_DIR" && docker compose -f "$COMPOSE_FILE" up -d) >>"$LOG_FILE" 2>&1 \
    || { tail -30 "$LOG_FILE" >&2; die "Deployment failed."; }

  say "Waiting for health..."
  for i in $(seq 1 60); do
    st="$(docker inspect "$CONTAINER" --format '{{.State.Health.Status}}' 2>/dev/null || echo starting)"
    if [[ "$st" == healthy ]]; then say "API is healthy."; break; fi
    if ! docker ps --format '{{.Names}}' | grep -qx "$CONTAINER"; then
      warn "Container exited. Last 40 lines:"
      docker logs --tail 40 "$CONTAINER" 2>&1 >&2
      die "The API did not stay up."
    fi
    if (( i == 60 )); then
      warn "Not healthy after 60s. Last 40 lines:"
      docker logs --tail 40 "$CONTAINER" 2>&1 >&2
      die "Timed out."
    fi
    sleep 1
  done

  # Reach it the way an agent will, through NGINX
  CODE="$(curl -sk -o /dev/null -w '%{http_code}' --max-time 15 \
    https://127.0.0.1/api/v1/health || echo 000)"
  if [[ "$CODE" == "200" ]]; then
    say "Reachable through the ingress at /api/v1/health"
  else
    warn "Through the ingress returned HTTP $CODE."
    warn "Check that NGINX routes /api/ to patch-api:8000."
  fi
fi

# ---------------------------------------------------------------------------
# Record and summarise
# ---------------------------------------------------------------------------
if [[ "$DRY_RUN" != yes ]]; then
  cat >"$ETC_DIR/phase3b.env" <<EOF
# Generated by phase3b-api.sh v$VERSION on $(date -Is)
PP_API_IMAGE="$API_IMAGE"
PP_API_CONTAINER="$CONTAINER"
PP_API_HOST="patch-api"
PP_API_PORT="8000"
PP_API_SECRETS="$API_ENV"
PP_COMPOSE_API="$COMPOSE_FILE"
EOF
  chmod 0600 "$ETC_DIR/phase3b.env"
fi

FQDN="$(hostname -f 2>/dev/null || hostname)"

echo
echo "================================================================"
echo " PHASE 3b COMPLETE - PATCH API"
echo "================================================================"
printf ' Image:     %s\n' "$API_IMAGE"
printf ' Container: %s  (no host port)\n' "$CONTAINER"
printf ' Health:    https://%s/api/v1/health\n' "$FQDN"
printf ' Docs:      https://%s/api/v1/docs\n' "$FQDN"
printf ' Secrets:   %s\n' "$API_ENV"
printf ' Log:       %s\n' "$LOG_FILE"
echo
echo " Enrol the first host:"
echo "   1. On PATCH-01:   ./scripts/phase3b-api.sh --token"
echo "   2. Copy agent/patch-agent.py to the managed host as /usr/local/bin/patch-agent"
echo "   3. On that host:  patch-agent enroll --token <token>"
echo "                     patch-agent inventory"
echo
echo " Then:  ./scripts/phase3b-api.sh --check"
