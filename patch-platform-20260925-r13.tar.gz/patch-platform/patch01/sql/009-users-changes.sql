-- ===========================================================================
-- PATCH-01 : schema 009 - users, roles, the change engine, richer assessments
--
-- Applied after 008. Idempotent.
--
-- USERS AND ROLES
--   viewer    reads dashboards and reports; changes nothing
--   operator  also schedules patching, VM snapshots and power actions, runs
--             CVE assessments, uses the chat and AI explanations
--   admin     everything, plus users, integrations and settings
--
-- THE CHANGE ENGINE
--   Every action that alters a server or a VM is a change: patching, VM
--   snapshots, reverts, power actions. One path, one record, one audit trail.
--
--   Approval is supported but off by default, as decided for this estate:
--   operators' changes run on their own authority. Each change still
--   records who asked, when, why and what happened, in an append-only log.
--   Switching approval on is a setting, not a schema change.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Users
-- ---------------------------------------------------------------------------
DO $$ BEGIN
    CREATE TYPE user_role AS ENUM ('viewer', 'operator', 'admin');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS users (
    id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username              TEXT NOT NULL UNIQUE
                          CHECK (username ~ '^[a-z0-9][a-z0-9._-]{1,62}$'),
    display_name          TEXT,
    role                  user_role NOT NULL,
    -- scrypt, with its parameters stored alongside, so they can be raised later
    password_hash         TEXT NOT NULL,
    active                BOOLEAN NOT NULL DEFAULT TRUE,
    must_change_password  BOOLEAN NOT NULL DEFAULT FALSE,
    failed_logins         INTEGER NOT NULL DEFAULT 0,
    locked_until          TIMESTAMPTZ,
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by            TEXT,
    last_login_at         TIMESTAMPTZ,
    password_changed_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- A session token is shown to the browser once and stored here only as a hash
CREATE TABLE IF NOT EXISTS user_sessions (
    token_hash    TEXT PRIMARY KEY,
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at    TIMESTAMPTZ NOT NULL,
    source_ip     INET,
    user_agent    TEXT
);

CREATE INDEX IF NOT EXISTS idx_sessions_user    ON user_sessions (user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON user_sessions (expires_at);

-- ---------------------------------------------------------------------------
-- Changes
-- ---------------------------------------------------------------------------
DO $$ BEGIN
    CREATE TYPE change_kind AS ENUM (
        'patch',
        'vm_snapshot_create',
        'vm_snapshot_remove',
        'vm_snapshot_revert',
        'vm_power_on',
        'vm_guest_shutdown',
        'vm_guest_restart'
    );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE change_state AS ENUM (
        'pending_approval',
        'scheduled',
        'running',
        'succeeded',
        'partially_succeeded',
        'failed',
        'cancelled',
        'rejected'
    );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS changes (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    -- A short reference people can say out loud: CHG-000123
    number             BIGSERIAL UNIQUE,
    kind               change_kind NOT NULL,
    title              TEXT NOT NULL,
    reason             TEXT NOT NULL CHECK (length(trim(reason)) >= 3),
    state              change_state NOT NULL DEFAULT 'scheduled',
    params             JSONB NOT NULL DEFAULT '{}'::jsonb,
    requested_by       TEXT NOT NULL,
    requested_role     user_role NOT NULL,
    requested_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    approval_required  BOOLEAN NOT NULL DEFAULT FALSE,
    approved_by        TEXT,
    approved_at        TIMESTAMPTZ,
    decision_note      TEXT,
    -- The window. Not started by run_before means the window was missed, and
    -- the change is cancelled rather than run late into business hours.
    run_after          TIMESTAMPTZ NOT NULL DEFAULT now(),
    run_before         TIMESTAMPTZ,
    max_parallel       INTEGER NOT NULL DEFAULT 5 CHECK (max_parallel BETWEEN 1 AND 50),
    started_at         TIMESTAMPTZ,
    finished_at        TIMESTAMPTZ,
    cancel_requested   BOOLEAN NOT NULL DEFAULT FALSE,
    summary            JSONB NOT NULL DEFAULT '{}'::jsonb,
    -- When approval IS required, nobody approves their own change
    CONSTRAINT chk_no_self_approval
        CHECK (NOT approval_required OR approved_by IS NULL OR approved_by <> requested_by),
    CONSTRAINT chk_window
        CHECK (run_before IS NULL OR run_before > run_after)
);

CREATE INDEX IF NOT EXISTS idx_changes_due   ON changes (state, run_after);
CREATE INDEX IF NOT EXISTS idx_changes_time  ON changes (requested_at DESC);

-- One row per server or VM a change touches, with where it has got to
CREATE TABLE IF NOT EXISTS change_targets (
    change_id        UUID NOT NULL REFERENCES changes(id) ON DELETE CASCADE,
    target_key       TEXT NOT NULL,          -- host id, or vcenter|vm moref
    host_id          UUID REFERENCES hosts(id) ON DELETE SET NULL,
    vcenter          TEXT,
    vm_moref         TEXT,
    label            TEXT NOT NULL,          -- what a person recognises
    -- queued precheck snapshot install reboot wait_boot postcheck inventory
    -- snapshot_cleanup vm_action done failed skipped cancelled
    state            TEXT NOT NULL DEFAULT 'queued',
    step_started_at  TIMESTAMPTZ,
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    current_command  UUID,
    snapshot_moref   TEXT,
    detail           JSONB NOT NULL DEFAULT '{}'::jsonb,
    error            TEXT,
    PRIMARY KEY (change_id, target_key)
);

CREATE INDEX IF NOT EXISTS idx_ctargets_state ON change_targets (state);

-- What happened, in order. Append-only, like the audit log.
CREATE TABLE IF NOT EXISTS change_events (
    id          BIGSERIAL PRIMARY KEY,
    change_id   UUID NOT NULL REFERENCES changes(id) ON DELETE CASCADE,
    target_key  TEXT,
    at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    actor       TEXT NOT NULL,              -- a username, or 'worker'
    event       TEXT NOT NULL,
    ok          BOOLEAN,
    message     TEXT,
    detail      JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_cevents_change ON change_events (change_id, id);

CREATE OR REPLACE FUNCTION change_events_immutable() RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'change_events is append-only; % is not permitted', TG_OP;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_change_events_no_update ON change_events;
CREATE TRIGGER trg_change_events_no_update
    BEFORE UPDATE OR DELETE ON change_events
    FOR EACH ROW EXECUTE FUNCTION change_events_immutable();

-- Agent commands can now belong to a change as well as to a legacy job
ALTER TABLE agent_commands ADD COLUMN IF NOT EXISTS change_id  UUID REFERENCES changes(id) ON DELETE CASCADE;
ALTER TABLE agent_commands ADD COLUMN IF NOT EXISTS target_key TEXT;
CREATE INDEX IF NOT EXISTS idx_cmds_change ON agent_commands (change_id);

-- ---------------------------------------------------------------------------
-- Richer CVE assessments
-- ---------------------------------------------------------------------------
-- Affected products from NVD, in CPE form, so a CVE can be matched against
-- ESXi hosts, vCenters, VM guest operating systems and installed software
ALTER TABLE cve_details ADD COLUMN IF NOT EXISTS cpes JSONB NOT NULL DEFAULT '[]'::jsonb;

ALTER TABLE cve_assessments ADD COLUMN IF NOT EXISTS state          TEXT NOT NULL DEFAULT 'done';
ALTER TABLE cve_assessments ADD COLUMN IF NOT EXISTS progress       INTEGER NOT NULL DEFAULT 0;
ALTER TABLE cve_assessments ADD COLUMN IF NOT EXISTS progress_total INTEGER NOT NULL DEFAULT 0;
ALTER TABLE cve_assessments ADD COLUMN IF NOT EXISTS enrich_error   TEXT;

ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS description      TEXT;
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS cvss_vector      TEXT;
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS cvss_severity    TEXT;
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS epss             NUMERIC(6,5);
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS published        TIMESTAMPTZ;
-- What the CVE affects, as NVD describes it: vendor, product, kind
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS products         JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS product_classes  TEXT[] NOT NULL DEFAULT '{}';
-- Where those products were found in our inventory, and with what certainty
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS inventory_matches JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS exposure         TEXT;
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS ai_summary       TEXT;
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS ai_model         TEXT;
ALTER TABLE cve_assessment_items ADD COLUMN IF NOT EXISTS enriched_at      TIMESTAMPTZ;

-- ---------------------------------------------------------------------------
-- Worker heartbeat: a stopped worker otherwise looks like changes that
-- simply never start
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS worker_heartbeat (
    name        TEXT PRIMARY KEY,
    beat_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    started_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    detail      JSONB NOT NULL DEFAULT '{}'::jsonb
);

INSERT INTO schema_version (version, description)
VALUES (9, 'users and roles, change engine, enriched CVE assessments')
ON CONFLICT (version) DO NOTHING;
