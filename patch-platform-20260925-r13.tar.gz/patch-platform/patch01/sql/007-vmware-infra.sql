-- ===========================================================================
-- PATCH-01 : schema 007 - VMware infrastructure
--
-- Applied after 006. Idempotent. Read-only inventory throughout.
--
-- Extends the VM list into the whole picture: which VM runs on which ESXi
-- host, in which cluster and datacenter, on which datastores, attached to
-- which networks, and the state of each of those.
--
-- Every row carries its vCenter, because names are only unique within one
-- vCenter, and morefs (vCenter's internal ids) certainly are not.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Clusters
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vm_clusters (
    vcenter        TEXT NOT NULL REFERENCES vcenters(name) ON DELETE CASCADE,
    moref          TEXT NOT NULL,
    name           TEXT,
    datacenter     TEXT,
    num_hosts      INTEGER,
    num_effective_hosts INTEGER,
    total_cpu_mhz  BIGINT,
    total_memory_mb BIGINT,
    num_cpu_cores  INTEGER,
    drs_enabled    BOOLEAN,
    ha_enabled     BOOLEAN,
    synced_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (vcenter, moref)
);

-- ---------------------------------------------------------------------------
-- ESXi hosts
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS esxi_hosts (
    vcenter          TEXT NOT NULL REFERENCES vcenters(name) ON DELETE CASCADE,
    moref            TEXT NOT NULL,
    name             TEXT,
    cluster          TEXT,
    datacenter       TEXT,
    vendor           TEXT,
    model            TEXT,
    cpu_model        TEXT,
    cpu_sockets      INTEGER,
    cpu_cores        INTEGER,
    cpu_threads      INTEGER,
    cpu_mhz          INTEGER,
    memory_mb        BIGINT,
    esxi_version     TEXT,
    esxi_build       TEXT,
    esxi_full_name   TEXT,
    connection_state TEXT,          -- connected, disconnected, notResponding
    power_state      TEXT,
    maintenance_mode BOOLEAN,
    boot_time        TIMESTAMPTZ,
    uptime_seconds   BIGINT,
    cpu_usage_mhz    INTEGER,
    memory_usage_mb  INTEGER,
    vm_count         INTEGER,
    synced_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (vcenter, moref)
);

CREATE INDEX IF NOT EXISTS idx_esxi_name    ON esxi_hosts (name);
CREATE INDEX IF NOT EXISTS idx_esxi_cluster ON esxi_hosts (vcenter, cluster);

-- ---------------------------------------------------------------------------
-- Datastores
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS datastores (
    vcenter          TEXT NOT NULL REFERENCES vcenters(name) ON DELETE CASCADE,
    moref            TEXT NOT NULL,
    name             TEXT,
    type             TEXT,          -- VMFS, NFS, NFS41, vsan, VVOL
    datacenter       TEXT,
    capacity_mb      BIGINT,
    free_mb          BIGINT,
    -- Provisioned beyond capacity is normal with thin disks, and worth seeing
    uncommitted_mb   BIGINT,
    accessible       BOOLEAN,
    maintenance_mode TEXT,
    host_count       INTEGER,
    vm_count         INTEGER,
    synced_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (vcenter, moref)
);

CREATE INDEX IF NOT EXISTS idx_ds_name ON datastores (name);

-- ---------------------------------------------------------------------------
-- Networks and port groups
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vm_networks (
    vcenter     TEXT NOT NULL REFERENCES vcenters(name) ON DELETE CASCADE,
    moref       TEXT NOT NULL,
    name        TEXT,
    kind        TEXT,               -- Network, DistributedVirtualPortgroup, OpaqueNetwork
    datacenter  TEXT,
    vlan        TEXT,
    accessible  BOOLEAN,
    vm_count    INTEGER,
    synced_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (vcenter, moref)
);

-- ---------------------------------------------------------------------------
-- VM relationships and hardware detail
-- ---------------------------------------------------------------------------
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS esxi_moref        TEXT;
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS folder_path       TEXT;
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS hardware_version  TEXT;
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS tools_version     TEXT;
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS boot_time         TIMESTAMPTZ;
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS storage_committed_mb   BIGINT;
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS storage_provisioned_mb BIGINT;
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS cpu_usage_mhz     INTEGER;
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS memory_usage_mb   INTEGER;
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS annotation        TEXT;
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS datastore_names   TEXT[] DEFAULT '{}';
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS network_names     TEXT[] DEFAULT '{}';
-- Disks as they are configured: size, thin or thick, and where each one lives
ALTER TABLE vm_inventory ADD COLUMN IF NOT EXISTS disks             JSONB DEFAULT '[]'::jsonb;

CREATE INDEX IF NOT EXISTS idx_vm_esxi ON vm_inventory (vcenter, esxi_moref);

-- ---------------------------------------------------------------------------
-- The map view, v_vm_map, is defined in 008-fix-vm-map.sql, not here.
--
-- It used to be created here as well, with fewer columns. Because every
-- migration is re-applied on each run, this file then tried to replace 008's
-- wider view with a narrower one, which PostgreSQL refuses ("cannot drop
-- columns from view"), and the run stopped here. One owner per view.
-- ---------------------------------------------------------------------------

INSERT INTO schema_version (version, description)
VALUES (7, 'VMware infrastructure: ESXi hosts, datastores, networks, clusters, VM placement')
ON CONFLICT (version) DO NOTHING;
