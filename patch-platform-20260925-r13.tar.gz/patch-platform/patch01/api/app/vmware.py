"""
PATCH-01 : VMware vCenter inventory (read-only)

Reads every configured vCenter, records its VMs and their snapshots, and
links each VM to the PATCH-01 server running inside it.

Read-only by construction: this module calls no method that changes a VM.
It only retrieves properties. Snapshot creation arrives with patch jobs, in
separate code, and needs extra vCenter permissions the read-only account
does not have.

Configuration: one pair of files per vCenter in /etc/vcenter (mounted
read-only from /patch/secrets/vcenter):

    <name>.env   VC_HOST, VC_PORT, VC_USER, VC_PASSWORD_B64
    <name>.crt   the certificate chain vCenter presented, pinned at setup

Run inside the API image, on the patchnet network:
    python -m app.vmware --list
    python -m app.vmware --test NAME
    python -m app.vmware --sync [NAME]
"""

import argparse
import base64
import glob
import json
import logging
import os
import re
import socket
import ssl
import sys
import time
from datetime import datetime, timezone

log = logging.getLogger("patchapi.vmware")

CONFIG_DIR = os.environ.get("VCENTER_CONFIG_DIR", "/etc/vcenter")
BATCH = 500
NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,39}$")
WRITE_SUFFIX = "-write"

LINUX_HINTS = ("linux", "red hat", "rhel", "centos", "oracle", "ubuntu",
               "debian", "suse", "rocky", "alma")

VM_PROPS = [
    "name", "config.uuid", "config.instanceUuid", "config.template",
    "config.guestFullName", "config.hardware.numCPU", "config.hardware.memoryMB",
    "config.version", "config.annotation", "config.hardware.device",
    "runtime.powerState", "runtime.host", "runtime.bootTime",
    "guest.hostName", "guest.ipAddress", "guest.net", "guest.guestFamily",
    "guest.toolsRunningStatus", "guest.toolsVersionStatus2", "guest.toolsVersion",
    "summary.storage.committed", "summary.storage.uncommitted",
    "summary.quickStats.overallCpuUsage", "summary.quickStats.guestMemoryUsage",
    "datastore", "network", "parent",
    "snapshot",
]

HOST_PROPS = [
    "name", "parent",
    "summary.hardware.vendor", "summary.hardware.model",
    "summary.hardware.cpuModel", "summary.hardware.numCpuPkgs",
    "summary.hardware.numCpuCores", "summary.hardware.numCpuThreads",
    "summary.hardware.cpuMhz", "summary.hardware.memorySize",
    "summary.config.product.version", "summary.config.product.build",
    "summary.config.product.fullName",
    "runtime.connectionState", "runtime.powerState", "runtime.inMaintenanceMode",
    "runtime.bootTime",
    "summary.quickStats.overallCpuUsage", "summary.quickStats.overallMemoryUsage",
    "vm",
]

DS_PROPS = ["name", "summary.type", "summary.capacity", "summary.freeSpace",
            "summary.uncommitted", "summary.accessible", "summary.maintenanceMode",
            "host", "vm", "parent"]

NET_PROPS = ["name", "summary.accessible", "vm"]

CLUSTER_PROPS = ["name", "parent", "summary.numHosts", "summary.numEffectiveHosts",
                 "summary.totalCpu", "summary.totalMemory", "summary.numCpuCores",
                 "configuration.drsConfig", "configuration.dasConfig"]


# ---------------------------------------------------------------------------
# Pure functions: no network, no pyVmomi. These decide correctness.
# ---------------------------------------------------------------------------

def norm_uuid(u):
    """Canonical lowercase 8-4-4-4-12 form, or None if it is not a UUID."""
    if not u:
        return None
    h = re.sub(r"[^0-9a-fA-F]", "", str(u)).lower()
    if len(h) != 32 or h == "0" * 32 or h == "f" * 32:
        return None
    return f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"


def swap_uuid(u):
    """The same UUID with its first three fields byte-reversed.

    SMBIOS stores the first three fields little-endian, and not every layer
    agrees on whether to swap them back. So the UUID a Linux guest reads can
    be the byte-swapped form of the one vCenter reports. Matching accepts
    either, which is safe: the two forms of one UUID cannot collide with a
    different machine's UUID except by the same chance as any UUID clash.
    """
    n = norm_uuid(u)
    if not n:
        return None
    a, b, c, d, e = n.split("-")
    rev = lambda x: "".join(reversed([x[i:i + 2] for i in range(0, len(x), 2)]))
    return f"{rev(a)}-{rev(b)}-{rev(c)}-{d}-{e}"


def uuid_forms(u):
    n = norm_uuid(u)
    return {x for x in (n, swap_uuid(n)) if x}


def is_linux_guest(family, full_name):
    if (family or "").lower() == "linuxguest":
        return True
    fn = (full_name or "").lower()
    return any(h in fn for h in LINUX_HINTS) and "windows" not in fn


def short_name(n):
    return (n or "").strip().lower().split(".")[0] or None


def flatten_snapshots(info):
    """Turn vCenter's snapshot tree into a flat list, oldest first.

    Works on anything shaped like pyVmomi's VirtualMachineSnapshotInfo,
    which is what makes it testable without a vCenter.
    """
    out = []
    if not info:
        return out
    cur = getattr(getattr(info, "currentSnapshot", None), "_moId", None)

    def walk(nodes, depth):
        for s in nodes or []:
            ref = getattr(getattr(s, "snapshot", None), "_moId", None)
            created = getattr(s, "createTime", None)
            out.append({
                "name": (getattr(s, "name", "") or "")[:200],
                "description": (getattr(s, "description", "") or "")[:500],
                "created": created.isoformat() if created else None,
                "moref": ref,
                "current": ref is not None and ref == cur,
                "depth": depth,
                "quiesced": bool(getattr(s, "quiesced", False)),
            })
            walk(getattr(s, "childSnapshotList", None), depth + 1)

    walk(getattr(info, "rootSnapshotList", None), 0)
    out.sort(key=lambda x: x["created"] or "")
    return out


def match_vms(vms, hosts):
    """Link VMs to PATCH-01 servers. Returns {vm_key: (host_id, method)}.

    Order of trust: hardware UUID, then guest hostname, then IP address.
    A hardware UUID shared by several VMs (a clone that kept its UUID) is
    treated as ambiguous rather than guessed, unless the hostname settles it.
    """
    by_uuid, by_name, by_ip = {}, {}, {}
    for h in hosts:
        for f in uuid_forms(h.get("hardware_uuid")):
            by_uuid.setdefault(f, []).append(h)
        n = short_name(h.get("hostname"))
        if n:
            by_name.setdefault(n, []).append(h)
        if h.get("agent_ip"):
            by_ip.setdefault(str(h["agent_ip"]), []).append(h)

    # How many VMs claim each UUID, to detect clones
    uuid_claims = {}
    for v in vms:
        for f in uuid_forms(v.get("bios_uuid")):
            uuid_claims[f] = uuid_claims.get(f, 0) + 1

    result = {}
    for v in vms:
        key = v["key"]
        cands = []
        for f in uuid_forms(v.get("bios_uuid")):
            cands.extend(by_uuid.get(f, []))
        cands = list({c["id"]: c for c in cands}.values())
        vname = short_name(v.get("guest_hostname")) or short_name(v.get("name"))

        if len(cands) == 1:
            clones = max((uuid_claims.get(f, 0) for f in uuid_forms(v.get("bios_uuid"))), default=0)
            if clones > 1:
                # Several VMs share this UUID; only accept if the name agrees
                if vname and short_name(cands[0]["hostname"]) == vname:
                    result[key] = (cands[0]["id"], "hardware_uuid+hostname")
                else:
                    result[key] = (None, "ambiguous")
            else:
                result[key] = (cands[0]["id"], "hardware_uuid")
            continue
        if len(cands) > 1:
            named = [c for c in cands if short_name(c["hostname"]) == vname]
            result[key] = (named[0]["id"], "hardware_uuid+hostname") if len(named) == 1 \
                else (None, "ambiguous")
            continue

        # No UUID match: fall back, but only on a unique hit
        if vname and len(by_name.get(vname, [])) == 1:
            result[key] = (by_name[vname][0]["id"], "hostname")
            continue
        ip_hits = {c["id"]: c for ip in (v.get("guest_ips") or []) for c in by_ip.get(ip, [])}
        if len(ip_hits) == 1:
            result[key] = (next(iter(ip_hits)), "ip")
            continue
        result[key] = (None, None)
    return result


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

def _read_env(path):
    out = {}
    with open(path) as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            out[k.strip()] = v.strip()
    return out


def load_vcenters():
    vcs = []
    for env in sorted(glob.glob(os.path.join(CONFIG_DIR, "*.env"))):
        name = os.path.basename(env)[:-4]
        # <name>-write.env holds the separate write account for that vCenter,
        # not a vCenter of its own
        if name.endswith(WRITE_SUFFIX):
            continue
        if not NAME_RE.match(name):
            log.warning("skipping %s: invalid name", env)
            continue
        e = _read_env(env)
        try:
            pw = base64.b64decode(e.get("VC_PASSWORD_B64", "")).decode()
        except Exception:
            pw = ""
        vcs.append({
            "name": name,
            "host": e.get("VC_HOST", ""),
            "port": int(e.get("VC_PORT", "443") or 443),
            "user": e.get("VC_USER", ""),
            "password": pw,
            "cert": os.path.join(CONFIG_DIR, name + ".crt"),
        })
    return vcs


def ssl_context(certfile):
    """Trust only the certificate chain pinned at setup.

    PARTIAL_CHAIN lets a pinned leaf or intermediate act as the trust anchor,
    so pinning works whether vCenter presents its whole chain or only its own
    certificate. The hostname is still checked.
    """
    if not os.path.exists(certfile):
        raise RuntimeError(f"no pinned certificate at {certfile}")
    ctx = ssl.create_default_context(cafile=certfile)
    ctx.verify_flags |= ssl.VERIFY_X509_PARTIAL_CHAIN
    return ctx


# ---------------------------------------------------------------------------
# vCenter access
# ---------------------------------------------------------------------------

def connect(vc):
    from pyVim.connect import SmartConnect
    socket.setdefaulttimeout(60)
    return SmartConnect(host=vc["host"], user=vc["user"], pwd=vc["password"],
                        port=vc["port"], sslContext=ssl_context(vc["cert"]),
                        connectionPoolTimeout=60)


def disconnect(si):
    try:
        from pyVim.connect import Disconnect
        Disconnect(si)
    except Exception:  # noqa: BLE001
        pass


def collect(si, vimtype, props):
    """Fetch one set of properties for every object of a type, in batches.

    A single PropertyCollector pass rather than walking objects one by one,
    so thousands of VMs cost a handful of round trips.
    """
    from pyVmomi import vim, vmodl
    content = si.RetrieveContent()
    view = content.viewManager.CreateContainerView(content.rootFolder, [vimtype], True)
    try:
        ts = vmodl.query.PropertyCollector.TraversalSpec(
            name="traverse", path="view", skip=False, type=vim.view.ContainerView)
        obj = vmodl.query.PropertyCollector.ObjectSpec(obj=view, skip=True, selectSet=[ts])
        prop = vmodl.query.PropertyCollector.PropertySpec(type=vimtype, pathSet=props, all=False)
        spec = vmodl.query.PropertyCollector.FilterSpec(objectSet=[obj], propSet=[prop])
        pc = content.propertyCollector
        res = pc.RetrievePropertiesEx([spec], vmodl.query.PropertyCollector.RetrieveOptions(maxObjects=BATCH))
        out = []
        while res:
            for o in res.objects or []:
                out.append((o.obj, {p.name: p.val for p in (o.propSet or [])}))
            if not res.token:
                break
            res = pc.ContinueRetrievePropertiesEx(res.token)
        return out
    finally:
        view.Destroy()


def _bytes_to_mb(v):
    try:
        return int(v) // (1024 * 1024)
    except (TypeError, ValueError):
        return None


def disks_of(devices):
    """Configured virtual disks: size, provisioning and where each one lives."""
    out = []
    for dev in devices or []:
        if type(dev).__name__ != "VirtualDisk":
            continue
        backing = getattr(dev, "backing", None)
        thin = getattr(backing, "thinProvisioned", None)
        out.append({
            "label": getattr(getattr(dev, "deviceInfo", None), "label", None),
            "size_gb": round((getattr(dev, "capacityInKB", 0) or 0) / 1048576, 1),
            "thin": bool(thin) if thin is not None else None,
            "file": getattr(backing, "fileName", None),
            "datastore": (getattr(backing, "fileName", "") or "").split("]")[0].lstrip("["),
        })
    return out


def fetch_infrastructure(si):
    """Clusters, ESXi hosts, datastores and networks, with their placement."""
    from pyVmomi import vim

    nodes = {}
    for t in (vim.HostSystem, vim.ClusterComputeResource, vim.ComputeResource,
              vim.Folder, vim.Datacenter):
        props = ["name"] if t is vim.Datacenter else ["name", "parent"]
        for o, d in collect(si, t, props):
            nodes[o._moId] = {"type": type(o).__name__, "name": d.get("name"),
                              "parent": getattr(d.get("parent"), "_moId", None)}

    def ancestor(moid, typenames):
        seen = 0
        while moid and seen < 50:
            n = nodes.get(moid)
            if not n:
                return None
            if any(t in n["type"] for t in typenames):
                return n["name"]
            moid = n["parent"]
            seen += 1
        return None

    def path_of(moid, stop_types=("Datacenter",)):
        """Folder path as vCenter shows it, outermost first."""
        parts, seen = [], 0
        while moid and seen < 50:
            n = nodes.get(moid)
            if not n or any(t in n["type"] for t in stop_types):
                break
            if "Folder" in n["type"] and n["name"] not in ("vm", "host", "datastore", "network"):
                parts.append(n["name"])
            moid = n["parent"]
            seen += 1
        return "/".join(reversed(parts)) or None

    clusters = []
    for o, d in collect(si, vim.ClusterComputeResource, CLUSTER_PROPS):
        clusters.append({
            "moref": o._moId, "name": d.get("name"),
            "datacenter": ancestor(o._moId, ("Datacenter",)),
            "num_hosts": d.get("summary.numHosts"),
            "num_effective_hosts": d.get("summary.numEffectiveHosts"),
            "total_cpu_mhz": d.get("summary.totalCpu"),
            "total_memory_mb": _bytes_to_mb(d.get("summary.totalMemory")),
            "num_cpu_cores": d.get("summary.numCpuCores"),
            "drs_enabled": getattr(d.get("configuration.drsConfig"), "enabled", None),
            "ha_enabled": getattr(d.get("configuration.dasConfig"), "enabled", None),
        })

    hosts = []
    host_names = {}
    for o, d in collect(si, vim.HostSystem, HOST_PROPS):
        boot = d.get("runtime.bootTime")
        host_names[o._moId] = d.get("name")
        hosts.append({
            "moref": o._moId, "name": d.get("name"),
            "cluster": ancestor(o._moId, ("ClusterComputeResource",)),
            "datacenter": ancestor(o._moId, ("Datacenter",)),
            "vendor": d.get("summary.hardware.vendor"),
            "model": d.get("summary.hardware.model"),
            "cpu_model": (d.get("summary.hardware.cpuModel") or "").strip() or None,
            "cpu_sockets": d.get("summary.hardware.numCpuPkgs"),
            "cpu_cores": d.get("summary.hardware.numCpuCores"),
            "cpu_threads": d.get("summary.hardware.numCpuThreads"),
            "cpu_mhz": d.get("summary.hardware.cpuMhz"),
            "memory_mb": _bytes_to_mb(d.get("summary.hardware.memorySize")),
            "esxi_version": d.get("summary.config.product.version"),
            "esxi_build": d.get("summary.config.product.build"),
            "esxi_full_name": d.get("summary.config.product.fullName"),
            "connection_state": str(d.get("runtime.connectionState") or ""),
            "power_state": str(d.get("runtime.powerState") or ""),
            "maintenance_mode": d.get("runtime.inMaintenanceMode"),
            "boot_time": boot.isoformat() if boot else None,
            "uptime_seconds": int((datetime.now(timezone.utc) - boot).total_seconds()) if boot else None,
            "cpu_usage_mhz": d.get("summary.quickStats.overallCpuUsage"),
            "memory_usage_mb": d.get("summary.quickStats.overallMemoryUsage"),
            "vm_count": len(d.get("vm") or []),
        })

    datastores, ds_names = [], {}
    for o, d in collect(si, vim.Datastore, DS_PROPS):
        ds_names[o._moId] = d.get("name")
        datastores.append({
            "moref": o._moId, "name": d.get("name"),
            "type": d.get("summary.type"),
            "datacenter": ancestor(o._moId, ("Datacenter",)),
            "capacity_mb": _bytes_to_mb(d.get("summary.capacity")),
            "free_mb": _bytes_to_mb(d.get("summary.freeSpace")),
            "uncommitted_mb": _bytes_to_mb(d.get("summary.uncommitted")),
            "accessible": d.get("summary.accessible"),
            "maintenance_mode": d.get("summary.maintenanceMode"),
            "host_count": len(d.get("host") or []),
            "vm_count": len(d.get("vm") or []),
        })

    networks, net_names = [], {}
    for t in (vim.Network, vim.dvs.DistributedVirtualPortgroup):
        try:
            found = collect(si, t, NET_PROPS)
        except Exception as e:  # noqa: BLE001 - a type may not exist on older vCenters
            log.warning("could not read %s: %s", t.__name__, e)
            continue
        for o, d in found:
            if o._moId in net_names:
                continue
            net_names[o._moId] = d.get("name")
            networks.append({
                "moref": o._moId, "name": d.get("name"),
                "kind": type(o).__name__,
                "datacenter": ancestor(o._moId, ("Datacenter",)),
                "accessible": d.get("summary.accessible"),
                "vm_count": len(d.get("vm") or []),
            })

    return {"clusters": clusters, "hosts": hosts, "datastores": datastores,
            "networks": networks, "nodes": nodes, "host_names": host_names,
            "ds_names": ds_names, "net_names": net_names,
            "ancestor": ancestor, "path_of": path_of}


def fetch_inventory(si, infra):
    """Every VM with its placement, guest facts, hardware and snapshots."""
    from pyVmomi import vim
    nodes = infra["nodes"]
    ancestor = infra["ancestor"]
    path_of = infra["path_of"]
    ds_names = infra["ds_names"]
    net_names = infra["net_names"]

    vms = []
    for o, d in collect(si, vim.VirtualMachine, VM_PROPS):
        if d.get("config.template"):
            continue
        host_moid = getattr(d.get("runtime.host"), "_moId", None)
        ips = set()
        if d.get("guest.ipAddress"):
            ips.add(d["guest.ipAddress"])
        for nic in d.get("guest.net") or []:
            for ip in getattr(nic, "ipAddress", None) or []:
                if ip and ":" not in ip and not ip.startswith("169.254."):
                    ips.add(ip)
        snaps = flatten_snapshots(d.get("snapshot"))
        boot = d.get("runtime.bootTime")
        vms.append({
            "key": o._moId,
            "moref": o._moId,
            "esxi_moref": host_moid,
            "folder_path": path_of(getattr(d.get("parent"), "_moId", None)),
            "hardware_version": d.get("config.version"),
            "tools_version": d.get("guest.toolsVersion"),
            "boot_time": boot.isoformat() if boot else None,
            "storage_committed_mb": _bytes_to_mb(d.get("summary.storage.committed")),
            "storage_provisioned_mb": (
                (_bytes_to_mb(d.get("summary.storage.committed")) or 0) +
                (_bytes_to_mb(d.get("summary.storage.uncommitted")) or 0)) or None,
            "cpu_usage_mhz": d.get("summary.quickStats.overallCpuUsage"),
            "memory_usage_mb": d.get("summary.quickStats.guestMemoryUsage"),
            "annotation": (d.get("config.annotation") or "")[:2000] or None,
            "datastore_names": sorted({ds_names.get(getattr(x, "_moId", None))
                                       for x in (d.get("datastore") or [])
                                       if ds_names.get(getattr(x, "_moId", None))}),
            "network_names": sorted({net_names.get(getattr(x, "_moId", None))
                                     for x in (d.get("network") or [])
                                     if net_names.get(getattr(x, "_moId", None))}),
            "disks": disks_of(d.get("config.hardware.device")),
            "name": d.get("name"),
            "bios_uuid": norm_uuid(d.get("config.uuid")),
            "instance_uuid": norm_uuid(d.get("config.instanceUuid")),
            "power_state": str(d.get("runtime.powerState") or ""),
            "guest_os": d.get("config.guestFullName"),
            "guest_family": d.get("guest.guestFamily"),
            "is_linux": is_linux_guest(d.get("guest.guestFamily"), d.get("config.guestFullName")),
            "guest_hostname": d.get("guest.hostName"),
            "guest_ips": sorted(ips),
            "tools_running": d.get("guest.toolsRunningStatus"),
            "tools_version_status": d.get("guest.toolsVersionStatus2"),
            "esxi_host": nodes.get(host_moid, {}).get("name"),
            "cluster": ancestor(host_moid, ("ClusterComputeResource",)),
            "datacenter": ancestor(host_moid, ("Datacenter",)),
            "num_cpu": d.get("config.hardware.numCPU"),
            "memory_mb": d.get("config.hardware.memoryMB"),
            "snapshots": snaps,
            "snapshot_count": len(snaps),
            "oldest_snapshot_at": snaps[0]["created"] if snaps else None,
        })
    return vms


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

def _db():
    import psycopg
    from psycopg.rows import dict_row
    return psycopg.connect(
        host=os.environ.get("PATCHDB_HOST", "postgres"),
        port=int(os.environ.get("PATCHDB_PORT", "5432")),
        dbname=os.environ.get("PATCHDB_NAME", "patchdb"),
        user=os.environ.get("PATCHDB_USER", "patchapi"),
        password=os.environ.get("PATCHDB_PASSWORD", ""),
        row_factory=dict_row, connect_timeout=15,
    )


def sync_one(conn, vc):
    started = time.time()
    conn.execute(
        """INSERT INTO vcenters (name, host) VALUES (%s,%s)
           ON CONFLICT (name) DO UPDATE SET host=EXCLUDED.host, updated_at=now()""",
        (vc["name"], vc["host"]))
    sync_id = conn.execute(
        "INSERT INTO vcenter_syncs (vcenter) VALUES (%s) RETURNING id",
        (vc["name"],)).fetchone()["id"]
    conn.commit()

    si = None
    try:
        si = connect(vc)
        about = si.content.about
        version = f"{about.version} build {about.build}"
        infra = fetch_infrastructure(si)
        vms = fetch_inventory(si, infra)
    except Exception as e:  # noqa: BLE001 - recorded per vCenter
        msg = str(e).replace(vc["password"], "***") if vc["password"] else str(e)
        conn.execute(
            """UPDATE vcenter_syncs SET finished_at=now(), ok=FALSE, error=%s,
                      duration_ms=%s WHERE id=%s""",
            (msg[:1000], int((time.time() - started) * 1000), sync_id))
        conn.execute(
            """UPDATE vcenters SET last_sync_at=now(), last_ok=FALSE, last_error=%s,
                      updated_at=now() WHERE name=%s""",
            (msg[:1000], vc["name"]))
        conn.commit()
        return {"vcenter": vc["name"], "ok": False, "error": msg[:300]}
    finally:
        if si:
            disconnect(si)

    hosts = conn.execute(
        """SELECT id, hostname, hardware_uuid, host(agent_ip) AS agent_ip
             FROM hosts WHERE status <> 'decommissioned'""").fetchall()
    links = match_vms(vms, hosts)

    def upsert(cur, tbl, cols, rows_, keys=("vcenter", "moref")):
        if not rows_:
            return
        ph = ", ".join(["%s"] * (len(cols) + 1))
        upd = ", ".join(f"{c}=EXCLUDED.{c}" for c in cols)
        cur.executemany(
            f"""INSERT INTO {tbl} (vcenter, {", ".join(cols)}, synced_at)
                VALUES (%s, {ph.rsplit(', ', 1)[0]}, now())
                ON CONFLICT ({", ".join(keys)}) DO UPDATE SET {upd}, synced_at=now()""",
            [[vc["name"]] + [r.get(c) for c in cols] for r in rows_])

    CLUSTER_COLS = ["moref", "name", "datacenter", "num_hosts", "num_effective_hosts",
                    "total_cpu_mhz", "total_memory_mb", "num_cpu_cores",
                    "drs_enabled", "ha_enabled"]
    HOST_COLS = ["moref", "name", "cluster", "datacenter", "vendor", "model", "cpu_model",
                 "cpu_sockets", "cpu_cores", "cpu_threads", "cpu_mhz", "memory_mb",
                 "esxi_version", "esxi_build", "esxi_full_name", "connection_state",
                 "power_state", "maintenance_mode", "boot_time", "uptime_seconds",
                 "cpu_usage_mhz", "memory_usage_mb", "vm_count"]
    DS_COLS = ["moref", "name", "type", "datacenter", "capacity_mb", "free_mb",
               "uncommitted_mb", "accessible", "maintenance_mode", "host_count", "vm_count"]
    NET_COLS = ["moref", "name", "kind", "datacenter", "accessible", "vm_count"]

    rows = []
    for v in vms:
        hid, method = links.get(v["key"], (None, None))
        rows.append((vc["name"], v["moref"], v["name"], v["bios_uuid"], v["instance_uuid"],
                     v["power_state"], v["guest_os"], v["guest_family"], v["is_linux"],
                     v["guest_hostname"], v["guest_ips"], v["tools_running"],
                     v["tools_version_status"], v["esxi_host"], v["cluster"], v["datacenter"],
                     v["num_cpu"], v["memory_mb"], v["snapshot_count"], v["oldest_snapshot_at"],
                     json.dumps(v["snapshots"]), hid, method,
                     v["esxi_moref"], v["folder_path"], v["hardware_version"],
                     v["tools_version"], v["boot_time"], v["storage_committed_mb"],
                     v["storage_provisioned_mb"], v["cpu_usage_mhz"], v["memory_usage_mb"],
                     v["annotation"], v["datastore_names"], v["network_names"],
                     json.dumps(v["disks"])))

    with conn.transaction():
        with conn.cursor() as cur:
            cur.executemany(
                """INSERT INTO vm_inventory
                     (vcenter, moref, name, bios_uuid, instance_uuid, power_state,
                      guest_os, guest_family, is_linux, guest_hostname, guest_ips,
                      tools_running, tools_version_status, esxi_host, cluster,
                      datacenter, num_cpu, memory_mb, snapshot_count,
                      oldest_snapshot_at, snapshots, host_id, match_method, synced_at,
                      esxi_moref, folder_path, hardware_version, tools_version,
                      boot_time, storage_committed_mb, storage_provisioned_mb,
                      cpu_usage_mhz, memory_usage_mb, annotation, datastore_names,
                      network_names, disks)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,now(),
                           %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                   ON CONFLICT (vcenter, moref) DO UPDATE SET
                     name=EXCLUDED.name, bios_uuid=EXCLUDED.bios_uuid,
                     instance_uuid=EXCLUDED.instance_uuid, power_state=EXCLUDED.power_state,
                     guest_os=EXCLUDED.guest_os, guest_family=EXCLUDED.guest_family,
                     is_linux=EXCLUDED.is_linux, guest_hostname=EXCLUDED.guest_hostname,
                     guest_ips=EXCLUDED.guest_ips, tools_running=EXCLUDED.tools_running,
                     tools_version_status=EXCLUDED.tools_version_status,
                     esxi_host=EXCLUDED.esxi_host, cluster=EXCLUDED.cluster,
                     datacenter=EXCLUDED.datacenter, num_cpu=EXCLUDED.num_cpu,
                     memory_mb=EXCLUDED.memory_mb, snapshot_count=EXCLUDED.snapshot_count,
                     oldest_snapshot_at=EXCLUDED.oldest_snapshot_at,
                     snapshots=EXCLUDED.snapshots, host_id=EXCLUDED.host_id,
                     match_method=EXCLUDED.match_method, synced_at=now(),
                     esxi_moref=EXCLUDED.esxi_moref, folder_path=EXCLUDED.folder_path,
                     hardware_version=EXCLUDED.hardware_version,
                     tools_version=EXCLUDED.tools_version, boot_time=EXCLUDED.boot_time,
                     storage_committed_mb=EXCLUDED.storage_committed_mb,
                     storage_provisioned_mb=EXCLUDED.storage_provisioned_mb,
                     cpu_usage_mhz=EXCLUDED.cpu_usage_mhz,
                     memory_usage_mb=EXCLUDED.memory_usage_mb,
                     annotation=EXCLUDED.annotation,
                     datastore_names=EXCLUDED.datastore_names,
                     network_names=EXCLUDED.network_names, disks=EXCLUDED.disks""",
                rows)
            # Infrastructure, and anything that has gone since the last sync
            upsert(cur, "vm_clusters", CLUSTER_COLS, infra["clusters"])
            upsert(cur, "esxi_hosts", HOST_COLS, infra["hosts"])
            upsert(cur, "datastores", DS_COLS, infra["datastores"])
            upsert(cur, "vm_networks", NET_COLS, infra["networks"])
        for tbl, items in (("vm_clusters", infra["clusters"]), ("esxi_hosts", infra["hosts"]),
                           ("datastores", infra["datastores"]), ("vm_networks", infra["networks"])):
            conn.execute(f"DELETE FROM {tbl} WHERE vcenter=%s AND NOT (moref = ANY(%s))",
                         (vc["name"], [x["moref"] for x in items]))
        # VMs gone from this vCenter since the last sync
        seen = [v["moref"] for v in vms]
        conn.execute("DELETE FROM vm_inventory WHERE vcenter=%s AND NOT (moref = ANY(%s))",
                     (vc["name"], seen))
        linux = sum(1 for v in vms if v["is_linux"])
        matched = sum(1 for k, (hid, _) in links.items() if hid)
        conn.execute(
            """UPDATE vcenter_syncs SET finished_at=now(), ok=TRUE, vms=%s, linux_vms=%s,
                      matched=%s, duration_ms=%s WHERE id=%s""",
            (len(vms), linux, matched, int((time.time() - started) * 1000), sync_id))
        conn.execute(
            """UPDATE vcenters SET last_sync_at=now(), last_ok=TRUE, last_error=NULL,
                      vm_count=%s, version=%s, updated_at=now() WHERE name=%s""",
            (len(vms), version, vc["name"]))
    return {"vcenter": vc["name"], "ok": True, "version": version, "vms": len(vms),
            "linux": linux, "matched": matched,
            "hosts": len(infra["hosts"]), "clusters": len(infra["clusters"]),
            "datastores": len(infra["datastores"]), "networks": len(infra["networks"]),
            "seconds": round(time.time() - started, 1)}


def sync(only=None):
    vcs = [v for v in load_vcenters() if not only or v["name"] == only]
    if not vcs:
        print("no vCenters configured" + (f" named {only}" if only else ""))
        return False
    ok = True
    with _db() as conn:
        for vc in vcs:
            # One vCenter failing never stops the others
            r = sync_one(conn, vc)
            ok = ok and r["ok"]
            print(json.dumps(r))
    return ok


def test(name):
    vc = next((v for v in load_vcenters() if v["name"] == name), None)
    if not vc:
        print(json.dumps({"ok": False, "error": f"no vCenter named {name}"}))
        return False
    si = None
    try:
        si = connect(vc)
        a = si.content.about
        from pyVmomi import vim
        n = len(collect(si, vim.VirtualMachine, ["name"]))
        print(json.dumps({"ok": True, "vcenter": name, "product": a.fullName,
                          "version": a.version, "build": a.build, "vms_visible": n,
                          "tls": "verified against pinned certificate"}))
        return True
    except ssl.SSLCertVerificationError as e:
        print(json.dumps({"ok": False, "error": f"certificate does not match the pin: {e}"}))
    except Exception as e:  # noqa: BLE001
        msg = str(e).replace(vc["password"], "***") if vc["password"] else str(e)
        print(json.dumps({"ok": False, "error": msg[:400]}))
    finally:
        if si:
            disconnect(si)
    return False


def main():
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--test", metavar="NAME")
    ap.add_argument("--sync", nargs="?", const="", metavar="NAME")
    a = ap.parse_args()
    if a.list:
        for v in load_vcenters():
            print(json.dumps({"name": v["name"], "host": v["host"], "user": v["user"],
                              "pinned": os.path.exists(v["cert"])}))
        return
    if a.test:
        sys.exit(0 if test(a.test) else 1)
    if a.sync is not None:
        sys.exit(0 if sync(a.sync or None) else 1)
    ap.print_help()


if __name__ == "__main__":
    main()



# ---------------------------------------------------------------------------
# Write operations
#
# These use a separate vCenter account per vCenter, in <name>-write.env,
# holding only what they need: snapshot management and guest power
# operations. The read-only sync account cannot perform any of them.
#
# Deliberately absent: hard power-off, reset, delete, and anything that
# changes a VM's configuration.
# ---------------------------------------------------------------------------

class WriteUnavailable(RuntimeError):
    """No write account is configured for this vCenter."""


def load_writer(name):
    ro = next((v for v in load_vcenters() if v["name"] == name), None)
    if not ro:
        raise WriteUnavailable(f"no vCenter named {name}")
    path = os.path.join(CONFIG_DIR, name + WRITE_SUFFIX + ".env")
    if not os.path.exists(path):
        raise WriteUnavailable(
            f"no write account for {name}. Add one on PATCH-01: "
            f"./scripts/phase7-vmware.sh --add-writer {name}")
    e = _read_env(path)
    try:
        pw = base64.b64decode(e.get("VC_PASSWORD_B64", "")).decode()
    except Exception:  # noqa: BLE001
        pw = ""
    return {**ro, "user": e.get("VC_USER", ""), "password": pw}


def _vm(si, moref):
    from pyVmomi import vim
    return vim.VirtualMachine(moref, si._stub)


def _snapshot(si, moref):
    from pyVmomi import vim
    return vim.vm.Snapshot(moref, si._stub)


def wait_task(task, timeout=1800):
    """Wait for a vCenter task; raise with vCenter's own message on failure."""
    from pyVmomi import vim
    start = time.time()
    while True:
        st = task.info.state
        if st == vim.TaskInfo.State.success:
            return task.info.result
        if st == vim.TaskInfo.State.error:
            err = task.info.error
            raise RuntimeError(getattr(err, "msg", None) or str(err))
        if time.time() - start > timeout:
            raise RuntimeError(f"vCenter task did not finish within {timeout // 60} minutes")
        time.sleep(2)


def vm_action(vcenter, moref, kind, params):
    """Carry out one VM action with the write account. Returns a result dict."""
    vc = load_writer(vcenter)
    si = connect(vc)
    try:
        vm = _vm(si, moref)
        name = vm.name
        if kind == "vm_snapshot_create":
            snap = wait_task(vm.CreateSnapshot_Task(
                name=params["name"], description=params.get("description") or "",
                memory=bool(params.get("memory")), quiesce=bool(params.get("quiesce"))))
            return {"vm": name, "snapshot_moref": getattr(snap, "_moId", None),
                    "snapshot_name": params["name"]}

        if kind == "vm_snapshot_remove":
            snap = _snapshot(si, params["snapshot_moref"])
            wait_task(snap.RemoveSnapshot_Task(removeChildren=bool(params.get("remove_children"))))
            return {"vm": name, "removed": params.get("snapshot_name")}

        if kind == "vm_snapshot_revert":
            # A snapshot of the current state first, so the revert itself can
            # be undone. Not optional: nobody else checks a revert here.
            stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
            safety = wait_task(vm.CreateSnapshot_Task(
                name=f"PATCH-01 before revert {stamp}",
                description=f"Taken automatically before reverting to "
                            f"'{params.get('snapshot_name')}'. Revert to this to undo the revert.",
                memory=False, quiesce=False))
            snap = _snapshot(si, params["snapshot_moref"])
            wait_task(snap.RevertToSnapshot_Task())
            return {"vm": name, "reverted_to": params.get("snapshot_name"),
                    "safety_snapshot_moref": getattr(safety, "_moId", None),
                    "safety_snapshot_name": f"PATCH-01 before revert {stamp}"}

        if kind == "vm_power_on":
            wait_task(vm.PowerOnVM_Task())
            return {"vm": name, "power": "on"}

        if kind in ("vm_guest_shutdown", "vm_guest_restart"):
            # Checked again now, not only at request time: Tools may have
            # stopped since the change was scheduled
            if vm.guest.toolsRunningStatus != "guestToolsRunning":
                raise RuntimeError("VMware Tools is not running, so a clean guest "
                                   "operation is not possible. Nothing was done.")
            if kind == "vm_guest_shutdown":
                vm.ShutdownGuest()
            else:
                vm.RebootGuest()
            # These return at once; the guest acts on its own afterwards
            return {"vm": name, "requested": "shutdown" if kind == "vm_guest_shutdown" else "restart"}

        raise RuntimeError(f"unsupported action {kind}")
    finally:
        disconnect(si)


def snapshot_for_patch(vcenter, moref, change_ref):
    """The snapshot taken before patching a server. Returns its moref."""
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    r = vm_action(vcenter, moref, "vm_snapshot_create",
                  {"name": f"PATCH-01 {change_ref} before patching",
                   "description": f"Taken by PATCH-01 at {stamp} before {change_ref}.",
                   "memory": False, "quiesce": False})
    return r["snapshot_moref"]


def remove_snapshot(vcenter, moref, snapshot_moref, label=None):
    return vm_action(vcenter, moref, "vm_snapshot_remove",
                     {"snapshot_moref": snapshot_moref, "snapshot_name": label,
                      "remove_children": False})
