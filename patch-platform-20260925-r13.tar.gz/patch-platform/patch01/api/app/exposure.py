"""
PATCH-01 : what a CVE affects, and whether we have it

NVD lists the products a CVE affects as CPE names, for example

    cpe:2.3:o:vmware:esxi:8.0:update_2:*:*:*:*:*:*
            ^ ^      ^    ^   ^
            | vendor product version update
            part: o = operating system, a = application, h = hardware

This module classifies those products and looks for them in every part of
the inventory PATCH-01 holds:

    Linux servers    installed packages, and the CVE engine's verdicts
    ESXi hosts       version and update level, from vCenter
    vCenters         version
    VM guests        guest operating system reported by VMware Tools

Certainty is always stated, because the sources differ in how much they can
prove:

    confirmed        a package version check says affected or fixed
    in_range         the version lies inside the range NVD gives as affected
    release_match    the release matches (8.0 Update 2) but NVD gives no build
                     range, so the exact patch level cannot be compared
    present          the product is in the inventory; no version data to judge
    not_tracked      a kind of product PATCH-01 does not inventory, such as a
                     network appliance

A match below "confirmed" or "in_range" is never reported as affected, only
as potentially affected, so a guess is never presented as a finding.
"""

import re

NETWORK_VENDORS = {
    "cisco", "juniper", "fortinet", "paloaltonetworks", "f5", "arista", "checkpoint",
    "sonicwall", "netgear", "zyxel", "mikrotik", "ubiquiti", "hpe_aruba", "arubanetworks",
    "citrix", "pulsesecure", "ivanti", "barracuda", "watchguard", "sophos", "huawei",
    "extremenetworks", "brocade", "netscout", "a10networks", "tp-link", "dlink", "d-link",
}

# Product name in CPE -> package name on the Linux servers, where they differ
PACKAGE_ALIASES = {
    "http_server": ["httpd", "apache2"],
    "linux_kernel": ["kernel", "kernel-core", "linux-image-generic"],
    "openssh": ["openssh", "openssh-server", "openssh-client"],
    "glibc": ["glibc"],
    "libc": ["glibc", "libc6"],
    "python": ["python3", "python3-libs"],
    "krb5": ["krb5-libs", "libkrb5-3"],
    "libcurl": ["libcurl", "libcurl4"],
    "polkit": ["polkit", "policykit-1"],
    "bind": ["bind", "bind-libs", "bind9"],
    "postgresql": ["postgresql", "postgresql-server"],
    "mariadb": ["mariadb", "mariadb-server"],
    "mysql": ["mysql", "mysql-server"],
    "openssl": ["openssl", "openssl-libs", "libssl3"],
    "sudo": ["sudo"],
    "xz": ["xz", "xz-libs", "liblzma5"],
    "systemd": ["systemd"],
    "samba": ["samba", "samba-libs"],
}

# CPE vendor/product for the Linux distributions we patch
LINUX_OS = {
    ("redhat", "enterprise_linux"): "rhel",
    ("oracle", "linux"): "ol",
    ("canonical", "ubuntu_linux"): "ubuntu",
}

# Windows Server CPE product -> text VMware Tools reports as the guest OS
WINDOWS_GUESTS = {
    "windows_server_2012": "Windows Server 2012",
    "windows_server_2016": "Windows Server 2016",
    "windows_server_2019": "Windows Server 2019",
    "windows_server_2022": "Windows Server 2022",
    "windows_server_2025": "Windows Server 2025",
    "windows_10": "Windows 10",
    "windows_11": "Windows 11",
}


# ---------------------------------------------------------------------------
# CPE parsing
# ---------------------------------------------------------------------------

def parse_cpe(criteria):
    """Split a CPE 2.3 name into its fields. None if it is not one."""
    if not criteria or not str(criteria).startswith("cpe:2.3:"):
        return None
    # Colons inside a field are escaped as \: in CPE; split on unescaped ones
    parts = re.split(r"(?<!\\):", criteria)
    if len(parts) < 7:
        return None
    return {"part": parts[2], "vendor": parts[3], "product": parts[4],
            "version": parts[5], "update": parts[6]}


def classify(part, vendor, product):
    if vendor == "vmware" and product == "esxi":
        return "Hypervisor (ESXi)"
    if vendor == "vmware" and product.startswith("vcenter"):
        return "vCenter"
    if part == "h":
        return "Hardware or firmware"
    if vendor in NETWORK_VENDORS:
        return "Network device or appliance"
    if part == "o":
        return "Operating system"
    return "Application"


def products_from_cpes(cpes):
    """Group NVD's CPE matches into products, keeping their version ranges."""
    out = {}
    for c in cpes or []:
        if not c.get("vulnerable", True):
            continue
        p = parse_cpe(c.get("criteria"))
        if not p:
            continue
        key = (p["vendor"], p["product"])
        prod = out.setdefault(key, {
            "vendor": p["vendor"], "product": p["product"], "part": p["part"],
            "kind": classify(p["part"], p["vendor"], p["product"]),
            "ranges": [],
        })
        prod["ranges"].append({
            "version": p["version"], "update": p["update"],
            "start_incl": c.get("versionStartIncluding"),
            "start_excl": c.get("versionStartExcluding"),
            "end_incl": c.get("versionEndIncluding"),
            "end_excl": c.get("versionEndExcluding"),
        })
    return list(out.values())


# ---------------------------------------------------------------------------
# Version comparison, for dotted numeric versions such as ESXi 8.0.3
# ---------------------------------------------------------------------------

def vkey(v):
    """'8.0.3' -> (8, 0, 3). Non-numeric parts sort as zero."""
    return tuple(int(x) if x.isdigit() else 0 for x in re.split(r"[.\-_]", str(v or "")) if x != "")


def _cmp(a, b):
    ka, kb = vkey(a), vkey(b)
    n = max(len(ka), len(kb))
    ka, kb = ka + (0,) * (n - len(ka)), kb + (0,) * (n - len(kb))
    return (ka > kb) - (ka < kb)


def in_range(version, r):
    """Is `version` inside one NVD range? None if the range cannot decide."""
    bounded = any(r.get(k) for k in ("start_incl", "start_excl", "end_incl", "end_excl"))
    if not bounded:
        return None
    if r.get("start_incl") and _cmp(version, r["start_incl"]) < 0:
        return False
    if r.get("start_excl") and _cmp(version, r["start_excl"]) <= 0:
        return False
    if r.get("end_incl") and _cmp(version, r["end_incl"]) > 0:
        return False
    if r.get("end_excl") and _cmp(version, r["end_excl"]) >= 0:
        return False
    return True


def esxi_release(esxi_version):
    """'8.0.3' -> ('8.0', '3'): ESXi's third number is its update level."""
    k = vkey(esxi_version)
    if len(k) < 2:
        return None, None
    return f"{k[0]}.{k[1]}", (str(k[2]) if len(k) > 2 else "0")


def cpe_update_number(update):
    """'update_2' / 'update2' / 'u2' -> '2'; '-' (GA) -> '0'; '*' -> None."""
    u = str(update or "").lower()
    if u in ("*", ""):
        return None
    if u == "-":
        return "0"
    m = re.search(r"(?:update_?|u)(\d+)", u)
    return m.group(1) if m else None


def match_versioned(version, ranges, release_of=None):
    """Best certainty for one installed version against a product's ranges.

    Each NVD entry is one of three shapes, and each is judged on its own:
      bounded   a start or end version: inside or outside, decisively
      exact     one release, such as 8.0 Update 2: matches ours or not
      any       every version, with no bounds: present, but uncomparable

    Returns (certainty, detail): in_range, release_match, present or outside.
    A different exact release counts as outside, not as present.
    """
    found_release = found_any = None
    for r in ranges:
        verdict = in_range(version, r)
        if verdict is True:
            lo = r.get("start_incl") or r.get("start_excl") or "any"
            hi = r.get("end_excl") or r.get("end_incl") or "any"
            return "in_range", f"version {version} is inside the affected range {lo} to {hi}"
        if verdict is False:
            continue
        rv = r.get("version")
        if rv in ("*", "", None):
            found_any = "every version is listed as affected; the patch level cannot be compared"
            continue
        if rv == "-":
            continue
        if release_of:
            rel, upd = release_of(version)
            if rel and str(rv).startswith(rel):
                cu = cpe_update_number(r.get("update"))
                if cu is None or cu == upd:
                    found_release = (f"release {rv}"
                                     + (f" update {cu}" if cu not in (None, "0") else "")
                                     + " matches; the exact patch level cannot be compared")
        elif _cmp(version, rv) == 0:
            found_release = f"version {rv} matches exactly"
    if found_release:
        return "release_match", found_release
    if found_any:
        return "present", found_any
    return "outside", f"version {version} is not among the affected versions"


# ---------------------------------------------------------------------------
# Matching against the inventory
# ---------------------------------------------------------------------------

def find_in_inventory(conn, products):
    """Where each product appears in our inventory, and how sure we are."""
    matches = []
    for p in products:
        vendor, product, kind = p["vendor"], p["product"], p["kind"]
        name = f"{vendor} {product}".replace("_", " ")

        if kind == "Hypervisor (ESXi)":
            rows = conn.execute(
                "SELECT vcenter, name, esxi_version, esxi_build FROM esxi_hosts").fetchall()
            for h in rows:
                cert, why = match_versioned(h["esxi_version"], p["ranges"], esxi_release)
                if cert == "outside":
                    continue
                matches.append({"product": name, "kind": kind, "where": "ESXi host",
                                "name": h["name"], "version": f"{h['esxi_version']} build {h['esxi_build']}",
                                "certainty": cert, "detail": why, "vcenter": h["vcenter"]})
            continue

        if kind == "vCenter":
            for v in conn.execute("SELECT name, host, version FROM vcenters").fetchall():
                ver = (v["version"] or "").split(" ")[0]
                cert, why = match_versioned(ver, p["ranges"], esxi_release)
                if cert == "outside":
                    continue
                matches.append({"product": name, "kind": kind, "where": "vCenter",
                                "name": v["host"], "version": v["version"],
                                "certainty": cert, "detail": why})
            continue

        if kind in ("Network device or appliance", "Hardware or firmware"):
            matches.append({"product": name, "kind": kind, "where": None, "name": None,
                            "certainty": "not_tracked",
                            "detail": "PATCH-01 does not inventory network devices or firmware; "
                                      "check with the team that owns them"})
            continue

        if vendor == "microsoft" and product in WINDOWS_GUESTS:
            label = WINDOWS_GUESTS[product]
            rows = conn.execute(
                """SELECT name, vcenter, guest_os, power_state FROM vm_inventory
                    WHERE guest_os ILIKE %s ORDER BY name LIMIT 200""",
                (f"%{label}%",)).fetchall()
            for r in rows:
                matches.append({"product": name, "kind": kind, "where": "VM guest OS",
                                "name": r["name"], "version": r["guest_os"],
                                "certainty": "present", "vcenter": r["vcenter"],
                                "detail": "Windows patch level is not visible without a Windows "
                                          "agent or WSUS integration"})
            continue

        if (vendor, product) in LINUX_OS:
            os_id = LINUX_OS[(vendor, product)]
            majors = {str(vkey(r.get("version"))[0]) for r in p["ranges"]
                      if r.get("version") not in ("*", "-", "", None) and vkey(r.get("version"))}
            rows = conn.execute(
                """SELECT hostname, os_version, os_major FROM hosts
                    WHERE os_id=%s AND status <> 'decommissioned' ORDER BY hostname LIMIT 200""",
                (os_id,)).fetchall()
            for r in rows:
                if majors and str(r["os_major"]) not in majors:
                    continue
                matches.append({"product": name, "kind": kind, "where": "Linux server",
                                "name": r["hostname"], "version": r["os_version"],
                                "certainty": "present",
                                "detail": "the operating system matches; the package verdict below "
                                          "decides whether it is affected"})
            continue

        # Applications, and Linux components such as the kernel
        pkgs = PACKAGE_ALIASES.get(product, [product])
        rows = conn.execute(
            """SELECT DISTINCT h.hostname, hp.name, hp.version, hp.release
                 FROM host_packages hp JOIN hosts h ON h.id = hp.host_id
                WHERE hp.name = ANY(%s) AND h.status <> 'decommissioned'
                ORDER BY h.hostname LIMIT 200""", (pkgs,)).fetchall()
        seen = set()
        for r in rows:
            if r["hostname"] in seen:
                continue
            seen.add(r["hostname"])
            ver = f"{r['version']}-{r['release']}" if r["release"] else r["version"]
            matches.append({"product": name, "kind": kind, "where": "Linux server",
                            "name": r["hostname"], "version": f"{r['name']} {ver}",
                            "certainty": "present",
                            "detail": "installed; distribution backports mean the upstream "
                                      "version alone cannot prove exposure"})
    return matches


def overall_exposure(verdict_status, matches):
    """One word for the whole CVE, from the strongest evidence available.

    A package verdict outranks everything, because it is the only check that
    compares a vendor's fixed version with what is actually installed.
    """
    if verdict_status == "affected":
        return "affected"
    # Where the package check has decided the Linux servers, "the product is
    # installed there" adds nothing and must not override it
    decided = verdict_status in ("pending_reboot", "patched", "not_applicable")
    matches = [m for m in matches if not (decided and m.get("where") == "Linux server")]
    if any(m["certainty"] == "in_range" for m in matches):
        return "affected"
    if verdict_status == "pending_reboot":
        return "pending_reboot"
    if any(m["certainty"] in ("release_match", "present") for m in matches):
        return "potentially_affected"
    if verdict_status == "patched":
        return "patched"
    if verdict_status == "not_applicable":
        return "not_affected"
    if matches and all(m["certainty"] == "not_tracked" for m in matches):
        return "not_tracked"
    return "not_found"
