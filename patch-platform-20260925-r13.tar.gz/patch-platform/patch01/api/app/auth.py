"""
PATCH-01 : users, sessions and roles

Roles form a strict ladder, each including everything below it:

    viewer  <  operator  <  admin

A check asks for the least role an action needs, so an admin passes every
operator check and an operator every viewer check.

Passwords are hashed with scrypt, with its parameters stored in the hash so
they can be raised later without invalidating existing passwords. Session
tokens are random, shown to the browser once, and stored only as a SHA-256
hash: a copy of the database does not contain usable sessions.

Scripts on PATCH-01 still authenticate with HTTP Basic, checked against the
same users table, so `curl -u admin:...` in the phase scripts keeps working.
"""

import hashlib
import hmac
import os
import re
import secrets
from datetime import datetime, timedelta, timezone

ROLES = ("viewer", "operator", "admin")
RANK = {r: i for i, r in enumerate(ROLES)}

SESSION_HOURS = int(os.environ.get("SESSION_HOURS", "12"))
MAX_FAILED = 5
LOCK_MINUTES = 15
MIN_PASSWORD = 12

USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{1,62}$")

# scrypt cost. 2**14 with r=8 takes tens of milliseconds: noticeable to an
# attacker trying millions, not to a person signing in.
SCRYPT_N, SCRYPT_R, SCRYPT_P = 2 ** 14, 8, 1


def role_at_least(role, needed):
    return RANK.get(role, -1) >= RANK[needed]


# ---------------------------------------------------------------------------
# Passwords
# ---------------------------------------------------------------------------

def hash_password(password):
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=SCRYPT_N, r=SCRYPT_R,
                        p=SCRYPT_P, dklen=32)
    return f"scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${salt.hex()}${dk.hex()}"


def verify_password(password, stored):
    try:
        algo, n, r, p, salt_hex, dk_hex = stored.split("$")
        if algo != "scrypt":
            return False
        dk = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex),
                            n=int(n), r=int(r), p=int(p), dklen=len(dk_hex) // 2)
        return hmac.compare_digest(dk.hex(), dk_hex)
    except (ValueError, TypeError):
        return False


def password_problem(password, username=None):
    """None if acceptable, otherwise the reason in plain words."""
    if not password or len(password) < MIN_PASSWORD:
        return f"Use at least {MIN_PASSWORD} characters."
    if username and username.lower() in password.lower():
        return "The password must not contain the username."
    classes = sum(bool(re.search(p, password)) for p in (r"[a-z]", r"[A-Z]", r"\d", r"[^A-Za-z0-9]"))
    if classes < 3:
        return "Mix at least three of: lowercase, uppercase, digits, symbols."
    return None


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------

def _token_hash(token):
    return hashlib.sha256(token.encode()).hexdigest()


def new_session(conn, user_id, source_ip=None, user_agent=None):
    token = secrets.token_urlsafe(32)
    conn.execute(
        """INSERT INTO user_sessions (token_hash, user_id, expires_at, source_ip, user_agent)
           VALUES (%s, %s, now() + make_interval(hours => %s), %s::inet, %s)""",
        (_token_hash(token), user_id, SESSION_HOURS, source_ip, (user_agent or "")[:300]))
    return token


def session_user(conn, token):
    """The user behind a session token, or None. Extends the session on use."""
    if not token or len(token) > 200:
        return None
    row = conn.execute(
        """UPDATE user_sessions s
              SET last_seen_at = now(),
                  expires_at = GREATEST(s.expires_at, now() + make_interval(hours => %s))
             FROM users u
            WHERE s.token_hash = %s AND s.expires_at > now()
              AND u.id = s.user_id AND u.active
        RETURNING u.id, u.username, u.role::text AS role, u.display_name,
                  u.must_change_password""",
        (SESSION_HOURS, _token_hash(token))).fetchone()
    return dict(row) if row else None


def end_session(conn, token):
    conn.execute("DELETE FROM user_sessions WHERE token_hash=%s", (_token_hash(token),))


def end_all_sessions(conn, user_id):
    conn.execute("DELETE FROM user_sessions WHERE user_id=%s", (user_id,))


# ---------------------------------------------------------------------------
# Sign in
# ---------------------------------------------------------------------------

class LoginError(Exception):
    pass


def authenticate(conn, username, password):
    """Check a username and password. Returns the user, or raises LoginError.

    The message is the same for an unknown user and a wrong password, so the
    response does not reveal which usernames exist.
    """
    username = (username or "").strip().lower()
    row = conn.execute(
        """SELECT id, username, role::text AS role, display_name, password_hash, active,
                  must_change_password, failed_logins, locked_until
             FROM users WHERE username=%s""", (username,)).fetchone()

    if row and row["locked_until"] and row["locked_until"] > datetime.now(timezone.utc):
        raise LoginError("This account is temporarily locked after repeated failed "
                         "sign-ins. Try again later, or ask an admin to unlock it.")

    # Hash anyway for unknown users, so timing does not reveal existence
    ok = verify_password(password or "", row["password_hash"] if row else
                         "scrypt$16384$8$1$" + "00" * 16 + "$" + "00" * 32)
    if not row or not ok or not row["active"]:
        if row:
            fails = row["failed_logins"] + 1
            lock = (datetime.now(timezone.utc) + timedelta(minutes=LOCK_MINUTES)
                    if fails >= MAX_FAILED else None)
            conn.execute("UPDATE users SET failed_logins=%s, locked_until=%s WHERE id=%s",
                         (0 if lock else fails, lock, row["id"]))
        raise LoginError("That username and password were not accepted.")

    conn.execute("UPDATE users SET failed_logins=0, locked_until=NULL, last_login_at=now() "
                 "WHERE id=%s", (row["id"],))
    return {k: row[k] for k in ("id", "username", "role", "display_name",
                                "must_change_password")}


def bootstrap_admin(conn, password):
    """First start: create 'admin' from the existing ADMIN_PASSWORD, so the
    account that worked before this upgrade still works after it."""
    try:
        n = conn.execute("SELECT count(*) AS n FROM users").fetchone()["n"]
    except Exception:  # noqa: BLE001 - table absent until schema 009 is applied
        return False
    if n or not password:
        return False
    conn.execute(
        """INSERT INTO users (username, display_name, role, password_hash, created_by)
           VALUES ('admin', 'Administrator', 'admin', %s, 'bootstrap')""",
        (hash_password(password),))
    return True
