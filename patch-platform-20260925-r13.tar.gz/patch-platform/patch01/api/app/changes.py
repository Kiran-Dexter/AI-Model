"""
PATCH-01 : the change engine

Every action that alters a server or a VM is a change. This module turns a
request into a validated, recorded change; app.worker carries it out.

Validation happens here, before anything is scheduled, so a mistake is
refused while the operator is still looking at the form rather than
discovered at 2am in a maintenance window.

Kinds
  patch                 install outstanding security fixes on servers
  vm_snapshot_create    take a snapshot of VMs
  vm_snapshot_remove    delete one snapshot
  vm_snapshot_revert    return a VM to a snapshot (a safety snapshot of the
                        current state is taken first, so a revert is undoable)
  vm_power_on
  vm_guest_shutdown     a clean OS shutdown through VMware Tools, never a
                        hard power-off
  vm_guest_restart      a clean OS restart through VMware Tools

Approval is off by default. If REQUIRE_APPROVAL is set, every change waits
for someone other than the requester to approve it.
"""

import json
import os
import re
from datetime import datetime, timedelta, timezone

REQUIRE_APPROVAL = os.environ.get("REQUIRE_APPROVAL", "false").lower() in ("1", "true", "yes")

KINDS = {
    "patch":              {"target": "host", "label": "Patch servers"},
    "vm_snapshot_create": {"target": "vm",   "label": "Take VM snapshot"},
    "vm_snapshot_remove": {"target": "vm",   "label": "Remove VM snapshot"},
    "vm_snapshot_revert": {"target": "vm",   "label": "Revert VM to snapshot"},
    "vm_power_on":        {"target": "vm",   "label": "Power on VM"},
    "vm_guest_shutdown":  {"target": "vm",   "label": "Shut down guest OS"},
    "vm_guest_restart":   {"target": "vm",   "label": "Restart guest OS"},
}

# One snapshot or revert targets one VM: a revert across many VMs at once is
# how a mistake becomes an outage.
SINGLE_VM = {"vm_snapshot_remove", "vm_snapshot_revert"}

MAX_TARGETS = 500
SNAP_NAME_RE = re.compile(r"^[A-Za-z0-9 _.:()/+-]{1,80}$")
MOREF_RE = re.compile(r"^[a-z]+-\d+$")
ADVISORY_RE = re.compile(r"^[A-Z]{2,6}-\d{4}[-:]\d{1,6}$")

PATCH_MODES = ("security", "advisories")
REBOOT = ("never", "if_required", "always")
SNAPSHOT = ("none", "keep", "remove_on_success")


class Invalid(ValueError):
    """A request that must not become a change. The message is for the operator."""


def _parse_time(v, name):
    if v in (None, ""):
        return None
    try:
        t = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except ValueError:
        raise Invalid(f"{name} is not a valid date and time.")
    if t.tzinfo is None:
        raise Invalid(f"{name} needs a time zone.")
    return t


def validate(conn, kind, raw_targets, raw_params, run_after=None, run_before=None,
             max_parallel=5):
    """Check a request against the inventory and the rules.

    Returns (targets, params, run_after, run_before, max_parallel), all
    normalised, or raises Invalid with a reason written for the operator.
    """
    if kind not in KINDS:
        raise Invalid("Unknown kind of change.")
    params = dict(raw_params or {})
    now = datetime.now(timezone.utc)

    ra = _parse_time(run_after, "Start") or now
    rb = _parse_time(run_before, "End of window")
    if ra < now - timedelta(minutes=5):
        raise Invalid("The start time is in the past.")
    if rb and rb <= ra:
        raise Invalid("The window must end after it starts.")
    if rb and rb - ra < timedelta(minutes=15):
        raise Invalid("Allow at least 15 minutes between start and end.")
    try:
        mp = int(max_parallel)
    except (TypeError, ValueError):
        raise Invalid("Parallel servers must be a number.")
    if not 1 <= mp <= 50:
        raise Invalid("Run between 1 and 50 servers at a time.")

    if not isinstance(raw_targets, list) or not raw_targets:
        raise Invalid("Choose at least one target.")
    if len(raw_targets) > MAX_TARGETS:
        raise Invalid(f"At most {MAX_TARGETS} targets in one change.")

    if KINDS[kind]["target"] == "host":
        targets = _validate_hosts(conn, raw_targets)
        params = _validate_patch(conn, params, targets)
    else:
        if kind in SINGLE_VM and len(raw_targets) != 1:
            raise Invalid("Choose exactly one VM for this action.")
        targets = _validate_vms(conn, raw_targets)
        params = _validate_vm_action(kind, params, targets)
    return targets, params, ra, rb, mp


def _validate_hosts(conn, raw):
    ids = []
    for t in raw:
        hid = t.get("host_id") if isinstance(t, dict) else t
        if not isinstance(hid, str) or not re.match(r"^[0-9a-f-]{36}$", hid):
            raise Invalid("A server id was not recognised.")
        ids.append(hid)
    rows = conn.execute(
        """SELECT h.id::text AS id, h.hostname, h.status, h.os_id,
                  (SELECT v.vcenter FROM vm_inventory v WHERE v.host_id = h.id LIMIT 1) AS vcenter,
                  (SELECT v.moref FROM vm_inventory v WHERE v.host_id = h.id LIMIT 1) AS vm_moref
             FROM hosts h WHERE h.id::text = ANY(%s)""", (ids,)).fetchall()
    found = {r["id"]: r for r in rows}
    missing = [i for i in ids if i not in found]
    if missing:
        raise Invalid(f"{len(missing)} selected server(s) no longer exist.")
    retired = [found[i]["hostname"] for i in ids if found[i]["status"] == "decommissioned"]
    if retired:
        raise Invalid("Retired servers cannot be patched: " + ", ".join(retired[:5]))
    seen, out = set(), []
    for i in ids:
        if i in seen:
            continue
        seen.add(i)
        r = found[i]
        out.append({"target_key": i, "host_id": i, "label": r["hostname"],
                    "vcenter": r["vcenter"], "vm_moref": r["vm_moref"]})
    return out


def _validate_patch(conn, p, targets):
    mode = p.get("mode", "security")
    if mode not in PATCH_MODES:
        raise Invalid("Patch mode must be all security fixes, or chosen advisories.")
    advisories = []
    if mode == "advisories":
        advisories = [a for a in (p.get("advisories") or []) if isinstance(a, str)]
        bad = [a for a in advisories if not ADVISORY_RE.match(a)]
        if not advisories or bad:
            raise Invalid("List the advisories to install, for example RHSA-2026:4417.")
    reboot = p.get("reboot", "if_required")
    if reboot not in REBOOT:
        raise Invalid("Reboot must be never, if required, or always.")
    snapshot = p.get("snapshot", "none")
    if snapshot not in SNAPSHOT:
        raise Invalid("Snapshot must be none, keep, or remove on success.")
    if snapshot != "none":
        unlinked = [t["label"] for t in targets if not t["vm_moref"]]
        if unlinked:
            raise Invalid("A snapshot needs each server linked to its VM. Not linked: "
                          + ", ".join(unlinked[:5])
                          + ". Sync the vCenter, or choose no snapshot.")
    return {"mode": mode, "advisories": advisories, "reboot": reboot,
            "snapshot": snapshot, "check_services": bool(p.get("check_services", True))}


def _validate_vms(conn, raw):
    out = []
    for t in raw:
        if not isinstance(t, dict):
            raise Invalid("A VM was not recognised.")
        vc, moref = str(t.get("vcenter") or ""), str(t.get("moref") or "")
        if not MOREF_RE.match(moref):
            raise Invalid("A VM was not recognised.")
        row = conn.execute(
            """SELECT name, power_state, tools_running, snapshots, host_id::text AS host_id
                 FROM vm_inventory WHERE vcenter=%s AND moref=%s""", (vc, moref)).fetchone()
        if not row:
            raise Invalid("A selected VM is no longer in the inventory. Re-sync the vCenter.")
        out.append({"target_key": f"{vc}|{moref}", "vcenter": vc, "vm_moref": moref,
                    "host_id": row["host_id"], "label": row["name"],
                    "_power": row["power_state"], "_tools": row["tools_running"],
                    "_snapshots": row["snapshots"] or []})
    keys = [o["target_key"] for o in out]
    if len(set(keys)) != len(keys):
        raise Invalid("The same VM was chosen twice.")
    return out


def _validate_vm_action(kind, p, targets):
    if kind == "vm_snapshot_create":
        name = str(p.get("name") or "").strip()
        if not SNAP_NAME_RE.match(name):
            raise Invalid("Give the snapshot a name: letters, digits and simple punctuation, up to 80.")
        return {"name": name, "description": str(p.get("description") or "")[:500],
                "memory": bool(p.get("memory", False)), "quiesce": bool(p.get("quiesce", False))}

    if kind in ("vm_snapshot_remove", "vm_snapshot_revert"):
        t = targets[0]
        snap = str(p.get("snapshot_moref") or "")
        known = {s.get("moref"): s for s in t["_snapshots"] if isinstance(s, dict)}
        if snap not in known:
            raise Invalid("That snapshot is not on this VM. Re-sync the vCenter if it is new.")
        out = {"snapshot_moref": snap, "snapshot_name": known[snap].get("name")}
        if kind == "vm_snapshot_remove":
            out["remove_children"] = bool(p.get("remove_children", False))
            return out
        # Revert discards everything since the snapshot. The operator types
        # the VM's name, so it cannot be done by a slip of the mouse.
        if str(p.get("confirm_name") or "").strip() != t["label"]:
            raise Invalid(f"To revert, type the VM name exactly: {t['label']}")
        out["safety_snapshot"] = True     # always, not optional
        return out

    if kind == "vm_power_on":
        on = [t["label"] for t in targets if t["_power"] == "poweredOn"]
        if on:
            raise Invalid("Already powered on: " + ", ".join(on[:5]))
        return {}

    if kind in ("vm_guest_shutdown", "vm_guest_restart"):
        # A clean guest operation needs VMware Tools. Without it the only way
        # is a hard power-off, which this platform deliberately does not offer.
        no_tools = [t["label"] for t in targets if t["_tools"] != "guestToolsRunning"]
        if no_tools:
            raise Invalid("VMware Tools is not running on: " + ", ".join(no_tools[:5])
                          + ". A clean shutdown or restart needs it.")
        off = [t["label"] for t in targets if t["_power"] != "poweredOn"]
        if off:
            raise Invalid("Not powered on: " + ", ".join(off[:5]))
        return {}
    return {}


def create(conn, kind, title, reason, targets, params, run_after, run_before,
           max_parallel, user, role):
    """Record a validated change. Returns its id and number."""
    reason = (reason or "").strip()
    if len(reason) < 3:
        raise Invalid("Say why this change is being made. It is kept in the record.")
    title = (title or "").strip()[:200] or KINDS[kind]["label"]
    state = "pending_approval" if REQUIRE_APPROVAL else "scheduled"
    row = conn.execute(
        """INSERT INTO changes (kind, title, reason, state, params, requested_by, requested_role,
                                approval_required, run_after, run_before, max_parallel)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id::text AS id, number""",
        (kind, title, reason[:2000], state, json.dumps(params), user, role,
         REQUIRE_APPROVAL, run_after, run_before, max_parallel)).fetchone()
    with conn.cursor() as cur:
        cur.executemany(
            """INSERT INTO change_targets (change_id, target_key, host_id, vcenter, vm_moref, label)
               VALUES (%s,%s,%s,%s,%s,%s)""",
            [(row["id"], t["target_key"], t.get("host_id"), t.get("vcenter"),
              t.get("vm_moref"), t["label"]) for t in targets])
    event(conn, row["id"], None, user, "requested", True,
          f"{KINDS[kind]['label']}: {len(targets)} target(s)",
          {"params": params, "run_after": run_after.isoformat(),
           "run_before": run_before.isoformat() if run_before else None})
    return row["id"], row["number"]


def event(conn, change_id, target_key, actor, what, ok=None, message=None, detail=None):
    conn.execute(
        """INSERT INTO change_events (change_id, target_key, actor, event, ok, message, detail)
           VALUES (%s,%s,%s,%s,%s,%s,%s)""",
        (change_id, target_key, actor, what, ok, (message or "")[:2000] or None,
         json.dumps(detail or {}, default=str)))


def ref(number):
    return f"CHG-{int(number):06d}"
