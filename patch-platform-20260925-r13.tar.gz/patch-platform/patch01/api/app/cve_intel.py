"""
PATCH-01 : CVE intelligence

Enriches every CVE referenced by an advisory with facts from four sources:

  NIST NVD     description, CVSS score and vector, weakness type (CWE)
  CISA KEV     whether it is known to be exploited in the wild
  FIRST EPSS   probability of exploitation in the next 30 days
  Red Hat      Red Hat's own severity, score and statement, for RHEL

These are the facts the dashboard shows and the facts AI-01 is given, which
is what lets an explanation say "remotely exploitable without a login, being
exploited now" instead of "apply the update".

Fetched through the corporate proxy (standard HTTPS_PROXY environment). NVD
allows 5 requests per 30 seconds without an API key and 50 with one; the
pacing below stays inside those limits.

Run inside the API image:
  python -m app.cve_intel                 all sources
  python -m app.cve_intel --only nvd      one source
  python -m app.cve_intel --estimate      how long the NVD import will take
"""

import argparse
import json
import logging
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

log = logging.getLogger("patchapi.cve_intel")

NVD_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
EPSS_URL = "https://api.first.org/data/v1/epss"
RH_URL = "https://access.redhat.com/hydra/rest/securitydata/cve/{}.json"

NVD_KEY = os.environ.get("NVD_API_KEY", "").strip()
# 50 per 30 s with a key, 5 per 30 s without, with a margin for safety
NVD_PAUSE = 0.7 if NVD_KEY else 6.5
REFRESH_DAYS = int(os.environ.get("CVE_REFRESH_DAYS", "30"))
UA = "PATCH-01-cve-intel/1.0"

CVE_RE = re.compile(r"^CVE-\d{4}-\d{4,7}$")


# ---------------------------------------------------------------------------
# Pure functions: reading records and deriving the attack type
# ---------------------------------------------------------------------------

AV = {"NETWORK": "network", "ADJACENT_NETWORK": "adjacent network",
      "ADJACENT": "adjacent network", "LOCAL": "local access", "PHYSICAL": "physical access"}
PR = {"NONE": "no login", "LOW": "a low-privilege login", "HIGH": "an administrator login"}
UI = {"NONE": "no user action", "REQUIRED": "a user action", "PASSIVE": "a user action",
      "ACTIVE": "a user action"}


def pick_cvss(metrics):
    """Choose one CVSS v3 record, preferring NVD's own over a vendor's.

    NVD often carries a Primary score from nvd@nist.gov and Secondary scores
    from vendors; the Primary one is the neutral reference. v3.1 is preferred
    over v3.0, and v2 is only a last resort.
    """
    metrics = metrics or {}
    for key in ("cvssMetricV31", "cvssMetricV30"):
        entries = metrics.get(key) or []
        for want in ("Primary", "Secondary"):
            for e in entries:
                if e.get("type") == want and e.get("cvssData"):
                    d = e["cvssData"]
                    return {
                        "version": d.get("version") or key[-2:-1] + "." + key[-1:],
                        "score": d.get("baseScore"),
                        "severity": d.get("baseSeverity"),
                        "vector": d.get("vectorString"),
                        "source": e.get("source"),
                        "attack_vector": d.get("attackVector"),
                        "attack_complexity": d.get("attackComplexity"),
                        "privileges_required": d.get("privilegesRequired"),
                        "user_interaction": d.get("userInteraction"),
                        "scope": d.get("scope"),
                        "conf_impact": d.get("confidentialityImpact"),
                        "integ_impact": d.get("integrityImpact"),
                        "avail_impact": d.get("availabilityImpact"),
                    }
    for e in metrics.get("cvssMetricV2") or []:
        d = e.get("cvssData") or {}
        return {"version": "2.0", "score": d.get("baseScore"),
                "severity": e.get("baseSeverity"), "vector": d.get("vectorString"),
                "source": e.get("source"),
                "attack_vector": {"N": "NETWORK", "A": "ADJACENT_NETWORK", "L": "LOCAL"}.get(
                    (d.get("accessVector") or "")[:1], d.get("accessVector")),
                "attack_complexity": d.get("accessComplexity"),
                "privileges_required": {"NONE": "NONE", "SINGLE": "LOW", "MULTIPLE": "HIGH"}.get(
                    d.get("authentication"), None),
                "user_interaction": None, "scope": None,
                "conf_impact": d.get("confidentialityImpact"),
                "integ_impact": d.get("integrityImpact"),
                "avail_impact": d.get("availabilityImpact")}
    return None


def pick_cvss4(metrics):
    for e in (metrics or {}).get("cvssMetricV40") or []:
        d = e.get("cvssData") or {}
        if d.get("baseScore") is not None:
            return {"score": d.get("baseScore"), "vector": d.get("vectorString")}
    return None


def parse_nvd(cve):
    """Flatten one NVD 2.0 'cve' object into our columns."""
    desc = ""
    for d in cve.get("descriptions") or []:
        if d.get("lang") == "en":
            desc = d.get("value") or ""
            break
    cwes = []
    for w in cve.get("weaknesses") or []:
        for d in w.get("description") or []:
            v = (d.get("value") or "").strip()
            if v.startswith("CWE-") and v not in cwes:
                cwes.append(v)
    refs = []
    for r in (cve.get("references") or [])[:25]:
        u = r.get("url")
        if u and u not in refs:
            refs.append(u)
    # Affected products, as CPE matches, kept with their version ranges
    cpes = []
    for conf in cve.get("configurations") or []:
        for node in conf.get("nodes") or []:
            for m in node.get("cpeMatch") or []:
                if not m.get("criteria"):
                    continue
                cpes.append({k: m.get(k) for k in (
                    "criteria", "vulnerable", "versionStartIncluding", "versionStartExcluding",
                    "versionEndIncluding", "versionEndExcluding")})
                if len(cpes) >= 400:
                    break
    c3 = pick_cvss(cve.get("metrics")) or {}
    c4 = pick_cvss4(cve.get("metrics")) or {}
    out = {
        "cve_id": cve.get("id"),
        "nvd_status": cve.get("vulnStatus"),
        "published": cve.get("published"),
        "last_modified": cve.get("lastModified"),
        "description": desc[:4000],
        "cvss_version": c3.get("version"),
        "cvss_score": c3.get("score"),
        "cvss_severity": c3.get("severity"),
        "cvss_vector": c3.get("vector"),
        "cvss_source": c3.get("source"),
        "attack_vector": c3.get("attack_vector"),
        "attack_complexity": c3.get("attack_complexity"),
        "privileges_required": c3.get("privileges_required"),
        "user_interaction": c3.get("user_interaction"),
        "scope": c3.get("scope"),
        "conf_impact": c3.get("conf_impact"),
        "integ_impact": c3.get("integ_impact"),
        "avail_impact": c3.get("avail_impact"),
        "cvss4_score": c4.get("score"),
        "cvss4_vector": c4.get("vector"),
        "cwes": cwes,
        "ref_urls": refs,
        "cpes": cpes,
        # NVD carries KEV data too; the CISA feed remains the authority
        "kev_from_nvd": bool(cve.get("cisaExploitAdd")),
    }
    out["attack_class"], out["attack_class_basis"] = classify(cwes, out)
    return out


# Weakness families. Order matters: the first family a CWE matches wins, and
# the most severe families come first.
CWE_FAMILIES = [
    ("code", {"CWE-94", "CWE-95", "CWE-96", "CWE-77", "CWE-78", "CWE-917", "CWE-1336",
              "CWE-502", "CWE-434"}),
    # Includes off-by-one (193), bad buffer size (131, 805, 806) and invalid
    # index (129, 786, 788, 823): the roots of many kernel and sudo flaws
    ("memory", {"CWE-787", "CWE-119", "CWE-120", "CWE-121", "CWE-122", "CWE-416", "CWE-415",
                "CWE-190", "CWE-191", "CWE-193", "CWE-131", "CWE-129", "CWE-786", "CWE-788",
                "CWE-805", "CWE-806", "CWE-823", "CWE-843", "CWE-680", "CWE-822", "CWE-824"}),
    ("sqli", {"CWE-89", "CWE-564"}),
    ("path", {"CWE-22", "CWE-23", "CWE-35", "CWE-36", "CWE-59", "CWE-73", "CWE-98"}),
    ("auth", {"CWE-287", "CWE-288", "CWE-290", "CWE-294", "CWE-306", "CWE-862", "CWE-863",
              "CWE-639", "CWE-285", "CWE-284", "CWE-798", "CWE-640"}),
    ("privesc", {"CWE-269", "CWE-250", "CWE-266", "CWE-274", "CWE-276", "CWE-732", "CWE-266"}),
    ("ssrf", {"CWE-918"}),
    ("xxe", {"CWE-611", "CWE-776"}),
    ("xss", {"CWE-79", "CWE-80"}),
    ("csrf", {"CWE-352"}),
    ("race", {"CWE-362", "CWE-367"}),
    ("crypto", {"CWE-295", "CWE-297", "CWE-326", "CWE-327", "CWE-328", "CWE-330", "CWE-347",
                "CWE-354"}),
    ("info", {"CWE-200", "CWE-201", "CWE-203", "CWE-209", "CWE-532", "CWE-538", "CWE-125",
              "CWE-126", "CWE-401", "CWE-908", "CWE-212"}),
    ("dos", {"CWE-400", "CWE-770", "CWE-674", "CWE-835", "CWE-476", "CWE-369", "CWE-617",
             "CWE-404", "CWE-834", "CWE-1333", "CWE-407"}),
]


def _reach(v):
    """(remote, no_login) from the CVSS vector."""
    av = (v.get("attack_vector") or "").upper()
    pr = (v.get("privileges_required") or "").upper()
    return av in ("NETWORK",), pr == "NONE"


def classify(cwes, v):
    """Derive a plain attack type from the weakness and how it is reached.

    Returns (label, basis). The basis names exactly which facts produced the
    label, so it is never presented as more certain than the data allows.
    """
    fam, cwe = None, None
    for f, members in CWE_FAMILIES:
        hit = next((c for c in cwes if c in members), None)
        if hit:
            fam, cwe = f, hit
            break

    remote, nologin = _reach(v)
    av = AV.get((v.get("attack_vector") or "").upper(), "unknown access")
    basis_v = "attack vector " + av + (", " + PR.get((v.get("privileges_required") or "").upper(), "")
                                        if v.get("privileges_required") else "")
    high_ci = "HIGH" in {(v.get("conf_impact") or "").upper(), (v.get("integ_impact") or "").upper()}

    def lab(text):
        return text, f"{cwe}; {basis_v}" if cwe else basis_v

    if fam == "code":
        if remote and nologin:
            return lab("Remote code execution, no login needed")
        if remote:
            return lab("Remote code execution, login needed")
        return lab("Local code execution")
    if fam == "memory":
        if remote and high_ci:
            return lab("Memory corruption, possible remote code execution")
        if not remote and high_ci:
            return lab("Memory corruption, possible privilege escalation")
        return lab("Memory corruption")
    if fam == "sqli":
        return lab("SQL injection")
    if fam == "path":
        return lab("Path traversal or file inclusion" + (", remote" if remote else ""))
    if fam == "auth":
        return lab("Authentication or authorisation bypass" + (", remote" if remote else ""))
    if fam == "privesc":
        return lab("Local privilege escalation" if not remote else "Privilege escalation")
    if fam == "ssrf":
        return lab("Server-side request forgery")
    if fam == "xxe":
        return lab("XML external entity injection")
    if fam == "xss":
        return lab("Cross-site scripting")
    if fam == "csrf":
        return lab("Cross-site request forgery")
    if fam == "race":
        # A race reachable from the network without a login and with high
        # impact is how regreSSHion (CVE-2024-6387) reads: say so plainly
        if remote and nologin and high_ci:
            return lab("Race condition, possible remote code execution")
        return lab("Race condition" + (", possible privilege escalation" if high_ci and not remote else ""))
    if fam == "crypto":
        return lab("Cryptographic or certificate validation weakness")
    if fam == "info":
        return lab("Information disclosure" + (", remote" if remote else ""))
    if fam == "dos":
        return lab("Denial of service" + (", remote" if remote else ""))

    # No recognised CWE: describe from impact alone, and say so
    if v.get("attack_vector"):
        imp = [k for k, name in (("conf_impact", "confidentiality"), ("integ_impact", "integrity"),
                                 ("avail_impact", "availability"))
               if (v.get(k) or "").upper() == "HIGH"]
        if not imp:
            return "Unclassified", f"no CWE mapped; {basis_v}"
        if imp == ["avail_impact"]:
            return f"Denial of service{', remote' if remote else ''} (from impact only)", \
                f"no CWE mapped; {basis_v}"
        names = [n for k, n in (("conf_impact", "confidentiality"), ("integ_impact", "integrity"),
                                ("avail_impact", "availability")) if k in imp]
        joined = names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]
        return f"Unclassified weakness, high {joined} impact", f"no CWE mapped; {basis_v}"
    return None, "no CVSS or CWE data"


def plain_vector(v):
    """'network, no login, no user action, low complexity'."""
    parts = []
    if v.get("attack_vector"):
        parts.append(AV.get(v["attack_vector"].upper(), v["attack_vector"].lower()))
    if v.get("privileges_required"):
        parts.append(PR.get(v["privileges_required"].upper(), v["privileges_required"].lower()))
    if v.get("user_interaction"):
        parts.append(UI.get(v["user_interaction"].upper(), v["user_interaction"].lower()))
    if v.get("attack_complexity"):
        parts.append((v["attack_complexity"] or "").lower() + " complexity")
    return ", ".join(parts)


def epss_band(e):
    """Coarse band, so a daily EPSS wobble does not invalidate explanations."""
    if e is None:
        return "unknown"
    e = float(e)
    if e >= 0.5:
        return "very high (50% or more)"
    if e >= 0.1:
        return "high (10 to 50%)"
    if e >= 0.01:
        return "moderate (1 to 10%)"
    return "low (under 1%)"


# ---------------------------------------------------------------------------
# HTTP, through the proxy in the environment
# ---------------------------------------------------------------------------

def _get(url, headers=None, tries=5):
    opener = urllib.request.build_opener()     # honours HTTPS_PROXY
    delay = 6.0
    for attempt in range(1, tries + 1):
        req = urllib.request.Request(url, headers={"User-Agent": UA, **(headers or {})})
        try:
            with opener.open(req, timeout=90) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            # NVD answers 403 or 503 when rate limited: back off and retry
            if e.code in (403, 429, 500, 502, 503, 504) and attempt < tries:
                log.warning("  HTTP %s, retrying in %.0fs", e.code, delay)
                time.sleep(delay)
                delay *= 2
                continue
            raise RuntimeError(f"HTTP {e.code} from {url.split('?')[0]}")
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            if attempt < tries:
                log.warning("  %s, retrying in %.0fs", e, delay)
                time.sleep(delay)
                delay *= 2
                continue
            raise RuntimeError(f"cannot reach {url.split('?')[0]}: {e}")
    return None


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

def _db():
    import psycopg
    from psycopg.rows import dict_row
    return psycopg.connect(
        host=os.environ.get("PATCHDB_HOST", "postgres"),
        port=int(os.environ.get("PATCHDB_PORT", "5432")),
        dbname=os.environ.get("PATCHDB_NAME", "patchdb"),
        user=os.environ.get("PATCHDB_USER", "patchapi"),
        password=os.environ.get("PATCHDB_PASSWORD", ""),
        row_factory=dict_row, connect_timeout=15,
    )


def _start(conn, source):
    sid = conn.execute("INSERT INTO intel_syncs (source) VALUES (%s) RETURNING id",
                       (source,)).fetchone()["id"]
    conn.commit()
    return sid


def _finish(conn, sid, ok, items, error=None):
    conn.execute("UPDATE intel_syncs SET finished_at=now(), ok=%s, items=%s, error=%s WHERE id=%s",
                 (ok, items, (error or "")[:1000] or None, sid))
    conn.commit()


def tracked_cves(conn):
    """Every CVE referenced by an advisory we hold."""
    rows = conn.execute("SELECT DISTINCT cve_id FROM advisory_cves").fetchall()
    return sorted(r["cve_id"] for r in rows if CVE_RE.match(r["cve_id"] or ""))


NVD_COLS = ["nvd_status", "published", "last_modified", "description", "cvss_version",
            "cvss_score", "cvss_severity", "cvss_vector", "cvss_source", "attack_vector",
            "attack_complexity", "privileges_required", "user_interaction", "scope",
            "conf_impact", "integ_impact", "avail_impact", "cvss4_score", "cvss4_vector",
            "cwes", "ref_urls", "attack_class", "attack_class_basis", "cpes"]


def _save_nvd(conn, d):
    cols = ", ".join(NVD_COLS)
    ph = ", ".join(["%s"] * len(NVD_COLS))
    upd = ", ".join(f"{c}=EXCLUDED.{c}" for c in NVD_COLS)
    conn.execute(
        f"""INSERT INTO cve_details (cve_id, {cols}, nvd_fetched_at, fetch_error, updated_at)
            VALUES (%s, {ph}, now(), NULL, now())
            ON CONFLICT (cve_id) DO UPDATE SET {upd},
              nvd_fetched_at=now(), fetch_error=NULL, updated_at=now()""",
        [d["cve_id"]] + [json.dumps(d[c]) if c == "cpes" else d[c] for c in NVD_COLS])


def sync_nvd(conn, limit=None):
    """Fetch CVEs we have never fetched, or fetched too long ago."""
    ids = tracked_cves(conn)
    stale = {r["cve_id"] for r in conn.execute(
        """SELECT cve_id FROM cve_details
            WHERE nvd_fetched_at > now() - make_interval(days => %s)""",
        (REFRESH_DAYS,)).fetchall()}
    todo = [c for c in ids if c not in stale]
    if limit:
        todo = todo[:limit]
    print(f"  NVD: {len(ids)} CVEs referenced, {len(todo)} to fetch "
          f"({'with' if NVD_KEY else 'WITHOUT'} an API key, about "
          f"{max(1, round(len(todo) * NVD_PAUSE / 60))} min)")
    sid = _start(conn, "nvd")
    done = failed = 0
    headers = {"apiKey": NVD_KEY} if NVD_KEY else {}
    for i, cve_id in enumerate(todo, 1):
        try:
            res = _get(NVD_URL + "?" + urllib.parse.urlencode({"cveId": cve_id}), headers)
            vulns = (res or {}).get("vulnerabilities") or []
            if vulns:
                _save_nvd(conn, parse_nvd(vulns[0]["cve"]))
                done += 1
            else:
                conn.execute(
                    """INSERT INTO cve_details (cve_id, fetch_error, nvd_fetched_at)
                       VALUES (%s, 'not found in NVD', now())
                       ON CONFLICT (cve_id) DO UPDATE SET fetch_error='not found in NVD',
                         nvd_fetched_at=now()""", (cve_id,))
            conn.commit()
        except RuntimeError as e:
            failed += 1
            conn.rollback()
            log.warning("  %s: %s", cve_id, e)
            if failed >= 20 and failed > done:
                _finish(conn, sid, False, done, f"stopped after {failed} failures: {e}")
                raise RuntimeError(f"NVD import stopped: {e}")
        if i % 100 == 0:
            print(f"    {i}/{len(todo)}")
        time.sleep(NVD_PAUSE)
    _finish(conn, sid, failed == 0, done, f"{failed} failed" if failed else None)
    print(f"  NVD: saved {done}, failed {failed}")
    return done


def sync_kev(conn):
    """CISA's catalogue is one file. Flags are reset for CVEs no longer listed."""
    sid = _start(conn, "kev")
    data = _get(KEV_URL)
    items = (data or {}).get("vulnerabilities") or []
    if not items:
        _finish(conn, sid, False, 0, "empty KEV catalogue")
        raise RuntimeError("the KEV catalogue came back empty")
    tracked = set(tracked_cves(conn))
    kev = {v["cveID"]: v for v in items if v.get("cveID") in tracked}
    for cve_id in tracked:
        conn.execute("INSERT INTO cve_details (cve_id) VALUES (%s) ON CONFLICT DO NOTHING", (cve_id,))
    conn.execute("UPDATE cve_details SET kev=FALSE, kev_added=NULL, kev_due=NULL, "
                 "kev_ransomware=NULL, kev_name=NULL, kev_action=NULL WHERE kev")
    for cve_id, v in kev.items():
        conn.execute(
            """UPDATE cve_details SET kev=TRUE, kev_added=%s, kev_due=%s, kev_ransomware=%s,
                      kev_name=%s, kev_action=%s, updated_at=now() WHERE cve_id=%s""",
            (v.get("dateAdded"), v.get("dueDate"), v.get("knownRansomwareCampaignUse"),
             (v.get("vulnerabilityName") or "")[:300], (v.get("requiredAction") or "")[:500], cve_id))
    conn.commit()
    _finish(conn, sid, True, len(kev))
    print(f"  CISA KEV: {len(items)} in the catalogue, {len(kev)} affect CVEs you track")
    return len(kev)


def sync_epss(conn):
    ids = tracked_cves(conn)
    sid = _start(conn, "epss")
    saved = 0
    for i in range(0, len(ids), 100):
        batch = ids[i:i + 100]
        res = _get(EPSS_URL + "?" + urllib.parse.urlencode({"cve": ",".join(batch), "limit": 100}))
        for r in (res or {}).get("data") or []:
            conn.execute(
                """INSERT INTO cve_details (cve_id, epss, epss_percentile, epss_date)
                   VALUES (%s,%s,%s,%s)
                   ON CONFLICT (cve_id) DO UPDATE SET epss=EXCLUDED.epss,
                     epss_percentile=EXCLUDED.epss_percentile, epss_date=EXCLUDED.epss_date,
                     updated_at=now()""",
                (r.get("cve"), r.get("epss"), r.get("percentile"), r.get("date")))
            saved += 1
        conn.commit()
        time.sleep(1.0)
    _finish(conn, sid, True, saved)
    print(f"  FIRST EPSS: scores for {saved} of {len(ids)} CVEs")
    return saved


def sync_redhat(conn, limit=None):
    """Red Hat's view of CVEs in RHEL advisories. Red Hat backports fixes and
    often scores a CVE differently from NVD for RHEL specifically."""
    rows = conn.execute(
        """SELECT DISTINCT ac.cve_id FROM advisory_cves ac
             JOIN advisories a ON a.id = ac.advisory_id
             LEFT JOIN cve_details cd ON cd.cve_id = ac.cve_id
            WHERE a.vendor = 'redhat'
              AND (cd.rh_fetched_at IS NULL OR cd.rh_fetched_at < now() - make_interval(days => %s))""",
        (REFRESH_DAYS,)).fetchall()
    todo = [r["cve_id"] for r in rows if CVE_RE.match(r["cve_id"] or "")]
    if limit:
        todo = todo[:limit]
    print(f"  Red Hat: {len(todo)} CVEs to fetch")
    sid = _start(conn, "redhat")
    done = 0
    for cve_id in todo:
        try:
            d = _get(RH_URL.format(cve_id))
        except RuntimeError as e:
            log.warning("  %s: %s", cve_id, e)
            continue
        c3 = (d or {}).get("cvss3") or {}
        conn.execute(
            """INSERT INTO cve_details (cve_id, rh_severity, rh_cvss_score, rh_cvss_vector,
                                        rh_cwe, rh_statement, rh_fetched_at)
               VALUES (%s,%s,%s,%s,%s,%s,now())
               ON CONFLICT (cve_id) DO UPDATE SET rh_severity=EXCLUDED.rh_severity,
                 rh_cvss_score=EXCLUDED.rh_cvss_score, rh_cvss_vector=EXCLUDED.rh_cvss_vector,
                 rh_cwe=EXCLUDED.rh_cwe, rh_statement=EXCLUDED.rh_statement,
                 rh_fetched_at=now(), updated_at=now()""",
            (cve_id, (d or {}).get("threat_severity"),
             c3.get("cvss3_base_score"), c3.get("cvss3_scoring_vector"),
             (d or {}).get("cwe"), ((d or {}).get("statement") or "")[:2000] or None))
        conn.commit()
        done += 1
        time.sleep(0.3)
    _finish(conn, sid, True, done)
    print(f"  Red Hat: saved {done}")
    return done


def main():
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", choices=["nvd", "kev", "epss", "redhat"])
    ap.add_argument("--limit", type=int, help="fetch at most N CVEs from NVD and Red Hat")
    ap.add_argument("--estimate", action="store_true")
    a = ap.parse_args()

    with _db() as conn:
        if a.estimate:
            ids = tracked_cves(conn)
            have = conn.execute("SELECT count(*) AS n FROM cve_details WHERE nvd_fetched_at IS NOT NULL"
                                ).fetchone()["n"]
            left = max(0, len(ids) - have)
            print(json.dumps({"cves_referenced": len(ids), "already_fetched": have,
                              "to_fetch": left, "api_key": bool(NVD_KEY),
                              "estimated_minutes_with_key": round(left * 0.7 / 60),
                              "estimated_minutes_without_key": round(left * 6.5 / 60)}))
            return
        failures = []
        for name, fn in (("kev", sync_kev), ("epss", sync_epss),
                         ("nvd", lambda c: sync_nvd(c, a.limit)),
                         ("redhat", lambda c: sync_redhat(c, a.limit))):
            if a.only and a.only != name:
                continue
            try:
                fn(conn)
            except RuntimeError as e:
                conn.rollback()
                failures.append(f"{name}: {e}")
                print(f"  {name} FAILED: {e}")
        s = conn.execute(
            """SELECT count(*) FILTER (WHERE nvd_fetched_at IS NOT NULL) AS with_nvd,
                      count(*) FILTER (WHERE kev)                        AS kev,
                      count(*) FILTER (WHERE epss IS NOT NULL)           AS with_epss,
                      count(*) FILTER (WHERE attack_class IS NOT NULL)   AS classified
                 FROM cve_details""").fetchone()
        print(json.dumps(dict(s)))
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()


def fetch_one(conn, cve_id):
    """Fetch one CVE from NVD now and store it. For CVEs that arrive in a SOC
    list without any advisory mentioning them. Returns True if NVD had it."""
    if not CVE_RE.match(cve_id or ""):
        return False
    headers = {"apiKey": NVD_KEY} if NVD_KEY else {}
    res = _get(NVD_URL + "?" + urllib.parse.urlencode({"cveId": cve_id}), headers)
    vulns = (res or {}).get("vulnerabilities") or []
    if not vulns:
        conn.execute(
            """INSERT INTO cve_details (cve_id, fetch_error, nvd_fetched_at)
               VALUES (%s, 'not found in NVD', now())
               ON CONFLICT (cve_id) DO UPDATE SET fetch_error='not found in NVD',
                 nvd_fetched_at=now()""", (cve_id,))
        return False
    _save_nvd(conn, parse_nvd(vulns[0]["cve"]))
    return True


def fetch_kev_epss_for(conn, cve_ids):
    """Exploitation data for specific CVEs, which may not be tracked yet."""
    if not cve_ids:
        return
    try:
        data = _get(KEV_URL)
        kev = {v["cveID"]: v for v in (data or {}).get("vulnerabilities") or []
               if v.get("cveID") in set(cve_ids)}
        for cid, v in kev.items():
            conn.execute(
                """UPDATE cve_details SET kev=TRUE, kev_added=%s, kev_due=%s, kev_ransomware=%s,
                          kev_name=%s, kev_action=%s WHERE cve_id=%s""",
                (v.get("dateAdded"), v.get("dueDate"), v.get("knownRansomwareCampaignUse"),
                 (v.get("vulnerabilityName") or "")[:300], (v.get("requiredAction") or "")[:500], cid))
    except RuntimeError as e:
        log.warning("KEV lookup failed: %s", e)
    for i in range(0, len(cve_ids), 100):
        batch = cve_ids[i:i + 100]
        try:
            res = _get(EPSS_URL + "?" + urllib.parse.urlencode({"cve": ",".join(batch), "limit": 100}))
        except RuntimeError as e:
            log.warning("EPSS lookup failed: %s", e)
            break
        for r in (res or {}).get("data") or []:
            conn.execute("UPDATE cve_details SET epss=%s, epss_percentile=%s, epss_date=%s WHERE cve_id=%s",
                         (r.get("epss"), r.get("percentile"), r.get("date"), r.get("cve")))
