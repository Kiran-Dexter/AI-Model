"""The full CVE sync (r110): at fixed times each day (08:00 and 12:00 Singapore time by
default), and on "Sync now".

Each run, in order, records what it did and what went wrong in every step:

  feeds      the CVE feeds (NIST, Microsoft, Red Hat) read again, now (the hourly news check
             goes on between runs); Microsoft's monthly updates imported (the Windows build
             check needs them); CISA's exploited list read again; the age of the Red Hat /
             Oracle advisories (imported nightly from the Pulp mirror) checked
  inventory  every server asked for its inventory now (packages, programs, updates)
  wait       until every server asked has answered (at most WAIT_INVENTORY)
  advisories every server's packages and Windows build compared with the advisories again
  check      every CVE in the window checked again against the fresh inventory
  done       the counts, and each problem named: a source that failed, a server that did
             not answer (its CVEs are "cannot tell", never clean), CVEs left unchecked

A step that cannot finish never stops the run: it is recorded as a problem and the run goes
on, so the morning report always comes. Nothing here reaches a server except through its
own agent asking for work; AI-01 is not involved in any verdict.
"""
import logging
import re
from datetime import datetime, timedelta, timezone

log = logging.getLogger("patchapi.cve_sync")

TZ = timezone(timedelta(hours=8))           # the console's time zone (SGT), as the reports use
TZ_LABEL = "SGT"
DEFAULT_TIMES = ("08:00", "12:00")
TIME_RE = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)$")
GRACE = timedelta(hours=3)                  # a time missed while PATCH-01 was down runs if this recent
WAIT_FEEDS = timedelta(minutes=40)
WAIT_INVENTORY = timedelta(minutes=25)
WAIT_CHECK = timedelta(minutes=30)
ADVISORIES_OLD = timedelta(hours=30)        # the nightly Pulp import has not run
MANUAL_GAP = timedelta(minutes=10)


def utcnow():
    return datetime.now(timezone.utc)


def clean_times(times):
    """['08:00', '12:00'] from what an admin typed: HH:MM, 1 to 6 of them, sorted, no repeats."""
    out = sorted({str(t).strip() for t in (times or []) if str(t).strip()})
    if not 1 <= len(out) <= 6 or not all(TIME_RE.match(t) for t in out):
        raise ValueError("Times are HH:MM (24-hour, Singapore time), one to six of them, e.g. 08:00 and 12:00.")
    return out


def due_slot(now, times):
    """(slot, at) of the latest sync time that has passed and is within GRACE, else (None, None).
    Times are Singapore time; now is aware (UTC)."""
    local = now.astimezone(TZ)
    best = None
    for day in (local.date() - timedelta(days=1), local.date()):
        for t in times:
            m = TIME_RE.match(t)
            if not m:
                continue
            at = datetime(day.year, day.month, day.day, int(m.group(1)), int(m.group(2)), tzinfo=TZ)
            if at <= local and (best is None or at > best):
                best = at
    if best is None or local - best > GRACE:
        return None, None
    return best.strftime("%Y-%m-%d %H:%M"), best


def next_slot(now, times):
    """When the next scheduled sync starts (aware, SGT)."""
    local = now.astimezone(TZ)
    for add in (0, 1):
        day = local.date() + timedelta(days=add)
        for t in sorted(times):
            m = TIME_RE.match(t)
            if not m:
                continue
            at = datetime(day.year, day.month, day.day, int(m.group(1)), int(m.group(2)), tzinfo=TZ)
            if at > local:
                return at
    return None


def settings(conn):
    r = conn.execute("""SELECT full_sync_times, full_sync_requested_at, full_sync_requested_by, nist, msrc, redhat,
                               days_back FROM cve_feed_settings WHERE id = 1""").fetchone()
    r = dict(r or {})
    try:
        r["times"] = clean_times(r.get("full_sync_times") or DEFAULT_TIMES)
    except ValueError:
        r["times"] = list(DEFAULT_TIMES)
    return r


# ---------------------------------------------------------------------------
# Starting a run
# ---------------------------------------------------------------------------

def request(conn, user):
    """Sync now. Refused while one runs, or within MANUAL_GAP of the last start."""
    run = conn.execute("SELECT id, started_at, state FROM cve_sync_runs ORDER BY started_at DESC LIMIT 1").fetchone()
    if run and run["state"] == "running":
        raise ValueError("A full sync is running now: its progress is shown on this page.")
    if run and utcnow() - run["started_at"] < MANUAL_GAP:
        raise ValueError("A full sync started less than 10 minutes ago.")
    conn.execute("UPDATE cve_feed_settings SET full_sync_requested_at = now(), full_sync_requested_by = %s WHERE id = 1",
                 (user,))


def _start_if_due(conn, now=None):
    now = now or utcnow()
    s = settings(conn)
    kind, slot, by = None, None, None
    if s.get("full_sync_requested_at"):
        kind, slot, by = "manual", "manual " + now.strftime("%Y-%m-%dT%H:%M:%SZ"), s.get("full_sync_requested_by")
    else:
        slot, at = due_slot(now, s["times"])
        if slot:
            kind, by = "scheduled", "schedule"
            prev = conn.execute("SELECT slot, started_at FROM cve_sync_runs ORDER BY started_at DESC LIMIT 1").fetchone()
            if prev and prev["slot"] != slot and prev["started_at"] >= at - timedelta(minutes=30):
                # A Sync now just before this time did the same work: the time is marked as covered by it
                conn.execute("""INSERT INTO cve_sync_runs (slot, kind, requested_by, state, step, finished_at, report)
                                VALUES (%s, 'scheduled', 'schedule', 'done', 'done', now(), %s::jsonb)
                                ON CONFLICT DO NOTHING""",
                             (slot, _json({"covered_by": prev["slot"]})))
                conn.commit()
                return None
    if not kind:
        return None
    row = conn.execute("""INSERT INTO cve_sync_runs (slot, kind, requested_by) VALUES (%s, %s, %s)
                          ON CONFLICT DO NOTHING RETURNING *""", (slot, kind, by)).fetchone()
    if kind == "manual":
        conn.execute("UPDATE cve_feed_settings SET full_sync_requested_at = NULL WHERE id = 1")
    conn.commit()
    if row:
        log.info("full CVE sync %s started (%s)", slot, kind)
    return dict(row) if row else None


# ---------------------------------------------------------------------------
# The steps
# ---------------------------------------------------------------------------

def _save(conn, run, step=None, state=None, **report):
    run["report"].update(report)
    if step:
        run["step"] = step
    if state:
        run["state"] = state
    conn.execute("""UPDATE cve_sync_runs SET step = %s, step_at = CASE WHEN step = %s THEN step_at ELSE now() END,
                           state = %s, report = %s::jsonb,
                           finished_at = CASE WHEN %s <> 'running' THEN now() END
                     WHERE id = %s""",
                 (run["step"], run["step"], run["state"], _json(run["report"]), run["state"], run["id"]))
    conn.commit()


def _json(v):
    import json
    return json.dumps(v, default=str)


def _problem(run, text):
    run["report"].setdefault("problems", [])
    if text not in run["report"]["problems"]:
        run["report"]["problems"].append(str(text)[:400])


def _step_feeds(conn, run):
    """Ask the feeds loop for a run now, import Microsoft's updates, CISA's list."""
    conn.execute("UPDATE cve_feed_settings SET run_requested_at = now() WHERE id = 1")
    conn.commit()
    rep = {"feeds_requested_at": utcnow().isoformat()}
    try:
        from . import msrc
        kbs, cves = msrc.import_recent(conn, months=3)
        conn.commit()
        rep["microsoft_updates"] = {"ok": True, "kbs": kbs, "cves": cves}
    except Exception as e:  # noqa: BLE001 - recorded; the run goes on
        conn.rollback()
        rep["microsoft_updates"] = {"ok": False, "error": str(e)[:300]}
        _problem(run, "Microsoft's updates could not be imported (" + str(e)[:200] + "): Windows builds are compared "
                      "with the updates imported before")
    try:
        from . import cve_intel
        n = cve_intel.sync_kev(conn)
        conn.commit()
        rep["cisa_kev"] = {"ok": True, "items": n}
    except Exception as e:  # noqa: BLE001
        conn.rollback()
        rep["cisa_kev"] = {"ok": False, "error": str(e)[:300]}
        _problem(run, "CISA's list of exploited CVEs could not be read (" + str(e)[:200] + ")")
    r = conn.execute("""SELECT max(imported_at) AS at FROM advisories WHERE coalesce(os_id, '') <> 'windows'""").fetchone()
    conn.commit()
    at = r and r["at"]
    rep["linux_advisories_at"] = at
    if at and utcnow() - at > ADVISORIES_OLD:
        _problem(run, "The Red Hat / Oracle advisories were last imported " + at.astimezone(TZ).strftime("%d %b %H:%M ")
                      + TZ_LABEL + ": the nightly import (phase4-cve.sh --install-timer) has not run since")
    _save(conn, run, step="feeds_wait", **rep)


def _step_feeds_wait(conn, run):
    since = datetime.fromisoformat(run["report"]["feeds_requested_at"])
    s = settings(conn)
    enabled = [k for k in ("nist", "msrc", "redhat") if s.get(k)]
    rows = {r["source"]: dict(r) for r in conn.execute(
        "SELECT source, last_run, last_ok, error FROM cve_feed_state WHERE source = ANY(%s)", (enabled,)).fetchall()}
    conn.commit()
    fresh = [k for k in enabled if rows.get(k) and rows[k]["last_run"] and rows[k]["last_run"] >= since]
    if len(fresh) < len(enabled) and utcnow() - since < WAIT_FEEDS:
        # A run that was already going when we asked clears the request: ask again
        req = conn.execute("SELECT run_requested_at FROM cve_feed_settings WHERE id = 1").fetchone()
        if req and not req["run_requested_at"]:
            conn.execute("UPDATE cve_feed_settings SET run_requested_at = now() WHERE id = 1")
        conn.commit()
        return
    feeds = {}
    for k in enabled:
        r = rows.get(k) or {}
        ok = bool(r.get("last_ok") and r["last_ok"] >= since)
        feeds[k] = {"ok": ok, "error": None if ok else (r.get("error") or "not read in time")[:300]}
        if not ok:
            _problem(run, {"nist": "NIST NVD", "msrc": "Microsoft", "redhat": "Red Hat"}[k] + " feed not read: "
                          + feeds[k]["error"])
    _save(conn, run, step="inventory", feeds=feeds)


def _step_inventory(conn, run):
    from . import cve_impact
    asked = cve_impact.request_scan(conn, run.get("requested_by") or "schedule", reason="full CVE sync")
    try:                                          # Carbon Black EDR read again too (r111)
        with conn.transaction():
            conn.execute("UPDATE cb_servers SET sync_requested_at = now() WHERE enabled")
    except Exception:  # noqa: BLE001 - schema 057 not applied: no Carbon Black
        pass
    conn.commit()
    _save(conn, run, step="inventory_wait", inventory_requested_at=utcnow().isoformat(),
          servers_asked=[str(r["host_id"]) for r in asked])


def _step_inventory_wait(conn, run):
    since = datetime.fromisoformat(run["report"]["inventory_requested_at"])
    ids = run["report"].get("servers_asked") or []
    rows = conn.execute("""SELECT id::text AS id, hostname, last_inventory FROM hosts WHERE id::text = ANY(%s)""",
                        (ids,)).fetchall()
    conn.commit()
    missing = [r["hostname"] for r in rows if not r["last_inventory"] or r["last_inventory"] < since]
    if missing and utcnow() - since < WAIT_INVENTORY:
        return
    silent = conn.execute("""SELECT hostname FROM hosts WHERE status <> 'decommissioned'
                               AND (last_checkin IS NULL OR last_checkin <= now() - interval '1 day')
                             ORDER BY hostname LIMIT 200""").fetchall()
    conn.commit()
    if missing:
        _problem(run, f"{len(missing)} server(s) did not send their inventory in time: they were checked on their last "
                      f"inventory, and become 'cannot tell' when it is over a day old ("
                      + ", ".join(sorted(missing)[:10]) + (" ..." if len(missing) > 10 else "") + ")")
    if silent:
        _problem(run, f"{len(silent)} server(s) have not checked in for a day and were not asked: "
                      + ", ".join(r["hostname"] for r in silent[:10]) + (" ..." if len(silent) > 10 else ""))
    _save(conn, run, step="advisories", servers_reported=len(rows) - len(missing),
          servers_missing=sorted(missing)[:200], servers_silent=[r["hostname"] for r in silent])


def _step_advisories(conn, run):
    from . import cve_engine
    try:
        cve_engine.staleness_sweep(conn, force=True)
        conn.commit()
    except Exception as e:  # noqa: BLE001 - compute_host still treats stale inventory as unknown
        conn.rollback()
        log.info("full sync: staleness sweep: %s", e)
    ok = failed = 0
    for h in conn.execute("""SELECT id, hostname, os_id, os_major, status, kernel_running, reboot_required, last_inventory
                               FROM hosts WHERE status <> 'decommissioned' ORDER BY hostname""").fetchall():
        if not cve_engine.supports(h["os_id"]):
            continue
        try:
            cve_engine.compute_host(conn, h)
            conn.commit()
            ok += 1
        except Exception as e:  # noqa: BLE001 - one server never stops the rest
            conn.rollback()
            failed += 1
            log.warning("full sync: advisories for %s: %s", h["hostname"], e)
    if failed:
        _problem(run, f"the advisory check failed on {failed} server(s): see the worker log")
    from . import cve_impact
    cve_impact.inventory_changed(conn)            # every CVE checked again (no row of cve_impact locked)
    conn.commit()
    _save(conn, run, step="check", advisories_servers=ok, check_started_at=utcnow().isoformat())


def _window_left(conn, since, days):
    """(CVEs in the window, how many are checked against the inventory as it is now)."""
    from . import cve_impact
    mark = cve_impact.inventory_mark(conn)
    r = conn.execute(f"""SELECT count(*) AS total,
                                count(*) FILTER (WHERE x.inventory_mark = %(mark)s) AS done
                           FROM ({cve_impact.CANDIDATES}) c LEFT JOIN cve_impact x ON x.cve_id = c.cve_id""",
                     {"days": int(days), "mark": mark}).fetchone()
    return int(r["total"] or 0), int(r["done"] or 0)


def _step_check(conn, run, stop=lambda: False):
    """Every CVE in the window checked again (this thread does it, pass after pass)."""
    from . import cve_impact
    since = datetime.fromisoformat(run["report"]["check_started_at"])
    days = int(settings(conn).get("days_back") or 14)
    try:
        from . import rh_state
        rh_state.refresh_pass(conn, days)
        conn.commit()
    except Exception as e:  # noqa: BLE001 - checked with what is cached
        conn.rollback()
        log.info("full sync: Red Hat state: %s", e)
    last = -1
    while not stop():
        total, done = _window_left(conn, since, days)
        conn.commit()
        if done >= total or utcnow() - since > WAIT_CHECK or done == last:
            break                         # finished, out of time, or only CVEs that keep failing are left
        last = done
        if not cve_impact.analyse_pass(conn):
            break
    total, done = _window_left(conn, since, days)
    conn.commit()
    if done < total:
        if utcnow() - since <= WAIT_CHECK and not stop():
            return
        _problem(run, f"{total - done} of {total} CVEs were not checked again in time (they are at the next pass)")
    _save(conn, run, step="finish", cves_checked=done, cves_total=total)


def _step_finish(conn, run):
    from . import cve_impact
    days = int(settings(conn).get("days_back") or 14)
    c = dict(cve_impact.counts(conn, days) or {})
    conn.commit()
    counts = {k: c.get(k) for k in ("affected", "exploited_impacting", "unknown", "no_data", "waiting_confirm",
                                    "not_affected", "not_found", "checked")}
    _save(conn, run, step="done", state="problems" if run["report"].get("problems") else "done", counts=counts)
    log.info("full CVE sync %s finished: %s", run["slot"], counts)


STEPS = {"start": _step_feeds, "feeds_wait": _step_feeds_wait, "inventory": _step_inventory,
         "inventory_wait": _step_inventory_wait, "advisories": _step_advisories, "check": _step_check,
         "finish": _step_finish}
STEP_WORDS = {"start": "reading the CVE feeds and Microsoft's updates", "feeds_wait": "reading the CVE feeds",
              "inventory": "asking every server for its inventory", "inventory_wait": "waiting for the servers' inventories",
              "advisories": "comparing every server with the advisories", "check": "checking every CVE again",
              "finish": "counting", "done": "done"}


STUCK = timedelta(hours=2)


def tick(conn, stop=lambda: False):
    """One step of the running sync, or a new one when due. Returns the run (or None)."""
    run = conn.execute("SELECT * FROM cve_sync_runs WHERE state = 'running' ORDER BY id DESC LIMIT 1").fetchone()
    conn.commit()
    if run and utcnow() - run["step_at"] > STUCK:
        # The worker stopped part way (restart, crash): this run is closed so the next one can start
        run = dict(run)
        run["report"] = dict(run.get("report") or {})
        _problem(run, f"stopped at step '{STEP_WORDS.get(run['step'], run['step'])}' (the worker was restarted?)")
        _save(conn, run, state="failed")
        return run
    run = dict(run) if run else _start_if_due(conn)
    if not run:
        return None
    run["report"] = dict(run.get("report") or {})
    fn = STEPS.get(run["step"])
    if not fn:
        _save(conn, run, state="failed")
        return run
    try:
        if fn is _step_check:
            fn(conn, run, stop)
        else:
            fn(conn, run)
    except Exception as e:  # noqa: BLE001 - one step never stops the run: recorded, and on to the next
        conn.rollback()
        log.warning("full CVE sync %s, step %s: %s", run["slot"], run["step"], e)
        _problem(run, f"step '{STEP_WORDS.get(run['step'], run['step'])}' failed: {str(e)[:200]}")
        order = list(STEPS)
        nxt = order[order.index(run["step"]) + 1] if run["step"] in order and order.index(run["step"]) + 1 < len(order) else None
        if run["step"] in ("start",):
            run["report"].setdefault("feeds_requested_at", utcnow().isoformat())
        if run["step"] in ("inventory",):
            run["report"].setdefault("inventory_requested_at", utcnow().isoformat())
        if nxt == "check":
            run["report"].setdefault("check_started_at", utcnow().isoformat())
        _save(conn, run, step=nxt or "done", state=None if nxt else "failed")
    return run


def status(conn):
    """For the console: the running or last run, the last scheduled one, and the next time."""
    s = settings(conn)
    rows = [dict(r) for r in conn.execute(
        """SELECT id, slot, kind, requested_by, started_at, step, step_at, finished_at, state, report
             FROM cve_sync_runs ORDER BY started_at DESC LIMIT 6""").fetchall()]
    for r in rows:
        rep = r.get("report") or {}
        rep.pop("servers_asked", None)                  # ids: not needed on the page
        r["step_words"] = STEP_WORDS.get(r["step"], r["step"])
    nxt = next_slot(utcnow(), s["times"])
    return {"times": s["times"], "tz": TZ_LABEL, "next_at": nxt, "runs": rows,
            "requested_at": s.get("full_sync_requested_at")}
