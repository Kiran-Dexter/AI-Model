"""Asset and software inventory, merged from every source PATCH-01 has.

Assets come from four places, merged by machine name:
  agents     the servers PATCH-01 manages (exact OS, agent state)
  vCenter    every VM (guest OS, power, cluster) and every ESXi host
  WSUS       every Windows computer WSUS knows (OS, last report)
  vCenters   the vCenter appliances themselves

Each asset is put in one category, server, client or appliance (or unknown
when nothing says), with the reason, so a wrong guess can be seen and
questioned. Software comes only from agents: vCenter and WSUS report
machines, not what is installed on them.

The functions here are pure (no database), so the merging can be tested.
"""

import ipaddress
import re

CATEGORIES = ("server", "client", "appliance", "unknown")

_LINUX_SERVER = re.compile(r"red hat|rhel|oracle linux|\bol ?\d|centos|rocky|alma|ubuntu|debian|suse|sles|amazon linux|fedora")
_APPLIANCE = re.compile(r"photon|vmware|esxi|vcenter|appliance|freebsd|netscaler|fortios|pan-os|junos|cisco|\bf5\b|big-ip|"
                        r"nsx|ontap|data domain|other \S* ?linux|other \(|other 3|other 4|other 5|other 6")
_WINDOWS_CLIENT = re.compile(r"windows (10|11|8|7|xp|vista)\b")


def classify(os_text, kind=None):
    """(category, reason) for one machine. kind is "esxi" or "vcenter" for
    VMware's own systems, which are always appliances."""
    if kind == "esxi":
        return "appliance", "ESXi host"
    if kind == "vcenter":
        return "appliance", "vCenter"
    t = (os_text or "").strip().lower()
    if not t:
        return "unknown", "no operating system reported"
    if "windows" in t and "server" in t:
        return "server", "Windows Server"
    if _WINDOWS_CLIENT.search(t) or ("windows" in t and "server" not in t and "microsoft" in t and re.search(r"\b(10|11)\b", t)):
        return "client", "Windows desktop edition"
    if "mac os" in t or "macos" in t:
        return "client", "macOS"
    if _APPLIANCE.search(t):
        return "appliance", "appliance or generic guest OS (" + os_text.strip()[:40] + ")"
    if _LINUX_SERVER.search(t):
        return "server", "Linux server distribution"
    if "windows" in t:
        return "server", "Windows (edition not stated)"
    if "linux" in t:
        return "server", "Linux"
    return "unknown", "unrecognised OS (" + os_text.strip()[:40] + ")"


def short_name(name):
    """The machine's short name, lower case, as the merge key."""
    n = (name or "").strip().lower().rstrip(".")
    if not n:
        return ""
    try:
        ipaddress.ip_address(n)
        return n                             # an address is kept whole
    except ValueError:
        return n.split(".")[0]


_OS_NAMES = {"rhel": "RHEL", "ol": "Oracle Linux", "ubuntu": "Ubuntu", "windows": "Windows Server"}


def _agent_os(h):
    if h.get("os_edition"):
        return h["os_edition"]
    base = _OS_NAMES.get(h.get("os_id") or "", h.get("os_id") or "")
    return (base + " " + (h.get("os_version") or "")).strip()


def merge(hosts, vms, wsus, esxi, vcenters):
    """One record per machine, from all sources. Each argument is a list of
    rows (dicts) as read from the database."""
    assets = {}
    by_host_id = {}

    def get(key, name):
        if key not in assets:
            assets[key] = {"name": name, "key": key, "sources": [], "os": None, "os_from": None, "ips": [],
                           "agent": None, "vm": None, "wsus": None, "esxi": None, "vcenter": None, "last_seen": None}
        return assets[key]

    def seen(a, when):
        if when and (a["last_seen"] is None or str(when) > str(a["last_seen"])):
            a["last_seen"] = when

    def add_ip(a, ip):
        for x in re.split(r"[,\s]+", str(ip or "")):
            x = x.strip()
            if x and x not in a["ips"] and not x.startswith(("fe80", "127.", "169.254")) and x != "::1":
                a["ips"].append(x)

    def set_os(a, text, src, rank):
        # Precedence: agent (exact) > WSUS > vCenter's configured guest OS
        order = {"agent": 3, "wsus": 2, "vcenter": 1}
        if text and (a["os"] is None or order.get(src, 0) > order.get(a["os_from"], 0)):
            a["os"], a["os_from"] = text, src

    for h in hosts:
        key = short_name(h.get("hostname"))
        if not key:
            continue
        a = get(key, h.get("hostname"))
        a["sources"].append("agent")
        a["agent"] = {"host_id": str(h["id"]), "version": h.get("agent_version"), "status": h.get("status"),
                      "last_checkin": h.get("last_checkin"), "os_id": h.get("os_id")}
        set_os(a, _agent_os(h), "agent", 3)
        add_ip(a, h.get("agent_ip"))
        seen(a, h.get("last_checkin"))
        by_host_id[str(h["id"])] = a

    for v in vms:
        a = by_host_id.get(str(v.get("host_id"))) if v.get("host_id") else None
        if a is None:
            key = short_name(v.get("guest_hostname")) or short_name(v.get("name"))
            if not key:
                continue
            a = get(key, v.get("guest_hostname") or v.get("name"))
        if "vcenter" not in a["sources"]:
            a["sources"].append("vcenter")
        a["vm"] = {"vcenter": v.get("vcenter"), "vm_name": v.get("name"), "cluster": v.get("cluster"),
                   "esxi_host": v.get("esxi_host"), "power": v.get("power_state"), "cpu": v.get("num_cpu"),
                   "memory_mb": v.get("memory_mb"), "tools": v.get("tools_running"), "folder": v.get("folder_path")}
        set_os(a, v.get("guest_os"), "vcenter", 1)
        add_ip(a, v.get("guest_ips"))
        seen(a, v.get("synced_at"))

    for w in wsus:
        key = short_name(w.get("name"))
        if not key:
            continue
        a = get(key, w.get("name"))
        if "wsus" not in a["sources"]:
            a["sources"].append("wsus")
        prev = a["wsus"] or {}
        a["wsus"] = {"source": ", ".join(sorted({x for x in (prev.get("source"), w.get("source")) if x})),
                     "groups": w.get("groups") or [], "last_reported": w.get("last_reported"),
                     "needed": w.get("needed"), "failed": w.get("failed")}
        set_os(a, w.get("os"), "wsus", 2)
        add_ip(a, w.get("ip"))
        seen(a, w.get("last_reported"))

    for e in esxi:
        key = short_name(e.get("name"))
        if not key:
            continue
        a = get(key, e.get("name"))
        a["sources"].append("vcenter")
        a["esxi"] = {"vcenter": e.get("vcenter"), "cluster": e.get("cluster"), "model": " ".join(
            x for x in (e.get("vendor"), e.get("model")) if x), "version": e.get("esxi_full_name") or e.get("esxi_version"),
            "state": e.get("connection_state"), "vm_count": e.get("vm_count"), "maintenance": e.get("maintenance_mode")}
        a["os"] = a["os"] or (e.get("esxi_full_name") or "VMware ESXi")
        a["os_from"] = a["os_from"] or "vcenter"
        seen(a, e.get("synced_at"))

    for c in vcenters:
        key = short_name(c.get("host")) or short_name(c.get("name"))
        if not key:
            continue
        a = get(key, c.get("host") or c.get("name"))
        a["sources"].append("vcenter")
        a["vcenter"] = {"name": c.get("name"), "version": c.get("version"), "last_ok": c.get("last_ok")}
        a["os"] = a["os"] or ("VMware vCenter " + (c.get("version") or "")).strip()
        a["os_from"] = a["os_from"] or "vcenter"
        seen(a, c.get("last_sync_at"))

    out = []
    for a in assets.values():
        kind = "esxi" if a["esxi"] else "vcenter" if a["vcenter"] else None
        a["category"], a["category_reason"] = classify(a["os"], kind)
        a["sources"] = sorted(set(a["sources"]))
        a["managed"] = a["agent"] is not None
        out.append(a)
    out.sort(key=lambda x: (CATEGORIES.index(x["category"]), x["name"].lower()))
    return out


def summarise(assets):
    """Counts per category: total, with an agent, without."""
    s = {c: {"total": 0, "managed": 0, "unmanaged": 0} for c in CATEGORIES}
    for a in assets:
        c = s[a["category"]]
        c["total"] += 1
        c["managed" if a["managed"] else "unmanaged"] += 1
    return s
