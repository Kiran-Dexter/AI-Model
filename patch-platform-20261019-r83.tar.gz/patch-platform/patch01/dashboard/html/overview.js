/* Overview: the top of the Patch Dashboard. Headline figures with their change
 * since last week, updates installed per day (this month against last month),
 * servers patched per week, compliance goals, recent jobs and live activity.
 *
 * Everything comes from GET /api/v1/overview and is put into the page as text
 * or numbers (createElement / createElementNS, textContent); never as HTML.
 * Charts are drawn here in SVG: one axis each, a legend for two series, and a
 * tooltip on hover or keyboard focus. Series colours come from the theme
 * (--ch1.. in shell.css), validated as a set on each theme's panel colour.
 */
"use strict";

let ovSeq = 0;
const OV_FMT = new Intl.NumberFormat();
const ovNum = v => (v === null || v === undefined) ? "–" : OV_FMT.format(v);

/* A round number at or above v, for the top of an axis */
function ovNice(v) {
  if (!(v > 0)) return 4;
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  const f = v / p;
  return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p;
}

function ovDate(iso, opts) {
  const d = new Date(String(iso).slice(0, 10) + "T12:00:00");
  return isNaN(d) ? String(iso) : d.toLocaleDateString(undefined, opts || { day: "numeric", month: "short" });
}

function ovCard(cls, title, kids, extra) {
  return h("section", { class: "ov-card " + (cls || ""), "aria-label": title },
    h("div", { class: "ov-card-h" }, h("h2", null, title), extra || null), kids);
}

/* ---- headline figures --------------------------------------------------- */

const OV_KPI_LINK = { online: "#/hosts?agent=online", to_patch: "#/advisories?state=affected",
  critical_cves: "#/impact?verdict=affected", success_pct: "#/changes" };

function ovKpi(k, i, hasHistory) {
  const val = k.value === null || k.value === undefined ? "–" : ovNum(k.value) + (k.unit || "");
  let sub = null;
  if (k.key === "online" || k.key === "to_patch") sub = "of " + ovNum(k.of) + " servers";
  if (k.key === "critical_cves") sub = k.extra === null || k.extra === undefined ? "0-day count not known yet"
    : k.extra ? ovNum(k.extra) + " of them 0-day" : "none are 0-day";
  if (k.key === "success_pct") sub = k.extra ? ovNum(k.extra) + " server jobs finished" : "no patch jobs yet";
  let delta;
  if (k.delta === null || k.delta === undefined) {
    delta = h("span", { class: "ov-d ov-d-none" }, hasHistory ? "No change figure for this one yet" : "Change since last week: known after a week of history");
  } else if (k.delta === 0) {
    delta = h("span", { class: "ov-d ov-d-flat" }, "● No change since last week");
  } else {
    const up = k.delta > 0;
    const better = (up && k.good === "up") || (!up && k.good === "down");
    const amt = Math.abs(k.delta);
    const words = k.unit === "%" ? amt.toFixed(1) + (up ? " points up on" : " points down on")
                                 : ovNum(amt) + (up ? " more than" : " fewer than");
    delta = h("span", { class: "ov-d " + (better ? "ov-d-good" : "ov-d-bad") },
      (up ? "\u25b2 " : "\u25bc ") + words + " last week");
  }
  return h("a", { class: "ov-kpi ov-k" + (i + 1), href: OV_KPI_LINK[k.key] || "#/dashboard" },
    h("span", { class: "ov-kpi-l" }, k.label),
    h("span", { class: "ov-kpi-v" }, val),
    sub ? h("span", { class: "ov-kpi-s" }, sub) : null,
    delta);
}

/* ---- tooltip shared by the charts --------------------------------------- */

function ovTip(host) {
  const tip = h("div", { class: "ov-tip", role: "status", "aria-live": "polite", hidden: true });
  host.append(tip);
  return {
    show(lines, x, y) {
      tip.replaceChildren(...lines.map((l, i) => h(i ? "div" : "strong", null,
        l.key ? h("span", { class: "ov-tip-k " + l.key, "aria-hidden": "true" }) : null, l.text)));
      tip.hidden = false;
      const hw = host.clientWidth, tw = tip.offsetWidth;
      tip.style.left = Math.max(4, Math.min(hw - tw - 4, x - tw / 2)) + "px";
      tip.style.top = Math.max(0, y - tip.offsetHeight - 10) + "px";
    },
    hide() { tip.hidden = true; },
  };
}

function ovLegend(items) {
  return h("ul", { class: "ov-legend" }, items.map(([cls, label, dashed]) =>
    h("li", null, h("span", { class: "ov-key " + cls + (dashed ? " ov-key-dash" : ""), "aria-hidden": "true" }), label)));
}

/* ---- updates installed per day: this month and last month --------------- */

function ovInstalls(ins) {
  const W = 640, H = 230, L = 44, R = 12, T = 12, B = 26;
  const a = ins.this_month || [], b = ins.last_month || [];
  const n = Math.max(a.length, b.length, 28);
  const top = ovNice(Math.max(1, ...a.filter(v => v !== null), ...b));
  const x = i => L + (i * (W - L - R)) / (n - 1);
  const y = v => T + (H - T - B) * (1 - v / top);
  const id = "ovg" + (++ovSeq);
  const pts = arr => arr.map((v, i) => v === null || v === undefined ? null : [x(i), y(v)]).filter(Boolean);
  const line = p => p.map((q, i) => (i ? "L" : "M") + q[0].toFixed(1) + " " + q[1].toFixed(1)).join(" ");
  const pa = pts(a), pb = pts(b);
  const grid = [0, 0.25, 0.5, 0.75, 1].map(f => {
    const v = top * f, yy = y(v);
    return [svg("line", { x1: L, x2: W - R, y1: yy, y2: yy, class: "ov-grid" + (f === 0 ? " ov-base" : "") }),
            svg("text", { x: L - 8, y: yy + 4, "text-anchor": "end", class: "ov-ax" }, ovNum(Math.round(v)))];
  });
  const xt = [1, 5, 10, 15, 20, 25, 30].filter(d => d <= n).map(d =>
    svg("text", { x: x(d - 1), y: H - 6, "text-anchor": "middle", class: "ov-ax" }, String(d)));
  const area = pa.length > 1 ? svg("path", { class: "ov-area", fill: "url(#" + id + ")",
    d: line(pa) + " L" + pa[pa.length - 1][0].toFixed(1) + " " + y(0) + " L" + pa[0][0].toFixed(1) + " " + y(0) + " Z" }) : null;
  const cross = svg("line", { class: "ov-cross", x1: 0, x2: 0, y1: T, y2: H - B, visibility: "hidden" });
  const dotA = svg("circle", { r: 4.5, class: "ov-dot s1", visibility: "hidden" });
  const dotB = svg("circle", { r: 4.5, class: "ov-dot s2", visibility: "hidden" });
  const hit = svg("rect", { x: L, y: T, width: W - L - R, height: H - T - B, class: "ov-hit", tabindex: 0,
    role: "img", "aria-label": "Updates installed per day. This month " + ovNum(ins.total_this) + ", last month " + ovNum(ins.total_last) + ". Use the arrow keys to read each day." });
  const pic = svg("svg", { viewBox: `0 0 ${W} ${H}`, class: "ov-svg" },
    svg("defs", null, svg("linearGradient", { id, x1: 0, x2: 0, y1: 0, y2: 1 },
      svg("stop", { offset: "0%", class: "ov-stop-top" }), svg("stop", { offset: "100%", class: "ov-stop-bot" }))),
    grid.flat(), xt, area,
    pb.length > 1 ? svg("path", { class: "ov-line s2 ov-dash", d: line(pb) }) : null,
    pa.length > 1 ? svg("path", { class: "ov-line s1", d: line(pa) }) : null,
    cross, dotB, dotA, hit);
  const wrap = h("div", { class: "ov-plot" }, pic);
  const tip = ovTip(wrap);
  const month = ovDate(ins.month, { month: "long" }), last = ovDate(ins.last, { month: "long" });
  let cur = -1;
  function at(i) {
    i = Math.max(0, Math.min(n - 1, i)); cur = i;
    const va = a[i], vb = b[i];
    const sx = pic.clientWidth / W, sy = pic.clientHeight / H;
    cross.setAttribute("x1", x(i)); cross.setAttribute("x2", x(i)); cross.setAttribute("visibility", "visible");
    [[dotA, va], [dotB, vb]].forEach(([d, v]) => {
      if (v === null || v === undefined) { d.setAttribute("visibility", "hidden"); return; }
      d.setAttribute("cx", x(i)); d.setAttribute("cy", y(v)); d.setAttribute("visibility", "visible");
    });
    tip.show([{ text: "Day " + (i + 1) },
      { key: "s1", text: month + ": " + (va === null || va === undefined ? "not yet" : ovNum(va)) },
      { key: "s2", text: last + ": " + (vb === undefined ? "no such day" : ovNum(vb)) }],
      x(i) * sx, Math.min(y(va || 0), y(vb || 0)) * sy);
  }
  function off() { cur = -1; tip.hide(); [cross, dotA, dotB].forEach(e => e.setAttribute("visibility", "hidden")); }
  hit.addEventListener("pointermove", e => {
    const r = pic.getBoundingClientRect();
    const px = (e.clientX - r.left) / (r.width / W);
    at(Math.round((px - L) / ((W - L - R) / (n - 1))));
  });
  hit.addEventListener("pointerleave", off);
  hit.addEventListener("blur", off);
  hit.addEventListener("focus", () => at(cur < 0 ? (a.filter(v => v !== null).length || 1) - 1 : cur));
  hit.addEventListener("keydown", e => {
    if (e.key === "ArrowLeft" || e.key === "ArrowRight") { e.preventDefault(); at(cur + (e.key === "ArrowLeft" ? -1 : 1)); }
  });
  // Month so far against the same days of last month
  const sofar = a.filter(v => v !== null && v !== undefined).length;
  const lastSame = b.slice(0, sofar).reduce((t, v) => t + (v || 0), 0);
  const trend = lastSame ? Math.round(100 * (ins.total_this - lastSame) / lastSame) : null;
  return ovCard("ov-installs", "Updates installed per day",
    [h("p", { class: "ov-big" }, h("strong", null, ovNum(ins.total_this)), " this month",
       h("span", { class: "muted" }, " · " + ovNum(ins.total_last) + " in all of " + last
         + (trend !== null ? " \u00b7 " + (trend >= 0 ? "+" : "") + trend + "% on the same days last month" : ""))),
     wrap],
    ovLegend([["s1", month], ["s2", last, true]]));
}

/* ---- servers patched per week, Windows and Linux ------------------------- */

function ovRoundTop(x, y, w, hgt, r) {
  r = Math.min(r, w / 2, hgt);
  if (hgt <= 0) return "";
  return `M${x} ${y + hgt}V${y + r}Q${x} ${y} ${x + r} ${y}H${x + w - r}Q${x + w} ${y} ${x + w} ${y + r}V${y + hgt}Z`;
}

function ovWeekly(weeks) {
  const W = 420, H = 230, L = 40, R = 8, T = 12, B = 26;
  const top = ovNice(Math.max(1, ...weeks.map(w => Math.max(w.windows, w.linux))));
  const gw = (W - L - R) / Math.max(1, weeks.length);
  const bw = Math.min(16, (gw - 10) / 2);
  const y = v => T + (H - T - B) * (1 - v / top);
  const pic = svg("svg", { viewBox: `0 0 ${W} ${H}`, class: "ov-svg" });
  [0, 0.5, 1].forEach(f => {
    pic.append(svg("line", { x1: L, x2: W - R, y1: y(top * f), y2: y(top * f), class: "ov-grid" + (f === 0 ? " ov-base" : "") }),
      svg("text", { x: L - 7, y: y(top * f) + 4, "text-anchor": "end", class: "ov-ax" }, ovNum(Math.round(top * f))));
  });
  const wrap = h("div", { class: "ov-plot" }, pic);
  const tip = ovTip(wrap);
  weeks.forEach((w, i) => {
    const cx = L + gw * i + gw / 2;
    const xa = cx - bw - 1, xb = cx + 1;
    const g = svg("g", { class: "ov-bar-g", tabindex: 0, role: "img",
      "aria-label": "Week of " + ovDate(w.week) + ": Windows " + w.windows + ", Linux " + w.linux });
    g.append(svg("rect", { x: L + gw * i, y: T, width: gw, height: H - T - B, class: "ov-hit" }),
      svg("path", { d: ovRoundTop(xa, y(w.windows), bw, y(0) - y(w.windows), 4), class: "ov-bar s1" }),
      svg("path", { d: ovRoundTop(xb, y(w.linux), bw, y(0) - y(w.linux), 4), class: "ov-bar s2" }));
    if ((weeks.length - 1 - i) % 2 === 0 || weeks.length <= 5)
      pic.append(svg("text", { x: cx, y: H - 6, "text-anchor": "middle", class: "ov-ax" }, ovDate(w.week)));
    const show = () => {
      const sx = pic.clientWidth / W, sy = pic.clientHeight / H;
      tip.show([{ text: "Week of " + ovDate(w.week) }, { key: "s1", text: "Windows: " + ovNum(w.windows) },
        { key: "s2", text: "Linux: " + ovNum(w.linux) }], cx * sx, y(Math.max(w.windows, w.linux)) * sy);
      g.classList.add("on");
    };
    const hide = () => { tip.hide(); g.classList.remove("on"); };
    g.addEventListener("pointerenter", show); g.addEventListener("focus", show);
    g.addEventListener("pointerleave", hide); g.addEventListener("blur", hide);
    pic.append(g);
  });
  return ovCard("ov-weekly", "Servers patched per week", [wrap], ovLegend([["s1", "Windows"], ["s2", "Linux"]]));
}

/* ---- goals ---------------------------------------------------------------- */

function ovGoals(goals, overall) {
  const R = 46, C = 2 * Math.PI * R;
  const v = overall === null || overall === undefined ? null : Math.max(0, Math.min(100, overall));
  const ring = svg("svg", { viewBox: "0 0 120 120", class: "ov-ring", "aria-hidden": "true" },
    svg("circle", { cx: 60, cy: 60, r: R, class: "ov-ring-track" }),
    svg("circle", { cx: 60, cy: 60, r: R, class: "ov-ring-val", transform: "rotate(-90 60 60)",
      "stroke-dasharray": ((v || 0) / 100 * C).toFixed(1) + " " + C.toFixed(1) }),
    svg("text", { x: 60, y: 62, "text-anchor": "middle", class: "ov-ring-n" }, v === null ? "–" : Math.round(v) + "%"),
    svg("text", { x: 60, y: 80, "text-anchor": "middle", class: "ov-ring-l" }, "of targets"));
  const rows = goals.map(g => {
    const p = g.pct === null || g.pct === undefined ? null : Math.max(0, Math.min(100, g.pct));
    const met = p !== null && p >= g.target;
    return h("li", { class: "ov-goal" },
      h("div", { class: "ov-goal-h" }, h("span", null, g.label),
        h("span", { class: "ov-goal-v" }, p === null ? "not known yet" : g.pct + "%",
          h("span", { class: "muted" }, " / target " + g.target + "%"), met ? h("span", { class: "ov-met" }, " ✓ met") : null)),
      h("div", { class: "ov-goal-bar", role: "meter", "aria-valuemin": "0", "aria-valuemax": "100",
                 "aria-valuenow": p === null ? null : String(p), "aria-label": g.label },
        h("span", { class: "ov-goal-fill", "data-w": p === null ? 0 : p }),
        h("span", { class: "ov-goal-t", "data-w": g.target, title: "Target " + g.target + "%" })));
  });
  const card = ovCard("ov-goals", "Compliance goals",
    [h("div", { class: "ov-goals-body" }, h("div", { class: "ov-ring-wrap", role: "img",
       "aria-label": v === null ? "Not known yet" : Math.round(v) + "% of the targets reached on average" }, ring),
     h("ul", { class: "ov-goal-list" }, rows))]);
  // Widths through the CSSOM: the content security policy allows that, not inline style attributes
  card.querySelectorAll("[data-w]").forEach(e => {
    const w = Number(e.dataset.w) || 0;
    if (e.classList.contains("ov-goal-t")) e.style.left = w + "%"; else e.style.width = w + "%";
  });
  return card;
}

/* ---- recent jobs and live activity ---------------------------------------- */

function ovTime(at) {
  const d = new Date(at);
  if (isNaN(d)) return "";
  const today = new Date().toDateString() === d.toDateString();
  return today ? d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })
               : d.toLocaleDateString(undefined, { day: "numeric", month: "short" }) + " " + d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}

function ovRecent(recent) {
  const rows = recent || [];
  const body = rows.length ? table([
    { label: "Change", cell: r => h("a", { href: "#/change/" + encodeURIComponent(r.id), class: "mono" }, r.ref), nowrap: true },
    { label: "What", cell: r => [h("span", { class: "ov-what", title: r.title || "" }, r.title || (KIND_LABEL[r.kind] || r.kind)),
                                 h("span", { class: "ov-when" }, ovTime(r.at))] },
    { label: "State", cell: r => changeMark(r.state), nowrap: true },
    { label: "Servers", num: true, cell: r => r.failed ? [ovNum(r.servers), h("span", { class: "ov-fail" }, " \u00b7 " + r.failed + " failed")] : ovNum(r.servers) },
  ], rows, { onRow: r => { location.hash = "#/change/" + encodeURIComponent(r.id); } })
    : h("p", { class: "muted" }, "No jobs yet.");
  return ovCard("ov-recent", "Recent jobs", [body], h("a", { href: "#/changes", class: "small" }, "All jobs"));
}

function ovActivity(events, offline) {
  const items = (events || []).map(e => h("li", { class: "ov-ev " + (e.ok === true ? "ok" : e.ok === false ? "bad" : "run") },
    h("span", { class: "ov-ev-dot", "aria-hidden": "true" }),
    h("div", { class: "ov-ev-b" },
      h("div", { class: "ov-ev-h" }, h("a", { href: "#/change/" + encodeURIComponent(e.change_id), class: "mono" }, e.ref),
        h("span", { class: "ov-ev-s" }, e.ok === true ? "passed" : e.ok === false ? "failed" : "in progress"),
        h("time", { datetime: e.at || "" }, ovTime(e.at))),
      h("p", { class: "ov-ev-m" }, e.message || e.event))));
  const off = (offline || []).length ? h("div", { class: "ov-off" },
    h("h3", null, "Stopped reporting in the last 24 hours"),
    h("ul", null, offline.map(o => h("li", null,
      h("a", { href: "#/hosts?q=" + encodeURIComponent(o.hostname) }, o.hostname),
      h("span", { class: "muted" }, " last seen " + ovTime(o.last_checkin)))))) : null;
  return ovCard("ov-activity", "Live activity",
    [items.length ? h("ul", { class: "ov-tl" }, items) : h("p", { class: "muted" }, "Nothing has happened yet."), off],
    h("span", { class: "ov-live" }, h("span", { class: "ov-live-dot", "aria-hidden": "true" }), "Live"));
}

/* ---- the whole top of the Overview ---------------------------------------- */

function drawOverviewTop(ov) {
  if (!ov || !Array.isArray(ov.kpis)) return null;
  return h("div", { class: "ov" },
    h("div", { class: "ov-kpis" }, ov.kpis.map((k, i) => ovKpi(k, i, ov.has_history))),
    h("div", { class: "ov-row ov-row-a" }, ovInstalls(ov.installs || {}), ovGoals(ov.goals || [], ov.goals_overall)),
    h("div", { class: "ov-row ov-row-b" }, ovWeekly(ov.weekly || []), ovActivity(ov.events, ov.went_offline)),
    ovRecent(ov.recent));
}
