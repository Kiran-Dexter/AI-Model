-- ---------------------------------------------------------------------------
-- 071 (r135) Remediation: the target date
--
-- The date by which findings must be fixed or decommissioned. A quarter can have its own; 'default' is used by
-- every quarter without one. A finding still outstanding (anything but Fixed or Decommission) after its own New
-- Target Completion Date, or after the target date when it has none, is overdue.
--
-- rem_targets   quarter ("2026 Q3", or 'default') -> target date, who set it and when
-- Re-run safe: the default is set once (29 Dec 2026) and never put back over a person's choice.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS rem_targets (
    quarter    TEXT PRIMARY KEY CHECK (quarter = 'default' OR quarter ~ '^[0-9]{4} Q[1-4]$'),
    target_on  DATE NOT NULL,
    set_by     TEXT NOT NULL,
    set_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO rem_targets (quarter, target_on, set_by)
VALUES ('default', DATE '2026-12-29', 'schema 071')
ON CONFLICT (quarter) DO NOTHING;

INSERT INTO schema_version (version, description)
VALUES (71, 'Remediation: the target date')
ON CONFLICT (version) DO NOTHING;
