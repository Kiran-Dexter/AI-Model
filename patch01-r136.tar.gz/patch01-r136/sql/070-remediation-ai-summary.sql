-- ---------------------------------------------------------------------------
-- 070 (r134) Remediation: AI-01's summary of a view (for example the open Critical findings)
--
-- PATCH-01 groups the view's findings by plugin and counts them, with their hosts, from the database. AI-01 is
-- given each issue's own text from the uploaded file (Synopsis, Description, Steps to Remediate, a sample of the
-- plugin output) and writes the themes, what is wrong and how to fix it, and what to fix first; it names issues by
-- number only, never hosts or counts, which PATCH-01 adds itself. Kept, so a view's summary is there the next time.
--
-- rem_ai_summaries   one summary: the view (quarter and filters), its state, the result, who and when
-- Re-run safe.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS rem_ai_summaries (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    quarter      TEXT NOT NULL,
    filters      JSONB NOT NULL,
    filter_key   TEXT NOT NULL,                 -- the view, written the same way each time
    state        TEXT NOT NULL DEFAULT 'running' CHECK (state IN ('running', 'done', 'failed')),
    phase        TEXT,                          -- waiting (AI-01 busy) / writing
    result       JSONB,
    error        TEXT,
    created_by   TEXT NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at  TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS rem_ai_summaries_view ON rem_ai_summaries (filter_key, created_at DESC);

INSERT INTO schema_version (version, description)
VALUES (70, 'Remediation: AI-01 summary of a view')
ON CONFLICT (version) DO NOTHING;
