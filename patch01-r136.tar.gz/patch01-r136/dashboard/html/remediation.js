/* ---- Vulnerabilities > Remediation -------------------------------------------------
 * The quarterly Nessus scan workbook: upload it, confirm how its columns were read (PATCH-01's rules, then AI-01
 * for the columns the rules cannot place), and follow every finding by severity, host, PIC, status and
 * Categorization1/2, quarter against quarter. Statuses, PIC, dates and exceptions are changed here (one finding
 * or many at once) with who and when; each host carries its device type, Application / Infra and team.
 * The export writes the quarter back in the file's own columns.
 */

const RM_BASE = "/nessus/remediation";
const RM_SEV = { 4: ["Critical", "sv-crit"], 3: ["High", "sv-high"], 2: ["Medium", "sv-med"], 1: ["Low", "sv-low"], 0: ["Info", "rm-sv-info"],
  "-1": ["Not given", "rm-sv-info"] };
const RM_STATUS = { open: "Open", fixed: "Fixed", pending_review: "Pending review", false_positive: "False positive",
  pending_deviation: "Pending deviation approval", deviation_approved: "Deviation approved", decommission: "Decommission" };
const RM_OPEN = new Set(["open", "pending_review", "pending_deviation"]);
const RM_NO_ACTION = ["fixed", "decommission"];
const RM_CARRIED = { status: "status", pic: "PIC", exception: "exception", target_on: "target date", cat1: "Categorization1",
  cat2: "Categorization2", env: "UAT/Prod" };
const rmCarried = list => (list || []).map(k => RM_CARRIED[k] || k).join(", ");                       // their own section: nothing left to do
const RM_ACTION_ORDER = ["open", "pending_review", "pending_deviation", "false_positive", "deviation_approved"];
const RM_KIND = { server: "Server", network: "Network device", appliance: "Appliance", unknown: "Type not known",
  not_in_inventory: "Not in the inventory" };
const RM_TEAM = { application: "Application", infra: "Infra" };
const RM_GROUPS = [["host", "Host"], ["severity", "Severity"], ["status", "Status"], ["pic", "PIC"], ["cat2", "Categorization2"],
  ["cat1", "Categorization1"], ["kind", "Device type"], ["env", "UAT/Prod"], ["team", "Team"], ["plugin", "Plugin"], ["none", "No grouping"]];
const RM_TABS = [["summary", "Summary"], ["categories", "Categories"], ["findings", "Findings"], ["hosts", "Hosts"], ["uploads", "Uploads"]];
const RM_CAT_FILTERS = ["pic", "pic_blank", "kind", "team_type", "env", "env_blank"];
const RM_HOW = { rule: ["Rule", "rm-how-rule"], close: ["Close spelling", "rm-how-rule"], saved: ["Saved", "rm-how-saved"],
  ai: ["AI-01", "rm-how-ai"], you: ["You", "rm-how-you"], clash: ["Taken", "rm-how-clash"] };
const RM_FILTERS = ["sev", "status", "open", "pic", "cat1", "cat2", "env", "kind", "team_type", "host", "overdue", "came_back", "new", "q",
  "pic_blank", "cat1_blank", "cat2_blank", "env_blank"];

// Fills an element: lists are flattened and empty parts left out (replaceChildren would write "null")
function rmPut(el, ...nodes) {
  el.replaceChildren(...nodes.flat(Infinity).filter(n => n !== null && n !== undefined && n !== false));
  return el;
}

function rmSev(n) {
  const [t, cls] = RM_SEV[n === null || n === undefined ? -1 : n] || RM_SEV[-1];
  return h("span", { class: "sv " + cls }, t);
}

function rmStatus(st) {
  return h("span", { class: "rm-st rm-st-" + st }, RM_STATUS[st] || st);
}

function rmQuery(p) {
  const u = new URLSearchParams();
  for (const [k, v] of Object.entries(p)) if (v !== undefined && v !== null && v !== "") u.set(k, v);
  return u.toString();
}

function rmHash(p) { return "#/remediation?" + rmQuery(p); }

function rmDate(v) { return v ? fmtDate(v) : ""; }

function rmBytes(n) {
  n = Number(n || 0);
  return n >= 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB";
}

async function renderRemediation(params) {
  setNav("vulns");
  const home = await api(RM_BASE);
  const qs = home.quarters || [];
  const st = {};
  for (const k of RM_FILTERS) if (params.get(k)) st[k] = params.get(k);
  st.quarter = params.get("quarter") && qs.some(q => q.quarter === params.get("quarter")) ? params.get("quarter") : (qs[0] || {}).quarter;
  st.tab = RM_TABS.some(t => t[0] === params.get("tab")) ? params.get("tab") : (qs.length ? "summary" : "uploads");
  st.by = RM_GROUPS.some(g => g[0] === params.get("by")) ? params.get("by") : "host";
  st.upload = params.get("upload") || null;
  const page = h("div", { class: "rm" });
  render(page);
  rmDraw(page, home, st);
}

function rmDraw(page, home, st) {
  const qs = home.quarters || [];
  const edit = !!home.can_edit;
  // after the first import (or a quarter gone), a quarter that exists; with none yet, only Uploads can be open
  if (!qs.some(q => q.quarter === st.quarter)) st.quarter = qs.length ? qs[0].quarter : undefined;
  if (!qs.length) st.tab = "uploads";
  const say = h("p", { class: "cm-meta rm-msg", role: "status", "aria-live": "polite" });
  const tell = (t, bad) => { say.textContent = t || ""; say.classList.toggle("hd-failed", !!bad); };
  const busy = (home.uploads || []).find(u => ["reading", "review", "importing"].includes(u.state) && !u.stalled);

  // the address keeps the tab, quarter and filters, so a refresh or a shared link opens the same view
  const keep = () => history.replaceState(null, "", rmHash(Object.assign({ tab: st.tab, quarter: st.quarter, by: st.by !== "host" ? st.by : null,
    upload: st.tab === "uploads" ? st.upload : null }, rmFiltersOf(st))));
  const go = (tab, extra) => {
    st.tab = tab;
    if (extra) { for (const k of RM_FILTERS) delete st[k]; Object.assign(st, extra); }
    keep();
    rmDraw(page, home, st);
  };

  const qSel = qs.length ? h("select", { "aria-label": "Quarter", class: "rm-q", on: { change: e => { st.quarter = e.target.value; keep(); rmDraw(page, home, st); } } },
    qs.map(q => h("option", { value: q.quarter, selected: q.quarter === st.quarter }, q.quarter + " · " + q.findings + " findings"))) : null;
  const upBtn = edit ? h("button", { type: "button", class: "btn", on: { click: () => rmPickFile(page, home, st, tell) } }, "Upload scan file") : null;
  const exBtn = qs.length ? h("button", { type: "button", class: "btn btn-quiet", "data-own-export": "1", on: { click: async e => {
    const b = e.currentTarget; b.disabled = true; tell("Building the Excel file…");
    try {
      const n = await downloadFile(RM_BASE + "/export?" + rmQuery(Object.assign({ quarter: st.quarter }, rmFiltersOf(st))), "remediation.xlsx");
      tell("Exported " + n + " finding" + (n === "1" ? "" : "s") + " of " + st.quarter + " in the file's own columns, with a Summary sheet.");
    } catch (err) { tell(err.message, true); }
    b.disabled = false;
  } } }, "Export Excel") : null;

  const tabs = h("div", { class: "filters rm-tabs", role: "tablist", "aria-label": "Show" },
    RM_TABS.map(([k, label]) => h("button", { type: "button", role: "tab", "aria-selected": String(st.tab === k), "aria-pressed": String(st.tab === k),
      disabled: !qs.length && k !== "uploads", on: { click: () => go(k) } }, label)));
  const body = h("div", { class: "rm-body" });
  rmPut(page, 
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure vulns --remediation" }, "Remediation"),
      h("div", { class: "head-actions" }, qSel, exBtn, upBtn)),
    h("p", { class: "muted small rm-intro" }, "The quarterly Nessus scan workbook: findings by severity, host, PIC and status, "
      + "quarter against quarter. Upload the file once a quarter; statuses, PIC, dates and exceptions are kept here with who changed what."),
    busy && st.tab !== "uploads" ? h("div", { class: "rm-banner" }, h("strong", null, busy.file_name + ": "),
      busy.state === "review" ? "waiting for you to confirm how its columns were read. " : busy.state === "reading" ? "being read… " : "being imported… ",
      h("button", { type: "button", class: "btn-link", on: { click: () => { st.upload = busy.id; go("uploads"); } } }, "Open")) : null,
    tabs, say, body);

  if (st.tab === "summary") rmSummary(body, st, go, tell).catch(e => rmFail(body, e));
  else if (st.tab === "categories") rmCategories(body, st, go, keep).catch(e => rmFail(body, e));
  else if (st.tab === "findings") rmFindings(body, st, edit, tell, keep).catch(e => rmFail(body, e));
  else if (st.tab === "hosts") rmHosts(body, st, edit, tell, go).catch(e => rmFail(body, e));
  else rmUploads(page, body, home, st, edit, tell, go).catch(e => rmFail(body, e));
}

function rmFail(box, e) {
  if (e instanceof StaleRoute) return;
  rmPut(box, h("div", { class: "empty" }, h("p", null, e.message || "This could not be read.")));
}

function rmFiltersOf(st) {
  const out = {};
  for (const k of RM_FILTERS) if (st[k]) out[k] = st[k];
  return out;
}

/* ---- Summary --------------------------------------------------------------------- */

async function rmSummary(box, st, go, tell) {
  rmPut(box, h("p", { class: "muted small" }, "Counting…"));
  const [s, cats, home] = await Promise.all([api(RM_BASE + "/summary?" + rmQuery({ quarter: st.quarter })),
    api(RM_BASE + "/categories?" + rmQuery({ quarter: st.quarter })), api(RM_BASE)]);
  const t = s.totals;
  const grid = {};
  for (const m of s.matrix) grid[m.severity + "|" + m.status] = Number(m.n);
  const link = (label, f, cls) => h("button", { type: "button", class: "btn-link " + (cls || ""), on: { click: () => go("findings", f) } }, label);

  const tile = (n, label, cls, f, title) => h(f ? "button" : "div", { type: f ? "button" : null, class: "srv-tile rm-tile " + (cls || ""), title: title || null,
    on: f ? { click: () => go("findings", f) } : null }, h("span", { class: "srv-tile-n" }, String(n || 0)), h("span", { class: "srv-tile-l" }, label));
  const bySev = {};
  for (const r of s.by_sev || []) bySev[r.k] = r;
  const sevTiles = h("div", { class: "srv-tiles rm-sevtiles", role: "group", "aria-label": "Outstanding findings by severity" },
    [4, 3, 2, 1, 0].map(sv => { const r = bySev[sv] || { outstanding: 0, total: 0, pct_outstanding: null };
      return tile(r.outstanding, RM_SEV[sv][0] + " outstanding of " + r.total + (r.total ? " · " + rmPctText(r.pct_outstanding) : ""), "rm-t-" + sv, { sev: String(sv) }); }));
  const prev = s.previous;
  const moreTiles = h("div", { class: "srv-tiles", role: "group", "aria-label": "This quarter" },
    tile(t.outstanding, "Outstanding of " + t.total + " · " + rmPctText(t.pct_outstanding), "", {}, "Everything but Fixed and Decommission"),
    tile(t.overdue, "Overdue", t.overdue ? "t-off" : "", { overdue: "1" }, "Outstanding, and past its own New Target date, or past the target date when it has none"),
    tile(t.hosts, "Hosts", "", null),
    prev ? tile(t.new, "New since " + prev, "", { new: "1" }) : null,
    prev ? tile(t.came_back, "Fixed in " + prev + ", found again", t.came_back ? "t-warn" : "", { came_back: "1" }) : null,
    prev ? tile(s.gone_since_previous, "In " + prev + ", not in " + st.quarter, "t-on", null, "Findings of the previous quarter's file that this quarter's file does not have") : null);
  const doneTiles = h("div", { class: "rm-done-tiles" }, h("span", { class: "rm-tiles-label" }, "No action needed"),
    h("div", { class: "srv-tiles", role: "group", "aria-label": "No action needed" },
      tile(t.fixed, "Fixed", "t-on", { status: "fixed" }), tile(t.decom, "Decommission", "", { status: "decommission" })));

  // severity x status, with each row's outstanding and % outstanding, and the column totals
  const statusKeys = RM_ACTION_ORDER.concat(RM_NO_ACTION);
  const na = k => RM_NO_ACTION.includes(k) ? " rm-na" + (k === RM_NO_ACTION[0] ? " rm-na-first" : "") : "";
  const sevRows = [4, 3, 2, 1, 0, -1].filter(sv => sv !== -1 || bySev[-1]);
  const cell0 = (n, f, cls) => n ? link(String(n), f, cls) : h("span", { class: "muted" }, "0");
  const matrix = h("div", { class: "table-wrap no-enh" }, h("table", { class: "rm-matrix" },
    h("thead", null,
      h("tr", { class: "rm-matrix-groups" }, h("th", { scope: "col", rowspan: "2" }, "Severity"),
        h("th", { scope: "colgroup", colspan: String(RM_ACTION_ORDER.length + 1), class: "rm-ma" }, "Outstanding"),
        h("th", { scope: "colgroup", colspan: String(RM_NO_ACTION.length), class: "rm-na rm-na-first" }, "Fixed / Decom"),
        h("th", { scope: "col", rowspan: "2", class: "num" }, "All"), h("th", { scope: "col", rowspan: "2", class: "num" }, "% outstanding")),
      h("tr", null, RM_ACTION_ORDER.map(k => h("th", { scope: "col", class: "num" }, RM_STATUS[k])), h("th", { scope: "col", class: "num rm-sum" }, "Total"),
        RM_NO_ACTION.map(k => h("th", { scope: "col", class: "num" + na(k) }, RM_STATUS[k])))),
    h("tbody", null, sevRows.map(sv => { const r = bySev[sv] || { outstanding: 0, total: 0, pct_outstanding: null };
      return h("tr", null, h("th", { scope: "row" }, rmSev(sv)),
        RM_ACTION_ORDER.map(k => h("td", { class: "num" }, cell0(grid[sv + "|" + k] || 0, { sev: String(sv), status: k }))),
        h("td", { class: "num rm-sum" }, cell0(r.outstanding, { sev: String(sv) })),
        RM_NO_ACTION.map(k => h("td", { class: "num" + na(k) }, cell0(grid[sv + "|" + k] || 0, { sev: String(sv), status: k }))),
        h("td", { class: "num" }, cell0(r.total, { sev: String(sv), status: statusKeys.join(",") })), rmPctCell(r.pct_outstanding)); })),
    h("tfoot", null, h("tr", null, h("th", { scope: "row" }, "Total"),
      RM_ACTION_ORDER.map(k => h("td", { class: "num" }, String(sevRows.reduce((a, sv) => a + (grid[sv + "|" + k] || 0), 0)))),
      h("td", { class: "num rm-sum" }, String(t.outstanding)),
      RM_NO_ACTION.map(k => h("td", { class: "num" + na(k) }, String(sevRows.reduce((a, sv) => a + (grid[sv + "|" + k] || 0), 0)))),
      h("td", { class: "num" }, String(t.total)), rmPctCell(t.pct_outstanding)))));

  const label = { pic: k => k || h("span", { class: "muted" }, "(blank)"), env: k => k || h("span", { class: "muted" }, "(blank)"),
    kind: k => RM_KIND[k] || k, team_type: k => RM_TEAM[k] || h("span", { class: "muted" }, "Not set yet") };
  const filt = { pic: k => k === "" ? { pic_blank: "1" } : { pic: k }, env: k => k === "" ? { env_blank: "1" } : { env: k },
    kind: k => ({ kind: k }), team_type: k => ({ team_type: k || "none" }) };
  const section = (title, rows, key, note) => h("section", { class: "rm-by" }, h("h3", null, title),
    rmTallyTable(title, rows.map(r => ({ row: r, label: label[key](r.k), filter: filt[key](r.k) })), t, go), note ? h("p", { class: "muted small" }, note) : null);

  rmPut(box,
    rmTarget(s, st, home.can_edit, () => rmSummary(box, st, go, tell), tell),
    h("p", { class: "muted small" }, (prev ? "Compared with " + prev + ", the quarter before it in PATCH-01. "
      : "No earlier quarter in PATCH-01 yet: once the next quarter is uploaded, new, fixed and found-again findings are shown. ")
      + "Outstanding: everything but Fixed and Decommission."),
    sevTiles, moreTiles, doneTiles,
    h("section", { class: "rm-by" }, h("h3", null, "Severity and status"), matrix),
    rmAiPick(st, go),
    h("section", { class: "rm-by" }, h("div", { class: "rm-by-head" }, h("h3", null, "By category: Categorization2 › Categorization1"),
      h("button", { type: "button", class: "btn-link", on: { click: () => go("categories") } }, "Filter by PIC, device or team")),
      rmCatTree(cats, go, {}, false)),
    section("PIC", s.by_pic, "pic"),
    section("Device type", s.by_kind, "kind", "From the inventory (Inventory › Assets) by host name, else by IP address; a person's choice on the Hosts tab wins."),
    section("UAT/Prod", s.by_env, "env"),
    section("Application / Infra", s.by_team, "team_type", "Set per host on the Hosts tab."));
}

// % as the server worked it out (one decimal; 0% and 100% only when exact)
function rmPctText(v) {
  if (v === null || v === undefined) return "–";
  return (v === 0 || v === 100 ? String(v) : v.toFixed(1)) + "%";
}

function rmPctCell(v) {
  return h("td", { class: "num rm-pct" }, v === null || v === undefined ? h("span", { class: "muted" }, "–") : [
    h("span", { class: "rm-pctbar", "aria-hidden": "true" }, h("span", { style: { width: Math.min(100, v) + "%" } })), rmPctText(v)]);
}

// The tally every section shows: outstanding per severity and in all, Fixed / Decom, all, % outstanding, overdue,
// with a total line that is the quarter's (so a section always adds up). items: [{row, label, filter}]
const RM_TALLY_ALL = "open,pending_review,pending_deviation,false_positive,deviation_approved,fixed,decommission";
function rmTallyHead(first, extra) {
  return h("thead", null,
    h("tr", { class: "rm-matrix-groups" }, h("th", { scope: "col", rowspan: "2" }, first),
      h("th", { scope: "colgroup", colspan: "6", class: "rm-ma" }, "Outstanding"),
      h("th", { scope: "col", rowspan: "2", class: "num rm-na rm-na-first" }, "Fixed / Decom"),
      h("th", { scope: "col", rowspan: "2", class: "num" }, "All"), h("th", { scope: "col", rowspan: "2", class: "num" }, "% outstanding"),
      h("th", { scope: "col", rowspan: "2", class: "num" }, "Overdue"), extra ? h("th", { scope: "col", rowspan: "2", class: "num" }, extra) : null),
    h("tr", null, ["Critical", "High", "Medium", "Low", "Info"].map(x => h("th", { scope: "col", class: "num" }, x)),
      h("th", { scope: "col", class: "num rm-sum" }, "Total")));
}

function rmTallyCells(r, f, go) {
  const cnt = (n, extra, cls) => Number(n) ? h("button", { type: "button", class: "btn-link " + (cls || ""),
    on: { click: () => go("findings", Object.assign({}, f, extra)) } }, String(n)) : h("span", { class: "muted" }, "0");
  return [...[4, 3, 2, 1, 0].map(n => h("td", { class: "num" }, cnt(r["s" + n], { sev: String(n) }, n >= 1 ? "rm-c-" + n : ""))),
    h("td", { class: "num rm-sum" }, cnt(r.outstanding, {})),
    h("td", { class: "num rm-na rm-na-first" }, cnt(r.done, { status: "fixed,decommission" })),
    h("td", { class: "num" }, cnt(r.total, { status: RM_TALLY_ALL })),
    rmPctCell(r.pct_outstanding),
    h("td", { class: "num" }, cnt(r.overdue, { overdue: "1" }, "rm-bad"))];
}

function rmTallyTable(first, items, total, go) {
  if (!items.length) return h("p", { class: "muted small" }, "Nothing yet.");
  return h("div", { class: "table-wrap no-enh" }, h("table", { class: "rm-tally" }, rmTallyHead(first),
    h("tbody", null, items.map(x => h("tr", null, h("td", null, x.label), rmTallyCells(x.row, x.filter, go)))),
    h("tfoot", null, h("tr", null, h("th", { scope: "row" }, "Total"), rmTallyCells(total, {}, go)))));
}

// The target date: days left, % done, the pace it needs; an operator changes it for the quarter or for all
function rmTarget(s, st, edit, again, tell) {
  const t = s.totals, g = s.target || {};
  const box = h("section", { class: "rm-target", "aria-label": "Progress to the target date" });
  const when = d => new Date(d + "T00:00:00").toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
  const form = () => {
    const d = h("input", { type: "date", value: g.date || "", "aria-label": "Target date" });
    const scope = h("select", { "aria-label": "For" }, h("option", { value: st.quarter }, "for " + st.quarter + " only"),
      h("option", { value: "default", selected: g.from !== "quarter" }, "for every quarter without its own date"));
    const save = h("button", { type: "button", class: "btn", on: { click: async () => {
      if (!d.value) { tell("Choose a date.", true); return; }
      save.disabled = true;
      try { await apiSend("PUT", RM_BASE + "/target", { quarter: scope.value, date: d.value }); tell("Target date saved."); again(); }
      catch (e) { tell(e.message, true); save.disabled = false; }
    } } }, "Save");
    const back = g.from === "quarter" ? h("button", { type: "button", class: "btn-link", on: { click: async () => {
      try { await apiSend("PUT", RM_BASE + "/target", { quarter: st.quarter, date: "" }); tell(st.quarter + " uses the default target date again."); again(); }
      catch (e) { tell(e.message, true); } } } }, "Use the default for " + st.quarter) : null;
    return h("div", { class: "rm-filterbar rm-target-form" }, d, scope, save, back,
      h("button", { type: "button", class: "btn btn-quiet", on: { click: () => draw() } }, "Cancel"));
  };
  const draw = (editing) => {
    if (!g.date) {
      rmPut(box, h("h3", null, "Progress"), h("p", { class: "muted" }, "No target date is set: overdue goes by each finding's own New Target date, else the file's Overdue?."),
        edit ? (editing ? form() : h("button", { type: "button", class: "btn", on: { click: () => draw(true) } }, "Set the target date")) : null);
      return;
    }
    const left = g.days_left;
    const state = left > 0 ? left + " day" + (left === 1 ? "" : "s") + " left" : left === 0 ? "the target date is today" : "passed " + (-left) + " day" + (left === -1 ? "" : "s") + " ago";
    rmPut(box,
      h("div", { class: "rm-target-head" }, h("h3", null, "Progress to " + when(g.date)),
        h("span", { class: "chip" + (left < 0 ? " chip-bad" : left <= 14 ? " chip-warn" : "") }, state),
        h("span", { class: "muted small" }, (g.from === "default" ? "the default target date" : st.quarter + "'s own target date") + " · today " + when(g.today)),
        edit && !editing ? h("button", { type: "button", class: "btn-link", on: { click: () => draw(true) } }, "Change") : null),
      editing ? form() : null,
      h("div", { class: "rm-progress-bar", role: "img", "aria-label": rmPctText(t.pct_done) + " fixed or decommissioned, " + rmPctText(t.pct_outstanding) + " outstanding" },
        h("span", { class: "rm-pb-done", style: { width: (t.pct_done || 0) + "%" } }), h("span", { class: "rm-pb-out", style: { width: (t.pct_outstanding || 0) + "%" } })),
      h("div", { class: "rm-target-nums" },
        h("span", null, h("strong", null, String(t.outstanding)), " outstanding of " + t.total + " (" + rmPctText(t.pct_outstanding) + ")"),
        h("span", null, h("strong", null, String(t.done)), " fixed / decommissioned (" + rmPctText(t.pct_done) + ")"),
        h("span", { class: t.overdue ? "rm-bad" : "" }, h("strong", null, String(t.overdue)), " overdue"),
        left > 0 && t.outstanding ? h("span", null, "to meet it: ", h("strong", null, String(g.per_week)), " a week (" + g.per_day + " a day)") : null,
        left > 0 && !t.outstanding ? h("span", { class: "rm-good" }, "nothing outstanding") : null),
      h("p", { class: "muted small" }, "Overdue: outstanding (anything but Fixed and Decommission) after its own New Target date, or after the target date when it has none."));
  };
  draw();
  return box;
}

// The Summary's AI-01 card: one severity (Critical first), what needs action or only what is open
function rmAiPick(st, go) {
  const wrap = h("div", { class: "rm-ai-pick" });
  const sev = h("select", { "aria-label": "Severity to summarise" }, [4, 3, 2, 1, 0].map(n => h("option", { value: String(n) }, RM_SEV[n][0])),
    h("option", { value: "4,3" }, "Critical and High"));
  const scope = h("select", { "aria-label": "Which findings" }, h("option", { value: "action" }, "that need action"),
    h("option", { value: "open" }, "that are open"));
  const mount = () => {
    const p = { quarter: st.quarter, sev: sev.value, [scope.value]: "1" };
    const label = sev.options[sev.selectedIndex].text + " " + scope.options[scope.selectedIndex].text;
    rmPut(slot, rmAiPanel(p, go, { label }));
  };
  const slot = h("div");
  sev.addEventListener("change", mount);
  scope.addEventListener("change", mount);
  rmPut(wrap, h("div", { class: "rm-filterbar" }, h("span", { class: "rm-tiles-label" }, "Summarise"), sev, scope), slot);
  mount();
  return wrap;
}

/* ---- Categories: Categorization2 › Categorization1 › severity ---------------------- */

// The tree as a table: an ER item (Categorization2) per row, its Categorization1 groups under it, each with the tally
// (outstanding per severity, outstanding, Fixed / Decom, all, % outstanding, overdue, hosts). Every count opens its findings.
function rmCatTree(data, go, base, expanded) {
  const tree = data.tree || [];
  if (!tree.length) return h("p", { class: "muted small" }, "No findings match.");
  const catF = (c2, c1) => Object.assign({}, base, c2 === "" ? { cat2_blank: "1" } : { cat2: c2 },
    c1 === undefined ? {} : c1 === "" ? { cat1_blank: "1" } : { cat1: c1 });
  const tb = h("tbody");
  for (const t of tree) {
    const kids = t.children || [];
    const label = t.cat2 === "" ? h("span", { class: "muted" }, "(blank)")
      : t.er_code ? [h("strong", { class: "mono" }, t.er_code), h("span", null, " " + t.er_title)] : h("strong", null, t.cat2);
    const rows = kids.map(k => h("tr", { class: "rm-tree-kid", hidden: !expanded },
      h("td", { class: "rm-tree-c1" }, h("span", { class: "rm-tree-elbow", "aria-hidden": "true" }, "└"),
        k.cat1 === "" ? h("span", { class: "muted" }, "(blank)") : k.cat1),
      rmTallyCells(k, catF(t.cat2, k.cat1), go), h("td", { class: "num" }, String(k.hosts))));
    const btn = h("button", { type: "button", class: "srv-plus", "aria-expanded": String(!!expanded),
      "aria-label": (expanded ? "Collapse " : "Expand ") + (t.cat2 || "(blank)") }, expanded ? "−" : "+");
    btn.addEventListener("click", () => {
      const open = btn.getAttribute("aria-expanded") !== "true";
      btn.setAttribute("aria-expanded", String(open)); btn.textContent = open ? "−" : "+";
      btn.setAttribute("aria-label", (open ? "Collapse " : "Expand ") + (t.cat2 || "(blank)"));
      for (const r of rows) r.hidden = !open;
    });
    tb.append(h("tr", { class: "rm-tree-top" }, h("td", null, h("div", { class: "rm-tree-name" }, btn,
      h("span", null, label, h("span", { class: "muted small" }, " · " + kids.length + " group" + (kids.length === 1 ? "" : "s"))))),
      rmTallyCells(t, catF(t.cat2), go), h("td", { class: "num" }, String(t.hosts))), ...rows);
  }
  const tot = data.total || {};
  return h("div", { class: "table-wrap no-enh" }, h("table", { class: "rm-tree rm-tally" },
    rmTallyHead("Categorization2 › Categorization1", "Hosts"), tb,
    h("tfoot", null, h("tr", null, h("th", { scope: "row" }, "All categories"), rmTallyCells(tot, Object.assign({}, base), go),
      h("td", { class: "num" }, String(tot.hosts || 0))))));
}

async function rmCategories(box, st, go, keep) {
  rmPut(box, h("p", { class: "muted small" }, "Counting…"));
  const s = await api(RM_BASE + "/summary?" + rmQuery({ quarter: st.quarter }));
  const own = () => { const f = {}; for (const k of RM_CAT_FILTERS) if (st[k]) f[k] = st[k]; return f; };
  const treeBox = h("div");
  const load = async () => {
    rmPut(treeBox, h("p", { class: "muted small" }, "Counting…"));
    try {
      const c = await api(RM_BASE + "/categories?" + rmQuery(Object.assign({ quarter: st.quarter }, own())));
      rmPut(treeBox, rmCatTree(c, go, own(), (c.tree || []).length <= 12),
        h("p", { class: "muted small" }, c.total.outstanding + " outstanding of " + c.total.total + " findings (" + rmPctText(c.total.pct_outstanding) + ") on "
          + c.total.hosts + " host" + (c.total.hosts === 1 ? "" : "s") + ". Click a count to see those findings and change them."));
    } catch (e) { if (!(e instanceof StaleRoute)) rmPut(treeBox, h("p", { class: "hd-failed" }, e.message)); }
  };
  const set = (k, v, blankKey) => {
    delete st[k]; if (blankKey) delete st[blankKey];
    if (v === "\u0000" && blankKey) st[blankKey] = "1"; else if (v) st[k] = v;
    keep(); load();
  };
  const sel = (k, label, rows, blankKey) => h("select", { "aria-label": label, on: { change: e => set(k, e.target.value, blankKey) } },
    h("option", { value: "" }, label + ": all"),
    blankKey && rows.some(r => r.k === "") ? h("option", { value: "\u0000", selected: !!st[blankKey] }, label + ": (blank)") : null,
    rows.filter(r => r.k !== "").map(r => h("option", { value: r.k, selected: st[k] === r.k }, (r.label || r.k) + " (" + r.total + ")")));
  const toggleAll = open => treeBox.querySelectorAll(".rm-tree-top .srv-plus").forEach(b => {
    if ((b.getAttribute("aria-expanded") === "true") !== open) b.click(); });
  rmPut(box,
    h("p", { class: "muted small" }, "Each ER item (Categorization2) with its Categorization1 groups: outstanding by severity, Fixed / Decom and % outstanding, for "
      + st.quarter + ". The worst first."),
    h("div", { class: "rm-filterbar" },
      sel("pic", "PIC", s.by_pic, "pic_blank"),
      sel("kind", "Device", s.by_kind.map(r => ({ k: r.k, label: RM_KIND[r.k] || r.k, total: r.total }))),
      sel("team_type", "Team", s.by_team.map(r => ({ k: r.k || "none", label: RM_TEAM[r.k] || "Not set", total: r.total }))),
      sel("env", "UAT/Prod", s.by_env, "env_blank"),
      h("button", { type: "button", class: "btn-link", on: { click: () => toggleAll(true) } }, "Expand all"),
      h("button", { type: "button", class: "btn-link", on: { click: () => toggleAll(false) } }, "Collapse all")),
    treeBox);
  load();
}

/* ---- Findings -------------------------------------------------------------------- */

async function rmFindings(box, st, edit, tell, keep) {
  const sel = new Set();
  let allMode = false;
  rmPut(box, h("p", { class: "muted small" }, "Loading…"));
  const s = await api(RM_BASE + "/summary?" + rmQuery({ quarter: st.quarter }));
  // the main list: what needs action (a status chosen in the filter shows that status, Fixed and Decommission too)
  const q = () => Object.assign({ quarter: st.quarter }, rmFiltersOf(st), st.status ? {} : { action: "1" });
  const set = (k, v) => { if (v === "" || v === null || v === undefined) delete st[k]; else st[k] = v; keep(); load(); };

  const options = (rows, key) => rows.map(r => r.k === "" ? null : h("option", { value: r.k, selected: st[key] === r.k }, r.k + " (" + r.total + ")"));
  const selectOf = (key, label, rows, blankKey) => {
    const s2 = h("select", { "aria-label": label, on: { change: e => {
      delete st[key]; delete st[blankKey];
      if (e.target.value === "\u0000") st[blankKey] = "1"; else if (e.target.value) st[key] = e.target.value;
      keep(); load(); } } },
      h("option", { value: "" }, label + ": all"),
      rows.some(r => r.k === "") ? h("option", { value: "\u0000", selected: !!st[blankKey] }, label + ": (blank)") : null, options(rows, key));
    return s2;
  };
  const search = h("input", { type: "search", placeholder: "Search host, IP, plugin, CVE, PIC", "aria-label": "Search", value: st.q || "" });
  let tq = null;
  search.addEventListener("input", () => { clearTimeout(tq); tq = setTimeout(() => set("q", search.value.trim()), 300); });
  const sevs = new Set((st.sev || "").split(",").filter(Boolean));
  const sevBtns = h("div", { class: "filters rm-sevs", role: "group", "aria-label": "Severity" }, [4, 3, 2, 1, 0].map(sv => h("button", {
    type: "button", class: "rm-sevbtn rm-t-" + sv, "aria-pressed": String(sevs.has(String(sv))), on: { click: e => {
      sevs.has(String(sv)) ? sevs.delete(String(sv)) : sevs.add(String(sv));
      e.currentTarget.setAttribute("aria-pressed", String(sevs.has(String(sv))));
      set("sev", [...sevs].join(","));
    } } }, RM_SEV[sv][0])));
  const statusSel = h("select", { "aria-label": "Status", on: { change: e => set("status", e.target.value) } },
    h("option", { value: "" }, "Status: all"), Object.entries(RM_STATUS).map(([k, v]) => h("option", { value: k, selected: st.status === k }, v)));
  const kindSel = h("select", { "aria-label": "Device type", on: { change: e => set("kind", e.target.value) } },
    h("option", { value: "" }, "Device: all"), Object.entries(RM_KIND).map(([k, v]) => h("option", { value: k, selected: st.kind === k }, v)));
  const teamSel = h("select", { "aria-label": "Application or Infra", on: { change: e => set("team_type", e.target.value) } },
    h("option", { value: "" }, "Team: all"), h("option", { value: "application", selected: st.team_type === "application" }, "Application"),
    h("option", { value: "infra", selected: st.team_type === "infra" }, "Infra"), h("option", { value: "none", selected: st.team_type === "none" }, "Not set"));
  const check = (key, label) => h("label", { class: "chk rm-chk" }, h("input", { type: "checkbox", checked: !!st[key],
    on: { change: e => set(key, e.target.checked ? "1" : "") } }), " " + label);
  const bySel = h("select", { "aria-label": "Group by", on: { change: e => { st.by = e.target.value; keep(); load(); } } },
    RM_GROUPS.map(([k, v]) => h("option", { value: k, selected: st.by === k }, "Group by: " + v)));
  const anyFilter = () => RM_FILTERS.some(k => st[k]);
  const clear = h("button", { type: "button", class: "btn-link", on: { click: () => {
    for (const k of RM_FILTERS) delete st[k]; keep(); rmFindings(box, st, edit, tell, keep); } } }, "Clear filters");

  const list = h("div", { class: "rm-list" });
  const bar = h("div", { class: "rm-bulk", hidden: true, role: "region", "aria-label": "Change the chosen findings" });
  const head = h("p", { class: "muted small rm-count", role: "status" });
  const doneBox = h("div");
  const aiSlot = h("details", { class: "rm-ai-wrap" }, h("summary", null, "AI-01 summary of these findings"));
  const mountAi = () => {
    const open = aiSlot.open;
    const p = q();
    rmPut(aiSlot, h("summary", null, "AI-01 summary of these findings"), open ? rmAiPanel(p, (t, f) => { st.tab = t; for (const k of RM_FILTERS) delete st[k]; Object.assign(st, f); keep(); rmFindings(box, st, edit, tell, keep); }, { label: "the findings shown" }) : null);
    aiSlot.dataset.view = JSON.stringify(p);
  };
  aiSlot.addEventListener("toggle", () => { if (aiSlot.open && !aiSlot.querySelector(".rm-ai")) mountAi(); });
  rmPut(box, 
    h("div", { class: "rm-filterbar" }, search, sevBtns, statusSel,
      selectOf("pic", "PIC", s.by_pic, "pic_blank"), selectOf("cat2", "Categorization2", s.by_cat2, "cat2_blank"),
      selectOf("cat1", "Categorization1", s.by_cat1, "cat1_blank"), selectOf("env", "UAT/Prod", s.by_env, "env_blank"), kindSel, teamSel),
    h("div", { class: "rm-filterbar" }, check("open", "Only open"), check("overdue", "Overdue"),
      s.previous ? check("came_back", "Fixed in " + s.previous + ", found again") : null, s.previous ? check("new", "New since " + s.previous) : null,
      st.host ? h("span", { class: "chip" }, "Host: " + st.host, " ", h("button", { type: "button", class: "btn-link", "aria-label": "Show every host",
        on: { click: () => set("host", "") } }, "×")) : null,
      bySel, anyFilter() ? clear : null),
    aiSlot, head, list, doneBox, bar);

  const drawBar = () => {
    const n = allMode ? Number(head.dataset.total || 0) : sel.size;
    bar.hidden = !edit || !n;
    if (bar.hidden) return;
    rmPut(bar, rmBulkForm(n, allMode, async (changes, note) => {
      const body = allMode ? { all: true, set: changes, note } : { ids: [...sel], set: changes, note };
      const r = await apiSend("POST", RM_BASE + "/findings/bulk?" + rmQuery(q()), body);
      tell(r.changed + " of " + r.findings + " finding" + (r.findings === 1 ? "" : "s") + " changed"
        + (r.changed < r.findings ? " (the others already had these values)." : "."));
      sel.clear(); allMode = false; load();
    }, () => { sel.clear(); allMode = false; list.querySelectorAll("input[data-fid], input[data-gall]").forEach(b => { b.checked = false; }); drawBar(); },
    !allMode && Number(head.dataset.total || 0) > sel.size ? () => { allMode = true; drawBar(); } : null, Number(head.dataset.total || 0), tell));
  };

  const findingTable = (rows) => {
    const tb = h("tbody");
    for (const r of rows) {
      const box1 = edit ? h("input", { type: "checkbox", "data-fid": r.id, checked: sel.has(r.id) || allMode, "aria-label": "Choose " + (r.plugin_name || r.plugin_id) + " on " + (r.hostname || r.ip),
        on: { click: e => e.stopPropagation(), change: e => { e.target.checked ? sel.add(r.id) : sel.delete(r.id); allMode = false; drawBar(); } } }) : null;
      const tags = [];
      if (r.came_back) tags.push(h("span", { class: "chip chip-warn", title: "It was Fixed in " + s.previous }, "found again"));
      else if (s.previous && !r.in_previous) tags.push(h("span", { class: "chip", title: "Not in " + s.previous }, "new"));
      if ((r.carried || []).length) tags.push(h("span", { class: "chip", title: "Blank in this quarter's file; taken from " + s.previous + ": " + rmCarried(r.carried) }, "from " + s.previous));
      const tr = h("tr", { class: "clickable" },
        edit ? h("td", { class: "rm-cb" }, box1) : null,
        h("td", null, rmSev(r.severity)),
        h("td", null, h("div", { class: "rm-plug" }, r.plugin_name || ""), h("div", { class: "muted small mono" }, r.plugin_id + (r.cve ? " · " + r.cve : ""))),
        h("td", null, h("strong", null, r.hostname || r.ip || ""), r.hostname && r.ip ? h("div", { class: "muted small mono" }, r.ip) : null),
        h("td", { class: "mono nowrap" }, (r.port || "") + (r.protocol ? "/" + r.protocol : "")),
        h("td", null, r.pic || h("span", { class: "muted" }, "–")),
        h("td", null, rmStatus(r.status), tags.length ? h("div", { class: "rm-tags" }, tags) : null),
        h("td", { class: "nowrap" }, r.due_on ? [rmDate(r.due_on), r.due_from_target ? h("div", { class: "muted small" }, "target date") : null]
          : h("span", { class: "muted" }, "–"),
          r.overdue ? h("div", null, h("span", { class: "chip chip-bad" }, "overdue")) : null),
        h("td", { class: "small" }, r.er_code || r.cat2 || h("span", { class: "muted" }, "–")));
      const detail = h("tr", { class: "rm-detail", hidden: true }, h("td", { colspan: edit ? 9 : 8 }));
      tr.addEventListener("click", async () => {
        detail.hidden = !detail.hidden;
        if (!detail.hidden && !detail.dataset.loaded) {
          detail.dataset.loaded = "1";
          const cell = detail.firstChild;
          rmPut(cell, h("p", { class: "muted small" }, "Loading…"));
          try { rmPut(cell, rmDetail(await api(RM_BASE + "/findings/" + r.id), s.previous)); }
          catch (e) { rmPut(cell, h("p", { class: "hd-failed small" }, e.message)); delete detail.dataset.loaded; }
        }
      });
      tb.append(tr, detail);
    }
    return h("div", { class: "table-wrap" }, h("table", { class: "rm-table", "data-no-select": "1" },
      h("thead", null, h("tr", null, edit ? h("th", { scope: "col", class: "rm-cb" }, "") : null,
        ["Severity", "Plugin", "Host", "Port", "PIC", "Status", "Due", "Categorization2"].map(x => h("th", { scope: "col" }, x)))), tb));
  };

  const groupBody = async (inner, gk, gcheck) => {
    rmPut(inner, h("p", { class: "muted small" }, "Loading…"));
    const p = Object.assign(q(), st.by !== "none" ? { group_by: st.by, group: gk } : {});
    const d = await api(RM_BASE + "/findings?" + rmQuery(Object.assign(p, { limit: 1000 })));
    rmPut(inner, findingTable(d.items), d.more ? h("p", { class: "muted small" }, "The first 1,000 of " + d.total
      + " are shown: narrow the filters to see the rest.") : null);
    if (gcheck) { gcheck.disabled = false; gcheck._ids = d.items.map(x => x.id); }
  };

  async function drawDone() {
    rmPut(doneBox);
    if (st.status) return;
    const base = Object.assign({ quarter: st.quarter }, rmFiltersOf(st));
    const counts = await Promise.all(RM_NO_ACTION.map(k => api(RM_BASE + "/findings?" + rmQuery(Object.assign({}, base, { status: k, limit: 1 })))));
    if (!counts.some(c => c.total)) return;
    rmPut(doneBox, h("section", { class: "rm-done", "aria-label": "No action needed" },
      h("h3", null, "No action needed"),
      h("p", { class: "muted small" }, "Fixed and decommissioned findings, kept out of the way. Open one to check it, or choose it to change its status back."),
      h("div", { class: "srv-groups" }, RM_NO_ACTION.map((k, i) => {
        const n = counts[i].total;
        if (!n) return null;
        const inner = h("div", { class: "srv-group-body", hidden: true });
        const btn = h("button", { type: "button", class: "srv-plus", "aria-expanded": "false", "aria-label": "Expand " + RM_STATUS[k] }, "+");
        const toggle = async () => {
          const now = inner.hidden;
          inner.hidden = !now; btn.textContent = now ? "−" : "+"; btn.setAttribute("aria-expanded", String(now));
          if (now && !inner.dataset.loaded) {
            inner.dataset.loaded = "1";
            rmPut(inner, h("p", { class: "muted small" }, "Loading…"));
            try {
              const d = await api(RM_BASE + "/findings?" + rmQuery(Object.assign({}, base, { status: k, limit: 1000 })));
              rmPut(inner, findingTable(d.items), d.more ? h("p", { class: "muted small" }, "The first 1,000 of " + d.total + " are shown.") : null);
            } catch (e) { rmPut(inner, h("p", { class: "hd-failed small" }, e.message)); delete inner.dataset.loaded; }
          }
        };
        btn.addEventListener("click", toggle);
        return h("section", { class: "srv-group rm-group rm-done-" + k, "aria-label": RM_STATUS[k] },
          h("div", { class: "srv-group-head" }, btn, h("button", { type: "button", class: "srv-group-name", on: { click: toggle } }, RM_STATUS[k]),
            h("span", { class: "srv-group-stats" }, h("span", { class: "chip" + (k === "fixed" ? " chip-ok" : "") }, n + " finding" + (n === 1 ? "" : "s")))),
          inner);
      }))));
  }

  async function load() {
    if (aiSlot.open) mountAi(); else rmPut(aiSlot, h("summary", null, "AI-01 summary of these findings"));
    rmPut(list, h("p", { class: "muted small" }, "Loading…"));
    sel.clear(); allMode = false; drawBar();
    drawDone().catch(e => { if (!(e instanceof StaleRoute)) rmPut(doneBox, h("p", { class: "hd-failed small" }, e.message)); });
    try {
      if (st.by === "none") {
        const d = await api(RM_BASE + "/findings?" + rmQuery(Object.assign(q(), { limit: 1000 })));
        head.dataset.total = d.total;
        head.textContent = d.total + " finding" + (d.total === 1 ? "" : "s") + (st.status ? "" : " need action") + (d.more ? " · the first 1,000 are shown" : "");
        rmPut(list, d.items.length ? findingTable(d.items) : h("div", { class: "empty" }, h("p", null, "No findings match these filters.")));
        return;
      }
      const d = await api(RM_BASE + "/groups?" + rmQuery(Object.assign(q(), { group_by: st.by })));
      const total = d.total ? d.total.total : d.groups.reduce((a, g) => a + Number(g.total), 0);
      head.dataset.total = total;
      head.textContent = total + " finding" + (total === 1 ? "" : "s") + (st.status ? "" : (total === 1 ? " needs" : " need") + " action") + " in " + d.groups.length + (d.more ? "+" : "") + " group"
        + (d.groups.length === 1 ? "" : "s") + " · grouped by " + (RM_GROUPS.find(g => g[0] === st.by) || ["", ""])[1].toLowerCase();
      if (!d.groups.length) { rmPut(list, h("div", { class: "empty" }, h("p", null, "No findings match these filters."))); return; }
      rmPut(list, h("div", { class: "srv-groups" }, d.groups.map((g, i) => {
        const inner = h("div", { class: "srv-group-body", hidden: true });
        const open = d.groups.length === 1;
        const btn = h("button", { type: "button", class: "srv-plus", "aria-expanded": "false", "aria-label": "Expand " + g.label }, "+");
        const gcheck = edit ? h("input", { type: "checkbox", "data-gall": "1", disabled: true, title: "Choose every finding in this group",
          "aria-label": "Choose every finding in " + g.label, on: { change: e => {
            for (const id of e.target._ids || []) e.target.checked ? sel.add(id) : sel.delete(id);
            inner.querySelectorAll("input[data-fid]").forEach(b => { b.checked = e.target.checked; });
            allMode = false; drawBar(); } } }) : null;
        const toggle = () => {
          const now = inner.hidden;
          inner.hidden = !now; btn.textContent = now ? "−" : "+"; btn.setAttribute("aria-expanded", String(now));
          if (now && !inner.dataset.loaded) { inner.dataset.loaded = "1"; groupBody(inner, g.k, gcheck).catch(e => { rmPut(inner, h("p", { class: "hd-failed small" }, e.message)); delete inner.dataset.loaded; }); }
        };
        btn.addEventListener("click", toggle);
        if (open) setTimeout(toggle, 0);
        const chip = (n, label, cls) => Number(n) ? h("span", { class: "chip " + (cls || "") }, n + " " + label) : null;
        return h("section", { class: "srv-group rm-group", "aria-label": g.label },
          h("div", { class: "srv-group-head" }, btn, gcheck,
            h("button", { type: "button", class: "srv-group-name", on: { click: toggle } }, g.label),
            st.by === "host" ? h("span", { class: "muted small" }, [RM_KIND[g.kind] || "", g.team_type ? " · " + RM_TEAM[g.team_type] + (g.team ? " · " + g.team : "") : ""].join("")) : null,
            h("span", { class: "srv-group-stats" },
              chip(g.s4, "critical", "rm-c-4"), chip(g.s3, "high", "rm-c-3"), chip(g.s2, "medium", "rm-c-2"), chip(g.s1, "low", "rm-c-1"),
              chip(g.s0, "info"), h("span", { class: "chip", title: "Outstanding: everything but Fixed and Decommission" },
                g.outstanding + " outstanding of " + g.total + " · " + rmPctText(g.pct_outstanding)), chip(g.overdue, "overdue", "chip-bad"),
              st.by !== "host" && Number(g.hosts) > 1 ? h("span", { class: "chip" }, g.hosts + " hosts") : null)),
          inner);
      })), d.more ? h("p", { class: "muted small" }, "The first 300 groups are shown: narrow the filters to see the rest.") : null);
    } catch (e) {
      if (e instanceof StaleRoute) return;
      rmPut(list, h("p", { class: "hd-failed" }, e.message));
    }
  }
  load();
}

function rmBulkForm(n, allMode, apply, clear, chooseAll, total, tell) {
  const status = h("select", { "aria-label": "New status" }, h("option", { value: "" }, "Status: keep"),
    Object.entries(RM_STATUS).map(([k, v]) => h("option", { value: k }, v)));
  const pic = h("input", { type: "text", placeholder: "PIC: keep", "aria-label": "New PIC", maxlength: "120", size: "10" });
  const target = h("input", { type: "date", "aria-label": "New target completion date" });
  const done = h("input", { type: "date", "aria-label": "Completion date of remediation" });
  const exc = h("input", { type: "text", placeholder: "Exception: keep", "aria-label": "Exception", maxlength: "2000", size: "12" });
  const note = h("input", { type: "text", placeholder: "Note (kept with the change)", "aria-label": "Note", maxlength: "500", size: "18" });
  status.addEventListener("change", () => { if (status.value === "fixed" && !done.value) done.value = new Date().toISOString().slice(0, 10); });
  const go = h("button", { type: "button", class: "btn", on: { click: async () => {
    const changes = {};
    if (status.value) changes.status = status.value;
    if (pic.value.trim()) changes.pic = pic.value.trim();
    if (target.value) changes.target_on = target.value;
    if (done.value) changes.completed_on = done.value;
    if (exc.value.trim()) changes.exception = exc.value.trim();
    if (!Object.keys(changes).length) { tell("Choose what to change.", true); return; }
    go.disabled = true;
    try { await apply(changes, note.value.trim() || null); } catch (e) { tell(e.message, true); go.disabled = false; }
  } } }, "Apply to " + n);
  return [h("strong", { class: "rm-bulk-n" }, n + " chosen" + (allMode ? " (every finding the filters show)" : "")),
    chooseAll ? h("button", { type: "button", class: "btn-link", on: { click: chooseAll } }, "Choose all " + total) : null,
    status, pic, target, done, exc, note, go, h("button", { type: "button", class: "btn btn-quiet", on: { click: clear } }, "Clear")];
}

function rmDetail(f, prev) {
  const kv = (label, v) => v ? [h("dt", null, label), h("dd", null, v)] : null;
  const long = (label, v) => v ? h("details", { class: "rm-long" }, h("summary", null, label), h("pre", { class: "rm-pre" }, v)) : null;
  const extra = Object.entries(f.extra || {}).filter(([k]) => k !== "_raw");
  const raw = (f.extra || {})._raw || {};
  return h("div", { class: "rm-det" },
    h("dl", { class: "kv rm-kv" },
      kv("Plugin", f.plugin_id + (f.plugin_name ? " · " + f.plugin_name : "")), kv("Host", [f.hostname, f.ip].filter(Boolean).join(" · ")),
      kv("Port", [f.port, f.protocol].filter(Boolean).join("/")), kv("UAT/Prod", f.env), kv("Device type", (RM_KIND[f.kind] || f.kind)
        + (f.kind_set ? " (set by a person)" : f.inv_name ? " (inventory: " + f.inv_name + (f.inv_reason ? ", " + f.inv_reason : "") + ")" : "")),
      kv("Team", f.team_type ? RM_TEAM[f.team_type] + (f.team ? " · " + f.team : "") : null),
      kv("Status", (RM_STATUS[f.status] || f.status) + (f.status_text && f.status_text !== RM_STATUS[f.status] ? " (the file says “" + f.status_text + "”)" : "")),
      kv("PIC", f.pic), kv("Exception", f.exception), kv("CVE", f.cve), kv("CVSS", [f.cvss3 ? "v3 " + f.cvss3 : "", f.cvss2 ? "v2 " + f.cvss2 : ""].filter(Boolean).join(" · ")),
      kv("Report shared", rmDate(f.report_shared) || raw.report_shared), kv("New target date", rmDate(f.target_on) || raw.target_on),
      kv("Due", f.due_on ? rmDate(f.due_on) + (f.due_from_target ? " (the target date: no date of its own)" : "") + (f.overdue ? " · overdue" : "") : null),
      kv("Completed", rmDate(f.completed_on) || raw.completed_on), kv("First discovered", rmDate(f.first_seen) || raw.first_seen),
      kv("Last observed", rmDate(f.last_seen) || raw.last_seen), kv("Categorization1", f.cat1), kv("Categorization2", f.cat2),
      kv("In the file", f.sheet ? "sheet " + f.sheet + ", row " + f.row_no : null),
      (f.carried || []).length ? kv("From " + (prev || "the previous quarter"), "blank in this file: " + rmCarried(f.carried)) : null,
      extra.length ? kv("Other columns", extra.map(([k, v]) => k + ": " + v).join(" · ")) : null),
    long("Synopsis", f.synopsis), long("Description", f.description), long("Steps to remediate", f.solution), long("Plugin output", f.plugin_output),
    (f.other_quarters || []).length ? h("p", { class: "small" }, h("strong", null, "Other quarters: "),
      f.other_quarters.map(o => o.quarter + " " + (RM_STATUS[o.status] || o.status) + (o.pic ? " (" + o.pic + ")" : "")).join(" · ")) : null,
    (f.history || []).length ? h("details", { class: "rm-long", open: true }, h("summary", null, "Changes (" + f.history.length + ")"),
      h("ul", { class: "rm-hist" }, f.history.map(x => h("li", null, h("span", { class: "muted" }, fmtDateTime(x.changed_at) + " · " + x.changed_by + ": "),
        x.field + " " + (x.old_value ? "“" + (RM_STATUS[x.old_value] || x.old_value) + "” → " : "set to ") + "“" + (RM_STATUS[x.new_value] || x.new_value || "blank") + "”",
        x.note ? h("span", { class: "muted" }, " — " + x.note) : null)))) : h("p", { class: "muted small" }, "No changes since it was imported."));
}

/* ---- AI-01's summary of a view ------------------------------------------------------ */

// What the view's issues are, how to fix them and what first, written by AI-01 from the file's own text (Synopsis,
// Description, Steps to Remediate). The issues, their hosts and every count come from PATCH-01, never from AI-01.
function rmAiPanel(params, go, opts) {
  opts = opts || {};
  const box = h("section", { class: "rm-ai", "aria-label": "AI-01 summary" });
  const view = Object.assign({}, params);
  const say = h("p", { class: "cm-meta", role: "status", "aria-live": "polite" });
  let timer = null;
  const stop = () => { if (timer) { clearTimeout(timer); timer = null; } };
  const startBtn = label => h("button", { type: "button", class: "btn", on: { click: async e => {
    const b = e.currentTarget; b.disabled = true;
    try { const r = await apiPost(RM_BASE + "/ai-summary?" + rmQuery(view), {}); follow(r.id); }
    catch (err) { say.textContent = err.message; say.classList.add("hd-failed"); b.disabled = false; }
  } } }, label);
  const head = (extra) => h("div", { class: "rm-ai-head" }, h("h3", null, "AI-01 summary"), h("span", { class: "chip" }, opts.label || "this view"), extra || null);

  function empty() {
    rmPut(box, head(), h("p", { class: "muted small" }, "AI-01 groups these findings into themes, says what is wrong and how to fix it, and what to fix first, "
      + "using only the file's own Synopsis, Description and Steps to Remediate. The hosts and every number come from PATCH-01."),
    h("div", { class: "cm-actions" }, startBtn("Summarise with AI-01")), say);
  }

  function follow(id) {
    stop();
    const tick = async () => {
      if (!box.isConnected) return stop();
      let s;
      try { s = await api(RM_BASE + "/ai-summary/" + encodeURIComponent(id)); }
      catch (e) { if (!(e instanceof StaleRoute)) { rmPut(box, head(), h("p", { class: "hd-failed" }, e.message)); } return; }
      if (s.state === "running" && !s.stalled) {
        const part = /^writing (\d+)\/(\d+)$/.exec(s.phase || "");
        rmPut(box, head(), h("div", { class: "rm-progress" }, h("p", null, s.phase === "waiting"
          ? "AI-01 is answering someone else: this summary starts right after…"
          : "AI-01 is reading the issues and writing the summary" + (part && part[2] !== "1" ? " (part " + part[1] + " of " + part[2] + ", the worst first)" : "") + "…"),
          h("div", { class: "rm-bar rm-bar-busy", role: "progressbar", "aria-label": "Writing the summary" }, h("span")),
          h("p", { class: "muted small" }, "On AI-01's processor this takes from under a minute to a few minutes. You can leave this page: the summary is kept for this view.")));
        timer = setTimeout(tick, 3000);
        return;
      }
      draw(s);
    };
    tick();
  }

  function draw(s) {
    if (s.state === "failed" || s.stalled) {
      rmPut(box, head(), h("p", { class: "hd-failed" }, s.stalled ? "The summary stopped (PATCH-01 may have restarted)." : s.error),
        h("div", { class: "cm-actions" }, startBtn("Try again")), say);
      return;
    }
    const r = s.result || {}, sc = r.scope || {};
    const hostChips = (hosts, n) => {
      const wrap = h("span", { class: "rm-ai-hosts" });
      const show = all => rmPut(wrap, (all ? hosts : hosts.slice(0, 10)).map(x => h("span", { class: "chip mono" }, x)),
        !all && hosts.length > 10 ? h("button", { type: "button", class: "btn-link", on: { click: () => show(true) } }, "+" + (hosts.length - 10) + " more") : null);
      show(false);
      return wrap;
    };
    const issueTable = list => h("div", { class: "table-wrap no-enh" }, h("table", { class: "rm-ai-issues" },
      h("thead", null, h("tr", null, ["Issue", "Severity", "Findings", "Hosts", "Overdue", "PIC"].map(x => h("th", { scope: "col" }, x)))),
      h("tbody", null, list.map(x => [
        h("tr", null,
          h("td", null, h("button", { type: "button", class: "btn-link rm-ai-issue", title: "Open these findings",
            on: { click: () => go("findings", Object.assign({}, rmViewFilters(view), { q: x.plugin_id })) } }, x.plugin_id + " " + (x.name || "")),
            x.solution ? h("details", { class: "rm-long" }, h("summary", null, "Steps to Remediate in the file"), h("pre", { class: "rm-pre" }, x.solution)) : null),
          h("td", null, rmSev(x.severity)), h("td", { class: "num" }, String(x.findings)),
          h("td", null, hostChips(x.hosts, x.host_count)), h("td", { class: "num" }, x.overdue ? h("span", { class: "rm-bad" }, String(x.overdue)) : "0"),
          h("td", { class: "small" }, (x.pics || []).join(", ") || "–"))]))));
    const themes = (r.themes || []).map(t => h("article", { class: "rm-ai-theme" + (t.other ? " rm-ai-other" : "") },
      h("div", { class: "rm-ai-theme-head" }, h("h4", null, t.title),
        h("span", { class: "chip" }, t.issues.length + " issue" + (t.issues.length === 1 ? "" : "s")),
        h("span", { class: "chip" }, t.findings + " finding" + (t.findings === 1 ? "" : "s")),
        h("span", { class: "chip" }, t.hosts.length + " host" + (t.hosts.length === 1 ? "" : "s"))),
      t.summary ? h("p", null, t.summary) : t.other ? h("p", { class: "muted small" }, "AI-01 did not put these in a theme.") : null,
      t.fix ? h("p", null, h("strong", null, "How to fix: "), t.fix) : null,
      issueTable(t.issues)));
    const first = (r.first || []).length ? h("div", { class: "rm-ai-first" }, h("h4", null, "Fix first"),
      h("ol", null, r.first.map(x => h("li", null, rmSev(x.severity), " ", h("strong", null, x.plugin_id + " " + (x.name || "")),
        h("span", { class: "muted" }, " · on " + x.host_count + " host" + (x.host_count === 1 ? "" : "s")), x.why ? " — " + x.why : "")))) : null;
    const copy = h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
      const txt = rmAiText(s);
      try { await navigator.clipboard.writeText(txt); say.textContent = "Copied."; }
      catch (e) { const ta = h("textarea", { class: "rm-copy", readonly: true }); ta.value = txt; box.append(ta); ta.select(); say.textContent = "Select all and copy."; }
    } } }, "Copy as text");
    rmPut(box,
      head(h("span", { class: "chip chip-warn" }, "AI draft: check it against the file's text")),
      h("p", { class: "muted small" }, s.words + " · " + s.quarter + " · " + s.created_by + ", " + fmtDateTime(s.finished_at || s.created_at)),
      h("p", { class: "small" }, sc.issues + " issue" + (sc.issues === 1 ? "" : "s") + " · " + sc.findings + " finding" + (sc.findings === 1 ? "" : "s")
        + " · " + sc.hosts + " host" + (sc.hosts === 1 ? "" : "s") + ". "
        + (sc.covered_issues < sc.issues ? "AI-01 read the " + sc.covered_issues + " worst (" + sc.covered_findings + " findings)"
          + (sc.parts > 1 ? " in " + sc.parts + " parts" : "") + ": it can read only so much; the other "
          + (sc.issues - sc.covered_issues) + " are listed at the end." : "AI-01 read all of them" + (sc.parts > 1 ? " (in " + sc.parts + " parts)" : "") + ".")),
      (r.warnings || []).length ? h("div", { class: "rm-ai-warn" }, h("strong", null, "Check before use: "),
        h("ul", null, r.warnings.map(w => h("li", null, w)))) : null,
      r.overview ? h("p", { class: "rm-ai-overview" }, r.overview) : null,
      first, themes,
      r.not_read_count ? h("details", { class: "rm-long" }, h("summary", null, "Not read by AI-01 (" + r.not_read_count + " issue" + (r.not_read_count === 1 ? "" : "s") + ")"),
        issueTable(r.not_read || [])) : null,
      h("div", { class: "cm-actions" }, startBtn("Summarise again"), copy), say);
  }

  (async () => {
    try {
      const d = await api(RM_BASE + "/ai-summary?" + rmQuery(view));
      if (!d.summary) empty();
      else if (d.summary.state === "running" && !d.summary.stalled) follow(d.summary.id);
      else draw(d.summary);
    } catch (e) { if (!(e instanceof StaleRoute)) rmPut(box, head(), h("p", { class: "hd-failed" }, e.message)); }
  })();
  return box;
}

function rmViewFilters(view) {
  const f = {};
  for (const k of RM_FILTERS) if (view[k]) f[k] = view[k];
  return f;
}

function rmAiText(s) {
  const r = s.result || {}, sc = r.scope || {};
  const sev = n => (RM_SEV[n === null || n === undefined ? -1 : n] || RM_SEV[-1])[0];
  const out = ["AI-01 summary (draft) — " + s.words + " — " + s.quarter, sc.issues + " issues, " + sc.findings + " findings, " + sc.hosts + " hosts", ""];
  if (r.overview) out.push(r.overview, "");
  if ((r.first || []).length) {
    out.push("Fix first:");
    r.first.forEach((x, i) => out.push((i + 1) + ". [" + sev(x.severity) + "] " + x.plugin_id + " " + (x.name || "") + " (" + x.host_count + " hosts)" + (x.why ? " — " + x.why : "")));
    out.push("");
  }
  for (const t of r.themes || []) {
    out.push("== " + t.title + " (" + t.findings + " findings, " + t.hosts.length + " hosts)");
    if (t.summary) out.push(t.summary);
    if (t.fix) out.push("How to fix: " + t.fix);
    for (const x of t.issues) out.push("  - [" + sev(x.severity) + "] " + x.plugin_id + " " + (x.name || "") + ": " + x.hosts.join(", "));
    out.push("");
  }
  return out.join("\n");
}

/* ---- Hosts ----------------------------------------------------------------------- */

async function rmHosts(box, st, edit, tell, go) {
  rmPut(box, h("p", { class: "muted small" }, "Loading…"));
  const d = await api(RM_BASE + "/hosts?" + rmQuery({ quarter: st.quarter }));
  const sel = new Set();
  let q = "", kind = "", team = "";
  const save = async (keys, body, what) => {
    try {
      await apiSend("PUT", RM_BASE + "/hosts", Object.assign({ keys }, body));
      tell(what + " for " + keys.length + " host" + (keys.length === 1 ? "" : "s") + ".");
      for (const x of d.hosts) if (keys.includes(x.host_key)) {
        if (body.team_type !== undefined) x.team_type = body.team_type || null;
        if (body.team !== undefined) x.team = body.team || null;
        if (body.kind !== undefined) { x.kind_set = body.kind || null; x.kind = body.kind || (x.inv_kind ? rmInvKind(x.inv_kind) : "not_in_inventory"); }
      }
      draw();
    } catch (e) { tell(e.message, true); }
  };
  const search = h("input", { type: "search", placeholder: "Search host or IP", "aria-label": "Search hosts" });
  search.addEventListener("input", () => { q = search.value.trim().toLowerCase(); draw(); });
  const kindSel = h("select", { "aria-label": "Device type", on: { change: e => { kind = e.target.value; draw(); } } },
    h("option", { value: "" }, "Device: all"), Object.entries(RM_KIND).map(([k, v]) => h("option", { value: k }, v)));
  const teamSel = h("select", { "aria-label": "Application or Infra", on: { change: e => { team = e.target.value; draw(); } } },
    h("option", { value: "" }, "Team: all"), h("option", { value: "application" }, "Application"), h("option", { value: "infra" }, "Infra"),
    h("option", { value: "none" }, "Not set"));
  const refresh = edit ? h("button", { type: "button", class: "btn btn-quiet", on: { click: async e => {
    const b = e.currentTarget; b.disabled = true; tell("Looking every host up in the inventory again…");
    try { const r = await apiPost(RM_BASE + "/hosts/refresh", {}); tell(r.hosts + " hosts checked against the inventory."); rmHosts(box, st, edit, tell, go); }
    catch (err) { tell(err.message, true); b.disabled = false; }
  } } }, "Check the inventory again") : null;
  const list = h("div");
  const bulk = h("div", { class: "rm-bulk", hidden: true });
  rmPut(box, h("div", { class: "rm-filterbar" }, search, kindSel, teamSel, refresh),
    h("p", { class: "muted small" }, "Application / Infra and the team start blank: fill them in, one host or many at once. They stay for every later quarter."),
    list, bulk);

  function drawBulk() {
    bulk.hidden = !edit || !sel.size;
    if (bulk.hidden) return;
    const tt = h("select", { "aria-label": "Application or Infra" }, h("option", { value: "-" }, "Application / Infra: keep"),
      h("option", { value: "application" }, "Application"), h("option", { value: "infra" }, "Infra"), h("option", { value: "" }, "Not set"));
    const tm = h("input", { type: "text", placeholder: "Team: keep", maxlength: "120", "aria-label": "Team" });
    const kd = h("select", { "aria-label": "Device type" }, h("option", { value: "-" }, "Device type: keep"),
      h("option", { value: "server" }, "Server"), h("option", { value: "network" }, "Network device"), h("option", { value: "appliance" }, "Appliance"),
      h("option", { value: "" }, "As the inventory says"));
    rmPut(bulk, h("strong", { class: "rm-bulk-n" }, sel.size + " host" + (sel.size === 1 ? "" : "s") + " chosen"), tt, tm, kd,
      h("button", { type: "button", class: "btn", on: { click: () => {
        const body = {};
        if (tt.value !== "-") body.team_type = tt.value;
        if (tm.value.trim()) body.team = tm.value.trim();
        if (kd.value !== "-") body.kind = kd.value;
        if (!Object.keys(body).length) { tell("Choose what to set.", true); return; }
        const keys = [...sel]; sel.clear(); save(keys, body, "Saved");
      } } }, "Apply"),
      h("button", { type: "button", class: "btn btn-quiet", on: { click: () => { sel.clear(); draw(); } } }, "Clear"));
  }

  function draw() {
    const rows = d.hosts.filter(x => (!q || (x.hostname || x.host_key).toLowerCase().includes(q) || (x.ips || []).some(i => i.includes(q)))
      && (!kind || x.kind === kind) && (!team || (team === "none" ? !x.team_type : x.team_type === team)));
    rmPut(list, rows.length ? rmOwnTicks(table([
      edit ? { label: "", cell: x => h("input", { type: "checkbox", checked: sel.has(x.host_key), "aria-label": "Choose " + (x.hostname || x.host_key),
        on: { change: e => { e.target.checked ? sel.add(x.host_key) : sel.delete(x.host_key); drawBulk(); } } }) } : null,
      { label: "Host", cell: x => [h("button", { type: "button", class: "btn-link", title: "This host's findings",
          on: { click: () => go("findings", { host: x.host_key }) } }, x.hostname || x.host_key),
        (x.ips || []).length ? h("div", { class: "muted small mono" }, x.ips.join(", ")) : null] },
      { label: "Device type", cell: x => edit ? h("select", { "aria-label": "Device type of " + (x.hostname || x.host_key), on: { change: e => save([x.host_key], { kind: e.target.value }, "Device type saved") } },
          h("option", { value: "", selected: !x.kind_set }, x.inv_kind ? RM_KIND[rmInvKind(x.inv_kind)] + " (inventory)" : RM_KIND.not_in_inventory),
          ["server", "network", "appliance"].map(k => h("option", { value: k, selected: x.kind_set === k }, RM_KIND[k] + " (set here)")))
        : RM_KIND[x.kind] || x.kind },
      { label: "Application / Infra", cell: x => edit ? h("select", { "aria-label": "Application or Infra for " + (x.hostname || x.host_key),
          on: { change: e => save([x.host_key], { team_type: e.target.value }, "Saved") } },
          h("option", { value: "", selected: !x.team_type }, "Not set"), h("option", { value: "application", selected: x.team_type === "application" }, "Application"),
          h("option", { value: "infra", selected: x.team_type === "infra" }, "Infra")) : (RM_TEAM[x.team_type] || "–") },
      { label: "Team", cell: x => edit ? h("input", { type: "text", value: x.team || "", maxlength: "120", placeholder: "blank", size: "14",
          "aria-label": "Team of " + (x.hostname || x.host_key), on: { change: e => save([x.host_key], { team: e.target.value.trim() }, "Team saved") } }) : (x.team || "–") },
      { label: "Outstanding", cell: x => h("span", { class: "rm-cnt" }, [4, 3, 2, 1].map(sv => Number(x["s" + sv])
        ? h("span", { class: "chip rm-c-" + sv, title: RM_SEV[sv][0] + " outstanding" }, x["s" + sv] + " " + RM_SEV[sv][0].toLowerCase()) : null),
        h("span", { class: "muted small" }, " " + x.outstanding + " of " + x.total + " · " + rmPctText(x.pct_outstanding))) },
      { label: "Overdue", cell: x => Number(x.overdue) ? h("span", { class: "rm-bad" }, String(x.overdue)) : h("span", { class: "muted" }, "0") },
      { label: "PIC", cell: x => (x.pics || []).join(", ") || h("span", { class: "muted" }, "–") },
      { label: "UAT/Prod", cell: x => (x.envs || []).join(", ") || h("span", { class: "muted" }, "–") },
    ].filter(Boolean), rows)) : h("div", { class: "empty" }, h("p", null, "No hosts match.")));
    drawBulk();
  }
  draw();
}

function rmOwnTicks(wrap) {
  const t = wrap.querySelector("table");
  if (t) t.dataset.noSelect = "1";
  return wrap;
}

function rmInvKind(k) {
  return ({ server: "server", client: "server", esxi: "server", network: "network", firewall: "network", appliance: "appliance", unknown: "unknown" })[k] || "not_in_inventory";
}

/* ---- Uploads --------------------------------------------------------------------- */

function rmPickFile(page, home, st, tell) {
  document.querySelectorAll("input.rm-file").forEach(x => x.remove());           // one left by a cancelled choice
  const input = h("input", { type: "file", class: "rm-file", accept: ".xlsx,.xlsm,.csv", hidden: true });
  document.body.append(input);
  input.addEventListener("change", async () => {
    const f = input.files[0];
    input.remove();
    if (!f) return;
    try {
      const id = await rmSend(f, tell);
      st.upload = id; st.tab = "uploads";
      rmDraw(page, await api(RM_BASE), st);
    } catch (e) { tell(e.message, true); }
  });
  input.click();
}

async function rmSend(file, tell) {
  if (!/\.(xlsx|xlsm|csv)$/i.test(file.name)) throw new Error(/\.xls$/i.test(file.name)
    ? "Old .xls files cannot be read: open it in Excel and save it as .xlsx, then upload that." : "Upload the scan workbook as .xlsx or .csv.");
  let body = file, gz = 0;
  // a big CSV is packed in the browser: the server takes at most 60 MB a request
  if (/\.csv$/i.test(file.name) && file.size > 8 * 1048576 && typeof CompressionStream === "function") {
    tell("Packing " + file.name + " (" + rmBytes(file.size) + ") before sending…");
    body = await new Response(file.stream().pipeThrough(new CompressionStream("gzip"))).blob();
    gz = 1;
  }
  if (body.size > 60 * 1048576) throw new Error("The file is larger than 60 MB" + (gz ? " even packed" : "") + ". Save it as .xlsx (much smaller than .csv) and try again.");
  tell("Sending " + file.name + " (" + rmBytes(body.size) + ")…");
  const res = await fetch("/api/v1" + RM_BASE + "/uploads?" + rmQuery({ name: file.name, gz }), {
    method: "POST", body, cache: "no-store",
    headers: { "Content-Type": "application/octet-stream", "X-Requested-With": "patch01-dashboard", ...authHeaders() } });
  if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
  if (!res.ok) {
    let d = ""; try { d = detailText((await res.json()).detail); } catch (e) { /* not JSON */ }
    throw new ApiError(res.status, d || httpReason(res));
  }
  tell("");
  return (await res.json()).id;
}

async function rmUploads(page, box, home, st, edit, tell, go) {
  const ups = home.uploads || [];
  const cur = st.upload || ((ups.find(u => ["reading", "review", "importing"].includes(u.state)) || {}).id);
  const detail = h("div", { class: "rm-upload" });
  const listBox = ups.length ? h("section", { class: "rm-by no-enh" }, h("h3", null, "Uploads"), table([
    { label: "File", cell: u => h("button", { type: "button", class: "btn-link", on: { click: () => { st.upload = u.id;
      history.replaceState(null, "", rmHash({ tab: "uploads", quarter: st.quarter, upload: u.id })); rmUploads(page, box, home, st, edit, tell, go); } } }, u.file_name) },
    { label: "State", cell: u => rmUpState(u) },
    { label: "Quarters", cell: u => Object.keys(u.result || {}).join(", ") || h("span", { class: "muted" }, "–") },
    { label: "By", cell: u => u.created_by },
    { label: "When", nowrap: true, cell: u => fmtDateTime(u.created_at) },
  ], ups)) : null;
  rmPut(box, 
    !ups.length ? h("div", { class: "empty rm-empty" }, h("h3", null, "No scan file yet"),
      h("ol", { class: "rm-steps" },
        h("li", null, h("strong", null, "Upload"), " the quarter's scan workbook (.xlsx or .csv): one sheet per quarter, such as 26Q3. A Summary sheet is recognised and left out: PATCH-01 counts for itself."),
        h("li", null, h("strong", null, "Check the columns"), ": each column with its sample values, what it was taken as and why (PATCH-01's rules, a choice saved before, or AI-01). Change any of them; they are remembered for the next file."),
        h("li", null, h("strong", null, "Import"), ": findings by severity, host, PIC and status; the next quarter is compared with this one.")),
      edit ? h("button", { type: "button", class: "btn", on: { click: () => rmPickFile(page, home, st, tell) } }, "Upload scan file")
        : h("p", { class: "muted" }, "An operator uploads the file.")) : null,
    detail, listBox);
  if (cur) await rmUploadDetail(page, detail, cur, home, st, edit, tell, go);
}

function rmUpState(u) {
  if (u.stalled) return h("span", { class: "chip chip-bad" }, "stopped");
  const m = { reading: ["reading…", "chip-warn"], review: ["check the columns", "chip-warn"], importing: ["importing…", "chip-warn"],
    imported: ["imported", "chip-ok"], failed: ["failed", "chip-bad"] }[u.state] || [u.state, ""];
  return h("span", { class: "chip " + m[1] }, m[0]);
}

async function rmUploadDetail(page, box, id, home, st, edit, tell, go) {
  let u;
  try { u = await api(RM_BASE + "/uploads/" + encodeURIComponent(id)); }
  catch (e) { if (e instanceof StaleRoute) return; rmPut(box, h("p", { class: "hd-failed" }, e.message)); return; }
  if (!box.isConnected) return;
  const head = h("div", { class: "rm-up-head" }, h("h3", null, u.file_name), rmUpState(u),
    h("span", { class: "muted small" }, rmBytes(u.size_bytes) + " · " + u.created_by + " · " + fmtDateTime(u.created_at)));
  const again = () => rmUploadDetail(page, box, id, home, st, edit, tell, go);
  const reloadAll = async () => rmDraw(page, await api(RM_BASE), st);
  const poll = () => setPageTimer(async () => {
    if (!box.isConnected || !location.hash.startsWith("#/remediation")) return clearPageTimer();
    try {
      const n = await api(RM_BASE + "/uploads/" + encodeURIComponent(id));
      if (n.state !== u.state || n.stalled) { clearPageTimer(); if (n.state === "imported") { reloadAll(); return; } again(); return; }
      const bar = box.querySelector(".rm-progress");
      if (bar) rmProgressInto(bar, n);
    } catch (e) { clearPageTimer(); }
  }, 1500);

  if (u.stalled || u.state === "failed") {
    rmPut(box, head, h("p", { class: "hd-failed" }, u.stalled ? "This " + (u.state === "reading" ? "reading" : "import")
      + " stopped (PATCH-01 may have restarted)." : u.error || "It failed."),
    edit ? h("div", { class: "cm-actions" },
      u.kept !== false ? h("button", { type: "button", class: "btn", on: { click: async () => {
        try { await apiPost(RM_BASE + "/uploads/" + id + "/retry", {}); again(); } catch (e) { tell(e.message, true); } } } }, "Try again") : null,
      h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
        try { await apiSend("DELETE", RM_BASE + "/uploads/" + id); st.upload = null; reloadAll(); } catch (e) { tell(e.message, true); } } } }, "Discard")) : null);
    return;
  }
  if (u.state === "reading" || u.state === "importing") {
    const bar = h("div", { class: "rm-progress" });
    rmProgressInto(bar, u);
    rmPut(box, head, bar);
    poll();
    return;
  }
  if (u.state === "imported") {
    rmPut(box, head, rmResult(u, go, st));
    return;
  }
  if (u.state === "discarded") { rmPut(box, head, h("p", { class: "muted" }, "Discarded.")); return; }
  rmPut(box, head, rmReview(u, edit, tell, again, async () => { st.upload = id; again(); poll(); }));
}

function rmProgressInto(bar, u) {
  const p = u.progress || {};
  const pct = p.total ? Math.min(100, Math.round(100 * (p.done || 0) / p.total)) : null;
  const what = p.phase === "waiting" ? "Waiting for another import to finish…"
    : u.state === "reading" ? (p.total ? "Reading sheet " + Math.min(p.total, (p.done || 0) + 1) + " of " + p.total + "…" : "Reading the file…")
    : "Importing " + (p.done || 0).toLocaleString() + " of " + (p.total || 0).toLocaleString() + " rows…";
  rmPut(bar, h("p", null, what), pct === null ? null : h("div", { class: "rm-bar", role: "progressbar", "aria-valuenow": String(pct),
    "aria-valuemin": "0", "aria-valuemax": "100", "aria-label": what }, h("span", { style: { width: pct + "%" } })),
    h("p", { class: "muted small" }, "You can leave this page: it carries on, and the Uploads tab shows where it is."));
}

function rmResult(u, go, st) {
  const res = u.result || {};
  const out = [h("p", null, "Imported by " + (u.imported_by || "") + " on " + fmtDateTime(u.imported_at) + ".")];
  for (const [q, r] of Object.entries(res)) {
    const skipped = r.skipped || [], dups = r.duplicates || [];
    out.push(h("section", { class: "rm-by" }, h("h3", null, q + " (sheet " + (r.sheets || []).join(", ") + ")"),
      h("ul", { class: "rm-res" },
        h("li", null, h("strong", null, String(r.findings)), " findings from " + r.rows + " rows"),
        h("li", null, r.new + " new to " + q + ", " + r.updated + " updated, " + r.unchanged + " unchanged"),
        r.previous ? h("li", null, r.carried + " took PIC, status, dates or categorisation from " + r.previous + " (blank in this file)") : null,
        r.no_severity ? h("li", { class: "hd-failed" }, r.no_severity + " have no severity PATCH-01 knows (shown as “Not given”)") : null,
        skipped.length ? h("li", null, skipped.length + (r.skipped_more ? "+" : "") + " rows left out: " + skipped.slice(0, 8).map(x => "row " + x.row + " (" + x.why + ")").join(", ")
          + (skipped.length > 8 ? ", …" : "")) : null,
        dups.length ? h("li", null, dups.length + " rows repeat a finding already in the sheet (same plugin, host, port and protocol); the first was kept: "
          + dups.slice(0, 8).map(x => "row " + x.row).join(", ")) : null,
        r.removed ? h("li", null, r.removed + " findings of " + q + " that were not in this file were removed") : null,
        r.not_in_file ? h("li", null, r.not_in_file + " findings of " + q + " already in PATCH-01 are not in this file: they were kept") : null,
        r.inventory_error ? h("li", { class: "hd-failed" }, "Device types could not be read from the inventory (" + r.inventory_error + "): use “Check the inventory again” on the Hosts tab") : null),
      h("button", { type: "button", class: "btn btn-quiet", on: { click: () => { st.quarter = q; go("summary"); } } }, "Open " + q)));
  }
  return out;
}

function rmReview(u, edit, tell, again, started) {
  const fields = u.fields || [];
  const statuses = u.statuses || [];
  const state = { words: {}, order: null };
  const sheetsBox = [];
  const words = new Map();                       // status words across the sheets
  const sheets = u.sheets || [];
  let unplaced = 0;
  for (const s of sheets) for (const w of s.words || []) if (!words.has(w.norm)) words.set(w.norm, w);
  const anyAmbiguous = sheets.some(s => s.ambiguous_dates);

  const cards = sheets.map(s => {
    const use = h("input", { type: "checkbox", checked: !!s.use, disabled: !edit, "aria-label": "Import the sheet " + s.name });
    const qIn = h("input", { type: "text", value: s.quarter || "", placeholder: "2026 Q3", size: "8", maxlength: "20", disabled: !edit,
      "aria-label": "Quarter of the sheet " + s.name });
    const selects = (s.map || []).map((m, i) => {
      if (!m.field && s.headers[i] && m.how !== "ai" && m.how !== "you") unplaced += s.use ? 1 : 0;
      return h("select", { disabled: !edit, "aria-label": "Column " + (s.headers[i] || i + 1) + " is", class: m.field ? "" : "rm-unset" },
        h("option", { value: "" }, "— not used —"), fields.map(f => h("option", { value: f.key, selected: m.field === f.key }, f.label)));
    });
    const colTable = h("div", { class: "table-wrap rm-cols no-enh" }, h("table", null,
      h("thead", null, h("tr", null, ["Column in the file", "Sample values", "Taken as", "Why"].map(x => h("th", { scope: "col" }, x)))),
      h("tbody", null, (s.headers || []).map((hd, i) => {
        const m = s.map[i] || {};
        const how = RM_HOW[m.how];
        const samples = (s.samples || []).map(r => r[i]).filter(Boolean).slice(0, 3);
        return h("tr", null,
          h("td", null, hd ? h("strong", null, hd) : h("span", { class: "muted" }, "(no heading)"), h("div", { class: "muted small" }, "column " + rmCol(i))),
          h("td", { class: "small rm-samples" }, samples.length ? samples.map(v => h("div", { class: "rm-sample", title: v }, v)) : h("span", { class: "muted" }, "empty")),
          h("td", null, selects[i]),
          h("td", { class: "small" }, how ? h("span", { class: "rm-how " + how[1] }, how[0]) : null, " ", m.why || (m.field ? "" : h("span", { class: "muted" }, "no rule knows this heading"))));
      }))));
    const probs = (s.problems || []).filter(p => !/status words mean|day\/month|month\/day/.test(p));
    const card = h("section", { class: "srv-group rm-sheet" + (s.findings ? "" : " rm-sheet-other") },
      h("div", { class: "srv-group-head" },
        h("label", { class: "chk" }, use, " ", h("strong", { class: "rm-sheet-name" }, s.name)),
        h("span", { class: "chip" + (s.findings ? " chip-ok" : "") }, s.findings ? "scan findings" : "not a findings sheet"),
        !s.findings ? h("span", { class: "muted small" }, "left out: a summary (PATCH-01 counts for itself)") : null,
        h("span", { class: "chip" }, (s.rows || 0).toLocaleString() + " rows"), s.hidden ? h("span", { class: "chip" }, "hidden sheet") : null,
        h("label", { class: "rm-qlabel" }, "Quarter ", qIn, s.quarter_from ? h("span", { class: "muted small" }, " (from the sheet name)") : null)),
      h("div", { class: "srv-group-body" },
        !s.findings ? h("p", { class: "muted small" }, "It has no Plugin / UUID and IP address / Hostname columns, so it is left out (a summary sheet: PATCH-01 counts for itself). Tick it to import it anyway and set its columns.") : null,
        s.too_many_rows ? h("p", { class: "hd-failed small" }, "This sheet has more than 500,000 rows: only that many can be imported.") : null,
        s.too_many_cols ? h("p", { class: "hd-failed small" }, "Some rows have values beyond the last heading: those values are not read.") : null,
        probs.length ? h("ul", { class: "hd-failed small rm-probs" }, probs.map(p => h("li", null, p))) : null,
        colTable));
    card.hidden = false;
    sheetsBox.push({ s, use, qIn, selects });
    const body = card.querySelector(".srv-group-body");
    if (!s.findings && !s.use) body.hidden = true;
    use.addEventListener("change", () => { body.hidden = !use.checked && !s.findings; });
    return card;
  });

  const wordRows = [...words.values()];
  const wordBox = wordRows.length ? h("section", { class: "rm-by" }, h("h3", null, "Status words in the file"),
    h("div", { class: "table-wrap no-enh" }, h("table", null,
      h("thead", null, h("tr", null, ["Word in the file", "Rows", "Means", ""].map(x => h("th", { scope: "col" }, x)))),
      h("tbody", null, wordRows.map(w => {
        const sel = h("select", { disabled: !edit, "aria-label": "“" + w.word + "” means", class: w.status ? "" : "rm-unset" },
          w.status ? null : h("option", { value: "", selected: true }, "Choose…"),
          statuses.map(x => h("option", { value: x.key, selected: w.status === x.key }, x.label)));
        sel.addEventListener("change", () => { state.words[w.word] = sel.value; sel.classList.toggle("rm-unset", !sel.value); });
        if (w.status) state.words[w.word] = w.status;
        return h("tr", null, h("td", null, h("strong", null, w.word)), h("td", { class: "num" }, String(w.count)), h("td", null, sel),
          h("td", { class: "small muted" }, w.how === "saved" ? "chosen before" : w.how === "rule" ? "known word" : "PATCH-01 does not know this word: say what it means"));
      }))))) : null;

  const orderBox = anyAmbiguous ? h("fieldset", { class: "rm-order" }, h("legend", null, "Dates such as 03/04/2026 are"),
    h("label", { class: "chk" }, h("input", { type: "radio", name: "rm-order", value: "dmy", on: { change: () => { state.order = "dmy"; } } }), " day first (3 April 2026)"),
    h("label", { class: "chk" }, h("input", { type: "radio", name: "rm-order", value: "mdy", on: { change: () => { state.order = "mdy"; } } }), " month first (4 March 2026)"),
    h("p", { class: "muted small" }, "The file's dates cannot tell: some are 13/11 (day first) only when the day is over 12.")) : null;
  const removeMissing = h("input", { type: "checkbox", disabled: !edit });
  const msg = h("p", { class: "cm-meta", role: "status", "aria-live": "polite" });
  const say = (t, bad) => { msg.textContent = t; msg.classList.toggle("hd-failed", !!bad); };

  const collect = () => ({
    sheets: sheetsBox.map(({ s, use, qIn, selects }) => ({ name: s.name, use: use.checked, quarter: qIn.value.trim() || null,
      columns: selects.map(x => x.value || null) })),
    status_words: Object.fromEntries(Object.entries(state.words).filter(([, v]) => v)), date_order: state.order,
    remove_missing: removeMissing.checked });
  const importBtn = h("button", { type: "button", class: "btn", on: { click: async () => {
    importBtn.disabled = true; say("Checking…");
    try { await apiPost(RM_BASE + "/uploads/" + u.id + "/confirm", collect()); say(""); started(); }
    catch (e) { say(e.message, true); importBtn.disabled = false; }
  } } }, "Import");
  const aiBtn = unplaced ? h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
    aiBtn.disabled = true; say("AI-01 is reading " + unplaced + " column" + (unplaced === 1 ? "" : "s") + " (heading and a few values each)…");
    try { const r = await apiPost(RM_BASE + "/uploads/" + u.id + "/suggest", {}); tell("AI-01 placed " + r.ai_placed + " of " + unplaced + " column" + (unplaced === 1 ? "" : "s") + ": check them below, then import."); again(); }
    catch (e) { say(e.message, true); aiBtn.disabled = false; }
  } } }, "Ask AI-01 about the " + unplaced + " column" + (unplaced === 1 ? "" : "s") + " not placed") : null;
  const discardBtn = h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
    try { await apiSend("DELETE", RM_BASE + "/uploads/" + u.id); tell("Discarded."); location.hash = "#/remediation?tab=uploads"; } catch (e) { say(e.message, true); }
  } } }, "Discard");

  return [u.error ? h("p", { class: "hd-failed" }, u.error) : null,
    h("p", { class: "muted small" }, "Check how each column was read. Change any that is wrong: your choices are remembered for the next file. "
      + "Nothing is imported until you press Import."),
    cards, wordBox, orderBox,
    edit ? h("label", { class: "chk rm-wrap" }, removeMissing, " Remove the findings of these quarters that are not in this file (otherwise they are kept)") : null,
    edit ? h("div", { class: "cm-actions rm-actions" }, importBtn, aiBtn, discardBtn) : h("p", { class: "muted" }, "An operator confirms the columns."), msg];
}

function rmCol(i) {
  let s = "", n = i + 1;
  while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); }
  return s;
}
