"""
PATCH-01 CVE applicability engine

Two stages:

  import   Read security advisories from the repositories Pulp has already
           synced. For RHEL these carry Red Hat's own fixed-in versions, so
           no extra feed or proxy domain is needed, and every fix found is by
           construction already held in the local mirror.

  compute  For each host, compare every installed package against every
           advisory for that host's OS, and record one of the five states:

             not_affected          package absent (not stored, implied)
             affected              installed version older than the fix
             fixed_active          fix installed and running
             fixed_pending_reboot  fix installed, old version still running
             unknown               host inventory too old to judge

Design rules:

  * The comparison target is ALWAYS the vendor's fixed-in version, never an
    upstream CVE version. Vendors backport fixes, so upstream numbers are
    meaningless for enterprise distributions.

  * Installed is not the same as effective. A kernel fix counts as
    fixed_active only if the RUNNING kernel is at or above it.

  * A host whose inventory is stale gets 'unknown', never a verdict derived
    from old data.

  * Every verdict records the installed and fixed versions and a reason, so
    it can be explained and audited rather than taken on trust.

Run inside the API image on the patchnet network:
  python -m app.cve_engine            import and compute
  python -m app.cve_engine --import   import only
  python -m app.cve_engine --compute  compute only
"""

import argparse
import base64
import json
import logging
import os
import re
import time
import urllib.error
import urllib.request
from collections import defaultdict
from datetime import datetime, timezone

import psycopg
from psycopg.rows import dict_row

from .evr import rpm_label_compare, evr_str

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"),
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("cve_engine")

PULP_URL = os.environ.get("PULP_URL", "http://pulp-api:24817").rstrip("/")
PULP_USER = os.environ.get("PULP_USER", "admin")
PULP_PASSWORD = os.environ.get("PULP_PASSWORD", "")

DB = dict(
    host=os.environ.get("PATCHDB_HOST", "postgres"),
    port=int(os.environ.get("PATCHDB_PORT", "5432")),
    dbname=os.environ.get("PATCHDB_NAME", "patchdb"),
    user=os.environ.get("PATCHDB_USER", "patchapi"),
    password=os.environ.get("PATCHDB_PASSWORD", ""),
)

STALE_HOURS = int(os.environ.get("STALE_HOURS", "24"))
STALE_REASON = "host inventory is stale"            # the same words as mark_stale_hosts() (schema 001)
NO_INVENTORY_REASON = "no package inventory on record"

# Systems the engine computes verdicts for: rhel/ol from the Pulp advisories,
# windows from Microsoft's Security Update Guide (app.msrc, the OS build)
SUPPORTED_OS = ("rhel", "ol", "windows")

# Repository name prefix -> (os_id, major). Matches config/repos.conf.
REPO_PREFIX = re.compile(r"^(rhel|ol)(\d+)-")

# Packages whose fix only takes effect after a reboot, beyond the kernel
# itself. Mirrors the list needs-restarting -r uses.
REBOOT_PACKAGES = {
    "glibc", "systemd", "systemd-libs", "udev", "linux-firmware",
    "dbus", "dbus-daemon", "openssl-libs", "gnutls",
}

KERNEL_PREFIXES = ("kernel", "kernel-core", "kernel-modules",
                   "kernel-modules-core", "kernel-rt")


def is_kernel(name):
    return name == "kernel" or name.startswith(KERNEL_PREFIXES)


# ---------------------------------------------------------------------------
# Pulp client
# ---------------------------------------------------------------------------

class Pulp:
    def __init__(self):
        if not PULP_PASSWORD:
            raise SystemExit("PULP_PASSWORD is not set")
        token = base64.b64encode(f"{PULP_USER}:{PULP_PASSWORD}".encode()).decode()
        self.auth = "Basic " + token
        # Pulp is on the internal Docker network; never route via a proxy
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def get(self, path):
        url = path if path.startswith("http") else PULP_URL + path
        req = urllib.request.Request(url)
        req.add_header("Authorization", self.auth)
        req.add_header("Accept", "application/json")
        try:
            with self.opener.open(req, timeout=300) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"HTTP {e.code} on {url}: {e.read().decode()[:300]}")

    def paged(self, path):
        """Follow Pulp pagination. 'next' is an absolute URL that may use an
        externally-facing host, so only its query string is reused."""
        url = path
        while url:
            page = self.get(url)
            for item in page.get("results", []):
                yield item
            nxt = page.get("next")
            if nxt:
                q = nxt.split("?", 1)[1] if "?" in nxt else ""
                base = url.split("?", 1)[0]
                url = f"{base}?{q}" if q else None
            else:
                url = None


# ---------------------------------------------------------------------------
# Import
# ---------------------------------------------------------------------------

CVE_RE = re.compile(r"CVE-\d{4}-\d{4,7}", re.I)


def extract_cves(advisory):
    """Every CVE an advisory refers to.

    Advisory references carry one entry per CVE. Pulp's model names those
    fields ref_id and ref_type, while its API has also been documented as id
    and type, so both are accepted: reading only one naming silently yields
    no CVEs at all.

    Three further fallbacks, because vendors are inconsistent:
      - a reference marked as a CVE but with the id only in its link
      - a reference of another type whose link is a CVE page
      - CVE numbers written in the advisory's own title or description
    """
    found = []

    def add(v):
        for m in CVE_RE.findall(str(v or "")):
            u = m.upper()
            if u not in found:
                found.append(u)

    for ref in advisory.get("references") or []:
        if not isinstance(ref, dict):
            add(ref)
            continue
        rtype = (ref.get("ref_type") or ref.get("type") or "").lower()
        rid = ref.get("ref_id") or ref.get("id") or ""
        href = ref.get("href") or ref.get("url") or ""
        if rtype == "cve":
            add(rid or href or ref.get("title"))
        else:
            # A CVE page linked under another type still identifies the CVE
            add(href if "cve" in str(href).lower() else "")
            add(rid if str(rid).upper().startswith("CVE-") else "")

    if not found:
        add(advisory.get("title"))
        add(advisory.get("description"))
        add(advisory.get("summary"))
    return found


def parse_date(s):
    if not s:
        return None
    m = re.match(r"(\d{4}-\d{2}-\d{2})", str(s))
    return m.group(1) if m else None


def import_advisories(pulp, conn):
    """Load security advisories from every synced RPM repository."""
    repos = list(pulp.paged("/pulp/api/v3/repositories/rpm/rpm/?limit=100"))
    log.info("found %d RPM repositories in Pulp", len(repos))

    summary = {}
    for repo in repos:
        name = repo["name"]
        m = REPO_PREFIX.match(name)
        if not m:
            log.info("  %s: name does not map to an OS, skipping", name)
            continue
        os_id, os_major = m.group(1), int(m.group(2))

        vhref = repo.get("latest_version_href") or ""
        if not vhref or vhref.rstrip("/").endswith("/versions/0"):
            log.info("  %s: not synced yet, skipping", name)
            summary[name] = {"advisories": 0, "note": "not synced"}
            continue

        adv_iter = pulp.paged(
            "/pulp/api/v3/content/rpm/advisories/"
            f"?repository_version={vhref}&limit=200"
        )

        n_adv = n_pkg = n_cve = n_mod_skipped = 0
        adv_rows, cve_rows, pkg_rows = [], [], []

        for a in adv_iter:
            if (a.get("type") or "").lower() != "security":
                continue
            aid = a.get("id")
            if not aid:
                continue
            n_adv += 1

            vendor = "redhat" if os_id == "rhel" else "oracle"
            adv_rows.append((
                aid, vendor, (a.get("title") or "")[:500],
                (a.get("severity") or "").lower() or None,
                parse_date(a.get("issued_date")),
                parse_date(a.get("updated_date")),
                (a.get("summary") or a.get("description") or "")[:4000],
                os_id, os_major,
            ))

            for cve in extract_cves(a):
                cve_rows.append((aid, cve))
                n_cve += 1

            for coll in a.get("pkglist") or []:
                # RHEL 8 modular content: the same package can appear for
                # several streams with different versions. Comparing across
                # streams produces false positives, so modular collections
                # are skipped in this version and counted instead.
                if coll.get("module"):
                    n_mod_skipped += len(coll.get("packages") or [])
                    continue
                for p in coll.get("packages") or []:
                    if not p.get("name") or not p.get("version"):
                        continue
                    pkg_rows.append((
                        aid, p["name"], p.get("arch") or "noarch",
                        int(p.get("epoch") or 0), p["version"],
                        p.get("release") or "",
                    ))
                    n_pkg += 1

        with conn.transaction():
            with conn.cursor() as cur:
                cur.executemany(
                    """INSERT INTO advisories
                         (id, vendor, title, severity, issued_at, updated_at_v,
                          summary, os_id, os_major)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
                       ON CONFLICT (id) DO UPDATE SET
                         title=EXCLUDED.title, severity=EXCLUDED.severity,
                         updated_at_v=EXCLUDED.updated_at_v,
                         summary=EXCLUDED.summary, imported_at=now()""",
                    adv_rows,
                )
                cur.executemany(
                    """INSERT INTO advisory_cves (advisory_id, cve_id)
                       VALUES (%s,%s) ON CONFLICT DO NOTHING""",
                    cve_rows,
                )
                # An advisory listing the same name+arch twice (rare outside
                # modular content, which is skipped above) keeps the first.
                cur.executemany(
                    """INSERT INTO advisory_packages
                         (advisory_id, name, arch, epoch, version, release)
                       VALUES (%s,%s,%s,%s,%s,%s)
                       ON CONFLICT (advisory_id, name, arch) DO NOTHING""",
                    pkg_rows,
                )

        summary[name] = {"advisories": n_adv, "packages": n_pkg,
                         "cves": n_cve, "modular_skipped": n_mod_skipped}
        if n_adv and not n_cve:
            log.warning("  %s: %d advisories but NO CVE references were found. "
                        "The repository metadata may omit them; check one advisory with: "
                        "pulp rpm content -t advisory list --limit 1", name, n_adv)
        note = ""
        if n_adv == 0 and os_id == "ol":
            note = ("  <- Oracle's public repos often omit errata metadata; "
                    "the Oracle OVAL feed is needed for these hosts")
        log.info("  %-20s %5d advisories, %6d packages, %5d CVEs%s%s",
                 name, n_adv, n_pkg, n_cve,
                 f", {n_mod_skipped} modular skipped" if n_mod_skipped else "",
                 note)

    return summary


# ---------------------------------------------------------------------------
# Compute
# ---------------------------------------------------------------------------

def split_running_kernel(uname_r):
    """'5.14.0-570.12.1.el9_6.x86_64' -> ('5.14.0', '570.12.1.el9_6')."""
    s = uname_r or ""
    s = re.sub(r"\.(x86_64|aarch64|ppc64le|s390x|i686|noarch)$", "", s)
    if "-" in s:
        v, _, r = s.partition("-")
        return v, r
    return s, ""


def arch_matches(host_arch, adv_arch):
    return host_arch == adv_arch or "noarch" in (host_arch, adv_arch)


def compute_host(conn, host):
    """Recompute every verdict for one host, atomically."""
    hid = host["id"]

    # Stale inventory cannot support a verdict
    stale = (host["status"] == "stale" or host["last_inventory"] is None or
             (datetime.now(timezone.utc) - host["last_inventory"]).total_seconds()
             > STALE_HOURS * 3600)

    installed = defaultdict(list)
    for p in conn.execute(
        "SELECT name, arch, epoch, version, release FROM host_packages WHERE host_id=%s",
        (hid,),
    ).fetchall():
        installed[p["name"]].append(p)

    if not installed:
        # No package list to judge by: verdicts from an earlier inventory are
        # no longer evidence, so they read as unknown (never as fixed)
        with conn.transaction():
            conn.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", ("applicability:" + str(hid),))
            n = conn.execute(
                """UPDATE host_applicability SET state = 'unknown', reason = %s, computed_at = now()
                    WHERE host_id = %s AND state <> 'unknown'""",
                (NO_INVENTORY_REASON, hid)).rowcount
        return {"skipped": "no inventory", "marked_unknown": n}

    adv_pkgs = conn.execute(
        """SELECT ap.advisory_id, ap.name, ap.arch, ap.epoch, ap.version, ap.release
             FROM advisory_packages ap
             JOIN advisories a ON a.id = ap.advisory_id
            WHERE a.os_id = %s AND a.os_major = %s
              AND ap.name = ANY(%s)""",
        (host["os_id"], host["os_major"], list(installed.keys())),
    ).fetchall()

    run_v, run_r = split_running_kernel(host["kernel_running"])
    host_needs_reboot = bool(host["reboot_required"])

    # Severity order for choosing a single verdict per advisory
    rank = {"affected": 3, "fixed_pending_reboot": 2, "fixed_active": 1}
    verdicts = {}

    for ap in adv_pkgs:
        for inst in installed[ap["name"]]:
            if not arch_matches(inst["arch"], ap["arch"]):
                continue

            cmp = rpm_label_compare(inst["epoch"], inst["version"], inst["release"],
                                    ap["epoch"], ap["version"], ap["release"])
            inst_s = evr_str(inst["epoch"], inst["version"], inst["release"])
            fix_s = evr_str(ap["epoch"], ap["version"], ap["release"])

            if cmp < 0:
                state = "affected"
                reason = f"{ap['name']} {inst_s} is older than the fixed {fix_s}"
            elif is_kernel(ap["name"]):
                # Installed is not effective: compare the running kernel
                rc = rpm_label_compare(0, run_v, run_r,
                                       ap["epoch"], ap["version"], ap["release"])
                if rc < 0:
                    state = "fixed_pending_reboot"
                    reason = (f"fixed kernel {fix_s} installed but running "
                              f"{host['kernel_running']}")
                else:
                    state = "fixed_active"
                    reason = f"running kernel is at or above {fix_s}"
            elif ap["name"] in REBOOT_PACKAGES and host_needs_reboot:
                state = "fixed_pending_reboot"
                reason = f"{ap['name']} {inst_s} installed; host reports a reboot is required"
            else:
                state = "fixed_active"
                reason = f"{ap['name']} {inst_s} is at or above the fixed {fix_s}"

            if stale:
                state = "unknown"
                reason = f"host inventory older than {STALE_HOURS}h"

            cur = verdicts.get(ap["advisory_id"])
            if cur is None or rank.get(state, 0) > rank.get(cur["state"], 0):
                verdicts[ap["advisory_id"]] = {
                    "state": state, "package": ap["name"],
                    "installed": inst_s, "fixed": fix_s, "reason": reason,
                }

    with conn.transaction():
        # One recompute of a host at a time (the worker after an inventory or a
        # patch job, and the nightly run): held until the transaction ends
        conn.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", ("applicability:" + str(hid),))
        conn.execute("DELETE FROM host_applicability WHERE host_id=%s", (hid,))
        with conn.cursor() as cur:
            cur.executemany(
                """INSERT INTO host_applicability
                     (host_id, advisory_id, state, fix_available,
                      package_name, installed_evr, fixed_evr, reason)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
                [(hid, aid, v["state"],
                  # Every advisory here came from a synced Pulp repository,
                  # so the fixed package is held locally.
                  "available",
                  v["package"], v["installed"], v["fixed"], v["reason"][:500])
                 for aid, v in verdicts.items()],
            )

    counts = defaultdict(int)
    for v in verdicts.values():
        counts[v["state"]] += 1
    return dict(counts)


def supports(os_id):
    """Whether the engine computes verdicts for this OS: RHEL and Oracle Linux from
    the Pulp advisories, Windows Server from Microsoft's (app.msrc: its OS build)."""
    return (os_id or "") in SUPPORTED_OS


# ---------------------------------------------------------------------------
# Staleness: a server that stops reporting reads as unknown, never as fixed
# ---------------------------------------------------------------------------

SWEEP_SECONDS = int(os.environ.get("STALE_SWEEP_SECONDS", "900"))
_last_sweep = {"at": 0.0}

# Verdicts the sweep set aside; a server reporting again gets them worked out anew
STALE_SQL = """
UPDATE host_applicability ha
   SET state = 'unknown', reason = %(reason)s, computed_at = now()
  FROM hosts h
 WHERE h.id = ha.host_id AND ha.state <> 'unknown' AND h.status <> 'decommissioned'
   AND (h.status = 'stale' OR h.last_inventory IS NULL
        OR h.last_inventory < now() - make_interval(hours => %(hours)s::int))"""

REVIVE_SQL = """
UPDATE hosts h SET packages_changed_at = now()
 WHERE h.status = 'active' AND h.packages_changed_at IS NULL
   AND h.last_inventory >= now() - make_interval(hours => %(hours)s::int)
   AND EXISTS (SELECT 1 FROM host_applicability ha
                WHERE ha.host_id = h.id AND ha.state = 'unknown'
                  AND (ha.reason = %(reason)s OR ha.reason = 'host inventory is stale'
                       OR ha.reason LIKE 'host inventory older than %%'))"""


def sweep_due(now, last, every=None):
    """Whether the staleness sweep should run (pure, for the tests)."""
    every = SWEEP_SECONDS if every is None else every
    return last <= 0 or now - last >= every


def staleness_sweep(conn, hours=None, force=False):
    """Run from the worker every few minutes (it runs at most every SWEEP_SECONDS,
    15 minutes by default; force=True runs it now). Three steps, one transaction:

      1. mark_stale_hosts() (schema 001): active servers silent beyond the window
         become 'stale', and their verdicts 'unknown'
      2. any server whose inventory is older than the window (it may still check in
         without sending one) has its verdicts set to 'unknown' too, as compute_host
         would
      3. a server reporting again with a fresh inventory but verdicts left 'unknown'
         by 1 or 2 is queued for the applicability loop (packages_changed_at), so
         its real verdicts come back within a minute

    Returns {"stale_hosts", "verdicts_unknown", "requeued"}, or None when not due."""
    now = time.time()
    if not force and not sweep_due(now, _last_sweep["at"]):
        return None
    hours = STALE_HOURS if hours is None else int(hours)
    p = {"hours": hours, "reason": STALE_REASON}
    with conn.transaction():
        n_hosts = conn.execute("SELECT mark_stale_hosts(%s) AS n", (hours,)).fetchone()["n"]
        n_rows = conn.execute(STALE_SQL, p).rowcount
        try:
            with conn.transaction():
                n_back = conn.execute(REVIVE_SQL, p).rowcount
        except Exception as e:  # noqa: BLE001 - schema 039 (packages_changed_at) not applied: the nightly run catches up
            log.info("staleness sweep: servers reporting again not requeued: %s", e)
            n_back = 0
    _last_sweep["at"] = now
    res = {"stale_hosts": n_hosts or 0, "verdicts_unknown": n_rows or 0, "requeued": n_back or 0}
    if any(res.values()):
        log.info("staleness sweep: %s", json.dumps(res))
    return res


def periodic_sweep(conn):
    """The worker's one-line call (applicability loop): the staleness sweep when it
    is due, committed; a failure is logged and never stops the caller."""
    try:
        res = staleness_sweep(conn)
        if not conn.autocommit:
            conn.commit()
        return res
    except Exception as e:  # noqa: BLE001 - tried again on the next round
        log.warning("staleness sweep failed: %s", e)
        _last_sweep["at"] = time.time()          # not retried every round: at the next interval
        try:
            if not conn.autocommit:
                conn.rollback()
        except Exception:  # noqa: BLE001
            pass
        return None


def compute_all(conn):
    hosts = conn.execute(
        """SELECT id, hostname, os_id, os_major, status, kernel_running,
                  reboot_required, last_inventory
             FROM hosts
            WHERE status <> 'decommissioned'
            ORDER BY hostname"""
    ).fetchall()
    log.info("computing applicability for %d host(s)", len(hosts))

    unsupported = []
    for h in hosts:
        if not supports(h["os_id"]):
            unsupported.append(f"{h['hostname']} ({h['os_id']})")
            continue
        t = time.time()
        try:
            res = compute_host(conn, h)
        except Exception as e:                 # one host does not stop the run
            log.error("  %-24s failed: %s", h["hostname"], e)
            if not conn.autocommit:
                conn.rollback()
            continue
        log.info("  %-24s %s %s  %s  (%.1fs)", h["hostname"], h["os_id"],
                 h["os_major"], json.dumps(res), time.time() - t)

    if unsupported:
        log.info("not supported by the advisory engine (Ubuntu: its package manager's list is used): %s",
                 ", ".join(unsupported))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--import", dest="do_import", action="store_true")
    ap.add_argument("--compute", action="store_true")
    args = ap.parse_args()
    do_import = args.do_import or not args.compute
    do_compute = args.compute or not args.do_import

    started = time.time()
    with psycopg.connect(**DB, row_factory=dict_row, connect_timeout=15) as conn:
        conn.autocommit = True
        if do_import:
            log.info("== importing advisories from Pulp")
            import_advisories(Pulp(), conn)
        if do_compute:
            log.info("== marking silent servers")
            try:
                staleness_sweep(conn, force=True)
            except Exception as e:  # noqa: BLE001 - compute_host still treats stale inventory as unknown
                log.warning("staleness sweep failed: %s", e)
            log.info("== computing applicability")
            compute_all(conn)

        s = conn.execute(
            """SELECT
                 (SELECT count(*) FROM advisories)                AS advisories,
                 (SELECT count(*) FROM advisory_cves)             AS cves,
                 (SELECT count(*) FROM advisory_packages)         AS fixed_pkgs,
                 (SELECT count(*) FROM host_applicability
                    WHERE state='affected')                       AS affected,
                 (SELECT count(*) FROM host_applicability
                    WHERE state='fixed_pending_reboot')           AS pending_reboot,
                 (SELECT count(*) FROM host_applicability
                    WHERE state='fixed_active')                   AS fixed_active,
                 (SELECT count(*) FROM host_applicability
                    WHERE state='unknown')                        AS unknown"""
        ).fetchone()
        log.info("== done in %.0fs: %s", time.time() - started, json.dumps(s))


if __name__ == "__main__":
    main()
