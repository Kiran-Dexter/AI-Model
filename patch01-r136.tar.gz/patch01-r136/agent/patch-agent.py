#!/usr/bin/env python3
"""
PATCH-01 agent

Runs on each managed host. Pull-only: every connection is outbound to
PATCH-01 over 443, so managed hosts need no inbound firewall rule.

  enroll      redeem an enrollment token for a per-host agent token
  checkin     heartbeat, report kernel and reboot state
  inventory   report OS, installed packages, kernel, reboot status
  run         checkin, then execute any queued commands
  check       prove this file loads and reads its settings and token (prints
              "PATCH-01 agent <version> ready"); used to test an update
  update-check  run by the previous version after an update: puts itself
              back if the new version has not answered PATCH-01's check job
              in time; stops a new version that hangs
  release-key [FILE]  the pinned release-signing key (or check a key file)

UPDATES FROM PATCH-01 (agent 1.8.0+)

  The new file is downloaded over the verified connection, checked against
  the SHA-256 in the job and (1.8.3+, once a release-signing key is pinned in
  /etc/patch-agent/release-signing.pub) against its signature made with an
  OFFLINE key that never lives on PATCH-01; then compiled, test-run with
  "check", and only then
  swapped in; the running version is kept as <path>.prev and a systemd timer
  (patch-agent-update-check, also after a restart) runs it to put itself back
  if the new one has not answered PATCH-01's check job within 10 minutes (or
  the agent's interval plus 5), and stops a new version that hangs. Never a
  downgrade, and never on an agent that does not verify PATCH-01's certificate.

SECURITY MODEL

  The agent executes a CLOSED SET of verbs. Each verb maps to a fixed
  function in VERB_HANDLERS below. There is no verb that accepts a shell
  command, and the server cannot introduce one: an unrecognised verb is
  refused and reported as an error.

  install_packages accepts a list of package names with target versions and
  passes them to dnf or apt as separate argv elements, after "--". Nothing
  from the server reaches a shell. Package names are validated against a
  strict pattern before use (a letter or digit first: never an option).

  update_agent replaces this file. With a release-signing key pinned, only a
  file signed with the offline key is accepted; without one, the SHA-256 that
  PATCH-01 sends is the only check (the check-in reports release_key=none).

  This is what bounds the damage if PATCH-01 is ever compromised: the worst
  an attacker can do is install signed packages from a signed repository,
  rather than run arbitrary commands as root on every host. That holds for
  update_agent only once the release-signing key is pinned (see above).

Requires Python 3.6+ and the standard library only, so it runs on RHEL 8
(Python 3.6) through Ubuntu 24.04 without extra packages.
"""

import argparse
import base64
import gzip
import hashlib
import json
import os
import platform
import re
import shutil
import signal
import ssl
import fcntl
import subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

AGENT_VERSION = "1.8.5"

CONFIG_DIR = "/etc/patch-agent"
CONFIG_FILE = os.path.join(CONFIG_DIR, "agent.conf")
TOKEN_FILE = os.path.join(CONFIG_DIR, "token")
STATE_DIR = "/var/lib/patch-agent"
LOG_FILE = "/var/log/patch-agent.log"

# Package names and versions coming from the server are validated against
# this before being passed to the package manager. The first character must be
# a letter or digit: a name starting with "-" would be read as an option
# ("--nogpgcheck", "--enablerepo=...", "--allow-unauthenticated"). The package
# arguments also follow "--", so even a name that got through could not be one.
SAFE_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+\-~^:]*$")

HTTP_TIMEOUT = 60


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def log(msg, level="INFO"):
    line = "%s %s %s" % (
        datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), level, msg)
    print(line, flush=True)
    try:
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        with open(LOG_FILE, "a") as fh:
            fh.write(line + "\n")
    except Exception:
        pass


LOG_OFFSET_FILE = os.path.join(STATE_DIR, "log.offset")
_LOG_LINE_RE = re.compile(r"^(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ) (\w+) (.+)$")


def send_log_tail(cfg, token):
    """Send the log lines written since the last send, so failures can be read
    in the console. A problem here never breaks a run, and it never logs about
    itself (that would feed its own output)."""
    try:
        if not os.path.exists(LOG_FILE):
            return
        try:
            with open(LOG_OFFSET_FILE) as fh:
                off = int(fh.read().strip() or 0)
        except (OSError, ValueError):
            off = 0
        size = os.path.getsize(LOG_FILE)
        if size < off:
            off = 0                                   # the log was rotated
        if size == off:
            return
        off = max(off, size - 262144)                 # at most the last 256 KB
        with open(LOG_FILE, "rb") as fh:
            fh.seek(off)
            text = fh.read().decode("utf-8", "replace")
        lines = []
        for l in text.splitlines():
            m = _LOG_LINE_RE.match(l)
            if m:
                lines.append({"at": m.group(1), "level": m.group(2)[:8], "msg": m.group(3)[:2000]})
        if lines:
            api_call(cfg, "POST", "/api/v1/agent/log", {"lines": lines[-500:]}, token)
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(LOG_OFFSET_FILE, "w") as fh:
            fh.write(str(size))
    except Exception:
        pass


def post_result(cfg, token, cid, verb, body):
    """A lost result leaves PATCH-01 waiting: retry, and log if it still fails."""
    reply_lost = False
    for attempt in (1, 2, 3):
        try:
            api_call(cfg, "POST", "/api/v1/agent/commands/%s/result" % cid, body, token)
            return True
        except Exception as e:
            # A retry after a reply lost on the way back: PATCH-01 already has this result.
            # Only then: a 404 on the first try means PATCH-01 refused it (1.8.5)
            if reply_lost and "HTTP 404" in str(e) and "no such pending command" in str(e):
                return True
            reply_lost = reply_lost or not str(e).startswith("HTTP ")
            log("sending the result of %s failed (try %d of 3): %s" % (verb, attempt, e), "ERROR")
            time.sleep(5 * attempt)
    return False


def die(msg):
    log(msg, "FATAL")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

def load_config():
    cfg = {"server": "", "verify_tls": "true", "ca_file": "", "group": "default"}
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                cfg[k.strip()] = v.strip().strip('"').strip("'")
    # Environment overrides the file, for testing
    cfg["server"] = os.environ.get("PATCH_SERVER", cfg["server"])
    return cfg


def load_token():
    if not os.path.exists(TOKEN_FILE):
        return None
    with open(TOKEN_FILE) as fh:
        return fh.read().strip() or None


def save_token(token):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    # 0600: the token is this host's credential
    fd = os.open(TOKEN_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        fh.write(token + "\n")
    os.chmod(TOKEN_FILE, 0o600)


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

def build_ssl_context(cfg):
    """TLS context.

    verify_tls=false exists only for the self-signed placeholder certificate
    on a new install. It must be turned on once a CA-signed certificate is in
    place, and the agent says so on every call while it is off.
    """
    verify = str(cfg.get("verify_tls", "true")).lower() not in ("false", "0", "no")
    ctx = ssl.create_default_context()
    if not verify:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    ca = cfg.get("ca_file")
    if ca and os.path.exists(ca):
        # Only the CA setup checked PATCH-01 against, not every CA the system trusts as well
        return ssl.create_default_context(cafile=ca)
    if ca:
        log("ca_file %s is missing: falling back to the system trust store. Run setup-agent.sh again." % ca, "WARN")
    return ctx


def api_call(cfg, method, path, body=None, token=None, timeout=HTTP_TIMEOUT):
    server = cfg["server"].rstrip("/")
    if not server:
        die("No server configured. Set 'server=' in %s" % CONFIG_FILE)
    url = server + path

    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", "patch-agent/%s" % AGENT_VERSION)
    if data:
        req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)

    ctx = build_ssl_context(cfg)
    # PATCH-01 is internal. urllib honours HTTP(S)_PROXY from the environment
    # by default, so a host with a global corporate proxy would otherwise
    # send its check-ins through the proxy. An empty ProxyHandler disables
    # that for every call the agent makes.
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        urllib.request.HTTPSHandler(context=ctx),
    )
    try:
        with opener.open(req, timeout=timeout) as resp:
            raw = resp.read().decode()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = e.read().decode()[:1000]
        except Exception:
            pass
        raise RuntimeError("HTTP %s on %s %s: %s" % (e.code, method, path, detail))
    except urllib.error.URLError as e:
        raise RuntimeError("cannot reach %s: %s" % (url, e.reason))


# ---------------------------------------------------------------------------
# Host facts
# ---------------------------------------------------------------------------

def run_cmd(argv, timeout=300):
    """Run a fixed argv list. Never a shell string: no argument from the
    server is ever interpolated into a shell command."""
    try:
        p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=timeout)
        return p.returncode, p.stdout.decode(errors="replace"), \
            p.stderr.decode(errors="replace")
    except subprocess.TimeoutExpired:
        return 124, "", "timed out after %ss" % timeout
    except FileNotFoundError:
        return 127, "", "%s not found" % argv[0]


def read_os_release():
    data = {}
    for path in ("/etc/os-release", "/usr/lib/os-release"):
        if os.path.exists(path):
            with open(path) as fh:
                for line in fh:
                    line = line.strip()
                    if "=" in line and not line.startswith("#"):
                        k, _, v = line.partition("=")
                        data[k] = v.strip().strip('"').strip("'")
            break
    return data


def machine_id():
    """Stable machine identity.

    Used instead of hostname as the enrollment key, so a renamed host keeps
    its history rather than appearing as a new machine.
    """
    for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        if os.path.exists(path):
            with open(path) as fh:
                mid = fh.read().strip()
                if mid:
                    return mid
    # Fall back to a hash of stable hardware identifiers
    parts = []
    for path in ("/sys/class/dmi/id/product_uuid",
                 "/sys/class/dmi/id/board_serial"):
        try:
            with open(path) as fh:
                parts.append(fh.read().strip())
        except Exception:
            pass
    parts.append(platform.node())
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:32]


def detect_pkg_manager():
    if shutil.which("dnf"):
        return "dnf"
    if shutil.which("apt-get"):
        return "apt"
    if shutil.which("yum"):
        return "yum"
    return None


def vercmp(a, b):
    """-1, 0 or 1, as rpm (and, for kernels, dpkg) order versions: runs of digits compare as
    numbers, digits sort after letters, '~' sorts before anything (1.8.5)."""
    if a == b:
        return 0
    x, y = re.findall(r"~|[0-9]+|[A-Za-z]+", a or ""), re.findall(r"~|[0-9]+|[A-Za-z]+", b or "")
    while x or y:
        tx, ty = bool(x) and x[0] == "~", bool(y) and y[0] == "~"
        if tx or ty:
            if not tx:
                return 1
            if not ty:
                return -1
            x.pop(0)
            y.pop(0)
            continue
        if not x:
            return -1
        if not y:
            return 1
        p, q = x.pop(0), y.pop(0)
        if p.isdigit() and q.isdigit():
            p, q = int(p), int(q)
        elif p.isdigit() or q.isdigit():
            return 1 if p.isdigit() else -1
        if p != q:
            return 1 if p > q else -1
    return 0


def _newest(items, key=lambda v: v):
    best = None
    for it in items:
        if best is None or vercmp(key(it), key(best)) > 0:
            best = it
    return best


def _rpm_kernels(running):
    """Installed kernels of the running kernel's family (UEK or not), as uname -r prints them."""
    rc, out, _ = run_cmd(["rpm", "-q", "--qf", "%{NAME}\t%{VERSION}-%{RELEASE}.%{ARCH}\n",
                          "kernel", "kernel-core", "kernel-uek", "kernel-uek-core"])
    uek = "uek" in running
    found = set()
    for line in out.splitlines():           # rc is not 0 when one of the names is not installed
        parts = line.strip().split("\t")
        if len(parts) == 2 and parts[0].startswith("kernel") and ("uek" in parts[0]) == uek:
            found.add(parts[1])
    return sorted(found)


def _dpkg_kernels(running):
    """{uname -r: package version} for installed kernel images of the running kernel's flavour."""
    rc, out, _ = run_cmd(["dpkg-query", "-W", "-f", "${Package}\t${Version}\t${db:Status-Abbrev}\n",
                          "linux-image-[0-9]*"])
    flavour = re.sub(r"^[0-9][0-9.]*-[0-9]+", "", running)        # -generic, -amd64, -cloud-amd64
    found = {}
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) < 3 or parts[2][1:2] != "i":               # installed (ii, or hi when held); not "rc"
            continue
        abi = parts[0][len("linux-image-"):]
        if re.match(r"^[0-9]", abi) and re.sub(r"^[0-9][0-9.]*-[0-9]+", "", abi) == flavour:   # -amd64, not -cloud-amd64
            found[abi] = parts[1]
    return found


def collect_kernel():
    """(running, newest installed of the same kind), both as uname -r prints them."""
    running = platform.release()
    latest = running
    pm = detect_pkg_manager()
    try:
        if pm in ("dnf", "yum"):
            latest = _newest(_rpm_kernels(running)) or running
        elif pm == "apt":
            k = _dpkg_kernels(running)
            if k:
                latest = _newest(k, key=lambda abi: k[abi]) or running
    except Exception as e:  # noqa: BLE001 - a kernel we cannot read is reported as the running one
        log("could not list installed kernels: %s" % e, "WARN")
    return running, latest


def boot_time_iso():
    """When this host last booted, as an ISO timestamp.

    Read from the kernel's own record (btime in /proc/stat) rather than
    computed from uptime, so it is exact. The server derives uptime from it,
    which stays correct between check-ins.
    """
    try:
        with open("/proc/stat") as fh:
            for line in fh:
                if line.startswith("btime "):
                    ts = int(line.split()[1])
                    return datetime.fromtimestamp(ts, timezone.utc).isoformat()
    except Exception:
        pass
    return None


def hardware_uuid():
    """The machine's SMBIOS UUID, which VMware sets to the VM's BIOS UUID.

    This is how PATCH-01 links a server to its VM in vCenter without relying
    on hostnames or IP addresses, which drift. Readable by root only, which
    the agent is. Returns None on hardware that does not provide one.
    """
    for path in ("/sys/class/dmi/id/product_uuid", "/sys/devices/virtual/dmi/id/product_uuid"):
        try:
            with open(path) as fh:
                v = fh.read().strip().lower()
            if re.match(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", v) \
                    and v.replace("-", "") not in ("0" * 32, "f" * 32):
                return v
        except Exception:
            pass
    return None


def check_reboot_required():
    """Whether the running kernel differs from the newest installed.

    This is the distinction between 'fix installed' and 'fix active'. A host
    with the patched kernel installed but the vulnerable one still running is
    NOT remediated, and reporting it as such is how a vulnerability survives
    an audit.
    """
    pm = detect_pkg_manager()

    if pm == "apt":
        if os.path.exists("/var/run/reboot-required"):
            reason = "reboot-required flag set"
            pkgs_file = "/var/run/reboot-required.pkgs"
            if os.path.exists(pkgs_file):
                try:
                    with open(pkgs_file) as fh:
                        pkgs = sorted(set(p.strip() for p in fh if p.strip()))
                    if pkgs:
                        reason = "packages requiring reboot: " + \
                                 ", ".join(pkgs[:10])
                except Exception:
                    pass
            return True, reason
        # Plain Debian never writes that flag (Ubuntu's update-notifier does): compare kernels
        running = platform.release()
        k = _dpkg_kernels(running)
        latest = _newest(k, key=lambda abi: k[abi]) if k else None
        if latest and running in k and latest != running and vercmp(k[latest], k[running]) > 0:
            return True, "running kernel %s, newest installed %s" % (running, latest)
        # The same ABI with a newer build (Debian keeps the name for point releases)
        try:
            with open("/proc/version") as fh:
                # "... (gcc-12 (Debian 12.2.0-14) ...) #1 SMP PREEMPT_DYNAMIC Debian 6.1.76-1 (2024-02-01)":
                # the kernel's own build comes after the "#N" marker, gcc's version before it
                m = re.search(r"#\d+ .*\bDebian (\S+)", fh.read())
            if m:
                inst = _dpkg_kernels(running).get(running)
                if inst and inst != m.group(1):
                    return True, "kernel %s was updated to %s; %s is still running" % (running, inst, m.group(1))
        except OSError:
            pass
        return False, None

    # RHEL / Oracle: needs-restarting -r is authoritative
    if shutil.which("needs-restarting"):
        rc, out, _ = run_cmd(["needs-restarting", "-r"], timeout=60)
        if rc == 1:
            return True, (out.strip().split("\n")[0][:500]
                          if out.strip() else "needs-restarting reports reboot required")
        if rc == 0:
            return False, None

    # Fallback: compare running against newest installed kernel (by version, 1.8.5)
    running, latest = collect_kernel()
    if latest and latest != running and vercmp(latest, running) > 0:
        return True, "running kernel %s, newest installed %s" % (running, latest)
    return False, None


def collect_packages():
    """Every installed package as name, version, arch.

    Version is reported as the full epoch:version-release string; the server
    splits it into separate columns. Epoch is included explicitly because
    dropping it silently inverts later version comparisons.
    """
    pm = detect_pkg_manager()
    pkgs = []

    if pm in ("dnf", "yum"):
        # %|EPOCH?{...}| emits the epoch only when set, matching how RPM
        # itself renders NEVRA
        rc, out, err = run_cmd([
            "rpm", "-qa", "--qf",
            "%{NAME}\t%|EPOCH?{%{EPOCH}:}|%{VERSION}-%{RELEASE}\t%{ARCH}\t"
            "%|INSTALLTIME?{%{INSTALLTIME}}:{0}|\n",
        ], timeout=300)
        if rc != 0:
            raise RuntimeError("rpm -qa failed: %s" % err[:300])
        for line in out.split("\n"):
            if not line.strip():
                continue
            fields = line.split("\t")
            if len(fields) < 3:
                continue
            name, version, arch = fields[0], fields[1], fields[2]
            if not (SAFE_NAME.match(name) and SAFE_NAME.match(arch)):
                continue
            pkgs.append({"name": name, "version": version, "arch": arch,
                         "install_time": _epoch_iso(fields[3] if len(fields) > 3 else None)})

    elif pm == "apt":
        rc, out, err = run_cmd([
            "dpkg-query", "-W", "-f",
            "${Package}\t${Version}\t${Architecture}\t${db:Status-Status}\n",
        ], timeout=300)
        if rc != 0:
            raise RuntimeError("dpkg-query failed: %s" % err[:300])
        for line in out.split("\n"):
            if not line.strip():
                continue
            fields = line.split("\t")
            if len(fields) < 4:
                continue
            name, version, arch, st = fields[0], fields[1], fields[2], fields[3]
            # Only fully installed packages count
            if st.strip() != "installed":
                continue
            if not (SAFE_NAME.match(name) and SAFE_NAME.match(arch)):
                continue
            pkgs.append({"name": name, "version": version, "arch": arch,
                         "install_time": _dpkg_install_time(name, arch)})
    else:
        raise RuntimeError("no supported package manager found")

    return pkgs


def _epoch_iso(v):
    """rpm's INSTALLTIME (seconds since 1970) as an ISO time, or None."""
    try:
        n = int(str(v or "").strip())
    except ValueError:
        return None
    if n <= 0:
        return None
    return datetime.fromtimestamp(n, timezone.utc).isoformat()


def _dpkg_install_time(name, arch):
    """dpkg keeps no install date: its file list for the package is rewritten
    on every install or upgrade, so its time is when this version went in."""
    for f in ("%s:%s.list" % (name, arch), "%s.list" % name):
        path = os.path.join("/var/lib/dpkg/info", f)
        try:
            return datetime.fromtimestamp(os.stat(path).st_mtime, timezone.utc).isoformat()
        except OSError:
            continue
    return None


# What the package manager itself would install now. This, not the CVE feeds,
# is what PATCH-01 shows as "to install" on its patching pages.
UPDATES_MAX = 5000
_NA_RE = re.compile(r"^([A-Za-z0-9._+\-~^]+)\.([A-Za-z0-9_]+)$")
_VER_RE = re.compile(r"^[0-9][A-Za-z0-9._+~^:\-]*$")


def _rpm_updates(pm, installed):
    rc, out, err = run_cmd([pm, "-q", "check-update"], timeout=240)
    if rc not in (0, 100):
        raise RuntimeError("%s check-update failed (rc=%d): %s" % (pm, rc, (err or out).strip()[-300:]))
    toks = []
    for line in out.split("\n"):
        if line.strip().lower().startswith("obsoleting packages"):
            break                                    # replacements follow: not updates of what is installed
        toks += line.split()
    items, i = [], 0
    while i + 2 < len(toks) and len(items) < UPDATES_MAX:
        m = _NA_RE.match(toks[i])
        if m and _VER_RE.match(toks[i + 1]):
            name, arch = m.group(1), m.group(2)
            items.append({"name": name, "arch": arch, "installed": installed.get((name, arch)),
                          "available": toks[i + 1], "repo": toks[i + 2][:128], "security": None})
            i += 3
        else:
            i += 1                                   # a message line: skip a word and look again
    if not items:
        return items
    # Which are security updates, by the repositories' own update notices for what is not
    # installed yet (every type: a repository with no notices at all says nothing, and its
    # updates stay "kind not known", counted as to install). A package is a security update
    # when any security notice names it (name.arch): installing the newest covers that fix,
    # even when a later bug-fix build is the newest.
    args = [pm, "-q", "updateinfo", "list", "--available"] if pm == "dnf" else [pm, "-q", "updateinfo", "list", "available"]
    rc2, out2, _ = run_cmd(args, timeout=240)
    if rc2 != 0:
        return items
    notices, any_notice = {}, False
    for line in out2.split("\n"):
        f = line.split()
        if len(f) < 3 or not SAFE_NAME.match(f[0]):
            continue
        any_notice = True
        if "sec" not in f[1].lower():
            continue
        nevra = f[2]
        base, dot, arch = nevra.rpartition(".")
        parts = base.rsplit("-", 2)
        if not dot or len(parts) != 3:
            continue
        key = (parts[0], arch)
        sev = f[1].split("/")[0] if "/" in f[1] else None
        notices.setdefault(key, (f[0][:64], sev))
    if not any_notice:
        return items                                 # no update notices in these repositories: kind not known
    for it in items:
        hit = notices.get((it["name"], it["arch"]))
        it["security"] = bool(hit)
        if hit:
            it["advisory"], it["severity"] = hit[0], hit[1]
    return items


_APT_INST = re.compile(r"^Inst (\S+) (?:\[(\S+)\] )?\((\S+) (.*?)(?: \[(\S+)\])?\)")


def _apt_updates(installed):
    env_lang = os.environ.get("LC_ALL")
    os.environ["LC_ALL"] = "C"
    try:
        # --with-new-pkgs (1.8.5): a kernel update is a new package (linux-image-<new ABI>);
        # plain "upgrade" keeps it back and never lists it, so kernels were never patched
        rc, out, err = run_cmd(["apt-get", "-s", "-q", "-o", "Debug::NoLocking=true", "--with-new-pkgs", "upgrade"],
                               timeout=240)
    finally:
        if env_lang is None:
            os.environ.pop("LC_ALL", None)
        else:
            os.environ["LC_ALL"] = env_lang
    if rc != 0:
        raise RuntimeError("apt-get -s upgrade failed (rc=%d): %s" % (rc, (err or out).strip()[-300:]))
    items = []
    for line in out.split("\n"):
        m = _APT_INST.match(line)
        if not m or len(items) >= UPDATES_MAX:
            continue
        name, old, new, repos, arch = m.groups()
        if ":" in name:                              # libc6:i386, a foreign-architecture package
            name, arch = name.split(":", 1)[0], arch or name.split(":", 1)[1]
        if not (SAFE_NAME.match(name) and SAFE_NAME.match(new)):
            continue
        arch = arch or "all"
        items.append({"name": name, "arch": arch, "installed": old or installed.get((name, arch)),
                      "available": new, "repo": repos.split(",")[0].strip()[:128],
                      "security": "-security" in repos})
    return items


def collect_updates(pkgs):
    """{"checked_at", "items", "error"}: never raises, an inventory is sent either way."""
    pm = detect_pkg_manager()
    installed = {(p["name"], p["arch"]): p["version"] for p in pkgs}
    res = {"checked_at": datetime.now(timezone.utc).isoformat(), "items": [], "error": None,
           "source": {"dnf": "dnf check-update", "yum": "yum check-update", "apt": "apt-get -s --with-new-pkgs upgrade"}.get(pm, pm)}
    try:
        if pm in ("dnf", "yum"):
            res["items"] = _rpm_updates(pm, installed)
        elif pm == "apt":
            res["items"] = _apt_updates(installed)
        else:
            res["error"] = "no supported package manager"
    except Exception as e:  # noqa: BLE001 - reported to PATCH-01, the inventory still goes
        res["error"] = str(e)[:500]
        log("update check failed: %s" % res["error"], "WARN")
    return res


# ---------------------------------------------------------------------------
# Verb handlers -- the closed set
# ---------------------------------------------------------------------------

def verb_collect_inventory(cfg, token, params):
    data = build_inventory()
    api_call(cfg, "POST", "/api/v1/agent/inventory", data, token)
    return {"packages": len(data["packages"])}


def verb_run_precheck(cfg, token, params):
    """Named checks only. The server names which checks to run; it cannot
    supply the check itself."""
    requested = params.get("checks") or ["disk", "locks", "history"]
    results = {}
    ok = True
    if params.get("capture_services") and shutil.which("systemctl"):
        # The post-check compares against this list, so a service that was
        # already down before patching is not blamed on the patch
        rc, out, _ = run_cmd(["systemctl", "list-units", "--type=service",
                              "--state=running", "--no-legend", "--plain"], timeout=60)
        if rc == 0:
            results["running_services"] = sorted(
                line.split()[0] for line in out.splitlines()
                if line.strip() and SAFE_NAME.match(line.split()[0]))[:300]

    if "disk" in requested:
        results["disk"] = {}
        for mount in ("/", "/boot", "/var"):
            if not os.path.isdir(mount):
                continue
            try:
                st = os.statvfs(mount)
                free_mb = (st.f_bavail * st.f_frsize) // (1024 * 1024)
                results["disk"][mount] = free_mb
                # A full /boot failing a kernel install is the single most
                # common patch failure
                threshold = 300 if mount == "/boot" else 1024
                if free_mb < threshold:
                    ok = False
                    results.setdefault("errors", []).append(
                        "%s has only %d MB free (need %d)" %
                        (mount, free_mb, threshold))
            except Exception as e:
                results["disk"][mount] = "error: %s" % e

    if "locks" in requested:
        pm = detect_pkg_manager()
        locked = False
        if pm in ("dnf", "yum"):
            for lk in ("/var/run/dnf.pid", "/var/lib/rpm/.rpm.lock"):
                if os.path.exists(lk):
                    rc, _, _ = run_cmd(["fuser", lk], timeout=15)
                    if rc == 0:
                        locked = True
        elif pm == "apt":
            for lk in ("/var/lib/dpkg/lock-frontend", "/var/lib/apt/lists/lock"):
                if os.path.exists(lk):
                    rc, _, _ = run_cmd(["fuser", lk], timeout=15)
                    if rc == 0:
                        locked = True
        results["package_manager_locked"] = locked
        if locked:
            ok = False
            results.setdefault("errors", []).append(
                "package manager is locked by another process")

    if "history" in requested:
        pm = detect_pkg_manager()
        clean = True
        if pm in ("dnf", "yum"):
            # What really blocks a transaction: problems in the package
            # database, as the package manager's own check reports them.
            # (Searching "dnf history" for "E" was wrong: E is also the
            # letter for Erase, which every kernel update shows.)
            rc, out, err = run_cmd([pm, "-q", "check"], timeout=300)
            problems = [l for l in (out + "\n" + err).splitlines() if l.strip()]
            if rc != 0 and problems:
                clean = False
                results.setdefault("errors", []).append(
                    "the package database has problems (%s check): %s" % (pm, problems[0][:160]))
            # A failed last transaction does not block the next one with dnf:
            # worth knowing, so it is a warning, not a failure
            rc2, info, _ = run_cmd([pm, "history", "info", "last"], timeout=60)
            if rc2 == 0:
                m = re.search(r"^\s*Return-Code\s*:\s*(.+)$", info, re.M)
                if m and m.group(1).strip().lower() != "success":
                    results.setdefault("warnings", []).append(
                        "the last %s transaction ended with: %s" % (pm, m.group(1).strip()))
        elif pm == "apt":
            rc, out, _ = run_cmd(["dpkg", "--audit"], timeout=60)
            if rc == 0 and out.strip():
                clean = False
                results.setdefault("errors", []).append(
                    "dpkg reports half-installed packages: run dpkg --configure -a")
        results["transaction_history_clean"] = clean
        if not clean:
            ok = False

    results["ok"] = ok
    if not ok:
        # Pre-check failure aborts without changing anything
        raise RuntimeError("pre-check failed: %s" %
                           "; ".join(results.get("errors", [])))
    return results


def _validated_package_args(params, pm=None):
    """Turn a server-supplied package list into safe argv elements.

    Each entry must be a plain name, optionally with a version. Anything
    containing shell metacharacters is refused outright rather than escaped,
    because refusing is easier to reason about.
    """
    pkgs = params.get("packages") or []
    if not isinstance(pkgs, list) or not pkgs:
        raise RuntimeError("no packages supplied")
    if len(pkgs) > 5000:
        raise RuntimeError("package list too long (%d)" % len(pkgs))

    args = []
    for entry in pkgs:
        if isinstance(entry, dict):
            name = entry.get("name", "")
            version = entry.get("version") or ""
        else:
            name, version = str(entry), ""
        if not SAFE_NAME.match(name):
            raise RuntimeError("refusing unsafe package name: %r" % name)
        if version and not SAFE_NAME.match(version):
            raise RuntimeError("refusing unsafe version: %r" % version)
        if not version:
            args.append(name)
        elif pm == "apt":
            # apt selects a version with name=version; name-version would be
            # read as a different package name and fail
            args.append("%s=%s" % (name, version))
        else:
            args.append("%s-%s" % (name, version))
    return args


def verb_download_packages(cfg, token, params):
    """Pre-download without installing, so the install step is fast and the
    window is short."""
    pm = detect_pkg_manager()
    args = _validated_package_args(params, pm)
    if pm in ("dnf", "yum"):
        argv = [pm, "install", "-y", "--downloadonly", "--setopt=tsflags=", "--"] + args
    elif pm == "apt":
        argv = ["apt-get", "install", "-y", "--no-remove", "--download-only", "--"] + args
    else:
        raise RuntimeError("no supported package manager")
    rc, out, err = run_cmd(argv, timeout=3600)
    if rc != 0:
        raise RuntimeError("download failed (rc=%d): %s" % (rc, err[-800:]))
    return {"downloaded": len(args), "output": out[-2000:]}


class VerbFailed(RuntimeError):
    """A failed step that still has a result to report (1.8.5)."""
    def __init__(self, message, result):
        RuntimeError.__init__(self, message)
        self.result = result


def verb_install_packages(cfg, token, params):
    """Install a specific list. argv only, never a shell string."""
    pm = detect_pkg_manager()
    mode = params.get("mode", "exact")
    if mode not in ("exact", "upgrade"):
        raise RuntimeError("unsupported install mode %r" % mode)
    # "upgrade" moves named packages to the newest available, ignoring any
    # version given; "exact" installs the precise version PATCH-01 chose
    if mode == "upgrade":
        args = _validated_package_args(
            {"packages": [p.get("name") if isinstance(p, dict) else p
                          for p in (params.get("packages") or [])]}, pm)
    else:
        args = _validated_package_args(params, pm)

    before, _ = collect_kernel()
    new_pkgs = _apt_not_installed(args) if pm == "apt" and mode == "exact" else []

    if pm in ("dnf", "yum"):
        argv = [pm, "upgrade" if mode == "upgrade" else "install", "-y", "--"] + args
    elif pm == "apt":
        # --no-remove (1.8.4): if the install would remove any package to make room,
        # apt stops instead. A patch job never takes software away.
        argv = ["apt-get", "install", "-y", "--no-remove",
                "-o", "Dpkg::Options::=--force-confdef",
                "-o", "Dpkg::Options::=--force-confold"]
        if mode == "upgrade":
            argv.append("--only-upgrade")
        argv += ["--"] + args
        os.environ["DEBIAN_FRONTEND"] = "noninteractive"
    else:
        raise RuntimeError("no supported package manager")

    rc, out, err = run_cmd(argv, timeout=7200)
    reboot, reason = check_reboot_required()

    result = {
        "packages_requested": len(args),
        "kernel_before": before,
        "reboot_required": reboot,
        "reboot_reason": reason,
        "output": out[-4000:],
    }
    if rc != 0:
        result["error"] = err[-2000:]
        # The result goes to PATCH-01 with the failure (Patch Reports, restart needed)
        raise VerbFailed("install failed (rc=%d): %s" % (rc, err[-800:]), result)
    if new_pkgs:
        # Named on the command line, apt would mark a new kernel "manually installed" and never
        # autoremove it: old kernels would pile up until /boot is full. They came as updates:
        # automatic, as apt's own upgrade would leave them (1.8.5)
        mrc, _, merr = run_cmd(["apt-mark", "auto"] + new_pkgs, timeout=120)
        result["marked_automatic"] = new_pkgs if mrc == 0 else []
        if mrc != 0:
            result["warnings"] = ["could not mark new packages as automatic: %s" % merr.strip()[-300:]]
    return result


def _apt_not_installed(args):
    """Which of these apt arguments (name or name=version) name packages not installed yet.
    (Names are checked by SAFE_NAME and never start with "-".)"""
    names = [a.split("=", 1)[0] for a in args]
    rc, out, _ = run_cmd(["dpkg-query", "-W", "-f", "${Package}\t${db:Status-Abbrev}\n"] + names, timeout=120)
    have = set()
    for line in out.splitlines():                    # rc is 1 when some are unknown: those are new
        parts = line.split("\t")
        if len(parts) == 2 and parts[1][1:2] == "i":
            have.add(parts[0].split(":", 1)[0])
    return [n for n in names if n not in have]


def verb_reboot_host(cfg, token, params):
    """Schedule a reboot far enough out that this result can be reported
    first, otherwise the server never learns the reboot was accepted."""
    delay = int(params.get("delay_seconds", 60))
    delay = max(10, min(delay, 3600))
    minutes = max(1, (delay + 59) // 60)          # shutdown takes whole minutes
    if shutil.which("shutdown"):
        rc, out, err = run_cmd(["shutdown", "-r", "+%d" % minutes,
                                "PATCH-01 scheduled reboot"], timeout=30)
        if rc != 0:
            raise RuntimeError("shutdown failed: %s" % err[:500])
    else:
        raise RuntimeError("shutdown command not available")
    return {"reboot_scheduled_in_seconds": minutes * 60}


def _uptime_minutes():
    """Minutes since boot, or a large number when it cannot be read."""
    try:
        with open("/proc/uptime") as fh:
            return float(fh.read().split()[0]) / 60
    except (OSError, ValueError, IndexError):
        return 10 ** 6


def verb_run_postcheck(cfg, token, params):
    """Compare against the baseline captured at pre-check time.

    Comparing against an absolute notion of healthy would blame the patch for
    a service that was already down beforehand.
    """
    baseline = params.get("baseline_services") or []
    results = {"services": {}, "ok": True}

    running, latest = collect_kernel()
    reboot, reason = check_reboot_required()
    results["kernel_running"] = running
    results["kernel_latest"] = latest
    results["reboot_required"] = reboot
    results["reboot_reason"] = reason

    if shutil.which("systemctl"):
        # Right after a restart some services are still starting: give them a few minutes
        # before calling the post-check failed
        deadline = time.time() + (240 if _uptime_minutes() < 15 else 0)
        while True:
            pending = []
            for svc in baseline:
                if SAFE_NAME.match(str(svc)):
                    rc, out, _ = run_cmd(["systemctl", "is-active", str(svc)], timeout=30)
                    if out.strip() in ("activating", "inactive", "failed", "deactivating", "reloading"):
                        pending.append(svc)
            if not pending or time.time() >= deadline:
                break
            time.sleep(20)
        rc, out, _ = run_cmd(["systemctl", "is-system-running"], timeout=30)
        results["system_state"] = out.strip() or "unknown"
        for svc in baseline:
            if not SAFE_NAME.match(str(svc)):
                continue
            rc, out, _ = run_cmd(["systemctl", "is-active", str(svc)],
                                 timeout=30)
            state = out.strip()
            results["services"][svc] = state
            if state != "active":
                results["ok"] = False
                results.setdefault("errors", []).append(
                    "service %s is %s" % (svc, state))

    if not results["ok"]:
        raise RuntimeError("post-check failed: %s" %
                           "; ".join(results.get("errors", [])))
    return results


def verb_report_evidence(cfg, token, params):
    running, latest = collect_kernel()
    reboot, reason = check_reboot_required()
    return {
        "kernel_running": running,
        "kernel_latest": latest,
        "reboot_required": reboot,
        "reboot_reason": reason,
        "collected_at": datetime.now(timezone.utc).isoformat(),
    }


# ---------------------------------------------------------------------------
# Hardening scan (OpenSCAP)
# ---------------------------------------------------------------------------

HARDENING_DIR = os.path.join(STATE_DIR, "hardening")
SCAN_TIMEOUT = 45 * 60
_PROFILE_RE = re.compile(r"^xccdf_[A-Za-z0-9_.\-]{1,200}$")
_PRODUCT_RE = re.compile(r"^[a-z0-9]{2,20}$")
_SCAN_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
_SHA_RE = re.compile(r"^[0-9a-f]{64}$")
_TAILOR_RE = re.compile(r"^/api/v1/agent/hardening/tailoring/[A-Za-z0-9._-]{1,120}\.xml$")


def scanner_hint():
    """How to install the scanner on this OS, for the error message."""
    if shutil.which("dnf") or shutil.which("yum"):
        return "install it with: dnf install -y openscap-scanner (yum on Oracle Linux 7)"
    if shutil.which("apt-get"):
        return ("install it with: apt-get install -y openscap-scanner "
                "(libopenscap8 on Ubuntu 20.04 and 22.04; both are in the universe repository)")
    return "install the OpenSCAP scanner (oscap)"


def fetch_content(cfg, token, path, sha, keep=True):
    """Download a benchmark or tailoring file once, verified against its hash."""
    os.makedirs(HARDENING_DIR, mode=0o700, exist_ok=True)
    dest = os.path.join(HARDENING_DIR, sha + (".xml" if keep else ".tailoring.xml"))
    if os.path.exists(dest):
        with open(dest, "rb") as fh:
            if hashlib.sha256(fh.read()).hexdigest() == sha:
                return dest
    server = cfg["server"].rstrip("/")
    req = urllib.request.Request(server + path, method="GET")
    req.add_header("User-Agent", "patch-agent/%s" % AGENT_VERSION)
    req.add_header("Authorization", "Bearer " + token)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),
                                         urllib.request.HTTPSHandler(context=build_ssl_context(cfg)))
    try:
        with opener.open(req, timeout=300) as resp:
            data = resp.read()
    except urllib.error.HTTPError as e:
        raise RuntimeError("could not download hardening content: HTTP %s" % e.code)
    got = hashlib.sha256(data).hexdigest()
    if got != sha:
        raise RuntimeError("hardening content failed its integrity check (expected %s, got %s)" % (sha[:12], got[:12]))
    tmp = dest + ".part"
    with open(tmp, "wb") as fh:
        fh.write(data)
    os.replace(tmp, dest)
    for old in os.listdir(HARDENING_DIR):      # keep only the current release
        if keep and old.endswith(".xml") and not old.endswith(".tailoring.xml") and old != os.path.basename(dest):
            try:
                os.remove(os.path.join(HARDENING_DIR, old))
            except OSError:
                pass
    return dest


PROGRESS_EVERY = 10     # seconds between progress reports


def report_progress(cfg, token, scan_id, stage, done=None, total=None):
    """Tell PATCH-01 where the scan is. Never fatal: progress is a courtesy."""
    try:
        api_call(cfg, "POST", "/api/v1/agent/hardening/progress",
                 {"scan_id": scan_id, "stage": stage, "done": done, "total": total}, token, timeout=20)
    except Exception:  # noqa: BLE001
        pass


def run_oscap_with_progress(argv, timeout, on_rule):
    """Run oscap with --progress, calling on_rule() for each rule it finishes.

    With --progress, oscap prints one line per evaluated rule
    ("<rule id>:<result>"). Anything else it prints is kept for the error
    message. Python 3.6 compatible.
    """
    import threading
    # Its own process group, so the watchdog stops oscap and any helper
    # processes it started, which would otherwise hold the output open
    p = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                         universal_newlines=True, errors="replace", start_new_session=True)
    killed = {"yes": False}

    def kill():
        killed["yes"] = True
        try:
            os.killpg(p.pid, signal.SIGKILL)
        except OSError:
            pass
    dog = threading.Timer(timeout, kill)
    dog.daemon = True
    dog.start()
    other = []
    errbuf = []

    def drain():
        # Read at the same time as stdout: a full stderr pipe (64 KB) would stop oscap (1.8.5)
        for chunk in iter(lambda: p.stderr.read(8192), ""):
            errbuf.append(chunk)
            if len(errbuf) > 64:
                del errbuf[:-64]
    reader = threading.Thread(target=drain, daemon=True)
    reader.start()
    try:
        for line in p.stdout:
            if "_rule_" in line and ":" in line:
                on_rule()
            elif line.strip():
                other.append(line.rstrip())
                del other[:-20]
        rc = p.wait()
        reader.join(30)
        err = "".join(errbuf)
    finally:
        dog.cancel()
    if killed["yes"]:
        return 124, "\n".join(other), "timed out after %ss" % timeout
    return rc, "\n".join(other), err


SCE_MARK = b"open-scap.org/page/sce"


def _runs_scripts(path):
    """Whether OpenSCAP content uses the Script Check Engine (runs programs as root) (1.8.5)."""
    import bz2
    with open(path, "rb") as fh:
        head = fh.read(3)
    opener = bz2.open if head == b"BZh" else open
    tail = b""
    with opener(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            if SCE_MARK in (tail + chunk).lower():
                return True
            tail = chunk[-64:]
    return False


def verb_run_hardening_scan(cfg, token, params):
    """Scan this host against a benchmark profile and upload the result.

    Read-only: `oscap xccdf eval` checks settings and changes nothing. Runs
    at low CPU and disk priority. Every parameter from PATCH-01 is checked
    against a strict pattern before use, and oscap gets a fixed argv list.
    """
    scan_id = str(params.get("scan_id", ""))
    product = str(params.get("product", ""))
    profile = str(params.get("profile_id", ""))
    sha = str(params.get("content_sha256", ""))
    path = str(params.get("content_path", ""))
    tpath = str(params.get("tailoring_path") or "")
    tsha = str(params.get("tailoring_sha256") or "")
    if not (_SCAN_RE.match(scan_id) and _PRODUCT_RE.match(product) and _PROFILE_RE.match(profile)
            and _SHA_RE.match(sha) and path == "/api/v1/agent/hardening/content/" + product
            and (not tpath or (_TAILOR_RE.match(tpath) and _SHA_RE.match(tsha)))):
        raise RuntimeError("refusing hardening scan: parameters failed validation")
    oscap = shutil.which("oscap")
    if not oscap:
        raise RuntimeError("OpenSCAP scanner not installed; " + scanner_hint())
    rc, out, err = run_cmd([oscap, "--version"], timeout=30)
    version = (out.splitlines() or [""])[0].strip()[:200]
    try:
        total = max(0, int(params.get("rule_total") or 0)) or None
    except (TypeError, ValueError):
        total = None
    report_progress(cfg, token, scan_id, "downloading")
    ds = fetch_content(cfg, token, path, sha)

    work = os.path.join(HARDENING_DIR, "scan-" + scan_id)
    os.makedirs(work, mode=0o700, exist_ok=True)
    arf = os.path.join(work, "arf.xml")
    argv = [oscap, "xccdf", "eval", "--progress", "--profile", profile, "--results-arf", arf]
    if tpath:
        # A custom profile: the tailoring file selects exactly its checks
        tfile = fetch_content(cfg, token, tpath, tsha, keep=False)
        argv += ["--tailoring-file", tfile]
    argv.append(ds)
    for f in [ds] + ([tfile] if tpath else []):
        if _runs_scripts(f):
            raise RuntimeError("refusing hardening scan: the content contains script checks (SCE), "
                               "which would run programs on this server; only read-only checks are allowed")
    lowprio = []
    if shutil.which("nice"):
        lowprio += ["nice", "-n", "15"]
    if shutil.which("ionice"):
        lowprio += ["ionice", "-c", "3"]
    started = time.time()
    state = {"done": 0, "sent": 0.0}
    report_progress(cfg, token, scan_id, "scanning", 0, total)

    def on_rule():
        state["done"] += 1
        if time.time() - state["sent"] >= PROGRESS_EVERY:
            state["sent"] = time.time()
            report_progress(cfg, token, scan_id, "scanning", state["done"], total)

    rc, out, err = run_oscap_with_progress(lowprio + argv, SCAN_TIMEOUT, on_rule)
    # 0: every rule passed, 2: some failed. Both are a completed scan.
    if rc not in (0, 2) or not os.path.exists(arf):
        tail = (err or out).strip().splitlines()[-5:]
        raise RuntimeError("oscap exited %s: %s" % (rc, " | ".join(tail)[:1500]))
    report_progress(cfg, token, scan_id, "uploading", state["done"], total)
    with open(arf, "rb") as fh:
        packed = gzip.compress(fh.read(), 6)
    api_call(cfg, "POST", "/api/v1/agent/hardening/result",
             {"scan_id": scan_id, "arf_gz_b64": base64.b64encode(packed).decode(),
              "oscap_version": version, "exit_code": rc}, token, timeout=300)
    shutil.rmtree(work, ignore_errors=True)
    return {"scan_id": scan_id, "exit_code": rc, "seconds": int(time.time() - started),
            "result_kb": len(packed) // 1024, "oscap": version}


def verb_cancel_job(cfg, token, params):
    return {"acknowledged": True}


# ---------------------------------------------------------------------------
# Updates of this agent from PATCH-01
# ---------------------------------------------------------------------------

UPDATE_DIR = os.path.join(STATE_DIR, "update")
UPDATE_MARKER = os.path.join(UPDATE_DIR, "pending.json")
# Written by the new version after each check-in: proves it starts and reaches PATCH-01
UPDATE_CHECKIN = os.path.join(UPDATE_DIR, "checked-in.json")
UPDATE_CONFIRM_MINUTES = 10
# The previous version stops a new one that hangs before ever checking in, this long after the swap
UPDATE_HARD_MINUTES = 30
RUN_LOCK = os.path.join(STATE_DIR, "run.lock")
# A persistent check (survives a restart in the window), removed once the update is settled
CHECK_UNIT = "patch-agent-update-check"
UNIT_DIR = "/etc/systemd/system"
AGENT_TIMER = os.path.join(UNIT_DIR, "patch-agent.timer")
UPDATE_DOWNLOAD = "/api/v1/agent/update-file"
_VERSION_LINE = re.compile(r'^AGENT_VERSION = "(\d{1,4}\.\d{1,4}\.\d{1,4})"\s*$', re.M)
UPDATED = {"done": False}

# ---------------------------------------------------------------------------
# Release signatures (agent 1.8.3+)
#
# Agent releases can be signed with an OFFLINE key that never lives on PATCH-01
# (patch01/scripts/sign-agent-release.sh, on the operator's offline machine):
# RSA (2048+ bits), PKCS#1 v1.5, SHA-256, over the exact bytes of the release
# file. The public key is pinned here by setup-agent.sh / install-agent.sh
# (--release-key). Once it is pinned, update_agent refuses any file whose
# signature does not verify, whatever PATCH-01 says; a compromised PATCH-01
# can then no longer put its own agent on the fleet. Without a pinned key the
# agent keeps the earlier behaviour (SHA-256 from PATCH-01's job only), and
# says so in its log, in the update's checks and in each check-in.
#
# The check is pure Python (standard library), so nothing extra is needed on
# RHEL 8/9 or Ubuntu. Verification uses only the public key.
# ---------------------------------------------------------------------------
RELEASE_KEY_FILE = os.path.join(CONFIG_DIR, "release-signing.pub")
_RSA_OID = bytes.fromhex("2a864886f70d010101")                 # 1.2.840.113549.1.1.1 rsaEncryption
_SHA256_DIGEST_INFO = bytes.fromhex("3031300d060960864801650304020105000420")


def _der(buf, pos, tag):
    """One DER element of the given tag at pos -> (value start, value end)."""
    if pos + 2 > len(buf) or buf[pos] != tag:
        raise ValueError("unexpected DER element")
    n = buf[pos + 1]
    pos += 2
    if n & 0x80:
        k = n & 0x7F
        if not 1 <= k <= 4 or pos + k > len(buf):
            raise ValueError("bad DER length")
        n = int.from_bytes(buf[pos:pos + k], "big")
        pos += k
    if pos + n > len(buf):
        raise ValueError("truncated DER")
    return pos, pos + n


def parse_release_key(pem):
    """An RSA public key in PEM (SubjectPublicKeyInfo, as openssl pkey -pubout writes it)
    -> (n, e, fingerprint). The fingerprint is the SHA-256 of the DER key, as
    `openssl pkey -pubin -in KEY -outform DER | sha256sum` prints it."""
    if isinstance(pem, bytes):
        pem = pem.decode("ascii", "replace")
    m = re.search(r"-----BEGIN PUBLIC KEY-----([A-Za-z0-9+/=\s]+)-----END PUBLIC KEY-----", pem)
    if not m:
        raise ValueError("not a PEM public key (-----BEGIN PUBLIC KEY-----)")
    der = base64.b64decode("".join(m.group(1).split()), validate=True)
    s, e_ = _der(der, 0, 0x30)
    if e_ != len(der):
        raise ValueError("trailing data after the key")
    a, a_end = _der(der, s, 0x30)
    o, o_end = _der(der, a, 0x06)
    if der[o:o_end] != _RSA_OID:
        raise ValueError("not an RSA key")
    b, b_end = _der(der, a_end, 0x03)
    if b >= b_end or der[b] != 0:
        raise ValueError("bad key bit string")
    r, r_end = _der(der, b + 1, 0x30)
    ns, ne = _der(der, r, 0x02)
    es, ee = _der(der, ne, 0x02)
    n, e = int.from_bytes(der[ns:ne], "big"), int.from_bytes(der[es:ee], "big")
    if n.bit_length() < 2048:
        raise ValueError("the key has %d bits; at least 2048 are needed" % n.bit_length())
    if e < 3 or e % 2 == 0:
        raise ValueError("bad public exponent")
    return n, e, hashlib.sha256(der).hexdigest()


def rsa_verify_sha256(n, e, data, sig):
    """RSASSA-PKCS1-v1_5 with SHA-256: True only for an exact, well-formed signature."""
    k = (n.bit_length() + 7) // 8
    if not isinstance(sig, (bytes, bytearray)) or len(sig) != k:
        return False
    s = int.from_bytes(sig, "big")
    if s >= n:
        return False
    em = pow(s, e, n).to_bytes(k, "big")
    t = _SHA256_DIGEST_INFO + hashlib.sha256(data).digest()
    if k < len(t) + 11:
        return False
    want = b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t
    import hmac
    return hmac.compare_digest(em, want)


def release_key_state():
    """("none", None, "") with no key pinned; ("pinned", (n, e), fingerprint); or
    ("invalid", None, why) when a key file is there but cannot be trusted or read:
    then updates are refused (a key was meant to be pinned)."""
    try:
        st = os.lstat(RELEASE_KEY_FILE)
    except FileNotFoundError:
        return "none", None, ""
    except OSError as e:
        return "invalid", None, str(e)
    try:
        if stat_islink(st):
            raise ValueError("it is a link")
        for p in (RELEASE_KEY_FILE, os.path.dirname(RELEASE_KEY_FILE)):
            s2 = os.stat(p)
            if s2.st_uid != 0 or s2.st_mode & 0o022:
                raise ValueError("%s is not owned by root alone, or others can write to it" % p)
        with open(RELEASE_KEY_FILE, "rb") as fh:
            n, e, fp = parse_release_key(fh.read(16384))
        return "pinned", (n, e), fp
    except (OSError, ValueError, TypeError) as e:   # binascii.Error is a ValueError
        return "invalid", None, str(e)


def verify_release(data, sig_b64):
    """The update check: (status, note). Raises when a pinned key refuses the file."""
    state, key, fp = release_key_state()
    if state == "invalid":
        raise RuntimeError("the release-signing key pinned on this server (%s) cannot be used (%s): agent "
                           "updates are refused until it is fixed (setup-agent.sh --release-key FILE); "
                           "nothing was changed" % (RELEASE_KEY_FILE, fp))
    if state == "none":
        log("agent update WITHOUT a release signature check: no release-signing key is pinned on this server "
            "(%s), so the new agent is trusted on PATCH-01's SHA-256 alone. Pin the offline key with "
            "setup-agent.sh --release-key FILE to require signed releases." % RELEASE_KEY_FILE, "WARN")
        return "unsigned", "NOT signature-checked: no release-signing key pinned on this server"
    if not sig_b64:
        raise RuntimeError("this server requires agent releases signed with the release key (%s...) and the "
                           "job carries no signature: sign the release offline (sign-agent-release.sh) and "
                           "publish it with its .sig (phase12-agents.sh); nothing was changed" % fp[:16])
    try:
        sig = base64.b64decode(str(sig_b64), validate=True)
    except (ValueError, TypeError):
        raise RuntimeError("the release signature in the job is not base64; nothing was changed")
    if not rsa_verify_sha256(key[0], key[1], data, sig):
        raise RuntimeError("the new agent's release signature does NOT verify with the key pinned on this "
                           "server (%s...): refused; nothing was changed" % fp[:16])
    return "verified", "release signature verified (key %s...)" % fp[:16]


def _vt(v):
    m = re.match(r"^(\d{1,4})\.(\d{1,4})\.(\d{1,4})", str(v or ""))
    return tuple(int(x) for x in m.groups()) if m else None


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def _self_path():
    return os.path.abspath(__file__)


def _safe_root_path(path, what):
    """Owned by root and writable by nobody else, the file and its folder: a
    file someone else could change must never be run as root."""
    st = os.lstat(path)
    if stat_islink(st):
        raise RuntimeError("%s (%s) is a link: refused" % (what, path))
    for p in (path, os.path.dirname(path)):
        s2 = os.stat(p)
        if s2.st_uid != 0 or s2.st_mode & 0o022:
            raise RuntimeError("%s is not owned by root alone, or others can write to it: refused" % p)


def stat_islink(st):
    import stat as _stat
    return _stat.S_ISLNK(st.st_mode)


def _write_file(path, data, mode):
    """Written beside it and swapped in one step; never through a link."""
    tmp = path + ".new"
    try:
        os.unlink(tmp)
    except FileNotFoundError:
        pass
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), mode)
    with os.fdopen(fd, "wb") as fh:
        fh.write(data)
        fh.flush()
        os.fsync(fh.fileno())
    os.chmod(tmp, mode)
    os.replace(tmp, path)


def _read_marker():
    try:
        with open(UPDATE_MARKER) as fh:
            m = json.load(fh)
        if isinstance(m, dict) and m.get("to") and m.get("sha_new"):
            return m
    except (OSError, ValueError):
        pass
    return None


def _marker_age_minutes(m):
    try:
        at = datetime.strptime(m["at"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc) - at).total_seconds() / 60.0
    except (KeyError, ValueError, TypeError):
        return 1e6


def _remove_marker():
    try:
        os.unlink(UPDATE_MARKER)
    except FileNotFoundError:
        pass


def _systemctl(*args):
    try:
        return subprocess.run(["systemctl"] + list(args), stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL, timeout=60).returncode
    except Exception:  # noqa: BLE001
        return 1


def _stop_check():
    """Remove the update check (persistent timer and service): the update is settled."""
    _systemctl("disable", "--now", CHECK_UNIT + ".timer")
    removed = False
    for ext in (".timer", ".service"):
        try:
            os.unlink(os.path.join(UNIT_DIR, CHECK_UNIT + ext))
            removed = True
        except FileNotFoundError:
            pass
    if removed:
        _systemctl("daemon-reload")


def _arm_check(prev):
    """The previous version checks the new one every 5 minutes, also after a restart."""
    svc = ("[Unit]\nDescription=PATCH-01 agent update check (the previous version puts itself back "
           "if the new one does not work)\n\n[Service]\nType=oneshot\nTimeoutStartSec=10min\n"
           "ExecStart=%s update-check\n" % prev)
    tmr = ("[Unit]\nDescription=PATCH-01 agent update check\n\n[Timer]\nOnActiveSec=5min\nOnBootSec=5min\n"
           "OnUnitActiveSec=5min\nAccuracySec=30s\n\n[Install]\nWantedBy=timers.target\n")
    _write_file(os.path.join(UNIT_DIR, CHECK_UNIT + ".service"), svc.encode(), 0o644)
    _write_file(os.path.join(UNIT_DIR, CHECK_UNIT + ".timer"), tmr.encode(), 0o644)
    if _systemctl("daemon-reload") != 0 or _systemctl("enable", "--now", CHECK_UNIT + ".timer") != 0:
        raise RuntimeError("systemd could not start the update check timer")


def _agent_interval_minutes():
    """How often the agent's timer runs it (install-agent.sh --interval), 5 by default."""
    try:
        with open(AGENT_TIMER) as fh:
            m = re.search(r"^OnUnitActiveSec=(\d{1,4})min\s*$", fh.read(), re.M)
        return max(1, int(m.group(1))) if m else 5
    except (OSError, ValueError):
        return 5


def _take_run_lock(wait_seconds=0):
    """One run at a time (the timer's run, a run by hand, the update check). The open
    file is the lock: keep it until the work is done. None when another still holds
    it after wait_seconds."""
    os.makedirs(STATE_DIR, exist_ok=True)
    fd = os.open(RUN_LOCK, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
    until = time.time() + wait_seconds
    while True:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return fd
        except OSError:
            if time.time() >= until:
                os.close(fd)
                return None
            time.sleep(2)


def _write_checkin_stamp():
    try:
        m = _read_marker()
        if m and m.get("to") == AGENT_VERSION:
            _write_file(UPDATE_CHECKIN, json.dumps({"version": AGENT_VERSION, "at": datetime.now(timezone.utc)
                                                     .strftime("%Y-%m-%dT%H:%M:%SZ")}).encode(), 0o600)
    except Exception:  # noqa: BLE001 - a courtesy for the update check
        pass


def _new_version_checked_in(m):
    try:
        with open(UPDATE_CHECKIN) as fh:
            c = json.load(fh)
        return c.get("version") == m.get("to") and _marker_age_minutes(c) < _marker_age_minutes(m)
    except (OSError, ValueError):
        return False


def _download_update(cfg, token, size):
    server = cfg["server"].rstrip("/")
    if not server.startswith("https://"):
        raise RuntimeError("PATCH-01's address is not https: refused")
    req = urllib.request.Request(server + UPDATE_DOWNLOAD, method="GET")
    req.add_header("User-Agent", "patch-agent/%s" % AGENT_VERSION)
    req.add_header("Authorization", "Bearer " + token)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),
                                         urllib.request.HTTPSHandler(context=build_ssl_context(cfg)))
    try:
        with opener.open(req, timeout=120) as resp:
            data = resp.read(size + 1)
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = e.read().decode()[:300]
        except Exception:
            pass
        raise RuntimeError("could not download the new agent: HTTP %s %s" % (e.code, detail))
    except urllib.error.URLError as e:
        raise RuntimeError("could not download the new agent: %s" % e.reason)
    if len(data) != size:
        raise RuntimeError("received %d of %d bytes of the new agent; nothing was changed" % (len(data), size))
    return data


def _test_run(path, interpreter, version):
    """Run the new file with the interpreter the timer will use, with "check" only."""
    env = {k: v for k, v in os.environ.items() if k.lower() not in ("http_proxy", "https_proxy")}
    try:
        p = subprocess.run(interpreter + [path, "check"], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=120, env=env)
    except subprocess.TimeoutExpired:
        raise RuntimeError("the new agent's test run did not finish within 2 minutes; nothing was changed")
    out = p.stdout.decode("utf-8", "replace")
    want = "PATCH-01 agent %s ready" % version
    if p.returncode != 0 or want not in out:
        why = " ".join((p.stderr.decode("utf-8", "replace") + " " + out).split())[:400]
        raise RuntimeError("the new agent's test run failed (exit %s): %s; nothing was changed" % (p.returncode, why))
    return want


def verb_update_agent(cfg, token, params):
    plat, ver = str(params.get("platform") or ""), str(params.get("version") or "")
    sha, dl = str(params.get("sha256") or "").lower(), str(params.get("download") or "")
    try:
        size = int(params.get("size") or 0)
    except (TypeError, ValueError):
        size = 0
    if plat != "linux":
        raise RuntimeError("this update is for %s agents, not Linux" % plat)
    if not re.match(r"^\d{1,4}\.\d{1,4}\.\d{1,4}$", ver):
        raise RuntimeError("the version %r was refused" % ver)
    if not re.match(r"^[0-9a-f]{64}$", sha):
        raise RuntimeError("the job has no valid SHA-256 for the new agent")
    if not 1024 <= size <= 4 * 2 ** 20:
        raise RuntimeError("the new agent's size (%d bytes) was refused" % size)
    have, want = _vt(AGENT_VERSION), _vt(ver)
    if params.get("probe"):
        # PATCH-01's check after an update: is the version it asked for the one running? Nothing is downloaded.
        if want == have:
            return {"nothing_to_do": True, "probe": True, "version": AGENT_VERSION,
                    "message": "agent %s is running and answers jobs" % AGENT_VERSION}
        raise RuntimeError("this is agent %s, not %s: the update was put back" % (AGENT_VERSION, ver))
    if dl != UPDATE_DOWNLOAD:
        raise RuntimeError("the download address was refused")
    if want == have:
        return {"nothing_to_do": True, "version": AGENT_VERSION, "message": "already runs agent %s" % AGENT_VERSION}
    if want < have:
        raise RuntimeError("this agent (%s) is newer than %s: agents are never downgraded from PATCH-01" % (AGENT_VERSION, ver))
    if str(cfg.get("verify_tls", "true")).lower() in ("false", "0", "no"):
        raise RuntimeError("this agent does not verify PATCH-01's certificate (verify_tls=false), so a new agent "
                           "could come from anyone on the network: refused. Run setup-agent.sh with PATCH-01's CA "
                           "(--ca) first, then update.")
    me = _self_path()
    _safe_root_path(me, "the running agent")
    old = _read_marker()
    if old:
        if _marker_age_minutes(old) < 60:
            raise RuntimeError("an update to %s is still waiting to be confirmed; try again later" % old.get("to"))
        _remove_marker()
    checks = []

    # 1. The file, over the verified connection, exactly the one the job names
    data = _download_update(cfg, token, size)
    if hashlib.sha256(data).hexdigest() != sha:
        raise RuntimeError("the downloaded agent's SHA-256 does not match the job; nothing was changed")
    checks.append("SHA-256 matches")
    # The offline release key, when pinned here, decides; PATCH-01's word alone does not
    sig_status, sig_note = verify_release(data, params.get("signature"))
    checks.append(sig_note)
    if not data.startswith(b"#!"):
        raise RuntimeError("the downloaded file is not the Linux agent; nothing was changed")
    # The interpreter this server's agent already uses (RHEL 8: platform-python)
    with open(me, "rb") as fh:
        first = fh.readline().rstrip(b"\r\n")
    if not first.startswith(b"#!"):
        first = ("#!" + sys.executable).encode()
    new = first + b"\n" + data.split(b"\n", 1)[1]
    import shlex
    interpreter = shlex.split(first[2:].decode("utf-8", "replace"))
    if not interpreter or not os.path.isabs(interpreter[0]) or not os.path.exists(interpreter[0]):
        interpreter = [sys.executable]
    try:
        text = new.decode("utf-8")
    except UnicodeDecodeError:
        raise RuntimeError("the new agent is not UTF-8 text; nothing was changed")
    m = _VERSION_LINE.search(text)
    if not m or m.group(1) != ver:
        raise RuntimeError("the file is not agent %s; nothing was changed" % ver)
    checks.append("it is agent %s" % ver)
    try:
        compile(text, "patch-agent-%s" % ver, "exec")
    except SyntaxError as e:
        raise RuntimeError("the new agent does not compile with %s (line %s: %s); nothing was changed"
                           % (sys.version.split()[0], e.lineno, e.msg))
    checks.append("compiles with Python %s" % sys.version.split()[0])

    # 2. Staged in a root-only folder and test-run
    os.makedirs(UPDATE_DIR, mode=0o700, exist_ok=True)
    if stat_islink(os.lstat(UPDATE_DIR)):
        raise RuntimeError("%s is a link: refused" % UPDATE_DIR)
    os.chmod(UPDATE_DIR, 0o700)
    for f in os.listdir(UPDATE_DIR):
        if f.startswith("patch-agent-"):
            try:
                os.unlink(os.path.join(UPDATE_DIR, f))
            except OSError:
                pass
    staged = os.path.join(UPDATE_DIR, "patch-agent-%s" % ver)
    _write_file(staged, new, 0o700)
    new_sha = hashlib.sha256(new).hexdigest()
    if _sha256_file(staged) != new_sha:
        raise RuntimeError("the staged file changed; nothing was changed")
    checks.append("test run: " + _test_run(staged, interpreter, ver))

    # 3. Keep this version, arm the check, swap
    prev = me + ".prev"
    with open(me, "rb") as fh:
        cur = fh.read()
    prev_sha = hashlib.sha256(cur).hexdigest()
    _write_file(prev, cur, 0o755)
    if _sha256_file(prev) != prev_sha:
        raise RuntimeError("could not keep a copy of the running agent; nothing was changed")
    # The new version must have run once (the timer's interval) and read its commands within this
    window = max(UPDATE_CONFIRM_MINUTES, _agent_interval_minutes() + 5)
    try:
        os.unlink(UPDATE_CHECKIN)
    except FileNotFoundError:
        pass
    marker = {"from": AGENT_VERSION, "to": ver, "sha_new": new_sha, "sha_prev": prev_sha,
              "confirm_minutes": window, "at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
    _write_file(UPDATE_MARKER, json.dumps(marker).encode(), 0o600)
    try:
        _arm_check(prev)
        _write_file(me, new, 0o755)
        if _sha256_file(me) != new_sha:
            raise RuntimeError("after the swap, %s is not the expected file" % me)
    except Exception as e:
        try:
            if _sha256_file(me) != prev_sha:
                _write_file(me, cur, 0o755)
        except Exception:
            pass
        _remove_marker()
        _stop_check()
        raise RuntimeError("the swap failed and the running version was kept: %s" % e)
    try:
        os.unlink(staged)
    except OSError:
        pass
    checks.append("swapped; previous version kept")
    log("agent updated %s -> %s (%s); the next run is the new version, which must check in and answer "
        "PATCH-01's check within %d minutes or this version is put back" % (AGENT_VERSION, ver, "; ".join(checks), window))
    UPDATED["done"] = True
    return {"from": AGENT_VERSION, "to": ver, "checks": checks, "confirm_minutes": window,
            "release_signature": sig_status}


def confirm_update():
    """A new version that has answered PATCH-01's check job (and reported the
    answer) runs jobs: it is confirmed, and the previous version stops watching.
    Does nothing when nothing is pending."""
    try:
        m = _read_marker()
        if not m or m.get("to") != AGENT_VERSION:
            return
        os.unlink(UPDATE_MARKER)
        try:
            os.unlink(UPDATE_CHECKIN)
        except FileNotFoundError:
            pass
        _stop_check()
        log("agent %s answered PATCH-01's check after the update from %s: update confirmed (the previous "
            "version is kept as %s.prev)" % (AGENT_VERSION, m.get("from"), _self_path()))
    except Exception as e:  # noqa: BLE001 - never breaks a run; tried again next run
        log("confirming the agent update failed (tried again next run): %s" % e, "WARN")


def cmd_update_check(cfg, args):
    """Run by the previous version (<path>.prev) from its systemd timer."""
    me = _self_path()
    target = me[:-len(".prev")] if me.endswith(".prev") else None
    m = _read_marker()
    if not m or not target:
        _stop_check()
        return 0
    try:
        cur = _sha256_file(target)
    except OSError:
        cur = None
    if cur != m.get("sha_new"):
        log("update check: %s is not the file the update to %s put in place; nothing to do" % (target, m.get("to")))
        _remove_marker()
        _stop_check()
        return 0
    age = _marker_age_minutes(m)
    window = int(m.get("confirm_minutes") or UPDATE_CONFIRM_MINUTES)
    if age < window:
        return 0
    lock = _take_run_lock()
    if lock is None:
        # A run holds the agent. The new version's first run answers PATCH-01's check within seconds,
        # and no other job is sent to it until then: still unconfirmed this long after the swap, it
        # hangs. Stop it, then put the previous version back.
        if age < window + UPDATE_HARD_MINUTES - UPDATE_CONFIRM_MINUTES:
            log("update check: an agent run is in progress; checking again in 5 minutes")
            return 0
        log("update check: agent %s is still unconfirmed %d minutes after the update and holds the agent: "
            "stopping it" % (m.get("to"), age), "ERROR")
        _systemctl("stop", "patch-agent.service")
        lock = _take_run_lock(wait_seconds=120)
        if lock is None:
            log("update check: the agent run could not be stopped (a run started by hand?); trying again in 5 minutes", "ERROR")
            return 0
    elif _new_version_checked_in(m) and age < window + UPDATE_HARD_MINUTES - UPDATE_CONFIRM_MINUTES:
        # It starts and reaches PATCH-01, but PATCH-01's check job has not reached it yet (PATCH-01 busy):
        # it gets until the hard limit, not just the window
        os.close(lock)
        log("update check: agent %s checks in but has not had PATCH-01's check job yet; waiting" % m.get("to"))
        return 0
    try:
        m = _read_marker()
        if not m:
            _stop_check()
            return 0
        try:
            cur = _sha256_file(target)
        except OSError:
            cur = None
        if cur != m.get("sha_new"):
            _remove_marker()
            _stop_check()
            return 0
        with open(me, "rb") as fh:
            back = fh.read()
        if hashlib.sha256(back).hexdigest() != m.get("sha_prev"):
            log("update check: agent %s has not been confirmed, but the kept copy of %s has changed, so it was "
                "not put back. Reinstall the agent (setup-agent.sh)." % (m.get("to"), m.get("from")), "ERROR")
        else:
            _write_file(target, back, 0o755)
            why = "checked in but did not answer PATCH-01's check" if _new_version_checked_in(m) else "did not check in"
            log("agent %s %s within %d minutes of the update: agent %s was put back"
                % (m.get("to"), why, window, m.get("from")), "ERROR")
        _remove_marker()
        try:
            os.unlink(UPDATE_CHECKIN)
        except FileNotFoundError:
            pass
    finally:
        os.close(lock)
    _stop_check()
    return 0


def cmd_release_key(cfg, args):
    """release-key [FILE]: print the fingerprint of FILE (exit 1 if it is not a usable key),
    or the state of the key pinned on this server."""
    if args.file:
        try:
            with open(args.file, "rb") as fh:
                n, e, fp = parse_release_key(fh.read(16384))
        except (OSError, ValueError, TypeError) as e:
            print("not a usable release key: %s" % e)
            return 1
        print("RSA %d bits, SHA-256 %s" % (n.bit_length(), fp))
        return 0
    state, key, fp = release_key_state()
    if state == "pinned":
        print("pinned: %s (RSA %d bits, SHA-256 %s): agent updates must be signed with it"
              % (RELEASE_KEY_FILE, key[0].bit_length(), fp))
    elif state == "none":
        print("none: no release-signing key pinned (%s); agent updates are checked by PATCH-01's SHA-256 only"
              % RELEASE_KEY_FILE)
    else:
        print("invalid: %s cannot be used (%s); agent updates are refused" % (RELEASE_KEY_FILE, fp))
    return 0 if state != "invalid" else 1


def cmd_check(cfg, args):
    if not str(cfg.get("server", "")).startswith("https://"):
        raise RuntimeError("PATCH-01's address in %s is not https" % CONFIG_FILE)
    if not load_token():
        raise RuntimeError("not enrolled (no token)")
    print("PATCH-01 agent %s ready" % AGENT_VERSION, flush=True)
    return 0


# The closed set. A verb not in this table is refused.
VERB_HANDLERS = {
    "collect_inventory": verb_collect_inventory,
    "run_hardening_scan": verb_run_hardening_scan,
    "run_precheck": verb_run_precheck,
    "download_packages": verb_download_packages,
    "install_packages": verb_install_packages,
    "reboot_host": verb_reboot_host,
    "run_postcheck": verb_run_postcheck,
    "report_evidence": verb_report_evidence,
    "cancel_job": verb_cancel_job,
    "update_agent": verb_update_agent,
}


# ---------------------------------------------------------------------------
# Operations
# ---------------------------------------------------------------------------

def build_inventory():
    started = time.time()
    osr = read_os_release()
    running, latest = collect_kernel()
    reboot, reason = check_reboot_required()
    pkgs = collect_packages()
    return {
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "kernel_running": running,
        "kernel_latest": latest,
        "reboot_required": reboot,
        "reboot_reason": reason,
        "os_version": osr.get("VERSION_ID", ""),
        "agent_version": AGENT_VERSION,
        "duration_ms": int((time.time() - started) * 1000),
        "boot_time": boot_time_iso(),
        "hardware_uuid": hardware_uuid(),
        "packages": pkgs,
        "updates": collect_updates(pkgs),
    }


def cmd_enroll(cfg, args):
    if load_token() and not args.force:
        log("Already enrolled. Use --force to re-enroll.")
        return 0
    # From the environment by preference: a --token argument is visible to every local user in ps
    token = os.environ.pop("PATCH_ENROLL_TOKEN", "") or args.token
    if not token:
        die("an enrolment token is required: PATCH_ENROLL_TOKEN=... patch-agent enroll (or --token)")

    osr = read_os_release()
    pm = detect_pkg_manager()
    if not pm:
        die("No supported package manager (dnf, yum or apt) found")

    hostname = platform.node().split(".")[0].lower()
    fqdn = platform.node().lower()

    body = {
        "enrollment_token": token,
        "machine_id": machine_id(),
        "hostname": hostname,
        "fqdn": fqdn if fqdn != hostname else None,
        "os_id": osr.get("ID", "unknown"),
        "os_version": osr.get("VERSION_ID", "0"),
        "arch": platform.machine(),
        "pkg_manager": pm,
        "agent_version": AGENT_VERSION,
    }
    hw = hardware_uuid()
    if hw:
        # PATCH-01 accepts a re-enrolment of an active server only from the same machine
        body["hardware_uuid"] = hw

    log("enrolling %s (%s %s, %s) with %s" %
        (hostname, body["os_id"], body["os_version"], pm, cfg["server"]))
    resp = api_call(cfg, "POST", "/api/v1/agent/enroll", body)
    save_token(resp["agent_token"])
    log("enrolled: host_id=%s token stored in %s" %
        (resp["host_id"], TOKEN_FILE))
    return 0


def cmd_inventory(cfg, args):
    token = load_token() or die("Not enrolled. Run: patch-agent enroll --token ...")
    data = build_inventory()
    log("collected %d packages in %dms" %
        (len(data["packages"]), data["duration_ms"]))
    resp = api_call(cfg, "POST", "/api/v1/agent/inventory", data, token)
    log("inventory accepted: %s" % json.dumps(resp))
    return 0


def cmd_checkin(cfg, args):
    token = load_token() or die("Not enrolled.")
    running, _ = collect_kernel()
    reboot, _ = check_reboot_required()
    resp = api_call(cfg, "POST", "/api/v1/agent/checkin", {
        "agent_version": AGENT_VERSION,
        "kernel_running": running,
        "reboot_required": reboot,
        "boot_time": boot_time_iso(),
        "hardware_uuid": hardware_uuid(),
        # Agent 1.8.3+: whether updates must carry the offline release signature (pinned/none/invalid)
        "release_key": release_key_state()[0],
        # 1.8.5: "patch-agent checkin" by hand (or setup-agent.sh) during a job is not a new run;
        # PATCH-01 would otherwise take it as "the run ended without reporting"
        "manual": getattr(args, "command", None) == "checkin",
    }, token)
    log("checkin ok (want_inventory=%s)" % resp.get("want_inventory"))
    return resp


def cmd_run(cfg, args):
    """Check in, send inventory if asked, then execute queued commands."""
    token = load_token() or die("Not enrolled.")
    lock = _take_run_lock()
    if lock is None:
        log("previous run still busy; skipping")
        return 0
    try:
        return _run_once(cfg, args, token)
    except Exception as e:
        log("run failed: %s" % e, "ERROR")
        raise
    finally:
        send_log_tail(cfg, token)
        os.close(lock)


def _run_once(cfg, args, token):

    resp = cmd_checkin(cfg, args)
    _write_checkin_stamp()
    pending = _read_marker()
    if pending and pending.get("to") == AGENT_VERSION:
        log("this version is waiting to be confirmed: no inventory in this run")
    elif resp.get("want_inventory"):
        log("server requested inventory")
        try:
            cmd_inventory(cfg, args)
        except Exception as e:
            log("inventory failed: %s" % e, "ERROR")

    # After finishing commands, ask again at once: PATCH-01 queues the next
    # step of a patch job as soon as the previous one reports, so this runs a
    # whole job in one pass instead of one step per check-in.
    for rnd in range(6):
        cmds = api_call(cfg, "GET", "/api/v1/agent/commands", None, token)
        if not cmds:
            if rnd == 0:
                log("no pending commands")
            return 0
        rebooting = _run_commands(cfg, token, cmds)
        if UPDATED["done"]:
            log("this file was replaced by the update: the next run is the new version")
            return 0
        if rebooting:
            return 0            # restarting: nothing more is asked for on the way down
        time.sleep(15)          # give the server a moment to queue the next step
    return 0


def _run_commands(cfg, token, cmds):
    log("%d command(s) claimed" % len(cmds))
    # PATCH-01's check job after an update is answered first: nothing in the batch may hold it up
    cmds = sorted(cmds, key=lambda c: 0 if (c.get("verb") == "update_agent" and (c.get("params") or {}).get("probe")) else 1)
    for c in cmds:
        verb = c.get("verb")
        cid = c.get("id")
        params = c.get("params") or {}
        handler = VERB_HANDLERS.get(verb)
        if UPDATED["done"]:
            # This file was replaced a moment ago: the rest of this batch is left to the new version's next run
            post_result(cfg, token, cid, verb, {"ok": False, "result": {"deferred": True},
                                                "message": "not run: the agent was replaced by an update a moment ago; run it again"})
            continue

        if handler is None:
            # An unknown verb is refused, not guessed at. This is what keeps
            # the instruction set closed even if the server changes.
            log("refusing unknown verb %r" % verb, "ERROR")
            try:
                api_call(cfg, "POST",
                         "/api/v1/agent/commands/%s/result" % cid,
                         {"ok": False, "result": {},
                          "message": "unsupported verb %r; agent version %s"
                                     % (verb, AGENT_VERSION)},
                         token)
            except Exception as e:
                log("could not report refusal: %s" % e, "ERROR")
            continue

        log("executing %s" % verb)
        try:
            result = handler(cfg, token, params)
            ok, message = True, None
        except Exception as e:
            result = getattr(e, "result", None)
            result, ok, message = (result if isinstance(result, dict) else {}), False, str(e)[:4000]
            log("%s failed: %s" % (verb, message), "ERROR")

        if post_result(cfg, token, cid, verb, {"ok": ok, "result": result, "message": message}):
            log("%s reported (ok=%s)" % (verb, ok))
            # PATCH-01's check job after an update: answered and reported, so this version runs jobs
            if ok and verb == "update_agent" and isinstance(result, dict) and result.get("probe"):
                confirm_update()
        send_log_tail(cfg, token)
        # A reboot ends this run: nothing after it should start on the way down. The rest of the
        # batch goes back to PATCH-01's queue (not left claimed), for after the restart.
        if verb == "reboot_host" and ok:
            log("reboot scheduled; stopping here")
            rest = cmds[cmds.index(c) + 1:]
            for r in rest:
                post_result(cfg, token, r.get("id"), r.get("verb"), {"ok": False, "result": {"deferred": True},
                                                                     "message": "not run: the server is restarting; it runs after the restart"})
            return True
    return False


def cmd_facts(cfg, args):
    """Print what would be reported, without contacting the server."""
    data = build_inventory()
    pkgs = data.pop("packages")
    print(json.dumps(data, indent=2))
    print("packages: %d" % len(pkgs))
    for p in pkgs[:10]:
        print("  %s %s %s" % (p["name"], p["version"], p["arch"]))
    if len(pkgs) > 10:
        print("  ... and %d more" % (len(pkgs) - 10))
    print("\nmachine_id: %s" % machine_id())
    print("pkg_manager: %s" % detect_pkg_manager())
    return 0


def main():
    ap = argparse.ArgumentParser(description="PATCH-01 agent")
    ap.add_argument("--server", help="override the configured server URL")
    ap.add_argument("--insecure", action="store_true",
                    help="skip TLS verification (self-signed placeholder only)")
    # required=True as a keyword is Python 3.7+. RHEL 8's platform-python is
    # 3.6 and raises TypeError on it, so set the attribute instead.
    sub = ap.add_subparsers(dest="command")
    sub.required = True

    p = sub.add_parser("enroll")
    p.add_argument("--token", required=False, help="enrollment token")
    p.add_argument("--force", action="store_true")

    sub.add_parser("checkin")
    sub.add_parser("inventory")
    sub.add_parser("run")
    sub.add_parser("facts")
    sub.add_parser("check")
    sub.add_parser("update-check")
    p = sub.add_parser("release-key", help="show the pinned release-signing key, or check a key file")
    p.add_argument("file", nargs="?", help="a PEM public key to check (setup-agent.sh uses this)")

    args = ap.parse_args()
    if args.command == "release-key":
        return cmd_release_key(None, args)

    cfg = load_config()
    if args.server:
        cfg["server"] = args.server
    if args.insecure:
        cfg["verify_tls"] = "false"

    if str(cfg.get("verify_tls", "true")).lower() in ("false", "0", "no"):
        log("TLS verification is DISABLED. Acceptable only with the "
            "self-signed placeholder certificate; enable it once a CA-signed "
            "certificate is installed.", "WARN")

    if os.geteuid() != 0 and args.command != "facts":
        die("Run as root (package queries and installs need it)")

    handlers = {
        "enroll": cmd_enroll,
        "checkin": cmd_checkin,
        "inventory": cmd_inventory,
        "run": cmd_run,
        "facts": cmd_facts,
        "check": cmd_check,
        "update-check": cmd_update_check,
    }
    try:
        rc = handlers[args.command](cfg, args)
        return 0 if rc in (0, None) else (rc if isinstance(rc, int) else 0)
    except RuntimeError as e:
        die(str(e))
    except KeyboardInterrupt:
        log("interrupted", "WARN")
        return 130


if __name__ == "__main__":
    sys.exit(main())
