#!/usr/bin/env bash
# ===========================================================================
# setup-agent.sh - install or upgrade the PATCH-01 agent on this Linux server.
#
#   sudo ./setup-agent.sh
#
# It works out what is needed and asks only for that:
#   1. checks this server (root, Python 3, systemd)
#   2. finds any existing agent: its version, whether it is enrolled, its settings
#   3. PATCH-01's address (the existing one is offered)
#   4. the CA chain (PEM) that verifies PATCH-01's certificate, tested right
#      away; the server's own trust store is used if it already trusts PATCH-01
#   5. a new server: asks for an enrolment token and enrols
#      an existing one: upgrades in place and keeps its identity (no token)
#   6. proves it works: version, timer, a check-in to PATCH-01
#
# Without questions (for scripts):  --server URL --ca FILE --yes, with the token in the
#   environment (never on the command line, where ps shows it):
#     read -rs PATCH_ENROLL_TOKEN; export PATCH_ENROLL_TOKEN
# Keep install-agent.sh and patch-agent.py beside this script.
#
# PATCH-01's repositories (r117): it offers to point this server's package manager
# at them, with the file from repos/ for this OS (repos/patch01-rhel9.repo, ...).
# Without questions: --repo-file repos/patch01-rhel9.repo; never: --no-repos.
#
# Signed agent updates: --release-key FILE pins the public half of your
# OFFLINE release-signing key (patch01/scripts/sign-agent-release.sh
# --new-key). From then on this server's agent accepts an update from
# PATCH-01 only when it is signed with that key. A release-signing.pub beside
# this script is pinned the same way when no key is pinned yet. Without a key
# the agent works as before and reports release_key=none when it checks in.
# ===========================================================================
set -Eeuo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN=/usr/local/bin/patch-agent
CONF_DIR=/etc/patch-agent
CONF="$CONF_DIR/agent.conf"
DEFAULT_SERVER=""
SYSTEM_BUNDLES=(/etc/pki/tls/certs/ca-bundle.crt /etc/ssl/certs/ca-certificates.crt /etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem)
SERVER=""; CA=""; TOKEN="${PATCH_ENROLL_TOKEN:-}"; YES=no; TOKEN_ARG=no; RKEY=""; REPO=""; NOREPO=no

while [[ $# -gt 0 ]]; do
  case "$1" in
    --server) SERVER="${2%/}"; shift ;; --ca) CA="$2"; shift ;; --token) TOKEN="$2"; TOKEN_ARG=yes; shift ;;
    --release-key) RKEY="$2"; shift ;;
    --repo-file) REPO="$2"; shift ;; --no-repos) NOREPO=yes ;;
    --yes|-y) YES=yes ;; -h|--help) sed -n '4,28p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Unknown option $1 (see --help)" >&2; exit 1 ;;
  esac; shift
done

B=$'\033[1m'; G=$'\033[32m'; R=$'\033[31m'; Y=$'\033[33m'; N=$'\033[0m'
[[ -t 1 ]] || { B=""; G=""; R=""; Y=""; N=""; }
step() { printf '\n%s[%s] %s%s\n' "$B" "$1" "$2" "$N"; }
ok()   { printf '  %sok%s    %s\n' "$G" "$N" "$*"; }
warn() { printf '  %swarn%s  %s\n' "$Y" "$N" "$*"; }
[[ "$TOKEN_ARG" == yes ]] && warn "--token puts the token on the command line, where ps on this server shows it: prefer PATCH_ENROLL_TOKEN in the environment, or let it ask."
die()  { printf '\n  %sSTOP%s  %s\n\n' "$R" "$N" "$*" >&2; exit 1; }
ask()  {  # ask VAR "question" default
  local __v="$1" q="$2" d="${3:-}" a=""
  if [[ "$YES" == yes ]]; then printf -v "$__v" '%s' "$d"; return; fi
  read -r -p "  $q${d:+ [$d]}: " a || true
  printf -v "$__v" '%s' "${a:-$d}"
}
ask_secret() {  # ask_secret VAR "question": not echoed while typed or pasted
  local __v="$1" q="$2" a=""
  if [[ "$YES" == yes ]]; then return; fi
  read -r -s -p "  $q (hidden): " a || true; echo
  printf -v "$__v" '%s' "$a"
}
conf_val() { [[ -f "$CONF" ]] && sed -n "s/^$1=//p" "$CONF" | tail -1 | tr -d "\"'" || true; }
# Verify exactly as the agent will: the same Python, with the same rules. curl
# is not used here: it accepts an intermediate CA as an anchor, the agent's
# Python does not, so curl could pass a CA file the agent then rejects.
health() {   # health <server> [cafile] -> 200, or "verify:<reason>" / "error:<reason>"
  "$PY" - "$1" "${2:-}" 2>/dev/null <<'PYV' || echo "error:python failed"
import ssl, sys
import urllib.request as ur
url, ca = sys.argv[1], (sys.argv[2] or None)
ctx = ssl.create_default_context(cafile=ca) if ca else ssl.create_default_context()
ctx.verify_flags &= ~getattr(ssl, "VERIFY_X509_PARTIAL_CHAIN", 0)   # an intermediate is not a root
op = ur.build_opener(ur.ProxyHandler({}), ur.HTTPSHandler(context=ctx))
verr = getattr(ssl, "SSLCertVerificationError", ssl.SSLError)
try:
    print(op.open(url + "/api/v1/health", timeout=10).getcode())
except verr as e:
    print("verify:" + str(getattr(e, "verify_message", "") or e)[:150])
except Exception as e:
    r = getattr(e, "reason", e)
    if isinstance(r, verr):
        print("verify:" + str(getattr(r, "verify_message", "") or r)[:150])
    else:
        code = getattr(e, "code", None)
        print(str(code) if code else "error:" + str(r)[:150])
PYV
}
answers() {  # does PATCH-01 answer at all, certificate aside?
  local c; c="$(curl -sk --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 10 "$1/api/v1/health" 2>/dev/null || true)"
  [[ "${c:-000}" == 200 ]]
}

# ---------------------------------------------------------------------------
step 1/6 "This server"
[[ $EUID -eq 0 ]] || die "Run it as root: sudo $0"
[[ -f "$HERE/install-agent.sh" && -f "$HERE/patch-agent.py" ]] \
  || die "install-agent.sh and patch-agent.py must be in the same folder as this script."
OS="$( . /etc/os-release 2>/dev/null && echo "$PRETTY_NAME" || uname -sr)"
ok "$OS"
PY=""
for c in /usr/bin/python3 /usr/libexec/platform-python /usr/bin/python3.6; do [[ -x "$c" ]] && { PY="$c"; break; }; done
[[ -n "$PY" ]] || die "No Python 3. Install it first (RHEL/OL: dnf install -y python3; OL7: yum install -y python3)."
ok "Python: $PY ($("$PY" -c 'import sys; print("%d.%d" % sys.version_info[:2])'))"
command -v systemctl >/dev/null || die "systemd is needed: the agent runs from a systemd timer."
command -v curl >/dev/null || die "curl is needed."
NEW_VER="$(sed -n 's/^AGENT_VERSION = "\(.*\)"$/\1/p' "$HERE/patch-agent.py" | head -1)"
ok "Agent in this folder: ${NEW_VER:-unknown}"
RKEY_ARG="$RKEY"     # only an explicit --release-key replaces a key already pinned
[[ -z "$RKEY" && -f "$HERE/release-signing.pub" ]] && RKEY="$HERE/release-signing.pub"
if [[ -n "$RKEY" ]]; then
  KFP="$("$PY" "$HERE/patch-agent.py" release-key "$RKEY" 2>&1)" || die "$RKEY: $KFP"
  if [[ -z "$RKEY_ARG" && -f "$CONF_DIR/release-signing.pub" ]] && ! cmp -s "$RKEY" "$CONF_DIR/release-signing.pub"; then
    die "$RKEY differs from the release-signing key already pinned here ($CONF_DIR/release-signing.pub). To replace that key, give the new one explicitly: --release-key FILE"
  fi
  ok "Release-signing key to pin: $RKEY ($KFP)"
  ok "Compare that SHA-256 with the one sign-agent-release.sh printed on your offline machine."
fi

# ---------------------------------------------------------------------------
step 2/6 "Existing agent"
HAVE=no; ENROLLED=no; OLD_VER=""
if [[ -f "$BIN" ]]; then
  HAVE=yes
  OLD_VER="$(sed -n 's/^AGENT_VERSION = "\(.*\)"$/\1/p' "$BIN" | head -1)"
  [[ -s "$CONF_DIR/token" ]] && ENROLLED=yes
  ok "Installed: version ${OLD_VER:-unknown}, $( [[ $ENROLLED == yes ]] && echo enrolled || echo 'not enrolled')"
  ok "Talks to: $(conf_val server) (TLS check: $(conf_val verify_tls)$( [[ -n "$(conf_val ca_file)" ]] && echo ", CA $(conf_val ca_file)"))"
  [[ "$OLD_VER" == "$NEW_VER" ]] && ok "Already this version: settings will be refreshed" || ok "Will upgrade ${OLD_VER:-?} -> $NEW_VER, keeping its identity"
else
  ok "None: this will be a new install"
fi

# ---------------------------------------------------------------------------
step 3/6 "PATCH-01"
D="${SERVER:-$(conf_val server)}"; D="${D:-$DEFAULT_SERVER}"
[[ -n "$SERVER" ]] || ask SERVER "PATCH-01 address" "$D"
SERVER="${SERVER%/}"
[[ -n "$SERVER" ]] || die "Give PATCH-01's address, e.g. https://<patch01 name> (or --server)."
[[ "$SERVER" =~ ^https://[A-Za-z0-9.-]+(:[0-9]+)?$ ]] || die "'$SERVER' is not an https:// address."
HOSTNAME_="$(sed -E 's#^https://##; s#[:/].*$##' <<<"$SERVER")"
PORT_="$(sed -nE 's#^https://[^:/]+:([0-9]+).*#\1#p' <<<"$SERVER")"; PORT_="${PORT_:-443}"
IP="$(getent ahostsv4 "$HOSTNAME_" 2>/dev/null | awk '{print $1; exit}' || true)"
[[ -n "$IP" ]] || die "$HOSTNAME_ does not resolve on this server. Fix DNS (or /etc/hosts) first."
ok "$HOSTNAME_ is $IP"
if timeout 6 bash -c "exec 3<>/dev/tcp/$IP/$PORT_" 2>/dev/null; then ok "Port $PORT_ reachable"
else die "Cannot connect to $IP:$PORT_. Ask for the firewall rule from this server to PATCH-01 on $PORT_."; fi
answers "$SERVER" || die "Something listens on $IP:$PORT_ but it is not PATCH-01 answering at $SERVER/api/v1/health."
ok "PATCH-01 answers at $SERVER"

# ---------------------------------------------------------------------------
step 4/6 "Trusting PATCH-01's certificate"
CA_USE=""
pick_ca() {   # pick_ca <file> : set CA_USE if this file verifies PATCH-01
  local f="$1" code
  [[ -f "$f" ]] || { warn "No file $f"; return 1; }
  openssl x509 -in "$f" -noout 2>/dev/null || { warn "$f is not a PEM certificate file"; return 1; }
  code="$(health "$SERVER" "$f")"
  if [[ "$code" == 200 ]]; then CA_USE="$f"; return 0; fi
  warn "$f does not verify PATCH-01's certificate (${code#verify:})."
  warn "It needs the ROOT CA that PATCH-01's certificate chains to: root and intermediate together in"
  warn "one file is safest. An intermediate alone is not enough for the agent."
  return 1
}
if [[ -n "$CA" ]]; then
  pick_ca "$CA" || die "The CA file given does not verify PATCH-01."
else
  # 1. the CA this agent already uses; 2. the system trust store; 3. ask
  cur="$(conf_val ca_file)"
  if [[ -n "$cur" && -f "$cur" ]] && [[ "$(health "$SERVER" "$cur")" == 200 ]]; then
    CA_USE="$cur"; ok "The CA this agent already uses still verifies PATCH-01"
  else
    for bfile in "${SYSTEM_BUNDLES[@]}"; do
      if [[ -f "$bfile" && "$(health "$SERVER" "$bfile")" == 200 ]]; then
        CA_USE="$bfile"; ok "This server already trusts PATCH-01 (system trust store $bfile)"; break
      fi
    done
  fi
  tries=0
  while [[ -z "$CA_USE" ]]; do
    [[ "$YES" == yes ]] && die "Nothing on this server verifies PATCH-01: give --ca with your CA chain (PEM)."
    ask CA "Path to the CA chain file (PEM: root, or root + intermediate)" ""
    [[ -n "$CA" ]] || die "A CA file is needed to verify PATCH-01."
    pick_ca "$CA" && break
    tries=$((tries + 1)); (( tries < 3 )) || die "Three files tried; none verifies PATCH-01."
    CA=""
  done
fi
ok "Verified the way the agent verifies: PATCH-01's certificate checks out with $CA_USE"
SUBJ="$(echo | timeout 10 openssl s_client -connect "$IP:$PORT_" -servername "$HOSTNAME_" 2>/dev/null \
        | openssl x509 -noout -subject -enddate 2>/dev/null | tr '\n' ' ' | sed 's/subject=//; s/notAfter=/, valid until /' || true)"
[[ -n "$SUBJ" ]] && ok "PATCH-01 presents: $SUBJ"

# ---------------------------------------------------------------------------
step 5/6 "$( [[ $ENROLLED == yes ]] && echo 'Upgrading the agent (identity kept, no token needed)' || echo 'Installing and enrolling' )"
ARGS=(--server "$SERVER" --ca "$CA_USE")
[[ -n "$RKEY_ARG" ]] && ARGS+=(--release-key "$RKEY_ARG")
# PATCH-01's repositories for this OS, from repos/ (asked; never done unasked with --yes)
if [[ "$NOREPO" != yes && -z "$REPO" && -r /etc/os-release ]]; then
  OSID="$(. /etc/os-release; echo "${ID:-}")"; OSVER="$(. /etc/os-release; echo "${VERSION_ID:-}")"
  case "$OSID" in
    ubuntu) CAND="$HERE/repos/patch01-ubuntu${OSVER//./}.list" ;;
    rhel|ol) CAND="$HERE/repos/patch01-${OSID}${OSVER%%.*}.repo" ;;
    *) CAND="" ;;
  esac
  if [[ -n "$CAND" && -f "$CAND" && "$YES" != yes ]]; then
    a=""; read -r -p "  Point this server's package manager at PATCH-01's repositories ($(basename "$CAND"))? [y/N]: " a || true
    [[ "$a" =~ ^[Yy] ]] && REPO="$CAND"
  fi
fi
if [[ -n "$REPO" ]]; then
  [[ -f "$REPO" ]] || die "Repository file not found: $REPO"
  ARGS+=(--repo-file "$REPO")
fi
if [[ "$ENROLLED" != yes ]]; then
  [[ -n "$TOKEN" ]] || ask_secret TOKEN "Enrolment token (from PATCH-01: phase10-windows.sh --tokens 1 <group>)"
  [[ -n "$TOKEN" ]] || die "A new server needs an enrolment token."
  export PATCH_ENROLL_TOKEN="$TOKEN"        # to the installer through the environment, never the command line
fi
if [[ "$YES" != yes ]]; then
  a=""; read -r -p "  Go ahead? [Y/n]: " a || true
  [[ -z "$a" || "$a" =~ ^[Yy] ]] || die "Stopped; nothing was changed."
fi
LOG="/var/log/patch-agent-setup.log"
if bash "$HERE/install-agent.sh" "${ARGS[@]}" >"$LOG" 2>&1; then
  ok "Installer finished (details in $LOG)"
  if [[ -n "$REPO" ]]; then
    if grep -q "PATCH-01's repositories answer" "$LOG"; then ok "Package manager reads PATCH-01's repositories ($(basename "$REPO"))"
    else warn "PATCH-01's repositories are set, but not readable yet: on PATCH-01, Admin > Repositories must show them synced and published"; fi
    warn "Turn this server's own vendor repositories off (the file's comments say how), so every update comes through PATCH-01"
  fi
else
  tail -15 "$LOG" | sed 's/^/        /'
  die "The installer stopped (above; full log $LOG)."
fi
unset PATCH_ENROLL_TOKEN

# ---------------------------------------------------------------------------
step 6/6 "Proving it works"
NOW_VER="$(sed -n 's/^AGENT_VERSION = "\(.*\)"$/\1/p' "$BIN" | head -1)"
[[ "$NOW_VER" == "$NEW_VER" ]] && ok "Agent version $NOW_VER" || die "Installed version is $NOW_VER, expected $NEW_VER."
[[ -s "$CONF_DIR/token" ]] && ok "Enrolled with PATCH-01" || die "Not enrolled: the enrolment did not complete (see $LOG)."
[[ "$(sed -n 's/^verify_tls=//p' "$CONF")" == true ]] && ok "Verifies PATCH-01's certificate" || warn "TLS verification is off"
RK="$("$BIN" release-key 2>&1 || true)"
case "$RK" in
  pinned:*) ok "Agent updates must be signed with the offline release key (${RK#pinned: })" ;;
  *) warn "Agent updates are NOT signature-checked: ${RK#*: }"
     warn "Pin the offline release key: $0 --release-key release-signing.pub" ;;
esac
systemctl is-active --quiet patch-agent.timer && ok "Timer active: checks in every 5 minutes" \
  || warn "patch-agent.timer is not active: systemctl enable --now patch-agent.timer"
CHK="$(mktemp)"; trap 'rm -f "$CHK"' EXIT
if env -u HTTP_PROXY -u HTTPS_PROXY -u http_proxy -u https_proxy "$BIN" checkin >"$CHK" 2>&1; then
  cat "$CHK" >>"$LOG"; ok "Checked in with PATCH-01 just now"
elif grep -qE 'HTTP (401|403)' "$CHK"; then
  # The saved identity is no longer accepted (removed or decommissioned on PATCH-01, or
  # this server was rebuilt or cloned): it enrols again. PATCH-01 knows the machine and
  # keeps its history. The certificate is fine: the check-in reached PATCH-01.
  cat "$CHK" >>"$LOG"
  warn "PATCH-01 no longer accepts this server's agent identity (removed or decommissioned there?)."
  warn "The certificate is fine. It enrols again with a new token; its history on PATCH-01 is kept."
  [[ -n "$TOKEN" ]] || { [[ "$YES" == yes ]] || ask_secret TOKEN "Enrolment token (from PATCH-01: phase10-windows.sh --tokens 1 <group>)"; }
  [[ -n "$TOKEN" ]] || die "Enrolling again needs a token: run this again (it asks for it), or with PATCH_ENROLL_TOKEN in the environment."
  export PATCH_ENROLL_TOKEN="$TOKEN"
  env -u HTTP_PROXY -u HTTPS_PROXY -u http_proxy -u https_proxy "$BIN" enroll --force >>"$LOG" 2>&1 \
    || { unset PATCH_ENROLL_TOKEN; tail -5 "$LOG" | sed 's/^/        /'; die "Enrolling again failed (above)."; }
  unset PATCH_ENROLL_TOKEN; TOKEN=""
  env -u HTTP_PROXY -u HTTPS_PROXY -u http_proxy -u https_proxy "$BIN" checkin >>"$LOG" 2>&1 \
    && ok "Enrolled again and checked in with PATCH-01 just now" || { tail -5 "$LOG" | sed 's/^/        /'; die "The check-in failed (above)."; }
  env -u HTTP_PROXY -u HTTPS_PROXY -u http_proxy -u https_proxy "$BIN" inventory >>"$LOG" 2>&1 || warn "First inventory failed; the timer will retry."
else
  cat "$CHK" >>"$LOG"; tail -5 "$LOG" | sed 's/^/        /'; die "The check-in failed (above)."
fi
printf '\n  %sDone.%s This server is on agent %s and appears on PATCH-01'"'"'s Agents page.\n\n' "$G" "$N" "$NOW_VER"
