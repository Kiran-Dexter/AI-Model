/* ---- Vulnerabilities > Nessus -------------------------------------------------
 * Nessus scanners PATCH-01 talks to: their scans with one-click buttons (launch,
 * pause, resume, stop, import, report, edit), Nessus's own reports passed through,
 * and the findings imported from the latest finished run of each scan.
 *
 * Nessus Professional lets outside tools read scans and export reports only: the
 * start / pause / stop / create / edit buttons show as unavailable there, with a
 * link to do it in Nessus. On Nessus Manager they work.
 */

const NS_STATUS = { completed: "Finished", imported: "Imported", running: "Running", paused: "Paused", canceled: "Stopped",
  aborted: "Aborted", empty: "Never run", pending: "Starting", pausing: "Pausing", resuming: "Resuming", stopping: "Stopping",
  processing: "Processing" };
const NS_BUSY = new Set(["running", "pending", "pausing", "resuming", "stopping", "processing"]);
const NS_SEV = { 4: ["Critical", "sv-crit"], 3: ["High", "sv-high"], 2: ["Medium", "sv-med"], 1: ["Low", "sv-low"], 0: ["Info", "sv-low"] };
const NS_FORMATS = [["pdf", "PDF"], ["html", "HTML"], ["csv", "CSV"], ["nessus", ".nessus"]];
const NS_DAYS = [["MO", "Monday"], ["TU", "Tuesday"], ["WE", "Wednesday"], ["TH", "Thursday"], ["FR", "Friday"], ["SA", "Saturday"], ["SU", "Sunday"]];

function nsSev(n) {
  const [t, cls] = NS_SEV[n] || NS_SEV[0];
  return h("span", { class: "sv " + cls }, t);
}

// Only the server's own https address, as saved (checked again on the server when it was saved)
function nsLink(server, scanId) {
  const u = String((server && server.url) || "");
  if (!/^https:\/\/[A-Za-z0-9.\-[\]:]+$/.test(u)) return null;
  return u + (scanId ? "/#/scans/reports/" + Number(scanId) + "/hosts" : "/#/scans/folders/my-scans");
}

function nsStatus(s) {
  const st = s.status || "";
  const cls = NS_BUSY.has(st) ? "ns-st ns-run" : st === "completed" || st === "imported" ? "ns-st ns-ok"
    : st === "aborted" || st === "canceled" ? "ns-st ns-bad" : "ns-st";
  return h("span", { class: cls }, NS_STATUS[st] || st || "–");
}

async function renderNessus(params) {
  setNav("vulns");
  const page = h("div", { class: "ns" });
  let d;
  try { d = await api("/nessus"); }
  catch (e) {
    if (e instanceof StaleRoute) throw e;
    render(h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure vulns --nessus" }, "Nessus")),
      h("div", { class: "empty" }, h("p", null, e.message || "Nessus could not be read.")));
    return;
  }
  render(page);
  await drawNessus(page, d, params);
}

async function drawNessus(page, d, params, skipIf) {
  const servers = d.servers || [];
  const byId = new Map(servers.map(s => [s.id, s]));
  const say = h("p", { class: "cm-meta ns-msg", role: "status", "aria-live": "polite" });
  const tell = (t, bad) => { say.textContent = t; say.classList.toggle("hd-failed", !!bad); };
  // Refreshes after a button never wipe a form being filled in
  const busy = () => !!page.querySelector(".ns-scanform, .ns-setup.editing, .ns-add[open]");
  const reload = async () => {
    if (busy()) return false;
    const fresh = await api("/nessus");
    if (busy() || !page.isConnected) return false;            // a form opened while it loaded
    return await drawNessus(page, fresh, new URLSearchParams(location.hash.split("?")[1] || ""), busy);
  };
  // After a button: refresh; when a form keeps the page as it is, the button comes back
  const after = (btn, ms) => setTimeout(async () => {
    let drawn = false;
    try { drawn = await reload(); } catch (e) { /* the page stays as it is */ }
    if (!drawn && btn.isConnected) btn.disabled = false;
  }, ms);

  if (!servers.length) {
    page.replaceChildren(
      h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure vulns --nessus" }, "Nessus")),
      h("p", { class: "muted small" }, "Manage Nessus scans from here and bring their results into Vulnerabilities."),
      can("admin") ? nsServerForm(page, d, null) : h("div", { class: "empty" }, h("p", null,
        "No Nessus scanner is connected yet. An admin adds one here (Vulnerabilities › Nessus).")));
    return;
  }

  // ---- findings: loaded once, filtered here
  const f = await api("/nessus/findings").catch(e => { if (e instanceof StaleRoute) throw e; return { items: [], severity: [], hosts: 0, our_hosts: 0, cves: 0, error: e.message }; });
  const scans = d.scans || [];
  const sevN = Object.fromEntries((f.severity || []).map(x => [x.label, x.n]));
  let q = params.get("q") || "", minSev = 1, scanSel = params.get("scan") || "", pg = 1;

  const tile = (n, label, cls, onClick) => h(onClick ? "button" : "div", { type: onClick ? "button" : null, class: "srv-tile " + (cls || ""),
    on: onClick ? { click: onClick } : null }, h("span", { class: "srv-tile-n" }, String(n || 0)), h("span", { class: "srv-tile-l" }, label));
  const running = scans.filter(s => NS_BUSY.has(s.status)).length;
  const tiles = h("div", { class: "srv-tiles" },
    tile(scans.length, "Scans"),
    tile(running, "Running now", running ? "t-warn" : ""),
    tile(sevN.Critical, "Critical findings", sevN.Critical ? "t-off" : "", () => { minSev = 4; pg = 1; drawFindings(); findingsHead.scrollIntoView({ block: "start" }); }),
    tile(sevN.High, "High findings", sevN.High ? "t-off" : "", () => { minSev = 3; pg = 1; drawFindings(); findingsHead.scrollIntoView({ block: "start" }); }),
    tile(f.hosts, "Hosts with findings"),
    tile(f.our_hosts, "Of them, our servers"),
    tile(f.cves, "CVEs found"));

  // ---- graphs
  const items = f.items || [];
  const hostTop = new Map(), pluginTop = new Map();
  for (const x of items) {
    if (x.severity >= 3) hostTop.set(x.host_name, (hostTop.get(x.host_name) || 0) + 1);
    const k = x.plugin_name || ("Plugin " + x.plugin_id);
    if (!pluginTop.has(k)) pluginTop.set(k, new Set());
    pluginTop.get(k).add(x.host_name);
  }
  const top = (m, n) => [...m.entries()].map(([label, v]) => ({ label, n: typeof v === "number" ? v : v.size }))
    .sort((a, b) => b.n - a.n || String(a.label).localeCompare(String(b.label))).slice(0, n);
  const charts = h("div", { class: "imp-charts" },
    impBars("Findings by severity", f.severity, { empty: "No findings imported yet.",
      href: r => { minSev = { Critical: 4, High: 3, Medium: 2, Low: 1 }[r.label] || 1; pg = 1; drawFindings(); } }),
    impBars("Hosts with most critical and high", top(hostTop, 8), { series: "s2", empty: "No critical or high finding.",
      href: r => { q = r.label; search.value = q; pg = 1; drawFindings(); } }),
    impBars("Findings on most hosts", top(pluginTop, 8), { empty: "No findings imported yet." }));

  // ---- servers
  const serverCard = s => {
    const link = nsLink(s);
    const ctl = s.scan_control === true ? h("span", { class: "ns-cap ok" }, "Scans start from here")
      : s.scan_control === false ? h("span", { class: "ns-cap", title: (s.product || "This Nessus") + " lets outside tools read scans and export reports only" },
          "Read and report only")
      : h("span", { class: "ns-cap" }, "Scan control: checked on first use");
    const acts = [];
    if (can("operator")) acts.push(h("button", { type: "button", class: "btn-link", disabled: !s.enabled, on: { click: async e => {
      e.target.disabled = true;
      try { const r = await apiPost("/nessus/servers/" + s.id + "/sync", {}); tell(s.name + ": " + r.message); }
      catch (err) { tell(err.message, true); e.target.disabled = false; } } } }, "Refresh"));
    if (can("admin")) {
      acts.push(h("button", { type: "button", class: "btn-link", on: { click: async e => {
        e.target.disabled = true; tell("Signing in to " + s.name + "…");
        try { const r = await apiPost("/admin/nessus/test", { id: s.id }); tell(s.name + ": " + r.message, !r.ok); }
        catch (err) { tell(err.message, true); }
        e.target.disabled = false; } } }, "Test"));
      acts.push(h("button", { type: "button", class: "btn-link", on: { click: () => {
        const form = nsServerForm(page, d, s);
        form.classList.add("editing");
        page.querySelectorAll(".ns-setup.editing").forEach(x => x.remove());
        page.append(form); form.scrollIntoView({ block: "start" }); form.querySelector("input").focus(); } } }, "Edit"));
      acts.push(h("button", { type: "button", class: "btn-link danger", on: { click: async () => {
        if (!confirm("Remove " + s.name + " from PATCH-01? Its saved keys and the findings imported from it are deleted here. Nothing changes in Nessus.")) return;
        try { await apiSend("DELETE", "/admin/nessus/" + s.id); await reload(); }
        catch (err) { tell(err.message, true); } } } }, "Remove"));
    }
    if (link) acts.push(h("a", { class: "btn-link", href: link, target: "_blank", rel: "noopener noreferrer" }, "Open Nessus ↗"));
    return h("div", { class: "ns-server" },
      h("div", { class: "ns-server-h" },
        h("span", { class: "light " + (s.last_sync_ok ? "light-on" : s.last_sync_ok === false ? "light-off" : "light-unk"), "aria-hidden": "true" }),
        h("strong", null, s.name), h("span", { class: "muted small" }, [s.product, s.version].filter(Boolean).join(" ") || "Nessus"),
        s.enabled ? null : h("span", { class: "ns-cap" }, "turned off"), ctl),
      h("p", { class: "small " + (s.last_sync_ok === false ? "hd-failed" : "muted") },
        s.last_sync_at ? (s.last_sync_ok ? "Read " + timeAgo(s.last_sync_at) : "Last read failed " + timeAgo(s.last_sync_at) + ": " + (s.last_sync_msg || ""))
          : "Waiting for the first read (within a minute).",
        " · every " + (d.sync_minutes || 15) + " minutes"
        + (s.pinned ? " · certificate trusted by fingerprint" + (s.pin_not_after ? " (until " + fmtDate(s.pin_not_after) + ")" : "") : "")),
      h("span", { class: "row-actions" }, acts));
  };

  // ---- scans
  const reportBox = h("div", { class: "ns-reports", "aria-live": "polite" });
  const scanBox = h("div", { class: "ns-scans" });
  const open = new Set();
  const control = (s, server) => {
    const out = [];
    const off = server.scan_control === false;
    const why = (server.product || "This Nessus") + " does not let outside tools do this: use Open in Nessus.";
    const btn = (label, verb, primary) => h("button", { type: "button", class: primary ? "btn ns-btn" : "btn btn-quiet ns-btn",
      disabled: off || !server.enabled, title: off ? why : null, "aria-disabled": off ? "true" : null, on: { click: async e => {
        if (verb === "stop" && !confirm("Stop " + s.name + " in Nessus? Hosts not yet scanned are left out of this run.")) return;
        e.target.disabled = true;
        const b = e.currentTarget;
        try { const r = await apiPost("/nessus/scans/" + server.id + "/" + s.scan_id + "/" + verb, {}); tell(s.name + ": " + r.message); after(b, 1500); }
        catch (err) {
          tell(s.name + ": " + err.message, true);
          if (err.status === 409) after(b, 800); else b.disabled = false;
        } } } }, label);
    if (can("operator")) {
      if (s.status === "running" || s.status === "pending") out.push(btn("Pause", "pause"), btn("Stop", "stop"));
      else if (s.status === "paused") out.push(btn("Resume", "resume", true), btn("Stop", "stop"));
      else if (!NS_BUSY.has(s.status)) out.push(btn("Launch", "launch", true));
      out.push(h("button", { type: "button", class: "btn btn-quiet ns-btn", disabled: !s.last_history_id || !server.enabled,
        title: s.last_history_id ? "Import the newest finished run now" : "No finished run to import yet", on: { click: async e => {
          e.target.disabled = true;
          try { const r = await apiPost("/nessus/scans/" + server.id + "/" + s.scan_id + "/import", {}); tell(s.name + ": " + r.message); }
          catch (err) { tell(err.message, true); e.target.disabled = false; } } } }, "Import now"));
      const fmt = h("select", { "aria-label": "Report format for " + s.name, class: "ns-fmt" }, NS_FORMATS.map(([v, t]) => h("option", { value: v }, t)));
      out.push(h("span", { class: "ns-rep" }, fmt, h("button", { type: "button", class: "btn btn-quiet ns-btn", disabled: !s.last_history_id,
        title: s.last_history_id ? "Nessus builds the report of the newest finished run" : "No finished run to report on yet",
        on: { click: e => nsReport(server, s, fmt.value, e.target, reportBox, tell) } }, "Report")));
    }
    if (can("admin")) out.push(h("button", { type: "button", class: "btn btn-quiet ns-btn", disabled: off, title: off ? why : null,
      "aria-disabled": off ? "true" : null, on: { click: () => nsScanForm(page, server, s, tell, reload) } }, "Edit"));
    const link = nsLink(server, s.scan_id);
    if (link) out.push(h("a", { class: "btn btn-quiet ns-btn", href: link, target: "_blank", rel: "noopener noreferrer" }, "Open in Nessus ↗"));
    return h("span", { class: "ns-actions" }, out);
  };
  const counts = s => s.last_history_id || s.critical || s.high || s.medium || s.low ? h("span", { class: "ns-counts" },
    [["critical", "sv-crit", "C"], ["high", "sv-high", "H"], ["medium", "sv-med", "M"], ["low", "sv-low", "L"]].map(([k, cls, l]) =>
      h("span", { class: "sv " + cls, title: (s[k] || 0) + " " + k }, l + " " + (s[k] || 0)))) : h("span", { class: "muted" }, "–");
  function drawScans() {
    const multi = servers.length > 1;
    const cols = [
      { label: "Scan", sort: s => (s.name || "").toLowerCase(), cell: s => [h("strong", null, s.name),
          h("div", { class: "muted small" }, [multi ? (byId.get(s.server_id) || {}).name : null, s.folder, s.schedule].filter(Boolean).join(" · "))] },
      { label: "Status", sort: s => s.status || "", cell: s => nsStatus(s) },
      { label: "Last run", sort: s => s.last_end ? Date.parse(s.last_end) : null, cell: s => s.last_end ? timeAgo(s.last_end) : h("span", { class: "muted" }, "–") },
      { label: "Hosts", num: true, sort: s => s.hosts || 0, cell: s => String(s.hosts || 0) },
      { label: "Found", sort: s => (s.critical || 0) * 1e6 + (s.high || 0) * 1e3 + (s.medium || 0), cell: counts },
      { label: "Imported", sort: s => s.imported_at ? Date.parse(s.imported_at) : null, cell: s => s.import_error
          ? h("span", { class: "hd-failed small", title: s.import_error }, "failed")
          : s.imported_at && s.imported_history_id === s.last_history_id ? [timeAgo(s.imported_at), h("div", { class: "muted small" }, (s.findings || 0) + " findings")]
          : s.last_history_id ? h("span", { class: "muted small" }, "waiting") : h("span", { class: "muted" }, "–") },
      { label: "", cell: s => control(s, byId.get(s.server_id) || {}) },
    ];
    scanBox.replaceChildren(scans.length ? plusTable(cols, scans, s => [
      h("dl", { class: "srv-kv" }, ...[["Targets", s.targets || "–"], ["Folder", s.folder || "–"], ["Owner", s.owner || "–"],
          ["Schedule", s.schedule || "On demand"], ["Started", s.last_start ? fmtDateTime(s.last_start) : "–"],
          ["Finished", s.last_end ? fmtDateTime(s.last_end) : "–"],
          ["Imported", s.imported_at ? fmtDateTime(s.imported_at) + " (" + (s.findings || 0) + " findings)" : "not yet"]]
        .map(([k, v]) => h("div", { class: "kv" }, h("dt", null, k), h("dd", null, v)))),
      s.import_error ? h("p", { class: "hd-failed small" }, "Import failed: " + s.import_error) : null,
      s.findings ? h("p", { class: "small" }, h("button", { type: "button", class: "btn-link", on: { click: () => {
        scanSel = s.server_id + "|" + s.scan_id; scanPick.value = scanSel; pg = 1; drawFindings(); findingsHead.scrollIntoView({ block: "start" }); } } },
        "Show this scan's findings")) : null], { open, key: s => s.server_id + "|" + s.scan_id, rowClass: s => NS_BUSY.has(s.status) ? "ns-row-run" : "" })
      : h("div", { class: "empty" }, h("p", null, "No scans in Nessus yet" + (servers.some(s => s.last_sync_at) ? "." : " (the first read runs within a minute)."))));
  }

  // ---- findings
  const findingsHead = h("h2", { class: "ns-h" }, "Findings");
  const findBox = h("div");
  const search = h("input", { type: "search", placeholder: "Search host, address, finding or CVE", "aria-label": "Search findings", value: q });
  let tq = null;
  search.addEventListener("input", () => { clearTimeout(tq); tq = setTimeout(() => { q = search.value.trim(); pg = 1; drawFindings(); }, 250); });
  const sevPick = h("select", { "aria-label": "Severity", on: { change: e => { minSev = Number(e.target.value); pg = 1; drawFindings(); } } },
    [[1, "Low and above"], [2, "Medium and above"], [3, "High and above"], [4, "Critical only"]].map(([v, t]) => h("option", { value: v }, t)));
  const scanPick = h("select", { "aria-label": "Scan", on: { change: e => { scanSel = e.target.value; pg = 1; drawFindings(); } } },
    h("option", { value: "" }, "Scan: all"), scans.filter(s => s.findings).map(s => h("option", { value: s.server_id + "|" + s.scan_id }, s.name)));
  scanPick.value = scanSel;
  const dlBtn = (fmt, label, quiet) => {
    const b = h("button", { type: "button", class: quiet ? "btn btn-quiet" : "btn" }, label);
    b.addEventListener("click", async () => {
      b.disabled = true; const t = b.textContent; b.textContent = "Preparing…";
      try { await downloadFile("/nessus/export?" + exportQuery(fmt), "nessus-findings." + fmt); }
      catch (e) { tell(e.message || "The export failed.", true); }
      finally { b.disabled = false; b.textContent = t; }
    });
    return b;
  };
  const exportQuery = fmt => {
    const p = new URLSearchParams({ format: fmt, severity: String(minSev) });
    if (scanSel) { const [sv, sc] = scanSel.split("|"); p.set("server", sv); p.set("scan", sc); }
    if (q) p.set("q", q.slice(0, 80));
    return p.toString();
  };
  setPageExport(() => ({ server: "/nessus/export?" + exportQuery("x").replace(/^format=x&?/, "") }));
  const findDl = h("span", { class: "head-actions" }, dlBtn("xlsx", "Download Excel"), dlBtn("pdf", "PDF", true), dlBtn("csv", "CSV", true));
  function drawFindings() {
    sevPick.value = String(minSev);
    const needle = q.toLowerCase();
    const list = items.filter(x => x.severity >= minSev && (!scanSel || (x.server_id + "|" + x.scan_id) === scanSel)
      && (!needle || [x.host_name, x.host_ip, x.our_host, x.plugin_name, (x.cves || []).join(" ")].join(" ").toLowerCase().includes(needle)));
    const pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
    pg = Math.min(pg, pages);
    const cols = [
      { label: "Severity", sort: x => x.severity * 100 + Number(x.cvss3 || x.cvss || 0), cell: x => [nsSev(x.severity),
          (x.cvss3 || x.cvss) ? h("span", { class: "muted small" }, " " + Number(x.cvss3 || x.cvss).toFixed(1)) : null] },
      { label: "Host", sort: x => (x.host_name || "").toLowerCase(), cell: x => [h("strong", null, x.host_name),
          h("div", { class: "muted small" }, [x.host_ip !== x.host_name ? x.host_ip : null,
            x.our_host ? "our server " + x.our_host : null].filter(Boolean).join(" · "))] },
      { label: "Finding", sort: x => (x.plugin_name || "").toLowerCase(), cell: x => [h("span", { class: "vu-title" }, x.plugin_name || "Plugin " + x.plugin_id),
          h("div", { class: "muted small" }, "Plugin " + x.plugin_id + (x.family ? " · " + x.family : ""))] },
      { label: "CVEs", cell: x => (x.cves || []).length ? h("span", { class: "mono small", title: x.cves.join(", ") },
          x.cves.slice(0, 3).join(", ") + (x.cves.length > 3 ? " +" + (x.cves.length - 3) : "")) : h("span", { class: "muted" }, "–") },
      { label: "Port", cell: x => x.port ? x.port + "/" + x.protocol : (x.protocol || "") },
      { label: "Exploit", cell: x => x.exploit ? h("span", { class: "sv sv-crit" }, "available") : "" },
    ];
    findBox.replaceChildren(...[f.error ? h("p", { class: "hd-failed small" }, f.error) : null,
      list.length ? h("div", { class: "table-wrap" }, table(cols, [], { paged: { key: "nessus-findings", items: list, page: pg, size: PAGE_SIZE, redraw: () => drawFindings() } }))
        : h("div", { class: "empty" }, h("p", null, items.length ? "Nothing matches the filter."
          : "No findings imported yet. They arrive within minutes of a scan finishing, or use Import now.")),
      f.limited ? h("p", { class: "muted small" }, "The page shows the 5,000 most severe findings; the downloads hold them all.") : null,
      pager(pg, pages, list.length, PAGE_SIZE, n => { pg = n; drawFindings(); })].filter(Boolean));
  }

  const newScan = can("admin") ? h("button", { type: "button", class: "btn btn-quiet" }, "New scan") : null;
  if (newScan) {
    const ok = servers.filter(s => s.enabled && s.scan_control !== false);
    if (!ok.length) { newScan.disabled = true; newScan.title = "Nessus Professional does not let outside tools create scans: use Open in Nessus."; newScan.setAttribute("aria-disabled", "true"); }
    newScan.addEventListener("click", () => nsScanForm(page, ok[0], null, tell, reload));
  }
  if (skipIf && skipIf()) return false;                       // a form was opened meanwhile: keep it
  drawScans();
  drawFindings();
  const proNote = servers.some(s => s.scan_control === false) ? h("p", { class: "small ns-note" },
    h("strong", null, "Nessus Professional: "), "Tenable allows outside tools only to read scans and export reports on Professional. "
      + "Launch, pause, stop, new scan and edit are shown greyed out; use Open in Nessus for those. Import, reports and findings work. "
      + "On Nessus Manager every button works.") : null;
  page.replaceChildren(...[
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure vulns --nessus" }, "Nessus"),
      h("span", { class: "head-actions" }, newScan)),
    h("p", { class: "muted small" }, "Scans on your Nessus scanners, read every " + (d.sync_minutes || 15) + " minutes. The newest finished run of each "
      + "scan is imported: its findings show below and count in Detected CVEs as proven on the scanned machine."),
    d.key_ready ? null : h("p", { class: "hd-failed" }, "The key that protects saved API keys (av.key) is not on PATCH-01 yet: run phase3b-api.sh."),
    h("div", { class: "ns-servers" }, servers.map(serverCard)), say, proNote, tiles, charts,
    h("h2", { class: "ns-h" }, "Scans"), scanBox, reportBox,
    h("div", { class: "page-head ns-fhead" }, findingsHead, findDl),
    h("div", { class: "srv-bar" }, search, sevPick, scans.some(s => s.findings) ? scanPick : null), findBox,
    can("admin") ? h("details", { class: "ns-add" }, h("summary", null, "Add another Nessus scanner"), nsServerForm(page, d, null)) : null,
  ].filter(Boolean));
  nsReportsResume(d.reports || [], byId, scans, reportBox, tell);
  return true;
}

/* ---- Nessus's own reports: ask, wait while Nessus builds it, download ---- */

function nsReportLine(rep, label) {
  const line = h("div", { class: "ns-repline" }, h("span", { class: "ns-spin", "aria-hidden": "true" }),
    h("span", null, label + ": Nessus is building the " + rep.format.toUpperCase() + " report…"));
  return line;
}

// One poller per report: a redrawn page hands its new line to the poller already running
const NS_POLLS = new Map();
async function nsPoll(rep, line0, label, tell) {
  if (NS_POLLS.has(rep.id)) { NS_POLLS.set(rep.id, line0); return; }
  NS_POLLS.set(rep.id, line0);
  try { await nsPollRun(rep, label, tell); } finally { NS_POLLS.delete(rep.id); }
}
async function nsPollRun(rep, label, tell) {
  const start = Date.now(), here = location.hash.split("?")[0];
  for (;;) {
    const line = NS_POLLS.get(rep.id);
    if (location.hash.split("?")[0] !== here || !line.isConnected) return;   // left the page: stop asking
    let st;
    try { st = await api("/nessus/reports/" + rep.id); }
    catch (e) { if (e instanceof StaleRoute) return; line.replaceChildren(h("span", { class: "hd-failed small" }, label + ": " + e.message)); return; }
    if (st.state === "ready" || st.state === "downloaded") {
      const b = h("button", { type: "button", class: "btn" }, "Download " + (st.format === "nessus" ? ".nessus" : st.format.toUpperCase()));
      b.addEventListener("click", async () => {
        b.disabled = true; b.textContent = "Downloading…";
        try { await downloadFile("/nessus/reports/" + rep.id + "/download", "nessus-report." + st.format); b.disabled = false; b.textContent = "Download again"; tell(label + ": downloaded."); }
        catch (e) { tell(e.message, true); b.disabled = false; b.textContent = "Download again"; }
      });
      line.replaceChildren(h("span", null, label + ": the report is ready. "), b);
      if (st.state === "ready") b.click();                     // the first time, straight away
      return;
    }
    if (st.state === "failed") { line.replaceChildren(h("span", { class: "hd-failed small" }, label + ": " + (st.error || "Nessus could not build the report."))); return; }
    await new Promise(r => setTimeout(r, Date.now() - start < 60000 ? 2000 : 5000));
  }
}

async function nsReport(server, s, fmt, btn, box, tell) {
  btn.disabled = true;
  try {
    const rep = await apiPost("/nessus/reports", { server_id: server.id, scan_id: s.scan_id, format: fmt });
    rep.format = fmt;
    const line = nsReportLine(rep, s.name);
    box.prepend(line);
    nsPoll(rep, line, s.name, tell).finally(() => { btn.disabled = false; });
  } catch (e) { tell(s.name + ": " + e.message, true); btn.disabled = false; }
}

// Reports asked in the last hour and still being built: shown again, and followed
function nsReportsResume(reps, byId, scans, box, tell) {
  if (!can("operator")) return;
  for (const r of reps) {
    if (r.state !== "exporting" || Date.now() - Date.parse(r.requested_at) > 3600e3) continue;
    const sc = scans.find(x => x.server_id === r.server_id && x.scan_id === r.scan_id);
    const label = sc ? sc.name : "Scan " + r.scan_id;
    const line = nsReportLine(r, label);
    box.append(line);
    nsPoll(r, line, label, tell);
  }
}

/* ---- New scan / edit scan (where Nessus allows it) ---------------------- */

async function nsScanForm(page, server, scan, tell, reload) {
  if (!server) return;
  page.querySelectorAll(".ns-scanform").forEach(x => x.remove());
  const box = h("section", { class: "ns-scanform av-form", "aria-label": scan ? "Edit scan" : "New scan" },
    h("p", { class: "muted" }, "Reading the scan templates from " + server.name + "…"));
  const anchor = page.querySelector(".ns-servers");
  if (anchor) anchor.after(box); else page.prepend(box);
  box.scrollIntoView({ block: "start" });
  let ed;
  try { ed = await api("/nessus/servers/" + server.id + "/editor"); }
  catch (e) { box.replaceChildren(h("p", { class: "hd-failed" }, e.message)); return; }
  if (!ed.allowed) {
    const link = nsLink(server, scan && scan.scan_id);
    box.replaceChildren(h("h2", null, scan ? "Edit " + scan.name : "New scan"), h("p", null, ed.message || "Not allowed on this Nessus."),
      h("div", { class: "cm-actions" }, link ? h("a", { class: "btn", href: link, target: "_blank", rel: "noopener noreferrer" }, "Open in Nessus ↗") : null,
        h("button", { type: "button", class: "btn-quiet", on: { click: () => box.remove() } }, "Close")));
    setTimeout(() => reload().catch(() => {}), 500);
    return;
  }
  const msg = h("p", { class: "cm-meta", role: "status" });
  const tpl = h("select", { "aria-label": "Template", required: !scan },
    scan ? h("option", { value: "" }, "Keep the scan's template") : null,
    (ed.templates || []).map(t => h("option", { value: t.uuid }, t.title)));
  const basic = (ed.templates || []).find(t => t.name === "basic");
  if (!scan && basic) tpl.value = basic.uuid;
  const name = h("input", { type: "text", maxlength: "100", required: true, value: scan ? scan.name : "", placeholder: "Weekly – all servers" });
  const desc = h("input", { type: "text", maxlength: "300", placeholder: "Optional" });
  const folder = h("select", { "aria-label": "Folder" }, (ed.folders || []).map(x => h("option", { value: x.id }, x.name)));
  if (scan && scan.folder_id && (ed.folders || []).some(x => x.id === scan.folder_id)) folder.value = String(scan.folder_id);
  const targets = h("textarea", { rows: "3", maxlength: "40000", spellcheck: "false",
    placeholder: "Names, addresses or ranges, separated by commas or new lines (10.0.0.0/24, 10.0.1.1-10.0.1.20)" }, scan ? scan.targets || "" : "");
  const groupTicks = (ed.groups || []).map(g => { const b = h("input", { type: "checkbox", value: g }); return [b, h("label", { class: "cm-check" }, b, " " + g)]; });
  const sched = h("select", { "aria-label": "Schedule" }, [["ondemand", "On demand"], ["daily", "Every day"], ["weekly", "Every week"], ["monthly", "Every month"]]
    .map(([v, t]) => h("option", { value: v }, t)));
  const at = h("input", { type: "time", value: "02:00", "aria-label": "Start time" });
  const day = h("select", { "aria-label": "Day of the week" }, NS_DAYS.map(([v, t]) => h("option", { value: v }, t)));
  const dom = h("input", { type: "number", min: "1", max: "28", value: "1", "aria-label": "Day of the month" });
  if (scan && scan.schedule) {
    const m = /^(Daily|Weekly|Monthly)/.exec(scan.schedule), dd = /\(([A-Z]{2})/.exec(scan.schedule), tt = /at (\d\d:\d\d)/.exec(scan.schedule);
    if (m) sched.value = m[1].toLowerCase();
    if (dd && NS_DAYS.some(x => x[0] === dd[1])) day.value = dd[1];
    if (tt) at.value = tt[1];
    const md = /BYMONTHDAY=(\d{1,2})/.exec(scan.rrules || "");
    if (md && Number(md[1]) >= 1 && Number(md[1]) <= 28) dom.value = md[1];
  }
  const when = h("span", { class: "ns-when" });
  const showWhen = () => when.replaceChildren(...(sched.value === "ondemand" ? [] : [
    h("label", null, h("span", null, "At"), at),
    sched.value === "weekly" ? h("label", null, h("span", null, "On"), day) : null,
    sched.value === "monthly" ? h("label", null, h("span", null, "Day"), dom) : null].filter(Boolean)));
  sched.addEventListener("change", showWhen); showWhen();
  const now = h("input", { type: "checkbox" });
  const save = h("button", { type: "submit" }, scan ? "Save changes in Nessus" : "Create in Nessus");
  const form = h("form", { autocomplete: "off", on: { submit: async e => {
    e.preventDefault();
    const body = { name: name.value.trim(), targets: targets.value.trim() || null, groups: groupTicks.filter(([b]) => b.checked).map(([b]) => b.value),
      schedule: sched.value, template_uuid: tpl.value || null, launch_now: now.checked };
    if (desc.value.trim()) body.description = desc.value.trim();
    if (folder.value && (!scan || Number(folder.value) !== scan.folder_id)) body.folder_id = Number(folder.value);
    if (sched.value !== "ondemand") body.at = at.value;
    if (sched.value === "weekly") body.day = day.value;
    if (sched.value === "monthly") body.dom = Number(dom.value);
    if (scan && sched.value === "ondemand" && scan.schedule && scan.schedule !== "On demand"
        && !confirm("The scan runs " + scan.schedule + " now. Save it as on demand (no schedule)?")) return;
    save.disabled = true; msg.textContent = scan ? "Saving in Nessus…" : "Creating in Nessus…";
    try {
      const r = scan ? await apiSend("PUT", "/nessus/servers/" + server.id + "/scans/" + scan.scan_id, body)
        : await apiPost("/nessus/servers/" + server.id + "/scans", body);
      tell(r.message); box.remove(); setTimeout(() => reload().catch(() => {}), 1200);
    } catch (err) { msg.textContent = err.message; msg.classList.add("hd-failed"); save.disabled = false; }
  } } },
    h("h2", null, scan ? "Edit " + scan.name : "New scan on " + server.name),
    h("div", { class: "av-grid" },
      h("label", null, h("span", null, "Name"), name),
      h("label", null, h("span", null, "Template"), tpl),
      h("label", null, h("span", null, "Folder"), folder),
      h("label", null, h("span", null, "Description"), desc)),
    h("label", { class: "ns-wide" }, h("span", null, "Targets"), targets),
    groupTicks.length ? h("fieldset", { class: "ns-groups" }, h("legend", null, "And the servers of these patch groups"), groupTicks.map(x => x[1])) : null,
    h("div", { class: "av-grid ns-sched" }, h("label", null, h("span", null, "Schedule"), sched), when),
    scan ? null : h("label", { class: "cm-check" }, now, " Start it now"),
    h("p", { class: "muted small" }, "The scan is created with the template's own settings. Credentials and advanced settings are set in Nessus."),
    h("div", { class: "cm-actions" }, save, h("button", { type: "button", class: "btn-quiet", on: { click: () => box.remove() } }, "Cancel"), msg));
  box.replaceChildren(form);
  name.focus();
}

/* ---- Connecting a Nessus scanner (admins) ------------------------------- */

function nsServerForm(page, d, ed) {
  const msg = h("p", { class: "cm-meta", role: "status" });
  const result = h("div", { class: "av-test", role: "status", "aria-live": "polite" });
  const name = h("input", { type: "text", maxlength: "60", required: true, value: ed ? ed.name : "", placeholder: "Nessus, head office" });
  const url = h("input", { type: "url", maxlength: "300", required: true, value: ed ? ed.url : "", placeholder: "https://nessus.example.local:8834",
    autocomplete: "off", spellcheck: "false" });
  const ak = h("input", { type: "password", maxlength: "80", required: !ed, autocomplete: "new-password", spellcheck: "false",
    placeholder: ed ? "saved: leave blank to keep" : "Access key" });
  const sk = h("input", { type: "password", maxlength: "80", required: !ed, autocomplete: "new-password", spellcheck: "false",
    placeholder: ed ? "saved: leave blank to keep" : "Secret key" });
  const enabled = h("input", { type: "checkbox", checked: ed ? !!ed.enabled : true });
  let pinPending = null;
  const certBox = h("div", { class: "av-cert", "aria-live": "polite" });
  const unpin = ed && ed.pinned ? h("label", { class: "cm-check" }, h("input", { type: "checkbox" }), " Stop trusting this certificate") : null;
  const getCert = h("button", { type: "button", class: "btn-quiet", on: { click: async () => {
    getCert.disabled = true; pinPending = null;
    certBox.replaceChildren(h("p", { class: "muted small" }, "Reading the certificate (handshake only, nothing is sent)…"));
    try {
      const c = await apiPost("/admin/nessus/certificate", { url: url.value.trim() });
      const ok = h("input", { type: "checkbox" });
      ok.addEventListener("change", () => { pinPending = ok.checked ? c.sha256 : null; });
      certBox.replaceChildren(h("div", { class: "av-res " + (c.expired ? "bad" : "ok") },
        h("strong", null, c.self_signed ? "Self-signed certificate" : "Certificate"),
        h("dl", { class: "srv-kv" }, ...[["Issued to", c.subject], ["Issued by", c.issuer],
            ["Valid", fmtDate(c.not_before) + " to " + fmtDate(c.not_after) + (c.expired ? " (EXPIRED)" : "")],
            ["Publicly trusted", c.publicly_trusted ? "yes: no need to trust it by fingerprint" : "no: trust it by its fingerprint below"]]
          .map(([k, v]) => h("div", { class: "kv" }, h("dt", null, k), h("dd", null, v)))),
        h("p", { class: "small" }, "SHA-256 fingerprint"), h("p", { class: "mono small av-fp" }, c.sha256_text),
        h("p", { class: "muted small" }, "Compare it on the Nessus server before trusting it, for example: "
          + "openssl x509 -in /opt/nessus/com/nessus/CA/servercert.pem -noout -fingerprint -sha256 (Linux), "
          + "or the certificate's details in the browser when you open Nessus. It must be the same value."),
        h("label", { class: "cm-check" }, ok, " I have compared the fingerprint with the Nessus server: trust exactly this certificate")));
    } catch (err) { certBox.replaceChildren(h("p", { class: "hd-failed small" }, err.message)); }
    getCert.disabled = false;
  } } }, "Get certificate");
  const body = () => {
    const b = { name: name.value.trim(), url: url.value.trim(), enabled: enabled.checked };
    if (ak.value.trim()) b.access_key = ak.value.trim();
    if (sk.value.trim()) b.secret_key = sk.value.trim();
    if (pinPending) b.pin_sha256 = pinPending;
    else if (unpin && unpin.querySelector("input").checked) b.pin_sha256 = "";
    return b;
  };
  const showResult = r => result.replaceChildren(h("div", { class: "av-res " + (r.ok ? "ok" : "bad") },
    h("strong", null, r.ok ? "Connected" : "Not connected"), h("p", null, r.message),
    r.ok ? h("p", { class: "small" }, r.scan_control === false ? "This is " + r.product + ": PATCH-01 can read its scans, import results and download reports. "
        + "Starting, stopping and creating scans stays in Nessus (Tenable does not allow it from outside on this edition)."
      : r.scan_control ? "Every button works: launch, pause, stop, new scan, edit, import and reports."
      : "Whether scans can be started from here is checked the first time a button is used.") : null));
  const test = h("button", { type: "button", class: "btn-quiet", on: { click: async () => {
    test.disabled = true; result.replaceChildren(h("p", { class: "muted" }, "Signing in to Nessus and listing its scans…"));
    try { const b = body(); if (ed) b.id = ed.id; showResult(await apiPost("/admin/nessus/test", b)); }
    catch (err) { showResult({ ok: false, message: err.message || "Could not test." }); }
    test.disabled = false;
  } } }, "Test connection");
  const save = h("button", { type: "submit" }, ed ? "Save changes" : "Save");
  const form = h("form", { class: "av-form", autocomplete: "off", on: { submit: async e => {
    e.preventDefault();
    save.disabled = true; msg.textContent = "Checking the connection before saving…"; msg.classList.remove("hd-failed");
    try {
      const r = ed ? await apiSend("PUT", "/admin/nessus/" + ed.id, body()) : await apiPost("/admin/nessus", body());
      await drawNessus(page, r, new URLSearchParams());
    } catch (err) { msg.textContent = err.message || "Could not save."; msg.classList.add("hd-failed"); save.disabled = false; }
  } } },
    h("h2", null, ed ? "Edit " + ed.name : "Connect a Nessus scanner"),
    h("p", { class: "muted small" }, "In Nessus: your user menu › My Account › API Keys › Generate. Copy both keys here; they are encrypted on PATCH-01 "
      + "and never shown again. Generating new keys in Nessus stops the old ones."),
    h("div", { class: "av-grid" },
      h("label", null, h("span", null, "Name"), name),
      h("label", null, h("span", null, "Nessus address"), url),
      h("label", null, h("span", null, "Access key"), ak),
      h("label", null, h("span", null, "Secret key"), sk)),
    h("div", { class: "av-more" },
      h("p", { class: "small" }, h("strong", null, "Certificate. "), "Nessus uses its own self-signed certificate unless you replaced it. "
        + "Get it, compare the fingerprint with the Nessus server, and trust that exact certificate. Verification is never turned off."),
      ed && ed.pinned ? h("p", { class: "small" }, "Trusted now: " + (ed.pin_subject || "") + (ed.pin_not_after ? " · valid until " + fmtDate(ed.pin_not_after) : ""), unpin) : null,
      h("div", { class: "cm-actions" }, getCert), certBox),
    h("label", { class: "cm-check" }, enabled, " Read this scanner every 15 minutes"),
    h("div", { class: "cm-actions" }, test, save,
      ed ? h("button", { type: "button", class: "btn-quiet", on: { click: () => box.remove() } }, "Cancel") : null, msg),
    result,
    h("details", { class: "small ns-help" }, h("summary", null, "If it does not connect"),
      h("ul", null,
        h("li", null, "“refused the connection”: Nessus listens on 8834 by default; check the port and that nessusd is running."),
        h("li", null, "“did not answer” or a time-out: a firewall between PATCH-01 and Nessus blocks TCP 8834; open it from PATCH-01 to Nessus only."),
        h("li", null, "“different certificate”: Nessus's certificate changed; get it again, compare it and trust it."),
        h("li", null, "“refused the API keys (401)”: the keys were regenerated or the user is disabled; generate new keys and enter both."),
        h("li", null, "“API is not available”: this is Nessus Professional; reading, import and reports still work."))));
  const box = h("section", { class: "ns-setup" }, form);
  return box;
}
