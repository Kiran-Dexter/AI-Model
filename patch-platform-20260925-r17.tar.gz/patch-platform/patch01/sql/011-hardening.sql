-- ===========================================================================
-- PATCH-01 : schema 011 - hardening (OpenSCAP, CIS-aligned)
--
-- Applied after 010. Idempotent: safe to re-apply on every run.
--
-- Benchmark content is the SCAP Security Guide (ComplianceAsCode), one pinned
-- release served by PATCH-01 to every agent, so every server is judged by the
-- same rules. A release holds one data stream per product (rhel9, ol8,
-- ubuntu2204 ...); each has its own profiles and rules.
-- ===========================================================================

-- The agent may be asked to scan; adding the verb to the allow-list
ALTER TYPE agent_verb ADD VALUE IF NOT EXISTS 'run_hardening_scan';

-- ---------------------------------------------------------------------------
-- Content: one row per product data stream in an imported release
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hardening_content (
    content_version TEXT NOT NULL,              -- e.g. 0.1.76
    product         TEXT NOT NULL,              -- rhel9, ol8, ubuntu2204 ...
    file_name       TEXT NOT NULL,              -- ssg-rhel9-ds.xml
    sha256          TEXT NOT NULL,
    benchmark_title TEXT,
    benchmark_version TEXT,
    active          BOOLEAN NOT NULL DEFAULT FALSE,
    imported_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (content_version, product)
);

-- ---------------------------------------------------------------------------
-- Profiles in each data stream. level is set only for CIS server profiles:
-- l1 / l2. Other profiles (STIG, PCI-DSS) are kept but not offered as CIS.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hardening_profiles (
    content_version TEXT NOT NULL,
    product         TEXT NOT NULL,
    profile_id      TEXT NOT NULL,              -- xccdf_org.ssgproject.content_profile_cis_server_l1
    title           TEXT,
    level           TEXT,                       -- l1, l2 or NULL
    rule_count      INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (content_version, product, profile_id),
    FOREIGN KEY (content_version, product)
        REFERENCES hardening_content (content_version, product) ON DELETE CASCADE
);

-- ---------------------------------------------------------------------------
-- Rules, with what a person needs to act on a failure
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hardening_rules (
    content_version TEXT NOT NULL,
    product         TEXT NOT NULL,
    rule_id         TEXT NOT NULL,              -- xccdf_org.ssgproject.content_rule_sshd_disable_root_login
    title           TEXT,
    severity        TEXT,                       -- high, medium, low, unknown
    description     TEXT,
    rationale       TEXT,
    cis_ref         TEXT,                       -- CIS control number(s), e.g. 5.2.7
    fix_available   BOOLEAN NOT NULL DEFAULT FALSE,
    fix_script      TEXT,                       -- the vendor's shell remediation, for later increments
    risky           BOOLEAN NOT NULL DEFAULT FALSE,  -- SSH, PAM, firewall, sudo, audit, mounts
    PRIMARY KEY (content_version, product, rule_id),
    FOREIGN KEY (content_version, product)
        REFERENCES hardening_content (content_version, product) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_hrules_cis ON hardening_rules (product, cis_ref);

CREATE TABLE IF NOT EXISTS hardening_profile_rules (
    content_version TEXT NOT NULL,
    product         TEXT NOT NULL,
    profile_id      TEXT NOT NULL,
    rule_id         TEXT NOT NULL,
    PRIMARY KEY (content_version, product, profile_id, rule_id),
    FOREIGN KEY (content_version, product, profile_id)
        REFERENCES hardening_profiles (content_version, product, profile_id) ON DELETE CASCADE
);

-- ---------------------------------------------------------------------------
-- Scans. One per server per request; the agent fills it in.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hardening_scans (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    host_id         UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    content_version TEXT NOT NULL,
    product         TEXT NOT NULL,
    profile_id      TEXT NOT NULL,
    level           TEXT,                       -- l1, l2, custom
    state           TEXT NOT NULL DEFAULT 'queued',  -- queued, running, done, failed
    requested_by    TEXT,
    requested_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    started_at      TIMESTAMPTZ,
    finished_at     TIMESTAMPTZ,
    score           NUMERIC(5,2),               -- pass / (pass + fail), 0-100
    oscap_score     NUMERIC(6,2),               -- the scanner's own weighted score
    passed          INTEGER, failed INTEGER, not_applicable INTEGER,
    errors          INTEGER, other INTEGER,
    oscap_version   TEXT,
    evidence_path   TEXT,                       -- compressed ARF result, kept for audit
    evidence_sha256 TEXT,
    error           TEXT
);
CREATE INDEX IF NOT EXISTS idx_hscans_host ON hardening_scans (host_id, requested_at DESC);

CREATE TABLE IF NOT EXISTS hardening_results (
    scan_id   UUID NOT NULL REFERENCES hardening_scans(id) ON DELETE CASCADE,
    rule_id   TEXT NOT NULL,
    result    TEXT NOT NULL,                    -- pass, fail, notapplicable, notchecked, error, unknown, informational, notselected, fixed
    severity  TEXT,
    PRIMARY KEY (scan_id, rule_id)
);
CREATE INDEX IF NOT EXISTS idx_hresults_fail ON hardening_results (rule_id) WHERE result = 'fail';

-- ---------------------------------------------------------------------------
-- The latest finished scan per server and level: what the dashboard shows
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_hardening_latest AS
SELECT DISTINCT ON (s.host_id, s.level)
       s.*, h.hostname, h.os_id, h.os_version, h.host_group
  FROM hardening_scans s
  JOIN hosts h ON h.id = s.host_id
 WHERE s.state = 'done' AND h.status <> 'decommissioned'
 ORDER BY s.host_id, s.level, s.finished_at DESC;

INSERT INTO schema_version (version, description)
VALUES (11, 'hardening: SCAP content, profiles, rules, scans, results')
ON CONFLICT (version) DO NOTHING;
