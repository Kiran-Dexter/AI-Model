/* PATCH-01 hardening pages: CIS-aligned OpenSCAP results.
 * Uses the console's shared helpers from app.js (h, api, render, table ...).
 */
"use strict";

const HLEVELS = [["l1", "CIS Level 1 Server"], ["l2", "CIS Level 2 Server"], ["custom", "Custom (from a document)"]];
const HRESULT = {
  pass: ["Pass", "hr-pass"], fail: ["Fail", "hr-fail"], error: ["Error", "hr-error"],
  notapplicable: ["Not applicable", "hr-na"], notchecked: ["Not checked", "hr-na"],
  unknown: ["Unknown", "hr-na"], informational: ["Info", "hr-na"], fixed: ["Fixed", "hr-pass"],
};

function hLevel(params) {
  const l = params.get("level") || localStorage.getItem("patch01.hardening.level") || "l1";
  return ["l1", "l2"].includes(l) ? l : "l1";
}

function levelPicker(level, onChange) {
  const sel = h("select", { "aria-label": "Benchmark profile", class: "hd-level" },
    HLEVELS.map(([k, label]) => h("option", { value: k, selected: k === level, disabled: k === "custom" },
      label + (k === "custom" ? " \u2013 coming next" : ""))));
  sel.addEventListener("change", () => { localStorage.setItem("patch01.hardening.level", sel.value); onChange(sel.value); });
  return sel;
}

function scoreBadge(score) {
  if (score === null || score === undefined) return h("span", { class: "muted" }, "not scanned");
  const n = Number(score);
  const cls = n >= 85 ? "hd-good" : n >= 70 ? "hd-fair" : "hd-poor";
  return h("span", { class: "hd-score " + cls }, n.toFixed(n % 1 ? 1 : 0) + "%");
}

function scoreBar(score) {
  if (score === null || score === undefined) return h("span", { class: "muted" }, "\u2013");
  const n = Math.max(0, Math.min(100, Number(score)));
  const bar = h("span", { class: "hd-bar " + (n >= 85 ? "hd-good" : n >= 70 ? "hd-fair" : "hd-poor") },
    h("span", { class: "hd-bar-fill" }));
  bar.firstChild.style.width = n + "%";
  return h("span", { class: "hd-bar-cell" }, bar, scoreBadge(n));
}

function sevChip(sev) {
  const s = (sev || "unknown").toLowerCase();
  return h("span", { class: "hd-sev hd-sev-" + s }, s === "unknown" ? "\u2013" : s[0].toUpperCase() + s.slice(1));
}

function resultChip(r) {
  const [label, cls] = HRESULT[r] || [r, "hr-na"];
  return h("span", { class: "hd-res " + cls }, label);
}

function scanState(row) {
  if (row.last_state === "queued") return h("span", { class: "muted" }, "queued");
  if (row.last_state === "running") return h("span", { class: "hd-running" }, "scanning\u2026");
  if (row.last_state === "failed") return h("span", { class: "hd-failed", title: row.last_error || "" },
    "last scan failed: " + (row.last_error || "unknown").slice(0, 80));
  return row.finished_at ? timeAgo(row.finished_at) : h("span", { class: "muted" }, "never");
}

function trendSvg(points) {
  if (!points || points.length < 2) return null;
  const W = 260, H = 54, xs = points.map((_, i) => 6 + i * (W - 12) / (points.length - 1));
  // Scaled to the data's own range, padded, so a real improvement is visible
  const vals = points.map(p => Number(p.score));
  const lo = Math.max(0, Math.min(...vals) - 5), hi = Math.min(100, Math.max(...vals) + 5);
  const span = Math.max(1, hi - lo);
  const ys = vals.map(v => H - 6 - ((v - lo) / span) * (H - 12));
  const NS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("viewBox", "0 0 " + W + " " + H); svg.setAttribute("class", "hd-trend");
  svg.setAttribute("role", "img"); svg.setAttribute("aria-label", "Fleet score over the last 90 days");
  const path = document.createElementNS(NS, "path");
  path.setAttribute("d", xs.map((x, i) => (i ? "L" : "M") + x.toFixed(1) + "," + ys[i].toFixed(1)).join(""));
  svg.append(path);
  const dot = document.createElementNS(NS, "circle");
  dot.setAttribute("cx", xs[xs.length - 1]); dot.setAttribute("cy", ys[ys.length - 1]); dot.setAttribute("r", 3);
  svg.append(dot);
  return svg;
}

async function queueScans(level, hostIds, btn, onDone) {
  btn.disabled = true;
  const was = btn.textContent;
  btn.textContent = "Queuing\u2026";
  try {
    const r = await apiPost("/hardening/scans", { level, host_ids: hostIds || null });
    btn.textContent = r.queued.length + " queued" + (r.skipped.length ? ", " + r.skipped.length + " skipped" : "");
    if (r.skipped.length) btn.title = r.skipped.map(x => x.hostname + ": " + x.reason).join("\n");
    setTimeout(() => { btn.textContent = was; btn.disabled = false; onDone && onDone(); }, 2500);
  } catch (err) {
    btn.textContent = was; btn.disabled = false;
    alert(err.message);
  }
}

// ---- fleet page ----------------------------------------------------------
async function renderHardening(params) {
  setNav("hardening");
  const level = hLevel(params);
  const [sum, list] = await Promise.all([api("/hardening/summary?level=" + level), api("/hardening/hosts?level=" + level)]);
  const reload = l => { location.hash = "#/hardening?level=" + l; };
  const scanAll = can("operator")
    ? h("button", { type: "button", class: "btn", on: { click: e => queueScans(level, null, e.target, () => renderHardening(params)) } },
        "Scan all servers") : null;

  const content = sum.content || [];
  const noContent = !content.length;
  const head = h("div", { class: "page-head" },
    h("h1", { "data-cmd": "patchctl harden --report" }, "Hardening"),
    h("div", { class: "head-actions" }, levelPicker(level, reload), scanAll));

  if (noContent) {
    render(head, h("div", { class: "empty" },
      h("p", null, "No benchmark content has been imported yet."),
      h("p", { class: "muted" }, "On PATCH-01: ./scripts/phase8-hardening.sh --fetch <version>, with the release number from "
        + "the ComplianceAsCode releases page. Then update agents to 1.4.0 and install the OpenSCAP scanner on each server.")));
    return;
  }

  const levelsOf = new Map(content.map(c => [c.product, c.levels || []]));
  const cards = h("div", { class: "hd-cards" },
    h("div", { class: "hd-card hd-card-main" },
      h("div", { class: "hd-card-l" }, "Fleet score"),
      h("div", { class: "hd-card-n" }, sum.fleet_score === null ? "\u2013" : scoreBadge(sum.fleet_score)),
      h("div", { class: "muted small" }, "Average of the latest scan per server: passed rules out of passed plus failed."),
      trendSvg(sum.trend)),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Servers scanned"),
      h("div", { class: "hd-card-n" }, String(sum.scanned), h("span", { class: "muted" }, " / " + sum.servers)),
      sum.no_content ? h("div", { class: "muted small" }, sum.no_content + " have no " + level.toUpperCase() + " content for their OS") : null),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "By score"),
      h("div", { class: "hd-bands" },
        h("span", { class: "hd-good" }, sum.bands.good, h("small", null, "85%+")),
        h("span", { class: "hd-fair" }, sum.bands.fair, h("small", null, "70\u201384%")),
        h("span", { class: "hd-poor" }, sum.bands.poor, h("small", null, "under 70%")))),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Failed checks"),
      h("div", { class: "hd-card-n" }, sum.failed_rules_total),
      h("div", { class: "muted small" }, "across all servers' latest scans")));

  const contentLine = h("p", { class: "muted small" }, "Benchmark: SCAP Security Guide " + content[0].content_version + ". "
    + content.map(c => c.product + " (" + ((c.levels || []).map(x => x.toUpperCase()).join(", ") || "no CIS server profile") + ")").join(", ") + ".");

  const top = sum.top_failing || [];
  const topTable = top.length ? table([
    { label: "Rule", cell: r => h("a", { href: "#/hardening/rule/" + encodeURIComponent(r.rule_id) + "?level=" + level }, r.title || r.rule_id) },
    { label: "CIS", nowrap: true, cell: r => r.cis_ref || h("span", { class: "muted" }, "\u2013") },
    { label: "Severity", nowrap: true, cell: r => sevChip(r.severity) },
    { label: "Servers failing", num: true, cell: r => h("strong", null, r.servers) },
    { label: "", nowrap: true, cell: r => r.risky ? h("span", { class: "hd-risky", title: "Fixing this can cut off access or break services. Test on one server first." }, "risky to fix") : "" },
  ], top) : h("div", { class: "empty" }, h("p", null, "Nothing failing in the latest scans."));

  const hosts = list.hosts || [];
  const hostTable = table([
    { label: "Server", nowrap: true, cell: r => h("a", { href: "#/hardening/host/" + r.id + "?level=" + level }, r.hostname) },
    { label: "Benchmark", nowrap: true, cell: r => {
        if (!r.product) return h("span", { class: "muted" }, "no content for " + r.os_id + " " + r.os_version);
        const lv = levelsOf.get(r.product);
        if (!lv) return h("span", { class: "muted" }, r.product + ": not imported");
        return lv.includes(level) ? r.product : h("span", { class: "muted" }, r.product + ": no " + level.toUpperCase() + " profile");
      } },
    { label: "Score", nowrap: true, cell: r => scoreBar(r.score) },
    { label: "Failed", num: true, cell: r => r.failed === null || r.failed === undefined ? "" :
        h("span", null, r.failed, Number(r.high_failed) ? h("span", { class: "hd-high" }, " (" + r.high_failed + " high)") : null) },
    { label: "Last scan", nowrap: true, cell: r => scanState(r) },
    can("operator") ? { label: "", nowrap: true, cell: r => h("button", { type: "button", class: "btn-link",
        on: { click: e => { e.stopPropagation(); queueScans(level, [r.id], e.target, () => renderHardening(params)); } } }, "Scan") } : null,
  ].filter(Boolean), hosts);

  render(head,
    h("p", { class: "muted" }, "How each server's configuration compares with the CIS benchmark: SSH, logins, "
      + "auditing, file permissions, services and kernel settings. Scans are read-only; they change nothing."),
    cards, contentLine,
    h("h2", null, "Most widely failing rules"),
    h("p", { class: "muted small" }, "Fixing one of these lifts every server listed against it."),
    topTable,
    h("h2", null, "Servers (" + hosts.length + ")"),
    hostTable);

  // Refresh while scans are in flight
  if (hosts.some(r => r.last_state === "queued" || r.last_state === "running")) {
    setPageTimer(async () => {
      if (!location.hash.startsWith("#/hardening")) return clearPageTimer();
      const fresh = await api("/hardening/hosts?level=" + level);
      if (!fresh.hosts.some(r => r.last_state === "queued" || r.last_state === "running")) {
        clearPageTimer(); renderHardening(params);
      }
    }, 15000);
  }
}

// ---- one server ------------------------------------------------------------
async function renderHardeningHost(hostId, params) {
  setNav("hardening");
  const level = hLevel(params);
  const d = await api("/hardening/hosts/" + hostId + "?level=" + level);
  const s = d.scan;
  let filter = params.get("show") || "fail";
  const body = h("div");
  const counts = { fail: 0, pass: 0, na: 0, error: 0 };
  (d.results || []).forEach(r => {
    if (r.result === "fail") counts.fail++; else if (r.result === "pass") counts.pass++;
    else if (r.result === "error") counts.error++; else counts.na++;
  });
  const tabs = [["fail", "Failed", counts.fail], ["error", "Errors", counts.error], ["pass", "Passed", counts.pass],
                ["na", "Not applicable", counts.na], ["all", "All", (d.results || []).length]];
  const tabBtns = tabs.map(([k, label, n]) => h("button", { type: "button", "data-k": k,
    on: { click: () => { filter = k; paint(); } } }, label + " (" + n + ")"));

  function detail(r) {
    return h("div", { class: "hd-detail" },
      r.description ? h("p", null, r.description) : null,
      r.rationale ? h("p", null, h("strong", null, "Why it matters: "), r.rationale) : null,
      h("p", { class: "muted small" },
        (r.cis_ref ? "CIS " + r.cis_ref + " \u00b7 " : "") + "Rule " + r.rule_id.replace("xccdf_org.ssgproject.content_rule_", "")
        + " \u00b7 " + (r.fix_available ? "an automated fix exists" : "no automated fix; fix by hand")),
      r.risky && r.result === "fail" ? h("p", { class: "hd-risky-note" },
        "Changing this can lock out logins, cut network access or stop services. Test the fix on one server first.") : null);
  }

  function paint() {
    tabBtns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === filter)));
    const rows = (d.results || []).filter(r => filter === "all" || r.result === filter
      || (filter === "na" && !["pass", "fail", "error"].includes(r.result)));
    if (!rows.length) { body.replaceChildren(h("div", { class: "empty" }, h("p", null, "Nothing here."))); return; }
    const t = table([
      { label: "Result", nowrap: true, cell: r => resultChip(r.result) },
      { label: "Rule", cell: r => r.title || r.rule_id },
      { label: "CIS", nowrap: true, cell: r => r.cis_ref || "" },
      { label: "Severity", nowrap: true, cell: r => sevChip(r.severity) },
      { label: "", nowrap: true, cell: r => r.risky && r.result === "fail" ? h("span", { class: "hd-risky" }, "risky to fix") : "" },
    ], rows, { onRow: (r, tr) => {
      const next = tr.nextElementSibling;
      if (next && next.classList.contains("hd-detail-row")) { next.remove(); return; }
      const td = h("td", { colspan: "5" }, detail(r));
      tr.after(h("tr", { class: "hd-detail-row" }, td));
    } });
    body.replaceChildren(h("p", { class: "muted small" }, "Click a rule for what it checks and why."), t);
  }

  const hist = (d.history || []).slice().reverse().filter(x => x.state === "done");
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl harden --host " + d.host.hostname }, d.host.hostname),
      h("div", { class: "head-actions" },
        levelPicker(level, l => { location.hash = "#/hardening/host/" + hostId + "?level=" + l; }),
        can("operator") ? h("button", { type: "button", class: "btn",
          on: { click: e => queueScans(level, [hostId], e.target, () => renderHardeningHost(hostId, params)) } }, "Scan now") : null,
        h("a", { href: "#/hardening?level=" + level }, "All servers"))),
    s ? h("div", { class: "hd-cards" },
      h("div", { class: "hd-card hd-card-main" }, h("div", { class: "hd-card-l" }, "Score"),
        h("div", { class: "hd-card-n" }, scoreBadge(s.score)),
        h("div", { class: "muted small" }, s.passed + " passed, " + s.failed + " failed, " + s.not_applicable + " not applicable"),
        trendSvg(hist.map(x => ({ score: x.score })))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Scanned"),
        h("div", null, fmtDateTime(s.finished_at)), h("div", { class: "muted small" }, timeAgo(s.finished_at)
          + (s.requested_by ? ", requested by " + s.requested_by : ""))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Benchmark"),
        h("div", null, s.product + " \u00b7 SSG " + s.content_version),
        h("div", { class: "muted small" }, s.profile_id.replace("xccdf_org.ssgproject.content_profile_", "") + ", oscap " + (s.oscap_version || "?"))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Evidence"),
        h("div", { class: "muted small hd-hash", title: "SHA-256 of the full result file kept on PATCH-01" },
          "SHA-256 " + (s.evidence_sha256 || "").slice(0, 16) + "\u2026"),
        h("div", { class: "muted small" }, "Full result file kept for audit.")))
      : h("div", { class: "empty" }, h("p", null, "No completed " + level.toUpperCase() + " scan for this server yet."),
          (d.history || [])[0] && d.history[0].state === "failed" ? h("p", { class: "hd-failed" }, "Last attempt failed: " + d.history[0].error) : null),
    s ? h("div", { class: "filters", role: "group", "aria-label": "Show" }, tabBtns) : null,
    s ? body : null);
  if (s) paint();
}

// ---- one rule --------------------------------------------------------------
async function renderHardeningRule(ruleId, params) {
  setNav("hardening");
  const level = hLevel(params);
  const d = await api("/hardening/rules/" + encodeURIComponent(ruleId) + "?level=" + level);
  const r = d.rule;
  const failing = d.servers.filter(x => x.result === "fail");
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl harden --rule" }, r.title || r.rule_id),
      h("a", { href: "#/hardening?level=" + level }, "All rules")),
    h("div", { class: "hd-rule-meta" }, sevChip(r.severity), r.cis_ref ? h("span", null, "CIS " + r.cis_ref) : null,
      r.risky ? h("span", { class: "hd-risky" }, "risky to fix") : null,
      h("span", { class: "muted" }, r.fix_available ? "automated fix available" : "fix by hand")),
    r.description ? h("p", null, r.description) : null,
    r.rationale ? h("p", null, h("strong", null, "Why it matters: "), r.rationale) : null,
    r.risky ? h("p", { class: "hd-risky-note" }, "Fixing this can lock out logins, cut network access or stop services. "
      + "Test on one server first.") : null,
    h("h2", null, "Servers (" + failing.length + " failing of " + d.servers.length + ")"),
    d.servers.length ? table([
      { label: "Server", cell: x => h("a", { href: "#/hardening/host/" + x.host_id + "?level=" + level }, x.hostname) },
      { label: "Result", nowrap: true, cell: x => resultChip(x.result) },
      { label: "Benchmark", nowrap: true, cell: x => x.product },
      { label: "Scanned", nowrap: true, cell: x => timeAgo(x.finished_at) },
    ], d.servers) : h("div", { class: "empty" }, h("p", null, "No server's latest scan includes this rule.")));
}
