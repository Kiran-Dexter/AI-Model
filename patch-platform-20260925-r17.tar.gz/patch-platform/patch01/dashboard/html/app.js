/* PATCH-01 console
 *
 * No framework and no build step: this is served on an air-gapped network.
 *
 * Every value from the API is inserted as text, never as HTML. Advisory
 * titles come from vendor feeds and hostnames from agents, so none of it is
 * trusted. The h() helper below only ever uses textContent.
 */
"use strict";

/* ---- state labels, in the words an operator uses ------------------------ */

const STATES = {
  affected:             { label: "Needs patch",    desc: "Installed version is older than the fix" },
  fixed_pending_reboot: { label: "Needs reboot",   desc: "Fix installed, old version still running" },
  fixed_active:         { label: "Patched",        desc: "Fix installed and running" },
  unknown:              { label: "No recent data", desc: "Host has not reported in 24 hours" },
};
const STATE_ORDER = ["affected", "fixed_pending_reboot", "fixed_active", "unknown"];

const HOST_STATUS = {
  active: "Reporting",
  stale: "Silent",
  pending: "Enrolled, no data yet",
  decommissioned: "Retired",
};

const AGENT_STATES = {
  online:        { label: "Online",        desc: "Checked in recently" },
  offline:       { label: "Offline",       desc: "Missed several check-ins" },
  not_reporting: { label: "Not reporting", desc: "Silent for over 24 hours; its verdicts are unknown" },
  no_data:       { label: "No data yet",   desc: "Enrolled but never checked in" },
};
const AGENT_ORDER = ["online", "offline", "not_reporting", "no_data"];

function agentMark(state) {
  const a = AGENT_STATES[state] || { label: state || "unknown" };
  return h("span", { class: "agent ag-" + (state || "unknown") }, a.label);
}

function fmtUptime(sec) {
  if (sec === null || sec === undefined || sec === "") return h("span", { class: "muted" }, "not reported");
  const s = Number(sec);
  if (s < 3600) return Math.max(1, Math.round(s / 60)) + " min";
  if (s < 86400) {
    const hrs = Math.floor(s / 3600), m = Math.round((s % 3600) / 60);
    return hrs + " h" + (m ? " " + m + " min" : "");
  }
  const d = Math.floor(s / 86400), hrs = Math.round((s % 86400) / 3600);
  return d + (d === 1 ? " day" : " days") + (hrs ? " " + hrs + " h" : "");
}

/* ---- DOM helper: text only, never innerHTML ----------------------------- */

function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v === null || v === undefined || v === false) continue;
      if (k === "class") el.className = v;
      else if (k === "on") for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
      else if (k === "style") for (const [p, val] of Object.entries(v)) el.style.setProperty(p, val);
      else el.setAttribute(k, v === true ? "" : String(v));
    }
  }
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}

/* ---- formatting --------------------------------------------------------- */

function timeAgo(iso) {
  if (!iso) return "never";
  const t = new Date(iso).getTime();
  if (isNaN(t)) return "unknown";
  const s = Math.round((Date.now() - t) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return Math.round(s / 60) + " min ago";
  if (s < 86400) return Math.round(s / 3600) + " h ago";
  const d = Math.round(s / 86400);
  return d === 1 ? "1 day ago" : d + " days ago";
}

function fmtDateTime(iso) {
  if (!iso) return "never";
  const d = new Date(iso);
  if (isNaN(d)) return String(iso);
  return d.toLocaleString(undefined, {
    year: "numeric", month: "short", day: "numeric",
    hour: "2-digit", minute: "2-digit",
  });
}

function fmtDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d)) return String(iso);
  return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function osLabel(osId, ver) {
  const names = { rhel: "RHEL", ol: "Oracle Linux", ubuntu: "Ubuntu" };
  return (names[osId] || osId || "") + (ver ? " " + ver : "");
}

function count(n, state) {
  const v = Number(n) || 0;
  return h("span", { class: "count " + (v === 0 ? "zero" : "st-" + state) }, v);
}

/* A host that has stopped reporting has no trustworthy counts. Showing 0
   would read as "clean", which is the exact failure the unknown state
   exists to prevent. */
function hostCount(r, field, state) {
  if (r.host_status === "stale") return h("span", { class: "count unknown-val" }, "unknown");
  return count(r[field], state);
}

function stateMark(state) {
  const s = STATES[state] || { label: state };
  return h("span", { class: "state st-" + state }, s.label);
}

function sevLabel(sev) {
  if (!sev) return h("span", { class: "muted" }, "unrated");
  return h("span", { class: "sev sev-" + sev }, sev.charAt(0).toUpperCase() + sev.slice(1));
}

/* ---- auth --------------------------------------------------------------- */

const AUTH_KEY = "patch01.session";

/* The session: a token from /auth/login and who it belongs to. Kept for this
   browser tab only, and never the password itself. */
function getAuth() {
  try {
    const a = JSON.parse(sessionStorage.getItem(AUTH_KEY));
    return a && a.token && a.user ? a : null;
  } catch (e) { return null; }
}
function setSession(data) {
  sessionStorage.setItem(AUTH_KEY, JSON.stringify({ token: data.token, user: data.user }));
}
function clearAuth() { sessionStorage.removeItem(AUTH_KEY); }

const ROLE_RANK = { viewer: 0, operator: 1, admin: 2 };
function myRole() { const a = getAuth(); return a ? a.user.role : null; }
function can(needed) { return (ROLE_RANK[myRole()] ?? -1) >= ROLE_RANK[needed]; }

function authHeaders() {
  const a = getAuth();
  return a ? { Authorization: "Bearer " + a.token } : {};
}

class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

async function api(path) {
  const auth = getAuth();
  const res = await fetch("/api/v1" + path, {
    headers: {
      "Accept": "application/json",
      "X-Requested-With": "patch01-dashboard",
      ...authHeaders(),
    },
    cache: "no-store",
  });
  if (res.status === 401) {
    clearAuth();
    throw new ApiError(401, "Your session has ended. Sign in again.");
  }
  if (res.status === 403) {
    let d = ""; try { d = (await res.json()).detail || ""; } catch (e) { /* not JSON */ }
    if (d === "password_change_required") { renderChangePassword(true); throw new ApiError(403, d); }
    throw new ApiError(403, d || "You do not have permission for this.");
  }
  if (!res.ok) {
    let detail = "";
    try { detail = (await res.json()).detail || ""; } catch (e) { /* not JSON */ }
    throw new ApiError(res.status, detail || res.statusText);
  }
  return res.json();
}

async function apiPost(path, body) {
  const auth = getAuth();
  const res = await fetch("/api/v1" + path, {
    method: "POST",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "X-Requested-With": "patch01-dashboard",
      ...authHeaders(),
    },
    body: JSON.stringify(body || {}),
    cache: "no-store",
  });
  if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
  if (res.status === 403) {
    let d = ""; try { d = (await res.json()).detail || ""; } catch (e) { /* not JSON */ }
    if (d === "password_change_required") { renderChangePassword(true); throw new ApiError(403, d); }
    throw new ApiError(403, d || "You do not have permission for this.");
  }
  if (!res.ok) {
    let detail = "";
    try { detail = (await res.json()).detail || ""; } catch (e) { /* not JSON */ }
    throw new ApiError(res.status, detail || res.statusText);
  }
  return res.json();
}

/* ---- explanations from AI-01 --------------------------------------------- */

const EXPLAINABLE = new Set(["affected", "fixed_pending_reboot"]);

function explainError(err) {
  if (err.status === 429) return "AI-01 is busy with another explanation. Try again in a moment.";
  if (err.status === 503) return "AI-01 is not available: " + (err.message || "not configured or unreachable") + ".";
  if (err.status === 404) return "This verdict no longer exists. Refresh the page.";
  return "Could not get an explanation (HTTP " + (err.status || "error") + ").";
}

async function toggleExplain(btn, hostId, advisoryId, colspan) {
  const tr = btn.closest("tr");
  const next = tr.nextElementSibling;
  if (next && next.classList.contains("explain-row")) {
    next.remove();
    btn.setAttribute("aria-expanded", "false");
    btn.textContent = "Explain";
    return;
  }
  const body = h("div", { class: "explain", role: "status" },
    h("p", { class: "explain-wait" }, "Asking AI-01. On a CPU-only server this can take up to a minute."));
  const row = h("tr", { class: "explain-row" }, h("td", { colspan: String(colspan) }, body));
  tr.after(row);
  btn.setAttribute("aria-expanded", "true");
  btn.textContent = "Hide";
  btn.disabled = true;
  try {
    const r = await apiPost("/admin/hosts/" + encodeURIComponent(hostId) +
                            "/advisories/" + encodeURIComponent(advisoryId) + "/explain");
    const meta = r.cached
      ? "From cache"
      : "Generated in " + Math.round((r.duration_ms || 0) / 1000) + "s";
    body.replaceChildren(
      h("p", { class: "explain-note" },
        "AI explanation, advisory only. The verdict comes from the version check, not the model."),
      // Plain text only: the model's output is never treated as HTML
      h("p", { class: "explain-text" }, r.text),
      h("p", { class: "explain-meta" }, meta + (r.model ? ", " + r.model : "")),
    );
  } catch (err) {
    if (err.status === 401) return renderSignIn(err.message);
    body.replaceChildren(h("p", { class: "explain-error" }, explainError(err)));
  } finally {
    btn.disabled = false;
  }
}

/* ---- rendering scaffolding ---------------------------------------------- */

const view = () => document.getElementById("view");

function render(...nodes) {
  const v = view();
  // replaceChildren would turn null into the text "null"
  v.replaceChildren(...nodes.flat().filter(n => n !== null && n !== undefined && n !== false));
  v.focus({ preventScroll: true });
}

function showError(err) {
  if (err.status === 401) return renderSignIn(err.message);
  const hints = {
    502: ["The API container is not answering. Check it with ", h("code", null, "./scripts/phase3b-api.sh --check"), "."],
    503: ["The API is up but cannot reach the database. Check ", h("code", null, "./scripts/phase1b-data.sh --check"), "."],
    404: ["This endpoint does not exist. The API image may be older than the dashboard; rebuild it with ", h("code", null, "./scripts/phase3b-api.sh"), "."],
  };
  render(
    h("div", { class: "error", role: "alert" },
      h("h2", null, "Could not load this page"),
      h("p", null, "The API returned HTTP " + (err.status || "error") + (err.message ? ": " + err.message : ".")),
      hints[err.status] ? h("p", null, hints[err.status]) : null,
    )
  );
}

function setNav(name) {
  document.querySelectorAll("nav a").forEach(a => {
    if (a.dataset.nav === name) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
  });
}

function table(columns, rows, opts = {}) {
  const thead = h("thead", null, h("tr", null,
    columns.map(c => h("th", { class: c.num ? "num" : null, scope: "col" }, c.label))));
  const tbody = h("tbody", null, rows.map(r => {
    const tr = h("tr", { class: opts.onRow ? "clickable" : null },
      columns.map(c => h("td", { class: [c.num ? "num" : "", c.mono ? "mono" : "",
                                         c.nowrap ? "nowrap" : ""].join(" ").trim() || null },
        c.cell(r))));
    if (opts.onRow) {
      tr.addEventListener("click", e => {
        if (e.target.closest("a")) return;
        opts.onRow(r, tr);
      });
    }
    return tr;
  }));
  return h("div", { class: "table-wrap" }, h("table", null, thead, tbody));
}

/* ---- theme picker ------------------------------------------------------- */

function fillThemeOptions(sel) {
  const T = window.PatchTheme;
  const admin = can("admin");
  // Before sign-in the role is unknown: offer BOT-MODE only if it is active
  const signedIn = !!getAuth();
  const opts = T.options.filter(([v]) => v !== "hacker" || admin || (!signedIn && T.get() === "hacker"));
  sel.replaceChildren(...opts.map(([v, label]) => h("option", { value: v }, label)));
}

function fillThemeSelect(sel) {
  const T = window.PatchTheme;
  if (!T) return sel;
  fillThemeOptions(sel);
  sel.value = T.get();
  sel.addEventListener("change", () => {
    T.set(sel.value);
    // keep any other picker on the page in step
    document.querySelectorAll("select[data-theme-select]").forEach(o => { o.value = sel.value; });
  });
  sel.setAttribute("data-theme-select", "");
  return sel;
}

function themePicker() {
  const sel = fillThemeSelect(h("select", { "aria-label": "Theme" }));
  return h("label", { class: "theme-pick" }, h("span", null, "Theme"), sel);
}

/* ---- sign in ------------------------------------------------------------ */

function renderSignIn(message) {
  document.getElementById("top").hidden = true;
  const fab = document.getElementById("chat-open");
  if (fab) fab.hidden = true;
  const cp = document.getElementById("chat");
  if (cp) cp.hidden = true;
  const err = message ? h("div", { class: "error", role: "alert" }, message) : null;
  const user = h("input", { type: "text", name: "user", autocomplete: "username", required: true,
                            autocapitalize: "none", spellcheck: "false" });
  const pass = h("input", { type: "password", name: "pass", autocomplete: "current-password", required: true });
  const btn = h("button", { type: "submit" }, "Sign in");

  const form = h("form", {
    class: "signin",
    on: {
      submit: async e => {
        e.preventDefault();
        btn.disabled = true;
        btn.textContent = "Signing in";
        try {
          const res = await fetch("/api/v1/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json", "X-Requested-With": "patch01-dashboard" },
            body: JSON.stringify({ username: user.value.trim().toLowerCase(), password: pass.value }),
          });
          const data = await res.json().catch(() => ({}));
          if (!res.ok) throw new ApiError(res.status, data.detail || "Sign-in failed.");
          setSession(data);
          applyRoleTheme();
          if (data.user.must_change_password) return renderChangePassword(true);
          start();
        } catch (ex) {
          clearAuth();
          renderSignIn(ex.status === 401 ? ex.message
            : "Could not reach the API (HTTP " + (ex.status || "error") + ").");
        }
      },
    },
  },
    themePicker(),
    h("h1", { "data-cmd": "patchctl login" }, "PATCH-01"),
    h("p", { class: "muted" }, "Patch, vulnerability and VMware management."),
    err,
    h("label", null, h("span", null, "Username"), user),
    h("label", null, h("span", null, "Password"), pass),
    btn,
    h("p", { class: "muted small" }, "Ask an admin if you need an account."),
  );
  view().replaceChildren(form);
  user.focus();
}

function renderChangePassword(forced) {
  const a = getAuth();
  if (!a) return renderSignIn();
  if (forced) {
    document.getElementById("top").hidden = true;
    document.getElementById("chat-open").hidden = true;
  }
  const cur = h("input", { type: "password", autocomplete: "current-password", required: true });
  const nw = h("input", { type: "password", autocomplete: "new-password", required: true, minlength: "12" });
  const nw2 = h("input", { type: "password", autocomplete: "new-password", required: true });
  const err = h("p", { class: "explain-error", hidden: true });
  const btn = h("button", { type: "submit" }, "Change password");
  const form = h("form", { class: "signin", on: { submit: async e => {
    e.preventDefault(); err.hidden = true;
    if (nw.value !== nw2.value) { err.textContent = "The new passwords do not match."; err.hidden = false; return; }
    btn.disabled = true;
    try {
      await apiPost("/auth/password", { current_password: cur.value, new_password: nw.value });
      const s = getAuth(); s.user.must_change_password = false; setSession(s);
      start();
    } catch (ex) {
      err.textContent = ex.message; err.hidden = false; btn.disabled = false;
    }
  } } },
    h("h1", { "data-cmd": "passwd " + a.user.username }, "Choose a new password"),
    h("p", { class: "muted" }, forced
      ? "Your password was set by an admin. Choose your own before continuing."
      : "At least 12 characters, mixing at least three of: lowercase, uppercase, digits, symbols."),
    h("label", null, h("span", null, "Current password"), cur),
    h("label", null, h("span", null, "New password"), nw),
    h("label", null, h("span", null, "New password again"), nw2),
    err, btn,
    forced ? null : h("p", null, h("a", { href: "#/" }, "Cancel")));
  view().replaceChildren(form);
  cur.focus();
}

/* BOT-MODE is for admins. Viewers and operators get Light, Dark and System,
   and a stored BOT-MODE choice falls back to Dark for them. */
function applyRoleTheme() {
  const T = window.PatchTheme;
  if (!T) return;
  if (!can("admin") && T.get() === "hacker") T.set("dark");
  document.querySelectorAll("select[data-theme-select]").forEach(sel => {
    const v = sel.value;
    fillThemeOptions(sel);
    sel.value = [...sel.options].some(o => o.value === v) ? v : T.get();
  });
}

/* ---- overview ----------------------------------------------------------- */

async function renderOverview() {
  setNav("overview");
  const [fleet, app, comp] = await Promise.all([
    api("/admin/fleet-summary"),
    api("/admin/applicability/summary"),
    api("/admin/compliance"),
  ]);

  const t = fleet.totals || {};
  if (!t.hosts) {
    return render(
      h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl status" }, "Overview")),
      h("div", { class: "empty" },
        h("h2", null, "No servers have enrolled yet"),
        h("p", null, "Issue a token on PATCH-01 with ", h("code", null, "./scripts/phase3b-api.sh --token"),
          ", then run ", h("code", null, "install-agent.sh"), " on a server with that token."),
      )
    );
  }

  // The exposure strip
  const byState = {};
  (app.by_state || []).forEach(r => { byState[r.state] = r; });
  const total = STATE_ORDER.reduce((a, s) => a + (byState[s] ? Number(byState[s].n) : 0), 0);

  const segs = STATE_ORDER.map(s =>
    h("span", { class: "st-" + s + (byState[s] && Number(byState[s].n) ? " nonzero" : ""), title: STATES[s].label + ": " + (byState[s] ? byState[s].n : 0),
                style: { "flex-grow": "0" }, "data-grow": byState[s] ? byState[s].n : 0 }));
  const strip = h("div", { class: "strip", role: "img",
    "aria-label": STATE_ORDER.map(s => STATES[s].label + " " + (byState[s] ? byState[s].n : 0)).join(", ") },
    segs);

  const legend = h("div", { class: "legend" }, STATE_ORDER.map(s => {
    const r = byState[s];
    const hosts = r ? Number(r.hosts) : 0;
    return h("a", { class: "st-" + s, href: "#/advisories?state=" + s },
      h("span", { class: "n" }, r ? r.n : 0),
      h("span", { class: "l" }, STATES[s].label),
      h("span", { class: "d" }, hosts === 1 ? "on 1 server" : "on " + hosts + " servers"));
  }));

  const exposure = h("section", { class: "exposure", "aria-labelledby": "exp-h" },
    h("div", { class: "page-head" },
      h("h1", { id: "exp-h", "data-cmd": "patchctl exposure --fleet" }, "Fleet exposure"),
      h("span", { class: "muted small" },
        total ? "Checked " + timeAgo(app.computed_at) : "The CVE engine has not run yet")),
    total ? strip : h("div", { class: "empty" },
      h("p", null, "No verdicts yet. Run ", h("code", null, "./scripts/phase4-cve.sh"), " on PATCH-01.")),
    total ? legend : null,
  );

  // Grow the strip once, after it is in the document
  requestAnimationFrame(() => requestAnimationFrame(() => {
    segs.forEach(sg => { sg.style.flexGrow = sg.dataset.grow; });
  }));

  const attention = (comp.hosts || [])
    .filter(r => Number(r.affected) || Number(r.pending_reboot) || r.host_status === "stale")
    .slice(0, 10);

  const attnSection = h("section", null,
    h("h2", null, "Servers needing attention"),
    attention.length ? table([
      { label: "Server", cell: r => h("a", { href: "#/host/" + r.host_id }, r.hostname) },
      { label: "OS", cell: r => osLabel(r.os_id, r.os_version) },
      { label: "Needs patch", num: true, cell: r => hostCount(r, "affected", "affected") },
      { label: "Needs reboot", num: true, cell: r => hostCount(r, "pending_reboot", "fixed_pending_reboot") },
      { label: "Last report", cell: r => h("span", { class: r.host_status === "stale" ? "host-silent" : null },
          timeAgo(r.last_checkin)) },
    ], attention, { onRow: r => { location.hash = "#/host/" + r.host_id; } })
    : h("div", { class: "empty" }, h("p", null, "Every reporting server is fully patched.")),
  );

  const top = (app.top_affected || []).slice(0, 8);
  const advSection = h("section", null,
    h("h2", null, "Most urgent advisories"),
    top.length ? table([
      { label: "Advisory", nowrap: true, cell: r => h("a", { href: "#/advisories?state=affected" }, r.advisory_id) },
      { label: "Severity", cell: r => sevLabel(r.severity) },
      { label: "Servers", num: true, cell: r => count(r.hosts_affected, "affected") },
    ], top)
    : h("div", { class: "empty" }, h("p", null, "No outstanding advisories.")),
  );

  const osTable = h("section", null,
    h("h2", null, "Fleet by operating system"),
    table([
      { label: "OS", cell: r => osLabel(r.os_id, r.os_major) },
      { label: "Status", cell: r => HOST_STATUS[r.status] || r.status },
      { label: "Servers", num: true, cell: r => r.hosts },
      { label: "Awaiting reboot", num: true, cell: r => count(r.awaiting_reboot, "fixed_pending_reboot") },
    ], fleet.by_os || []),
  );

  const ag = {};
  (comp.hosts || []).forEach(r => { ag[r.agent_state] = (ag[r.agent_state] || 0) + 1; });
  const agentLine = h("a", { class: "agent-line", href: "#/agents" },
    AGENT_ORDER.filter(s => ag[s]).map(s =>
      h("span", { class: "agent-count" }, agentMark(s), " ", h("strong", null, ag[s]))));

  render(agentLine, exposure, h("div", { class: "two-col" }, attnSection, advSection), osTable);
}

/* ---- hosts -------------------------------------------------------------- */

async function renderHosts(params) {
  setNav("hosts");
  const comp = await api("/admin/compliance");
  const all = comp.hosts || [];
  let q = params.get("q") || "";
  let filter = params.get("show") || "all";

  const body = h("div");
  const search = h("input", { type: "search", placeholder: "Filter by server name", value: q,
    "aria-label": "Filter by server name" });

  const filters = [
    ["all", "All servers"],
    ["attention", "Needs attention"],
    ["silent", "Silent"],
  ];
  const btns = filters.map(([k, label]) =>
    h("button", { type: "button", "aria-pressed": String(k === filter), "data-k": k }, label));

  function draw() {
    const needle = q.toLowerCase();
    const rows = all.filter(r => {
      if (needle && !r.hostname.toLowerCase().includes(needle)) return false;
      if (filter === "attention") return Number(r.affected) || Number(r.pending_reboot);
      if (filter === "silent") return r.host_status === "stale";
      return true;
    });
    btns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === filter)));
    body.replaceChildren(rows.length ? table([
      { label: "Server", cell: r => h("a", { href: "#/host/" + r.host_id }, r.hostname) },
      { label: "OS", cell: r => osLabel(r.os_id, r.os_version) },
      { label: "Agent", nowrap: true, cell: r => agentMark(r.agent_state) },
      { label: "Running kernel", mono: true, cell: r => r.kernel_running || "" },
      { label: "Needs patch", num: true, cell: r => hostCount(r, "affected", "affected") },
      { label: "Needs reboot", num: true, cell: r => hostCount(r, "pending_reboot", "fixed_pending_reboot") },
      { label: "Patched", num: true, cell: r => r.host_status === "stale" ? h("span", { class: "count unknown-val" }, "unknown") : r.remediated },
      { label: "Last report", cell: r => timeAgo(r.last_checkin) },
    ], rows, { onRow: r => { location.hash = "#/host/" + r.host_id; } })
    : h("div", { class: "empty" }, h("p", null,
        all.length ? "No servers match this filter." : "No servers have enrolled yet.")));
  }

  search.addEventListener("input", () => { q = search.value; draw(); });
  btns.forEach(b => b.addEventListener("click", () => { filter = b.dataset.k; draw(); }));

  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl servers ls" }, "Servers"),
      h("span", { class: "muted small" }, all.length + (all.length === 1 ? " server" : " servers"))),
    h("div", { class: "controls" }, search, h("div", { class: "filters", role: "group", "aria-label": "Show" }, btns)),
    body,
  );
  draw();
}

/* ---- host detail -------------------------------------------------------- */
/*
 * Two panes: the advisory list on the left stays still, and the selected
 * advisory's details and explanation open on the right. Nothing in the list
 * moves when an explanation loads. On narrow screens the panel becomes a
 * sheet over the bottom of the page.
 */

const explainCache = new Map();   // advisory id -> result, for this page view

function wideScreen() { return window.matchMedia("(min-width: 1100px)").matches; }

async function renderHost(id, params) {
  setNav("hosts");
  const [detail, advs, vmres] = await Promise.all([
    api("/admin/hosts/" + encodeURIComponent(id)),
    api("/admin/hosts/" + encodeURIComponent(id) + "/advisories"),
    api("/admin/hosts/" + encodeURIComponent(id) + "/vm").catch(() => null),
  ]);
  const host = detail.host;
  const rows = advs.advisories || [];
  const vm = vmres && vmres.vm;
  const oldDays = (vmres && vmres.snapshot_old_days) || 7;
  explainCache.clear();

  const counts = {};
  rows.forEach(r => { counts[r.state] = (counts[r.state] || 0) + 1; });
  let show = params.get("state") || (counts.affected ? "affected"
    : counts.fixed_pending_reboot ? "fixed_pending_reboot" : "all");
  let selected = null;

  /* -- summary line: the four facts that matter, reboot folded in -------- */
  const stale = host.status === "stale";
  const kernelDiffers = host.kernel_latest && host.kernel_running &&
    !host.kernel_running.startsWith(host.kernel_latest.replace(/\.(x86_64|aarch64)$/, ""));
  const summary = h("div", { class: "host-summary" },
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "OS"),
      osLabel(host.os_id, host.os_version) + " " + (host.arch || "")),
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Running"),
      h("span", { class: "mono" }, host.kernel_running || "unknown")),
    h("span", { class: "hs-item" + (stale ? " host-silent" : "") }, h("span", { class: "hs-k" }, "Reported"),
      timeAgo(host.last_checkin)),
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Up"),
      host.boot_time ? fmtUptime((Date.now() - new Date(host.boot_time).getTime()) / 1000) : fmtUptime(null)),
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Packages"), detail.package_count),
    vm ? h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "VM"),
           h("a", { href: "#/vmware?view=linux" }, vm.name),
           vm.cluster ? h("span", { class: "muted" }, " on " + vm.cluster) : null) : null,
  );

  const alerts = [];
  if (host.reboot_required) {
    alerts.push(h("div", { class: "hs-alert st-fixed_pending_reboot" },
      h("strong", null, "Needs reboot"),
      kernelDiffers
        ? h("span", null, " to run the installed kernel ", h("span", { class: "mono" }, host.kernel_latest))
        : h("span", null, host.reboot_reason ? ": " + host.reboot_reason : ""),
    ));
  }
  if (vm && vm.snapshot_count > 0) {
    const age = daysSince(vm.oldest_snapshot_at);
    const oldOnes = age !== null && age >= oldDays;
    alerts.push(h("div", { class: "hs-alert " + (oldOnes ? "vm-alert-old" : "vm-alert") },
      h("strong", null, vm.snapshot_count + (vm.snapshot_count === 1 ? " VM snapshot" : " VM snapshots")),
      h("span", null, ", oldest " + ageLabel(age) +
        (oldOnes ? ". Old snapshots grow and slow the VM; remove them in vCenter once they are no longer needed." : ".")),
    ));
  }
  if (stale) {
    alerts.push(h("div", { class: "hs-alert st-unknown" },
      h("strong", null, "Not reporting"),
      h("span", null, " since " + fmtDateTime(host.last_checkin) +
        ". Verdicts are shown as no recent data until it checks in."),
    ));
  }

  const more = h("details", { class: "host-more" },
    h("summary", null, "Details"),
    h("dl", { class: "facts" }, [
      ["Newest installed kernel", h("span", { class: "mono" }, host.kernel_latest || "unknown")],
      ["Last report", fmtDateTime(host.last_checkin)],
      ["Last inventory", fmtDateTime(host.last_inventory)],
      ["Status", HOST_STATUS[host.status] || host.status],
      ["Host group", host.host_group || "default"],
      ["Agent", host.agent_version || "unknown"],
      ["Enrolled", fmtDate(host.enrolled_at)],
    ].concat(vm ? [
      ["vCenter", vm.vcenter],
      ["ESXi host", vm.esxi_host || "unknown"],
      ["Cluster", vm.cluster || "none"],
      ["VM size", (vm.num_cpu || "?") + " vCPU, " + (vm.memory_mb ? Math.round(vm.memory_mb / 1024) + " GB" : "?")],
      ["VMware Tools", toolsLabel(vm.tools_running)],
      ["Linked by", MATCH_LABEL[vm.match_method] || vm.match_method || "unknown"],
    ] : []).map(([k, v]) => h("div", null, h("dt", null, k), h("dd", null, v)))),
  );

  /* -- filters ------------------------------------------------------------- */
  const filterDefs = [["all", "All (" + rows.length + ")", null]].concat(
    STATE_ORDER.filter(s => counts[s]).map(s => [s, STATES[s].label + " (" + counts[s] + ")", s]));
  const btns = filterDefs.map(([k, label, st]) =>
    h("button", { type: "button", class: st ? "st-" + st : null, "data-k": k,
                  "aria-pressed": String(k === show) }, label));

  /* -- list and panel ------------------------------------------------------ */
  const listBox = h("div", { class: "pane-list" });
  const panel = h("aside", { class: "pane-detail", "aria-live": "polite", "aria-label": "Selected advisory" });
  const sheetClose = () => { panel.classList.remove("open"); document.body.classList.remove("sheet-open"); };

  function cveList(r) {
    const c = r.cves || [];
    if (!c.length) return h("span", { class: "muted" }, "none");
    return c[0] + (c.length > 1 ? " +" + (c.length - 1) : "");
  }

  function drawPanel() {
    if (!selected) {
      panel.replaceChildren(h("p", { class: "pane-empty" },
        rows.length ? "Select an advisory to see its details and an explanation."
                    : "No advisories apply to this server."));
      return;
    }
    const r = selected;
    const cached = explainCache.get(r.advisory_id);
    const explainBox = h("div", { class: "pd-explain" });

    const fill = res => {
      explainBox.replaceChildren(
        h("p", { class: "explain-note" }, "AI explanation, advisory only. The verdict comes from the version check."),
        h("p", { class: "explain-text" }, res.text),
        h("p", { class: "explain-meta" },
          (res.cached ? "From cache" : "Generated in " + Math.round((res.duration_ms || 0) / 1000) + "s") +
          (res.model ? ", " + res.model : "")));
    };

    if (cached) fill(cached);
    else if (EXPLAINABLE.has(r.state) && can("operator")) {
      const b = h("button", { type: "button", class: "explain-btn" }, "Explain with AI-01");
      b.addEventListener("click", async () => {
        b.disabled = true;
        explainBox.replaceChildren(h("p", { class: "explain-wait" },
          "Asking AI-01. On a CPU-only server this can take up to a minute."));
        try {
          const res = await apiPost("/admin/hosts/" + encodeURIComponent(id) +
                                    "/advisories/" + encodeURIComponent(r.advisory_id) + "/explain");
          explainCache.set(r.advisory_id, res);
          if (selected === r) fill(res);
        } catch (err) {
          if (err.status === 401) return renderSignIn(err.message);
          explainBox.replaceChildren(h("p", { class: "explain-error" }, explainError(err)), b);
          b.disabled = false;
        }
      });
      explainBox.replaceChildren(b);
    }

    const cveBox = h("div", { class: "pd-cvedetail" });
    if ((r.cves || []).length) {
      const btn = h("button", { type: "button", class: "explain-btn" },
        "CVE details (" + r.cves.length + ")");
      btn.addEventListener("click", async () => {
        btn.disabled = true;
        cveBox.replaceChildren(h("p", { class: "muted" }, "Loading"));
        try {
          const res = await api("/admin/advisories/" + encodeURIComponent(r.advisory_id) + "/cves");
          const items = (res.cves || []).map(cveBlock);
          cveBox.replaceChildren(h("h3", { class: "pd-sub" }, "Published CVE data"), ...items);
        } catch (err) {
          if (err.status === 401) return renderSignIn(err.message);
          cveBox.replaceChildren(h("p", { class: "explain-error" },
            err.status === 404 ? "The API is older than this feature; rebuild it."
                               : "Could not load CVE data (HTTP " + err.status + ")."));
          btn.disabled = false;
        }
      });
      cveBox.replaceChildren(btn);
    }

    panel.replaceChildren(
      h("div", { class: "pd-head" },
        h("h2", null, r.advisory_id),
        h("button", { type: "button", class: "pd-close", "aria-label": "Close", on: { click: sheetClose } }, "Close")),
      h("div", { class: "pd-badges" }, stateMark(r.state), sevLabel(r.severity)),
      r.title ? h("p", { class: "pd-title" }, r.title) : null,
      h("dl", { class: "pd-facts" },
        h("div", null, h("dt", null, "Package"), h("dd", null, r.package_name)),
        h("div", null, h("dt", null, "Installed"),
          h("dd", { class: "mono" + (r.state === "affected" ? " ver-old" : "") }, r.installed_evr)),
        h("div", null, h("dt", null, "Fixed in"),
          h("dd", { class: "mono" + (r.state === "affected" ? " ver-new" : "") }, r.fixed_evr)),
        h("div", null, h("dt", null, "CVEs"),
          // Each ID is unbreakable; lines wrap only between IDs. A browser
          // otherwise breaks at the hyphens inside CVE-2026-31338.
          h("dd", { class: "pd-cves" }, (r.cves || []).length
            ? (r.cves || []).flatMap((c, i) => [i ? ", " : null, h("span", { class: "cve" }, c)])
            : "none listed")),
        r.max_cvss !== null && r.max_cvss !== undefined
          ? h("div", null, h("dt", null, "Worst CVSS"),
              h("dd", null, cvssCell(r.max_cvss), r.any_kev ? " " : null,
                r.any_kev ? kevBadge() : null)) : null,
        r.reason ? h("div", null, h("dt", null, "Why"), h("dd", null, r.reason)) : null,
      ),
      cveBox,
      explainBox,
    );
  }

  function select(r, tr) {
    selected = r;
    listBox.querySelectorAll("tr.selected").forEach(x => x.classList.remove("selected"));
    if (tr) tr.classList.add("selected");
    drawPanel();
    if (!wideScreen()) {
      panel.classList.add("open");
      document.body.classList.add("sheet-open");
    }
  }

  function draw() {
    btns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === show)));
    const list = show === "all" ? rows : rows.filter(r => r.state === show);
    if (!list.length) {
      listBox.replaceChildren(h("div", { class: "empty" }, h("p", null,
        rows.length ? "Nothing in this category." :
        "No advisories apply to this server yet. If it has just enrolled, run ./scripts/phase4-cve.sh --compute on PATCH-01.")));
      return;
    }
    const tbl = table([
      { label: "State", nowrap: true, cell: r => stateMark(r.state) },
      { label: "Advisory", nowrap: true, cell: r => [r.advisory_id, r.any_kev ? " " : null,
          r.any_kev ? kevBadge() : null] },
      // CVSS replaces the vendor severity here: it carries more information
      // and the vendor rating is shown in the panel.
      { label: "CVSS", num: true, nowrap: true, cell: r => cvssCell(r.max_cvss) },
      { label: "Package", nowrap: true, cell: r => r.package_name },
      { label: "Installed", mono: true, cell: r =>
          h("span", { class: r.state === "affected" ? "ver-old" : null }, r.installed_evr) },
      { label: "Fixed in", mono: true, cell: r =>
          h("span", { class: r.state === "affected" ? "ver-new" : null }, r.fixed_evr) },
    ], list, { onRow: r => {} });   // CVEs are listed in full in the panel
    // Row selection needs the <tr>, so wire it here rather than via onRow
    tbl.querySelectorAll("tbody tr").forEach((tr, i) => {
      const r = list[i];
      tr.tabIndex = 0;
      tr.setAttribute("aria-label", r.advisory_id + ", " + (STATES[r.state] || {}).label);
      const pick = () => select(r, tr);
      tr.addEventListener("click", pick);
      tr.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); pick(); } });
      if (selected && selected.advisory_id === r.advisory_id) tr.classList.add("selected");
    });
    listBox.replaceChildren(tbl);

    // On a wide screen, open the first item so the panel is never idle
    if (wideScreen() && (!selected || !list.includes(selected))) {
      select(list[0], tbl.querySelector("tbody tr"));
    }
  }
  btns.forEach(b => b.addEventListener("click", () => { show = b.dataset.k; draw(); }));

  const outstanding = (counts.affected || 0);
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl host show " + host.hostname }, host.hostname),
      h("span", { class: "head-actions" },
        can("operator") && outstanding
          ? h("a", { class: "btn", href: "#/changes/new?kind=patch&hosts=" + encodeURIComponent(host.id) },
              "Patch this server") : null,
        h("a", { href: "#/hosts", class: "small" }, "All servers"))),
    summary,
    alerts,
    more,
    h("div", { class: "controls" }, h("div", { class: "filters", role: "group", "aria-label": "Show" }, btns)),
    h("div", { class: "panes" }, listBox, panel),
  );
  draw();
  drawPanel();
}

/* ---- agents ------------------------------------------------------------- */

async function renderAgents(params) {
  setNav("agents");
  const res = await api("/admin/agents");
  const all = res.agents || [];
  const by = res.by_state || {};
  let show = params.get("state") || "all";

  const tiles = h("div", { class: "agent-tiles" }, AGENT_ORDER.map(s =>
    h("button", { type: "button", class: "agent-tile ag-" + s, "data-k": s,
                  "aria-pressed": String(show === s) },
      h("span", { class: "at-n" }, by[s] || 0),
      h("span", { class: "at-l" }, AGENT_STATES[s].label),
      h("span", { class: "at-d" }, AGENT_STATES[s].desc))));

  // Agents older than 1.1.0 do not report boot time
  const old = all.filter(r => !r.agent_version || r.agent_version < "1.1.0").length;
  const verLine = h("p", { class: "muted small" },
    "Agent versions: " + (res.versions || []).map(v => v.version + " on " + v.n).join(", ") +
    ". Online means a check-in within the last " + res.online_minutes + " minutes.");
  const notice = old ? h("div", { class: "hs-alert st-unknown" },
    h("strong", null, old + (old === 1 ? " server runs" : " servers run") + " an agent older than 1.1.0"),
    h("span", null, ", which does not report uptime. Re-run install-agent.sh on them to update.")) : null;

  const body = h("div");
  const tileBtns = tiles.querySelectorAll("button");
  function draw() {
    tileBtns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === show)));
    const rows = show === "all" ? all : all.filter(r => r.agent_state === show);
    body.replaceChildren(rows.length ? table([
      { label: "Server", nowrap: true, cell: r => h("a", { href: "#/host/" + r.host_id }, r.hostname) },
      { label: "Agent", nowrap: true, cell: r => agentMark(r.agent_state) },
      { label: "Last seen", nowrap: true, cell: r => timeAgo(r.last_checkin) },
      { label: "Uptime", nowrap: true, cell: r => fmtUptime(r.uptime_seconds) },
      { label: "Booted", nowrap: true, cell: r => r.boot_time ? fmtDateTime(r.boot_time) : "" },
      { label: "Version", nowrap: true, cell: r => r.agent_version || "unknown" },
      { label: "Address", mono: true, cell: r => r.agent_ip || "" },
      { label: "OS", nowrap: true, cell: r => osLabel(r.os_id, r.os_version) },
    ], rows, { onRow: r => { location.hash = "#/host/" + r.host_id; } })
    : h("div", { class: "empty" }, h("p", null,
        all.length ? "No agents in this state." : "No servers have enrolled yet.")));
  }
  tileBtns.forEach(b => b.addEventListener("click", () => {
    show = (show === b.dataset.k) ? "all" : b.dataset.k;   // click again to clear
    draw();
  }));

  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl agents status" }, "Agents"),
      h("span", { class: "muted small" }, all.length + (all.length === 1 ? " agent" : " agents"))),
    tiles, verLine, notice, body,
  );
  draw();
}

/* ---- CVE facts ---------------------------------------------------------- */

const AV_WORDS = { NETWORK: "over the network", ADJACENT_NETWORK: "from the local network",
                   LOCAL: "local access", PHYSICAL: "physical access" };
const PR_WORDS = { NONE: "no login", LOW: "user login", HIGH: "admin login" };

function cvssCell(score, severity) {
  if (score === null || score === undefined) return h("span", { class: "muted" }, "-");
  return h("span", { class: "cvss", title: (severity || "").toLowerCase() }, Number(score).toFixed(1));
}

/* "Exploited" is deliberately not red or amber: those mean patch states.
   High-contrast inverse type makes it stand out without borrowing a meaning. */
function kevBadge(extra) {
  return h("span", { class: "kev", title: "Listed in CISA's Known Exploited Vulnerabilities catalogue" },
    "Exploited" + (extra ? " " + extra : ""));
}

function pctLabel(e) {
  if (e === null || e === undefined) return null;
  const v = Number(e) * 100;
  return v >= 10 ? Math.round(v) + "%" : v >= 1 ? v.toFixed(1) + "%" : "<1%";
}

function reachLine(c) {
  const bits = [];
  if (c.attack_vector) bits.push(AV_WORDS[c.attack_vector] || c.attack_vector.toLowerCase());
  if (c.privileges_required) bits.push(PR_WORDS[c.privileges_required] || c.privileges_required.toLowerCase());
  if ((c.user_interaction || "") === "REQUIRED") bits.push("needs a user action");
  if (c.attack_complexity) bits.push((c.attack_complexity || "").toLowerCase() + " complexity");
  return bits.join(", ");
}

function cveBlock(c) {
  if (!c.nvd_fetched_at && !c.cvss_score) {
    return h("div", { class: "cve-item" },
      h("div", { class: "cve-head" }, h("span", { class: "cve-id" }, c.cve_id)),
      h("p", { class: "muted small" }, c.fetch_error
        ? "No published data: " + c.fetch_error
        : "Published data not collected yet. Run ./scripts/phase4-cve.sh --intel on PATCH-01."));
  }
  const pct = pctLabel(c.epss);
  return h("div", { class: "cve-item" },
    h("div", { class: "cve-head" },
      h("span", { class: "cve-id" }, c.cve_id),
      cvssCell(c.cvss_score, c.cvss_severity),
      c.kev ? kevBadge(c.kev_ransomware === "Known" ? "and used in ransomware" : "") : null),
    c.attack_class ? h("p", { class: "cve-class" }, c.attack_class) : null,
    reachLine(c) ? h("p", { class: "cve-reach" }, reachLine(c)) : null,
    pct ? h("p", { class: "cve-epss" }, pct + " chance of exploitation in the next 30 days") : null,
    c.description ? h("p", { class: "cve-desc" }, c.description) : null,
    h("p", { class: "cve-src" },
      [c.cvss_version ? "CVSS " + c.cvss_version : null,
       c.cvss_source ? "scored by " + c.cvss_source : null,
       c.rh_severity ? "Red Hat: " + c.rh_severity : null,
       c.attack_class_basis ? "attack type from " + c.attack_class_basis : null,
      ].filter(Boolean).join(" | ")),
  );
}

/* ---- CVE assessment ----------------------------------------------------- */

const ASSESS_STATUS = {
  affected:       { label: "Needs patch",    desc: "At least one server needs the fix" },
  pending_reboot: { label: "Needs reboot",   desc: "Installed everywhere, a reboot is due" },
  patched:        { label: "Patched",        desc: "Every server with the package is fixed" },
  unknown:        { label: "Unknown",        desc: "Only servers with stale inventory involved" },
  not_applicable: { label: "Not applicable", desc: "We hold an advisory, but no server has the package" },
  no_vendor_data: { label: "Cannot assess",  desc: "No advisory in the mirrors mentions this CVE" },
};
const ASSESS_ORDER = ["affected", "pending_reboot", "unknown", "no_vendor_data",
                      "patched", "not_applicable"];

function assessMark(st) {
  const a = ASSESS_STATUS[st] || { label: st };
  const cls = { affected: "st-affected", pending_reboot: "st-fixed_pending_reboot",
                patched: "st-fixed_active", unknown: "st-unknown" }[st] || "st-plain";
  return h("span", { class: "state " + cls, title: (ASSESS_STATUS[st] || {}).desc || "" }, a.label);
}

async function downloadCsv(id, name) {
  const auth = getAuth();
  const res = await fetch("/api/v1/admin/assessments/" + encodeURIComponent(id) + "/export.csv", {
    headers: { "X-Requested-With": "patch01-dashboard",
               ...authHeaders() },
  });
  if (!res.ok) throw new ApiError(res.status, res.statusText);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = h("a", { href: url, download: (name || "assessment").replace(/[^A-Za-z0-9_-]+/g, "-") + ".csv" });
  document.body.append(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}

const EXPOSURE = {
  affected:             { label: "Affected",             cls: "st-affected",             desc: "Confirmed by a version check" },
  potentially_affected: { label: "Possibly affected",    cls: "st-fixed_pending_reboot", desc: "A matching product was found; its exact patch level could not be compared" },
  pending_reboot:       { label: "Needs reboot",         cls: "st-fixed_pending_reboot", desc: "Fixed, awaiting a reboot" },
  patched:              { label: "Patched",              cls: "st-fixed_active",         desc: "Found and already fixed" },
  not_affected:         { label: "Not affected",         cls: "st-fixed_active",         desc: "No server has the vulnerable package" },
  not_tracked:          { label: "Not in our inventory", cls: "st-unknown",              desc: "Network devices or firmware: check with their owners" },
  not_found:            { label: "Not found",            cls: "st-plain",                desc: "Nothing matching is in the inventory" },
};
const EXPOSURE_ORDER = ["affected", "potentially_affected", "pending_reboot", "not_tracked",
                        "not_found", "patched", "not_affected"];
const CERTAINTY = { confirmed: "confirmed", in_range: "version in affected range",
                    release_match: "release matches, build not compared",
                    present: "installed, version not comparable", not_tracked: "not tracked" };

function exposureOf(i) {
  if (i.exposure) return i.exposure;
  // Before enrichment: the package verdict only
  return { affected: "affected", pending_reboot: "pending_reboot", patched: "patched",
           not_applicable: "not_affected" }[i.status] || "not_found";
}
function exposureMark(i) {
  const e = EXPOSURE[exposureOf(i)] || { label: i.status, cls: "st-plain" };
  return h("span", { class: "state " + e.cls, title: e.desc || "" }, e.label);
}

function assessResult(res) {
  const items = res.items || [];
  const enriching = res.state === "enriching";
  const by = {};
  items.forEach(i => { const e = exposureOf(i); by[e] = (by[e] || 0) + 1; });
  const exposed = (by.affected || 0) + (by.potentially_affected || 0);
  const servers = new Set();
  items.forEach(i => (i.affected_hosts || []).forEach(x => { if (x.state === "affected") servers.add(x.hostname); }));
  (items || []).forEach(i => (i.inventory_matches || []).forEach(m => {
    if (m.name && ["in_range", "release_match"].includes(m.certainty)) servers.add(m.name); }));

  const tiles = h("div", { class: "agent-tiles" }, EXPOSURE_ORDER.filter(k => by[k]).map(k =>
    h("div", { class: "agent-tile" }, h("span", { class: "at-n" }, by[k]),
      h("span", { class: "at-l" }, EXPOSURE[k].label), h("span", { class: "at-d" }, EXPOSURE[k].desc))));

  const progress = enriching ? h("div", { class: "enrich" },
    h("span", null, "Looking up each CVE in NVD, matching it against the inventory and writing briefs: "
      + (res.progress || 0) + " of " + (res.progress_total || items.length)),
    pctBar(Math.round(100 * (res.progress || 0) / Math.max(1, res.progress_total || items.length)))) : null;

  const lead = h("p", null, items.length + " CVEs checked. ",
    h("strong", null, exposed + " affect or may affect us"),
    exposed ? " across " + servers.size + " system" + (servers.size === 1 ? "" : "s") + "." : ".",
    items.some(i => i.kev && ["affected", "potentially_affected"].includes(exposureOf(i)))
      ? h("span", null, " ", kevBadge(), " Some are exploited in the wild.") : null);

  let show = EXPOSURE_ORDER.find(k => by[k]) || "affected";
  const filters = [["all", "All (" + items.length + ")"]].concat(
    EXPOSURE_ORDER.filter(k => by[k]).map(k => [k, EXPOSURE[k].label + " (" + by[k] + ")"]))
    .map(([k, l]) => h("button", { type: "button", "data-k": k, "aria-pressed": String(k === show) }, l));
  const body = h("div");

  // Where it was found: servers the package verdict flags, plus inventory
  // matches (ESXi, vCenter, VM guests). The package verdict is authoritative
  // for Linux servers, so the matcher leaves those out and they are added here.
  function matchSummary(i) {
    const kinds = {};
    const add = (k, n) => { kinds[k] = (kinds[k] || 0) + n; };
    const hosts = (i.affected_hosts || []).filter(x => x.state === "affected" || x.state === "pending_reboot"
                                                    || x.state === "fixed_pending_reboot");
    if (hosts.length) add("Linux server", hosts.length);
    const m = (i.inventory_matches || []).filter(x =>
      ["confirmed", "in_range", "release_match", "present"].includes(x.certainty));
    m.forEach(x => add(x.where || "item", 1));
    if (!Object.keys(kinds).length) {
      return (i.inventory_matches || []).some(x => x.certainty === "not_tracked")
        ? h("span", { class: "muted" }, "not tracked") : h("span", { class: "muted" }, "none");
    }
    return Object.entries(kinds).map(([k, n]) => n + " " + k + (n === 1 ? "" : "s")).join(", ");
  }
  function detailRow(i, cols) {
    const matches = (i.inventory_matches || []);
    return h("tr", { class: "explain-row" }, h("td", { colspan: String(cols) },
      h("div", { class: "explain" },
        i.ai_summary ? [h("p", { class: "explain-note" }, "AI brief from AI-01, from the facts below."),
                        h("p", { class: "explain-text" }, i.ai_summary)]
          : enriching && !i.enriched_at ? h("p", { class: "explain-wait" }, "Brief pending")
          : h("p", { class: "muted small" }, "No AI brief: AI-01 unavailable or not configured."),
        i.description ? h("p", { class: "cve-desc" }, h("strong", null, "NVD: "), i.description) : null,
        (i.products || []).length ? h("p", { class: "small" }, h("strong", null, "Affects: "),
          i.products.slice(0, 10).map(p => p.vendor + " " + p.product + " (" + p.kind + ")").join("; ")) : null,
        matches.length ? h("div", { class: "cm-table" }, table([
          { label: "Found in", nowrap: true, cell: m => m.where || m.kind },
          { label: "Name", nowrap: true, cell: m => m.name || "" },
          { label: "Version", cell: m => m.version || "" },
          { label: "Certainty", nowrap: true, cell: m => CERTAINTY[m.certainty] || m.certainty },
          { label: "Why", cell: m => m.detail || "" },
        ], matches.slice(0, 40))) : null)));
  }
  function draw() {
    filters.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === show)));
    const rows = items.filter(i => show === "all" || exposureOf(i) === show);
    if (!rows.length) return body.replaceChildren(h("div", { class: "empty" }, h("p", null, "Nothing in this category.")));
    const cols = [
      { label: "CVE", nowrap: true, mono: true, cell: i => i.cve_id },
      { label: "Exposure", nowrap: true, cell: exposureMark },
      { label: "CVSS", num: true, nowrap: true, cell: i => cvssCell(i.cvss_score, i.cvss_severity) },
      { label: "", nowrap: true, cell: i => i.kev ? kevBadge() : "" },
      { label: "Attack type", cell: i => i.attack_class || (enriching && !i.enriched_at ? h("span", { class: "muted" }, "looking up") : "") },
      { label: "Affects", cell: i => (i.product_classes || []).join(", ") },
      { label: "Found in", cell: matchSummary },
    ];
    const tbl = table(cols, rows, { onRow: () => {} });
    tbl.querySelectorAll("tbody tr").forEach((tr, n) => {
      tr.addEventListener("click", () => {
        const nx = tr.nextElementSibling;
        if (nx && nx.classList.contains("explain-row")) return nx.remove();
        tr.after(detailRow(rows[n], cols.length));
      });
    });
    body.replaceChildren(h("p", { class: "muted small" }, "Click a CVE for its brief, what it affects and where it was found."), tbl);
  }
  filters.forEach(b => b.addEventListener("click", () => { show = b.dataset.k; draw(); }));
  draw();

  return h("div", null,
    h("div", { class: "page-head" }, h("h2", null, "Result: " + res.name),
      h("button", { type: "button", class: "quiet",
                    on: { click: () => downloadCsv(res.id, res.name).catch(() => alert("Export failed")) } },
        "Export CSV")),
    progress, lead, tiles,
    res.rejected && res.rejected.length ? h("p", { class: "muted small" },
      "Not understood in the input: " + res.rejected.join(" | ")) : null,
    h("div", { class: "controls" }, h("div", { class: "filters", role: "group" }, filters)),
    body);
}

async function showAssessment(id, box) {
  const d = await api("/admin/assessments/" + encodeURIComponent(id));
  const a = d.assessment || {};
  box.replaceChildren(assessResult({ id: a.id, name: a.name, state: a.state, progress: a.progress,
    progress_total: a.progress_total, rejected: a.rejected, items: d.items || [] }));
  if (a.state === "enriching") {
    setPageTimer(async () => {
      if (!location.hash.startsWith("#/assess")) return clearPageTimer();
      try {
        const n = await api("/admin/assessments/" + encodeURIComponent(id));
        const na = n.assessment || {};
        // Keep an open detail row by only redrawing when something changed
        if (na.progress !== a.progress || na.state !== a.state) {
          a.progress = na.progress; a.state = na.state;
          box.replaceChildren(assessResult({ id: na.id, name: na.name, state: na.state, progress: na.progress,
            progress_total: na.progress_total, rejected: na.rejected, items: n.items || [] }));
        }
        if (na.state !== "enriching") clearPageTimer();
      } catch (e) { clearPageTimer(); }
    }, 5000);
  }
}

async function renderAssess(params) {
  setNav("assess");
  const list = await api("/admin/assessments");
  const resultBox = h("div");

  const name = h("input", { type: "text", required: true, placeholder: "SOC bulletin, September" });
  const source = h("input", { type: "text", placeholder: "SOC, auditor, vendor notice" });
  const textarea = h("textarea", { rows: "6", placeholder:
    "Paste the CVE list here, in any format:\nCVE-2026-31337, CVE-2026-31338\nCVE-2026-29001" });
  const fileIn = h("input", { type: "file", accept: ".txt,.csv,.text,text/plain,text/csv" });
  const submit = h("button", { type: "submit" }, "Assess");
  const err = h("p", { class: "explain-error", hidden: true });

  const form = h("form", { class: "assess-form", on: { submit: async e => {
    e.preventDefault();
    err.hidden = true;
    if (!name.value.trim()) { err.textContent = "Give the assessment a name."; err.hidden = false; return; }
    if (!textarea.value.trim() && !fileIn.files.length) {
      err.textContent = "Paste a CVE list or choose a file."; err.hidden = false; return;
    }
    submit.disabled = true; submit.textContent = "Assessing";
    const fd = new FormData();
    fd.append("name", name.value.trim());
    if (source.value.trim()) fd.append("source", source.value.trim());
    if (textarea.value.trim()) fd.append("text", textarea.value);
    if (fileIn.files.length) fd.append("file", fileIn.files[0]);
    try {
      const auth = getAuth();
      const res = await fetch("/api/v1/admin/assessments", {
        method: "POST",
        headers: { "X-Requested-With": "patch01-dashboard",
                   ...authHeaders() },
        body: fd,
      });
      if (res.status === 401) { clearAuth(); return renderSignIn("Your session has ended."); }
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new ApiError(res.status, data.detail || res.statusText);
      history.replaceState(null, "", "#/assess?id=" + data.id);
      await showAssessment(data.id, resultBox);
      resultBox.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (ex) {
      err.textContent = ex.message || "Assessment failed.";
      err.hidden = false;
    } finally {
      submit.disabled = false; submit.textContent = "Assess";
    }
  } } },
    h("div", { class: "af-row" },
      h("label", null, h("span", null, "Name"), name),
      h("label", null, h("span", null, "Where it came from"), source)),
    h("label", null, h("span", null, "CVE list"), textarea),
    h("label", null, h("span", null, "or upload a file"), fileIn,
      h("span", { class: "muted small" },
        "Text or CSV. Save a spreadsheet as CSV, or paste the column in above.")),
    err, submit);

  const past = (list.assessments || []);
  const history = h("section", null,
    h("h2", null, "Previous assessments"),
    past.length ? table([
      { label: "Name", cell: a => h("a", { href: "#/assess?id=" + a.id }, a.name) },
      { label: "From", nowrap: true, cell: a => a.source || "" },
      { label: "When", nowrap: true, cell: a => fmtDateTime(a.created_at) },
      { label: "CVEs", num: true, cell: a => a.cve_count },
      { label: "Exposed", num: true, cell: a => count(a.exposed != null ? a.exposed : a.affected, "affected") },
      { label: "State", nowrap: true, cell: a => a.state === "enriching"
          ? h("span", { class: "muted" }, "enriching " + (a.progress || 0) + "/" + (a.progress_total || a.cve_count)) : "done" },
      { label: "Exploited", num: true, cell: a => a.exploited_affected
          ? h("span", null, a.exploited_affected, " ", kevBadge()) : "0" },
      { label: "Cannot assess", num: true, cell: a => a.no_vendor_data },
      { label: "By", nowrap: true, cell: a => a.created_by },
    ], past, { onRow: a => { location.hash = "#/assess?id=" + a.id; } })
      : h("div", { class: "empty" }, h("p", null, "No assessment has been run yet.")));

  if (!can("operator")) form.replaceChildren(
    h("p", { class: "muted" }, "Running an assessment needs the operator role. Previous assessments are below."));
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl assess --cve-list" }, "Assess a CVE list"),
      h("span", { class: "muted small" }, "For lists from a SOC, an auditor or a vendor")),
    h("p", { class: "muted" },
      "Paste or upload a list of CVEs. Each one is looked up in NVD, classified by what it "
      + "affects (operating system, application, ESXi, vCenter, network device), and checked "
      + "against the inventory: server packages, ESXi hosts, vCenters and VM guest systems. "
      + "AI-01 writes a short brief for each. Results export to CSV."),
    form, resultBox, history);

  // Opening a saved assessment
  const id = params.get("id");
  if (id) {
    try { await showAssessment(id, resultBox); } catch (e) { /* the list below still shows */ }
  }
}

/* ---- VMware ------------------------------------------------------------- */

const MATCH_LABEL = {
  "hardware_uuid": "Hardware ID",
  "hardware_uuid+hostname": "Hardware ID and hostname",
  "hostname": "Hostname only",
  "ip": "IP address only",
  "ambiguous": "Ambiguous",
};

function daysSince(iso) {
  if (!iso) return null;
  const t = new Date(iso).getTime();
  return isNaN(t) ? null : Math.floor((Date.now() - t) / 86400000);
}
function ageLabel(d) {
  if (d === null) return "unknown";
  if (d < 1) return "today";
  return d === 1 ? "1 day" : d + " days";
}

const POWER = { poweredOn: "On", poweredOff: "Off", suspended: "Suspended" };
const TOOLS_STATE = {
  guestToolsRunning: "Running",
  guestToolsNotRunning: "Not running",
  guestToolsExecutingScripts: "Starting",
};
function toolsLabel(v) {
  const t = TOOLS_STATE[v];
  if (t === "Running") return t;
  return h("span", { class: "muted" }, t || "unknown");
}

/* ---- the infrastructure map ---------------------------------------------
 * vCenter > datacenter > cluster > ESXi host > VM, drawn from PostgreSQL.
 * Expandable rather than a drawn graph: an estate of thousands of VMs is
 * read by drilling in, not by looking at a picture of all of it at once.
 */

function pctBar(pct, label) {
  const v = Math.max(0, Math.min(100, Number(pct) || 0));
  const bar = h("span", { class: "pbar" + (v >= 90 ? " pbar-full" : "") },
    h("span", { class: "pbar-fill" }));
  bar.firstChild.style.width = v + "%";
  return h("span", { class: "pcell" }, bar, h("span", { class: "pnum" }, label || (v + "%")));
}

function gb(mb) {
  if (mb === null || mb === undefined) return "";
  const n = Number(mb);
  return n >= 1024 ? Math.round(n / 1024) + " GB" : n + " MB";
}
function tb(mb) {
  if (mb === null || mb === undefined) return "";
  const n = Number(mb) / 1024;
  return n >= 1024 ? (n / 1024).toFixed(1) + " TB" : Math.round(n) + " GB";
}

function vmStatusDot(v) {
  // Patch state first, then agent coverage: a VM we cannot see is not "clean"
  let cls = "vmdot-unmanaged", title = "No agent: not assessed";
  if (v.host_id) {
    if (Number(v.needs_patch) > 0) { cls = "vmdot-affected"; title = v.needs_patch + " advisories need patching"; }
    else if (Number(v.needs_reboot) > 0) { cls = "vmdot-reboot"; title = "Awaiting reboot"; }
    else if (v.agent_state === "not_reporting" || v.agent_state === "no_data") {
      cls = "vmdot-unknown"; title = "Agent not reporting: status unknown";
    } else { cls = "vmdot-ok"; title = "Patched"; }
  }
  return h("span", { class: "vmdot " + cls, title: title });
}

function mapTree(data) {
  const byVc = {};
  (data.hosts || []).forEach(hst => {
    const dc = byVc[hst.vcenter] || (byVc[hst.vcenter] = {});
    const cl = dc[hst.datacenter || "(no datacenter)"] || (dc[hst.datacenter || "(no datacenter)"] = {});
    const key = hst.cluster || "(standalone hosts)";
    (cl[key] || (cl[key] = [])).push(hst);
  });
  const vmsByHost = {};
  const vmsNoHost = [];
  (data.vms || []).forEach(v => {
    if (v.esxi_moref) (vmsByHost[v.vcenter + "|" + v.esxi_moref] || (vmsByHost[v.vcenter + "|" + v.esxi_moref] = [])).push(v);
    else vmsNoHost.push(v);
  });

  const out = [];
  Object.keys(byVc).sort().forEach(vc => {
    const dcs = byVc[vc];
    const vcNode = h("details", { class: "mt mt-vc", open: true },
      h("summary", null,
        h("span", { class: "mt-kind" }, "vCenter"), h("strong", null, vc),
        h("span", { class: "mt-count" },
          Object.keys(dcs).length + " datacenter" + (Object.keys(dcs).length === 1 ? "" : "s"))));
    Object.keys(dcs).sort().forEach(dc => {
      const clusters = dcs[dc];
      const dcNode = h("details", { class: "mt mt-dc", open: true },
        h("summary", null, h("span", { class: "mt-kind" }, "Datacenter"), h("strong", null, dc),
          h("span", { class: "mt-count" }, Object.keys(clusters).length + " clusters")));
      // Real clusters first, the standalone-hosts group last
      const clusterOrder = Object.keys(clusters).sort((a, b) => {
        const sa = a.startsWith("("), sb = b.startsWith("(");
        return sa !== sb ? (sa ? 1 : -1) : a.localeCompare(b);
      });
      clusterOrder.forEach(cl => {
        const hostList = clusters[cl];
        const vmTotal = hostList.reduce((a, x) =>
          a + ((vmsByHost[x.vcenter + "|" + x.moref] || []).length), 0);
        const clNode = h("details", { class: "mt mt-cl" },
          h("summary", null, h("span", { class: "mt-kind" }, "Cluster"), h("strong", null, cl),
            h("span", { class: "mt-count" }, hostList.length + " hosts, " + vmTotal + " VMs")));
        hostList.forEach(hst => {
          const vms = (vmsByHost[hst.vcenter + "|" + hst.moref] || []).slice();
          const cpuPct = hst.cpu_mhz && hst.cpu_cores
            ? Math.round(100 * (hst.cpu_usage_mhz || 0) / (hst.cpu_mhz * hst.cpu_cores)) : null;
          const memPct = hst.memory_mb ? Math.round(100 * (hst.memory_usage_mb || 0) / hst.memory_mb) : null;
          const bad = hst.connection_state && hst.connection_state !== "connected";
          const hNode = h("details", { class: "mt mt-esxi" },
            h("summary", null,
              h("span", { class: "mt-kind" }, "ESXi"),
              h("strong", { class: bad ? "esxi-bad" : null }, hst.name),
              h("span", { class: "mt-count" }, vms.length + " VMs"),
              h("span", { class: "mt-facts" },
                "ESXi " + (hst.esxi_version || "?") + ", " + (hst.cpu_cores || "?") + " cores, "
                + gb(hst.memory_mb)),
              cpuPct !== null ? pctBar(cpuPct, "CPU " + cpuPct + "%") : null,
              memPct !== null ? pctBar(memPct, "RAM " + memPct + "%") : null,
              bad ? h("span", { class: "esxi-bad" }, hst.connection_state) : null,
              hst.maintenance_mode ? h("span", { class: "muted" }, "maintenance") : null));
          vms.sort((a, b) => (b.needs_patch || 0) - (a.needs_patch || 0) || String(a.vm).localeCompare(b.vm));
          hNode.append(h("div", { class: "mt-vms" }, vms.length ? vms.map(v =>
            h("div", { class: "mt-vm" },
              vmStatusDot(v),
              v.host_id ? h("a", { href: "#/host/" + v.host_id }, v.vm) : h("span", null, v.vm),
              h("span", { class: "muted" }, (v.guest_os || "unknown OS")),
              h("span", { class: "muted" }, (v.num_cpu || "?") + " vCPU, " + gb(v.memory_mb)),
              v.power_state !== "poweredOn" ? h("span", { class: "muted" }, POWER[v.power_state] || v.power_state) : null,
              Number(v.snapshot_count) ? h("span", { class: "muted" }, v.snapshot_count + " snapshot" + (v.snapshot_count === 1 ? "" : "s")) : null,
              v.host_id && Number(v.needs_patch) ? h("span", { class: "count st-affected" }, v.needs_patch + " to patch") : null,
              !v.host_id ? h("span", { class: "muted" }, v.is_linux ? "no agent" : "not managed") : null,
            )) : h("p", { class: "muted small" }, "No VMs on this host.")));
          clNode.append(hNode);
        });
        dcNode.append(clNode);
      });
      vcNode.append(dcNode);
    });
    out.push(vcNode);
  });

  if (vmsNoHost.length) {
    const orphan = h("details", { class: "mt mt-cl" },
      h("summary", null, h("span", { class: "mt-kind" }, "Unplaced"),
        h("strong", null, "VMs with no host recorded"),
        h("span", { class: "mt-count" }, vmsNoHost.length + " VMs")),
      h("div", { class: "mt-vms" }, vmsNoHost.map(v =>
        h("div", { class: "mt-vm" }, vmStatusDot(v), v.vm,
          h("span", { class: "muted" }, v.vcenter)))));
    out.push(orphan);
  }
  return out;
}

function mapLegend() {
  return h("div", { class: "map-legend" },
    h("span", null, h("span", { class: "vmdot vmdot-affected" }), "needs patching"),
    h("span", null, h("span", { class: "vmdot vmdot-reboot" }), "needs reboot"),
    h("span", null, h("span", { class: "vmdot vmdot-ok" }), "patched"),
    h("span", null, h("span", { class: "vmdot vmdot-unknown" }), "agent not reporting"),
    h("span", null, h("span", { class: "vmdot vmdot-unmanaged" }), "no agent"));
}

// How much of the estate the map can fully describe
async function coverageView() {
  const c = await api("/admin/vmware/coverage");
  const row = (label, n) => h("div", { class: "cov-row" }, h("span", null, label),
    pctBar(c.total ? Math.round(100 * n / c.total) : 0, " "), h("span", { class: "num" }, n));
  return h("div", null,
    h("p", { class: "muted" }, "What the map can fully describe, from vCenter alone. Dependency lines between "
      + "VMs will need flow records, which only Distributed Switches can export; application groups come "
      + "from vSphere tags, else folders."),
    h("div", { class: "cov-grid" },
      h("div", { class: "cov-card" }, h("h3", null, "Switching (" + c.total + " VMs)"),
        row("Distributed only", c.switching.distributed), row("Mixed", c.switching.mixed),
        row("Standard only", c.switching.standard), row("Other (NSX)", c.switching.other),
        row("No network", c.switching.none)),
      h("div", { class: "cov-card" }, h("h3", null, "Application grouping"),
        row("vSphere tag", c.grouping.tag), row("Folder", c.grouping.folder), row("Ungrouped", c.grouping.none))),
    h("h2", null, "Application groups (" + c.apps.length + ")"),
    c.apps.length ? table([
      { label: "Application", cell: a => a.app },
      { label: "From", nowrap: true, cell: a => a.source === "tag" ? "vSphere tag" : "folder" },
      { label: "VMs", num: true, cell: a => a.vms },
    ], c.apps) : h("div", { class: "empty" }, h("p", null, "No VM is tagged or foldered by application yet.")),
    h("h2", null, "Standard-switch only (" + c.standard_only.length + ")"),
    h("p", { class: "muted small" }, "No flow records for these unless a VM they talk to is on a Distributed Switch."),
    c.standard_only.length ? table([
      { label: "VM", cell: v => v.name }, { label: "Cluster", cell: v => v.cluster || "" },
      { label: "vCenter", nowrap: true, cell: v => v.vcenter }], c.standard_only)
      : h("div", { class: "empty" }, h("p", null, "Every VM has at least one Distributed port group.")),
    h("h2", null, "Ungrouped (" + c.ungrouped.length + ")"),
    h("p", { class: "muted small" }, "Tag these in vCenter with an Application category, or file them in an application folder."),
    c.ungrouped.length ? table([
      { label: "VM", cell: v => v.name }, { label: "Cluster", cell: v => v.cluster || "" },
      { label: "Folder", cell: v => v.folder || h("span", { class: "muted" }, "none") },
      { label: "vCenter", nowrap: true, cell: v => v.vcenter }], c.ungrouped)
      : h("div", { class: "empty" }, h("p", null, "Every VM belongs to an application group.")));
}

async function renderVmware(params) {
  setNav("vmware");
  let res;
  try { res = await api("/admin/vmware/summary"); }
  catch (e) {
    if (e.status === 404) {
      return render(h("div", { class: "page-head" }, h("h1", null, "VMware")),
        h("div", { class: "empty" }, h("p", null,
          "The API is older than the VMware integration. Rebuild it with ",
          h("code", null, "./scripts/phase3b-api.sh"), ".")));
    }
    throw e;
  }
  const vcs = res.vcenters || [];
  const c = res.counts || {};
  const oldDays = res.snapshot_old_days || 7;

  const head = h("div", { class: "page-head" },
    h("h1", { "data-cmd": "patchctl vmware status" }, "VMware"),
    h("span", { class: "muted small" },
      vcs.length + (vcs.length === 1 ? " vCenter" : " vCenters") + ", " + (c.vms || 0) + " VMs"));

  if (!vcs.length) {
    return render(head, h("div", { class: "empty" },
      h("h2", null, "No vCenter is configured"),
      h("p", null, "On PATCH-01, add one with ",
        h("code", null, "./scripts/phase7-vmware.sh --add <name> --host <vcenter address>"),
        ", then run ", h("code", null, "--sync"), ".")));
  }

  const vcCards = h("div", { class: "vc-cards" }, vcs.map(v =>
    h("div", { class: "vc-card" + (v.last_ok === false ? " vc-failed" : "") },
      h("div", { class: "vc-name" }, v.name),
      h("div", { class: "muted small" }, v.host),
      h("div", { class: "small" }, v.version || ""),
      v.last_ok === false
        ? h("div", { class: "vc-error" }, "Last sync failed " + timeAgo(v.last_sync_at) + ": " + (v.last_error || ""))
        : h("div", { class: "small" }, (v.vm_count || 0) + " VMs, synced " + timeAgo(v.last_sync_at)))));

  let view = params.get("view") || "live";
  const tabs = [
    ["live", "Live map", null],
    ["map", "Tree", null],
    ["coverage", "Coverage", null],
    ["all", "All VMs", c.vms],
    ["hosts", "ESXi hosts", null],
    ["datastores", "Datastores", null],
    ["networks", "Networks", null],
    ["clusters", "Clusters", null],
    ["snapshots", "VMs with snapshots", null],
    ["unmanaged", "Linux VMs without an agent", c.unmanaged],
    ["ambiguous", "Ambiguous matches", c.ambiguous],
  ];
  const tabBtns = tabs.map(([k, label, n]) =>
    h("button", { type: "button", "data-k": k, "aria-pressed": String(k === view) },
      label + (n !== null && n !== undefined ? " (" + n + ")" : "")));

  const note = h("p", { class: "muted small" },
    (c.matched || 0) + " VMs are linked to a server. " +
    (res.servers_without_vm ? res.servers_without_vm +
      " servers have no VM linked: physical machines, a vCenter not yet synced, or agents older than 1.2.0. " : "") +
    "Snapshots older than " + oldDays + " days are flagged.");

  const body = h("div");
  const search = h("input", { type: "search", placeholder: "Filter by VM, server, cluster or OS",
                              "aria-label": "Filter virtual machines" });
  let cache = [];
  let q = "";

  function matches(v) {
    if (!q) return true;
    const hay = [v.name, v.server, v.cluster, v.guest_os, v.guest_hostname, v.vcenter,
                 v.esxi_host, v.datacenter, v.type, v.kind, v.model, v.vendor,
                 v.cpu_model, v.esxi_version, (v.guest_ips || []).join(" ")]
      .filter(Boolean).join(" ").toLowerCase();
    return hay.includes(q);
  }

  const ROW_NOUN = { hosts: ["ESXi host", "ESXi hosts"], datastores: ["datastore", "datastores"],
                     networks: ["network", "networks"], clusters: ["cluster", "clusters"],
                     snapshots: ["VM", "VMs"], unmanaged: ["VM", "VMs"],
                     ambiguous: ["VM", "VMs"], all: ["VM", "VMs"], linux: ["VM", "VMs"] };
  const noun = (n, v) => (ROW_NOUN[v] || ["row", "rows"])[n === 1 ? 0 : 1];

  const ENDPOINT = {
    map: "/admin/vmware/map", hosts: "/admin/vmware/hosts",
    datastores: "/admin/vmware/datastores", networks: "/admin/vmware/networks",
    clusters: "/admin/vmware/clusters",
  };

  async function draw() {
    tabBtns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === view)));
    search.hidden = (view === "map");
    body.replaceChildren(h("p", { class: "muted" }, "Loading"));
    if (view === "live") {
      search.hidden = true;
      NeonMap.mount(body, { api, setTimer: setPageTimer, clearTimer: clearPageTimer });
      return;
    }
    clearPageTimer();
    if (view === "coverage") {
      search.hidden = true;
      body.replaceChildren(await coverageView());
      return;
    }
    if (view === "map") {
      const d = await api(ENDPOINT.map);
      cache = [];
      const tree = mapTree(d);
      body.replaceChildren(
        h("p", { class: "muted small" },
          (d.hosts || []).length + " ESXi hosts, " + (d.vms || []).length + " VMs, "
          + (d.datastores || []).length + " datastores. Click a cluster or host to expand."),
        mapLegend(),
        tree.length ? h("div", { class: "map-tree" }, tree)
          : h("div", { class: "empty" }, h("p", null,
              "Nothing synced yet. Run ./scripts/phase7-vmware.sh --sync on PATCH-01.")),
        (d.datastores || []).length ? h("details", { class: "mt mt-ds" },
          h("summary", null, h("span", { class: "mt-kind" }, "Storage"),
            h("strong", null, "Datastores"),
            h("span", { class: "mt-count" }, d.datastores.length)),
          table([
            { label: "Datastore", nowrap: true, cell: x => x.name },
            { label: "Type", nowrap: true, cell: x => x.type || "" },
            { label: "Capacity", num: true, nowrap: true, cell: x => tb(x.capacity_mb) },
            { label: "Free", num: true, nowrap: true, cell: x => tb(x.free_mb) },
            { label: "Usage", nowrap: true, cell: x => pctBar(x.used_pct) },
            { label: "VMs", num: true, cell: x => x.vm_count },
            { label: "vCenter", nowrap: true, cell: x => x.vcenter },
          ], d.datastores)) : null);
      return;
    }
    if (ENDPOINT[view]) {
      const d = await api(ENDPOINT[view]);
      cache = d.hosts || d.datastores || d.networks || d.clusters || [];
    } else {
      const r = await api("/admin/vmware/vms?view=" + encodeURIComponent(view));
      cache = r.vms || [];
    }
    paint();
  }

  function paint() {
    const vms = cache.filter(matches);
    const vmCell = v => v.host_id ? h("a", { href: "#/host/" + v.host_id }, v.name) : v.name;
    const cols = {
      all: [
        { label: "VM", nowrap: true, cell: v => v.host_id
            ? h("a", { href: "#/host/" + v.host_id }, v.name) : v.name },
        { label: "Guest OS", cell: v => v.guest_os || h("span", { class: "muted" }, "unknown") },
        { label: "Power", nowrap: true, cell: v => h("span",
            { class: v.power_state === "poweredOn" ? null : "muted" },
            POWER[v.power_state] || v.power_state) },
        { label: "Server", nowrap: true, cell: v => v.server
            || h("span", { class: "muted" }, v.is_linux ? "no agent" : "not managed") },
        { label: "Cluster", nowrap: true, cell: v => v.cluster || "" },
        { label: "Snapshots", num: true, cell: v => v.snapshot_count
            ? h("span", { class: daysSince(v.oldest_snapshot_at) >= oldDays ? "snap-old" : null },
                v.snapshot_count) : "0" },
        { label: "Tools", nowrap: true, cell: v => toolsLabel(v.tools_running) },
        { label: "vCenter", nowrap: true, cell: v => v.vcenter },
        { label: "", nowrap: true, cell: v => can("operator")
            ? h("a", { class: "small", href: "#/changes/new?kind=vm&vc=" + encodeURIComponent(v.vcenter)
                        + "&moref=" + encodeURIComponent(v.moref) }, "Actions") : "" },
      ],
      hosts: [
        { label: "ESXi host", nowrap: true, cell: x => h("span",
            { class: x.connection_state !== "connected" ? "esxi-bad" : null }, x.name) },
        { label: "Cluster", nowrap: true, cell: x => x.cluster || h("span", { class: "muted" }, "standalone") },
        { label: "State", nowrap: true, cell: x => [
            x.connection_state === "connected" ? "Connected" : h("span", { class: "esxi-bad" }, x.connection_state),
            x.maintenance_mode ? h("span", { class: "muted" }, " maintenance") : null] },
        { label: "ESXi", nowrap: true, cell: x => (x.esxi_version || "") + (x.esxi_build ? " b" + x.esxi_build : "") },
        { label: "Hardware", cell: x => [x.vendor, x.model].filter(Boolean).join(" ") },
        { label: "CPU", cell: x => (x.cpu_sockets || "?") + " x " + (x.cpu_cores || "?") + " cores"
            + (x.cpu_model ? " - " + x.cpu_model : "") },
        { label: "CPU used", nowrap: true, cell: x => x.cpu_pct !== null ? pctBar(x.cpu_pct) : "" },
        { label: "Memory", num: true, nowrap: true, cell: x => gb(x.memory_mb) },
        { label: "RAM used", nowrap: true, cell: x => x.memory_pct !== null ? pctBar(x.memory_pct) : "" },
        { label: "VMs", num: true, cell: x => x.vm_count },
        { label: "Uptime", nowrap: true, cell: x => fmtUptime(x.uptime_seconds) },
        { label: "vCenter", nowrap: true, cell: x => x.vcenter },
      ],
      datastores: [
        { label: "Datastore", nowrap: true, cell: x => x.name },
        { label: "Type", nowrap: true, cell: x => x.type || "" },
        { label: "Capacity", num: true, nowrap: true, cell: x => tb(x.capacity_mb) },
        { label: "Used", num: true, nowrap: true, cell: x => tb(x.used_mb) },
        { label: "Free", num: true, nowrap: true, cell: x => tb(x.free_mb) },
        { label: "Usage", nowrap: true, cell: x => pctBar(x.used_pct) },
        // Over 100% means thin disks are promising more than the datastore has
        { label: "Provisioned", nowrap: true, cell: x => x.provisioned_pct !== null
            ? h("span", { class: Number(x.provisioned_pct) > 100 ? "overcommit" : null,
                          title: Number(x.provisioned_pct) > 100
                            ? "Thin disks are provisioned beyond capacity" : "" },
                x.provisioned_pct + "%") : "" },
        { label: "Hosts", num: true, cell: x => x.host_count },
        { label: "VMs", num: true, cell: x => x.vm_count },
        { label: "State", nowrap: true, cell: x => x.accessible === false
            ? h("span", { class: "esxi-bad" }, "not accessible") : "Accessible" },
        { label: "vCenter", nowrap: true, cell: x => x.vcenter },
      ],
      networks: [
        { label: "Network", nowrap: true, cell: x => x.name },
        { label: "Kind", nowrap: true, cell: x => ({
            Network: "Standard port group",
            DistributedVirtualPortgroup: "Distributed port group",
            OpaqueNetwork: "Opaque (NSX)" }[x.kind] || x.kind) },
        { label: "Datacenter", nowrap: true, cell: x => x.datacenter || "" },
        { label: "VMs", num: true, cell: x => x.vm_count },
        { label: "State", nowrap: true, cell: x => x.accessible === false
            ? h("span", { class: "esxi-bad" }, "not accessible") : "Accessible" },
        { label: "vCenter", nowrap: true, cell: x => x.vcenter },
      ],
      clusters: [
        { label: "Cluster", nowrap: true, cell: x => x.name },
        { label: "Datacenter", nowrap: true, cell: x => x.datacenter || "" },
        { label: "Hosts", num: true, cell: x => x.hosts_seen },
        { label: "VMs", num: true, cell: x => x.vms },
        { label: "CPU cores", num: true, cell: x => x.num_cpu_cores || "" },
        { label: "Memory", num: true, nowrap: true, cell: x => tb(x.total_memory_mb) },
        { label: "DRS", nowrap: true, cell: x => x.drs_enabled === null ? ""
            : (x.drs_enabled ? "On" : h("span", { class: "muted" }, "Off")) },
        { label: "HA", nowrap: true, cell: x => x.ha_enabled === null ? ""
            : (x.ha_enabled ? "On" : h("span", { class: "muted" }, "Off")) },
        { label: "vCenter", nowrap: true, cell: x => x.vcenter },
      ],
      unmanaged: [
        { label: "VM", nowrap: true, cell: v => v.name },
        { label: "Guest OS", cell: v => v.guest_os || "" },
        { label: "Hostname", nowrap: true, cell: v => v.guest_hostname || h("span", { class: "muted" }, "unknown") },
        { label: "Addresses", mono: true, cell: v => (v.guest_ips || []).join(", ") },
        { label: "Tools", nowrap: true, cell: v => toolsLabel(v.tools_running) },
        { label: "Cluster", nowrap: true, cell: v => v.cluster || "" },
        { label: "vCenter", nowrap: true, cell: v => v.vcenter },
      ],
      snapshots: [
        { label: "VM", nowrap: true, cell: vmCell },
        { label: "Snapshots", num: true, cell: v => v.snapshot_count },
        { label: "Oldest", nowrap: true, cell: v => {
            const d = daysSince(v.oldest_snapshot_at);
            return h("span", { class: d !== null && d >= oldDays ? "snap-old" : null }, ageLabel(d));
          } },
        { label: "Names", cell: v => (v.snapshots || []).map(x => x.name).join(", ") },
        { label: "vCenter", nowrap: true, cell: v => v.vcenter },
      ],
      ambiguous: [
        { label: "VM", nowrap: true, cell: v => v.name },
        { label: "Hostname", nowrap: true, cell: v => v.guest_hostname || "" },
        { label: "Why", cell: () => "Shares its hardware ID with another VM, usually a clone. Not linked, to avoid guessing." },
        { label: "vCenter", nowrap: true, cell: v => v.vcenter },
      ],
      linux: [
        { label: "VM", nowrap: true, cell: vmCell },
        { label: "Server", nowrap: true, cell: v => v.server || h("span", { class: "muted" }, "no agent") },
        { label: "Power", nowrap: true, cell: v => POWER[v.power_state] || v.power_state },
        { label: "Cluster", nowrap: true, cell: v => v.cluster || "" },
        { label: "Snapshots", num: true, cell: v => v.snapshot_count },
        { label: "Linked by", nowrap: true, cell: v => MATCH_LABEL[v.match_method] || "" },
      ],
    }[view];
    const empty = {
      all: q ? "No VM matches that filter." : "No VMs found in any vCenter.",
      hosts: "No ESXi hosts synced yet.",
      datastores: "No datastores synced yet.",
      networks: "No networks synced yet.",
      clusters: "No clusters found. Standalone hosts appear under ESXi hosts.",
      unmanaged: "Every running Linux VM has an agent.",
      snapshots: "No VM has a snapshot.",
      ambiguous: "No ambiguous matches.",
      linux: "No Linux VMs found.",
    }[view];
    body.replaceChildren(
      cache.length ? h("p", { class: "muted small" },
        (vms.length === cache.length ? String(cache.length)
          : vms.length + " of " + cache.length) + " " + noun(vms.length, view)) : null,
      vms.length ? table(cols, vms) : h("div", { class: "empty" }, h("p", null, empty)));
  }
  search.addEventListener("input", () => { q = search.value.trim().toLowerCase(); paint(); });
  tabBtns.forEach(b => b.addEventListener("click", () => { view = b.dataset.k; draw().catch(showError); }));

  render(head, vcCards, note,
    h("div", { class: "controls" },
      h("div", { class: "filters", role: "group", "aria-label": "Show" }, tabBtns),
      search),
    body);
  await draw();
}

/* ---- advisories --------------------------------------------------------- */

async function renderAdvisories() {
  setNav("advisories");
  const app = await api("/admin/applicability/summary");
  const top = app.top_affected || [];
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl advisories --affected --sort severity" }, "Advisories"),
      h("span", { class: "muted small" }, "Ordered by severity, then by how many servers need the fix")),
    top.length ? table([
      { label: "Advisory", nowrap: true, cell: r => r.advisory_id },
      { label: "Severity", cell: r => sevLabel(r.severity) },
      { label: "Servers affected", num: true, cell: r => count(r.hosts_affected, "affected") },
      { label: "Issued", cell: r => fmtDate(r.issued_at) },
      { label: "Summary", cell: r => r.title || "" },
      { label: "CVEs", cell: r => (r.cves || []).slice(0, 3).join(", ") +
          ((r.cves || []).length > 3 ? " and " + (r.cves.length - 3) + " more" : "") },
    ], top)
    : h("div", { class: "empty" },
        h("p", null, "No server needs a patch right now."),
        h("p", { class: "muted small" }, "If this is unexpected, check the CVE engine last ran with ",
          h("code", null, "./scripts/phase4-cve.sh --report"), ".")),
  );
}

/* ---- activity ----------------------------------------------------------- */

const ACTIONS = {
  enroll: "Server enrolled",
  re_enroll: "Server re-enrolled",
  inventory: "Inventory received",
  inventory_rejected: "Inventory rejected",
  create_enrollment_token: "Enrollment token issued",
  decommission: "Server retired",
  mark_stale: "Silent servers marked",
};

async function renderActivity() {
  setNav("activity");
  const res = await api("/admin/audit?limit=200");
  const rows = res.events || [];
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl audit tail -n 200" }, "Activity"),
      h("span", { class: "muted small" }, "Permanent record; entries cannot be edited or removed")),
    rows.length ? table([
      { label: "When", cell: r => fmtDateTime(r.occurred_at) },
      { label: "What", cell: r => ACTIONS[r.action] || r.action },
      { label: "By", cell: r => r.actor },
      { label: "From", mono: true, cell: r => r.source_ip || "" },
      { label: "Detail", cell: r => {
          const d = r.detail || {};
          const parts = [];
          if (d.packages !== undefined) parts.push(d.packages + " packages" + (d.unchanged ? ", unchanged" : ""));
          if (d.os) parts.push(d.os);
          if (d.host_group) parts.push("group " + d.host_group);
          if (d.reboot_required) parts.push("reboot required");
          if (d.package_count !== undefined) parts.push(d.package_count + " packages reported");
          return parts.join(", ");
        } },
    ], rows)
    : h("div", { class: "empty" }, h("p", null, "Nothing recorded yet.")),
  );
}

/* ---- routing ------------------------------------------------------------ */

async function route() {
  const a = getAuth();
  if (!a) return renderSignIn();
  if (a.user.must_change_password) return renderChangePassword(true);
  applyRoleTheme();
  document.getElementById("top").hidden = false;
  // The chat, AI explanations and CVE analysis are operator tools
  document.getElementById("chat-open").hidden = !can("operator");
  // Short enough to leave the nav its room; the full name is in the tooltip
  const who = document.getElementById("whoami");
  who.textContent = a.user.username + " \u00b7 " + a.user.role;
  who.title = (a.user.display_name ? a.user.display_name + ". " : "") + "Change your password";
  document.querySelectorAll("nav a[data-min-role]").forEach(el => {
    el.hidden = !can(el.dataset.minRole);
  });

  const raw = location.hash.replace(/^#\/?/, "");
  const [path, query] = raw.split("?");
  const params = new URLSearchParams(query || "");
  const parts = path.split("/").filter(Boolean);

  try {
    if (parts[0] === "hosts") await renderHosts(params);
    else if (parts[0] === "host" && parts[1]) await renderHost(parts[1], params);
    else if (parts[0] === "agents") await renderAgents(params);
    else if (parts[0] === "vmware") await renderVmware(params);
    else if (parts[0] === "assess") await renderAssess(params);
    else if (parts[0] === "hardening" && parts[1] === "host" && parts[2]) await renderHardeningHost(parts[2], params);
    else if (parts[0] === "hardening" && parts[1] === "rule" && parts[2]) await renderHardeningRule(decodeURIComponent(parts[2]), params);
    else if (parts[0] === "hardening") await renderHardening(params);
    else if (parts[0] === "changes" && parts[1] === "new") await renderNewChange(params);
    else if (parts[0] === "changes") await renderChanges(params);
    else if (parts[0] === "change" && parts[1]) await renderChange(parts[1]);
    else if (parts[0] === "users") await renderUsers(params);
    else if (parts[0] === "password") renderChangePassword(false);
    else if (parts[0] === "advisories") await renderAdvisories(params);
    else if (parts[0] === "activity") await renderActivity(params);
    else await renderOverview();
  } catch (err) {
    showError(err);
  }
}

function start() {
  route();
}

/* ---- page timers --------------------------------------------------------
 * A page that refreshes itself (a running change, an assessment being
 * enriched) registers here, so navigating away stops it.
 */
let pageTimer = null;
function setPageTimer(fn, ms) { clearPageTimer(); pageTimer = setInterval(fn, ms); }
function clearPageTimer() { if (pageTimer) { clearInterval(pageTimer); pageTimer = null; } }
window.addEventListener("hashchange", clearPageTimer);

/* ---- changes ------------------------------------------------------------ */

const CHANGE_STATE = {
  pending_approval: ["Awaiting approval", "st-unknown"],
  scheduled: ["Scheduled", "st-plain"],
  running: ["Running", "st-running"],
  succeeded: ["Succeeded", "st-fixed_active"],
  partially_succeeded: ["Partly succeeded", "st-fixed_pending_reboot"],
  failed: ["Failed", "st-affected"],
  cancelled: ["Cancelled", "st-unknown"],
  rejected: ["Rejected", "st-unknown"],
};
const TARGET_STATE = {
  queued: "Queued", precheck: "Pre-check", snapshot: "Snapshot", install: "Installing",
  reboot: "Rebooting", wait_boot: "Waiting for boot", postcheck: "Post-check",
  inventory: "Reporting inventory", snapshot_cleanup: "Removing snapshot",
  vm_action: "In progress", done: "Done", failed: "Failed", skipped: "Skipped",
  cancelled: "Cancelled",
};
const KIND_LABEL = {
  patch: "Patch servers", vm_snapshot_create: "Take snapshot", vm_snapshot_remove: "Remove snapshot",
  vm_snapshot_revert: "Revert to snapshot", vm_power_on: "Power on",
  vm_guest_shutdown: "Shut down guest", vm_guest_restart: "Restart guest",
};

function changeMark(st) {
  const [label, cls] = CHANGE_STATE[st] || [st, "st-plain"];
  return h("span", { class: "state " + cls }, label);
}
function targetMark(st) {
  const cls = st === "done" ? "st-fixed_active" : st === "failed" ? "st-affected"
    : ["skipped", "cancelled"].includes(st) ? "st-unknown"
    : st === "queued" ? "st-plain" : "st-running";
  return h("span", { class: "state " + cls }, TARGET_STATE[st] || st);
}
function ref(n) { return "CHG-" + String(n).padStart(6, "0"); }

async function workerBanner() {
  try {
    const w = await api("/worker/status");
    if (w.alive) return null;
    return h("div", { class: "hs-alert st-affected" }, h("strong", null, "The worker is not running. "),
      "Scheduled changes will not start until it is. On PATCH-01: ",
      h("code", null, "./scripts/phase3b-api.sh --check"));
  } catch (e) { return null; }
}

async function renderChanges(params) {
  setNav("changes");
  let show = params.get("state") || "";
  const [list, banner] = await Promise.all([
    api("/changes" + (show ? "?state=" + encodeURIComponent(show) : "")), workerBanner()]);
  const rows = list.changes || [];
  const filters = [["", "All"], ["scheduled", "Scheduled"], ["running", "Running"],
                   ["failed", "Failed"], ["partially_succeeded", "Partly succeeded"],
                   ["succeeded", "Succeeded"]]
    .map(([k, l]) => h("a", { class: "fbtn", href: "#/changes" + (k ? "?state=" + k : ""),
                              "aria-pressed": String(k === show) }, l));
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl changes ls" }, "Changes"),
      h("span", { class: "head-actions" }, can("operator") ? [
        h("a", { class: "btn", href: "#/changes/new?kind=patch" }, "New patch job"),
        h("a", { class: "btn btn-quiet", href: "#/changes/new?kind=vm" }, "New VMware action")] : null)),
    banner,
    h("p", { class: "muted" }, "Every patch job and VMware action, who asked for it, why, and what happened."),
    h("div", { class: "controls" }, h("div", { class: "filters" }, filters)),
    rows.length ? table([
      { label: "Change", nowrap: true, mono: true, cell: c => h("a", { href: "#/change/" + c.id }, ref(c.number)) },
      { label: "What", cell: c => c.title },
      { label: "Kind", nowrap: true, cell: c => KIND_LABEL[c.kind] || c.kind },
      { label: "State", nowrap: true, cell: c => changeMark(c.state) },
      { label: "Progress", nowrap: true, cell: c => c.targets + " target" + (c.targets == 1 ? "" : "s")
          + (c.done ? ", " + c.done + " done" : "") + (c.failed ? ", " + c.failed + " failed" : "")
          + (c.in_progress ? ", " + c.in_progress + " running" : "") },
      { label: "Starts", nowrap: true, cell: c => fmtDateTime(c.run_after) },
      { label: "By", nowrap: true, cell: c => c.requested_by },
    ], rows, { onRow: c => { location.hash = "#/change/" + c.id; } })
      : h("div", { class: "empty" }, h("p", null, show ? "No changes in this state."
          : can("operator") ? "Nothing scheduled yet. Start with a patch job." : "Nothing scheduled yet.")));
}

function describeParams(c) {
  const p = c.params || {};
  if (c.kind === "patch") {
    return [
      ["Installs", p.mode === "advisories" ? "Only: " + (p.advisories || []).join(", ")
                                           : "All outstanding security fixes"],
      ["Reboot", { never: "Never, flag only", if_required: "Only if required", always: "Always" }[p.reboot] || p.reboot],
      ["VM snapshot", { none: "None", keep: "Take one before, keep it",
                        remove_on_success: "Take one before, remove it if patching succeeds" }[p.snapshot] || p.snapshot],
      ["Service check", p.check_services ? "Services running before must be running after" : "Off"],
    ];
  }
  const out = [];
  if (p.name) out.push(["Snapshot name", p.name]);
  if (p.snapshot_name) out.push(["Snapshot", p.snapshot_name]);
  if (c.kind === "vm_snapshot_revert") out.push(["Safety", "A snapshot of the current state is taken first, so the revert can be undone"]);
  return out;
}

async function renderChange(id) {
  setNav("changes");
  const d = await api("/changes/" + encodeURIComponent(id));
  const c = d.change;
  const live = ["scheduled", "running", "pending_approval"].includes(c.state);
  const facts = [
    ["State", changeMark(c.state)],
    ["Kind", KIND_LABEL[c.kind] || c.kind],
    ["Why", c.reason],
    ["Requested", c.requested_by + " (" + c.requested_role + "), " + fmtDateTime(c.requested_at)],
    ["Window", fmtDateTime(c.run_after) + (c.run_before ? " to " + fmtDateTime(c.run_before) : ", no end")],
    ["Parallel", c.max_parallel + " at a time"],
    c.started_at ? ["Started", fmtDateTime(c.started_at)] : null,
    c.finished_at ? ["Finished", fmtDateTime(c.finished_at)] : null,
    c.approval_required ? ["Approval", c.approved_by ? "By " + c.approved_by : "Waiting"] : null,
  ].filter(Boolean).concat(describeParams(c));

  const cancelBtn = can("operator") && live && !c.cancel_requested
    ? h("button", { type: "button", class: "btn btn-danger", on: { click: async () => {
        if (!confirm("Cancel " + ref(c.number) + "? Servers not yet started will not be touched; "
                     + "a server part way through stops before installing.")) return;
        try { await apiPost("/changes/" + c.id + "/cancel", {}); route(); }
        catch (e) { alert(e.message); }
      } } }, "Cancel change") : null;

  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl change show " + ref(c.number) }, ref(c.number) + "  " + c.title),
      h("span", { class: "head-actions" }, cancelBtn, h("a", { href: "#/changes", class: "small" }, "All changes"))),
    c.cancel_requested && live ? h("div", { class: "hs-alert st-unknown" }, h("strong", null, "Cancelling. "),
      "Servers part way through will stop before installing.") : null,
    await workerBanner(),
    h("dl", { class: "facts" }, facts.map(([k, v]) => h("div", null, h("dt", null, k), h("dd", null, v)))),
    h("section", null, h("h2", null, "Targets"),
      table([
        { label: "Target", nowrap: true, cell: t => t.host_id && c.kind === "patch"
            ? h("a", { href: "#/host/" + t.host_id }, t.label) : t.label },
        { label: "State", nowrap: true, cell: t => targetMark(t.state) },
        { label: "Packages", num: true, cell: t => ((t.detail || {}).packages || []).length || "" },
        // Only "kept" once the target has finished with it still in place
        { label: "Snapshot", nowrap: true, cell: t => !t.snapshot_moref ? ""
            : (["done", "failed", "skipped", "cancelled"].includes(t.state)
                ? "kept (" + t.snapshot_moref + ")" : t.snapshot_moref) },
        { label: "Since", nowrap: true, cell: t => t.step_started_at ? timeAgo(t.step_started_at) : "" },
        { label: "Problem", cell: t => t.error ? h("span", { class: "explain-error" }, t.error) : "" },
      ], d.targets || [])),
    h("section", null, h("h2", null, "What happened"),
      h("ol", { class: "timeline" }, (d.events || []).map(e =>
        h("li", { class: e.ok === false ? "tl-bad" : e.ok ? "tl-ok" : "" },
          h("span", { class: "tl-when" }, fmtDateTime(e.at)),
          h("span", { class: "tl-who" }, e.actor),
          h("span", { class: "tl-msg" }, e.message || e.event))))),
  );
  if (live) setPageTimer(() => { if (location.hash === "#/change/" + id) renderChange(id).catch(showError); }, 10000);
}

/* ---- new change --------------------------------------------------------- */

function localInputValue(d) {
  const z = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return z.toISOString().slice(0, 16);
}
function toIso(v) { return v ? new Date(v).toISOString() : null; }

function windowFields(opts) {
  const parallel = !(opts && opts.single);
  const start = h("input", { type: "datetime-local", value: localInputValue(new Date()) });
  const end = h("input", { type: "datetime-local" });
  const par = h("input", { type: "number", min: "1", max: "50", value: parallel ? "5" : "1" });
  const el = h("div", { class: "af-row" },
    h("label", null, h("span", null, "Start"), start),
    h("label", null, h("span", null, "End of window (optional)"), end),
    parallel ? h("label", null, h("span", null, "Servers at a time"), par) : null);
  return { el, get: () => ({ run_after: toIso(start.value), run_before: toIso(end.value),
                             max_parallel: Number(par.value) || 5 }) };
}

async function renderNewChange(params) {
  setNav("changes");
  if (!can("operator")) return render(h("div", { class: "empty" },
    h("p", null, "Scheduling changes needs the operator role.")));
  return params.get("kind") === "vm" ? renderNewVmChange(params) : renderNewPatch(params);
}

async function renderNewPatch(params) {
  const comp = await api("/admin/compliance");
  const pre = new Set((params.get("hosts") || "").split(",").filter(Boolean));
  const hosts = (comp.hosts || []).filter(x => x.host_status !== "decommissioned");
  const boxes = new Map();
  const list = h("div", { class: "pick-list" }, hosts.map(x => {
    const cb = h("input", { type: "checkbox", value: x.host_id });
    if (pre.has(x.host_id)) cb.checked = true;
    boxes.set(x.host_id, cb);
    return h("label", { class: "pick" }, cb,
      h("span", { class: "pick-name" }, x.hostname),
      h("span", { class: "muted" }, osLabel(x.os_id, x.os_version)),
      agentMark(x.agent_state),
      Number(x.affected) ? h("span", null, count(x.affected, "affected"), " to patch")
                         : h("span", { class: "muted" }, "up to date"));
  }));
  const selectNeeding = h("button", { type: "button", class: "btn btn-quiet", on: { click: () => {
    hosts.forEach(x => { boxes.get(x.host_id).checked = Number(x.affected) > 0; });
  } } }, "Select all needing patches");

  const mode = h("select", null, h("option", { value: "security" }, "All outstanding security fixes"),
                                 h("option", { value: "advisories" }, "Only the advisories listed below"));
  const advs = h("input", { type: "text", placeholder: "RHSA-2026:4417, RHSA-2026:4380", hidden: true });
  mode.addEventListener("change", () => { advs.hidden = mode.value !== "advisories"; });
  const reboot = h("select", null, h("option", { value: "if_required" }, "Only if required"),
                   h("option", { value: "never" }, "Never, just flag it"), h("option", { value: "always" }, "Always"));
  const snap = h("select", null, h("option", { value: "none" }, "No snapshot"),
                 h("option", { value: "remove_on_success" }, "Snapshot first, remove if it succeeds"),
                 h("option", { value: "keep" }, "Snapshot first, keep it"));
  const svc = h("input", { type: "checkbox", checked: true });
  const win = windowFields();
  const title = h("input", { type: "text", placeholder: "September security patching, prod web tier" });
  const reason = h("textarea", { rows: "2", placeholder: "Why this change is being made. Kept in the record." });
  const out = h("div");
  const err = h("p", { class: "explain-error", hidden: true });

  function body() {
    return {
      kind: "patch", title: title.value.trim() || null, reason: reason.value.trim(),
      targets: [...boxes.entries()].filter(([, cb]) => cb.checked).map(([id]) => ({ host_id: id })),
      params: { mode: mode.value, reboot: reboot.value, snapshot: snap.value, check_services: svc.checked,
                advisories: advs.value.split(/[,\s]+/).map(x => x.trim().toUpperCase()).filter(Boolean) },
      ...win.get(),
    };
  }
  async function preview() {
    err.hidden = true;
    try {
      const r = await apiPost("/changes/preview", body());
      const total = r.targets.reduce((a, t) => a + t.packages.length, 0);
      out.replaceChildren(h("h2", null, "What will happen"),
        h("p", null, total + " package installs across " + r.targets.length + " server"
          + (r.targets.length === 1 ? "" : "s") + ". Each server runs a pre-check first and stops if it fails."),
        table([
          { label: "Server", nowrap: true, cell: t => t.label },
          { label: "Advisories", num: true, cell: t => t.advisories.length },
          { label: "Packages", cell: t => t.packages.length
              ? t.packages.slice(0, 6).map(p => p.name).join(", ") + (t.packages.length > 6 ? " and " + (t.packages.length - 6) + " more" : "")
              : h("span", { class: "muted" }, "nothing to install") },
          { label: "VM", nowrap: true, cell: t => t.linked_vm ? "linked" : h("span", { class: "muted" }, "not linked") },
        ], r.targets));
    } catch (e) { err.textContent = e.message; err.hidden = false; }
  }
  async function submit() {
    err.hidden = true;
    try {
      const r = await apiPost("/changes", body());
      location.hash = "#/change/" + r.id;
    } catch (e) { err.textContent = e.message; err.hidden = false; }
  }
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl patch --new" }, "New patch job"),
      h("a", { href: "#/changes", class: "small" }, "All changes")),
    h("section", { class: "form-sec" }, h("h2", null, "1. Servers"),
      h("div", { class: "controls" }, selectNeeding), list),
    h("section", { class: "form-sec" }, h("h2", null, "2. What to install"),
      h("div", { class: "af-row" },
        h("label", null, h("span", null, "Install"), mode, advs),
        h("label", null, h("span", null, "Reboot afterwards"), reboot),
        h("label", null, h("span", null, "VM snapshot"), snap)),
      h("label", { class: "check" }, svc,
        h("span", null, "Check that services running before are still running afterwards"))),
    h("section", { class: "form-sec" }, h("h2", null, "3. When"), win.el),
    h("section", { class: "form-sec" }, h("h2", null, "4. Record"),
      h("label", null, h("span", null, "Title"), title),
      h("label", null, h("span", null, "Reason (required)"), reason)),
    err,
    h("div", { class: "form-actions" },
      h("button", { type: "button", class: "btn btn-quiet", on: { click: preview } }, "Preview"),
      h("button", { type: "button", class: "btn", on: { click: submit } }, "Schedule")),
    out);
}

async function renderNewVmChange(params) {
  const vc = params.get("vc"), moref = params.get("moref");
  const writers = await api("/admin/vmware/writers").catch(() => ({ vcenters: [] }));
  const canWrite = new Set((writers.vcenters || []).filter(v => v.can_write).map(v => v.name));
  if (!vc || !moref) {
    const all = await api("/admin/vmware/vms?view=all");
    const q = h("input", { type: "search", placeholder: "Find a VM by name, cluster or OS" });
    const res = h("div");
    const draw = () => {
      const needle = q.value.trim().toLowerCase();
      const rows = (all.vms || []).filter(v => !needle || [v.name, v.cluster, v.guest_os, v.vcenter]
        .join(" ").toLowerCase().includes(needle)).slice(0, 50);
      res.replaceChildren(table([
        { label: "VM", nowrap: true, cell: v => h("a", { href: "#/changes/new?kind=vm&vc="
            + encodeURIComponent(v.vcenter) + "&moref=" + encodeURIComponent(v.moref) }, v.name) },
        { label: "Power", nowrap: true, cell: v => POWER[v.power_state] || v.power_state },
        { label: "Cluster", nowrap: true, cell: v => v.cluster || "" },
        { label: "vCenter", nowrap: true, cell: v => v.vcenter + (canWrite.has(v.vcenter) ? "" : " (read-only)") },
      ], rows));
    };
    q.addEventListener("input", draw);
    render(h("div", { class: "page-head" }, h("h1", null, "New VMware action"),
             h("a", { href: "#/changes", class: "small" }, "All changes")),
           h("p", { class: "muted" }, "Choose the VM."), h("div", { class: "controls" }, q), res);
    draw();
    return;
  }
  const d = await api("/admin/vmware/vm/" + encodeURIComponent(vc) + "/" + encodeURIComponent(moref));
  const vm = d.vm, snaps = d.snapshots || [];
  if (!canWrite.has(vc)) {
    return render(h("div", { class: "page-head" }, h("h1", null, vm.vm)),
      h("div", { class: "hs-alert st-unknown" }, h("strong", null, "No write account for " + vc + ". "),
        "Snapshots and power actions need one. On PATCH-01: ",
        h("code", null, "./scripts/phase7-vmware.sh --add-writer " + vc)));
  }
  const on = vm.power_state === "poweredOn", tools = vm.tools_running === "guestToolsRunning";
  const opts = [
    ["vm_snapshot_create", "Take a snapshot", true],
    ["vm_snapshot_remove", "Remove a snapshot", snaps.length > 0],
    ["vm_snapshot_revert", "Revert to a snapshot", snaps.length > 0],
    ["vm_power_on", "Power on", !on],
    ["vm_guest_shutdown", "Shut down the guest OS cleanly", on && tools],
    ["vm_guest_restart", "Restart the guest OS cleanly", on && tools],
  ];
  const kind = h("select", null, opts.map(([v, l, ok]) => h("option", { value: v, disabled: !ok }, l + (ok ? "" : " (not available)"))));
  const snapName = h("input", { type: "text", placeholder: "Before config change CHG-4471", maxlength: "80" });
  const snapDesc = h("input", { type: "text", placeholder: "Optional description", maxlength: "500" });
  const memory = h("input", { type: "checkbox" });
  const snapSel = h("select", null, snaps.map(x => h("option", { value: x.moref },
    x.name + " (" + (x.created ? fmtDateTime(x.created) : "unknown date") + ")")));
  const confirmName = h("input", { type: "text", placeholder: vm.vm, autocomplete: "off" });
  const reason = h("textarea", { rows: "2", placeholder: "Why. Kept in the record." });
  const win = windowFields({ single: true });
  const go = h("button", { type: "button", class: "btn" }, "Schedule");
  const err = h("p", { class: "explain-error", hidden: true });
  const fields = h("div");

  function draw() {
    const k = kind.value;
    const parts = [];
    if (k === "vm_snapshot_create") parts.push(
      h("label", null, h("span", null, "Snapshot name"), snapName),
      h("label", null, h("span", null, "Description"), snapDesc),
      h("label", { class: "check" }, memory, h("span", null, "Include memory (slower, larger)")));
    if (k === "vm_snapshot_remove" || k === "vm_snapshot_revert") parts.push(
      h("label", null, h("span", null, "Snapshot"), snapSel));
    if (k === "vm_snapshot_revert") parts.push(
      h("div", { class: "hs-alert st-affected" }, h("strong", null, "A revert discards everything since that snapshot. "),
        "PATCH-01 takes a snapshot of the current state first, so the revert itself can be undone."),
      h("label", null, h("span", null, "Type the VM name to confirm: " + vm.vm), confirmName));
    if (k === "vm_guest_shutdown") parts.push(h("p", { class: "muted" },
      "Asks the guest OS to shut down through VMware Tools. PATCH-01 never pulls the power."));
    fields.replaceChildren(...parts);
    const revert = k === "vm_snapshot_revert";
    go.className = revert ? "btn btn-danger" : "btn";
    go.textContent = revert ? "Schedule revert" : "Schedule";
  }
  kind.addEventListener("change", draw);
  const firstOk = opts.find(o => o[2]); if (firstOk) kind.value = firstOk[0];
  draw();

  async function submit() {
    err.hidden = true;
    const k = kind.value;
    const p = k === "vm_snapshot_create" ? { name: snapName.value.trim(), description: snapDesc.value, memory: memory.checked }
      : (k === "vm_snapshot_remove" || k === "vm_snapshot_revert")
        ? { snapshot_moref: snapSel.value, confirm_name: confirmName.value } : {};
    try {
      const r = await apiPost("/changes", { kind: k, reason: reason.value.trim(),
        title: (KIND_LABEL[k] || k) + ": " + vm.vm, targets: [{ vcenter: vc, moref }], params: p, ...win.get() });
      location.hash = "#/change/" + r.id;
    } catch (e) { err.textContent = e.message; err.hidden = false; }
  }
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl vm " + vm.vm }, vm.vm),
      h("a", { href: "#/changes", class: "small" }, "All changes")),
    h("div", { class: "host-summary" },
      h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Power"), POWER[vm.power_state] || vm.power_state),
      h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Tools"), toolsLabel(vm.tools_running)),
      h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Host"), vm.esxi_host || ""),
      h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Snapshots"), snaps.length)),
    h("section", { class: "form-sec" }, h("h2", null, "Action"),
      h("label", null, h("span", null, "What to do"), kind), fields),
    h("section", { class: "form-sec" }, h("h2", null, "When"), win.el),
    h("section", { class: "form-sec" }, h("h2", null, "Record"),
      h("label", null, h("span", null, "Reason (required)"), reason)),
    err, h("div", { class: "form-actions" }, go));
  go.addEventListener("click", submit);
}

/* ---- users (admin) ------------------------------------------------------ */

async function renderUsers() {
  setNav("users");
  if (!can("admin")) return render(h("div", { class: "empty" }, h("p", null, "User management needs the admin role.")));
  const d = await api("/admin/users");
  const me = getAuth().user.username;
  const err = h("p", { class: "explain-error", hidden: true });

  async function patch(u, body, done) {
    try { await apiRequest("PATCH", "/admin/users/" + encodeURIComponent(u), body); renderUsers(); if (done) done(); }
    catch (e) { alert(e.message); }
  }
  const nu = h("input", { type: "text", placeholder: "jtan", autocapitalize: "none" });
  const nd = h("input", { type: "text", placeholder: "Jason Tan" });
  const nr = h("select", null, h("option", { value: "viewer" }, "Viewer"),
               h("option", { value: "operator" }, "Operator"), h("option", { value: "admin" }, "Admin"));
  const np = h("input", { type: "password", autocomplete: "new-password", placeholder: "Temporary, 12+ characters" });
  const add = h("form", { class: "assess-form", on: { submit: async e => {
    e.preventDefault(); err.hidden = true;
    try {
      await apiPost("/admin/users", { username: nu.value.trim().toLowerCase(), display_name: nd.value.trim(),
                                      role: nr.value, password: np.value });
      renderUsers();
    } catch (ex) { err.textContent = ex.message; err.hidden = false; }
  } } },
    h("div", { class: "af-row" },
      h("label", null, h("span", null, "Username"), nu),
      h("label", null, h("span", null, "Name"), nd),
      h("label", null, h("span", null, "Role"), nr),
      h("label", null, h("span", null, "Temporary password"), np)),
    err, h("button", { type: "submit" }, "Add user"),
    h("p", { class: "muted small" }, "They choose their own password at first sign-in."));

  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl users ls" }, "Users")),
    h("div", { class: "role-help" },
      h("p", null, h("strong", null, "Viewer "), "sees dashboards and reports. Changes nothing."),
      h("p", null, h("strong", null, "Operator "), "also schedules patching, VM snapshots and power actions, runs CVE assessments, and uses the chat and AI explanations."),
      h("p", null, h("strong", null, "Admin "), "everything, plus users and settings, and the BOT-MODE theme.")),
    table([
      { label: "User", nowrap: true, cell: u => [u.username, u.username === me ? h("span", { class: "muted" }, " (you)") : null] },
      { label: "Name", cell: u => u.display_name || "" },
      { label: "Role", nowrap: true, cell: u => {
          const sel = h("select", { disabled: u.username === me }, ["viewer", "operator", "admin"].map(r =>
            h("option", { value: r, selected: r === u.role }, r)));
          sel.addEventListener("change", () => patch(u.username, { role: sel.value }));
          return sel; } },
      { label: "State", nowrap: true, cell: u => !u.active ? h("span", { class: "muted" }, "disabled")
          : u.locked ? h("span", { class: "explain-error" }, "locked") : u.must_change_password ? "must change password" : "active" },
      { label: "Last sign-in", nowrap: true, cell: u => u.last_login_at ? timeAgo(u.last_login_at) : "never" },
      { label: "", nowrap: true, cell: u => u.username === me ? "" : h("span", { class: "row-actions" },
          h("button", { type: "button", class: "btn-link", on: { click: () => patch(u.username, { active: !u.active }) } },
            u.active ? "Disable" : "Enable"),
          u.locked ? h("button", { type: "button", class: "btn-link", on: { click: () => patch(u.username, { unlock: true }) } }, "Unlock") : null,
          h("button", { type: "button", class: "btn-link", on: { click: () => {
            const pw = prompt("New temporary password for " + u.username + " (12+ characters). They will change it at sign-in.");
            if (pw) patch(u.username, { new_password: pw });
          } } }, "Reset password")) },
    ], d.users || []),
    h("section", null, h("h2", null, "Add a user"), add));
}

async function apiRequest(method, path, body) {
  const res = await fetch("/api/v1" + path, {
    method, headers: { "Content-Type": "application/json", "X-Requested-With": "patch01-dashboard", ...authHeaders() },
    body: body ? JSON.stringify(body) : undefined });
  if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, data.detail || res.statusText);
  return data;
}

/* ---- admin chat --------------------------------------------------------- */
/*
 * Read-only by design. It answers questions and shows the rows behind every
 * answer; it cannot patch, snapshot or power anything. Those go through the
 * approval flow.
 */

const CHAT_EXAMPLES = [
  "Which servers are affected by CVE-2026-31337?",
  "Which rhel servers need patches?",
  "What CVEs are exploited in the wild?",
  "Which agents are offline?",
  "VMs with snapshots older than 30 days",
];

let chatHistoryEl = null;

function chatBubble(role, nodes) {
  return h("div", { class: "cm cm-" + role }, nodes);
}

function chatTable(res) {
  if (!res.rows || !res.rows.length) return null;
  const cols = (res.columns || []).map(c => ({
    label: c.replace(/_/g, " "),
    cell: r => {
      const v = r[c];
      if (v === null || v === undefined) return "";
      if (typeof v === "boolean") return v ? "yes" : "no";
      if (Array.isArray(v)) return v.join(", ");
      if (typeof v === "string" && /^\d{4}-\d{2}-\d{2}T/.test(v)) return timeAgo(v);
      return String(v);
    },
  }));
  return h("div", { class: "cm-table" }, table(cols, res.rows));
}

async function chatAsk(question) {
  const hist = chatHistoryEl;
  hist.append(chatBubble("you", question));
  const thinking = chatBubble("bot", h("span", { class: "cm-wait" }, "Looking"));
  hist.append(thinking);
  hist.scrollTop = hist.scrollHeight;
  try {
    const res = await apiPost("/admin/chat", { question });
    const meta = [];
    if (res.tool) meta.push("query: " + res.tool.replace(/_/g, " "));
    if (res.how) meta.push(res.how === "model" ? "chosen by AI-01" : "chosen by keywords");
    if (res.truncated) meta.push("first " + (res.rows || []).length + " rows");
    thinking.replaceWith(chatBubble("bot", [
      h("p", null, res.answer),
      chatTable(res),
      meta.length ? h("p", { class: "cm-meta" }, meta.join(" | ")) : null,
      res.tools ? h("ul", { class: "cm-tools" },
        res.tools.slice(0, 6).map(t => h("li", null, t.what))) : null,
    ]));
  } catch (err) {
    if (err.status === 401) { closeChat(); return renderSignIn(err.message); }
    thinking.replaceWith(chatBubble("bot",
      h("p", { class: "explain-error" },
        err.status === 404 ? "The API is older than the chat; rebuild it with phase3b-api.sh."
        : err.status === 429 ? "AI-01 is busy. Try again in a moment."
        : "Could not answer (HTTP " + (err.status || "error") + ").")));
  }
  hist.scrollTop = hist.scrollHeight;
}

function closeChat() {
  const p = document.getElementById("chat");
  const b = document.getElementById("chat-open");
  p.hidden = true;
  b.setAttribute("aria-expanded", "false");
  b.focus();
}

function buildChat() {
  const panel = document.getElementById("chat");
  chatHistoryEl = h("div", { class: "cm-history" },
    chatBubble("bot", [
      h("p", null, "Ask about servers, CVEs, agents or VMs. I read the data and show "
                 + "the rows behind every answer."),
      h("p", { class: "cm-meta" }, "Read-only: patching and VMware actions go through approval."),
      h("div", { class: "cm-examples" }, CHAT_EXAMPLES.map(q =>
        h("button", { type: "button", on: { click: () => { input.value = q; form.requestSubmit(); } } }, q))),
    ]));
  const input = h("input", { type: "text", placeholder: "Ask a question", autocomplete: "off",
                             "aria-label": "Your question", maxlength: "400" });
  const form = h("form", { class: "cm-form", on: { submit: e => {
    e.preventDefault();
    const q = input.value.trim();
    if (!q) return;
    input.value = "";
    chatAsk(q);
  } } }, input, h("button", { type: "submit" }, "Ask"));

  panel.replaceChildren(
    h("div", { class: "cm-head" },
      h("strong", null, "Ask about the fleet"),
      h("button", { type: "button", class: "quiet", on: { click: closeChat } }, "Close")),
    chatHistoryEl, form);
  panel.dataset.built = "1";
  return input;
}

function openChat() {
  const panel = document.getElementById("chat");
  const input = panel.dataset.built ? panel.querySelector(".cm-form input") : buildChat();
  panel.hidden = false;
  document.getElementById("chat-open").setAttribute("aria-expanded", "true");
  input.focus();
}

document.addEventListener("keydown", e => {
  if (e.key === "Escape" && !document.getElementById("chat").hidden) closeChat();
});

document.addEventListener("DOMContentLoaded", () => {
  const fab = document.getElementById("chat-open");
  fab.addEventListener("click", () => {
    document.getElementById("chat").hidden ? openChat() : closeChat();
  });
  fillThemeSelect(document.getElementById("theme"));
  window.addEventListener("hashchange", route);
  document.getElementById("refresh").addEventListener("click", route);
  document.getElementById("signout").addEventListener("click", () => {
    apiPost("/auth/logout", {}).catch(() => {});
    clearAuth();
    location.hash = "#/";
    renderSignIn();
  });
  start();
});
