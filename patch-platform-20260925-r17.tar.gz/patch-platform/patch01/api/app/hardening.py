"""Hardening: SCAP Security Guide content and OpenSCAP results.

One pinned content release is imported on PATCH-01 and served to agents.
Each product data stream (ssg-rhel9-ds.xml, ssg-ubuntu2204-ds.xml ...) has
its own profiles and rules. Agents scan with `oscap xccdf eval` and upload the
ARF result, which is kept as audit evidence and parsed into rule results.

Parsing follows XCCDF 1.2 selection rules rather than assuming how a content
release marks its rules, so a profile's rule list is right whichever way a
release chooses to express it.

Run as a module for the import step:
    python -m app.hardening import --dir /hardening/content/0.1.76 --version 0.1.76
    python -m app.hardening status
"""

import argparse
import glob
import gzip
import hashlib
import io
import json
import logging
import os
import re
import sys

log = logging.getLogger("hardening")

XCCDF = "http://checklists.nist.gov/xccdf/1.2"
X = "{%s}" % XCCDF
CONTENT_DIR = os.environ.get("HARDENING_DIR", "/hardening")
RULE_PREFIX = "xccdf_org.ssgproject.content_rule_"
PROFILE_PREFIX = "xccdf_org.ssgproject.content_profile_"

# Products imported from a release. A release carries dozens; these are the
# ones this fleet runs. Override with HARDENING_PRODUCTS.
PRODUCTS = [p.strip() for p in os.environ.get(
    "HARDENING_PRODUCTS",
    "rhel8,rhel9,rhel10,ol7,ol8,ol9,ubuntu2004,ubuntu2204,ubuntu2404").split(",") if p.strip()]

# CIS server profiles by short id. Workstation profiles are deliberately not
# offered: these are servers.
LEVEL_IDS = {
    "l1": {"cis_server_l1", "cis_level1_server"},
    "l2": {"cis", "cis_server_l2", "cis_level2_server"},
}

# Rules whose fixes are known to cause outages: remote access, logins,
# firewalls, privilege, auditing that can fill a disk, mounts, boot.
RISKY_RE = re.compile(r"(sshd_|(^|_)pam_|accounts_|faillock|pwquality|password|firewalld|nftables|"
                      r"iptables|(^|_)ufw|sudo|audit|mount_option|partition_|grub2_|selinux|"
                      r"kernel_module_|sysctl_net_|service_.*_disabled|package_.*_removed)")

RESULTS = ("pass", "fail", "notapplicable", "notchecked", "error", "unknown",
           "informational", "notselected", "fixed")


def short(ident, prefix):
    return ident[len(prefix):] if ident and ident.startswith(prefix) else ident


def level_of(profile_id):
    s = short(profile_id, PROFILE_PREFIX)
    for level, ids in LEVEL_IDS.items():
        if s in ids:
            return level
    return None


def product_for(os_id, os_version):
    """Which data stream judges this server, or None if there is none."""
    os_id = (os_id or "").lower()
    ver = str(os_version or "")
    major = ver.split(".")[0] if ver else ""
    if os_id in ("rhel", "redhat") and major.isdigit():
        return "rhel" + major
    if os_id in ("ol", "oracle", "oraclelinux") and major.isdigit():
        return "ol" + major
    if os_id == "ubuntu":
        m = re.match(r"(\d{2})\.(\d{2})", ver)
        return "ubuntu" + m.group(1) + m.group(2) if m else None
    return None


def product_of_file(path):
    m = re.match(r"ssg-(.+)-ds(?:-1\.\d)?\.xml$", os.path.basename(path))
    return m.group(1) if m else None


def _text(el):
    """All the text in an element, HTML markup and all, as readable prose."""
    if el is None:
        return None
    # Joined without separators: inline markup such as <code> sits inside a
    # sentence, and a space would land before the next full stop
    t = " ".join("".join(el.itertext()).split())
    return t or None


def _selected(el):
    v = el.get("selected")
    return True if v is None else v in ("true", "1")


# ---------------------------------------------------------------------------
# Benchmark content
# ---------------------------------------------------------------------------

def parse_datastream(path_or_bytes):
    """Profiles and rules of the XCCDF 1.2 benchmark inside a data stream."""
    from lxml import etree
    parser = etree.XMLParser(huge_tree=True, resolve_entities=False, no_network=True)
    if isinstance(path_or_bytes, (bytes, bytearray)):
        root = etree.fromstring(bytes(path_or_bytes), parser)
    else:
        root = etree.parse(path_or_bytes, parser).getroot()
    bench = root if root.tag == X + "Benchmark" else root.find(".//" + X + "Benchmark")
    if bench is None:
        raise ValueError("no XCCDF 1.2 benchmark in this data stream")

    rules, order = {}, []
    group_rules = {}          # group id -> rule ids beneath it
    defaults = {}             # rule id -> selected by default (rule and every ancestor group)

    def walk(node, inherited, groups):
        for child in node:
            if child.tag == X + "Group":
                gid = child.get("id")
                sel = inherited and _selected(child)
                walk(child, sel, groups + [gid])
            elif child.tag == X + "Rule":
                rid = child.get("id")
                refs = [r for r in child.findall(X + "reference")
                        if "cisecurity.org" in (r.get("href") or "")]
                cis = ", ".join(dict.fromkeys(
                    (r.text or "").strip() for r in refs if (r.text or "").strip())) or None
                fix = next((f for f in child.findall(X + "fix")
                            if (f.get("system") or "") == "urn:xccdf:fix:script:sh"), None)
                rules[rid] = {
                    "rule_id": rid,
                    "title": _text(child.find(X + "title")),
                    "severity": child.get("severity") or "unknown",
                    "description": _text(child.find(X + "description")),
                    "rationale": _text(child.find(X + "rationale")),
                    "cis_ref": cis,
                    "fix_available": fix is not None and bool((fix.text or "").strip() or len(fix)),
                    "fix_script": ("".join(fix.itertext()).strip() or None) if fix is not None else None,
                    "risky": bool(RISKY_RE.search(short(rid, RULE_PREFIX))),
                }
                order.append(rid)
                defaults[rid] = inherited and _selected(child)
                for g in groups:
                    group_rules.setdefault(g, []).append(rid)

    walk(bench, True, [])

    profiles = []
    for p in bench.findall(X + "Profile"):
        sel = dict(defaults)
        for s in p.findall(X + "select"):
            idref, on = s.get("idref"), _selected(s)
            if idref in rules:
                sel[idref] = on
            elif idref in group_rules:
                for rid in group_rules[idref]:
                    sel[rid] = on
        pid = p.get("id")
        chosen = [r for r in order if sel.get(r)]
        profiles.append({"profile_id": pid, "title": _text(p.find(X + "title")),
                         "level": level_of(pid), "rules": chosen})
    return {
        "title": _text(bench.find(X + "title")),
        "version": _text(bench.find(X + "version")),
        "rules": [rules[r] for r in order],
        "profiles": profiles,
    }


# ---------------------------------------------------------------------------
# Scan results (ARF, or a bare XCCDF TestResult)
# ---------------------------------------------------------------------------

def parse_results(data):
    """Summary and per-rule results from an oscap result file."""
    from lxml import etree
    if data[:2] == b"\x1f\x8b":
        data = gzip.decompress(data)
    parser = etree.XMLParser(huge_tree=True, resolve_entities=False, no_network=True)
    root = etree.fromstring(data, parser)
    tr = root if root.tag == X + "TestResult" else root.find(".//" + X + "TestResult")
    if tr is None:
        raise ValueError("no XCCDF TestResult in the upload")
    prof = tr.find(X + "profile")
    out = {"profile_id": prof.get("idref") if prof is not None else None,
           "start_time": tr.get("start-time"), "end_time": tr.get("end-time"),
           "rules": []}
    counts = {k: 0 for k in RESULTS}
    for rr in tr.findall(X + "rule-result"):
        res = (rr.findtext(X + "result") or "unknown").strip()
        res = res if res in RESULTS else "unknown"
        counts[res] += 1
        out["rules"].append({"rule_id": rr.get("idref"), "result": res,
                             "severity": rr.get("severity")})
    sc = tr.find(X + "score")
    out["oscap_score"] = float(sc.text) if sc is not None and sc.text else None
    judged = counts["pass"] + counts["fail"]
    out["score"] = round(100.0 * counts["pass"] / judged, 2) if judged else None
    out["counts"] = counts
    return out


# ---------------------------------------------------------------------------
# Database: import content, ingest a scan
# ---------------------------------------------------------------------------

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def import_release(conn, directory, version, activate=True):
    """Import every wanted product data stream in a release directory."""
    found = []
    for path in sorted(glob.glob(os.path.join(directory, "**", "ssg-*-ds.xml"), recursive=True)):
        product = product_of_file(path)
        if product not in PRODUCTS:
            continue
        log.info("reading %s", os.path.basename(path))
        b = parse_datastream(path)
        digest = sha256_file(path)
        rel = os.path.relpath(path, CONTENT_DIR) if path.startswith(CONTENT_DIR) else path
        with conn.transaction():
            conn.execute("DELETE FROM hardening_content WHERE content_version=%s AND product=%s",
                         (version, product))
            conn.execute(
                """INSERT INTO hardening_content (content_version, product, file_name, sha256,
                                                  benchmark_title, benchmark_version)
                   VALUES (%s, %s, %s, %s, %s, %s)""",
                (version, product, rel, digest, b["title"], b["version"]))
            with conn.cursor() as cur:
                cur.executemany(
                    """INSERT INTO hardening_rules (content_version, product, rule_id, title, severity,
                                                    description, rationale, cis_ref, fix_available,
                                                    fix_script, risky)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                    [(version, product, r["rule_id"], r["title"], r["severity"], r["description"],
                      r["rationale"], r["cis_ref"], r["fix_available"], r["fix_script"], r["risky"])
                     for r in b["rules"]])
                for p in b["profiles"]:
                    cur.execute(
                        """INSERT INTO hardening_profiles (content_version, product, profile_id,
                                                           title, level, rule_count)
                           VALUES (%s,%s,%s,%s,%s,%s)""",
                        (version, product, p["profile_id"], p["title"], p["level"], len(p["rules"])))
                    cur.executemany(
                        """INSERT INTO hardening_profile_rules (content_version, product, profile_id, rule_id)
                           VALUES (%s,%s,%s,%s)""",
                        [(version, product, p["profile_id"], r) for r in p["rules"]])
        levels = sorted({p["level"] for p in b["profiles"] if p["level"]})
        found.append({"product": product, "rules": len(b["rules"]), "profiles": len(b["profiles"]),
                      "cis_levels": levels})
    if not found:
        raise RuntimeError(f"no wanted ssg-*-ds.xml files under {directory}")
    if activate:
        with conn.transaction():
            conn.execute("UPDATE hardening_content SET active = (content_version = %s)", (version,))
    return found


def active_content(conn, product):
    return conn.execute(
        "SELECT * FROM hardening_content WHERE product=%s AND active", (product,)).fetchone()


def profile_for(conn, product, level):
    """The CIS profile of this level for a product in the active release."""
    return conn.execute(
        """SELECT p.* FROM hardening_profiles p
             JOIN hardening_content c USING (content_version, product)
            WHERE c.active AND p.product=%s AND p.level=%s
            ORDER BY p.profile_id LIMIT 1""", (product, level)).fetchone()


def ingest(conn, scan_id, data, oscap_version=None):
    """Keep the evidence, parse it, and record every rule result."""
    raw = gzip.decompress(data) if data[:2] == b"\x1f\x8b" else data
    parsed = parse_results(raw)
    ev_dir = os.path.join(CONTENT_DIR, "evidence")
    os.makedirs(ev_dir, exist_ok=True)
    path = os.path.join(ev_dir, f"{scan_id}.arf.xml.gz")
    with gzip.open(path, "wb") as fh:
        fh.write(raw)
    digest = hashlib.sha256(raw).hexdigest()
    c = parsed["counts"]
    with conn.transaction():
        conn.execute("DELETE FROM hardening_results WHERE scan_id=%s", (scan_id,))
        with conn.cursor() as cur:
            cur.executemany(
                "INSERT INTO hardening_results (scan_id, rule_id, result, severity) VALUES (%s,%s,%s,%s)",
                [(scan_id, r["rule_id"], r["result"], r["severity"]) for r in parsed["rules"]
                 if r["result"] != "notselected"])
        conn.execute(
            """UPDATE hardening_scans SET state='done', finished_at=now(), score=%s, oscap_score=%s,
                      passed=%s, failed=%s, not_applicable=%s, errors=%s, other=%s,
                      oscap_version=%s, evidence_path=%s, evidence_sha256=%s, error=NULL
                WHERE id=%s""",
            (parsed["score"], parsed["oscap_score"], c["pass"], c["fail"], c["notapplicable"],
             c["error"], c["notchecked"] + c["unknown"] + c["informational"] + c["fixed"],
             oscap_version, path, digest, scan_id))
    return {"score": parsed["score"], "counts": c}


SCAN_STALE_HOURS = 5


def queue_scan(conn, host, level, requested_by):
    """Queue one scan for a server, or say why it cannot run.

    host needs id, os_id and os_version. Shared by the API, the worker's
    schedule and the command line, so the rules are the same everywhere.
    """
    product = product_for(host["os_id"], host["os_version"])
    if not product:
        return None, f"no benchmark content exists for {host['os_id']} {host['os_version']}"
    c = active_content(conn, product)
    if not c:
        return None, f"no {product} content imported; run phase8-hardening.sh"
    p = profile_for(conn, product, level)
    if not p:
        return None, f"{product} content has no CIS {level.upper()} server profile"
    busy = conn.execute(
        """SELECT 1 FROM hardening_scans WHERE host_id=%s AND level=%s AND state IN ('queued','running')
              AND requested_at > now() - make_interval(hours => %s)""",
        (host["id"], level, SCAN_STALE_HOURS)).fetchone()
    if busy:
        return None, "a scan is already queued or running"
    scan = conn.execute(
        """INSERT INTO hardening_scans (host_id, content_version, product, profile_id, level, requested_by)
           VALUES (%s,%s,%s,%s,%s,%s) RETURNING id""",
        (host["id"], c["content_version"], product, p["profile_id"], level, requested_by)).fetchone()
    conn.execute(
        """INSERT INTO agent_commands (host_id, verb, params, expires_at)
           VALUES (%s, 'run_hardening_scan', %s, now() + make_interval(hours => %s))""",
        (host["id"], json.dumps({"scan_id": str(scan["id"]), "product": product,
                                  "profile_id": p["profile_id"], "content_sha256": c["sha256"],
                                  "content_path": f"/api/v1/agent/hardening/content/{product}"}),
         SCAN_STALE_HOURS))
    return str(scan["id"]), None


def queue_due(conn, level="l1", days=7, limit=50, requested_by="schedule"):
    """Queue scans for servers not scanned at this level in `days` days.
    Capped per call so a fleet is spread over hours, not scanned at once."""
    hosts = conn.execute(
        """SELECT h.id, h.hostname, h.os_id, h.os_version FROM hosts h
            WHERE h.status = 'active'
              AND NOT EXISTS (SELECT 1 FROM hardening_scans s WHERE s.host_id = h.id AND s.level = %s
                                 AND s.requested_at > now() - make_interval(days => %s))
            ORDER BY h.hostname LIMIT %s""", (level, days, limit)).fetchall()
    out = []
    for h in hosts:
        sid, why = queue_scan(conn, h, level, requested_by)
        out.append((h["hostname"], sid, why))
    return out


# ---------------------------------------------------------------------------
# Command line (run inside the API container)
# ---------------------------------------------------------------------------

def _db():
    import psycopg
    from psycopg.rows import dict_row
    return psycopg.connect(
        host=os.environ.get("PATCHDB_HOST", "postgres"),
        port=int(os.environ.get("PATCHDB_PORT", "5432")),
        dbname=os.environ.get("PATCHDB_NAME", "patchdb"),
        user=os.environ.get("PATCHDB_USER", "patchapi"),
        password=os.environ.get("PATCHDB_PASSWORD", ""),
        row_factory=dict_row, connect_timeout=15)


def main(argv=None):
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    ap = argparse.ArgumentParser(prog="hardening")
    sub = ap.add_subparsers(dest="cmd", required=True)
    im = sub.add_parser("import")
    im.add_argument("--dir", required=True)
    im.add_argument("--version", required=True)
    im.add_argument("--no-activate", action="store_true")
    sub.add_parser("status")
    sc = sub.add_parser("scan")
    sc.add_argument("--level", choices=["l1", "l2"], default="l1")
    sc.add_argument("--host", action="append", help="hostname; repeat for several; omit for all")
    a = ap.parse_args(argv)
    with _db() as conn:
        if a.cmd == "import":
            res = import_release(conn, a.dir, a.version, activate=not a.no_activate)
            for r in res:
                lv = ", ".join(x.upper() for x in r["cis_levels"]) or "no CIS server profile"
                print(f"  {r['product']:12} {r['rules']:5} rules  {r['profiles']:3} profiles  CIS: {lv}")
            return 0
        if a.cmd == "scan":
            hosts = conn.execute(
                """SELECT id, hostname, os_id, os_version FROM hosts
                    WHERE status <> 'decommissioned' AND (%s::text[] IS NULL OR hostname = ANY(%s::text[]))
                    ORDER BY hostname""", (a.host, a.host)).fetchall()
            with conn.transaction():
                for h in hosts:
                    sid, why = queue_scan(conn, h, a.level, "cli")
                    print(f"  {h['hostname']:30} {'queued' if sid else 'skipped: ' + why}")
            if not hosts:
                print("  no matching servers")
            return 0
        rows = conn.execute(
            """SELECT c.content_version, c.product, c.active, c.benchmark_version,
                      string_agg(DISTINCT upper(p.level), ', ') AS levels,
                      (SELECT count(*) FROM hardening_rules r
                        WHERE r.content_version=c.content_version AND r.product=c.product) AS rules
                 FROM hardening_content c
                 LEFT JOIN hardening_profiles p USING (content_version, product)
                GROUP BY 1,2,3,4 ORDER BY 1 DESC, 2""").fetchall()
        for r in rows:
            print(f"  {r['content_version']:9} {r['product']:12} {'ACTIVE' if r['active'] else '      '} "
                  f"{r['rules']:5} rules  CIS: {r['levels'] or 'none'}")
        if not rows:
            print("  no hardening content imported yet")
    return 0


if __name__ == "__main__":
    sys.exit(main())
