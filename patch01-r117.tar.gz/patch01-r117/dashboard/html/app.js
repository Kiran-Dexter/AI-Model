/* PATCH-01 console
 *
 * No framework and no build step: this is served on an air-gapped network.
 *
 * Every value from the API is inserted as text, never as HTML. Advisory
 * titles come from vendor feeds and hostnames from agents, so none of it is
 * trusted. The h() helper below only ever uses textContent.
 */
"use strict";

/* ---- state labels, in the words an operator uses ------------------------ */

const STATES = {
  // CVE advisories (Vulnerabilities): whether the installed version has the advisory's fix.
  // Not a patch list: what to install is what WSUS and the package manager report.
  affected:             { label: "Affected",       desc: "Installed version is older than the advisory's fix" },
  fixed_pending_reboot: { label: "Fixed, reboot needed", desc: "Fix installed, old version still running" },
  fixed_active:         { label: "Fixed",          desc: "Fix installed and running" },
  unknown:              { label: "No recent data", desc: "Host has not reported in 24 hours" },
};
const STATE_ORDER = ["affected", "fixed_pending_reboot", "fixed_active", "unknown"];

const HOST_STATUS = {
  active: "Reporting",
  stale: "Silent",
  pending: "Enrolled, no data yet",
  decommissioned: "Retired",
};

const AGENT_STATES = {
  online:        { label: "Online",        desc: "Checked in recently" },
  offline:       { label: "Offline",       desc: "Missed several check-ins" },
  not_reporting: { label: "Not reporting", desc: "Silent for over 24 hours; its verdicts are unknown" },
  no_data:       { label: "No data yet",   desc: "Enrolled but never checked in" },
};

function agentMark(state) {
  const a = AGENT_STATES[state] || { label: state || "unknown" };
  return h("span", { class: "agent ag-" + (state || "unknown") }, a.label);
}

function fmtUptime(sec) {
  if (sec === null || sec === undefined || sec === "") return h("span", { class: "muted" }, "not reported");
  const s = Number(sec);
  if (s < 3600) return Math.max(1, Math.round(s / 60)) + " min";
  if (s < 86400) {
    const hrs = Math.floor(s / 3600), m = Math.round((s % 3600) / 60);
    return hrs + " h" + (m ? " " + m + " min" : "");
  }
  const d = Math.floor(s / 86400), hrs = Math.round((s % 86400) / 3600);
  return d + (d === 1 ? " day" : " days") + (hrs ? " " + hrs + " h" : "");
}

/* ---- DOM helper: text only, never innerHTML ----------------------------- */

function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v === null || v === undefined || v === false) continue;
      if (k === "class") el.className = v;
      else if (k === "on") for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
      else if (k === "style") for (const [p, val] of Object.entries(v)) el.style.setProperty(p, val);
      else el.setAttribute(k, v === true ? "" : String(v));
    }
  }
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}

/* ---- formatting --------------------------------------------------------- */

function timeAgo(iso) {
  if (!iso) return "never";
  const t = new Date(iso).getTime();
  if (isNaN(t)) return "unknown";
  const s = Math.round((Date.now() - t) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return Math.round(s / 60) + " min ago";
  if (s < 86400) return Math.round(s / 3600) + " h ago";
  const d = Math.round(s / 86400);
  return d === 1 ? "1 day ago" : d + " days ago";
}

function fmtDateTime(iso) {
  if (!iso) return "never";
  const d = new Date(iso);
  if (isNaN(d)) return String(iso);
  return d.toLocaleString(undefined, {
    year: "numeric", month: "short", day: "numeric",
    hour: "2-digit", minute: "2-digit",
  });
}

function fmtDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d)) return String(iso);
  return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function osLabel(osId, ver) {
  const names = { rhel: "RHEL", ol: "Oracle Linux", ubuntu: "Ubuntu", windows: "Windows Server" };
  return (names[osId] || osId || "") + (ver ? " " + ver : "");
}

function count(n, state) {
  const v = Number(n) || 0;
  return h("span", { class: "count " + (v === 0 ? "zero" : "st-" + state) }, v);
}

/* A host that has stopped reporting has no trustworthy counts. Showing 0
   would read as "clean", which is the exact failure the unknown state
   exists to prevent. */

function stateMark(state) {
  const s = STATES[state] || { label: state };
  return h("span", { class: "state st-" + state }, s.label);
}

function sevLabel(sev) {
  if (!sev) return h("span", { class: "muted" }, "unrated");
  return h("span", { class: "sev sev-" + sev }, sev.charAt(0).toUpperCase() + sev.slice(1));
}

/* ---- auth --------------------------------------------------------------- */

const AUTH_KEY = "patch01.session";

/* The session: a token from /auth/login and who it belongs to. Kept for this
   browser tab only, and never the password itself. */
function getAuth() {
  try {
    const a = JSON.parse(sessionStorage.getItem(AUTH_KEY));
    return a && a.token && a.user ? a : null;
  } catch (e) { return null; }
}
function setSession(data) {
  sessionStorage.setItem(AUTH_KEY, JSON.stringify({ token: data.token, user: data.user }));
}
function clearAuth() { sessionStorage.removeItem(AUTH_KEY); }

const ROLE_RANK = { viewer: 0, operator: 1, admin: 2 };
function myRole() { const a = getAuth(); return a ? a.user.role : null; }
function can(needed) { return (ROLE_RANK[myRole()] ?? -1) >= ROLE_RANK[needed]; }

function authHeaders() {
  const a = getAuth();
  return a ? { Authorization: "Bearer " + a.token } : {};
}

class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

// A page load that the user has navigated away from: thrown by api() and ignored by route()
class StaleRoute extends Error {}

async function api(path) {
  const seq = typeof routeSeq === "number" ? routeSeq : 0;
  const res = await fetch("/api/v1" + path, {
    headers: {
      "Accept": "application/json",
      "X-Requested-With": "patch01-dashboard",
      ...authHeaders(),
    },
    cache: "no-store",
  });
  if (res.status === 401) {
    clearAuth();
    throw new ApiError(401, "Your session has ended. Sign in again.");
  }
  if (res.status === 403) {
    let d = ""; try { d = (await res.json()).detail || ""; } catch (e) { /* not JSON */ }
    if (d === "password_change_required") { renderChangePassword(true); throw new ApiError(403, d); }
    if (d === "two_factor_setup_required") { renderTwoFactor(true); throw new ApiError(403, d); }
    throw new ApiError(403, d || "You do not have permission for this.");
  }
  if (!res.ok) {
    let detail = "";
    try { detail = (await res.json()).detail || ""; } catch (e) { /* not JSON */ }
    throw new ApiError(res.status, detail || httpReason(res));
  }
  if (typeof routeSeq === "number" && seq !== routeSeq) {
    // The user moved to another page while this loaded: the old page must not draw over the new one
    throw new StaleRoute("stale");
  }
  return res.json();
}

// A failure with no explanation from the server still says what kind it was
function httpReason(res) {
  if (res.status >= 500) return "The server hit an error (HTTP " + res.status + "). "
    + "On PATCH-01, the API log has the reason: sudo docker logs --tail 50 patch01-api";
  return (res.statusText || "The request failed") + " (HTTP " + res.status + ")";
}

// FastAPI reports rejected fields as a list; turn any detail into a sentence
function detailText(d) {
  if (!d) return "";
  if (typeof d === "string") return d;
  if (Array.isArray(d)) return d.map(x => {
    const where = (x.loc || []).filter(p => p !== "body").join(".");
    return (where ? where + ": " : "") + (x.msg || JSON.stringify(x));
  }).join("; ");
  return d.message || JSON.stringify(d);
}

async function apiSend(method, path, body) {
  const res = await fetch("/api/v1" + path, {
    method,
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "X-Requested-With": "patch01-dashboard",
      ...authHeaders(),
    },
    body: method === "GET" || method === "DELETE" ? undefined : JSON.stringify(body || {}),
    cache: "no-store",
  });
  if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
  if (res.status === 403) {
    let d = ""; try { d = detailText((await res.json()).detail); } catch (e) { /* not JSON */ }
    if (d === "password_change_required") { renderChangePassword(true); throw new ApiError(403, d); }
    if (d === "two_factor_setup_required") { renderTwoFactor(true); throw new ApiError(403, d); }
    throw new ApiError(403, d || "You do not have permission for this.");
  }
  if (!res.ok) {
    let detail = "";
    try { detail = detailText((await res.json()).detail); } catch (e) { /* not JSON */ }
    throw new ApiError(res.status, detail || httpReason(res));
  }
  return res.json();
}

async function apiPost(path, body) { return apiSend("POST", path, body); }

/* ---- explanations from AI-01 --------------------------------------------- */

const EXPLAINABLE = new Set(["affected", "fixed_pending_reboot"]);

function explainError(err) {
  if (err.status === 429) return "AI-01 is busy with another explanation. Try again in a moment.";
  if (err.status === 503) return "AI-01 is not available: " + (err.message || "not configured or unreachable") + ".";
  if (err.status === 404) return "This verdict no longer exists. Refresh the page.";
  return "Could not get an explanation (HTTP " + (err.status || "error") + ").";
}


/* ---- rendering scaffolding ---------------------------------------------- */

const view = () => document.getElementById("view");

function render(...nodes) {
  const v = view();
  // replaceChildren would turn null into the text "null"
  v.replaceChildren(...nodes.flat().filter(n => n !== null && n !== undefined && n !== false));
  v.focus({ preventScroll: true });
}

function showError(err) {
  if (err instanceof StaleRoute) return;              // a page the user already left
  if (err.status === 401) return renderSignIn(err.message);
  const hints = {
    502: ["The API container is not answering. Check it with ", h("code", null, "./scripts/phase3b-api.sh --check"), "."],
    503: ["The API is up but cannot reach the database. Check ", h("code", null, "./scripts/phase1b-data.sh --check"), "."],
    404: ["This endpoint does not exist. The API image may be older than the dashboard; rebuild it with ", h("code", null, "./scripts/phase3b-api.sh"), "."],
  };
  render(
    h("div", { class: "error", role: "alert" },
      h("h2", null, "Could not load this page"),
      h("p", null, "The API returned HTTP " + (err.status || "error") + (err.message ? ": " + err.message : ".")),
      hints[err.status] ? h("p", null, hints[err.status]) : null,
    )
  );
}

function setNav(name) {
  const key = (typeof NAV_ALIAS !== "undefined" && NAV_ALIAS[name]) || name;
  document.querySelectorAll(".side nav a[data-nav]").forEach(a => {
    if (a.dataset.nav === key) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
  });
}

function table(columns, rows, opts = {}) {
  if (opts.paged) {                                // a paged list: sort the whole list, then take the page
    const p = opts.paged;
    rows = sortItems(p.key, p.items, columns).slice((p.page - 1) * p.size, p.page * p.size);
    opts = Object.assign({}, opts, { sortKey: p.key, redraw: p.redraw });
  }
  // Paged lists sort their data before paging: they pass sortKey (and redraw) or onSort
  const own = !!(opts.onSort || opts.sortKey);
  const st = opts.sort || (opts.sortKey ? sortState(opts.sortKey) : null);
  const onSort = opts.onSort || (opts.sortKey ? i => { toggleSort(opts.sortKey, i); if (opts.redraw) opts.redraw(); } : null);
  const thead = h("thead", null, h("tr", null,
    columns.map((c, i) => own ? sortHead(c, i, st, onSort) : h("th", { class: c.num ? "num" : null, scope: "col" }, c.label))));
  const tbody = h("tbody", null, rows.map(r => {
    const tr = h("tr", { class: opts.onRow ? "clickable" : null },
      columns.map(c => h("td", { class: [c.num ? "num" : "", c.mono ? "mono" : "",
                                         c.nowrap ? "nowrap" : ""].join(" ").trim() || null },
        c.cell(r))));
    if (opts.onRow) {
      tr.addEventListener("click", e => {
        if (e.target.closest("a")) return;
        opts.onRow(r, tr);
      });
    }
    return tr;
  }));
  return h("div", { class: "table-wrap" }, h("table", { "data-own-sort": own ? "1" : null, "data-paged": opts.paged ? "1" : null }, thead, tbody));
}

/* ---- theme picker ------------------------------------------------------- */

function fillThemeOptions(sel) {
  const T = window.PatchTheme;
  const admin = can("admin");
  // Before sign-in the role is unknown: offer B-Mode only if it is active
  const signedIn = !!getAuth();
  const opts = T.options.filter(([v]) => v !== "hacker" || admin || (!signedIn && T.get() === "hacker"));
  sel.replaceChildren(...opts.map(([v, label]) => h("option", { value: v }, label)));
}

function fillThemeSelect(sel) {
  const T = window.PatchTheme;
  if (!T) return sel;
  fillThemeOptions(sel);
  sel.value = T.get();
  sel.addEventListener("change", () => {
    T.set(sel.value);
    // keep any other picker on the page in step
    document.querySelectorAll("select[data-theme-select]").forEach(o => { o.value = sel.value; });
  });
  sel.setAttribute("data-theme-select", "");
  return sel;
}

function themePicker() {
  const sel = fillThemeSelect(h("select", { "aria-label": "Theme" }));
  return h("label", { class: "theme-pick" }, h("span", null, "Theme"), sel);
}

/* ---- the frame: menu on the left, bar on top --------------------------- */

/* Shown once signed in; hidden on the sign-in, two-factor and password pages */
function showShell(on) {
  ["top", "side"].forEach(id => { const el = document.getElementById(id); if (el) el.hidden = !on; });
  const sub = document.getElementById("subnav"); if (sub && !on) sub.hidden = true;
  document.body.classList.toggle("shell", !!on);
  if (!on) sideOpen(false);
}

/* Phones: the menu slides in over the page */
function sideOpen(on) {
  document.body.classList.toggle("side-open", !!on);
  const t = document.getElementById("side-toggle"); if (t) t.setAttribute("aria-expanded", String(!!on));
  const sc = document.getElementById("side-scrim"); if (sc) sc.hidden = !on;
}

/* ---- sign in ------------------------------------------------------------ */

/* Small line icons for the sign-in form */
const LG_ICONS = {
  user: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4.5 20.5c.8-3.6 3.9-5.5 7.5-5.5s6.7 1.9 7.5 5.5",
  lock: "M6 11h12v9H6zM8.5 11V8a3.5 3.5 0 0 1 7 0v3",
  eye: "M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",
};
function lgIcon(name) {
  const NS = "http://www.w3.org/2000/svg";
  const s = document.createElementNS(NS, "svg");
  s.setAttribute("viewBox", "0 0 24 24"); s.setAttribute("class", "lg-ico lg-ico-" + name);
  s.setAttribute("aria-hidden", "true"); s.setAttribute("focusable", "false");
  const p = document.createElementNS(NS, "path"); p.setAttribute("d", LG_ICONS[name] || "");
  s.append(p);
  return s;
}

function renderSignIn(message) {
  showShell(false);
  document.body.classList.remove("signed-in");
  const fab = document.getElementById("chat-open");
  if (fab) fab.hidden = true;
  if (typeof chatPip !== "undefined" && chatPip) chatPip.close();
  const cp = chatPanel();
  if (cp) cp.hidden = true;
  const err = message ? h("div", { class: "error", role: "alert" }, message) : null;
  const user = h("input", { type: "text", name: "user", autocomplete: "username", required: true,
                            autocapitalize: "none", spellcheck: "false" });
  const pass = h("input", { type: "password", name: "pass", autocomplete: "current-password", required: true });
  const btn = h("button", { type: "submit" }, "Sign in", h("span", { class: "lg-arrow", "aria-hidden": "true" }, " \u2192"));
  // Show or hide the password while typing it
  const eye = h("button", { type: "button", class: "lg-eye", "aria-label": "Show password", "aria-pressed": "false",
    on: { click: () => {
      const show = pass.type === "password";
      pass.type = show ? "text" : "password";
      eye.setAttribute("aria-pressed", String(show));
      eye.setAttribute("aria-label", show ? "Hide password" : "Show password");
      pass.focus();
    } } }, lgIcon("eye"));
  const field = (label, input, icon, after) => h("label", { class: "lg-field" }, h("span", null, label),
    h("span", { class: "lg-in" }, lgIcon(icon), input, after || null));
  user.placeholder = "Enter your username";
  pass.placeholder = "Enter your password";

  const form = h("form", {
    class: "signin",
    on: {
      submit: async e => {
        e.preventDefault();
        btn.disabled = true;
        btn.textContent = "Signing in";
        try {
          const res = await fetch("/api/v1/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json", "X-Requested-With": "patch01-dashboard" },
            body: JSON.stringify({ username: user.value.trim().toLowerCase(), password: pass.value }),
          });
          const data = await res.json().catch(() => ({}));
          if (!res.ok) throw new ApiError(res.status, data.detail || "Sign-in failed.");
          if (data.mfa_required) return renderSecondFactor(data.mfa_ticket, user.value.trim().toLowerCase());
          signedIn(data);
          return;
        } catch (ex) {
          clearAuth();
          renderSignIn(ex.status === 401 ? ex.message
            : "Could not reach the API (HTTP " + (ex.status || "error") + ").");
        }
      },
    },
  },
    themePicker(),
    h("h2", { class: "signin-h" }, "Welcome back"),
    h("p", { class: "lg-sub" }, "Sign in to your security workspace."),
    err,
    field("Username", user, "user"),
    field("Password", pass, "lock", eye),
    btn,
    h("p", { class: "lg-need" }, "Need access? Ask an admin for an account."),
    h("p", { class: "lg-auth" }, lgIcon("lock"), "Authorised personnel only."),
  );
  view().replaceChildren(form);
  user.focus();
  // The welcome, logo and CVE news board around the form (cyber.js)
  if (typeof signinDecor === "function") {
    signinDecor(form).then(page => {
      if (!page) return;
      const focused = page.prevFocus;
      view().replaceChildren(page);
      (focused && page.contains(focused) ? focused : user).focus();
    }).catch(() => {});
  }
}

/* Signed in: say hello by name, then where the user was heading */
function signedIn(data) {
  setSession(data);
  applyRoleTheme();
  try { sessionStorage.setItem("cs.welcome", "1"); } catch (e) { /* private mode */ }
  if (data.user.must_change_password) return renderChangePassword(true);
  if (data.user.must_setup_2fa) return renderTwoFactor(true);
  if (typeof takeAfterSignIn === "function" && takeAfterSignIn()) return;
  start();
}

function welcomeToast() {
  let due = false;
  try { due = sessionStorage.getItem("cs.welcome") === "1"; sessionStorage.removeItem("cs.welcome"); } catch (e) { due = false; }
  const a = getAuth();
  if (!due || !a) return;
  const hour = new Date().getHours();
  const part = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const t = h("div", { class: "welcome-toast", role: "status" },
    h("strong", null, part + ", " + (a.user.display_name || a.user.username) + "."),
    h("span", null, " Welcome to " + (typeof PORTAL !== "undefined" ? PORTAL : "Cyber-Secure") + "."));
  // In the page's flow, above its heading: it never covers what is on the page
  const view = document.getElementById("view");
  if (!view) return;
  view.prepend(t);
  setTimeout(() => t.classList.add("welcome-out"), 6000);
  setTimeout(() => t.remove(), 6700);
}

/* The second step when the account has two-factor sign-in */
function renderSecondFactor(ticket, username) {
  const code = h("input", { type: "text", inputmode: "numeric", autocomplete: "one-time-code", maxlength: "11",
                            required: true, placeholder: "123456", "aria-label": "Code from your authenticator app" });
  const err = h("div", { class: "error", role: "alert", hidden: true });
  const btn = h("button", { type: "submit" }, "Verify");
  const form = h("form", { class: "signin", on: { submit: async e => {
    e.preventDefault(); err.hidden = true; btn.disabled = true; btn.textContent = "Checking";
    try {
      const res = await fetch("/api/v1/auth/login/2fa", { method: "POST",
        headers: { "Content-Type": "application/json", "X-Requested-With": "patch01-dashboard" },
        body: JSON.stringify({ mfa_ticket: ticket, code: code.value.trim() }) });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new ApiError(res.status, data.detail || "The code was not accepted.");
      if (data.recovery_codes_left !== undefined) alert("You used a recovery code. " + data.recovery_codes_left + " left: set up two-factor sign-in again soon (Your account).");
      signedIn(data);
    } catch (ex) {
      if (/expired|too many/i.test(ex.message)) return renderSignIn(ex.message);
      err.textContent = ex.message; err.hidden = false; btn.disabled = false; btn.textContent = "Verify"; code.select();
    }
  } } },
    h("h2", { class: "signin-h" }, "Two-factor sign-in"),
    h("p", { class: "muted small" }, "Signing in as " + username + ". Enter the 6-digit code from your authenticator app, or one of your recovery codes."),
    err,
    h("label", null, h("span", null, "Code"), code),
    btn,
    h("p", { class: "small" }, h("a", { href: "#/", on: { click: e => { e.preventDefault(); renderSignIn(); } } }, "Start again")));
  const host = view().querySelector("form.signin");
  if (host) host.replaceWith(form); else view().replaceChildren(form);
  code.focus();
}

/* Your account: password, and two-factor sign-in (forced: required before going on) */
async function renderTwoFactor(forced) {
  const a = getAuth();
  if (!a) return renderSignIn();
  if (forced) showShell(false);
  let st = { enabled: false, recovery_codes_left: 0, required: false, available: true };
  try { st = await api("/auth/2fa"); } catch (e) { /* shown below */ }
  const box = h("section", { class: "signin mfa-box" });
  const err = h("p", { class: "explain-error", hidden: true });
  const fail = m => { err.textContent = m; err.hidden = false; };
  function drawOff() {
    const pw = h("input", { type: "password", autocomplete: "current-password", "aria-label": "Your password" });
    const go = h("button", { type: "button", on: { click: async () => {
      err.hidden = true;
      try { const r = await apiPost("/auth/2fa/setup", { password: pw.value }); drawScan(r); } catch (e) { fail(e.message); }
    } } }, "Set up");
    box.replaceChildren(
      h("h1", null, "Two-factor sign-in"),
      h("p", { class: "muted" }, forced ? "This console needs two-factor sign-in for every account. Set it up now with an authenticator app "
        + "(Microsoft Authenticator, Google Authenticator or similar)." : "Sign in with your password and a code from an authenticator app "
        + "(Microsoft Authenticator, Google Authenticator or similar) on your phone."),
      st.available ? null : h("p", { class: "explain-error" }, "Two-factor sign-in is not set up on PATCH-01 yet (its key is missing): ask the administrator."),
      h("label", null, h("span", null, "Your password, to confirm"), pw), err, go,
      forced ? null : h("p", null, h("a", { href: "#/password" }, "Change your password instead")));
    pw.focus();
  }
  function drawScan(r) {
    const code = h("input", { type: "text", inputmode: "numeric", autocomplete: "one-time-code", maxlength: "6", placeholder: "123456", "aria-label": "First code" });
    const img = h("img", { class: "mfa-qr", alt: "QR code for your authenticator app", width: "220", height: "220",
      src: "data:image/svg+xml;charset=utf-8," + encodeURIComponent(r.qr_svg) });
    const ok = h("button", { type: "button", on: { click: async () => {
      err.hidden = true;
      try { const x = await apiPost("/auth/2fa/enable", { code: code.value.trim() }); drawCodes(x.recovery_codes || []); } catch (e) { fail(e.message); }
    } } }, "Turn on");
    box.replaceChildren(h("h1", null, "Scan with your authenticator app"),
      h("p", { class: "muted small" }, "1. In the app, add an account and scan this code. 2. Type the 6-digit code it shows."),
      img,
      h("details", { class: "small" }, h("summary", null, "Cannot scan? Type this key instead"), h("code", { class: "mfa-key" }, r.secret.replace(/(.{4})/g, "$1 ").trim())),
      h("label", null, h("span", null, "Code from the app"), code), err, ok);
    code.focus();
  }
  function drawCodes(codes) {
    const s2 = getAuth(); if (s2) { s2.user.totp_enabled = true; s2.user.must_setup_2fa = false; setSession(s2); }
    box.replaceChildren(h("h1", null, "Two-factor sign-in is on"),
      h("p", null, "Keep these recovery codes somewhere safe (not on the phone). Each works once if the phone is lost. They are not shown again."),
      h("pre", { class: "mfa-codes" }, codes.join("\n")),
      h("button", { type: "button", on: { click: () => { if (forced) start(); else location.hash = "#/"; } } }, "I have saved them"));
  }
  function drawOn() {
    const pw = h("input", { type: "password", autocomplete: "current-password", "aria-label": "Your password" });
    const code = h("input", { type: "text", inputmode: "numeric", autocomplete: "one-time-code", maxlength: "6", placeholder: "123456", "aria-label": "Code" });
    box.replaceChildren(h("h1", null, "Two-factor sign-in"),
      h("p", null, h("span", { class: "state st-fixed_active" }, "On"), " since " + fmtDateTime(st.enabled_at) + ". "
        + st.recovery_codes_left + " recovery code" + (st.recovery_codes_left === 1 ? "" : "s") + " left."),
      st.required ? h("p", { class: "muted small" }, "Required for every account here. A lost phone: ask an admin to reset it.")
        : h("details", null, h("summary", null, "Turn it off"),
            h("label", null, h("span", null, "Your password"), pw), h("label", null, h("span", null, "Code from the app"), code),
            h("button", { type: "button", class: "btn-danger", on: { click: async () => {
              err.hidden = true;
              try { await apiPost("/auth/2fa/disable", { password: pw.value, code: code.value.trim() }); route(); } catch (e) { fail(e.message); }
            } } }, "Turn off")),
      err, h("p", null, h("a", { href: "#/password" }, "Change your password")));
  }
  st.enabled ? drawOn() : drawOff();
  view().replaceChildren(box);
}

function renderChangePassword(forced) {
  const a = getAuth();
  if (!a) return renderSignIn();
  if (forced) {
    showShell(false);
    document.getElementById("chat-open").hidden = true;
  }
  const cur = h("input", { type: "password", autocomplete: "current-password", required: true });
  const nw = h("input", { type: "password", autocomplete: "new-password", required: true, minlength: "12" });
  const nw2 = h("input", { type: "password", autocomplete: "new-password", required: true });
  const err = h("p", { class: "explain-error", hidden: true });
  const btn = h("button", { type: "submit" }, "Change password");
  const form = h("form", { class: "signin", on: { submit: async e => {
    e.preventDefault(); err.hidden = true;
    if (nw.value !== nw2.value) { err.textContent = "The new passwords do not match."; err.hidden = false; return; }
    btn.disabled = true;
    try {
      await apiPost("/auth/password", { current_password: cur.value, new_password: nw.value });
      const s = getAuth(); s.user.must_change_password = false; setSession(s);
      if (s.user.must_setup_2fa) return renderTwoFactor(true);
      start();
    } catch (ex) {
      err.textContent = ex.message; err.hidden = false; btn.disabled = false;
    }
  } } },
    h("h1", { "data-cmd": "passwd " + a.user.username }, "Choose a new password"),
    h("p", { class: "muted" }, forced
      ? "Your password was set by an admin. Choose your own before continuing."
      : "At least 12 characters, mixing at least three of: lowercase, uppercase, digits, symbols."),
    h("label", null, h("span", null, "Current password"), cur),
    h("label", null, h("span", null, "New password"), nw),
    h("label", null, h("span", null, "New password again"), nw2),
    err, btn,
    forced ? null : h("p", null, h("a", { href: "#/two-factor" }, "Two-factor sign-in"), " \u00b7 ", h("a", { href: "#/" }, "Cancel")));
  view().replaceChildren(form);
  cur.focus();
}

/* B-Mode is for admins. Viewers and operators get Default and Dark,
   and a stored B-Mode choice falls back to Dark for them. */
function applyRoleTheme() {
  const T = window.PatchTheme;
  if (!T) return;
  if (!can("admin") && T.get() === "hacker") T.set("dark");
  document.querySelectorAll("select[data-theme-select]").forEach(sel => {
    const v = sel.value;
    fillThemeOptions(sel);
    sel.value = [...sel.options].some(o => o.value === v) ? v : T.get();
  });
}

/* ---- overview: the Cyber-Secure dashboard is in cyber.js ------------------ */

/* ---- hosts -------------------------------------------------------------- */

/* ---- host detail -------------------------------------------------------- */
/*
 * Two panes: the advisory list on the left stays still, and the selected
 * advisory's details and explanation open on the right. Nothing in the list
 * moves when an explanation loads. On narrow screens the panel becomes a
 * sheet over the bottom of the page.
 */

const explainCache = new Map();   // advisory id -> result, for this page view

function wideScreen() { return window.matchMedia("(min-width: 1100px)").matches; }

async function renderHost(id, params) {
  setNav("hosts");
  const [detail, advs, vmres] = await Promise.all([
    api("/admin/hosts/" + encodeURIComponent(id)),
    api("/admin/hosts/" + encodeURIComponent(id) + "/advisories"),
    api("/admin/hosts/" + encodeURIComponent(id) + "/vm").catch(() => null),
  ]);
  const host = detail.host;
  const rows = advs.advisories || [];
  const vm = vmres && vmres.vm;
  const oldDays = (vmres && vmres.snapshot_old_days) || 7;
  explainCache.clear();

  const counts = {};
  rows.forEach(r => { counts[r.state] = (counts[r.state] || 0) + 1; });
  let show = params.get("state") || (counts.affected ? "affected"
    : counts.fixed_pending_reboot ? "fixed_pending_reboot" : "all");
  let selected = null;

  /* -- summary line: the four facts that matter, reboot folded in -------- */
  const stale = host.status === "stale";
  const kernelDiffers = host.kernel_latest && host.kernel_running &&
    !host.kernel_running.startsWith(host.kernel_latest.replace(/\.(x86_64|aarch64)$/, ""));
  const summary = h("div", { class: "host-summary" },
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "OS"),
      osLabel(host.os_id, host.os_version) + " " + (host.arch || "")),
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Running"),
      h("span", { class: "mono" }, host.kernel_running || "unknown")),
    h("span", { class: "hs-item" + (stale ? " host-silent" : "") }, h("span", { class: "hs-k" }, "Reported"),
      timeAgo(host.last_checkin)),
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Up"),
      host.boot_time ? fmtUptime((Date.now() - new Date(host.boot_time).getTime()) / 1000) : fmtUptime(null)),
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Packages"), detail.package_count),
    vm ? h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "VM"),
           h("a", { href: "#/vmware?view=linux" }, vm.name),
           vm.cluster ? h("span", { class: "muted" }, " on " + vm.cluster) : null) : null,
  );

  const alerts = [];
  if (host.reboot_required) {
    alerts.push(h("div", { class: "hs-alert st-fixed_pending_reboot" },
      h("strong", null, "Needs reboot"),
      kernelDiffers
        ? h("span", null, " to run the installed kernel ", h("span", { class: "mono" }, host.kernel_latest))
        : h("span", null, host.reboot_reason ? ": " + host.reboot_reason : ""),
    ));
  }
  if (vm && vm.snapshot_count > 0) {
    const age = daysSince(vm.oldest_snapshot_at);
    const oldOnes = age !== null && age >= oldDays;
    alerts.push(h("div", { class: "hs-alert " + (oldOnes ? "vm-alert-old" : "vm-alert") },
      h("strong", null, vm.snapshot_count + (vm.snapshot_count === 1 ? " VM snapshot" : " VM snapshots")),
      h("span", null, ", oldest " + ageLabel(age) +
        (oldOnes ? ". Old snapshots grow and slow the VM; remove them in vCenter once they are no longer needed." : ".")),
    ));
  }
  if (stale) {
    alerts.push(h("div", { class: "hs-alert st-unknown" },
      h("strong", null, "Not reporting"),
      h("span", null, " since " + fmtDateTime(host.last_checkin) +
        ". Verdicts are shown as no recent data until it checks in."),
    ));
  }

  const more = h("details", { class: "host-more" },
    h("summary", null, "Details"),
    h("dl", { class: "facts" }, [
      ["Newest installed kernel", h("span", { class: "mono" }, host.kernel_latest || "unknown")],
      ["Last report", fmtDateTime(host.last_checkin)],
      ["Last inventory", fmtDateTime(host.last_inventory)],
      ["Status", HOST_STATUS[host.status] || host.status],
      ["Host group", host.host_group || "default"],
      ["Agent", host.agent_version || "unknown"],
      ["Enrolled", fmtDate(host.enrolled_at)],
    ].concat(vm ? [
      ["vCenter", vm.vcenter],
      ["ESXi host", vm.esxi_host || "unknown"],
      ["Cluster", vm.cluster || "none"],
      ["VM size", (vm.num_cpu || "?") + " vCPU, " + (vm.memory_mb ? Math.round(vm.memory_mb / 1024) + " GB" : "?")],
      ["VMware Tools", toolsLabel(vm.tools_running)],
      ["Linked by", MATCH_LABEL[vm.match_method] || vm.match_method || "unknown"],
    ] : []).map(([k, v]) => h("div", null, h("dt", null, k), h("dd", null, v)))),
  );

  /* -- filters ------------------------------------------------------------- */
  const filterDefs = [["all", "All (" + rows.length + ")", null]].concat(
    STATE_ORDER.filter(s => counts[s]).map(s => [s, STATES[s].label + " (" + counts[s] + ")", s]));
  const btns = filterDefs.map(([k, label, st]) =>
    h("button", { type: "button", class: st ? "st-" + st : null, "data-k": k,
                  "aria-pressed": String(k === show) }, label));

  /* -- list and panel ------------------------------------------------------ */
  const listBox = h("div", { class: "pane-list" });
  const panel = h("aside", { class: "pane-detail", "aria-live": "polite", "aria-label": "Selected advisory" });
  const sheetClose = () => { panel.classList.remove("open"); document.body.classList.remove("sheet-open"); };

  function drawPanel() {
    if (!selected) {
      panel.replaceChildren(h("p", { class: "pane-empty" },
        rows.length ? "Select an advisory to see its details and an explanation."
                    : "No advisories apply to this server."));
      return;
    }
    const r = selected;
    const cached = explainCache.get(r.advisory_id);
    const explainBox = h("div", { class: "pd-explain" });

    const fill = res => {
      explainBox.replaceChildren(
        h("p", { class: "explain-note" }, "AI explanation, advisory only. The verdict comes from the version check."),
        h("p", { class: "explain-text" }, res.text),
        h("p", { class: "explain-meta" },
          (res.cached ? "From cache" : "Generated in " + Math.round((res.duration_ms || 0) / 1000) + "s") +
          (res.model ? ", " + res.model : "")));
    };

    if (cached) fill(cached);
    else if (EXPLAINABLE.has(r.state) && can("operator")) {
      const b = h("button", { type: "button", class: "explain-btn" }, "Explain with AI-01");
      b.addEventListener("click", async () => {
        b.disabled = true;
        explainBox.replaceChildren(h("p", { class: "explain-wait" },
          "Asking AI-01. On a CPU-only server this can take up to a minute."));
        try {
          const res = await apiPost("/admin/hosts/" + encodeURIComponent(id) +
                                    "/advisories/" + encodeURIComponent(r.advisory_id) + "/explain");
          explainCache.set(r.advisory_id, res);
          if (selected === r) fill(res);
        } catch (err) {
          if (err.status === 401) return renderSignIn(err.message);
          explainBox.replaceChildren(h("p", { class: "explain-error" }, explainError(err)), b);
          b.disabled = false;
        }
      });
      explainBox.replaceChildren(b);
    }

    const cveBox = h("div", { class: "pd-cvedetail" });
    if ((r.cves || []).length) {
      const btn = h("button", { type: "button", class: "explain-btn" },
        "CVE details (" + r.cves.length + ")");
      btn.addEventListener("click", async () => {
        btn.disabled = true;
        cveBox.replaceChildren(h("p", { class: "muted" }, "Loading"));
        try {
          const res = await api("/admin/advisories/" + encodeURIComponent(r.advisory_id) + "/cves");
          const items = (res.cves || []).map(cveBlock);
          cveBox.replaceChildren(h("h3", { class: "pd-sub" }, "Published CVE data"), ...items);
        } catch (err) {
          if (err.status === 401) return renderSignIn(err.message);
          cveBox.replaceChildren(h("p", { class: "explain-error" },
            err.status === 404 ? "The API is older than this feature; rebuild it."
                               : "Could not load CVE data (HTTP " + err.status + ")."));
          btn.disabled = false;
        }
      });
      cveBox.replaceChildren(btn);
    }

    panel.replaceChildren(
      h("div", { class: "pd-head" },
        h("h2", null, r.advisory_id),
        h("button", { type: "button", class: "pd-close", "aria-label": "Close", on: { click: sheetClose } }, "Close")),
      h("div", { class: "pd-badges" }, stateMark(r.state), sevLabel(r.severity)),
      r.title ? h("p", { class: "pd-title" }, r.title) : null,
      h("dl", { class: "pd-facts" },
        h("div", null, h("dt", null, "Package"), h("dd", null, r.package_name)),
        h("div", null, h("dt", null, "Installed"),
          h("dd", { class: "mono" + (r.state === "affected" ? " ver-old" : "") }, r.installed_evr)),
        h("div", null, h("dt", null, "Fixed in"),
          h("dd", { class: "mono" + (r.state === "affected" ? " ver-new" : "") }, r.fixed_evr)),
        h("div", null, h("dt", null, "CVEs"),
          // Each ID is unbreakable; lines wrap only between IDs. A browser
          // otherwise breaks at the hyphens inside CVE-2026-31338.
          h("dd", { class: "pd-cves" }, (r.cves || []).length
            ? (r.cves || []).flatMap((c, i) => [i ? ", " : null, h("span", { class: "cve" }, c)])
            : "none listed")),
        r.max_cvss !== null && r.max_cvss !== undefined
          ? h("div", null, h("dt", null, "Worst CVSS"),
              h("dd", null, cvssCell(r.max_cvss), r.any_kev ? " " : null,
                r.any_kev ? kevBadge() : null)) : null,
        r.reason ? h("div", null, h("dt", null, "Why"), h("dd", null, r.reason)) : null,
      ),
      cveBox,
      explainBox,
    );
  }

  function select(r, tr) {
    selected = r;
    listBox.querySelectorAll("tr.selected").forEach(x => x.classList.remove("selected"));
    if (tr) tr.classList.add("selected");
    drawPanel();
    if (!wideScreen()) {
      panel.classList.add("open");
      document.body.classList.add("sheet-open");
    }
  }

  function draw() {
    btns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === show)));
    const list = show === "all" ? rows : rows.filter(r => r.state === show);
    if (!list.length) {
      listBox.replaceChildren(h("div", { class: "empty" }, h("p", null,
        rows.length ? "Nothing in this category." :
        "No advisories apply to this server yet. If it has just enrolled, run ./scripts/phase4-cve.sh --compute on PATCH-01.")));
      return;
    }
    const tbl = table([
      { label: "State", nowrap: true, cell: r => stateMark(r.state) },
      { label: "Advisory", nowrap: true, cell: r => [r.advisory_id, r.any_kev ? " " : null,
          r.any_kev ? kevBadge() : null] },
      // CVSS replaces the vendor severity here: it carries more information
      // and the vendor rating is shown in the panel.
      { label: "CVSS", num: true, nowrap: true, cell: r => cvssCell(r.max_cvss) },
      { label: "Package", nowrap: true, cell: r => r.package_name },
      { label: "Installed", mono: true, cell: r =>
          h("span", { class: r.state === "affected" ? "ver-old" : null }, r.installed_evr) },
      { label: "Fixed in", mono: true, cell: r =>
          h("span", { class: r.state === "affected" ? "ver-new" : null }, r.fixed_evr) },
    ], list, { onRow: r => {} });   // CVEs are listed in full in the panel
    // Row selection needs the <tr>, so wire it here rather than via onRow
    tbl.querySelectorAll("tbody tr").forEach((tr, i) => {
      const r = list[i];
      tr.tabIndex = 0;
      tr.setAttribute("aria-label", r.advisory_id + ", " + (STATES[r.state] || {}).label);
      const pick = () => select(r, tr);
      tr.addEventListener("click", pick);
      tr.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); pick(); } });
      if (selected && selected.advisory_id === r.advisory_id) tr.classList.add("selected");
    });
    listBox.replaceChildren(tbl);

    // On a wide screen, open the first item so the panel is never idle
    if (wideScreen() && (!selected || !list.includes(selected))) {
      select(list[0], tbl.querySelector("tbody tr"));
    }
  }
  btns.forEach(b => b.addEventListener("click", () => { show = b.dataset.k; draw(); }));

  // Patching first (what the server itself reports: WSUS, the package manager), filled in by
  // windowsPanel / linuxPanel. The CVE advisories are a separate, folded section below.
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl host show " + host.hostname }, host.hostname),
      h("span", { class: "head-actions", id: "host-actions" },
        h("a", { class: "btn btn-quiet", href: "#/installed-patches?hosts=" + encodeURIComponent(host.id) + "&days=90" }, "Installed patches"),
        h("a", { href: "#/hosts", class: "small" }, "All servers"))),
    summary,
    alerts,
    more,
    h("div", { id: "host-patch" }),
    h("details", { class: "host-vulns" },
      h("summary", null, h("span", { class: "hv-title" }, "Vulnerabilities (CVE advisories)"),
        h("span", { class: "muted small" }, " " + (counts.affected || 0) + " affecting this server" + (counts.fixed_pending_reboot ? ", " + counts.fixed_pending_reboot + " fixed, reboot needed" : ""))),
      h("p", { class: "muted small" }, "The vendors' security advisories and their CVEs, checked against the versions installed here. "
        + "This is not a list of missing patches: what to install is in Patches above (Windows Update against WSUS, or the package manager). "
        + "An advisory stays \u201caffected\u201d until its fixed version is installed, even when WSUS or the repository does not offer it yet."),
      h("div", { class: "controls" }, h("div", { class: "filters", role: "group", "aria-label": "Show" }, btns)),
      h("div", { class: "panes" }, listBox, panel)),
  );
  draw();
  drawPanel();
}

/* ---- agents ------------------------------------------------------------- */

/* ---- CVE facts ---------------------------------------------------------- */

const AV_WORDS = { NETWORK: "over the network", ADJACENT_NETWORK: "from the local network",
                   LOCAL: "local access", PHYSICAL: "physical access" };
const PR_WORDS = { NONE: "no login", LOW: "user login", HIGH: "admin login" };

function cvssCell(score, severity) {
  if (score === null || score === undefined) return h("span", { class: "muted" }, "-");
  return h("span", { class: "cvss", title: (severity || "").toLowerCase() }, Number(score).toFixed(1));
}

/* "Exploited" is deliberately not red or amber: those mean patch states.
   High-contrast inverse type makes it stand out without borrowing a meaning. */
function kevBadge(extra) {
  return h("span", { class: "kev", title: "Listed in CISA's Known Exploited Vulnerabilities catalogue" },
    "Exploited" + (extra ? " " + extra : ""));
}

function pctLabel(e) {
  if (e === null || e === undefined) return null;
  const v = Number(e) * 100;
  return v >= 10 ? Math.round(v) + "%" : v >= 1 ? v.toFixed(1) + "%" : "<1%";
}

function reachLine(c) {
  const bits = [];
  if (c.attack_vector) bits.push(AV_WORDS[c.attack_vector] || c.attack_vector.toLowerCase());
  if (c.privileges_required) bits.push(PR_WORDS[c.privileges_required] || c.privileges_required.toLowerCase());
  if ((c.user_interaction || "") === "REQUIRED") bits.push("needs a user action");
  if (c.attack_complexity) bits.push((c.attack_complexity || "").toLowerCase() + " complexity");
  return bits.join(", ");
}

function cveBlock(c) {
  if (!c.nvd_fetched_at && !c.cvss_score) {
    return h("div", { class: "cve-item" },
      h("div", { class: "cve-head" }, h("span", { class: "cve-id" }, c.cve_id)),
      h("p", { class: "muted small" }, c.fetch_error
        ? "No published data: " + c.fetch_error
        : "Published data not collected yet. Run ./scripts/phase4-cve.sh --intel on PATCH-01."));
  }
  const pct = pctLabel(c.epss);
  return h("div", { class: "cve-item" },
    h("div", { class: "cve-head" },
      h("span", { class: "cve-id" }, c.cve_id),
      cvssCell(c.cvss_score, c.cvss_severity),
      c.kev ? kevBadge(c.kev_ransomware === "Known" ? "and used in ransomware" : "") : null),
    c.attack_class ? h("p", { class: "cve-class" }, c.attack_class) : null,
    reachLine(c) ? h("p", { class: "cve-reach" }, reachLine(c)) : null,
    pct ? h("p", { class: "cve-epss" }, pct + " chance of exploitation in the next 30 days") : null,
    c.description ? h("p", { class: "cve-desc" }, c.description) : null,
    h("p", { class: "cve-src" },
      [c.cvss_version ? "CVSS " + c.cvss_version : null,
       c.cvss_source ? "scored by " + c.cvss_source : null,
       c.rh_severity ? "Red Hat: " + c.rh_severity : null,
       c.attack_class_basis ? "attack type from " + c.attack_class_basis : null,
      ].filter(Boolean).join(" | ")),
  );
}

/* ---- CVE assessment ----------------------------------------------------- */

const EXPOSURE = {
  // The same rules as Vulnerabilities: affected only when proven on a machine (a version compared
  // with the vendor's fix or NVD's affected range, or Windows Update reporting the fix missing)
  affected:        { label: "Affected",               cls: "st-affected",     desc: "Proven on at least one machine or appliance" },
  appliance_check: { label: "Appliance: check",       cls: "st-fixed_pending_reboot", desc: "An appliance matches the product; its firmware version is not recorded" },
  not_affected:    { label: "Not affected",           cls: "st-fixed_active", desc: "The product is on our machines, at a fixed version" },
  not_found:       { label: "Not in our environment", cls: "st-plain",        desc: "No machine or appliance has the product" },
  no_data:         { label: "Cannot assess",          cls: "st-unknown",      desc: "No vendor or NVD data names the affected products yet" },
  // Assessments made before r84
  potentially_affected: { label: "Possibly affected (old rules)", cls: "st-unknown", desc: "From an assessment made before r84: run it again" },
  pending_reboot: { label: "Affected (restart)", cls: "st-affected", desc: "The fix is installed; a restart finishes it" },
  patched:        { label: "Not affected",       cls: "st-fixed_active", desc: "Found and already fixed" },
  not_tracked:    { label: "Not in our environment", cls: "st-plain", desc: "Not in the inventory" },
};
const EXPOSURE_ORDER = ["affected", "pending_reboot", "appliance_check", "not_affected", "patched", "not_found", "not_tracked",
                        "no_data", "potentially_affected"];
function exposureOf(i) {
  if (i.exposure) return i.exposure;
  // Before enrichment: the package verdict only
  return { affected: "affected", pending_reboot: "pending_reboot", patched: "patched",
           not_applicable: "not_affected" }[i.status] || "not_found";
}
function exposureMark(i) {
  const e = EXPOSURE[exposureOf(i)] || { label: i.status, cls: "st-plain" };
  return h("span", { class: "state " + e.cls, title: e.desc || "" }, e.label);
}

function assessResult(res) {
  const items = res.items || [];
  const enriching = res.state === "enriching";
  const by = {};
  items.forEach(i => { const e = exposureOf(i); by[e] = (by[e] || 0) + 1; });
  const exposed = (by.affected || 0) + (by.pending_reboot || 0);
  const servers = new Set();
  const sn = x => String(x || "").toLowerCase().split(".")[0];
  items.forEach(i => (i.affected_hosts || []).forEach(x => { if (x.state === "affected") servers.add(sn(x.hostname)); }));
  (items || []).forEach(i => (i.inventory_matches || []).forEach(m => {
    if (m.name && ["confirmed", "in_range", "no_fix", "pending_reboot"].includes(m.certainty)) servers.add(sn(m.name)); }));

  const tiles = h("div", { class: "agent-tiles" }, EXPOSURE_ORDER.filter(k => by[k]).map(k =>
    h("div", { class: "agent-tile" }, h("span", { class: "at-n" }, by[k]),
      h("span", { class: "at-l" }, EXPOSURE[k].label), h("span", { class: "at-d" }, EXPOSURE[k].desc))));

  const total = res.progress_total || items.length, got = res.progress || 0;
  const progress = enriching ? h("div", { class: "enrich hud-row" },
    hudRing({ pct: 100 * got / Math.max(1, total), live: true, key: "assess-" + res.id, title: "ASSESSING",
      sub: got + " / " + total + " CVEs", label: "Assessment progress",
      segs: total <= 72 ? Array.from({ length: total }, (_, i) => ({ k: i < got ? "done" : i === got ? "run" : "wait" })) : [] }),
    h("span", null, "Looking up each CVE in NVD, matching it against the inventory and writing briefs: "
      + got + " of " + total + ".")) : null;

  const lead = h("p", null, items.length + " CVEs checked. ",
    h("strong", null, exposed + " affect or may affect us"),
    exposed ? " across " + servers.size + " system" + (servers.size === 1 ? "" : "s") + "." : ".",
    items.some(i => i.kev && exposureOf(i) === "affected")
      ? h("span", null, " ", kevBadge(), " Some are exploited in the wild.") : null);

  let show = EXPOSURE_ORDER.find(k => by[k]) || "affected";
  const filters = [["all", "All (" + items.length + ")"]].concat(
    EXPOSURE_ORDER.filter(k => by[k]).map(k => [k, EXPOSURE[k].label + " (" + by[k] + ")"]))
    .map(([k, l]) => h("button", { type: "button", "data-k": k, "aria-pressed": String(k === show) }, l));
  const body = h("div");

  // Where it was found: servers the package verdict flags, plus inventory
  // matches (ESXi, vCenter, VM guests). The package verdict is authoritative
  // for Linux servers, so the matcher leaves those out and they are added here.
  function matchSummary(i) {
    const kinds = {};
    const add = (k, n) => { kinds[k] = (kinds[k] || 0) + n; };
    const hosts = (i.affected_hosts || []).filter(x => x.state === "affected" || x.state === "pending_reboot"
                                                    || x.state === "fixed_pending_reboot");
    const sn = x => String(x || "").toLowerCase().split(".")[0];
    const seen = new Set(hosts.map(x => sn(x.hostname)));
    if (hosts.length) add("Linux server", hosts.length);
    // Each machine once: the engine's own server checks are already in affected_hosts
    const m = (i.inventory_matches || []).filter(x =>
      ["confirmed", "in_range", "no_fix", "pending_reboot", "check"].includes(x.certainty) && !seen.has(sn(x.name)));
    m.forEach(x => add(x.where || "item", 1));
    if (!Object.keys(kinds).length) {
      return (i.inventory_matches || []).some(x => x.certainty === "not_tracked")
        ? h("span", { class: "muted" }, "not tracked") : h("span", { class: "muted" }, "none");
    }
    return Object.entries(kinds).map(([k, n]) => n + " " + k + (n === 1 ? "" : "s")).join(", ");
  }
  function detailRow(i, cols) {
    const matches = (i.inventory_matches || []);
    return h("tr", { class: "explain-row" }, h("td", { colspan: String(cols) },
      h("div", { class: "explain" },
        i.ai_summary ? [h("p", { class: "explain-note" }, "AI brief from AI-01, from the facts below."),
                        h("p", { class: "explain-text" }, i.ai_summary)]
          : enriching && !i.enriched_at ? h("p", { class: "explain-wait" }, "Brief pending")
          : h("p", { class: "muted small" }, "No AI brief: AI-01 unavailable or not configured."),
        i.description ? h("p", { class: "cve-desc" }, h("strong", null, "NVD: "), i.description) : null,
        (i.products || []).length ? h("p", { class: "small" }, h("strong", null, "Affects: "),
          i.products.slice(0, 10).map(p => p.vendor + " " + p.product + " (" + p.kind + ")").join("; ")) : null,
        ...whereTable(matches.slice(0, 40), i))));
  }
  function draw() {
    filters.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === show)));
    const rows = items.filter(i => show === "all" || exposureOf(i) === show);
    if (!rows.length) return body.replaceChildren(h("div", { class: "empty" }, h("p", null, "Nothing in this category.")));
    const cols = [
      { label: "", nowrap: true, cell: () => h("span", { class: "srv-plus", "aria-hidden": "true" }, "+") },
      { label: "CVE", nowrap: true, mono: true, cell: i => i.cve_id },
      { label: "Exposure", nowrap: true, cell: exposureMark },
      { label: "CVSS", num: true, nowrap: true, cell: i => cvssCell(i.cvss_score, i.cvss_severity) },
      { label: "", nowrap: true, cell: i => i.kev ? kevBadge() : "" },
      { label: "Attack type", cell: i => i.attack_class || (enriching && !i.enriched_at ? h("span", { class: "muted" }, "looking up") : "") },
      { label: "Affects", cell: i => (i.product_classes || []).join(", ") },
      { label: "Found in", cell: matchSummary },
    ];
    const tbl = table(cols, rows, { onRow: () => {} });
    tbl.querySelectorAll("tbody tr").forEach((tr, n) => {
      tr.addEventListener("click", () => {
        const nx = tr.nextElementSibling;
        const plus = tr.querySelector(".srv-plus");
        if (nx && nx.classList.contains("explain-row")) { if (plus) plus.textContent = "+"; return nx.remove(); }
        if (plus) plus.textContent = "\u2212";
        tr.after(detailRow(rows[n], cols.length));
      });
    });
    body.replaceChildren(h("p", { class: "muted small" }, "Press + on a CVE for AI-01's brief, what it affects and where it was found."), tbl);
  }
  filters.forEach(b => b.addEventListener("click", () => { show = b.dataset.k; draw(); }));
  draw();

  return h("div", null,
    h("div", { class: "page-head" }, h("h2", null, "Result: " + res.name)),
    progress, lead, tiles,
    res.rejected && res.rejected.length ? h("p", { class: "muted small" },
      "Not understood in the input: " + res.rejected.join(" | ")) : null,
    h("div", { class: "controls" }, h("div", { class: "filters", role: "group" }, filters)),
    body);
}

async function showAssessment(id, box) {
  const d = await api("/admin/assessments/" + encodeURIComponent(id));
  const a = d.assessment || {};
  box.replaceChildren(assessResult({ id: a.id, name: a.name, state: a.state, progress: a.progress,
    progress_total: a.progress_total, rejected: a.rejected, items: d.items || [] }));
  if (a.state === "enriching") {
    setPageTimer(async () => {
      if (!location.hash.startsWith("#/assess")) return clearPageTimer();
      try {
        const n = await api("/admin/assessments/" + encodeURIComponent(id));
        const na = n.assessment || {};
        // Keep an open detail row by only redrawing when something changed
        if (na.progress !== a.progress || na.state !== a.state) {
          a.progress = na.progress; a.state = na.state;
          box.replaceChildren(assessResult({ id: na.id, name: na.name, state: na.state, progress: na.progress,
            progress_total: na.progress_total, rejected: na.rejected, items: n.items || [] }));
        }
        if (na.state !== "enriching") clearPageTimer();
      } catch (e) { clearPageTimer(); }
    }, 5000);
  }
}

async function renderAssess(params) {
  const list = await api("/admin/assessments");
  const resultBox = h("div");

  const name = h("input", { type: "text", required: true, placeholder: "SOC bulletin, September" });
  const source = h("input", { type: "text", placeholder: "SOC, auditor, vendor notice" });
  const textarea = h("textarea", { rows: "6", placeholder:
    "Paste the CVE list here, in any format:\nCVE-2026-31337, CVE-2026-31338\nCVE-2026-29001" });
  const fileIn = h("input", { type: "file", accept: ".txt,.csv,.text,text/plain,text/csv" });
  const submit = h("button", { type: "submit" }, "Assess");
  const err = h("p", { class: "explain-error", hidden: true });

  const form = h("form", { class: "assess-form", on: { submit: async e => {
    e.preventDefault();
    err.hidden = true;
    if (!name.value.trim()) { err.textContent = "Give the assessment a name."; err.hidden = false; return; }
    if (!textarea.value.trim() && !fileIn.files.length) {
      err.textContent = "Paste a CVE list or choose a file."; err.hidden = false; return;
    }
    submit.disabled = true; submit.textContent = "Assessing";
    const fd = new FormData();
    fd.append("name", name.value.trim());
    if (source.value.trim()) fd.append("source", source.value.trim());
    if (textarea.value.trim()) fd.append("text", textarea.value);
    if (fileIn.files.length) fd.append("file", fileIn.files[0]);
    try {
      const res = await fetch("/api/v1/admin/assessments", {
        method: "POST",
        headers: { "X-Requested-With": "patch01-dashboard",
                   ...authHeaders() },
        body: fd,
      });
      if (res.status === 401) { clearAuth(); return renderSignIn("Your session has ended."); }
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new ApiError(res.status, data.detail || res.statusText);
      history.replaceState(null, "", "#/assess?id=" + data.id);
      await showAssessment(data.id, resultBox);
      resultBox.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (ex) {
      err.textContent = ex.message || "Assessment failed.";
      err.hidden = false;
    } finally {
      submit.disabled = false; submit.textContent = "Assess";
    }
  } } },
    h("div", { class: "af-row" },
      h("label", null, h("span", null, "Name"), name),
      h("label", null, h("span", null, "Where it came from"), source)),
    h("label", null, h("span", null, "CVE list"), textarea),
    h("label", null, h("span", null, "or upload a file"), fileIn,
      h("span", { class: "muted small" },
        "Text or CSV. Save a spreadsheet as CSV, or paste the column in above.")),
    err, submit);

  const past = (list.assessments || []);
  const history = h("section", null,
    h("h2", null, "Previous assessments"),
    past.length ? table([
      { label: "Name", cell: a => h("a", { href: "#/assess?id=" + a.id }, a.name) },
      { label: "From", nowrap: true, cell: a => a.source || "" },
      { label: "When", nowrap: true, cell: a => fmtDateTime(a.created_at) },
      { label: "CVEs", num: true, cell: a => a.cve_count },
      { label: "Exposed", num: true, cell: a => count(a.exposed != null ? a.exposed : a.affected, "affected") },
      { label: "State", nowrap: true, cell: a => a.state === "enriching"
          ? h("span", { class: "muted" }, "enriching " + (a.progress || 0) + "/" + (a.progress_total || a.cve_count)) : "done" },
      { label: "Exploited", num: true, cell: a => a.exploited_affected
          ? h("span", null, a.exploited_affected, " ", kevBadge()) : "0" },
      { label: "Cannot assess", num: true, cell: a => a.no_vendor_data },
      { label: "By", nowrap: true, cell: a => a.created_by },
    ], past, { onRow: a => { location.hash = "#/assess?id=" + a.id; } })
      : h("div", { class: "empty" }, h("p", null, "No assessment has been run yet.")));

  if (!can("operator")) form.replaceChildren(
    h("p", { class: "muted" }, "Running an assessment needs the operator role. Previous assessments are below."));
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "cybersecure vulns --assess" }, "Vulnerabilities"),
      h("span", { class: "muted small" }, "Assess CVEs from a SOC, an auditor, a vendor or a file")),
    h("p", { class: "muted small" }, "Paste or upload a list of CVEs; each one is checked in this order."), pipeline(),
    form, resultBox, history);
  vulnTabs("assess");

  // Opening a saved assessment
  const id = params.get("id");
  if (id) {
    try { await showAssessment(id, resultBox); } catch (e) { /* the list below still shows */ }
  }
}

/* ---- VMware ------------------------------------------------------------- */

const MATCH_LABEL = {
  "hardware_uuid": "Hardware ID",
  "hardware_uuid+hostname": "Hardware ID and hostname",
  "hostname": "Hostname only",
  "ip": "IP address only",
  "ambiguous": "Ambiguous",
};

function daysSince(iso) {
  if (!iso) return null;
  const t = new Date(iso).getTime();
  return isNaN(t) ? null : Math.floor((Date.now() - t) / 86400000);
}
function ageLabel(d) {
  if (d === null) return "unknown";
  if (d < 1) return "today";
  return d === 1 ? "1 day" : d + " days";
}

const POWER = { poweredOn: "On", poweredOff: "Off", suspended: "Suspended" };
const TOOLS_STATE = {
  guestToolsRunning: "Running",
  guestToolsNotRunning: "Not running",
  guestToolsExecutingScripts: "Starting",
};
function toolsLabel(v) {
  const t = TOOLS_STATE[v];
  if (t === "Running") return t;
  return h("span", { class: "muted" }, t || "unknown");
}

/* ---- the infrastructure map ---------------------------------------------
 * vCenter > datacenter > cluster > ESXi host > VM, drawn from PostgreSQL.
 * Expandable rather than a drawn graph: an estate of thousands of VMs is
 * read by drilling in, not by looking at a picture of all of it at once.
 */

function pctBar(pct, label) {
  const v = Math.max(0, Math.min(100, Number(pct) || 0));
  const bar = h("span", { class: "pbar" + (v >= 90 ? " pbar-full" : "") },
    h("span", { class: "pbar-fill" }));
  bar.firstChild.style.width = v + "%";
  return h("span", { class: "pcell" }, bar, h("span", { class: "pnum" }, label || (v + "%")));
}

function gb(mb) {
  if (mb === null || mb === undefined) return "";
  const n = Number(mb);
  return n >= 1024 ? Math.round(n / 1024) + " GB" : n + " MB";
}
function tb(mb) {
  if (mb === null || mb === undefined) return "";
  const n = Number(mb) / 1024;
  return n >= 1024 ? (n / 1024).toFixed(1) + " TB" : Math.round(n) + " GB";
}

function vmStatusDot(v) {
  // Patch state first, then agent coverage: a VM we cannot see is not "clean"
  let cls = "vmdot-unmanaged", title = "No agent: not assessed";
  if (v.host_id) {
    if (Number(v.needs_patch) > 0) { cls = "vmdot-affected"; title = v.needs_patch + " CVE advisories affect it (Vulnerabilities)"; }
    else if (Number(v.needs_reboot) > 0) { cls = "vmdot-reboot"; title = "Awaiting reboot"; }
    else if (v.agent_state === "not_reporting" || v.agent_state === "no_data") {
      cls = "vmdot-unknown"; title = "Agent not reporting: status unknown";
    } else { cls = "vmdot-ok"; title = "Patched"; }
  }
  return h("span", { class: "vmdot " + cls, title: title });
}

function mapTree(data) {
  const byVc = {};
  (data.hosts || []).forEach(hst => {
    const dc = byVc[hst.vcenter] || (byVc[hst.vcenter] = {});
    const cl = dc[hst.datacenter || "(no datacenter)"] || (dc[hst.datacenter || "(no datacenter)"] = {});
    const key = hst.cluster || "(standalone hosts)";
    (cl[key] || (cl[key] = [])).push(hst);
  });
  const vmsByHost = {};
  const vmsNoHost = [];
  (data.vms || []).forEach(v => {
    if (v.esxi_moref) (vmsByHost[v.vcenter + "|" + v.esxi_moref] || (vmsByHost[v.vcenter + "|" + v.esxi_moref] = [])).push(v);
    else vmsNoHost.push(v);
  });

  const out = [];
  Object.keys(byVc).sort().forEach(vc => {
    const dcs = byVc[vc];
    const vcNode = h("details", { class: "mt mt-vc", open: true },
      h("summary", null,
        h("span", { class: "mt-kind" }, "vCenter"), h("strong", null, vc),
        h("span", { class: "mt-count" },
          Object.keys(dcs).length + " datacenter" + (Object.keys(dcs).length === 1 ? "" : "s"))));
    Object.keys(dcs).sort().forEach(dc => {
      const clusters = dcs[dc];
      const dcNode = h("details", { class: "mt mt-dc", open: true },
        h("summary", null, h("span", { class: "mt-kind" }, "Datacenter"), h("strong", null, dc),
          h("span", { class: "mt-count" }, Object.keys(clusters).length + " clusters")));
      // Real clusters first, the standalone-hosts group last
      const clusterOrder = Object.keys(clusters).sort((a, b) => {
        const sa = a.startsWith("("), sb = b.startsWith("(");
        return sa !== sb ? (sa ? 1 : -1) : a.localeCompare(b);
      });
      clusterOrder.forEach(cl => {
        const hostList = clusters[cl];
        const vmTotal = hostList.reduce((a, x) =>
          a + ((vmsByHost[x.vcenter + "|" + x.moref] || []).length), 0);
        const clNode = h("details", { class: "mt mt-cl" },
          h("summary", null, h("span", { class: "mt-kind" }, "Cluster"), h("strong", null, cl),
            h("span", { class: "mt-count" }, hostList.length + " hosts, " + vmTotal + " VMs")));
        hostList.forEach(hst => {
          const vms = (vmsByHost[hst.vcenter + "|" + hst.moref] || []).slice();
          const cpuPct = hst.cpu_mhz && hst.cpu_cores
            ? Math.round(100 * (hst.cpu_usage_mhz || 0) / (hst.cpu_mhz * hst.cpu_cores)) : null;
          const memPct = hst.memory_mb ? Math.round(100 * (hst.memory_usage_mb || 0) / hst.memory_mb) : null;
          const bad = hst.connection_state && hst.connection_state !== "connected";
          const hNode = h("details", { class: "mt mt-esxi" },
            h("summary", null,
              h("span", { class: "mt-kind" }, "ESXi"),
              h("strong", { class: bad ? "esxi-bad" : null }, hst.name),
              h("span", { class: "mt-count" }, vms.length + " VMs"),
              h("span", { class: "mt-facts" },
                "ESXi " + (hst.esxi_version || "?") + ", " + (hst.cpu_cores || "?") + " cores, "
                + gb(hst.memory_mb)),
              cpuPct !== null ? pctBar(cpuPct, "CPU " + cpuPct + "%") : null,
              memPct !== null ? pctBar(memPct, "RAM " + memPct + "%") : null,
              bad ? h("span", { class: "esxi-bad" }, hst.connection_state) : null,
              hst.maintenance_mode ? h("span", { class: "muted" }, "maintenance") : null));
          vms.sort((a, b) => (b.needs_patch || 0) - (a.needs_patch || 0) || String(a.vm).localeCompare(b.vm));
          hNode.append(h("div", { class: "mt-vms" }, vms.length ? vms.map(v =>
            h("div", { class: "mt-vm" },
              vmStatusDot(v),
              v.host_id ? h("a", { href: "#/host/" + v.host_id }, v.vm) : h("span", null, v.vm),
              h("span", { class: "muted" }, (v.guest_os || "unknown OS")),
              h("span", { class: "muted" }, (v.num_cpu || "?") + " vCPU, " + gb(v.memory_mb)),
              v.power_state !== "poweredOn" ? h("span", { class: "muted" }, POWER[v.power_state] || v.power_state) : null,
              Number(v.snapshot_count) ? h("span", { class: "muted" }, v.snapshot_count + " snapshot" + (v.snapshot_count === 1 ? "" : "s")) : null,
              v.host_id && Number(v.needs_patch) ? h("span", { class: "count st-affected", title: "CVE advisories affecting this server (Vulnerabilities)" }, v.needs_patch + " CVE advisories") : null,
              !v.host_id ? h("span", { class: "muted" }, v.is_linux ? "no agent" : "not managed") : null,
            )) : h("p", { class: "muted small" }, "No VMs on this host.")));
          clNode.append(hNode);
        });
        dcNode.append(clNode);
      });
      vcNode.append(dcNode);
    });
    out.push(vcNode);
  });

  if (vmsNoHost.length) {
    const orphan = h("details", { class: "mt mt-cl" },
      h("summary", null, h("span", { class: "mt-kind" }, "Unplaced"),
        h("strong", null, "VMs with no host recorded"),
        h("span", { class: "mt-count" }, vmsNoHost.length + " VMs")),
      h("div", { class: "mt-vms" }, vmsNoHost.map(v =>
        h("div", { class: "mt-vm" }, vmStatusDot(v), v.vm,
          h("span", { class: "muted" }, v.vcenter)))));
    out.push(orphan);
  }
  return out;
}

function mapLegend() {
  return h("div", { class: "map-legend" },
    h("span", null, h("span", { class: "vmdot vmdot-affected" }), "needs patching"),
    h("span", null, h("span", { class: "vmdot vmdot-reboot" }), "needs reboot"),
    h("span", null, h("span", { class: "vmdot vmdot-ok" }), "patched"),
    h("span", null, h("span", { class: "vmdot vmdot-unknown" }), "agent not reporting"),
    h("span", null, h("span", { class: "vmdot vmdot-unmanaged" }), "no agent"));
}

// How much of the estate the map can fully describe
async function coverageView() {
  const c = await api("/admin/vmware/coverage");
  const row = (label, n) => h("div", { class: "cov-row" }, h("span", null, label),
    pctBar(c.total ? Math.round(100 * n / c.total) : 0, " "), h("span", { class: "num" }, n));
  return h("div", null,
    h("p", { class: "muted" }, "What the map can fully describe, from vCenter alone. Dependency lines between "
      + "VMs will need flow records, which only Distributed Switches can export; application groups come "
      + "from vSphere tags, else folders."),
    h("div", { class: "cov-grid" },
      h("div", { class: "cov-card" }, h("h3", null, "Switching (" + c.total + " VMs)"),
        row("Distributed only", c.switching.distributed), row("Mixed", c.switching.mixed),
        row("Standard only", c.switching.standard), row("Other (NSX)", c.switching.other),
        row("No network", c.switching.none)),
      h("div", { class: "cov-card" }, h("h3", null, "Application grouping"),
        row("vSphere tag", c.grouping.tag), row("Folder", c.grouping.folder), row("Ungrouped", c.grouping.none))),
    h("h2", null, "Application groups (" + c.apps.length + ")"),
    c.apps.length ? table([
      { label: "Application", cell: a => a.app },
      { label: "From", nowrap: true, cell: a => a.source === "tag" ? "vSphere tag" : "folder" },
      { label: "VMs", num: true, cell: a => a.vms },
    ], c.apps) : h("div", { class: "empty" }, h("p", null, "No VM is tagged or foldered by application yet.")),
    h("h2", null, "Standard-switch only (" + c.standard_only.length + ")"),
    h("p", { class: "muted small" }, "No flow records for these unless a VM they talk to is on a Distributed Switch."),
    c.standard_only.length ? table([
      { label: "VM", cell: v => v.name }, { label: "Cluster", cell: v => v.cluster || "" },
      { label: "vCenter", nowrap: true, cell: v => v.vcenter }], c.standard_only)
      : h("div", { class: "empty" }, h("p", null, "Every VM has at least one Distributed port group.")),
    h("h2", null, "Ungrouped (" + c.ungrouped.length + ")"),
    h("p", { class: "muted small" }, "Tag these in vCenter with an Application category, or file them in an application folder."),
    c.ungrouped.length ? table([
      { label: "VM", cell: v => v.name }, { label: "Cluster", cell: v => v.cluster || "" },
      { label: "Folder", cell: v => v.folder || h("span", { class: "muted" }, "none") },
      { label: "vCenter", nowrap: true, cell: v => v.vcenter }], c.ungrouped)
      : h("div", { class: "empty" }, h("p", null, "Every VM belongs to an application group.")));
}

async function renderVmware(params) {
  setNav("vmware");
  let res;
  try { res = await api("/admin/vmware/summary"); }
  catch (e) {
    if (e.status === 404) {
      return render(h("div", { class: "page-head" }, h("h1", null, "VMware")),
        h("div", { class: "empty" }, h("p", null,
          "The API is older than the VMware integration. Rebuild it with ",
          h("code", null, "./scripts/phase3b-api.sh"), ".")));
    }
    throw e;
  }
  const vcs = res.vcenters || [];
  const c = res.counts || {};
  const oldDays = res.snapshot_old_days || 7;

  const head = h("div", { class: "page-head" },
    h("h1", { "data-cmd": "patchctl vmware status" }, "VMware"),
    h("span", { class: "muted small" },
      vcs.length + (vcs.length === 1 ? " vCenter" : " vCenters") + ", " + (c.vms || 0) + " VMs"));

  if (!vcs.length) {
    return render(head, h("div", { class: "empty" },
      h("h2", null, "No vCenter is configured"),
      h("p", null, "On PATCH-01, add one with ",
        h("code", null, "./scripts/phase7-vmware.sh --add <name> --host <vcenter address>"),
        ", then run ", h("code", null, "--sync"), ".")));
  }

  const vcCards = h("div", { class: "vc-cards" }, vcs.map(v =>
    h("div", { class: "vc-card" + (v.last_ok === false ? " vc-failed" : "") },
      h("div", { class: "vc-name" }, v.name),
      h("div", { class: "muted small" }, v.host),
      h("div", { class: "small" }, v.version || ""),
      v.last_ok === false
        ? h("div", { class: "vc-error" }, "Last sync failed " + timeAgo(v.last_sync_at) + ": " + (v.last_error || ""))
        : h("div", { class: "small" }, (v.vm_count || 0) + " VMs, synced " + timeAgo(v.last_sync_at)))));

  let view = params.get("view") || "live";
  const tabs = [
    ["live", "Live map", null],
    ["map", "Tree", null],
    ["coverage", "Coverage", null],
    ["all", "All VMs", c.vms],
    ["hosts", "ESXi hosts", null],
    ["datastores", "Datastores", null],
    ["networks", "Networks", null],
    ["clusters", "Clusters", null],
    ["snapshots", "VMs with snapshots", null],
    ["unmanaged", "Linux VMs without an agent", c.unmanaged],
    ["ambiguous", "Ambiguous matches", c.ambiguous],
  ];
  const tabBtns = tabs.map(([k, label, n]) =>
    h("button", { type: "button", "data-k": k, "aria-pressed": String(k === view) },
      label + (n !== null && n !== undefined ? " (" + n + ")" : "")));

  const note = h("p", { class: "muted small" },
    (c.matched || 0) + " VMs are linked to a server. " +
    (res.servers_without_vm ? res.servers_without_vm +
      " servers have no VM linked: physical machines, a vCenter not yet synced, or agents older than 1.2.0. " : "") +
    "Snapshots older than " + oldDays + " days are flagged.");

  const body = h("div");
  const search = h("input", { type: "search", placeholder: "Filter by VM, server, cluster or OS",
                              "aria-label": "Filter virtual machines" });
  let cache = [];
  let q = "";

  function matches(v) {
    if (!q) return true;
    const hay = [v.name, v.server, v.cluster, v.guest_os, v.guest_hostname, v.vcenter,
                 v.esxi_host, v.datacenter, v.type, v.kind, v.model, v.vendor,
                 v.cpu_model, v.esxi_version, (v.guest_ips || []).join(" ")]
      .filter(Boolean).join(" ").toLowerCase();
    return hay.includes(q);
  }

  const ROW_NOUN = { hosts: ["ESXi host", "ESXi hosts"], datastores: ["datastore", "datastores"],
                     networks: ["network", "networks"], clusters: ["cluster", "clusters"],
                     snapshots: ["VM", "VMs"], unmanaged: ["VM", "VMs"],
                     ambiguous: ["VM", "VMs"], all: ["VM", "VMs"], linux: ["VM", "VMs"] };
  const noun = (n, v) => (ROW_NOUN[v] || ["row", "rows"])[n === 1 ? 0 : 1];

  const ENDPOINT = {
    map: "/admin/vmware/map", hosts: "/admin/vmware/hosts",
    datastores: "/admin/vmware/datastores", networks: "/admin/vmware/networks",
    clusters: "/admin/vmware/clusters",
  };

  async function draw() {
    tabBtns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === view)));
    search.hidden = (view === "map");
    body.replaceChildren(h("p", { class: "muted" }, "Loading"));
    if (view === "live") {
      search.hidden = true;
      window.NeonMap.mount(body, { api, setTimer: setPageTimer, clearTimer: clearPageTimer });
      return;
    }
    clearPageTimer();
    if (view === "coverage") {
      search.hidden = true;
      body.replaceChildren(await coverageView());
      return;
    }
    if (view === "map") {
      const d = await api(ENDPOINT.map);
      cache = [];
      const tree = mapTree(d);
      body.replaceChildren(
        h("p", { class: "muted small" },
          (d.hosts || []).length + " ESXi hosts, " + (d.vms || []).length + " VMs, "
          + (d.datastores || []).length + " datastores. Click a cluster or host to expand."),
        mapLegend(),
        tree.length ? h("div", { class: "map-tree" }, tree)
          : h("div", { class: "empty" }, h("p", null,
              "Nothing synced yet. Run ./scripts/phase7-vmware.sh --sync on PATCH-01.")),
        (d.datastores || []).length ? h("details", { class: "mt mt-ds" },
          h("summary", null, h("span", { class: "mt-kind" }, "Storage"),
            h("strong", null, "Datastores"),
            h("span", { class: "mt-count" }, d.datastores.length)),
          table([
            { label: "Datastore", nowrap: true, cell: x => x.name },
            { label: "Type", nowrap: true, cell: x => x.type || "" },
            { label: "Capacity", num: true, nowrap: true, cell: x => tb(x.capacity_mb) },
            { label: "Free", num: true, nowrap: true, cell: x => tb(x.free_mb) },
            { label: "Usage", nowrap: true, cell: x => pctBar(x.used_pct) },
            { label: "VMs", num: true, cell: x => x.vm_count },
            { label: "vCenter", nowrap: true, cell: x => x.vcenter },
          ], d.datastores)) : null);
      return;
    }
    if (ENDPOINT[view]) {
      const d = await api(ENDPOINT[view]);
      cache = d.hosts || d.datastores || d.networks || d.clusters || [];
    } else {
      const r = await api("/admin/vmware/vms?view=" + encodeURIComponent(view));
      cache = r.vms || [];
    }
    paint();
  }

  function paint() {
    const vms = cache.filter(matches);
    const vmCell = v => v.host_id ? h("a", { href: "#/host/" + v.host_id }, v.name) : v.name;
    const cols = {
      all: [
        { label: "VM", nowrap: true, cell: v => v.host_id
            ? h("a", { href: "#/host/" + v.host_id }, v.name) : v.name },
        { label: "Guest OS", cell: v => v.guest_os || h("span", { class: "muted" }, "unknown") },
        { label: "Power", nowrap: true, cell: v => h("span",
            { class: v.power_state === "poweredOn" ? null : "muted" },
            POWER[v.power_state] || v.power_state) },
        { label: "Server", nowrap: true, cell: v => v.server
            || h("span", { class: "muted" }, v.is_linux ? "no agent" : "not managed") },
        { label: "Cluster", nowrap: true, cell: v => v.cluster || "" },
        { label: "Snapshots", num: true, cell: v => v.snapshot_count
            ? h("span", { class: daysSince(v.oldest_snapshot_at) >= oldDays ? "snap-old" : null },
                v.snapshot_count) : "0" },
        { label: "Tools", nowrap: true, cell: v => toolsLabel(v.tools_running) },
        { label: "vCenter", nowrap: true, cell: v => v.vcenter },
        { label: "", nowrap: true, cell: v => can("operator")
            ? h("a", { class: "small", href: "#/changes/new?kind=vm&vc=" + encodeURIComponent(v.vcenter)
                        + "&moref=" + encodeURIComponent(v.moref) }, "Actions") : "" },
      ],
      hosts: [
        { label: "ESXi host", nowrap: true, cell: x => h("span",
            { class: x.connection_state !== "connected" ? "esxi-bad" : null }, x.name) },
        { label: "Cluster", nowrap: true, cell: x => x.cluster || h("span", { class: "muted" }, "standalone") },
        { label: "State", nowrap: true, cell: x => [
            x.connection_state === "connected" ? "Connected" : h("span", { class: "esxi-bad" }, x.connection_state),
            x.maintenance_mode ? h("span", { class: "muted" }, " maintenance") : null] },
        { label: "ESXi", nowrap: true, cell: x => (x.esxi_version || "") + (x.esxi_build ? " b" + x.esxi_build : "") },
        { label: "Hardware", cell: x => [x.vendor, x.model].filter(Boolean).join(" ") },
        { label: "CPU", cell: x => (x.cpu_sockets || "?") + " x " + (x.cpu_cores || "?") + " cores"
            + (x.cpu_model ? " - " + x.cpu_model : "") },
        { label: "CPU used", nowrap: true, cell: x => x.cpu_pct !== null ? pctBar(x.cpu_pct) : "" },
        { label: "Memory", num: true, nowrap: true, cell: x => gb(x.memory_mb) },
        { label: "RAM used", nowrap: true, cell: x => x.memory_pct !== null ? pctBar(x.memory_pct) : "" },
        { label: "VMs", num: true, cell: x => x.vm_count },
        { label: "Uptime", nowrap: true, cell: x => fmtUptime(x.uptime_seconds) },
        { label: "vCenter", nowrap: true, cell: x => x.vcenter },
      ],
      datastores: [
        { label: "Datastore", nowrap: true, cell: x => x.name },
        { label: "Type", nowrap: true, cell: x => x.type || "" },
        { label: "Capacity", num: true, nowrap: true, cell: x => tb(x.capacity_mb) },
        { label: "Used", num: true, nowrap: true, cell: x => tb(x.used_mb) },
        { label: "Free", num: true, nowrap: true, cell: x => tb(x.free_mb) },
        { label: "Usage", nowrap: true, cell: x => pctBar(x.used_pct) },
        // Over 100% means thin disks are promising more than the datastore has
        { label: "Provisioned", nowrap: true, cell: x => x.provisioned_pct !== null
            ? h("span", { class: Number(x.provisioned_pct) > 100 ? "overcommit" : null,
                          title: Number(x.provisioned_pct) > 100
                            ? "Thin disks are provisioned beyond capacity" : "" },
                x.provisioned_pct + "%") : "" },
        { label: "Hosts", num: true, cell: x => x.host_count },
        { label: "VMs", num: true, cell: x => x.vm_count },
        { label: "State", nowrap: true, cell: x => x.accessible === false
            ? h("span", { class: "esxi-bad" }, "not accessible") : "Accessible" },
        { label: "vCenter", nowrap: true, cell: x => x.vcenter },
      ],
      networks: [
        { label: "Network", nowrap: true, cell: x => x.name },
        { label: "Kind", nowrap: true, cell: x => ({
            Network: "Standard port group",
            DistributedVirtualPortgroup: "Distributed port group",
            OpaqueNetwork: "Opaque (NSX)" }[x.kind] || x.kind) },
        { label: "Datacenter", nowrap: true, cell: x => x.datacenter || "" },
        { label: "VMs", num: true, cell: x => x.vm_count },
        { label: "State", nowrap: true, cell: x => x.accessible === false
            ? h("span", { class: "esxi-bad" }, "not accessible") : "Accessible" },
        { label: "vCenter", nowrap: true, cell: x => x.vcenter },
      ],
      clusters: [
        { label: "Cluster", nowrap: true, cell: x => x.name },
        { label: "Datacenter", nowrap: true, cell: x => x.datacenter || "" },
        { label: "Hosts", num: true, cell: x => x.hosts_seen },
        { label: "VMs", num: true, cell: x => x.vms },
        { label: "CPU cores", num: true, cell: x => x.num_cpu_cores || "" },
        { label: "Memory", num: true, nowrap: true, cell: x => tb(x.total_memory_mb) },
        { label: "DRS", nowrap: true, cell: x => x.drs_enabled === null ? ""
            : (x.drs_enabled ? "On" : h("span", { class: "muted" }, "Off")) },
        { label: "HA", nowrap: true, cell: x => x.ha_enabled === null ? ""
            : (x.ha_enabled ? "On" : h("span", { class: "muted" }, "Off")) },
        { label: "vCenter", nowrap: true, cell: x => x.vcenter },
      ],
      unmanaged: [
        { label: "VM", nowrap: true, cell: v => v.name },
        { label: "Guest OS", cell: v => v.guest_os || "" },
        { label: "Hostname", nowrap: true, cell: v => v.guest_hostname || h("span", { class: "muted" }, "unknown") },
        { label: "Addresses", mono: true, cell: v => (v.guest_ips || []).join(", ") },
        { label: "Tools", nowrap: true, cell: v => toolsLabel(v.tools_running) },
        { label: "Cluster", nowrap: true, cell: v => v.cluster || "" },
        { label: "vCenter", nowrap: true, cell: v => v.vcenter },
      ],
      snapshots: [
        { label: "VM", nowrap: true, cell: vmCell },
        { label: "Snapshots", num: true, cell: v => v.snapshot_count },
        { label: "Oldest", nowrap: true, cell: v => {
            const d = daysSince(v.oldest_snapshot_at);
            return h("span", { class: d !== null && d >= oldDays ? "snap-old" : null }, ageLabel(d));
          } },
        { label: "Names", cell: v => (v.snapshots || []).map(x => x.name).join(", ") },
        { label: "vCenter", nowrap: true, cell: v => v.vcenter },
      ],
      ambiguous: [
        { label: "VM", nowrap: true, cell: v => v.name },
        { label: "Hostname", nowrap: true, cell: v => v.guest_hostname || "" },
        { label: "Why", cell: () => "Shares its hardware ID with another VM, usually a clone. Not linked, to avoid guessing." },
        { label: "vCenter", nowrap: true, cell: v => v.vcenter },
      ],
      linux: [
        { label: "VM", nowrap: true, cell: vmCell },
        { label: "Server", nowrap: true, cell: v => v.server || h("span", { class: "muted" }, "no agent") },
        { label: "Power", nowrap: true, cell: v => POWER[v.power_state] || v.power_state },
        { label: "Cluster", nowrap: true, cell: v => v.cluster || "" },
        { label: "Snapshots", num: true, cell: v => v.snapshot_count },
        { label: "Linked by", nowrap: true, cell: v => MATCH_LABEL[v.match_method] || "" },
      ],
    }[view];
    const empty = {
      all: q ? "No VM matches that filter." : "No VMs found in any vCenter.",
      hosts: "No ESXi hosts synced yet.",
      datastores: "No datastores synced yet.",
      networks: "No networks synced yet.",
      clusters: "No clusters found. Standalone hosts appear under ESXi hosts.",
      unmanaged: "Every running Linux VM has an agent.",
      snapshots: "No VM has a snapshot.",
      ambiguous: "No ambiguous matches.",
      linux: "No Linux VMs found.",
    }[view];
    body.replaceChildren(
      cache.length ? h("p", { class: "muted small" },
        (vms.length === cache.length ? String(cache.length)
          : vms.length + " of " + cache.length) + " " + noun(vms.length, view)) : null,
      vms.length ? table(cols, vms) : h("div", { class: "empty" }, h("p", null, empty)));
  }
  search.addEventListener("input", () => { q = search.value.trim().toLowerCase(); paint(); });
  tabBtns.forEach(b => b.addEventListener("click", () => { view = b.dataset.k; draw().catch(showError); }));

  render(head, vcCards, note,
    h("div", { class: "controls" },
      h("div", { class: "filters", role: "group", "aria-label": "Show" }, tabBtns),
      search),
    body);
  await draw();
}

/* ---- advisories --------------------------------------------------------- */

/* ---- activity ----------------------------------------------------------- */

const ACTIONS = {
  enroll: "Server enrolled",
  re_enroll: "Server re-enrolled",
  inventory: "Inventory received",
  inventory_rejected: "Inventory rejected",
  create_enrollment_token: "Enrollment token issued",
  decommission: "Server retired",
  mark_stale: "Silent servers marked",
};

async function renderActivity() {
  setNav("activity");
  const res = await api("/admin/audit?limit=200");
  const rows = res.events || [];
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl audit tail -n 200" }, "Activity"),
      h("span", { class: "muted small" }, "Permanent record; entries cannot be edited or removed")),
    rows.length ? table([
      { label: "When", cell: r => fmtDateTime(r.occurred_at) },
      { label: "What", cell: r => ACTIONS[r.action] || r.action },
      { label: "By", cell: r => r.actor },
      { label: "From", mono: true, cell: r => r.source_ip || "" },
      { label: "Detail", cell: r => {
          const d = r.detail || {};
          const parts = [];
          if (d.packages !== undefined) parts.push(d.packages + " packages" + (d.unchanged ? ", unchanged" : ""));
          if (d.os) parts.push(d.os);
          if (d.host_group) parts.push("group " + d.host_group);
          if (d.reboot_required) parts.push("reboot required");
          if (d.package_count !== undefined) parts.push(d.package_count + " packages reported");
          return parts.join(", ");
        } },
    ], rows)
    : h("div", { class: "empty" }, h("p", null, "Nothing recorded yet.")),
  );
}

/* ---- routing ------------------------------------------------------------ */

let routeSeq = 0;
async function route() {
  // A slower page that finishes after the user has moved on must not replace the newer page
  const my = ++routeSeq;
  const a = getAuth();
  if (!a) return renderSignIn();
  if (a.user.must_change_password) return renderChangePassword(true);
  if (a.user.must_setup_2fa) return renderTwoFactor(true);
  document.body.classList.add("signed-in");
  applyRoleTheme();
  if (typeof applyBrand === "function") applyBrand();
  showShell(true);
  // The chat, AI explanations and CVE analysis are operator tools
  document.getElementById("chat-open").hidden = !can("operator");
  // Who is signed in, at the foot of the menu; the account page is one click away
  const who = document.getElementById("whoami");
  const name = a.user.display_name || a.user.username;
  who.textContent = name;
  who.title = a.user.username + " \u00b7 " + a.user.role + ". Your account: password and two-factor sign-in";
  const role = document.getElementById("su-role");
  if (role) role.textContent = ({ admin: "Admin", operator: "Operator", viewer: "Viewer" })[a.user.role] || a.user.role;
  const ini = document.getElementById("su-ini");
  if (ini) ini.textContent = name.split(/[\s._-]+/).filter(Boolean).slice(0, 2).map(w => w[0]).join("").toUpperCase() || "?";
  document.querySelectorAll("nav a[data-min-role]").forEach(el => {
    el.hidden = !can(el.dataset.minRole);
  });

  const raw = location.hash.replace(/^#\/?/, "");
  const [path, query] = raw.split("?");
  const params = new URLSearchParams(query || "");
  const parts = path.split("/").filter(Boolean);

  // Modules this user may open (cyber.js); the API enforces the same
  if (typeof setPageExport === "function") setPageExport(null);
  if (typeof setPageSelection === "function") setPageSelection(null);
  if (typeof setMailParams === "function") setMailParams({});
  if (typeof applyModuleNav === "function") {
    await refreshMe(false);
    applyModuleNav();
    if (!routeAllowed(parts[0])) {
      clearPageTimer();
      if (typeof sectionNav === "function") sectionNav(parts[0]);   // the menu, even on a page this user may not open
      return noAccess(parts[0]);
    }
  }

  if (typeof sectionNav === "function") { sectionNav(parts[0]); watchIntros(); }
  try {
    if (parts[0] === "hosts") await renderServers(params);
    else if (parts[0] === "server-groups") await renderServerGroups(params);
    else if (parts[0] === "patch-reports") await renderPatchReports(params);
    else if (parts[0] === "installed-patches") await renderInstalledPatches(params);
    else if (parts[0] === "deployment") await renderDeployment(params);
    else if (parts[0] === "host" && parts[1]) { await renderHost(parts[1], params); await Promise.all([windowsPanel(parts[1]), linuxPanel(parts[1])]); }
    else if (parts[0] === "agents") await renderServers(params, true);
    else if (parts[0] === "agent-updates") await renderAgentUpdates(params);
    else if (parts[0] === "vmware") await renderVmware(params);
    else if (parts[0] === "assess") await renderAssess(params);
    else if (parts[0] === "hardening" && parts[1] === "custom" && parts[2] === "new") await renderCustomNew();
    else if (parts[0] === "hardening" && parts[1] === "custom" && parts[2]) await renderCustomReview(parts[2]);
    else if (parts[0] === "hardening" && parts[1] === "custom") await renderCustomList();
    else if (parts[0] === "hardening" && parts[1] === "host" && parts[2]) await renderHardeningHost(parts[2], params);
    else if (parts[0] === "hardening" && parts[1] === "rule" && parts[2]) await renderHardeningRule(decodeURIComponent(parts[2]), params);
    else if (parts[0] === "hardening") await renderHardening(params);
    else if (parts[0] === "mail") { await renderMail(params); adminTabs("mail"); }
    else if (parts[0] === "wsus") await renderWsus(params);
    else if (parts[0] === "assets") await renderAssets(params);
    else if (parts[0] === "assets-decom") await renderAssetsDecom(params);
    else if (parts[0] === "assets-coverage") await renderAssetsCoverage(params);
    else if (parts[0] === "software-inventory" || parts[0] === "software")
      await renderSoftwareInventory(params, params.get("platform") === "linux" ? "linux" : "windows");
    else if (parts[0] === "software-linux") await renderSoftwareInventory(params, "linux");
    else if (parts[0] === "software-rules" || parts[0] === "software-tools") await renderSoftwareRules(params);
    else if (parts[0] === "branding") { await renderBranding(params); adminTabs("branding"); }
    else if (parts[0] === "certificate") { await renderCertificate(params); adminTabs("certificate"); }
    else if (parts[0] === "changes" && parts[1] === "new") {
      const kind = params.get("kind") || "patch";
      const need = kind === "software" ? ["lifecycle"] : kind === "vm" ? ["patch", "inventory"] : ["patch"];
      if (!hasModule(...need)) return noAccess(kind === "software" ? "deployment" : kind === "vm" ? "vmware" : "dashboard");
      await renderNewChange(params);
    }
    else if (parts[0] === "changes") await renderChanges(params);
    else if (parts[0] === "change" && parts[1]) { await renderChange(parts[1]); }
    // Installers on a share is retired: Deployment holds the installers now
    else if (parts[0] === "installers") { location.replace("#/deployment"); return; }
    else if (parts[0] === "users") { await renderUsers(params); adminTabs("users"); }
    else if (parts[0] === "password") renderChangePassword(false);
    else if (parts[0] === "two-factor") await renderTwoFactor(false);
    else if (parts[0] === "advisories") await renderAdvisories(params);
    else if (parts[0] === "activity") await renderActivity(params);
    else if (parts[0] === "feeds") await renderFeedsAdmin(params);
    else if (parts[0] === "access") await renderAccess(params);
    else if (parts[0] === "antivirus") await renderAntivirus(params);
    else if (parts[0] === "av-consoles") await renderAvConsoles(params);
    else if (parts[0] === "nessus-servers") await renderNessusServers(params);
    else if (parts[0] === "cb-servers") await renderCbServers(params);
    else if (parts[0] === "repos") await renderRepos(params);
    else if (parts[0] === "report-schedules") await renderReportSchedules(params);
    else if (parts[0] === "dashboard") await renderCyberDashboard();
    else if (parts[0] === "impact") await renderImpact(params);
    else if (parts[0] === "nessus") await renderNessus(params);
    else if (parts[0] === "vulns") await renderAdvisories(params);
    else await renderHome();
    if (my !== routeSeq) return;
    if (typeof attachExport === "function" && parts[0]) attachExport(parts[0], parts[1]);
    welcomeToast();
  } catch (err) {
    if (err instanceof StaleRoute || my !== routeSeq) return;
    showError(err);
  }
}

function start() {
  route();
}

/* ---- page timers --------------------------------------------------------
 * A page that refreshes itself (a running change, an assessment being
 * enriched) registers here, so navigating away stops it.
 */
let pageTimer = null;
function setPageTimer(fn, ms) { clearPageTimer(); pageTimer = setInterval(fn, ms); }
function clearPageTimer() { if (pageTimer) { clearInterval(pageTimer); pageTimer = null; } }
window.addEventListener("hashchange", clearPageTimer);

/* ---- changes ------------------------------------------------------------ */

const CHANGE_STATE = {
  pending_approval: ["Awaiting approval", "st-unknown"],
  scheduled: ["Scheduled", "st-plain"],
  running: ["Running", "st-running"],
  succeeded: ["Succeeded", "st-fixed_active"],
  partially_succeeded: ["Partly succeeded", "st-fixed_pending_reboot"],
  failed: ["Failed", "st-affected"],
  cancelled: ["Cancelled", "st-unknown"],
  rejected: ["Rejected", "st-unknown"],
};
const TARGET_STATE = {
  queued: "Queued", precheck: "Pre-check", snapshot: "Snapshot", install: "Installing",
  reboot: "Rebooting", wait_boot: "Waiting for boot", reboot_wait: "Installed, waiting for the restart time", waiting_credential: "Waiting for the share credential",
  postcheck: "Post-check",
  inventory: "Reporting inventory", snapshot_cleanup: "Removing snapshot",
  vm_action: "In progress", update: "Updating the agent", verify: "Waiting for the new agent to check in and answer", done: "Done", done_with_warnings: "Done, with warnings", failed: "Failed", skipped: "Skipped",
  cancelled: "Cancelled",
};
// What a running job is doing, in the HUD ring's few letters
const KIND_VERB = { patch: "PATCHING", software: "DEPLOYING", agent_update: "UPDATING", restart: "RESTARTING",
  vm_snapshot_create: "SNAPSHOT", vm_snapshot_remove: "CLEANUP", vm_snapshot_cleanup: "CLEANUP", vm_snapshot_revert: "REVERTING",
  vm_power_on: "POWER ON", vm_guest_shutdown: "SHUTDOWN", vm_guest_restart: "RESTARTING" };
const KIND_LABEL = {
  patch: "Patch servers", software: "Software", vm_snapshot_create: "Take snapshot", vm_snapshot_remove: "Remove snapshot",
  vm_snapshot_cleanup: "Remove snapshots by name or age",
  vm_snapshot_revert: "Revert to snapshot", vm_power_on: "Power on",
  vm_guest_shutdown: "Shut down guest", vm_guest_restart: "Restart guest", agent_update: "Update agents", restart: "Restart servers",
};

function changeMark(st, summary) {
  // A software job where the agent changed nothing is never shown as a plain success
  const s = summary || {}, unchanged = Number(s.unchanged || 0), done = Number(s.done || 0) + Number(s.done_with_warnings || 0);
  if (unchanged && unchanged >= done && (st === "succeeded" || st === "partially_succeeded"))
    return h("span", { class: "state st-warn", title: "The agent found nothing to do on " + unchanged + " server(s): see each server's reason" }, "Nothing changed");
  const [label, cls] = CHANGE_STATE[st] || [st, "st-plain"];
  return h("span", { class: "state " + cls }, label,
    unchanged ? h("span", { class: "small", title: "nothing was changed on these servers: see each server's reason" }, " \u00b7 " + unchanged + " unchanged") : null);
}
// A software job's install step, by what it does (r109): a removal is never shown as "Installing"
const SOFTWARE_STEP = { install: "Installing", upgrade: "Upgrading", uninstall: "Removing", replace: "Replacing" };
function targetMark(st, params, detail) {
  const p = params || {};
  let word = TARGET_STATE[st] || st;
  if (st === "install" && (p.source === "installed" || SOFTWARE_STEP[p.action])) {
    word = p.source === "installed" ? "Removing" : SOFTWARE_STEP[p.action];
    if (p.action === "replace") word = (detail || {}).replace_phase === "install" ? "Replacing: installing the new one" : "Replacing: removing the old one";
  }
  const cls = st === "done" ? "st-fixed_active" : st === "done_with_warnings" ? "st-warn" : st === "failed" ? "st-affected"
    : ["skipped", "cancelled"].includes(st) ? "st-unknown"
    : st === "queued" ? "st-plain" : "st-running";
  return h("span", { class: "state " + cls }, word);
}
function ref(n) { return "CHG-" + String(n).padStart(6, "0"); }

async function workerBanner() {
  try {
    const w = await api("/worker/status");
    if (w.alive) return null;
    return h("div", { class: "hs-alert st-affected" }, h("strong", null, "The worker is not running. "),
      "Scheduled changes will not start until it is. On PATCH-01: ",
      h("code", null, "./scripts/phase3b-api.sh --check"));
  } catch (e) { return null; }
}

async function renderChanges(params) {
  setNav("changes");
  let show = params.get("state") || "";
  const [list, banner] = await Promise.all([
    api("/changes" + (show ? "?state=" + encodeURIComponent(show) : "")), workerBanner()]);
  const rows = list.changes || [];
  const filters = [["", "All"], ["scheduled", "Scheduled"], ["running", "Running"],
                   ["failed", "Failed"], ["partially_succeeded", "Partly succeeded"],
                   ["succeeded", "Succeeded"]]
    .map(([k, l]) => h("a", { class: "fbtn", href: "#/changes" + (k ? "?state=" + k : ""),
                              "aria-pressed": String(k === show) }, l));
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl changes ls" }, "Changes"),
      h("span", { class: "head-actions" }, can("operator") ? [
        hasModule("patch") ? h("a", { class: "btn", href: "#/changes/new?kind=patch" }, "New patch job") : null,
        hasModule("patch", "inventory") ? h("a", { class: "btn btn-quiet", href: "#/changes/new?kind=vm" }, "New VMware action") : null,
        hasModule("patch", "inventory") ? h("a", { class: "btn btn-quiet", href: "#/changes/new?kind=snapclean" }, "Remove snapshots by name or age") : null,
        hasModule("lifecycle") ? h("a", { class: "btn btn-quiet", href: "#/deployment?tab=new" }, "New software job") : null] : null)),
    banner,
    h("p", { class: "muted" }, "Every patch job and VMware action, who asked for it, why, and what happened."),
    h("div", { class: "controls" }, h("div", { class: "filters" }, filters)),
    rows.length ? table([
      { label: "Change", nowrap: true, mono: true, cell: c => h("a", { href: "#/change/" + c.id }, ref(c.number)) },
      { label: "What", cell: c => c.title },
      { label: "Kind", nowrap: true, cell: c => KIND_LABEL[c.kind] || c.kind },
      { label: "State", nowrap: true, cell: c => changeMark(c.state, c.summary) },
      { label: "Progress", nowrap: true, cell: c => {
          const ring = c.state === "running" ? hudJobCounts(c, { key: "jobs-" + c.id }) : null;
          return ring ? h("span", { class: "hud-inline" }, ring, h("span", { class: "small" },
              (c.done + c.failed) + " / " + c.targets + " finished" + (c.failed ? ", " + c.failed + " failed" : "")
              + (c.in_progress ? ", " + c.in_progress + " running" : "")))
            : c.targets + " target" + (c.targets == 1 ? "" : "s")
              + (c.done ? ", " + c.done + " done" : "") + (c.failed ? ", " + c.failed + " failed" : "")
              + (c.in_progress ? ", " + c.in_progress + " running" : ""); } },
      { label: "Starts", nowrap: true, cell: c => fmtDateTime(c.run_after) },
      { label: "By", nowrap: true, cell: c => c.requested_by },
    ], rows, { onRow: c => { location.hash = "#/change/" + c.id; } })
      : h("div", { class: "empty" }, h("p", null, show ? "No changes in this state."
          : can("operator") ? "Nothing scheduled yet. Start with a patch job." : "Nothing scheduled yet.")));
  // A running job's ring follows it (r112)
  if (rows.some(c => c.state === "running")) {
    const here = location.hash;
    setPageTimer(() => { if (location.hash === here) renderChanges(params).catch(showError); }, 15000);
  }
}

function describeParams(c) {
  const p = c.params || {};
  if (c.kind === "patch") {
    return [
      ["Installs", p.mode === "advisories" ? "Only: " + (p.advisories || []).join(", ")
                                           : "Security updates each server reports (WSUS / package manager)"],
      ["Reboot", { never: "Never, flag only", if_required: "Only if required", always: "Always" }[p.reboot] || p.reboot],
      ["Restart", p.reboot === "never" ? null : p.reboot_at ? "At a set time: " + fmtDateTime(p.reboot_at) + " (servers wait after installing)" : "Right after installing"],
      ["VM snapshot", { none: "None", keep: "Take one before, keep it",
                        remove_on_success: "Take one before, remove it if patching succeeds" }[p.snapshot] || p.snapshot],
      ["Service check", p.check_services ? "Services running before must be running after" : "Off"],
    ].filter(r => r[1] != null);
  }
  if (c.kind === "restart") {
    return [["Does", "Restarts only: nothing is installed"],
            ["Steps", "Pre-check, restart, wait until the server is back, post-check, inventory"],
            ["Service check", p.check_services ? "Services running before must be running after" : "Off"]];
  }
  if (c.kind === "agent_update") {
    const r = p.releases || {};
    return Object.entries(r).map(([k, v]) => [k === "windows" ? "Windows agent" : "Linux agent",
      v.version + " (SHA-256 " + String(v.sha256 || "").slice(0, 16) + "\u2026)"])
      .concat([["Safety", "Each agent checks and test-runs the file before the swap, and puts its previous version back if the new one does not check in and read its commands within 10 minutes (Linux: its interval plus 5); the new one must also answer a check job"]]);
  }
  if (c.kind === "vm_snapshot_cleanup") {
    return [["Removes", (p.total || 0) + " snapshot" + (p.total == 1 ? "" : "s") + " on " + (p.vms || 0) + " VM" + (p.vms == 1 ? "" : "s")],
            ["Chosen by", p.described || ""],
            ["Safety", "Each snapshot is checked again on the VM just before it is removed: still there, same name, still "
                       + "matching. Only that snapshot is removed; its children and the VM's current state are kept."]];
  }
  const out = [];
  if (p.name) out.push(["Snapshot name", p.name]);
  if (p.snapshot_name) out.push(["Snapshot", p.snapshot_name]);
  if (c.kind === "vm_snapshot_revert") out.push(["Safety", "A snapshot of the current state is taken first, so the revert can be undone"]);
  return out;
}

async function renderChange(id) {
  setNav("changes");
  const d = await api("/changes/" + encodeURIComponent(id));
  const c = d.change;
  const live = ["scheduled", "running", "pending_approval"].includes(c.state);
  const facts = [
    ["State", changeMark(c.state, c.summary)],
    ["Kind", KIND_LABEL[c.kind] || c.kind],
    ["Why", c.reason],
    ["Requested", c.requested_by + " (" + c.requested_role + "), " + fmtDateTime(c.requested_at)],
    ["Window", fmtDateTime(c.run_after) + (c.run_before ? " to " + fmtDateTime(c.run_before) : ", no end")],
    ["Parallel", c.max_parallel + " at a time"],
    c.started_at ? ["Started", fmtDateTime(c.started_at)] : null,
    c.finished_at ? ["Finished", fmtDateTime(c.finished_at)] : null,
    c.approval_required ? ["Approval", c.approved_by ? "By " + c.approved_by : "Waiting"] : null,
  ].filter(Boolean).concat(describeParams(c));

  const cancelBtn = can("operator") && live && !c.cancel_requested
    ? h("button", { type: "button", class: "btn btn-danger", on: { click: async () => {
        if (!confirm("Cancel " + ref(c.number) + "? Servers not yet started will not be touched; "
                     + "a server part way through stops before installing.")) return;
        try { await apiPost("/changes/" + c.id + "/cancel", {}); route(); }
        catch (e) { alert(e.message); }
      } } }, "Cancel change") : null;

  // Waiting for approval (only when approval is switched on): a different admin decides
  const me = (getAuth() || { user: {} }).user.username;
  const decide = approve => async () => {
    if (!confirm((approve ? "Approve " : "Reject ") + ref(c.number) + "?"
                 + (approve ? " It runs in its window." : " Nothing is installed."))) return;
    try { await apiPost("/changes/" + c.id + "/decide", { approve }); route(); }
    catch (e) { alert(e.message); }
  };
  const decideBtns = c.state === "pending_approval" && can("admin")
    ? (c.requested_by === me
        ? h("span", { class: "muted small" }, "Another admin approves this change.")
        : [h("button", { type: "button", class: "btn", on: { click: decide(true) } }, "Approve"),
           h("button", { type: "button", class: "btn btn-quiet", on: { click: decide(false) } }, "Reject")])
    : null;

  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl change show " + ref(c.number) }, ref(c.number) + "  " + c.title),
      h("span", { class: "head-actions" }, decideBtns, cancelBtn, h("a", { href: "#/changes", class: "small" }, "All changes"))),
    c.cancel_requested && live ? h("div", { class: "hs-alert st-unknown" }, h("strong", null, "Cancelling. "),
      "Servers part way through will stop before installing.") : null,
    await workerBanner(),
    (d.targets || []).length ? h("div", { class: "hud-row hud-top" },
      hudJob(d.targets, { key: "change-" + c.id, title: c.state === "running" ? (KIND_VERB[c.kind] || "RUNNING")
          : c.state === "scheduled" ? "SCHEDULED" : c.state === "pending_approval" ? "AWAITING OK" : (CHANGE_STATE[c.state] || [c.state])[0] }),
      h("dl", { class: "facts" }, facts.map(([k, v]) => h("div", null, h("dt", null, k), h("dd", null, v)))))
      : h("dl", { class: "facts" }, facts.map(([k, v]) => h("div", null, h("dt", null, k), h("dd", null, v)))),
    h("section", null, h("h2", null, "Targets"),
      table([
        { label: "Target", nowrap: true, cell: t => t.host_id && (c.kind === "patch" || c.kind === "agent_update")
            ? h("a", { href: "#/host/" + t.host_id }, t.label) : t.label },
        { label: "State", nowrap: true, cell: t => targetMark(t.state, c.kind === "software" ? c.params : null, t.detail) },
        c.kind === "vm_snapshot_cleanup" ? { label: "Snapshots", cell: t => cleanupCell(c, t) }
          : { label: "Packages", num: true, cell: t => ((t.detail || {}).packages || []).length || "" },
        // Only "kept" once the target has finished with it still in place
        c.kind === "vm_snapshot_cleanup" ? null : { label: "Snapshot", nowrap: true, cell: t => !t.snapshot_moref ? ""
            : (["done", "failed", "skipped", "cancelled"].includes(t.state)
                ? "kept (" + t.snapshot_moref + ")" : t.snapshot_moref) },
        { label: "Since", nowrap: true, cell: t => t.step_started_at ? timeAgo(t.step_started_at) : "" },
        { label: "Problem", cell: t => {
            const dt = t.detail || {};
            const warns = (dt.warnings || []).filter(Boolean);
            if (!t.error && !warns.length) return "";
            return h("div", null, t.error ? h("span", { class: "explain-error" }, t.error) : null,
              warns.length ? h("ul", { class: "small pr-warn" }, warns.slice(0, 8).map(w => h("li", null, w))) : null,
              ["patch", "software"].includes(c.kind) ? explainBox({ state: t.state, warnings: warns, explain: dt.explain, target_key: t.target_key }, c.id) : null);
          } },
      ].filter(Boolean), d.targets || [])),
    h("section", null, h("h2", null, "What happened"),
      h("ol", { class: "timeline" }, (d.events || []).map(e =>
        h("li", { class: e.ok === false ? "tl-bad" : e.ok ? "tl-ok" : "" },
          h("span", { class: "tl-when" }, fmtDateTime(e.at)),
          h("span", { class: "tl-who" }, e.actor),
          h("span", { class: "tl-msg" }, e.message || e.event))))),
  );
  if (live) setPageTimer(() => { if (location.hash === "#/change/" + id) renderChange(id).catch(showError); }, 10000);
}

// Snapshot removal by name or age: on each VM, what is to be removed, then what was
function cleanupCell(c, t) {
  const d = t.detail || {};
  const planned = ((c.params || {}).selection || {})[t.target_key] || [];
  if (!d.removed && !d.skipped && !d.failed) {
    return h("details", null, h("summary", null, planned.length + " to remove"),
      h("ul", { class: "small" }, planned.map(s => h("li", null, s.name + (s.created ? " (" + fmtDateTime(s.created) + ")" : "")))));
  }
  const rm = d.removed || [], sk = d.skipped || [], fl = d.failed || [];
  const head = [rm.length + " removed", sk.length ? sk.length + " skipped" : null, fl.length ? fl.length + " failed" : null]
    .filter(Boolean).join(", ");
  return h("details", { open: (sk.length || fl.length) ? true : null }, h("summary", null, head),
    h("ul", { class: "small" },
      rm.map(s => h("li", null, "Removed: " + s.name)),
      sk.map(s => h("li", null, "Skipped: " + s.name + " (" + s.reason + ")")),
      fl.map(s => h("li", { class: "explain-error" }, "Failed: " + s.name + " (" + s.error + ")"))));
}

/* ---- new change --------------------------------------------------------- */

function localInputValue(d) {
  const z = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return z.toISOString().slice(0, 16);
}
function toIso(v) { return v ? new Date(v).toISOString() : null; }

function windowFields(opts) {
  const parallel = !(opts && opts.single);
  const start = h("input", { type: "datetime-local", value: localInputValue(new Date()) });
  const end = h("input", { type: "datetime-local" });
  const par = h("input", { type: "number", min: "1", max: "50", value: parallel ? "5" : "1" });
  const el = h("div", { class: "af-row" },
    h("label", null, h("span", null, "Start"), start),
    h("label", null, h("span", null, "End of window (optional)"), end),
    parallel ? h("label", null, h("span", null, "Servers at a time"), par) : null);
  return { el, get: () => ({ run_after: toIso(start.value), run_before: toIso(end.value),
                             max_parallel: Number(par.value) || 5 }) };
}

async function renderNewChange(params) {
  setNav("changes");
  if (!can("operator")) return render(h("div", { class: "empty" },
    h("p", null, "Scheduling changes needs the operator role.")));
  // Software jobs are made in Deployment (installers on a share are retired)
  if (params.get("kind") === "software") { location.replace("#/deployment?tab=new"); return; }
  if (params.get("kind") === "snapclean") return renderSnapshotCleanup(params);
  return params.get("kind") === "vm" ? renderNewVmChange(params) : renderNewPatch(params);
}

async function renderNewPatch(params) {
  // The same servers, groups and "to install" counts as the Servers page
  const sv = await api("/servers?view=groups&sort=name");
  const pre = new Set((params.get("hosts") || "").split(",").filter(Boolean));
  const preGroup = params.get("group") || "";
  const groups = (sv.groups || []).filter(g => g.rows.length);
  const hosts = [].concat(...groups.map(g => g.rows));
  const boxes = new Map();
  const counter = h("span", { class: "muted small" });
  const recount = () => { const n = [...boxes.values()].filter(cb => cb.checked).length; counter.textContent = n + (n === 1 ? " server chosen" : " servers chosen"); };
  const list = h("div", { class: "pick-groups" }, groups.map(g => {
    const all = h("input", { type: "checkbox", "aria-label": "Choose every server in " + g.name });
    const items = g.rows.map(x => {
      const cb = h("input", { type: "checkbox", value: x.host_id });
      if (pre.has(x.host_id) || (preGroup && preGroup === g.name)) cb.checked = true;
      cb.addEventListener("change", () => { sync(); recount(); });
      boxes.set(x.host_id, cb);
      const n = Number(x.to_install || 0);
      return h("label", { class: "pick" }, cb,
        h("span", { class: "pick-name" }, x.hostname),
        h("span", { class: "muted" }, x.os_label || osLabel(x.os_id, x.os_version)),
        agentMark(x.agent === "online" ? "online" : "offline"),
        n ? h("span", null, h("span", { class: "count st-affected" }, String(n)), x.os_id === "windows" ? (n === 1 ? " Windows update" : " Windows updates") : (n === 1 ? " package" : " packages"))
          : h("span", { class: "muted" }, "up to date"));
    });
    const sync = () => { const cs = g.rows.map(x => boxes.get(x.host_id)); all.checked = cs.every(c => c.checked); all.indeterminate = !all.checked && cs.some(c => c.checked); };
    all.addEventListener("change", () => { g.rows.forEach(x => { boxes.get(x.host_id).checked = all.checked; }); sync(); recount(); });
    const body = h("div", { class: "pick-list" }, items);
    sync();
    return h("details", { class: "pick-group", open: g.rows.some(x => boxes.get(x.host_id).checked) || groups.length === 1 },
      h("summary", null, all, h("strong", null, g.name), h("span", { class: "muted small" },
        " " + g.servers + (g.servers === 1 ? " server" : " servers") + (g.to_install_servers ? ", " + g.to_install_servers + " to patch" : ", up to date"))),
      body);
  }));
  const selectNeeding = h("button", { type: "button", class: "btn btn-quiet", on: { click: () => {
    hosts.forEach(x => { boxes.get(x.host_id).checked = Number(x.to_install || 0) > 0; });
    refreshPicks(); recount();
  } } }, "Select all needing patches");
  function refreshPicks() {
    list.querySelectorAll("details.pick-group").forEach(dt => {
      const cs = [...dt.querySelectorAll(".pick input")]; const a = dt.querySelector("summary input");
      a.checked = cs.length && cs.every(c => c.checked); a.indeterminate = !a.checked && cs.some(c => c.checked);
      if (cs.some(c => c.checked)) dt.open = true;
    });
  }
  recount();

  const mode = h("select", null, h("option", { value: "security" }, "Security updates each server reports (WSUS / package manager)"),
                                 h("option", { value: "advisories" }, "Only the advisories listed below"));
  const advs = h("input", { type: "text", placeholder: "RHSA-2026:4417, RHSA-2026:4380", hidden: true });
  mode.addEventListener("change", () => { advs.hidden = mode.value !== "advisories"; });
  // Opened from an advisory: only that advisory, on the servers that need it
  const preAdv = (params.get("advisories") || "").split(",").map(x => x.trim()).filter(x => /^[A-Za-z0-9][A-Za-z0-9:._-]{1,60}$/.test(x));
  if (preAdv.length) { mode.value = "advisories"; advs.value = preAdv.join(", "); advs.hidden = false; }
  const reboot = h("select", null, h("option", { value: "if_required" }, "Only if required"),
                   h("option", { value: "never" }, "Never, just flag it"), h("option", { value: "always" }, "Always"));
  // When the restart happens: straight after installing, or at a time of its own (patch at night, restart in the maintenance slot)
  const rebootWhen = h("select", { "aria-label": "When to restart" },
    h("option", { value: "after_install" }, "Right after installing"),
    h("option", { value: "at" }, "At a set time"));
  const rebootAt = h("input", { type: "datetime-local", "aria-label": "Restart time" });
  const rebootAtLbl = h("label", { hidden: true }, h("span", null, "Restart at"), rebootAt);
  const rebootNote = h("p", { class: "muted small", hidden: true },
    "The servers install from the start time, then wait. At the restart time they restart, as many at once as "
    + "“Servers at a time” allows (one at a time for a cluster). Waiting servers do not hold up the others. "
    + "A server that finishes installing after the restart time restarts as soon as it has installed.");
  const syncReboot = () => {
    const never = reboot.value === "never";
    rebootWhen.disabled = never;
    const at = !never && rebootWhen.value === "at";
    rebootAtLbl.hidden = !at; rebootNote.hidden = !at;
  };
  reboot.addEventListener("change", syncReboot);
  rebootWhen.addEventListener("change", () => {
    if (rebootWhen.value === "at" && !rebootAt.value) {
      const t = new Date(Date.now() + 4 * 3600 * 1000); t.setMinutes(0, 0, 0);
      rebootAt.value = localInputValue(t);
    }
    syncReboot();
  });
  const snap = h("select", null, h("option", { value: "none" }, "No snapshot"),
                 h("option", { value: "remove_on_success" }, "Snapshot first, remove if it succeeds"),
                 h("option", { value: "keep" }, "Snapshot first, keep it"));
  const svc = h("input", { type: "checkbox", checked: true });
  const win = windowFields();
  const title = h("input", { type: "text", placeholder: "September security patching, prod web tier" });
  const reason = h("textarea", { rows: "2", placeholder: "Why this change is being made. Kept in the record." });
  const out = h("div");
  const err = h("p", { class: "explain-error", hidden: true });

  function body() {
    return {
      kind: "patch", title: title.value.trim() || null, reason: reason.value.trim(),
      targets: [...boxes.entries()].filter(([, cb]) => cb.checked).map(([id]) => ({ host_id: id })),
      params: { mode: mode.value, reboot: reboot.value, snapshot: snap.value, check_services: svc.checked,
                advisories: advs.value.split(/[,\s]+/).map(x => x.trim().toUpperCase()).filter(Boolean),
                reboot_when: reboot.value === "never" ? "after_install" : rebootWhen.value,
                reboot_at: reboot.value !== "never" && rebootWhen.value === "at" ? toIso(rebootAt.value) : null },
      ...win.get(),
    };
  }
  async function preview() {
    err.hidden = true;
    try {
      const r = await apiPost("/changes/preview", body());
      const total = r.targets.reduce((a, t) => a + t.packages.length, 0);
      out.replaceChildren(h("h2", null, "What will happen"),
        h("p", null, total + " updates across " + r.targets.length + " server"
          + (r.targets.length === 1 ? "" : "s") + ". Each server runs a pre-check first and stops if it fails. "
          + "Windows servers search WSUS again just before installing."),
        table([
          { label: "Server", nowrap: true, cell: t => t.label },
          { label: "From", nowrap: true, cell: t => t.source === "package manager" ? "Package manager"
              : t.source === "WSUS" ? "WSUS" : h("span", { title: "Chosen advisories, or an agent older than 1.8.2" }, "Advisories") },
          { label: "Packages", cell: t => t.packages.length
              ? t.packages.slice(0, 6).map(p => p.name).join(", ") + (t.packages.length > 6 ? " and " + (t.packages.length - 6) + " more" : "")
              : h("span", { class: "muted" }, "nothing to install") },
          { label: "VM", nowrap: true, cell: t => t.linked_vm ? "linked" : h("span", { class: "muted" }, "not linked") },
        ], r.targets));
    } catch (e) { err.textContent = e.message; err.hidden = false; }
  }
  async function submit() {
    err.hidden = true;
    try {
      const r = await apiPost("/changes", body());
      location.hash = "#/change/" + r.id;
    } catch (e) { err.textContent = e.message; err.hidden = false; }
  }
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl patch --new" }, "New patch job"),
      h("a", { href: "#/changes", class: "small" }, "All changes")),
    h("section", { class: "form-sec" }, h("h2", null, "1. Servers"),
      h("div", { class: "controls" }, selectNeeding, counter), list),
    h("section", { class: "form-sec" }, h("h2", null, "2. What to install"),
      h("div", { class: "af-row" },
        h("label", null, h("span", null, "Install"), mode, advs),
        h("label", null, h("span", null, "Reboot afterwards"), reboot),
        h("label", null, h("span", null, "When to restart"), rebootWhen),
        rebootAtLbl,
        h("label", null, h("span", null, "VM snapshot"), snap)),
      rebootNote,
      h("label", { class: "check" }, svc,
        h("span", null, "Check that services running before are still running afterwards"))),
    h("section", { class: "form-sec" }, h("h2", null, "3. When"), win.el),
    h("section", { class: "form-sec" }, h("h2", null, "4. Record"),
      h("label", null, h("span", null, "Title"), title),
      h("label", null, h("span", null, "Reason (required)"), reason)),
    err,
    h("div", { class: "form-actions" },
      h("button", { type: "button", class: "btn btn-quiet", on: { click: preview } }, "Preview"),
      h("button", { type: "button", class: "btn", on: { click: submit } }, "Schedule")),
    out);
}

/* ---- remove snapshots by name or age ------------------------------------ */

async function renderSnapshotCleanup(params) {
  const writers = await api("/admin/vmware/writers").catch(() => ({ vcenters: [] }));
  const vcs = writers.vcenters || [];
  const mode = h("select", { id: "sc-mode" },
    [["contains", "Name contains"], ["starts", "Name starts with"], ["exact", "Name is exactly"],
     ["pattern", "Name matches a pattern (* and ?)"], ["any", "Any name"]]
      .map(([v, l]) => h("option", { value: v }, l)));
  const name = h("input", { id: "sc-name", type: "text", maxlength: "80", placeholder: "Before patch" });
  const ageOn = h("input", { id: "sc-age-on", type: "checkbox", checked: true });
  const days = h("input", { id: "sc-days", type: "number", min: "1", max: "3650", value: "10" });
  const vcSel = h("select", { id: "sc-vcenter" }, h("option", { value: "" }, "All vCenters"),
    vcs.map(v => h("option", { value: v.name }, v.name + (v.can_write ? "" : " (read-only)"))));
  const vmQ = h("input", { id: "sc-vm", type: "search", maxlength: "80", placeholder: "Optional" });
  if (params.get("name")) { name.value = params.get("name"); mode.value = params.get("mode") || "contains"; }
  if (params.get("days")) days.value = params.get("days");
  const find = h("button", { type: "button", class: "btn", id: "sc-find" }, "Find snapshots");
  const findErr = h("p", { class: "explain-error", hidden: true });
  const results = h("div", { id: "sc-results" });
  const nameRow = () => { name.disabled = mode.value === "any"; days.disabled = !ageOn.checked; };
  mode.addEventListener("change", nameRow); ageOn.addEventListener("change", nameRow); nameRow();

  let found = null, used = null;            // the last search and the filter it used
  const ticked = new Set();                 // "vcenter|vm_moref|snapshot_moref"
  const key = m => m.vcenter + "|" + m.vm_moref + "|" + m.snapshot_moref;
  const filterNow = () => ({ name_mode: mode.value, name: mode.value === "any" ? "" : name.value.trim(),
                             older_than_days: ageOn.checked ? days.value : null,
                             vcenter: vcSel.value || null, vm: vmQ.value.trim() || null });
  // Results belong to the filter that found them: changing a field asks for a new search
  const stale = () => { if (found) { found = null; drawResults(); } };
  [mode, name, ageOn, days, vcSel, vmQ].forEach(el => { el.addEventListener("input", stale); el.addEventListener("change", stale); });

  async function search() {
    findErr.hidden = true;
    const f = filterNow();
    try {
      const r = await apiPost("/changes/snapshot-search", { filter: f });
      found = r; used = r.filter; ticked.clear();
      r.matches.filter(m => !m.blocked).forEach(m => ticked.add(key(m)));
      drawResults();
    } catch (e) { found = null; drawResults(); findErr.textContent = e.message; findErr.hidden = false; }
  }
  find.addEventListener("click", search);

  const reason = h("textarea", { id: "sc-reason", rows: "2", placeholder: "Why. Kept in the record." });
  const win = windowFields({ single: true });
  const confirmIn = h("input", { id: "sc-confirm", type: "text", inputmode: "numeric", autocomplete: "off" });
  const go = h("button", { type: "button", class: "btn btn-danger", id: "sc-go" }, "Schedule removal");
  const err = h("p", { class: "explain-error", hidden: true, id: "sc-err" });
  const count = h("p", { id: "sc-count", class: "small" });
  const confirmLabel = h("span", null);

  function selection() {
    const sel = {};
    for (const m of (found ? found.matches : [])) {
      if (!ticked.has(key(m))) continue;
      const k = m.vcenter + "|" + m.vm_moref;
      (sel[k] = sel[k] || []).push(m.snapshot_moref);
    }
    return sel;
  }
  function updateCount() {
    const sel = selection(), vms = Object.keys(sel).length, n = Object.values(sel).reduce((a, x) => a + x.length, 0);
    count.textContent = n + " snapshot" + (n === 1 ? "" : "s") + " on " + vms + " VM" + (vms === 1 ? "" : "s") + " ticked";
    confirmLabel.textContent = "Type " + n + " to confirm";
    go.disabled = n === 0;
  }

  function drawResults() {
    if (!found) {
      results.replaceChildren(h("p", { class: "muted" }, "Set the filter and choose Find snapshots. Nothing is removed until you schedule it."));
      return;
    }
    const ms = found.matches;
    if (!ms.length) {
      results.replaceChildren(h("p", { class: "muted", id: "sc-none" }, "No snapshot matches: " + found.described + "."));
      return;
    }
    const box = m => {
      const cb = h("input", { type: "checkbox", "aria-label": "Remove " + m.name + " on " + m.vm,
                              checked: ticked.has(key(m)) ? true : null, disabled: m.blocked ? true : null });
      cb.addEventListener("change", () => { cb.checked ? ticked.add(key(m)) : ticked.delete(key(m)); updateCount(); });
      return cb;
    };
    const all = (on) => () => { ms.forEach(m => { if (!m.blocked) on ? ticked.add(key(m)) : ticked.delete(key(m)); }); drawResults(); };
    const notes = m => [m.blocked ? h("span", { class: "state st-unknown" }, "Cannot remove: " + m.blocked) : null,
                        m.current ? h("span", { class: "muted" }, "The VM runs on top of it; its changes are merged into the VM") : null,
                        m.description ? h("div", { class: "muted small" }, m.description) : null];
    results.replaceChildren(
      h("p", null, h("strong", null, ms.length + " snapshot" + (ms.length === 1 ? "" : "s")), " on " + found.vms + " VM"
        + (found.vms === 1 ? "" : "s") + " match: " + found.described + "."
        + (found.blocked ? " " + found.blocked + " cannot be removed (shown greyed)." : "")
        + (found.truncated ? " Only the first " + ms.length + " are shown: narrow the filter." : "")),
      h("div", { class: "controls" },
        h("button", { type: "button", class: "btn btn-quiet", id: "sc-all", on: { click: all(true) } }, "Tick all"),
        h("button", { type: "button", class: "btn btn-quiet", id: "sc-none-btn", on: { click: all(false) } }, "Untick all"), count),
      table([
        { label: "Remove", cell: box },
        { label: "VM", nowrap: true, cell: m => m.vm },
        { label: "Snapshot", cell: m => m.name },
        { label: "Created", nowrap: true, cell: m => m.created ? fmtDateTime(m.created) : "unknown" },
        { label: "Age (days)", num: true, cell: m => m.age_days == null ? "" : m.age_days },
        { label: "vCenter", nowrap: true, cell: m => m.vcenter },
        { label: "Notes", cell: notes },
      ], ms),
      h("section", { class: "form-sec" }, h("h2", null, "When"), win.el),
      h("section", { class: "form-sec" }, h("h2", null, "Record"),
        h("label", null, h("span", null, "Reason (required)"), reason)),
      h("section", { class: "form-sec" }, h("h2", null, "Confirm"),
        h("div", { class: "hs-alert st-affected" }, h("strong", null, "Removed snapshots cannot be brought back. "),
          "Each one is checked again on the VM just before it is removed, and skipped if it was renamed, removed, "
          + "or no longer matches. A removal can take minutes per snapshot while vCenter merges its changes. "
          + "Cancel, or the end of the window, stops it before the next snapshot."),
        h("label", null, confirmLabel, confirmIn)),
      err, h("div", { class: "form-actions" }, go));
    updateCount();
  }

  async function submit() {
    err.hidden = true;
    const sel = selection(), targets = Object.keys(sel).map(k => ({ vcenter: k.split("|")[0], moref: k.split("|")[1] }));
    const n = Object.values(sel).reduce((a, x) => a + x.length, 0);
    try {
      const r = await apiPost("/changes", { kind: "vm_snapshot_cleanup", reason: reason.value.trim(),
        title: "Remove " + n + " snapshot" + (n === 1 ? "" : "s") + ": " + found.described,
        targets, params: { filter: used, selection: sel, confirm_count: confirmIn.value.trim() }, ...win.get() });
      location.hash = "#/change/" + r.id;
    } catch (e) { err.textContent = e.message; err.hidden = false; }
  }
  go.addEventListener("click", submit);

  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl snapshots rm --older-than 10d" }, "Remove snapshots by name or age"),
      h("a", { href: "#/changes", class: "small" }, "All changes")),
    h("p", { class: "muted" }, "Find snapshots across the vCenters by their name, their age, or both. Untick any to keep, "
      + "then schedule the removal like any other change: it shows in Changes with its live progress and record."),
    h("section", { class: "form-sec" }, h("h2", null, "Which snapshots"),
      h("div", { class: "af-row" },
        h("label", null, h("span", null, "Name"), mode),
        h("label", null, h("span", null, "Text or pattern"), name)),
      h("div", { class: "af-row" },
        h("label", { class: "check" }, ageOn, h("span", null, "Only snapshots older than")),
        h("label", null, h("span", null, "Days"), days)),
      h("div", { class: "af-row" },
        h("label", null, h("span", null, "vCenter"), vcSel),
        h("label", null, h("span", null, "VM name contains"), vmQ)),
      findErr, h("div", { class: "form-actions" }, find)),
    results);
  drawResults();
}

async function renderNewVmChange(params) {
  const vc = params.get("vc"), moref = params.get("moref");
  const writers = await api("/admin/vmware/writers").catch(() => ({ vcenters: [] }));
  const canWrite = new Set((writers.vcenters || []).filter(v => v.can_write).map(v => v.name));
  if (!vc || !moref) {
    const all = await api("/admin/vmware/vms?view=all");
    const q = h("input", { type: "search", placeholder: "Find a VM by name, cluster or OS" });
    const res = h("div");
    const draw = () => {
      const needle = q.value.trim().toLowerCase();
      const rows = (all.vms || []).filter(v => !needle || [v.name, v.cluster, v.guest_os, v.vcenter]
        .join(" ").toLowerCase().includes(needle)).slice(0, 50);
      res.replaceChildren(table([
        { label: "VM", nowrap: true, cell: v => h("a", { href: "#/changes/new?kind=vm&vc="
            + encodeURIComponent(v.vcenter) + "&moref=" + encodeURIComponent(v.moref) }, v.name) },
        { label: "Power", nowrap: true, cell: v => POWER[v.power_state] || v.power_state },
        { label: "Cluster", nowrap: true, cell: v => v.cluster || "" },
        { label: "vCenter", nowrap: true, cell: v => v.vcenter + (canWrite.has(v.vcenter) ? "" : " (read-only)") },
      ], rows));
    };
    q.addEventListener("input", draw);
    render(h("div", { class: "page-head" }, h("h1", null, "New VMware action"),
             h("a", { href: "#/changes", class: "small" }, "All changes")),
           h("p", { class: "muted" }, "Choose the VM. To remove snapshots across many VMs at once, by name or age: ",
             h("a", { href: "#/changes/new?kind=snapclean" }, "Remove snapshots by name or age"), "."),
           h("div", { class: "controls" }, q), res);
    draw();
    return;
  }
  const d = await api("/admin/vmware/vm/" + encodeURIComponent(vc) + "/" + encodeURIComponent(moref));
  const vm = d.vm, snaps = d.snapshots || [];
  if (!canWrite.has(vc)) {
    return render(h("div", { class: "page-head" }, h("h1", null, vm.vm)),
      h("div", { class: "hs-alert st-unknown" }, h("strong", null, "No write account for " + vc + ". "),
        "Snapshots and power actions need one. On PATCH-01: ",
        h("code", null, "./scripts/phase7-vmware.sh --add-writer " + vc)));
  }
  const on = vm.power_state === "poweredOn", tools = vm.tools_running === "guestToolsRunning";
  const opts = [
    ["vm_snapshot_create", "Take a snapshot", true],
    ["vm_snapshot_remove", "Remove a snapshot", snaps.length > 0],
    ["vm_snapshot_revert", "Revert to a snapshot", snaps.length > 0],
    ["vm_power_on", "Power on", !on],
    ["vm_guest_shutdown", "Shut down the guest OS cleanly", on && tools],
    ["vm_guest_restart", "Restart the guest OS cleanly", on && tools],
  ];
  const kind = h("select", null, opts.map(([v, l, ok]) => h("option", { value: v, disabled: !ok }, l + (ok ? "" : " (not available)"))));
  const snapName = h("input", { type: "text", placeholder: "Before config change CHG-4471", maxlength: "80" });
  const snapDesc = h("input", { type: "text", placeholder: "Optional description", maxlength: "500" });
  const memory = h("input", { type: "checkbox" });
  const snapSel = h("select", null, snaps.map(x => h("option", { value: x.moref },
    x.name + " (" + (x.created ? fmtDateTime(x.created) : "unknown date") + ")")));
  const confirmName = h("input", { type: "text", placeholder: vm.vm, autocomplete: "off" });
  const reason = h("textarea", { rows: "2", placeholder: "Why. Kept in the record." });
  const win = windowFields({ single: true });
  const go = h("button", { type: "button", class: "btn" }, "Schedule");
  const err = h("p", { class: "explain-error", hidden: true });
  const fields = h("div");

  function draw() {
    const k = kind.value;
    const parts = [];
    if (k === "vm_snapshot_create") parts.push(
      h("label", null, h("span", null, "Snapshot name"), snapName),
      h("label", null, h("span", null, "Description"), snapDesc),
      h("label", { class: "check" }, memory, h("span", null, "Include memory (slower, larger)")));
    if (k === "vm_snapshot_remove" || k === "vm_snapshot_revert") parts.push(
      h("label", null, h("span", null, "Snapshot"), snapSel));
    if (k === "vm_snapshot_revert") parts.push(
      h("div", { class: "hs-alert st-affected" }, h("strong", null, "A revert discards everything since that snapshot. "),
        "PATCH-01 takes a snapshot of the current state first, so the revert itself can be undone."),
      h("label", null, h("span", null, "Type the VM name to confirm: " + vm.vm), confirmName));
    if (k === "vm_guest_shutdown") parts.push(h("p", { class: "muted" },
      "Asks the guest OS to shut down through VMware Tools. PATCH-01 never pulls the power."));
    fields.replaceChildren(...parts);
    const revert = k === "vm_snapshot_revert";
    go.className = revert ? "btn btn-danger" : "btn";
    go.textContent = revert ? "Schedule revert" : "Schedule";
  }
  kind.addEventListener("change", draw);
  const firstOk = opts.find(o => o[2]); if (firstOk) kind.value = firstOk[0];
  draw();

  async function submit() {
    err.hidden = true;
    const k = kind.value;
    const p = k === "vm_snapshot_create" ? { name: snapName.value.trim(), description: snapDesc.value, memory: memory.checked }
      : (k === "vm_snapshot_remove" || k === "vm_snapshot_revert")
        ? { snapshot_moref: snapSel.value, confirm_name: confirmName.value } : {};
    try {
      const r = await apiPost("/changes", { kind: k, reason: reason.value.trim(),
        title: (KIND_LABEL[k] || k) + ": " + vm.vm, targets: [{ vcenter: vc, moref }], params: p, ...win.get() });
      location.hash = "#/change/" + r.id;
    } catch (e) { err.textContent = e.message; err.hidden = false; }
  }
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl vm " + vm.vm }, vm.vm),
      h("a", { href: "#/changes", class: "small" }, "All changes")),
    h("div", { class: "host-summary" },
      h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Power"), POWER[vm.power_state] || vm.power_state),
      h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Tools"), toolsLabel(vm.tools_running)),
      h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Host"), vm.esxi_host || ""),
      h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Snapshots"), snaps.length)),
    h("section", { class: "form-sec" }, h("h2", null, "Action"),
      h("label", null, h("span", null, "What to do"), kind), fields),
    h("section", { class: "form-sec" }, h("h2", null, "When"), win.el),
    h("section", { class: "form-sec" }, h("h2", null, "Record"),
      h("label", null, h("span", null, "Reason (required)"), reason)),
    err, h("div", { class: "form-actions" }, go));
  go.addEventListener("click", submit);
}

/* ---- users (admin) ------------------------------------------------------ */

async function renderUsers() {
  setNav("users");
  if (!can("admin")) return render(h("div", { class: "empty" }, h("p", null, "User management needs the admin role.")));
  const d = await api("/admin/users");
  const me = getAuth().user.username;
  const err = h("p", { class: "explain-error", hidden: true });

  async function patch(u, body, done) {
    try { await apiRequest("PATCH", "/admin/users/" + encodeURIComponent(u), body); renderUsers(); if (done) done(); }
    catch (e) { alert(e.message); }
  }
  const nu = h("input", { type: "text", placeholder: "jtan", autocapitalize: "none" });
  const nd = h("input", { type: "text", placeholder: "Jason Tan" });
  const nr = h("select", null, h("option", { value: "viewer" }, "Viewer"),
               h("option", { value: "operator" }, "Operator"), h("option", { value: "admin" }, "Admin"));
  const np = h("input", { type: "password", autocomplete: "new-password", placeholder: "Temporary, 12+ characters" });
  const add = h("form", { class: "assess-form", on: { submit: async e => {
    e.preventDefault(); err.hidden = true;
    try {
      await apiPost("/admin/users", { username: nu.value.trim().toLowerCase(), display_name: nd.value.trim(),
                                      role: nr.value, password: np.value });
      renderUsers();
    } catch (ex) { err.textContent = ex.message; err.hidden = false; }
  } } },
    h("div", { class: "af-row" },
      h("label", null, h("span", null, "Username"), nu),
      h("label", null, h("span", null, "Name"), nd),
      h("label", null, h("span", null, "Role"), nr),
      h("label", null, h("span", null, "Temporary password"), np)),
    err, h("button", { type: "submit" }, "Add user"),
    h("p", { class: "muted small" }, "They choose their own password at first sign-in."));

  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl users ls" }, "Users")),
    h("div", { class: "role-help" },
      h("p", null, h("strong", null, "Viewer "), "sees dashboards and reports. Changes nothing."),
      h("p", null, h("strong", null, "Operator "), "also schedules patching, VM snapshots and power actions, runs CVE assessments, and uses the chat and AI explanations."),
      h("p", null, h("strong", null, "Admin "), "everything, plus users and settings, and the B-Mode theme.")),
    table([
      { label: "User", nowrap: true, cell: u => [u.username, u.username === me ? h("span", { class: "muted" }, " (you)") : null] },
      { label: "Name", cell: u => u.display_name || "" },
      { label: "Role", nowrap: true, cell: u => {
          const sel = h("select", { disabled: u.username === me }, ["viewer", "operator", "admin"].map(r =>
            h("option", { value: r, selected: r === u.role }, r)));
          sel.addEventListener("change", () => patch(u.username, { role: sel.value }));
          return sel; } },
      { label: "State", nowrap: true, cell: u => !u.active ? h("span", { class: "muted" }, "disabled")
          : u.locked ? h("span", { class: "explain-error" }, "locked") : u.must_change_password ? "must change password" : "active" },
      { label: "Two-factor", nowrap: true, cell: u => u.totp_enabled ? h("span", { class: "state st-fixed_active" }, "on") : h("span", { class: "muted" }, "off") },
      { label: "Last sign-in", nowrap: true, cell: u => u.last_login_at ? timeAgo(u.last_login_at) : "never" },
      { label: "", nowrap: true, cell: u => u.username === me ? "" : h("span", { class: "row-actions" },
          h("button", { type: "button", class: "btn-link", on: { click: () => patch(u.username, { active: !u.active }) } },
            u.active ? "Disable" : "Enable"),
          u.locked ? h("button", { type: "button", class: "btn-link", on: { click: () => patch(u.username, { unlock: true }) } }, "Unlock") : null,
          u.totp_enabled ? h("button", { type: "button", class: "btn-link", on: { click: () => {
            if (confirm("Reset two-factor sign-in for " + u.username + " (a lost phone)? Their sessions end, and they set it up again at sign-in.")) patch(u.username, { reset_2fa: true });
          } } }, "Reset two-factor") : null,
          h("button", { type: "button", class: "btn-link", on: { click: () => {
            const pw = prompt("New temporary password for " + u.username + " (12+ characters). They will change it at sign-in.");
            if (pw) patch(u.username, { new_password: pw });
          } } }, "Reset password")) },
    ], d.users || []),
    h("section", null, h("h2", null, "Add a user"), add));
}

async function apiRequest(method, path, body) {
  const res = await fetch("/api/v1" + path, {
    method, headers: { "Content-Type": "application/json", "X-Requested-With": "patch01-dashboard", ...authHeaders() },
    body: body ? JSON.stringify(body) : undefined });
  if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, data.detail || res.statusText);
  return data;
}

/* ---- the assistant ------------------------------------------------------ */
/*
 * Read-only by design. It answers questions and shows the rows behind every
 * answer; it cannot patch, snapshot or power anything (those go through the
 * approval flow). It can export an answer as CSV, and draft an e-mail of it
 * that is sent only when you press Send. It can read answers aloud with the
 * browser's own offline voices: voices that would send the text to an online
 * service are never used.
 */

const CHAT_EXAMPLES = [
  "Give me an overview of the fleet",
  "Windows 10 Pro list",
  "Which servers need patches?",
  "What CVEs are exploited in the wild?",
  "Windows servers missing updates",
  "Failed changes in the last 30 days",
  "Which servers have openssl installed?",
  "Datastores below 15% free",
];
const CHAT_KEY = "patch01.chat";

let chatHistoryEl = null;
let chatEl = null;                 // the panel; it moves into the pop-out window and back
let chatPip = null;                // the always-on-top pop-out window, while open
function chatPanel() { return chatEl || (chatEl = document.getElementById("chat")); }
let chatLast = null;               // the previous answer's query, for "export that" / "mail it"

function chatPrefs() {
  try { return JSON.parse(localStorage.getItem(CHAT_KEY) || "{}") || {}; } catch (e) { return {}; }
}
function chatSavePrefs(p) {
  try { localStorage.setItem(CHAT_KEY, JSON.stringify(Object.assign(chatPrefs(), p))); } catch (e) { /* private window */ }
}

/* Speech: offline voices only (localService), so nothing leaves this PC. */
const ChatVoice = (() => {
  const ok = typeof window.speechSynthesis !== "undefined" && typeof window.SpeechSynthesisUtterance !== "undefined";
  function voices() {
    if (!ok) return [];
    return speechSynthesis.getVoices().filter(v => v.localService);
  }
  function pick() {
    const all = voices();
    const want = chatPrefs().voice;
    return all.find(v => v.voiceURI === want) ||
           all.find(v => (v.lang || "").toLowerCase().startsWith((navigator.language || "en").slice(0, 2).toLowerCase())) ||
           all[0] || null;
  }
  function say(text) {
    if (!ok || !text) return false;
    const v = pick();
    if (!v) return false;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(String(text).slice(0, 1200));
    u.voice = v; u.lang = v.lang; u.rate = chatPrefs().rate || 1;
    speechSynthesis.speak(u);
    return true;
  }
  function stop() { if (ok) speechSynthesis.cancel(); }
  return { ok, voices, pick, say, stop };
})();

function chatBubble(role, nodes) {
  return h("div", { class: "cm cm-" + role }, nodes);
}

function chatCell(v) {
  if (v === null || v === undefined) return "";
  if (typeof v === "boolean") return v ? "yes" : "no";
  if (Array.isArray(v)) return v.join(", ");
  if (typeof v === "string" && /^\d{4}-\d{2}-\d{2}T/.test(v)) return timeAgo(v);
  return String(v);
}

function chatTable(res) {
  if (!res.rows || !res.rows.length) return null;
  const cols = (res.columns || []).map(c => ({ label: c.replace(/_/g, " "), cell: r => chatCell(r[c]) }));
  return h("div", { class: "cm-table" }, table(cols, res.rows));
}

async function chatExport(q, note) {
  const res = await fetch("/api/v1/assistant/export", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Requested-With": "patch01-dashboard", ...authHeaders() },
    body: JSON.stringify({ tool: q.tool, args: q.args || {} }),
  });
  if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
  if (!res.ok) {
    const d = await res.json().catch(() => ({}));
    throw new ApiError(res.status, d.detail || res.statusText);
  }
  const blob = await res.blob();
  const name = (q.file || "export.csv").replace(/[^A-Za-z0-9._-]+/g, "-");
  const url = URL.createObjectURL(blob);
  const a = h("a", { href: url, download: name });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  if (note) { const n = res.headers.get("X-Rows") || "?"; note.textContent = "Downloaded " + name + " (" + n + (n === "1" ? " row)." : " rows)."); }
}

function chatCompose(q, draft) {
  const allowed = draft.allowed || { recipients: [], domains: [] };
  const listId = "cm-rcpt-" + Math.random().toString(36).slice(2, 8);
  const to = h("input", { type: "text", value: (draft.to || []).join(", "), list: listId, autocomplete: "off",
                          "aria-label": "To", placeholder: "name@" + (allowed.domains[0] || "your-domain") });
  const cc = h("input", { type: "text", list: listId, autocomplete: "off", "aria-label": "Cc", placeholder: "optional" });
  const subj = h("input", { type: "text", value: draft.subject || "", maxlength: "200", "aria-label": "Subject" });
  const body = h("textarea", { rows: "6", maxlength: "10000", "aria-label": "Message" });
  body.value = draft.body || "";
  const attach = h("input", { type: "checkbox", checked: true });
  const msg = h("p", { class: "cm-meta", role: "status" });
  const send = h("button", { type: "submit" }, "Send");
  const split = v => v.split(/[,;\s]+/).map(x => x.trim()).filter(Boolean);
  const card = h("form", { class: "cm-mail", on: { submit: async e => {
    e.preventDefault();
    const toList = split(to.value);
    if (!toList.length) { msg.textContent = "Add at least one recipient."; return; }
    send.disabled = true; send.textContent = "Sending";
    try {
      const r = await apiPost("/assistant/email", { tool: q.tool, args: q.args || {}, to: toList, cc: split(cc.value),
                                                    subject: subj.value.trim(), body: body.value, attach: attach.checked });
      card.replaceWith(h("p", { class: "cm-meta cm-sent" },
        "Sent to " + r.to.concat(r.cc || []).join(", ") + (r.attached ? ", with the CSV attached (" + r.rows + (r.rows === 1 ? " row)." : " rows).")
          : attach.checked ? " (no CSV: the answer had no rows)." : ".")));
      ChatVoice.ok && chatPrefs().speak && ChatVoice.say("The e-mail has been sent.");
    } catch (err) {
      if (err.status === 401) { closeChat(); return renderSignIn(err.message); }
      msg.textContent = err.message || ("Could not send (HTTP " + (err.status || "error") + ").");
      send.disabled = false; send.textContent = "Send";
    }
  } } },
    h("datalist", { id: listId }, (allowed.recipients || []).map(a => h("option", { value: a }))),
    h("label", null, h("span", null, "To"), to),
    h("label", null, h("span", null, "Cc"), cc),
    h("label", null, h("span", null, "Subject"), subj),
    h("label", null, h("span", null, "Message"), body),
    h("label", { class: "cm-check" }, attach, " Attach the full result as CSV"),
    h("p", { class: "cm-meta" }, "Allowed: the configured mail recipients"
      + (allowed.domains.length ? " and addresses at " + allowed.domains.join(", ") : "") + ". Nothing is sent until you press Send."),
    msg,
    h("div", { class: "cm-actions" }, send,
      h("button", { type: "button", class: "quiet", on: { click: () => card.remove() } }, "Cancel")));
  return card;
}

function chatAnswer(res) {
  const q = res.tool ? { tool: res.tool, args: res.args || {}, file: res.file } : null;
  const note = h("p", { class: "cm-meta", role: "status" });
  const meta = [];
  if (res.title) meta.push(res.title);
  if (res.how) meta.push(res.how === "model" ? "chosen by AI-01" : res.how === "previous answer" ? "from the previous answer" : "chosen by keywords");
  const body = h("div", null);
  const actions = q ? h("div", { class: "cm-actions" },
    h("button", { type: "button", class: "quiet", on: { click: async () => {
      note.textContent = "Exporting";
      try { await chatExport(q, note); } catch (err) { note.textContent = "Export failed: " + (err.message || err.status); }
    } } }, "Export CSV"),
    h("button", { type: "button", class: "quiet", on: { click: async () => {
      // The draft is made by the server, so the recipient policy is current
      try {
        const d = await apiPost("/admin/chat", { question: "email that", context: { tool: q.tool, args: q.args } });
        body.append(chatCompose(q, d.email || {}));
      } catch (err) { note.textContent = "Could not draft the e-mail: " + (err.message || err.status); }
    } } }, "E-mail"),
    ChatVoice.ok ? h("button", { type: "button", class: "quiet", title: "Read aloud",
      on: { click: () => { if (!ChatVoice.say(res.answer)) note.textContent = "No offline voice is installed on this computer."; } } },
      "\u{1F50A} Read") : null) : null;
  body.append(...[
    h("p", null, res.answer),
    chatTable(res),
    meta.length ? h("p", { class: "cm-meta" }, meta.join(" | ")) : null,
    res.tools ? h("details", { class: "cm-tools-d" }, h("summary", { class: "cm-meta" }, "What I can report on (" + res.tools.length + ")"),
      h("ul", { class: "cm-tools" }, res.tools.map(t => h("li", null, t.what)))) : null,
    actions, note].filter(Boolean));
  if (res.action === "email" && res.email && q) body.append(chatCompose(q, res.email));
  if (res.action === "export" && q) {
    note.textContent = "Exporting";
    chatExport(q, note).catch(err => { note.textContent = "Export failed: " + (err.message || err.status); });
  }
  return body;
}

async function chatAsk(question) {
  const hist = chatHistoryEl;
  hist.append(chatBubble("you", question));
  const thinking = chatBubble("bot", h("span", { class: "cm-wait" }, "Looking"));
  hist.append(thinking);
  hist.scrollTop = hist.scrollHeight;
  try {
    const res = await apiPost("/admin/chat", { question, context: chatLast });
    if (res.tool) chatLast = { tool: res.tool, args: res.args || {} };
    const answer = chatAnswer(res);
    thinking.replaceWith(chatBubble("bot", answer));
    if (chatPrefs().speak) ChatVoice.say(res.answer);
    chatInsight(question, res, answer);
  } catch (err) {
    if (err.status === 401) { closeChat(); return renderSignIn(err.message); }
    thinking.replaceWith(chatBubble("bot",
      h("p", { class: "explain-error" },
        err.status === 404 ? "The API is older than the assistant; rebuild it with phase3b-api.sh."
        : err.status === 429 ? "AI-01 is busy. Try again in a moment."
        : err.status === 422 ? (err.message || "That question could not be read.")
        : "Could not answer (HTTP " + (err.status || "error") + ").")));
  }
  hist.scrollTop = hist.scrollHeight;
}

/* AI-01 then answers in its own words, under the table: from the rows shown
 * (every number and server name checked against them, or it is not shown),
 * or, when no prepared query fits, a general answer that says so. */
function chatInsight(question, res, box) {
  if (res.action === "export" || res.action === "email") return;
  if (res.tool && !(res.rows || []).length) return;
  const ai = h("div", { class: "cm-ai", role: "status" },
    h("span", { class: "ai-badge ai-small" }, h("span", { class: "ai-dot", "aria-hidden": "true" }), "AI-01"),
    h("span", { class: "cm-wait" }, res.tool ? " reading the result…" : " thinking about your question…"));
  box.append(ai);
  const hist = chatHistoryEl;
  if (hist) hist.scrollTop = hist.scrollHeight;
  apiPost("/admin/chat/insight", { question, tool: res.tool || null, args: res.args || {} }).then(r => {
    if (!r || !r.text) {
      if (r && r.why && r.kind !== "off") ai.replaceChildren(h("p", { class: "cm-meta" }, r.why));
      else ai.remove();
      return;
    }
    ai.replaceChildren(
      h("div", { class: "cm-ai-h" }, h("span", { class: "ai-badge ai-small" }, h("span", { class: "ai-dot", "aria-hidden": "true" }), "AI-01"),
        h("span", { class: "muted small" }, r.kind === "general" ? " general answer, not from your PATCH-01 data: check it before acting"
                                                                  : " from the rows above; its figures and server names were checked against them")),
      h("p", { class: "cm-ai-text" }, r.text));
    if (chatPrefs().speak) ChatVoice.say(r.text);
    if (hist) hist.scrollTop = hist.scrollHeight;
  }).catch(err => {
    ai.replaceChildren(h("p", { class: "cm-meta" }, err.status === 429 ? "AI-01 is busy with another question: the table is the answer."
                                                   : "AI-01 did not answer: the table is the answer."));
  });
}

function closeChat() {
  if (chatPip) { chatPip.close(); }
  const p = chatPanel();
  const b = document.getElementById("chat-open");
  ChatVoice.stop();
  p.hidden = true;
  b.setAttribute("aria-expanded", "false");
  b.focus();
}

function chatPlace(panel) {
  const p = chatPrefs();
  panel.classList.toggle("cm-max", !!p.max);
  if (p.max) return;
  if (typeof p.left === "number" && typeof p.top === "number") {
    panel.style.left = Math.max(0, Math.min(window.innerWidth - 120, p.left)) + "px";
    panel.style.top = Math.max(0, Math.min(window.innerHeight - 60, p.top)) + "px";
    panel.style.right = "auto"; panel.style.bottom = "auto";
  }
  if (p.width) panel.style.width = Math.min(window.innerWidth - 16, p.width) + "px";
  if (p.height) panel.style.height = Math.min(window.innerHeight - 16, p.height) + "px";
}

function chatDrag(panel, handle) {
  handle.addEventListener("pointerdown", ev => {
    if (ev.target.closest("button, select, input, label") || panel.classList.contains("cm-max")
        || panel.classList.contains("cm-pip")) return;
    const r = panel.getBoundingClientRect(), dx = ev.clientX - r.left, dy = ev.clientY - r.top;
    const move = m => {
      panel.style.left = Math.max(0, Math.min(window.innerWidth - 120, m.clientX - dx)) + "px";
      panel.style.top = Math.max(0, Math.min(window.innerHeight - 60, m.clientY - dy)) + "px";
      panel.style.right = "auto"; panel.style.bottom = "auto";
    };
    const up = () => {
      document.removeEventListener("pointermove", move); document.removeEventListener("pointerup", up);
      const b = panel.getBoundingClientRect();
      chatSavePrefs({ left: Math.round(b.left), top: Math.round(b.top) });
    };
    document.addEventListener("pointermove", move); document.addEventListener("pointerup", up);
    ev.preventDefault();
  });
  // Remember a size the user dragged with the resize corner
  if (typeof ResizeObserver !== "undefined") {
    let t = null;
    new ResizeObserver(() => {
      clearTimeout(t);
      t = setTimeout(() => {
        if (panel.hidden || panel.classList.contains("cm-max") || panel.classList.contains("cm-pip")) return;
        const b = panel.getBoundingClientRect();
        if (b.width > 200) chatSavePrefs({ width: Math.round(b.width), height: Math.round(b.height) });
      }, 400);
    }).observe(panel);
  }
}

/* Pop out: an always-on-top window (Document Picture-in-Picture, Chrome and
 * Edge 116+) that floats over every other application. The same panel moves
 * into it, so nothing is duplicated and the session never leaves this tab. */
async function chatPopOut(panel, say) {
  if (chatPip) { chatPip.close(); return; }
  if (!("documentPictureInPicture" in window)) {
    say("This browser cannot pop the assistant out on top of other windows: Chrome or Edge 116 or later can. "
        + "You can still drag this window anywhere on the page.");
    return;
  }
  let w;
  try {
    const p = chatPrefs();
    w = await window.documentPictureInPicture.requestWindow({ width: p.pipW || 520, height: p.pipH || 680 });
  } catch (err) {
    say("The browser refused the pop-out window (" + (err.message || err.name) + ").");
    return;
  }
  chatPip = w;
  const d = w.document;
  for (const a of Array.from(document.documentElement.attributes)) d.documentElement.setAttribute(a.name, a.value);
  d.title = "Cyber-Secure assistant";
  document.querySelectorAll('link[rel="stylesheet"]').forEach(l => {
    const n = d.createElement("link"); n.rel = "stylesheet"; n.href = l.href; d.head.append(n);
  });
  d.body.className = "cm-pip-body";
  panel.classList.remove("cm-max");
  panel.classList.add("cm-pip");
  panel.hidden = false;
  d.body.append(panel);
  const pb = panel.querySelector(".cm-pop");
  if (pb) { pb.textContent = "\u29c9 Back to page"; pb.title = "Put the assistant back in the page"; }
  document.getElementById("chat-open").setAttribute("aria-expanded", "true");
  d.addEventListener("keydown", e => { if (e.key === "Escape") w.close(); });
  w.addEventListener("pagehide", () => {
    chatSavePrefs({ pipW: w.innerWidth, pipH: w.innerHeight });
    panel.classList.remove("cm-pip");
    if (pb) { pb.textContent = "\u29c9 Pop out"; pb.title = "Pop out: float on top of all windows"; }
    document.body.append(panel);
    chatPip = null;
    panel.removeAttribute("style");
    chatPlace(panel);
  });
  const inp = panel.querySelector(".cm-form input");
  if (inp) inp.focus();
}

function chatVoiceControls() {
  if (!ChatVoice.ok) return h("span", { class: "cm-meta" }, "This browser cannot read aloud.");
  const toggle = h("input", { type: "checkbox", checked: !!chatPrefs().speak });
  const sel = h("select", { "aria-label": "Voice" });
  const fill = () => {
    const vs = ChatVoice.voices();
    const cur = ChatVoice.pick();
    sel.replaceChildren(...(vs.length ? vs.map(v => h("option", { value: v.voiceURI, selected: cur && v.voiceURI === cur.voiceURI },
      v.name + " (" + v.lang + ")")) : [h("option", { value: "" }, "no offline voice installed")]));
    sel.disabled = !vs.length;
  };
  fill();
  speechSynthesis.addEventListener("voiceschanged", fill);
  toggle.addEventListener("change", () => { chatSavePrefs({ speak: toggle.checked }); if (!toggle.checked) ChatVoice.stop(); });
  sel.addEventListener("change", () => chatSavePrefs({ voice: sel.value }));
  return h("div", { class: "cm-voice" },
    h("label", { class: "cm-check" }, toggle, " Read answers aloud"), sel,
    h("button", { type: "button", class: "quiet", title: "Stop speaking", on: { click: () => ChatVoice.stop() } }, "Stop"));
}

function buildChat() {
  const panel = chatPanel();
  chatHistoryEl = h("div", { class: "cm-history", role: "log", "aria-live": "polite" },
    chatBubble("bot", [
      h("p", null, "Ask about servers, patches pending or installed, CVEs, Windows updates, WSUS, changes, "
                 + "hardening, VMs, ESXi, datastores, software or the asset inventory. I show the rows behind every answer."),
      h("p", { class: "cm-meta" }, "Add “export” or “email to …” to a question, or use the buttons under an answer. "
                 + "Read-only: patching and VMware actions go through approval."),
      h("div", { class: "cm-examples" }, CHAT_EXAMPLES.map(q =>
        h("button", { type: "button", on: { click: () => { input.value = q; form.requestSubmit(); } } }, q))),
    ]));
  const input = h("input", { type: "text", placeholder: "Ask a question", autocomplete: "off",
                             "aria-label": "Your question", maxlength: "400" });
  const form = h("form", { class: "cm-form", on: { submit: e => {
    e.preventDefault();
    const q = input.value.trim();
    if (!q) return;
    input.value = "";
    chatAsk(q);
  } } }, input, h("button", { type: "submit" }, "Ask"));

  const maxB = h("button", { type: "button", class: "quiet", title: "Larger / smaller", "aria-label": "Larger or smaller",
    on: { click: () => { chatSavePrefs({ max: !chatPrefs().max }); panel.removeAttribute("style"); chatPlace(panel); } } }, "⤢");
  const homeB = h("button", { type: "button", class: "quiet", title: "Back to the corner", "aria-label": "Back to the corner",
    on: { click: () => { chatSavePrefs({ left: null, top: null, width: null, height: null, max: false });
                         panel.removeAttribute("style"); chatPlace(panel); } } }, "↵");
  const say = text => { chatHistoryEl.append(chatBubble("bot", h("p", { class: "cm-meta" }, text)));
                        chatHistoryEl.scrollTop = chatHistoryEl.scrollHeight; };
  const popB = h("button", { type: "button", class: "quiet cm-pop", title: "Pop out: float on top of all windows",
    "aria-label": "Pop out on top of all windows", on: { click: () => chatPopOut(panel, say) } }, "\u29c9 Pop out");
  const head = h("div", { class: "cm-head" },
    h("strong", null, "Cyber-Secure assistant"),
    h("span", { class: "cm-head-btns" }, popB, homeB, maxB,
      h("button", { type: "button", class: "quiet", title: "Close", "aria-label": "Close", on: { click: closeChat } }, "×")));
  panel.replaceChildren(head, chatVoiceControls(), chatHistoryEl, form);
  panel.dataset.built = "1";
  chatDrag(panel, head);
  chatPlace(panel);
  return input;
}

/* The chat button floats: drag it anywhere on the screen; it stays where it was left.
 * A press that moves less than a few pixels is a click and opens the chat. */
const FAB_KEY = "patch01.chatfab";
function fabPlace(fab, pos) {
  if (!pos || typeof pos.r !== "number" || typeof pos.b !== "number") {
    fab.style.removeProperty("left"); fab.style.removeProperty("top");
    fab.style.removeProperty("right"); fab.style.removeProperty("bottom");
    return;
  }
  const w = fab.offsetWidth || 48, ht = fab.offsetHeight || 48;
  const r = Math.max(8, Math.min(window.innerWidth - w - 8, pos.r));
  const b = Math.max(8, Math.min(window.innerHeight - ht - 8, pos.b));
  fab.style.right = r + "px"; fab.style.bottom = b + "px";
  fab.style.left = "auto"; fab.style.top = "auto";
}
function fabSaved() {
  try { return JSON.parse(localStorage.getItem(FAB_KEY) || "null"); } catch (e) { return null; }
}
function fabDrag(fab) {
  let start = null, moved = false;
  fab.addEventListener("pointerdown", e => {
    if (e.button !== 0) return;
    const r = fab.getBoundingClientRect();
    start = { x: e.clientX, y: e.clientY, dx: e.clientX - r.left, dy: e.clientY - r.top };
    moved = false;
    fab.setPointerCapture(e.pointerId);
  });
  fab.addEventListener("pointermove", e => {
    if (!start) return;
    if (!moved && Math.hypot(e.clientX - start.x, e.clientY - start.y) < 6) return;
    moved = true;
    fab.classList.add("dragging");
    const w = fab.offsetWidth, ht = fab.offsetHeight;
    fabPlace(fab, { r: window.innerWidth - (e.clientX - start.dx) - w, b: window.innerHeight - (e.clientY - start.dy) - ht });
  });
  const end = e => {
    if (!start) return;
    start = null;
    // A drag that is not followed by a click must not swallow the next one
    if (moved) setTimeout(() => { moved = false; }, 0);
    fab.classList.remove("dragging");
    try { fab.releasePointerCapture(e.pointerId); } catch (x) { /* already released */ }
    if (moved) {
      const pos = { r: parseFloat(fab.style.right) || 0, b: parseFloat(fab.style.bottom) || 0 };
      try { localStorage.setItem(FAB_KEY, JSON.stringify(pos)); } catch (x) { /* private window */ }
    }
  };
  fab.addEventListener("pointerup", end);
  fab.addEventListener("pointercancel", end);
  // A drag is not a click
  fab.addEventListener("click", e => { if (moved) { e.stopImmediatePropagation(); e.preventDefault(); moved = false; } }, true);
  // Double-click puts it back in the corner
  fab.addEventListener("dblclick", () => {
    closeChat(); try { localStorage.removeItem(FAB_KEY); } catch (x) { /* private window */ } fabPlace(fab, null); });
  fabPlace(fab, fabSaved());
  window.addEventListener("resize", () => fabPlace(fab, fabSaved()));
}

/* With no saved place, the chat opens beside its button, wherever the button is */
function chatNearFab(panel) {
  const p = chatPrefs();
  if (p.max || (typeof p.left === "number" && typeof p.top === "number")) return;
  // Phones: the chat fills the width (style.css); no placing beside the button
  if (window.matchMedia("(max-width: 620px)").matches) { ["left", "top", "right", "bottom"].forEach(k => panel.style.removeProperty(k)); return; }
  const fab = document.getElementById("chat-open");
  if (!fab || !fabSaved()) { ["left", "top", "right", "bottom"].forEach(k => panel.style.removeProperty(k)); return; }
  const f = fab.getBoundingClientRect(), w = panel.offsetWidth, ht = panel.offsetHeight;
  const W = window.innerWidth, H = window.innerHeight, g = 10;
  const alignX = f.left + f.width / 2 < W / 2 ? f.left : f.right - w;
  const alignY = f.top + f.height / 2 < H / 2 ? f.top : f.bottom - ht;
  // Below, above, left of or right of the button: the first that fits without covering it
  const spots = [[alignX, f.bottom + g], [alignX, f.top - ht - g], [f.left - w - g, alignY], [f.right + g, alignY]];
  const fits = ([x, y]) => x >= 8 && y >= 8 && x + w <= W - 8 && y + ht <= H - 8;
  const [left, top] = spots.find(fits) || (f.left + f.width / 2 < W / 2 ? spots[3] : spots[2]);
  panel.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, left)) + "px";
  panel.style.top = Math.max(8, Math.min(window.innerHeight - ht - 8, top)) + "px";
  panel.style.right = "auto"; panel.style.bottom = "auto";
}

function openChat() {
  const panel = chatPanel();
  const input = panel.dataset.built ? panel.querySelector(".cm-form input") : buildChat();
  panel.hidden = false;
  chatNearFab(panel);
  document.getElementById("chat-open").setAttribute("aria-expanded", "true");
  input.focus();
}

document.addEventListener("keydown", e => {
  if (e.key === "Escape" && !chatPip && !chatPanel().hidden) closeChat();
});

document.addEventListener("DOMContentLoaded", () => {
  const fab = document.getElementById("chat-open");
  fabDrag(fab);
  fab.title = "Cyber-Secure assistant. Drag to move; double-click to put it back.";
  fab.addEventListener("click", () => {
    if (chatPip) { chatPip.focus(); return; }
    chatPanel().hidden ? openChat() : closeChat();
  });
  fillThemeSelect(document.getElementById("theme"));
  window.addEventListener("hashchange", () => { sideOpen(false); route(); });
  document.getElementById("side-toggle").addEventListener("click", () => sideOpen(!document.body.classList.contains("side-open")));
  document.getElementById("side-scrim").addEventListener("click", () => sideOpen(false));
  document.addEventListener("keydown", e => { if (e.key === "Escape" && document.body.classList.contains("side-open")) sideOpen(false); });
  document.getElementById("refresh").addEventListener("click", route);
  document.getElementById("signout").addEventListener("click", () => {
    apiPost("/auth/logout", {}).catch(() => {});
    clearAuth();
    location.hash = "#/";
    renderSignIn();
  });
  start();
});
