"""Inventory: assets, coverage, and software (inventory, lifecycle, removal).

Split out of main.py in r90; the code is unchanged."""

import json
import os
import psycopg
import re
import time
import uuid
from fastapi import Depends, File, HTTPException, Request, UploadFile
from pydantic import BaseModel, Field
from typing import Dict, List, Optional

from .core import (_asset_perms, _change_ok, app, audit, client_ip, db, jsonable, log, require_admin, require_viewer)


# ---------------------------------------------------------------------------
# Inventory: assets (agents, vCenter, WSUS) and software (agents)
# ---------------------------------------------------------------------------


ASSET_UPLOADS_PER_HOUR = 20


ASSET_ACTION_MAX = 2000


def _asset_view(a):
    """One asset as the pages show it: no raw source records beyond what
    the expanded row needs."""
    from . import inventory as inv
    vm, es, ws, ma = a.get("vm") or {}, a.get("esxi") or {}, a.get("wsus") or {}, a.get("manual") or {}
    return {"key": a["key"], "name": a["name"], "device": a["category"], "device_reason": a["category_reason"],
            "device_from": a.get("device_from"), "os": a["os"], "os_from": a["os_from"],
            "os_by": {inv.SOURCE_LABEL.get(k, k): v for k, v in (a.get("os_by") or {}).items()},
            "ips": a["ips"], "detected": [inv.SOURCE_LABEL.get(x, x) for x in a["sources"]], "sources": a["sources"],
            "location": a["location"], "location_kind": a["location_kind"], "last_detected": a["last_seen"],
            "status": a["status"], "gone": a.get("gone", False), "managed": a["managed"], "powered_off": a.get("powered_off", False),
            "host_id": (a.get("agent") or {}).get("host_id"), "agent_version": (a.get("agent") or {}).get("version"),
            "approved_by": a.get("approved_by"), "approved_at": a.get("approved_at"),
            "decom_by": a.get("decom_by"), "decom_at": a.get("decom_at"), "decom_reason": a.get("decom_reason"),
            "vm": {"name": vm.get("vm_name"), "vcenter": vm.get("vcenter_host"), "cluster": vm.get("cluster"),
                   "esxi": vm.get("esxi_host"), "power": vm.get("power"), "folder": vm.get("folder"),
                   "created": vm.get("created")} if vm else None,
            "esxi": {"vcenter": es.get("vcenter_host"), "cluster": es.get("cluster"), "model": es.get("model"),
                     "version": es.get("version")} if es else None,
            "wsus": {"server": ws.get("source"), "groups": ws.get("groups"), "last_reported": ws.get("last_reported")} if ws else None,
            "apex": {k: (a.get("apex") or {}).get(k) for k in ("console", "product", "os", "not_reported", "last_connected")}
            if a.get("apex") else None,
            "apex_product": a.get("apex_product"),
            "sheet": {k: ma.get(k) for k in ("location", "serial", "manufacturer", "model", "owner", "notes", "updated_by", "updated_at")}
            if ma else None,
            "hardware": a.get("hardware") or {}}


@app.get("/api/v1/inventory/assets")
def inventory_assets(request: Request, view: str = "active", user: str = Depends(require_viewer)):
    """Every machine from every source with its status. view=active (new and
    approved) or decommissioned."""
    from . import inventory as inv
    if view not in ("active", "decommissioned"):
        raise HTTPException(422, "view is active or decommissioned")
    with db() as conn:
        d = inv.load_assets(conn)
        perms = _asset_perms(conn, request.state.user)
        last_upload = None
        try:
            with conn.transaction():
                last_upload = conn.execute(
                    """SELECT file_name, uploaded_by, uploaded_at, applied_by, applied_at, result FROM asset_uploads
                        WHERE status = 'applied' ORDER BY applied_at DESC LIMIT 1""").fetchone()
        except psycopg.errors.UndefinedTable:
            pass
    allv = d["assets"]
    status = {s: sum(1 for a in allv if a["status"] == s) for s in inv.STATUSES}
    rows = [a for a in allv if (a["status"] == "decommissioned") == (view == "decommissioned")]
    from . import asset_coverage as cov
    gap_rows = cov.gaps(allv)
    gap_count = len({(g["key"], g["missing"]) for g in gap_rows})
    cf = cov.facts(allv, gap_rows)
    templates = (d.get("templates") or []) if view == "active" else []
    return jsonable({"view": view, "assets": [_asset_view(a) for a in rows], "summary": d["summary"], "status": status, "gaps": gap_count,
                     "templates": templates, "powered_off": sum(1 for a in rows if a.get("powered_off")),
                     "coverage": {k: cf[k] for k in ("windows", "windows_in_wsus", "windows_in_apex", "windows_in_wsus_pct", "windows_in_apex_pct")},
                     "sources": d["sources"], "findings": inv.findings(allv), "perms": perms,
                     "last_upload": last_upload, "is_admin": request.state.user.get("role") == "admin"})


@app.get("/api/v1/inventory/assets/{key}/history")
def inventory_asset_history(key: str, user: str = Depends(require_viewer)):
    from . import inventory as inv
    key = (key or "").lower()
    if not inv.KEY_RE.match(key):
        raise HTTPException(422, "Not an asset name.")
    with db() as conn:
        try:
            with conn.transaction():
                rows = conn.execute(
                    """SELECT action, from_status, to_status, actor, at, reason, detail FROM asset_events
                        WHERE asset_key = %s ORDER BY at DESC, id DESC LIMIT 100""", (key,)).fetchall()
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Asset approval is not installed yet: run phase3a-schema.sh.")
    return jsonable({"key": key, "events": rows})


class AssetActionIn(BaseModel):
    action: str = Field(..., pattern="^(approve|decom|revoke)$")
    keys: List[str] = Field(..., min_length=1, max_length=ASSET_ACTION_MAX)
    reason: Optional[str] = Field(default=None, max_length=500)


@app.post("/api/v1/inventory/assets/action")
def inventory_asset_action(body: AssetActionIn, request: Request, user: str = Depends(require_viewer)):
    """Approve, decommission or revoke the chosen assets. Each user needs the
    permission for that action (admins have all three)."""
    from . import inventory as inv
    perm = body.action
    reason = re.sub(r"\s+", " ", (body.reason or "")).strip() or None
    if perm == "decom" and (not reason or len(reason) < 3):
        raise HTTPException(422, "Give a reason for the decommission.")
    keys = sorted({(k or "").strip().lower() for k in body.keys})
    bad = {k: "not a valid asset name" for k in keys if not inv.KEY_RE.match(k)}
    keys = [k for k in keys if k not in bad]
    with db() as conn:
        if perm not in _asset_perms(conn, request.state.user):
            raise HTTPException(403, f"You do not have the {perm.replace('decom', 'decommission')} permission. "
                                     "Ask an admin (Admin > Access).")
        current = {a["key"]: a for a in inv.load_assets(conn)["assets"]}
        done, skipped = [], dict(bad)
        try:
            with conn.transaction():
                # Every key gets a row first, so two people acting on the same new machine queue on its lock
                present = [k for k in keys if k in current]
                if present:
                    conn.cursor().executemany(
                        """INSERT INTO asset_records (asset_key, name, status, updated_by) VALUES (%s, %s, 'new', %s)
                           ON CONFLICT (asset_key) DO NOTHING""", [(k, current[k]["name"][:255], user) for k in present])
                recs = {r["asset_key"]: dict(r) for r in conn.execute(
                    "SELECT asset_key, status, prev_status FROM asset_records WHERE asset_key = ANY(%s) ORDER BY asset_key FOR UPDATE",
                    (keys,)).fetchall()}
                for k in keys:
                    a = current.get(k)
                    if a is None:
                        skipped[k] = "not in the inventory"
                        continue
                    st = (recs.get(k) or {}).get("status") or "new"
                    snap = json.dumps(inv.snapshot(a), default=str)
                    if perm == "approve":
                        if st != "new":
                            skipped[k] = "already approved" if st == "approved" else "decommissioned: revoke it first"
                            continue
                        to = "approved"
                        conn.execute(
                            """INSERT INTO asset_records (asset_key, name, status, prev_status, approved_by, approved_at, snapshot,
                                                          updated_by, updated_at)
                               VALUES (%s, %s, 'approved', 'new', %s, now(), %s, %s, now())
                               ON CONFLICT (asset_key) DO UPDATE SET name = EXCLUDED.name, status = 'approved', prev_status = 'new',
                                   approved_by = EXCLUDED.approved_by, approved_at = now(), snapshot = EXCLUDED.snapshot,
                                   updated_by = EXCLUDED.updated_by, updated_at = now()""",
                            (k, a["name"][:255], user, snap, user))
                    elif perm == "decom":
                        if st == "decommissioned":
                            skipped[k] = "already decommissioned"
                            continue
                        to = "decommissioned"
                        conn.execute(
                            """INSERT INTO asset_records (asset_key, name, status, prev_status, decom_by, decom_at, decom_reason,
                                                          snapshot, updated_by, updated_at)
                               VALUES (%s, %s, 'decommissioned', %s, %s, now(), %s, %s, %s, now())
                               ON CONFLICT (asset_key) DO UPDATE SET name = EXCLUDED.name, status = 'decommissioned',
                                   prev_status = EXCLUDED.prev_status, decom_by = EXCLUDED.decom_by, decom_at = now(),
                                   decom_reason = EXCLUDED.decom_reason, snapshot = EXCLUDED.snapshot,
                                   updated_by = EXCLUDED.updated_by, updated_at = now()""",
                            (k, a["name"][:255], st, user, reason, snap, user))
                    else:
                        if st == "new":
                            skipped[k] = "nothing to revoke"
                            continue
                        if st == "approved":
                            to = "new"
                            conn.execute(
                                """UPDATE asset_records SET status = 'new', prev_status = NULL, approved_by = NULL, approved_at = NULL,
                                          updated_by = %s, updated_at = now() WHERE asset_key = %s""", (user, k))
                        else:
                            to = (recs[k].get("prev_status") or "new")
                            conn.execute(
                                """UPDATE asset_records SET status = %s, prev_status = NULL, decom_by = NULL, decom_at = NULL,
                                          decom_reason = NULL, updated_by = %s, updated_at = now() WHERE asset_key = %s""",
                                (to, user, k))
                    conn.execute(
                        """INSERT INTO asset_events (asset_key, action, from_status, to_status, actor, reason, detail)
                           VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                        (k, {"approve": "approved", "decom": "decommissioned", "revoke": "revoked"}[perm], st, to, user, reason,
                         json.dumps({"name": a["name"], "ips": a["ips"][:5], "location": a["location"]})))
                    done.append(k)
                if done:
                    audit(conn, actor=user, actor_type="user", action="asset_" + perm, object_type="asset",
                          object_id=done[0] if len(done) == 1 else None,
                          detail={"count": len(done), "assets": done[:50], "reason": reason},
                          source_ip=client_ip(request))
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Asset approval is not installed yet: run phase3a-schema.sh.")
    return {"done": len(done), "skipped": len(skipped),
            "skipped_why": [f"{k}: {v}" for k, v in list(skipped.items())[:20]]}


class AssetTypeIn(BaseModel):
    keys: List[str] = Field(..., min_length=1, max_length=ASSET_ACTION_MAX)
    device: str = Field(..., pattern="^(server|client|esxi|appliance|network|firewall|unknown|auto)$")
    reason: Optional[str] = Field(default=None, max_length=500)


@app.post("/api/v1/inventory/assets/type")
def inventory_asset_type(body: AssetTypeIn, request: Request, user: str = Depends(require_viewer)):
    """A person sets the device type of the chosen machines (it wins over the
    rules and AI-01), or hands them back to automatic ("auto"). Needs the
    Approve permission."""
    from . import inventory as inv
    keys = sorted({(k or "").strip().lower() for k in body.keys})
    bad = [k for k in keys if not inv.KEY_RE.match(k)]
    keys = [k for k in keys if k not in bad]
    reason = re.sub(r"\s+", " ", (body.reason or "")).strip() or None
    with db() as conn:
        if "approve" not in _asset_perms(conn, request.state.user):
            raise HTTPException(403, "Setting a device type needs the Approve permission. Ask an admin (Admin > Access).")
        current = {a["key"]: a for a in inv.load_assets(conn)["assets"]}
        keys = [k for k in keys if k in current]
        # Taking a server or PC out of the server/PC types needs a reason (it is kept in the history)
        leaving = body.device not in ("auto",) + inv.EXPECTED_PATCHED and any(current[k]["category"] in inv.EXPECTED_PATCHED for k in keys)
        if leaving and (not reason or len(reason) < 3):
            raise HTTPException(422, "Give a reason: this takes a server or laptop/desktop out of those types.")
        try:
            with conn.transaction():
                if body.device == "auto":
                    conn.execute("DELETE FROM asset_type_overrides WHERE asset_key = ANY(%s)", (keys,))
                else:
                    conn.cursor().executemany(
                        """INSERT INTO asset_type_overrides (asset_key, device, set_by, reason) VALUES (%s, %s, %s, %s)
                           ON CONFLICT (asset_key) DO UPDATE SET device = EXCLUDED.device, set_by = EXCLUDED.set_by,
                               set_at = now(), reason = EXCLUDED.reason""", [(k, body.device, user, reason) for k in keys])
                conn.cursor().executemany(
                    """INSERT INTO asset_events (asset_key, action, actor, reason, detail) VALUES (%s, 'type_set', %s, %s, %s)""",
                    [(k, user, reason, json.dumps({"from": current[k]["category"], "to": body.device})) for k in keys])
                if keys:
                    audit(conn, actor=user, actor_type="user", action="asset_type_set", object_type="asset",
                          object_id=keys[0] if len(keys) == 1 else None,
                          detail={"count": len(keys), "device": body.device, "assets": keys[:50], "reason": reason},
                          source_ip=client_ip(request))
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Device types are not installed yet: run phase3a-schema.sh.")
    return {"done": len(keys), "skipped": len(body.keys) - len(keys)}


@app.post("/api/v1/inventory/check")
def inventory_check(request: Request, user: str = Depends(require_viewer)):
    """AI-01 places the OS names the rules cannot, then the findings are
    worked out again. Open to anyone who may approve, decommission or revoke."""
    from . import inventory as inv, asset_import as ai
    with db() as conn:
        if not _asset_perms(conn, request.state.user):
            raise HTTPException(403, "This needs an asset permission. Ask an admin (Admin > Access).")
        n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'asset_ai_check'
                              AND occurred_at > now() - interval '10 minutes'""", (user,)).fetchone()["n"]
        if n >= 5:
            raise HTTPException(429, "At most 5 checks in 10 minutes: try again shortly.")
        # Recorded before AI-01 is asked, so requests sent together count against the limit
        audit(conn, actor=user, actor_type="user", action="asset_ai_check", object_type="asset", detail={}, source_ip=client_ip(request))
        conn.commit()
        assets = inv.load_assets(conn)["assets"]
        conn.commit()
        try:
            r = ai.classify_unknown(conn, assets)
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Asset approval is not installed yet: run phase3a-schema.sh.")
        assets = inv.load_assets(conn)["assets"]
    return jsonable({**r, "findings": inv.findings(assets)})


@app.get("/api/v1/inventory/coverage")
def inventory_coverage(request: Request, user: str = Depends(require_viewer)):
    """Machines missing in WSUS or Apex, with the evidence and what to do,
    and the latest AI-01 summary."""
    from . import inventory as inv, asset_coverage as cov
    with db() as conn:
        assets = inv.load_assets(conn)["assets"]
        rows = cov.gaps(assets)
        f = cov.facts(assets, rows)
        latest = cov.latest(conn)
        perms = _asset_perms(conn, request.state.user)
        n_apex = sum(1 for a in assets if a.get("apex"))
    return jsonable({"rows": rows, "facts": f, "summary": latest, "perms": perms, "apex_agents": n_apex,
                     "reasons": cov.REASON_TEXT})


@app.post("/api/v1/inventory/coverage/analyse")
def inventory_coverage_analyse(request: Request, user: str = Depends(require_viewer)):
    """A fresh AI-01 summary of the gaps (anyone with an asset permission)."""
    from . import inventory as inv, asset_coverage as cov
    with db() as conn:
        if not _asset_perms(conn, request.state.user):
            raise HTTPException(403, "This needs an asset permission. Ask an admin (Admin > Access).")
        n = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = 'asset_coverage_analysed'
                              AND occurred_at > now() - interval '10 minutes'""", (user,)).fetchone()["n"]
        if n >= 5:
            raise HTTPException(429, "At most 5 analyses in 10 minutes: try again shortly.")
        # Recorded before AI-01 is asked, so requests sent together count against the limit
        audit(conn, actor=user, actor_type="user", action="asset_coverage_analysed", object_type="asset",
              detail={}, source_ip=client_ip(request))
        conn.commit()
        assets = inv.load_assets(conn)["assets"]
        rows = cov.gaps(assets)
        text, source, model, f = cov.summarise(conn, assets, rows, user)
    return jsonable({"text": text, "source": source, "model": model, "facts": f})


# ---- Uploaded asset sheets (admins) --------------------------------------------------

def _upload_view(conn, up, rows_shown=300):
    """An upload with its preview, worked out from the stored cells and mapping."""
    from . import inventory as inv, asset_import as ai
    headers = up["headers"] if isinstance(up["headers"], list) else json.loads(up["headers"] or "[]")
    mapping = up["mapping"] if isinstance(up["mapping"], dict) else json.loads(up["mapping"] or "{}")
    cells = up["rows"] if isinstance(up["rows"], list) else json.loads(up["rows"] or "[]")
    mapping = ai.valid_mapping({k: int(v) for k, v in mapping.items() if v is not None}, len(headers)) or {}
    out = {k: up[k] for k in ("id", "file_name", "uploaded_by", "uploaded_at", "sheet", "header_row", "mapped_by", "status",
                               "applied_by", "applied_at", "result")}
    out.update({"headers": headers, "mapping": mapping, "fields": [{"key": f, "label": ai.FIELD_LABEL[f]} for f in ai.FIELDS],
                "samples": cells[:3]})
    if up["status"] != "preview":
        return out
    checked = ai.check_rows(cells, mapping) if "hostname" in mapping else []
    assets = inv.load_assets(conn)["assets"]
    manual_keys = {r["asset_key"] for r in conn.execute("SELECT asset_key FROM manual_assets").fetchall()}
    counts, rows = ai.preview(checked, assets, manual_keys)
    order = {"skip": 0, "new": 1, "update": 2, "known": 3}
    rows.sort(key=lambda r: (order[r["action"]], -len(r["fixes"]) - len(r["compare"]), r["row"]))
    in_sheet = {c["key"] for c in checked if c.get("key")}          # every row's machine, passed or not
    remove = sorted(manual_keys - in_sheet)
    out.update({"counts": counts, "rows": rows[:rows_shown], "need_hostname": "hostname" not in mapping,
                "would_remove": len(remove), "would_remove_names": remove[:20],
                "replace_allowed": counts["valid"] >= max(1, counts["rows"] // 2)})
    return out


def _upload_row(conn, uid):
    try:
        uid = str(uuid.UUID(str(uid)))
    except ValueError:
        raise HTTPException(404, "No such upload.")
    try:
        with conn.transaction():
            r = conn.execute("SELECT * FROM asset_uploads WHERE id = %s", (uid,)).fetchone()
    except psycopg.errors.UndefinedTable:
        raise HTTPException(503, "Asset upload is not installed yet: run phase3a-schema.sh.")
    if not r:
        raise HTTPException(404, "No such upload.")
    return dict(r)


@app.post("/api/v1/inventory/uploads")
def inventory_upload(request: Request, file: UploadFile = File(...), admin: str = Depends(require_admin)):
    """An Excel or CSV sheet of assets: read here, columns mapped (AI-01,
    checked against the cells), every row checked, shown as a preview."""
    from . import asset_import as ai
    data = file.file.read(ai.MAX_BYTES + 1)     # a plain def: FastAPI runs it in a thread, AI-01 may take a minute
    fn = os.path.basename((file.filename or "").replace("\\", "/"))[:120] or "upload"
    with db() as conn:
        try:
            with conn.transaction():
                n = conn.execute("""SELECT count(*) AS n FROM asset_uploads WHERE uploaded_by = %s
                                      AND uploaded_at > now() - interval '1 hour'""", (admin,)).fetchone()["n"]
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Asset upload is not installed yet: run phase3a-schema.sh.")
        if n >= ASSET_UPLOADS_PER_HOUR:
            raise HTTPException(429, f"At most {ASSET_UPLOADS_PER_HOUR} uploads an hour: try again later.")
        try:
            sheet, rows = ai.read_file(fn, data)
        except ai.SheetError as e:
            raise HTTPException(422, str(e))
        hr = ai.header_row(rows)
        if len(rows) - hr - 1 > ai.MAX_ROWS:              # never cut silently: a cut-off row could be removed by "replace"
            raise HTTPException(422, f"The sheet has more than {ai.MAX_ROWS} asset rows. Split it into smaller files.")
        headers, cells = rows[hr], rows[hr + 1:]
        conn.commit()                                     # nothing held open while AI-01 reads the headers
        mapping, mapped_by, notes = ai.choose_mapping(headers, cells)
        with conn.transaction():
            r = conn.execute(
                """INSERT INTO asset_uploads (file_name, sha256, uploaded_by, sheet, header_row, headers, mapping, mapped_by, rows)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING *""",
                (fn, ai.sha256(data), admin, sheet, hr + 1, json.dumps(headers), json.dumps(mapping), mapped_by,
                 json.dumps(cells))).fetchone()
            audit(conn, actor=admin, actor_type="user", action="asset_sheet_uploaded", object_type="asset_upload",
                  object_id=str(r["id"]), detail={"file": fn, "rows": len(cells), "mapped_by": mapped_by},
                  source_ip=client_ip(request))
        v = _upload_view(conn, dict(r))
        v["notes"] = notes
        return jsonable(v)


@app.get("/api/v1/inventory/uploads")
def inventory_uploads(admin: str = Depends(require_admin)):
    with db() as conn:
        try:
            with conn.transaction():
                rows = conn.execute(
                    """SELECT id, file_name, uploaded_by, uploaded_at, status, mapped_by, applied_by, applied_at, result
                         FROM asset_uploads ORDER BY uploaded_at DESC LIMIT 20""").fetchall()
        except psycopg.errors.UndefinedTable:
            raise HTTPException(503, "Asset upload is not installed yet: run phase3a-schema.sh.")
    return jsonable({"uploads": rows})


@app.get("/api/v1/inventory/uploads/{uid}")
def inventory_upload_get(uid: str, admin: str = Depends(require_admin)):
    with db() as conn:
        return jsonable(_upload_view(conn, _upload_row(conn, uid)))


class UploadMappingIn(BaseModel):
    mapping: Dict[str, Optional[int]]


@app.patch("/api/v1/inventory/uploads/{uid}")
def inventory_upload_map(uid: str, body: UploadMappingIn, request: Request, admin: str = Depends(require_admin)):
    """The admin corrects which column holds what."""
    from . import asset_import as ai
    with db() as conn:
        up = _upload_row(conn, uid)
        if up["status"] != "preview":
            raise HTTPException(409, "This upload was already applied or discarded.")
        headers = up["headers"] if isinstance(up["headers"], list) else json.loads(up["headers"] or "[]")
        m = ai.valid_mapping({k: v for k, v in body.mapping.items() if v is not None}, len(headers))
        if m is None:
            raise HTTPException(422, "Each column can be used once, and only columns of the sheet.")
        with conn.transaction():
            conn.execute("UPDATE asset_uploads SET mapping = %s, mapped_by = 'admin' WHERE id = %s AND status = 'preview'",
                         (json.dumps(m), up["id"]))
        up["mapping"], up["mapped_by"] = m, "admin"
        return jsonable(_upload_view(conn, up))


class UploadApplyIn(BaseModel):
    replace: bool = False


@app.post("/api/v1/inventory/uploads/{uid}/apply")
def inventory_upload_apply(uid: str, body: UploadApplyIn, request: Request, admin: str = Depends(require_admin)):
    """Save the valid rows as Manual assets. replace: also remove Manual
    assets from earlier sheets that are not in this one."""
    from . import asset_import as ai
    with db() as conn:
        up = _upload_row(conn, uid)
        if up["status"] != "preview":
            raise HTTPException(409, "This upload was already applied or discarded.")
        v = _upload_view(conn, up, rows_shown=ai.MAX_ROWS)
        if v.get("need_hostname"):
            raise HTTPException(422, "Choose the column that holds the host name first.")
        good = [r for r in v["rows"] if r["ok"]]
        if not good:
            raise HTTPException(422, "No row passed the checks: nothing to save.")
        with conn.transaction():
            st = conn.execute("SELECT status FROM asset_uploads WHERE id = %s FOR UPDATE", (up["id"],)).fetchone()
            if st["status"] != "preview":
                raise HTTPException(409, "This upload was already applied or discarded.")
            if not conn.execute("SELECT 1 FROM schema_version WHERE version = 32").fetchone():
                raise HTTPException(503, "The asset sheet needs schema 032: run phase3a-schema.sh, then apply again.")
            conn.cursor().executemany(
                """INSERT INTO manual_assets (asset_key, name, ips, os, device, location, serial, manufacturer, model, owner, notes,
                                              upload_id, updated_by, updated_at)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now())
                   ON CONFLICT (asset_key) DO UPDATE SET name = EXCLUDED.name, ips = EXCLUDED.ips, os = EXCLUDED.os,
                       device = EXCLUDED.device, location = EXCLUDED.location, serial = EXCLUDED.serial,
                       manufacturer = EXCLUDED.manufacturer, model = EXCLUDED.model, owner = EXCLUDED.owner,
                       notes = EXCLUDED.notes, upload_id = EXCLUDED.upload_id, updated_by = EXCLUDED.updated_by, updated_at = now()""",
                [(r["key"], r["name"][:255], r["ips"][:20], r["os"], r["device"], r["location"], r["serial"], r.get("manufacturer"),
                  r.get("model"), r["owner"], r["notes"], up["id"], admin) for r in good])
            removed = 0
            if body.replace:
                if not v["replace_allowed"]:
                    raise HTTPException(422, "Fewer than half the rows passed the checks, so earlier Manual assets are not removed. "
                                             "Fix the sheet or the columns, or apply without removing.")
                keep = sorted({c["key"] for c in ai.check_rows(
                    up["rows"] if isinstance(up["rows"], list) else json.loads(up["rows"] or "[]"), v["mapping"]) if c.get("key")})
                removed = len(conn.execute("DELETE FROM manual_assets WHERE asset_key <> ALL(%s) RETURNING asset_key",
                                           (keep,)).fetchall())
            conn.cursor().executemany(
                """INSERT INTO asset_events (asset_key, action, actor, reason, detail) VALUES (%s, 'uploaded', %s, %s, %s)""",
                [(r["key"], admin, "from " + up["file_name"], json.dumps({"row": r["row"], "action": r["action"]}))
                 for r in good if r["action"] == "new"])
            result = {**v["counts"], "saved": len(good), "removed": removed}
            conn.execute("""UPDATE asset_uploads SET status = 'applied', applied_by = %s, applied_at = now(), result = %s,
                                   rows = '[]'::jsonb WHERE id = %s""", (admin, json.dumps(result), up["id"]))
            audit(conn, actor=admin, actor_type="user", action="asset_sheet_applied", object_type="asset_upload",
                  object_id=str(up["id"]), detail={"file": up["file_name"], **result}, source_ip=client_ip(request))
        # Machines now in both WSUS and the sheet are approved at once (also hourly by the worker)
        try:
            from . import inventory as inv, asset_coverage as cov
            result["auto_approved"] = cov.auto_approve(conn, inv.load_assets(conn)["assets"])
        except Exception as e:  # noqa: BLE001 - the sheet is saved; the worker approves within the hour
            log.warning("auto-approval after upload: %s", type(e).__name__)
            result["auto_approved"] = 0
    return result


@app.post("/api/v1/inventory/uploads/{uid}/discard")
def inventory_upload_discard(uid: str, request: Request, admin: str = Depends(require_admin)):
    with db() as conn:
        up = _upload_row(conn, uid)
        with conn.transaction():
            r = conn.execute("""UPDATE asset_uploads SET status = 'discarded', rows = '[]'::jsonb
                                 WHERE id = %s AND status = 'preview' RETURNING id""", (up["id"],)).fetchone()
            if not r:
                raise HTTPException(409, "This upload was already applied or discarded.")
            audit(conn, actor=admin, actor_type="user", action="asset_sheet_discarded", object_type="asset_upload",
                  object_id=str(up["id"]), detail={"file": up["file_name"]}, source_ip=client_ip(request))
    return {"ok": True}


@app.get("/api/v1/inventory/software")
def inventory_software(request: Request, platform: str = "windows", category: str = "all", q: str = "", host: str = "",
                       user: str = Depends(require_viewer)):
    """Installed software by program, then version, then the machines that have it. The grouping
    is cached for 5 minutes (it takes seconds on a large estate); whether each program may be
    removed is worked out on every call (the removable tools list can change at any time)."""
    from . import sw_policy
    from . import auth
    # The cache follows the servers' own reports: a new inventory from any server makes a new key
    with db() as conn:
        stamp = conn.execute(
            """SELECT max(last_inventory) AS h,
                      (SELECT max(reported_at) FROM windows_software) AS w FROM hosts""").fetchone()
    key = (platform, category, (q or "").strip()[:100].lower(), (host or "").strip()[:80].lower(),
           str(stamp["h"]), str(stamp["w"]))
    hit = _SW_CACHE.get(key)
    if hit and time.monotonic() - hit[0] < SW_CACHE_SECONDS:
        out = hit[1]
    else:
        out = _inventory_software(platform, category, q, host)
        if len(_SW_CACHE) >= 64:
            _SW_CACHE.pop(next(iter(_SW_CACHE)))
        _SW_CACHE[key] = (time.monotonic(), out)
    mods = set(auth.user_modules(getattr(request.state, "user", None) or {})) if request is not None else {"lifecycle"}
    return _software_enrich(out, platform, with_packages="lifecycle" in mods)


def _software_enrich(out, platform, with_packages=True):
    """Live facts on top of the cached grouping: the Deployment package each Windows program can be
    upgraded or installed from (and which versions are older than it), each version's end of
    support / end of life, and whether removing it is possible (kept for the API; the page does
    not show it until someone chooses to remove)."""
    from . import deploy, sw_lifecycle, sw_policy
    out = dict(out)
    with db() as conn:
        rules = sw_lifecycle.rules(conn, platform)
        pats, pkgs = [], []
        if platform == "windows":
            try:
                with conn.transaction():
                    pats = [t["pattern"] for t in sw_policy.tools(conn)]
            except psycopg.errors.UndefinedTable:
                pats = []
            if with_packages:            # Deployment's packages: for users of the software lifecycle module
                try:
                    with conn.transaction():
                        pkgs = deploy.deployable(conn)
                except psycopg.errors.UndefinedTable:
                    pkgs = []

    vmaps = {}
    if pkgs:
        with db() as conn:
            try:
                with conn.transaction():
                    vmaps = deploy.verdicts_for(conn, pkgs)
            except psycopg.errors.UndefinedTable:
                vmaps = {}

    def package_for(name, publisher=None):
        return deploy.package_for(pkgs, name, publisher, vmaps)

    progs, upgradable, eol_n = [], 0, 0
    for pr in out["programs"]:
        pr = dict(pr)
        pkg = package_for(pr["name"], pr.get("publisher")) if pkgs else None
        older = 0
        vers = []
        for v in pr["versions"]:
            v = dict(v)
            v["support"] = sw_lifecycle.state(sw_lifecycle.rule_for(rules, pr["name"], v["version"]))
            if pkg:
                c = deploy.compare_versions(v["version"], pkg["version"])
                v["vs_package"] = None if c is None else {-1: "older", 0: "same", 1: "newer"}[c]
                if c == -1:
                    older += v["machines"]
            vers.append(v)
        pr["versions"] = vers
        pr["package"] = ({"id": str(pkg["id"]), "name": pkg["name"], "version": pkg["version"], "file_name": pkg["file_name"]}
                         if pkg else None)
        pr["upgrade_servers"] = older
        upgradable += 1 if older else 0
        worst = [v["support"]["state"] for v in vers if v.get("support")]
        pr["support"] = next((s for s in ("eol", "eos", "eol_soon", "supported") if s in worst), None)
        eol_n += 1 if pr["support"] in ("eol", "eos") else 0
        if platform == "windows":
            st, why = sw_policy.verdict(pats, pr["name"], pr["publisher"])
            pr.update(state=st, state_reason=why,
                      silent_hosts=sum(1 for v in vers for hh in v["hosts"] if hh.get("how") and hh.get("agent_ok")))
        progs.append(pr)
    out["programs"] = progs
    out["upgradable"] = upgradable
    out["past_support"] = eol_n
    out["packages"] = len(pkgs)
    out["lifecycle_rules"] = len(rules)
    return out


SW_CACHE_SECONDS = 300


_SW_CACHE = {}


SW_ROW_CAP = 30000


def _ver3(v):
    m = re.match(r"^\s*(\d{1,4})\.(\d{1,4})\.(\d{1,4})", str(v or ""))
    return tuple(int(x) for x in m.groups()) if m else None


def _inventory_software(platform, category, q, host=""):
    """Installed software across machines with an agent: each program with its versions, and under
    each version the machines (name, patch group, address, installed on, 64/32-bit). Windows:
    Programs and Features. Linux: installed packages."""
    from . import inventory as inv
    if platform not in ("windows", "linux"):
        raise HTTPException(422, "platform must be windows or linux")
    if category != "all" and category not in inv.CATEGORIES:
        raise HTTPException(422, "unknown category")
    q = (q or "").strip()[:100]
    host = (host or "").strip()[:80].lower()
    with db() as conn:
        hosts = conn.execute(
            """SELECT id::text AS id, hostname, host_group, host(agent_ip) AS ip, os_id, os_version, os_edition, agent_version
                 FROM hosts WHERE status <> 'decommissioned' AND (%s = 'windows') = (os_id = 'windows')""", (platform,)).fetchall()
        cats = {h["id"]: inv.classify(inv._agent_os(h))[0] for h in hosts}
        ids = [i for i, c in cats.items() if category == "all" or c == category]
        by_id = {h["id"]: h for h in hosts}
        if host:
            ids = [i for i in ids if host in (by_id[i]["hostname"] or "").lower()]
        empty = {"programs": [], "machines": 0, "platform": platform, "category": category, "truncated": False,
                 "multi_version": 0, "counts": {c: sum(1 for x in cats.values() if x == c) for c in inv.CATEGORIES}}
        if not ids:
            return empty
        if platform == "windows":
            rows = conn.execute(
                """SELECT name, publisher, version, arch, installed_on, uninstall_how AS how, host_id::text AS host_id
                     FROM windows_software WHERE host_id::text = ANY(%s)
                      AND (%s = '' OR strpos(lower(name), lower(%s)) > 0 OR strpos(lower(coalesce(publisher, '')), lower(%s)) > 0)
                    ORDER BY lower(name), version DESC LIMIT %s""", (ids, q, q, q, SW_ROW_CAP + 1)).fetchall()
        else:
            rows = conn.execute(
                """SELECT name, NULL::text AS publisher, version || '-' || release AS version, arch, NULL::date AS installed_on,
                          NULL::text AS how, host_id::text AS host_id
                     FROM host_packages WHERE host_id::text = ANY(%s) AND (%s = '' OR strpos(lower(name), lower(%s)) > 0)
                    ORDER BY lower(name), 3 DESC LIMIT %s""", (ids, q, q, SW_ROW_CAP + 1)).fetchall()
    truncated = len(rows) > SW_ROW_CAP
    progs = {}
    for r in rows[:SW_ROW_CAP]:
        # One program per name: the same program reported with and without a publisher is still one program
        pr = progs.setdefault(r["name"], {"name": r["name"], "publisher": r["publisher"], "_hosts": set(), "_v": {}})
        pr["publisher"] = pr["publisher"] or r["publisher"]
        v = pr["_v"].setdefault(r["version"] or "", {"version": r["version"] or "", "hosts": [], "_all": set()})
        h = by_id.get(r["host_id"]) or {}
        pr["_hosts"].add(r["host_id"])
        v["_all"].add(r["host_id"])                  # every server counts, even past the 500 listed
        if len(v["hosts"]) < 500:
            v["hosts"].append({"id": r["host_id"], "name": h.get("hostname") or r["host_id"], "group": h.get("host_group"),
                               "ip": h.get("ip"), "installed_on": r["installed_on"].isoformat() if hasattr(r["installed_on"], "isoformat")
                               else r["installed_on"], "arch": r["arch"], "how": r["how"], "agent": h.get("agent_version"),
                               # removal needs Windows agent 1.9.3 or later (it removes by the exact key)
                               "agent_ok": platform == "windows" and (_ver3(h.get("agent_version")) or (0, 0, 0)) >= (1, 9, 3)})
    out = []
    for pr in progs.values():
        vers = []
        for v in pr["_v"].values():
            v["hosts"].sort(key=lambda x: (x["name"] or "").lower())
            allh = v.pop("_all")
            vers.append(dict(v, machines=len(allh), listed=len(v["hosts"])))
        out.append({"name": pr["name"], "publisher": pr["publisher"], "machines": len(pr["_hosts"]), "versions": vers})
    return {"programs": out, "machines": len(ids), "platform": platform, "category": category, "truncated": truncated,
            "multi_version": sum(1 for x in out if len(x["versions"]) > 1),
            "counts": {c: sum(1 for x in cats.values() if x == c) for c in inv.CATEGORIES}}


# ---- Software: the removable tools list, and removing a listed tool (admins) ----

class SwLifecycleIn(BaseModel):
    platform: str = Field("windows", pattern="^(windows|linux)$")
    name_prefix: str = Field(..., min_length=2, max_length=80)
    version_prefix: str = Field("", max_length=40)
    eos: Optional[str] = Field(None, max_length=10)
    eol: Optional[str] = Field(None, max_length=10)
    note: Optional[str] = Field(None, max_length=300)


@app.get("/api/v1/software/lifecycle")
def sw_lifecycle_list(user: str = Depends(require_viewer)):
    from . import sw_lifecycle
    with db() as conn:
        from . import sw_eol_feed
        return jsonable({"rules": sw_lifecycle.rules(conn), "soon_days": sw_lifecycle.SOON_DAYS,
                         "feed": sw_eol_feed.status(conn)})


def _lc_id(v):
    try:
        return str(uuid.UUID(str(v)))
    except (ValueError, TypeError):
        raise HTTPException(404, "No such rule.")


class LifecycleFeedIn(BaseModel):
    enabled: Optional[bool] = None
    read_now: bool = False


@app.post("/api/v1/software/lifecycle/feed")
def sw_lifecycle_feed(body: LifecycleFeedIn, request: Request, admin: str = Depends(require_admin)):
    """Admin › Software rules: switch the daily read of endoflife.date on or off, or read now."""
    from . import sw_eol_feed
    with db() as conn:
        if sw_eol_feed.status(conn) is None:
            raise HTTPException(409, "Schema 058 is not applied yet: run phase3a-schema.sh.")
        if body.enabled is not None:
            conn.execute("UPDATE lifecycle_feed SET enabled = %s WHERE id = 1", (body.enabled,))
        if body.read_now:
            conn.execute("UPDATE lifecycle_feed SET requested_at = now(), requested_by = %s, enabled = true WHERE id = 1", (admin,))
        audit(conn, actor=admin, actor_type="user", action="software_lifecycle_feed", object_type="software_lifecycle",
              detail={"enabled": body.enabled, "read_now": body.read_now}, source_ip=client_ip(request))
        conn.commit()
        return jsonable({"feed": sw_eol_feed.status(conn)})


@app.post("/api/v1/software/lifecycle")
def sw_lifecycle_add(body: SwLifecycleIn, request: Request, admin: str = Depends(require_admin)):
    from . import sw_lifecycle
    try:
        r = sw_lifecycle.clean(body.model_dump())
    except sw_lifecycle.Invalid as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        try:
            with conn.transaction():
                row = conn.execute(
                    """INSERT INTO software_lifecycle (platform, name_prefix, version_prefix, eos, eol, note, created_by)
                       VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING id::text AS id""",
                    (r["platform"], r["name_prefix"], r["version_prefix"], r["eos"], r["eol"], r["note"], admin)).fetchone()
                from . import cve_impact
                cve_impact.inventory_changed(conn)          # r116: the CVE assessments use these dates
                audit(conn, actor=admin, actor_type="user", action="software_lifecycle_added", object_type="software_lifecycle",
                      object_id=row["id"], detail={k: str(v) for k, v in r.items() if v}, source_ip=client_ip(request))
        except psycopg.errors.UniqueViolation:
            raise HTTPException(409, "A rule for this product and version line already exists: edit it.")
        return jsonable({"rules": sw_lifecycle.rules(conn)})


@app.put("/api/v1/software/lifecycle/{rid}")
def sw_lifecycle_edit(rid: str, body: SwLifecycleIn, request: Request, admin: str = Depends(require_admin)):
    from . import sw_lifecycle
    try:
        r = sw_lifecycle.clean(body.model_dump())
    except sw_lifecycle.Invalid as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        try:
            with conn.transaction():
                row = conn.execute(
                    """UPDATE software_lifecycle SET platform=%s, name_prefix=%s, version_prefix=%s, eos=%s, eol=%s, note=%s,
                              source='manual', updated_by=%s, updated_at=now() WHERE id=%s RETURNING id::text AS id""",
                    (r["platform"], r["name_prefix"], r["version_prefix"], r["eos"], r["eol"], r["note"], admin, _lc_id(rid))).fetchone()
                if not row:
                    raise HTTPException(404, "No such rule.")
                from . import cve_impact
                cve_impact.inventory_changed(conn)          # r116: the CVE assessments use these dates
                audit(conn, actor=admin, actor_type="user", action="software_lifecycle_changed", object_type="software_lifecycle",
                      object_id=rid, detail={k: str(v) for k, v in r.items() if v}, source_ip=client_ip(request))
        except psycopg.errors.UniqueViolation:
            raise HTTPException(409, "Another rule covers this product and version line.")
        return jsonable({"rules": sw_lifecycle.rules(conn)})


@app.delete("/api/v1/software/lifecycle/{rid}")
def sw_lifecycle_delete(rid: str, request: Request, admin: str = Depends(require_admin)):
    from . import sw_lifecycle
    with db() as conn:
        with conn.transaction():
            row = conn.execute("DELETE FROM software_lifecycle WHERE id=%s RETURNING name_prefix", (_lc_id(rid),)).fetchone()
            if not row:
                raise HTTPException(404, "No such rule.")
            from . import cve_impact
            cve_impact.inventory_changed(conn)          # r116: the CVE assessments use these dates
            audit(conn, actor=admin, actor_type="user", action="software_lifecycle_removed", object_type="software_lifecycle",
                  object_id=rid, detail={"name": row["name_prefix"]}, source_ip=client_ip(request))
        return jsonable({"rules": sw_lifecycle.rules(conn)})


class SwPatternIn(BaseModel):
    pattern: str = Field(..., min_length=1, max_length=80)


class SwRemoveIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=300)
    version: str = Field("", max_length=120)
    arch: str = Field(..., pattern="^(64-bit|32-bit)$")
    host_ids: List[str] = Field(..., min_length=1, max_length=500)
    reason: str = Field(..., min_length=3, max_length=2000)
    reboot: str = Field("never", pattern="^(never|if_required)$")
    run_after: Optional[str] = Field(None, max_length=40)


def _sw_tools_view(conn):
    from . import sw_policy
    return {"tools": sw_policy.tools(conn), "critical_examples": [
        "SQL Server and every other database", "antivirus and EDR agents", "backup agents", "VMware Tools and drivers",
        ".NET, Visual C++ and other runtimes", "server roles (Exchange, IIS, AD...)", "monitoring and management agents",
        "the PATCH-01 agent"]}


@app.get("/api/v1/software/removable")
def sw_removable(user: str = Depends(require_viewer)):
    with db() as conn:
        return jsonable(_sw_tools_view(conn))


@app.post("/api/v1/software/removable")
def sw_removable_add(body: SwPatternIn, request: Request, admin: str = Depends(require_admin)):
    from . import sw_policy
    try:
        pat = sw_policy.clean_pattern(body.pattern)
    except sw_policy.Refused as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        with conn.transaction():
            if conn.execute("SELECT 1 FROM software_removable WHERE lower(pattern) = lower(%s)", (pat,)).fetchone():
                raise HTTPException(409, f"“{pat}” is already on the list.")
            conn.execute("INSERT INTO software_removable (pattern, created_by) VALUES (%s, %s)", (pat, admin))
            now_removable = sw_policy.matches(conn, pat)
            audit(conn, actor=admin, actor_type="user", action="software_removable_added", object_type="software_removable",
                  object_id=pat, detail={"pattern": pat, "programs": now_removable[:10]}, source_ip=client_ip(request))
        return jsonable(dict(_sw_tools_view(conn), added=pat, now_removable=now_removable))


@app.post("/api/v1/software/removable/delete")
def sw_removable_delete(body: SwPatternIn, request: Request, admin: str = Depends(require_admin)):
    with db() as conn:
        with conn.transaction():
            r = conn.execute("DELETE FROM software_removable WHERE lower(pattern) = lower(%s) RETURNING pattern",
                             (body.pattern.strip(),)).fetchone()
            if not r:
                raise HTTPException(404, "Not on the list.")
            # Removals of programs it allowed that no server has started yet are withdrawn (the jobs say why)
            from . import sw_policy
            left = [t["pattern"] for t in sw_policy.tools(conn)]
            for q in conn.execute("""SELECT id, params->>'name' AS name FROM agent_commands
                                      WHERE verb = 'software_action' AND claimed_at IS NULL AND expires_at > now()
                                        AND params->>'source' = 'installed'""").fetchall():
                if sw_policy.allowed_by([r["pattern"]], q["name"]) and not sw_policy.allowed_by(left, q["name"]):
                    conn.execute("""UPDATE agent_commands SET expires_at = now(),
                                           params = params || '{"withdrawn": "tools_list"}'::jsonb WHERE id = %s AND claimed_at IS NULL""",
                                 (q["id"],))
            audit(conn, actor=admin, actor_type="user", action="software_removable_removed", object_type="software_removable",
                  object_id=r["pattern"], detail={"pattern": r["pattern"]}, source_ip=client_ip(request))
        return jsonable(_sw_tools_view(conn))


@app.post("/api/v1/software/remove")
def sw_remove(body: SwRemoveIn, request: Request, admin: str = Depends(require_admin)):
    """Remove one listed tool (one exact name, version and 64/32-bit entry) from the chosen Windows
    servers: a job in Patching › Jobs that runs at once or at the chosen time (admins, no approval)."""
    from . import changes as ch
    _change_ok(request, "software")
    params = {"source": "installed", "program": {"name": body.name.strip(), "version": body.version.strip(), "arch": body.arch},
              "reboot": body.reboot, "check_services": True}
    with db() as conn:
        try:
            targets, params, ra, rb, mp = ch.validate(conn, "software", [{"host_id": h} for h in body.host_ids], params,
                                                      body.run_after, None, 5)
            with conn.transaction():
                title = f"Remove {params['software']}"[:200]
                cid, number = ch.create(conn, "software", title, body.reason, targets, params, ra, rb, mp, admin, "admin")
                audit(conn, actor=admin, actor_type="user", action="change_created", object_type="change", object_id=cid,
                      detail={"ref": ch.ref(number), "kind": "software", "removal": params["software"], "arch": body.arch,
                              "targets": len(targets), "reason": body.reason[:300]}, source_ip=client_ip(request))
        except ch.Invalid as e:
            raise HTTPException(422, str(e))
    _SW_CACHE.clear()
    return {"id": cid, "ref": ch.ref(number), "number": number, "servers": len(targets)}
