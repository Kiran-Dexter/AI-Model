"""Admin › Repositories (r117): what Pulp holds and what servers see, Sync and Publish, and the
daily sync times. The API only records what an admin asks; the worker talks to Pulp."""
from typing import List

from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field

from .core import app, audit, client_ip, db, jsonable, require_admin


@app.get("/api/v1/admin/repos")
def repos_list(admin: str = Depends(require_admin)):
    from . import pulp_repos
    with db() as conn:
        out = pulp_repos.listing(conn)
    if out is None:
        raise HTTPException(409, "Schema 059 is not applied yet: run phase3a-schema.sh.")
    return jsonable(out)


class RepoActionIn(BaseModel):
    names: List[str] = Field(..., min_length=1, max_length=200)
    action: str = Field(..., max_length=20)


@app.post("/api/v1/admin/repos/action")
def repos_action(body: RepoActionIn, request: Request, admin: str = Depends(require_admin)):
    from . import pulp_repos
    with db() as conn:
        try:
            names = pulp_repos.request(conn, body.names, body.action, admin)
        except ValueError as e:
            raise HTTPException(400, str(e))
        audit(conn, actor=admin, actor_type="user", action="repos_" + body.action, object_type="repository",
              detail={"repositories": names}, source_ip=client_ip(request))
        conn.commit()
        out = pulp_repos.listing(conn)
    out["queued"] = names
    return jsonable(out)


class RepoSettingsIn(BaseModel):
    enabled: bool = True
    times: List[str] = Field(default_factory=lambda: ["02:00"], max_length=6)
    publish_after: bool = True
    import_after: bool = True


@app.put("/api/v1/admin/repos/settings")
def repos_settings(body: RepoSettingsIn, request: Request, admin: str = Depends(require_admin)):
    from . import pulp_repos
    times = sorted({t.strip() for t in body.times if t.strip()})
    bad = [t for t in times if not pulp_repos.TIME_RE.match(t)]
    if bad:
        raise HTTPException(400, "Write times as HH:MM (24-hour), for example 02:00.")
    if body.enabled and not times:
        raise HTTPException(400, "Give at least one time, or switch the daily sync off.")
    with db() as conn:
        conn.execute("""UPDATE repo_settings SET enabled = %s, times = %s, publish_after = %s, import_after = %s,
                               updated_by = %s, updated_at = now() WHERE id = 1""",
                     (body.enabled, times, body.publish_after, body.import_after, admin))
        audit(conn, actor=admin, actor_type="user", action="repos_settings", object_type="repository",
              detail={"enabled": body.enabled, "times": times, "publish_after": body.publish_after,
                      "import_after": body.import_after}, source_ip=client_ip(request))
        conn.commit()
        return jsonable(pulp_repos.listing(conn))


@app.post("/api/v1/admin/repos/refresh")
def repos_refresh(admin: str = Depends(require_admin)):
    from . import pulp_repos
    with db() as conn:
        conn.execute("UPDATE repo_settings SET refresh_requested_at = now() WHERE id = 1")
        conn.commit()
        return jsonable(pulp_repos.listing(conn))
