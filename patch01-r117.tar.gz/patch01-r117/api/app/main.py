"""PATCH-01 API: the FastAPI application.

The app and what every area shares are in core.py; each area's endpoints are in its
own module (api_*.py), imported here in the order they register their routes."""

from .core import app  # noqa: F401  (uvicorn serves app.main:app)

from . import (  # noqa: F401,E402  (each module registers its routes, in this order)
    api_agent,
    api_admin,
    api_vmware,
    api_cve,
    api_assistant,
    api_dashboard,
    api_deploy,
    api_users,
    api_changes,
    api_hardening,
    api_reports,
    api_windows,
    api_certificate,
    api_inventory,
    api_antivirus,
    api_nessus,
    api_cbedr,
    api_repos,
)
