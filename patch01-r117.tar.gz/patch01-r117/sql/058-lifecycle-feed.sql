-- ---------------------------------------------------------------------------
-- PATCH-01 : schema 058 - End of support / end of life from endoflife.date (r114)
--
-- lifecycle_feed   one row: whether the daily read of endoflife.date is on, when it
--                  last ran, what it found, and an admin's "read now".
-- Rules it fills go into software_lifecycle with source 'endoflife'; an admin's own
-- rules (source 'manual') are never changed by it. Re-run safe.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS lifecycle_feed (
    id            INT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    enabled       BOOLEAN NOT NULL DEFAULT true,
    requested_at  TIMESTAMPTZ,
    requested_by  TEXT,
    last_run_at   TIMESTAMPTZ,
    last_ok_at    TIMESTAMPTZ,
    last_error    TEXT,
    last_counts   JSONB NOT NULL DEFAULT '{}'::jsonb
);
INSERT INTO lifecycle_feed (id) VALUES (1) ON CONFLICT DO NOTHING;

INSERT INTO schema_version (version, description)
VALUES (58, 'End of support / end of life read daily from endoflife.date')
ON CONFLICT (version) DO NOTHING;
