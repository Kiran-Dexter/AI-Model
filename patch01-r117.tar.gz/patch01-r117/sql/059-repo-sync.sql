-- ---------------------------------------------------------------------------
-- PATCH-01 : schema 059 - repositories synced and published from the console (r117)
--
-- repo_settings  one row: the daily sync times (SGT), whether it publishes and imports
--                the advisories after, the last scheduled slot run, Pulp's reachability
-- repo_state     one row per repository in Pulp (kept by the worker): what it holds,
--                what the servers see, the action an admin asked for, and how it went
-- Only the worker talks to Pulp. Re-run safe.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS repo_settings (
    id                   INT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    enabled              BOOLEAN NOT NULL DEFAULT true,
    times                TEXT[] NOT NULL DEFAULT ARRAY['02:00'],
    publish_after        BOOLEAN NOT NULL DEFAULT true,
    import_after         BOOLEAN NOT NULL DEFAULT true,
    last_slot            TEXT,
    last_run_at          TIMESTAMPTZ,
    last_run_summary     JSONB NOT NULL DEFAULT '{}'::jsonb,
    refresh_requested_at TIMESTAMPTZ,
    pulp_ok_at           TIMESTAMPTZ,
    pulp_error           TEXT,
    updated_by           TEXT,
    updated_at           TIMESTAMPTZ
);
INSERT INTO repo_settings (id) VALUES (1) ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS repo_state (
    name               TEXT PRIMARY KEY CHECK (name ~ '^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$'),
    type               TEXT NOT NULL CHECK (type IN ('rpm', 'deb')),
    version            INT,
    published_version  INT,
    base_path          TEXT,
    packages           INT,
    advisories         INT,
    has_remote         BOOLEAN NOT NULL DEFAULT true,
    seen_at            TIMESTAMPTZ,
    state              TEXT NOT NULL DEFAULT 'idle' CHECK (state IN ('idle', 'running', 'done', 'failed')),
    step               TEXT,
    progress           JSONB,
    error              TEXT,
    requested          TEXT CHECK (requested IS NULL OR requested IN ('sync', 'publish', 'sync_publish')),
    requested_by       TEXT,
    requested_at       TIMESTAMPTZ,
    started_at         TIMESTAMPTZ,
    finished_at        TIMESTAMPTZ,
    last_sync_at       TIMESTAMPTZ,
    last_sync_ok       BOOLEAN,
    last_sync_version  INT,
    last_publish_at    TIMESTAMPTZ
);

INSERT INTO schema_version (version, description)
VALUES (59, 'Repositories synced and published from the console')
ON CONFLICT (version) DO NOTHING;
