/* PATCH-01 hardening pages: CIS-aligned OpenSCAP results.
 * Uses the console's shared helpers from app.js (h, api, render, table ...).
 */
"use strict";

const HLEVELS = [["l1", "CIS Level 1 Server"], ["l2", "CIS Level 2 Server"], ["custom", "Custom (from a document)"]];
const HRESULT = {
  pass: ["Pass", "hr-pass"], fail: ["Fail", "hr-fail"], error: ["Error", "hr-error"],
  notapplicable: ["Not applicable", "hr-na"], notchecked: ["Not checked", "hr-na"],
  unknown: ["Unknown", "hr-na"], informational: ["Info", "hr-na"], fixed: ["Fixed", "hr-pass"],
};

function hLevel(params) {
  const l = params.get("level") || localStorage.getItem("patch01.hardening.level") || "l1";
  return ["l1", "l2"].includes(l) || /^custom:[0-9a-f-]{36}$/.test(l) ? l : "l1";
}

let CUSTOMS = [];            // active custom profiles, for the picker
async function loadCustoms() {
  try { CUSTOMS = ((await api("/hardening/custom")).profiles || []).filter(p => p.status === "active"); } catch (e) { CUSTOMS = []; }
  return CUSTOMS;
}
function levelName(level) {
  if (level === "l1") return "CIS Level 1 Server";
  if (level === "l2") return "CIS Level 2 Server";
  const p = CUSTOMS.find(x => "custom:" + x.id === level);
  return p ? p.name : "Custom profile";
}

function levelPicker(level, onChange) {
  const sel = h("select", { "aria-label": "Benchmark profile", class: "hd-level" },
    h("option", { value: "l1", selected: level === "l1" }, "CIS Level 1 Server"),
    h("option", { value: "l2", selected: level === "l2" }, "CIS Level 2 Server"),
    CUSTOMS.length ? h("optgroup", { label: "Custom profiles" },
      CUSTOMS.map(p => h("option", { value: "custom:" + p.id, selected: level === "custom:" + p.id }, p.name))) : null,
    h("option", { value: "__manage" }, can("operator") ? "\uFF0B New or manage custom profiles\u2026" : "Custom profiles\u2026"));
  sel.addEventListener("change", () => {
    if (sel.value === "__manage") { location.hash = "#/hardening/custom"; return; }
    localStorage.setItem("patch01.hardening.level", sel.value); onChange(sel.value);
  });
  return sel;
}

function scoreBadge(score) {
  if (score === null || score === undefined) return h("span", { class: "muted" }, "not scanned");
  const n = Number(score);
  const cls = n >= 85 ? "hd-good" : n >= 70 ? "hd-fair" : "hd-poor";
  return h("span", { class: "hd-score " + cls }, n.toFixed(n % 1 ? 1 : 0) + "%");
}

function scoreBar(score) {
  if (score === null || score === undefined) return h("span", { class: "muted" }, "\u2013");
  const n = Math.max(0, Math.min(100, Number(score)));
  const bar = h("span", { class: "hd-bar " + (n >= 85 ? "hd-good" : n >= 70 ? "hd-fair" : "hd-poor") },
    h("span", { class: "hd-bar-fill" }));
  bar.firstChild.style.width = n + "%";
  return h("span", { class: "hd-bar-cell" }, bar, scoreBadge(n));
}

function sevChip(sev) {
  const s = (sev || "unknown").toLowerCase();
  return h("span", { class: "hd-sev hd-sev-" + s }, s === "unknown" ? "\u2013" : s[0].toUpperCase() + s.slice(1));
}

function resultChip(r) {
  const [label, cls] = HRESULT[r] || [r, "hr-na"];
  return h("span", { class: "hd-res " + cls }, label);
}

const CHECKIN_MIN = 5;   // the agent's timer: install-agent.sh --interval

// Where an in-flight scan is, in words, with a bar while rules are checked
function scanProgress(row) {
  const st = row.last_state, stage = row.stage;
  if (st === "queued") {
    // Past two check-ins, the agent is not calling in: say so plainly
    const mins = row.last_requested ? (Date.now() - new Date(row.last_requested).getTime()) / 60000 : 0;
    if (mins > 2 * CHECKIN_MIN + 2) {
      return h("span", { class: "hd-prog hd-failed" },
        "Not picked up after " + Math.round(mins) + " min: the agent is not checking in. "
        + "On the server: systemctl status patch-agent.timer");
    }
    return h("span", { class: "hd-prog" }, h("span", { class: "hd-pulse" }),
      h("span", null, "Waiting for the agent's next check-in ",
        h("span", { class: "muted" }, "(every " + CHECKIN_MIN + " min; queued " + timeAgo(row.last_requested) + ")")));
  }
  const labels = { picked_up: "Starting", downloading: "Downloading benchmark",
                   uploading: "Uploading results", processing: "Processing results" };
  if (stage === "scanning") {
    const done = Number(row.progress_done || 0), total = Number(row.progress_total || 0);
    const pct = total ? Math.min(100, Math.round(100 * done / total)) : null;
    const bar = h("span", { class: "hd-pbar" }, h("span", { class: "hd-pbar-fill" }));
    bar.firstChild.style.width = (pct === null ? 100 : pct) + "%";
    if (pct === null) bar.classList.add("hd-pbar-indet");
    return h("span", { class: "hd-prog" }, bar,
      h("span", null, "Scanning " + (total ? done + " / " + total + " rules (" + pct + "%)" : done + " rules")));
  }
  if (stage && labels[stage]) {
    const old = stage === "picked_up" && row.agent_version && versionBelow(row.agent_version, "1.5.0");
    return h("span", { class: "hd-prog" }, h("span", { class: "hd-pulse" }),
      h("span", null, old ? "Scanning " : labels[stage] + "\u2026 ",
        old ? h("span", { class: "muted" }, "(agent " + row.agent_version + " does not report progress; 1.5.0 does)") : null));
  }
  return h("span", { class: "hd-prog" }, h("span", { class: "hd-pulse" }), "Scanning\u2026");
}

// Numeric version comparison: "1.10.0" is newer than "1.5.0"
function versionBelow(v, than) {
  const a = String(v || "0").split(".").map(Number), b = String(than).split(".").map(Number);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const x = a[i] || 0, y = b[i] || 0;
    if (x !== y) return x < y;
  }
  return false;
}

function inFlight(row) { return row.last_state === "queued" || row.last_state === "running"; }

function scanState(row) {
  if (inFlight(row)) return scanProgress(row);
  if (row.last_state === "failed") return h("span", { class: "hd-failed", title: row.last_error || "" },
    "last scan failed: " + (row.last_error || "unknown").slice(0, 80));
  return row.finished_at ? timeAgo(row.finished_at) : h("span", { class: "muted" }, "never");
}

function trendSvg(points) {
  if (!points || points.length < 2) return null;
  const W = 260, H = 54, xs = points.map((_, i) => 6 + i * (W - 12) / (points.length - 1));
  // Scaled to the data's own range, padded, so a real improvement is visible
  const vals = points.map(p => Number(p.score));
  const lo = Math.max(0, Math.min(...vals) - 5), hi = Math.min(100, Math.max(...vals) + 5);
  const span = Math.max(1, hi - lo);
  const ys = vals.map(v => H - 6 - ((v - lo) / span) * (H - 12));
  const NS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("viewBox", "0 0 " + W + " " + H); svg.setAttribute("class", "hd-trend");
  svg.setAttribute("role", "img"); svg.setAttribute("aria-label", "Fleet score over the last 90 days");
  const path = document.createElementNS(NS, "path");
  path.setAttribute("d", xs.map((x, i) => (i ? "L" : "M") + x.toFixed(1) + "," + ys[i].toFixed(1)).join(""));
  svg.append(path);
  const dot = document.createElementNS(NS, "circle");
  dot.setAttribute("cx", xs[xs.length - 1]); dot.setAttribute("cy", ys[ys.length - 1]); dot.setAttribute("r", 3);
  svg.append(dot);
  return svg;
}

async function queueScans(level, hostIds, btn, onDone) {
  btn.disabled = true;
  const was = btn.textContent;
  btn.textContent = "Queuing\u2026";
  try {
    const r = await apiPost("/hardening/scans", { level, host_ids: hostIds || null });
    btn.textContent = r.queued.length + " queued" + (r.skipped.length ? ", " + r.skipped.length + " skipped" : "");
    if (r.skipped.length) btn.title = r.skipped.map(x => x.hostname + ": " + x.reason).join("\n");
    setTimeout(() => { btn.textContent = was; btn.disabled = false; onDone && onDone(); }, 2500);
  } catch (err) {
    btn.textContent = was; btn.disabled = false;
    alert(err.message);
  }
}

// ---- fleet page ----------------------------------------------------------
async function renderHardening(params) {
  setNav("hardening");
  await loadCustoms();
  let level = hLevel(params);
  if (level.startsWith("custom:") && !CUSTOMS.find(p => "custom:" + p.id === level)) level = "l1";
  const enc = encodeURIComponent(level);
  const [sum, list] = await Promise.all([api("/hardening/summary?level=" + enc), api("/hardening/hosts?level=" + enc)]);
  const reload = l => { location.hash = "#/hardening?level=" + encodeURIComponent(l); };
  const scanAll = can("operator")
    ? h("button", { type: "button", class: "btn", on: { click: e => queueScans(level, null, e.target, () => renderHardening(params)) } },
        "Scan all servers") : null;

  const content = sum.content || [];
  const noContent = !content.length;
  const head = h("div", { class: "page-head" },
    h("h1", { "data-cmd": "patchctl harden --report" }, "Hardening"),
    h("div", { class: "head-actions" }, levelPicker(level, reload),
      h("button", { type: "button", class: "btn btn-quiet", on: { click: () => {
        const p = document.querySelector(".rep-panel"); if (p) { p.hidden = !p.hidden; if (!p.hidden) p.scrollIntoView({ block: "nearest" }); }
      } } }, "Export report"), scanAll));

  if (noContent) {
    render(head, h("div", { class: "empty" },
      h("p", null, "No benchmark content has been imported yet."),
      h("p", { class: "muted" }, "On PATCH-01: ./scripts/phase8-hardening.sh --fetch <version>, with the release number from "
        + "the ComplianceAsCode releases page. Then update agents to 1.4.0 and install the OpenSCAP scanner on each server.")));
    return;
  }

  const levelsOf = new Map(content.map(c => [c.product, c.levels || []]));
  const cards = h("div", { class: "hd-cards" },
    h("div", { class: "hd-card hd-card-main" },
      h("div", { class: "hd-card-l" }, "Fleet score"),
      h("div", { class: "hd-card-n" }, sum.fleet_score === null ? "\u2013" : scoreBadge(sum.fleet_score)),
      h("div", { class: "muted small" }, "Average of the latest scan per server: passed rules out of passed plus failed."),
      trendSvg(sum.trend)),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Servers scanned"),
      h("div", { class: "hd-card-n" }, String(sum.scanned), h("span", { class: "muted" }, " / " + sum.servers)),
      sum.no_content ? h("div", { class: "muted small" }, sum.no_content + " have no benchmark content for their OS") : null),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "By score"),
      h("div", { class: "hd-bands" },
        h("span", { class: "hd-good" }, sum.bands.good, h("small", null, "85%+")),
        h("span", { class: "hd-fair" }, sum.bands.fair, h("small", null, "70\u201384%")),
        h("span", { class: "hd-poor" }, sum.bands.poor, h("small", null, "under 70%")))),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Failed checks"),
      h("div", { class: "hd-card-n" }, sum.failed_rules_total),
      h("div", { class: "muted small" }, "across all servers' latest scans")));

  const contentLine = h("p", { class: "muted small" }, "Benchmark: SCAP Security Guide " + content[0].content_version + ". "
    + content.map(c => c.product + " (" + ((c.levels || []).map(x => x.toUpperCase()).join(", ") || "no CIS server profile") + ")").join(", ") + ".");

  const top = sum.top_failing || [];
  const topTable = top.length ? table([
    { label: "Rule", cell: r => h("a", { href: "#/hardening/rule/" + encodeURIComponent(r.rule_id) + "?level=" + level }, r.title || r.rule_id) },
    { label: "CIS", nowrap: true, cell: r => r.cis_ref || h("span", { class: "muted" }, "\u2013") },
    { label: "Severity", nowrap: true, cell: r => sevChip(r.severity) },
    { label: "Servers failing", num: true, cell: r => h("strong", null, r.servers) },
    { label: "", nowrap: true, cell: r => r.risky ? h("span", { class: "hd-risky", title: "Fixing this can cut off access or break services. Test on one server first." }, "risky to fix") : "" },
  ], top) : h("div", { class: "empty" }, h("p", null, "Nothing failing in the latest scans."));

  const hosts = list.hosts || [];
  const hostTable = table([
    { label: "Server", nowrap: true, cell: r => h("a", { href: "#/hardening/host/" + r.id + "?level=" + level }, r.hostname) },
    { label: "Benchmark", nowrap: true, cell: r => {
        if (!r.product) return h("span", { class: "muted" }, "no content for " + r.os_id + " " + r.os_version);
        const lv = levelsOf.get(r.product);
        if (!lv) return h("span", { class: "muted" }, r.product + ": not imported");
        if (level.startsWith("custom:")) return r.product;
        return lv.includes(level) ? r.product : h("span", { class: "muted" }, r.product + ": no " + level.toUpperCase() + " profile");
      } },
    { label: "Score", nowrap: true, cell: r => scoreBar(r.score) },
    { label: "Failed", num: true, cell: r => r.failed === null || r.failed === undefined ? "" :
        h("span", null, r.failed, Number(r.high_failed) ? h("span", { class: "hd-high" }, " (" + r.high_failed + " high)") : null) },
    { label: "Last scan", nowrap: true, cell: r => scanState(r) },
    can("operator") ? { label: "", nowrap: true, cell: r => h("button", { type: "button", class: "btn-link",
        on: { click: e => { e.stopPropagation(); queueScans(level, [r.id], e.target, () => renderHardening(params)); } } }, "Scan") } : null,
  ].filter(Boolean), hosts);

  const exportPanel = reportPanel(level, hosts);
  const archive = h("div");
  loadArchive(archive);
  render(head,
    exportPanel,
    h("p", { class: "muted" }, "How each server's configuration compares with the CIS benchmark: SSH, logins, "
      + "auditing, file permissions, services and kernel settings. Scans are read-only; they change nothing."),
    cards, contentLine,
    h("h2", null, "Most widely failing rules"),
    h("p", { class: "muted small" }, "Fixing one of these lifts every server listed against it."),
    topTable,
    h("h2", null, "Servers (" + hosts.length + ")"),
    hostTable,
    h("h2", null, "Reports"),
    archive);

  // While scans are in flight, redraw every 5 s so progress moves on its own
  if (hosts.some(inFlight)) {
    setPageTimer(async () => {
      if (!location.hash.startsWith("#/hardening") || location.hash.includes("/host/")
          || location.hash.includes("/rule/")) return clearPageTimer();
      const y = window.scrollY;
      await renderHardening(params);
      window.scrollTo(0, y);
    }, 5000);
  } else {
    clearPageTimer();
  }
}

// ---- one server ------------------------------------------------------------
async function renderHardeningHost(hostId, params) {
  setNav("hardening");
  const level = hLevel(params);
  await loadCustoms();
  const d = await api("/hardening/hosts/" + hostId + "?level=" + encodeURIComponent(level));
  const s = d.scan;
  let filter = params.get("show") || "fail";
  const body = h("div");
  const counts = { fail: 0, pass: 0, na: 0, error: 0 };
  (d.results || []).forEach(r => {
    if (r.result === "fail") counts.fail++; else if (r.result === "pass") counts.pass++;
    else if (r.result === "error") counts.error++; else counts.na++;
  });
  const tabs = [["fail", "Failed", counts.fail], ["error", "Errors", counts.error], ["pass", "Passed", counts.pass],
                ["na", "Not applicable", counts.na], ["all", "All", (d.results || []).length]];
  const tabBtns = tabs.map(([k, label, n]) => h("button", { type: "button", "data-k": k,
    on: { click: () => { filter = k; paint(); } } }, label + " (" + n + ")"));

  function detail(r) {
    return h("div", { class: "hd-detail" },
      r.description ? h("p", null, r.description) : null,
      r.rationale ? h("p", null, h("strong", null, "Why it matters: "), r.rationale) : null,
      h("p", { class: "muted small" },
        (r.cis_ref ? "CIS " + r.cis_ref + " \u00b7 " : "") + "Rule " + r.rule_id.replace("xccdf_org.ssgproject.content_rule_", "")
        + " \u00b7 " + (r.fix_available ? "an automated fix exists" : "no automated fix; fix by hand")),
      r.risky && r.result === "fail" ? h("p", { class: "hd-risky-note" },
        "Changing this can lock out logins, cut network access or stop services. Test the fix on one server first.") : null);
  }

  function paint() {
    tabBtns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === filter)));
    const rows = (d.results || []).filter(r => filter === "all" || r.result === filter
      || (filter === "na" && !["pass", "fail", "error"].includes(r.result)));
    if (!rows.length) { body.replaceChildren(h("div", { class: "empty" }, h("p", null, "Nothing here."))); return; }
    const t = table([
      { label: "Result", nowrap: true, cell: r => resultChip(r.result) },
      { label: "Rule", cell: r => r.title || r.rule_id },
      { label: "CIS", nowrap: true, cell: r => r.cis_ref || "" },
      { label: "Severity", nowrap: true, cell: r => sevChip(r.severity) },
      { label: "", nowrap: true, cell: r => r.risky && r.result === "fail" ? h("span", { class: "hd-risky" }, "risky to fix") : "" },
    ], rows, { onRow: (r, tr) => {
      const next = tr.nextElementSibling;
      if (next && next.classList.contains("hd-detail-row")) { next.remove(); return; }
      const td = h("td", { colspan: "5" }, detail(r));
      tr.after(h("tr", { class: "hd-detail-row" }, td));
    } });
    body.replaceChildren(h("p", { class: "muted small" }, "Click a rule for what it checks and why."), t);
  }

  const hist = (d.history || []).slice().reverse().filter(x => x.state === "done");
  const live = (d.history || [])[0];
  const liveRow = live && (live.state === "queued" || live.state === "running")
    ? Object.assign({}, live, { last_state: live.state, last_requested: live.requested_at }) : null;
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl harden --host " + d.host.hostname }, d.host.hostname),
      h("div", { class: "head-actions" },
        levelPicker(level, l => { location.hash = "#/hardening/host/" + hostId + "?level=" + encodeURIComponent(l); }),
        can("operator") ? h("button", { type: "button", class: "btn",
          on: { click: e => queueScans(level, [hostId], e.target, () => renderHardeningHost(hostId, params)) } }, "Scan now") : null,
        h("a", { href: "#/hardening?level=" + level }, "All servers"))),
    liveRow ? h("div", { class: "hd-live" }, h("span", { class: "hd-card-l" }, "Scan in progress"), scanProgress(liveRow)) : null,
    s ? h("div", { class: "hd-cards" },
      h("div", { class: "hd-card hd-card-main" }, h("div", { class: "hd-card-l" }, "Score"),
        h("div", { class: "hd-card-n" }, scoreBadge(s.score)),
        h("div", { class: "muted small" }, s.passed + " passed, " + s.failed + " failed, " + s.not_applicable + " not applicable"),
        trendSvg(hist.map(x => ({ score: x.score })))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Scanned"),
        h("div", null, fmtDateTime(s.finished_at)), h("div", { class: "muted small" }, timeAgo(s.finished_at)
          + (s.requested_by ? ", requested by " + s.requested_by : ""))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Benchmark"),
        h("div", null, s.product + " \u00b7 SSG " + s.content_version),
        h("div", { class: "muted small" }, s.profile_id.replace("xccdf_org.ssgproject.content_profile_", "") + ", oscap " + (s.oscap_version || "?"))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Evidence"),
        h("div", { class: "muted small hd-hash", title: "SHA-256 of the full result file kept on PATCH-01" },
          "SHA-256 " + (s.evidence_sha256 || "").slice(0, 16) + "\u2026"),
        h("div", { class: "muted small" }, "Full result file kept for audit.")))
      : h("div", { class: "empty" }, h("p", null, "No completed " + level.toUpperCase() + " scan for this server yet."),
          (d.history || [])[0] && d.history[0].state === "failed" ? h("p", { class: "hd-failed" }, "Last attempt failed: " + d.history[0].error) : null),
    s ? h("div", { class: "filters", role: "group", "aria-label": "Show" }, tabBtns) : null,
    s ? body : null);
  if (s) paint();
  if (liveRow) {
    setPageTimer(async () => {
      if (!location.hash.startsWith("#/hardening/host/" + hostId)) return clearPageTimer();
      const y = window.scrollY;
      await renderHardeningHost(hostId, params);
      window.scrollTo(0, y);
    }, 5000);
  } else if (location.hash.startsWith("#/hardening/host/")) {
    clearPageTimer();
  }
}

// ---- one rule --------------------------------------------------------------
async function renderHardeningRule(ruleId, params) {
  setNav("hardening");
  const level = hLevel(params);
  const d = await api("/hardening/rules/" + encodeURIComponent(ruleId) + "?level=" + encodeURIComponent(level));
  const r = d.rule;
  const failing = d.servers.filter(x => x.result === "fail");
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl harden --rule" }, r.title || r.rule_id),
      h("a", { href: "#/hardening?level=" + level }, "All rules")),
    h("div", { class: "hd-rule-meta" }, sevChip(r.severity), r.cis_ref ? h("span", null, "CIS " + r.cis_ref) : null,
      r.risky ? h("span", { class: "hd-risky" }, "risky to fix") : null,
      h("span", { class: "muted" }, r.fix_available ? "automated fix available" : "fix by hand")),
    r.description ? h("p", null, r.description) : null,
    r.rationale ? h("p", null, h("strong", null, "Why it matters: "), r.rationale) : null,
    r.risky ? h("p", { class: "hd-risky-note" }, "Fixing this can lock out logins, cut network access or stop services. "
      + "Test on one server first.") : null,
    h("h2", null, "Servers (" + failing.length + " failing of " + d.servers.length + ")"),
    d.servers.length ? table([
      { label: "Server", cell: x => h("a", { href: "#/hardening/host/" + x.host_id + "?level=" + level }, x.hostname) },
      { label: "Result", nowrap: true, cell: x => resultChip(x.result) },
      { label: "Benchmark", nowrap: true, cell: x => x.product },
      { label: "Scanned", nowrap: true, cell: x => timeAgo(x.finished_at) },
    ], d.servers) : h("div", { class: "empty" }, h("p", null, "No server's latest scan includes this rule.")));
}

// ---- mail alerts (admin) ---------------------------------------------------
async function renderMail(params) {
  setNav("mail");
  let d = await api("/admin/mail");
  const c = d.settings;
  const f = {};                                   // form fields by name
  const inp = (name, attrs) => (f[name] = h("input", Object.assign({ name }, attrs)));
  const chk = (name, on, label) => h("label", { class: "check" },
    (f[name] = h("input", { type: "checkbox", name, checked: on })), h("span", null, label));
  const field = (label, el, hint) => h("label", null, h("span", null, label), el, hint ? h("span", { class: "muted small" }, hint) : null);

  inp("host", { type: "text", value: c.host || "", placeholder: "smtp-relay.corp.local" });
  inp("port", { type: "number", min: "1", max: "65535", value: String(c.port || 25) });
  f.tls = h("select", { name: "tls" }, [["starttls", "STARTTLS (port 587, or 25)"], ["tls", "TLS from the start (port 465)"],
    ["none", "None (plain internal relay)"]].map(([v, l]) => h("option", { value: v, selected: c.tls === v }, l)));
  inp("username", { type: "text", value: c.user || "", placeholder: "Blank if the relay accepts PATCH-01 by address",
                    autocomplete: "off" });
  inp("password", { type: "password", autocomplete: "new-password",
                    placeholder: c.password_set ? "Saved. Leave blank to keep it" : "Mailbox password" });
  const clearPw = c.password_set ? chk("clear_password", false, "Remove the saved password") : null;
  f.ca_pem = h("textarea", { name: "ca_pem", rows: "5", placeholder: "-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----" },
               c.ca_pem || "");
  inp("from_addr", { type: "text", value: c.from || "", placeholder: "patch01-alerts@corp.example" });
  inp("from_name", { type: "text", value: c.from_name || "", placeholder: "PATCH-01 Alerts" });
  inp("digest_time", { type: "text", value: c.digest_time || "07:00", pattern: "\\d{2}:\\d{2}" });
  f.weekly_day = h("select", { name: "weekly_day" }, ["mon", "tue", "wed", "thu", "fri", "sat", "sun"].map(v =>
    h("option", { value: v, selected: c.weekly_day === v }, v[0].toUpperCase() + v.slice(1))));
  inp("console_url", { type: "text", value: c.console || "", placeholder: "https://patch01.example" });
  inp("company", { type: "text", value: c.company === "PATCH-01" ? "" : (c.company || ""), placeholder: "Your Company Pte Ltd" });
  f.signature = h("textarea", { name: "signature", rows: "5", maxlength: "2000",
    placeholder: "Security Operations\nYour Company Pte Ltd\n+65 6000 0000 | secops@corp.example" }, c.signature || "");

  const values = () => {
    const pw = f.password.value;
    return {
      enabled: f.enabled.checked, host: f.host.value.trim(), port: Number(f.port.value || 25), tls: f.tls.value,
      verify: f.verify.checked, ca_pem: f.ca_pem.value.trim() || null, username: f.username.value.trim(),
      password: pw ? pw : (f.clear_password && f.clear_password.checked ? "" : null),
      from_addr: f.from_addr.value.trim(), from_name: f.from_name.value.trim(),
      send_critical: f.send_critical.checked, send_tasks: f.send_tasks.checked,
      send_digest: f.send_digest.checked, send_weekly: f.send_weekly.checked,
      digest_time: f.digest_time.value.trim(), weekly_day: f.weekly_day.value,
      console_url: f.console_url.value.trim(), company: f.company.value.trim(),
      signature: f.signature.value,
    };
  };

  // Test connection: step by step, with the values in the form, saved or not
  const steps = h("ol", { class: "mail-steps" });
  const checkBtn = h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
    checkBtn.disabled = true; steps.replaceChildren(h("li", { class: "muted" }, "Testing\u2026"));
    try {
      const r = await apiPost("/admin/mail/check", values());
      steps.replaceChildren(...r.steps.map(st => h("li", { class: st.ok ? "ms-ok" : "ms-bad" },
        h("strong", null, st.step), " ", st.detail)));
      if (r.ok) steps.append(h("li", { class: "ms-ok ms-final" }, h("strong", null, "Ready."),
        " The relay accepts mail from PATCH-01. Save, then send a test mail."));
    } catch (e) { steps.replaceChildren(h("li", { class: "ms-bad" }, e.message)); }
    checkBtn.disabled = false;
  } } }, "Test connection");

  const saveMsg = h("span", { class: "small" });
  const saveBtn = h("button", { type: "button", class: "btn", on: { click: async () => {
    saveBtn.disabled = true; saveMsg.className = "muted small"; saveMsg.textContent = "Saving\u2026";
    try {
      d = await apiSend("PUT", "/admin/mail", values());
      saveMsg.className = "hd-good small"; saveMsg.textContent = "Saved.";
      setTimeout(() => renderMail(params), 700);
    } catch (e) { saveMsg.className = "hd-failed"; saveMsg.textContent = e.message; }
    saveBtn.disabled = false;
  } } }, "Save settings");

  // Recipients
  const KINDS = [["critical", "Critical"], ["tasks", "Tasks"], ["digest", "Daily digest"], ["weekly", "Weekly"]];
  const rmsg = h("span", { class: "small" });
  const recTable = () => (d.recipients || []).length ? table([
    { label: "Address", cell: r => h("span", null, h("strong", null, r.address), r.name ? h("span", { class: "muted" }, " \u00b7 " + r.name) : null) },
    ...KINDS.map(([k, label]) => ({ label, nowrap: true, cell: r => {
      const cb = h("input", { type: "checkbox", checked: r[k], "aria-label": label + " for " + r.address });
      cb.addEventListener("change", async () => {
        try { d = await apiSend("PATCH", "/admin/mail/recipients/" + r.id, { [k]: cb.checked }); }
        catch (e) { cb.checked = !cb.checked; rmsg.className = "hd-failed"; rmsg.textContent = e.message; }
      });
      return cb;
    } })),
    { label: "", nowrap: true, cell: r => h("span", { class: "row-actions" },
        h("button", { type: "button", class: "btn-link", on: { click: async e => {
          const b = e.target; b.disabled = true; b.textContent = "Sending\u2026";
          try { await apiPost("/admin/mail/test", { to: r.address }); b.textContent = "Sent \u2713"; }
          catch (err) { b.textContent = "Test"; rmsg.className = "hd-failed"; rmsg.textContent = err.message; }
          setTimeout(() => { b.disabled = false; b.textContent = "Test"; }, 3000);
        } } }, "Test"),
        h("button", { type: "button", class: "btn-link", on: { click: async () => {
          if (!confirm("Stop sending mail to " + r.address + "?")) return;
          try { d = await apiSend("DELETE", "/admin/mail/recipients/" + r.id); showRecipients();
                rmsg.className = "muted small"; rmsg.textContent = r.address + " removed."; }
          catch (err) { rmsg.className = "hd-failed"; rmsg.textContent = err.message; }
        } } }, "Remove")) },
  ], d.recipients) : h("div", { class: "empty" }, h("p", null, "No recipients yet. Add at least one to turn mail on."));
  const recBox = h("div");
  const showRecipients = () => recBox.replaceChildren(recTable());
  const newAddr = h("input", { type: "text", placeholder: "name@corp.example", "aria-label": "New recipient address" });
  const newName = h("input", { type: "text", placeholder: "Name or team (optional)", "aria-label": "New recipient name" });
  const newKinds = KINDS.map(([k, label]) => h("label", { class: "check" }, h("input", { type: "checkbox", checked: true, "data-k": k }), h("span", null, label)));
  const addBtn = h("button", { type: "button", class: "btn", on: { click: async () => {
    const body = { address: newAddr.value.trim(), name: newName.value.trim() };
    newKinds.forEach(l => { const cb = l.querySelector("input"); body[cb.dataset.k] = cb.checked; });
    try {
      d = await apiPost("/admin/mail/recipients", body);
      showRecipients(); newAddr.value = ""; newName.value = ""; rmsg.className = "hd-good small";
      rmsg.textContent = body.address + " added.";
    } catch (e) { rmsg.className = "hd-failed"; rmsg.textContent = e.message; }
  } } }, "Add recipient");

  const w = d.worker;
  const STATE = { sent: ["Sent", "hr-pass"], queued: ["Queued", "hr-na"], failed: ["Failed", "hr-fail"] };
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl mail --setup" }, "Mail alerts"),
      h("span", { class: "muted small" }, c.updated_by ? "Last changed by " + c.updated_by + ", " + timeAgo(c.updated_at) : "")),
    !c.key_present ? h("div", { class: "form-warn" }, h("strong", null, "The mail key is missing. "),
      "A password cannot be saved until phase3b-api.sh has run on PATCH-01.") : null,
    h("div", { class: "form-sec" },
      h("label", { class: "check mail-enable" }, (f.enabled = h("input", { type: "checkbox", name: "enabled", checked: c.enabled })),
        h("span", null, h("strong", null, "Send mail alerts"), h("span", { class: "muted small" },
          c.enabled ? " \u00b7 on" : " \u00b7 off: nothing is sent until this is ticked and saved")))),
    h("div", { class: "form-sec" }, h("h2", null, "1. Relay"),
      h("div", { class: "af-row" }, field("Relay host", f.host), field("Port", f.port), field("Encryption", f.tls)),
      h("div", { class: "af-row" }, field("Login (the mailbox)", f.username), field("Password", f.password,
        "Stored encrypted on PATCH-01; never shown again.")),
      clearPw,
      h("details", { class: "mail-adv", open: !!c.ca_pem || c.verify === false },
        h("summary", null, "Certificate checks"),
        chk("verify", c.verify !== false, "Check the relay's certificate (recommended)"),
        field("CA certificate, if the relay's certificate comes from an internal CA", f.ca_pem,
          "Paste the PEM text. Leave blank for a publicly trusted certificate."))),
    h("div", { class: "form-sec" }, h("h2", null, "2. Sender"),
      h("div", { class: "af-row" }, field("From address (the mailbox)", f.from_addr), field("From name", f.from_name),
        field("Company name in mail", f.company)),
      field("Console address, for links in mail", f.console_url),
      field("Signature, added to every mail: alerts, digests and reports", f.signature)),
    h("div", { class: "form-actions" }, checkBtn, h("span", { class: "muted small" }, "Uses the values above, saved or not. Sends nothing.")),
    steps,
    h("div", { class: "form-sec" }, h("h2", null, "3. What to send"),
      chk("send_critical", c.critical, "Critical alerts, within a minute"),
      chk("send_tasks", c.tasks, "Task updates: changes started and finished, scans completed"),
      chk("send_digest", c.digest, "Daily digest"),
      chk("send_weekly", c.weekly, "Weekly summary"),
      h("div", { class: "af-row" }, field("Digest time (Singapore, 24-hour)", f.digest_time), field("Weekly summary day", f.weekly_day))),
    h("div", { class: "form-actions" }, saveBtn, saveMsg),
    h("h2", null, "4. Recipients"),
    h("p", { class: "muted small" }, "Choose who gets each kind of mail. Changes apply at once and are recorded in Activity."),
    recBox,
    h("div", { class: "mail-add" }, newAddr, newName, h("span", { class: "mail-kinds" }, newKinds), addBtn),
    rmsg,
    h("h2", null, "Recent mail"),
    h("p", { class: "muted small" }, (d.counts_7d.sent || 0) + " sent, " + (d.counts_7d.queued || 0) + " queued, "
      + (d.counts_7d.failed || 0) + " failed in the last 7 days"
      + (w ? " \u00b7 the worker last checked " + timeAgo(w.beat_at) : "")),
    (d.recent || []).length ? table([
      { label: "When", nowrap: true, cell: n => fmtDateTime(n.created_at) },
      { label: "Kind", nowrap: true, cell: n => ({ critical: "Critical", task: "Task", digest: "Daily digest", weekly: "Weekly",
                                                   system: "System", test: "Test" })[n.category] || n.category },
      { label: "Subject", cell: n => n.subject.replace("[PATCH-01] ", "") },
      { label: "State", nowrap: true, cell: n => { const [l, cls] = STATE[n.state] || [n.state, "hr-na"];
          return h("span", { class: "hd-res " + cls }, l + (n.state === "queued" && n.attempts ? " (retry " + n.attempts + ")" : "")); } },
      { label: "Problem", cell: n => n.last_error ? h("span", { class: "hd-failed" }, n.last_error) : "" },
    ], d.recent) : h("div", { class: "empty" }, h("p", null, "No mail sent yet.")));
  showRecipients();
}


// ---- reports ------------------------------------------------------------------
function fmtBytes(n) { return n >= 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB"; }

async function downloadReport(id, btn) {
  // A link cannot carry the sign-in token, so fetch the file and hand it over
  const was = btn ? btn.textContent : null;
  if (btn) { btn.disabled = true; btn.textContent = "Downloading\u2026"; }
  try {
    const res = await fetch("/api/v1/reports/" + id + "/download", { headers: { ...authHeaders(), "X-Requested-With": "patch01-dashboard" } });
    if (!res.ok) { let d = ""; try { d = detailText((await res.json()).detail); } catch (e) { /* not JSON */ } throw new Error(d || res.statusText); }
    const cd = res.headers.get("Content-Disposition") || "";
    const m = /filename="?([^";]+)"?/.exec(cd);
    const blob = await res.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = m ? m[1] : "report";
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 30000);
  } catch (e) { alert(e.message); }
  if (btn) { btn.disabled = false; btn.textContent = was; }
}

function reportPanel(level, hosts) {
  let detailWrap;
  const groups = [...new Set(hosts.map(x => x.host_group).filter(Boolean))].sort();
  const scope = h("select", { "aria-label": "Report scope" },
    h("option", { value: "all" }, "All servers"),
    ...groups.map(g => h("option", { value: "g:" + g }, "Group: " + g)),
    h("option", { value: "attention" }, "Servers below 85%"));
  const style = h("select", { "aria-label": "Report type" },
    h("option", { value: "management" }, "Management summary: pass and fail, no fixes"),
    h("option", { value: "technical" }, "Technical detail: findings with how to fix"));
  const detail = h("select", { "aria-label": "Findings to include" },
    h("option", { value: "high_medium" }, "High and medium findings in detail"),
    h("option", { value: "all" }, "Every finding in detail"),
    h("option", { value: "high" }, "High findings only in detail"));
  const label = h("input", { type: "text", placeholder: "Title for the cover, e.g. Production Linux fleet", maxlength: "80" });
  const out = h("div", { class: "rep-out" });
  const go = fmt => async e => {
    const btn = e.target; btn.disabled = true; const was = btn.textContent; btn.textContent = "Building\u2026";
    out.replaceChildren(h("span", { class: "muted small" }, "Building the report from the latest scans\u2026"));
    const body = { level, format: fmt, detail: detail.value, style: style.value, scope_label: label.value.trim() || null };
    if (scope.value.startsWith("g:")) body.host_group = scope.value.slice(2);
    if (scope.value === "attention") {
      body.host_ids = hosts.filter(x => x.score !== null && Number(x.score) < 85).map(x => x.id);
      body.scope_label = body.scope_label || "Servers below 85%";
      if (!body.host_ids.length) { out.replaceChildren(h("span", { class: "hd-good small" }, "No scanned server is below 85%.")); btn.disabled = false; btn.textContent = was; return; }
    }
    try {
      const r = await apiPost("/reports/hardening", body);
      const dl = h("button", { type: "button", class: "btn", on: { click: ev => downloadReport(r.id, ev.target) } }, "Download " + (fmt === "pdf" ? "PDF" : "Word"));
      out.replaceChildren(h("div", { class: "rep-ready" },
        h("strong", null, r.report_id), " \u00b7 " + r.servers + " server" + (r.servers === 1 ? "" : "s")
          + (r.pages ? " \u00b7 " + r.pages + " pages" : "") + " \u00b7 " + fmtBytes(r.size_bytes), dl,
        can("operator") ? h("button", { type: "button", class: "btn btn-quiet", on: { click: () => emailReport(r.id) } }, "Email this report") : null,
        h("div", { class: "muted small hd-hash" }, "SHA-256 " + r.sha256)));
      downloadReport(r.id);
      const arch = document.querySelector(".rep-archive"); if (arch) loadArchive(arch.parentNode);
    } catch (err) { out.replaceChildren(h("span", { class: "hd-failed" }, err.message)); }
    btn.disabled = false; btn.textContent = was;
  };
  const panel = h("div", { class: "rep-panel", hidden: true },
    h("div", { class: "rep-row" },
      h("label", null, h("span", null, "Report type"), style),
      h("label", null, h("span", null, "Scope"), scope),
      (detailWrap = h("label", { hidden: true }, h("span", null, "Findings in detail"), detail)),
      h("label", { class: "rep-wide" }, h("span", null, "Cover title (optional)"), label)),
    h("div", { class: "rep-row" },
      h("button", { type: "button", class: "btn", on: { click: go("pdf") } }, "PDF"),
      h("button", { type: "button", class: "btn btn-quiet", on: { click: go("docx") } }, "Word"),
      h("span", { class: "muted small" }, levelName(level)
        + ", from each server's latest scan. The logo and company details come from Admin \u203a Branding.")),
    out);
  style.addEventListener("change", () => { detailWrap.hidden = style.value !== "technical"; });
  return panel;
}

async function loadArchive(box) {
  try {
    const d = await api("/reports");
    const rows = (d.reports || []).slice(0, 15);
    box.replaceChildren(rows.length ? h("div", { class: "rep-archive" }, table([
      { label: "Report", nowrap: true, cell: r => h("strong", null, r.report_ref || ("#" + r.number)) },
      { label: "Type", nowrap: true, cell: r => r.style === "technical" ? "Technical" : "Management" },
      { label: "Title", cell: r => (r.title || "").replace("CIS Hardening Report, ", "").replace(/(Management summary|Technical detail), /, "") },
      { label: "Format", nowrap: true, cell: r => r.format === "pdf" ? "PDF" : "Word" },
      { label: "Servers", num: true, cell: r => r.servers },
      { label: "Score", num: true, cell: r => r.score === null ? "\u2013" : Number(r.score).toFixed(1) + "%" },
      { label: "By", nowrap: true, cell: r => r.generated_by },
      { label: "When", nowrap: true, cell: r => timeAgo(r.generated_at) },
      { label: "", nowrap: true, cell: r => h("span", { class: "row-actions" },
          h("button", { type: "button", class: "btn-link", on: { click: e => downloadReport(r.id, e.target) } }, "Download"),
          can("operator") && r.report_ref ? h("button", { type: "button", class: "btn-link", on: { click: () => emailReport(r.id) } }, "Email") : null) },
    ], rows)) : h("div", { class: "empty rep-archive" }, h("p", null, "No reports yet. Use Export report above.")));
  } catch (e) { box.replaceChildren(h("p", { class: "hd-failed" }, e.message)); }
}

// ---- admin: tabs, branding ------------------------------------------------------
function adminTabs(active) {
  const tabs = [["users", "Users"], ["access", "Access"], ["mail", "Mail"], ["feeds", "CVE feeds"], ["branding", "Branding"], ["certificate", "Certificate"]];
  const el = h("div", { class: "filters admin-tabs", role: "group", "aria-label": "Admin" },
    tabs.map(([k, label]) => h("a", { class: "fbtn", href: "#/" + k, "aria-pressed": String(k === active) }, label)));
  const view = document.getElementById("view");
  if (view && !view.querySelector(".admin-tabs")) view.prepend(el);
  document.querySelectorAll("nav a[data-nav]").forEach(a => a.removeAttribute("aria-current"));
  const nav = document.querySelector('nav a[data-nav="admin"]');
  if (nav) nav.setAttribute("aria-current", "page");
}

async function renderBranding(params) {
  setNav("admin");
  const d = await api("/admin/branding");
  const e = d.effective, sv = d.saved || {};
  const m = e.logo_meta;
  const company = h("input", { type: "text", value: sv.company || "", placeholder: "Your Company Pte Ltd", maxlength: "120" });
  const copy = h("input", { type: "text", value: sv.copyright || "", placeholder: e.copyright, maxlength: "200" });
  const CLS = ["CONFIDENTIAL", "INTERNAL", "RESTRICTED", "PUBLIC"];
  const cls = h("select", null, CLS.map(c => h("option", { value: c, selected: (sv.classification || "CONFIDENTIAL") === c }, c)));
  const own = h("input", { type: "checkbox", checked: !!sv.accent });
  const colour = h("input", { type: "color", value: sv.accent || e.accent || "#1F5AA6", disabled: !sv.accent });
  own.addEventListener("change", () => { colour.disabled = !own.checked; });
  const img = h("img", { class: "brand-logo", alt: "Processed logo" });
  const imgW = h("img", { class: "brand-logo brand-dark", alt: "Logo on a dark background" });
  async function loadImg(el, variant) {
    try {
      const res = await fetch("/api/v1/branding/logo?variant=" + variant, { headers: authHeaders() });
      if (res.ok) el.src = URL.createObjectURL(await res.blob()); else el.remove();
    } catch (err) { el.remove(); }
  }
  const msg = h("span", { class: "small" });
  const save = h("button", { type: "button", class: "btn", on: { click: async () => {
    save.disabled = true;
    try {
      await apiSend("PUT", "/admin/branding", { company: company.value.trim(), copyright: copy.value.trim(),
        classification: cls.value, accent: own.checked ? colour.value.toUpperCase() : null });
      msg.className = "hd-good small"; msg.textContent = "Saved. New reports use it at once.";
      setTimeout(() => renderBranding(params), 800);
    } catch (err) { msg.className = "hd-failed"; msg.textContent = err.message; }
    save.disabled = false;
  } } }, "Save");
  const fact = (k, v) => h("div", { class: "brand-fact" }, h("span", { class: "muted small" }, k), h("span", null, v));
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl branding" }, "Branding")),
    h("h2", null, "Logo"),
    m ? h("div", { class: "brand-grid" },
      h("div", { class: "brand-previews" },
        h("div", { class: "brand-light" }, img),
        h("div", { class: "brand-navy" }, e.has_logo_white || !m.dark ? imgW
          : h("div", { class: "brand-plate" }, h("img", { class: "brand-logo", alt: "", src: "" }))),
        h("p", { class: "muted small" }, e.has_logo_white ? "On dark backgrounds: " + e.logo_white_file
          : (m.dark ? "Dark logo: on the navy cover it sits on a white plate so it stays visible."
                    : "Light logo: used directly on dark backgrounds."))),
      h("div", null,
        fact("File", e.logo_file), fact("Original", m.original[0] + " \u00d7 " + m.original[1] + " px, " + fmtBytes(m.bytes_in)),
        fact("As used", m.size[0] + " \u00d7 " + m.size[1] + " px, " + fmtBytes(m.bytes_out) + " (margins trimmed)"),
        fact("Background", m.transparent ? "transparent" : "solid"),
        fact("Main colour", m.accent ? h("span", null, h("span", { class: "brand-swatch", style: null, "data-c": m.accent }), " " + m.accent) : "none found"),
        ...(m.warnings || []).map(w => h("p", { class: "hd-risky-note" }, w))))
      : h("div", { class: "empty" }, h("p", null, e.logo_problem || "No logo yet."),
          h("p", { class: "muted" }, "Copy a PNG to " + d.folder + "/logo.png on PATCH-01. Any size works: PATCH-01 "
            + "trims the margins and scales it. For dark backgrounds you can add logo-white.png as well.")),
    m ? h("p", { class: "muted small" }, "To change it, replace the file in " + d.folder
      + " on PATCH-01. It is picked up the next time a report is made.") : null,
    h("div", { class: "form-sec" }, h("h2", null, "Company"),
      h("label", null, h("span", null, "Company name"), company),
      h("label", null, h("span", null, "Copyright line (footer of every page)"), copy),
      h("label", null, h("span", null, "Classification (header, footer and cover)"), cls),
      h("label", { class: "check" }, own, h("span", null, "Choose the accent colour myself")),
      h("label", null, h("span", null, "Accent colour " + (e.accent_source === "logo" ? "(now taken from the logo: " + e.accent + ")" : "")), colour)),
    h("div", { class: "form-actions" }, save, msg));
  if (m) {
    loadImg(img, "main");
    if (e.has_logo_white || !m.dark) loadImg(imgW, e.has_logo_white ? "white" : "main");
    else loadImg(document.querySelector(".brand-plate img"), "main");
    document.querySelectorAll(".brand-swatch").forEach(x => { x.style.background = x.dataset.c; });
  }
}


// ---- e-mailing a report ---------------------------------------------------------------
async function emailReport(reportId) {
  document.querySelectorAll(".mw-back").forEach(x => x.remove());
  const close = () => back.remove();
  const status = h("p", { class: "mw-status" }, "Loading\u2026");
  const summaryBox = h("div", { class: "mw-summary" }, h("p", { class: "muted small" }, "Loading the report\u2026"));
  const to = h("input", { type: "text", placeholder: "name@corp.example, another@corp.example", list: "mw-recips" });
  const cc = h("input", { type: "text", placeholder: "Optional", list: "mw-recips" });
  const subject = h("input", { type: "text", maxlength: "200" });
  const text = h("textarea", { rows: "9", placeholder: "The message appears here." });
  const sig = h("pre", { class: "mw-sig" });
  const att = h("div", { class: "mw-att" });
  const recips = h("datalist", { id: "mw-recips" });
  const picks = h("div", { class: "mw-picks" });
  const msg = h("div", { class: "small" });
  const send = h("button", { type: "button", class: "btn", disabled: true }, "Send with report attached");
  const redraft = h("button", { type: "button", class: "btn btn-quiet", disabled: true,
    title: "AI-01 rewrites the message from the report's figures; it can take up to a minute" }, "Polish with AI-01");
  const box = h("div", { class: "mw", role: "dialog", "aria-modal": "true", "aria-label": "E-mail this report" },
    h("div", { class: "mw-head" }, h("h2", null, "E-mail this report"),
      h("button", { type: "button", class: "btn-link", on: { click: close } }, "Close")),
    h("div", { class: "mw-grid" },
      h("div", null, h("h3", null, "Report at a glance"), summaryBox, att),
      h("div", null,
        h("label", null, h("span", null, "To"), to), picks,
        h("label", null, h("span", null, "Cc"), cc),
        h("label", null, h("span", null, "Subject"), subject),
        status,
        h("label", null, h("span", null, "Message"), text),
        h("div", { class: "mw-sigwrap" }, h("span", { class: "muted small" }, "Signature, added automatically (Admin \u203a Mail)"), sig),
        h("div", { class: "form-actions" }, send, redraft), msg)),
    recips);
  const back = h("div", { class: "mw-back", on: { click: e => { if (e.target === back) close(); } } }, box);
  document.body.append(back);
  document.addEventListener("keydown", function esc(e) { if (e.key === "Escape") { close(); document.removeEventListener("keydown", esc); } });

  api("/mail/recipients").then(r => {
    (r.recipients || []).forEach(x => recips.append(h("option", { value: x.address }, x.name || "")));
    picks.replaceChildren(...(r.recipients || []).slice(0, 8).map(x => h("button", { type: "button", class: "mw-chip",
      on: { click: () => { const cur = to.value.split(/[,;]/).map(v => v.trim()).filter(Boolean);
                           if (!cur.includes(x.address)) cur.push(x.address); to.value = cur.join(", "); } } },
      "+ " + (x.name ? x.name : x.address))));
  }).catch(() => {});

  async function polish() {
    redraft.disabled = true; send.disabled = true;
    status.className = "mw-status"; status.replaceChildren(h("span", { class: "hd-pulse" }),
      " AI-01 is rewriting the message from the report's figures. On this hardware that can take up to a minute.");
    try {
      const d = await apiPost("/reports/" + reportId + "/email/polish", {});
      subject.value = d.subject; text.value = d.body;
      status.className = "mw-status " + (d.source === "ai" ? "mw-ai" : "mw-tpl"); status.replaceChildren(d.note);
    } catch (e) { status.className = "mw-status hd-failed"; status.replaceChildren(e.message); }
    redraft.disabled = false; send.disabled = false;
  }

  async function loadDraft() {
    status.hidden = false; redraft.disabled = true; send.disabled = true;
    try {
      const d = await apiPost("/reports/" + reportId + "/email/draft", {});
      summaryBox.replaceChildren(...d.summary.map(([k, v]) => h("div", { class: "mw-fact" },
        h("span", { class: "muted small" }, k), h("strong", null, v))));
      att.replaceChildren(h("span", { class: "muted small" }, "Attached: "), h("strong", null, d.attachment.file),
        " (" + fmtBytes(d.attachment.size_bytes) + ")");
      subject.value = d.subject; text.value = d.body;
      sig.textContent = d.signature || "No signature set yet.";
      status.hidden = false;
      status.className = "mw-status " + (d.source === "ai" ? "mw-ai" : "mw-tpl");
      status.replaceChildren(d.note);
      if (!d.ready) { msg.className = "hd-failed"; msg.textContent = "Mail is not set up yet: an admin can do it under Admin \u203a Mail."; }
      send.disabled = !d.ready;
    } catch (e) { status.className = "mw-status hd-failed"; status.replaceChildren(e.message); }
    redraft.disabled = false;
  }
  redraft.addEventListener("click", polish);
  send.addEventListener("click", async () => {
    const list = v => v.split(/[,;]/).map(x => x.trim()).filter(Boolean);
    if (!list(to.value).length) { msg.className = "hd-failed"; msg.textContent = "Add at least one recipient."; return; }
    send.disabled = true; send.textContent = "Sending\u2026";
    try {
      const r = await apiPost("/reports/" + reportId + "/email", { to: list(to.value), cc: list(cc.value),
                                                                 subject: subject.value.trim(), body: text.value });
      msg.className = "hd-good"; msg.textContent = "Sent to " + r.to.concat(r.cc).join(", ") + ". Recorded in Activity.";
      send.textContent = "Sent \u2713";
      setTimeout(close, 2500);
    } catch (e) { msg.className = "hd-failed"; msg.textContent = e.message; send.disabled = false; send.textContent = "Send with report attached"; }
  });
  to.focus();
  loadDraft();
}


// ---- custom profiles ---------------------------------------------------------------
const CP_HOW = { cis: ["CIS number", "cp-cis"], title: ["Title match", "cp-title"], ai: ["AI-01", "cp-ai"],
                 manual: ["Chosen", "cp-manual"], none: ["Manual check", "cp-none"], skipped: ["Not a check", "cp-skip"] };
const CP_PRODUCTS = [["rhel9", "RHEL 9"], ["rhel8", "RHEL 8"], ["rhel10", "RHEL 10"], ["ubuntu2204", "Ubuntu 22.04"],
                     ["ubuntu2404", "Ubuntu 24.04"]];

async function renderCustomList() {
  setNav("hardening");
  const d = await api("/hardening/custom");
  const rows = d.profiles || [];
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl harden --custom" }, "Custom profiles"),
      h("div", { class: "head-actions" },
        can("operator") ? h("a", { class: "btn", href: "#/hardening/custom/new" }, "New from a document") : null,
        h("a", { href: "#/hardening" }, "Hardening"))),
    h("p", { class: "muted" }, "A custom profile checks exactly the settings in a document you provide, such as your own "
      + "hardening standard or an auditor's checklist, instead of the whole CIS benchmark. Reports list its results in "
      + "the document's terms, and anything no scan can check is listed as a manual check."),
    rows.length ? table([
      { label: "Profile", cell: p => h("a", { href: "#/hardening/custom/" + p.id }, h("strong", null, p.name)) },
      { label: "State", nowrap: true, cell: p => h("span", { class: "hd-res " + (p.status === "active" ? "hr-pass" : "hr-na") },
          p.status === "active" ? "In use" : "Draft") },
      { label: "From", cell: p => p.source_file || "" },
      { label: "Lines", num: true, cell: p => p.lines },
      { label: "Matched", num: true, cell: p => p.matched },
      { label: "Version", num: true, cell: p => p.version },
      { label: "Changed", nowrap: true, cell: p => timeAgo(p.updated_at) + (p.updated_by ? ", " + p.updated_by : "") },
    ], rows) : h("div", { class: "empty" }, h("p", null, "No custom profiles yet.")));
}

async function renderCustomNew() {
  setNav("hardening");
  const name = h("input", { type: "text", maxlength: "120", placeholder: "Company Linux Standard v2" });
  const product = h("select", null, CP_PRODUCTS.map(([v, l]) => h("option", { value: v }, l)));
  const file = h("input", { type: "file", accept: ".txt,.csv,.docx" });
  const text = h("textarea", { rows: "8", placeholder: "Or paste the list here, one requirement per line:\n5.1.20 Ensure SSH root login is disabled\nPasswords must be at least 14 characters" });
  const msg = h("div", { class: "small" });
  const go = h("button", { type: "button", class: "btn", on: { click: async () => {
    if (!name.value.trim()) { msg.className = "hd-failed"; msg.textContent = "Give the profile a name."; return; }
    const fd = new FormData();
    fd.append("name", name.value.trim()); fd.append("product", product.value);
    if (file.files.length) fd.append("file", file.files[0]); else fd.append("text", text.value);
    go.disabled = true; msg.className = "muted small"; msg.textContent = "Reading the document and matching each line\u2026";
    try {
      const res = await fetch("/api/v1/hardening/custom", { method: "POST", body: fd,
        headers: { ...authHeaders(), "X-Requested-With": "patch01-dashboard" } });
      const dd = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(dd.detail) || res.statusText);
      location.hash = "#/hardening/custom/" + dd.id;
    } catch (e) { msg.className = "hd-failed"; msg.textContent = e.message; go.disabled = false; }
  } } }, "Read and match");
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl harden --custom --new" }, "New custom profile"),
      h("a", { href: "#/hardening/custom" }, "Custom profiles")),
    h("div", { class: "form-sec" },
      h("label", null, h("span", null, "Profile name"), name),
      h("label", null, h("span", null, "Benchmark the document's CIS numbers follow"), product,
        h("span", { class: "muted small" }, "CIS numbers differ between benchmarks, so this decides what 5.2.4 means.")),
      h("label", null, h("span", null, "Document (.txt, .csv or .docx)"), file),
      h("label", null, h("span", null, "Or paste the list"), text)),
    h("p", { class: "muted small" }, "Each line is matched to benchmark checks: by its CIS number first, then by its "
      + "wording. You review every match before the profile is used."),
    h("div", { class: "form-actions" }, go, msg));
}

async function renderCustomReview(pid) {
  setNav("hardening");
  let d = await api("/hardening/custom/" + pid);
  const canEdit = can("operator");
  let edit = canEdit && d.profile.status !== "active";
  const body = h("div");
  let filter = "all";
  const msg = h("div", { class: "small" });

  async function change(bodyObj, itemId) {
    try { d = await apiSend("PATCH", "/hardening/custom/" + pid + "/items/" + itemId, bodyObj); msg.textContent = ""; paint(); }
    catch (e) { msg.className = "hd-failed"; msg.textContent = e.message; }
  }
  function ruleLine(r) {
    return h("div", { class: "cp-rule" }, h("span", null, r.title), r.cis_ref ? h("span", { class: "muted small" }, " \u00b7 CIS " + r.cis_ref) : null);
  }
  function picker(it, cell) {
    const q = h("input", { type: "search", placeholder: "Search checks by words or CIS number", value: "" });
    const list = h("div", { class: "cp-results" });
    let timer = null;
    q.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(async () => {
      if (q.value.trim().length < 2) { list.replaceChildren(); return; }
      let r;
      try { r = await api("/hardening/custom/" + pid + "/search?q=" + encodeURIComponent(q.value.trim())); }
      catch (e) { list.replaceChildren(h("p", { class: "hd-failed" }, e.message)); return; }
      list.replaceChildren(...(r.rules || []).slice(0, 10).map(x => h("button", { type: "button", class: "cp-pick",
        on: { click: () => change({ rule_ids: [x.rule_id] }, it.id) } },
        x.title, x.cis_ref ? h("span", { class: "muted small" }, " \u00b7 CIS " + x.cis_ref) : null)));
      if (!(r.rules || []).length) list.replaceChildren(h("p", { class: "muted small" }, "No check matches those words."));
    }, 250); });
    cell.replaceChildren(q, list); q.focus();
  }

  function paint() {
    edit = canEdit && d.profile.status !== "active";
    const c = d.counts;
    counts.replaceChildren(...[
      h("span", null, h("strong", null, c.lines), " lines"),
      h("span", { class: "hr-pass" }, h("strong", null, c.matched), " matched to " + c.checks + " checks"),
      h("span", { class: "hr-error" }, h("strong", null, c.to_review), " to review"),
      h("span", { class: "muted" }, h("strong", null, c.manual), " manual checks"),
      c.skipped ? h("span", { class: "muted" }, h("strong", null, c.skipped), " not checks") : null].filter(Boolean));
    tabs.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === filter)));
    const items = d.items.filter(it => filter === "all" || (filter === "review" && ["low", "medium"].includes(it.confidence) && it.rule_ids.length)
      || (filter === "manual" && !it.rule_ids.length && it.matched_by !== "skipped") || (filter === "matched" && it.rule_ids.length));
    body.replaceChildren(items.length ? table([
      { label: "#", num: true, cell: it => it.line_no },
      { label: "Requirement in the document", cell: it => h("span", { class: it.matched_by === "skipped" ? "muted" : null }, it.source_text) },
      { label: "Checked by", cell: it => {
          const cell = h("div", null, it.rules.length ? it.rules.map(ruleLine) : h("span", { class: "muted small" },
            it.matched_by === "skipped" ? "\u2013" : "Nothing automatic: listed in reports as a manual check"),
            it.note && (it.confidence === "low" || it.matched_by === "ai") ? h("div", { class: "hd-risky-note small" }, it.note) : null);
          cell.dataset.item = it.id;
          return cell; } },
      { label: "How", nowrap: true, cell: it => { const [l, cls] = CP_HOW[it.matched_by] || [it.matched_by, "cp-none"];
          return h("span", { class: "cp-how " + cls + (it.confidence === "low" ? " cp-low" : "") }, l + (it.confidence === "low" ? " ?" : "")); } },
      edit ? { label: "", nowrap: true, cell: it => h("span", { class: "row-actions" },
          h("button", { type: "button", class: "btn-link", on: { click: e => picker(it, e.target.closest("tr").querySelector("[data-item]")) } },
            it.rule_ids.length ? "Change" : "Pick check"),
          !it.rule_ids.length && it.matched_by !== "skipped" ? h("button", { type: "button", class: "btn-link", on: { click: async e => {
            const b = e.target; b.disabled = true; b.textContent = "AI-01\u2026";
            try { const r = await apiPost("/hardening/custom/" + pid + "/items/" + it.id + "/suggest", {});
                  d = r.view; msg.className = r.ok ? "hd-good small" : "muted small"; msg.textContent = r.note; paint(); }
            catch (err) { msg.className = "hd-failed"; msg.textContent = err.message; b.disabled = false; b.textContent = "Ask AI-01"; }
          } } }, "Ask AI-01") : null,
          it.rule_ids.length ? h("button", { type: "button", class: "btn-link", on: { click: () => change({ rule_ids: [] }, it.id) } }, "Clear") : null,
          h("button", { type: "button", class: "btn-link", on: { click: () => change({ skip: it.matched_by !== "skipped" }, it.id) } },
            it.matched_by === "skipped" ? "It is a check" : "Not a check")) } : null,
    ].filter(Boolean), items) : h("div", { class: "empty" }, h("p", null, "Nothing here.")));
    const p = d.profile;
    state.replaceChildren(h("span", { class: "hd-res " + (p.status === "active" ? "hr-pass" : "hr-na") },
      p.status === "active" ? "In use, version " + p.version : "Draft, not used yet"));
    act.replaceChildren(canEdit ? (p.status === "active"
      ? h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
          try { d = await apiPost("/hardening/custom/" + pid + "/state", { status: "draft" }); paint(); }
          catch (e) { msg.className = "hd-failed"; msg.textContent = e.message; } } } }, "Edit (back to draft)")
      : h("button", { type: "button", class: "btn", on: { click: async () => {
          try { d = await apiPost("/hardening/custom/" + pid + "/state", { status: "active" }); await loadCustoms(); paint();
                msg.className = "hd-good small"; msg.textContent = "In use. Choose it from the profile list on the Hardening page to scan with it."; }
          catch (e) { msg.className = "hd-failed"; msg.textContent = e.message; } } } }, "Use this profile")) : null,
      p.status === "active" ? h("a", { class: "btn btn-quiet", href: "#/hardening?level=" + encodeURIComponent("custom:" + p.id) }, "Scan with it") : null);
  }
  const counts = h("div", { class: "cp-counts" });
  const state = h("span");
  const act = h("div", { class: "head-actions" });
  const tabs = [["all", "All"], ["review", "To review"], ["matched", "Matched"], ["manual", "Manual checks"]].map(([k, l]) =>
    h("button", { type: "button", "data-k": k, on: { click: () => { filter = k; paint(); } } }, l));
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl harden --custom --review" }, d.profile.name),
      h("a", { href: "#/hardening/custom" }, "Custom profiles")),
    h("p", { class: "muted" }, "From " + (d.profile.source_file || "pasted text") + " \u00b7 CIS numbers read as " + d.product_name
      + ". Check each match, then use the profile. Lines marked with ? matched by number but read differently: confirm them."),
    h("div", { class: "cp-bar" }, counts, state, act), msg,
    h("div", { class: "filters", role: "group", "aria-label": "Show" }, tabs),
    body);
  paint();
}


// ---- Windows servers: build, update source, missing updates -------------------------
async function windowsPanel(hostId) {
  let d;
  try { d = await api("/admin/hosts/" + encodeURIComponent(hostId) + "/windows"); } catch (e) { return; }   // not Windows
  const h_ = d.host, miss = d.missing || [];
  const SEV = { Critical: "hr-fail", Important: "hr-error", Moderate: "hr-na", Low: "hr-na" };
  const panel = h("section", { class: "win-panel" },
    h("h2", null, "Windows Update"),
    h("div", { class: "hd-cards" },
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "OS build"), h("div", { class: "hd-card-v" }, h_.build || "\u2013"),
        h("div", { class: "muted small" }, h_.os_edition || "")),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Updates from"),
        h("div", null, h_.wu_source === "wsus" ? "WSUS" : h_.wu_source === "microsoft" ? "Microsoft Update" : "\u2013"),
        h("div", { class: "muted small" }, h_.wu_server || "")),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Missing updates"),
        h("div", { class: "hd-card-v" + (miss.length ? " hd-failed" : "") }, String(miss.length)),
        h("div", { class: "muted small" }, h_.wu_searched_at ? "searched " + timeAgo(h_.wu_searched_at) : "not searched yet")),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Reboot"),
        h("div", null, h_.reboot_required ? "Pending" : "Not needed"))),
    h_.wu_error ? h("div", { class: "form-warn" }, h("strong", null, "Last Windows Update search failed: "), h_.wu_error) : null,
    h("p", { class: "muted small" }, "Missing updates are what Windows Update reports against "
      + (h_.wu_source === "wsus" ? "your WSUS, so they are the updates WSUS has approved for this server." : "Microsoft Update.")
      + " The advisories above come from the OS build, compared with Microsoft's Security Update Guide, so they include "
      + "updates WSUS has not approved yet."),
    miss.length ? table([
      { label: "Update", cell: u => h("span", null, h("strong", null, u.kb || ""), " ", u.title) },
      { label: "Severity", nowrap: true, cell: u => u.severity ? h("span", { class: "hd-res " + (SEV[u.severity] || "hr-na") }, u.severity) : h("span", { class: "muted" }, "\u2013") },
      { label: "CVEs", num: true, cell: u => (u.cves || []).length || "" },
      { label: "Reboot", nowrap: true, cell: u => ({ always: "Yes", may: "Maybe", never: "No" })[u.reboot_behaviour] || "" },
      { label: "Size", num: true, cell: u => u.size_mb ? u.size_mb + " MB" : "" },
      { label: "Downloaded", nowrap: true, cell: u => u.downloaded ? "Yes" : "No" },
    ], miss) : h("div", { class: "empty" }, h("p", null, h_.wu_searched_at ? "Nothing missing." : "The agent has not reported yet.")),
    d.installed_kbs && d.installed_kbs.length ? h("details", { class: "win-kbs" },
      h("summary", null, "Installed updates (" + d.installed_kbs.length + ")"),
      h("p", { class: "small" }, d.installed_kbs.join(", "))) : null);
  // Installed software, with a filter
  let sw = [];
  try { sw = (await api("/admin/hosts/" + encodeURIComponent(hostId) + "/software")).software || []; } catch (e) { sw = []; }
  if (sw.length) {
    const box = h("div");
    const filt = h("input", { type: "search", placeholder: "Filter by name or publisher", "aria-label": "Filter software" });
    const paintSw = () => {
      const q = filt.value.trim().toLowerCase();
      const rows = sw.filter(x => !q || x.name.toLowerCase().includes(q) || (x.publisher || "").toLowerCase().includes(q));
      box.replaceChildren(table([
        { label: "Program", cell: x => h("strong", null, x.name) },
        { label: "Version", nowrap: true, cell: x => x.version || "\u2013" },
        { label: "Publisher", cell: x => x.publisher || "" },
        { label: "Installed", nowrap: true, cell: x => x.installed_on ? dayLabel(x.installed_on) : "" },
        { label: "Size", num: true, cell: x => x.size_mb ? x.size_mb + " MB" : "" },
        { label: "", nowrap: true, cell: x => h("span", { class: "muted small" }, x.arch || "") },
      ], rows));
    };
    filt.addEventListener("input", paintSw);
    panel.append(h("h2", null, "Installed software (" + sw.length + ")"),
      h("div", { class: "win-swbar" }, filt, h("a", { href: "#/software" }, "Across all Windows servers")), box);
    paintSw();
  }
  const view = document.getElementById("view");
  const anchor = view.querySelector(".page-head");
  if (anchor && anchor.nextSibling) anchor.parentNode.insertBefore(panel, anchor.nextSibling.nextSibling || null);
  else view.append(panel);
}

// A calendar date (2024-03-11) as "11 Mar 2024", without shifting it by time zone
function dayLabel(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || "");
  if (!m) return iso || "";
  return Number(m[3]) + " " + ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][Number(m[2]) - 1] + " " + m[1];
}

function windowsTabs(active) {
  const el = h("div", { class: "filters admin-tabs", role: "group", "aria-label": "Windows" },
    [["wsus", "WSUS"], ["installers", "Installers"]].map(([k, l]) => h("a", { class: "fbtn", href: "#/" + k, "aria-pressed": String(k === active) }, l)));
  const view = document.getElementById("view");
  if (view && !view.querySelector(".admin-tabs")) view.prepend(el);
  document.querySelectorAll("nav a[data-nav]").forEach(a => a.removeAttribute("aria-current"));
  const n = document.querySelector('nav a[data-nav="windows"]'); if (n) n.setAttribute("aria-current", "page");
}

async function renderSoftware(params) {
  const q0 = params.get("q") || "";
  const d = await api("/software?q=" + encodeURIComponent(q0));
  const search = h("input", { type: "search", value: q0, placeholder: "Program or publisher, e.g. Java, Chrome, Oracle", "aria-label": "Search software" });
  let timer = null;
  search.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => {
    location.hash = "#/software" + (search.value.trim() ? "?q=" + encodeURIComponent(search.value.trim()) : ""); }, 400); });
  const progs = d.programs || [];
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl software" }, "Software"),
      h("span", { class: "muted small" }, d.servers_reporting + " Windows server" + (d.servers_reporting === 1 ? "" : "s") + " reporting")),
    h("p", { class: "muted" }, "Programs installed on Windows servers, from Programs and Features, with every version in use "
      + "and which servers have it. Refreshed with each server's inventory, every 4 hours."),
    h("div", { class: "win-swbar" }, search),
    progs.length ? table([
      { label: "Program", cell: p => h("span", null, h("strong", null, p.name), p.publisher ? h("div", { class: "muted small" }, p.publisher) : null) },
      { label: "Versions in use", cell: p => h("div", { class: "sw-vers" }, p.versions.map(v => {
          const d_ = h("details", { class: "sw-ver" }, h("summary", null, (v.version || "no version") + " \u00b7 " + v.servers),
            h("div", { class: "small" }, v.hosts.join(", ")));
          return d_; })) },
      { label: "Servers", num: true, cell: p => p.servers },
    ], progs) : h("div", { class: "empty" }, h("p", null, q0 ? "Nothing installed matches \u201c" + q0 + "\u201d." : "No Windows server has reported its software yet.")));
  windowsTabs("software");
  search.focus(); search.setSelectionRange(search.value.length, search.value.length);
}

async function renderWsus(params) {
  const d = await api("/wsus");
  const srcs = d.sources || [], comps = d.computers || [];
  const STALE_DAYS = 7;
  const stale = c => !c.last_reported || (Date.now() - new Date(c.last_reported).getTime()) > STALE_DAYS * 86400000;
  const seenBy = {};
  comps.forEach(c => { (seenBy[c.name] = seenBy[c.name] || new Set()).add(c.source); });
  let filter = params.get("show") || "all";
  const body = h("div");
  const tabs = [["all", "All computers"], ["needs", "Needing updates"], ["stale", "Not reporting (" + STALE_DAYS + "+ days)"],
                ["errors", "With errors"], ["unenrolled", "Not in PATCH-01"]].map(([k, l]) =>
    h("button", { type: "button", "data-k": k, on: { click: () => { filter = k; paint(); } } }, l));
  function paint() {
    tabs.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === filter)));
    const rows = comps.filter(c => filter === "all" || (filter === "needs" && c.needed > 0) || (filter === "stale" && stale(c))
      || (filter === "errors" && c.failed > 0) || (filter === "unenrolled" && !c.host_id));
    body.replaceChildren(rows.length ? table([
      { label: "Computer", cell: c => h("span", null,
          c.host_id ? h("a", { href: "#/host/" + c.host_id }, h("strong", null, c.name)) : h("strong", null, c.name),
          c.host_id ? null : h("span", { class: "muted small" }, " \u00b7 not in PATCH-01"),
          seenBy[c.name].size > 1 ? h("span", { class: "muted small", title: "Listed by " + [...seenBy[c.name]].join(" and ")
            + ": usually reporting roll-up from a downstream WSUS" }, " \u00b7 also on another WSUS") : null) },
      srcs.length > 1 ? { label: "WSUS", nowrap: true, cell: c => c.source } : null,
      { label: "Groups", cell: c => (c.groups || []).join(", ") },
      { label: "Last reported", nowrap: true, cell: c => h("span", { class: stale(c) ? "hd-failed" : null }, c.last_reported ? timeAgo(c.last_reported) : "never") },
      { label: "Needed", num: true, cell: c => c.needed == null ? "" : h("span", { class: c.needed ? "hd-failed" : null }, String(c.needed)) },
      { label: "Failed", num: true, cell: c => c.failed ? h("span", { class: "hd-failed" }, String(c.failed)) : (c.failed == null ? "" : "0") },
      { label: "Pending reboot", num: true, cell: c => c.pending_reboot || (c.pending_reboot == null ? "" : "0") },
      { label: "OS", cell: c => h("span", { class: "muted small" }, c.os || "") },
    ].filter(Boolean), rows) : h("div", { class: "empty" }, h("p", null, "Nothing here.")));
  }
  const cards = srcs.map(s_ => {
    const r = s_.report || {}, sy = r.sync || {}, up = r.updates || {}, cm = r.computers || {};
    const ok = (sy.result || "").toLowerCase() === "succeeded";
    return h("div", { class: "hd-cards" },
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "WSUS"), h("div", { class: "hd-card-v" }, s_.name),
        h("div", { class: "muted small" }, (r.version ? "version " + r.version + " \u00b7 " : "") + (s_.reported_at ? "reported " + timeAgo(s_.reported_at) : "has not reported"))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Last sync"),
        h("div", { class: ok ? "hd-good" : "hd-failed" }, sy.result || "\u2013"),
        h("div", { class: "muted small" }, (sy.last_end ? timeAgo(sy.last_end) : "") + (sy.error ? " \u00b7 " + sy.error : ""))),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Security updates not approved"),
        h("div", { class: "hd-card-v" + (up.security_not_approved ? " hd-failed" : "") }, String(up.security_not_approved ?? "\u2013")),
        h("div", { class: "muted small" }, (up.approved ?? 0) + " approved in total")),
      h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Computers needing updates"),
        h("div", { class: "hd-card-v" }, String(cm.needing_updates ?? "\u2013")),
        h("div", { class: "muted small" }, (cm.total ?? 0) + " computers \u00b7 " + (cm.with_errors ?? 0) + " with errors")),
      s_.error ? h("div", { class: "form-warn" }, h("strong", null, "The last report failed on the WSUS server: "), s_.error) : null);
  });
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl wsus" }, "WSUS")),
    srcs.length ? cards : h("div", { class: "empty" }, h("p", null, "No WSUS server reports yet."),
      h("p", { class: "muted" }, "On PATCH-01: ./scripts/phase10-windows.sh --wsus-token <wsus name>. On the WSUS server, as administrator: "
        + ".\\wsus-report.ps1 -Server https://patch01.example -Pin <pin> -Token <token> -Install")),
    (d.not_in_wsus || []).length ? h("div", { class: "form-warn" }, h("strong", null, (d.not_in_wsus.length) + " Windows server(s) in PATCH-01 are unknown to WSUS: "),
      d.not_in_wsus.map(x => x.hostname).join(", "), ". They cannot receive approved updates.") : null,
    comps.length ? h("div", { class: "filters", role: "group", "aria-label": "Show" }, tabs) : null,
    comps.length ? body : null);
  if (comps.length) paint();
  windowsTabs("wsus");
}



// ---- PATCH-01's certificate ------------------------------------------------------------
async function renderCertificate(params) {
  setNav("admin");
  const d = await api("/admin/certificate");
  const cur = d.served || {};
  const certCard = (c, title) => c.error ? h("div", { class: "form-warn" }, c.error) : h("div", { class: "hd-cards" },
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, title), h("div", { class: "hd-card-v" }, c.subject),
      h("div", { class: "muted small" }, "issued by " + c.issuer + (c.self_signed ? " (self-signed)" : ""))),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Valid until"),
      h("div", { class: c.days_left < 30 ? "hd-failed" : null }, dayLabel(c.not_after)),
      h("div", { class: "muted small" }, c.days_left + " days left")),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Names"),
      h("div", { class: "small" }, (c.dns_names || []).concat(c.ip_names || []).join(", ") || "none")),
    h("div", { class: "hd-card" }, h("div", { class: "hd-card-l" }, "Pin (SHA-256)"),
      h("code", { class: "cert-pin" }, c.pin)));
  const last = (d.status || {}).last;
  const lastBox = h("div");
  const showLast = st => {
    if (!st || !st.last) { lastBox.replaceChildren(); return; }
    const l = st.last;
    const cls = l.state === "ok" ? "cert-ok" : l.state === "rolled_back" ? "cert-rb" : "cert-bad";
    lastBox.replaceChildren(h("div", { class: "cert-result " + cls },
      h("strong", null, { ok: "Done", rolled_back: "Rolled back", failed: "Not changed" }[l.state] || l.state), ": ",
      l.message, h("div", { class: "muted small" }, (l.action === "rollback" ? "Rollback" : "Install") + " by " + l.by + ", " + timeAgo(l.at))));
  };
  showLast(d.status);

  // upload
  const mode = h("select", { "aria-label": "What your CA gave you" },
    h("option", { value: "pem" }, "Certificate and key files (.crt / .pem / .cer and .key)"),
    h("option", { value: "pfx" }, "One .pfx / .p12 file with a password"));
  const fCert = h("input", { type: "file", accept: ".crt,.pem,.cer,.der" });
  const fKey = h("input", { type: "file", accept: ".key,.pem" });
  const fChain = h("input", { type: "file", accept: ".crt,.pem,.cer" });
  const fPfx = h("input", { type: "file", accept: ".pfx,.p12" });
  const pw = h("input", { type: "password", autocomplete: "off", placeholder: "Password of the .pfx, or of the key if it has one" });
  const pemBox = h("div", null,
    h("label", null, h("span", null, "Certificate"), fCert),
    h("label", null, h("span", null, "Private key"), fKey),
    h("label", null, h("span", null, "Intermediate CA (optional, if not inside the certificate file)"), fChain));
  const pfxBox = h("div", { hidden: true }, h("label", null, h("span", null, ".pfx / .p12 file"), fPfx));
  mode.addEventListener("change", () => { pemBox.hidden = mode.value !== "pem"; pfxBox.hidden = mode.value !== "pfx"; });
  const report = h("div");
  const checkBtn = h("button", { type: "button", class: "btn", on: { click: async () => {
    const fd = new FormData();
    if (mode.value === "pfx") { if (fPfx.files[0]) fd.append("pfx", fPfx.files[0]); }
    else { if (fCert.files[0]) fd.append("cert", fCert.files[0]); if (fKey.files[0]) fd.append("key", fKey.files[0]);
           if (fChain.files[0]) fd.append("chain", fChain.files[0]); }
    if (pw.value) fd.append("password", pw.value);
    checkBtn.disabled = true; report.replaceChildren(h("p", { class: "muted small" }, "Checking\u2026"));
    try {
      const res = await fetch("/api/v1/admin/certificate/check", { method: "POST", body: fd,
        headers: { ...authHeaders(), "X-Requested-With": "patch01-dashboard" } });
      const r = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(detailText(r.detail) || res.statusText);
      showCheck(r);
    } catch (e) { report.replaceChildren(h("div", { class: "form-warn" }, e.message)); }
    checkBtn.disabled = false;
  } } }, "Check");

  function showCheck(r) {
    const parts = [];
    if (r.errors && r.errors.length) parts.push(h("div", { class: "cert-result cert-bad" }, h("strong", null, "Cannot be used: "),
      h("ul", null, r.errors.map(e => h("li", null, e)))));
    if (r.warnings && r.warnings.length) parts.push(h("div", { class: "cert-result cert-rb" }, h("strong", null, "Note: "),
      h("ul", null, r.warnings.map(e => h("li", null, e)))));
    if (r.certificate) parts.push(certCard(r.certificate, "Uploaded certificate"),
      r.chain && r.chain.length ? h("p", { class: "muted small" }, "Chain: " + r.chain.map(c => c.subject).join(" \u2192 ")) : null);
    if (r.ok) {
      const old = r.pins.old || "<current pin>";
      const both = old + "," + r.pins.new;
      const short = d.names.short;
      const cmds = h("pre", { class: "cert-cmds" },
        ".\\push-agent.ps1 -Computers servers.txt -Server https://" + short + " -Pin " + both + " -Repin\n"
        + ".\\wsus-report.ps1 -Repin -Pin " + both);
      const copy = h("button", { type: "button", class: "btn-link", on: { click: () => { navigator.clipboard && navigator.clipboard.writeText(cmds.textContent); copy.textContent = "Copied"; } } }, "Copy");
      const ack = h("input", { type: "checkbox" });
      const go = h("button", { type: "button", class: "btn", disabled: true }, "Install this certificate");
      ack.addEventListener("change", () => { go.disabled = !ack.checked; });
      go.addEventListener("click", async () => {
        go.disabled = true; go.textContent = "Installing\u2026";
        try {
          const a = await apiPost("/admin/certificate/apply", { id: r.id, windows_repinned: ack.checked });
          await waitResult(a.request);
        } catch (e) { report.append(h("div", { class: "form-warn" }, e.message)); go.disabled = false; go.textContent = "Install this certificate"; }
      });
      parts.push(h("h3", null, "Before installing: Windows agents and WSUS"),
        h("p", { class: "small" }, "Windows agents and the WSUS reports trust only the current certificate. Give them both pins first, "
          + "from the jump host and on each WSUS server, so they keep working before and after the change:"),
        h("div", { class: "cert-cmdbox" }, cmds, copy),
        h("label", { class: "check" }, ack, h("span", null, "The Windows agents and WSUS servers have been given both pins")),
        h("div", { class: "form-actions" }, go,
          h("span", { class: "muted small" }, "PATCH-01 installs it, restarts its web front, checks it is served, and puts the old one back if not.")));
    }
    report.replaceChildren(...parts.filter(Boolean));
  }

  async function waitResult(reqId) {
    const t0 = Date.now();
    report.append(h("p", { class: "muted small cert-wait" }, "Waiting for PATCH-01 to install it (the console may blink while its web front restarts)\u2026"));
    while (Date.now() - t0 < 180000) {
      await new Promise(r => setTimeout(r, 3000));
      try {
        const st = await api("/admin/certificate");
        if (st.status && st.status.last && st.status.last.id === reqId) { renderCertificate(params).then(() => adminTabs("certificate")); return; }
      } catch (e) { /* the web front is restarting */ }
    }
    report.append(h("div", { class: "form-warn" }, "No answer after 3 minutes: see /var/log/patch01-cert.log on PATCH-01."));
  }

  const rb = h("button", { type: "button", class: "btn btn-quiet", on: { click: async () => {
    if (!confirm("Go back to the certificate PATCH-01 used before the last change?")) return;
    try { const a = await apiPost("/admin/certificate/rollback", {}); rb.disabled = true; await waitResult(a.request); }
    catch (e) { lastBox.replaceChildren(h("div", { class: "form-warn" }, e.message)); }
  } } }, "Roll back to the previous certificate");

  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl cert" }, "Certificate")),
    !d.status.helper_ready ? h("div", { class: "form-warn" }, h("strong", null, "The certificate helper is not installed. "),
      "Run phase3b-api.sh on PATCH-01 once; until then certificates can be checked here but not installed.") : null,
    h("h2", null, "Served now"), certCard(cur, "Certificate"), lastBox,
    h("h2", null, "Install a new certificate"),
    h("p", { class: "muted small" }, "Upload what your CA issued. It is checked first: the key matches, it is in date, it names "
      + d.names.short + " and " + d.names.fqdn + ", and the chain is complete. Nothing changes until you install it."),
    h("div", { class: "form-sec" }, h("label", null, h("span", null, "What your CA gave you"), mode), pemBox, pfxBox,
      h("label", null, h("span", null, "Password (only if needed)"), pw)),
    h("div", { class: "form-actions" }, checkBtn), report,
    h("h2", null, "Undo"), h("div", { class: "form-actions" }, rb,
      h("span", { class: "muted small" }, "The five previous certificates are kept on PATCH-01.")));
}


// ---- Software catalog: Windows installers from a share --------------------------------
async function renderInstallers(params) {
  const d = await api("/software/catalog");
  const me = getAuth().user.username;
  const rows = d.catalog || [];
  const STATE = { pending: "Waiting for a second admin", approved: "Approved", disabled: "Disabled" };
  const decide = async (id, verb) => { try { await apiPost("/admin/software/catalog/" + id + "/" + verb, {}); renderInstallers(params); }
                                       catch (e) { alert(e.message); } };
  const list = rows.length ? table([
    { label: "Software", cell: r => h("span", null, h("strong", null, r.name + " " + r.version), h("div", { class: "muted small" }, r.kind.toUpperCase() + " \u00b7 " + r.unc_path)) },
    { label: "Checks", cell: r => h("div", { class: "small" }, "SHA-256 " + r.sha256.slice(0, 12) + "\u2026",
        h("div", { class: "muted" }, r.require_signature ? "signed by " + r.publisher : "signature not required")) },
    { label: "Can", nowrap: true, cell: r => (r.actions || []).join(", ") || "\u2013" },
    { label: "State", nowrap: true, cell: r => h("span", null, STATE[r.state] || r.state,
        h("div", { class: "muted small" }, "by " + r.created_by + (r.approved_by ? ", approved by " + r.approved_by : ""))) },
    { label: "", nowrap: true, cell: r => h("span", null,
        r.state === "pending" && can("admin") && r.created_by !== me ? h("button", { type: "button", class: "btn", on: { click: () => decide(r.id, "approve") } }, "Approve") : null,
        r.state === "pending" && r.created_by === me ? h("span", { class: "muted small" }, "another admin approves") : null,
        r.state === "approved" && can("operator") ? h("a", { class: "btn btn-quiet", href: "#/changes/new?kind=software&entry=" + r.id }, "Use in a job") : null,
        r.state !== "disabled" && can("admin") ? h("button", { type: "button", class: "btn-link", on: { click: () => { if (confirm("Disable " + r.name + " " + r.version + "? Jobs can no longer use it.")) decide(r.id, "disable"); } } }, "Disable") : null) },
  ], rows) : h("div", { class: "empty" }, h("p", null, "No installers registered yet."));

  let form = null;
  if (can("admin")) {
    const f = {};
    const inp = (k, ph, type) => (f[k] = h("input", { type: type || "text", placeholder: ph || "" }));
    const kind = h("select", null, h("option", { value: "msi" }, "MSI"), h("option", { value: "exe" }, "EXE"));
    const sig = h("input", { type: "checkbox", checked: true });
    const exeOnly = h("div", { hidden: true },
      h("label", null, h("span", null, "Silent install options"), inp("install_args", "/S  or  /quiet /norestart")),
      h("label", null, h("span", null, "Silent uninstall options (optional; without them it cannot be removed)"), inp("uninstall_args", "/S")));
    const msiOnly = h("div", null, h("label", null, h("span", null, "MSI product code"), inp("product_code", "{XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX}")));
    kind.addEventListener("change", () => { exeOnly.hidden = kind.value !== "exe"; msiOnly.hidden = kind.value !== "msi"; });
    const msg = h("div");
    form = h("details", { class: "form-sec" }, h("summary", null, "Register an installer"),
      h("p", { class: "muted small" }, "The share must be readable only with the account you give when a job runs. "
        + "Get the fingerprint on the file itself: Get-FileHash -Algorithm SHA256 <file>. "
        + "The publisher is the signer's certificate subject: (Get-AuthenticodeSignature <file>).SignerCertificate.Subject"),
      h("label", null, h("span", null, "Name"), inp("name", "7-Zip")),
      h("label", null, h("span", null, "Version"), inp("version", "23.01")),
      h("label", null, h("span", null, "Type"), kind),
      h("label", null, h("span", null, "Share path"), inp("unc_path", "\\\\fileserver\\software$\\7zip\\7z2301-x64.msi")),
      h("label", null, h("span", null, "SHA-256"), inp("sha256", "64 hexadecimal characters")),
      h("label", { class: "check" }, sig, h("span", null, "Must carry a valid signature from this publisher")),
      h("label", null, h("span", null, "Publisher (certificate subject)"), inp("publisher", "CN=Vendor Ltd, O=Vendor Ltd, C=GB")),
      msiOnly, exeOnly,
      h("label", null, h("span", null, "Name in Programs and Features (or its start)"), inp("detect_name", "7-Zip")),
      h("label", null, h("span", null, "Notes"), inp("notes", "why, ticket")),
      h("div", { class: "form-actions" }, h("button", { type: "button", class: "btn", on: { click: async () => {
        const body = { kind: kind.value, require_signature: sig.checked };
        Object.keys(f).forEach(k => { body[k] = f[k].value.trim() || null; });
        try { await apiPost("/admin/software/catalog", body); renderInstallers(params); }
        catch (e) { msg.replaceChildren(h("div", { class: "form-warn" }, e.message)); }
      } } }, "Register"), h("span", { class: "muted small" }, "A different admin must approve it before any job can use it.")), msg);
  }
  render(h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl software catalog" }, "Installers")),
    h("p", { class: "muted" }, "Windows installers on a share, each checked by SHA-256 and signature on every server before it runs. "
      + "Jobs need the share's credential at run time: without it, servers cannot read the installers."),
    list, form);
  windowsTabs("installers");
}

async function renderNewSoftware(params) {
  const [cat, comp] = await Promise.all([api("/software/catalog"), api("/admin/compliance")]);
  const entries = (cat.catalog || []).filter(e => e.state === "approved");
  if (!entries.length) return render(h("div", { class: "empty" }, h("p", null, "No approved installers yet: see Windows \u203a Installers.")));
  const sel = h("select", null, entries.map(e => h("option", { value: e.id }, e.name + " " + e.version + " (" + e.kind.toUpperCase() + ")")));
  if (params.get("entry")) sel.value = params.get("entry");
  const action = h("select");
  const fillActions = () => { const e = entries.find(x => x.id === sel.value) || entries[0];
    action.replaceChildren(...e.actions.map(a => h("option", { value: a }, { install: "Install", upgrade: "Upgrade", uninstall: "Remove" }[a]))); };
  sel.addEventListener("change", fillActions); fillActions();
  const hosts = (comp.hosts || []).filter(x => x.host_status !== "decommissioned" && x.os_id === "windows");
  const boxes = new Map();
  const list = h("div", { class: "pick-list" }, hosts.length ? hosts.map(x => {
    const cb = h("input", { type: "checkbox", value: x.host_id }); boxes.set(x.host_id, cb);
    return h("label", { class: "pick" }, cb, h("span", { class: "pick-name" }, x.hostname), h("span", { class: "muted" }, osLabel(x.os_id, x.os_version)), agentMark(x.agent_state));
  }) : h("p", { class: "muted" }, "No Windows servers enrolled."));
  const reboot = h("select", null, h("option", { value: "if_required" }, "Only if required"), h("option", { value: "never" }, "Never, just flag it"), h("option", { value: "always" }, "Always"));
  const snap = h("select", null, h("option", { value: "none" }, "No snapshot"), h("option", { value: "remove_on_success" }, "Snapshot first, remove if it succeeds"), h("option", { value: "keep" }, "Snapshot first, keep it"));
  const win = windowFields();
  const title = h("input", { type: "text", placeholder: "Install 7-Zip 23.01 on the test servers" });
  const reason = h("textarea", { rows: "2", placeholder: "Why. Kept in the record." });
  const err = h("p", { class: "explain-error", hidden: true });
  const go = h("button", { type: "button", class: "btn", on: { click: async () => {
    err.hidden = true;
    try {
      const r = await apiPost("/changes", { kind: "software", title: title.value.trim() || null, reason: reason.value.trim(),
        targets: [...boxes.entries()].filter(([, cb]) => cb.checked).map(([id]) => ({ host_id: id })),
        params: { catalog_id: sel.value, action: action.value, reboot: reboot.value, snapshot: snap.value, check_services: true },
        ...win.get() });
      location.hash = "#/change/" + r.id;
    } catch (e) { err.textContent = e.message; err.hidden = false; }
  } } }, "Submit for approval");
  render(h("div", { class: "page-head" }, h("h1", null, "New software job"), h("a", { href: "#/changes", class: "small" }, "All changes")),
    h("div", { class: "form-sec" }, h("label", null, h("span", null, "Software"), sel), h("label", null, h("span", null, "Action"), action)),
    h("h2", null, "Servers"), list,
    h("div", { class: "form-sec" }, h("label", null, h("span", null, "Snapshot"), snap), h("label", null, h("span", null, "Reboot"), reboot)),
    win.el, h("div", { class: "form-sec" }, h("label", null, h("span", null, "Title"), title), h("label", null, h("span", null, "Reason"), reason)),
    h("p", { class: "muted small" }, "After approval, the job waits at its install step until someone enters the share credential on its page. "
      + "Each server then checks the installer's SHA-256 and signature before running it."),
    h("div", { class: "form-actions" }, go), err);
}

// On a software change's page: give, or discard, the share credential for this job
async function softwareCredentialPanel(changeId) {
  let st;
  try { st = await api("/changes/" + encodeURIComponent(changeId) + "/credential"); } catch (e) { return; }   // not a software change
  const box = h("section", { class: "cred-panel" });
  const view = document.getElementById("view");
  const head = view.querySelector(".page-head");
  if (head && head.nextSibling) head.parentNode.insertBefore(box, head.nextSibling); else view.append(box);
  const paint = s => {
    if (!s.vault_ready) { box.replaceChildren(h("div", { class: "form-warn" }, "The credential store is not set up on PATCH-01 (phase3b-api.sh).")); return; }
    if (s.held) {
      box.replaceChildren(h("div", { class: "cert-result cert-ok" }, h("strong", null, "Share credential held for this job"),
        " \u00b7 entered by " + s.by + ", gone when the job ends or at " + new Date(s.expires_at * 1000).toLocaleTimeString(),
        can("operator") ? h("button", { type: "button", class: "btn-link", on: { click: async () => {
          if (!confirm("Discard the credential? Servers not yet installed will wait for a new one.")) return;
          await apiSend("DELETE", "/changes/" + encodeURIComponent(changeId) + "/credential"); paint(await api("/changes/" + encodeURIComponent(changeId) + "/credential"));
        } } }, "Discard now") : null));
      return;
    }
    if (!can("operator")) { box.replaceChildren(h("div", { class: "cert-result cert-rb" }, "Waiting for an operator to enter the share credential.")); return; }
    const u = h("input", { type: "text", autocomplete: "off", placeholder: "DOMAIN\\user or user@domain" });
    const pw = h("input", { type: "password", autocomplete: "new-password" });
    const msg = h("span", { class: "small" });
    box.replaceChildren(h("div", { class: "cert-result cert-rb" }, h("strong", null, "Share credential needed"),
      h("p", { class: "small" }, "Servers wait at the install step until it is entered. It is kept encrypted in memory on PATCH-01 for this job only, "
        + "each server fetches it once, and it is never stored, logged or shown again."),
      h("div", { class: "cred-row" }, u, pw, h("button", { type: "button", class: "btn", on: { click: async () => {
        try {
          await apiPost("/changes/" + encodeURIComponent(changeId) + "/credential", { username: u.value.trim(), password: pw.value, hours: 6 });
          pw.value = ""; paint(await api("/changes/" + encodeURIComponent(changeId) + "/credential"));
        } catch (e) { pw.value = ""; msg.textContent = e.message; }
      } } }, "Release the job")), msg));
  };
  paint(st);
}


// ---- Live log: a small floating terminal with agent output and change steps --------
// Lines come from servers, so they are untrusted text: inserted with textContent
// only, never as HTML.
const LiveLog = (() => {
  const KEY = "patch01.livelog";
  let el = null, body = null, scopeEl = null, timer = null, paused = false;
  let afterLog = 0, afterEvent = 0, scopeKey = "";
  const MAX_LINES = 800;
  const pad = n => String(n).padStart(2, "0");
  const hhmmss = iso => { const d = new Date(iso); return pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds()); };
  function scope() {
    const m = /^#\/(change|host)\/([0-9a-f-]{36})/.exec(location.hash || "");
    return m ? { kind: m[1], id: m[2] } : null;
  }
  function line(cls, parts) {
    const row = document.createElement("div"); row.className = "ll-row " + cls;
    parts.forEach(([c, text]) => { const sp = document.createElement("span"); sp.className = c; sp.textContent = text; row.append(sp); });
    body.append(row);
    while (body.childNodes.length > MAX_LINES) body.removeChild(body.firstChild);
  }
  async function poll() {
    if (!el || paused || !getAuth()) return;
    const sc = scope(); const key = sc ? sc.kind + ":" + sc.id : "all";
    if (key !== scopeKey) {                   // a new page: start that page's view afresh
      scopeKey = key; afterLog = 0; afterEvent = 0; body.replaceChildren();
      scopeEl.textContent = sc ? (sc.kind === "change" ? "this change" : "this server") : "all servers and changes";
    }
    let q = "/console/stream?after_log=" + afterLog + "&after_event=" + afterEvent;
    if (sc) q += "&" + sc.kind + "=" + sc.id;
    let d;
    try { d = await api(q); } catch (e) { return; }
    const items = [];
    (d.logs || []).forEach(l => { items.push({ at: l.at, kind: "log", l }); afterLog = Math.max(afterLog, l.id); });
    (d.events || []).forEach(e => { items.push({ at: e.at, kind: "ev", e }); afterEvent = Math.max(afterEvent, e.id); });
    items.sort((a, b) => new Date(a.at) - new Date(b.at));
    const stick = body.scrollTop + body.clientHeight >= body.scrollHeight - 8;
    items.forEach(it => {
      if (it.kind === "log") {
        const lv = (it.l.level || "INFO").toUpperCase();
        line("ll-" + lv.toLowerCase(), [["ll-t", hhmmss(it.at) + " "], ["ll-h", it.l.hostname + " "], ["ll-lv", lv.padEnd(5) + " "], ["ll-m", it.l.line]]);
      } else {
        const ok = it.e.ok === true ? "ll-ok" : it.e.ok === false ? "ll-error" : "ll-info";
        line(ok, [["ll-t", hhmmss(it.at) + " "], ["ll-h", "CHG-" + String(it.e.number).padStart(6, "0") + " "], ["ll-lv", (it.e.actor || "").padEnd(5) + " "], ["ll-m", it.e.message || it.e.event]]);
      }
    });
    if (stick) body.scrollTop = body.scrollHeight;
  }
  function drag(handle) {
    handle.addEventListener("mousedown", ev => {
      if (ev.target.tagName === "BUTTON") return;
      const r = el.getBoundingClientRect(), dx = ev.clientX - r.left, dy = ev.clientY - r.top;
      const move = m => { el.style.left = Math.max(0, Math.min(window.innerWidth - 80, m.clientX - dx)) + "px";
                          el.style.top = Math.max(0, Math.min(window.innerHeight - 40, m.clientY - dy)) + "px";
                          el.style.right = "auto"; el.style.bottom = "auto"; };
      const up = () => { document.removeEventListener("mousemove", move); document.removeEventListener("mouseup", up); };
      document.addEventListener("mousemove", move); document.addEventListener("mouseup", up); ev.preventDefault();
    });
  }
  function open() {
    if (el) return;
    el = document.createElement("section"); el.className = "livelog"; el.setAttribute("aria-label", "Live log");
    const head = document.createElement("div"); head.className = "ll-head";
    const title = document.createElement("strong"); title.textContent = ">_ Live log";
    scopeEl = document.createElement("span"); scopeEl.className = "ll-scope";
    const pauseB = document.createElement("button"); pauseB.type = "button"; pauseB.textContent = "Pause";
    pauseB.onclick = () => { paused = !paused; pauseB.textContent = paused ? "Resume" : "Pause"; if (!paused) poll(); };
    const clearB = document.createElement("button"); clearB.type = "button"; clearB.textContent = "Clear";
    clearB.onclick = () => body.replaceChildren();
    const closeB = document.createElement("button"); closeB.type = "button"; closeB.textContent = "\u00d7"; closeB.title = "Close";
    closeB.onclick = close;
    head.append(title, scopeEl, pauseB, clearB, closeB);
    body = document.createElement("div"); body.className = "ll-body"; body.setAttribute("role", "log"); body.setAttribute("aria-live", "polite");
    el.append(head, body); document.body.append(el); drag(head);
    scopeKey = ""; poll(); timer = setInterval(poll, 3000);
    sessionStorage.setItem(KEY, "open"); setBtn(true);
  }
  function close() {
    if (!el) return;
    clearInterval(timer); el.remove(); el = null; sessionStorage.removeItem(KEY); setBtn(false);
  }
  function setBtn(on) { const b = document.getElementById("logbtn"); if (b) b.setAttribute("aria-pressed", String(on)); }
  function init() {
    const b = document.getElementById("logbtn"); if (!b || b.dataset.wired) return;
    b.dataset.wired = "1"; b.addEventListener("click", () => (el ? close() : open()));
    if (sessionStorage.getItem(KEY) === "open") open();
    window.addEventListener("hashchange", () => { if (el) poll(); });
  }
  return { init, open, close };
})();
document.addEventListener("DOMContentLoaded", () => setTimeout(() => LiveLog.init(), 0));


// ---- Inventory: Assets and Software, two pages ---------------------------------------
const INV_CAT = { server: "Servers", client: "Clients", appliance: "Appliances", unknown: "Unknown" };
const INV_SRC = { agent: "Agent", vcenter: "vCenter", wsus: "WSUS" };

function invTabs(active) {
  const el = h("div", { class: "filters admin-tabs", role: "group", "aria-label": "Inventory" },
    [["assets", "Assets"], ["software-inventory", "Software"]].map(([k, l]) =>
      h("a", { class: "fbtn", href: "#/" + k, "aria-pressed": String(k === active) }, l)));
  const view = document.getElementById("view");
  if (view && !view.querySelector(".admin-tabs")) view.prepend(el);
  document.querySelectorAll("nav a[data-nav]").forEach(a => a.removeAttribute("aria-current"));
  const n = document.querySelector('nav a[data-nav="inventory"]'); if (n) n.setAttribute("aria-current", "page");
}

// CSV for spreadsheets. A cell starting with = + - @ is prefixed with ' so a
// spreadsheet never runs it as a formula (the data comes from servers).
function inventoryCsv(name, header, rows) {
  const cell = v => {
    let t = v == null ? "" : String(v);
    if (/^[=+\-@\t\r]/.test(t)) t = "'" + t;
    return '"' + t.replace(/"/g, '""') + '"';
  };
  const text = [header, ...rows].map(r => r.map(cell).join(",")).join("\r\n");
  const url = URL.createObjectURL(new Blob(["﻿" + text], { type: "text/csv;charset=utf-8" }));
  const a = h("a", { href: url, download: name }); document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

async function renderAssets(params) {
  const d = await api("/inventory/assets");
  const all = d.assets || [];
  let cat = params.get("cat") || "all", src = "any", noAgent = false, q = "";
  const MAX = 1000;
  const cards = h("div", { class: "hd-cards inv-cards" }, Object.keys(INV_CAT).map(c => {
    const s = d.summary[c] || { total: 0, managed: 0, unmanaged: 0 };
    return h("button", { type: "button", class: "hd-card inv-card", "data-c": c, on: { click: () => { cat = cat === c ? "all" : c; paint(); } } },
      h("div", { class: "hd-card-l" }, INV_CAT[c]), h("div", { class: "hd-card-v" }, String(s.total)),
      h("div", { class: "muted small" }, s.managed + " with an agent · " + s.unmanaged + " without"));
  }));
  const srcSel = h("select", { "aria-label": "Seen by" }, h("option", { value: "any" }, "Seen by any source"),
    Object.entries(INV_SRC).map(([k, l]) => h("option", { value: k }, "Seen by " + l)));
  const noAg = h("input", { type: "checkbox" });
  const search = h("input", { type: "search", placeholder: "Name, OS or IP", "aria-label": "Search assets" });
  const countEl = h("span", { class: "muted small" });
  const box = h("div");
  srcSel.addEventListener("change", () => { src = srcSel.value; paint(); });
  noAg.addEventListener("change", () => { noAgent = noAg.checked; paint(); });
  search.addEventListener("input", () => { q = search.value.trim().toLowerCase(); paint(); });
  let shown = [];
  function paint() {
    cards.querySelectorAll(".inv-card").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.c === cat)));
    shown = all.filter(a => (cat === "all" || a.category === cat) && (src === "any" || a.sources.includes(src))
      && (!noAgent || !a.managed)
      && (!q || a.name.toLowerCase().includes(q) || (a.os || "").toLowerCase().includes(q) || a.ips.some(ip => ip.includes(q))));
    countEl.textContent = shown.length + " of " + all.length + (shown.length > MAX ? " (first " + MAX + " shown; narrow the search)" : "");
    box.replaceChildren(shown.length ? table([
      { label: "Name", cell: a => a.agent && routeAllowed("host") ? h("a", { href: "#/host/" + a.agent.host_id }, h("strong", null, a.name)) : h("strong", null, a.name) },
      { label: "Type", nowrap: true, cell: a => h("span", { title: a.category_reason }, INV_CAT[a.category].replace(/s$/, "")) },
      { label: "Operating system", cell: a => h("span", null, a.os || "–", a.os_from ? h("span", { class: "muted small" }, " · from " + INV_SRC[a.os_from]) : null) },
      { label: "IP", nowrap: true, mono: true, cell: a => a.ips.slice(0, 2).join(", ") },
      { label: "Seen by", nowrap: true, cell: a => h("span", { class: "inv-srcs" }, a.sources.map(x => h("span", { class: "inv-src inv-" + x }, INV_SRC[x]))) },
      { label: "Where", cell: a => h("span", { class: "small" },
          a.vm ? [a.vm.vcenter, a.vm.cluster].filter(Boolean).join(" / ") : a.esxi ? [a.esxi.vcenter, a.esxi.cluster].filter(Boolean).join(" / ")
          : a.wsus ? "WSUS " + a.wsus.source : "") },
      { label: "Power", nowrap: true, cell: a => a.vm && a.vm.power ? a.vm.power.replace("powered", "").replace(/^On$/i, "on").replace(/^Off$/i, "off") : "" },
      { label: "Agent", nowrap: true, cell: a => a.agent ? h("span", { class: "small" }, a.agent.version || "yes")
          : (a.category === "server" ? h("span", { class: "hd-failed small" }, "none") : h("span", { class: "muted small" }, "–")) },
      { label: "Last seen", nowrap: true, cell: a => a.last_seen ? timeAgo(a.last_seen) : "" },
    ], shown.slice(0, MAX)) : h("div", { class: "empty" }, h("p", null, "No assets match.")));
  }
  const exportBtn = h("button", { type: "button", class: "btn btn-quiet", on: { click: () => inventoryCsv("assets.csv",
    ["name", "type", "type_reason", "os", "ips", "seen_by", "vcenter", "cluster", "power", "wsus", "agent_version", "last_seen"],
    shown.map(a => [a.name, a.category, a.category_reason, a.os, a.ips.join(" "), a.sources.join(" "), a.vm ? a.vm.vcenter : (a.esxi ? a.esxi.vcenter : ""),
                    a.vm ? a.vm.cluster : (a.esxi ? a.esxi.cluster : ""), a.vm ? a.vm.power : "", a.wsus ? a.wsus.source : "",
                    a.agent ? a.agent.version : "", a.last_seen || ""])) } }, "Export CSV");
  const sc = d.sources || {};
  render(h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl inventory assets" }, "Assets")),
    h("p", { class: "muted small" }, "Every machine PATCH-01 knows of, merged by name from " + sc.agents + " agents, " + sc.vms + " VMs and "
      + sc.esxi + " ESXi hosts in vCenter, and " + sc.wsus + " WSUS computers. The type comes from the operating system; hover it for the reason."),
    cards,
    h("div", { class: "inv-bar" }, search, srcSel, h("label", { class: "check" }, noAg, h("span", null, "Without an agent only")), countEl, exportBtn),
    box);
  paint();
  invTabs("assets");
}

async function renderSoftwareInventory(params) {
  let platform = params.get("platform") === "linux" ? "linux" : "windows";
  let cat = params.get("cat") || "server", q = params.get("q") || "";
  const box = h("div"); const head = h("p", { class: "muted small" });
  const platBtns = [["windows", "Windows programs"], ["linux", "Linux packages"]].map(([k, l]) =>
    h("button", { type: "button", "data-k": k, on: { click: () => { platform = k; load(); } } }, l));
  const catBtns = [["server", "Servers"], ["client", "Clients"], ["all", "All"]].map(([k, l]) =>
    h("button", { type: "button", "data-k": k, on: { click: () => { cat = k; load(); } } }, l));
  const search = h("input", { type: "search", value: q, placeholder: "Program, package or publisher", "aria-label": "Search software" });
  let timer = null, last = null;
  search.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => { q = search.value.trim(); load(); }, 350); });
  const exportBtn = h("button", { type: "button", class: "btn btn-quiet", on: { click: () => {
    if (!last) return;
    const rows = [];
    last.programs.forEach(p => p.versions.forEach(v => rows.push([p.name, p.publisher || "", v.version, v.machines, v.hosts.join(" ")])));
    inventoryCsv("software-" + platform + "-" + cat + ".csv", ["program", "publisher", "version", "machines", "hosts"], rows);
  } } }, "Export CSV");
  async function load() {
    platBtns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === platform)));
    catBtns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === cat)));
    let d;
    try { d = await api("/inventory/software?platform=" + platform + "&category=" + cat + "&q=" + encodeURIComponent(q)); }
    catch (e) { box.replaceChildren(h("div", { class: "form-warn" }, e.message)); return; }
    last = d;
    head.textContent = d.programs.length + " " + (platform === "windows" ? "programs" : "packages") + " on " + d.machines + " "
      + (cat === "all" ? "" : INV_CAT[cat].toLowerCase() + " ") + "with an agent. vCenter and WSUS report machines, not installed software, "
      + "so machines without an agent are not here (see Assets)." + (d.truncated ? " The list is cut at 3000 versions: search to narrow it." : "");
    box.replaceChildren(d.programs.length ? table([
      { label: platform === "windows" ? "Program" : "Package", cell: p => h("span", null, h("strong", null, p.name), p.publisher ? h("div", { class: "muted small" }, p.publisher) : null) },
      { label: "Versions in use", cell: p => h("div", { class: "sw-vers" }, p.versions.map(v =>
          h("details", { class: "sw-ver" }, h("summary", null, (v.version || "no version") + " · " + v.machines),
            h("div", { class: "small" }, v.hosts.join(", "))))) },
      { label: "Machines", num: true, cell: p => p.machines },
    ], d.programs) : h("div", { class: "empty" }, h("p", null, q ? "Nothing matches “" + q + "”." : "No software reported yet.")));
  }
  render(h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl inventory software" }, "Software")),
    h("div", { class: "inv-bar" }, h("div", { class: "filters", role: "group", "aria-label": "Platform" }, platBtns),
      h("div", { class: "filters", role: "group", "aria-label": "Type" }, catBtns), search, exportBtn),
    head, box);
  await load();
  invTabs("software-inventory");
}
