/* Cyber-Secure: the dashboard, the CVE news boards, the sign-in welcome and
 * the CVE feed settings.
 *
 * Everything shown is text from the API, written with textContent (the h()
 * helper); nothing is inserted as HTML. Links to CVE pages are built by the
 * API, always to the vendor's own site, and open with no referrer.
 */

/* ---- brand ---------------------------------------------------------------- */

const PORTAL = "Cyber-Secure";
let brandInfo = null;

async function loadBrand() {
  if (brandInfo) return brandInfo;
  try {
    const r = await fetch("/api/v1/public/brand", { headers: { Accept: "application/json" } });
    brandInfo = r.ok ? await r.json() : { has_logo: false, has_logo_white: false };
  } catch (e) { brandInfo = { has_logo: false, has_logo_white: false }; }
  return brandInfo;
}

function isDarkTheme() {
  const t = document.documentElement.getAttribute("data-theme");
  return t === "dark" || t === "hacker";
}

/* The logo for a dark background (the top bar is dark in every theme). */
function logoImg(onDark, cls) {
  const b = brandInfo || {};
  if (!b.has_logo && !b.has_logo_white) return null;
  const variant = onDark && b.has_logo_white ? "white" : "main";
  const img = h("img", { class: cls + (onDark && !b.has_logo_white ? " logo-chip" : ""),
                         src: "/api/v1/public/logo?variant=" + variant, alt: "", decoding: "async" });
  img.addEventListener("error", () => img.remove());
  return img;
}

async function applyBrand() {
  await loadBrand();
  document.title = PORTAL;
  const a = document.querySelector(".top .brand");
  if (a && !a.dataset.branded) {
    a.dataset.branded = "1";
    const img = logoImg(true, "brand-logo-top");
    a.replaceChildren(...[img, h("span", { class: "brand-name" }, PORTAL)].filter(Boolean));
    a.classList.toggle("has-logo", !!img);
    a.title = PORTAL;
    a.setAttribute("aria-label", PORTAL + " dashboard");
  }
}

/* ---- donuts --------------------------------------------------------------- */

const SVGNS = "http://www.w3.org/2000/svg";
function svg(tag, attrs, ...kids) {
  const el = document.createElementNS(SVGNS, tag);
  Object.entries(attrs || {}).forEach(([k, v]) => { if (v !== null && v !== undefined) el.setAttribute(k, String(v)); });
  kids.flat().forEach(k => { if (k) el.append(k instanceof Node ? k : document.createTextNode(String(k))); });
  return el;
}

/* segs: [{label, value, cls, href?, note?}]. Each colour comes from a class,
 * so the theme decides it; the legend always names every segment, so colour
 * never carries meaning on its own. */
function donut(title, segs, opts = {}) {
  const total = segs.reduce((a, s) => a + (Number(s.value) || 0), 0);
  const R = 52, SW = 14, C = 2 * Math.PI * R, GAP = total && segs.filter(s => s.value > 0).length > 1 ? 2.5 : 0;
  const ring = svg("g", { transform: "rotate(-90 70 70)" },
    svg("circle", { cx: 70, cy: 70, r: R, class: "dn-track", "stroke-width": SW, fill: "none" }));
  const tip = h("div", { class: "dn-tip", role: "status", "aria-live": "polite" });
  let start = 0;
  const shown = [];
  segs.forEach((s, i) => {
    const v = Number(s.value) || 0;
    if (!total || v <= 0) return;
    const len = Math.max(0.8, (v / total) * C - GAP);
    const pct = Math.round((v / total) * 100);
    const arc = svg("circle", {
      cx: 70, cy: 70, r: R, fill: "none", "stroke-width": SW, class: "dn-seg " + s.cls,
      "stroke-dasharray": "0 " + C, "stroke-dashoffset": -start, "data-len": len, "data-c": C, tabindex: 0,
      role: "img", "aria-label": s.label + ": " + v + " (" + pct + "%)" },
      svg("title", null, s.label + ": " + v + " (" + pct + "%)"));
    const show = () => { tip.textContent = s.label + ": " + v + " (" + pct + "%)" + (s.note ? " · " + s.note : ""); };
    arc.addEventListener("mouseenter", show);
    arc.addEventListener("focus", show);
    arc.addEventListener("mouseleave", () => { tip.textContent = ""; });
    if (s.href) arc.addEventListener("click", () => { location.hash = s.href; });
    if (s.href) arc.classList.add("dn-link");
    ring.append(arc);
    shown.push(arc);
    start += (v / total) * C;
  });
  const centre = svg("text", { x: 70, y: 68, "text-anchor": "middle", class: "dn-total" },
    opts.centre !== undefined ? opts.centre : String(total));
  const sub = svg("text", { x: 70, y: 88, "text-anchor": "middle", class: "dn-sub" },
    opts.centreLabel || (total ? "total" : "no data yet"));
  const pic = svg("svg", { viewBox: "0 0 140 140", class: "dn-svg", "aria-hidden": "true", focusable: "false" }, ring, centre, sub);
  const legend = h("ul", { class: "dn-legend" }, segs.map(s => {
    const v = Number(s.value) || 0;
    const label = h("span", { class: "dn-l", title: s.label }, s.label);
    return h("li", { class: v ? null : "dn-zero" },
      h("span", { class: "dn-key " + s.cls, "aria-hidden": "true" }),
      s.href ? h("a", { href: s.href }, label) : label,
      h("span", { class: "dn-v" }, String(v)),
      h("span", { class: "dn-p" }, total ? Math.round((v / total) * 100) + "%" : ""));
  }));
  // Draw the arcs once they are in the page, so they sweep in
  requestAnimationFrame(() => requestAnimationFrame(() => shown.forEach(a => {
    a.setAttribute("stroke-dasharray", a.dataset.len + " " + (Number(a.dataset.c) - Number(a.dataset.len)));
  })));
  return h("section", { class: "dn-card", "aria-label": title + ": " + segs.map(s => s.label + " " + (s.value || 0)).join(", ") },
    h("h2", { class: "dn-h" }, title),
    opts.caption ? h("p", { class: "dn-cap" }, opts.caption) : null,
    h("div", { class: "dn-body" }, h("div", { class: "dn-pic" }, pic, tip), legend));
}

/* ---- news board ------------------------------------------------------------ */

const FEED_NAME = { nist: "NIST NVD", msrc: "Microsoft", redhat: "Red Hat" };
const SEV_CLASS = { critical: "sv-crit", high: "sv-high", important: "sv-high", medium: "sv-med", moderate: "sv-med", low: "sv-low" };

function sevChip(sev, cvss) {
  const s = (sev || "").toLowerCase();
  return h("span", { class: "sv " + (SEV_CLASS[s] || "sv-low") },
    (s ? s.charAt(0).toUpperCase() + s.slice(1) : "Unrated") + (cvss !== null && cvss !== undefined ? " " + Number(cvss).toFixed(1) : ""));
}

function safeVendorUrl(u) {
  // Only the three vendors' own sites, over HTTPS
  return /^https:\/\/(nvd\.nist\.gov|msrc\.microsoft\.com|access\.redhat\.com)\//.test(u || "") ? u : null;
}

function newsItem(it, opts = {}) {
  const url = safeVendorUrl(it.url);
  const id = url ? h("a", { href: url, target: "_blank", rel: "noopener noreferrer", class: "nw-id" }, it.cve_id)
                 : h("span", { class: "nw-id" }, it.cve_id);
  const when = it.published ? new Date(it.published) : null;
  return h("li", { class: "nw-item" + (it.exploited ? " nw-kev" : "") },
    h("div", { class: "nw-top" },
      sevChip(it.severity, it.cvss), id,
      opts.source ? h("span", { class: "nw-src" }, FEED_NAME[it.source] || it.source) : null,
      it.exploited ? h("span", { class: "nw-flag" }, "0-day") : null,
      h("time", { class: "nw-when", datetime: it.published || "" }, when ? when.toLocaleDateString(undefined, { day: "numeric", month: "short" }) : "")),
    h("p", { class: "nw-title" }, it.title || ""),
    (it.matched && it.matched.length) || it.servers_affected ? h("div", { class: "nw-tags" },
      (it.matched || []).map(m => h("span", { class: "nw-tag" }, m)),
      it.servers_affected ? h("span", { class: "nw-tag nw-hit" },
        it.servers_affected === 1 ? "1 of your servers" : it.servers_affected + " of your servers") : null) : null);
}

/* ---- the dashboard ---------------------------------------------------------- */

const OS_CLASSES = ["c-cat1", "c-cat2", "c-cat3", "c-cat4", "c-cat5", "c-cat6"];

/* ---- modules and who may open them ------------------------------------------ */

const MODULES = [
  { key: "patch", label: "Patch Dashboard", href: "#/dashboard",
    desc: "Servers, patches, CVEs, changes and hardening" },
  { key: "inventory", label: "Asset & Inventory", href: "#/assets",
    desc: "Every machine and its software, from agents, vCenter and WSUS" },
  { key: "lifecycle", label: "Software Lifecycle", href: "#/installers",
    desc: "Approved installers, software installs and removals" },
];
const ALL_MODULES = MODULES.map(m => m.key);

/* The console only shows and hides; the API refuses what a user may not
 * open, whatever the browser does. */
function myModules() {
  const a = getAuth();
  if (!a) return [];
  if (a.user.role === "admin") return ALL_MODULES.slice();
  return Array.isArray(a.user.modules) ? a.user.modules.filter(m => ALL_MODULES.includes(m)) : [];
}
function hasModule(...keys) { const mine = myModules(); return keys.some(k => mine.includes(k)); }

// Which modules each page belongs to (any one of them opens it)
const ROUTE_MODULES = {
  dashboard: ["patch"], impact: ["patch"], hosts: ["patch"], host: ["patch"], agents: ["patch"],
  advisories: ["patch"], hardening: ["patch"], assess: ["patch"], wsus: ["patch"],
  vmware: ["patch", "inventory"], assets: ["inventory"], "software-inventory": ["inventory"], software: ["inventory"],
  installers: ["lifecycle"], changes: ["patch", "lifecycle"], change: ["patch", "lifecycle"],
  activity: ["patch", "inventory", "lifecycle"],
};

function routeAllowed(first) {
  const need = ROUTE_MODULES[first];
  return !need || hasModule(...need);
}

function applyModuleNav() {
  document.querySelectorAll("nav a[data-modules]").forEach(el => {
    const need = el.dataset.modules.split(",");
    const allowed = hasModule(...need) && (!el.dataset.minRole || can(el.dataset.minRole));
    el.hidden = !allowed;
  });
}

let meCheckedAt = 0;
/* Pick up access an admin changed while this user is signed in. */
async function refreshMe(force) {
  const a = getAuth();
  if (!a || (!force && Date.now() - meCheckedAt < 60000 && Array.isArray(a.user.modules))) return;
  meCheckedAt = Date.now();
  try {
    const me = await api("/auth/me");
    const s = getAuth();
    if (!s) return;
    const changed = JSON.stringify(s.user.modules) !== JSON.stringify(me.modules) || s.user.role !== me.role;
    s.user.modules = me.modules; s.user.role = me.role;
    setSession(s);
    if (changed) applyModuleNav();
  } catch (e) { /* the next page load tries again */ }
}

function noAccess(first) {
  const mods = (ROUTE_MODULES[first] || []).map(k => (MODULES.find(m => m.key === k) || {}).label).filter(Boolean);
  render(h("div", { class: "empty" },
    h("h2", null, "No access"),
    h("p", null, "This page is part of " + mods.join(" or ") + ". Your account does not have access to it; "
      + "ask an admin to grant it under Admin, Access."),
    h("p", null, h("a", { href: "#/" }, "Back to the home page"))));
}

/* The three module buttons: lit when the user may open the module, grey
 * when not. Before sign-in they are all lit and lead to the sign-in form. */
function moduleButtons(opts = {}) {
  const signedIn = !!getAuth();
  return h("div", { class: "mod-row", role: "group", "aria-label": "Modules" }, MODULES.map(m => {
    const ok = !signedIn || hasModule(m.key);
    if (!ok) {
      return h("span", { class: "mod-btn mod-off", role: "link", "aria-disabled": "true",
                         title: "Your account does not have access to " + m.label + ". Ask an admin." },
        h("span", { class: "mod-t" }, m.label), h("span", { class: "mod-d" }, "No access"));
    }
    return h("a", { class: "mod-btn mod-on", href: signedIn ? m.href : "#/",
                    on: signedIn ? null : { click: e => { e.preventDefault(); opts.onPick && opts.onPick(m); } } },
      h("span", { class: "mod-t" }, m.label), h("span", { class: "mod-d" }, m.desc));
  }));
}

/* ---- the CVE scroller: critical, high and 0-day only ------------------------- */

let scrollerTimer = null;

function scrollerItem(it, hidden) {
  const url = safeVendorUrl(it.url);
  const attrs = hidden ? { tabindex: "-1" } : {};
  const id = url ? h("a", Object.assign({ href: url, target: "_blank", rel: "noopener noreferrer", class: "nw-id" }, attrs), it.cve_id)
                 : h("span", { class: "nw-id" }, it.cve_id);
  const when = it.published ? new Date(it.published) : null;
  return h("li", { class: "sc-item" + (it.exploited ? " nw-kev" : "") },
    h("div", { class: "nw-top" },
      it.exploited ? h("span", { class: "sv sv-crit sv-0day" }, "0-day") : sevChip(it.severity, it.cvss),
      id, h("span", { class: "nw-src" }, FEED_NAME[it.source] || it.source),
      h("time", { class: "nw-when", datetime: it.published || "" },
        when ? when.toLocaleDateString(undefined, { day: "numeric", month: "short" }) : "")),
    h("p", { class: "nw-title" }, it.title || ""));
}

function cveScroller() {
  const track = h("div", { class: "sc-track" });
  const box = h("div", { class: "sc-window", tabindex: "0", "aria-label": "Critical, high and 0-day CVEs; hover or focus to pause" }, track);
  const panel = h("section", { class: "signin-news sc-panel", "aria-labelledby": "sc-h" },
    h("div", { class: "sc-head" },
      h("h2", { id: "sc-h" }, "Critical, High & 0-day CVEs"),
      h("span", { class: "sc-live", "aria-hidden": "true" }, "LIVE")),
    h("p", { class: "muted small" }, "Just published by NIST, Microsoft and Red Hat"),
    box);
  async function load() {
    let d = null;
    try {
      const r = await fetch("/api/v1/public/news", { headers: { Accept: "application/json" } });
      d = r.ok ? await r.json() : null;
    } catch (e) { d = null; }
    if (!panel.isConnected) { clearInterval(scrollerTimer); return; }
    if (!d || !d.enabled) { panel.hidden = true; return; }
    const items = [];
    Object.entries(d.sources || {}).forEach(([src, rows]) => rows.forEach(r => items.push(Object.assign({ source: src }, r))));
    items.sort((a, b) => String(b.published).localeCompare(String(a.published)));
    if (!items.length) {
      track.replaceChildren(h("p", { class: "muted small" }, "No critical, high or 0-day CVEs in this period."));
      box.classList.add("sc-static");
      return;
    }
    const list = h("ul", { class: "sc-list" }, items.map(i => scrollerItem(i, false)));
    // A second copy follows the first, so the loop is seamless; screen readers skip it
    const copy = h("ul", { class: "sc-list", "aria-hidden": "true" }, items.map(i => scrollerItem(i, true)));
    track.replaceChildren(list, copy);
    track.style.setProperty("--sc-dur", Math.max(30, items.length * 4) + "s");
    box.classList.toggle("sc-static", items.length < 4);
    if (items.length < 4) copy.remove();
  }
  load();
  clearInterval(scrollerTimer);
  scrollerTimer = setInterval(load, 120000);
  return panel;
}

function welcomeBlock(extra) {
  return h("div", { class: "signin-welcome" },
    logoImg(isDarkTheme(), "signin-logo"),
    h("p", { class: "signin-kicker" }, "Welcome to the"),
    h("h1", { class: "signin-title", "data-cmd": "login" }, PORTAL + " Dashboard portal"),
    h("p", { class: "ai-badge" }, h("span", { class: "ai-dot", "aria-hidden": "true" }), "AI powered dashboard"),
    h("p", { class: "muted" }, "Patch, vulnerability, inventory and software lifecycle in one place, analysed by AI-01."),
    extra || null);
}

/* ---- sign-in page ------------------------------------------------------------ */

const AFTER_KEY = "cs.after";

async function signinDecor(formEl) {
  await loadBrand();
  if (!formEl.isConnected) return null;      // the user moved on (signed in) meanwhile
  const prevFocus = document.activeElement;  // moving the form into the layout drops focus
  const hint = h("p", { class: "mod-hint", role: "status" });
  const buttons = moduleButtons({ onPick: m => {
    try { sessionStorage.setItem(AFTER_KEY, m.key); } catch (e) { /* private mode */ }
    hint.textContent = "Sign in to open " + m.label + ".";
    const u = formEl.querySelector("input[name=user]");
    if (u) u.focus();
  } });
  const wrap = h("div", { class: "signin-page" },
    h("div", { class: "signin-left" }, welcomeBlock(buttons), hint, formEl), cveScroller());
  wrap.prevFocus = prevFocus;
  return wrap;
}

/* After sign-in: go where the user was heading, if they may. */
function takeAfterSignIn() {
  let k = null;
  try { k = sessionStorage.getItem(AFTER_KEY); sessionStorage.removeItem(AFTER_KEY); } catch (e) { k = null; }
  const m = MODULES.find(x => x.key === k);
  if (m && hasModule(m.key)) {
    if (location.hash === m.href) route(); else location.hash = m.href;
    return true;
  }
  return false;
}

/* ---- home: the same welcome, with this user's modules lit ---------------------- */

async function renderHome() {
  setNav("home");
  await loadBrand();
  await refreshMe(true);
  const a = getAuth();
  const name = (a && (a.user.display_name || a.user.username)) || "";
  const mine = myModules();
  render(h("div", { class: "signin-page home-page" },
    h("div", { class: "signin-left" },
      welcomeBlock(moduleButtons()),
      h("p", { class: "muted small home-who" }, "Signed in as " + name + ". "
        + (mine.length === ALL_MODULES.length ? "You can open every module."
          : mine.length ? "Greyed-out modules need an admin to grant access."
          : "Your account has no modules yet: ask an admin to grant access under Admin, Access."))),
    cveScroller()));
}

/* ---- the Patch Dashboard ----------------------------------------------------- */

async function renderCyberDashboard() {
  setNav("overview");
  applyBrand();
  const [d, imp] = await Promise.all([api("/dashboard/summary"), api("/impact").catch(() => null)]);
  const page = h("div", { class: "cy" });
  render(page);
  drawDashboard(page, d, imp);
  setPageTimer(async () => {
    if (document.hidden) return;
    try {
      const [d2, i2] = await Promise.all([api("/dashboard/summary"), api("/impact").catch(() => null)]);
      if (!document.body.contains(page)) return;
      const y = window.scrollY;
      drawDashboard(page, d2, i2, true);
      window.scrollTo(0, y);
    } catch (e) { /* keep the last figures; the next tick retries */ }
  }, 60000);
}

const VERDICT = {
  affected: ["Affected", "c-bad"], pending_reboot: ["Fixed, reboot needed", "c-warn"],
  potentially_affected: ["Possibly affected", "c-mod"], not_found: ["Not in inventory", "c-muted"],
  not_tracked: ["Not inventoried (e.g. network gear)", "c-cat6"],
};

function impactCard(d, imp) {
  const ic = (d.feeds && d.feeds.impact) || (imp && imp.counts) || null;
  const days = (d.feeds && d.feeds.days) || (imp && imp.days) || 14;
  const segs = ic ? ["affected", "pending_reboot", "potentially_affected", "not_found", "not_tracked"].map(k =>
    ({ label: VERDICT[k][0], value: ic[k] || 0, cls: VERDICT[k][1], href: "#/impact?verdict=" + k })) : [];
  const dn = donut("Impacted CVEs", segs, {
    caption: ic ? "New critical, high and 0-day CVEs (last " + days + " days) matched to your software and hardware"
                : "Waiting for the first analysis: rebuild the API and worker (phase3b-api.sh)",
    centreLabel: ic ? "analysed" : "not yet" });
  const top = ((imp && imp.items) || []).filter(i => ["affected", "pending_reboot", "potentially_affected"].includes(i.verdict)).slice(0, 4);
  const list = h("ul", { class: "imp-top" }, top.length ? top.map(i => h("li", null,
    h("div", { class: "nw-top" },
      i.exploited ? h("span", { class: "sv sv-crit sv-0day" }, "0-day") : sevChip(i.severity, i.cvss),
      h("a", { href: "#/impact?cve=" + encodeURIComponent(i.cve_id), class: "nw-id" }, i.cve_id),
      h("span", { class: "imp-v " + VERDICT[i.verdict][1] }, VERDICT[i.verdict][0]),
      h("span", { class: "nw-src" }, i.machines === 1 ? "1 machine" : i.machines + " machines")),
    h("p", { class: "imp-ai" + (i.ai_summary ? "" : " imp-wait") },
      i.ai_summary ? h("span", { class: "ai-tag" }, "AI") : null,
      i.ai_summary ? " " + i.ai_summary.split(/\n\s*\n/)[0] : (i.title || "") + " · AI-01 brief pending")))
    : [h("li", { class: "muted small" }, ic ? "Nothing new is affecting your machines." : "")]);
  return h("section", { class: "dn-card imp-card" },
    h("div", { class: "imp-grid" }, dn,
      h("div", { class: "imp-side" },
        h("h3", null, "Needs your attention", h("span", { class: "ai-badge ai-small" }, h("span", { class: "ai-dot" }), "AI analysed")),
        list,
        h("a", { href: "#/impact", class: "small" }, "All impacted CVEs, where they were found, and AI-01's briefs"))));
}

function drawDashboard(page, d, imp, quiet) {
  const s = d.servers || {}, a = d.advisories || {}, sv = d.severity || {}, ag = d.agents || {};
  const f = (d.feeds && d.feeds.counts) || null;
  const ic = (d.feeds && d.feeds.impact) || null;
  const at = d.at ? new Date(d.at) : new Date();
  const hero = (n, label, cls, href) => h(href ? "a" : "div", { class: "cy-hero " + (cls || ""), href: href || null },
    h("span", { class: "cy-n" }, n === null || n === undefined ? "–" : String(n)), h("span", { class: "cy-l" }, label));

  const head = h("div", { class: "page-head cy-head" },
    h("div", null,
      h("h1", { "data-cmd": "cybersecure status" }, "Patch Dashboard"),
      h("p", { class: "muted small" }, "Live security posture · updated " + at.toLocaleTimeString() + " · refreshes every minute")),
    h("div", { class: "cy-heroes" },
      hero(d.compliance_pct === null ? null : d.compliance_pct + "%", "patch compliance", "cy-ok"),
      hero(s.total || 0, "servers", "", "#/hosts"),
      hero(sv.critical || 0, "critical updates outstanding", sv.critical ? "cy-bad" : "", "#/advisories?state=affected"),
      ic ? hero(ic.affected || 0, "CVEs affecting your machines", ic.affected ? "cy-bad" : "", "#/impact?verdict=affected") : null));

  if (!s.total) {
    page.replaceChildren(head, h("div", { class: "empty" },
      h("h2", null, "No servers have enrolled yet"),
      h("p", null, "Issue a token with ", h("code", null, "./scripts/phase3b-api.sh --token"),
        ", then install the agent on a server. It appears here within a minute.")));
    return;
  }

  const grid = h("div", { class: "cy-grid" },
    impactCard(d, imp),
    donut("Servers", [
      { label: "Patched", value: s.patched, cls: "c-ok", href: "#/hosts" },
      { label: "Needs patches", value: s.needs_patch, cls: "c-bad", href: "#/advisories?state=affected" },
      { label: "Needs a reboot", value: s.needs_reboot, cls: "c-warn", href: "#/advisories?state=fixed_pending_reboot" },
      { label: "Not reporting", value: s.not_reporting, cls: "c-muted", href: "#/agents", note: "status unknown until it reports" },
    ], { caption: "Each server once, by its worst state" }),
    donut("Updates", [
      { label: "To install", value: (a.to_install || 0) + (a.windows_to_install || 0), cls: "c-bad",
        note: (a.to_install || 0) + " Linux advisories, " + (a.windows_to_install || 0) + " Windows updates" },
      { label: "Installed, reboot needed", value: a.awaiting_reboot, cls: "c-warn" },
      { label: "Installed", value: a.installed, cls: "c-ok" },
    ], { caption: "Per server and update" }),
    donut("Outstanding by severity", [
      { label: "Critical", value: sv.critical, cls: "c-bad" },
      { label: "Important", value: sv.important, cls: "c-warn" },
      { label: "Moderate", value: sv.moderate, cls: "c-mod" },
      { label: "Low or unrated", value: sv.low_or_unrated, cls: "c-muted" },
    ], { caption: "Distinct advisories and updates still to install" }),
    donut("Operating systems", (d.os || []).map((o, i) => (
      { label: o.os, value: o.n, cls: o.os === "Other" ? "c-muted" : OS_CLASSES[i] || "c-muted" })),
      { caption: "Servers with an agent" }),
    donut("Agents", [
      { label: "Online", value: ag.online || 0, cls: "c-ok", href: "#/agents" },
      { label: "Offline", value: ag.offline || 0, cls: "c-warn", href: "#/agents" },
      { label: "Not reporting", value: ag.not_reporting || 0, cls: "c-bad", href: "#/agents" },
      { label: "Never reported", value: ag.no_data || 0, cls: "c-muted", href: "#/agents" },
    ]),
    f ? donut("New CVEs (feeds)", [
      { label: "Critical", value: f.critical, cls: "c-bad" },
      { label: "High", value: f.high, cls: "c-warn" },
      { label: "Medium", value: f.medium, cls: "c-mod" },
      { label: "Low", value: f.low, cls: "c-muted" },
    ], { caption: (d.feeds.watch_list ? "Your watched software" : "All software (no watch list yet)")
                 + ", last " + d.feeds.days + " days · " + (f.exploited || 0) + " 0-day" })
      : donut("New CVEs (feeds)", [], { caption: "Feeds are not set up yet: Admin, CVE feeds", centreLabel: "not set up" }));

  page.replaceChildren(head, grid);
  if (quiet) page.querySelectorAll(".dn-seg").forEach(x => x.classList.add("dn-noanim"));
}

/* ---- impacted CVEs: where each was found, and AI-01's brief --------------------- */

async function renderImpact(params) {
  setNav("overview");
  const verdict = params.get("verdict") || "";
  const only = params.get("cve") || "";
  const d = await api("/impact" + (verdict ? "?verdict=" + encodeURIComponent(verdict) : ""));
  const c = d.counts || {};
  const filters = h("div", { class: "filters", role: "group", "aria-label": "Verdict" },
    [["", "All"], ["affected", "Affected"], ["pending_reboot", "Reboot needed"], ["potentially_affected", "Possibly affected"],
     ["not_found", "Not in inventory"], ["not_tracked", "Not inventoried"]].map(([k, label]) =>
      h("a", { class: "fbtn", href: "#/impact" + (k ? "?verdict=" + k : ""), "aria-pressed": String(k === verdict) },
        label + (k && c[k] !== undefined ? " (" + c[k] + ")" : ""))));
  const items = (d.items || []).filter(i => !only || i.cve_id === only);
  const cards = items.map(i => {
    const lines = (i.matches || []).filter(m => m.certainty !== "not_tracked" || !(i.matches || []).some(x => x.certainty !== "not_tracked"));
    const url = i.sources && i.sources.includes("nist") ? "https://nvd.nist.gov/vuln/detail/" + i.cve_id
      : i.sources && i.sources.includes("msrc") ? "https://msrc.microsoft.com/update-guide/vulnerability/" + i.cve_id
      : "https://access.redhat.com/security/cve/" + i.cve_id.toLowerCase();
    return h("article", { class: "imp-item" + (i.exploited ? " nw-kev" : "") },
      h("div", { class: "nw-top" },
        i.exploited ? h("span", { class: "sv sv-crit sv-0day" }, "0-day") : sevChip(i.severity, i.cvss),
        h("a", { href: url, target: "_blank", rel: "noopener noreferrer", class: "nw-id" }, i.cve_id),
        h("span", { class: "imp-v " + (VERDICT[i.verdict] || ["", "c-muted"])[1] }, (VERDICT[i.verdict] || [i.verdict])[0]),
        h("span", { class: "nw-src" }, (i.sources || []).map(s => FEED_NAME[s] || s).join(", ")),
        h("span", { class: "nw-when" }, "checked " + timeAgo(i.analysed_at))),
      h("p", { class: "nw-title" }, i.title || ""),
      i.ai_summary ? h("div", { class: "imp-brief" }, h("span", { class: "ai-tag" }, "AI-01"),
        ...i.ai_summary.split(/\n\s*\n/).map(p => h("p", null, p))) :
        (["affected", "pending_reboot", "potentially_affected"].includes(i.verdict)
          ? h("p", { class: "muted small" }, "AI-01's brief is being written; it appears here within minutes.") : null),
      lines.length ? h("details", null, h("summary", null, "Where it was found (" + lines.length + ")"),
        table([
          { label: "Where", cell: m => m.where || m.kind || "" },
          { label: "Machine", cell: m => m.name || "–" },
          { label: "Found", cell: m => m.version || "" },
          { label: "Certainty", cell: m => String(m.certainty || "").replace(/_/g, " ") },
          { label: "Why", cell: m => m.detail || "" },
        ], lines)) : null);
  });
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure impact" }, "Impacted CVEs"),
      can("admin") ? h("button", { type: "button", on: { click: async e => {
        e.target.disabled = true;
        try { await apiPost("/admin/impact/reanalyse", {}); e.target.textContent = "Re-analysis requested"; }
        catch (err) { e.target.textContent = err.message; }
      } } }, "Analyse again now") : null),
    h("p", { class: "muted" }, "New critical, high and 0-day CVEs from NIST, Microsoft and Red Hat (last " + d.days
      + " days), matched against your servers' software, operating systems, ESXi hosts, vCenters and server hardware. "
      + "The verdict comes from the inventory and the vendors' fixed versions; AI-01 only writes the brief."),
    filters,
    cards.length ? h("div", { class: "imp-list" }, cards) : h("div", { class: "empty" }, h("p", null, "Nothing here.")));
}

/* ---- admin: who may open which module ------------------------------------------ */

async function renderAccess() {
  setNav("admin");
  const d = await api("/admin/users");
  const msg = h("p", { class: "cm-meta", role: "status" });
  const rows = d.users || [];
  const t = table([
    { label: "User", cell: u => h("span", null, h("strong", null, u.username), u.display_name ? " · " + u.display_name : "") },
    { label: "Role", cell: u => u.role },
    ...MODULES.map(m => ({ label: m.label, cell: u => {
      if (u.role === "admin") return h("span", { class: "muted small" }, "always");
      const box = h("input", { type: "checkbox", checked: (u.modules || []).includes(m.key), "data-user": u.username,
                               "data-mod": m.key, "aria-label": m.label + " for " + u.username });
      box.addEventListener("change", async () => {
        // The whole row is sent, read from its boxes, and locked until the server answers
        const row = [...document.querySelectorAll("input[data-user]")].filter(b => b.dataset.user === u.username);
        const want = row.filter(b => b.checked).map(b => b.dataset.mod);
        row.forEach(b => { b.disabled = true; });
        try {
          const r = await apiSend("PATCH", "/admin/users/" + encodeURIComponent(u.username), { modules: want });
          u.modules = Array.isArray(r.modules) ? r.modules : want;
          msg.textContent = u.username + ": " + (u.modules.length ? u.modules.map(k => MODULES.find(x => x.key === k).label).join(", ") : "no modules")
            + ". Applies at once, on their next click.";
        } catch (err) { msg.textContent = err.message; }
        row.forEach(b => { b.checked = (u.modules || []).includes(b.dataset.mod); b.disabled = false; });
      });
      return box;
    } })),
    { label: "Active", cell: u => u.active ? "yes" : "no" },
  ], rows);
  render(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure access" }, "Access")),
    h("p", { class: "muted" }, "Choose which modules each user may open. The home page lights the modules a user may open and greys "
      + "out the rest, and the API refuses the others whatever the browser does. Admins can always open everything. "
      + "Roles (viewer, operator, admin) still decide what a user may change inside a module: set them under Users."),
    t, msg);
  adminTabs("access");
}

/* ---- admin: CVE feeds ------------------------------------------------------- */


async function renderFeedsAdmin() {
  setNav("admin");
  const d = await api("/admin/feeds");
  const page = h("div", { class: "feeds-admin" });
  render(page);
  drawFeedsAdmin(page, d);
  adminTabs("feeds");
}

function drawFeedsAdmin(page, d) {
  const st = d.settings || {};
  const msg = h("p", { class: "cm-meta", role: "status" });
  const box = (k, label) => h("label", { class: "cm-check" }, h("input", { type: "checkbox", name: k, checked: !!st[k] }), " " + label);
  const num = (k, label, min, max, step) => h("label", null, h("span", null, label),
    h("input", { type: "number", name: k, value: st[k], min, max, step: step || 1, required: true }));
  const form = h("form", { class: "feeds-form", on: { submit: async e => {
    e.preventDefault();
    const fd = new FormData(form);
    const body = { nist: fd.has("nist"), msrc: fd.has("msrc"), redhat: fd.has("redhat"), signin_board: fd.has("signin_board"),
                   days_back: Number(fd.get("days_back")), min_cvss: Number(fd.get("min_cvss")),
                   interval_minutes: Number(fd.get("interval_minutes")), signin_min_cvss: Number(st.signin_min_cvss || 7) };
    try { const r = await apiSend("PUT", "/admin/feeds/settings", body); drawFeedsAdmin(page, r); }
    catch (err) { msg.textContent = err.message || "Could not save."; }
  } } },
    h("fieldset", null, h("legend", null, "Sources"), box("nist", "NIST NVD"), box("msrc", "Microsoft"), box("redhat", "Red Hat")),
    h("div", { class: "feeds-nums" },
      num("days_back", "Days to show", 1, 90), num("min_cvss", "Lowest CVSS on the dashboard", 0, 10, 0.1),
      num("interval_minutes", "Read every (minutes)", 15, 1440)),
    h("fieldset", null, h("legend", null, "Sign-in page"),
      box("signin_board", "Show the CVE scroller before sign-in"),
      h("p", { class: "muted small" }, "The sign-in scroller shows only critical, high and 0-day CVEs from the general feeds, "
        + "never your watch list, so it does not reveal what software you run.")),
    h("div", { class: "cm-actions" }, h("button", { type: "submit" }, "Save"), msg));

  const term = h("input", { type: "text", maxlength: "60", placeholder: "for example: openssl, apache tomcat, vmware vcenter",
                            "aria-label": "Software to follow", required: true });
  const kind = h("select", { "aria-label": "Kind" }, ["software", "vendor", "keyword"].map(k => h("option", { value: k }, k)));
  const addMsg = h("p", { class: "cm-meta", role: "status" });
  const add = async (t, k) => {
    try { const r = await apiPost("/admin/feeds/watch", { term: t, kind: k || "software" }); drawFeedsAdmin(page, r); }
    catch (err) { addMsg.textContent = err.message || "Could not add."; }
  };
  const addForm = h("form", { class: "feeds-add", on: { submit: e => { e.preventDefault(); add(term.value.trim(), kind.value); } } },
    term, kind, h("button", { type: "submit" }, "Add"));

  const watch = d.watch || [];
  const watchTable = watch.length ? table([
    { label: "Software", cell: w => w.term },
    { label: "Kind", cell: w => w.kind },
    { label: "Following", cell: w => h("input", { type: "checkbox", checked: !!w.enabled, "aria-label": "Follow " + w.term,
        on: { change: async e => { try { drawFeedsAdmin(page, await apiSend("PATCH", "/admin/feeds/watch/" + w.id, { enabled: e.target.checked })); }
                                   catch (err) { addMsg.textContent = err.message; } } } }) },
    { label: "Added", cell: w => (w.added_by || "") + ", " + timeAgo(w.added_at) },
    { label: "", cell: w => h("button", { type: "button", class: "btn-link", on: { click: async () => {
        try { drawFeedsAdmin(page, await apiSend("DELETE", "/admin/feeds/watch/" + w.id)); } catch (err) { addMsg.textContent = err.message; } } } }, "Remove") },
  ], watch) : h("p", { class: "muted" }, "Nothing on the watch list yet. Until you add software, the dashboard shows every CVE collected.");

  const sugBox = h("div", { class: "feeds-sug" }, h("p", { class: "muted small" }, "Loading what your servers run"));
  api("/admin/feeds/suggestions").then(sg => {
    const group = (title, rows) => rows.length ? h("div", null, h("h3", null, title),
      h("div", { class: "chips" }, rows.slice(0, 40).map(r => h("button", { type: "button", class: "chip",
        title: r.servers ? "On " + r.servers + " server(s): add to the watch list" : "Add to the watch list",
        on: { click: () => add(r.name, r.kind) } }, "+ " + r.name + (r.servers ? " (" + r.servers + ")" : ""))))) : null;
    sugBox.replaceChildren(...[group("Windows software on your servers", sg.windows || []),
      group("Linux software on your servers", sg.linux || []), group("Operating systems", sg.os || [])].filter(Boolean));
    if (!sugBox.childNodes.length) sugBox.replaceChildren(h("p", { class: "muted small" }, "Everything your servers report is already on the list."));
  }).catch(() => sugBox.replaceChildren(h("p", { class: "muted small" }, "Suggestions are not available.")));

  const state = d.state || [];
  const stored = {};
  (d.stored || []).forEach(r => { stored[r.source] = r; });
  const stateTable = table([
    { label: "Source", cell: r => FEED_NAME[r.source] || r.source },
    { label: "Last read", cell: r => r.last_ok ? timeAgo(r.last_ok) : "never" },
    { label: "Read last time", num: true, cell: r => r.items === null || r.items === undefined ? "" : r.items },
    { label: "Kept", num: true, cell: r => stored[r.source] ? stored[r.source].n : 0 },
    { label: "Problem", cell: r => r.error ? h("span", { class: "hd-failed" }, r.error) : "" },
  ], ["nist", "msrc", "redhat"].map(k => Object.assign({ source: k }, state.find(x => x.source === k) || {})));
  const syncMsg = h("span", { class: "cm-meta", role: "status" });
  const syncBtn = h("button", { type: "button", on: { click: async () => {
    syncBtn.disabled = true;
    try { await apiPost("/admin/feeds/sync", {}); syncMsg.textContent = "Asked the worker: it starts within a minute. NIST takes a few minutes"
          + (d.nvd_api_key ? "." : " without an NVD API key."); }
    catch (err) { syncMsg.textContent = err.message; syncBtn.disabled = false; }
  } } }, "Read the feeds now");

  page.replaceChildren(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure feeds" }, "CVE feeds")),
    h("p", { class: "muted" }, "New CVEs from NIST NVD, Microsoft and Red Hat, read through the proxy by PATCH-01's worker. "
      + "Choose the software to follow: the dashboard and its news then show only CVEs naming that software, "
      + "plus any CVE already found on your servers."),
    h("section", null, h("h2", null, "Software to follow"), addForm, addMsg, watchTable, sugBox),
    h("section", null, h("h2", null, "Settings"), form),
    h("section", null, h("h2", null, "Status"), stateTable, h("div", { class: "cm-actions" }, syncBtn, syncMsg),
      d.worker_seen ? null : h("p", { class: "hd-failed" }, "The worker has not started reading feeds yet: rebuild it with phase3b-api.sh."),
      d.nvd_api_key || !d.worker_seen ? null : h("p", { class: "muted small" }, "No NVD API key is set, so NIST is read slowly "
        + "(5 requests every 30 seconds). A free key from NIST raises that tenfold: save it in /patch/secrets/nvd-api-key "
        + "on PATCH-01 and run phase3b-api.sh.")));
}
