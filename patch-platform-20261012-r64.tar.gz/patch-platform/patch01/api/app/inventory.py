"""Asset and software inventory, merged from every source PATCH-01 has.

Assets come from five places, merged by machine name:
  agents     the servers PATCH-01 manages (exact OS, agent state)
  vCenter    every VM (guest OS, power, cluster) and every ESXi host
  WSUS       every Windows computer WSUS knows (OS, last report)
  vCenters   the vCenter appliances themselves
  manual     rows from a sheet an admin uploaded (Excel or CSV)

Each asset is put in one category, server, client or appliance (or unknown
when nothing says), with the reason, so a wrong guess can be seen and
questioned. Software comes only from agents: vCenter and WSUS report
machines, not what is installed on them.

The functions here are pure (no database), so the merging can be tested.
"""

import ipaddress
import re

CATEGORIES = ("server", "client", "appliance", "unknown")
STATUSES = ("new", "approved", "decommissioned")
KEY_RE = re.compile(r"^[a-z0-9:._-]{1,255}$")
# Where each kind of record came from, as the page labels it
SOURCE_LABEL = {"agent": "Agent", "virtual": "Virtual", "vcenter": "vCenter", "wsus": "WSUS", "manual": "Manual"}
LIVE_SOURCES = ("agent", "virtual", "vcenter", "wsus")      # everything but the uploaded sheet

_LINUX_SERVER = re.compile(r"red hat|rhel|oracle linux|\bol ?\d|centos|rocky|alma|ubuntu|debian|suse|sles|amazon linux|fedora")
_APPLIANCE = re.compile(r"photon|vmware|esxi|vcenter|appliance|freebsd|netscaler|fortios|pan-os|junos|cisco|\bf5\b|big-ip|"
                        r"nsx|ontap|data domain|other \S* ?linux|other \(|other 3|other 4|other 5|other 6")
_WINDOWS_CLIENT = re.compile(r"windows (10|11|8|7|xp|vista)\b")


def classify(os_text, kind=None):
    """(category, reason) for one machine. kind is "esxi" or "vcenter" for
    VMware's own systems, which are always appliances."""
    if kind == "esxi":
        return "appliance", "ESXi host"
    if kind == "vcenter":
        return "appliance", "vCenter"
    t = (os_text or "").strip().lower()
    if not t:
        return "unknown", "no operating system reported"
    if "windows" in t and "server" in t:
        return "server", "Windows Server"
    if _WINDOWS_CLIENT.search(t) or ("windows" in t and "server" not in t and "microsoft" in t and re.search(r"\b(10|11)\b", t)):
        return "client", "Windows desktop edition"
    if "mac os" in t or "macos" in t:
        return "client", "macOS"
    if _APPLIANCE.search(t):
        return "appliance", "appliance or generic guest OS (" + os_text.strip()[:40] + ")"
    if _LINUX_SERVER.search(t):
        return "server", "Linux server distribution"
    if "windows" in t:
        return "server", "Windows (edition not stated)"
    if "linux" in t:
        return "server", "Linux"
    return "unknown", "unrecognised OS (" + os_text.strip()[:40] + ")"


JUNK_NAMES = {"", "localhost", "localhost.localdomain", "localdomain", "unknown", "none", "-"}


def short_name(name):
    """The machine's short name, lower case, as the merge key. Always a key
    the database accepts (KEY_RE): "DOM\\PC-1" gives "pc-1", "web server 01"
    gives "web-server-01"; a placeholder name such as localhost gives ""."""
    n = (name or "").strip().lower().rstrip(".")
    if "\\" in n:
        n = n.rsplit("\\", 1)[1]                  # DOMAIN\name
    if n in JUNK_NAMES:
        return ""
    try:
        return str(ipaddress.ip_address(n.split("%")[0]))      # an address is kept whole (no IPv6 scope)
    except ValueError:
        pass
    n = n.split(".")[0]
    k = re.sub(r"[^a-z0-9_-]+", "-", n).strip("-")[:200]
    if not k or (k != n and not re.fullmatch(r"[a-z0-9 _-]+", n)):
        # Letters a key cannot hold (non-ASCII, symbols): a short hash keeps such names apart
        import hashlib
        k = (k + "-" if k else "h-") + hashlib.sha256(n.encode()).hexdigest()[:8]
    return k


_OS_NAMES = {"rhel": "RHEL", "ol": "Oracle Linux", "ubuntu": "Ubuntu", "windows": "Windows Server"}


def _agent_os(h):
    if h.get("os_edition"):
        return h["os_edition"]
    base = _OS_NAMES.get(h.get("os_id") or "", h.get("os_id") or "")
    return (base + " " + (h.get("os_version") or "")).strip()


def clean_ips(value):
    """Addresses from any source as a plain list: a list, a "{a,b}" array
    text, "['a', 'b']", or "a, b" all give ["a", "b"]. Only real addresses
    are kept; loopback, link-local and unspecified ones are dropped."""
    items = value if isinstance(value, (list, tuple, set)) else [value]
    out = []
    for item in items:
        for x in re.split(r"[,;\s]+", re.sub(r"[\[\]{}()'\"]", " ", str(item or ""))):
            x = x.strip()
            if not x:
                continue
            try:
                ip = ipaddress.ip_address(x.split("%")[0].split("/")[0])
            except ValueError:
                continue
            if ip.is_loopback or ip.is_link_local or ip.is_unspecified or ip.is_multicast:
                continue
            t = str(ip)
            if t not in out:
                out.append(t)
    return out


def _os_family(text):
    t = (text or "").lower()
    if "windows" in t:
        return "windows"
    if _LINUX_SERVER.search(t) or "linux" in t:
        return "linux"
    return None


def merge(hosts, vms, wsus, esxi, vcenters, manual=(), records=None, ai_types=None):
    """One record per machine, from all sources. Each argument is a list of
    rows (dicts) as read from the database. records: asset_key -> status row;
    ai_types: OS text (lower case) -> device type AI-01 chose."""
    assets = {}
    by_host_id = {}
    records = records or {}
    ai_types = ai_types or {}
    vc_host = {c.get("name"): c.get("host") or c.get("name") for c in vcenters}

    def get(key, name):
        if key not in assets:
            assets[key] = {"name": name, "key": key, "sources": [], "os": None, "os_from": None, "ips": [],
                           "os_by": {}, "agent": None, "vm": None, "wsus": None, "esxi": None, "vcenter": None,
                           "manual": None, "last_seen": None}
        return assets[key]

    def seen(a, when):
        if when and (a["last_seen"] is None or str(when) > str(a["last_seen"])):
            a["last_seen"] = when

    def add_ip(a, ip):
        for x in clean_ips(ip):
            if x not in a["ips"]:
                a["ips"].append(x)

    def set_os(a, text, src, rank):
        # Precedence: agent (exact) > WSUS > vCenter's configured guest OS > the uploaded sheet
        order = {"agent": 4, "wsus": 3, "vcenter": 2, "virtual": 2, "manual": 1}
        if text:
            a["os_by"][src] = text
        if text and (a["os"] is None or order.get(src, 0) > order.get(a["os_from"], 0)):
            a["os"], a["os_from"] = text, src

    for h in hosts:
        key = short_name(h.get("hostname"))
        if not key:
            continue
        a = get(key, h.get("hostname"))
        a["sources"].append("agent")
        a["agent"] = {"host_id": str(h["id"]), "version": h.get("agent_version"), "status": h.get("status"),
                      "last_checkin": h.get("last_checkin"), "os_id": h.get("os_id")}
        set_os(a, _agent_os(h), "agent", 3)
        add_ip(a, h.get("agent_ip"))
        seen(a, h.get("last_checkin"))
        by_host_id[str(h["id"])] = a

    for v in vms:
        a = by_host_id.get(str(v.get("host_id"))) if v.get("host_id") else None
        if a is None:
            key = short_name(v.get("guest_hostname")) or short_name(v.get("name"))     # a placeholder guest name falls back to the VM name
            if not key:
                continue
            a = get(key, v.get("guest_hostname") if short_name(v.get("guest_hostname")) else v.get("name"))
        if "virtual" not in a["sources"]:
            a["sources"].append("virtual")
        a["vm"] = {"vcenter": v.get("vcenter"), "vcenter_host": vc_host.get(v.get("vcenter")) or v.get("vcenter"),
                   "vm_name": v.get("name"), "cluster": v.get("cluster"),
                   "esxi_host": v.get("esxi_host"), "power": v.get("power_state"), "cpu": v.get("num_cpu"),
                   "memory_mb": v.get("memory_mb"), "tools": v.get("tools_running"), "folder": v.get("folder_path")}
        set_os(a, v.get("guest_os"), "virtual", 1)
        add_ip(a, v.get("guest_ips"))
        seen(a, v.get("synced_at"))

    for w in wsus:
        key = short_name(w.get("name"))
        if not key:
            continue
        a = get(key, w.get("name"))
        if "wsus" not in a["sources"]:
            a["sources"].append("wsus")
        prev = a["wsus"] or {}
        a["wsus"] = {"source": ", ".join(sorted({x for x in (prev.get("source"), w.get("source")) if x})),
                     "groups": w.get("groups") or [], "last_reported": w.get("last_reported"),
                     "needed": w.get("needed"), "failed": w.get("failed")}
        set_os(a, w.get("os"), "wsus", 2)
        add_ip(a, w.get("ip"))
        seen(a, w.get("last_reported"))

    for e in esxi:
        key = short_name(e.get("name"))
        if not key:
            continue
        a = get(key, e.get("name"))
        a["sources"].append("vcenter")
        a["esxi"] = {"vcenter": e.get("vcenter"), "vcenter_host": vc_host.get(e.get("vcenter")) or e.get("vcenter"),
                     "cluster": e.get("cluster"), "model": " ".join(
            x for x in (e.get("vendor"), e.get("model")) if x), "version": e.get("esxi_full_name") or e.get("esxi_version"),
            "state": e.get("connection_state"), "vm_count": e.get("vm_count"), "maintenance": e.get("maintenance_mode")}
        a["os"] = a["os"] or (e.get("esxi_full_name") or "VMware ESXi")
        a["os_from"] = a["os_from"] or "vcenter"
        seen(a, e.get("synced_at"))

    for c in vcenters:
        key = short_name(c.get("host")) or short_name(c.get("name"))
        if not key:
            continue
        a = get(key, c.get("host") or c.get("name"))
        a["sources"].append("vcenter")
        a["vcenter"] = {"name": c.get("name"), "version": c.get("version"), "last_ok": c.get("last_ok")}
        a["os"] = a["os"] or ("VMware vCenter " + (c.get("version") or "")).strip()
        a["os_from"] = a["os_from"] or "vcenter"
        seen(a, c.get("last_sync_at"))

    # The uploaded sheet joins by name only: it never moves another source's data
    for m in manual:
        key = m.get("asset_key") or short_name(m.get("name"))
        if not key:
            continue
        a = get(key, m.get("name"))
        a["sources"].append("manual")
        a["manual"] = {"location": m.get("location"), "device": m.get("device"), "serial": m.get("serial"),
                       "owner": m.get("owner"), "notes": m.get("notes"), "updated_at": m.get("updated_at"),
                       "updated_by": m.get("updated_by")}
        set_os(a, m.get("os"), "manual", 0)
        add_ip(a, m.get("ips"))

    out = []
    for a in assets.values():
        kind = "esxi" if a["esxi"] else "vcenter" if a["vcenter"] else None
        a["category"], a["category_reason"] = classify(a["os"], kind)
        a["device_from"] = "rules"
        if a["category"] == "unknown":
            man = (a["manual"] or {}).get("device")
            ai = ai_types.get((a["os"] or "").strip().lower())
            if man in CATEGORIES and man != "unknown":
                a["category"], a["category_reason"], a["device_from"] = man, "as given in the uploaded sheet", "manual"
            elif ai in CATEGORIES and ai != "unknown":
                a["category"], a["category_reason"], a["device_from"] = ai, "AI-01, from the OS name (" + (a["os"] or "")[:40] + ")", "ai"
        a["sources"] = sorted(set(a["sources"]), key=lambda x: list(SOURCE_LABEL).index(x))
        a["managed"] = a["agent"] is not None
        a["gone"] = False
        a["location"], a["location_kind"] = _location(a)
        r = records.get(key_of(a)) or {}
        a["status"] = r.get("status") or "new"
        a["approved_by"], a["approved_at"] = r.get("approved_by"), r.get("approved_at")
        a["decom_by"], a["decom_at"], a["decom_reason"] = r.get("decom_by"), r.get("decom_at"), r.get("decom_reason")
        out.append(a)
    out.sort(key=lambda x: (CATEGORIES.index(x["category"]), x["name"].lower()))
    return out


SNAPSHOT_FIELDS = ("name", "category", "category_reason", "os", "ips", "location", "location_kind", "sources", "last_seen", "managed")


def snapshot(a):
    """What an asset looked like when it was approved or decommissioned, so it
    can still be shown when no source reports it any more."""
    return {k: (str(a.get(k)) if k == "last_seen" and a.get(k) is not None else a.get(k)) for k in SNAPSHOT_FIELDS}


def gone(records, present):
    """Approved and decommissioned machines that no source reports now,
    rebuilt from their snapshot."""
    out = []
    for k, r in records.items():
        snap = r.get("snapshot") or {}
        # approved, decommissioned, or taken back to New after a decision (it has a snapshot)
        if k in present or not (r.get("status") in ("approved", "decommissioned") or (r.get("status") == "new" and snap)):
            continue
        if isinstance(snap, str):
            import json as _json
            try:
                snap = _json.loads(snap)
            except ValueError:
                snap = {}
        cat = snap.get("category") if snap.get("category") in CATEGORIES else "unknown"
        out.append({"name": snap.get("name") or r.get("name") or k, "key": k, "sources": [], "os": snap.get("os"),
                    "os_from": None, "os_by": {}, "ips": clean_ips(snap.get("ips") or []), "agent": None, "vm": None,
                    "wsus": None, "esxi": None, "vcenter": None, "manual": None, "last_seen": snap.get("last_seen"),
                    "category": cat, "category_reason": snap.get("category_reason") or "as it was when last recorded",
                    "device_from": "snapshot", "managed": False, "location": snap.get("location") or "",
                    "location_kind": snap.get("location_kind") or "", "gone": True,
                    "status": r["status"], "approved_by": r.get("approved_by"), "approved_at": r.get("approved_at"),
                    "decom_by": r.get("decom_by"), "decom_at": r.get("decom_at"), "decom_reason": r.get("decom_reason")})
    return out


def key_of(a):
    """The asset's key when it is safe to store, else None."""
    k = (a.get("key") or "").lower()
    return k if KEY_RE.match(k) else None


def _location(a):
    """(text, kind). A VM is where its vCenter is; anything else is told
    apart by its type: Windows 10/11 and macOS are laptops or desktops."""
    if a["vm"]:
        return a["vm"].get("vcenter_host") or a["vm"].get("vcenter") or "vCenter", "virtual"
    if a["esxi"]:
        return "ESXi host · " + (a["esxi"].get("vcenter_host") or a["esxi"].get("vcenter") or ""), "esxi"
    if a["vcenter"]:
        return "vCenter appliance", "vcenter"
    given = ((a["manual"] or {}).get("location") or "").strip()
    if given:
        return given, "manual"
    return {"client": "Laptop/Desktop", "server": "Physical server", "appliance": "Appliance"}.get(a["category"], ""), "physical"


def findings(assets, now=None, stale_days=30):
    """What does not add up across the sources. Pure: no changes are made.
    Each finding names the assets it is about, so it can be checked."""
    import datetime as _dt
    now = now or _dt.datetime.now(_dt.timezone.utc)
    out = []

    def ts(v):
        if v is None:
            return None
        if isinstance(v, _dt.datetime):
            return v if v.tzinfo else v.replace(tzinfo=_dt.timezone.utc)
        try:
            d = _dt.datetime.fromisoformat(str(v).replace("Z", "+00:00"))
            return d if d.tzinfo else d.replace(tzinfo=_dt.timezone.utc)
        except ValueError:
            return None

    active = [a for a in assets if a["status"] != "decommissioned"]
    by_ip = {}
    for a in active:
        for ip in a["ips"]:
            by_ip.setdefault(ip, []).append(a["name"])
    dup = {ip: names for ip, names in by_ip.items() if len(set(n.lower() for n in names)) > 1}
    if dup:
        out.append({"kind": "shared_ip", "level": "warn", "title": "One address, several names",
                    "text": f"{len(dup)} address{'es are' if len(dup) != 1 else ' is'} used by more than one name: "
                            "the same machine under two names, or an address that moved.",
                    "items": [f"{ip}: {', '.join(sorted(set(n)))}" for ip, n in sorted(dup.items())][:50]})
    os_clash = []
    for a in active:
        fams = {src: _os_family(t) for src, t in a["os_by"].items() if _os_family(t)}
        if len(set(fams.values())) > 1:
            os_clash.append(f"{a['name']}: " + ", ".join(f"{SOURCE_LABEL.get(s, s)} says {a['os_by'][s]}" for s in fams))
    if os_clash:
        out.append({"kind": "os_conflict", "level": "warn", "title": "Sources disagree on the OS",
                    "text": f"{len(os_clash)} machine{'s' if len(os_clash) != 1 else ''}: one source reports Windows, another Linux.",
                    "items": os_clash[:50]})
    only_sheet = [a["name"] for a in active if a["sources"] == ["manual"]]
    if only_sheet:
        out.append({"kind": "sheet_only", "level": "info", "title": "Only in the uploaded sheet",
                    "text": f"{len(only_sheet)} machine{'s are' if len(only_sheet) != 1 else ' is'} in the sheet but no agent, "
                            "vCenter or WSUS reports {0}: check the name, or whether {0} still exist{1}."
                            .format("them" if len(only_sheet) != 1 else "it", "" if len(only_sheet) != 1 else "s"),
                    "items": sorted(only_sheet)[:50]})
    stale = []
    for a in active:
        if a["status"] != "approved":
            continue
        t = ts(a["last_seen"])
        if a.get("gone"):
            stale.append(f"{a['name']}: no source reports it any more" + (f" (last detected {t.date().isoformat()})" if t else ""))
        elif any(s in LIVE_SOURCES for s in a["sources"]) and t and (now - t).days >= stale_days:
            stale.append(f"{a['name']}: last detected {t.date().isoformat()}")
    if stale:
        out.append({"kind": "stale", "level": "info", "title": f"Approved, not detected for {stale_days} days",
                    "text": f"{len(stale)} approved machine{'s have' if len(stale) != 1 else ' has'} not been reported by any source "
                            f"for {stale_days} days or more, or at all now: candidates to decommission.",
                    "items": stale[:50]})
    back = []
    for a in assets:
        if a["status"] == "decommissioned":
            t, d = ts(a["last_seen"]), ts(a["decom_at"])
            if t and d and t > d and any(s in LIVE_SOURCES for s in a["sources"]):
                back.append(f"{a['name']}: decommissioned {d.date().isoformat()}, detected again {t.date().isoformat()}")
    if back:
        out.append({"kind": "seen_again", "level": "bad", "title": "Decommissioned, but still detected",
                    "text": f"{len(back)} decommissioned machine{'s are' if len(back) != 1 else ' is'} still reported by a source "
                            "after the decommission date: still running, or the name was reused.",
                    "items": back[:50]})
    unk = [a["name"] + (" (" + a["os"] + ")" if a["os"] else "") for a in active if a["category"] == "unknown"]
    if unk:
        out.append({"kind": "unknown_type", "level": "info", "title": "Device type unknown",
                    "text": f"{len(unk)} machine{'s' if len(unk) != 1 else ''} with no OS, or one that neither the rules nor AI-01 could place.",
                    "items": sorted(unk)[:50]})
    return out


def load_assets(conn):
    """Read every source and merge. Read-only. Decommissioned machines are
    included, marked; the pages filter them."""
    hosts = conn.execute(
        """SELECT id, hostname, os_id, os_version, os_edition, agent_version, status::text AS status,
                  last_checkin, host(agent_ip) AS agent_ip
             FROM hosts WHERE status <> 'decommissioned'""").fetchall()
    vms = conn.execute(
        """SELECT vcenter, name, guest_hostname, guest_os, guest_ips, power_state, cluster, esxi_host,
                  num_cpu, memory_mb, tools_running, folder_path, host_id, synced_at FROM vm_inventory""").fetchall()
    wsus = conn.execute(
        "SELECT source, name, ip, os, groups, last_reported, needed, failed FROM wsus_computers").fetchall()
    esxi = conn.execute(
        """SELECT name, vcenter, cluster, vendor, model, esxi_version, esxi_full_name, connection_state,
                  maintenance_mode, vm_count, synced_at FROM esxi_hosts""").fetchall()
    vcs = conn.execute("SELECT name, host, version, last_ok, last_sync_at FROM vcenters").fetchall()
    manual, records, ai = [], {}, {}
    try:
        with conn.transaction():
            manual = conn.execute(
                """SELECT asset_key, name, ips, os, device, location, serial, owner, notes, updated_at, updated_by
                     FROM manual_assets""").fetchall()
            records = {r["asset_key"]: dict(r) for r in conn.execute(
                """SELECT asset_key, name, status, approved_by, approved_at, decom_by, decom_at, decom_reason, snapshot
                     FROM asset_records""").fetchall()}
            ai = {r["os_key"]: r["device"] for r in conn.execute("SELECT os_key, device FROM asset_ai_types").fetchall()}
    except Exception as e:  # noqa: BLE001
        if type(e).__name__ != "UndefinedTable":    # schema 030 not applied yet: the sources alone
            raise
    assets = merge(hosts, vms, wsus, esxi, vcs, manual, records, ai)
    assets += gone(records, {a["key"] for a in assets})
    return {"assets": assets, "summary": summarise([a for a in assets if a["status"] != "decommissioned"]),
            "sources": {"agents": len(hosts), "vms": len(vms), "wsus": len(wsus), "esxi": len(esxi), "vcenters": len(vcs),
                        "manual": len(manual)}}


def summarise(assets):
    """Counts per category: total, with an agent, without."""
    s = {c: {"total": 0, "managed": 0, "unmanaged": 0} for c in CATEGORIES}
    for a in assets:
        c = s[a["category"]]
        c["total"] += 1
        c["managed" if a["managed"] else "unmanaged"] += 1
    return s
