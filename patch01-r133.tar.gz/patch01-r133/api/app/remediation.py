"""Vulnerabilities > Remediation (r131): the quarterly Nessus scan workbook.

An operator uploads the workbook (xlsx or csv; one sheet per quarter, e.g. "26Q3"). It is handled in two steps,
each in the background with its progress in the database:

  reading    every sheet is read once: its heading row, five sample rows, the number of rows and, per column, its
             different values (for the status words) and how its dates are written. The columns are placed by
             PATCH-01's rules (exact names, then a close spelling: the files have their own spellings), then by
             what a person chose for that heading before; AI-01 is asked only about the columns still unplaced.
  review     the operator sees every column with its sample values, what it was taken as and why, and confirms
             (or changes) it; status words the rules do not know and day/month order are asked, never guessed.
  importing  the file is read again with the confirmed columns and merged into the quarter: a finding is one
             plugin on one host, port and protocol. A value in the file wins; a blank keeps what PATCH-01 has
             (a re-upload of a quarter never wipes the statuses set here); a finding new to the quarter takes its
             PIC, status, exception, target date and categorisation from the previous quarter when the file
             leaves them blank (a finding fixed last quarter comes back as open).

Overdue, "seen in the previous quarter" and "fixed last quarter but found again" are worked out when they are
shown, from the data, so they are always right after an edit. Every change of a tracking field is kept with who
and when. The export writes the quarter back in the file's own columns and headings.
"""

import csv
import difflib
import gzip
import io
import ipaddress
import json
import re
import threading
import time
import zipfile
from datetime import date, datetime, timedelta, timezone

from .inventory import short_name


class RemError(Exception):
    """A reason the request cannot be done, in words for the operator (HTTP 400)."""


class NotFound(Exception):
    pass


# ---------------------------------------------------------------------------
# Fields, statuses, severities
# ---------------------------------------------------------------------------

# key, label, kind. The order is the template's: the export writes the columns in this order.
FIELDS = [
    ("uuid", "UUID", "text"),
    ("plugin_id", "Plugin", "text"),
    ("plugin_name", "Plugin name", "text"),
    ("severity", "Severity", "severity"),
    ("ip", "IP address", "ip"),
    ("env", "UAT/Prod", "text"),
    ("hostname", "Hostname", "text"),
    ("pic", "PIC", "text"),
    ("port", "Port", "port"),
    ("plugin_output", "Plugin output", "long"),
    ("synopsis", "Synopsis", "long"),
    ("description", "Description", "long"),
    ("solution", "Steps to Remediate", "long"),
    ("prev_finding", "Previous Finding", "text"),
    ("prev_fixed", "Previous Fixed but discovered", "text"),
    ("exception", "Exception", "text"),
    ("status", "Status", "status"),
    ("overdue", "Overdue?", "text"),
    ("report_shared", "Report Shared Date", "date"),
    ("completed_on", "Completion Date of Remediation", "date"),
    ("target_on", "New Target Completion Date of Remediation", "date"),
    ("protocol", "Protocol", "text"),
    ("first_seen", "First Discovered", "date"),
    ("last_seen", "Last observed", "date"),
    ("cve", "CVE", "text"),
    ("vuln_pub", "Vul Publication Date", "date"),
    ("plugin_pub", "Plugin publication date", "date"),
    ("cat1", "Categorization1", "text"),
    ("cat2", "Categorization2", "text"),
    ("cvss3", "CVSS v3.0 Base Score", "num"),
    ("cvss2", "CVSS v2.0 Base Score", "num"),
]
FIELD = {k: (label, kind) for k, label, kind in FIELDS}
FIELD_KEYS = [k for k, _l, _k in FIELDS]
DATE_FIELDS = [k for k, _l, kind in FIELDS if kind == "date"]
TRACKED = ("status", "pic", "exception", "target_on", "completed_on", "report_shared", "cat1", "cat2", "env")
CARRY = ("status", "pic", "exception", "target_on", "cat1", "cat2", "env")     # from the previous quarter, when blank

STATUSES = [("open", "Open"), ("fixed", "Fixed"), ("pending_review", "Pending review"), ("false_positive", "False positive"),
            ("pending_deviation", "Pending deviation approval"), ("deviation_approved", "Deviation approved"),
            ("decommission", "Decommission")]
STATUS = dict(STATUSES)
OPEN_STATUSES = ("open", "pending_review", "pending_deviation")
NO_ACTION = ("fixed", "decommission")             # kept in their own section: nothing left to do
SEVERITIES = [(4, "Critical"), (3, "High"), (2, "Medium"), (1, "Low"), (0, "Info")]
SEV = dict(SEVERITIES)
KINDS = {"server": "Server", "network": "Network device", "appliance": "Appliance", "unknown": "Type not known",
         "not_in_inventory": "Not in the inventory"}

MAX_BYTES = 60 * 1024 * 1024               # one request (nginx takes 64 MB): a big CSV is gzipped by the browser
MAX_UNPACKED = 800 * 1024 * 1024           # what an xlsx or a gzipped CSV may unpack to
MAX_COLS = 200
MAX_ROWS = 500_000                          # per sheet
MAX_DISTINCT = 60
EXCEL_CELL_MAX = 32767
STALL_S = 180                               # no heartbeat for this long: the reading / import stopped


def norm(text):
    """A heading or a word, compared: lower case, letters and digits only ("Severity " = "severity")."""
    return re.sub(r"[^a-z0-9]+", "", str(text or "").lower())


def norm_word(text):
    """A status word, compared: lower case, single spaces ("Pending  Review" = "pending review")."""
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", str(text or "").lower())).strip()


# Headings each field is known by: the template's (as written, with its own spellings) and Nessus's own exports
SYNONYMS = {
    "uuid": ["UUID", "Finding ID", "Unique ID"],
    "plugin_id": ["Plugin", "Plugin ID", "PluginID", "Plugin No", "Nessus Plugin ID"],
    "plugin_name": ["Plugin name", "Name", "Plugin Title", "Vulnerability", "Vulnerability Name", "Finding", "Title"],
    "severity": ["Severity", "Risk", "Risk Factor", "Severity Level", "Risk Rating"],
    "ip": ["IP address", "IP", "Host", "IP Address(es)", "Host IP", "Target", "IPv4"],
    "env": ["UAT/Prod", "Environment", "Env", "Prod/UAT", "UAT / Prod"],
    "hostname": ["Hostname", "Host name", "DNS Name", "NetBIOS Name", "FQDN", "Server", "Server Name", "Asset Name"],
    "pic": ["PIC", "Engineer", "Owner", "Assigned To", "Assignee", "Person in charge", "Responsible"],
    "port": ["port", "Port Number"],
    "plugin_output": ["Plugin output", "Output", "Plugin Text"],
    "synopsis": ["Synopsis", "Summary"],
    "description": ["Description", "Details"],
    "solution": ["Steps to Remediate", "Solution", "Remediation", "Fix", "Recommendation", "Remediation Steps"],
    "prev_finding": ["Previous Finding", "Previously Found", "Repeat Finding", "Prev Finding"],
    "prev_fixed": ["Previous Fixed but discovered", "Previously Fixed but discovered", "Reopened", "Fixed but rediscovered",
                   "Previous Fixed but rediscovered"],
    "exception": ["Exception", "Exception ID", "Exception Reference", "Deviation", "Deviation Reference"],
    "status": ["Status", "Remediation Status", "Finding Status", "State"],
    "overdue": ["Overdue?", "Overdue", "Is Overdue"],
    "report_shared": ["Report Shared Date", "Report Date", "Shared Date", "Date Shared"],
    "completed_on": ["Completion Date of Remediation", "Completion Date", "Remediation Date", "Date Fixed", "Fixed Date",
                     "Closed Date"],
    "target_on": ["New Target Completion Date of Remediation", "New Target Completion Date", "Target Date",
                  "Target Completion Date", "Due Date", "New Target Date"],
    "protocol": ["Protocol"],
    "first_seen": ["First Discovered", "First Seen", "First Found"],
    "last_seen": ["Last observed", "Last Seen", "Last Found"],
    "cve": ["CVE", "CVEs", "CVE ID"],
    "vuln_pub": ["Vul Publication Date", "Vuln Publication Date", "Vulnerability Publication Date"],
    "plugin_pub": ["Plugin publication date", "Plugin Published"],
    "cat1": ["Categorization1", "Categorization 1", "Category 1", "Category1", "Categorisation1"],
    "cat2": ["Categorization2", "Categorization 2", "Category 2", "Category2", "Categorisation2"],
    "cvss3": ["CVSS v3.0 Base Score", "CVSS v3 Base Score", "CVSS3", "CVSS v3.1 Base Score", "CVSS 3"],
    "cvss2": ["CVSS v2.0 Base Score", "CVSS v2 Base Score", "CVSS2", "CVSS"],
}
EXACT = {}
for _f, _names in SYNONYMS.items():
    for _n in _names:
        EXACT.setdefault(norm(_n), _f)
CLOSE_MIN = 0.88                            # a heading this close to a known one (and long enough) is that field


def rule_field(header):
    """(field, how, why) by PATCH-01's own rules, or (None, None, None)."""
    n = norm(header)
    if not n:
        return None, None, None
    if n in EXACT:
        return EXACT[n], "rule", "the heading is a known name for " + FIELD[EXACT[n]][0]
    if len(n) >= 6:
        best, score = None, 0.0
        for known, f in EXACT.items():
            if len(known) < 6:
                continue
            s = difflib.SequenceMatcher(None, n, known).ratio()
            if s > score:
                best, score = (known, f), s
        if best and score >= CLOSE_MIN:
            return best[1], "close", f"the heading is a close spelling of a known name for {FIELD[best[1]][0]}"
    return None, None, None


STATUS_WORDS = {
    "": "open", "open": "open", "new": "open", "not fixed": "open", "outstanding": "open", "unresolved": "open",
    "fixed": "fixed", "closed": "fixed", "resolved": "fixed", "remediated": "fixed", "done": "fixed", "patched": "fixed",
    "pending review": "pending_review", "under review": "pending_review", "in review": "pending_review",
    "review": "pending_review", "to review": "pending_review",
    "false positive": "false_positive", "fp": "false_positive", "false positives": "false_positive",
    "pending deviation approval": "pending_deviation", "pending deviation": "pending_deviation",
    "deviation pending": "pending_deviation", "pending deviation approved": "pending_deviation",
    "pending exception approval": "pending_deviation", "deviation approval pending": "pending_deviation",
    "deviation approved": "deviation_approved", "approved deviation": "deviation_approved",
    "exception approved": "deviation_approved", "risk accepted": "deviation_approved",
    "decommission": "decommission", "decommissioned": "decommission", "decom": "decommission",
    "to be decommissioned": "decommission", "decommissioning": "decommission",
}


def severity_of(v):
    """4..0 from a word or a number, or None when the value says nothing."""
    s = norm(v)
    if s in ("critical", "crit", "4", "40", "p1"):
        return 4
    if s in ("high", "3", "30"):
        return 3
    if s in ("medium", "med", "moderate", "2", "20"):
        return 2
    if s in ("low", "1", "10"):
        return 1
    if s in ("info", "informational", "none", "0", "00", "information"):
        return 0
    return None


# ---------------------------------------------------------------------------
# Values
# ---------------------------------------------------------------------------

def text(v):
    """A cell as text: numbers without a stray .0, dates as YYYY-MM-DD, spaces trimmed."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, float):
        if v != v:                                          # NaN
            return ""
        return str(int(v)) if v.is_integer() else repr(v)
    if isinstance(v, datetime):
        return v.date().isoformat() if (v.hour, v.minute, v.second) == (0, 0, 0) else v.isoformat(sep=" ")
    if isinstance(v, date):
        return v.isoformat()
    return str(v).replace("\x00", "").strip()


_MONTHS = {m: i + 1 for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"])}
_DMY = re.compile(r"^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2}|\d{4})(?:[ T].*)?$")
_YMD = re.compile(r"^(\d{4})[/.\-](\d{1,2})[/.\-](\d{1,2})(?:[ T].*)?$")
_DMONY = re.compile(r"^(\d{1,2})[ \-/]([A-Za-z]{3,9})[ \-/,]+(\d{2}|\d{4})(?:[ T].*)?$")
_MONDY = re.compile(r"^([A-Za-z]{3,9})\.? (\d{1,2}),? (\d{4})(?:[ T,].*)?$")       # Nessus: "Nov 13, 2026 10:00:00 UTC"


def _year(y):
    y = int(y)
    return y + 2000 if y < 100 else y


def slash_order(v):
    """For a d/m/y-or-m/d/y date written as text: 'dmy' or 'mdy' when the numbers prove it, 'either' when both
    could be meant, None when it is not such a date."""
    if isinstance(v, (date, datetime)):
        return None
    m = _DMY.match(text(v))
    if not m:
        return None
    a, b = int(m.group(1)), int(m.group(2))
    if a > 12 and b <= 12:
        return "dmy"
    if b > 12 and a <= 12:
        return "mdy"
    return "either" if a <= 12 and b <= 12 else None


def parse_date(v, order=None):
    """A date from a cell, or None. order ('dmy' / 'mdy') decides 03/04/2026; without it such a value is None."""
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if 20000 <= v <= 80000:                             # an Excel day number (1954 .. 2119)
            return date(1899, 12, 30) + timedelta(days=int(v))
        return None
    s = text(v)
    if re.fullmatch(r"\d{5}(\.\d+)?", s):
        return parse_date(float(s))
    try:
        m = _YMD.match(s)
        if m:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        m = _DMY.match(s)
        if m:
            a, b, y = int(m.group(1)), int(m.group(2)), _year(m.group(3))
            o = slash_order(s)
            if o == "either":
                o = order
            if o == "dmy":
                return date(y, b, a)
            if o == "mdy":
                return date(y, a, b)
            return None
        m = _DMONY.match(s)
        if m and m.group(2)[:3].lower() in _MONTHS:
            return date(_year(m.group(3)), _MONTHS[m.group(2)[:3].lower()], int(m.group(1)))
        m = _MONDY.match(s)
        if m and m.group(1)[:3].lower() in _MONTHS:
            return date(int(m.group(3)), _MONTHS[m.group(1)[:3].lower()], int(m.group(2)))
    except ValueError:                                      # 31/02/2026 and the like
        return None
    return None


def is_ip(v):
    try:
        ipaddress.ip_address(text(v))
        return True
    except ValueError:
        return False


def split_cat2(v):
    """"ER-2026Q3-M07:OS Patch & Core Security" -> ("ER-2026Q3-M07", "OS Patch & Core Security"); else (None, None)."""
    m = re.match(r"^\s*([A-Za-z]{1,8}-[A-Za-z0-9][A-Za-z0-9\-_.]*)\s*[:|]\s*(.+?)\s*$", text(v))
    return (m.group(1), m.group(2)) if m else (None, None)


def quarter_of(name):
    """"26Q3", "2026 Q3", "Q3-2026", "2026-Q3" -> "2026 Q3"; anything else -> None."""
    s = re.sub(r"\s+", " ", text(name)).strip()
    m = re.fullmatch(r"(?i)(?:FY\s?)?(\d{2}|\d{4})\s?[-_ ]?\s?Q([1-4])", s) \
        or re.fullmatch(r"(?i)Q([1-4])\s?[-_ ]?\s?(?:FY\s?)?(\d{2}|\d{4})", s)
    if not m:
        return None
    y, q = (m.group(1), m.group(2)) if s[:1].isdigit() or s[:2].upper() == "FY" else (m.group(2), m.group(1))
    y = _year(y)
    return f"{y} Q{q}" if 2000 <= y <= 2099 else None


def qkey(quarter):
    m = re.fullmatch(r"(\d{4}) Q([1-4])", quarter or "")
    return int(m.group(1)) * 10 + int(m.group(2)) if m else 0


def short_label(quarter):
    """"2026 Q3" -> "26Q3" (the sheet name the files use)."""
    m = re.fullmatch(r"\d{2}(\d{2}) Q([1-4])", quarter or "")
    return f"{m.group(1)}Q{m.group(2)}" if m else (quarter or "")


# ---------------------------------------------------------------------------
# Reading files
# ---------------------------------------------------------------------------

def file_type_of(name):
    n = (name or "").lower()
    if n.endswith((".xlsx", ".xlsm")):
        return "xlsx"
    if n.endswith((".csv", ".csv.gz", ".txt")):
        return "csv"
    if n.endswith(".xls"):
        raise RemError("Old .xls files cannot be read: open it in Excel and save it as .xlsx (Excel Workbook), then upload that.")
    raise RemError("Upload the scan workbook as .xlsx or .csv.")


def unpack(data, gz):
    """The file as uploaded; a gzipped body (the browser packs big CSV files) is unpacked, with a size limit."""
    if not gz:
        return data
    try:
        with gzip.GzipFile(fileobj=io.BytesIO(data)) as g:
            out = g.read(MAX_UNPACKED + 1)
    except (OSError, EOFError) as e:
        raise RemError(f"The upload could not be unpacked: {e}")
    if len(out) > MAX_UNPACKED:
        raise RemError("The file is larger than 800 MB unpacked.")
    return out


def _check_xlsx(data):
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise RemError("This is not an Excel .xlsx file (it is not a zip package). Save it from Excel as .xlsx and upload again.")
    if sum(i.file_size for i in z.infolist()) > MAX_UNPACKED:
        raise RemError("The workbook is larger than 800 MB unpacked.")
    if "xl/workbook.xml" not in z.namelist():
        raise RemError("This zip file is not an Excel workbook.")


def _decode(data):
    if data[:3] == b"\xef\xbb\xbf":
        return data[3:].decode("utf-8", "replace")
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return data.decode("utf-16", "replace")
    if len(data) > 3 and data[1:2] == b"\x00" and data[3:4] == b"\x00":
        return data.decode("utf-16-le", "replace")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("cp1252", "replace")


def sheets_of(data, ftype, csv_name="Sheet1"):
    """[(sheet name, hidden, row iterator)], the rows as lists of cell values."""
    if ftype == "xlsx":
        import openpyxl
        _check_xlsx(data)
        try:
            wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        except Exception as e:  # noqa: BLE001 - a damaged workbook
            raise RemError(f"The workbook could not be opened: {type(e).__name__}: {str(e)[:200]}")
        return [(ws.title, getattr(ws, "sheet_state", "visible") != "visible", ws.iter_rows(values_only=True))
                for ws in wb.worksheets]
    body = _decode(data)
    first = body.split("\n", 1)[0]
    delim = max([",", ";", "\t", "|"], key=first.count)
    csv.field_size_limit(10 * 1024 * 1024)
    return [(csv_name, False, csv.reader(io.StringIO(body, newline=""), delimiter=delim))]


def _cells(row):
    row = list(row or ())
    while row and (row[-1] is None or text(row[-1]) == ""):
        row.pop()
    return row[:MAX_COLS]


def _header_score(row):
    """(known fields matched, whether it has a finding's identity) for a candidate heading row."""
    fields = set()
    for v in row:
        f, _h, _w = rule_field(v)
        if f:
            fields.add(f)
    ident = ("plugin_id" in fields or "uuid" in fields) and bool(fields & {"ip", "hostname", "uuid"})
    return len(fields), ident


def scan_sheet(name, hidden, rows):
    """One pass over a sheet: heading, samples, row count, per-column distinct values and date order."""
    head, head_rn, pre = None, None, []
    best = (0, False, None, None)
    for rn, row in enumerate(rows, start=1):
        cells = _cells(row)
        if rn <= 30:
            pre.append((rn, cells))
            n, ident = _header_score(cells)
            if ident and n > best[0]:
                best = (n, ident, rn, cells)
            if rn < 30:
                continue
        break
    else:
        rn = None
    findings = best[2] is not None and best[0] >= 3
    if findings:
        head_rn, head = best[2], best[3]
    else:                                              # not a findings sheet (a summary): its first non-empty row
        for r0, cells in pre:
            if any(text(c) for c in cells):
                head_rn, head = r0, cells
                break
    info = {"name": name, "hidden": hidden, "findings": findings, "header_row": head_rn,
            "headers": [text(h) for h in (head or [])], "rows": 0, "samples": [],
            "distinct": [], "date_order": [], "too_many_rows": False, "too_many_cols": False}
    if head is None:
        return info
    ncol = len(head)
    distinct = [dict() for _ in range(ncol)]
    over = [False] * ncol
    orders = [set() for _ in range(ncol)]

    def take(cells):
        if not any(text(c) for c in cells):
            return
        info["rows"] += 1
        if len(cells) > ncol and any(text(c) for c in cells[ncol:]):
            info["too_many_cols"] = True
        if len(info["samples"]) < 5:
            info["samples"].append([text(c)[:160] for c in cells[:ncol]] + [""] * (ncol - min(len(cells), ncol)))
        for i in range(min(ncol, len(cells))):
            v = cells[i]
            t = text(v)
            if not t:
                continue
            o = slash_order(v)
            if o:
                orders[i].add(o)
            if not over[i]:
                k = t[:80]
                d = distinct[i]
                if k in d:
                    d[k] += 1
                elif len(d) < MAX_DISTINCT:
                    d[k] = 1
                else:
                    over[i] = True

    for r0, cells in pre:
        if r0 > head_rn:
            take(cells)
    if rn is not None:                                  # the 30 rows were not the end: read on
        for row in rows:
            take(_cells(row))
            if info["rows"] > MAX_ROWS:
                info["too_many_rows"] = True
                break
    info["distinct"] = [{"values": sorted(d.items(), key=lambda x: -x[1])[:MAX_DISTINCT], "more": over[i]}
                        for i, d in enumerate(distinct)]
    info["date_order"] = [("mixed" if {"dmy", "mdy"} <= o else "dmy" if "dmy" in o else "mdy" if "mdy" in o
                           else "either" if "either" in o else None) for o in orders]
    return info


# ---------------------------------------------------------------------------
# Column mapping
# ---------------------------------------------------------------------------

def place_columns(info, memory):
    """Fills info["map"]: per column {field, how, why}. A person's earlier choice for the heading first, then the rules.
    A field is given to one column only (the first that claims it); a second is left for the operator."""
    used, out = set(), []
    for i, h in enumerate(info["headers"]):
        n = norm(h)
        f, how, why = None, None, None
        if n and n in memory:
            f, how, why = memory[n], "saved", "chosen for this heading before"
            if f == "ignore":
                f, why = None, "chosen before: not used"
        if not how:
            f, how, why = rule_field(h)
        if f and f in used:
            f, why = None, f"{FIELD[f][0]} is already taken by an earlier column"
            how = "clash"
        if f:
            used.add(f)
        out.append({"field": f, "how": how, "why": why})
    info["map"] = out
    return info


def _shape_ok(field, values):
    """Whether sample values look like the field (AI-01's suggestions are checked against them)."""
    vals = [v for v in values if v][:12]
    if not vals:
        return True
    kind = FIELD[field][1]
    hit = 0
    for v in vals:
        if kind == "date":
            hit += bool(parse_date(v, "dmy") or slash_order(v))
        elif kind == "severity":
            hit += severity_of(v) is not None
        elif kind == "ip":
            hit += is_ip(v) or bool(re.fullmatch(r"[A-Za-z0-9.\-]+", v))
        elif kind == "port":
            hit += bool(re.fullmatch(r"\d{1,5}(/(tcp|udp))?", v.lower()))
        elif kind == "num":
            hit += bool(re.fullmatch(r"\d{1,2}(\.\d+)?", v))
        else:
            hit += 1
    return hit * 2 >= len(vals)


AI_SYSTEM = ("You read the column headings of a Nessus vulnerability scan workbook that a security team keeps, with a "
             "few sample values of each column, and say which field each column holds. Choose only from the fields "
             "given; answer \"none\" when no field fits or you are not sure. Base each answer on the heading and the "
             "values together, and say why in a few words. Answer with JSON only.")


def ai_messages(cols):
    fields = [{"field": k, "means": FIELD[k][0]} for k in FIELD_KEYS]
    data = {"fields": fields, "columns": cols}
    return [{"role": "system", "content": AI_SYSTEM},
            {"role": "user", "content": json.dumps(data, ensure_ascii=False)}]


AI_SCHEMA = {"type": "object", "properties": {"columns": {"type": "array", "items": {
    "type": "object", "properties": {"col": {"type": "integer"}, "field": {"enum": FIELD_KEYS + ["none"]},
                                     "why": {"type": "string", "maxLength": 160}},
    "required": ["col", "field", "why"]}}}, "required": ["columns"]}
AI_BATCH = 12


def ai_place(info, ask):
    """AI-01 for the columns no rule or earlier choice placed. ask(messages, schema) -> JSON text. Each suggestion is
    checked: the field must exist, be free, and fit the sample values; else the column stays unplaced, with why.
    Returns how many were placed."""
    todo = [i for i, m in enumerate(info["map"]) if not m["field"] and m["how"] not in ("saved", "you") and info["headers"][i]]
    placed = 0
    used = {m["field"] for m in info["map"] if m["field"]}
    for s in range(0, len(todo), AI_BATCH):
        part = todo[s:s + AI_BATCH]
        cols = []
        for i in part:
            vals = [v for v, _n in (info["distinct"][i]["values"] if i < len(info["distinct"]) else [])][:3]
            cols.append({"col": i, "heading": info["headers"][i][:80], "values": [str(v)[:60] for v in vals]})
        raw = ask(ai_messages(cols), AI_SCHEMA)
        try:
            ans = json.loads(raw)["columns"]
        except (ValueError, KeyError, TypeError):
            raise RemError("AI-01 gave an answer that is not the expected JSON. Place these columns yourself, or ask again.")
        for a in ans if isinstance(ans, list) else []:
            try:
                i, f, why = int(a.get("col")), a.get("field"), str(a.get("why") or "")[:160]
            except (TypeError, ValueError, AttributeError):
                continue
            if i not in part or info["map"][i]["field"]:
                continue
            m = info["map"][i]
            if f == "none" or f not in FIELD:
                m.update(how="ai", why="AI-01: no field fits" + (" (" + why + ")" if why else ""))
                continue
            vals = [v for v, _n in info["distinct"][i]["values"]]
            if f in used:
                m.update(how="ai", why=f"AI-01 said {FIELD[f][0]}, but another column already holds it")
            elif not _shape_ok(f, vals):
                m.update(how="ai", why=f"AI-01 said {FIELD[f][0]}, but the values do not look like it")
            else:
                m.update(field=f, how="ai", why="AI-01: " + (why or FIELD[f][0]))
                used.add(f)
                placed += 1
    return placed


def status_column(info):
    for i, m in enumerate(info.get("map") or []):
        if m["field"] == "status":
            return i
    return None


def status_words_found(info, words):
    """The status column's words: [{word, count, status (known or None), how}]."""
    i = status_column(info)
    if i is None or i >= len(info["distinct"]):
        return []
    out = []
    for v, n in info["distinct"][i]["values"]:
        w = norm_word(v)
        st, how = (words.get(w), "saved") if w in words else (STATUS_WORDS.get(w), "rule") if w in STATUS_WORDS else (None, None)
        out.append({"word": v, "norm": w, "count": n, "status": st, "how": how})
    return out


def check_sheet(info, words, given_words=None, date_order=None):
    """What stops this sheet from being imported, as sentences (empty: it can be)."""
    problems = []
    fields = [m["field"] for m in info["map"] if m["field"]]
    dup = sorted({f for f in fields if fields.count(f) > 1})
    for f in dup:
        problems.append(f"Two columns are set to {FIELD[f][0]}: choose one.")
    have = set(fields)
    if "severity" not in have:
        problems.append("No column is set to Severity.")
    if not have & {"plugin_id", "uuid"}:
        problems.append("No column is set to Plugin (or UUID).")
    if not have & {"ip", "hostname", "uuid"}:
        problems.append("No column is set to IP address or Hostname (or UUID).")
    if not quarter_of(info.get("quarter") or ""):
        problems.append("Say which quarter this sheet is (for example 2026 Q3).")
    allw = dict(words)
    allw.update({norm_word(k): v for k, v in (given_words or {}).items() if v in STATUS})
    unknown = [w["word"] for w in status_words_found(info, allw) if not w["status"] and w["norm"] not in STATUS_WORDS]
    if unknown:
        problems.append("Say what these status words mean: " + ", ".join(repr(w) for w in unknown[:12]) + ".")
    i = status_column(info)
    if i is not None and i < len(info["distinct"]) and info["distinct"][i]["more"]:
        problems.append(f"The status column has more than {MAX_DISTINCT} different values: is it really the status?")
    for j, m in enumerate(info["map"]):
        if m["field"] in DATE_FIELDS and j < len(info["date_order"]):
            o = info["date_order"][j]
            if o in ("either", "mixed") and date_order not in ("dmy", "mdy"):
                problems.append("Some dates could be day/month or month/day (for example 03/04/2026): say which.")
                break
    return problems


# ---------------------------------------------------------------------------
# Rows -> findings
# ---------------------------------------------------------------------------

def row_values(cells, mapping, order, headers):
    """One sheet row as {field: value} plus the file's other columns and the dates that were not dates."""
    out, extra, raw = {}, {}, {}
    for i, m in enumerate(mapping):
        v = cells[i] if i < len(cells) else None
        f = m.get("field")
        if not f:
            t = text(v)
            if t and i < len(headers) and headers[i]:
                extra[headers[i][:120]] = t[:EXCEL_CELL_MAX]
            continue
        kind = FIELD[f][1]
        if kind == "date":
            d = parse_date(v, order)
            out[f] = d
            if d is None and text(v):
                raw[f] = text(v)[:200]
        elif kind == "long":
            out[f] = text(v)[:200_000]
        else:
            out[f] = text(v)[:2000]
    if raw:
        extra["_raw"] = raw
    return out, extra


def finding_of(vals, words):
    """The finding's columns from one row's values, or (None, why) when the row has no plugin or host."""
    v = dict(vals)
    uid = v.get("uuid") or ""
    if uid and "|" in uid:
        parts = [p.strip() for p in uid.split("|")]
        if not v.get("plugin_id") and parts[0]:
            v["plugin_id"] = parts[0]
        if not v.get("ip") and not v.get("hostname") and len(parts) > 1 and parts[1]:
            v["ip"] = parts[1]
    ip, host = (v.get("ip") or "").strip(), (v.get("hostname") or "").strip()
    if ip and not is_ip(ip) and not host:                 # Nessus's "Host" is a name when scanned by name
        host, ip = ip, ""
    plugin = (v.get("plugin_id") or "").strip()
    if not plugin or not (ip or host):
        return None, "no plugin" if not plugin else "no IP address or host name"
    port, proto = (v.get("port") or "").strip(), (v.get("protocol") or "").strip()
    m = re.fullmatch(r"(\d{1,5})\s*/\s*(tcp|udp|icmp)", port.lower())
    if m and not proto:
        port, proto = m.group(1), m.group(2)
    hk = short_name(host) if host else (ip.lower() if ip else "")
    if not hk:
        hk = (host or ip).lower()[:200]
    sev_text = (v.get("severity") or "").strip()
    st_text = (v.get("status") or "").strip()
    w = norm_word(st_text)
    status = (words.get(w) or STATUS_WORDS.get(w)) if st_text else None
    er_code, er_title = split_cat2(v.get("cat2"))
    f = {
        "fkey": "|".join([plugin, ip or host, port, proto]).lower()[:600],
        "host_key": hk[:255], "uuid_text": uid or None, "plugin_id": plugin, "plugin_name": v.get("plugin_name") or None,
        "severity": severity_of(sev_text), "severity_text": sev_text or None, "ip": ip or None, "hostname": host or None,
        "env": v.get("env") or None, "pic": v.get("pic") or None, "port": port or None, "protocol": proto or None,
        "plugin_output": v.get("plugin_output") or None, "synopsis": v.get("synopsis") or None,
        "description": v.get("description") or None, "solution": v.get("solution") or None, "cve": v.get("cve") or None,
        "cvss3": v.get("cvss3") or None, "cvss2": v.get("cvss2") or None,
        "prev_finding": v.get("prev_finding") or None, "prev_fixed": v.get("prev_fixed") or None,
        "exception": v.get("exception") or None, "status": status, "status_text": st_text or None,
        "overdue_text": v.get("overdue") or None, "cat1": v.get("cat1") or None, "cat2": v.get("cat2") or None,
        "er_code": er_code, "er_title": er_title,
    }
    for k in DATE_FIELDS:
        f[k] = v.get(k)
    return f, None


# ---------------------------------------------------------------------------
# Database helpers (the same code runs on psycopg and on the tests' psql shim)
# ---------------------------------------------------------------------------

def _iso(v):
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.isoformat()
    if isinstance(v, date):
        return v.isoformat()
    return str(v)


def _day(v):
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    return date.fromisoformat(str(v)[:10])


def _bytes(v):
    if v is None:
        return None
    if isinstance(v, memoryview):
        return v.tobytes()
    if isinstance(v, (bytes, bytearray)):
        return bytes(v)
    s = str(v)
    return bytes.fromhex(s[2:]) if s.startswith("\\x") else s.encode()


def _json(v):
    if v is None or isinstance(v, (dict, list)):
        return v
    return json.loads(v)


def _words(conn):
    return {r["word_norm"]: r["status"] for r in conn.execute("SELECT word_norm, status FROM rem_status_words").fetchall()}


def _memory(conn):
    return {r["header_norm"]: r["field"] for r in conn.execute("SELECT header_norm, field FROM rem_header_memory").fetchall()}


UPLOAD_COLS = ("id, file_name, size_bytes, file_type, state, sheets, progress, options, result, error, created_by, created_at, "
               "updated_at, imported_by, imported_at, (data IS NOT NULL) AS kept")


def _upload(conn, uid, data=False):
    """One upload; its file (up to 60 MB) only when the reading or the import needs it, never for a progress poll."""
    r = conn.execute("SELECT " + UPLOAD_COLS + (", data" if data else "") + " FROM rem_uploads WHERE id = %s", (uid,)).fetchone()
    if not r:
        raise NotFound("No such upload.")
    return dict(r)


def _beat(conn, uid, phase, done, total):
    conn.execute("UPDATE rem_uploads SET progress = %s::jsonb, updated_at = now() WHERE id = %s",
                 (json.dumps({"phase": phase, "done": done, "total": total}), uid))
    conn.commit()


# ---------------------------------------------------------------------------
# Upload lifecycle
# ---------------------------------------------------------------------------

def start_upload(conn, user, name, data, gz=False):
    """Stores the file and returns its id; the reading runs next (read_upload), in the background."""
    name = re.sub(r"[\x00-\x1f\\/]+", " ", (name or "scan.xlsx")).strip()[:200] or "scan.xlsx"
    ftype = file_type_of(name[:-3] if name.lower().endswith(".gz") else name)
    if not data:
        raise RemError("The file is empty.")
    data = unpack(data, gz or name.lower().endswith(".gz"))
    if ftype == "xlsx":
        _check_xlsx(data)
    # uploads left unconfirmed for a week, and failed ones: their files are let go
    conn.execute("""UPDATE rem_uploads SET data = NULL, state = 'discarded'
                     WHERE state IN ('review', 'failed') AND created_at < now() - interval '7 days'""")
    r = conn.execute("""INSERT INTO rem_uploads (file_name, size_bytes, file_type, data, state, created_by, progress)
                        VALUES (%s, %s, %s, %s, 'reading', %s, %s::jsonb) RETURNING id""",
                     (name, len(data), ftype, data, user, json.dumps({"phase": "reading", "done": 0, "total": 0}))).fetchone()
    conn.commit()
    return str(r["id"])


def read_upload(conn, uid):
    """Reading: every sheet once. Ends in 'review' (or 'failed' with the reason)."""
    u = _upload(conn, uid, data=True)
    if u["state"] != "reading":
        return
    try:
        data = _bytes(u["data"])
        if data is None:
            raise RemError("The file is no longer kept: upload it again.")
        memory, words = _memory(conn), _words(conn)
        base = re.sub(r"\.(csv|txt)(\.gz)?$", "", u["file_name"], flags=re.I)
        sheets = []
        found = sheets_of(data, u["file_type"], csv_name=base[:31] or "Sheet1")
        for n, (name, hidden, rows) in enumerate(found, start=1):
            _beat(conn, uid, "reading", n - 1, len(found))
            info = scan_sheet(name, hidden, rows)
            place_columns(info, memory)
            info["quarter"] = quarter_of(name) or ""
            info["quarter_from"] = "sheet name" if info["quarter"] else None
            info["use"] = bool(info["findings"]) and not hidden
            info["words"] = status_words_found(info, words)
            sheets.append(info)
        if not any(s["findings"] for s in sheets):
            note = ("No sheet has the columns of a scan (a Plugin or UUID column, and an IP address or Hostname "
                    "column). Check the file, or set its columns yourself below.")
        else:
            note = None
        conn.execute("""UPDATE rem_uploads SET sheets = %s::jsonb, state = 'review', error = %s, updated_at = now(),
                               progress = %s::jsonb WHERE id = %s AND state = 'reading'""",
                     (json.dumps(sheets, default=str), note, json.dumps({"phase": "read", "done": len(found), "total": len(found)}), uid))
        conn.commit()
    except Exception as e:  # noqa: BLE001 - every failure ends the reading with its reason
        conn.rollback()
        msg = str(e) if isinstance(e, RemError) else f"The file could not be read: {type(e).__name__}: {str(e)[:300]}"
        conn.execute("UPDATE rem_uploads SET state = 'failed', error = %s, updated_at = now() WHERE id = %s", (msg, uid))
        conn.commit()


def suggest(conn, uid, ask):
    """AI-01 for the columns still unplaced, in every sheet. Returns how many it placed."""
    u = _upload(conn, uid)
    if u["state"] != "review":
        raise RemError("This upload is not waiting for its columns to be confirmed.")
    sheets = _json(u["sheets"]) or []
    placed = 0
    for info in sheets:
        if info.get("headers"):
            placed += ai_place(info, ask)
            info["words"] = status_words_found(info, _words(conn))
    conn.execute("UPDATE rem_uploads SET sheets = %s::jsonb, updated_at = now() WHERE id = %s",
                 (json.dumps(sheets, default=str), uid))
    conn.commit()
    return placed


def confirm(conn, uid, user, body):
    """The operator's confirmation: per sheet use, quarter and columns; status words; day/month order.
    Checks everything, remembers the choices, and sets the upload to 'importing'. Raises RemError with every problem."""
    u = _upload(conn, uid)
    if u["state"] != "review":
        raise RemError("This upload is not waiting for its columns to be confirmed.")
    sheets = _json(u["sheets"]) or []
    by_name = {s["name"]: s for s in sheets}
    given = {s.get("name"): s for s in body.get("sheets") or []}
    words_given = {norm_word(k): v for k, v in (body.get("status_words") or {}).items()}
    bad = [v for v in words_given.values() if v not in STATUS]
    if bad:
        raise RemError("Unknown status: " + ", ".join(map(str, bad[:5])))
    order = body.get("date_order") or None
    if order not in (None, "dmy", "mdy"):
        raise RemError("Day/month order is dmy or mdy.")
    words = _words(conn)
    problems, used_quarters = [], {}
    for name, g in given.items():
        if name not in by_name:
            raise RemError(f"The file has no sheet named {name!r}.")
    for info in sheets:
        g = given.get(info["name"])
        if g is None:
            info["use"] = False
            continue
        info["use"] = bool(g.get("use"))
        if not info["use"]:
            continue
        q = quarter_of(g.get("quarter") or info.get("quarter") or "")
        info["quarter"] = q or (g.get("quarter") or "")
        cols = g.get("columns")
        if cols is not None:
            if len(cols) != len(info["headers"]):
                raise RemError(f"Sheet {info['name']}: the columns sent do not match the file's.")
            for i, f in enumerate(cols):
                f = f or None
                if f is not None and f not in FIELD:
                    raise RemError(f"Sheet {info['name']}: unknown field {f!r}.")
                m = info["map"][i]
                if f != m["field"]:
                    m.update(field=f, how="you", why="chosen by " + user)
        p = check_sheet(info, words, words_given, order)
        problems += [f"Sheet {info['name']}: {x}" for x in p]
        if q:
            used_quarters.setdefault(q, []).append(info["name"])
    if not any(s.get("use") for s in sheets):
        problems.append("Choose at least one sheet to import.")
    if problems:
        raise RemError(" ".join(problems))
    # remembered for every later file: the headings a person (or AI-01, confirmed) placed, and the status words
    for info in sheets:
        if not info.get("use"):
            continue
        for h, m in zip(info["headers"], info["map"]):
            n = norm(h)
            if not n:
                continue
            # a person's choice (a column left out too), and AI-01's and the close spellings once confirmed
            if m["how"] == "you" or (m["how"] in ("ai", "close") and m["field"]):
                conn.execute("""INSERT INTO rem_header_memory (header_norm, field, set_by) VALUES (%s, %s, %s)
                                ON CONFLICT (header_norm) DO UPDATE SET field = EXCLUDED.field, set_by = EXCLUDED.set_by,
                                                                        set_at = now()""",
                             (n, m["field"] or "ignore", user))
    for w, st in words_given.items():
        if STATUS_WORDS.get(w) != st:
            conn.execute("""INSERT INTO rem_status_words (word_norm, status, set_by) VALUES (%s, %s, %s)
                            ON CONFLICT (word_norm) DO UPDATE SET status = EXCLUDED.status, set_by = EXCLUDED.set_by,
                                                                  set_at = now()""", (w, st, user))
    opts = {"remove_missing": bool(body.get("remove_missing")), "date_order": order}
    conn.execute("""UPDATE rem_uploads SET sheets = %s::jsonb, options = %s::jsonb, state = 'importing', error = NULL,
                           imported_by = %s, updated_at = now(), progress = %s::jsonb WHERE id = %s AND state = 'review'""",
                 (json.dumps(sheets, default=str), json.dumps(opts), user,
                  json.dumps({"phase": "importing", "done": 0, "total": sum(s["rows"] for s in sheets if s.get("use"))}), uid))
    conn.commit()
    return sorted(used_quarters)


def discard(conn, uid):
    u = _upload(conn, uid)
    if u["state"] in ("imported", "discarded"):
        raise RemError("This upload is already " + u["state"] + ".")
    if u["state"] in ("reading", "importing") and not stalled(u):
        raise RemError("This upload is being " + ("read" if u["state"] == "reading" else "imported") + ": wait for it to finish.")
    conn.execute("UPDATE rem_uploads SET state = 'discarded', data = NULL, updated_at = now() WHERE id = %s", (uid,))
    conn.commit()


def stalled(u):
    if u["state"] not in ("reading", "importing"):
        return False
    t = u["updated_at"]
    if isinstance(t, str):
        t = datetime.fromisoformat(t)
    return (datetime.now(timezone.utc) - t).total_seconds() > STALL_S


def retry(conn, uid):
    """A reading or import that stopped (the API restarted) is started again from the start."""
    u = _upload(conn, uid)
    if not (stalled(u) or u["state"] == "failed"):
        raise RemError("This upload has not stopped.")
    if not u["kept"]:
        raise RemError("The file is no longer kept: upload it again.")
    state = "importing" if u.get("options") else "reading"          # confirmed: import again; else read again
    conn.execute("UPDATE rem_uploads SET state = %s, error = NULL, updated_at = now() WHERE id = %s", (state, uid))
    conn.commit()
    return state


def upload_view(conn, uid):
    u = _upload(conn, uid)
    sheets = _json(u["sheets"]) or []
    words = _words(conn)
    for s in sheets:
        if s.get("map") is not None:
            s["words"] = status_words_found(s, words)
            s["problems"] = check_sheet(s, words, None, (_json(u.get("options")) or {}).get("date_order")) if s.get("use") else []
            s["ambiguous_dates"] = any(m["field"] in DATE_FIELDS and j < len(s["date_order"]) and s["date_order"][j] in ("either", "mixed")
                                       for j, m in enumerate(s["map"]))
            s.pop("distinct", None)
    return {"id": str(u["id"]), "file_name": u["file_name"], "size_bytes": u["size_bytes"], "file_type": u["file_type"],
            "state": u["state"], "stalled": stalled(u), "sheets": sheets, "progress": _json(u["progress"]),
            "options": _json(u["options"]), "result": _json(u["result"]), "error": u["error"],
            "created_by": u["created_by"], "created_at": _iso(u["created_at"]), "imported_by": u["imported_by"],
            "imported_at": _iso(u["imported_at"]), "fields": [{"key": k, "label": l} for k, l, _k in FIELDS],
            "statuses": [{"key": k, "label": l} for k, l in STATUSES], "kept": bool(u["kept"])}


def uploads(conn, limit=20):
    rows = conn.execute("""SELECT id, file_name, size_bytes, state, created_by, created_at, imported_by, imported_at, result,
                                  error, updated_at
                             FROM rem_uploads WHERE state <> 'discarded' ORDER BY created_at DESC LIMIT %s""", (limit,)).fetchall()
    return [dict(r, id=str(r["id"]), result=_json(r["result"]), stalled=stalled(r), created_at=_iso(r["created_at"]),
                 imported_at=_iso(r["imported_at"]), updated_at=_iso(r["updated_at"])) for r in rows]


# ---------------------------------------------------------------------------
# Import
# ---------------------------------------------------------------------------

COLS = ["fkey", "host_key", "uuid_text", "plugin_id", "plugin_name", "severity", "severity_text", "ip", "hostname", "env",
        "pic", "port", "protocol", "plugin_output", "synopsis", "description", "solution", "cve", "cvss3", "cvss2",
        "prev_finding", "prev_fixed", "exception", "status", "status_text", "overdue_text", "report_shared",
        "completed_on", "target_on", "first_seen", "last_seen", "vuln_pub", "plugin_pub", "cat1", "cat2", "er_code",
        "er_title"]
BATCH = 1000


def _prev_quarter(conn, quarter):
    r = conn.execute("SELECT max(quarter) AS q FROM rem_findings WHERE quarter < %s", (quarter,)).fetchone()
    return r["q"] if r else None


def run_import(conn, uid, inventory=None):
    """Importing: the file read again with the confirmed columns, merged quarter by quarter. Ends in 'imported'
    (or 'failed' with the reason). Safe to run again: it gives the same result."""
    u = _upload(conn, uid, data=True)
    if u["state"] != "importing":
        return
    who = "import: " + (u["imported_by"] or u["created_by"])
    # one import at a time (two files of the same quarter must not merge into each other)
    waited = 0
    while not conn.execute("SELECT pg_try_advisory_lock(%s) AS ok", (IMPORT_LOCK,)).fetchone()["ok"]:
        _beat(conn, uid, "waiting", 0, 0)
        time.sleep(3)
        waited += 3
        if waited > 1800:
            conn.execute("UPDATE rem_uploads SET state = 'failed', error = %s, updated_at = now() WHERE id = %s",
                         ("Another import ran for more than 30 minutes; this one did not start. Try again.", uid))
            conn.commit()
            return
    try:
        _import(conn, uid, u, who, inventory)
    finally:
        try:
            conn.execute("SELECT pg_advisory_unlock(%s)", (IMPORT_LOCK,)).fetchone()
            conn.commit()
        except Exception:  # noqa: BLE001 - a lost connection takes its lock with it
            pass


IMPORT_LOCK = 7_461_301


def _import(conn, uid, u, who, inventory):
    try:
        data = _bytes(u["data"])
        if data is None:
            raise RemError("The file is no longer kept: upload it again.")
        sheets = _json(u["sheets"]) or []
        opts = _json(u["options"]) or {}
        order = opts.get("date_order")
        words = _words(conn)
        base = re.sub(r"\.(csv|txt)(\.gz)?$", "", u["file_name"], flags=re.I)
        files = {name: rows for name, _h, rows in sheets_of(data, u["file_type"], csv_name=base[:31] or "Sheet1")}
        total = sum(s["rows"] for s in sheets if s.get("use"))
        done = 0
        per_q = {}
        for info in sorted([s for s in sheets if s.get("use")], key=lambda s: qkey(s["quarter"])):
            rows = files.get(info["name"])
            if rows is None:
                raise RemError(f"The sheet {info['name']} is no longer in the file.")
            q = info["quarter"]
            st = per_q.setdefault(q, {"sheets": [], "rows": 0, "new": 0, "updated": 0, "unchanged": 0, "carried": 0,
                                      "skipped": [], "duplicates": [], "no_severity": 0, "fkeys": set()})
            st["sheets"].append(info["name"])
            batch = []
            for rn, row in enumerate(rows, start=1):
                if rn <= info["header_row"]:
                    continue
                cells = _cells(row)
                if not any(text(c) for c in cells):
                    continue
                vals, extra = row_values(cells, info["map"], order, info["headers"])
                f, why = finding_of(vals, words)
                st["rows"] += 1
                done += 1
                if f is None:
                    if len(st["skipped"]) < 200:
                        st["skipped"].append({"sheet": info["name"], "row": rn, "why": why})
                    else:
                        st["skipped_more"] = st.get("skipped_more", 0) + 1
                    continue
                if f["fkey"] in st["fkeys"]:
                    if len(st["duplicates"]) < 200:
                        st["duplicates"].append({"sheet": info["name"], "row": rn, "key": f["fkey"]})
                    continue
                st["fkeys"].add(f["fkey"])
                if f["severity"] is None:
                    st["no_severity"] += 1
                f.update(sheet=info["name"], row_no=rn, extra=extra or None)
                batch.append(f)
                if len(batch) >= BATCH:
                    _merge(conn, uid, q, batch, st, who)
                    batch = []
                    _beat(conn, uid, "importing", done, total)
                if st["rows"] > MAX_ROWS:
                    raise RemError(f"The sheet {info['name']} has more than {MAX_ROWS:,} rows.")
            _merge(conn, uid, q, batch, st, who)
            _beat(conn, uid, "importing", done, total)
        removed = {}
        if opts.get("remove_missing"):
            for q, st in per_q.items():
                keep = list(st["fkeys"])
                if not keep:
                    continue
                n = conn.execute("""DELETE FROM rem_findings WHERE quarter = %s AND NOT (fkey = ANY(%s::text[]))
                                    RETURNING id""", (q, keep)).fetchall()
                removed[q] = len(n)
        missing = {}
        for q, st in per_q.items():
            r = conn.execute("SELECT count(*) AS n FROM rem_findings WHERE quarter = %s", (q,)).fetchone()
            missing[q] = max(0, int(r["n"]) - len(st["fkeys"]))
        conn.commit()
        hosts = sorted({hk for q in per_q for hk in _hosts_of(conn, q)})
        try:
            refresh_hosts(conn, hosts, inventory)
        except Exception as e:  # noqa: BLE001 - the findings are in; the device types can be checked again
            conn.rollback()
            for st in per_q.values():
                st["inventory_error"] = f"{type(e).__name__}: {str(e)[:200]}"
        result = {q: {("findings" if k == "fkeys" else k): (len(v) if k == "fkeys" else v) for k, v in st.items()}
                  for q, st in per_q.items()}
        for q in result:
            result[q]["removed"] = removed.get(q, 0)
            result[q]["not_in_file"] = 0 if opts.get("remove_missing") else missing.get(q, 0)
            result[q]["previous"] = _prev_quarter(conn, q)
        conn.execute("""UPDATE rem_uploads SET state = 'imported', result = %s::jsonb, data = NULL, imported_at = now(),
                               updated_at = now(), progress = %s::jsonb WHERE id = %s""",
                     (json.dumps(result, default=str), json.dumps({"phase": "imported", "done": done, "total": total}), uid))
        conn.commit()
    except Exception as e:  # noqa: BLE001
        conn.rollback()
        msg = str(e) if isinstance(e, RemError) else f"The import stopped: {type(e).__name__}: {str(e)[:300]}"
        conn.execute("UPDATE rem_uploads SET state = 'failed', error = %s, updated_at = now() WHERE id = %s", (msg, uid))
        conn.commit()


def _hosts_of(conn, q):
    return [r["host_key"] for r in conn.execute("SELECT DISTINCT host_key FROM rem_findings WHERE quarter = %s", (q,)).fetchall()]


def _merge(conn, uid, quarter, batch, st, who):
    """One batch into the quarter: new findings (with blanks taken from the previous quarter), and the ones already
    there (the file's values win; a blank keeps PATCH-01's; each change of a tracked field is kept in the history)."""
    if not batch:
        return
    keys = [f["fkey"] for f in batch]
    have = {r["fkey"]: dict(r) for r in conn.execute(
        "SELECT id, fkey, " + ", ".join(TRACKED) + " FROM rem_findings WHERE quarter = %s AND fkey = ANY(%s::text[])",
        (quarter, keys)).fetchall()}
    prevq = _prev_quarter(conn, quarter)
    prev = {}
    if prevq:
        prev = {r["fkey"]: dict(r) for r in conn.execute(
            "SELECT fkey, status_text, " + ", ".join(CARRY) + " FROM rem_findings WHERE quarter = %s AND fkey = ANY(%s::text[])",
            (prevq, keys)).fetchall()}
    for f in batch:
        old = have.get(f["fkey"])
        carried = []
        if old is None:
            p = prev.get(f["fkey"])
            if p:
                for k in CARRY:
                    if f.get(k) in (None, ""):
                        pv = p.get(k)
                        if k == "status":
                            pv = None if pv in (None, "fixed") else pv
                        if pv not in (None, ""):
                            f[k] = _day(pv) if k == "target_on" else pv
                            carried.append(k)
                            if k == "status":
                                f["status_text"] = p.get("status_text")        # the file's own word for it, too
                if "cat2" in carried:
                    f["er_code"], f["er_title"] = split_cat2(f["cat2"])
            if not f.get("status"):
                f["status"] = "open"
            vals = [_db_val(k, f.get(k)) for k in COLS]
            conn.execute("INSERT INTO rem_findings (quarter, upload_id, sheet, row_no, extra, carried, " + ", ".join(COLS)
                         + ") VALUES (%s, %s, %s, %s, %s::jsonb, %s::text[], " + ", ".join(["%s"] * len(COLS)) + ")",
                         [quarter, uid, f["sheet"], f["row_no"], json.dumps(f.get("extra")) if f.get("extra") else None,
                          carried] + vals)
            st["new"] += 1
            st["carried"] += bool(carried)
            continue
        changes = []
        for k in TRACKED:
            nv = f.get(k)
            if nv in (None, ""):
                f[k] = old.get(k)                                  # a blank in the file keeps PATCH-01's value
                if k in ("target_on", "completed_on", "report_shared"):
                    f[k] = _day(f[k])
                continue
            ov = old.get(k)
            if _iso(_day(ov) if k in ("target_on", "completed_on", "report_shared") else ov) != _iso(nv):
                changes.append((k, _iso(ov) if ov is not None else None, _iso(nv)))
        if f.get("cat2") and not f.get("er_code"):
            f["er_code"], f["er_title"] = split_cat2(f["cat2"])
        if not f.get("status"):
            f["status"] = old.get("status") or "open"
        sets = ", ".join(f"{k} = %s" for k in COLS if k != "fkey")
        conn.execute("UPDATE rem_findings SET upload_id = %s, sheet = %s, row_no = %s, extra = %s::jsonb, " + sets
                     + ", updated_at = now(), updated_by = %s WHERE id = %s",
                     [uid, f["sheet"], f["row_no"], json.dumps(f.get("extra")) if f.get("extra") else None]
                     + [_db_val(k, f.get(k)) for k in COLS if k != "fkey"] + [who, old["id"]])
        for k, ov, nv in changes:
            conn.execute("""INSERT INTO rem_history (finding_id, field, old_value, new_value, changed_by, source)
                            VALUES (%s, %s, %s, %s, %s, 'import')""", (old["id"], k, ov, nv, who))
        st["updated" if changes else "unchanged"] += 1


def _db_val(k, v):
    if k in DATE_FIELDS:
        return _day(v)
    return v


# ---------------------------------------------------------------------------
# Hosts: device type from the inventory, Application / Infra, team
# ---------------------------------------------------------------------------

def _inventory_assets(conn):
    from . import inventory
    return inventory.load_assets(conn)["assets"]


def refresh_hosts(conn, host_keys=None, assets=None):
    """Each host's device type as the inventory decides it (by name, else by IP). host_keys None: every host."""
    if host_keys is None:
        host_keys = [r["host_key"] for r in conn.execute("SELECT DISTINCT host_key FROM rem_findings").fetchall()]
    if not host_keys:
        return 0
    if assets is None:
        assets = _inventory_assets(conn)
    by_key, by_ip = {}, {}
    for a in assets:
        if a.get("status") == "decommissioned":
            continue
        by_key.setdefault((a.get("key") or "").lower(), a)
        for ip in a.get("ips") or []:
            by_ip.setdefault(str(ip), a)
    info = {}
    for r in conn.execute("""SELECT host_key, max(hostname) AS hostname, array_agg(DISTINCT ip) AS ips
                               FROM rem_findings WHERE host_key = ANY(%s::text[]) GROUP BY host_key""",
                          (list(host_keys),)).fetchall():
        info[r["host_key"]] = r
    n = 0
    for hk in host_keys:
        r = info.get(hk) or {"hostname": None, "ips": []}
        ips = [i for i in (r["ips"] or []) if i]
        a = by_key.get(hk) or next((by_ip[i] for i in ips if i in by_ip), None)
        conn.execute("""INSERT INTO rem_hosts (host_key, hostname, ips, inv_kind, inv_name, inv_reason, checked_at)
                        VALUES (%s, %s, %s::text[], %s, %s, %s, now())
                        ON CONFLICT (host_key) DO UPDATE SET hostname = EXCLUDED.hostname, ips = EXCLUDED.ips,
                               inv_kind = EXCLUDED.inv_kind, inv_name = EXCLUDED.inv_name, inv_reason = EXCLUDED.inv_reason,
                               checked_at = now()""",
                     (hk, r["hostname"], ips, a.get("category") if a else None, a.get("name") if a else None,
                      (a.get("category_reason") or "")[:200] if a else None))
        n += 1
    conn.commit()
    return n


def set_hosts(conn, user, keys, team_type=None, team=None, kind=None):
    """For each host: Application / Infra ('' clears), team ('' clears), device type ('' back to the inventory's).
    None leaves a value as it is."""
    if not keys:
        raise RemError("Choose at least one host.")
    if team_type not in (None, "", "application", "infra"):
        raise RemError("Application or Infra.")
    if kind not in (None, "", "server", "network", "appliance"):
        raise RemError("The device type is server, network or appliance.")
    if team is not None and len(team) > 120:
        raise RemError("A team name is at most 120 characters.")
    n = 0
    for k in keys:
        conn.execute("""INSERT INTO rem_hosts (host_key, team_type, team, kind, set_by, set_at)
                        VALUES (%s, %s, %s, %s, %s, now())
                        ON CONFLICT (host_key) DO UPDATE SET
                          team_type = CASE WHEN %s THEN EXCLUDED.team_type ELSE rem_hosts.team_type END,
                          team = CASE WHEN %s THEN EXCLUDED.team ELSE rem_hosts.team END,
                          kind = CASE WHEN %s THEN EXCLUDED.kind ELSE rem_hosts.kind END,
                          set_by = EXCLUDED.set_by, set_at = now()""",
                     (k, team_type or None, (team or "").strip() or None, kind or None, user,
                      team_type is not None, team is not None, kind is not None))
        n += 1
    conn.commit()
    return n


# ---------------------------------------------------------------------------
# Reading the findings: filters, summary, groups, list, one finding
# ---------------------------------------------------------------------------

KIND_SQL = """coalesce(h.kind, CASE h.inv_kind WHEN 'server' THEN 'server' WHEN 'client' THEN 'server' WHEN 'esxi' THEN 'server'
                                    WHEN 'network' THEN 'network' WHEN 'firewall' THEN 'network'
                                    WHEN 'appliance' THEN 'appliance' WHEN 'unknown' THEN 'unknown'
                                    ELSE 'not_in_inventory' END)"""
OPEN_SQL = "f.status IN ('open', 'pending_review', 'pending_deviation')"
ACTION_SQL = "f.status NOT IN ('fixed', 'decommission')"
OVERDUE_SQL = f"""(CASE WHEN NOT ({OPEN_SQL}) THEN false
                       WHEN f.target_on IS NOT NULL THEN f.target_on < current_date
                       ELSE lower(trim(coalesce(f.overdue_text, ''))) IN ('yes', 'y', 'true', 'overdue') END)"""
FROM_SQL = """FROM rem_findings f
              LEFT JOIN rem_hosts h ON h.host_key = f.host_key
              LEFT JOIN rem_findings p ON p.quarter = %(prev)s AND p.fkey = f.fkey"""
GROUPS = {
    "host": ("f.host_key", "Host"), "severity": ("coalesce(f.severity, -1)::text", "Severity"),
    "status": ("f.status", "Status"), "pic": ("coalesce(f.pic, '')", "PIC"), "cat1": ("coalesce(f.cat1, '')", "Categorization1"),
    "cat2": ("coalesce(f.cat2, '')", "Categorization2"), "env": ("coalesce(f.env, '')", "UAT/Prod"),
    "kind": (KIND_SQL, "Device type"), "team": ("coalesce(h.team_type, '') || '|' || coalesce(h.team, '')", "Team"),
    "plugin": ("f.plugin_id", "Plugin"),
}


def quarters(conn):
    return [dict(r) for r in conn.execute(
        """SELECT quarter, count(*) AS findings, count(*) FILTER (WHERE status IN ('open', 'pending_review', 'pending_deviation')) AS open,
                  max(updated_at) AS updated_at
             FROM rem_findings GROUP BY quarter ORDER BY quarter DESC""").fetchall()]


def where(params):
    """SQL conditions and their values from the page's filters (every value checked here)."""
    q = (params.get("quarter") or "").strip()
    if not re.fullmatch(r"\d{4} Q[1-4]", q):
        raise RemError("Choose a quarter.")
    cond, val = ["f.quarter = %(quarter)s"], {"quarter": q}
    sev = [int(x) for x in re.findall(r"-?\d", params.get("sev") or "") if int(x) in (-1, 0, 1, 2, 3, 4)]
    if sev:
        cond.append("coalesce(f.severity, -1) = ANY(%(sev)s::int[])")
        val["sev"] = sev
    sts = [s for s in (params.get("status") or "").split(",") if s in STATUS]
    if sts:
        cond.append("f.status = ANY(%(status)s::text[])")
        val["status"] = sts
    elif params.get("open") in ("1", "true"):
        cond.append(OPEN_SQL)
    elif params.get("action") in ("1", "true"):                     # needs action: everything but Fixed / Decommission
        cond.append(ACTION_SQL)
    for k, col in (("pic", "f.pic"), ("cat1", "f.cat1"), ("cat2", "f.cat2"), ("env", "f.env")):
        v = params.get(k)
        if v is not None and v != "":
            if v == "\x00":                                         # "(blank)"
                cond.append(f"coalesce({col}, '') = ''")
            else:
                cond.append(f"{col} = %({k})s")
                val[k] = v[:300]
    kind = params.get("kind")
    if kind in KINDS:
        cond.append(f"{KIND_SQL} = %(kind)s")
        val["kind"] = kind
    tt = params.get("team_type")
    if tt in ("application", "infra"):
        cond.append("h.team_type = %(team_type)s")
        val["team_type"] = tt
    elif tt == "none":
        cond.append("h.team_type IS NULL")
    if params.get("host"):
        cond.append("f.host_key = %(host)s")
        val["host"] = params["host"][:255]
    if params.get("overdue") in ("1", "true"):
        cond.append(OVERDUE_SQL)
    if params.get("came_back") in ("1", "true"):
        cond.append("p.status = 'fixed'")
    if params.get("new") in ("1", "true"):
        cond.append("p.id IS NULL")
    s = (params.get("q") or "").strip()
    if s:
        cond.append("""(f.hostname ILIKE %(q)s OR f.ip ILIKE %(q)s OR f.plugin_name ILIKE %(q)s OR f.plugin_id = %(qx)s
                        OR f.cve ILIKE %(q)s OR f.pic ILIKE %(q)s)""")
        val["q"] = "%" + s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")[:100] + "%"
        val["qx"] = s[:100]
    gb, gv = params.get("group_by"), params.get("group")
    if gb in GROUPS and gv is not None:
        cond.append(f"{GROUPS[gb][0]} = %(group)s")
        val["group"] = gv[:600]
    return " AND ".join(cond), val


def _with_prev(conn, val):
    val["prev"] = _prev_quarter(conn, val["quarter"])
    return val


def summary(conn, params):
    w, val = where(params)
    _with_prev(conn, val)
    def base(cols):
        return f"SELECT {cols} {FROM_SQL} WHERE {w}"
    tot = conn.execute(base(f"""count(*) AS total, count(*) FILTER (WHERE {OPEN_SQL}) AS open,
                                   count(*) FILTER (WHERE {OVERDUE_SQL}) AS overdue,
                                   count(*) FILTER (WHERE p.status = 'fixed') AS came_back,
                                   count(*) FILTER (WHERE p.id IS NULL) AS new,
                                   count(*) FILTER (WHERE {ACTION_SQL}) AS action,
                                   count(*) FILTER (WHERE f.status = 'fixed') AS fixed,
                                   count(*) FILTER (WHERE f.status = 'decommission') AS decom,
                                   count(DISTINCT f.host_key) AS hosts"""), val).fetchone()
    matrix = conn.execute(base("coalesce(f.severity, -1) AS severity, f.status, count(*) AS n")
                          + " GROUP BY 1, 2", val).fetchall()

    def by(expr):
        return [dict(r) for r in conn.execute(
            base(f"""{expr} AS k, count(*) AS total, count(*) FILTER (WHERE {OPEN_SQL}) AS open,
                       count(*) FILTER (WHERE {OPEN_SQL} AND f.severity = 4) AS crit,
                       count(*) FILTER (WHERE {OPEN_SQL} AND f.severity = 3) AS high,
                       count(*) FILTER (WHERE {OPEN_SQL} AND f.severity = 2) AS med,
                       count(*) FILTER (WHERE {OPEN_SQL} AND f.severity = 1) AS low,
                       count(*) FILTER (WHERE {OVERDUE_SQL}) AS overdue""")
            + " GROUP BY 1 ORDER BY crit DESC, high DESC, open DESC, total DESC, 1 LIMIT 200", val).fetchall()]
    gone = 0
    if val["prev"]:
        gone = conn.execute("""SELECT count(*) AS n FROM rem_findings p WHERE p.quarter = %(prev)s
                                 AND NOT EXISTS (SELECT 1 FROM rem_findings f WHERE f.quarter = %(quarter)s AND f.fkey = p.fkey)""",
                            val).fetchone()["n"]
    return {"quarter": val["quarter"], "previous": val["prev"], "totals": dict(tot), "gone_since_previous": int(gone),
            "matrix": [dict(r) for r in matrix], "by_pic": by("coalesce(f.pic, '')"), "by_cat1": by("coalesce(f.cat1, '')"),
            "by_cat2": by("coalesce(f.cat2, '')"), "by_env": by("coalesce(f.env, '')"), "by_kind": by(KIND_SQL),
            "by_team": by("coalesce(h.team_type, '')")}


def categories(conn, params):
    """Categorization2 -> Categorization1 -> severity: per pair, per Categorization2 and in all (one query, so the
    hosts are counted right at every level). Each level has, per severity, the open findings (o4..o0) and the ones that
    need action (a4..a0: all but Fixed / Decommission), and open, overdue, action, fixed, decom, all and hosts. Blank categories are "" (shown as "(blank)")."""
    p2 = {k: v for k, v in params.items() if k not in ("cat1", "cat2", "group_by", "group")}
    w, val = where(p2)
    _with_prev(conn, val)
    sev = ", ".join(f"count(*) FILTER (WHERE {OPEN_SQL} AND coalesce(f.severity, -1) = {n}) AS o{abs(n) if n >= 0 else 'x'}, "
                    f"count(*) FILTER (WHERE {ACTION_SQL} AND coalesce(f.severity, -1) = {n}) AS a{abs(n) if n >= 0 else 'x'}"
                    for n in (4, 3, 2, 1, 0, -1))
    rows = conn.execute(f"""SELECT coalesce(f.cat2, '') AS cat2, coalesce(f.cat1, '') AS cat1,
                                   GROUPING(coalesce(f.cat2, '')) AS g2, GROUPING(coalesce(f.cat1, '')) AS g1, {sev},
                                   count(*) FILTER (WHERE {OPEN_SQL}) AS open, count(*) FILTER (WHERE {OVERDUE_SQL}) AS overdue,
                                   count(*) FILTER (WHERE {ACTION_SQL}) AS action, count(*) FILTER (WHERE f.status = 'fixed') AS fixed,
                                   count(*) FILTER (WHERE f.status = 'decommission') AS decom,
                                   count(*) AS total, count(DISTINCT f.host_key) AS hosts
                              {FROM_SQL} WHERE {w}
                             GROUP BY GROUPING SETS ((coalesce(f.cat2, ''), coalesce(f.cat1, '')), (coalesce(f.cat2, '')), ())""",
                        val).fetchall()
    total, tops, kids = None, {}, {}
    for r in rows:
        r = {k: (int(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else v) for k, v in dict(r).items()}
        if r["g2"]:
            total = r
        elif r["g1"]:
            tops[r["cat2"]] = r
        else:
            kids.setdefault(r["cat2"], []).append(r)

    def rank(r):                                    # the worst open first, then the most open; blank last
        return (r["cat2" if "children" in r else "cat1"] == "", -r["o4"], -r["o3"], -r["o2"], -r["o1"], -r["open"], -r["total"],
                r.get("cat2", "") if "children" in r else r["cat1"])
    tree = []
    for c2, top in tops.items():
        top["children"] = sorted(kids.get(c2, []), key=rank)
        top["er_code"], top["er_title"] = split_cat2(c2)
        tree.append(top)
    tree.sort(key=rank)
    for r in [total] + tree + [k for t in tree for k in t["children"]]:
        if r:
            for k in ("g1", "g2"):
                r.pop(k, None)
    return {"quarter": val["quarter"], "previous": val["prev"], "tree": tree,
            "total": total or {"open": 0, "total": 0, "overdue": 0, "hosts": 0, "action": 0, "fixed": 0, "decom": 0}}


def groups(conn, params, limit=300):
    gb = params.get("group_by") or "host"
    if gb not in GROUPS:
        raise RemError("Unknown grouping.")
    p2 = dict(params)
    p2.pop("group", None)
    w, val = where(p2)
    _with_prev(conn, val)
    expr = GROUPS[gb][0]
    rows = conn.execute(f"""SELECT {expr} AS k, count(*) AS total, count(*) FILTER (WHERE {OPEN_SQL}) AS open,
                                   count(*) FILTER (WHERE f.severity = 4) AS crit, count(*) FILTER (WHERE f.severity = 3) AS high,
                                   count(*) FILTER (WHERE f.severity = 2) AS med, count(*) FILTER (WHERE f.severity = 1) AS low,
                                   count(*) FILTER (WHERE f.severity = 0) AS info,
                                   count(*) FILTER (WHERE {OVERDUE_SQL}) AS overdue, max(f.severity) AS worst,
                                   max(f.hostname) AS hostname, min(f.ip) AS ip, max(h.team_type) AS team_type,
                                   max(h.team) AS team, max({KIND_SQL}) AS kind, count(DISTINCT f.host_key) AS hosts
                              {FROM_SQL} WHERE {w}
                             GROUP BY 1 ORDER BY max(coalesce(f.severity, -1)) DESC, crit DESC, high DESC, total DESC, 1
                             LIMIT %(limit)s""", dict(val, limit=limit + 1)).fetchall()
    out = [dict(r) for r in rows[:limit]]
    for g in out:
        g["label"] = group_label(gb, g)
    return {"group_by": gb, "groups": out, "more": len(rows) > limit}


def group_label(gb, g):
    k = g["k"]
    if gb == "host":
        return (g.get("hostname") or g.get("ip") or k) + (f" ({g['ip']})" if g.get("hostname") and g.get("ip") else "")
    if gb == "severity":
        return SEV.get(int(k), "Not given") if str(k).lstrip("-").isdigit() else k
    if gb == "status":
        return STATUS.get(k, k)
    if gb == "kind":
        return KINDS.get(k, k)
    if gb == "team":
        tt, _s, team = (k or "").partition("|")
        return ({"application": "Application", "infra": "Infra"}.get(tt, "Not set") + (" · " + team if team else ""))
    return k if k else "(blank)"


LIST_COLS = f"""f.id, f.severity, f.plugin_id, f.plugin_name, f.hostname, f.ip, f.host_key, f.port, f.protocol, f.env, f.pic,
                f.status, f.status_text, f.exception, f.target_on, f.completed_on, f.report_shared, f.cat1, f.cat2, f.er_code,
                left(f.cve, 200) AS cve, f.cvss3, f.carried, f.row_no, f.sheet,
                {OVERDUE_SQL} AS overdue, (p.id IS NOT NULL) AS in_previous, (p.status = 'fixed') AS came_back,
                p.status AS previous_status, {KIND_SQL} AS kind, h.team_type, h.team"""


def findings(conn, params, offset=0, limit=200):
    w, val = where(params)
    _with_prev(conn, val)
    limit = max(1, min(int(limit), 1000))
    offset = max(0, int(offset))
    rows = conn.execute(f"""SELECT {LIST_COLS} {FROM_SQL} WHERE {w}
                            ORDER BY coalesce(f.severity, -1) DESC, f.host_key, f.plugin_id, f.port, f.id
                            LIMIT %(limit)s OFFSET %(offset)s""", dict(val, limit=limit + 1, offset=offset)).fetchall()
    total = conn.execute(f"SELECT count(*) AS n {FROM_SQL} WHERE {w}", val).fetchone()["n"]
    return {"items": [_row_out(r) for r in rows[:limit]], "more": len(rows) > limit, "total": int(total),
            "offset": offset, "previous": val["prev"]}


def _row_out(r):
    r = dict(r)
    for k in ("target_on", "completed_on", "report_shared", "first_seen", "last_seen", "vuln_pub", "plugin_pub",
              "created_at", "updated_at"):
        if k in r:
            r[k] = _iso(r[k])
    if r.get("previous_status") is None:
        r["came_back"] = False
    r["carried"] = list(r.get("carried") or [])
    return r


def finding(conn, fid):
    r = conn.execute("SELECT f.*, h.team_type, h.team, h.inv_kind, h.inv_name, h.inv_reason, h.kind AS kind_set, "
                     + KIND_SQL + " AS kind FROM rem_findings f LEFT JOIN rem_hosts h ON h.host_key = f.host_key WHERE f.id = %s",
                     (fid,)).fetchone()
    if not r:
        raise NotFound("No such finding.")
    out = _row_out(r)
    out["extra"] = _json(out.get("extra"))
    out.pop("upload_id", None)
    hist = conn.execute("""SELECT field, old_value, new_value, changed_by, changed_at, source, note FROM rem_history
                            WHERE finding_id = %s ORDER BY changed_at DESC, id DESC LIMIT 100""", (fid,)).fetchall()
    out["history"] = [dict(x, changed_at=_iso(x["changed_at"])) for x in hist]
    other = conn.execute("""SELECT id, quarter, status, pic, target_on, exception FROM rem_findings
                             WHERE fkey = %s AND id <> %s ORDER BY quarter DESC""", (r["fkey"], fid)).fetchall()
    out["other_quarters"] = [_row_out(x) for x in other]
    out["overdue"] = conn.execute(f"SELECT {OVERDUE_SQL} AS o FROM rem_findings f WHERE f.id = %s", (fid,)).fetchone()["o"]
    return out


# ---------------------------------------------------------------------------
# Changes
# ---------------------------------------------------------------------------

EDITABLE = {"status": 40, "pic": 120, "exception": 2000, "target_on": 10, "completed_on": 10, "report_shared": 10,
            "cat1": 300, "cat2": 300, "env": 40}


def bulk_edit(conn, user, ids=None, params=None, changes=None, note=None):
    """Sets fields on the chosen findings (ids, or every finding the filters show). Each change kept with who and when.
    Returns {"findings": n chosen, "changed": n changed}."""
    changes = {k: v for k, v in (changes or {}).items() if k in EDITABLE}
    if not changes:
        raise RemError("Choose what to change.")
    clean = {}
    for k, v in changes.items():
        v = "" if v is None else str(v).strip()
        if len(v) > EDITABLE[k]:
            raise RemError(f"{FIELD[k][0]} is at most {EDITABLE[k]} characters.")
        if k == "status":
            if v not in STATUS:
                raise RemError("Unknown status.")
        elif k in DATE_FIELDS and v:
            try:
                date.fromisoformat(v)
            except ValueError:
                raise RemError(f"{FIELD[k][0]}: a date as YYYY-MM-DD.")
        clean[k] = v or None
    if note is not None and len(note) > 500:
        raise RemError("A note is at most 500 characters.")
    if ids is not None:
        ids = sorted({int(i) for i in ids})[:50000]
        if not ids:
            raise RemError("Choose at least one finding.")
        rows = conn.execute("SELECT id, " + ", ".join(clean) + " FROM rem_findings WHERE id = ANY(%s::bigint[])", (ids,)).fetchall()
    else:
        w, val = where(params or {})
        _with_prev(conn, val)
        rows = conn.execute("SELECT f.id, " + ", ".join("f." + k for k in clean) + f" {FROM_SQL} WHERE {w}", val).fetchall()
        if len(rows) > 50000:
            raise RemError("More than 50,000 findings: narrow the filters first.")
    changed = 0
    for r in rows:
        diff = []
        for k, nv in clean.items():
            ov = r.get(k)
            ovs = _iso(_day(ov)) if k in DATE_FIELDS else ov
            if (ovs or None) != (nv or None):
                diff.append((k, ovs, nv))
        if not diff:
            continue
        sets = ", ".join(f"{k} = %s" + ("::date" if k in DATE_FIELDS else "") for k, _o, _n in diff)
        vals = [n for _k, _o, n in diff]
        extra = ""
        if any(k == "cat2" for k, _o, _n in diff):
            code, title = split_cat2(clean["cat2"])
            extra = ", er_code = %s, er_title = %s"
            vals += [code, title]
        conn.execute(f"UPDATE rem_findings SET {sets}{extra}, updated_by = %s, updated_at = now() WHERE id = %s",
                     vals + [user, r["id"]])
        for k, ov, nv in diff:
            conn.execute("""INSERT INTO rem_history (finding_id, field, old_value, new_value, changed_by, source, note)
                            VALUES (%s, %s, %s, %s, %s, 'edit', %s)""", (r["id"], k, ov, nv, user, (note or None)))
        changed += 1
    conn.commit()
    return {"findings": len(rows), "changed": changed}


def hosts(conn, params):
    p2 = {k: v for k, v in params.items() if k in ("quarter", "q", "kind", "team_type")}
    w, val = where(p2)
    _with_prev(conn, val)
    rows = conn.execute(f"""SELECT f.host_key, max(f.hostname) AS hostname, array_agg(DISTINCT f.ip) AS ips,
                                   count(*) AS total, count(*) FILTER (WHERE {OPEN_SQL}) AS open,
                                   count(*) FILTER (WHERE {OPEN_SQL} AND f.severity = 4) AS crit,
                                   count(*) FILTER (WHERE {OPEN_SQL} AND f.severity = 3) AS high,
                                   count(*) FILTER (WHERE {OPEN_SQL} AND f.severity = 2) AS med,
                                   count(*) FILTER (WHERE {OPEN_SQL} AND f.severity = 1) AS low,
                                   array_agg(DISTINCT f.pic) AS pics, array_agg(DISTINCT f.env) AS envs,
                                   max({KIND_SQL}) AS kind, max(h.kind) AS kind_set, max(h.inv_kind) AS inv_kind,
                                   max(h.inv_name) AS inv_name, max(h.inv_reason) AS inv_reason, max(h.team_type) AS team_type,
                                   max(h.team) AS team, max(h.set_by) AS set_by
                              {FROM_SQL} WHERE {w}
                             GROUP BY f.host_key ORDER BY crit DESC, high DESC, open DESC, f.host_key LIMIT 5000""", val).fetchall()
    out = []
    for r in rows:
        r = dict(r)
        for k in ("ips", "pics", "envs"):
            r[k] = sorted(x for x in (r.get(k) or []) if x)
        out.append(r)
    return {"quarter": val["quarter"], "hosts": out}


# ---------------------------------------------------------------------------
# Export: the quarter in the file's own columns and headings
# ---------------------------------------------------------------------------

def _headings(conn, quarter):
    """Field -> the heading the latest imported file used for it (else the template's), and that sheet's name."""
    heads, sheet = {}, None
    for u in conn.execute("""SELECT sheets FROM rem_uploads WHERE state = 'imported' ORDER BY imported_at DESC LIMIT 20""").fetchall():
        for s in _json(u["sheets"]) or []:
            if s.get("use") and s.get("quarter") == quarter:
                for h, m in zip(s.get("headers") or [], s.get("map") or []):
                    if m.get("field") and m["field"] not in heads:
                        heads[m["field"]] = h
                sheet = sheet or s.get("name")
        if heads:
            break
    return heads, sheet


def _cell_text(v):
    t = text(v)
    if len(t) > EXCEL_CELL_MAX:
        t = t[:EXCEL_CELL_MAX - 60] + " … (cut: an Excel cell holds at most 32,767 characters)"
    return t


EXPORT_PAGE = 2000


def export_rows(conn, params):
    """(rows, previous quarter, extra column names). The rows come in pages of EXPORT_PAGE, in the order they were
    imported, so a quarter of any size is written without holding it all in memory."""
    w, val = where(params)
    _with_prev(conn, val)
    extra = [r["k"] for r in conn.execute(f"""SELECT k FROM (SELECT k, min(f.id) AS first
                                                 FROM rem_findings f LEFT JOIN rem_hosts h ON h.host_key = f.host_key
                                                      LEFT JOIN rem_findings p ON p.quarter = %(prev)s AND p.fkey = f.fkey
                                                      CROSS JOIN LATERAL jsonb_object_keys(coalesce(f.extra, '{{}}'::jsonb)) k
                                                WHERE {w} GROUP BY k) x WHERE k <> '_raw' ORDER BY first, k""", val).fetchall()]

    def pages():
        after = 0
        while True:
            rows = conn.execute(f"""SELECT f.*, {OVERDUE_SQL} AS overdue_calc, (p.id IS NOT NULL) AS in_previous,
                                           (p.status = 'fixed') AS came_back, {KIND_SQL} AS kind, h.team_type, h.team
                                      {FROM_SQL} WHERE {w} AND f.id > %(after)s
                                     ORDER BY f.id LIMIT %(page)s""", dict(val, after=after, page=EXPORT_PAGE)).fetchall()
            yield from rows
            if len(rows) < EXPORT_PAGE:
                return
            after = rows[-1]["id"]
    return pages(), val["prev"], extra


def export_xlsx(conn, params, user, company=""):
    import openpyxl
    from openpyxl.cell import WriteOnlyCell
    from openpyxl.styles import Font, PatternFill
    rows, prev, extra_cols = export_rows(conn, params)
    q = params["quarter"]
    known = _words(conn)                                # the status words as confirmed, read once for this export
    heads, sheet_name = _headings(conn, q)
    wb = openpyxl.Workbook(write_only=True)
    bold = Font(bold=True)
    fill = PatternFill("solid", fgColor="DDE4EE")

    def head_row(ws, names):
        out = []
        for n in names:
            c = WriteOnlyCell(ws, value=n)
            c.font, c.fill = bold, fill
            out.append(c)
        ws.append(out)

    def cell(ws, v, as_date=False):
        if as_date and isinstance(v, date):
            c = WriteOnlyCell(ws, value=v)
            c.number_format = "dd-mmm-yyyy"
            return c
        t = _cell_text(v)
        c = WriteOnlyCell(ws, value=t)
        if t.startswith("="):
            c.data_type = "s"                           # a value, never a formula
        return c

    # Summary
    s = summary(conn, params)
    ws = wb.create_sheet("Summary")
    ws.append([f"Nessus remediation — {q}" + (f" — {company}" if company else "")])
    ws.append([f"Exported by {user} on {datetime.now().strftime('%d %b %Y %H:%M')}" + (f"; compared with {prev}" if prev else "")])
    ws.append([])
    t = s["totals"]
    for label, k in (("Findings", "total"), ("Open (incl. pending review / deviation)", "open"), ("Overdue", "overdue"),
                     ("Hosts", "hosts")):
        ws.append([label, int(t[k])])
    if prev:
        ws.append(["New since " + prev, int(t["new"])])
        ws.append(["Fixed in " + prev + " but found again", int(t["came_back"])])
        ws.append(["In " + prev + " but not in " + q, int(s["gone_since_previous"])])
    ws.append([])
    head_row(ws, ["Severity"] + [l for _k, l in STATUSES] + ["Total"])
    grid = {}
    for m in s["matrix"]:
        grid[(int(m["severity"]), m["status"])] = int(m["n"])
    for sv, sl in SEVERITIES + [(-1, "Not given")]:
        line = [grid.get((sv, k), 0) for k, _l in STATUSES]
        if sv == -1 and not any(line):
            continue
        ws.append([sl] + line + [sum(line)])
    ws.append([])
    head_row(ws, ["PIC", "Open critical", "Open high", "Open medium", "Open low", "Open", "Overdue", "All"])
    for g in s["by_pic"]:
        ws.append([g["k"] or "(blank)", int(g["crit"]), int(g["high"]), int(g["med"]), int(g["low"]), int(g["open"]),
                   int(g["overdue"]), int(g["total"])])
    # Categorization2 -> Categorization1, open findings per severity
    ws.append([])
    head_row(ws, ["Categorization2", "Categorization1", "Open critical", "Open high", "Open medium", "Open low", "Open info",
                  "Open", "Overdue", "All", "Hosts"])
    for t in categories(conn, params)["tree"]:
        for r, c1 in [(t, "")] + [(k, k["cat1"] or "(blank)") for k in t["children"]]:
            line = [(t["cat2"] or "(blank)") if r is t else "", c1] + [r[k] for k in ("o4", "o3", "o2", "o1", "o0", "open", "overdue",
                                                                                      "total", "hosts")]
            ws.append(line)
    # Findings, in the file's own columns
    ws = wb.create_sheet((sheet_name or short_label(q))[:31])
    order = [k for k in FIELD_KEYS if k not in ("cvss3", "cvss2") or k in heads]
    names = [heads.get(k) or FIELD[k][0] for k in order]
    head_row(ws, names + ["Device type (PATCH-01)", "Application / Infra", "Team"] + extra_cols)

    def yesno(b):
        return "Yes" if b else "No"
    n = 0
    for r in rows:
        n += 1
        raw = (_json(r["extra"]) or {}).get("_raw") or {}
        line = []
        for k in order:
            if k in DATE_FIELDS:
                d = r[k]
                line.append(cell(ws, _day(d), True) if d else cell(ws, raw.get(k, "")))
                continue
            if k == "severity":
                v = r["severity_text"] if r["severity_text"] and severity_of(r["severity_text"]) == r["severity"] \
                    else SEV.get(r["severity"], r["severity_text"] or "")
            elif k == "status":
                w = norm_word(r["status_text"] or "")
                v = r["status_text"] if r["status_text"] and (known.get(w) or STATUS_WORDS.get(w)) == r["status"] \
                    else STATUS.get(r["status"], r["status"])
            elif k == "overdue":
                v = yesno(r["overdue_calc"]) if (r["target_on"] or r["status"] not in OPEN_STATUSES) else (r["overdue_text"] or "")
            elif k == "prev_finding":
                v = yesno(r["in_previous"]) if prev else (r["prev_finding"] or "")
            elif k == "prev_fixed":
                v = yesno(r["came_back"]) if prev else (r["prev_fixed"] or "")
            elif k == "uuid":
                v = r["uuid_text"] or ""
            else:
                v = r[k]
            line.append(cell(ws, v))
        line += [cell(ws, KINDS.get(r["kind"], r["kind"])),
                 cell(ws, {"application": "Application", "infra": "Infra"}.get(r["team_type"], "")), cell(ws, r["team"])]
        ex = _json(r["extra"]) or {}
        line += [cell(ws, ex.get(k, "")) for k in extra_cols]
        ws.append(line)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue(), n


# ---------------------------------------------------------------------------
# Background runs (API process)
# ---------------------------------------------------------------------------

def run_in_background(fn, uid):
    """Runs read_upload / run_import on its own connection, off the request."""
    from . import core

    def go():
        try:
            with core.pool.connection() as conn:
                fn(conn, uid)
        except Exception as e:  # noqa: BLE001 - the upload shows it stopped; it can be started again
            core.log.error("remediation %s %s: %s", fn.__name__, uid, e)
    threading.Thread(target=go, name="rem-" + fn.__name__, daemon=True).start()
