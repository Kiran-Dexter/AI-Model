#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 agent installer
#
# Run on each managed host, as root. Installs the agent, writes its config,
# installs a systemd timer so it checks in on its own, and enrolls.
#
# Usage:
#   ./install-agent.sh --server https://sgpinfappxu01 --token <token>
#   ./install-agent.sh --server https://sgpinfappxu01 --token <token> --insecure
#   ./install-agent.sh --uninstall
#   ./install-agent.sh --status
#
# --insecure   skip TLS verification. Only while PATCH-01 still has the
#              self-signed placeholder certificate.
# --ca FILE    trust this CA bundle (use once the CA-signed cert is in place)
# ---------------------------------------------------------------------------

set -Eeuo pipefail

SERVER=""
TOKEN=""
INSECURE=no
CA_FILE=""
DO_UNINSTALL=no
DO_STATUS=no
INTERVAL_MIN=5

BIN=/usr/local/bin/patch-agent
CONF_DIR=/etc/patch-agent
CONF=$CONF_DIR/agent.conf
UNIT_DIR=/etc/systemd/system

while (($#)); do
  case "$1" in
    --server)    SERVER="${2:-}"; shift ;;
    --token)     TOKEN="${2:-}"; shift ;;
    --insecure)  INSECURE=yes ;;
    --ca)        CA_FILE="${2:-}"; shift ;;
    --interval)  INTERVAL_MIN="${2:-5}"; shift ;;
    --uninstall) DO_UNINSTALL=yes ;;
    --status)    DO_STATUS=yes ;;
    -h|--help)   sed -n '2,18p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

say()  { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }
die()  { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
step() { printf '\n==> %s\n' "$*"; }

[[ $EUID -eq 0 ]] || die "Run as root."

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------
if [[ "$DO_STATUS" == yes ]]; then
  step "Agent status"
  [[ -x "$BIN" ]] && say "binary:   $BIN" || say "binary:   not installed"
  [[ -f "$CONF" ]] && { say "config:"; sed 's/^/  /' "$CONF"; } || say "config:   none"
  [[ -f "$CONF_DIR/token" ]] && say "enrolled: yes" || say "enrolled: no"
  systemctl is-enabled patch-agent.timer 2>/dev/null | sed 's/^/timer:    /' || true
  systemctl list-timers patch-agent.timer --no-pager 2>/dev/null | sed -n '2p' || true
  say ""
  say "last runs:"
  journalctl -u patch-agent.service -n 10 --no-pager 2>/dev/null | sed 's/^/  /' || true
  exit 0
fi

# ---------------------------------------------------------------------------
# Uninstall
# ---------------------------------------------------------------------------
if [[ "$DO_UNINSTALL" == yes ]]; then
  step "Removing the agent"
  systemctl disable --now patch-agent.timer 2>/dev/null || true
  rm -f "$UNIT_DIR/patch-agent.service" "$UNIT_DIR/patch-agent.timer"
  systemctl daemon-reload
  rm -f "$BIN"
  # The token is this host's credential; remove it too
  rm -rf "$CONF_DIR"
  say "Removed. Decommission the host on PATCH-01 to revoke it server-side:"
  say "  POST /api/v1/admin/hosts/<id>/decommission"
  exit 0
fi

# ---------------------------------------------------------------------------
# Preconditions
# ---------------------------------------------------------------------------
[[ -n "$SERVER" ]] || die "--server is required, e.g. --server https://sgpinfappxu01"
[[ "$SERVER" == https://* ]] || die "--server must start with https://"
SERVER="${SERVER%/}"

AGENT_SRC="$HERE/patch-agent.py"
[[ -f "$AGENT_SRC" ]] || die "patch-agent.py must be next to this script ($HERE)"

step "Detecting the environment"

. /etc/os-release 2>/dev/null || true
say "OS: ${PRETTY_NAME:-unknown}"

# Pick an interpreter. RHEL 8 has no /usr/bin/python3 by default; its
# system Python lives at /usr/libexec/platform-python (3.6). Using that
# avoids installing anything on the managed host.
PY=""
for cand in /usr/bin/python3 /usr/libexec/platform-python /usr/bin/python3.6; do
  if [[ -x "$cand" ]]; then
    ver="$("$cand" -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null || true)"
    if [[ -n "$ver" ]]; then
      major="${ver%%.*}"; minor="${ver##*.}"
      if (( major == 3 && minor >= 6 )); then
        PY="$cand"; break
      fi
    fi
  fi
done
[[ -n "$PY" ]] || die "No Python 3.6+ found (tried python3 and platform-python)."
say "Python: $PY ($("$PY" -V 2>&1))"

# Package manager sanity
if command -v dnf >/dev/null 2>&1; then PM=dnf
elif command -v apt-get >/dev/null 2>&1; then PM=apt
elif command -v yum >/dev/null 2>&1; then PM=yum
else die "No supported package manager (dnf, yum or apt)."
fi
say "Package manager: $PM"

# needs-restarting gives the authoritative reboot answer on RHEL/Oracle.
# Without it the agent falls back to comparing kernel versions.
if [[ "$PM" != apt ]] && ! command -v needs-restarting >/dev/null 2>&1; then
  warn "needs-restarting not found. Reboot detection will fall back to kernel"
  warn "comparison. For the accurate check install: dnf install -y dnf-utils"
fi

# ---------------------------------------------------------------------------
# Proxy check -- the agent must talk to PATCH-01 directly
# ---------------------------------------------------------------------------
step "Checking the path to PATCH-01"

SHOST="${SERVER#https://}"; SHOST="${SHOST%%/*}"; SHOST="${SHOST%%:*}"

if [[ -n "${HTTPS_PROXY:-}${https_proxy:-}" ]]; then
  NP="${NO_PROXY:-}${no_proxy:-}"
  if [[ ",$NP," != *",$SHOST,"* && ",$NP," != *".${SHOST#*.},"* ]]; then
    warn "A proxy is set in this shell and $SHOST is not in NO_PROXY."
    warn "The agent itself ignores proxy variables for PATCH-01, but check"
    warn "that nothing else routes internal traffic through the proxy."
  fi
fi

if getent hosts "$SHOST" >/dev/null 2>&1; then
  say "DNS: $SHOST -> $(getent hosts "$SHOST" | awk '{print $1}' | head -1)"
else
  warn "$SHOST does not resolve on this host."
fi

CURL_TLS=()
[[ "$INSECURE" == yes ]] && CURL_TLS=(-k) || true
[[ -n "$CA_FILE" ]] && CURL_TLS=(--cacert "$CA_FILE") || true

CODE="$(curl -s --noproxy '*' "${CURL_TLS[@]}" -o /dev/null -w '%{http_code}' \
  --max-time 15 "$SERVER/api/v1/health" 2>/dev/null || echo 000)"
if [[ "$CODE" == "200" ]]; then
  say "PATCH-01 API reachable (HTTP 200)"
else
  warn "PATCH-01 health check returned HTTP $CODE"
  [[ "$CODE" == "000" ]] && warn "No response: check DNS, routing and that port 443 is open."
  [[ "$INSECURE" == no && -z "$CA_FILE" && "$CODE" == "000" ]] && \
    warn "If PATCH-01 still has the self-signed cert, add --insecure" || true
  die "Cannot reach PATCH-01."
fi

# ---------------------------------------------------------------------------
# Install
# ---------------------------------------------------------------------------
step "Installing the agent"

# Rewrite the shebang to the interpreter we found, so it works on RHEL 8
# without /usr/bin/python3
sed "1s|^#!.*|#!$PY|" "$AGENT_SRC" > "$BIN.new"
chmod 0755 "$BIN.new"
mv -f "$BIN.new" "$BIN"
say "Installed $BIN (interpreter $PY)"

mkdir -p "$CONF_DIR"
chmod 0700 "$CONF_DIR"

VERIFY=true
[[ "$INSECURE" == yes ]] && VERIFY=false || true

if [[ -n "$CA_FILE" ]]; then
  [[ -f "$CA_FILE" ]] || die "CA file not found: $CA_FILE"
  cp -f "$CA_FILE" "$CONF_DIR/ca.pem"
  chmod 0644 "$CONF_DIR/ca.pem"
fi

cat > "$CONF" <<EOF
# PATCH-01 agent configuration. Written by install-agent.sh on $(date -Is).
server=$SERVER
verify_tls=$VERIFY
ca_file=$([[ -n "$CA_FILE" ]] && echo "$CONF_DIR/ca.pem" || true)
EOF
chmod 0600 "$CONF"
say "Wrote $CONF (verify_tls=$VERIFY)"

[[ "$VERIFY" == false ]] && \
  warn "TLS verification is off. Re-run with --ca once the CA-signed cert is installed." || true

# Dry run: prove collection works on this OS before contacting the server
step "Testing inventory collection"
if "$BIN" facts > /tmp/patch-agent-facts.$$ 2>&1; then
  grep -E '^packages:|"os_version"|"kernel_running"|"reboot_required"|^pkg_manager' \
    /tmp/patch-agent-facts.$$ | sed 's/^/  /'
else
  warn "facts failed:"; sed 's/^/  /' /tmp/patch-agent-facts.$$ >&2
  rm -f /tmp/patch-agent-facts.$$
  die "Inventory collection does not work on this host."
fi
rm -f /tmp/patch-agent-facts.$$

# ---------------------------------------------------------------------------
# Enroll
# ---------------------------------------------------------------------------
step "Enrolling"

if [[ -f "$CONF_DIR/token" ]]; then
  say "Already enrolled; keeping the existing identity."
elif [[ -z "$TOKEN" ]]; then
  warn "No --token given. Enroll later with:"
  warn "  patch-agent enroll --token <token>"
else
  # Proxy variables stripped: this is internal traffic to PATCH-01
  env -u HTTP_PROXY -u HTTPS_PROXY -u http_proxy -u https_proxy \
    "$BIN" enroll --token "$TOKEN" || die "Enrollment failed."
  env -u HTTP_PROXY -u HTTPS_PROXY -u http_proxy -u https_proxy \
    "$BIN" inventory || warn "First inventory failed; the timer will retry."
fi

# ---------------------------------------------------------------------------
# systemd timer
#
# Without this the host checks in once and then goes stale after 24 hours,
# which the platform correctly reports as "unknown" but which is useless.
# ---------------------------------------------------------------------------
step "Installing the systemd timer"

cat > "$UNIT_DIR/patch-agent.service" <<EOF
[Unit]
Description=PATCH-01 agent check-in
Documentation=https://$SHOST/api/v1/docs
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=$BIN run
# Internal traffic to PATCH-01 must not go through the corporate proxy
UnsetEnvironment=HTTP_PROXY HTTPS_PROXY http_proxy https_proxy
Environment=NO_PROXY=$SHOST
# Package installs can take a long time; do not kill a job midway
TimeoutStartSec=3h
Nice=10
IOSchedulingClass=idle
EOF

cat > "$UNIT_DIR/patch-agent.timer" <<EOF
[Unit]
Description=Run the PATCH-01 agent every $INTERVAL_MIN minutes

[Timer]
OnBootSec=2min
OnUnitActiveSec=${INTERVAL_MIN}min
# Spread 200 hosts across the interval instead of all hitting PATCH-01 at once
RandomizedDelaySec=60
Persistent=true

[Install]
WantedBy=timers.target
EOF

systemctl daemon-reload
systemctl enable --now patch-agent.timer >/dev/null 2>&1 \
  || die "Could not enable patch-agent.timer"
say "Timer enabled: every $INTERVAL_MIN min, randomised by up to 60s"

echo
echo "================================================================"
echo " PATCH-01 AGENT INSTALLED"
echo "================================================================"
printf ' Host:     %s\n' "$(hostname)"
printf ' Server:   %s\n' "$SERVER"
printf ' Enrolled: %s\n' "$([[ -f $CONF_DIR/token ]] && echo yes || echo no)"
printf ' TLS:      %s\n' "$([[ $VERIFY == true ]] && echo verified || echo NOT verified)"
echo
echo " Status:    $0 --status"
echo " Run now:   patch-agent run"
echo " Logs:      journalctl -u patch-agent.service -f"
