#!/usr/bin/env python3
"""
PATCH-01 agent

Runs on each managed host. Pull-only: every connection is outbound to
PATCH-01 over 443, so managed hosts need no inbound firewall rule.

  enroll      redeem an enrollment token for a per-host agent token
  checkin     heartbeat, report kernel and reboot state
  inventory   report OS, installed packages, kernel, reboot status
  run         checkin, then execute any queued commands

SECURITY MODEL

  The agent executes a CLOSED SET of verbs. Each verb maps to a fixed
  function in VERB_HANDLERS below. There is no verb that accepts a shell
  command, and the server cannot introduce one: an unrecognised verb is
  refused and reported as an error.

  install_packages accepts a list of package names with target versions and
  passes them to dnf or apt as separate argv elements. Nothing from the
  server reaches a shell. Package names are validated against a strict
  pattern before use.

  This is what bounds the damage if PATCH-01 is ever compromised: the worst
  an attacker can do is install signed packages from a signed repository,
  rather than run arbitrary commands as root on every host.

Requires Python 3.6+ and the standard library only, so it runs on RHEL 8
(Python 3.6) through Ubuntu 24.04 without extra packages.
"""

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

AGENT_VERSION = "1.2.0"

CONFIG_DIR = "/etc/patch-agent"
CONFIG_FILE = os.path.join(CONFIG_DIR, "agent.conf")
TOKEN_FILE = os.path.join(CONFIG_DIR, "token")
STATE_DIR = "/var/lib/patch-agent"
LOG_FILE = "/var/log/patch-agent.log"

# Package names and versions coming from the server are validated against
# this before being passed to the package manager.
SAFE_NAME = re.compile(r"^[A-Za-z0-9._+\-~^:]+$")

HTTP_TIMEOUT = 60


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def log(msg, level="INFO"):
    line = "%s %s %s" % (
        datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), level, msg)
    print(line, flush=True)
    try:
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        with open(LOG_FILE, "a") as fh:
            fh.write(line + "\n")
    except Exception:
        pass


def die(msg):
    log(msg, "FATAL")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

def load_config():
    cfg = {"server": "", "verify_tls": "true", "ca_file": "", "group": "default"}
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                cfg[k.strip()] = v.strip().strip('"').strip("'")
    # Environment overrides the file, for testing
    cfg["server"] = os.environ.get("PATCH_SERVER", cfg["server"])
    return cfg


def load_token():
    if not os.path.exists(TOKEN_FILE):
        return None
    with open(TOKEN_FILE) as fh:
        return fh.read().strip() or None


def save_token(token):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    # 0600: the token is this host's credential
    fd = os.open(TOKEN_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        fh.write(token + "\n")
    os.chmod(TOKEN_FILE, 0o600)


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

def build_ssl_context(cfg):
    """TLS context.

    verify_tls=false exists only for the self-signed placeholder certificate
    on a new install. It must be turned on once a CA-signed certificate is in
    place, and the agent says so on every call while it is off.
    """
    verify = str(cfg.get("verify_tls", "true")).lower() not in ("false", "0", "no")
    ctx = ssl.create_default_context()
    if not verify:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    ca = cfg.get("ca_file")
    if ca and os.path.exists(ca):
        ctx.load_verify_locations(ca)
    return ctx


def api_call(cfg, method, path, body=None, token=None, timeout=HTTP_TIMEOUT):
    server = cfg["server"].rstrip("/")
    if not server:
        die("No server configured. Set 'server=' in %s" % CONFIG_FILE)
    url = server + path

    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", "patch-agent/%s" % AGENT_VERSION)
    if data:
        req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)

    ctx = build_ssl_context(cfg)
    # PATCH-01 is internal. urllib honours HTTP(S)_PROXY from the environment
    # by default, so a host with a global corporate proxy would otherwise
    # send its check-ins through the proxy. An empty ProxyHandler disables
    # that for every call the agent makes.
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        urllib.request.HTTPSHandler(context=ctx),
    )
    try:
        with opener.open(req, timeout=timeout) as resp:
            raw = resp.read().decode()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = e.read().decode()[:1000]
        except Exception:
            pass
        raise RuntimeError("HTTP %s on %s %s: %s" % (e.code, method, path, detail))
    except urllib.error.URLError as e:
        raise RuntimeError("cannot reach %s: %s" % (url, e.reason))


# ---------------------------------------------------------------------------
# Host facts
# ---------------------------------------------------------------------------

def run_cmd(argv, timeout=300):
    """Run a fixed argv list. Never a shell string: no argument from the
    server is ever interpolated into a shell command."""
    try:
        p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=timeout)
        return p.returncode, p.stdout.decode(errors="replace"), \
            p.stderr.decode(errors="replace")
    except subprocess.TimeoutExpired:
        return 124, "", "timed out after %ss" % timeout
    except FileNotFoundError:
        return 127, "", "%s not found" % argv[0]


def read_os_release():
    data = {}
    for path in ("/etc/os-release", "/usr/lib/os-release"):
        if os.path.exists(path):
            with open(path) as fh:
                for line in fh:
                    line = line.strip()
                    if "=" in line and not line.startswith("#"):
                        k, _, v = line.partition("=")
                        data[k] = v.strip().strip('"').strip("'")
            break
    return data


def machine_id():
    """Stable machine identity.

    Used instead of hostname as the enrollment key, so a renamed host keeps
    its history rather than appearing as a new machine.
    """
    for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        if os.path.exists(path):
            with open(path) as fh:
                mid = fh.read().strip()
                if mid:
                    return mid
    # Fall back to a hash of stable hardware identifiers
    parts = []
    for path in ("/sys/class/dmi/id/product_uuid",
                 "/sys/class/dmi/id/board_serial"):
        try:
            with open(path) as fh:
                parts.append(fh.read().strip())
        except Exception:
            pass
    parts.append(platform.node())
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:32]


def detect_pkg_manager():
    if shutil.which("dnf"):
        return "dnf"
    if shutil.which("apt-get"):
        return "apt"
    if shutil.which("yum"):
        return "yum"
    return None


def collect_kernel():
    running = platform.release()
    latest = running
    pm = detect_pkg_manager()
    if pm in ("dnf", "yum"):
        rc, out, _ = run_cmd(["rpm", "-q", "--qf",
                              "%{VERSION}-%{RELEASE}.%{ARCH}\n", "kernel"])
        if rc == 0 and out.strip():
            # rpm does not sort, so take the highest by rpm's own comparison
            kernels = [k for k in out.strip().split("\n") if k]
            latest = kernels[-1] if kernels else running
    elif pm == "apt":
        rc, out, _ = run_cmd(["dpkg-query", "-W", "-f",
                              "${Package}\t${Version}\n", "linux-image-*"])
        if rc == 0:
            vers = [l.split("\t")[0].replace("linux-image-", "")
                    for l in out.strip().split("\n")
                    if l and "generic" in l]
            if vers:
                latest = sorted(vers)[-1]
    return running, latest


def boot_time_iso():
    """When this host last booted, as an ISO timestamp.

    Read from the kernel's own record (btime in /proc/stat) rather than
    computed from uptime, so it is exact. The server derives uptime from it,
    which stays correct between check-ins.
    """
    try:
        with open("/proc/stat") as fh:
            for line in fh:
                if line.startswith("btime "):
                    ts = int(line.split()[1])
                    return datetime.fromtimestamp(ts, timezone.utc).isoformat()
    except Exception:
        pass
    return None


def hardware_uuid():
    """The machine's SMBIOS UUID, which VMware sets to the VM's BIOS UUID.

    This is how PATCH-01 links a server to its VM in vCenter without relying
    on hostnames or IP addresses, which drift. Readable by root only, which
    the agent is. Returns None on hardware that does not provide one.
    """
    for path in ("/sys/class/dmi/id/product_uuid", "/sys/devices/virtual/dmi/id/product_uuid"):
        try:
            with open(path) as fh:
                v = fh.read().strip().lower()
            if re.match(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", v) \
                    and v.replace("-", "") not in ("0" * 32, "f" * 32):
                return v
        except Exception:
            pass
    return None


def check_reboot_required():
    """Whether the running kernel differs from the newest installed.

    This is the distinction between 'fix installed' and 'fix active'. A host
    with the patched kernel installed but the vulnerable one still running is
    NOT remediated, and reporting it as such is how a vulnerability survives
    an audit.
    """
    pm = detect_pkg_manager()

    if pm == "apt":
        if os.path.exists("/var/run/reboot-required"):
            reason = "reboot-required flag set"
            pkgs_file = "/var/run/reboot-required.pkgs"
            if os.path.exists(pkgs_file):
                try:
                    with open(pkgs_file) as fh:
                        pkgs = sorted(set(p.strip() for p in fh if p.strip()))
                    if pkgs:
                        reason = "packages requiring reboot: " + \
                                 ", ".join(pkgs[:10])
                except Exception:
                    pass
            return True, reason
        return False, None

    # RHEL / Oracle: needs-restarting -r is authoritative
    if shutil.which("needs-restarting"):
        rc, out, _ = run_cmd(["needs-restarting", "-r"], timeout=60)
        if rc == 1:
            return True, (out.strip().split("\n")[0][:500]
                          if out.strip() else "needs-restarting reports reboot required")
        if rc == 0:
            return False, None

    # Fallback: compare running against newest installed kernel
    running, latest = collect_kernel()
    if latest and latest not in running:
        return True, "running kernel %s, newest installed %s" % (running, latest)
    return False, None


def collect_packages():
    """Every installed package as name, version, arch.

    Version is reported as the full epoch:version-release string; the server
    splits it into separate columns. Epoch is included explicitly because
    dropping it silently inverts later version comparisons.
    """
    pm = detect_pkg_manager()
    pkgs = []

    if pm in ("dnf", "yum"):
        # %|EPOCH?{...}| emits the epoch only when set, matching how RPM
        # itself renders NEVRA
        rc, out, err = run_cmd([
            "rpm", "-qa", "--qf",
            "%{NAME}\t%|EPOCH?{%{EPOCH}:}|%{VERSION}-%{RELEASE}\t%{ARCH}\t"
            "%|INSTALLTIME?{%{INSTALLTIME}}:{0}|\n",
        ], timeout=300)
        if rc != 0:
            raise RuntimeError("rpm -qa failed: %s" % err[:300])
        for line in out.split("\n"):
            if not line.strip():
                continue
            fields = line.split("\t")
            if len(fields) < 3:
                continue
            name, version, arch = fields[0], fields[1], fields[2]
            if not (SAFE_NAME.match(name) and SAFE_NAME.match(arch)):
                continue
            pkgs.append({"name": name, "version": version, "arch": arch})

    elif pm == "apt":
        rc, out, err = run_cmd([
            "dpkg-query", "-W", "-f",
            "${Package}\t${Version}\t${Architecture}\t${db:Status-Status}\n",
        ], timeout=300)
        if rc != 0:
            raise RuntimeError("dpkg-query failed: %s" % err[:300])
        for line in out.split("\n"):
            if not line.strip():
                continue
            fields = line.split("\t")
            if len(fields) < 4:
                continue
            name, version, arch, st = fields[0], fields[1], fields[2], fields[3]
            # Only fully installed packages count
            if st.strip() != "installed":
                continue
            if not (SAFE_NAME.match(name) and SAFE_NAME.match(arch)):
                continue
            pkgs.append({"name": name, "version": version, "arch": arch})
    else:
        raise RuntimeError("no supported package manager found")

    return pkgs


# ---------------------------------------------------------------------------
# Verb handlers -- the closed set
# ---------------------------------------------------------------------------

def verb_collect_inventory(cfg, token, params):
    data = build_inventory()
    api_call(cfg, "POST", "/api/v1/agent/inventory", data, token)
    return {"packages": len(data["packages"])}


def verb_run_precheck(cfg, token, params):
    """Named checks only. The server names which checks to run; it cannot
    supply the check itself."""
    requested = params.get("checks") or ["disk", "locks", "history"]
    results = {}
    ok = True

    if "disk" in requested:
        results["disk"] = {}
        for mount in ("/", "/boot", "/var"):
            if not os.path.isdir(mount):
                continue
            try:
                st = os.statvfs(mount)
                free_mb = (st.f_bavail * st.f_frsize) // (1024 * 1024)
                results["disk"][mount] = free_mb
                # A full /boot failing a kernel install is the single most
                # common patch failure
                threshold = 300 if mount == "/boot" else 1024
                if free_mb < threshold:
                    ok = False
                    results.setdefault("errors", []).append(
                        "%s has only %d MB free (need %d)" %
                        (mount, free_mb, threshold))
            except Exception as e:
                results["disk"][mount] = "error: %s" % e

    if "locks" in requested:
        pm = detect_pkg_manager()
        locked = False
        if pm in ("dnf", "yum"):
            for lk in ("/var/run/dnf.pid", "/var/lib/rpm/.rpm.lock"):
                if os.path.exists(lk):
                    rc, _, _ = run_cmd(["fuser", lk], timeout=15)
                    if rc == 0:
                        locked = True
        elif pm == "apt":
            for lk in ("/var/lib/dpkg/lock-frontend", "/var/lib/apt/lists/lock"):
                if os.path.exists(lk):
                    rc, _, _ = run_cmd(["fuser", lk], timeout=15)
                    if rc == 0:
                        locked = True
        results["package_manager_locked"] = locked
        if locked:
            ok = False
            results.setdefault("errors", []).append(
                "package manager is locked by another process")

    if "history" in requested:
        pm = detect_pkg_manager()
        clean = True
        if pm in ("dnf", "yum"):
            rc, out, _ = run_cmd(["dnf", "history", "list", "--reverse"],
                                 timeout=60)
            # A prior failed transaction blocks the next one
            if rc == 0 and re.search(r"\bE\b|Aborted", out):
                clean = False
        elif pm == "apt":
            rc, out, _ = run_cmd(["dpkg", "--audit"], timeout=60)
            if rc == 0 and out.strip():
                clean = False
        results["transaction_history_clean"] = clean
        if not clean:
            ok = False
            results.setdefault("errors", []).append(
                "previous package transaction did not complete cleanly")

    results["ok"] = ok
    if not ok:
        # Pre-check failure aborts without changing anything
        raise RuntimeError("pre-check failed: %s" %
                           "; ".join(results.get("errors", [])))
    return results


def _validated_package_args(params):
    """Turn a server-supplied package list into safe argv elements.

    Each entry must be a plain name, optionally with a version. Anything
    containing shell metacharacters is refused outright rather than escaped,
    because refusing is easier to reason about.
    """
    pkgs = params.get("packages") or []
    if not isinstance(pkgs, list) or not pkgs:
        raise RuntimeError("no packages supplied")
    if len(pkgs) > 5000:
        raise RuntimeError("package list too long (%d)" % len(pkgs))

    args = []
    for entry in pkgs:
        if isinstance(entry, dict):
            name = entry.get("name", "")
            version = entry.get("version") or ""
        else:
            name, version = str(entry), ""
        if not SAFE_NAME.match(name):
            raise RuntimeError("refusing unsafe package name: %r" % name)
        if version and not SAFE_NAME.match(version):
            raise RuntimeError("refusing unsafe version: %r" % version)
        args.append("%s-%s" % (name, version) if version else name)
    return args


def verb_download_packages(cfg, token, params):
    """Pre-download without installing, so the install step is fast and the
    window is short."""
    args = _validated_package_args(params)
    pm = detect_pkg_manager()
    if pm in ("dnf", "yum"):
        argv = [pm, "install", "-y", "--downloadonly", "--setopt=tsflags="] + args
    elif pm == "apt":
        argv = ["apt-get", "install", "-y", "--download-only"] + args
    else:
        raise RuntimeError("no supported package manager")
    rc, out, err = run_cmd(argv, timeout=3600)
    if rc != 0:
        raise RuntimeError("download failed (rc=%d): %s" % (rc, err[-800:]))
    return {"downloaded": len(args), "output": out[-2000:]}


def verb_install_packages(cfg, token, params):
    """Install a specific list. argv only, never a shell string."""
    args = _validated_package_args(params)
    pm = detect_pkg_manager()

    before, _ = collect_kernel()

    if pm in ("dnf", "yum"):
        argv = [pm, "install", "-y"] + args
    elif pm == "apt":
        argv = ["apt-get", "install", "-y",
                "-o", "Dpkg::Options::=--force-confdef",
                "-o", "Dpkg::Options::=--force-confold"] + args
        os.environ["DEBIAN_FRONTEND"] = "noninteractive"
    else:
        raise RuntimeError("no supported package manager")

    rc, out, err = run_cmd(argv, timeout=7200)
    reboot, reason = check_reboot_required()

    result = {
        "packages_requested": len(args),
        "kernel_before": before,
        "reboot_required": reboot,
        "reboot_reason": reason,
        "output": out[-4000:],
    }
    if rc != 0:
        result["error"] = err[-2000:]
        raise RuntimeError("install failed (rc=%d): %s" % (rc, err[-800:]))
    return result


def verb_reboot_host(cfg, token, params):
    """Schedule a reboot far enough out that this result can be reported
    first, otherwise the server never learns the reboot was accepted."""
    delay = int(params.get("delay_seconds", 60))
    delay = max(10, min(delay, 3600))
    if shutil.which("shutdown"):
        rc, out, err = run_cmd(["shutdown", "-r", "+%d" % max(1, delay // 60),
                                "PATCH-01 scheduled reboot"], timeout=30)
        if rc != 0:
            raise RuntimeError("shutdown failed: %s" % err[:500])
    else:
        raise RuntimeError("shutdown command not available")
    return {"reboot_scheduled_in_seconds": delay}


def verb_run_postcheck(cfg, token, params):
    """Compare against the baseline captured at pre-check time.

    Comparing against an absolute notion of healthy would blame the patch for
    a service that was already down beforehand.
    """
    baseline = params.get("baseline_services") or []
    results = {"services": {}, "ok": True}

    running, latest = collect_kernel()
    reboot, reason = check_reboot_required()
    results["kernel_running"] = running
    results["kernel_latest"] = latest
    results["reboot_required"] = reboot
    results["reboot_reason"] = reason

    if shutil.which("systemctl"):
        rc, out, _ = run_cmd(["systemctl", "is-system-running"], timeout=30)
        results["system_state"] = out.strip() or "unknown"
        for svc in baseline:
            if not SAFE_NAME.match(str(svc)):
                continue
            rc, out, _ = run_cmd(["systemctl", "is-active", str(svc)],
                                 timeout=30)
            state = out.strip()
            results["services"][svc] = state
            if state != "active":
                results["ok"] = False
                results.setdefault("errors", []).append(
                    "service %s is %s" % (svc, state))

    if not results["ok"]:
        raise RuntimeError("post-check failed: %s" %
                           "; ".join(results.get("errors", [])))
    return results


def verb_report_evidence(cfg, token, params):
    running, latest = collect_kernel()
    reboot, reason = check_reboot_required()
    return {
        "kernel_running": running,
        "kernel_latest": latest,
        "reboot_required": reboot,
        "reboot_reason": reason,
        "collected_at": datetime.now(timezone.utc).isoformat(),
    }


def verb_cancel_job(cfg, token, params):
    return {"acknowledged": True}


# The closed set. A verb not in this table is refused.
VERB_HANDLERS = {
    "collect_inventory": verb_collect_inventory,
    "run_precheck": verb_run_precheck,
    "download_packages": verb_download_packages,
    "install_packages": verb_install_packages,
    "reboot_host": verb_reboot_host,
    "run_postcheck": verb_run_postcheck,
    "report_evidence": verb_report_evidence,
    "cancel_job": verb_cancel_job,
}


# ---------------------------------------------------------------------------
# Operations
# ---------------------------------------------------------------------------

def build_inventory():
    started = time.time()
    osr = read_os_release()
    running, latest = collect_kernel()
    reboot, reason = check_reboot_required()
    pkgs = collect_packages()
    return {
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "kernel_running": running,
        "kernel_latest": latest,
        "reboot_required": reboot,
        "reboot_reason": reason,
        "os_version": osr.get("VERSION_ID", ""),
        "agent_version": AGENT_VERSION,
        "duration_ms": int((time.time() - started) * 1000),
        "boot_time": boot_time_iso(),
        "hardware_uuid": hardware_uuid(),
        "packages": pkgs,
    }


def cmd_enroll(cfg, args):
    if load_token() and not args.force:
        log("Already enrolled. Use --force to re-enroll.")
        return 0
    if not args.token:
        die("--token is required (get one from the admin API)")

    osr = read_os_release()
    pm = detect_pkg_manager()
    if not pm:
        die("No supported package manager (dnf, yum or apt) found")

    hostname = platform.node().split(".")[0].lower()
    fqdn = platform.node().lower()

    body = {
        "enrollment_token": args.token,
        "machine_id": machine_id(),
        "hostname": hostname,
        "fqdn": fqdn if fqdn != hostname else None,
        "os_id": osr.get("ID", "unknown"),
        "os_version": osr.get("VERSION_ID", "0"),
        "arch": platform.machine(),
        "pkg_manager": pm,
        "agent_version": AGENT_VERSION,
    }

    log("enrolling %s (%s %s, %s) with %s" %
        (hostname, body["os_id"], body["os_version"], pm, cfg["server"]))
    resp = api_call(cfg, "POST", "/api/v1/agent/enroll", body)
    save_token(resp["agent_token"])
    log("enrolled: host_id=%s token stored in %s" %
        (resp["host_id"], TOKEN_FILE))
    return 0


def cmd_inventory(cfg, args):
    token = load_token() or die("Not enrolled. Run: patch-agent enroll --token ...")
    data = build_inventory()
    log("collected %d packages in %dms" %
        (len(data["packages"]), data["duration_ms"]))
    resp = api_call(cfg, "POST", "/api/v1/agent/inventory", data, token)
    log("inventory accepted: %s" % json.dumps(resp))
    return 0


def cmd_checkin(cfg, args):
    token = load_token() or die("Not enrolled.")
    running, _ = collect_kernel()
    reboot, _ = check_reboot_required()
    resp = api_call(cfg, "POST", "/api/v1/agent/checkin", {
        "agent_version": AGENT_VERSION,
        "kernel_running": running,
        "reboot_required": reboot,
        "boot_time": boot_time_iso(),
        "hardware_uuid": hardware_uuid(),
    }, token)
    log("checkin ok (want_inventory=%s)" % resp.get("want_inventory"))
    return resp


def cmd_run(cfg, args):
    """Check in, send inventory if asked, then execute queued commands."""
    token = load_token() or die("Not enrolled.")

    resp = cmd_checkin(cfg, args)
    if resp.get("want_inventory"):
        log("server requested inventory")
        try:
            cmd_inventory(cfg, args)
        except Exception as e:
            log("inventory failed: %s" % e, "ERROR")

    cmds = api_call(cfg, "GET", "/api/v1/agent/commands", None, token)
    if not cmds:
        log("no pending commands")
        return 0

    log("%d command(s) claimed" % len(cmds))
    for c in cmds:
        verb = c.get("verb")
        cid = c.get("id")
        params = c.get("params") or {}
        handler = VERB_HANDLERS.get(verb)

        if handler is None:
            # An unknown verb is refused, not guessed at. This is what keeps
            # the instruction set closed even if the server changes.
            log("refusing unknown verb %r" % verb, "ERROR")
            try:
                api_call(cfg, "POST",
                         "/api/v1/agent/commands/%s/result" % cid,
                         {"ok": False, "result": {},
                          "message": "unsupported verb %r; agent version %s"
                                     % (verb, AGENT_VERSION)},
                         token)
            except Exception as e:
                log("could not report refusal: %s" % e, "ERROR")
            continue

        log("executing %s" % verb)
        try:
            result = handler(cfg, token, params)
            ok, message = True, None
        except Exception as e:
            result, ok, message = {}, False, str(e)[:4000]
            log("%s failed: %s" % (verb, message), "ERROR")

        try:
            api_call(cfg, "POST",
                     "/api/v1/agent/commands/%s/result" % cid,
                     {"ok": ok, "result": result, "message": message},
                     token)
            log("%s reported (ok=%s)" % (verb, ok))
        except Exception as e:
            log("could not report result for %s: %s" % (verb, e), "ERROR")

    return 0


def cmd_facts(cfg, args):
    """Print what would be reported, without contacting the server."""
    data = build_inventory()
    pkgs = data.pop("packages")
    print(json.dumps(data, indent=2))
    print("packages: %d" % len(pkgs))
    for p in pkgs[:10]:
        print("  %s %s %s" % (p["name"], p["version"], p["arch"]))
    if len(pkgs) > 10:
        print("  ... and %d more" % (len(pkgs) - 10))
    print("\nmachine_id: %s" % machine_id())
    print("pkg_manager: %s" % detect_pkg_manager())
    return 0


def main():
    ap = argparse.ArgumentParser(description="PATCH-01 agent")
    ap.add_argument("--server", help="override the configured server URL")
    ap.add_argument("--insecure", action="store_true",
                    help="skip TLS verification (self-signed placeholder only)")
    # required=True as a keyword is Python 3.7+. RHEL 8's platform-python is
    # 3.6 and raises TypeError on it, so set the attribute instead.
    sub = ap.add_subparsers(dest="command")
    sub.required = True

    p = sub.add_parser("enroll")
    p.add_argument("--token", required=False, help="enrollment token")
    p.add_argument("--force", action="store_true")

    sub.add_parser("checkin")
    sub.add_parser("inventory")
    sub.add_parser("run")
    sub.add_parser("facts")

    args = ap.parse_args()

    cfg = load_config()
    if args.server:
        cfg["server"] = args.server
    if args.insecure:
        cfg["verify_tls"] = "false"

    if str(cfg.get("verify_tls", "true")).lower() in ("false", "0", "no"):
        log("TLS verification is DISABLED. Acceptable only with the "
            "self-signed placeholder certificate; enable it once a CA-signed "
            "certificate is installed.", "WARN")

    if os.geteuid() != 0 and args.command != "facts":
        die("Run as root (package queries and installs need it)")

    handlers = {
        "enroll": cmd_enroll,
        "checkin": cmd_checkin,
        "inventory": cmd_inventory,
        "run": cmd_run,
        "facts": cmd_facts,
    }
    try:
        rc = handlers[args.command](cfg, args)
        return 0 if rc in (0, None) else (rc if isinstance(rc, int) else 0)
    except RuntimeError as e:
        die(str(e))
    except KeyboardInterrupt:
        log("interrupted", "WARN")
        return 130


if __name__ == "__main__":
    sys.exit(main())
