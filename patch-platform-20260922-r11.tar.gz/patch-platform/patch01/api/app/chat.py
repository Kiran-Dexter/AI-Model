"""
PATCH-01 : admin chat

Answers questions about the fleet in plain language. Admin only, read-only.

How it works, and why:

  * The model is asked to choose ONE prepared query and its parameters, and
    nothing else. It never writes SQL, never sees the database, and never
    supplies a number that appears in an answer.
  * Every query below is fixed, parameterised and read-only. There is no
    path from this module to an UPDATE, INSERT or DELETE.
  * Parameters are validated against a type and a range before use, so a
    confused or manipulated model cannot widen a query beyond its shape.
  * The figures in the reply are computed here from the rows returned, and
    the rows are shown to the operator alongside the answer. A wrong tool
    choice produces a visibly wrong table rather than a confident lie.
  * If the model is unreachable or answers nonsense, a keyword fallback
    picks the query, so the chat still works without AI-01.

Actions are deliberately absent. Patching, snapshots and power operations
happen through the approval flow, never from a sentence typed into a chat.
"""

import json
import logging
import re

log = logging.getLogger("patchapi.chat")

MAX_ROWS = 60
MAX_QUESTION = 400

CVE_IN_TEXT = re.compile(r"\bCVE[-–_ ]?(\d{4})[-–_ ]?(\d{4,7})\b", re.I)
HOSTNAME_IN_TEXT = re.compile(r"\b([a-z0-9][a-z0-9-]{2,62})\b", re.I)


# ---------------------------------------------------------------------------
# The complete set of things the chat can ask the database
# ---------------------------------------------------------------------------
#   sql     fixed, parameterised, read-only
#   params  name -> (type, default); validated before use
#   needs   parameters with no sensible default
# ---------------------------------------------------------------------------

# Every placeholder carries an explicit type. Without one, a NULL filter makes
# PostgreSQL refuse the query: "could not determine data type of parameter".
TOOLS = {
    "fleet_summary": {
        "what": "Overall counts: servers, their patch status and agent state.",
        "params": {},
        "sql": """SELECT count(*) AS servers,
                         count(*) FILTER (WHERE status='active')  AS active,
                         count(*) FILTER (WHERE status='stale')   AS not_reporting,
                         count(*) FILTER (WHERE reboot_required)  AS awaiting_reboot
                    FROM hosts WHERE status <> 'decommissioned'""",
    },
    "hosts_affected_by_cve": {
        "what": "Which servers are affected by one CVE.",
        "params": {"cve_id": ("cve", None)},
        "needs": ["cve_id"],
        "sql": """SELECT h.hostname, h.os_id || ' ' || coalesce(h.os_version,'') AS os,
                         ha.state, ha.package_name AS package,
                         ha.installed_evr AS installed, ha.fixed_evr AS fixed_in,
                         h.host_group
                    FROM advisory_cves ac
                    JOIN host_applicability ha ON ha.advisory_id = ac.advisory_id
                    JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'
                   WHERE ac.cve_id = %(cve_id)s::text
                   ORDER BY CASE ha.state WHEN 'affected' THEN 1
                              WHEN 'fixed_pending_reboot' THEN 2 ELSE 3 END, h.hostname
                   LIMIT %(limit)s::int""",
    },
    "cve_summary": {
        "what": "Published facts about one CVE: score, attack type, whether it is exploited.",
        "params": {"cve_id": ("cve", None)},
        "needs": ["cve_id"],
        "sql": """SELECT cd.cve_id, cd.cvss_score, cd.cvss_severity, cd.attack_class,
                         cd.kev AS exploited_in_wild, cd.epss, cd.description,
                         cd.rh_severity,
                         (SELECT count(DISTINCT ha.host_id)
                            FROM advisory_cves ac2
                            JOIN host_applicability ha ON ha.advisory_id = ac2.advisory_id
                           WHERE ac2.cve_id = cd.cve_id AND ha.state='affected') AS servers_affected
                    FROM cve_details cd WHERE cd.cve_id = %(cve_id)s::text""",
    },
    "hosts_needing_patch": {
        "what": "Servers that need patches, optionally filtered by OS, group, or only exploited CVEs.",
        "params": {"os_id": ("os", None), "host_group": ("name", None),
                   "exploited_only": ("bool", False)},
        "sql": """SELECT h.hostname, h.os_id || ' ' || coalesce(h.os_version,'') AS os,
                         h.host_group,
                         count(DISTINCT ha.advisory_id) AS advisories_outstanding,
                         max(r.max_cvss) AS worst_cvss,
                         bool_or(coalesce(r.any_kev,false)) AS any_exploited
                    FROM hosts h
                    JOIN host_applicability ha ON ha.host_id = h.id AND ha.state='affected'
                    LEFT JOIN v_advisory_risk r ON r.advisory_id = ha.advisory_id
                   WHERE h.status <> 'decommissioned'
                     AND (%(os_id)s::text IS NULL OR h.os_id = %(os_id)s::text)
                     AND (%(host_group)s::text IS NULL OR h.host_group = %(host_group)s::text)
                     AND (NOT %(exploited_only)s::boolean OR coalesce(r.any_kev,false))
                   GROUP BY h.hostname, h.os_id, h.os_version, h.host_group
                   ORDER BY any_exploited DESC, advisories_outstanding DESC
                   LIMIT %(limit)s::int""",
    },
    "host_detail": {
        "what": "One server: OS, kernel, agent state, uptime and how much it needs patching.",
        "params": {"hostname": ("name", None)},
        "needs": ["hostname"],
        "sql": """SELECT h.hostname, h.os_id || ' ' || coalesce(h.os_version,'') AS os,
                         h.kernel_running, h.reboot_required, h.host_group,
                         agent_state(h.last_checkin, h.status) AS agent,
                         h.last_checkin, h.boot_time,
                         count(*) FILTER (WHERE ha.state='affected')             AS needs_patch,
                         count(*) FILTER (WHERE ha.state='fixed_pending_reboot') AS needs_reboot
                    FROM hosts h LEFT JOIN host_applicability ha ON ha.host_id = h.id
                   WHERE lower(h.hostname) = lower(%(hostname)s::text)
                   GROUP BY h.hostname, h.os_id, h.os_version, h.kernel_running,
                            h.reboot_required, h.host_group, h.last_checkin,
                            h.status, h.boot_time""",
    },
    "exploited_cves": {
        "what": "CVEs known to be exploited in the wild that still affect servers.",
        "params": {},
        "sql": """SELECT cd.cve_id, cd.cvss_score, cd.attack_class,
                         count(DISTINCT ha.host_id) AS servers_affected
                    FROM cve_details cd
                    JOIN advisory_cves ac ON ac.cve_id = cd.cve_id
                    JOIN host_applicability ha ON ha.advisory_id = ac.advisory_id
                                              AND ha.state = 'affected'
                   WHERE cd.kev
                   GROUP BY cd.cve_id, cd.cvss_score, cd.attack_class
                   ORDER BY servers_affected DESC, cd.cvss_score DESC NULLS LAST
                   LIMIT %(limit)s::int""",
    },
    "agents_by_state": {
        "what": "Servers whose agent is offline, not reporting, or online.",
        "params": {"state": ("agent_state", "offline")},
        "sql": """SELECT hostname, os_id || ' ' || coalesce(os_version,'') AS os,
                         agent_state(last_checkin, status) AS agent,
                         last_checkin, agent_version, host_group
                    FROM hosts
                   WHERE status <> 'decommissioned'
                     AND agent_state(last_checkin, status) = %(state)s::text
                   ORDER BY last_checkin NULLS FIRST
                   LIMIT %(limit)s::int""",
    },
    "vms_old_snapshots": {
        "what": "Virtual machines carrying snapshots older than a number of days.",
        "params": {"days": ("int", 7)},
        "sql": """SELECT name AS vm, vcenter, cluster, snapshot_count,
                         oldest_snapshot_at,
                         extract(day FROM now() - oldest_snapshot_at)::int AS days_old
                    FROM vm_inventory
                   WHERE snapshot_count > 0
                     AND oldest_snapshot_at < now() - make_interval(days => %(days)s::int)
                   ORDER BY oldest_snapshot_at
                   LIMIT %(limit)s::int""",
    },
    "vms_without_agent": {
        "what": "Running Linux virtual machines with no agent, so not covered by patching.",
        "params": {},
        "sql": """SELECT name AS vm, vcenter, cluster, guest_os, guest_hostname, guest_ips
                    FROM v_vm_unmanaged ORDER BY vcenter, name LIMIT %(limit)s::int""",
    },
    "hardening_placeholder": {
        "what": "Hardening scan results. Not built yet.",
        "params": {},
        "sql": None,
    },
}

TOOL_NAMES = [k for k, v in TOOLS.items() if v.get("sql")]


# ---------------------------------------------------------------------------
# Parameter validation
# ---------------------------------------------------------------------------

VALID_OS = {"rhel", "ol", "ubuntu"}
VALID_AGENT = {"online", "offline", "not_reporting", "no_data"}
NAME_OK = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,62}$")


def coerce(kind, value, default):
    """Force a parameter into its declared shape, or fall back to the default.

    A model that returns nonsense, or a prompt that tries to smuggle SQL,
    cannot get past this: values are rebuilt, never passed through.
    """
    if value is None or value == "":
        return default
    if kind == "cve":
        m = CVE_IN_TEXT.search(str(value))
        return f"CVE-{m.group(1)}-{m.group(2)}" if m else default
    if kind == "os":
        v = str(value).strip().lower()
        v = {"redhat": "rhel", "red hat": "rhel", "oracle": "ol",
             "oraclelinux": "ol", "oracle linux": "ol"}.get(v, v)
        return v if v in VALID_OS else default
    if kind == "agent_state":
        v = str(value).strip().lower().replace(" ", "_").replace("-", "_")
        v = {"silent": "not_reporting", "down": "offline", "up": "online"}.get(v, v)
        return v if v in VALID_AGENT else default
    if kind == "name":
        v = str(value).strip()
        return v if NAME_OK.match(v) else default
    if kind == "bool":
        return str(value).strip().lower() in ("1", "true", "yes", "y", "on")
    if kind == "int":
        try:
            return max(0, min(3650, int(float(value))))
        except (TypeError, ValueError):
            return default
    return default


def build_args(tool, raw_args):
    spec = TOOLS[tool]
    args = {}
    for name, (kind, default) in spec["params"].items():
        args[name] = coerce(kind, (raw_args or {}).get(name), default)
    missing = [n for n in spec.get("needs", []) if args.get(n) is None]
    args["limit"] = MAX_ROWS
    return args, missing


# ---------------------------------------------------------------------------
# Choosing a query: the model, with a keyword fallback
# ---------------------------------------------------------------------------

SELECT_PROMPT = """You choose which prepared database query answers a question about a Linux server fleet.

Reply with ONE line of JSON and nothing else:
{"tool": "<name>", "args": {...}}

Available tools and their arguments:
""" + "\n".join(
    f'- {k}: {v["what"]} args: '
    f'{", ".join(f"{n} ({t})" for n, (t, _) in v["params"].items()) or "none"}'
    for k, v in TOOLS.items() if v.get("sql")
) + """

Rules:
- Use only a tool from the list. Never invent one.
- Copy identifiers such as CVE numbers and host names from the question exactly.
- If the question asks about something no tool covers, reply {"tool": "none", "args": {}}.
- Reply with the JSON only. No explanation."""


def keyword_pick(q):
    """Choose a query without the model. Used when AI-01 is unavailable, and
    as a check on an implausible model answer."""
    t = q.lower()
    m = CVE_IN_TEXT.search(q)
    if m:
        cve = f"CVE-{m.group(1)}-{m.group(2)}"
        if any(w in t for w in ("what is", "explain", "detail", "severity", "score", "about")):
            return "cve_summary", {"cve_id": cve}
        return "hosts_affected_by_cve", {"cve_id": cve}
    if "snapshot" in t:
        d = re.search(r"(\d{1,4})\s*day", t)
        return "vms_old_snapshots", {"days": d.group(1) if d else 7}
    if ("without an agent" in t or "no agent" in t or "unmanaged" in t or
            ("vm" in t and "agent" in t)):
        return "vms_without_agent", {}
    if "offline" in t or "not reporting" in t or "silent" in t or "agent" in t:
        state = ("not_reporting" if ("not reporting" in t or "silent" in t)
                 else "online" if "online" in t else "offline")
        return "agents_by_state", {"state": state}
    if "exploited" in t or "kev" in t or "in the wild" in t:
        return "exploited_cves", {}
    if "hardening" in t or "cis" in t or "benchmark" in t:
        return "hardening_placeholder", {}
    if any(w in t for w in ("need patch", "needs patch", "outstanding", "to patch",
                            "unpatched", "vulnerable", "affected")):
        args = {}
        for k, v in (("rhel", "rhel"), ("red hat", "rhel"), ("oracle", "ol"), ("ubuntu", "ubuntu")):
            if k in t:
                args["os_id"] = v
        g = re.search(r"\b(prod|production|test|dev|staging|default)\b", t)
        if g:
            args["host_group"] = {"production": "prod"}.get(g.group(1), g.group(1))
        if "exploited" in t or "kev" in t:
            args["exploited_only"] = True
        return "hosts_needing_patch", args
    if any(w in t for w in ("how many", "summary", "overall", "fleet", "total")):
        return "fleet_summary", {}
    # A bare word that looks like a hostname
    for w in HOSTNAME_IN_TEXT.findall(q):
        if w.lower() not in ("what", "which", "show", "list", "servers", "server",
                             "hosts", "host", "the", "and", "are", "for", "with"):
            if any(c.isdigit() for c in w) and len(w) > 4:
                return "host_detail", {"hostname": w}
    return None, {}


def pick_tool(question, ask_model):
    """Returns (tool, args, how). The model chooses; keywords are the fallback."""
    if ask_model:
        try:
            raw = ask_model([{"role": "system", "content": SELECT_PROMPT},
                             {"role": "user", "content": question[:MAX_QUESTION]}])
            txt = (raw or "").strip()
            m = re.search(r"\{.*\}", txt, re.S)
            if m:
                d = json.loads(m.group(0))
                tool = str(d.get("tool") or "").strip()
                if tool in TOOLS:
                    return tool, d.get("args") or {}, "model"
                if tool == "none":
                    kw, kwargs = keyword_pick(question)
                    if kw:
                        return kw, kwargs, "keywords"
                    return None, {}, "model"
        except Exception as e:  # noqa: BLE001 - fall back rather than fail
            log.warning("tool selection via AI-01 failed: %s", e)
    kw, kwargs = keyword_pick(question)
    return kw, kwargs, "keywords"


# ---------------------------------------------------------------------------
# Wording the answer from the rows
# ---------------------------------------------------------------------------

def phrase(tool, args, rows):
    n = len(rows)
    if tool == "fleet_summary" and rows:
        r = rows[0]
        return (f"{r['servers']} servers: {r['active']} reporting, "
                f"{r['not_reporting']} not reporting, {r['awaiting_reboot']} awaiting a reboot.")
    if tool == "hosts_affected_by_cve":
        cve = args.get("cve_id")
        if not n:
            return (f"No server is linked to {cve}. Either no advisory in the mirrors "
                    f"mentions it, or no server has the affected package. Check it in "
                    f"an assessment for a definite answer.")
        need = sum(1 for r in rows if r["state"] == "affected")
        reboot = sum(1 for r in rows if r["state"] == "fixed_pending_reboot")
        done = sum(1 for r in rows if r["state"] == "fixed_active")
        bits = []
        if need:
            bits.append(f"{need} still need the patch")
        if reboot:
            bits.append(f"{reboot} have it installed but need a reboot")
        if done:
            bits.append(f"{done} are patched and running the fix")
        return f"{cve} touches {n} servers: " + ", ".join(bits) + "."
    if tool == "cve_summary":
        if not n:
            return (f"No published data has been collected for {args.get('cve_id')} yet. "
                    f"Run the CVE data fetch on PATCH-01, or it may not be referenced "
                    f"by any advisory in the mirrors.")
        r = rows[0]
        parts = [f"{r['cve_id']}"]
        if r.get("cvss_score") is not None:
            parts.append(f"CVSS {r['cvss_score']} ({(r.get('cvss_severity') or '').lower()})")
        if r.get("attack_class"):
            parts.append(str(r["attack_class"]).lower())
        s = ", ".join(parts) + "."
        if r.get("exploited_in_wild"):
            s += " It is on CISA's exploited list, so attackers are using it now."
        s += f" {r.get('servers_affected') or 0} of your servers still need the fix."
        return s
    if tool == "hosts_needing_patch":
        if not n:
            return "No server has outstanding patches for that filter."
        exploited = sum(1 for r in rows if r.get("any_exploited"))
        s = f"{n} servers need patches"
        if args.get("os_id"):
            s += f" on {args['os_id']}"
        if args.get("host_group"):
            s += f" in group {args['host_group']}"
        s += "."
        if exploited:
            s += f" {exploited} of them have an advisory covering a CVE exploited in the wild."
        return s
    if tool == "host_detail":
        if not n:
            return f"No server named {args.get('hostname')} is enrolled."
        r = rows[0]
        return (f"{r['hostname']} runs {r['os']}, kernel {r['kernel_running']}, agent "
                f"{r['agent']}. It needs {r['needs_patch']} patches and "
                f"{r['needs_reboot']} advisories are waiting on a reboot"
                + (". A reboot is pending." if r["reboot_required"] else "."))
    if tool == "exploited_cves":
        return ("No CVE known to be exploited in the wild currently affects your servers."
                if not n else
                f"{n} CVEs known to be exploited in the wild still affect servers, "
                f"worst first.")
    if tool == "agents_by_state":
        st = args.get("state")
        return (f"No agent is {st.replace('_', ' ')}." if not n
                else f"{n} agents are {st.replace('_', ' ')}.")
    if tool == "vms_old_snapshots":
        return (f"No VM has a snapshot older than {args.get('days')} days." if not n
                else f"{n} VMs carry snapshots older than {args.get('days')} days, oldest first.")
    if tool == "vms_without_agent":
        return ("Every running Linux VM has an agent." if not n
                else f"{n} running Linux VMs have no agent, so they are not patched or assessed.")
    return f"{n} rows."


def ask(conn, question, ask_model=None, requested_by="admin"):
    """Answer one question. Read-only throughout."""
    q = (question or "").strip()
    if not q:
        raise ValueError("empty question")
    if len(q) > MAX_QUESTION:
        q = q[:MAX_QUESTION]

    tool, raw_args, how = pick_tool(q, ask_model)
    if not tool:
        return {"answer": "I cannot answer that one yet. I can report patch status, "
                          "CVEs, agents and VMs. Try naming a CVE, a server, or asking "
                          "which servers need patches.",
                "tool": None, "rows": [], "columns": [], "how": how,
                "tools": [{"name": k, "what": v["what"]} for k, v in TOOLS.items() if v.get("sql")]}

    spec = TOOLS[tool]
    if not spec.get("sql"):
        return {"answer": "Hardening scans are not built yet, so there is nothing to report.",
                "tool": tool, "rows": [], "columns": [], "how": how}

    args, missing = build_args(tool, raw_args)
    if missing:
        need = " and ".join(missing).replace("_", " ")
        return {"answer": f"I need the {need} to answer that. For example: "
                          f"\"which servers are affected by CVE-2026-31337?\"",
                "tool": tool, "rows": [], "columns": [], "how": how}

    rows = conn.execute(spec["sql"], args).fetchall()
    rows = [dict(r) for r in rows]
    cols = list(rows[0].keys()) if rows else []
    return {"answer": phrase(tool, args, rows), "tool": tool, "args":
            {k: v for k, v in args.items() if k != "limit"},
            "rows": rows[:MAX_ROWS], "columns": cols, "how": how,
            "truncated": len(rows) >= MAX_ROWS}
