"""
Version comparison for RPM and Debian packages.

This is the single most correctness-critical code in the platform. Every
applicability verdict rests on it, and the failure modes are silent: a wrong
comparison does not crash, it just marks a vulnerable host as fixed or a
fixed host as vulnerable.

Rules implemented faithfully rather than approximated:

  * Epoch is compared first, as an integer, and defaults to 0. Dropping it
    inverts results: 1:1.0 is NEWER than 0:9.9.
  * Versions are NEVER compared as strings. "1.10" > "1.9", which string
    comparison gets wrong.
  * RPM tilde (~) sorts before everything, including the end of the string,
    so 1.0~rc1 < 1.0. RPM caret (^) sorts after the end but before any
    further segment, so 1.0 < 1.0^git1 < 1.0.1.
  * Debian uses a different algorithm (verrevcmp) with its own ordering of
    letters and punctuation. The two must not be mixed.

rpmvercmp follows lib/rpmvercmp.c from rpm; verrevcmp follows lib/dpkg/
version.c from dpkg. Both are verified against the upstream test vectors in
the accompanying tests.
"""


# ---------------------------------------------------------------------------
# RPM
# ---------------------------------------------------------------------------

def _risdigit(c):
    return "0" <= c <= "9"


def _risalpha(c):
    return ("a" <= c <= "z") or ("A" <= c <= "Z")


def _risalnum(c):
    return _risdigit(c) or _risalpha(c)


def rpmvercmp(a, b):
    """Compare two RPM version or release strings.

    Returns -1, 0 or 1. Port of rpmvercmp() from rpm's lib/rpmvercmp.c.
    ASCII-only character classes are used deliberately, matching rpm's own
    risdigit/risalpha rather than Python's Unicode-aware str methods.
    """
    if a == b:
        return 0

    i = j = 0
    la, lb = len(a), len(b)

    while i < la or j < lb:
        # Skip separators, but not ~ or ^ which carry meaning
        while i < la and not _risalnum(a[i]) and a[i] not in "~^":
            i += 1
        while j < lb and not _risalnum(b[j]) and b[j] not in "~^":
            j += 1

        # Tilde sorts before anything, including end of string
        ta = i < la and a[i] == "~"
        tb = j < lb and b[j] == "~"
        if ta or tb:
            if not ta:
                return 1
            if not tb:
                return -1
            i += 1
            j += 1
            continue

        # Caret sorts after end of string, before any other segment
        ca = i < la and a[i] == "^"
        cb = j < lb and b[j] == "^"
        if ca or cb:
            if i >= la:
                return -1
            if j >= lb:
                return 1
            if not ca:
                return 1
            if not cb:
                return -1
            i += 1
            j += 1
            continue

        if not (i < la and j < lb):
            break

        # Take one segment from each: all digits, or all letters. The type
        # is decided by the first string.
        si, sj = i, j
        if _risdigit(a[i]):
            while i < la and _risdigit(a[i]):
                i += 1
            while j < lb and _risdigit(b[j]):
                j += 1
            isnum = True
        else:
            while i < la and _risalpha(a[i]):
                i += 1
            while j < lb and _risalpha(b[j]):
                j += 1
            isnum = False

        seg_a = a[si:i]
        seg_b = b[sj:j]

        # Segments of different types: numeric is newer than alpha
        if not seg_b:
            return 1 if isnum else -1

        if isnum:
            # Leading zeros are insignificant; then longer is bigger
            seg_a = seg_a.lstrip("0")
            seg_b = seg_b.lstrip("0")
            if len(seg_a) != len(seg_b):
                return 1 if len(seg_a) > len(seg_b) else -1

        if seg_a != seg_b:
            return 1 if seg_a > seg_b else -1

    if i >= la and j >= lb:
        return 0
    return -1 if i >= la else 1


def rpm_label_compare(e1, v1, r1, e2, v2, r2):
    """Compare two (epoch, version, release) tuples. Returns -1, 0, 1.

    Equivalent to rpm.labelCompare. Epoch compared as an integer first.
    """
    e1 = int(e1 or 0)
    e2 = int(e2 or 0)
    if e1 != e2:
        return 1 if e1 > e2 else -1
    c = rpmvercmp(v1 or "", v2 or "")
    if c != 0:
        return c
    return rpmvercmp(r1 or "", r2 or "")


# ---------------------------------------------------------------------------
# Debian
# ---------------------------------------------------------------------------

def _dpkg_order(c):
    """Character weight in dpkg's version ordering.

    Digits sort as 0 here because they are handled numerically elsewhere,
    letters sort by value, ~ sorts before everything including the empty
    string, and all other characters sort after letters.
    """
    if c is None:
        return 0
    if _risdigit(c):
        return 0
    if _risalpha(c):
        return ord(c)
    if c == "~":
        return -1
    return ord(c) + 256


def verrevcmp(a, b):
    """Compare two Debian upstream-version or revision strings.

    Returns a negative, zero or positive number. Port of verrevcmp() from
    dpkg's lib/dpkg/version.c.
    """
    a = a or ""
    b = b or ""
    i = j = 0
    la, lb = len(a), len(b)

    while i < la or j < lb:
        first_diff = 0

        # Non-digit prefix, compared character by character
        while (i < la and not _risdigit(a[i])) or (j < lb and not _risdigit(b[j])):
            ac = _dpkg_order(a[i] if i < la else None)
            bc = _dpkg_order(b[j] if j < lb else None)
            if ac != bc:
                return ac - bc
            i += 1
            j += 1

        # Numeric part: skip leading zeros, then compare digit by digit
        while i < la and a[i] == "0":
            i += 1
        while j < lb and b[j] == "0":
            j += 1
        while i < la and _risdigit(a[i]) and j < lb and _risdigit(b[j]):
            if not first_diff:
                first_diff = ord(a[i]) - ord(b[j])
            i += 1
            j += 1

        if i < la and _risdigit(a[i]):
            return 1
        if j < lb and _risdigit(b[j]):
            return -1
        if first_diff:
            return first_diff

    return 0


def parse_deb_version(s):
    """Split a Debian version into (epoch, upstream, revision)."""
    s = (s or "").strip()
    epoch = 0
    if ":" in s:
        head, _, s = s.partition(":")
        try:
            epoch = int(head)
        except ValueError:
            epoch = 0
    if "-" in s:
        upstream, _, revision = s.rpartition("-")
    else:
        upstream, revision = s, ""
    return epoch, upstream, revision


def deb_compare(e1, v1, r1, e2, v2, r2):
    """Compare two Debian (epoch, upstream, revision) tuples. -1, 0, 1."""
    e1 = int(e1 or 0)
    e2 = int(e2 or 0)
    if e1 != e2:
        return 1 if e1 > e2 else -1
    c = verrevcmp(v1, v2)
    if c:
        return 1 if c > 0 else -1
    c = verrevcmp(r1, r2)
    if c:
        return 1 if c > 0 else -1
    return 0


def evr_str(e, v, r):
    """Human-readable EVR, epoch shown only when non-zero."""
    e = int(e or 0)
    base = "%s-%s" % (v, r) if r else v
    return "%d:%s" % (e, base) if e else base
