#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 : image resolver
#
# Discovers which locally-present Docker image fills each role, rather than
# hardcoding repo:tag. Also records the image VARIANT, because different
# upstreams use different conventions for the same software:
#
#   postgres:16                     -> /var/lib/postgresql/data, POSTGRES_*, uid 999
#   ubi9/postgresql-16              -> /var/lib/pgsql/data,      POSTGRESQL_*, uid 26
#
# Anything generated later (compose files, env files) is built from what this
# finds, so swapping an image means re-running this, not editing scripts.
#
# Usage:
#   ./resolve-images.sh                 interactive, writes the manifest
#   ./resolve-images.sh --show          print what is currently resolved
#   ./resolve-images.sh --require nginx,postgres,redis
#                                       fail unless those roles resolve
#   ./resolve-images.sh --set postgres=myrepo/pg:16
#                                       override one role explicitly
#
# Output: /etc/patch-platform/images.env
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 027

VERSION="1.0.0"
ETC_DIR="/etc/patch-platform"
MANIFEST="$ETC_DIR/images.env"
LOG_DIR="/var/log/patch-platform"

SHOW_ONLY=no
REQUIRED_ROLES=""
declare -A OVERRIDE=()

while (($#)); do
  case "$1" in
    --show)    SHOW_ONLY=yes ;;
    --require) REQUIRED_ROLES="${2:-}"; shift ;;
    --set)
      # --set role=image
      if [[ "${2:-}" =~ ^([a-z0-9_]+)=(.+)$ ]]; then
        OVERRIDE["${BASH_REMATCH[1]}"]="${BASH_REMATCH[2]}"
      else
        echo "Bad --set value. Use: --set postgres=repo/image:tag" >&2; exit 2
      fi
      shift ;;
    -h|--help) sed -n '2,28p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$ETC_DIR" "$LOG_DIR"
LOG_FILE="$LOG_DIR/resolve-images-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"

log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\n' "$1" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Run as root."
command -v docker >/dev/null 2>&1 || die "Docker is not installed."
docker info >/dev/null 2>&1 || die "The Docker daemon is not responding."

# ---------------------------------------------------------------------------
# Candidate patterns, most specific first. These are search hints, not
# requirements: any image whose name matches is a candidate for that role.
# ---------------------------------------------------------------------------
ROLES=(nginx postgres redis pulp pulp_web python node)

declare -A PATTERNS=(
  [nginx]='nginx-12[0-9]|ubi[0-9]*/nginx|library/nginx|(^|/)nginx(:|$)'
  [postgres]='postgresql-1[0-9]|ubi[0-9]*/postgresql|library/postgres|(^|/)postgres(:|$)'
  [redis]='(^|/)redis(:|$)|library/redis|ubi[0-9]*/redis|rhel[0-9]*/redis'
  [pulp]='pulp/pulp-minimal|pulp/pulp(:|$)'
  [pulp_web]='pulp/pulp-web'
  [python]='ubi[0-9]*/python-3|library/python|(^|/)python(:|$)'
  [node]='ubi[0-9]*/nodejs-|library/node|(^|/)node(:|$)'
)

declare -A ROLE_DESC=(
  [nginx]="TLS ingress on 443"
  [postgres]="platform database"
  [redis]="job queue and cache"
  [pulp]="repository service (api, content, worker)"
  [pulp_web]="reference NGINX config for Pulp routes (not run)"
  [python]="build base for the patch API"
  [node]="build base for the dashboard"
)

# ---------------------------------------------------------------------------
# classify_variant <role> <image> -> variant string
# Determines which upstream convention an image follows.
# ---------------------------------------------------------------------------
classify_variant() {
  local role="$1" img="$2"
  case "$role" in
    postgres)
      if [[ "$img" =~ ubi[0-9]*/postgresql|rhel[0-9]*/postgresql|rhscl ]]; then
        echo "rh"
      else
        echo "upstream"
      fi ;;
    nginx)
      if [[ "$img" =~ ubi[0-9]*/nginx|rhel[0-9]*/nginx ]]; then
        echo "rh-s2i"
      else
        echo "upstream"
      fi ;;
    redis)
      [[ "$img" =~ ubi[0-9]*/redis|rhel[0-9]*/redis ]] && echo "rh" || echo "upstream" ;;
    *) echo "upstream" ;;
  esac
}

# ---------------------------------------------------------------------------
# Variant-specific conventions. This is the payload other scripts consume.
# ---------------------------------------------------------------------------
emit_conventions() {
  local role="$1" variant="$2"
  case "${role}_${variant}" in
    postgres_upstream)
      echo 'PG_DATA_PATH="/var/lib/postgresql/data"'
      echo 'PG_DATA_SUBDIR="pgdata"'
      echo 'PG_ENV_PREFIX="POSTGRES"'
      echo 'PG_UID="999"'
      echo 'PG_GID="999"'
      ;;
    postgres_rh)
      echo 'PG_DATA_PATH="/var/lib/pgsql/data"'
      echo 'PG_DATA_SUBDIR="userdata"'
      echo 'PG_ENV_PREFIX="POSTGRESQL"'
      echo 'PG_UID="26"'
      echo 'PG_GID="26"'
      ;;
    nginx_rh-s2i)
      # Unprivileged: cannot bind <1024 inside the container
      echo 'NGINX_HTTP_PORT="8080"'
      echo 'NGINX_HTTPS_PORT="8443"'
      echo 'NGINX_UID="1001"'
      echo 'NGINX_GID="0"'
      # MUST be quoted: this value contains a space, and an unquoted
      # assignment with a space is parsed as a command when sourced.
      echo 'NGINX_CONF_ARG="-c /etc/nginx/nginx.conf"'
      ;;
    nginx_upstream)
      # Runs as root by default and can bind 443 directly
      echo 'NGINX_HTTP_PORT="80"'
      echo 'NGINX_HTTPS_PORT="443"'
      echo 'NGINX_UID="0"'
      echo 'NGINX_GID="0"'
      echo 'NGINX_CONF_ARG=""'
      ;;
    redis_upstream)
      echo 'REDIS_UID="999"'
      echo 'REDIS_GID="999"'
      echo 'REDIS_DATA_PATH="/data"'
      ;;
    redis_rh)
      echo 'REDIS_UID="1001"'
      echo 'REDIS_GID="0"'
      echo 'REDIS_DATA_PATH="/var/lib/redis/data"'
      ;;
  esac
}

# ---------------------------------------------------------------------------
# Gather the local image inventory once
# ---------------------------------------------------------------------------
step "Reading the local image inventory"

IMAGE_LIST="$(docker images --format '{{.Repository}}:{{.Tag}}' 2>/dev/null \
  | grep -v '<none>' | sort -u || true)"

if [[ -z "$IMAGE_LIST" ]]; then
  die "No Docker images found locally. Pull or load them first."
fi

IMAGE_COUNT="$(printf '%s\n' "$IMAGE_LIST" | wc -l)"
say "$IMAGE_COUNT image(s) present."

# ---------------------------------------------------------------------------
# Show mode
# ---------------------------------------------------------------------------
if [[ "$SHOW_ONLY" == yes ]]; then
  if [[ -f "$MANIFEST" ]]; then
    step "Current manifest: $MANIFEST"
    sed 's/^/  /' "$MANIFEST"
  else
    warn "No manifest yet. Run without --show to create one."
  fi
  exit 0
fi

# ---------------------------------------------------------------------------
# Resolve each role
# ---------------------------------------------------------------------------
step "Resolving roles"

declare -A RESOLVED=() VARIANT=() ARCHOF=()
UNRESOLVED=()

for role in "${ROLES[@]}"; do
  chosen=""

  # An explicit override wins, but must actually exist locally
  if [[ -n "${OVERRIDE[$role]:-}" ]]; then
    cand="${OVERRIDE[$role]}"
    if docker image inspect "$cand" >/dev/null 2>&1; then
      chosen="$cand"
      log "role=$role override=$cand"
    else
      die "Override image for '$role' is not present locally: $cand"
    fi
  else
    # Collect every local image matching this role's patterns
    mapfile -t matches < <(printf '%s\n' "$IMAGE_LIST" \
      | grep -Ei "${PATTERNS[$role]}" || true)

    # pulp_web must not swallow pulp-minimal, and vice versa
    if [[ "$role" == pulp ]]; then
      mapfile -t matches < <(printf '%s\n' "${matches[@]:-}" | grep -v 'pulp-web' || true)
    fi

    # Drop empties
    filtered=()
    for m in "${matches[@]:-}"; do [[ -n "$m" ]] && filtered+=("$m") || true; done
    matches=("${filtered[@]:-}")

    if ((${#matches[@]} == 0)); then
      UNRESOLVED+=("$role")
      printf '  %-10s %-52s %s\n' "$role" "NOT FOUND" "(${ROLE_DESC[$role]})"
      continue
    elif ((${#matches[@]} == 1)); then
      chosen="${matches[0]}"
    else
      # Several candidates: prefer a concrete tag over :latest, then newest
      chosen="$(printf '%s\n' "${matches[@]}" | grep -v ':latest$' | head -1 || true)"
      [[ -n "$chosen" ]] || chosen="${matches[0]}"
      warn "Multiple candidates for '$role': ${matches[*]}"
      warn "  using $chosen  (override with --set $role=<image>)"
    fi
  fi

  RESOLVED[$role]="$chosen"
  VARIANT[$role]="$(classify_variant "$role" "$chosen")"
  ARCHOF[$role]="$(docker image inspect "$chosen" \
    --format '{{.Os}}/{{.Architecture}}' 2>/dev/null || echo unknown)"

  printf '  %-10s %-52s %s\n' "$role" "$chosen" "[${VARIANT[$role]}, ${ARCHOF[$role]}]"
done

# ---------------------------------------------------------------------------
# Architecture check -- a wrong-arch image loads fine and fails at runtime
# ---------------------------------------------------------------------------
step "Checking architecture"

HOST_ARCH="$(uname -m)"
case "$HOST_ARCH" in
  x86_64)  WANT="linux/amd64" ;;
  aarch64) WANT="linux/arm64" ;;
  *)       WANT="" ;;
esac

ARCH_BAD=0
if [[ -n "$WANT" ]]; then
  for role in "${!RESOLVED[@]}"; do
    a="${ARCHOF[$role]}"
    if [[ "$a" != "$WANT" && "$a" != unknown ]]; then
      warn "$role: ${RESOLVED[$role]} is $a but this host needs $WANT"
      ARCH_BAD=$((ARCH_BAD+1))
    fi
  done
  if (( ARCH_BAD > 0 )); then
    warn "Re-pull those with: docker pull --platform $WANT <image>"
    die "$ARCH_BAD image(s) have the wrong architecture."
  fi
  say "All resolved images are $WANT."
fi

# ---------------------------------------------------------------------------
# Version probe -- record what is actually inside, not what the tag claims
# ---------------------------------------------------------------------------
step "Probing versions"

probe() {
  local img="$1"; shift
  timeout 60 docker run --rm --network none --entrypoint "" "$img" "$@" 2>/dev/null | head -1 || true
}

PG_VER=""; REDIS_VER=""; NGINX_VER=""; PULP_VER=""; PY_VER=""; NODE_VER=""

if [[ -n "${RESOLVED[postgres]:-}" ]]; then
  PG_VER="$(probe "${RESOLVED[postgres]}" postgres --version || true)"
  [[ -n "$PG_VER" ]] || PG_VER="$(probe "${RESOLVED[postgres]}" sh -c 'postgres --version || pg_config --version')"
  say "postgres: ${PG_VER:-unknown}"
fi
if [[ -n "${RESOLVED[redis]:-}" ]]; then
  REDIS_VER="$(probe "${RESOLVED[redis]}" redis-server --version || true)"
  say "redis:    ${REDIS_VER:-unknown}"
fi
if [[ -n "${RESOLVED[nginx]:-}" ]]; then
  NGINX_VER="$(probe "${RESOLVED[nginx]}" nginx -v 2>&1 || true)"
  [[ -n "$NGINX_VER" ]] || NGINX_VER="$(probe "${RESOLVED[nginx]}" sh -c 'nginx -v 2>&1')"
  say "nginx:    ${NGINX_VER:-unknown}"
fi
if [[ -n "${RESOLVED[pulp]:-}" ]]; then
  PULP_VER="$(probe "${RESOLVED[pulp]}" sh -c 'pip show pulpcore 2>/dev/null | awk "/^Version/{print \$2}"')"
  say "pulpcore: ${PULP_VER:-unknown}"
  PULP_PLUGINS="$(probe "${RESOLVED[pulp]}" sh -c 'pip list 2>/dev/null | grep -Ei "^pulp-(rpm|deb|container)" | tr "\n" " "')"
  say "plugins:  ${PULP_PLUGINS:-unknown}"
fi
[[ -n "${RESOLVED[python]:-}" ]] && PY_VER="$(probe "${RESOLVED[python]}" python3 --version)" && say "python:   ${PY_VER:-unknown}" || true
[[ -n "${RESOLVED[node]:-}" ]] && NODE_VER="$(probe "${RESOLVED[node]}" node --version)" && say "node:     ${NODE_VER:-unknown}" || true

# ---------------------------------------------------------------------------
# Compatibility warnings based on what was actually found
# ---------------------------------------------------------------------------
step "Compatibility"

PG_MAJOR="$(printf '%s' "${PG_VER:-}" | grep -oE '[0-9]+' | head -1 || true)"
if [[ -n "$PG_MAJOR" && -n "$PULP_VER" ]]; then
  say "Pulp $PULP_VER with PostgreSQL $PG_MAJOR"
  if (( PG_MAJOR < 13 )); then
    warn "Pulp 3 needs PostgreSQL 13 or newer. This will fail on migration."
  elif (( PG_MAJOR > 16 )); then
    warn "PostgreSQL $PG_MAJOR is newer than Pulp typically certifies."
    warn "If pulp-api fails during migration, drop to PostgreSQL 15 or 16."
  else
    say "Version pairing looks fine."
  fi
elif [[ -n "$PG_MAJOR" ]]; then
  say "PostgreSQL $PG_MAJOR found; Pulp version unknown so no pairing check."
fi

if [[ -n "${RESOLVED[pulp]:-}" && -n "${PULP_PLUGINS:-}" ]]; then
  printf '%s' "$PULP_PLUGINS" | grep -qi 'pulp-rpm' \
    && say "pulp_rpm present (RHEL, Oracle Linux)" \
    || warn "pulp_rpm NOT found - RHEL and Oracle Linux mirroring will not work"
  printf '%s' "$PULP_PLUGINS" | grep -qi 'pulp-deb' \
    && say "pulp_deb present (Ubuntu)" \
    || warn "pulp_deb NOT found - Ubuntu mirroring will not work"
fi

# Pulp images should be from the same build
if [[ -n "${RESOLVED[pulp]:-}" && -n "${RESOLVED[pulp_web]:-}" ]]; then
  t1="${RESOLVED[pulp]##*:}"; t2="${RESOLVED[pulp_web]##*:}"
  [[ "$t1" == "$t2" ]] && say "pulp and pulp-web tags match ($t1)" \
    || warn "Tag mismatch: pulp=$t1 pulp-web=$t2 - use the same version"
fi

# ---------------------------------------------------------------------------
# Required roles
# ---------------------------------------------------------------------------
if [[ -n "$REQUIRED_ROLES" ]]; then
  step "Checking required roles"
  IFS=',' read -r -a req <<<"$REQUIRED_ROLES"
  missing=()
  for r in "${req[@]}"; do
    r="$(printf '%s' "$r" | tr -d ' ')"
    [[ -n "${RESOLVED[$r]:-}" ]] || missing+=("$r")
  done
  if ((${#missing[@]})); then
    die "Required role(s) unresolved: ${missing[*]}"
  fi
  say "All required roles resolved."
fi

# ---------------------------------------------------------------------------
# Write the manifest
# ---------------------------------------------------------------------------
step "Writing $MANIFEST"

[[ -f "$MANIFEST" ]] && cp -a "$MANIFEST" "$MANIFEST.$(date +%Y%m%d-%H%M%S).bak" || true

{
  echo "# Generated by resolve-images.sh v$VERSION on $(date -Is)"
  echo "# Discovered from the local Docker image store. Re-run after pulling"
  echo "# or replacing an image; do not edit by hand."
  echo
  for role in "${ROLES[@]}"; do
    img="${RESOLVED[$role]:-}"
    up="$(printf '%s' "$role" | tr '[:lower:]' '[:upper:]')"
    if [[ -n "$img" ]]; then
      echo "IMG_${up}=\"$img\""
      echo "IMG_${up}_VARIANT=\"${VARIANT[$role]}\""
      digest="$(docker image inspect "$img" --format '{{index .RepoDigests 0}}' 2>/dev/null || echo "")"
      [[ -n "$digest" ]] && echo "IMG_${up}_DIGEST=\"${digest##*@}\"" || true
      emit_conventions "$role" "${VARIANT[$role]}"
    else
      echo "IMG_${up}=\"\""
    fi
    echo
  done
  echo "# Probed versions"
  echo "VER_POSTGRES=\"${PG_VER:-}\""
  echo "VER_REDIS=\"${REDIS_VER:-}\""
  echo "VER_NGINX=\"${NGINX_VER:-}\""
  echo "VER_PULPCORE=\"${PULP_VER:-}\""
  echo "VER_PULP_PLUGINS=\"${PULP_PLUGINS:-}\""
  echo "VER_PYTHON=\"${PY_VER:-}\""
  echo "VER_NODE=\"${NODE_VER:-}\""
  echo
  echo "PG_MAJOR=\"${PG_MAJOR:-}\""
  echo "RESOLVED_AT=\"$(date -Is)\""
} >"$MANIFEST"

chmod 0644 "$MANIFEST"

# Every value must be quoted, or sourcing a value containing a space runs it
# as a command. Verify in a subshell before anything downstream trusts it.
if ! ( set -u; source "$MANIFEST" ) >/dev/null 2>&1; then
  warn "The manifest is not safely sourceable. Offending lines:"
  ( set -u; source "$MANIFEST" ) 2>&1 | head -5 >&2
  die "Manifest validation failed: $MANIFEST"
fi
BADQ="$(grep -nE '^[A-Z_]+=[^"]*[[:space:]]' "$MANIFEST" || true)"
if [[ -n "$BADQ" ]]; then
  warn "Unquoted values with spaces found:"
  printf '%s\n' "$BADQ" >&2
  die "Manifest would break when sourced."
fi
say "Manifest validated as safely sourceable."

echo
echo "================================================================"
echo " IMAGE MANIFEST WRITTEN"
echo "================================================================"
printf ' Manifest: %s\n' "$MANIFEST"
printf ' Resolved: %d of %d role(s)\n' "${#RESOLVED[@]}" "${#ROLES[@]}"
if ((${#UNRESOLVED[@]})); then
  printf ' Missing:  %s\n' "${UNRESOLVED[*]}"
fi
printf ' Log:      %s\n' "$LOG_FILE"
echo
echo " Later scripts source this file instead of hardcoding image names."
echo " After pulling or changing an image, re-run this script."
