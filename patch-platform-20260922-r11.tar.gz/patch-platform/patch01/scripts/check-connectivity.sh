#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 : vendor connectivity check
#
# Tests every repository URL this platform needs, through the corporate
# proxy, and reports exactly which ones work. Read-only: makes HEAD/GET
# requests only and changes nothing.
#
# Checks, in order:
#   1. proxy settings are discoverable
#   2. the proxy itself is reachable
#   3. DNS resolves each vendor hostname
#   4. each repository URL returns HTTP 200
#   5. RHEL entitlement certificates are present and valid
#   6. TLS interception detection on cdn.redhat.com
#
# Usage:
#   ./check-connectivity.sh              test everything
#   ./check-connectivity.sh --rhel       RHEL only
#   ./check-connectivity.sh --oracle     Oracle only
#   ./check-connectivity.sh --ubuntu     Ubuntu only
#   ./check-connectivity.sh --no-proxy   test direct, bypassing the proxy
#   ./check-connectivity.sh --verbose    show full curl output on failure
# ---------------------------------------------------------------------------

set -uo pipefail

PROXY_ENV="/etc/patch-platform/proxy.env"
ENT_DIR="/etc/pki/entitlement"
RHSM_CA="/etc/rhsm/ca/redhat-uep.pem"
TIMEOUT=45

ONLY=""
USE_PROXY=yes
VERBOSE=no

while (($#)); do
  case "$1" in
    --rhel)     ONLY=rhel ;;
    --oracle)   ONLY=oracle ;;
    --ubuntu)   ONLY=ubuntu ;;
    --no-proxy) USE_PROXY=no ;;
    --verbose|-v) VERBOSE=yes ;;
    --timeout)  TIMEOUT="${2:-45}"; shift ;;
    -h|--help)  sed -n '2,24p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

# Colour only when writing to a terminal
if [[ -t 1 ]]; then
  G=$'\033[32m'; R=$'\033[31m'; Y=$'\033[33m'; B=$'\033[1m'; N=$'\033[0m'
else
  G=""; R=""; Y=""; B=""; N=""
fi

PASS=0; FAIL=0; SKIP=0
FAILED_ITEMS=()

step() { printf '\n%s==> %s%s\n' "$B" "$1" "$N"; }
ok()   { printf '  %s[ OK ]%s  %s\n' "$G" "$N" "$1"; PASS=$((PASS+1)); }
bad()  { printf '  %s[FAIL]%s  %s\n' "$R" "$N" "$1"; FAIL=$((FAIL+1)); FAILED_ITEMS+=("$1"); }
warnx(){ printf '  %s[WARN]%s  %s\n' "$Y" "$N" "$1"; }
skip() { printf '  %s[SKIP]%s  %s\n' "$Y" "$N" "$1"; SKIP=$((SKIP+1)); }
info() { printf '         %s\n' "$1"; }

# ---------------------------------------------------------------------------
# Proxy discovery
# ---------------------------------------------------------------------------
step "Proxy configuration"

PROXY_HTTP=""
PROXY_HTTPS=""

# Prefer the recorded file, fall back to the environment
if [[ -f "$PROXY_ENV" ]]; then
  # Read without executing
  while IFS='=' read -r k v; do
    k="$(printf '%s' "$k" | tr -d ' ')"
    v="$(printf '%s' "$v" | tr -d ' ' | tr -d '"'"'")"
    case "$k" in
      HTTP_PROXY|http_proxy)   [[ -z "$PROXY_HTTP"  ]] && PROXY_HTTP="$v" ;;
      HTTPS_PROXY|https_proxy) [[ -z "$PROXY_HTTPS" ]] && PROXY_HTTPS="$v" ;;
    esac
  done < <(grep -E '^[A-Za-z_]+=' "$PROXY_ENV" 2>/dev/null || true)
  info "read from $PROXY_ENV"
fi

# Environment overrides an empty file value
[[ -z "$PROXY_HTTP"  ]] && PROXY_HTTP="${HTTP_PROXY:-${http_proxy:-}}"
[[ -z "$PROXY_HTTPS" ]] && PROXY_HTTPS="${HTTPS_PROXY:-${https_proxy:-}}"
# One set but not the other is almost always a mistake
[[ -z "$PROXY_HTTPS" && -n "$PROXY_HTTP"  ]] && PROXY_HTTPS="$PROXY_HTTP"
[[ -z "$PROXY_HTTP"  && -n "$PROXY_HTTPS" ]] && PROXY_HTTP="$PROXY_HTTPS"

if [[ "$USE_PROXY" == no ]]; then
  warnx "--no-proxy given: testing direct connections"
  PROXY_HTTP=""; PROXY_HTTPS=""
elif [[ -z "$PROXY_HTTPS" ]]; then
  bad "No proxy found in $PROXY_ENV or the environment"
  info "Set it in $PROXY_ENV or export HTTPS_PROXY, or use --no-proxy"
else
  ok "HTTPS proxy: $PROXY_HTTPS"
  [[ "$PROXY_HTTP" != "$PROXY_HTTPS" ]] && info "HTTP proxy:  $PROXY_HTTP" || true
fi

# Reachability of the proxy itself, before blaming any vendor
if [[ -n "$PROXY_HTTPS" ]]; then
  PHOST="${PROXY_HTTPS#*://}"; PHOST="${PHOST%%/*}"
  PPORT="${PHOST##*:}"; PHOST="${PHOST%%:*}"
  [[ "$PPORT" == "$PHOST" ]] && PPORT=8080 || true
  if timeout 10 bash -c "</dev/tcp/$PHOST/$PPORT" 2>/dev/null; then
    ok "Proxy TCP $PHOST:$PPORT reachable"
  else
    bad "Cannot open a TCP connection to the proxy at $PHOST:$PPORT"
    info "Everything below will fail until this works."
  fi
fi

# Docker daemon proxy: separate from the shell, and needed for image pulls
if [[ -d /etc/systemd/system/docker.service.d ]]; then
  if grep -rqs 'HTTPS_PROXY' /etc/systemd/system/docker.service.d/ 2>/dev/null; then
    ok "Docker daemon has a proxy configured"
  else
    warnx "Docker daemon has no proxy drop-in (only affects image pulls, not syncs)"
  fi
fi

# Pulp gets its proxy from the remote objects, not the environment
info "Note: Pulp uses the proxy stored in each remote object."
info "After changing the proxy run: ./phase2-repos.py --update-remotes"

# ---------------------------------------------------------------------------
# Entitlement certificates
# ---------------------------------------------------------------------------
CERT=""; KEY=""; CA=""

if [[ -z "$ONLY" || "$ONLY" == rhel ]]; then
  step "Red Hat entitlement certificates"

  if [[ -d "$ENT_DIR" ]]; then
    # Newest cert/key pair
    for k in $(ls -t "$ENT_DIR"/*-key.pem 2>/dev/null); do
      c="${k%-key.pem}.pem"
      if [[ -f "$c" ]]; then KEY="$k"; CERT="$c"; break; fi
    done
  fi

  if [[ -n "$CERT" ]]; then
    ok "Certificate: $(basename "$CERT")"
    info "Key:         $(basename "$KEY")"

    if command -v openssl >/dev/null 2>&1; then
      END="$(openssl x509 -enddate -noout -in "$CERT" 2>/dev/null | cut -d= -f2 || true)"
      if [[ -n "$END" ]]; then
        END_EPOCH="$(date -d "$END" +%s 2>/dev/null || echo 0)"
        NOW="$(date +%s)"
        if (( END_EPOCH > 0 )); then
          DAYS=$(( (END_EPOCH - NOW) / 86400 ))
          if (( DAYS < 0 )); then
            bad "Certificate EXPIRED $(( -DAYS )) days ago ($END)"
            info "Run: subscription-manager refresh"
          elif (( DAYS < 30 )); then
            warnx "Certificate expires in $DAYS days ($END)"
            info "Renew with: subscription-manager refresh"
            info "Then run:   ./phase2-repos.py --update-remotes"
          else
            ok "Certificate valid for $DAYS more days ($END)"
          fi
        fi
      fi
      # A mismatched pair produces a confusing TLS error later
      CMOD="$(openssl x509 -noout -modulus -in "$CERT" 2>/dev/null | openssl md5 2>/dev/null || true)"
      KMOD="$(openssl rsa -noout -modulus -in "$KEY" 2>/dev/null | openssl md5 2>/dev/null || true)"
      if [[ -n "$CMOD" && "$CMOD" == "$KMOD" ]]; then
        ok "Certificate and key match"
      elif [[ -n "$CMOD" && -n "$KMOD" ]]; then
        bad "Certificate and key DO NOT match"
      fi
    fi
  else
    bad "No entitlement certificate pair found in $ENT_DIR"
    info "This host may not be registered. Run: subscription-manager register"
    info "RHEL tests below will be skipped."
  fi

  if [[ -f "$RHSM_CA" ]]; then
    ok "Red Hat CA: $RHSM_CA"
    CA="$RHSM_CA"
  else
    warnx "$RHSM_CA not found; will fall back to the system trust store"
  fi
fi

# ---------------------------------------------------------------------------
# DNS
# ---------------------------------------------------------------------------
step "DNS resolution"

HOSTS=()
[[ -z "$ONLY" || "$ONLY" == rhel   ]] && HOSTS+=(cdn.redhat.com subscription.rhsm.redhat.com) || true
[[ -z "$ONLY" || "$ONLY" == oracle ]] && HOSTS+=(yum.oracle.com linux.oracle.com) || true
[[ -z "$ONLY" || "$ONLY" == ubuntu ]] && HOSTS+=(archive.ubuntu.com security.ubuntu.com) || true

for h in "${HOSTS[@]}"; do
  IPS=""
  if command -v getent >/dev/null 2>&1; then
    IPS="$(getent ahostsv4 "$h" 2>/dev/null | awk '{print $1}' | sort -u | head -3 | tr '\n' ' ' || true)"
  fi
  if [[ -n "${IPS// /}" ]]; then
    ok "$h -> $IPS"
  else
    # DNS failure is not fatal when the proxy resolves names on our behalf
    warnx "$h did not resolve locally (fine if the proxy resolves DNS)"
  fi
done

# ---------------------------------------------------------------------------
# URL tests
# ---------------------------------------------------------------------------

# test_url <label> <url> <proxy> [use_cert]
test_url() {
  local label="$1" url="$2" proxy="$3" usecert="${4:-no}"
  local args=(-s -o /dev/null -w '%{http_code}|%{time_total}|%{size_download}'
              --max-time "$TIMEOUT" -L)

  [[ -n "$proxy" ]] && args+=(--proxy "$proxy") || true

  if [[ "$usecert" == yes ]]; then
    if [[ -z "$CERT" ]]; then
      skip "$label (no entitlement certificate)"
      return
    fi
    args+=(--cert "$CERT" --key "$KEY")
    [[ -n "$CA" ]] && args+=(--cacert "$CA") || true
  fi

  local out code ttime
  out="$(curl "${args[@]}" "$url" 2>/dev/null || echo '000|0|0')"
  code="${out%%|*}"
  ttime="$(printf '%s' "$out" | cut -d'|' -f2)"

  case "$code" in
    200)
      ok "$(printf '%-24s HTTP 200  %ss' "$label" "$ttime")"
      ;;
    301|302|303|307|308)
      # -L was passed, so a bare redirect means the target was blocked
      bad "$(printf '%-24s HTTP %s  redirect not followed' "$label" "$code")"
      info "The redirect target is probably blocked. See the CDN hostnames"
      info "in proxy-allowlist.txt section 2."
      ;;
    401|403)
      bad "$(printf '%-24s HTTP %s  rejected' "$label" "$code")"
      if [[ "$usecert" == yes ]]; then
        info "Either this certificate does not entitle the product, or the"
        info "proxy is intercepting TLS on cdn.redhat.com. See section 4."
      fi
      ;;
    404)
      bad "$(printf '%-24s HTTP 404  path not found' "$label")"
      info "$url"
      ;;
    407)
      bad "$(printf '%-24s HTTP 407  proxy authentication required' "$label")"
      info "Supply credentials in the proxy URL or ask for an exempt service account."
      ;;
    000)
      bad "$(printf '%-24s no response (blocked, DNS, or timeout >%ss)' "$label" "$TIMEOUT")"
      ;;
    *)
      bad "$(printf '%-24s HTTP %s' "$label" "$code")"
      ;;
  esac

  if [[ "$VERBOSE" == yes && "$code" != "200" ]]; then
    printf '         --- verbose ---\n'
    local vargs=(-sS -o /dev/null -v --max-time "$TIMEOUT")
    [[ -n "$proxy" ]] && vargs+=(--proxy "$proxy") || true
    if [[ "$usecert" == yes && -n "$CERT" ]]; then
      vargs+=(--cert "$CERT" --key "$KEY")
      [[ -n "$CA" ]] && vargs+=(--cacert "$CA") || true
    fi
    curl "${vargs[@]}" "$url" 2>&1 | sed 's/^/         /' | head -25
  fi
}

if [[ -z "$ONLY" || "$ONLY" == oracle ]]; then
  step "Oracle Linux 8 (public, no certificate)"
  test_url "OL8 baseos" \
    "https://yum.oracle.com/repo/OracleLinux/OL8/baseos/latest/x86_64/repodata/repomd.xml" \
    "$PROXY_HTTPS"
  test_url "OL8 appstream" \
    "https://yum.oracle.com/repo/OracleLinux/OL8/appstream/x86_64/repodata/repomd.xml" \
    "$PROXY_HTTPS"
  test_url "OL8 UEK R6" \
    "https://yum.oracle.com/repo/OracleLinux/OL8/UEKR6/x86_64/repodata/repomd.xml" \
    "$PROXY_HTTPS"
  test_url "OL security OVAL" \
    "https://linux.oracle.com/security/oval/com.oracle.elsa-ol8.xml.bz2" \
    "$PROXY_HTTPS"
fi

if [[ -z "$ONLY" || "$ONLY" == rhel ]]; then
  step "RHEL (requires the entitlement certificate)"
  test_url "RHEL8 baseos" \
    "https://cdn.redhat.com/content/dist/rhel8/8/x86_64/baseos/os/repodata/repomd.xml" \
    "$PROXY_HTTPS" yes
  test_url "RHEL8 appstream" \
    "https://cdn.redhat.com/content/dist/rhel8/8/x86_64/appstream/os/repodata/repomd.xml" \
    "$PROXY_HTTPS" yes
  test_url "RHEL9 baseos" \
    "https://cdn.redhat.com/content/dist/rhel9/9/x86_64/baseos/os/repodata/repomd.xml" \
    "$PROXY_HTTPS" yes
  test_url "RHEL9 appstream" \
    "https://cdn.redhat.com/content/dist/rhel9/9/x86_64/appstream/os/repodata/repomd.xml" \
    "$PROXY_HTTPS" yes
  test_url "RHEL10 baseos" \
    "https://cdn.redhat.com/content/dist/rhel10/10/x86_64/baseos/os/repodata/repomd.xml" \
    "$PROXY_HTTPS" yes

  # TLS interception breaks client-certificate auth, so identify the issuer
  if [[ -n "$PROXY_HTTPS" ]] && command -v openssl >/dev/null 2>&1; then
    step "TLS interception check on cdn.redhat.com"
    PHOST="${PROXY_HTTPS#*://}"; PHOST="${PHOST%%/*}"
    ISSUER="$(timeout 30 openssl s_client -proxy "$PHOST" \
                -connect cdn.redhat.com:443 -servername cdn.redhat.com \
                </dev/null 2>/dev/null | openssl x509 -noout -issuer 2>/dev/null || true)"
    if [[ -z "$ISSUER" ]]; then
      warnx "Could not read the TLS certificate through the proxy"
    elif printf '%s' "$ISSUER" | grep -qiE 'digicert|globalsign|entrust|akamai|let.s encrypt|sectigo'; then
      ok "Certificate issued by a public CA - TLS is NOT intercepted"
      info "$ISSUER"
    else
      bad "cdn.redhat.com certificate is issued by an unexpected CA"
      info "$ISSUER"
      info "This strongly suggests the proxy is intercepting TLS, which will"
      info "prevent the entitlement client certificate from reaching Red Hat."
      info "Ask for cdn.redhat.com to be added to the TLS bypass list."
    fi
  fi
fi

if [[ -z "$ONLY" || "$ONLY" == ubuntu ]]; then
  step "Ubuntu (plain HTTP)"
  test_url "Ubuntu jammy" \
    "http://archive.ubuntu.com/ubuntu/dists/jammy/Release" "$PROXY_HTTP"
  test_url "Ubuntu jammy-updates" \
    "http://archive.ubuntu.com/ubuntu/dists/jammy-updates/Release" "$PROXY_HTTP"
  test_url "Ubuntu jammy-security" \
    "http://security.ubuntu.com/ubuntu/dists/jammy-security/Release" "$PROXY_HTTP"
  test_url "Ubuntu noble" \
    "http://archive.ubuntu.com/ubuntu/dists/noble/Release" "$PROXY_HTTP"
  test_url "Ubuntu noble-updates" \
    "http://archive.ubuntu.com/ubuntu/dists/noble-updates/Release" "$PROXY_HTTP"
  test_url "Ubuntu noble-security" \
    "http://security.ubuntu.com/ubuntu/dists/noble-security/Release" "$PROXY_HTTP"
fi

# ---------------------------------------------------------------------------
# Large transfer test
#
# A small metadata file can succeed while a large package fails, because of
# proxy response size limits or idle timeouts. Worth testing separately.
# ---------------------------------------------------------------------------
if [[ -z "$ONLY" ]]; then
  step "Large file transfer (proxy size limits)"
  PRIMARY_URL="https://yum.oracle.com/repo/OracleLinux/OL8/baseos/latest/x86_64/repodata/"
  SIZE="$(curl -s --max-time "$TIMEOUT" ${PROXY_HTTPS:+--proxy "$PROXY_HTTPS"} \
          "https://yum.oracle.com/repo/OracleLinux/OL8/baseos/latest/x86_64/repodata/repomd.xml" \
          2>/dev/null | wc -c || echo 0)"
  if [[ "$SIZE" =~ ^[0-9]+$ ]] && (( SIZE > 100 )); then
    ok "Downloaded repomd.xml ($SIZE bytes) - body transfer works"
    info "Metadata files can exceed 1 GB and packages 500 MB."
    info "If syncs fail partway, check the proxy's response size limit."
  else
    bad "Could not download a response body (got $SIZE bytes)"
    info "Headers may be passing while bodies are blocked."
  fi
fi

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
printf '\n%s================================================================%s\n' "$B" "$N"
printf '%s CONNECTIVITY SUMMARY%s\n' "$B" "$N"
printf '%s================================================================%s\n' "$B" "$N"
printf '  passed: %s%d%s   failed: %s%d%s   skipped: %d\n' \
  "$G" "$PASS" "$N" "$R" "$FAIL" "$N" "$SKIP"

if (( FAIL > 0 )); then
  printf '\n  Failures:\n'
  for f in "${FAILED_ITEMS[@]}"; do printf '    - %s\n' "$f"; done
  printf '\n  Next steps:\n'
  printf '    - Share proxy-allowlist.txt with the network team\n'
  printf '    - Re-run with --verbose to see the full curl exchange\n'
  printf '    - Test without the proxy to isolate it: --no-proxy\n'
  exit 1
fi

printf '\n  All reachable. If Pulp still fails, its remotes hold their own\n'
printf '  proxy setting - refresh them with:\n'
printf '    ./phase2-repos.py --update-remotes\n'
exit 0
