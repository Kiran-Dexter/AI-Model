#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 phase 6 : connect to AI-01 for verdict explanations
#
#   1. Fetches AI-01's certificate and pins it, after you confirm its
#      fingerprint matches the one shown on AI-01 itself
#   2. Stores the AI-01 URL and API key with the API's other secrets
#   3. Rebuilds and restarts the API so it includes the explanation code
#   4. Tests the link from inside the API container, the way it will run
#
# The API key is read from the terminal without echo, so it does not land in
# shell history or the process list.
#
# Usage:
#   ./phase6-llm.sh --ai01 10.142.32.180
#   ./phase6-llm.sh --check
#   ./phase6-llm.sh --warm 50          pre-generate up to 50 explanations
#   ./phase6-llm.sh --install-timer    warm the cache nightly after the CVE engine
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 027

PATCH_BASE="/patch"
SECRETS_DIR="$PATCH_BASE/secrets"
PIN_DIR="$SECRETS_DIR/ai01"
API_ENV="$SECRETS_DIR/api.env"
CONTAINER="patch01-api"
LOG_DIR="/var/log/patch-platform"

AI01=""; CHECK_ONLY=no; WARM=""; TIMER=no

while (($#)); do
  case "$1" in
    --ai01)          AI01="${2:-}"; shift ;;
    --check)         CHECK_ONLY=yes ;;
    --warm)          WARM="${2:-50}"; shift ;;
    --install-timer) TIMER=yes ;;
    -h|--help)       sed -n '2,19p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/phase6-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"

say()  { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }
step() { printf '\n==> %s\n' "$*"; }
die()  { printf '\nERROR: %s\nLog: %s\n' "$*" "$LOG_FILE" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Run as root."
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

in_api() { docker exec "$CONTAINER" "$@"; }

# ---------------------------------------------------------------------------
# Check
# ---------------------------------------------------------------------------
if [[ "$CHECK_ONLY" == yes ]]; then
  step "Link from the API container to AI-01"
  docker ps --format '{{.Names}}' | grep -qx "$CONTAINER" || die "$CONTAINER is not running."
  OUT="$(in_api python -m app.llm --health 2>&1 || true)"
  say "  $OUT"
  printf '%s' "$OUT" | grep -q '"reachable": true' || die "AI-01 is not reachable from the API."
  printf '%s' "$OUT" | grep -q '"tls_verified": true' \
    && say "  Certificate is pinned and verified." \
    || warn "TLS is NOT verified: re-run with --ai01 to pin AI-01's certificate."

  step "Explanation cache"
  ADMIN_PW="$(grep -E '^ADMIN_PASSWORD=' "$API_ENV" | cut -d= -f2-)"
  curl -sk -u "admin:$ADMIN_PW" https://127.0.0.1/api/v1/admin/llm/status \
    | python3 -c 'import json,sys
d=json.load(sys.stdin)
for k in ("cached_explanations","cache_hits_total","requests_24h","hits_24h","errors_24h","avg_generation_ms","prompt_version","model_tag"):
    print("  %-22s %s" % (k, d.get(k)))'
  exit 0
fi

# ---------------------------------------------------------------------------
# Warm the cache
# ---------------------------------------------------------------------------
if [[ -n "$WARM" ]]; then
  [[ "$WARM" =~ ^[0-9]+$ ]] || die "--warm needs a number."
  step "Pre-generating up to $WARM explanations"
  say "Most severe first. Facts already explained are skipped at no cost."
  in_api python -m app.llm --warm --limit "$WARM" 2>&1 | tee -a "$LOG_FILE"
  exit "${PIPESTATUS[0]}"
fi

# ---------------------------------------------------------------------------
# Nightly timer
# ---------------------------------------------------------------------------
if [[ "$TIMER" == yes ]]; then
  SELF="$(readlink -f "$0")"
  cat >/etc/systemd/system/patch01-llm-warm.service <<EOF
[Unit]
Description=Pre-generate PATCH-01 verdict explanations on AI-01
After=docker.service patch01-cve.service
Requires=docker.service

[Service]
Type=oneshot
ExecStart=$SELF --warm 100
TimeoutStartSec=4h
EOF
  # After the CVE engine's 03:30 run, so it explains fresh verdicts
  cat >/etc/systemd/system/patch01-llm-warm.timer <<'EOF'
[Unit]
Description=Warm the PATCH-01 explanation cache nightly

[Timer]
OnCalendar=*-*-* 04:30:00
RandomizedDelaySec=10min
Persistent=true

[Install]
WantedBy=timers.target
EOF
  systemctl daemon-reload
  systemctl enable --now patch01-llm-warm.timer
  say "Nightly warm-up installed at 04:30, after the CVE engine."
  systemctl list-timers patch01-llm-warm.timer --no-pager | sed -n '2p'
  exit 0
fi

# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------
[[ -n "$AI01" ]] || die "--ai01 is required: AI-01's IP address or hostname."
[[ -f "$API_ENV" ]] || die "Missing $API_ENV. Run phase3b-api.sh first."
AI01_URL="https://$AI01"

step "Reaching AI-01"
CODE="$(curl -sk -o /dev/null -w '%{http_code}' --noproxy '*' --max-time 10 "$AI01_URL/health" || echo 000)"
[[ "$CODE" == "200" ]] || die "AI-01 /health returned $CODE. Check AI-01 with ./ai01-setup.sh --check"
say "AI-01 answers on $AI01_URL"

# ---- pin the certificate --------------------------------------------------
step "Pinning AI-01's certificate"
TMP="$(mktemp)"; trap 'rm -f "$TMP"' EXIT
echo | timeout 15 openssl s_client -connect "$AI01:443" -servername "$AI01" 2>/dev/null \
  | openssl x509 -outform PEM > "$TMP" 2>/dev/null || true
[[ -s "$TMP" ]] || die "Could not read AI-01's certificate."

FP="$(openssl x509 -noout -fingerprint -sha256 -in "$TMP" | cut -d= -f2)"
SUBJ="$(openssl x509 -noout -subject -in "$TMP" | sed 's/^subject=//')"
SAN="$(openssl x509 -noout -ext subjectAltName -in "$TMP" 2>/dev/null | tail -1 | xargs || true)"
say "  Subject:     $SUBJ"
say "  Names:       $SAN"
say "  Fingerprint: $FP"
say ""
say "  On AI-01, run this and check the fingerprint is identical:"
say "    openssl x509 -noout -fingerprint -sha256 -in /llm/certs/ai01.crt"
say ""
say "  If they differ, something between the two hosts is presenting its own"
say "  certificate. Do not continue."

if [[ -t 0 ]]; then
  read -r -p "  Do the fingerprints match? [y/N]: " ans || true
  [[ "${ans,,}" =~ ^(y|yes)$ ]] || die "Stopped: fingerprint not confirmed."
else
  die "Run interactively so the fingerprint can be confirmed."
fi

mkdir -p "$PIN_DIR"
cp -f "$TMP" "$PIN_DIR/ca.crt"
# The API runs as uid 1001 in group 0
chown root:0 "$PIN_DIR" "$PIN_DIR/ca.crt"
chmod 0750 "$PIN_DIR"; chmod 0640 "$PIN_DIR/ca.crt"
say "Pinned to $PIN_DIR/ca.crt"

# The pinned certificate must actually verify for the address in use
if curl -s -o /dev/null --noproxy '*' --cacert "$PIN_DIR/ca.crt" --max-time 10 "$AI01_URL/health"; then
  say "Verified: AI-01 matches the pinned certificate for $AI01."
else
  warn "The pinned certificate does not verify for '$AI01'."
  warn "Its names are: $SAN"
  die "Use an address that appears in those names."
fi

# ---- API key --------------------------------------------------------------
step "AI-01 API key"
say "On AI-01, run:  ./ai01-setup.sh --show-key"
read -r -s -p "  Paste the key (input is hidden): " KEY; echo
KEY="$(printf '%s' "$KEY" | tr -d '[:space:]')"
[[ "$KEY" =~ ^[A-Fa-f0-9]{32,128}$ ]] || die "That does not look like the hex key ai01-setup.sh generates."

# Prove the key works before saving it
CODE="$(curl -s -o /dev/null -w '%{http_code}' --noproxy '*' --cacert "$PIN_DIR/ca.crt" --max-time 120 \
  -H "Authorization: Bearer $KEY" -H 'Content-Type: application/json' \
  -d '{"messages":[{"role":"user","content":"Reply with the single word ok."}],"max_tokens":4,"chat_template_kwargs":{"enable_thinking":false}}' \
  "$AI01_URL/v1/chat/completions" || echo 000)"
case "$CODE" in
  200) say "Key accepted by AI-01." ;;
  401) die "AI-01 rejected the key." ;;
  *)   die "Test request returned HTTP $CODE." ;;
esac

cp -a "$API_ENV" "$API_ENV.$(date +%Y%m%d-%H%M%S).bak"
sed -i '/^AI01_/d' "$API_ENV"
cat >>"$API_ENV" <<EOF
AI01_URL=$AI01_URL
AI01_API_KEY=$KEY
AI01_CA_FILE=/etc/ai01/ca.crt
AI01_MODEL_TAG=qwen3-8b-q4km
EOF
chmod 0600 "$API_ENV"
unset KEY
say "Saved to $API_ENV"

# ---- rebuild and restart the API -----------------------------------------
step "Rebuilding the API with the explanation code"
"$SRC_DIR/scripts/phase3b-api.sh" >>"$LOG_FILE" 2>&1 \
  || { tail -20 "$LOG_FILE" >&2; die "API rebuild failed."; }
say "API rebuilt and restarted."

step "Testing from inside the API container"
OUT="$(in_api python -m app.llm --health 2>&1 || true)"
say "  $OUT"
printf '%s' "$OUT" | grep -q '"reachable": true' || die "The API container cannot reach AI-01."
printf '%s' "$OUT" | grep -q '"tls_verified": true' || die "The API container is not verifying AI-01's certificate."

echo
echo "================================================================"
echo " PHASE 6 COMPLETE - AI-01 CONNECTED"
echo "================================================================"
echo " AI-01:        $AI01_URL (certificate pinned)"
echo " Explanations: dashboard, any host page, Explain on an advisory"
echo
echo " Next:"
echo "   ./scripts/phase5-dashboard.sh     deploy the dashboard with the Explain button"
echo "   ./scripts/phase6-llm.sh --warm 20 pre-generate the most severe ones"
echo "   ./scripts/phase6-llm.sh --check"
