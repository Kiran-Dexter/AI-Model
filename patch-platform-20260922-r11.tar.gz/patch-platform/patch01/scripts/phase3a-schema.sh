#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 phase 3a : apply the patch platform schema
#
# Applies sql/001-schema.sql to the patchdb database. Idempotent: the schema
# uses IF NOT EXISTS and ON CONFLICT throughout, so re-running is safe.
#
# Usage:
#   ./phase3a-schema.sh --dry-run    print the SQL that would run
#   ./phase3a-schema.sh              apply it
#   ./phase3a-schema.sh --check      verify what is present
#   ./phase3a-schema.sh --describe   dump the resulting table layout
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 027

PATCH_BASE="/patch"
ETC_DIR="/etc/patch-platform"
LOG_DIR="/var/log/patch-platform"
SECRETS_DIR="$PATCH_BASE/secrets"
PG_CONTAINER="patch01-postgres"

DRY_RUN=no
CHECK_ONLY=no
DESCRIBE=no

while (($#)); do
  case "$1" in
    --dry-run)  DRY_RUN=yes ;;
    --check)    CHECK_ONLY=yes ;;
    --describe) DESCRIBE=yes ;;
    -h|--help)  sed -n '2,14p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/phase3a-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"

log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Run as root."

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# Migrations applied in filename order
mapfile -t MIGRATIONS < <(ls -1 "$SRC_DIR"/sql/*.sql 2>/dev/null | sort)
((${#MIGRATIONS[@]})) || die "No migrations found in $SRC_DIR/sql/"
SCHEMA="${MIGRATIONS[0]}"   # kept for messages

# ---------------------------------------------------------------------------
# Database connection
# ---------------------------------------------------------------------------
step "Checking the database"

docker ps --format '{{.Names}}' | grep -qx "$PG_CONTAINER" \
  || die "$PG_CONTAINER is not running. Run phase1b-data.sh first."

PG_ENV="$SECRETS_DIR/postgres.env"
[[ -f "$PG_ENV" ]] || die "Missing $PG_ENV"
# shellcheck disable=SC1090
source "$PG_ENV"

DB="${PATCHAPI_DB_NAME:-patchdb}"
DBUSER="${PATCHAPI_DB_USER:-patchapi}"

say "Database: $DB  (owner $DBUSER)"

# psql as superuser: creating extensions and triggers needs it
psqlq() {
  docker exec -i "$PG_CONTAINER" psql -U postgres -d "$DB" -qtAX "$@"
}

psqlq -c 'SELECT 1' >/dev/null 2>>"$LOG_FILE" \
  || die "Cannot connect to database '$DB'. Check phase1b-data.sh --check"
say "Connection ok"

PGVER="$(psqlq -c 'SHOW server_version' 2>/dev/null | head -1 || echo unknown)"
say "PostgreSQL $PGVER"

# ---------------------------------------------------------------------------
# Describe mode
# ---------------------------------------------------------------------------
if [[ "$DESCRIBE" == yes ]]; then
  step "Tables"
  docker exec -i "$PG_CONTAINER" psql -U postgres -d "$DB" -c '\dt'
  step "Views"
  docker exec -i "$PG_CONTAINER" psql -U postgres -d "$DB" -c '\dv'
  step "Enum types"
  docker exec -i "$PG_CONTAINER" psql -U postgres -d "$DB" -c \
    "SELECT t.typname AS type, string_agg(e.enumlabel, ', ' ORDER BY e.enumsortorder) AS values
       FROM pg_type t JOIN pg_enum e ON e.enumtypid = t.oid
       JOIN pg_namespace n ON n.oid = t.typnamespace
      WHERE n.nspname = 'public' GROUP BY t.typname ORDER BY t.typname;"
  step "Row counts"
  docker exec -i "$PG_CONTAINER" psql -U postgres -d "$DB" -c \
    "SELECT relname AS table, n_live_tup AS rows
       FROM pg_stat_user_tables ORDER BY relname;"
  exit 0
fi

# ---------------------------------------------------------------------------
# Check mode
# ---------------------------------------------------------------------------
if [[ "$CHECK_ONLY" == yes ]]; then
  step "Verifying the schema"
  FAILS=0

  VER="$(psqlq -c 'SELECT max(version) FROM schema_version' 2>/dev/null || echo "")"
  if [[ -n "$VER" ]]; then
    say "Schema version: $VER"
  else
    warn "schema_version table not found - schema not applied yet"
    FAILS=$((FAILS+1))
  fi

  for t in hosts enrollment_tokens host_packages inventory_runs \
           advisories advisory_cves advisory_packages \
           host_applicability audit_log schema_version \
           host_groups maintenance_windows content_snapshots \
           snapshot_repositories environment_content repo_syncs \
           patch_jobs job_targets job_target_packages job_events \
           agent_commands llm_explanations llm_requests; do
    n="$(psqlq -c "SELECT count(*) FROM information_schema.tables
                    WHERE table_schema='public' AND table_name='$t'" 2>/dev/null || echo 0)"
    if [[ "$n" == "1" ]]; then
      rows="$(psqlq -c "SELECT count(*) FROM $t" 2>/dev/null || echo '?')"
      say "  table $t ($rows rows)"
    else
      warn "  table $t MISSING"; FAILS=$((FAILS+1))
    fi
  done

  for v in v_fleet_summary v_compliance v_not_mirrored \
           v_due_jobs v_reboot_timeouts v_job_progress v_compliance_export; do
    n="$(psqlq -c "SELECT count(*) FROM information_schema.views
                    WHERE table_schema='public' AND table_name='$v'" 2>/dev/null || echo 0)"
    [[ "$n" == "1" ]] && say "  view $v" \
      || { warn "  view $v MISSING"; FAILS=$((FAILS+1)); }
  done

  # The five applicability states are the engine's contract
  STATES="$(psqlq -c "SELECT string_agg(e.enumlabel, ',' ORDER BY e.enumsortorder)
                        FROM pg_type t JOIN pg_enum e ON e.enumtypid=t.oid
                       WHERE t.typname='applicability_state'" 2>/dev/null || echo "")"
  EXPECT="not_affected,affected,fixed_active,fixed_pending_reboot,unknown"
  if [[ "$STATES" == "$EXPECT" ]]; then
    say "  applicability_state: $STATES"
  else
    warn "  applicability_state is '$STATES', expected '$EXPECT'"; FAILS=$((FAILS+1))
  fi

  # The audit log must reject UPDATE and DELETE
  step "Audit log immutability"
  if psqlq -c "INSERT INTO audit_log (actor, actor_type, action)
               VALUES ('schema-check','system','immutability_test')" >/dev/null 2>&1; then
    if psqlq -c "UPDATE audit_log SET actor='tampered'
                  WHERE action='immutability_test'" >/dev/null 2>&1; then
      warn "  UPDATE on audit_log SUCCEEDED - the trigger is not working"
      FAILS=$((FAILS+1))
    else
      say "  UPDATE correctly rejected"
    fi
    if psqlq -c "DELETE FROM audit_log WHERE action='immutability_test'" >/dev/null 2>&1; then
      warn "  DELETE on audit_log SUCCEEDED - the trigger is not working"
      FAILS=$((FAILS+1))
    else
      say "  DELETE correctly rejected"
    fi
  else
    warn "  could not insert a test row"; FAILS=$((FAILS+1))
  fi

  # job_events carries the same immutability guarantee
  if psqlq -c "SELECT count(*) FROM pg_trigger WHERE tgname='trg_jevents_no_update'" 2>/dev/null | grep -q '^1$'; then
    say "  job_events immutability trigger present"
  else
    warn "  job_events immutability trigger MISSING"; FAILS=$((FAILS+1))
  fi

  # The agent verb set must stay closed - no free-text command verb
  VERBS="$(psqlq -c "SELECT string_agg(e.enumlabel, ',' ORDER BY e.enumsortorder)
                       FROM pg_type t JOIN pg_enum e ON e.enumtypid=t.oid
                      WHERE t.typname='agent_verb'" 2>/dev/null || echo "")"
  if [[ -n "$VERBS" ]]; then
    say "  agent_verb: $VERBS"
    if printf '%s' "$VERBS" | grep -qiE 'shell|exec|command|script|raw'; then
      warn "  agent_verb contains an arbitrary-execution verb"; FAILS=$((FAILS+1))
    fi
  else
    warn "  agent_verb enum MISSING"; FAILS=$((FAILS+1))
  fi

  # mark_stale_hosts must exist for the scheduler
  FN="$(psqlq -c "SELECT count(*) FROM pg_proc WHERE proname='mark_stale_hosts'" 2>/dev/null || echo 0)"
  [[ "$FN" == "1" ]] && say "  function mark_stale_hosts" \
    || { warn "  function mark_stale_hosts MISSING"; FAILS=$((FAILS+1)); }

  (( FAILS == 0 )) && say "
All checks passed." || die "$FAILS check(s) failed."
  exit 0
fi

# ---------------------------------------------------------------------------
# Dry run
# ---------------------------------------------------------------------------
if [[ "$DRY_RUN" == yes ]]; then
  step "SQL that would be applied"
  for f in "${MIGRATIONS[@]}"; do
    say "File: $(basename "$f") ($(wc -l <"$f") lines)"
  done
  say ""
  say "Objects created:"
  for f in "${MIGRATIONS[@]}"; do
    grep -oE 'CREATE (TABLE IF NOT EXISTS|TYPE|OR REPLACE (VIEW|FUNCTION)|INDEX IF NOT EXISTS|TRIGGER) [a-z_]+' "$f" \
      | sed 's/CREATE //; s/IF NOT EXISTS //; s/OR REPLACE //' | sed 's/^/  /'
  done
  say ""
  say "Nothing was changed. Re-run without --dry-run to apply."
  exit 0
fi

# ---------------------------------------------------------------------------
# Apply
# ---------------------------------------------------------------------------
step "Applying the schema"

# pgcrypto for gen_random_uuid() on PostgreSQL below 13; harmless on 13+
psqlq -c 'CREATE EXTENSION IF NOT EXISTS pgcrypto' >>"$LOG_FILE" 2>&1 \
  || warn "Could not create the pgcrypto extension (fine on PostgreSQL 13+)"

# Each migration runs in its own transaction, so a later failure does not
# roll back an earlier migration that succeeded.
for f in "${MIGRATIONS[@]}"; do
  base="$(basename "$f")"
  say "applying $base ..."
  if docker exec -i "$PG_CONTAINER" psql -U postgres -d "$DB" \
       -v ON_ERROR_STOP=1 --single-transaction -f - <"$f" >>"$LOG_FILE" 2>&1; then
    say "  $base ok"
  else
    warn "$base FAILED. Last 30 log lines:"
    tail -30 "$LOG_FILE" >&2
    die "$base was rolled back. Earlier migrations remain applied."
  fi
done

# ---------------------------------------------------------------------------
# Grants
#
# The API connects as patchapi, not as superuser. It needs DML on the tables
# and SELECT on the views, but not the ability to alter the schema.
# ---------------------------------------------------------------------------
step "Granting privileges to $DBUSER"

psqlq <<GRANTS >>"$LOG_FILE" 2>&1 || warn "Some grants failed; see $LOG_FILE"
GRANT USAGE ON SCHEMA public TO $DBUSER;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO $DBUSER;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO $DBUSER;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO $DBUSER;
-- Future tables too, so a later migration needs no re-grant
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO $DBUSER;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO $DBUSER;
GRANTS
say "Grants applied."

# The audit log is compliance evidence. The API may append but must not
# rewrite history, which the trigger enforces regardless of privilege.
say "Note: audit_log is append-only, enforced by trigger for all roles."

# ---------------------------------------------------------------------------
# Verify
# ---------------------------------------------------------------------------
step "Verifying"

TBLS="$(psqlq -c "SELECT count(*) FROM information_schema.tables
                   WHERE table_schema='public'" || echo 0)"
VIEWS="$(psqlq -c "SELECT count(*) FROM information_schema.views
                    WHERE table_schema='public'" || echo 0)"
ENUMS="$(psqlq -c "SELECT count(DISTINCT t.typname) FROM pg_type t
                    JOIN pg_enum e ON e.enumtypid=t.oid" || echo 0)"
VER="$(psqlq -c 'SELECT max(version) FROM schema_version' || echo '?')"

say "tables: $TBLS   views: $VIEWS   enum types: $ENUMS   schema version: $VER"

# Prove the API role can actually use it
if docker exec -i -e PGPASSWORD="${PATCHAPI_DB_PASSWORD:-}" "$PG_CONTAINER" \
     psql -U "$DBUSER" -d "$DB" -h 127.0.0.1 -qtAX \
     -c 'SELECT count(*) FROM hosts' >/dev/null 2>>"$LOG_FILE"; then
  say "Role $DBUSER can query the schema."
else
  warn "Role $DBUSER could NOT query the schema. See $LOG_FILE"
fi

cat >"$ETC_DIR/phase3a.env" <<EOF
# Generated by phase3a-schema.sh on $(date -Is)
PP_SCHEMA_VERSION="$VER"
PP_PATCHDB_NAME="$DB"
PP_PATCHDB_USER="$DBUSER"
PP_SCHEMA_FILE="$SCHEMA"
EOF
chmod 0600 "$ETC_DIR/phase3a.env"

echo
echo "================================================================"
echo " PHASE 3a COMPLETE - SCHEMA"
echo "================================================================"
printf ' Database: %s\n' "$DB"
printf ' Tables:   %s   Views: %s   Version: %s\n' "$TBLS" "$VIEWS" "$VER"
printf ' Log:      %s\n' "$LOG_FILE"
echo
echo " Inspect:  ./scripts/phase3a-schema.sh --describe"
echo " Verify:   ./scripts/phase3a-schema.sh --check"
echo
echo " The five applicability states are the engine's contract:"
echo "   not_affected  affected  fixed_active  fixed_pending_reboot  unknown"
echo " Only fixed_active counts as remediated."
echo
echo " Next: the patch API (enrollment, check-in, inventory) and the agent."
