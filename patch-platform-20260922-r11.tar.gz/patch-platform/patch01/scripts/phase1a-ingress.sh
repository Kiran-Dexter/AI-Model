#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# PATCH-01 phase 1a : NGINX + TLS ingress
#
# Deploys the single 443 entry point. Deliberately stops there: Pulp,
# PostgreSQL, Redis and the API come in later phases. The NGINX config
# already carries their routes, and resolves upstreams at request time, so
# a route to a backend that does not exist yet returns 502 on that path
# only rather than preventing NGINX from starting.
#
# Assumes Docker (not Podman), SELinux disabled, firewalld disabled.
#
# Usage:
#   ./phase1a-ingress.sh              deploy
#   ./phase1a-ingress.sh --dry-run    show the plan only
#   ./phase1a-ingress.sh --check      validate an existing deployment
#   ./phase1a-ingress.sh --down       stop and remove the ingress
# ---------------------------------------------------------------------------

set -Eeuo pipefail
umask 027

VERSION="1.0.0"
PATCH_BASE="/patch"
ETC_DIR="/etc/patch-platform"
LOG_DIR="/var/log/patch-platform"
IMAGES_MANIFEST="/etc/patch-platform/images.env"
NGINX_IMAGE=""          # resolved from the manifest, never hardcoded
NGINX_VARIANT=""
NGINX_HTTPS_PORT=8443
NGINX_HTTP_PORT=8080
NGINX_UID=1001
NGINX_CONF_ARG="-c /etc/nginx/nginx.conf"

DRY_RUN=no
CHECK_ONLY=no
DO_DOWN=no
CERT_DAYS=825

while (($#)); do
  case "$1" in
    --dry-run) DRY_RUN=yes ;;
    --check)   CHECK_ONLY=yes ;;
    --down)    DO_DOWN=yes ;;
    --base)    PATCH_BASE="${2:-}"; shift ;;
    -h|--help) sed -n '2,20p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/phase1a-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG_FILE"; chmod 0600 "$LOG_FILE"

log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG_FILE"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG_FILE" >&2; exit 1; }

run() {
  if [[ "$DRY_RUN" == yes ]]; then printf '  [dry-run] %s\n' "$*"; return 0; fi
  log "EXEC: $*"
  "$@" </dev/null >>"$LOG_FILE" 2>&1
}

confirm() {
  local p="$1" d="${2:-y}" r hint="[y/N]"
  [[ "$d" == y ]] && hint="[Y/n]" || true
  [[ -t 0 ]] || { [[ "$d" == y ]]; return; }
  read -r -p "$p $hint: " r || true
  r="${r:-$d}"; [[ "${r,,}" =~ ^(y|yes)$ ]]
}

[[ $EUID -eq 0 ]] || die "Run as root."

COMPOSE_DIR="$PATCH_BASE/compose"
NGINX_CFG="$PATCH_BASE/config/nginx"
CERT_DIR="$PATCH_BASE/certs"

# ---------------------------------------------------------------------------
# Tear down
# ---------------------------------------------------------------------------
if [[ "$DO_DOWN" == yes ]]; then
  step "Stopping the ingress"
  if [[ -f "$COMPOSE_DIR/docker-compose.yml" ]]; then
    (cd "$COMPOSE_DIR" && docker compose down) || warn "compose down reported errors"
  fi
  docker rm -f patch01-nginx >/dev/null 2>&1 || true
  say "Ingress stopped. Config and certs left in place."
  exit 0
fi

# ---------------------------------------------------------------------------
# Preconditions
# ---------------------------------------------------------------------------
step "Checking preconditions"

command -v docker >/dev/null 2>&1 || die "Docker is not installed."
docker info >/dev/null 2>&1 || die "The Docker daemon is not responding. Try: systemctl start docker"

if ! docker compose version >/dev/null 2>&1; then
  die "The 'docker compose' plugin is missing. Install docker-compose-plugin."
fi
say "Docker:  $(docker --version 2>/dev/null | head -1)"
say "Compose: $(docker compose version --short 2>/dev/null || echo unknown)"

# Docker's data-root should be on the platform volume, not the root filesystem
DATA_ROOT="$(docker info --format '{{.DockerRootDir}}' 2>/dev/null || echo unknown)"
say "Docker data-root: $DATA_ROOT"
if [[ "$DATA_ROOT" == /var/lib/docker* ]]; then
  warn "Docker is storing images on the root filesystem."
  warn "Phase 0 created a volume for this. To move it, with Docker stopped:"
  warn "    systemctl stop docker"
  warn "    mkdir -p $PATCH_BASE/images/docker"
  warn "    rsync -aHAX /var/lib/docker/ $PATCH_BASE/images/docker/"
  warn "    echo '{\"data-root\": \"$PATCH_BASE/images/docker\"}' > /etc/docker/daemon.json"
  warn "    systemctl start docker"
  warn "Continuing - this is not fatal, but the root filesystem can fill."
fi

# Confirm the expected mounts exist
for d in "$PATCH_BASE" "$PATCH_BASE/config" "$PATCH_BASE/certs" "$PATCH_BASE/logs"; do
  [[ -d "$d" ]] || die "Missing directory: $d  (run the phase 0 bootstrap first)"
done
say "Platform directories present."

if [[ -f "$ETC_DIR/phase0.env" ]]; then
  say "Phase 0 baseline found."
else
  warn "No $ETC_DIR/phase0.env - continuing, but phase 0 may not have run."
fi

# ---------------------------------------------------------------------------
# Port 443 availability
# ---------------------------------------------------------------------------
step "Checking port 443"

PORT_HOLDER=""
if command -v ss >/dev/null 2>&1; then
  PORT_HOLDER="$(ss -ltnp 2>/dev/null | awk '$4 ~ /:443$/ {print; exit}' || true)"
fi
if [[ -n "$PORT_HOLDER" ]]; then
  # Our own container re-binding is fine
  if docker ps --format '{{.Names}}' 2>/dev/null | grep -qx patch01-nginx; then
    say "443 is held by the existing patch01-nginx container."
  else
    warn "Port 443 is already in use:"
    warn "  $PORT_HOLDER"
    warn "If this is an RPM-installed nginx or httpd, stop and disable it:"
    warn "    systemctl disable --now nginx httpd"
    confirm "Continue anyway?" n || exit 0
  fi
else
  say "Port 443 is free."
fi

# ---------------------------------------------------------------------------
# Check mode
# ---------------------------------------------------------------------------
if [[ "$CHECK_ONLY" == yes ]]; then
  step "Validating the deployment"
  FAILS=0

  if docker ps --format '{{.Names}}\t{{.Status}}' | grep -q '^patch01-nginx'; then
    say "Container: $(docker ps --format '{{.Status}}' --filter name=patch01-nginx)"
  else
    warn "patch01-nginx is not running"; FAILS=$((FAILS+1))
  fi

  if curl -fsk --max-time 10 https://127.0.0.1/healthz >/dev/null 2>&1; then
    say "HTTPS health check passed."
  else
    warn "HTTPS health check failed"; FAILS=$((FAILS+1))
  fi

  if [[ -f "$CERT_DIR/patch01.crt" ]]; then
    say "Certificate expires: $(openssl x509 -enddate -noout -in "$CERT_DIR/patch01.crt" | cut -d= -f2)"
    say "Certificate SANs: $(openssl x509 -text -noout -in "$CERT_DIR/patch01.crt" \
      | grep -A1 'Subject Alternative Name' | tail -1 | xargs || echo none)"
  else
    warn "No certificate at $CERT_DIR/patch01.crt"; FAILS=$((FAILS+1))
  fi

  step "Exposure check"
  if command -v ss >/dev/null 2>&1; then
    ss -ltnH 2>/dev/null | awk '{print $4}' | while read -r a; do
      p="${a##*:}"
      case "$p" in
        5432|6379|24816|24817|8000)
          b="${a%:*}"; b="${b#\[}"; b="${b%\]}"
          case "$b" in
            127.0.0.1|::1) printf '  %-22s localhost only - fine\n' "$a" ;;
            *) printf '  %-22s EXPOSED - must bind 127.0.0.1\n' "$a" ;;
          esac ;;
      esac
    done
  fi

  (( FAILS == 0 )) && say "All checks passed." || die "$FAILS check(s) failed."
  exit 0
fi

# ---------------------------------------------------------------------------
# Image
# ---------------------------------------------------------------------------
step "Resolving the NGINX image"

# The image is discovered, not hardcoded. resolve-images.sh scans the local
# Docker store and records which image fills each role plus its variant,
# because an s2i UBI nginx and an upstream nginx need different ports,
# UIDs and config handling.
if [[ ! -f "$IMAGES_MANIFEST" ]]; then
  warn "No image manifest at $IMAGES_MANIFEST"
  warn "Run the resolver first:  ./scripts/resolve-images.sh --require nginx"
  die "Cannot continue without a resolved image manifest."
fi

# shellcheck disable=SC1090
source "$IMAGES_MANIFEST"

NGINX_IMAGE="${IMG_NGINX:-}"
NGINX_VARIANT="${IMG_NGINX_VARIANT:-unknown}"
[[ -n "$NGINX_IMAGE" ]] || die "The manifest has no nginx image. Re-run resolve-images.sh"

docker image inspect "$NGINX_IMAGE" >/dev/null 2>&1 \
  || die "Manifest lists $NGINX_IMAGE but it is no longer present. Re-run resolve-images.sh"

# Variant decides the in-container ports and whether -c is needed
NGINX_HTTPS_PORT="${NGINX_HTTPS_PORT:-8443}"
NGINX_HTTP_PORT="${NGINX_HTTP_PORT:-8080}"
NGINX_UID="${NGINX_UID:-1001}"
NGINX_CONF_ARG="${NGINX_CONF_ARG--c /etc/nginx/nginx.conf}"

say "Image:   $NGINX_IMAGE"
say "Variant: $NGINX_VARIANT  (container ports ${NGINX_HTTP_PORT}/${NGINX_HTTPS_PORT}, uid $NGINX_UID)"
say "Version: ${VER_NGINX:-unknown}"

ARCH="$(docker image inspect "$NGINX_IMAGE" --format '{{.Os}}/{{.Architecture}}' 2>/dev/null || echo unknown)"
[[ "$ARCH" == "linux/amd64" || "$ARCH" == unknown ]] \
  || die "Image is $ARCH but this host is $(uname -m). Re-pull with --platform linux/amd64."

# nginx 1.25.1+ replaced "listen ... http2" with a separate "http2 on;"
NGINX_MAJMIN="$(printf '%s' "${VER_NGINX:-}" | grep -oE '[0-9]+\.[0-9]+' | head -1 || true)"
HTTP2_STYLE=listen
if [[ -n "$NGINX_MAJMIN" ]]; then
  if [[ "$(printf '%s\n' "1.25" "$NGINX_MAJMIN" | sort -V | head -1)" == "1.25" && "$NGINX_MAJMIN" != "1.25" ]] \
     || [[ "$NGINX_MAJMIN" == "1.25" ]]; then
    HTTP2_STYLE=directive
  fi
fi
say "http2 syntax: $HTTP2_STYLE (nginx ${NGINX_MAJMIN:-unknown})"

# ---------------------------------------------------------------------------
# Config files
# ---------------------------------------------------------------------------
step "Installing configuration"

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

run mkdir -p "$NGINX_CFG/conf.d" "$COMPOSE_DIR" "$CERT_DIR" "$PATCH_BASE/logs/nginx"

install_file() {
  local src="$1" dst="$2"
  [[ -f "$src" ]] || die "Source file missing: $src"
  if [[ -f "$dst" ]] && ! cmp -s "$src" "$dst"; then
    local bak="$dst.$(date +%Y%m%d-%H%M%S).bak"
    [[ "$DRY_RUN" == yes ]] && printf '  [dry-run] backup %s\n' "$dst" || cp -a "$dst" "$bak"
    say "Backed up $(basename "$dst")"
  fi
  if [[ "$DRY_RUN" == yes ]]; then
    printf '  [dry-run] install %s -> %s\n' "$src" "$dst"
  else
    cp -f "$src" "$dst"; chmod 0644 "$dst"
    say "Installed $(basename "$dst")"
  fi
}

install_file "$SRC_DIR/nginx/nginx.conf"           "$NGINX_CFG/nginx.conf"
install_file "$SRC_DIR/nginx/conf.d/patch01.conf"  "$NGINX_CFG/conf.d/patch01.conf"
# Compose is GENERATED from the resolved image and variant, not copied,
# so the port mapping and command match whichever nginx image is present.
if [[ "$DRY_RUN" == yes ]]; then
  printf '  [dry-run] generate %s for %s\n' "$COMPOSE_DIR/docker-compose.yml" "$NGINX_IMAGE"
else
  [[ -f "$COMPOSE_DIR/docker-compose.yml" ]] \
    && cp -a "$COMPOSE_DIR/docker-compose.yml" "$COMPOSE_DIR/docker-compose.yml.$(date +%Y%m%d-%H%M%S).bak" || true
  sed -e "s|@@IMAGE@@|$NGINX_IMAGE|g" \
      -e "s|@@HTTPS_PORT@@|$NGINX_HTTPS_PORT|g" \
      -e "s|@@HTTP_PORT@@|$NGINX_HTTP_PORT|g" \
      -e "s|@@CONF_ARG@@|$NGINX_CONF_ARG|g" \
      "$SRC_DIR/compose/docker-compose.yml.tmpl" >"$COMPOSE_DIR/docker-compose.yml"
  chmod 0644 "$COMPOSE_DIR/docker-compose.yml"
  say "Generated docker-compose.yml"
fi

# Match the http2 syntax to the nginx version actually present
if [[ "$DRY_RUN" != yes ]]; then
  if [[ "$HTTP2_STYLE" == directive ]]; then
    sed -i -e 's|^\(\s*\)listen \([0-9]*\) ssl http2;|\1listen \2 ssl;|' \
           -e 's|^\(\s*\)listen \[::\]:\([0-9]*\) ssl http2;|\1listen [::]:\2 ssl;\n\1http2 on;|' \
           "$NGINX_CFG/conf.d/patch01.conf"
    say "Adjusted config to nginx 1.25+ http2 syntax"
  fi
  # Align the listen ports with the variant
  sed -i -e "s|listen 8443|listen $NGINX_HTTPS_PORT|g" \
         -e "s|listen \[::\]:8443|listen [::]:$NGINX_HTTPS_PORT|g" \
         -e "s|listen 8080|listen $NGINX_HTTP_PORT|g" \
         -e "s|listen \[::\]:8080|listen [::]:$NGINX_HTTP_PORT|g" \
         "$NGINX_CFG/conf.d/patch01.conf"
fi

# Container filesystem access.
#
# Phase 0 created certs/ as 0700 root:root. A container running as a
# non-root UID cannot traverse a 0700 directory, so nginx fails with
# "permission denied" on the certificate before it ever opens the file.
#
# The UBI nginx image runs as UID 1001 with GID 0, so group-root plus r-x
# grants exactly the access needed while keeping the directory closed to
# other local users. 0755 would also work but needlessly exposes the key.
if [[ "$DRY_RUN" != yes ]]; then
  chown -R "$NGINX_UID":0 "$PATCH_BASE/logs/nginx" 2>/dev/null || true
  chmod 0775 "$PATCH_BASE/logs/nginx"

  # Certificate directory must be traversable by the container user
  chown root:0 "$CERT_DIR"
  chmod 0750 "$CERT_DIR"
  say "Set $CERT_DIR to 0750 root:0 so the container (uid $NGINX_UID, gid 0) can read it"

  # Config must be readable too
  chown -R root:0 "$NGINX_CFG"
  chmod 0750 "$NGINX_CFG" "$NGINX_CFG/conf.d"
  find "$NGINX_CFG" -type f -exec chmod 0640 {} \;
fi

# ---------------------------------------------------------------------------
# Placeholder certificate
# ---------------------------------------------------------------------------
step "TLS certificate"

FQDN="$(hostname -f 2>/dev/null || hostname)"
SHORT="$(hostname -s 2>/dev/null || hostname)"
HOST_IP="$(hostname -I 2>/dev/null | awk '{print $1}' || echo 127.0.0.1)"

if [[ -f "$CERT_DIR/patch01.crt" && -f "$CERT_DIR/patch01.key" ]]; then
  say "Existing certificate found; leaving it alone."
  say "  expires: $(openssl x509 -enddate -noout -in "$CERT_DIR/patch01.crt" | cut -d= -f2)"
else
  say "Generating a self-signed PLACEHOLDER certificate."
  say "  CN/SAN: $FQDN, $SHORT, $HOST_IP"
  warn "This is a placeholder. Agents pin the certificate that appears here,"
  warn "so replace it with the corporate CA cert BEFORE enrolling any agent."

  if [[ "$DRY_RUN" != yes ]]; then
    cat >"$CERT_DIR/openssl.cnf" <<EOF
[req]
distinguished_name = dn
req_extensions     = ext
prompt             = no

[dn]
CN = $FQDN
O  = Patch Platform
OU = PATCH-01

[ext]
subjectAltName   = @san
keyUsage         = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
basicConstraints = critical, CA:FALSE

[san]
DNS.1 = $FQDN
DNS.2 = $SHORT
DNS.3 = localhost
IP.1  = $HOST_IP
IP.2  = 127.0.0.1
EOF
    openssl req -x509 -nodes -newkey rsa:2048 \
      -keyout "$CERT_DIR/patch01.key" \
      -out    "$CERT_DIR/patch01.crt" \
      -days   "$CERT_DAYS" \
      -config "$CERT_DIR/openssl.cnf" \
      -extensions ext >>"$LOG_FILE" 2>&1 \
      || die "Certificate generation failed."

    # root:0 with group read. The container user is in group 0, so it can
    # read both; no other local user can read the private key.
    chown root:0 "$CERT_DIR/patch01.key" "$CERT_DIR/patch01.crt"
    chmod 0640 "$CERT_DIR/patch01.key"
    chmod 0644 "$CERT_DIR/patch01.crt"
    say "Certificate created, valid $CERT_DAYS days."
  fi
fi

# ---------------------------------------------------------------------------
# Validate the config before starting
# ---------------------------------------------------------------------------
step "Validating the NGINX configuration"

# Prove the container user can actually read the cert and config before
# starting the real service. A permission problem here is otherwise only
# visible as an nginx startup error.
if [[ "$DRY_RUN" != yes ]]; then
  if ! docker run --rm --user "$NGINX_UID:0" --network none \
        -v "$CERT_DIR:/etc/nginx/certs:ro" \
        -v "$NGINX_CFG:/etc/nginx-test:ro" \
        --entrypoint "" "$NGINX_IMAGE" \
        sh -c 'cat /etc/nginx/certs/patch01.crt >/dev/null && cat /etc/nginx/certs/patch01.key >/dev/null && cat /etc/nginx-test/nginx.conf >/dev/null' \
        >>"$LOG_FILE" 2>&1; then
    warn "The container user (uid $NGINX_UID, gid 0) cannot read the certificate or config."
    warn "Current permissions:"
    ls -ldn "$CERT_DIR" "$NGINX_CFG" >&2
    ls -ln "$CERT_DIR" >&2
    warn "Fix with:"
    warn "    chown root:0 $CERT_DIR $CERT_DIR/* $NGINX_CFG"
    warn "    chmod 0750 $CERT_DIR; chmod 0640 $CERT_DIR/patch01.key; chmod 0644 $CERT_DIR/patch01.crt"
    die "Permission check failed."
  fi
  say "Container user can read the certificate and config."
fi

if [[ "$DRY_RUN" != yes ]]; then
  if docker run --rm \
      -v "$NGINX_CFG/nginx.conf:/etc/nginx/nginx.conf:ro" \
      -v "$NGINX_CFG/conf.d:/etc/nginx/conf.d:ro" \
      -v "$CERT_DIR:/etc/nginx/certs:ro" \
      "$NGINX_IMAGE" nginx $NGINX_CONF_ARG -t >>"$LOG_FILE" 2>&1; then
    say "Configuration is valid."
  else
    warn "nginx -t failed. Last lines of the log:"
    tail -20 "$LOG_FILE" >&2
    die "Fix the configuration before deploying."
  fi
fi

# ---------------------------------------------------------------------------
# Deploy
# ---------------------------------------------------------------------------
step "Starting the ingress"

if [[ "$DRY_RUN" == yes ]]; then
  say "[dry-run] docker compose up -d"
else
  (cd "$COMPOSE_DIR" && docker compose up -d) >>"$LOG_FILE" 2>&1 \
    || { warn "compose up failed:"; tail -20 "$LOG_FILE" >&2; die "Deployment failed."; }

  say "Waiting for the health check..."
  for i in $(seq 1 30); do
    if curl -fsk --max-time 5 https://127.0.0.1/healthz >/dev/null 2>&1; then
      say "Ingress is responding on 443."
      break
    fi
    if (( i == 30 )); then
      warn "Ingress did not respond within 30s. Container logs:"
      docker logs --tail 30 patch01-nginx 2>&1 | tail -30 >&2
      die "Health check failed."
    fi
    sleep 1
  done
fi

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
if [[ "$DRY_RUN" != yes ]]; then
  cat >"$ETC_DIR/phase1a.env" <<EOF
# Generated by phase1a-ingress.sh v$VERSION on $(date -Is)
PP_PHASE1A_VERSION=$VERSION
PP_INGRESS_CONTAINER=patch01-nginx
PP_INGRESS_IMAGE=$NGINX_IMAGE
PP_INGRESS_VARIANT=$NGINX_VARIANT
PP_INGRESS_NETWORK=patchnet
PP_NGINX_CONFIG=$NGINX_CFG
PP_CERT_FILE=$CERT_DIR/patch01.crt
PP_CERT_KEY=$CERT_DIR/patch01.key
PP_CERT_PLACEHOLDER=yes
PP_FQDN=$FQDN
EOF
  chmod 0600 "$ETC_DIR/phase1a.env"
fi

echo
echo "================================================================"
echo " PHASE 1a COMPLETE - INGRESS"
echo "================================================================"
printf ' URL:       https://%s/healthz\n' "$FQDN"
printf ' Container: patch01-nginx\n'
printf ' Network:   patchnet (172.30.0.0/24)\n'
printf ' Config:    %s\n' "$NGINX_CFG"
printf ' Cert:      %s  (PLACEHOLDER)\n' "$CERT_DIR/patch01.crt"
printf ' Log:       %s\n' "$LOG_FILE"
echo
echo " Routes configured, backends not yet deployed:"
echo "   /pulp/content/  -> pulp-content:24816"
echo "   /pulp/api/v3/   -> pulp-api:24817"
echo "   /api/           -> patch-api:8000"
echo "   /               -> dashboard:8080"
echo
echo " Test:  curl -k https://localhost/healthz"
echo " Next:  phase 1b - PostgreSQL and Redis on patchnet, bound to 127.0.0.1"
