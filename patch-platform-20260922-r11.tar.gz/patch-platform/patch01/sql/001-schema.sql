-- ===========================================================================
-- PATCH-01 : patch platform schema
--
-- Applied to the patchdb database, owned by the patchapi role.
-- Idempotent: safe to re-run.
--
-- Design notes that matter later:
--
--   * applicability_state is an ENUM, not free text. It is the engine's
--     public contract: the dashboard, the compliance export and the LLM
--     prompts all read the same five values rather than each re-deriving
--     "is this host patched" from raw package data. That is how the numbers
--     stay consistent between what an operator sees and what an auditor is
--     handed.
--
--   * "fixed_active" and "fixed_pending_reboot" are deliberately separate.
--     A host with the patched kernel installed but the vulnerable one still
--     running is NOT remediated. Collapsing these is the error that
--     survives an audit right up until someone checks uname -r.
--
--   * "unknown" exists so a host that stops reporting fails toward
--     attention rather than silently reading as "not affected".
--
--   * Package versions are stored as separate epoch/version/release columns,
--     never as a single string. Correct comparison needs EVR semantics and
--     epoch is the field most often dropped, which silently inverts results.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Enumerated types
-- ---------------------------------------------------------------------------

DO $$ BEGIN
    CREATE TYPE host_status AS ENUM (
        'pending',        -- enrolled but never checked in
        'active',         -- checking in normally
        'stale',          -- no check-in within the staleness window
        'decommissioned'  -- retired, retained for audit history
    );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE package_manager AS ENUM ('dnf', 'yum', 'apt');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    -- The five applicability states. See the header.
    CREATE TYPE applicability_state AS ENUM (
        'not_affected',          -- package absent, or architecture N/A
        'affected',              -- installed version older than the fix
        'fixed_active',          -- fix installed AND running: remediated
        'fixed_pending_reboot',  -- fix installed, old version still running
        'unknown'                -- inventory too old to judge
    );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE fix_availability AS ENUM (
        'available',    -- the fixed package is in our Pulp repositories
        'not_mirrored', -- vendor has a fix, we do not hold it
        'no_fix',       -- vendor has published no fix yet
        'unknown'
    );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ---------------------------------------------------------------------------
-- Hosts
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS hosts (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hostname            TEXT NOT NULL,
    fqdn                TEXT,
    -- Stable machine identity. Survives a hostname change, which is why it
    -- is the enrollment key rather than the hostname.
    machine_id          TEXT NOT NULL UNIQUE,

    os_id               TEXT,           -- rhel, ol, ubuntu
    os_version          TEXT,           -- 9.4, 8.10, 22.04
    os_major            INTEGER,        -- 9, 8, 22
    arch                TEXT,
    pkg_manager         package_manager,

    kernel_running      TEXT,           -- uname -r
    kernel_latest       TEXT,           -- newest installed kernel
    reboot_required     BOOLEAN DEFAULT FALSE,
    reboot_reason       TEXT,

    agent_version       TEXT,
    status              host_status NOT NULL DEFAULT 'pending',

    -- Identity. cert_serial is populated once mTLS enrollment replaces
    -- bearer tokens; both are supported so the switch needs no schema change.
    cert_serial         TEXT,
    token_hash          TEXT,

    host_group          TEXT DEFAULT 'default',
    tags                JSONB DEFAULT '{}'::jsonb,

    enrolled_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_checkin        TIMESTAMPTZ,
    last_inventory      TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_hosts_hostname     ON hosts (hostname);
CREATE INDEX IF NOT EXISTS idx_hosts_status       ON hosts (status);
CREATE INDEX IF NOT EXISTS idx_hosts_last_checkin ON hosts (last_checkin);
CREATE INDEX IF NOT EXISTS idx_hosts_os           ON hosts (os_id, os_major);
CREATE INDEX IF NOT EXISTS idx_hosts_group        ON hosts (host_group);

-- ---------------------------------------------------------------------------
-- Enrollment tokens
--
-- Short-lived, single-use. A shared secret baked into an image would let any
-- host that ever held it impersonate any other host indefinitely, so tokens
-- are issued individually and expire.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS enrollment_tokens (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    token_hash    TEXT NOT NULL UNIQUE,   -- sha256, never the token itself
    label         TEXT,
    host_group    TEXT DEFAULT 'default',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at    TIMESTAMPTZ NOT NULL,
    used_at       TIMESTAMPTZ,
    used_by_host  UUID REFERENCES hosts(id) ON DELETE SET NULL,
    revoked_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_tokens_hash ON enrollment_tokens (token_hash);

-- ---------------------------------------------------------------------------
-- Installed packages
--
-- Current state per host. Replaced wholesale on each inventory run: a diff
-- based approach loses packages removed outside the agent's knowledge.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS host_packages (
    host_id     UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    name        TEXT NOT NULL,
    arch        TEXT NOT NULL DEFAULT 'noarch',
    -- EVR components kept separate. Epoch defaults to 0 rather than NULL so
    -- comparisons never silently skip it.
    epoch       INTEGER NOT NULL DEFAULT 0,
    version     TEXT NOT NULL,
    release     TEXT NOT NULL DEFAULT '',
    -- Original string as reported, for display and debugging only. Never
    -- compared against anything.
    full_nevra  TEXT,
    install_time TIMESTAMPTZ,
    from_repo   TEXT,
    PRIMARY KEY (host_id, name, arch)
);

CREATE INDEX IF NOT EXISTS idx_pkgs_name    ON host_packages (name);
CREATE INDEX IF NOT EXISTS idx_pkgs_host    ON host_packages (host_id);
CREATE INDEX IF NOT EXISTS idx_pkgs_name_ver ON host_packages (name, version);

-- ---------------------------------------------------------------------------
-- Inventory runs
--
-- One row per collection. Keeps a history of when each host reported and
-- how much, so a host that reports an implausibly small package set can be
-- spotted rather than silently overwriting good data.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS inventory_runs (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    host_id        UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    collected_at   TIMESTAMPTZ NOT NULL,
    received_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    package_count  INTEGER NOT NULL,
    -- Hash of the sorted package list. Identical hashes mean nothing
    -- changed, which lets the applicability engine skip recomputation.
    content_hash   TEXT,
    agent_version  TEXT,
    duration_ms    INTEGER,
    ok             BOOLEAN NOT NULL DEFAULT TRUE,
    error          TEXT
);

CREATE INDEX IF NOT EXISTS idx_invruns_host ON inventory_runs (host_id, collected_at DESC);

-- ---------------------------------------------------------------------------
-- Vendor advisories and CVE data
--
-- Populated from vendor OVAL/errata feeds, never from upstream CVE version
-- numbers: Red Hat, Oracle and Ubuntu all backport fixes, so an installed
-- openssl-3.0.7-27.el9 can be patched against a CVE whose upstream fix
-- landed in 3.2. Applicability must use the vendor's fixed-in NEVRA.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS advisories (
    id            TEXT PRIMARY KEY,       -- RHSA-2026:1234, ELSA-..., USN-...
    vendor        TEXT NOT NULL,          -- redhat, oracle, ubuntu
    title         TEXT,
    severity      TEXT,                   -- critical, important, moderate, low
    issued_at     DATE,
    updated_at_v  DATE,
    summary       TEXT,
    os_id         TEXT,
    os_major      INTEGER,
    source_url    TEXT,
    imported_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_adv_vendor ON advisories (vendor, os_major);
CREATE INDEX IF NOT EXISTS idx_adv_sev    ON advisories (severity);

CREATE TABLE IF NOT EXISTS advisory_cves (
    advisory_id  TEXT NOT NULL REFERENCES advisories(id) ON DELETE CASCADE,
    cve_id       TEXT NOT NULL,
    cvss_score   NUMERIC(3,1),
    PRIMARY KEY (advisory_id, cve_id)
);

CREATE INDEX IF NOT EXISTS idx_advcve_cve ON advisory_cves (cve_id);

-- The fixed-in NEVRA per package per advisory. This is the authoritative
-- comparison target.
CREATE TABLE IF NOT EXISTS advisory_packages (
    advisory_id  TEXT NOT NULL REFERENCES advisories(id) ON DELETE CASCADE,
    name         TEXT NOT NULL,
    arch         TEXT NOT NULL DEFAULT 'x86_64',
    epoch        INTEGER NOT NULL DEFAULT 0,
    version      TEXT NOT NULL,
    release      TEXT NOT NULL DEFAULT '',
    module_name  TEXT,      -- RHEL 8 modular content
    module_stream TEXT,
    PRIMARY KEY (advisory_id, name, arch)
);

CREATE INDEX IF NOT EXISTS idx_advpkg_name ON advisory_packages (name);

-- ---------------------------------------------------------------------------
-- Applicability results
--
-- One row per host per advisory. Recomputed when inventory or advisory data
-- changes; the content_hash on inventory_runs lets unchanged hosts be
-- skipped.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS host_applicability (
    host_id        UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    advisory_id    TEXT NOT NULL REFERENCES advisories(id) ON DELETE CASCADE,
    state          applicability_state NOT NULL,
    fix_available  fix_availability NOT NULL DEFAULT 'unknown',
    -- What the decision was based on, so a result can be explained and
    -- audited rather than taken on trust.
    package_name   TEXT,
    installed_evr  TEXT,
    fixed_evr      TEXT,
    reason         TEXT,
    computed_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (host_id, advisory_id)
);

CREATE INDEX IF NOT EXISTS idx_app_state    ON host_applicability (state);
CREATE INDEX IF NOT EXISTS idx_app_host     ON host_applicability (host_id, state);
CREATE INDEX IF NOT EXISTS idx_app_advisory ON host_applicability (advisory_id, state);

-- ---------------------------------------------------------------------------
-- Audit log
--
-- Append only. This is the compliance evidence, so it must not be
-- rewritable by the same code path that runs jobs. The trigger below blocks
-- UPDATE and DELETE outright.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS audit_log (
    id          BIGSERIAL PRIMARY KEY,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    actor       TEXT NOT NULL,          -- admin username, agent id, 'system'
    actor_type  TEXT NOT NULL,          -- user, agent, system
    action      TEXT NOT NULL,          -- enroll, checkin, inventory, ...
    host_id     UUID,
    object_type TEXT,
    object_id   TEXT,
    detail      JSONB DEFAULT '{}'::jsonb,
    source_ip   INET
);

CREATE INDEX IF NOT EXISTS idx_audit_time  ON audit_log (occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_host  ON audit_log (host_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_log (action, occurred_at DESC);

CREATE OR REPLACE FUNCTION audit_log_immutable() RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'audit_log is append-only; % is not permitted', TG_OP;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_audit_no_update ON audit_log;
CREATE TRIGGER trg_audit_no_update
    BEFORE UPDATE OR DELETE ON audit_log
    FOR EACH ROW EXECUTE FUNCTION audit_log_immutable();

-- ---------------------------------------------------------------------------
-- Maintenance: mark hosts stale
--
-- A host that stops reporting must read as 'stale' and its applicability as
-- 'unknown', never as compliant. Run from the scheduler.
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION mark_stale_hosts(staleness_hours INTEGER DEFAULT 24)
RETURNS INTEGER AS $$
DECLARE
    n INTEGER;
BEGIN
    UPDATE hosts
       SET status = 'stale', updated_at = now()
     WHERE status = 'active'
       AND (last_checkin IS NULL
            OR last_checkin < now() - make_interval(hours => staleness_hours));
    GET DIAGNOSTICS n = ROW_COUNT;

    -- Existing verdicts for stale hosts can no longer be trusted
    UPDATE host_applicability ha
       SET state = 'unknown',
           reason = 'host inventory is stale',
           computed_at = now()
     WHERE ha.state <> 'unknown'
       AND ha.host_id IN (SELECT id FROM hosts WHERE status = 'stale');

    RETURN n;
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------------
-- Reporting views
-- ---------------------------------------------------------------------------

CREATE OR REPLACE VIEW v_fleet_summary AS
SELECT
    os_id,
    os_major,
    status,
    count(*)                                        AS hosts,
    count(*) FILTER (WHERE reboot_required)         AS awaiting_reboot,
    min(last_checkin)                               AS oldest_checkin,
    max(last_checkin)                               AS newest_checkin
FROM hosts
WHERE status <> 'decommissioned'
GROUP BY os_id, os_major, status
ORDER BY os_id, os_major;

-- Only fixed_active counts as remediated. Everything else needs action or
-- investigation, which is the point of separating the states.
CREATE OR REPLACE VIEW v_compliance AS
SELECT
    h.id                AS host_id,
    h.hostname,
    h.os_id,
    h.os_major,
    h.status            AS host_status,
    h.last_checkin,
    count(ha.advisory_id) FILTER (WHERE ha.state = 'affected')             AS affected,
    count(ha.advisory_id) FILTER (WHERE ha.state = 'fixed_pending_reboot') AS pending_reboot,
    count(ha.advisory_id) FILTER (WHERE ha.state = 'fixed_active')         AS remediated,
    count(ha.advisory_id) FILTER (WHERE ha.state = 'unknown')              AS unknown,
    count(ha.advisory_id) FILTER (WHERE ha.state = 'affected'
                                    AND ha.fix_available = 'not_mirrored') AS blocked_not_mirrored
FROM hosts h
LEFT JOIN host_applicability ha ON ha.host_id = h.id
WHERE h.status <> 'decommissioned'
GROUP BY h.id, h.hostname, h.os_id, h.os_major, h.status, h.last_checkin;

-- Advisories we are expected to fix but do not hold. This is an
-- infrastructure fault, not a host status, and belongs in alerting.
CREATE OR REPLACE VIEW v_not_mirrored AS
SELECT
    ha.advisory_id,
    a.severity,
    a.os_id,
    a.os_major,
    count(DISTINCT ha.host_id) AS hosts_affected,
    min(a.issued_at)           AS issued_at
FROM host_applicability ha
JOIN advisories a ON a.id = ha.advisory_id
WHERE ha.state = 'affected'
  AND ha.fix_available = 'not_mirrored'
GROUP BY ha.advisory_id, a.severity, a.os_id, a.os_major
ORDER BY min(a.issued_at);

-- ---------------------------------------------------------------------------
-- Schema version
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS schema_version (
    version     INTEGER PRIMARY KEY,
    applied_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    description TEXT
);

INSERT INTO schema_version (version, description)
VALUES (1, 'hosts, inventory, advisories, applicability, audit')
ON CONFLICT (version) DO NOTHING;
