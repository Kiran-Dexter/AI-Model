-- ===========================================================================
-- PATCH-01 : schema 003 - agent status and uptime
--
-- Applied after 002. Idempotent.
--
-- Uptime is stored as the BOOT TIME the agent reports, not as a number of
-- seconds. A boot time stays correct between check-ins; an uptime figure is
-- stale the moment it is written.
--
-- Online and offline are computed at query time from last_checkin, never
-- stored, so they cannot drift out of date:
--
--   online         checked in within the online window (15 minutes by
--                  default: about three missed 5-minute check-ins)
--   offline        beyond that, but still inside the 24-hour staleness window
--   not_reporting  status 'stale': verdicts are marked unknown
--   no_data        enrolled but never checked in
-- ===========================================================================

ALTER TABLE hosts ADD COLUMN IF NOT EXISTS boot_time TIMESTAMPTZ;
ALTER TABLE hosts ADD COLUMN IF NOT EXISTS agent_ip  INET;

CREATE OR REPLACE FUNCTION agent_state(last_checkin TIMESTAMPTZ,
                                       status host_status,
                                       online_minutes INTEGER DEFAULT 15)
RETURNS TEXT AS $$
    SELECT CASE
        WHEN status = 'decommissioned' THEN 'retired'
        WHEN last_checkin IS NULL      THEN 'no_data'
        WHEN status = 'stale'          THEN 'not_reporting'
        WHEN last_checkin > now() - make_interval(mins => online_minutes) THEN 'online'
        ELSE 'offline'
    END
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE VIEW v_agents AS
SELECT
    h.id                                        AS host_id,
    h.hostname,
    h.fqdn,
    h.os_id,
    h.os_version,
    h.host_group,
    h.agent_version,
    h.agent_ip,
    h.status                                    AS host_status,
    agent_state(h.last_checkin, h.status)       AS agent_state,
    h.last_checkin,
    h.last_inventory,
    h.boot_time,
    CASE WHEN h.boot_time IS NOT NULL
         THEN extract(epoch FROM (now() - h.boot_time))::bigint END AS uptime_seconds,
    h.reboot_required,
    h.enrolled_at
FROM hosts h
WHERE h.status <> 'decommissioned';

INSERT INTO schema_version (version, description)
VALUES (3, 'agent status: boot time, agent address, online state')
ON CONFLICT (version) DO NOTHING;
