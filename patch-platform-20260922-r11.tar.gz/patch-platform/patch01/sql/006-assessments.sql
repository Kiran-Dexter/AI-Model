-- ===========================================================================
-- PATCH-01 : schema 006 - CVE assessments
--
-- Applied after 005. Idempotent.
--
-- An assessment answers "which of our servers are affected by this list of
-- CVEs?", for a list that arrived from outside: a SOC bulletin, an auditor,
-- a vendor notice. Each one is kept so the answer can be revisited and
-- exported, which is also the record that the question was asked and
-- answered on a given date.
--
-- Statuses are per CVE across the fleet:
--
--   affected        at least one server needs the fix
--   pending_reboot  the fix is installed everywhere but a reboot is due
--   patched         every server that has the package is fixed and running
--   unknown         only servers whose inventory is stale are involved
--   not_applicable  we hold an advisory for it, but no server has the package
--   no_vendor_data  no advisory in our mirrors mentions this CVE, so it
--                   cannot be judged from package versions alone
-- ===========================================================================

CREATE TABLE IF NOT EXISTS cve_assessments (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name          TEXT NOT NULL,
    source        TEXT,                    -- SOC bulletin, audit request, ...
    note          TEXT,
    created_by    TEXT NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    evaluated_at  TIMESTAMPTZ,
    cve_count     INTEGER NOT NULL DEFAULT 0,
    -- CVE-shaped strings that were in the input but are not valid CVE ids
    rejected      TEXT[] NOT NULL DEFAULT '{}',
    hosts_in_scope INTEGER
);

CREATE INDEX IF NOT EXISTS idx_assess_created ON cve_assessments (created_at DESC);

CREATE TABLE IF NOT EXISTS cve_assessment_items (
    assessment_id   UUID NOT NULL REFERENCES cve_assessments(id) ON DELETE CASCADE,
    cve_id          TEXT NOT NULL,
    status          TEXT NOT NULL,
    affected        INTEGER NOT NULL DEFAULT 0,
    pending_reboot  INTEGER NOT NULL DEFAULT 0,
    patched         INTEGER NOT NULL DEFAULT 0,
    unknown         INTEGER NOT NULL DEFAULT 0,
    advisories      TEXT[] NOT NULL DEFAULT '{}',
    packages        TEXT[] NOT NULL DEFAULT '{}',
    -- The servers needing action, so the result stands on its own later even
    -- if the fleet has changed since
    affected_hosts  JSONB NOT NULL DEFAULT '[]'::jsonb,
    cvss_score      NUMERIC(3,1),
    kev             BOOLEAN NOT NULL DEFAULT FALSE,
    attack_class    TEXT,
    PRIMARY KEY (assessment_id, cve_id)
);

CREATE INDEX IF NOT EXISTS idx_assess_item_status ON cve_assessment_items (assessment_id, status);

INSERT INTO schema_version (version, description)
VALUES (6, 'CVE assessments from external lists')
ON CONFLICT (version) DO NOTHING;
