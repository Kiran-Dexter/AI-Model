-- ===========================================================================
-- PATCH-01 : schema 004 - VMware vCenter inventory
--
-- Applied after 003. Idempotent.
--
-- Servers are matched to VMs by hardware UUID, which VMware sets as the VM's
-- BIOS UUID and the guest reads from /sys/class/dmi/id/product_uuid. Unlike a
-- hostname or IP address it does not drift. Hostname and IP are used only as
-- fallbacks, and match_method records which one made the link so a weak
-- match can be spotted.
--
-- Part 1 is read-only: this schema describes VMs and their snapshots. Nothing
-- here creates or removes a snapshot; that arrives with patch jobs.
-- ===========================================================================

ALTER TABLE hosts ADD COLUMN IF NOT EXISTS hardware_uuid TEXT;
CREATE INDEX IF NOT EXISTS idx_hosts_hwuuid ON hosts (hardware_uuid);

CREATE TABLE IF NOT EXISTS vcenters (
    name          TEXT PRIMARY KEY,
    host          TEXT NOT NULL,
    version       TEXT,
    last_sync_at  TIMESTAMPTZ,
    last_ok       BOOLEAN,
    last_error    TEXT,
    vm_count      INTEGER,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS vm_inventory (
    vcenter              TEXT NOT NULL REFERENCES vcenters(name) ON DELETE CASCADE,
    moref                TEXT NOT NULL,         -- vCenter's own id, e.g. vm-1234
    name                 TEXT,
    bios_uuid            TEXT,                  -- config.uuid, normalised
    instance_uuid        TEXT,
    power_state          TEXT,                  -- poweredOn, poweredOff, suspended
    guest_os             TEXT,
    guest_family         TEXT,                  -- linuxGuest, windowsGuest, ...
    is_linux             BOOLEAN NOT NULL DEFAULT FALSE,
    guest_hostname       TEXT,
    guest_ips            TEXT[] DEFAULT '{}',
    tools_running        TEXT,
    tools_version_status TEXT,
    esxi_host            TEXT,
    cluster              TEXT,
    datacenter           TEXT,
    num_cpu              INTEGER,
    memory_mb            INTEGER,
    snapshot_count       INTEGER NOT NULL DEFAULT 0,
    oldest_snapshot_at   TIMESTAMPTZ,
    snapshots            JSONB NOT NULL DEFAULT '[]'::jsonb,
    host_id              UUID REFERENCES hosts(id) ON DELETE SET NULL,
    match_method         TEXT,                  -- hardware_uuid, hostname, ip, ambiguous
    synced_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (vcenter, moref)
);

CREATE INDEX IF NOT EXISTS idx_vm_bios    ON vm_inventory (bios_uuid);
CREATE INDEX IF NOT EXISTS idx_vm_host    ON vm_inventory (host_id);
CREATE INDEX IF NOT EXISTS idx_vm_guestnm ON vm_inventory (guest_hostname);
CREATE INDEX IF NOT EXISTS idx_vm_snap    ON vm_inventory (oldest_snapshot_at)
    WHERE snapshot_count > 0;

CREATE TABLE IF NOT EXISTS vcenter_syncs (
    id           BIGSERIAL PRIMARY KEY,
    vcenter      TEXT NOT NULL,
    started_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at  TIMESTAMPTZ,
    ok           BOOLEAN,
    vms          INTEGER,
    linux_vms    INTEGER,
    matched      INTEGER,
    duration_ms  INTEGER,
    error        TEXT
);

CREATE INDEX IF NOT EXISTS idx_vcsync_time ON vcenter_syncs (vcenter, started_at DESC);

-- Linux VMs that are running but have no agent: servers the platform cannot
-- see, and therefore cannot patch or report on.
CREATE OR REPLACE VIEW v_vm_unmanaged AS
SELECT vcenter, moref, name, guest_os, guest_hostname, guest_ips,
       power_state, esxi_host, cluster, datacenter, tools_running
  FROM vm_inventory
 WHERE is_linux AND host_id IS NULL AND power_state = 'poweredOn';

INSERT INTO schema_version (version, description)
VALUES (4, 'vCenter inventory, VM snapshots, server-to-VM matching')
ON CONFLICT (version) DO NOTHING;
