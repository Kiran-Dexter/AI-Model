-- ===========================================================================
-- PATCH-01 : schema 008 - fix v_vm_map
--
-- Applied after 007. Idempotent.
--
-- The map endpoint asks this view for esxi_moref, which groups VMs under
-- their ESXi host, but the view did not expose it. The VMware page returned
-- HTTP 500 as a result: "column esxi_moref does not exist".
--
-- The view is dropped and recreated rather than replaced, because CREATE OR
-- REPLACE VIEW cannot insert a column in the middle of the column list.
-- Nothing depends on this view, so dropping it is safe.
--
-- While recreating it, the remaining per-VM detail the map and the server
-- pages use is included, so the same gap does not recur.
-- ===========================================================================

DROP VIEW IF EXISTS v_vm_map;

CREATE VIEW v_vm_map AS
SELECT
    v.vcenter,
    v.datacenter,
    v.cluster,
    v.esxi_host,
    v.esxi_moref,
    v.moref,
    v.name                AS vm,
    v.power_state,
    v.guest_os,
    v.is_linux,
    v.num_cpu,
    v.memory_mb,
    v.tools_running,
    v.tools_version,
    v.hardware_version,
    v.folder_path,
    v.snapshot_count,
    v.oldest_snapshot_at,
    v.datastore_names,
    v.network_names,
    v.disks,
    v.storage_committed_mb,
    v.storage_provisioned_mb,
    v.cpu_usage_mhz,
    v.memory_usage_mb,
    v.boot_time            AS vm_boot_time,
    v.annotation,
    v.host_id,
    h.hostname             AS server,
    agent_state(h.last_checkin, h.status) AS agent_state,
    (SELECT count(*) FROM host_applicability ha
      WHERE ha.host_id = v.host_id AND ha.state = 'affected')             AS needs_patch,
    (SELECT count(*) FROM host_applicability ha
      WHERE ha.host_id = v.host_id AND ha.state = 'fixed_pending_reboot') AS needs_reboot
FROM vm_inventory v
LEFT JOIN hosts h ON h.id = v.host_id;

INSERT INTO schema_version (version, description)
VALUES (8, 'fix v_vm_map: expose esxi_moref and the remaining VM detail')
ON CONFLICT (version) DO NOTHING;
