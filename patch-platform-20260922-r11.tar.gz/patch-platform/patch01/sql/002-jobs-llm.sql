-- ===========================================================================
-- PATCH-01 : schema 002 - jobs, scheduling, promotion, LLM cache
--
-- Applied after 001-schema.sql. Idempotent.
--
-- Design notes that matter later:
--
--   * job_targets carries per-host state, and job_events records every
--     stage transition. Evidence is written AS the job progresses, not once
--     at the end, so an aborted or timed-out job still leaves a record of
--     exactly how far it got.
--
--   * The agent instruction set is a bounded verb enum, never a shell
--     string. A compromised PATCH-01 can then only tell agents to install
--     signed packages from a signed repository, which is a far smaller
--     blast radius than arbitrary command execution as root on 200 hosts.
--
--   * Job creation and job approval are separate columns with separate
--     actors, because this system's output is compliance evidence and the
--     person who runs a change should not be the only person who authorised
--     it.
--
--   * content_snapshots records the Pulp publication href per repository.
--     Test and production environments point at a SNAPSHOT, not at "latest",
--     which is what makes "we tested this patch set" a true statement.
--
--   * llm_explanations is keyed on the CONTENT of a verdict, not on the
--     host. The explanation for a given advisory against a given OS version
--     and package version is identical across every affected host, so 200
--     hosts x 50 advisories is a few hundred distinct generations rather
--     than ten thousand. That is what makes CPU inference viable.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Enumerated types
-- ---------------------------------------------------------------------------

DO $$ BEGIN
    CREATE TYPE job_type AS ENUM (
        'full',            -- everything available
        'security_only',   -- security advisories only
        'minimal',         -- minimal/security errata (dnf update --security --bugfix=no)
        'specific_cve',    -- named CVEs
        'specific_pkgs',   -- named packages
        'reboot_only'      -- no package change, coordinate a pending reboot
    );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE job_state AS ENUM (
        'draft',           -- being composed
        'pending_approval',
        'approved',
        'scheduled',       -- waiting for its window
        'running',
        'completed',       -- every target reached a terminal state
        'completed_with_errors',
        'failed',
        'cancelled'
    );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    -- Per host within a job. Terminal states are the last five.
    CREATE TYPE target_state AS ENUM (
        'queued',
        'precheck',
        'downloading',
        'installing',
        'rebooting',
        'postcheck',
        'succeeded',
        'failed',
        'aborted',          -- pre-check refused; nothing was changed
        'rolled_back',
        'timed_out',        -- rebooted and never came back
        'skipped',          -- host offline or outside its window
        'cancelled'
    );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE job_stage AS ENUM (
        'queued', 'precheck', 'download', 'install',
        'reboot', 'postcheck', 'evidence', 'rollback'
    );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    -- The complete set of things an agent will accept. Deliberately closed:
    -- there is no verb that takes a shell command.
    CREATE TYPE agent_verb AS ENUM (
        'collect_inventory',   -- report OS, packages, kernel, reboot state
        'run_precheck',        -- named checks only: disk, locks, history
        'download_packages',   -- fetch a specific NEVRA list from Pulp
        'install_packages',    -- install a specific NEVRA list
        'reboot_host',
        'run_postcheck',
        'report_evidence',
        'cancel_job'
    );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE environment_tier AS ENUM ('dev', 'test', 'staging', 'prod');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ---------------------------------------------------------------------------
-- Host groups and maintenance windows
--
-- Reboot coordination lives here: max_concurrent stops a job taking down
-- both halves of a cluster at once.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS host_groups (
    name            TEXT PRIMARY KEY,
    description     TEXT,
    environment     environment_tier NOT NULL DEFAULT 'prod',
    -- Never patch more than this many members of the group at a time.
    max_concurrent  INTEGER NOT NULL DEFAULT 5 CHECK (max_concurrent >= 1),
    -- Lower numbers patch first, so test groups can precede production.
    patch_order     INTEGER NOT NULL DEFAULT 100,
    reboot_allowed  BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO host_groups (name, description, environment, max_concurrent, patch_order)
VALUES
    ('default', 'Ungrouped hosts',        'prod', 5,  100),
    ('test',    'Validation hosts',       'test', 10, 10),
    ('prod',    'Production hosts',       'prod', 5,  100)
ON CONFLICT (name) DO NOTHING;

CREATE TABLE IF NOT EXISTS maintenance_windows (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name         TEXT NOT NULL,
    host_group   TEXT REFERENCES host_groups(name) ON DELETE CASCADE,
    -- 0=Sunday .. 6=Saturday; NULL means any day
    day_of_week  INTEGER CHECK (day_of_week BETWEEN 0 AND 6),
    start_time   TIME NOT NULL,
    duration_min INTEGER NOT NULL CHECK (duration_min > 0),
    timezone     TEXT NOT NULL DEFAULT 'UTC',
    enabled      BOOLEAN NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_windows_group ON maintenance_windows (host_group, enabled);

-- ---------------------------------------------------------------------------
-- Content snapshots and promotion
--
-- A snapshot pins a Pulp publication per repository. An environment points
-- at a snapshot, so test and production receive byte-identical content
-- rather than whatever each happened to sync.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS content_snapshots (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name          TEXT NOT NULL UNIQUE,
    description   TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by    TEXT NOT NULL,
    -- Set once the snapshot has been validated on a test group
    validated_at  TIMESTAMPTZ,
    validated_by  TEXT,
    notes         TEXT
);

CREATE TABLE IF NOT EXISTS snapshot_repositories (
    snapshot_id       UUID NOT NULL REFERENCES content_snapshots(id) ON DELETE CASCADE,
    repo_name         TEXT NOT NULL,        -- matches config/repos.conf
    -- The immutable Pulp objects. publication_href is what promotion moves.
    publication_href  TEXT NOT NULL,
    repo_version      INTEGER,
    package_count     INTEGER,
    PRIMARY KEY (snapshot_id, repo_name)
);

CREATE TABLE IF NOT EXISTS environment_content (
    environment    environment_tier PRIMARY KEY,
    snapshot_id    UUID REFERENCES content_snapshots(id) ON DELETE SET NULL,
    promoted_at    TIMESTAMPTZ,
    promoted_by    TEXT
);

INSERT INTO environment_content (environment) VALUES ('test'), ('prod')
ON CONFLICT (environment) DO NOTHING;

-- ---------------------------------------------------------------------------
-- Repository sync state
--
-- Records each sync so "not mirrored" can be distinguished from "sync has
-- not run", and so a silently failing sync is visible.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS repo_syncs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    repo_name       TEXT NOT NULL,
    started_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at     TIMESTAMPTZ,
    ok              BOOLEAN,
    task_href       TEXT,
    packages_added  INTEGER,
    packages_total  INTEGER,
    bytes_downloaded BIGINT,
    error           TEXT
);

CREATE INDEX IF NOT EXISTS idx_syncs_repo ON repo_syncs (repo_name, started_at DESC);

-- ---------------------------------------------------------------------------
-- Patch jobs
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS patch_jobs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            TEXT NOT NULL,
    job_type        job_type NOT NULL,
    state           job_state NOT NULL DEFAULT 'draft',

    -- For specific_cve / specific_pkgs
    target_cves     TEXT[],
    target_packages TEXT[],

    -- Which content the job installs from. NULL means the environment's
    -- current snapshot at execution time.
    snapshot_id     UUID REFERENCES content_snapshots(id) ON DELETE SET NULL,

    -- Behaviour
    allow_reboot    BOOLEAN NOT NULL DEFAULT FALSE,
    max_concurrent  INTEGER NOT NULL DEFAULT 5 CHECK (max_concurrent >= 1),
    dry_run         BOOLEAN NOT NULL DEFAULT FALSE,
    -- A host that reboots and does not return is timed out, not hung
    reboot_timeout_min INTEGER NOT NULL DEFAULT 20,

    -- Scheduling
    scheduled_for   TIMESTAMPTZ,
    window_id       UUID REFERENCES maintenance_windows(id) ON DELETE SET NULL,

    -- Separation of duties: whoever creates a job is not automatically
    -- whoever authorises it.
    created_by      TEXT NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    approved_by     TEXT,
    approved_at     TIMESTAMPTZ,
    started_at      TIMESTAMPTZ,
    finished_at     TIMESTAMPTZ,

    notes           TEXT,

    CONSTRAINT approver_differs CHECK (approved_by IS NULL OR approved_by <> created_by)
);

CREATE INDEX IF NOT EXISTS idx_jobs_state     ON patch_jobs (state);
CREATE INDEX IF NOT EXISTS idx_jobs_scheduled ON patch_jobs (scheduled_for)
    WHERE state IN ('approved', 'scheduled');
CREATE INDEX IF NOT EXISTS idx_jobs_created   ON patch_jobs (created_at DESC);

-- Per-host state within a job
CREATE TABLE IF NOT EXISTS job_targets (
    job_id            UUID NOT NULL REFERENCES patch_jobs(id) ON DELETE CASCADE,
    host_id           UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    state             target_state NOT NULL DEFAULT 'queued',
    current_stage     job_stage NOT NULL DEFAULT 'queued',

    -- Snapshot of the host as the job began, so evidence is self-contained
    kernel_before     TEXT,
    kernel_after      TEXT,
    packages_planned  INTEGER,
    packages_changed  INTEGER,

    -- Reboot tracking. reboot_requested_at plus reboot_timeout_min is how a
    -- host that never returns becomes timed_out rather than hanging.
    reboot_required   BOOLEAN DEFAULT FALSE,
    reboot_requested_at TIMESTAMPTZ,
    returned_at       TIMESTAMPTZ,

    started_at        TIMESTAMPTZ,
    finished_at       TIMESTAMPTZ,
    error             TEXT,
    PRIMARY KEY (job_id, host_id)
);

CREATE INDEX IF NOT EXISTS idx_targets_state ON job_targets (state);
CREATE INDEX IF NOT EXISTS idx_targets_host  ON job_targets (host_id);
CREATE INDEX IF NOT EXISTS idx_targets_job   ON job_targets (job_id, state);

-- The exact packages a job intends to change on a host, resolved before
-- execution. The agent receives this list, never a wildcard or a command.
CREATE TABLE IF NOT EXISTS job_target_packages (
    job_id       UUID NOT NULL REFERENCES patch_jobs(id) ON DELETE CASCADE,
    host_id      UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    name         TEXT NOT NULL,
    arch         TEXT NOT NULL DEFAULT 'x86_64',
    from_epoch   INTEGER,
    from_version TEXT,
    from_release TEXT,
    to_epoch     INTEGER NOT NULL DEFAULT 0,
    to_version   TEXT NOT NULL,
    to_release   TEXT NOT NULL DEFAULT '',
    advisory_id  TEXT REFERENCES advisories(id) ON DELETE SET NULL,
    applied      BOOLEAN,
    PRIMARY KEY (job_id, host_id, name, arch)
);

CREATE INDEX IF NOT EXISTS idx_jtp_job ON job_target_packages (job_id, host_id);

-- ---------------------------------------------------------------------------
-- Job events: the evidence trail
--
-- Append-only, written as the job progresses. Same immutability rule as
-- audit_log, for the same reason.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS job_events (
    id           BIGSERIAL PRIMARY KEY,
    job_id       UUID NOT NULL REFERENCES patch_jobs(id) ON DELETE CASCADE,
    host_id      UUID REFERENCES hosts(id) ON DELETE SET NULL,
    occurred_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    stage        job_stage NOT NULL,
    state        target_state,
    ok           BOOLEAN,
    message      TEXT,
    -- Command output, package lists, check results. Bounded by the API.
    detail       JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_jevents_job  ON job_events (job_id, occurred_at);
CREATE INDEX IF NOT EXISTS idx_jevents_host ON job_events (host_id, occurred_at DESC);

CREATE OR REPLACE FUNCTION job_events_immutable() RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'job_events is append-only; % is not permitted', TG_OP;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_jevents_no_update ON job_events;
CREATE TRIGGER trg_jevents_no_update
    BEFORE UPDATE OR DELETE ON job_events
    FOR EACH ROW EXECUTE FUNCTION job_events_immutable();

-- ---------------------------------------------------------------------------
-- Agent command queue
--
-- Agents poll for work. Each row is one bounded verb plus its parameters;
-- there is no free-text command field by design.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS agent_commands (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    host_id      UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    job_id       UUID REFERENCES patch_jobs(id) ON DELETE CASCADE,
    verb         agent_verb NOT NULL,
    params       JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    -- Claimed by the agent on poll; prevents two agents taking one command
    claimed_at   TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    ok           BOOLEAN,
    result       JSONB,
    expires_at   TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '4 hours')
);

CREATE INDEX IF NOT EXISTS idx_cmds_pending ON agent_commands (host_id, created_at)
    WHERE claimed_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_cmds_job     ON agent_commands (job_id);

-- ---------------------------------------------------------------------------
-- LLM explanations
--
-- Keyed on the content of a verdict, not on a host. Identical inputs across
-- many hosts reuse one generation, which is what makes CPU inference on
-- AI-01 practical.
--
-- Strictly advisory. Nothing in this table may select packages, gate an
-- approval or trigger a job. The prompt_hash exists so a cached answer can
-- be invalidated when the prompt template changes.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS llm_explanations (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    -- sha256 of (kind + advisory + os + installed_evr + fixed_evr + prompt)
    cache_key     TEXT NOT NULL UNIQUE,
    kind          TEXT NOT NULL,       -- risk_summary, why_affected, failure_analysis, remediation
    advisory_id   TEXT REFERENCES advisories(id) ON DELETE CASCADE,
    os_id         TEXT,
    os_major      INTEGER,
    installed_evr TEXT,
    fixed_evr     TEXT,
    prompt_hash   TEXT NOT NULL,
    model         TEXT NOT NULL,
    output        TEXT NOT NULL,
    tokens_out    INTEGER,
    duration_ms   INTEGER,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    hit_count     INTEGER NOT NULL DEFAULT 0,
    last_used_at  TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_llm_key      ON llm_explanations (cache_key);
CREATE INDEX IF NOT EXISTS idx_llm_advisory ON llm_explanations (advisory_id, kind);

-- Request log, for cost and latency visibility and to prove the model was
-- only ever asked to explain, never to decide.
CREATE TABLE IF NOT EXISTS llm_requests (
    id           BIGSERIAL PRIMARY KEY,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    kind         TEXT NOT NULL,
    cache_hit    BOOLEAN NOT NULL,
    model        TEXT,
    duration_ms  INTEGER,
    tokens_in    INTEGER,
    tokens_out   INTEGER,
    ok           BOOLEAN NOT NULL DEFAULT TRUE,
    error        TEXT,
    requested_by TEXT
);

CREATE INDEX IF NOT EXISTS idx_llmreq_time ON llm_requests (requested_at DESC);

-- ---------------------------------------------------------------------------
-- Scheduler support
-- ---------------------------------------------------------------------------

-- Jobs that are due: approved, in the past, not yet started.
CREATE OR REPLACE VIEW v_due_jobs AS
SELECT
    j.id,
    j.name,
    j.job_type,
    j.state,
    j.scheduled_for,
    j.max_concurrent,
    j.allow_reboot,
    count(t.host_id)                                        AS targets,
    count(t.host_id) FILTER (WHERE t.state = 'queued')      AS queued,
    count(t.host_id) FILTER (WHERE t.state NOT IN
        ('queued','succeeded','failed','aborted','rolled_back',
         'timed_out','skipped','cancelled'))                AS in_flight
FROM patch_jobs j
LEFT JOIN job_targets t ON t.job_id = j.id
WHERE j.state IN ('approved', 'scheduled', 'running')
  AND (j.scheduled_for IS NULL OR j.scheduled_for <= now())
GROUP BY j.id, j.name, j.job_type, j.state, j.scheduled_for,
         j.max_concurrent, j.allow_reboot
ORDER BY j.scheduled_for NULLS FIRST;

-- Hosts that rebooted and never came back. Needs an alert, not a hung job.
CREATE OR REPLACE VIEW v_reboot_timeouts AS
SELECT
    t.job_id,
    t.host_id,
    h.hostname,
    t.reboot_requested_at,
    j.reboot_timeout_min,
    now() - t.reboot_requested_at AS waiting_for
FROM job_targets t
JOIN patch_jobs j ON j.id = t.job_id
JOIN hosts h      ON h.id = t.host_id
WHERE t.state = 'rebooting'
  AND t.reboot_requested_at IS NOT NULL
  AND t.reboot_requested_at < now() - make_interval(mins => j.reboot_timeout_min);

-- Job progress at a glance
CREATE OR REPLACE VIEW v_job_progress AS
SELECT
    j.id,
    j.name,
    j.job_type,
    j.state,
    j.created_by,
    j.approved_by,
    j.started_at,
    j.finished_at,
    count(t.host_id)                                          AS total,
    count(t.host_id) FILTER (WHERE t.state = 'succeeded')      AS succeeded,
    count(t.host_id) FILTER (WHERE t.state = 'failed')         AS failed,
    count(t.host_id) FILTER (WHERE t.state = 'aborted')        AS aborted,
    count(t.host_id) FILTER (WHERE t.state = 'rolled_back')    AS rolled_back,
    count(t.host_id) FILTER (WHERE t.state = 'timed_out')      AS timed_out,
    count(t.host_id) FILTER (WHERE t.state = 'skipped')        AS skipped
FROM patch_jobs j
LEFT JOIN job_targets t ON t.job_id = j.id
GROUP BY j.id, j.name, j.job_type, j.state, j.created_by,
         j.approved_by, j.started_at, j.finished_at;

-- ---------------------------------------------------------------------------
-- Compliance export
--
-- Generated from the append-only trail rather than live tables, so the same
-- question asked months later gives the same answer.
-- ---------------------------------------------------------------------------

CREATE OR REPLACE VIEW v_compliance_export AS
SELECT
    h.hostname,
    h.fqdn,
    h.os_id,
    h.os_version,
    h.status                        AS host_status,
    h.last_checkin,
    h.reboot_required,
    ha.advisory_id,
    a.severity,
    a.issued_at                     AS advisory_issued,
    ac.cve_id,
    ha.state                        AS applicability_state,
    ha.fix_available,
    ha.package_name,
    ha.installed_evr,
    ha.fixed_evr,
    ha.computed_at,
    -- Only fixed_active is remediated. Pending reboot is not.
    (ha.state = 'fixed_active')     AS is_remediated
FROM hosts h
JOIN host_applicability ha ON ha.host_id = h.id
JOIN advisories a          ON a.id = ha.advisory_id
LEFT JOIN advisory_cves ac ON ac.advisory_id = a.id
WHERE h.status <> 'decommissioned';

-- ---------------------------------------------------------------------------
-- Schema version
-- ---------------------------------------------------------------------------

INSERT INTO schema_version (version, description)
VALUES (2, 'jobs, scheduling, snapshots, agent commands, LLM cache')
ON CONFLICT (version) DO NOTHING;
