/* Applies the saved theme before the page paints, so there is no flash of
 * the wrong theme. Loaded without defer, ahead of the stylesheet. A separate
 * file rather than inline because the content security policy forbids
 * inline scripts.
 */
(function () {
  "use strict";
  var KEY = "patch01.theme";
  var DEFAULT = "hacker";
  var VALID = { system: 1, light: 1, dark: 1, hacker: 1 };

  function pref() {
    try {
      var v = localStorage.getItem(KEY);
      return VALID[v] ? v : DEFAULT;
    } catch (e) { return DEFAULT; }
  }

  function prefersDark() {
    return !!(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
  }

  function resolve(t) {
    return t === "system" ? (prefersDark() ? "dark" : "light") : t;
  }

  function apply(t) {
    var root = document.documentElement;
    root.setAttribute("data-theme", resolve(t));
    root.setAttribute("data-theme-pref", t);
  }

  apply(pref());

  window.PatchTheme = {
    get: pref,
    set: function (t) {
      if (!VALID[t]) return;
      try { localStorage.setItem(KEY, t); } catch (e) { /* private mode */ }
      apply(t);
    },
    options: [
      ["system", "System"],
      ["light", "Light"],
      ["dark", "Dark"],
      ["hacker", "Hacker"],
    ],
  };

  if (window.matchMedia) {
    var mq = window.matchMedia("(prefers-color-scheme: dark)");
    var onChange = function () { if (pref() === "system") apply("system"); };
    if (mq.addEventListener) mq.addEventListener("change", onChange);
    else if (mq.addListener) mq.addListener(onChange);
  }
})();
