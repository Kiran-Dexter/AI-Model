PATCH-01 agent for Linux (agent 1.8.0)
======================================

On each server, as root, from this folder:

    sudo ./setup-agent.sh

It asks for PATCH-01's address (an upgrade offers the one the agent already
uses), finds any existing agent and upgrades it (keeping its identity, no
token), or installs and enrols a new one (it asks for a token). It checks DNS
and the port, then works out how to trust PATCH-01's certificate: the agent's
current CA, the server's own trust store, or your CA chain file (PEM: the ROOT
CA, or root + intermediate in one file; an intermediate alone is not enough).
Nothing is installed until that check passes. It ends with a check-in.

New in 1.8.0: updated from PATCH-01 (Servers > Update agents). The agent
checks the new file's SHA-256, compiles and test-runs it, keeps itself as
/usr/local/bin/patch-agent.prev and swaps; if the new one does not answer
PATCH-01's check in time, the previous version puts itself back (systemd
timer patch-agent-update-check, which also survives a restart). Only for
agents that verify PATCH-01's certificate (installed with the CA). This is
the last version you install by hand.

New in 1.7.0: the agent sends its log lines to PATCH-01 (see ">_ Log" in the
console), and retries sending a result.

Unattended:  sudo ./setup-agent.sh --server https://<patch01 name> --ca corp-chain.pem --token <token> --yes
Many servers at once, over SSH:  ./push-linux.sh --help
