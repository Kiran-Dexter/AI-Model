/* PATCH-01 console
 *
 * No framework and no build step: this is served on an air-gapped network.
 *
 * Every value from the API is inserted as text, never as HTML. Advisory
 * titles come from vendor feeds and hostnames from agents, so none of it is
 * trusted. The h() helper below only ever uses textContent.
 */
"use strict";

/* ---- state labels, in the words an operator uses ------------------------ */

const STATES = {
  affected:             { label: "Needs patch",    desc: "Installed version is older than the fix" },
  fixed_pending_reboot: { label: "Needs reboot",   desc: "Fix installed, old version still running" },
  fixed_active:         { label: "Patched",        desc: "Fix installed and running" },
  unknown:              { label: "No recent data", desc: "Host has not reported in 24 hours" },
};
const STATE_ORDER = ["affected", "fixed_pending_reboot", "fixed_active", "unknown"];

const HOST_STATUS = {
  active: "Reporting",
  stale: "Silent",
  pending: "Enrolled, no data yet",
  decommissioned: "Retired",
};

/* ---- DOM helper: text only, never innerHTML ----------------------------- */

function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v === null || v === undefined || v === false) continue;
      if (k === "class") el.className = v;
      else if (k === "on") for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
      else if (k === "style") for (const [p, val] of Object.entries(v)) el.style.setProperty(p, val);
      else el.setAttribute(k, v === true ? "" : String(v));
    }
  }
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}

/* ---- formatting --------------------------------------------------------- */

function timeAgo(iso) {
  if (!iso) return "never";
  const t = new Date(iso).getTime();
  if (isNaN(t)) return "unknown";
  const s = Math.round((Date.now() - t) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return Math.round(s / 60) + " min ago";
  if (s < 86400) return Math.round(s / 3600) + " h ago";
  return Math.round(s / 86400) + " days ago";
}

function fmtDateTime(iso) {
  if (!iso) return "never";
  const d = new Date(iso);
  if (isNaN(d)) return String(iso);
  return d.toLocaleString(undefined, {
    year: "numeric", month: "short", day: "numeric",
    hour: "2-digit", minute: "2-digit",
  });
}

function fmtDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d)) return String(iso);
  return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function osLabel(osId, ver) {
  const names = { rhel: "RHEL", ol: "Oracle Linux", ubuntu: "Ubuntu" };
  return (names[osId] || osId || "") + (ver ? " " + ver : "");
}

function count(n, state) {
  const v = Number(n) || 0;
  return h("span", { class: "count " + (v === 0 ? "zero" : "st-" + state) }, v);
}

/* A host that has stopped reporting has no trustworthy counts. Showing 0
   would read as "clean", which is the exact failure the unknown state
   exists to prevent. */
function hostCount(r, field, state) {
  if (r.host_status === "stale") return h("span", { class: "count unknown-val" }, "unknown");
  return count(r[field], state);
}

function stateMark(state) {
  const s = STATES[state] || { label: state };
  return h("span", { class: "state st-" + state }, s.label);
}

function sevLabel(sev) {
  if (!sev) return h("span", { class: "muted" }, "unrated");
  return h("span", { class: "sev sev-" + sev }, sev.charAt(0).toUpperCase() + sev.slice(1));
}

/* ---- auth --------------------------------------------------------------- */

const AUTH_KEY = "patch01.auth";

function getAuth() {
  try { return JSON.parse(sessionStorage.getItem(AUTH_KEY)); } catch (e) { return null; }
}
function setAuth(user, pass) {
  sessionStorage.setItem(AUTH_KEY, JSON.stringify({ user, token: btoa(user + ":" + pass) }));
}
function clearAuth() { sessionStorage.removeItem(AUTH_KEY); }

class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

async function api(path) {
  const auth = getAuth();
  const res = await fetch("/api/v1" + path, {
    headers: {
      "Accept": "application/json",
      "X-Requested-With": "patch01-dashboard",
      ...(auth ? { "Authorization": "Basic " + auth.token } : {}),
    },
    cache: "no-store",
  });
  if (res.status === 401) {
    clearAuth();
    throw new ApiError(401, "Your session has ended. Sign in again.");
  }
  if (!res.ok) {
    let detail = "";
    try { detail = (await res.json()).detail || ""; } catch (e) { /* not JSON */ }
    throw new ApiError(res.status, detail || res.statusText);
  }
  return res.json();
}

async function apiPost(path, body) {
  const auth = getAuth();
  const res = await fetch("/api/v1" + path, {
    method: "POST",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "X-Requested-With": "patch01-dashboard",
      ...(auth ? { "Authorization": "Basic " + auth.token } : {}),
    },
    body: JSON.stringify(body || {}),
    cache: "no-store",
  });
  if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
  if (!res.ok) {
    let detail = "";
    try { detail = (await res.json()).detail || ""; } catch (e) { /* not JSON */ }
    throw new ApiError(res.status, detail || res.statusText);
  }
  return res.json();
}

/* ---- explanations from AI-01 --------------------------------------------- */

const EXPLAINABLE = new Set(["affected", "fixed_pending_reboot"]);

function explainError(err) {
  if (err.status === 429) return "AI-01 is busy with another explanation. Try again in a moment.";
  if (err.status === 503) return "AI-01 is not available: " + (err.message || "not configured or unreachable") + ".";
  if (err.status === 404) return "This verdict no longer exists. Refresh the page.";
  return "Could not get an explanation (HTTP " + (err.status || "error") + ").";
}

async function toggleExplain(btn, hostId, advisoryId, colspan) {
  const tr = btn.closest("tr");
  const next = tr.nextElementSibling;
  if (next && next.classList.contains("explain-row")) {
    next.remove();
    btn.setAttribute("aria-expanded", "false");
    btn.textContent = "Explain";
    return;
  }
  const body = h("div", { class: "explain", role: "status" },
    h("p", { class: "explain-wait" }, "Asking AI-01. On a CPU-only server this can take up to a minute."));
  const row = h("tr", { class: "explain-row" }, h("td", { colspan: String(colspan) }, body));
  tr.after(row);
  btn.setAttribute("aria-expanded", "true");
  btn.textContent = "Hide";
  btn.disabled = true;
  try {
    const r = await apiPost("/admin/hosts/" + encodeURIComponent(hostId) +
                            "/advisories/" + encodeURIComponent(advisoryId) + "/explain");
    const meta = r.cached
      ? "From cache"
      : "Generated in " + Math.round((r.duration_ms || 0) / 1000) + "s";
    body.replaceChildren(
      h("p", { class: "explain-note" },
        "AI explanation, advisory only. The verdict comes from the version check, not the model."),
      // Plain text only: the model's output is never treated as HTML
      h("p", { class: "explain-text" }, r.text),
      h("p", { class: "explain-meta" }, meta + (r.model ? ", " + r.model : "")),
    );
  } catch (err) {
    if (err.status === 401) return renderSignIn(err.message);
    body.replaceChildren(h("p", { class: "explain-error" }, explainError(err)));
  } finally {
    btn.disabled = false;
  }
}

/* ---- rendering scaffolding ---------------------------------------------- */

const view = () => document.getElementById("view");

function render(...nodes) {
  const v = view();
  // replaceChildren would turn null into the text "null"
  v.replaceChildren(...nodes.flat().filter(n => n !== null && n !== undefined && n !== false));
  v.focus({ preventScroll: true });
}

function showError(err) {
  if (err.status === 401) return renderSignIn(err.message);
  const hints = {
    502: ["The API container is not answering. Check it with ", h("code", null, "./scripts/phase3b-api.sh --check"), "."],
    503: ["The API is up but cannot reach the database. Check ", h("code", null, "./scripts/phase1b-data.sh --check"), "."],
    404: ["This endpoint does not exist. The API image may be older than the dashboard; rebuild it with ", h("code", null, "./scripts/phase3b-api.sh"), "."],
  };
  render(
    h("div", { class: "error", role: "alert" },
      h("h2", null, "Could not load this page"),
      h("p", null, "The API returned HTTP " + (err.status || "error") + (err.message ? ": " + err.message : ".")),
      hints[err.status] ? h("p", null, hints[err.status]) : null,
    )
  );
}

function setNav(name) {
  document.querySelectorAll("nav a").forEach(a => {
    if (a.dataset.nav === name) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
  });
}

function table(columns, rows, opts = {}) {
  const thead = h("thead", null, h("tr", null,
    columns.map(c => h("th", { class: c.num ? "num" : null, scope: "col" }, c.label))));
  const tbody = h("tbody", null, rows.map(r => {
    const tr = h("tr", { class: opts.onRow ? "clickable" : null },
      columns.map(c => h("td", { class: [c.num ? "num" : "", c.mono ? "mono" : "",
                                         c.nowrap ? "nowrap" : ""].join(" ").trim() || null },
        c.cell(r))));
    if (opts.onRow) {
      tr.addEventListener("click", e => {
        if (e.target.closest("a")) return;
        opts.onRow(r);
      });
    }
    return tr;
  }));
  return h("div", { class: "table-wrap" }, h("table", null, thead, tbody));
}

/* ---- theme picker ------------------------------------------------------- */

function fillThemeSelect(sel) {
  const T = window.PatchTheme;
  if (!T) return sel;
  sel.replaceChildren(...T.options.map(([v, label]) => h("option", { value: v }, label)));
  sel.value = T.get();
  sel.addEventListener("change", () => {
    T.set(sel.value);
    // keep any other picker on the page in step
    document.querySelectorAll("select[data-theme-select]").forEach(o => { o.value = sel.value; });
  });
  sel.setAttribute("data-theme-select", "");
  return sel;
}

function themePicker() {
  const sel = fillThemeSelect(h("select", { "aria-label": "Theme" }));
  return h("label", { class: "theme-pick" }, h("span", null, "Theme"), sel);
}

/* ---- sign in ------------------------------------------------------------ */

function renderSignIn(message) {
  document.getElementById("top").hidden = true;
  const err = message ? h("div", { class: "error", role: "alert" }, message) : null;
  const user = h("input", { type: "text", name: "user", autocomplete: "username", required: true, value: "admin" });
  const pass = h("input", { type: "password", name: "pass", autocomplete: "current-password", required: true });
  const btn = h("button", { type: "submit" }, "Sign in");

  const form = h("form", {
    class: "signin",
    on: {
      submit: async e => {
        e.preventDefault();
        btn.disabled = true;
        btn.textContent = "Signing in";
        setAuth(user.value.trim(), pass.value);
        try {
          await api("/admin/fleet-summary");
          start();
        } catch (ex) {
          clearAuth();
          renderSignIn(ex.status === 401
            ? "That username and password were not accepted."
            : "Could not reach the API (HTTP " + (ex.status || "error") + ").");
        }
      },
    },
  },
    themePicker(),
    h("h1", { "data-cmd": "patchctl login" }, "PATCH-01"),
    h("p", { class: "muted" }, "Patch and vulnerability status for your Linux fleet."),
    err,
    h("label", null, h("span", null, "Username"), user),
    h("label", null, h("span", null, "Password"), pass),
    btn,
    h("p", { class: "muted small" },
      "Use the admin password from ", h("code", null, "/patch/secrets/api.env"), " on PATCH-01."),
  );
  view().replaceChildren(form);
  pass.focus();
}

/* ---- overview ----------------------------------------------------------- */

async function renderOverview() {
  setNav("overview");
  const [fleet, app, comp] = await Promise.all([
    api("/admin/fleet-summary"),
    api("/admin/applicability/summary"),
    api("/admin/compliance"),
  ]);

  const t = fleet.totals || {};
  if (!t.hosts) {
    return render(
      h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl status" }, "Overview")),
      h("div", { class: "empty" },
        h("h2", null, "No servers have enrolled yet"),
        h("p", null, "Issue a token on PATCH-01 with ", h("code", null, "./scripts/phase3b-api.sh --token"),
          ", then run ", h("code", null, "install-agent.sh"), " on a server with that token."),
      )
    );
  }

  // The exposure strip
  const byState = {};
  (app.by_state || []).forEach(r => { byState[r.state] = r; });
  const total = STATE_ORDER.reduce((a, s) => a + (byState[s] ? Number(byState[s].n) : 0), 0);

  const segs = STATE_ORDER.map(s =>
    h("span", { class: "st-" + s + (byState[s] && Number(byState[s].n) ? " nonzero" : ""), title: STATES[s].label + ": " + (byState[s] ? byState[s].n : 0),
                style: { "flex-grow": "0" }, "data-grow": byState[s] ? byState[s].n : 0 }));
  const strip = h("div", { class: "strip", role: "img",
    "aria-label": STATE_ORDER.map(s => STATES[s].label + " " + (byState[s] ? byState[s].n : 0)).join(", ") },
    segs);

  const legend = h("div", { class: "legend" }, STATE_ORDER.map(s => {
    const r = byState[s];
    const hosts = r ? Number(r.hosts) : 0;
    return h("a", { class: "st-" + s, href: "#/advisories?state=" + s },
      h("span", { class: "n" }, r ? r.n : 0),
      h("span", { class: "l" }, STATES[s].label),
      h("span", { class: "d" }, hosts === 1 ? "on 1 server" : "on " + hosts + " servers"));
  }));

  const exposure = h("section", { class: "exposure", "aria-labelledby": "exp-h" },
    h("div", { class: "page-head" },
      h("h1", { id: "exp-h", "data-cmd": "patchctl exposure --fleet" }, "Fleet exposure"),
      h("span", { class: "muted small" },
        total ? "Checked " + timeAgo(app.computed_at) : "The CVE engine has not run yet")),
    total ? strip : h("div", { class: "empty" },
      h("p", null, "No verdicts yet. Run ", h("code", null, "./scripts/phase4-cve.sh"), " on PATCH-01.")),
    total ? legend : null,
  );

  // Grow the strip once, after it is in the document
  requestAnimationFrame(() => requestAnimationFrame(() => {
    segs.forEach(sg => { sg.style.flexGrow = sg.dataset.grow; });
  }));

  const attention = (comp.hosts || [])
    .filter(r => Number(r.affected) || Number(r.pending_reboot) || r.host_status === "stale")
    .slice(0, 10);

  const attnSection = h("section", null,
    h("h2", null, "Servers needing attention"),
    attention.length ? table([
      { label: "Server", cell: r => h("a", { href: "#/host/" + r.host_id }, r.hostname) },
      { label: "OS", cell: r => osLabel(r.os_id, r.os_version) },
      { label: "Needs patch", num: true, cell: r => hostCount(r, "affected", "affected") },
      { label: "Needs reboot", num: true, cell: r => hostCount(r, "pending_reboot", "fixed_pending_reboot") },
      { label: "Last report", cell: r => h("span", { class: r.host_status === "stale" ? "host-silent" : null },
          timeAgo(r.last_checkin)) },
    ], attention, { onRow: r => { location.hash = "#/host/" + r.host_id; } })
    : h("div", { class: "empty" }, h("p", null, "Every reporting server is fully patched.")),
  );

  const top = (app.top_affected || []).slice(0, 8);
  const advSection = h("section", null,
    h("h2", null, "Most urgent advisories"),
    top.length ? table([
      { label: "Advisory", nowrap: true, cell: r => h("a", { href: "#/advisories?state=affected" }, r.advisory_id) },
      { label: "Severity", cell: r => sevLabel(r.severity) },
      { label: "Servers", num: true, cell: r => count(r.hosts_affected, "affected") },
    ], top)
    : h("div", { class: "empty" }, h("p", null, "No outstanding advisories.")),
  );

  const osTable = h("section", null,
    h("h2", null, "Fleet by operating system"),
    table([
      { label: "OS", cell: r => osLabel(r.os_id, r.os_major) },
      { label: "Status", cell: r => HOST_STATUS[r.status] || r.status },
      { label: "Servers", num: true, cell: r => r.hosts },
      { label: "Awaiting reboot", num: true, cell: r => count(r.awaiting_reboot, "fixed_pending_reboot") },
    ], fleet.by_os || []),
  );

  render(exposure, h("div", { class: "two-col" }, attnSection, advSection), osTable);
}

/* ---- hosts -------------------------------------------------------------- */

async function renderHosts(params) {
  setNav("hosts");
  const comp = await api("/admin/compliance");
  const all = comp.hosts || [];
  let q = params.get("q") || "";
  let filter = params.get("show") || "all";

  const body = h("div");
  const search = h("input", { type: "search", placeholder: "Filter by server name", value: q,
    "aria-label": "Filter by server name" });

  const filters = [
    ["all", "All servers"],
    ["attention", "Needs attention"],
    ["silent", "Silent"],
  ];
  const btns = filters.map(([k, label]) =>
    h("button", { type: "button", "aria-pressed": String(k === filter), "data-k": k }, label));

  function draw() {
    const needle = q.toLowerCase();
    const rows = all.filter(r => {
      if (needle && !r.hostname.toLowerCase().includes(needle)) return false;
      if (filter === "attention") return Number(r.affected) || Number(r.pending_reboot);
      if (filter === "silent") return r.host_status === "stale";
      return true;
    });
    btns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === filter)));
    body.replaceChildren(rows.length ? table([
      { label: "Server", cell: r => h("a", { href: "#/host/" + r.host_id }, r.hostname) },
      { label: "OS", cell: r => osLabel(r.os_id, r.os_version) },
      { label: "Status", cell: r => h("span", { class: r.host_status === "stale" ? "host-silent" : null },
          HOST_STATUS[r.host_status] || r.host_status) },
      { label: "Running kernel", mono: true, cell: r => r.kernel_running || "" },
      { label: "Needs patch", num: true, cell: r => hostCount(r, "affected", "affected") },
      { label: "Needs reboot", num: true, cell: r => hostCount(r, "pending_reboot", "fixed_pending_reboot") },
      { label: "Patched", num: true, cell: r => r.host_status === "stale" ? h("span", { class: "count unknown-val" }, "unknown") : r.remediated },
      { label: "Last report", cell: r => timeAgo(r.last_checkin) },
    ], rows, { onRow: r => { location.hash = "#/host/" + r.host_id; } })
    : h("div", { class: "empty" }, h("p", null,
        all.length ? "No servers match this filter." : "No servers have enrolled yet.")));
  }

  search.addEventListener("input", () => { q = search.value; draw(); });
  btns.forEach(b => b.addEventListener("click", () => { filter = b.dataset.k; draw(); }));

  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl hosts ls" }, "Hosts"),
      h("span", { class: "muted small" }, all.length + (all.length === 1 ? " server" : " servers"))),
    h("div", { class: "controls" }, search, h("div", { class: "filters", role: "group", "aria-label": "Show" }, btns)),
    body,
  );
  draw();
}

/* ---- host detail -------------------------------------------------------- */
/*
 * Two panes: the advisory list on the left stays still, and the selected
 * advisory's details and explanation open on the right. Nothing in the list
 * moves when an explanation loads. On narrow screens the panel becomes a
 * sheet over the bottom of the page.
 */

const explainCache = new Map();   // advisory id -> result, for this page view

function wideScreen() { return window.matchMedia("(min-width: 1100px)").matches; }

async function renderHost(id, params) {
  setNav("hosts");
  const [detail, advs] = await Promise.all([
    api("/admin/hosts/" + encodeURIComponent(id)),
    api("/admin/hosts/" + encodeURIComponent(id) + "/advisories"),
  ]);
  const host = detail.host;
  const rows = advs.advisories || [];
  explainCache.clear();

  const counts = {};
  rows.forEach(r => { counts[r.state] = (counts[r.state] || 0) + 1; });
  let show = params.get("state") || (counts.affected ? "affected"
    : counts.fixed_pending_reboot ? "fixed_pending_reboot" : "all");
  let selected = null;

  /* -- summary line: the four facts that matter, reboot folded in -------- */
  const stale = host.status === "stale";
  const kernelDiffers = host.kernel_latest && host.kernel_running &&
    !host.kernel_running.startsWith(host.kernel_latest.replace(/\.(x86_64|aarch64)$/, ""));
  const summary = h("div", { class: "host-summary" },
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "OS"),
      osLabel(host.os_id, host.os_version) + " " + (host.arch || "")),
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Running"),
      h("span", { class: "mono" }, host.kernel_running || "unknown")),
    h("span", { class: "hs-item" + (stale ? " host-silent" : "") }, h("span", { class: "hs-k" }, "Reported"),
      timeAgo(host.last_checkin)),
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Packages"), detail.package_count),
  );

  const alerts = [];
  if (host.reboot_required) {
    alerts.push(h("div", { class: "hs-alert st-fixed_pending_reboot" },
      h("strong", null, "Needs reboot"),
      kernelDiffers
        ? h("span", null, " to run the installed kernel ", h("span", { class: "mono" }, host.kernel_latest))
        : h("span", null, host.reboot_reason ? ": " + host.reboot_reason : ""),
    ));
  }
  if (stale) {
    alerts.push(h("div", { class: "hs-alert st-unknown" },
      h("strong", null, "Not reporting"),
      h("span", null, " since " + fmtDateTime(host.last_checkin) +
        ". Verdicts are shown as no recent data until it checks in."),
    ));
  }

  const more = h("details", { class: "host-more" },
    h("summary", null, "Details"),
    h("dl", { class: "facts" }, [
      ["Newest installed kernel", h("span", { class: "mono" }, host.kernel_latest || "unknown")],
      ["Last report", fmtDateTime(host.last_checkin)],
      ["Last inventory", fmtDateTime(host.last_inventory)],
      ["Status", HOST_STATUS[host.status] || host.status],
      ["Host group", host.host_group || "default"],
      ["Agent", host.agent_version || "unknown"],
      ["Enrolled", fmtDate(host.enrolled_at)],
    ].map(([k, v]) => h("div", null, h("dt", null, k), h("dd", null, v)))),
  );

  /* -- filters ------------------------------------------------------------- */
  const filterDefs = [["all", "All (" + rows.length + ")", null]].concat(
    STATE_ORDER.filter(s => counts[s]).map(s => [s, STATES[s].label + " (" + counts[s] + ")", s]));
  const btns = filterDefs.map(([k, label, st]) =>
    h("button", { type: "button", class: st ? "st-" + st : null, "data-k": k,
                  "aria-pressed": String(k === show) }, label));

  /* -- list and panel ------------------------------------------------------ */
  const listBox = h("div", { class: "pane-list" });
  const panel = h("aside", { class: "pane-detail", "aria-live": "polite", "aria-label": "Selected advisory" });
  const sheetClose = () => { panel.classList.remove("open"); document.body.classList.remove("sheet-open"); };

  function cveList(r) {
    const c = r.cves || [];
    if (!c.length) return h("span", { class: "muted" }, "none");
    return c[0] + (c.length > 1 ? " +" + (c.length - 1) : "");
  }

  function drawPanel() {
    if (!selected) {
      panel.replaceChildren(h("p", { class: "pane-empty" },
        rows.length ? "Select an advisory to see its details and an explanation."
                    : "No advisories apply to this server."));
      return;
    }
    const r = selected;
    const cached = explainCache.get(r.advisory_id);
    const explainBox = h("div", { class: "pd-explain" });

    const fill = res => {
      explainBox.replaceChildren(
        h("p", { class: "explain-note" }, "AI explanation, advisory only. The verdict comes from the version check."),
        h("p", { class: "explain-text" }, res.text),
        h("p", { class: "explain-meta" },
          (res.cached ? "From cache" : "Generated in " + Math.round((res.duration_ms || 0) / 1000) + "s") +
          (res.model ? ", " + res.model : "")));
    };

    if (cached) fill(cached);
    else if (EXPLAINABLE.has(r.state)) {
      const b = h("button", { type: "button", class: "explain-btn" }, "Explain with AI-01");
      b.addEventListener("click", async () => {
        b.disabled = true;
        explainBox.replaceChildren(h("p", { class: "explain-wait" },
          "Asking AI-01. On a CPU-only server this can take up to a minute."));
        try {
          const res = await apiPost("/admin/hosts/" + encodeURIComponent(id) +
                                    "/advisories/" + encodeURIComponent(r.advisory_id) + "/explain");
          explainCache.set(r.advisory_id, res);
          if (selected === r) fill(res);
        } catch (err) {
          if (err.status === 401) return renderSignIn(err.message);
          explainBox.replaceChildren(h("p", { class: "explain-error" }, explainError(err)), b);
          b.disabled = false;
        }
      });
      explainBox.replaceChildren(b);
    }

    panel.replaceChildren(
      h("div", { class: "pd-head" },
        h("h2", null, r.advisory_id),
        h("button", { type: "button", class: "pd-close", "aria-label": "Close", on: { click: sheetClose } }, "Close")),
      h("div", { class: "pd-badges" }, stateMark(r.state), sevLabel(r.severity)),
      r.title ? h("p", { class: "pd-title" }, r.title) : null,
      h("dl", { class: "pd-facts" },
        h("div", null, h("dt", null, "Package"), h("dd", null, r.package_name)),
        h("div", null, h("dt", null, "Installed"),
          h("dd", { class: "mono" + (r.state === "affected" ? " ver-old" : "") }, r.installed_evr)),
        h("div", null, h("dt", null, "Fixed in"),
          h("dd", { class: "mono" + (r.state === "affected" ? " ver-new" : "") }, r.fixed_evr)),
        h("div", null, h("dt", null, "CVEs"),
          // Each ID is unbreakable; lines wrap only between IDs. A browser
          // otherwise breaks at the hyphens inside CVE-2026-31338.
          h("dd", { class: "pd-cves" }, (r.cves || []).length
            ? (r.cves || []).flatMap((c, i) => [i ? ", " : null, h("span", { class: "cve" }, c)])
            : "none listed")),
        r.reason ? h("div", null, h("dt", null, "Why"), h("dd", null, r.reason)) : null,
      ),
      explainBox,
    );
  }

  function select(r, tr) {
    selected = r;
    listBox.querySelectorAll("tr.selected").forEach(x => x.classList.remove("selected"));
    if (tr) tr.classList.add("selected");
    drawPanel();
    if (!wideScreen()) {
      panel.classList.add("open");
      document.body.classList.add("sheet-open");
    }
  }

  function draw() {
    btns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === show)));
    const list = show === "all" ? rows : rows.filter(r => r.state === show);
    if (!list.length) {
      listBox.replaceChildren(h("div", { class: "empty" }, h("p", null,
        rows.length ? "Nothing in this category." :
        "No advisories apply to this server yet. If it has just enrolled, run ./scripts/phase4-cve.sh --compute on PATCH-01.")));
      return;
    }
    const tbl = table([
      { label: "State", nowrap: true, cell: r => stateMark(r.state) },
      { label: "Advisory", nowrap: true, cell: r => r.advisory_id },
      { label: "Severity", nowrap: true, cell: r => sevLabel(r.severity) },
      { label: "Package", nowrap: true, cell: r => r.package_name },
      { label: "Installed", mono: true, cell: r =>
          h("span", { class: r.state === "affected" ? "ver-old" : null }, r.installed_evr) },
      { label: "Fixed in", mono: true, cell: r =>
          h("span", { class: r.state === "affected" ? "ver-new" : null }, r.fixed_evr) },
    ], list, { onRow: r => {} });   // CVEs are listed in full in the panel
    // Row selection needs the <tr>, so wire it here rather than via onRow
    tbl.querySelectorAll("tbody tr").forEach((tr, i) => {
      const r = list[i];
      tr.tabIndex = 0;
      tr.setAttribute("aria-label", r.advisory_id + ", " + (STATES[r.state] || {}).label);
      const pick = () => select(r, tr);
      tr.addEventListener("click", pick);
      tr.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); pick(); } });
      if (selected && selected.advisory_id === r.advisory_id) tr.classList.add("selected");
    });
    listBox.replaceChildren(tbl);

    // On a wide screen, open the first item so the panel is never idle
    if (wideScreen() && (!selected || !list.includes(selected))) {
      select(list[0], tbl.querySelector("tbody tr"));
    }
  }
  btns.forEach(b => b.addEventListener("click", () => { show = b.dataset.k; draw(); }));

  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl host show " + host.hostname }, host.hostname),
      h("a", { href: "#/hosts", class: "small" }, "All hosts")),
    summary,
    alerts,
    more,
    h("div", { class: "controls" }, h("div", { class: "filters", role: "group", "aria-label": "Show" }, btns)),
    h("div", { class: "panes" }, listBox, panel),
  );
  draw();
  drawPanel();
}

/* ---- advisories --------------------------------------------------------- */

async function renderAdvisories() {
  setNav("advisories");
  const app = await api("/admin/applicability/summary");
  const top = app.top_affected || [];
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl advisories --affected --sort severity" }, "Advisories"),
      h("span", { class: "muted small" }, "Ordered by severity, then by how many servers need the fix")),
    top.length ? table([
      { label: "Advisory", nowrap: true, cell: r => r.advisory_id },
      { label: "Severity", cell: r => sevLabel(r.severity) },
      { label: "Servers affected", num: true, cell: r => count(r.hosts_affected, "affected") },
      { label: "Issued", cell: r => fmtDate(r.issued_at) },
      { label: "Summary", cell: r => r.title || "" },
      { label: "CVEs", cell: r => (r.cves || []).slice(0, 3).join(", ") +
          ((r.cves || []).length > 3 ? " and " + (r.cves.length - 3) + " more" : "") },
    ], top)
    : h("div", { class: "empty" },
        h("p", null, "No server needs a patch right now."),
        h("p", { class: "muted small" }, "If this is unexpected, check the CVE engine last ran with ",
          h("code", null, "./scripts/phase4-cve.sh --report"), ".")),
  );
}

/* ---- activity ----------------------------------------------------------- */

const ACTIONS = {
  enroll: "Server enrolled",
  re_enroll: "Server re-enrolled",
  inventory: "Inventory received",
  inventory_rejected: "Inventory rejected",
  create_enrollment_token: "Enrollment token issued",
  decommission: "Server retired",
  mark_stale: "Silent servers marked",
};

async function renderActivity() {
  setNav("activity");
  const res = await api("/admin/audit?limit=200");
  const rows = res.events || [];
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl audit tail -n 200" }, "Activity"),
      h("span", { class: "muted small" }, "Permanent record; entries cannot be edited or removed")),
    rows.length ? table([
      { label: "When", cell: r => fmtDateTime(r.occurred_at) },
      { label: "What", cell: r => ACTIONS[r.action] || r.action },
      { label: "By", cell: r => r.actor },
      { label: "From", mono: true, cell: r => r.source_ip || "" },
      { label: "Detail", cell: r => {
          const d = r.detail || {};
          const parts = [];
          if (d.packages !== undefined) parts.push(d.packages + " packages" + (d.unchanged ? ", unchanged" : ""));
          if (d.os) parts.push(d.os);
          if (d.host_group) parts.push("group " + d.host_group);
          if (d.reboot_required) parts.push("reboot required");
          if (d.package_count !== undefined) parts.push(d.package_count + " packages reported");
          return parts.join(", ");
        } },
    ], rows)
    : h("div", { class: "empty" }, h("p", null, "Nothing recorded yet.")),
  );
}

/* ---- routing ------------------------------------------------------------ */

async function route() {
  if (!getAuth()) return renderSignIn();
  document.getElementById("top").hidden = false;
  document.getElementById("whoami").textContent = "Signed in as " + getAuth().user;

  const raw = location.hash.replace(/^#\/?/, "");
  const [path, query] = raw.split("?");
  const params = new URLSearchParams(query || "");
  const parts = path.split("/").filter(Boolean);

  try {
    if (parts[0] === "hosts") await renderHosts(params);
    else if (parts[0] === "host" && parts[1]) await renderHost(parts[1], params);
    else if (parts[0] === "advisories") await renderAdvisories(params);
    else if (parts[0] === "activity") await renderActivity(params);
    else await renderOverview();
  } catch (err) {
    showError(err);
  }
}

function start() {
  route();
}

document.addEventListener("DOMContentLoaded", () => {
  fillThemeSelect(document.getElementById("theme"));
  window.addEventListener("hashchange", route);
  document.getElementById("refresh").addEventListener("click", route);
  document.getElementById("signout").addEventListener("click", () => {
    clearAuth();
    location.hash = "#/";
    renderSignIn();
  });
  start();
});
