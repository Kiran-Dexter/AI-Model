<#
.SYNOPSIS
  PATCH-01 agent for Windows Server (PowerShell 5.1, built in to Windows Server 2016 and later).

.DESCRIPTION
  Runs every 2 minutes as SYSTEM from a scheduled task. Patch jobs from
  PATCH-01 run through it: a precheck, installing the WSUS-approved updates
  the job names, a reboot when the job says so, and a postcheck. Each run checks in and
  picks up commands. Every 4 hours, or when PATCH-01 asks, it also reports:
    - the OS build (10.0.17763.6414), which PATCH-01 compares with Microsoft's
      Security Update Guide to know which CVEs are still open;
    - installed updates (KBs);
    - updates Windows Update says are missing, searched against the server's
      own WSUS, so they reflect your approvals;
    - whether a reboot is pending, uptime, and the hardware ID that links the
      server to its VM in vCenter.

  Patch jobs: the precheck restarts Windows Update, searches this server's
  WSUS for the job's updates and downloads them; the install installs them
  one by one (one failure does not stop the rest); after the reboot the
  postcheck confirms each update is installed and that the services running
  before are running again (a service that will not start is reported, it is
  not a failed patch).

  patch-agent.ps1 -SelfTest -Server https://patch01.example -Pin <sha256>
      checks every step and reports ok or failed; enrols nothing
  patch-agent.ps1 -Enroll -Server <url> -Token <token> -Pin <sha256>
  patch-agent.ps1 -Run            (what the scheduled task runs)
  patch-agent.ps1 -Inventory      (report now)
#>
[CmdletBinding(DefaultParameterSetName = "Run")]
param(
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)][switch]$Enroll,
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][switch]$SelfTest,
    [Parameter(ParameterSetName = "Run")][switch]$Run,
    [Parameter(ParameterSetName = "Inventory", Mandatory = $true)][switch]$Inventory,
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)]
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][string]$Server,
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)][string]$Token,
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)]
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][string]$Pin
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$AgentVersion = "1.5.1-win"
$DataDir = Join-Path $env:ProgramData "PatchAgent"
$ConfigFile = Join-Path $DataDir "agent.json"
$TokenFile = Join-Path $DataDir "token.bin"
$StateFile = Join-Path $DataDir "state.json"
$LogFile = Join-Path $DataDir "agent.log"
$InventoryEveryHours = 4
$SearchTimeoutSec = 1800
# Script-wide state, declared up front: strict mode refuses to read a variable
# that has never been set, and Get-Config checks this before anything sets it
$script:Cfg = $null

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
function Write-Log([string]$Message, [string]$Level = "INFO") {
    # Never throws: a log file held by an antivirus scan or a log reader must not break a job step.
    # The timestamp is always yyyy-MM-dd HH:mm:ss, whatever the server's regional settings.
    $line = "{0} {1} {2}" -f (Get-Date).ToString("yyyy-MM-dd HH:mm:ss", [Globalization.CultureInfo]::InvariantCulture), $Level, $Message
    Write-Verbose $line
    if (-not (Test-Path -LiteralPath $DataDir)) { return }
    for ($i = 0; $i -lt 3; $i++) {
        try {
            if ((Test-Path -LiteralPath $LogFile) -and ((Get-Item -LiteralPath $LogFile).Length -gt 1MB)) {
                try { Move-Item -LiteralPath $LogFile -Destination ($LogFile + ".1") -Force -ErrorAction Stop } catch { }
            }
            Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8 -ErrorAction Stop
            return
        } catch { Start-Sleep -Milliseconds 200 }
    }
}

# ---------------------------------------------------------------------------
# TLS: PATCH-01's certificate is pinned by its SHA-256 fingerprint. Compiled
# once, because a PowerShell script block used as a certificate callback can
# be called on a thread with no PowerShell runspace and fail.
# ---------------------------------------------------------------------------
if (-not ("PatchAgentPin" -as [type])) {
    Add-Type -TypeDefinition @"
using System;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
public static class PatchAgentPin {
    public static string Pin = "";
    public static string Seen = "";
    public static bool Check(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors errors) {
        if (cert == null) { return false; }
        using (SHA256 sha = SHA256.Create()) {
            Seen = BitConverter.ToString(sha.ComputeHash(cert.GetRawCertData())).Replace("-", "").ToLowerInvariant();
        }
        if (Pin == "system") { return errors == SslPolicyErrors.None; }
        // Several fingerprints, comma-separated, while a certificate is being replaced
        foreach (string one in Pin.Split(',')) { if (one.Length > 0 && Seen == one) { return true; } }
        return false;
    }
    public static void Use(string pin) {
        Pin = pin.Trim().ToLowerInvariant().Replace(":", "").Replace(" ", "");
        ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(Check);
    }
}
"@
}

function Initialize-Http([string]$PinValue) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [PatchAgentPin]::Use($PinValue)
    # PATCH-01 is internal: never send it through a proxy configured for the internet
    [Net.WebRequest]::DefaultWebProxy = $null
}

function Assert-Https([string]$Url) {
    # The certificate pin only applies to https: a plain http address would send the token in clear
    if ($Url -notmatch '^https://[A-Za-z0-9.-]+(:\d{1,5})?/?$') { throw ("PATCH-01's address must be https://<name>[:port]; '" + $Url + "' was refused") }
}

function Invoke-Api([string]$Method, [string]$Path, $Body = $null, [string]$Bearer = $null, [int]$Timeout = 60) {
    $cfg = Get-Config
    Assert-Https ([string]$cfg.server)
    $uri = $cfg.server.TrimEnd("/") + $Path
    $headers = @{ "User-Agent" = "patch-agent/$AgentVersion" }
    if ($Bearer) { $headers["Authorization"] = "Bearer " + $Bearer }
    $params = @{ Method = $Method; Uri = $uri; Headers = $headers; TimeoutSec = $Timeout; UseBasicParsing = $true }
    if ($null -ne $Body) {
        # -InputObject, not a pipe: piping unwraps one-element arrays in PowerShell 5.1
        $params["Body"] = [Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $Body -Depth 8 -Compress))
        $params["ContentType"] = "application/json; charset=utf-8"
    }
    try {
        return Invoke-RestMethod @params
    } catch {
        $detail = $_.Exception.Message
        # In PowerShell 5.1 Invoke-RestMethod has already read the error body:
        # it is in ErrorDetails, and the response stream is empty by now
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
            $code = ""
            if ($_.Exception.PSObject.Properties["Response"] -and $_.Exception.Response) { $code = "HTTP " + [int]$_.Exception.Response.StatusCode + ": " }
            $detail = $code + $_.ErrorDetails.Message
        }
        # Only web errors carry a response; asking others for one fails under strict mode
        elseif ($_.Exception.PSObject.Properties["Response"] -and $_.Exception.Response) {
            try {
                $sr = New-Object IO.StreamReader($_.Exception.Response.GetResponseStream())
                $detail = "HTTP " + [int]$_.Exception.Response.StatusCode + ": " + $sr.ReadToEnd()
            } catch { }
        }
        if ([PatchAgentPin]::Seen -and [PatchAgentPin]::Pin -ne "system" -and ([PatchAgentPin]::Pin.Split(",") -notcontains [PatchAgentPin]::Seen)) {
            $detail = "PATCH-01's certificate does not match the pin. It presented " + [PatchAgentPin]::Seen
        }
        throw "$Method $Path failed: $detail"
    }
}

function Get-IsoUtc([datetime]$When = (Get-Date)) {
    # Whole seconds: "o" writes seven decimal places, more than the API accepts
    return $When.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ", [Globalization.CultureInfo]::InvariantCulture)
}

# ---------------------------------------------------------------------------
# Configuration and the agent's token, encrypted for this machine only
# ---------------------------------------------------------------------------
function Get-Config {
    if ($script:Cfg) { return $script:Cfg }
    if (-not (Test-Path $ConfigFile)) { throw "Not enrolled: run install-agent.ps1 first." }
    $script:Cfg = Get-Content -Raw $ConfigFile | ConvertFrom-Json
    return $script:Cfg
}

function Save-Token([string]$Value) {
    Add-Type -AssemblyName System.Security
    $bytes = [Text.Encoding]::UTF8.GetBytes($Value)
    $enc = [Security.Cryptography.ProtectedData]::Protect($bytes, $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
    [IO.File]::WriteAllBytes($TokenFile, $enc)
}

function Get-Token {
    Add-Type -AssemblyName System.Security
    if (-not (Test-Path $TokenFile)) { throw "No agent token: enrol first." }
    $enc = [IO.File]::ReadAllBytes($TokenFile)
    $bytes = [Security.Cryptography.ProtectedData]::Unprotect($enc, $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
    return [Text.Encoding]::UTF8.GetString($bytes)
}

function Get-State {
    # A missing, empty or damaged state file starts afresh instead of breaking every later run
    try {
        if (Test-Path -LiteralPath $StateFile) {
            $raw = [IO.File]::ReadAllText($StateFile)
            if (-not [string]::IsNullOrWhiteSpace($raw)) {
                $st = ConvertFrom-Json -InputObject $raw
                if ($st -is [Management.Automation.PSCustomObject]) { return $st }
            }
        }
    } catch { }
    return [pscustomobject]@{ last_inventory = $null }
}

function Save-State($State) {
    # Written to a temporary file and swapped in, so a restart mid-write never leaves it empty
    $tmp = $StateFile + ".tmp"
    [IO.File]::WriteAllText($tmp, (ConvertTo-Json -InputObject $State -Depth 6), (New-Object Text.UTF8Encoding($false)))
    if (Test-Path -LiteralPath $StateFile) { [IO.File]::Replace($tmp, $StateFile, [NullString]::Value) } else { [IO.File]::Move($tmp, $StateFile) }
}

function Get-Prop($Object, [string]$Name) {
    <# A value that may be missing, without tripping strict mode. Works for
       objects (registry entries, JSON from PATCH-01) and for hashtables (what a
       background job returns): a hashtable's entries are not its properties. #>
    if ($null -eq $Object) { return $null }
    if ($Object -is [Collections.IDictionary]) {
        if ($Object.Contains($Name)) { return $Object[$Name] }
        return $null
    }
    if ($Object.PSObject.Properties[$Name]) { return $Object.$Name }
    return $null
}

# ---------------------------------------------------------------------------
# Facts about this server
# ---------------------------------------------------------------------------
function Get-Build {
    $cv = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion"
    $major = 10; $minor = 0
    if ($cv.PSObject.Properties["CurrentMajorVersionNumber"]) { $major = $cv.CurrentMajorVersionNumber }
    if ($cv.PSObject.Properties["CurrentMinorVersionNumber"]) { $minor = $cv.CurrentMinorVersionNumber }
    $ubr = 0
    if ($cv.PSObject.Properties["UBR"]) { $ubr = $cv.UBR }
    return [pscustomobject]@{
        Build   = "{0}.{1}.{2}.{3}" -f $major, $minor, $cv.CurrentBuildNumber, $ubr
        Number  = [int]$cv.CurrentBuildNumber
        Product = $cv.ProductName
    }
}

function Get-ServerVersion($BuildInfo) {
    # The Windows Server release, from the build number; the product name as a fallback
    switch ($BuildInfo.Number) {
        14393 { return "2016" } 17763 { return "2019" } 20348 { return "2022" } 26100 { return "2025" }
    }
    if ($BuildInfo.Product -match "(20\d\d)") { return $Matches[1] }
    return [string]$BuildInfo.Number
}

function Get-RebootState {
    $reasons = @()
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending") { $reasons += "component servicing" }
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") { $reasons += "Windows Update" }
    try { if ((New-Object -ComObject Microsoft.Update.SystemInfo).RebootRequired) { if ($reasons -notcontains "Windows Update") { $reasons += "Windows Update" } } } catch { }
    return [pscustomobject]@{ Required = ($reasons.Count -gt 0); Reason = ($reasons -join ", ") }
}

function Get-Facts {
    $os = Get-CimInstance Win32_OperatingSystem
    $cs = Get-CimInstance Win32_ComputerSystemProduct
    $b = Get-Build
    # A DNS hiccup must not stop the check-in (and so every job step)
    $fqdn = $env:COMPUTERNAME.ToLowerInvariant()
    try { $fqdn = ([Net.Dns]::GetHostEntry($env:COMPUTERNAME).HostName).ToLowerInvariant() } catch { }
    $uuid = $null
    if ($cs.UUID -and $cs.UUID -match "^[0-9A-Fa-f-]{32,36}$" -and $cs.UUID -notmatch "^[0F-]+$") { $uuid = $cs.UUID.ToLowerInvariant() }
    return [pscustomobject]@{
        Hostname = $env:COMPUTERNAME.ToLowerInvariant()
        Fqdn     = $fqdn
        Build    = $b.Build
        Version  = Get-ServerVersion $b
        Edition  = $b.Product
        Boot     = Get-IsoUtc $os.LastBootUpTime
        Uuid     = $uuid
        MachineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
    }
}

function Get-WsusSource {
    $wu = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
    $server = $null; $use = 0
    if (Test-Path $wu) {
        $p = Get-ItemProperty $wu
        if ($p.PSObject.Properties["WUServer"]) { $server = $p.WUServer }
        if (Test-Path "$wu\AU") {
            $au = Get-ItemProperty "$wu\AU"
            if ($au.PSObject.Properties["UseWUServer"]) { $use = $au.UseWUServer }
        }
    }
    if ($server -and $use -eq 1) { return [pscustomobject]@{ Source = "wsus"; Server = $server } }
    return [pscustomobject]@{ Source = "microsoft"; Server = $null }
}

function Get-InstalledSoftware {
    <# Programs and Features, from the registry both 64-bit and 32-bit programs
       write to. Updates and hidden system components are left out. #>
    $out = @(); $seen = @{}
    foreach ($src in @(@{ Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"; Arch = "64-bit" },
                       @{ Path = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"; Arch = "32-bit" })) {
        foreach ($e in @(Get-ItemProperty -Path $src.Path -ErrorAction SilentlyContinue)) {
            $name = Get-Prop $e "DisplayName"
            if (-not $name) { continue }
            if ((Get-Prop $e "SystemComponent") -eq 1) { continue }
            if (Get-Prop $e "ParentKeyName") { continue }
            $rt = [string](Get-Prop $e "ReleaseType")
            if ($rt -in @("Update", "Hotfix", "Security Update", "Update Rollup")) { continue }
            $ver = [string](Get-Prop $e "DisplayVersion")
            $key = ($name + "|" + $ver + "|" + $src.Arch).ToLowerInvariant()
            if ($seen.ContainsKey($key)) { continue }
            $seen[$key] = $true
            $size = Get-Prop $e "EstimatedSize"
            $item = @{ name = ([string]$name).Trim(); version = $ver.Trim(); arch = $src.Arch }
            $pub = Get-Prop $e "Publisher"; if ($pub) { $item["publisher"] = ([string]$pub).Trim() }
            $d = [string](Get-Prop $e "InstallDate"); if ($d -match "^\d{8}$") { $item["installed_on"] = $d }
            $kbSize = 0.0
            if ($size -and $size -isnot [array] -and [double]::TryParse([string]$size, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$kbSize) -and $kbSize -gt 0) {
                $item["size_mb"] = [int]($kbSize / 1024)
            }
            $out += $item
        }
    }
    return ,$out
}

function Search-MissingUpdates {
    <# Asks Windows Update what is not installed. Against WSUS this returns
       what WSUS has approved for this computer. Run as a job so a search that
       hangs is abandoned instead of blocking every later run. #>
    $job = Start-Job -ScriptBlock {
        $ErrorActionPreference = "Stop"          # a failed search must fail, never look like "nothing missing"
        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = "PATCH-01"
        $searcher = $session.CreateUpdateSearcher()
        $result = $searcher.Search("IsInstalled=0 and IsHidden=0 and BrowseOnly=0 and Type='Software'")
        if ([int]$result.ResultCode -ne 2 -and [int]$result.ResultCode -ne 3) { throw ("Windows Update search ended with result " + [int]$result.ResultCode) }
        $out = @()
        foreach ($u in $result.Updates) {
          try {
            $kb = $null
            if ($u.KBArticleIDs.Count -gt 0) { $kb = "KB" + $u.KBArticleIDs.Item(0) }
            $cats = @(); foreach ($c in $u.Categories) { $cats += [string]$c.Name }
            $cves = @(); foreach ($c in $u.CveIDs) { $cves += [string]$c }
            $out += [pscustomobject]@{
                update_id = [string]$u.Identity.UpdateID
                kb = $kb
                title = [string]$u.Title
                severity = [string]$u.MsrcSeverity
                categories = $cats
                cves = $cves
                downloaded = [bool]$u.IsDownloaded
                reboot_behaviour = @("never", "always", "may")[[int]$u.InstallationBehavior.RebootBehavior]
                size_mb = [int]([double]$u.MaxDownloadSize / 1MB)
            }
          } catch { }                               # one unreadable update does not lose the rest
        }
        return @{ updates = $out }
    }
    if (-not (Wait-Job $job -Timeout $SearchTimeoutSec)) {
        Stop-Job $job; Remove-Job $job -Force
        throw "Windows Update search did not finish within $([int]($SearchTimeoutSec / 60)) minutes"
    }
    try { $r = Receive-JobResult $job "Windows Update search" } finally { Remove-Job $job -Force }
    $data = @(Get-Prop $r "updates")
    # Results come back deserialised: an empty list can arrive as $null, and
    # extra job properties ride along. Rebuild each update with exactly the
    # fields PATCH-01 expects.
    $clean = @()
    foreach ($u in @($data)) {
        if ($null -eq $u -or -not $u.PSObject.Properties["update_id"]) { continue }
        $sev = $null; if ($u.severity) { $sev = [string]$u.severity }
        $clean += @{
            update_id = [string]$u.update_id; kb = $u.kb; title = [string]$u.title; severity = $sev
            categories = @(@($u.categories) | Where-Object { $_ } | ForEach-Object { [string]$_ })
            cves = @(@($u.cves) | Where-Object { $_ } | ForEach-Object { [string]$_ })
            downloaded = [bool]$u.downloaded; reboot_behaviour = [string]$u.reboot_behaviour; size_mb = [int]$u.size_mb
        }
    }
    return ,$clean
}

# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------
function Send-Checkin($Token) {
    $f = Get-Facts
    $r = Get-RebootState
    $body = @{ agent_version = $AgentVersion; kernel_running = $f.Build; reboot_required = $r.Required; boot_time = $f.Boot }
    if ($f.Uuid) { $body["hardware_uuid"] = $f.Uuid }
    Invoke-Api "POST" "/api/v1/agent/checkin" $body $Token | Out-Null
}

function Send-Inventory($Token) {
    $t0 = Get-Date
    $f = Get-Facts
    $r = Get-RebootState
    $packages = @(@{ name = "windows-os-build"; version = ($f.Build + "-0"); arch = "noarch" })
    foreach ($h in (Get-HotFix -ErrorAction SilentlyContinue)) {
        if ($h.HotFixID -match "^KB\d+$") {
            $packages += @{ name = $h.HotFixID.ToLowerInvariant(); version = "1-0"; arch = "noarch"; from_repo = [string]$h.Description }
        }
    }
    $body = @{
        collected_at = (Get-IsoUtc); kernel_running = $f.Build
        reboot_required = $r.Required; reboot_reason = $r.Reason; os_version = $f.Version
        agent_version = $AgentVersion; boot_time = $f.Boot; packages = $packages
        duration_ms = [int]((Get-Date) - $t0).TotalMilliseconds
    }
    if ($f.Uuid) { $body["hardware_uuid"] = $f.Uuid }
    Invoke-Api "POST" "/api/v1/agent/inventory" $body $Token -Timeout 120 | Out-Null
    Write-Log ("inventory sent: build {0}, {1} updates installed" -f $f.Build, ($packages.Count - 1))

    try {
        $sw = Get-InstalledSoftware
        Invoke-Api "POST" "/api/v1/agent/windows/software" @{ software = $sw } $Token -Timeout 120 | Out-Null
        Write-Log ("software sent: {0} programs" -f $sw.Count)
    } catch { Write-Log ("software inventory failed: " + $_.Exception.Message) }

    $src = Get-WsusSource
    $report = @{ searched_at = (Get-IsoUtc); source = $src.Source; server = $src.Server
                 os_edition = $f.Edition; updates = @() }
    try {
        $report["updates"] = Search-MissingUpdates
        Write-Log ("Windows Update ({0}): {1} missing" -f $src.Source, $report["updates"].Count)
    } catch {
        $report["error"] = [string]$_.Exception.Message
        Write-Log ("Windows Update search failed: " + $report["error"])
    }
    Invoke-Api "POST" "/api/v1/agent/windows/updates" $report $Token -Timeout 120 | Out-Null
}

# ---------------------------------------------------------------------------
# Windows Update helpers shared by the precheck and the install
# ---------------------------------------------------------------------------
$WuIdRe = '^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$'

function Get-ValidUpdateIds($Params) {
    return @(@(Get-Prop $Params "windows_updates") | ForEach-Object { [string]$_ } | Where-Object { $_ -match $WuIdRe })
}

function Test-Tcp([string]$HostName, [int]$Port, [int]$Ms = 5000) {
    # "" when it connects, otherwise the reason
    $c = New-Object Net.Sockets.TcpClient
    try {
        $iar = $c.BeginConnect($HostName, $Port, $null, $null)
        if (-not $iar.AsyncWaitHandle.WaitOne($Ms)) { return "no answer within " + [int]($Ms / 1000) + " s" }
        $c.EndConnect($iar); return ""
    } catch {
        $ex = $_.Exception
        if ($ex.PSObject.Properties["InnerException"] -and $ex.InnerException) { $ex = $ex.InnerException }
        return [string]$ex.Message
    }
    finally { $c.Close() }
}

function Get-WuActivity {
    <# Signs that Windows Update is doing something: bytes landing in its
       download folders (BITS and Delivery Optimization both write there) and
       CPU used by the servicing engine. Compared over time, they tell
       "slow" from "stuck". #>
    $bytes = [long]0
    foreach ($d in @("$env:SystemRoot\SoftwareDistribution\Download",
                     "$env:SystemRoot\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache")) {
        if (Test-Path $d) {
            # An empty folder gives no measurement at all ($null): counted as 0, never read as $null.Sum
            foreach ($fi in @(Get-ChildItem -Path $d -Recurse -Force -File -ErrorAction SilentlyContinue)) { $bytes += [long]$fi.Length }
        }
    }
    try { foreach ($b in @(Get-BitsTransfer -AllUsers -ErrorAction Stop)) { $bytes += [long]$b.BytesTransferred } } catch { }
    $cpu = 0.0
    foreach ($pr in @(Get-Process -Name TiWorker, TrustedInstaller -ErrorAction SilentlyContinue)) { if ($pr.CPU) { $cpu += [double]$pr.CPU } }
    return [pscustomobject]@{ Bytes = $bytes; Cpu = $cpu }
}

function Invoke-PreDownload([string[]]$Ids, $Token, [int]$StallMinutes, [int]$LimitMinutes, [int]$TotalMb) {
    <# Download the job's updates now, so the install window only installs.
       Progress every 30 s. If nothing moves for StallMinutes, stop and say so:
       nothing has been installed at this point, so stopping is safe. #>
    $job = Start-Job -ArgumentList (,$Ids) -ScriptBlock {
        param($ids)
        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = "PATCH-01"
        $ErrorActionPreference = "Stop"
        $ids = @($ids | ForEach-Object { $_ } | Where-Object { $_ })
        $found = $session.CreateUpdateSearcher().Search((($ids | ForEach-Object { "UpdateID='" + $_ + "'" }) -join " or "))
        $coll = New-Object -ComObject Microsoft.Update.UpdateColl
        foreach ($u in $found.Updates) {
            if (($ids -contains [string]$u.Identity.UpdateID) -and -not $u.IsDownloaded -and -not $u.IsInstalled) {
                if (-not $u.EulaAccepted) { $u.AcceptEula() }
                [void]$coll.Add($u)
            }
        }
        if ($coll.Count -eq 0) { return @{ code = 2; done = @() } }
        $dl = $session.CreateUpdateDownloader()
        try { $dl.Priority = 4 } catch { try { $dl.Priority = 3 } catch { } }    # foreground download, not background BITS
        $dl.Updates = $coll
        $r = $dl.Download()
        $done = @(); for ($i = 0; $i -lt $coll.Count; $i++) { $done += @{ id = [string]$coll.Item($i).Identity.UpdateID; ok = [bool]$coll.Item($i).IsDownloaded } }
        return @{ code = [int]$r.ResultCode; hresult = ("0x{0:X8}" -f $r.HResult); done = $done }
    }
    $t0 = Get-Date; $a0 = Get-WuActivity; $lastBytes = $a0.Bytes; $lastMove = Get-Date
    while (-not (Wait-Job $job -Timeout 30)) {
        $a = Get-WuActivity
        $got = [int](([math]::Max(0, $a.Bytes - $a0.Bytes)) / 1MB)
        if ($a.Bytes -ne $lastBytes) { $lastBytes = $a.Bytes; $lastMove = Get-Date }
        $quiet = [int]((Get-Date) - $lastMove).TotalMinutes
        Write-Log ("pre-download: about " + $got + " of up to " + $TotalMb + " MB after " + [int]((Get-Date) - $t0).TotalMinutes + " min" +
                   $(if ($quiet -ge 2) { "; nothing has arrived for " + $quiet + " min" } else { "" }))
        Send-LogTail $Token
        if ($quiet -ge $StallMinutes) {
            Stop-Job $job; Remove-Job $job -Force
            return @{ ok = $false; stalled = $true
                      why = ("the download stalled: nothing arrived for " + $StallMinutes + " minutes (about " + $got + " of " + $TotalMb + " MB had arrived)") }
        }
        if (((Get-Date) - $t0).TotalMinutes -ge $LimitMinutes) {
            Stop-Job $job; Remove-Job $job -Force
            return @{ ok = $false; stalled = $false; why = ("the download did not finish within " + $LimitMinutes + " minutes (about " + $got + " MB arrived)") }
        }
    }
    try { $r = Receive-JobResult $job "pre-download" } finally { Remove-Job $job -Force }
    $all = @(@(Get-Prop $r "done") | Where-Object { $_ })
    $notDone = @($all | Where-Object { -not (Get-Prop $_ "ok") })
    $code = [int](Get-Prop $r "code")
    $mins = [int]((Get-Date) - $t0).TotalMinutes
    if ($code -eq 2 -and $notDone.Count -eq 0) { return @{ ok = $true; minutes = $mins } }
    if ($all.Count -gt 0 -and $notDone.Count -lt $all.Count) {
        # Some arrived: the install downloads the rest itself, one by one
        return @{ ok = $true; minutes = $mins; partial = $true
                  why = ([string]$notDone.Count + " of " + $all.Count + " update(s) did not download now (result " + $code + ", " + (Get-Prop $r "hresult") + "); the install will try them again") }
    }
    return @{ ok = $false; stalled = $false; why = ("Windows Update ended the download with result " + $code + " (" + (Get-Prop $r "hresult") + "); none of the " + $all.Count + " update(s) downloaded") }
}

function Receive-JobResult($Job, [string]$What) {
    <# A background job's answer. A stray error the job wrote along the way
       (a log line that could not be written, one update that could not be
       read) is logged, and never throws away the answer itself. #>
    $jerr = $null
    $r = Receive-Job $Job -ErrorAction SilentlyContinue -ErrorVariable jerr
    foreach ($x in @($jerr)) { if ($x) { Write-Log ($What + ": " + [string]$x) "WARN" } }
    $r = @($r | Where-Object { $_ -is [Collections.IDictionary] })
    if ($r.Count -eq 0) { throw ($What + " returned no answer" + $(if (@($jerr).Count) { ": " + [string]@($jerr)[0] } else { "" })) }
    return $r[$r.Count - 1]
}

function Format-Gb([double]$Value) {
    # "12.3 GB": always text, so it can be joined to other text (a number first
    # in "+" makes PowerShell try to turn the text into a number)
    return ([string]::Format([Globalization.CultureInfo]::InvariantCulture, "{0:0.0} GB", $Value))
}

function Set-StateValue([string]$Name, $Value) {
    $state = Get-State
    if ($state.PSObject.Properties[$Name]) { $state.$Name = $Value }
    else { $state | Add-Member -NotePropertyName $Name -NotePropertyValue $Value }
    Save-State $state
}

# ---------------------------------------------------------------------------
# The Windows Update service
# ---------------------------------------------------------------------------
function Restart-WindowsUpdate {
    <# Restart the Windows Update service (wuauserv) so the job starts with a
       clean client: a stuck search or download from earlier is dropped. If it
       does not stop within 60 seconds and runs in a process of its own, that
       process is ended; a process shared with other services is never ended. #>
    $t0 = Get-Date
    try {
        $svc = Get-Service -Name wuauserv -ErrorAction Stop
        if ([string]$svc.StartType -eq "Disabled") { return @{ ok = $false; detail = "Windows Update (wuauserv) is disabled" } }
        if ([string]$svc.Status -ne "Stopped") {
            # The service object's own Stop() returns at once; Stop-Service would wait for ever on a hung service
            try { $svc.Stop() } catch { Write-Log ("stopping wuauserv: " + $_.Exception.Message) "WARN" }
            try { $svc.WaitForStatus("Stopped", (New-TimeSpan -Seconds 60)) } catch { }
            $svc.Refresh()
            if ([string]$svc.Status -ne "Stopped") {
                $w = Get-CimInstance Win32_Service -Filter "Name='wuauserv'"
                $procId = [int]$w.ProcessId
                $sharing = @(Get-CimInstance Win32_Service -Filter ("ProcessId=" + $procId)).Count
                if ($procId -le 0 -or $sharing -ne 1) {
                    return @{ ok = $false; detail = "Windows Update did not stop within 60 s and shares its process with other services, so it was left running" }
                }
                Write-Log ("wuauserv did not stop within 60 s: ending its own process " + $procId) "WARN"
                Stop-Process -Id $procId -Force -ErrorAction Stop
                Start-Sleep -Seconds 5
            }
        }
        $svc.Refresh()
        if ([string]$svc.Status -ne "Running") { $svc.Start() }
        try { $svc.WaitForStatus("Running", (New-TimeSpan -Seconds 60)) }
        catch { return @{ ok = $false; detail = "Windows Update was restarted but did not report Running within 60 s; it starts on demand" } }
        return @{ ok = $true; detail = ("Windows Update service restarted in " + [int]((Get-Date) - $t0).TotalSeconds + " s") }
    } catch {
        return @{ ok = $false; detail = ("Windows Update service could not be restarted: " + $_.Exception.Message) }
    }
}

# ---------------------------------------------------------------------------
# Which updates this job installs, from a fresh search of this server's WSUS
# ---------------------------------------------------------------------------
function Get-JobSelection($Params) {
    <# What PATCH-01 asked for. Older PATCH-01 releases send only the update
       IDs; newer ones also say the job's mode (every approved update, or the
       ones for chosen advisories) with its KBs and CVEs. #>
    $kbs = @(@(Get-Prop $Params "windows_kbs") | Where-Object { $_ } | ForEach-Object { ([string]$_).ToUpperInvariant() } | Where-Object { $_ -match '^KB\d{5,8}$' })
    $cves = @(@(Get-Prop $Params "windows_cves") | Where-Object { $_ } | ForEach-Object { ([string]$_).ToUpperInvariant() } | Where-Object { $_ -match '^CVE-\d{4}-\d{4,7}$' })
    $mode = [string](Get-Prop $Params "windows_mode")
    if (@("all", "advisories") -notcontains $mode) { $mode = "" }
    return @{ ids = @(Get-ValidUpdateIds $Params); kbs = $kbs; cves = $cves; mode = $mode }
}

function Find-JobUpdates($Params, [int]$TimeoutSec = 1200) {
    <# Ask WSUS now what this server is missing, and pick the job's updates
       from that: by update ID, then by KB (a re-released update keeps its KB),
       then by CVE for an advisory job, or everything approved for an "all"
       job. Updates that would wait for someone to click are skipped. Run as a
       background job so a hanging Windows Update cannot block the agent. #>
    $sel = Get-JobSelection $Params
    $job = Start-Job -ArgumentList $sel.ids, $sel.kbs, $sel.cves, $sel.mode -ScriptBlock {
        param($ids, $kbs, $cves, $mode)
        $ErrorActionPreference = "Stop"          # a failed search must fail, never look like "nothing to install"
        $ids = @($ids | Where-Object { $_ }); $kbs = @($kbs | Where-Object { $_ }); $cves = @($cves | Where-Object { $_ })
        function KbOf($u) { if ($u.KBArticleIDs.Count -gt 0) { return "KB" + $u.KBArticleIDs.Item(0) }; return $null }
        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = "PATCH-01"
        $searcher = $session.CreateUpdateSearcher()
        # BrowseOnly=0: never the optional or preview updates Windows Update only offers
        $missing = $searcher.Search("IsInstalled=0 and IsHidden=0 and BrowseOnly=0 and Type='Software'")
        if ([int]$missing.ResultCode -ne 2 -and [int]$missing.ResultCode -ne 3) { throw ("Windows Update search ended with result " + [int]$missing.ResultCode) }
        # The job's own IDs, installed or not, to tell "already installed" from "gone"
        $named = @{}
        if ($ids.Count -gt 0) {
            try {
                $byId = $searcher.Search((($ids | ForEach-Object { "UpdateID='" + $_ + "'" }) -join " or "))
                foreach ($u in $byId.Updates) { $named[[string]$u.Identity.UpdateID] = $u }
            } catch { }
        }
        $wantKb = @{}; foreach ($k in $kbs) { $wantKb[$k] = $true }
        $already = @()
        foreach ($k in @($named.Keys)) {
            $u = $named[$k]; $kb = KbOf $u
            if ($u.IsInstalled) { $already += @{ id = $k; kb = $kb; title = [string]$u.Title } }
            elseif ($kb) { $wantKb[$kb] = $true }
        }
        $all = @(); $chosen = @(); $skipped = @(); $seen = @{}
        foreach ($u in $missing.Updates) {
          try {
            $id = [string]$u.Identity.UpdateID; $kb = KbOf $u
            $seen[$id] = $true
            $ucves = @(); foreach ($c in $u.CveIDs) { $ucves += ([string]$c).ToUpperInvariant() }
            $why = $null
            if ($mode -eq "all") { $why = "approved in WSUS" }
            elseif ($ids -contains $id) { $why = "named by the job" }
            elseif ($kb -and $wantKb.ContainsKey($kb)) { $why = "same KB as the job's update" }
            elseif ($mode -eq "advisories" -and $cves.Count -gt 0 -and @($ucves | Where-Object { $cves -contains $_ }).Count -gt 0) { $why = "fixes a CVE of the chosen advisories" }
            $urls = @()
            try {                       # only for a reachability hint: never fails the search
                foreach ($dc in $u.DownloadContents) { $urls += [string]$dc.DownloadUrl }
                foreach ($b in $u.BundledUpdates) { foreach ($dc in $b.DownloadContents) { $urls += [string]$dc.DownloadUrl } }
            } catch { }
            $item = @{ id = $id; kb = $kb; title = [string]$u.Title; mb = [int]([double]$u.MaxDownloadSize / 1MB)
                       downloaded = [bool]$u.IsDownloaded; why = $why; urls = @($urls | Where-Object { $_ } | Select-Object -Unique) }
            $all += @{ id = $id; kb = $kb; title = [string]$u.Title }
            if (-not $why) { continue }
            if ($u.InstallationBehavior.CanRequestUserInput) { $skipped += @{ id = $id; kb = $kb; title = [string]$u.Title; why = "it asks for input while installing" }; continue }
            $chosen += $item
          } catch { }                               # one unreadable update does not lose the rest
        }
        $gone = @($ids | Where-Object { -not $named.ContainsKey($_) -and -not $seen.ContainsKey($_) })
        return @{ missing = $all; selected = $chosen; already = $already; skipped = $skipped; not_found = $gone }
    }
    if (-not (Wait-Job $job -Timeout $TimeoutSec)) {
        Stop-Job $job; Remove-Job $job -Force
        throw ("Windows Update did not answer the search within " + [int]($TimeoutSec / 60) + " minutes")
    }
    try { $r = Receive-JobResult $job "Windows Update search" } finally { Remove-Job $job -Force }
    $out = @{}
    foreach ($k in @("missing", "selected", "already", "skipped", "not_found")) { $out[$k] = @(@(Get-Prop $r $k) | Where-Object { $_ }) }
    $out.mode = $sel.mode
    return $out
}

function Find-JobUpdatesTwice($Params, [int]$TimeoutSec) {
    # A search that fails once is tried again after restarting Windows Update
    try { return Find-JobUpdates $Params $TimeoutSec }
    catch {
        Write-Log ("Windows Update search failed: " + $_.Exception.Message + "; restarting Windows Update and trying once more") "WARN"
        $rs = Restart-WindowsUpdate; Write-Log $rs.detail $(if ($rs.ok) { "INFO" } else { "WARN" })
        return Find-JobUpdates $Params $TimeoutSec
    }
}

# Services that stop by design (started on demand, by a trigger, or only for
# updates): never counted as "did not come back"
$TransientServices = @("TrustedInstaller", "wuauserv", "BITS", "UsoSvc", "WaaSMedicSvc", "DoSvc", "sppsvc", "RemoteRegistry",
                       "gupdate", "gupdatem", "edgeupdate", "edgeupdatem", "MapsBroker", "tiledatamodelsvc", "WbioSrvc",
                       "ShellHWDetection", "CDPSvc", "msiserver", "VSS", "swprv", "defragsvc", "WinHttpAutoProxySvc")

function Test-StopsByDesign([string]$Name) {
    if ($TransientServices -contains $Name) { return $true }
    $key = "HKLM:\SYSTEM\CurrentControlSet\Services\" + $Name
    if (Test-Path ($key + "\TriggerInfo")) { return $true }               # started by a trigger, stops by itself
    try {
        $type = [int](Get-ItemProperty -Path $key -Name Type -ErrorAction Stop).Type
        if (($type -band 0x40) -ne 0) { return $true }                    # a per-user service instance
    } catch { }
    return $false
}

function Get-BaselineServices {
    # The automatic services running now that are expected to keep running
    return @(Get-CimInstance Win32_Service -Filter "State='Running' AND StartMode='Auto'" |
             ForEach-Object { [string]$_.Name } | Where-Object { -not (Test-StopsByDesign $_) } | Sort-Object)
}

function Invoke-Precheck($Params, $Token) {
    <# Everything the job needs, checked before anything changes. Each check is
       logged as it runs, so ">_ Log" shows exactly which one failed and why.
       Then Windows Update is restarted, this server's WSUS is searched for the
       job's updates, and they are downloaded now, so the install only installs. #>
    function Note([string]$Name, [string]$State, [string]$Detail) {
        $script:pcChecks += @{ check = $Name; state = $State; detail = $Detail }
        Write-Log ("precheck " + $Name + ": " + $State.ToUpper() + " - " + $Detail) $(if ($State -eq "fail") { "ERROR" } elseif ($State -eq "warn") { "WARN" } else { "INFO" })
        if ($State -eq "fail") { $script:pcErrors += ($Name + ": " + $Detail) }
        if ($State -eq "warn") { $script:pcWarnings += ($Name + ": " + $Detail) }
    }
    $script:pcChecks = @(); $script:pcErrors = @(); $script:pcWarnings = @(); $script:pcJobWarnings = @()
    $pcStart = Get-Date

    # 1. Disk: more than 1 GB free on C: is enough to go ahead
    $c = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
    $freeBytes = [double]$c.FreeSpace
    $freeGb = [math]::Round($freeBytes / 1GB, 1)
    if ($freeBytes -le 1GB) { Note "disk" "fail" ("only " + (Format-Gb $freeGb) + " free on C:; at least 1 GB is needed") }
    elseif ($freeGb -lt 5) { Note "disk" "warn" ((Format-Gb $freeGb) + " free on C:; a cumulative update can need more, watch the install") }
    else { Note "disk" "ok" ((Format-Gb $freeGb) + " free on C:") }

    # 2. Services Windows Update depends on: they may be stopped (they start on demand), never disabled
    foreach ($sv in @(@{ n = "wuauserv"; l = "Windows Update" }, @{ n = "BITS"; l = "Background Intelligent Transfer" },
                      @{ n = "CryptSvc"; l = "Cryptographic Services" }, @{ n = "TrustedInstaller"; l = "Windows Modules Installer" })) {
        $o = Get-Service -Name $sv.n -ErrorAction SilentlyContinue
        if (-not $o) { Note ("service " + $sv.n) "fail" ($sv.l + " is missing") }
        elseif ([string]$o.StartType -eq "Disabled") { Note ("service " + $sv.n) "fail" ($sv.l + " is disabled; updates cannot be installed") }
        else { Note ("service " + $sv.n) "ok" ($sv.l + " is " + [string]$o.Status + ", start " + [string]$o.StartType) }
    }

    # 3. A reboot already waiting can make cumulative updates fail
    $r = Get-RebootState
    if ($r.Required) { Note "reboot" "warn" ("a reboot was already pending before this change (" + $r.Reason + ")") }
    else { Note "reboot" "ok" "no reboot pending" }

    # 4. The update source
    $src = Get-WsusSource
    if ($src.Source -eq "wsus") {
        try { $u = [Uri]$src.Server; $why = Test-Tcp $u.Host $u.Port } catch { $why = "the address '" + $src.Server + "' could not be read" }
        if ($why) { Note "wsus" "fail" ("WSUS at " + $src.Server + " cannot be reached: " + $why) } else { Note "wsus" "ok" ("WSUS at " + $src.Server + " answers") }
    } else { Note "wsus" "warn" "no WSUS policy found: this server uses Microsoft Update directly" }

    $res = @{ free_gb_c = $freeGb; update_source = $src.Source }
    $baseline = @()
    if ((Get-Prop $Params "capture_services") -ne $false) {
        $baseline = @(Get-BaselineServices)
        Write-Log ("services running before the change: " + $baseline.Count + " (kept to compare after)")
    }
    $res.running_services = $baseline

    # 5. Restart Windows Update, then search WSUS for the job's updates and download them
    if ($script:pcErrors.Count -eq 0 -and (Get-Prop $Params "restart_windows_update") -ne $false) {
        $rs = Restart-WindowsUpdate
        Note "windows update service" $(if ($rs.ok) { "ok" } else { "warn" }) $rs.detail
    }
    $sel = Get-JobSelection $Params
    if ($script:pcErrors.Count -eq 0 -and ($sel.ids.Count -gt 0 -or $sel.mode -or $sel.kbs.Count -gt 0)) {
        $t0 = Get-Date
        $f = $null
        try { $f = Find-JobUpdatesTwice $Params 1200 } catch { Note "search" "fail" ([string]$_.Exception.Message) }
        if ($f) {
            $todo = @($f.selected)
            Note "search" "ok" ("WSUS lists " + $f.missing.Count + " missing update(s) for this server; " + $todo.Count + " for this job, " +
                                $f.already.Count + " of the job's already installed (" + [int]((Get-Date) - $t0).TotalSeconds + " s)")
            foreach ($x in $todo) {
                Write-Log ("  " + (Get-Prop $x "kb") + " " + (Get-Prop $x "title") + ", up to " + (Get-Prop $x "mb") + " MB" +
                           $(if (Get-Prop $x "downloaded") { ", already downloaded" } else { "" }) + " (" + (Get-Prop $x "why") + ")")
            }
            foreach ($x in $f.skipped) {
                $t = (Get-Prop $x "kb") + " " + (Get-Prop $x "title") + " was skipped: " + (Get-Prop $x "why")
                Note "skipped" "warn" $t; $script:pcJobWarnings += $t
            }
            if ($f.not_found.Count -gt 0) {
                $t = [string]$f.not_found.Count + " of the job's updates are no longer offered by WSUS (replaced or declined)"
                Note "not offered" "warn" $t; $script:pcJobWarnings += $t
            }
            $res.windows_selected = @($todo | ForEach-Object { @{ id = (Get-Prop $_ "id"); kb = (Get-Prop $_ "kb"); title = (Get-Prop $_ "title") } })
            Set-StateValue "job_updates" @{ at = (Get-IsoUtc); key = (Get-JobKey $Params); selected = $res.windows_selected }
            $need = @($todo | Where-Object { -not (Get-Prop $_ "downloaded") })
            if ($todo.Count -eq 0) {
                Note "download" "ok" "nothing to download: every update of this job is installed"
            } elseif ($need.Count -eq 0) {
                Note "download" "ok" "all updates are already downloaded"
            } else {
                # Where the files come from: a warning only, the download itself decides
                $endpoints = @{}
                foreach ($x in $need) { foreach ($url in @(Get-Prop $x "urls")) {
                    try { $uu = [Uri]$url; $endpoints[$uu.Host + ":" + $uu.Port] = @{ h = $uu.Host; p = $uu.Port } } catch { }
                } }
                foreach ($k in $endpoints.Keys) {
                    $e = $endpoints[$k]; $why = Test-Tcp $e.h $e.p
                    if ($why) { Note "download source" "warn" ($k + " does not answer directly (" + $why + "); trying the download anyway") }
                    else { Write-Log ("  download source " + $k + " answers") }
                }
                $res.download_sources = @($endpoints.Keys)
                $total = 0; foreach ($x in $need) { $total += [int](Get-Prop $x "mb") }
                $stall = [int](Get-Prop $Params "stall_minutes"); if ($stall -lt 3 -or $stall -gt 60) { $stall = 10 }
                Write-Log ("pre-download: " + $need.Count + " update(s), up to " + $total + " MB")
                # PATCH-01 gives the whole precheck 130 minutes: the download gets what is left, keeping a margin
                $budget = [int][math]::Max(10, [math]::Min(80, 115 - ((Get-Date) - $pcStart).TotalMinutes))
                try { $d = Invoke-PreDownload @($need | ForEach-Object { [string](Get-Prop $_ "id") }) $Token $stall $budget $total }
                catch { $d = @{ ok = $false; why = ("the download could not run: " + $_.Exception.Message) } }
                if ($d.ok -and (Get-Prop $d "partial")) { Note "download" "warn" $d.why; $script:pcJobWarnings += $d.why }
                elseif ($d.ok) { Note "download" "ok" ("downloaded in " + $d.minutes + " min; the install will not need to download") }
                else {
                    $hint = ""
                    if ($src.Source -eq "wsus") { $hint = ". If WSUS sends servers to Microsoft for the files, set WSUS to store update files locally (Options, Update Files and Languages)" }
                    Note "download" "fail" ($d.why + ". Nothing was installed" + $hint)
                }
            }
        }
    } elseif ($script:pcErrors.Count -eq 0) {
        Note "updates" "ok" "this job names no Windows updates"
    }

    $res.checks = $script:pcChecks; $res.errors = $script:pcErrors; $res.warnings = $script:pcWarnings
    $res.job_warnings = $script:pcJobWarnings          # the ones PATCH-01 keeps on the server's result
    $ok = ($script:pcErrors.Count -eq 0)
    $msg = $(if ($ok) { "precheck passed" + $(if ($script:pcWarnings.Count) { "; " + ($script:pcWarnings -join "; ") } else { "" }) } else { $script:pcErrors -join "; " })
    return @{ ok = $ok; result = $res; message = $msg }
}

function Get-JobKey($Params) {
    # What identifies a job's selection, so the install can reuse its precheck's search
    $sel = Get-JobSelection $Params
    return ((@($sel.ids | Sort-Object) -join ",") + "|" + $sel.mode + "|" + (@($sel.kbs | Sort-Object) -join ",") + "|" + (@($sel.cves | Sort-Object) -join ","))
}

function Get-CachedSelection($Params) {
    <# The precheck's WSUS search for this same job, if under 2 hours old:
       the install then skips a second full search (minutes on 2016/2019). #>
    $st = Get-State
    if (-not $st.PSObject.Properties["job_updates"] -or -not $st.job_updates) { return $null }
    $j = $st.job_updates
    if ([string](Get-Prop $j "key") -ne (Get-JobKey $Params)) { return $null }
    $at = $null; try { $at = [datetime](Get-Prop $j "at") } catch { }
    if (-not $at) { return $null }
    $age = ((Get-Date).ToUniversalTime() - $at.ToUniversalTime()).TotalMinutes
    if ($age -lt 0 -or $age -gt 120) { return $null }
    $ids = @(@(Get-Prop $j "selected") | Where-Object { $_ } | ForEach-Object { [string](Get-Prop $_ "id") } | Where-Object { $_ -match $WuIdRe })
    if ($ids.Count -eq 0) { return $null }
    return @{ ids = $ids; minutes = [int]$age }
}

function Invoke-InstallUpdates($Params, $Token) {
    <# Install the job's updates: the servicing stack first on its own, then
       the rest downloaded and installed together in one Windows Update
       session (much faster than one by one; if that fails, one by one).
       The precheck's WSUS search is reused when it is recent. Progress goes
       to the agent's log (and so to PATCH-01) every 30 seconds. One update
       that fails does not stop the others; the job fails only when none of
       its updates could be installed. #>
    $cmdStart = Get-Date
    $sel = Get-JobSelection $Params
    if ($sel.ids.Count -eq 0 -and -not $sel.mode -and $sel.kbs.Count -eq 0) {
        return @{ ok = $false; message = "this job names no valid Windows updates"; result = @{} }
    }
    $cache = Get-CachedSelection $Params
    $out = $null; $wanted = @()
    if ($cache) {
        $wanted = $cache.ids
        Write-Log ("using the precheck's WSUS search from " + $cache.minutes + " min ago: " + $wanted.Count + " update(s); no second search")
        $out = Invoke-InstallJob $wanted $Token $cmdStart
        if (Get-Prop $out "lookup_empty") { Write-Log "the precheck's updates were not found again; searching WSUS afresh" "WARN"; $out = $null }
    }
    if (-not $out) {
        $rs = Restart-WindowsUpdate
        Write-Log $rs.detail $(if ($rs.ok) { "INFO" } else { "WARN" })
        $f = Find-JobUpdatesTwice $Params 1200
        $wanted = @($f.selected | ForEach-Object { [string](Get-Prop $_ "id") } | Where-Object { $_ -match $WuIdRe })
        Write-Log ("WSUS search: " + $f.missing.Count + " missing, " + $wanted.Count + " for this job, " + $f.already.Count + " of the job's already installed")
        if ($wanted.Count -eq 0) {
            $pending = (Get-RebootState).Required
            # Installed earlier but still waiting for a restart: not "nothing to do", PATCH-01 restarts it
            $res = @{ nothing_to_do = (-not $pending); installed = @(); errors = @(); reboot_required = $pending
                      already = @($f.already | ForEach-Object { @{ id = (Get-Prop $_ "id"); kb = (Get-Prop $_ "kb") } }) }
            $why = $(if ($f.already.Count -gt 0) { "the updates were already installed" } elseif ($f.not_found.Count -gt 0) { "WSUS no longer offers the job's updates (replaced or declined): nothing to install" } else { "nothing approved in WSUS is missing" })
            return @{ ok = $true; message = $why; result = $res }
        }
        $out = Invoke-InstallJob $wanted $Token $cmdStart
    }
    if (Get-Prop $out "final") { return $out.final }
    if (Get-Prop $out "lookup_empty") {
        return @{ ok = $false; result = @{ reboot_required = (Get-RebootState).Required }
                  message = ("WSUS listed " + $wanted.Count + " update(s) for this job, but Windows Update did not find them again to install; nothing was installed. Run the job again; if it repeats, check the server's Windows Update log") }
    }
    $r = $out.r
    $start = $out.started
    $installed = @(@(Get-Prop $r "installed") | Where-Object { $_ })
    $failed = @(@(Get-Prop $r "failed") | Where-Object { $_ })
    # Windows' own flag counts too: some updates only say so in the registry
    $reboot = [bool](Get-Prop $r "reboot_required") -or ($installed.Count -gt 0 -and (Get-RebootState).Required)
    $failText = @($failed | ForEach-Object { "{0} failed (result {1}, {2})" -f $(if ($_.kb) { $_.kb } else { $_.title }), $_.code, $_.hresult })
    $res = @{ nothing_to_do = [bool](Get-Prop $r "nothing_to_do"); reboot_required = $reboot
              installed = @($installed | ForEach-Object { @{ id = $_.id; kb = $_.kb; title = $_.title } })
              failed = @($failed | ForEach-Object { @{ id = $_.id; kb = $_.kb; title = $_.title } })
              errors = @(); warnings = $failText }
    Set-StateValue "last_install" @{ at = (Get-IsoUtc); installed = $res.installed; failed = $res.failed }
    if ($res.nothing_to_do) { return @{ ok = $true; message = "the updates were already installed"; result = $res } }
    $msg = "{0} installed in {1} min" -f $installed.Count, [int]((Get-Date) - $start).TotalMinutes
    if ($failed.Count) { $msg += ", {0} failed: {1}" -f $failed.Count, ($failText -join "; ") }
    if ($reboot) { $msg += "; a reboot is needed" }
    if ($installed.Count -eq 0) {
        # Nothing went in: that is a failed install
        $res.errors = $failText
        return @{ ok = $false; message = $msg; result = $res }
    }
    # Some or all went in: carry on to the reboot and the check after it
    return @{ ok = $true; message = $msg; result = $res }
}

function Invoke-InstallJob([string[]]$wanted, $Token, [datetime]$cmdStart) {
    <# Runs the install in a background job and follows it. Returns
       @{ r = the job's answer; started }, @{ lookup_empty = $true }, or
       @{ final = the step's result } when it had to stop early. #>
    $progress = Join-Path $DataDir ("wu-progress-" + [guid]::NewGuid().ToString("N") + ".log")
    # Two arguments: no (,$x) wrapping here, that is only for a single array argument
    $job = Start-Job -ArgumentList $wanted, $progress -ScriptBlock {
        param($ids, $pf)
        $ErrorActionPreference = "Stop"          # a failed lookup must fail, never look like "nothing to install"
        $ids = @($ids | ForEach-Object { $_ } | Where-Object { $_ })
        function P([string]$m, [string]$lvl = "INFO") {
            try { Add-Content -Path $pf -Value ((Get-Date).ToString("yyyy-MM-dd HH:mm:ss", [Globalization.CultureInfo]::InvariantCulture) + " " + $lvl + " " + $m) -Encoding UTF8 -ErrorAction Stop } catch { }
        }
        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = "PATCH-01"
        $searcher = $session.CreateUpdateSearcher()
        $t0 = Get-Date
        P ("looking up " + $ids.Count + " update(s) by their IDs")
        try { $found = $searcher.Search((($ids | ForEach-Object { "UpdateID='" + $_ + "'" }) -join " or ")) }
        catch {
            P ("the lookup by ID was refused (" + $_.Exception.Message + "); doing a full search instead") "WARN"
            $found = $searcher.Search("IsInstalled=0 and Type='Software'")
        }
        $todo = @()
        foreach ($u in $found.Updates) {
            if (($ids -contains [string]$u.Identity.UpdateID) -and -not $u.IsInstalled) { $todo += $u }
        }
        P ("found " + $todo.Count + " to install in " + [int]((Get-Date) - $t0).TotalSeconds + " s")
        if ($todo.Count -eq 0) { return @{ nothing_to_do = $false; lookup_empty = $true; installed = @(); failed = @(); reboot_required = $false } }
        $acc = @{ ok = @(); bad = @(); reboot = $false; i = 0; n = $todo.Count }
        function KbOf($u) { if ($u.KBArticleIDs.Count -gt 0) { return "KB" + $u.KBArticleIDs.Item(0) }; return $null }
        function Label($u) { $k = KbOf $u; return $(if ($k) { $k } else { "update" }) + " " + [string]$u.Title }
        function Fast($dl) { try { $dl.Priority = 4 } catch { try { $dl.Priority = 3 } catch { } } }   # foreground download, not background BITS
        function Record($u, $code, [string]$hr, [int]$secs) {
            $acc.i++
            $e = @{ id = [string]$u.Identity.UpdateID; kb = (KbOf $u); title = [string]$u.Title; code = $code; hresult = $hr }
            if ($code -eq 2 -or $code -eq 3) { $acc.ok += $e; P ("installed " + $acc.i + " of " + $acc.n + " in " + [int]($secs / 60) + " min " + ($secs % 60) + " s: " + (Label $u)) }
            else { $acc.bad += $e; P ("FAILED " + $acc.i + " of " + $acc.n + " after " + $secs + " s: " + (Label $u) + " (result " + $code + ", " + $hr + ")") "ERROR" }
        }
        function One($u) {
            try {
                if (-not $u.EulaAccepted) { $u.AcceptEula() }
                $one = New-Object -ComObject Microsoft.Update.UpdateColl; [void]$one.Add($u)
                if (-not $u.IsDownloaded) {
                    P ("downloading " + (Label $u) + " (up to " + [int]([double]$u.MaxDownloadSize / 1MB) + " MB)")
                    $t1 = Get-Date; $dl = $session.CreateUpdateDownloader(); Fast $dl; $dl.Updates = $one; $dr = $dl.Download()
                    P ("downloaded in " + [int]((Get-Date) - $t1).TotalSeconds + " s (result " + [int]$dr.ResultCode + ")")
                }
                P ("installing " + ($acc.i + 1) + " of " + $acc.n + ": " + (Label $u))
                $t2 = Get-Date; $inst = $session.CreateUpdateInstaller(); $inst.Updates = $one; $r = $inst.Install()
                Record $u ([int]$r.GetUpdateResult(0).ResultCode) ("0x{0:X8}" -f $r.GetUpdateResult(0).HResult) ([int]((Get-Date) - $t2).TotalSeconds)
                if ($r.RebootRequired) { $acc.reboot = $true }
            } catch {
                # One update that throws (corrupt download, refused) does not stop the rest
                Record $u ([int]-1) ([string]$_.Exception.Message) 0
            }
        }
        # Servicing stack updates first, on their own: Windows needs them before the cumulative update
        $ssu = @($todo | Where-Object { $_.Title -match "Servicing Stack" })
        $rest = @($todo | Where-Object { $_.Title -notmatch "Servicing Stack" })
        foreach ($u in $ssu) { One $u }
        if ($rest.Count -gt 1) {
            # The rest in one Windows Update session: one download, one install (much faster than one by one)
            try {
                $coll = New-Object -ComObject Microsoft.Update.UpdateColl
                $need = New-Object -ComObject Microsoft.Update.UpdateColl
                $mb = 0
                foreach ($u in $rest) {
                    if (-not $u.EulaAccepted) { $u.AcceptEula() }
                    [void]$coll.Add($u)
                    if (-not $u.IsDownloaded) { [void]$need.Add($u); $mb += [int]([double]$u.MaxDownloadSize / 1MB) }
                }
                $later = @()
                if ($need.Count -gt 0) {
                    P ("downloading " + $need.Count + " update(s) together (up to " + $mb + " MB)")
                    $t1 = Get-Date; $dl = $session.CreateUpdateDownloader(); Fast $dl; $dl.Updates = $need; $dr = $dl.Download()
                    P ("downloaded in " + [int]((Get-Date) - $t1).TotalSeconds + " s (result " + [int]$dr.ResultCode + ")")
                    # Any that did not download go one by one after the batch (each gets its own download try)
                    $later = @($rest | Where-Object { -not $_.IsDownloaded })
                    if ($later.Count -gt 0) {
                        P ([string]$later.Count + " update(s) did not download with the others; they will be tried one by one") "WARN"
                        $coll = New-Object -ComObject Microsoft.Update.UpdateColl
                        foreach ($u in $rest) { if ($u.IsDownloaded) { [void]$coll.Add($u) } }
                    }
                }
                if ($coll.Count -gt 0) {
                    $ids2 = @(); $kbs2 = @()
                    for ($j = 0; $j -lt $coll.Count; $j++) { $ids2 += [string]$coll.Item($j).Identity.UpdateID; $kbs2 += [string](KbOf $coll.Item($j)) }
                    # A marker line: if this step is stopped mid-install, the updates of this batch are still known
                    P ("batch: " + ($ids2 -join ",") + " kbs: " + ($kbs2 -join ","))
                    P ("installing " + $coll.Count + " update(s) together: " + ((@($rest | ForEach-Object { Label $_ }) | Select-Object -First 6) -join "; "))
                    $t2 = Get-Date; $inst = $session.CreateUpdateInstaller(); $inst.Updates = $coll; $r = $inst.Install()
                    $secs = [int]((Get-Date) - $t2).TotalSeconds
                    for ($j = 0; $j -lt $coll.Count; $j++) {
                        $ur = $r.GetUpdateResult($j)
                        Record $coll.Item($j) ([int]$ur.ResultCode) ("0x{0:X8}" -f $ur.HResult) $secs
                    }
                    if ($r.RebootRequired) { $acc.reboot = $true }
                }
                foreach ($u in $later) { One $u }
            } catch {
                P ("installing them together failed (" + $_.Exception.Message + "); one at a time instead") "WARN"
                $done = @($acc.ok + $acc.bad | ForEach-Object { $_.id })
                foreach ($u in $rest) { if ($done -notcontains [string]$u.Identity.UpdateID -and -not $u.IsInstalled) { One $u } }
            }
        } else {
            foreach ($u in $rest) { One $u }
        }
        $ok = $acc.ok; $bad = $acc.bad; $reboot = $acc.reboot
        return @{ nothing_to_do = $false; installed = $ok; failed = $bad; reboot_required = $reboot }
    }
    # While Windows works: copy its progress into the log, and say so when it is quiet
    $copied = 0; $start = Get-Date; $lastLine = "starting"; $lastNew = Get-Date
    $deadline = $cmdStart.AddMinutes(170)              # PATCH-01 waits 3 hours for this step
    $act = Get-WuActivity; $lastBytes = $act.Bytes; $lastCpu = $act.Cpu; $lastMove = Get-Date
    while ($true) {
        $finished = [bool](Wait-Job $job -Timeout 30)
        if (Test-Path $progress) {
            $lines = @(Get-Content -Path $progress -Encoding UTF8 -ErrorAction SilentlyContinue)
            for ($k = $copied; $k -lt $lines.Count; $k++) {
                if ($lines[$k] -match '^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d (INFO|WARN|ERROR) (.+)$') {
                    Write-Log ("windows update: " + $Matches[2]) $Matches[1]; $lastLine = $Matches[2]; $lastNew = Get-Date
                }
            }
            $copied = $lines.Count
        }
        if ($finished) { break }
        $act = Get-WuActivity
        $busy = ($act.Bytes -ne $lastBytes) -or (($act.Cpu - $lastCpu) -ge 1)
        if ($busy) { $lastMove = Get-Date }
        $lastBytes = $act.Bytes; $lastCpu = $act.Cpu
        $idle = [int]((Get-Date) - $lastMove).TotalMinutes
        if (((Get-Date) - $lastNew).TotalSeconds -ge 60) {
            Write-Log ("windows update: still working (" + [int]((Get-Date) - $start).TotalMinutes + " min so far): " + $lastLine + "; " +
                       $(if ($idle -lt 2) { "Windows is busy" } else { "no download or install activity for " + $idle + " min" })) $(if ($idle -ge 10) { "WARN" } else { "INFO" })
            $lastNew = Get-Date
        }
        # A download that has stopped moving is safe to stop: nothing of that update is installed yet
        $why = $null
        if ($lastLine -like "downloading*" -and $idle -ge 15) { $why = "the download stalled: no activity for 15 minutes while " + $lastLine }
        elseif ((Get-Date) -gt $deadline) { $why = "the install did not finish within 2 h 50 min" }
        if ($why) {
            Stop-Job $job; Remove-Job $job -Force
            return @{ final = (Complete-PartialInstall $progress $why) }
        }
        Send-LogTail $Token
    }
    try { $r = Receive-JobResult $job "the install" }
    catch {
        Remove-Job $job -Force
        # The answer was lost: what the progress file says went in still counts
        return @{ final = (Complete-PartialInstall $progress ([string]$_.Exception.Message)) }
    }
    Remove-Job $job -Force
    Remove-Item $progress -Force -ErrorAction SilentlyContinue
    if (Get-Prop $r "lookup_empty") { return @{ lookup_empty = $true } }
    return @{ r = $r; started = $start }
}

function Complete-PartialInstall([string]$Progress, [string]$Why) {
    <# The install stopped early (stall, time limit, lost answer). Updates the
       progress file shows as installed are in and need the restart: the job
       carries on to the reboot with a warning, instead of failing a server
       that is half patched and waiting to restart. #>
    $done = @(); $batch = @(); $batchOpen = $false
    if (Test-Path $Progress) {
        foreach ($l in @(Get-Content -Path $Progress -Encoding UTF8 -ErrorAction SilentlyContinue)) {
            if ($l -match ' INFO installed \d+ of \d+ in .*?: (KB\d+|update) (.+)$') { $done += @{ id = $null; kb = $(if ($Matches[1] -ne "update") { $Matches[1] } else { $null }); title = $Matches[2] }; $batchOpen = $false }
            elseif ($l -match ' INFO batch: ([0-9A-Fa-f,-]+) kbs: (.*)$') {
                $ids = $Matches[1].Split(","); $kbs = $Matches[2].Split(","); $batch = @(); $batchOpen = $true
                for ($q = 0; $q -lt $ids.Count; $q++) { $batch += @{ id = $ids[$q]; kb = $(if ($q -lt $kbs.Count -and $kbs[$q]) { $kbs[$q] } else { $null }); title = ("update " + $ids[$q]) } }
            }
        }
        Remove-Item $Progress -Force -ErrorAction SilentlyContinue
    }
    $pending = (Get-RebootState).Required
    if ($batchOpen -and $pending) {
        # Stopped while a batch was installing and Windows now wants a restart: part or all of it went in.
        # Restart and let the check after it say exactly which ones are installed.
        $all = @($done + $batch)
        $note = $Why + " while installing " + $batch.Count + " update(s) together; Windows asks for a restart, so the server restarts and the check after it shows which are installed"
        Set-StateValue "last_install" @{ at = (Get-IsoUtc); installed = $all; failed = @() }
        return @{ ok = $true; message = $note
                  result = @{ nothing_to_do = $false; reboot_required = $true; installed = $all; failed = @(); errors = @(); warnings = @($note) } }
    }
    if ($done.Count -eq 0) {
        return @{ ok = $false; message = ($Why + ". Nothing was installed"); result = @{ reboot_required = $pending } }
    }
    $note = $Why + "; " + $done.Count + " update(s) installed before that, the rest were not"
    Set-StateValue "last_install" @{ at = (Get-IsoUtc); installed = $done; failed = @() }
    return @{ ok = $true; message = ($done.Count.ToString() + " installed; " + $note)
              result = @{ nothing_to_do = $false; reboot_required = $true; installed = $done; failed = @(); errors = @(); warnings = @($note) } }
}

function Invoke-Reboot($Params) {
    $delay = [int](Get-Prop $Params "delay_seconds"); if ($delay -lt 30) { $delay = 60 }
    # Scheduled, not immediate, so this result reaches PATCH-01 first
    & shutdown.exe /r /t $delay /d p:2:17 /c "PATCH-01 patch job: restarting to complete updates" | Out-Null
    $code = $LASTEXITCODE
    # 1190: a restart is already scheduled, which is what this step wants
    if ($code -eq 1190) { return @{ ok = $true; message = "a restart was already scheduled"; result = @{ delay_seconds = $delay } } }
    return @{ ok = ($code -eq 0); message = $(if ($code -eq 0) { "restart in $delay seconds" } else { "shutdown.exe refused the restart (code " + $code + ")" }); result = @{ delay_seconds = $delay } }
}

function Test-UpdatesInstalled($Updates) {
    <# For each update this job installed: is it installed now (after the
       restart)? From the installed hotfix list (KBs, what servicing really
       has) and Windows Update's own history; no WSUS search, so seconds. A
       history "succeeded" is trusted only when the KB is not a hotfix-listed
       package that has gone missing (rolled back). #>
    $hot = @(Get-HotFix -ErrorAction SilentlyContinue | ForEach-Object { ([string]$_.HotFixID).ToUpperInvariant() })
    $hist = @{}
    try {
        $s = New-Object -ComObject Microsoft.Update.Session
        $h = $s.CreateUpdateSearcher()
        $n = [int]$h.GetTotalHistoryCount()
        if ($n -gt 0) {
            foreach ($e in $h.QueryHistory(0, [math]::Min($n, 300))) {
                $id = [string]$e.UpdateIdentity.UpdateID
                if ($id -and -not $hist.ContainsKey($id)) { $hist[$id] = [int]$e.ResultCode }   # newest first
            }
        }
    } catch { Write-Log ("Windows Update history could not be read: " + $_.Exception.Message + "; using the installed hotfix list") "WARN" }
    $yes = @(); $no = @()
    foreach ($x in $Updates) {
        $id = [string](Get-Prop $x "id"); $kb = [string](Get-Prop $x "kb")
        $title = [string](Get-Prop $x "title")
        $inHot = ($kb -and ($hot -contains $kb.ToUpperInvariant()))
        $okHist = ($id -and $hist.ContainsKey($id) -and (@(2, 3) -contains $hist[$id]))
        # Cumulative and servicing stack updates are packages: they must be in the hotfix list
        # (.NET cumulative updates are listed in the hotfix list under other KBs: history decides for them)
        $package = ($title -notmatch '\.NET') -and ($title -match 'Cumulative Update for (Windows|Microsoft server operating system)|Servicing Stack|Security Monthly Quality Rollup|Security Only')
        $installed = $inHot -or ($okHist -and -not $package)
        $label = $(if ($kb) { $kb } else { $title })
        if ($installed) { $yes += $label } else { $no += $label }
    }
    return @{ installed = $yes; not_installed = $no }
}

function Invoke-Postcheck($Params) {
    <# After installing (and the reboot):
       - the job's updates are checked one by one: still not installed is reported;
       - the services that were running before are running again. Late starters
         are waited for; any still down is started once. A service that does
         not start is reported, but it is not a failed patch. #>
    $os = Get-CimInstance Win32_OperatingSystem
    $upMin = [int]((Get-Date) - $os.LastBootUpTime).TotalMinutes
    $warnings = @(); $errors = @()

    # 1. Services: wait for delayed starts after a fresh boot, then start what is still down
    $base = @(@(Get-Prop $Params "baseline_services") | Where-Object { $_ } | ForEach-Object { [string]$_ } | Where-Object { -not (Test-StopsByDesign $_) })
    $waitMin = $(if ($upMin -lt 15) { [math]::Min(8, 15 - $upMin) } else { 1 })
    $until = (Get-Date).AddMinutes($waitMin)
    do {
        $now = @(Get-CimInstance Win32_Service -Filter "State='Running'" | ForEach-Object { [string]$_.Name })
        $missing = @($base | Where-Object { $now -notcontains $_ })
        if ($missing.Count -eq 0) { break }
        Start-Sleep -Seconds 20
    } while ((Get-Date) -lt $until)
    $restarted = @(); $down = @()
    $startBy = (Get-Date).AddMinutes(6)
    foreach ($name in $missing) {
        $svc = Get-Service -Name $name -ErrorAction SilentlyContinue
        if (-not $svc) { $down += $name; continue }
        if ([string]$svc.StartType -eq "Disabled" -or (Get-Date) -gt $startBy) { $down += $name; continue }
        try {
            # Start() returns at once; Start-Service would wait for ever on a service stuck "starting"
            $svc.Start()
            $svc.WaitForStatus("Running", (New-TimeSpan -Seconds 60))
            $restarted += $name; Write-Log ("service " + $name + " was not running after the change: started it") "WARN"
        } catch {
            $down += $name; Write-Log ("service " + $name + " is not running and did not start: " + $_.Exception.Message) "WARN"
        }
    }

    # 2. The job's updates, installed now?
    $updates = @(@(Get-Prop $Params "windows_installed") | Where-Object { $_ })
    if ($updates.Count -eq 0) {
        # Older PATCH-01: what this agent installed for the job, if it was recent
        $st = Get-State
        if ($st.PSObject.Properties["last_install"] -and $st.last_install) {
            $at = $null; try { $at = [datetime]$st.last_install.at } catch { }
            if ($at -and ((Get-Date).ToUniversalTime() - $at.ToUniversalTime()).TotalHours -lt 12) { $updates = @(@($st.last_install.installed) | Where-Object { $_ }) }
        }
    }
    $check = @{ installed = @(); not_installed = @() }
    if ($updates.Count -gt 0) {
        $check = Test-UpdatesInstalled $updates
        Write-Log ("after the change: " + $check.installed.Count + " of " + $updates.Count + " update(s) installed" +
                   $(if ($check.not_installed.Count) { "; NOT installed: " + ($check.not_installed -join ", ") } else { "" }))
        if ($check.not_installed.Count -gt 0 -and $check.installed.Count -eq 0) {
            $errors += ("none of the job's updates is installed after the reboot (Windows may have rolled them back): " + ($check.not_installed -join ", "))
        } elseif ($check.not_installed.Count -gt 0) {
            $warnings += ("not installed after the reboot: " + ($check.not_installed -join ", "))
        }
    }
    $r = Get-RebootState
    if ($r.Required) { $warnings += ("Windows still reports a reboot pending (" + $r.Reason + "); another restart is needed") }
    if ($restarted.Count) { $warnings += ("started again after the change: " + ($restarted -join ", ")) }
    $build = (Get-Build).Build
    $res = @{ missing_services = $down; restarted_services = $restarted; updates_installed = $check.installed
              updates_not_installed = $check.not_installed; warnings = $warnings; build = $build; uptime_minutes = $upMin }
    if ($errors.Count) {
        $res.errors = $errors
        return @{ ok = $false; result = $res; message = ($errors -join "; ") }
    }
    if ($down.Count) {
        # Patched; only services are down. Reported in the form PATCH-01 shows as
        # "done, with warnings": a service is for the operator to start, not a failed patch.
        $res.errors = @("not running any more: " + ($down -join ", "))
        return @{ ok = $false; result = $res; message = ("patched, build " + $build + "; services not running: " + ($down -join ", ")) }
    }
    $res.errors = @()
    return @{ ok = $true; result = $res
              message = ("postcheck passed, build " + $build + $(if ($warnings.Count) { "; " + ($warnings -join "; ") } else { "" })) }
}

# ---------------------------------------------------------------------------
# Software from the catalog: install, upgrade or remove one approved installer
# ---------------------------------------------------------------------------
$SwUnc = '^\\\\([A-Za-z0-9][A-Za-z0-9.-]{0,252})\\([A-Za-z0-9$_.-]{1,80})((\\[A-Za-z0-9 _.()+-]{1,120}){1,12})$'
$SwArgs = '^[A-Za-z0-9 /\\_.:=,+()\-"]{0,300}$'
$SwGuid = '^\{[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}$'

function Get-InstalledProgram([string]$Name) {
    # Programs and Features entries whose name is, or starts with, the catalog's name
    $hits = @()
    foreach ($root in @("HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
                        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*")) {
        foreach ($e in @(Get-ItemProperty -Path $root -ErrorAction SilentlyContinue)) {
            $dn = [string](Get-Prop $e "DisplayName")
            if ($dn -and ($dn -eq $Name -or $dn.StartsWith($Name, [StringComparison]::OrdinalIgnoreCase))) {
                $hits += [pscustomobject]@{ Name = $dn; Version = [string](Get-Prop $e "DisplayVersion"); Key = [string]$e.PSChildName
                                            Uninstall = [string](Get-Prop $e "UninstallString") }
            }
        }
    }
    return ,$hits
}

function Test-VersionMatch([string]$Have, [string]$Want) {
    if (-not $Have) { return $false }
    if ($Have -eq $Want) { return $true }
    # 23.01 and 23.01.00.0 are the same release
    return ($Have.StartsWith($Want + ".") -or $Want.StartsWith($Have + "."))
}

function Get-ShareCredential($Token, [string]$CommandId) {
    $r = Invoke-Api "GET" ("/api/v1/agent/commands/" + $CommandId + "/credential") $null $Token
    $sec = ConvertTo-SecureString ([string]$r.password) -AsPlainText -Force
    $r.password = $null
    return New-Object Management.Automation.PSCredential([string]$r.username, $sec)
}

function Invoke-SoftwareAction($Params, $Token, [string]$CommandId) {
    $action = [string](Get-Prop $Params "action"); $kind = [string](Get-Prop $Params "kind")
    $unc = [string](Get-Prop $Params "unc_path"); $want = [string](Get-Prop $Params "sha256")
    $detect = [string](Get-Prop $Params "detect_name"); $ver = [string](Get-Prop $Params "version")
    $pcode = [string](Get-Prop $Params "product_code"); $iargs = [string](Get-Prop $Params "install_args")
    $uargs = [string](Get-Prop $Params "uninstall_args"); $pub = [string](Get-Prop $Params "publisher")
    $needSig = [bool](Get-Prop $Params "require_signature")
    # Check again here what PATCH-01 sent: nothing reaches a command line unchecked
    if ($action -notin @("install", "upgrade", "uninstall")) { return @{ ok = $false; message = "unknown action"; result = @{} } }
    if ($kind -notin @("msi", "exe")) { return @{ ok = $false; message = "unknown installer type"; result = @{} } }
    if ($unc -notmatch $SwUnc -or $unc.Contains("..")) { return @{ ok = $false; message = "the share path was refused"; result = @{} } }
    if ($want -notmatch '^[0-9a-f]{64}$') { return @{ ok = $false; message = "the SHA-256 was refused"; result = @{} } }
    if ($kind -eq "msi" -and $pcode -notmatch $SwGuid) { return @{ ok = $false; message = "the product code was refused"; result = @{} } }
    if ($iargs -notmatch $SwArgs -or $uargs -notmatch $SwArgs) { return @{ ok = $false; message = "the installer options were refused"; result = @{} } }
    if (-not $detect) { return @{ ok = $false; message = "no name to recognise the program by"; result = @{} } }

    $before = @(Get-InstalledProgram $detect)
    $have = $null; if ($before.Count -gt 0) { $have = $before[0].Version }
    $res = @{ action = $action; before = $have; reboot_required = $false; nothing_to_do = $false }
    if ($action -eq "install" -and $before.Count -gt 0 -and (Test-VersionMatch $have $ver)) {
        $res.nothing_to_do = $true; return @{ ok = $true; message = ("already installed: " + $have); result = $res } }
    if ($action -eq "upgrade" -and $before.Count -eq 0) {
        return @{ ok = $false; message = ("not installed here, so nothing to upgrade (use install): " + $detect); result = $res } }
    if ($action -eq "upgrade" -and (Test-VersionMatch $have $ver)) {
        $res.nothing_to_do = $true; return @{ ok = $true; message = ("already on " + $have); result = $res } }
    if ($action -eq "uninstall" -and $before.Count -eq 0) {
        $res.nothing_to_do = $true; return @{ ok = $true; message = "not installed: nothing to remove"; result = $res } }

    $work = Join-Path $DataDir ("pkg\" + ($CommandId -replace '[^0-9a-f-]', ''))
    $log = Join-Path $DataDir ("pkg-" + ($CommandId -replace '[^0-9a-f-]', '') + ".log")
    try {
        New-Item -ItemType Directory -Force -Path $work | Out-Null
        $local = $null
        $needFile = -not ($action -eq "uninstall")
        if ($needFile) {
            # The share is reachable only with this job's credential, fetched once, kept in memory
            $null = $unc -match $SwUnc
            $root = "\\" + $Matches[1] + "\" + $Matches[2]; $rest = $Matches[3]
            $cred = Get-ShareCredential $Token $CommandId
            $drv = "PA" + ([guid]::NewGuid().ToString("N").Substring(0, 6))
            try {
                New-PSDrive -Name $drv -PSProvider FileSystem -Root $root -Credential $cred -ErrorAction Stop | Out-Null
                $local = Join-Path $work (Split-Path -Leaf $unc)
                Copy-Item -LiteralPath ($drv + ":" + $rest) -Destination $local -ErrorAction Stop
            } catch {
                return @{ ok = $false; message = ("could not copy the installer from the share: " + $_.Exception.Message); result = $res }
            } finally {
                Remove-PSDrive -Name $drv -Force -ErrorAction SilentlyContinue
                $cred = $null
            }
            $got = (Get-FileHash -Algorithm SHA256 -LiteralPath $local).Hash.ToLowerInvariant()
            if ($got -ne $want) {
                return @{ ok = $false; message = ("the installer's SHA-256 is " + $got + ", not the approved one: nothing was run"); result = $res } }
            if ($needSig) {
                $sig = Get-AuthenticodeSignature -LiteralPath $local
                if ($sig.Status -ne "Valid") {
                    return @{ ok = $false; message = ("the installer's signature is " + $sig.Status + ": nothing was run"); result = $res } }
                if ($sig.SignerCertificate.Subject -ne $pub) {
                    return @{ ok = $false; message = ("signed by '" + $sig.SignerCertificate.Subject + "', not the approved publisher: nothing was run"); result = $res } }
            }
        }
        # Fixed templates; started directly, never through cmd
        if ($kind -eq "msi") {
            $exe = Join-Path $env:SystemRoot "System32\msiexec.exe"
            if ($action -eq "uninstall") { $argline = "/x " + $pcode + " /qn /norestart /l*v `"" + $log + "`"" }
            else { $argline = "/i `"" + $local + "`" /qn /norestart /l*v `"" + $log + "`"" }
        } elseif ($action -eq "uninstall") {
            $u = $before[0].Uninstall
            if ($u -match '^"([^"]+\.exe)"') { $exe = $Matches[1] } elseif ($u -match '^(.+?\.exe)') { $exe = $Matches[1] } else { $exe = "" }
            # "MsiExec.exe /X{...}" names no path: an MSI-based program is removed by its product code
            $isMsi = ($exe -and (Split-Path -Leaf $exe) -ieq "msiexec.exe")
            if (-not $isMsi -and (-not $exe -or -not (Test-Path -LiteralPath $exe))) {
                return @{ ok = $false; message = "the program's own uninstaller was not found"; result = $res } }
            if ($isMsi) {
                $exe = Join-Path $env:SystemRoot "System32\msiexec.exe"
                $argline = "/x " + $before[0].Key + " /qn /norestart /l*v `"" + $log + "`""
                if ($before[0].Key -notmatch $SwGuid) { return @{ ok = $false; message = "the program's MSI code was not recognised"; result = $res } }
            } else { $argline = $uargs }
        } else {
            $exe = $local; $argline = $iargs
        }
        # Start-Process refuses an empty argument list, so options go in only when there are some
        $sp = @{ FilePath = $exe; PassThru = $true; WindowStyle = "Hidden" }
        if ($argline) { $sp["ArgumentList"] = $argline }
        $p = Start-Process @sp
        $null = $p.Handle          # PowerShell 5.1 loses the exit code of a -PassThru process unless its handle is held
        if (-not $p.WaitForExit(10200000)) {                 # 2 h 50 min, under PATCH-01's 3 h limit
            try { $p.Kill() } catch { }
            return @{ ok = $false; message = "the installer did not finish within 2 h 50 min and was stopped"; result = $res }
        }
        $p.WaitForExit()           # the timed wait can return before the exit code is filled in
        $code = $p.ExitCode
        if ($null -eq $code) { return @{ ok = $false; message = "the installer finished but Windows gave no exit code; check the program and run the job again"; result = $res } }
        $code = [int]$code; $res.exit_code = $code
        if ($code -eq 3010 -or $code -eq 1641) { $res.reboot_required = $true }
        elseif ($code -ne 0) {
            return @{ ok = $false; message = ("the installer ended with code " + $code + $(if ($kind -eq "msi") { " (MSI log: " + $log + ")" } else { "" })); result = $res } }
        # Prove it: the program is there in the expected version, or gone
        $after = @(Get-InstalledProgram $detect)
        $res.after = $null; if ($after.Count -gt 0) { $res.after = $after[0].Version }
        if ($action -eq "uninstall") {
            if ($after.Count -gt 0 -and -not $res.reboot_required) {
                return @{ ok = $false; message = ("the installer finished but " + $after[0].Name + " is still listed"); result = $res } }
            return @{ ok = $true; message = ("removed " + $detect + $(if ($res.reboot_required) { "; a reboot completes it" } else { "" })); result = $res }
        }
        if ($after.Count -eq 0) { return @{ ok = $false; message = ("the installer finished but " + $detect + " is not listed"); result = $res } }
        if (-not (Test-VersionMatch $after[0].Version $ver)) {
            return @{ ok = $false; message = ("installed, but it reports version " + $after[0].Version + ", not " + $ver); result = $res } }
        return @{ ok = $true; message = ($action + " done: " + $after[0].Name + " " + $after[0].Version + $(if ($res.reboot_required) { "; a reboot is needed" } else { "" })); result = $res }
    } finally {
        Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Send-LogTail($Token) {
    <# Sends the log lines written since the last send, so failures can be read
       in the console. Never lets a problem here break a run, and never logs
       about itself (that would feed its own output). #>
    try {
        if (-not (Test-Path $LogFile)) { return }
        $state = Get-State
        $off = [long]0
        if ($state.PSObject.Properties["log_offset"] -and $state.log_offset) { $off = [long]$state.log_offset }
        $len = (Get-Item $LogFile).Length
        if ($len -lt $off) { $off = 0 }                       # the log was rotated
        if ($len -eq $off) { return }
        if ($len - $off -gt 262144) { $off = $len - 262144 }  # at most the last 256 KB
        $fs = [IO.File]::Open($LogFile, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
        try {
            [void]$fs.Seek($off, [IO.SeekOrigin]::Begin)
            $text = (New-Object IO.StreamReader($fs, [Text.Encoding]::UTF8)).ReadToEnd()
        } finally { $fs.Dispose() }
        $lines = @()
        foreach ($l in ($text -split "`r?`n")) {
            if ($l -match '^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d) (?:(INFO|WARN|ERROR) )?(.+)$') {
                $at = [datetime]::ParseExact($Matches[1], "yyyy-MM-dd HH:mm:ss", [Globalization.CultureInfo]::InvariantCulture)
                $lvl = "INFO"; if ($Matches[2]) { $lvl = $Matches[2] }
                $msg = $Matches[3]; if ($msg.Length -gt 2000) { $msg = $msg.Substring(0, 2000) }
                $lines += @{ at = (Get-IsoUtc $at); level = $lvl; msg = $msg }
            }
        }
        if ($lines.Count -gt 500) { $lines = $lines[($lines.Count - 500)..($lines.Count - 1)] }
        if ($lines.Count -gt 0) { Invoke-Api "POST" "/api/v1/agent/log" @{ lines = $lines } $Token | Out-Null }
        $state = Get-State
        if ($state.PSObject.Properties["log_offset"]) { $state.log_offset = $len } else { $state | Add-Member -NotePropertyName log_offset -NotePropertyValue $len }
        Save-State $state
    } catch { Write-Verbose ("log send failed: " + $_.Exception.Message) }
}

function Send-Result($Token, [string]$CommandId, $Body) {
    # A lost result leaves PATCH-01 waiting: retry, and log if it still fails
    for ($i = 1; $i -le 3; $i++) {
        try { Invoke-Api "POST" ("/api/v1/agent/commands/" + $CommandId + "/result") $Body $Token | Out-Null; return $true }
        catch {
            Write-Log ("sending the result of command " + $CommandId + " failed (try " + $i + " of 3): " + $_.Exception.Message) "ERROR"
            Start-Sleep -Seconds (5 * $i)
        }
    }
    return $false
}

function Invoke-Commands($Token) {
    # PowerShell 5.1 returns a JSON list from Invoke-RestMethod as ONE object
    # (the whole list), not one item per command. Sending it through the
    # pipeline unrolls it, whichever way it came back.
    $cmds = @(@(Invoke-Api "GET" "/api/v1/agent/commands" $null $Token) | ForEach-Object { $_ } | Where-Object { $null -ne $_ })
    $ranInventory = $false; $count = 0; $rebooting = $false
    if ($cmds.Count -gt 0) { Write-Log ("received " + $cmds.Count + " command(s) from PATCH-01") }
    foreach ($c in $cmds) {
        if (-not $c.PSObject.Properties["id"] -or -not $c.PSObject.Properties["verb"]) {
            # Never skip silently: say so, and answer if there is an id to answer to
            Write-Log ("a command could not be read and was not run: " + (ConvertTo-Json -InputObject $c -Compress -Depth 3)) "ERROR"
            if ($c.PSObject.Properties["id"]) {
                [void](Send-Result $Token ([string]$c.id) @{ ok = $false; message = "the Windows agent could not read this command"; result = @{} })
            }
            continue
        }
        $count++
        $ok = $true; $msg = $null; $res = @{}
        $t0 = Get-Date
        Write-Log ("command " + $c.verb + " started (" + $c.id + ")")
        try {
            $params = Get-Prop $c "params"
            $out = $null
            switch ($c.verb) {
                "collect_inventory" { Send-Inventory $Token; $ranInventory = $true; $msg = "inventory sent" }
                "run_precheck"      { $out = Invoke-Precheck $params $Token }
                "install_packages"  { $out = Invoke-InstallUpdates $params $Token }
                "reboot_host"       { $out = Invoke-Reboot $params }
                "run_postcheck"     { $out = Invoke-Postcheck $params }
                "software_action"   { $out = Invoke-SoftwareAction $params $Token ([string]$c.id) }
                default { $ok = $false; $msg = "'" + $c.verb + "' is not supported by the Windows agent" }
            }
            if ($null -ne $out) { $ok = [bool]$out.ok; $msg = [string]$out.message; $res = $out.result }
        } catch {
            $ok = $false
            $msg = [string]$_.Exception.Message
            $where = ""; if ($_.InvocationInfo) { $where = " (line " + $_.InvocationInfo.ScriptLineNumber + ")" }
            Write-Log ("command " + $c.verb + " threw: " + $msg + $where) "ERROR"
        }
        $secs = [int]((Get-Date) - $t0).TotalSeconds
        Write-Log ("command {0} {1} in {2} s: {3}" -f $c.verb, $(if ($ok) { "ok" } else { "failed" }), $secs, $msg) $(if ($ok) { "INFO" } else { "WARN" })
        [void](Send-Result $Token ([string]$c.id) @{ ok = $ok; message = $msg; result = $res })
        Send-LogTail $Token
        if ($c.verb -eq "reboot_host" -and $ok) { $rebooting = $true }
    }
    return @{ inventory = $ranInventory; count = $count; rebooting = $rebooting }
}

# ---------------------------------------------------------------------------
# Modes
# ---------------------------------------------------------------------------
function Start-Run {
    # One run at a time: a slow Windows Update search must not overlap the next
    $mutex = New-Object Threading.Mutex($false, "Global\PatchAgentRun")
    $owned = $false
    try { $owned = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owned = $true }   # the last run was killed
    if (-not $owned) {
        $mutex.Dispose()
        if ($Inventory) { throw "another agent run is in progress; try again in a few minutes" }
        Write-Log "previous run still busy; skipping"; return
    }
    $tok = $null
    try {
        $cfg = Get-Config
        Initialize-Http $cfg.pin
        $tok = Get-Token
        Send-Checkin $tok
        # PATCH-01 queues a job's next step as soon as the last one reports, so ask
        # again straight away instead of waiting for the next 5-minute run
        $done = $false
        # -Inventory (used by the installer to prove the agent works) only reports: it never
        # runs a queued job step in an administrator's window
        for ($round = 0; $round -lt 12 -and -not $Inventory; $round++) {
            $r = Invoke-Commands $tok
            if ($r.inventory) { $done = $true }
            if ($r.count -eq 0 -or $r.rebooting) { break }
            Start-Sleep -Seconds 10
        }
        $state = Get-State
        if (-not $state.PSObject.Properties["last_inventory"]) { $state | Add-Member -NotePropertyName last_inventory -NotePropertyValue $null }
        $due = $true
        if ($state.last_inventory) {
            $due = ((Get-Date) - [datetime]$state.last_inventory).TotalHours -ge $InventoryEveryHours
        }
        if ($Inventory -or ($due -and -not $done)) { Send-Inventory $tok; $done = $true }
        if ($done) { $state.last_inventory = (Get-Date).ToString("o"); Save-State $state }
    } catch {
        $where = ""; if ($_.InvocationInfo) { $where = " (line " + $_.InvocationInfo.ScriptLineNumber + ")" }
        Write-Log ("run failed: " + $_.Exception.Message + $where) "ERROR"
        throw
    } finally {
        # Whatever happened, the console gets this run's log lines
        try { if ($tok) { Send-LogTail $tok } } catch { }
        if ($owned) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}

function Start-Enroll {
    Assert-Https $Server
    if (-not (Test-Path $DataDir)) { New-Item -ItemType Directory -Path $DataDir | Out-Null }
    $script:Cfg = [pscustomobject]@{ server = $Server.TrimEnd("/"); pin = $Pin.Trim().ToLowerInvariant() }
    Initialize-Http $script:Cfg.pin
    $f = Get-Facts
    $body = @{ enrollment_token = $Token; machine_id = $f.MachineId; hostname = $f.Hostname; os_id = "windows"
               os_version = $f.Version; arch = "x86_64"; pkg_manager = "wua"; agent_version = $AgentVersion }
    if ($f.Fqdn -and $f.Fqdn -ne $f.Hostname) { $body["fqdn"] = $f.Fqdn }
    $resp = Invoke-Api "POST" "/api/v1/agent/enroll" $body
    ConvertTo-Json -InputObject @{ server = $script:Cfg.server; pin = $script:Cfg.pin; host_id = $resp.host_id } | Set-Content -Path $ConfigFile -Encoding UTF8
    Save-Token $resp.agent_token
    Write-Log ("enrolled as {0} ({1})" -f $f.Hostname, $resp.host_id)
    Write-Output ("Enrolled {0} with PATCH-01. Host id {1}." -f $f.Hostname, $resp.host_id)
}

function Start-SelfTest {
    Assert-Https $Server
    $results = New-Object Collections.ArrayList
    function Step([string]$Name, [scriptblock]$Do) {
        try { $d = & $Do; [void]$results.Add([pscustomobject]@{ Step = $Name; Result = "ok"; Detail = [string]$d }) }
        catch { [void]$results.Add([pscustomobject]@{ Step = $Name; Result = "FAILED"; Detail = $_.Exception.Message }) }
    }
    $script:Cfg = [pscustomobject]@{ server = $Server.TrimEnd("/"); pin = $Pin.Trim().ToLowerInvariant() }
    Step "Run as administrator" { $id = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
                                  if (-not $id.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw "run PowerShell as administrator" }; "yes" }
    Step "PowerShell version" { if ($PSVersionTable.PSVersion.Major -lt 5) { throw ("5.1 needed, found " + $PSVersionTable.PSVersion) }; [string]$PSVersionTable.PSVersion }
    Step "Reach PATCH-01, certificate pin" { Initialize-Http $script:Cfg.pin; $h = Invoke-Api "GET" "/api/v1/health"; "reached; certificate " + [PatchAgentPin]::Seen.Substring(0, 16) + "... matches" }
    Step "OS build" { $b = Get-Build; "{0} ({1}), Windows Server {2}" -f $b.Build, $b.Product, (Get-ServerVersion $b) }
    Step "Reboot state" { $r = Get-RebootState; if ($r.Required) { "reboot pending: " + $r.Reason } else { "no reboot pending" } }
    Step "Hardware ID (links the VM)" { $f = Get-Facts; if ($f.Uuid) { $f.Uuid } else { throw "no usable UUID from Win32_ComputerSystemProduct" } }
    Step "Installed updates" { "{0} KBs" -f @(Get-HotFix -ErrorAction SilentlyContinue).Count }
    Step "Update source" { $s = Get-WsusSource; if ($s.Source -eq "wsus") { "WSUS at " + $s.Server } else { "Microsoft Update directly (no WSUS policy found)" } }
    Step "Windows Update search" { $u = Search-MissingUpdates; "{0} updates missing" -f $u.Count }
    $results | Format-Table -AutoSize -Wrap | Out-String -Width 200 | Write-Output
    $failed = @($results | Where-Object { $_.Result -ne "ok" }).Count
    if ($failed) { Write-Output "$failed step(s) failed: fix them before enrolling." } else { Write-Output "All steps passed: this server is ready to enrol." }
}

switch ($PSCmdlet.ParameterSetName) {
    "SelfTest"  { Start-SelfTest }
    "Enroll"    { Start-Enroll }
    "Inventory" { Start-Run }
    default     { Start-Run }
}
