#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# MONITOR-01: VM monitoring from vCenter (nothing installed in the VMs).
# A system of its own: own containers, database, key, certificate and address.
# Today it can run on the PATCH-01 server; later it moves to its own server
# with --backup here and --restore there.
#
#   ./monitor01.sh install [--port 9443] [--name monitor.corp.local] [--bind IP]
#                                      build, deploy, update the schema (re-run safe)
#   ./monitor01.sh --link-patch01 https://patch01.corp.local
#                                      sign in with PATCH-01 accounts (trusts its certificate)
#   ./monitor01.sh --patch01-service USER
#                                      optional: a PATCH-01 viewer account (patch module) used
#                                      only to show each VM's patch status
#   ./monitor01.sh --local-admin NAME  the break-glass admin (works when PATCH-01 is down)
#   ./monitor01.sh --cert FILE --key FILE
#                                      use your own certificate instead of the self-signed one
#   ./monitor01.sh --check             is everything running, is vCenter being read
#   ./monitor01.sh --logs [api|collector|web|db]
#   ./monitor01.sh --down              stop MONITOR-01 (data kept)
#   ./monitor01.sh --backup [DIR]      database and /etc/monitor01, for moving or safe keeping
#   ./monitor01.sh --restore FILE      load a --backup into a fresh install (the new server)
#   ./monitor01.sh --dry-run install   show the plan, change nothing
# ---------------------------------------------------------------------------
set -Eeuo pipefail
umask 027

APP="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"     # /opt/monitor01
ETC="/etc/monitor01"
DATA="/srv/monitor01"
LOG_DIR="/var/log/monitor01"
COMPOSE="$DATA/compose/docker-compose.yml"
VERSION="$(tr -d '[:space:]' <"$APP/VERSION" 2>/dev/null || echo dev)"
API_IMAGE="monitor01/api:$VERSION"
PORT=""; NAME=""; BIND=""; DRY=no; CMD=""; ARG=""; CERT=""; KEY=""

while (($#)); do
  case "$1" in
    install)            CMD=install ;;
    --port)             PORT="${2:?}"; shift ;;
    --name)             NAME="${2:?}"; shift ;;
    --bind)             BIND="${2:?}"; shift ;;
    --dry-run)          DRY=yes ;;
    --link-patch01)     CMD=link; ARG="${2:?give the PATCH-01 URL, e.g. https://patch01.corp.local}"; shift ;;
    --patch01-service)  CMD=service; ARG="${2:?give the PATCH-01 account name}"; shift ;;
    --local-admin)      CMD=localadmin; ARG="${2:?give a name, e.g. monadmin}"; shift ;;
    --local-disable)    CMD=localdisable; ARG="${2:?}"; shift ;;
    --cert)             CMD=cert; CERT="${2:?}"; shift ;;
    --key)              KEY="${2:?}"; shift ;;
    --check)            CMD=check ;;
    --logs)             CMD=logs; ARG="${2:-}"; [[ $# -gt 1 ]] && shift ;;
    --down)             CMD=down ;;
    --backup)           CMD=backup; ARG="${2:-/var/backups/monitor01}"; [[ $# -gt 1 ]] && shift ;;
    --restore)          CMD=restore; ARG="${2:?give the backup file}"; shift ;;
    -h|--help)          sed -n '2,26p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1 (see --help)" >&2; exit 2 ;;
  esac
  shift
done
[[ -n "$CMD" ]] || { sed -n '2,26p' "$0"; exit 2; }

mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/monitor01-$(date +%Y%m%d-%H%M%S).log"; : >"$LOG"; chmod 0600 "$LOG"
log()  { printf '%s  %s\n' "$(date '+%F %T')" "$*" >>"$LOG"; }
say()  { printf '%s\n' "$*"; log "OUT: $*"; }
step() { printf '\n==> %s\n' "$*"; log "STEP: $*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; log "WARN: $*"; }
die()  { log "FATAL: $1"; printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG" >&2; exit 1; }
run()  { log "RUN: $*"; if [[ $DRY == yes ]]; then say "[dry-run] $*"; else "$@" >>"$LOG" 2>&1; fi; }

[[ $EUID -eq 0 ]] || die "Run as root."
command -v docker >/dev/null || die "Docker is not installed."
docker compose version >/dev/null 2>&1 || die "The docker compose plugin is missing."

setting() { grep -E "^$1=" "$ETC/monitor.env" 2>/dev/null | tail -1 | cut -d= -f2- || true; }
set_setting() {   # set_setting KEY VALUE   (in monitor.env)
  local k="$1" v="$2"
  [[ "$v" != *$'\n'* ]] || die "bad value for $k"
  touch "$ETC/monitor.env"
  grep -vE "^$k=" "$ETC/monitor.env" >"$ETC/monitor.env.new" || true
  printf '%s=%s\n' "$k" "$v" >>"$ETC/monitor.env.new"
  chmod 0600 "$ETC/monitor.env.new"; mv "$ETC/monitor.env.new" "$ETC/monitor.env"
}
in_api() { docker exec -i mon01-api "$@"; }
# The database password goes to psql through the environment (-e NAME without a value), never on a command line
dbpw() { PGPASSWORD="$(grep -E '^MON_DB_PASSWORD=' "$ETC/api-db.env" | cut -d= -f2-)"; export PGPASSWORD; }
dbq() { dbpw; docker exec -i -e PGPASSWORD mon01-db psql -h 127.0.0.1 -U monitor -d monitor -v ON_ERROR_STOP=1 -qtAX "$@"; }
up() { docker compose -p monitor01 -f "$COMPOSE" up -d "$@" >>"$LOG" 2>&1; }

# The certificate a server presents, as SHA-256 (64 hex), read with openssl
pin_of() {   # pin_of HOST PORT
  echo | timeout 15 openssl s_client -connect "$1:$2" -servername "$1" 2>/dev/null \
    | openssl x509 -outform DER 2>/dev/null | sha256sum | cut -d' ' -f1 || true
}

wait_healthy() {   # wait_healthy CONTAINER SECONDS
  local c="$1" n="${2:-120}" s
  for ((i = 0; i < n; i += 3)); do
    s="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "$c" 2>/dev/null || echo missing)"
    [[ "$s" == healthy ]] && return 0
    sleep 3
  done
  return 1
}

# ---- images: MONITOR-01's own list; on a PATCH-01 server, the images PATCH-01 already has -----
images() {
  local list="$ETC/images.env"
  if [[ ! -f "$list" && $DRY == yes ]]; then
    list=/etc/patch-platform/images.env; [[ -f "$list" ]] || die "No image list ($ETC/images.env, or PATCH-01's)."
  elif [[ ! -f "$list" ]]; then
    install -d -m 0750 "$ETC"
    [[ -f /etc/patch-platform/images.env ]] || die "No image list. Create $ETC/images.env with IMG_POSTGRES, IMG_NGINX and IMG_PYTHON (see README.md)."
    grep -E '^(IMG_(POSTGRES|NGINX|PYTHON)(_VARIANT)?|PG_(DATA_PATH|DATA_SUBDIR|ENV_PREFIX|UID|GID)|NGINX_UID)=' /etc/patch-platform/images.env >"$ETC/images.env" || true
    say "Image list copied from PATCH-01's (the same images, already on this server): $ETC/images.env"
  fi
  # shellcheck disable=SC1090
  source "$list"
  PG_IMAGE="${IMG_POSTGRES:-}"; NGINX_IMAGE="${IMG_NGINX:-}"; PY_IMAGE="${IMG_PYTHON:-}"
  [[ -n "$PG_IMAGE" && -n "$NGINX_IMAGE" && -n "$PY_IMAGE" ]] || die "$ETC/images.env must name IMG_POSTGRES, IMG_NGINX and IMG_PYTHON."
  for i in "$PG_IMAGE" "$NGINX_IMAGE" "$PY_IMAGE"; do
    docker image inspect "$i" >/dev/null 2>&1 || die "Image $i is not on this server: docker pull it (or load it) first."
  done
  PG_DATA_PATH="${PG_DATA_PATH:-/var/lib/postgresql/data}"; PG_DATA_SUBDIR="${PG_DATA_SUBDIR:-pgdata}"
  PG_ENV_PREFIX="${PG_ENV_PREFIX:-POSTGRES}"; PG_UID="${PG_UID:-999}"; PG_GID="${PG_GID:-999}"
}

secrets() {
  install -d -m 0750 "$ETC" "$ETC/tls" "$DATA" "$DATA/compose"
  install -d -m 0700 "$DATA/pgdata"
  chown "$PG_UID:$PG_GID" "$DATA/pgdata"
  if [[ ! -s "$ETC/db.env" ]]; then
    local pw; pw="$(openssl rand -hex 24)"
    if [[ "$PG_ENV_PREFIX" == POSTGRESQL ]]; then
      printf 'POSTGRESQL_USER=monitor\nPOSTGRESQL_PASSWORD=%s\nPOSTGRESQL_DATABASE=monitor\n' "$pw" >"$ETC/db.env"
    else
      printf 'POSTGRES_USER=monitor\nPOSTGRES_PASSWORD=%s\nPOSTGRES_DB=monitor\n' "$pw" >"$ETC/db.env"
    fi
    printf 'MON_DB_PASSWORD=%s\n' "$pw" >"$ETC/api-db.env"
    chmod 0600 "$ETC/db.env" "$ETC/api-db.env"
    say "Database password made (only in $ETC/db.env and api-db.env)."
  fi
  if [[ ! -s "$ETC/monitor.key" ]]; then
    openssl rand -base64 32 | tr '+/' '-_' >"$ETC/monitor.key"
    say "monitor.key made: it encrypts the vCenter passwords. Keep a copy with the backups."
  fi
  chown 1001:0 "$ETC/monitor.key"; chmod 0440 "$ETC/monitor.key"
  [[ -e "$ETC/patch01-svc.pass" ]] || : >"$ETC/patch01-svc.pass"
  chown 1001:0 "$ETC/patch01-svc.pass"; chmod 0440 "$ETC/patch01-svc.pass"
  if [[ ! -s "$ETC/tls/monitor.crt" ]]; then
    local cn="${NAME:-$(hostname -f 2>/dev/null || hostname)}" san ips
    san="DNS:$cn,DNS:$(hostname -s)"
    for ips in $(hostname -I 2>/dev/null); do [[ "$ips" == *:* ]] || san="$san,IP:$ips"; done
    openssl req -x509 -newkey rsa:3072 -sha256 -days 825 -nodes -subj "/CN=$cn/O=MONITOR-01" -addext "subjectAltName=$san" \
      -keyout "$ETC/tls/monitor.key" -out "$ETC/tls/monitor.crt" >>"$LOG" 2>&1 || die "Could not make the certificate."
    say "Self-signed certificate made for $cn ($san). Replace it with your CA's: ./monitor01.sh --cert FILE --key FILE"
  fi
  chown root:0 "$ETC/tls/monitor.key" "$ETC/tls/monitor.crt"; chmod 0640 "$ETC/tls/monitor.key"; chmod 0644 "$ETC/tls/monitor.crt"
  touch "$ETC/monitor.env"; chmod 0600 "$ETC/monitor.env"
  set_setting MON_VERSION "$VERSION"
  [[ -n "$(setting MON_DB_HOST)" ]] || set_setting MON_DB_HOST mon01-db
}

write_compose() {
  local port="${PORT:-$(setting MON_PORT)}"; port="${port:-9443}"
  [[ "$port" =~ ^[0-9]+$ ]] && ((port > 0 && port < 65536)) || die "Bad port: $port"
  local bind="${BIND:-$(setting MON_BIND)}"
  set_setting MON_PORT "$port"; [[ -n "$bind" ]] && set_setting MON_BIND "$bind"
  local name="${NAME:-$(setting MON_NAME)}"; name="${name:-$(hostname -f 2>/dev/null || hostname)}"
  set_setting MON_NAME "$name"; set_setting MON_PUBLIC_URL "https://$name:$port"
  sed -e "s|@@PG_IMAGE@@|$PG_IMAGE|g" -e "s|@@NGINX_IMAGE@@|$NGINX_IMAGE|g" -e "s|@@API_IMAGE@@|$API_IMAGE|g" \
      -e "s|@@PG_UID@@|$PG_UID|g" -e "s|@@PG_GID@@|$PG_GID|g" -e "s|@@PG_DATA_PATH@@|$PG_DATA_PATH|g" \
      -e "s|@@PG_DATA_SUBDIR@@|$PG_DATA_SUBDIR|g" -e "s|@@ETC@@|$ETC|g" -e "s|@@DATA@@|$DATA|g" -e "s|@@APP@@|$APP|g" \
      -e "s|@@PORT@@|$port|g" -e "s|@@BIND@@|${bind:+$bind:}|g" "$APP/compose/docker-compose.yml.tmpl" >"$COMPOSE.new"
  ! grep -q '@@' "$COMPOSE.new" || die "Template placeholder left in the compose file."
  mv "$COMPOSE.new" "$COMPOSE"
  PORT="$port"; NAME="$name"
}

migrate() {
  step "Database schema"
  for f in "$APP"/sql/*.sql; do
    dbq --single-transaction <"$f" >>"$LOG" 2>&1 || die "Schema file $(basename "$f") failed (details in the log)."
    log "applied $(basename "$f")"
  done
  say "Schema version $(dbq -c 'SELECT max(version) FROM schema_version' </dev/null)."
}

do_install() {
  step "MONITOR-01 $VERSION: checks"
  images
  say "Images: $PG_IMAGE, $NGINX_IMAGE, $PY_IMAGE"
  if [[ $DRY == yes ]]; then
    say "[dry-run] would make $ETC (keys, certificate), $DATA, build $API_IMAGE, start mon01-db, mon01-api, mon01-collector, mon01-web on port ${PORT:-9443}"
    exit 0
  fi
  secrets
  write_compose
  step "Building $API_IMAGE"
  docker build -t "$API_IMAGE" --build-arg "BASE_IMAGE=$PY_IMAGE" \
    --build-arg "HTTP_PROXY=${HTTP_PROXY:-${http_proxy:-}}" --build-arg "HTTPS_PROXY=${HTTPS_PROXY:-${https_proxy:-}}" \
    --build-arg "NO_PROXY=${NO_PROXY:-${no_proxy:-}}" "$APP/api" >>"$LOG" 2>&1 || die "The image build failed (pip needs the proxy or a mirror: see the log)."
  step "Starting the database"
  up mon01-db || die "mon01-db did not start."
  wait_healthy mon01-db 180 || die "mon01-db is not healthy: docker logs mon01-db"
  local pgv; pgv="$(dbq -c 'SHOW server_version_num' </dev/null || echo 0)"
  (( ${pgv:-0} >= 140000 )) || die "MONITOR-01 needs PostgreSQL 14 or newer (this image: ${pgv:-unknown}). Name another in $ETC/images.env."
  migrate
  step "Starting the API, the collector and the web server"
  up --force-recreate mon01-api mon01-collector mon01-web || die "The containers did not start (see the log)."
  wait_healthy mon01-api 120 || die "mon01-api is not healthy: docker logs mon01-api"
  wait_healthy mon01-web 90 || die "mon01-web is not healthy: docker logs mon01-web"
  if command -v firewall-cmd >/dev/null && firewall-cmd --state >/dev/null 2>&1; then
    firewall-cmd -q --permanent --add-port="$PORT/tcp" && firewall-cmd -q --reload || warn "Could not open $PORT/tcp in firewalld."
  fi
  step "Ready"
  say "MONITOR-01:   https://$NAME:$PORT/"
  say "Certificate:  SHA-256 $(openssl x509 -in "$ETC/tls/monitor.crt" -noout -fingerprint -sha256 | cut -d= -f2)"
  [[ -n "$(setting PATCH01_URL)" ]] || say "Next: ./monitor01.sh --link-patch01 https://<PATCH-01 address>   (sign-in with PATCH-01 accounts)"
  [[ -n "$(dbq -c 'SELECT 1 FROM local_users LIMIT 1' </dev/null)" ]] || say "Next: ./monitor01.sh --local-admin monadmin   (break-glass account)"
  say "Then, signed in as an admin: Admin > vCenter > add your vCenter (read-only account)."
}

do_link() {
  local url="${ARG%/}" host port pin ok
  [[ "$url" =~ ^https://([A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\])(:([0-9]{1,5}))?$ ]] || die "Give the URL as https://host or https://host:port"
  host="${BASH_REMATCH[1]}"; host="${host#[}"; host="${host%]}"; port="${BASH_REMATCH[3]:-443}"
  pin="$(pin_of "$host" "$port")" || pin=""
  [[ "$pin" =~ ^[0-9a-f]{64}$ && "$pin" != e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 ]] || die "No certificate read from $host:$port: check the address and that this server reaches it."
  say "PATCH-01 at $url presents the certificate:"
  echo | timeout 15 openssl s_client -connect "$host:$port" -servername "$host" 2>/dev/null | openssl x509 -noout -subject -issuer -enddate | sed 's/^/  /'
  say "  SHA-256 $(echo "$pin" | sed 's/../&:/g; s/:$//' | tr a-f A-F)"
  say "Compare it with PATCH-01's own: on PATCH-01 run  openssl x509 -in /patch/certs/patch01.crt -noout -fingerprint -sha256"
  read -r -p "Does it match? Type yes to trust it: " ok
  [[ "$ok" == yes ]] || die "Not linked."
  set_setting PATCH01_URL "$url"; set_setting PATCH01_PIN "$pin"
  if docker ps --format '{{.Names}}' | grep -qx mon01-api; then up --force-recreate mon01-api mon01-web || warn "Restart mon01-api and mon01-web by hand."; fi
  say "Linked. People now sign in to MONITOR-01 with their PATCH-01 account (admins, and users with the inventory or patch module)."
  say "When PATCH-01's certificate is renewed, run this again."
}

do_service() {
  [[ "$ARG" =~ ^[A-Za-z0-9._-]{1,64}$ ]] || die "Bad account name."
  [[ -n "$(setting PATCH01_URL)" ]] || die "Link PATCH-01 first: ./monitor01.sh --link-patch01 https://..."
  local pw
  say "In PATCH-01 make a viewer account $ARG with only the patch module (Admin > Users). It is used only to read patch status."
  read -r -s -p "Its password: " pw; echo
  [[ -n "$pw" ]] || die "No password given."
  printf '%s\n' "$pw" >"$ETC/patch01-svc.pass"; chown 1001:0 "$ETC/patch01-svc.pass"; chmod 0440 "$ETC/patch01-svc.pass"
  set_setting PATCH01_SVC_USER "$ARG"
  up --force-recreate mon01-api mon01-web || warn "Restart mon01-api and mon01-web by hand."
  say "Saved. Each VM page now shows what PATCH-01 knows about it."
}

do_localadmin() {
  local p1 p2
  wait_healthy mon01-api 5 || die "MONITOR-01 is not running: ./monitor01.sh install"
  read -r -s -p "Password for local admin $ARG (14+ characters): " p1; echo
  read -r -s -p "Again: " p2; echo
  [[ "$p1" == "$p2" ]] || die "The two passwords differ."
  printf '%s\n' "$p1" | in_api python -m app.cli local-admin "$ARG" || die "Not saved."
}

do_cert() {
  [[ -r "$CERT" && -r "$KEY" ]] || die "Give both: --cert FILE --key FILE"
  openssl x509 -in "$CERT" -noout >/dev/null 2>&1 || die "$CERT is not a PEM certificate."
  [[ "$(openssl x509 -in "$CERT" -noout -pubkey | sha256sum)" == "$(openssl pkey -in "$KEY" -pubout 2>/dev/null | sha256sum)" ]] || die "The key does not belong to the certificate."
  install -m 0644 -o root -g 0 "$CERT" "$ETC/tls/monitor.crt"; install -m 0640 -o root -g 0 "$KEY" "$ETC/tls/monitor.key"
  docker restart mon01-web >>"$LOG" 2>&1 || true
  say "Certificate installed: $(openssl x509 -in "$ETC/tls/monitor.crt" -noout -subject -enddate | tr '\n' ' ')"
}

do_check() {
  local bad=0 c s
  for c in mon01-db mon01-api mon01-collector mon01-web; do
    s="$(docker inspect -f '{{.State.Status}}{{if .State.Health}} ({{.State.Health.Status}}){{end}}' "$c" 2>/dev/null || echo 'not there')"
    printf '  %-16s %s\n' "$c" "$s"
    [[ "$s" == "running (healthy)" ]] || bad=1
  done
  echo
  in_api python -m app.cli status 2>/dev/null || bad=1
  local port bind; port="$(setting MON_PORT)"; bind="$(setting MON_BIND)"
  curl -kfs "https://${bind:-127.0.0.1}:${port:-9443}/healthz" >/dev/null && say "  web answers on ${port:-9443}" || { say "  web does not answer on ${port:-9443}"; bad=1; }
  [[ -n "$(setting PATCH01_URL)" ]] && say "  sign-in through PATCH-01: $(setting PATCH01_URL)" || say "  sign-in through PATCH-01: not linked (--link-patch01)"
  ((bad == 0)) && say "OK" || { say "Something is not right (above)."; exit 1; }
}

do_backup() {
  install -d -m 0700 "$ARG"
  local f; f="$ARG/monitor01-$(date +%Y%m%d-%H%M%S).tar.gz"
  local t; t="$(mktemp -d)"; trap 'rm -rf "$t"' RETURN
  dbpw
  docker exec -e PGPASSWORD mon01-db pg_dump -h 127.0.0.1 -U monitor -d monitor -Fc >"$t/monitor.dump" || die "pg_dump failed."
  tar -C / -cf "$t/etc.tar" "${ETC#/}"
  tar -C "$t" -czf "$f" monitor.dump etc.tar; chmod 0600 "$f"
  say "Backup: $f   ($(du -h "$f" | cut -f1)). It holds monitor.key and the database: keep it as safe as a password."
}

do_restore() {
  [[ -r "$ARG" ]] || die "Cannot read $ARG"
  local t; t="$(mktemp -d)"; trap 'rm -rf "$t"' RETURN
  tar -C "$t" -xzf "$ARG" monitor.dump etc.tar || die "Not a MONITOR-01 backup."
  say "This replaces this MONITOR-01's database and settings with the backup's."
  wait_healthy mon01-db 30 || die "Install first (./monitor01.sh install): the database must be running to restore into."
  local ok; read -r -p "Type yes to go on: " ok; [[ "$ok" == yes ]] || die "Nothing changed."
  docker stop mon01-api mon01-collector mon01-web >>"$LOG" 2>&1 || true
  tar -C / -xf "$t/etc.tar" "${ETC#/}/monitor.key" "${ETC#/}/monitor.env" "${ETC#/}/patch01-svc.pass" 2>>"$LOG" || die "Could not restore $ETC."
  chown 1001:0 "$ETC/monitor.key" "$ETC/patch01-svc.pass"; chmod 0440 "$ETC/monitor.key" "$ETC/patch01-svc.pass"
  dbpw
  if ! docker exec -i -e PGPASSWORD mon01-db pg_restore -h 127.0.0.1 -U monitor -d monitor --clean --if-exists --no-owner <"$t/monitor.dump" >>"$LOG" 2>&1; then
    warn "pg_restore reported problems (details in $LOG)."
  fi
  [[ -n "$(dbq -c 'SELECT 1 FROM vcenters LIMIT 1' </dev/null 2>/dev/null)" ]] || die "The restored database holds no vCenter: the restore did not work (see $LOG)."
  say "Restored. Now run: ./monitor01.sh install   (it applies this version's schema and starts everything with the restored settings)"
  say "Point MONITOR-01's DNS name at this server, and PATCH01_URL still names PATCH-01: nothing else to change."
}

case "$CMD" in
  install)      do_install ;;
  link)         do_link ;;
  service)      do_service ;;
  localadmin)   do_localadmin ;;
  localdisable) printf '' | in_api python -m app.cli local-disable "$ARG" ;;
  cert)         do_cert ;;
  check)        do_check ;;
  logs)         docker logs --tail 200 -f "mon01-${ARG:-api}" ;;
  down)         docker compose -p monitor01 -f "$COMPOSE" down && say "Stopped (data kept in $DATA, settings in $ETC)." ;;
  backup)       do_backup ;;
  restore)      do_restore ;;
esac
