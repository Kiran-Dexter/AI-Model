#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Install this package on its server: PATCH-01 (patch01-rNN), AI-01 (ai01-rNN) or MONITOR-01 (monitor01-rNN).
#
#   sudo ./install.sh              check the files, install to /opt/<server>,
#                                  keep the previous version as /opt/<server>.prev,
#                                  then remove the unpacked package folders and tar files
#                                  (this one and older ones: /opt keeps one standard layout)
#   sudo ./install.sh --rollback   put /opt/<server>.prev back
#
# It only copies files. It does not restart or change anything that runs:
# README.md, section "Upgrading", lists the commands for that.
# ---------------------------------------------------------------------------
set -Eeuo pipefail
umask 022
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG="$(basename "$HERE")"                      # patch01-r98 / ai01-r98 / monitor01-r114
NAME="${PKG%-r*}"                              # patch01 / ai01 / monitor01
[[ "$NAME" == patch01 || "$NAME" == ai01 || "$NAME" == monitor01 ]] || { echo "Run this from the unpacked package folder (patch01-rNN, ai01-rNN or monitor01-rNN)." >&2; exit 1; }
ROOT_DIR="${PACKAGE_INSTALL_ROOT:-/opt}"      # /opt; the tests use a temporary folder
DEST="$ROOT_DIR/$NAME"; PREV="$ROOT_DIR/$NAME.prev"
[[ $EUID -eq 0 ]] || { echo "Run as root." >&2; exit 1; }

ask() { [[ "${YES:-no}" == yes ]] && return 0; local r; read -r -p "$1 [y/N]: " r || true; [[ "${r,,}" =~ ^(y|yes)$ ]]; }
YES=no; MODE=install
for a in "$@"; do case "$a" in --yes) YES=yes ;; --rollback) MODE=rollback ;; -h|--help) sed -n '2,12p' "$0"; exit 0 ;; *) echo "Unknown option: $a" >&2; exit 2 ;; esac; done

if [[ "$MODE" == rollback ]]; then
  [[ -d "$PREV" ]] || { echo "No previous version at $PREV." >&2; exit 1; }
  echo "Installed now: $(cat "$DEST/VERSION" 2>/dev/null || echo ?)   previous: $(cat "$PREV/VERSION" 2>/dev/null || echo ?)"
  ask "Put the previous version back in $DEST?" || exit 0
  rm -rf "$DEST.failed"; mv "$DEST" "$DEST.failed"; mv "$PREV" "$DEST"
  echo "Done: $DEST is $(cat "$DEST/VERSION"). The version you rolled back from is in $DEST.failed."
  echo "Now re-run the deploy steps of that version (its README.md, \"Upgrading\")."
  exit 0
fi

echo "Package: $PKG"
( cd "$HERE" && sha256sum -c --quiet MANIFEST.sha256 ) || { echo "Files do not match MANIFEST.sha256: the package is damaged. Nothing installed." >&2; exit 1; }
echo "  every file matches its checksum"
[[ -d "$DEST" ]] && echo "  installed now: $(cat "$DEST/VERSION" 2>/dev/null || echo 'unknown version') in $DEST"
ask "Install $PKG to $DEST?" || exit 0

rm -rf "$DEST.new"; mkdir -p "$DEST.new"
cp -a "$HERE"/. "$DEST.new"/
chown -R root:root "$DEST.new"; chmod -R go-w "$DEST.new"
( cd "$DEST.new" && sha256sum -c --quiet MANIFEST.sha256 ) || { rm -rf "$DEST.new"; echo "Copy failed its checksum test. Nothing changed." >&2; exit 1; }
if [[ -d "$DEST" ]]; then rm -rf "$PREV"; mv "$DEST" "$PREV"; fi
mv "$DEST.new" "$DEST"
if [[ -d "$PREV" ]]; then echo "  installed: $DEST ($(cat "$DEST/VERSION")); previous kept in $PREV"
else echo "  installed: $DEST ($(cat "$DEST/VERSION"))"; fi

# Boot services installed from an older location keep running the old copy
case "$NAME" in
  patch01) units="patch01-start"; how="$DEST/scripts/patch01-start.sh --install-boot" ;;
  ai01)    units="ai01-start";    how="$DEST/ai01-start.sh --install-boot" ;;
  *)       units="" ;;            # monitor01: Docker restarts its containers at boot
esac
for u in $units; do
  f="${PACKAGE_SYSTEMD_DIR:-/etc/systemd/system}/$u.service"
  if [[ -f "$f" ]] && ! grep -q "ExecStart=$DEST/" "$f"; then
    echo ""
    echo "  The boot service $u still runs the copy at: $(sed -n 's/^ExecStart=\([^ ]*\).*/\1/p' "$f")"
    echo "  Point it here with:  $how"
  fi
done
# One standard layout, whatever the version (r104): /opt/<server> (in use) and
# /opt/<server>.prev (rollback). An unpacked package (patch01-r103/) or its .tar.gz
# is only a way in: once installed, it is not needed. Only those exact names are
# touched, in /opt and where this package was unpacked; never /opt/<server>*.
LEFT=()
for dir in "$ROOT_DIR" "$(dirname "$HERE")"; do
  for f in "$dir"/"$NAME"-r*; do
    [[ -e "$f" ]] || continue
    b="$(basename "$f")"
    if [[ -d "$f" && "$b" =~ ^${NAME}-r[0-9]+$ ]] || [[ -f "$f" && "$b" =~ ^${NAME}-r[0-9]+\.tar\.gz$ ]]; then
      [[ " ${LEFT[*]-} " == *" $f "* ]] || LEFT+=("$f")
    fi
  done
done
if (( ${#LEFT[@]} )); then
  echo ""
  echo "  Unpacked packages and their tar files, not needed any more ($DEST has the files):"
  printf '    %s\n' "${LEFT[@]}"
  if ask "  Remove them, so /opt keeps only $NAME and $NAME.prev?"; then
    cd /
    rm -rf --one-file-system -- "${LEFT[@]}"
    echo "  removed"
  else
    echo "  kept (remove them by hand when you like)"
  fi
fi
echo ""
echo "Next: the deploy commands in $DEST/README.md, section \"Upgrading\"."
