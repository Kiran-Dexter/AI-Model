/* MONITOR-01: applies the saved theme before the page paints (no flash of the wrong theme).
 * A file, not inline, because the content security policy forbids inline scripts.
 * The same three themes as the PATCH-01 console: Default (light), Dark, B-Mode (neon). */
(function () {
  "use strict";
  var KEY = "monitor01.theme", VALID = { light: 1, dark: 1, hacker: 1 };
  function pref() {
    try { var v = localStorage.getItem(KEY); return Object.prototype.hasOwnProperty.call(VALID, v) ? v : "dark"; }
    catch (e) { return "dark"; }
  }
  function apply(t) { document.documentElement.setAttribute("data-theme", t); }
  apply(pref());
  window.MonTheme = {
    get: pref,
    set: function (t) {
      if (!Object.prototype.hasOwnProperty.call(VALID, t)) return;
      try { localStorage.setItem(KEY, t); } catch (e) { /* private mode */ }
      apply(t);
    },
    options: [["light", "Default"], ["dark", "Dark"], ["hacker", "B-Mode"]]
  };
})();
