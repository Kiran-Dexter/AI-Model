/* MONITOR-01: every VM in vCenter, nothing installed in them. The agreed mock-up (v2), on real data.
 *
 * Pages (address after #): / overview, /vms, /vm/ID, /hosts, /datastores, /alerts, /admin.
 * The critical alerts are polled every 15 s and stay on the screen (strip, bell, toast, sound)
 * until acknowledged or cleared; pages refresh every minute (vCenter is read once a minute).
 * Text always goes in as text nodes: nothing from the server is ever parsed as HTML.
 */
(function () {
  "use strict";
  const NS = "http://www.w3.org/2000/svg";
  const add = (e, kids) => kids.flat(3).forEach(k => { if (k != null && k !== false) e.append(k instanceof Node ? k : document.createTextNode(String(k))); });
  const el = (tag, attrs, ...kids) => {
    const e = document.createElement(tag);
    Object.entries(attrs || {}).forEach(([k, v]) => {
      if (v == null || v === false) return;
      if (k.startsWith("on") && typeof v === "function") e.addEventListener(k.slice(2), v);
      else if (k === "value") e.value = v;
      else e.setAttribute(k, v === true ? "" : v);
    });
    add(e, kids);
    return e;
  };
  const sv = (tag, attrs, ...kids) => {
    const e = document.createElementNS(NS, tag);
    Object.entries(attrs || {}).forEach(([k, v]) => { if (v != null) e.setAttribute(k, v); });
    add(e, kids);
    return e;
  };
  const store = {
    get(k, d) { try { const v = localStorage.getItem("monitor01." + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem("monitor01." + k, JSON.stringify(v)); } catch (e) { /* private mode */ } },
    del(k) { try { localStorage.removeItem("monitor01." + k); } catch (e) { /* private mode */ } },
  };
  const S = { token: store.get("token", null), me: null, range: store.get("range", "24h"), sound: store.get("sound", true),
              seenMax: null, live: null, timers: [], sel: null, audio: null, page: null };
  const ROOT = document.getElementById("mon");
  const KIND = { windows: "Windows VMs", linux: "Linux VMs", appliance: "Appliances" };
  const KIND1 = { windows: "Windows", linux: "Linux", appliance: "appliance" };
  const STATE_TXT = { crit: "▲ critical", warn: "● warning", off: "powered off", unknown: "no figures yet", ok: "fine" };

  // ---- formatting ---------------------------------------------------------------------------
  const pct = (v, d = 0) => v == null ? "–" : Number(v).toFixed(d) + "%";
  const bytes = b => { if (b == null) return "–"; const u = ["B", "KB", "MB", "GB", "TB", "PB"]; let i = 0, n = Number(b);
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; } return (n >= 100 || i === 0 ? n.toFixed(0) : n.toFixed(1)) + " " + u[i]; };
  const rate = k => k == null ? "–" : k >= 1000 ? (k * 8 / 1000).toFixed(0) + " Mb/s" : (k * 8).toFixed(0) + " kb/s";
  const ago = t => { if (!t) return "never"; const s = Math.max(0, (Date.now() - new Date(t).getTime()) / 1000);
    return s < 90 ? Math.round(s) + " s ago" : s < 5400 ? Math.round(s / 60) + " min ago" : s < 172800 ? Math.round(s / 3600) + " h ago" : Math.round(s / 86400) + " days ago"; };
  const mins = m => m < 60 ? m + " min" : m < 2880 ? Math.round(m / 60) + " h" : Math.round(m / 1440) + " d";
  const upDays = t => t ? Math.max(0, Math.floor((Date.now() - new Date(t).getTime()) / 86400000)) + " d" : "–";
  const when = t => t ? new Date(t).toLocaleString() : "–";
  const RNG = { "1h": "1 h", "6h": "6 h", "24h": "24 h", "7d": "7 days", "30d": "30 days" };
  const role = r => ({ viewer: 0, operator: 1, admin: 2 }[r] ?? -1);
  const can = r => S.me && role(S.me.user.role) >= role(r);
  const lvl = (v, th) => v == null ? "" : v >= th.crit ? "crit" : v >= th.warn ? "warn" : "ok";
  const rlvl = (v, th) => v == null ? "" : v >= th.ready_crit ? "crit" : v >= th.ready_warn ? "warn" : "ok";
  const tdCls = l => "num" + (l === "crit" ? " bad" : l === "warn" ? " meh" : "");
  const tag = st => st === "ok" || !st ? null : el("span", { class: "mon-tag " + st }, STATE_TXT[st] || st);

  // ---- the server ----------------------------------------------------------------------------
  async function api(path, opt = {}) {
    const h = { "Accept": "application/json" };
    if (S.token) h.Authorization = "Bearer " + S.token;
    if (opt.body !== undefined) h["Content-Type"] = "application/json";
    if (opt.background) h["X-Background"] = "1";
    let r;
    try {
      r = await fetch("api/" + path, { method: opt.method || "GET", headers: h, cache: "no-store",
        body: opt.body !== undefined ? JSON.stringify(opt.body) : undefined });
    } catch (e) { throw new Error("MONITOR-01 cannot be reached. Check the network and try again."); }
    let doc = null;
    try { doc = await r.json(); } catch (e) { /* not JSON */ }
    if (r.status === 401 && !opt.signin) { signedOut("Your session has ended. Sign in again."); throw new Error("signed out"); }
    if (!r.ok) {
      const d = doc && doc.detail;
      throw new Error(typeof d === "string" ? d : Array.isArray(d) ? "Some values are not valid: " + d.map(x => (x.loc || []).slice(-1)[0]).join(", ")
        : "The request failed (" + r.status + ").");
    }
    return doc;
  }

  function clearTimers() { S.timers.forEach(t => clearInterval(t)); S.timers = []; }
  function every(ms, fn) { S.timers.push(setInterval(fn, ms)); }

  // ---- sign-in -----------------------------------------------------------------------------------
  function signedOut(msg) {
    clearTimers();
    S.token = null; S.me = null; S.seenMax = null;
    store.del("token");
    signin(msg);
  }

  function signin(msg) {
    ROOT.replaceChildren();
    const err = el("div", { class: "mon-msg bad", role: "alert", hidden: !msg }, msg || "");
    const user = el("input", { name: "username", autocomplete: "username", required: true, maxlength: "64", autocapitalize: "none", spellcheck: "false" });
    const pass = el("input", { name: "password", type: "password", autocomplete: "current-password", required: true, maxlength: "256" });
    const code = el("input", { name: "code", inputmode: "numeric", autocomplete: "one-time-code", maxlength: "20" });
    const codeRow = el("label", { hidden: true }, "Code from your authenticator app", code);
    const btn = el("button", { class: "mon-btn", type: "submit" }, "Sign in");
    let ticket = null;
    const form = el("form", { novalidate: true },
      el("h1", null, "MONITOR", el("b", null, "-01")),
      el("p", null, "Sign in with your PATCH-01 account. Every VM in vCenter: CPU, memory, drives, CPU ready, with nothing installed in them."),
      err, el("label", null, "Username", user), el("label", null, "Password", pass), codeRow, btn);
    form.addEventListener("submit", async ev => {
      ev.preventDefault();
      err.hidden = true; btn.disabled = true;
      try {
        let doc;
        if (ticket) doc = await api("auth/login/2fa", { method: "POST", body: { mfa_ticket: ticket, code: code.value.trim() }, signin: true });
        else doc = await api("auth/login", { method: "POST", body: { username: user.value.trim(), password: pass.value }, signin: true });
        if (doc.mfa_required) {
          ticket = doc.mfa_ticket; codeRow.hidden = false; user.disabled = pass.disabled = true; btn.textContent = "Check code"; code.focus();
          return;
        }
        S.token = doc.token; store.set("token", doc.token);
        pass.value = "";
        unlockAudio();
        await start();
      } catch (e) {
        err.textContent = e.message; err.hidden = false;
        if (ticket && /expired|again/i.test(e.message)) { ticket = null; codeRow.hidden = true; user.disabled = pass.disabled = false; btn.textContent = "Sign in"; }
      } finally { btn.disabled = false; }
    });
    ROOT.append(el("main", { class: "mon-signin" }, form));
    (user.value ? pass : user).focus();
  }

  // ---- sound: two short tones, made here (no audio file) --------------------------------------
  function unlockAudio() {
    try { if (!S.audio) S.audio = new (window.AudioContext || window.webkitAudioContext)(); if (S.audio.state === "suspended") S.audio.resume(); }
    catch (e) { S.audio = null; }
  }
  function beep() {
    if (!S.sound || !S.audio) return;
    try {
      const t = S.audio.currentTime;
      [0, .22].forEach((d, i) => {
        const o = S.audio.createOscillator(), g = S.audio.createGain();
        o.type = "square"; o.frequency.value = i ? 660 : 880;
        g.gain.setValueAtTime(0.0001, t + d); g.gain.exponentialRampToValueAtTime(0.12, t + d + .02); g.gain.exponentialRampToValueAtTime(0.0001, t + d + .18);
        o.connect(g).connect(S.audio.destination); o.start(t + d); o.stop(t + d + .2);
      });
    } catch (e) { /* no sound device */ }
  }
  document.addEventListener("click", unlockAudio, { once: true });

  // ---- the frame -------------------------------------------------------------------------------------
  const F = {};
  function frame() {
    ROOT.replaceChildren();
    const navItems = [["#/", "Overview", "overview"], ["#/vms", "VMs", "vms"], ["#/hosts", "Hosts", "hosts"],
                      ["#/datastores", "Datastores", "datastores"], ["#/alerts", "Alerts", "alerts"]];
    if (can("admin")) navItems.push(["#/admin", "Admin", "admin"]);
    F.nav = el("nav", { class: "mon-nav", "aria-label": "MONITOR-01" }, navItems.map(([h, t, k]) => el("a", { href: h, "data-k": k }, t)),
      S.me.patch01_url ? el("a", { href: S.me.patch01_url + "/", target: "_blank", rel: "noopener noreferrer" }, "PATCH-01 ↗") : null);
    F.range = el("div", { class: "mon-range", role: "group", "aria-label": "Time range for the history" },
      ["1h", "6h", "24h", "7d", "30d"].map(r => el("button", { type: "button", "aria-pressed": String(r === S.range),
        onclick: () => { S.range = r; store.set("range", r); F.range.querySelectorAll("button").forEach(b => b.setAttribute("aria-pressed", String(b.textContent.replace(" ", "") === r))); render(true); } },
        r.replace(/(\d)([hd])/, "$1 $2"))));
    F.liveTxt = el("span", { class: "mon-live", role: "status" }, "reading…");
    F.bell = el("a", { class: "mon-bell", href: "#/alerts", title: "Critical alerts" }, "▲ ", el("b", null, "0"));
    const theme = el("select", { "aria-label": "Theme", onchange: e => window.MonTheme.set(e.target.value) },
      window.MonTheme.options.map(([v, t]) => el("option", { value: v, selected: v === window.MonTheme.get() }, t)));
    const u = S.me.user;
    F.top = el("header", { class: "mon-top" }, el("a", { class: "mon-brand", href: "#/" }, "MONITOR", el("b", null, "-01")), F.nav, F.range, F.liveTxt, F.bell,
      el("span", { class: "mon-user" }, (u.display_name || u.username) + " (" + u.role + (u.source === "local" ? ", local" : "") + ")", theme,
        el("button", { type: "button", class: "mon-btn quiet", onclick: async () => { try { await api("auth/logout", { method: "POST", body: {} }); } catch (e) { /* ended anyway */ } signedOut(); } }, "Sign out")));
    F.strip = el("section", { class: "mon-alerts", id: "alerts-strip", role: "region", "aria-label": "Critical alerts", hidden: true });
    F.main = el("main", { class: "mon", id: "main" });
    F.toasts = el("div", { class: "mon-toasts", "aria-live": "assertive" });
    ROOT.append(F.top, F.strip, F.main, F.toasts);
    const fit = () => document.documentElement.style.setProperty("--strip-top", F.top.offsetHeight + "px");
    fit(); window.addEventListener("resize", fit);
  }

  // ---- the live strip ------------------------------------------------------------------------------
  function rulesText(th) {
    return `drive ${th.crit}% used or more · CPU or memory ${th.crit}% or more for ${th.sustain_min} min · CPU ready ${th.ready_crit}% or more`;
  }

  async function poll() {
    let L;
    try { L = await api("live", { background: true }); } catch (e) { if (F.liveTxt) { F.liveTxt.className = "mon-live stale"; F.liveTxt.textContent = e.message; } return; }
    S.live = L;
    const st = L.status, stale = !st.collector_ok || !st.last_read || (Date.now() - new Date(st.last_read).getTime()) > st.every_s * 3000;
    const bad = st.vcenters.filter(v => v.error);
    F.liveTxt.className = "mon-live" + (stale || bad.length ? " stale" : "");
    F.liveTxt.textContent = !st.vcenters.length ? "no vCenter added yet" : bad.length ? bad[0].name + ": not read (" + ago(st.last_read) + ")"
      : !st.collector_ok ? "collector stopped" : "vCenter read " + ago(st.last_read) + " · every " + st.every_s + " s";
    F.liveTxt.title = bad.map(v => v.name + ": " + v.error).join("\n");
    F.bell.className = "mon-bell" + (L.unacked ? " on" : "");
    F.bell.lastChild.textContent = String(L.unacked);
    F.bell.title = L.unacked + " critical alert(s) not acknowledged" + (L.acked ? ", " + L.acked + " acknowledged and still open" : "");
    const fresh = S.seenMax === null ? [] : L.alerts.filter(a => a.id > S.seenMax);
    drawStrip(L, new Set(fresh.map(a => a.id)));
    if (fresh.length) {
      beep();
      fresh.slice(0, 3).forEach(a => toast(a));
    }
    S.seenMax = Math.max(S.seenMax || 0, L.max_id || 0);
  }

  function drawStrip(L, freshIds) {
    const th = S.me.thresholds;
    if (!L.alerts.length) { F.strip.hidden = true; F.strip.replaceChildren(); return; }
    const sound = el("input", { type: "checkbox", checked: S.sound, onchange: e => { S.sound = e.target.checked; store.set("sound", S.sound); unlockAudio(); } });
    F.strip.replaceChildren(...[
      el("div", { class: "mon-alerts-head" }, el("strong", null, "▲ " + L.unacked + " CRITICAL"), el("span", null, rulesText(th)),
        can("operator") ? el("button", { type: "button", class: "mon-ack", onclick: async e => {
          e.target.disabled = true;
          try { await api("alerts/ack", { method: "POST", body: { all: true } }); await poll(); if (/^alerts/.test(S.page)) render(true); }
          catch (err) { e.target.disabled = false; e.target.textContent = err.message; } } }, "Acknowledge all") : null,
        el("label", { class: "mon-sound" }, sound, " sound")),
      el("div", { class: "mon-alerts-list" }, L.alerts.slice(0, 12).map(a => el("a", { class: "mon-alert" + (freshIds.has(a.id) ? " new" : ""), href: "#/vm/" + a.vm_id },
        el("b", null, a.vm), el("span", null, a.text), el("small", null, (a.kind === "appliance" ? "appliance · " : "") + mins(a.minutes))))),
      L.alerts.length > 12 ? el("div", { class: "mon-more" }, "and " + (L.alerts.length - 12) + " more: ", el("a", { href: "#/alerts" }, "Alerts")) : null].filter(Boolean));
    F.strip.hidden = false;
  }

  function toast(a) {
    const t = el("div", { class: "mon-toast", role: "alert", onclick: () => { location.hash = "#/vm/" + a.vm_id; t.remove(); } },
      el("strong", null, "▲ NEW CRITICAL"), el("div", null, a.vm + ": " + a.text), el("small", null, "just now · click to open"));
    F.toasts.prepend(t);
    while (F.toasts.children.length > 3) F.toasts.lastChild.remove();
    setTimeout(() => t.remove(), 20000);
  }

  // ---- small drawings ------------------------------------------------------------------------------------
  function spark(vals, thr) {
    const v = (vals || []).filter(x => x != null);
    if (v.length < 2) return el("span", { class: "muted" }, "–");
    const W = 120, H = 26, x = i => i * W / (v.length - 1), y = n => H - 2 - Math.min(100, n) * (H - 4) / 100;
    const d = v.map((n, i) => (i ? "L" : "M") + x(i).toFixed(1) + " " + y(n).toFixed(1)).join(" ");
    return sv("svg", { viewBox: `0 0 ${W} ${H}`, class: "mon-spark", preserveAspectRatio: "none", role: "img",
                       "aria-label": "CPU over the time range, now " + Math.round(v[v.length - 1]) + "%" },
      sv("path", { class: "area", d: d + ` L${W} ${H} L0 ${H} Z` }), thr ? sv("line", { x1: 0, x2: W, y1: y(thr), y2: y(thr) }) : null,
      sv("path", { d }), sv("title", null, "CPU: " + v.map(n => Math.round(n)).join(", ")));
  }
  function bar(p, cls) { const b = el("div", { class: "mon-bar " + (cls || ""), role: "img", "aria-label": pct(p) }, el("span")); b.firstChild.style.width = Math.max(0, Math.min(100, p || 0)) + "%"; return b; }

  /* One measure per chart (never two scales), its alert line labelled, a crosshair and value on hover */
  function chart(title, pts, key, line, unit, opts = {}) {
    const vals = pts.map(p => p[key]);
    const have = vals.filter(v => v != null);
    const wrap = el("div", { class: "mon-chart-wrap" });
    const head = el("h2", null, title, el("span", null, have.length ? "now " + (opts.dec ? have[have.length - 1].toFixed(1) : Math.round(have[have.length - 1])) + unit : "no figures in this range"));
    if (have.length < 2) { wrap.append(head, el("div", { class: "mon-empty" }, "Not enough history yet: the first figures arrive a minute after vCenter is added.")); return wrap; }
    const top = opts.max || 100, W = 520, H = 150, L = 34, R = 6, B = 18, T = 8;
    const t0 = new Date(pts[0].t).getTime(), t1 = new Date(pts[pts.length - 1].t).getTime() || t0 + 1;
    const x = t => L + (W - L - R) * ((new Date(t).getTime() - t0) / Math.max(1, t1 - t0));
    const y = v => T + (H - B - T) * (1 - Math.min(top, v) / top);
    let d = "", started = false;
    pts.forEach(p => { if (p[key] == null) { started = false; return; } d += (started ? "L" : "M") + x(p.t).toFixed(1) + " " + y(p[key]).toFixed(1) + " "; started = true; });
    const first = pts.find(p => p[key] != null), last = [...pts].reverse().find(p => p[key] != null);
    const ticks = [0, top / 2, top];
    const fmtT = t => { const s = (t1 - t0) / 3600000; const dt = new Date(t); return s > 48 ? dt.toLocaleDateString(undefined, { day: "numeric", month: "short" }) : dt.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }); };
    const xh = sv("line", { class: "xh", y1: T, y2: H - B, visibility: "hidden" }), dot = sv("circle", { class: "dot", r: 4, visibility: "hidden" });
    const svg = sv("svg", { viewBox: `0 0 ${W} ${H}`, class: "mon-chart", role: "img", "aria-label": title + " over the time range, now " + Math.round(have[have.length - 1]) + unit },
      ticks.map(v => [sv("line", { x1: L, x2: W - R, y1: y(v), y2: y(v), class: "ax" }), sv("text", { x: L - 6, y: y(v) + 3, "text-anchor": "end" }, (opts.dec ? v.toFixed(0) : Math.round(v)) + unit)]),
      [pts[0].t, pts[Math.floor(pts.length / 2)].t, pts[pts.length - 1].t].map((t, i) => sv("text", { x: i === 0 ? L : i === 2 ? W - R : x(t), y: H - 4, "text-anchor": i === 0 ? "start" : i === 2 ? "end" : "middle" }, i === 2 ? "now" : fmtT(t))),
      sv("path", { class: "ar", d: d.replace(/M/g, "M").trim() ? `M${x(first.t)} ${y(0)} ` + d.replace(/^M/, "L") + `L${x(last.t)} ${y(0)} Z` : "" }),
      sv("path", { class: "ln", d }),
      line != null && line <= top ? [sv("line", { x1: L, x2: W - R, y1: y(line), y2: y(line), class: "th" }), sv("text", { class: "thl", x: W - 8, y: y(line) - 4, "text-anchor": "end" }, "alert at " + line + unit)] : null,
      xh, dot);
    const tip = el("div", { class: "mon-tip", hidden: true });
    const hit = sv("rect", { class: "hit", x: L, y: T, width: W - L - R, height: H - B - T });
    const move = ev => {
      const r = svg.getBoundingClientRect(), mx = (ev.clientX - r.left) * W / r.width;
      let best = null;
      pts.forEach(p => { if (p[key] == null) return; const dx = Math.abs(x(p.t) - mx); if (!best || dx < best.dx) best = { p, dx }; });
      if (!best) return;
      const px = x(best.p.t), py = y(best.p[key]);
      xh.setAttribute("x1", px); xh.setAttribute("x2", px); xh.setAttribute("visibility", "visible");
      dot.setAttribute("cx", px); dot.setAttribute("cy", py); dot.setAttribute("visibility", "visible");
      tip.replaceChildren(el("b", null, (opts.dec ? best.p[key].toFixed(1) : Math.round(best.p[key])) + unit), " · " + new Date(best.p.t).toLocaleString(undefined, { weekday: "short", hour: "2-digit", minute: "2-digit" }));
      tip.style.left = (px * r.width / W) + "px"; tip.style.top = (py * r.height / H) + "px"; tip.hidden = false;
    };
    hit.addEventListener("pointermove", move);
    hit.addEventListener("pointerleave", () => { tip.hidden = true; xh.setAttribute("visibility", "hidden"); dot.setAttribute("visibility", "hidden"); });
    svg.append(hit);
    wrap.append(head, svg, tip);
    return wrap;
  }

  // ---- pages --------------------------------------------------------------------------------------------
  const kpi = (n, l, cls) => el("div", { class: "mon-kpi " + (cls || "") + (n === 0 && cls ? " zero" : "") }, el("div", { class: "n" }, String(n)), el("div", { class: "l" }, l));

  function noVcenter() {
    return el("section", { class: "mon-card" }, el("h2", null, "No vCenter yet"),
      el("p", null, "MONITOR-01 has nothing to show until it can read a vCenter."),
      can("admin") ? el("p", null, el("a", { class: "mon-btn", href: "#/admin" }, "Add a vCenter in Admin"))
                   : el("p", { class: "muted" }, "Ask a MONITOR-01 admin to add one."));
  }

  function vmTable(rows, th, opts = {}) {
    const cols = ["VM", "Host", opts.appliance ? "What it is" : "OS", "CPU", "CPU", "Memory", "Fullest drive", "Ready", "Network", "Up"];
    return el("div", { class: "mon-wrap" }, el("table", { class: "mon-table" },
      el("thead", null, el("tr", null, cols.map((t, i) => el("th", null, i === 3 ? "CPU, " + RNG[S.range] : t)))),
      el("tbody", null, rows.length ? rows.map(v => el("tr", { class: "click" + (S.sel === v.id ? " sel" : ""), "data-id": v.id, onclick: () => opts.onpick ? opts.onpick(v) : (location.hash = "#/vm/" + v.id) },
        el("td", null, el("a", { href: "#/vm/" + v.id, onclick: e => e.stopPropagation() }, v.name), tag(v.state)), el("td", null, v.host || "–"),
        el("td", { class: "os", title: v.os || "" }, v.os || "–"), el("td", { class: "spk" }, spark(v.spark, th.crit)),
        el("td", { class: tdCls(lvl(v.cpu, th)) }, pct(v.cpu)), el("td", { class: tdCls(lvl(v.mem, th)) }, pct(v.mem)),
        el("td", { class: tdCls(lvl(v.disk, th)) }, v.power !== "on" ? "–" : !v.drives ? el("span", { class: "muted" }, "not reported") : pct(v.disk) + " used"),
        el("td", { class: tdCls(rlvl(v.ready, th)) }, v.ready == null ? "–" : v.ready.toFixed(1) + "%"), el("td", { class: "num" }, rate(v.net)),
        el("td", { class: "num" }, v.power === "on" ? upDays(v.boot) : "off")))
        : el("tr", null, el("td", { colspan: cols.length, class: "mon-empty" }, opts.empty || "Nothing to show.")))));
  }

  async function pageOverview(main) {
    const o = await api("overview?range=" + S.range, { background: S.bg });
    const th = o.thresholds;
    if (!o.status.vcenters.length) { main.replaceChildren(el("h1", null, "Estate overview"), noVcenter()); return; }
    const k = o.kpis;
    const ring = r => el("div", { class: "mon-card mon-ring" },
      window.hudRing({ pct: r.pct, title: r.title, sub: r.sub, segs: r.segs, key: "ring-" + r.key, idle: "NO DATA", label: r.title + " " + pct(r.pct) }),
      el("div", { class: "mon-ring-note" }, r.note));
    const hero = el("section", { class: "mon-row mon-row-hero" }, o.rings.map(ring),
      el("div", { class: "mon-card mon-kpis" },
        kpi(k.vms, `${k.windows} Windows · ${k.linux} Linux · ${k.appliances} appliances${k.powered_off ? " · " + k.powered_off + " off" : ""}`),
        kpi(k.hosts, k.hosts_connected === k.hosts ? "ESXi hosts, all connected" : `ESXi hosts, ${k.hosts - k.hosts_connected} not connected`, k.hosts_connected === k.hosts ? "ok" : "crit"),
        kpi(k.alerts, `critical alerts on ${k.alert_vms} VM${k.alert_vms === 1 ? "" : "s"}${k.alerts > k.unacked ? " (" + (k.alerts - k.unacked) + " acknowledged)" : ""}`, "crit"),
        kpi(k.warn, `VMs at ${th.warn}% or more (warning)`, "warn"),
        kpi(k.drives_crit, `drives ${th.crit}% used or more`, "crit"),
        kpi(k.ready_warn, `VMs waiting for CPU (ready ${th.ready_warn}% or more)`, "warn")));

    const cells = list => el("div", { class: "mon-grid", role: "list" }, list.map(([id, name, st, tip]) =>
      el("button", { type: "button", class: "mon-cell " + st, role: "listitem", title: tip, "aria-label": tip + " (" + (STATE_TXT[st] || st) + ")",
                     onclick: () => { location.hash = "#/vm/" + id; } })));
    const groupBox = kd => { const list = o.groups[kd]; const c = list.filter(x => x[2] === "crit").length, w = list.filter(x => x[2] === "warn").length;
      return el("div", { class: "mon-group" }, el("div", { class: "mon-group-h" }, el("strong", null, KIND[kd]), el("span", null, list.length + " · "),
        c ? el("span", { class: "mon-tag crit" }, "▲ " + c + " critical") : null, w ? el("span", { class: "mon-tag warn" }, "● " + w + " warning") : null,
        !c && !w && list.length ? el("span", { class: "mon-tag ok" }, "all fine") : null), list.length ? cells(list) : el("div", { class: "mon-empty" }, "None.")); };
    const all = Object.values(o.groups).flat();
    const n = st => all.filter(x => x[2] === st).length;
    const every = el("section", { class: "mon-card" }, el("h2", null, "Every VM", el("span", null, "by kind · worst of CPU, memory, drives, CPU ready · hover for figures, click to open")),
      el("div", { class: "mon-groups" }, ["windows", "linux", "appliance"].map(groupBox)),
      el("div", { class: "mon-legend" }, [["ok", "fine"], ["warn", "warning"], ["crit", "critical"], ["off", "powered off"], ["unknown", "no figures yet"]]
        .filter(([s]) => s !== "unknown" || n(s)).map(([s, t]) => el("span", null, el("i", { class: "sw-" + s }), n(s) + " " + t))));

    const panel = (title, sub, items, empty) => el("section", { class: "mon-card" }, el("h2", null, title, el("span", null, sub)),
      items.length ? el("ul", { class: "mon-list" }, items) : el("div", { class: "mon-empty" }, empty));
    const who = (id, name, small) => el("span", { class: "who" }, el("a", { href: "#/vm/" + id }, name), el("small", null, small));
    const row3 = el("section", { class: "mon-row mon-row-3" },
      panel("Drives almost full", th.crit + "% used or more is critical", o.drives.map(d => el("li", { class: "mon-li" },
        who(d.vm_id, d.vm + " " + d.path, bytes(d.capacity_b - d.free_b) + " of " + bytes(d.capacity_b)), bar(d.used, lvl(d.used, th) || "ok"), el("span", { class: "v" }, pct(d.used) + " used"))),
        "No drive reported yet (VMware Tools reports drives)."),
      panel("Busiest CPU", "over " + RNG[S.range], o.busiest.map(v => el("li", { class: "mon-li" },
        who(v.id, v.name, v.host || ""), spark(v.spark, th.crit), el("span", { class: "v" }, pct(v.cpu)))), "No CPU figures yet."),
      panel("Waiting for CPU", "CPU ready: the VM waits for its host", o.waiting.map(v => el("li", { class: "mon-li" },
        who(v.id, v.name, v.host || ""), bar(Math.min(100, (v.ready || 0) * 100 / (th.ready_crit * 2)), rlvl(v.ready, th) || "ok"), el("span", { class: "v" }, v.ready == null ? "–" : v.ready.toFixed(1) + "%"))), "No CPU ready figures yet."));

    const tabKind = S.tabKind && o.attention[S.tabKind] ? S.tabKind : (["windows", "linux", "appliance"].find(x => o.attention[x].length) || "windows");
    S.tabKind = tabKind;
    const detail = el("section", { class: "mon-card mon-detail", "aria-live": "polite" });
    const pick = v => { S.sel = v.id; table.querySelectorAll("tr[data-id]").forEach(tr => tr.classList.toggle("sel", Number(tr.dataset.id) === v.id)); drawDetail(detail, v.id, true); };
    const tabs = el("div", { class: "mon-tabs", role: "tablist" }, ["windows", "linux", "appliance"].map(x =>
      el("button", { type: "button", role: "tab", "aria-selected": String(x === tabKind), onclick: () => { S.tabKind = x; render(true); } },
        KIND[x] + " (" + o.attention_total[x] + ")")));
    const rows = o.attention[tabKind];
    const table = el("section", { class: "mon-card" }, el("h2", null, "VMs needing attention", el("span", null, "critical first · ", el("a", { href: "#/vms?kind=" + tabKind }, "all " + KIND[tabKind]))), tabs,
      vmTable(rows, th, { onpick: pick, empty: "Nothing needs attention here: every " + KIND1[tabKind] + " VM is under " + th.warn + "%." }),
      o.attention_total[tabKind] > rows.length ? el("div", { class: "mon-more" }, "and " + (o.attention_total[tabKind] - rows.length) + " more: ", el("a", { href: "#/vms?kind=" + tabKind + "&state=warn" }, "VMs")) : null);
    const appl = el("section", { class: "mon-card" }, el("h2", null, "Appliances", el("span", null, "vCenter, NSX, backup, virtual firewalls · from vCenter only")),
      vmTable(o.appliances, th, { appliance: true, onpick: pick, empty: "No VM is counted as an appliance. An admin can set the rules in Admin." }),
      el("p", { class: "mon-sub" }, "Appliances often run without VMware Tools' drive report: their drives show “not reported”, never as fine."));
    const first = S.sel && [...rows, ...o.appliances, ...o.busiest].find(v => v.id === S.sel) ? S.sel : (rows[0] || o.busiest[0] || {}).id;
    main.replaceChildren(el("h1", null, "Estate overview"),
      el("p", { class: "mon-sub" }, "Every VM in vCenter, with nothing installed in them: CPU, memory, CPU ready, disk and network from the hosts; drive free space from VMware Tools."),
      hero, every, row3, el("section", { class: "mon-row mon-row-2" }, el("div", { class: "mon-stack" }, table, appl), detail));
    if (first) { S.sel = first; table.querySelectorAll("tr[data-id]").forEach(tr => tr.classList.toggle("sel", Number(tr.dataset.id) === first)); await drawDetail(detail, first, true); }
    else detail.append(el("div", { class: "mon-empty" }, "Pick a VM to see its history."));
  }

  async function drawDetail(box, id, compact) {
    let v;
    try { v = await api("vms/" + id + "?range=" + S.range, { background: S.bg }); }
    catch (e) { box.replaceChildren(el("div", { class: "mon-msg bad" }, e.message)); return; }
    const th = v.thresholds;
    const facts = [v.os, v.host, v.num_cpu ? v.num_cpu + " vCPU" : null, v.memory_mb ? Math.round(v.memory_mb / 1024) + " GB" : null, v.ip, v.vcenter].filter(Boolean).join(" · ");
    const kv = [["CPU ready", v.ready == null ? "–" : v.ready.toFixed(1) + "%"], ["Disk latency", v.disk_lat_ms == null ? "–" : v.disk_lat_ms + " ms"],
      ["Disk I/O", v.disk_kbps == null ? "–" : bytes(v.disk_kbps * 1024) + "/s"], ["Network", rate(v.net)],
      ["Snapshots", v.snapshots ? v.snapshots + (v.oldest_snapshot ? " (oldest " + ago(v.oldest_snapshot).replace(" ago", "") + ")" : "") : "none"],
      ["VMware Tools", v.tools || "not running"], ["Up", v.power === "on" ? upDays(v.boot) : v.power],
      ["Memory ballooned / swapped", (v.balloon_mb || 0) + " / " + (v.swap_mb || 0) + " MB"], ["Kind", KIND1[v.kind] + " (" + (v.why || "") + ")"], ["Read", ago(v.last_seen)]];
    const drives = v.drives.length ? el("ul", { class: "mon-list" }, v.drives.map(d => el("li", { class: "mon-li" },
      el("span", { class: "who" }, d.path, el("small", null, bytes(d.capacity_b - d.free_b) + " of " + bytes(d.capacity_b))), bar(d.used, lvl(d.used, th) || "ok"), el("span", { class: "v" }, pct(d.used) + " used"))))
      : el("div", { class: "mon-empty" }, v.power !== "on" ? "Powered off." : "VMware Tools reports no drives for this VM: its drives are not watched (never shown as fine).");
    const patch = el("div", { class: "mon-patch" }, el("strong", null, "From PATCH-01: "), el("span", { class: "muted" }, "looking up…"));
    const ready = chart("CPU ready", v.series, "ready", th.ready_crit, "%", { max: Math.max(th.ready_crit * 2, Math.ceil(Math.max(0, ...v.series.map(p => p.ready || 0)) * 1.2)), dec: true });
    const head = el("div", { class: "hd" }, el("strong", null, v.name), tag(v.state), el("span", { class: "mon-sub" }, facts),
      compact ? el("a", { class: "open", href: "#/vm/" + v.id }, "open ›") : null);
    const charts = [chart("CPU", v.series, "cpu", th.crit, "%"), chart("Memory (active)", v.series, "mem", th.crit, "%")];
    if (compact) box.replaceChildren(head, ...charts, el("h2", null, "Drives", el("span", null, "VMware Tools")), drives, el("dl", { class: "mon-kv" }, kv.slice(0, 7).map(([a, b]) => el("div", null, el("dt", null, a), el("dd", null, b)))), patch);
    else {
      const kindSel = can("admin") ? el("label", { class: "mon-sub" }, "Kind: ", el("select", { class: "mon-input", onchange: async e => {
        try { await api("admin/vms/" + v.id + "/kind", { method: "PUT", body: { kind: e.target.value || null } }); render(true); } catch (err) { alert_(box, err.message); } } },
        el("option", { value: "", selected: !v.kind_override }, "work it out (" + KIND1[v.kind] + ")"),
        ["windows", "linux", "appliance"].map(x => el("option", { value: x, selected: v.kind_override === x }, "always " + KIND1[x])))) : null;
      const hist = el("section", { class: "mon-card" }, el("h2", null, "Alerts on this VM", el("span", null, "the last 20")),
        v.alerts.length ? el("div", { class: "mon-wrap" }, el("table", { class: "mon-table" }, el("thead", null, el("tr", null, ["Opened", "What", "Peak", "Status"].map(t => el("th", null, t)))),
          el("tbody", null, v.alerts.map(a => el("tr", null, el("td", { title: when(a.opened_at) }, ago(a.opened_at)), el("td", null, a.text),
            el("td", { class: "num" }, a.peak == null ? "–" : a.peak + (a.rule === "ready" ? "%" : "%")),
            el("td", null, a.cleared_at ? "cleared " + ago(a.cleared_at) : a.acked_at ? el("span", { class: "mon-tag warn" }, "acknowledged by " + a.acked_by) : el("span", { class: "mon-tag crit" }, "open")))))))
          : el("div", { class: "mon-empty" }, "No alert on this VM."));
      box.replaceChildren(el("section", { class: "mon-card mon-detail" }, head, el("div", { class: "mon-detail-grid" }, charts, ready)),
        el("section", { class: "mon-row mon-row-2" }, el("section", { class: "mon-card mon-detail" }, el("h2", null, "Drives", el("span", null, "VMware Tools")), drives,
          el("dl", { class: "mon-kv" }, kv.map(([a, b]) => el("div", null, el("dt", null, a), el("dd", null, b)))), patch, kindSel), hist));
    }
    api("vms/" + v.id + "/patch", { background: true }).then(r => {
      const p = r.patch;
      if (!p) { patch.replaceChildren(el("strong", null, "From PATCH-01: "), el("span", { class: "muted" }, "not linked (an admin can link it with monitor01.sh --link-patch01)."), S.me.patch01_url ? [" ", el("a", { href: S.me.patch01_url + "/", target: "_blank", rel: "noopener noreferrer" }, "open the console")] : null); return; }
      if (p.error) { patch.replaceChildren(el("strong", null, "From PATCH-01: "), el("span", { class: "muted" }, p.error)); return; }
      if (p.not_found) { patch.replaceChildren(el("strong", null, "From PATCH-01: "), "no PATCH-01 server is called " + v.name + ". ", el("a", { href: p.console, target: "_blank", rel: "noopener noreferrer" }, "open the console")); return; }
      patch.replaceChildren(el("strong", null, "From PATCH-01: "),
        (p.to_install == null ? "patch status not known yet" : p.to_install ? p.to_install + " update" + (p.to_install === 1 ? "" : "s") + " to install" : "up to date"),
        p.reboot ? " · reboot needed" : "", p.last_patch_at ? " · last patched " + ago(p.last_patch_at) : "", p.agent ? " · agent " + p.agent : "", " · ",
        el("a", { href: p.console, target: "_blank", rel: "noopener noreferrer" }, "open in the console"));
    }).catch(() => patch.replaceChildren(el("strong", null, "From PATCH-01: "), el("span", { class: "muted" }, "not available now.")));
  }

  function alert_(box, msg) { box.prepend(el("div", { class: "mon-msg bad", role: "alert" }, msg)); }

  async function pageVm(main, id) {
    const box = el("div");
    if (!main.childElementCount) main.append(el("p", { class: "mon-loading" }, "Reading…"));
    await drawDetail(box, id, false);
    main.replaceChildren(el("p", { class: "mon-sub" }, el("a", { href: "#/vms" }, "‹ every VM")), box);
  }

  async function pageVms(main, params) {
    const f = { kind: params.get("kind") || "", state: params.get("state") || "", q: params.get("q") || "", sort: params.get("sort") || "state", page: Number(params.get("page") || 1) };
    const go = ch => { const p = new URLSearchParams(Object.entries(Object.assign({}, f, ch, ch.page ? {} : { page: 1 })).filter(([, v]) => v && v !== 1 || false)); location.hash = "#/vms" + (p.toString() ? "?" + p : ""); };
    const r = await api("vms?" + new URLSearchParams({ kind: f.kind, state: f.state, q: f.q, sort: f.sort, page: f.page, range: S.range }), { background: S.bg });
    const th = S.me.thresholds;
    const total = Object.values(r.counts).reduce((a, b) => a + b, 0);
    const tabs = el("div", { class: "mon-tabs", role: "tablist" }, [["", "All", total], ["windows", "Windows", r.counts.windows || 0], ["linux", "Linux", r.counts.linux || 0], ["appliance", "Appliances", r.counts.appliance || 0]]
      .map(([k, t, n]) => el("button", { type: "button", role: "tab", "aria-selected": String(f.kind === k), onclick: () => go({ kind: k }) }, t + " (" + n + ")")));
    const q = el("input", { class: "mon-input", type: "search", placeholder: "Name, host, OS or address", value: f.q, "aria-label": "Search VMs" });
    let tm; q.addEventListener("input", () => { clearTimeout(tm); tm = setTimeout(() => go({ q: q.value.trim() }), 450); });
    const state = el("select", { "aria-label": "State", onchange: e => go({ state: e.target.value }) }, [["", "any state"], ["crit", "critical"], ["warn", "warning"], ["ok", "fine"], ["off", "powered off"], ["unknown", "no figures yet"]]
      .map(([v, t]) => el("option", { value: v, selected: f.state === v }, t)));
    const sort = el("select", { "aria-label": "Sort", onchange: e => go({ sort: e.target.value }) }, [["state", "worst first"], ["cpu", "CPU"], ["mem", "memory"], ["disk", "fullest drive"], ["ready", "CPU ready"], ["name", "name"]]
      .map(([v, t]) => el("option", { value: v, selected: f.sort === v }, "sort: " + t)));
    const pager = el("div", { class: "mon-pager" }, r.total + " VM" + (r.total === 1 ? "" : "s") + " · page " + r.page + " of " + r.pages,
      el("button", { type: "button", class: "mon-btn quiet", disabled: r.page <= 1, onclick: () => go({ page: r.page - 1 }) }, "‹ previous"),
      el("button", { type: "button", class: "mon-btn quiet", disabled: r.page >= r.pages, onclick: () => go({ page: r.page + 1 }) }, "next ›"));
    const focused = document.activeElement && document.activeElement.type === "search";
    main.replaceChildren(el("h1", null, "VMs"), el("p", { class: "mon-sub" }, "Every VM vCenter reports, with its latest figures (read once a minute)."),
      el("section", { class: "mon-card" }, el("div", { class: "mon-tools" }, tabs, q, state, sort), vmTable(r.rows, th, { empty: "No VM matches." }), pager));
    if (focused) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); }
  }

  async function pageHosts(main) {
    const r = await api("hosts", { background: S.bg });
    const th = r.thresholds;
    main.replaceChildren(el("h1", null, "ESXi hosts"), el("p", { class: "mon-sub" }, "CPU and memory of each host, as vCenter reports them."),
      el("section", { class: "mon-card" }, el("div", { class: "mon-wrap" }, el("table", { class: "mon-table" },
        el("thead", null, el("tr", null, ["Host", "Cluster", "State", "CPU", "", "Memory", "", "VMs on / all", "VMs critical", "VMs warning", "vCenter"].map(t => el("th", null, t)))),
        el("tbody", null, r.rows.length ? r.rows.map(h => el("tr", null, el("td", null, el("strong", null, h.name)), el("td", null, h.cluster || "–"),
          el("td", null, h.connection !== "connected" ? el("span", { class: "mon-tag crit" }, h.connection) : h.maintenance ? el("span", { class: "mon-tag warn" }, "maintenance") : el("span", { class: "mon-tag ok" }, "connected")),
          el("td", { class: "barcell" }, bar(h.cpu, lvl(h.cpu, th) || "ok")), el("td", { class: tdCls(lvl(h.cpu, th)) }, pct(h.cpu) + " of " + h.cpu_ghz + " GHz"),
          el("td", { class: "barcell" }, bar(h.mem, lvl(h.mem, th) || "ok")), el("td", { class: tdCls(lvl(h.mem, th)) }, pct(h.mem) + " of " + h.mem_gb + " GB"),
          el("td", { class: "num" }, h.vms_on + " / " + h.vms), el("td", { class: "num" + (h.vm_crit ? " bad" : "") }, h.vm_crit), el("td", { class: "num" + (h.vm_warn ? " meh" : "") }, h.vm_warn),
          el("td", null, h.vcenter))) : el("tr", null, el("td", { colspan: 11, class: "mon-empty" }, "No host read yet.")))))));
  }

  async function pageDatastores(main) {
    const r = await api("datastores", { background: S.bg });
    const th = r.thresholds;
    main.replaceChildren(el("h1", null, "Datastores"), el("p", { class: "mon-sub" }, "Space on each datastore, as vCenter reports it."),
      el("section", { class: "mon-card" }, el("div", { class: "mon-wrap" }, el("table", { class: "mon-table" },
        el("thead", null, el("tr", null, ["Datastore", "Type", "Used", "", "Free", "Size", "VMs", "vCenter"].map(t => el("th", null, t)))),
        el("tbody", null, r.rows.length ? r.rows.map(d => el("tr", null, el("td", null, el("strong", null, d.name), d.accessible ? tag(d.state) : el("span", { class: "mon-tag crit" }, "not accessible")),
          el("td", null, d.type || "–"), el("td", { class: "barcell" }, bar(d.used, lvl(d.used, th) || "ok")), el("td", { class: tdCls(lvl(d.used, th)) }, pct(d.used, 1)),
          el("td", { class: "num" }, bytes(d.free_b)), el("td", { class: "num" }, bytes(d.capacity_b)), el("td", { class: "num" }, d.vms), el("td", null, d.vcenter)))
          : el("tr", null, el("td", { colspan: 8, class: "mon-empty" }, "No datastore read yet.")))))));
  }

  async function pageAlerts(main, params) {
    const which = params.get("which") || "open", page = Number(params.get("page") || 1);
    const r = await api("alerts?which=" + which + "&page=" + page, { background: S.bg });
    const picked = new Set();
    const ackBtn = el("button", { type: "button", class: "mon-btn", disabled: true, onclick: async () => {
      try { await api("alerts/ack", { method: "POST", body: { ids: [...picked] } }); await poll(); render(true); } catch (e) { alert_(main, e.message); } } }, "Acknowledge selected");
    const tabs = el("div", { class: "mon-tabs", role: "tablist" }, [["open", "Open"], ["cleared", "Cleared"], ["all", "All"]].map(([k, t]) =>
      el("button", { type: "button", role: "tab", "aria-selected": String(k === which), onclick: () => { location.hash = "#/alerts?which=" + k; } }, t)));
    const op = can("operator");
    main.replaceChildren(el("h1", null, "Alerts"),
      el("p", { class: "mon-sub" }, "Critical: " + rulesText(S.me.thresholds) + ". An alert clears by itself when the figure is " + S.me.thresholds.clear_margin + " points under the line; acknowledging only takes it off the screen."),
      el("section", { class: "mon-card" }, el("div", { class: "mon-tools" }, tabs, op && which !== "cleared" ? ackBtn : null),
        el("div", { class: "mon-wrap" }, el("table", { class: "mon-table" },
          el("thead", null, el("tr", null, [op ? "" : null, "Opened", "VM", "Kind", "What", "Now", "Peak", "Status"].filter(x => x !== null).map(t => el("th", null, t)))),
          el("tbody", null, r.rows.length ? r.rows.map(a => el("tr", null,
            op ? el("td", null, !a.cleared_at && !a.acked_at ? el("input", { type: "checkbox", "aria-label": "Select " + a.vm + " " + a.text, onchange: e => { e.target.checked ? picked.add(a.id) : picked.delete(a.id); ackBtn.disabled = !picked.size; } }) : null) : null,
            el("td", { title: when(a.opened_at) }, ago(a.opened_at)), el("td", null, el("a", { href: "#/vm/" + a.vm_id }, a.vm)), el("td", null, KIND1[a.kind] || a.kind),
            el("td", null, a.text), el("td", { class: "num" }, a.value == null ? "–" : a.value + "%"), el("td", { class: "num" }, a.peak == null ? "–" : a.peak + "%"),
            el("td", null, a.cleared_at ? el("span", { class: "mon-tag ok" }, "cleared " + ago(a.cleared_at)) : a.acked_at ? el("span", { class: "mon-tag warn" }, "acknowledged by " + a.acked_by + ", " + ago(a.acked_at)) : el("span", { class: "mon-tag crit" }, "open"))))
            : el("tr", null, el("td", { colspan: 8, class: "mon-empty" }, which === "open" ? "No open alert. Everything is under the lines." : "Nothing here."))))),
        el("div", { class: "mon-pager" }, r.total + " alert" + (r.total === 1 ? "" : "s") + " · page " + r.page + " of " + r.pages,
          el("button", { type: "button", class: "mon-btn quiet", disabled: r.page <= 1, onclick: () => { location.hash = "#/alerts?which=" + which + "&page=" + (r.page - 1); } }, "‹ previous"),
          el("button", { type: "button", class: "mon-btn quiet", disabled: r.page >= r.pages, onclick: () => { location.hash = "#/alerts?which=" + which + "&page=" + (r.page + 1); } }, "next ›"))));
  }

  // ---- admin ---------------------------------------------------------------------------------------------------
  async function pageAdmin(main) {
    if (!can("admin")) { main.replaceChildren(el("h1", null, "Admin"), el("p", null, "This needs the admin role.")); return; }
    const [vcs, st, au] = await Promise.all([api("admin/vcenters"), api("admin/settings"), api("admin/audit")]);
    main.replaceChildren(el("h1", null, "Admin"), el("p", { class: "mon-sub" }, "vCenter connections, the alert rules, and who changed what."),
      vcenterCard(vcs.rows), rulesCard(st.settings), auditCard(au.rows));
  }

  function vcenterCard(rows) {
    const msg = el("div", { class: "mon-msg", hidden: true, role: "status" });
    const say = (t, good) => { msg.textContent = t; msg.className = "mon-msg " + (good ? "good" : "bad"); msg.hidden = false; };
    const f = { name: el("input", { maxlength: "60", placeholder: "vc-prod" }), host: el("input", { maxlength: "253", placeholder: "vcsa01.corp.local" }),
                port: el("input", { type: "number", min: "1", max: "65535", value: "443" }), username: el("input", { maxlength: "120", placeholder: "monitor-ro@vsphere.local", autocomplete: "off" }),
                password: el("input", { type: "password", maxlength: "256", autocomplete: "new-password" }) };
    let editing = null, pin = null;
    const certBox = el("div", { class: "mon-cert", hidden: true });
    const agree = el("input", { type: "checkbox" });
    const agreeRow = el("label", { class: "check", hidden: true }, agree, el("span", null, "I compared this SHA-256 fingerprint with vCenter's own certificate (vCenter: Administration › Certificates, or the browser's padlock), and it matches."));
    const save = el("button", { type: "button", class: "mon-btn", disabled: true }, "Test and save");
    agree.addEventListener("change", () => { save.disabled = !agree.checked; });
    const getCert = el("button", { type: "button", class: "mon-btn quiet", onclick: async () => {
      msg.hidden = true; certBox.hidden = agreeRow.hidden = true; agree.checked = false; save.disabled = true;
      try {
        const c = await api("admin/vcenters/certificate", { method: "POST", body: { host: f.host.value.trim(), port: Number(f.port.value || 443) } });
        pin = c.sha256;
        certBox.replaceChildren(el("div", null, el("strong", null, "Certificate presented by " + c.host + ":" + c.port)),
          el("div", null, "Issued to: " + c.subject + (c.names.length ? " (" + c.names.slice(0, 4).join(", ") + ")" : "")), el("div", null, "Issued by: " + c.issuer + (c.self_signed ? " (self-signed)" : "")),
          el("div", null, "Valid until: " + when(c.not_after)), el("div", null, "SHA-256: ", el("code", null, c.sha256_text)));
        certBox.hidden = agreeRow.hidden = false;
      } catch (e) { say(e.message); }
    } }, "Get certificate");
    save.addEventListener("click", async () => {
      save.disabled = true; say("Logging in to vCenter to test the account…", true);
      const body = { name: f.name.value.trim(), host: f.host.value.trim(), port: Number(f.port.value || 443), username: f.username.value.trim(),
                     password: f.password.value, pin_sha256: pin || "", enabled: true };
      try {
        const r = await api("admin/vcenters" + (editing ? "/" + editing : ""), { method: editing ? "PUT" : "POST", body });
        f.password.value = "";
        say("Saved. vCenter answered (" + r.found.version + ") and shows " + r.found.vms + " VMs. The first figures appear within a minute.", true);
        setTimeout(() => render(true), 2500);
      } catch (e) { say(e.message); save.disabled = !agree.checked; }
    });
    const edit = v => { editing = v.id; f.name.value = v.name; f.host.value = v.host; f.port.value = v.port; f.username.value = v.username; f.password.value = "";
      pin = v.pin_sha256; certBox.replaceChildren(el("div", null, "Trusted now: ", el("code", null, v.pin_text)), el("div", { class: "muted" }, "Press “Get certificate” to check it again or trust a renewed one."));
      certBox.hidden = false; agreeRow.hidden = false; agree.checked = false; save.disabled = true; formTitle.textContent = "Change " + v.name + " (leave the password empty to keep it)"; f.name.focus(); };
    const formTitle = el("strong", null, "Add a vCenter");
    const table = rows.length ? el("div", { class: "mon-wrap" }, el("table", { class: "mon-table" },
      el("thead", null, el("tr", null, ["Name", "Address", "Account", "Certificate", "Last read", "VMs", "", ""].map(t => el("th", null, t)))),
      el("tbody", null, rows.map(v => el("tr", null, el("td", null, el("strong", null, v.name)), el("td", null, v.host + ":" + v.port), el("td", null, v.username),
        el("td", { title: v.pin_text }, el("code", null, v.pin_text.slice(0, 23) + "…")),
        el("td", null, v.last_error ? el("span", { class: "mon-tag crit", title: v.last_error }, "not read: " + v.last_error.slice(0, 80)) : ago(v.last_ok_at) + (v.last_ms ? " (" + (v.last_ms / 1000).toFixed(1) + " s)" : "")),
        el("td", { class: "num" }, (v.counts && v.counts.vms) || "–"),
        el("td", null, el("button", { type: "button", class: "mon-btn quiet", onclick: () => edit(v) }, "Change")),
        el("td", null, el("button", { type: "button", class: "mon-btn danger", onclick: async e => {
          if (e.target.dataset.sure !== "1") { e.target.dataset.sure = "1"; e.target.textContent = "Remove, with its history?"; return; }
          try { await api("admin/vcenters/" + v.id, { method: "DELETE" }); render(true); } catch (err) { say(err.message); } } }, "Remove"))))))) : el("div", { class: "mon-empty" }, "No vCenter yet.");
    return el("section", { class: "mon-card" }, el("h2", null, "vCenter", el("span", null, "read-only, every " + S.me.every_s + " s")), table,
      el("hr", { class: "ax" }),
      el("div", { class: "mon-form" }, formTitle,
        el("p", { class: "mon-help" }, "Use a vCenter account with the built-in ", el("b", null, "Read-only"), " role, given at the top (vCenter) and propagated. MONITOR-01 also refuses, on its side, every vCenter call that is not a read."),
        el("div", { class: "row" }, el("label", null, "Name", f.name), el("label", null, "vCenter address", f.host), el("label", null, "Port", f.port)),
        el("div", { class: "row" }, el("label", null, "Account", f.username), el("label", null, "Password", f.password)),
        el("div", { class: "acts" }, getCert), certBox, agreeRow, el("div", { class: "acts" }, save,
          el("button", { type: "button", class: "mon-btn quiet", onclick: () => { editing = null; pin = null; Object.values(f).forEach(i => { i.value = ""; }); f.port.value = "443"; certBox.hidden = agreeRow.hidden = true; formTitle.textContent = "Add a vCenter"; msg.hidden = true; } }, "Clear")), msg));
  }

  function rulesCard(s) {
    const t = s.thresholds, a = s.appliances;
    const num = (v, step) => el("input", { type: "number", step: step || "1", value: String(v) });
    const i = { crit: num(t.crit), warn: num(t.warn), ready_crit: num(t.ready_crit, "0.5"), ready_warn: num(t.ready_warn, "0.5"), sustain_min: num(t.sustain_min), clear_margin: num(t.clear_margin, "0.5") };
    const names = el("textarea", { spellcheck: "false" }); names.value = (a.names || []).join("\n");
    const guests = el("textarea", { spellcheck: "false" }); guests.value = (a.guests || []).join("\n");
    const products = el("input", { type: "checkbox", checked: a.products !== false });
    const ignore = el("textarea", { spellcheck: "false" }); ignore.value = (s.drives_ignore || []).join("\n");
    const msg = el("div", { class: "mon-msg", hidden: true, role: "status" });
    const lines = ta => ta.value.split("\n").map(x => x.trim()).filter(Boolean);
    const save = el("button", { type: "button", class: "mon-btn", onclick: async () => {
      const body = { thresholds: Object.fromEntries(Object.entries(i).map(([k, x]) => [k, Number(x.value)])),
                     appliances: { names: lines(names), guests: lines(guests), products: products.checked }, drives_ignore: lines(ignore) };
      try { const r = await api("admin/settings", { method: "PUT", body }); S.me.thresholds = r.settings.thresholds; msg.textContent = "Saved. " + r.reclassified + " VM(s) changed kind."; msg.className = "mon-msg good"; }
      catch (e) { msg.textContent = e.message; msg.className = "mon-msg bad"; }
      msg.hidden = false;
    } }, "Save the rules");
    return el("section", { class: "mon-card" }, el("h2", null, "Rules", el("span", null, "what is critical, and what counts as an appliance")),
      el("div", { class: "mon-form" },
        el("div", { class: "row" }, el("label", null, "Critical at (% used / busy)", i.crit), el("label", null, "Warning at (%)", i.warn),
          el("label", null, "CPU ready critical at (%)", i.ready_crit), el("label", null, "CPU ready warning at (%)", i.ready_warn)),
        el("div", { class: "row" }, el("label", null, "CPU, memory, ready: minutes over the line before an alert", i.sustain_min), el("label", null, "Clears when under the line by (points)", i.clear_margin)),
        el("p", { class: "mon-help" }, "A drive alerts as soon as it is over the line. CPU, memory and CPU ready must stay over it for the minutes above, so a short spike is not an alert."),
        el("div", { class: "row" }, el("label", null, "Appliance names (regular expressions, one per line)", names), el("label", null, "Appliance guest OS text (one per line)", guests)),
        el("label", { class: "check" }, products, el("span", null, "A VM that vCenter lists as a packaged product (an OVA appliance) is an appliance")),
        el("label", null, "Drives never watched (patterns such as /snap/*, one per line)", ignore),
        el("div", { class: "acts" }, save), msg));
  }

  function auditCard(rows) {
    return el("section", { class: "mon-card" }, el("h2", null, "Audit", el("span", null, "the last 200 entries")),
      el("div", { class: "mon-wrap" }, el("table", { class: "mon-table" }, el("thead", null, el("tr", null, ["When", "Who", "What", "Details", "From"].map(t => el("th", null, t)))),
        el("tbody", null, rows.map(r => el("tr", null, el("td", { title: when(r.at) }, ago(r.at)), el("td", null, r.actor), el("td", null, r.action.replace(/_/g, " ")),
          el("td", { class: "os", title: JSON.stringify(r.detail) }, JSON.stringify(r.detail).slice(0, 140)), el("td", null, r.ip || "–")))))));
  }

  // ---- routing ---------------------------------------------------------------------------------------------------
  let busy = false;
  async function render(keep, background) {
    if (!S.me) return;
    S.bg = !!background;
    const h = location.hash.replace(/^#\/?/, "");
    const [path, qs] = h.split("?");
    const params = new URLSearchParams(qs || "");
    const parts = path.split("/").filter(Boolean);
    const page = parts[0] === "vm" ? "vm" : (parts[0] || "overview");
    F.nav.querySelectorAll("a[data-k]").forEach(a => { if (a.dataset.k === (page === "vm" ? "vms" : page)) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current"); });
    const changed = S.page !== h;
    S.page = h;
    if (changed && !keep) { F.main.replaceChildren(el("p", { class: "mon-loading" }, "Reading…")); window.scrollTo(0, 0); }
    if (busy) return;
    busy = true;
    try {
      if (page === "overview") await pageOverview(F.main);
      else if (page === "vm") await pageVm(F.main, Number(parts[1]));
      else if (page === "vms") await pageVms(F.main, params);
      else if (page === "hosts") await pageHosts(F.main);
      else if (page === "datastores") await pageDatastores(F.main);
      else if (page === "alerts") await pageAlerts(F.main, params);
      else if (page === "admin") await pageAdmin(F.main);
      else F.main.replaceChildren(el("h1", null, "Not found"), el("p", null, el("a", { href: "#/" }, "Back to the overview")));
    } catch (e) {
      if (e.message !== "signed out") F.main.replaceChildren(el("h1", null, "Not shown"), el("div", { class: "mon-msg bad", role: "alert" }, e.message));
    } finally {
      busy = false;
      if (S.page !== h) render();
    }
  }

  async function start() {
    try { S.me = await api("auth/me"); }
    catch (e) { if (e.message !== "signed out") signin(e.message); return; }
    frame();
    await poll();
    render();
    clearTimers();
    every(15000, poll);
    // the admin page holds forms being typed into: it is not redrawn under the person
    every(60000, () => { if (!/^#\/admin/.test(location.hash) && document.visibilityState === "visible") render(true, true); });
  }

  window.addEventListener("hashchange", () => render());
  window.addEventListener("monitor01-poll", () => { if (S.me) poll(); });     // tests: poll now
  if (S.token) start(); else signin();
})();
