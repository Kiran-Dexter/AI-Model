-- MONITOR-01 schema 1: its own database, nothing shared with PATCH-01.
-- Safe to re-run (every install runs every migration again): CREATE ... IF NOT EXISTS only,
-- and no constraint is ever narrowed by a later file.

CREATE TABLE IF NOT EXISTS schema_version (
  version    int PRIMARY KEY,
  applied_at timestamptz NOT NULL DEFAULT now()
);

-- ---- people ------------------------------------------------------------------------------
-- Sign-in is delegated to PATCH-01 (its users, roles, two-factor). This table holds only the
-- local break-glass admin made on the server with monitor01.sh --local-admin, so MONITOR-01
-- can still be opened when PATCH-01 is down, and keeps working once it moves to its own server.
CREATE TABLE IF NOT EXISTS local_users (
  id            serial PRIMARY KEY,
  username      text NOT NULL UNIQUE CHECK (username ~ '^[a-z0-9][a-z0-9._-]{1,62}$'),
  password_hash text NOT NULL,
  role          text NOT NULL DEFAULT 'admin' CHECK (role IN ('viewer', 'operator', 'admin')),
  active        boolean NOT NULL DEFAULT true,
  failed_logins int NOT NULL DEFAULT 0,
  locked_until  timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  last_login_at timestamptz
);

-- Sessions: the token is shown to the browser once and kept here only as its SHA-256
CREATE TABLE IF NOT EXISTS sessions (
  token_hash   text PRIMARY KEY,
  username     text NOT NULL,
  display_name text,
  role         text NOT NULL CHECK (role IN ('viewer', 'operator', 'admin')),
  source       text NOT NULL CHECK (source IN ('patch01', 'local')),
  created_at   timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  expires_at   timestamptz NOT NULL,
  source_ip    inet,
  user_agent   text
);
CREATE INDEX IF NOT EXISTS sessions_expiry ON sessions (expires_at);

-- Failed sign-ins per address, so guessing is slowed before PATCH-01 is even asked
CREATE TABLE IF NOT EXISTS login_failures (
  source_ip inet NOT NULL,
  at        timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS login_failures_ip ON login_failures (source_ip, at);

CREATE TABLE IF NOT EXISTS audit (
  id        bigserial PRIMARY KEY,
  at        timestamptz NOT NULL DEFAULT now(),
  actor     text NOT NULL,
  action    text NOT NULL,
  detail    jsonb NOT NULL DEFAULT '{}'::jsonb,
  source_ip inet
);
CREATE INDEX IF NOT EXISTS audit_at ON audit (at DESC);

CREATE TABLE IF NOT EXISTS settings (
  key        text PRIMARY KEY,
  value      jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by text
);

-- ---- vCenter -----------------------------------------------------------------------------
-- A read-only account per vCenter. The password is encrypted with monitor.key (Fernet); the
-- certificate is trusted by its SHA-256 fingerprint, confirmed by an admin.
CREATE TABLE IF NOT EXISTS vcenters (
  id           serial PRIMARY KEY,
  name         text NOT NULL UNIQUE CHECK (name ~ '^[A-Za-z0-9][A-Za-z0-9 ._()-]{0,59}$'),
  host         text NOT NULL,
  port         int NOT NULL DEFAULT 443 CHECK (port BETWEEN 1 AND 65535),
  username     text NOT NULL,
  password_enc text NOT NULL,
  pin_sha256   text NOT NULL CHECK (pin_sha256 ~ '^[0-9a-f]{64}$'),
  enabled      boolean NOT NULL DEFAULT true,
  created_at   timestamptz NOT NULL DEFAULT now(),
  created_by   text,
  last_run_at  timestamptz,
  last_ok_at   timestamptz,
  last_ms      int,
  last_error   text,
  counts       jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS hosts (
  id            bigserial PRIMARY KEY,
  vcenter_id    int NOT NULL REFERENCES vcenters(id) ON DELETE CASCADE,
  moref         text NOT NULL,
  name          text NOT NULL,
  cluster       text,
  connection    text,
  maintenance   boolean NOT NULL DEFAULT false,
  cpu_mhz_total bigint,
  cpu_mhz_used  bigint,
  mem_mb_total  bigint,
  mem_mb_used   bigint,
  vms           int NOT NULL DEFAULT 0,
  last_seen     timestamptz NOT NULL DEFAULT now(),
  gone_at       timestamptz,
  UNIQUE (vcenter_id, moref)
);

CREATE TABLE IF NOT EXISTS datastores (
  id          bigserial PRIMARY KEY,
  vcenter_id  int NOT NULL REFERENCES vcenters(id) ON DELETE CASCADE,
  moref       text NOT NULL,
  name        text NOT NULL,
  type        text,
  capacity_b  bigint,
  free_b      bigint,
  accessible  boolean NOT NULL DEFAULT true,
  vms         int NOT NULL DEFAULT 0,
  last_seen   timestamptz NOT NULL DEFAULT now(),
  gone_at     timestamptz,
  UNIQUE (vcenter_id, moref)
);

-- One row per VM: its latest figures. "kind" is worked out each read (rules in settings);
-- kind_override is an admin's choice and always wins.
CREATE TABLE IF NOT EXISTS vms (
  id              bigserial PRIMARY KEY,
  vcenter_id      int NOT NULL REFERENCES vcenters(id) ON DELETE CASCADE,
  moref           text NOT NULL,
  uuid            text,
  name            text NOT NULL,
  kind            text NOT NULL DEFAULT 'linux' CHECK (kind IN ('windows', 'linux', 'appliance')),
  kind_override   text CHECK (kind_override IN ('windows', 'linux', 'appliance')),
  kind_reason     text,
  guest_full      text,
  guest_id        text,
  guest_family    text,
  product         text,
  host_moref      text,
  host_name       text,
  cluster         text,
  num_cpu         int,
  memory_mb       int,
  power           text NOT NULL DEFAULT 'unknown',
  tools           text,
  ip              text,
  boot_time       timestamptz,
  annotation      text,
  snapshots       int NOT NULL DEFAULT 0,
  oldest_snapshot timestamptz,
  cpu_pct         real,
  mem_pct         real,
  ready_pct       real,
  disk_pct        real,
  drives_reported int NOT NULL DEFAULT 0,
  net_kbps        real,
  disk_kbps       real,
  disk_lat_ms     real,
  balloon_mb      int,
  swap_mb         int,
  state           text NOT NULL DEFAULT 'unknown',
  first_seen      timestamptz NOT NULL DEFAULT now(),
  last_seen       timestamptz NOT NULL DEFAULT now(),
  gone_at         timestamptz,
  UNIQUE (vcenter_id, moref)
);
CREATE INDEX IF NOT EXISTS vms_name ON vms (lower(name));
CREATE INDEX IF NOT EXISTS vms_live ON vms (kind, state) WHERE gone_at IS NULL;

-- The drives VMware Tools reports inside each VM (free space), latest only
CREATE TABLE IF NOT EXISTS vm_drives (
  vm_id      bigint NOT NULL REFERENCES vms(id) ON DELETE CASCADE,
  path       text NOT NULL,
  capacity_b bigint NOT NULL,
  free_b     bigint NOT NULL,
  used_pct   real NOT NULL,
  PRIMARY KEY (vm_id, path)
);

-- History. A row a minute per VM, kept 2 days; then hourly figures, kept 35 days.
CREATE TABLE IF NOT EXISTS vm_samples (
  vm_id     bigint NOT NULL REFERENCES vms(id) ON DELETE CASCADE,
  ts        timestamptz NOT NULL,
  cpu_pct   real,
  mem_pct   real,
  ready_pct real,
  disk_pct  real,
  net_kbps  real,
  PRIMARY KEY (vm_id, ts)
);
CREATE INDEX IF NOT EXISTS vm_samples_ts ON vm_samples (ts);

CREATE TABLE IF NOT EXISTS vm_hourly (
  vm_id     bigint NOT NULL REFERENCES vms(id) ON DELETE CASCADE,
  ts        timestamptz NOT NULL,
  cpu_avg   real, cpu_max   real,
  mem_avg   real, mem_max   real,
  ready_avg real, ready_max real,
  disk_max  real,
  net_avg   real,
  n         int NOT NULL DEFAULT 0,
  PRIMARY KEY (vm_id, ts)
);
CREATE INDEX IF NOT EXISTS vm_hourly_ts ON vm_hourly (ts);

-- ---- alerts ------------------------------------------------------------------------------
-- One row per problem, from the moment it is true for long enough until it clears. An
-- acknowledged alert leaves the screen but stays open until the figure is back to normal.
CREATE TABLE IF NOT EXISTS alerts (
  id           bigserial PRIMARY KEY,
  vm_id        bigint NOT NULL REFERENCES vms(id) ON DELETE CASCADE,
  rule         text NOT NULL CHECK (rule IN ('drive', 'cpu', 'mem', 'ready')),
  item         text NOT NULL DEFAULT '',
  level        text NOT NULL CHECK (level IN ('crit', 'warn')),
  value        real,
  threshold    real,
  opened_at    timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  peak         real,
  cleared_at   timestamptz,
  acked_at     timestamptz,
  acked_by     text
);
CREATE UNIQUE INDEX IF NOT EXISTS alerts_one_open ON alerts (vm_id, rule, item) WHERE cleared_at IS NULL;
CREATE INDEX IF NOT EXISTS alerts_opened ON alerts (opened_at DESC);

-- The collector's own heartbeat, for the "vCenter read 14 s ago" line and --check
CREATE TABLE IF NOT EXISTS collector_status (
  id         int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  beat_at    timestamptz,
  last_cycle timestamptz,
  cycle_ms   int,
  note       text
);
INSERT INTO collector_status (id) VALUES (1) ON CONFLICT DO NOTHING;

INSERT INTO schema_version (version) VALUES (1) ON CONFLICT DO NOTHING;
