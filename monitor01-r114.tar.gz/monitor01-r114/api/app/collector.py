"""MONITOR-01 collector: reads every vCenter each minute, keeps the history, opens and clears alerts.

Run as its own container (mon01-collector):  python -m app.collector
Network first, database after: vCenter is read with no transaction open, then everything for
that vCenter is written in one short transaction.
"""
import json
import logging
import signal
import time
from datetime import datetime, timezone

from . import config, crypto, model, vcenter
from .db import db

log = logging.getLogger("monitor01.collector")
STOP = False


def settings(conn):
    row = conn.execute("SELECT value FROM settings WHERE key = 'rules'").fetchone()
    return model.merged(row["value"] if row else None)


def _upsert_hosts(conn, vc_id, hosts):
    for h in hosts:
        conn.execute(
            """INSERT INTO hosts (vcenter_id, moref, name, cluster, connection, maintenance, cpu_mhz_total, cpu_mhz_used,
                                  mem_mb_total, mem_mb_used, vms, last_seen, gone_at)
               VALUES (%(vc)s, %(moref)s, %(name)s, %(cluster)s, %(connection)s, %(maintenance)s, %(cpu_mhz_total)s,
                       %(cpu_mhz_used)s, %(mem_mb_total)s, %(mem_mb_used)s, %(vms)s, now(), NULL)
               ON CONFLICT (vcenter_id, moref) DO UPDATE SET name = EXCLUDED.name, cluster = EXCLUDED.cluster,
                   connection = EXCLUDED.connection, maintenance = EXCLUDED.maintenance,
                   cpu_mhz_total = EXCLUDED.cpu_mhz_total, cpu_mhz_used = EXCLUDED.cpu_mhz_used,
                   mem_mb_total = EXCLUDED.mem_mb_total, mem_mb_used = EXCLUDED.mem_mb_used, vms = EXCLUDED.vms,
                   last_seen = now(), gone_at = NULL""", dict(h, vc=vc_id))
    conn.execute("""UPDATE hosts SET gone_at = now() WHERE vcenter_id = %s AND gone_at IS NULL
                     AND NOT (moref = ANY(%s))""", (vc_id, [h["moref"] for h in hosts]))


def _upsert_datastores(conn, vc_id, dss):
    for d in dss:
        conn.execute(
            """INSERT INTO datastores (vcenter_id, moref, name, type, capacity_b, free_b, accessible, vms, last_seen, gone_at)
               VALUES (%(vc)s, %(moref)s, %(name)s, %(type)s, %(capacity_b)s, %(free_b)s, %(accessible)s, %(vms)s, now(), NULL)
               ON CONFLICT (vcenter_id, moref) DO UPDATE SET name = EXCLUDED.name, type = EXCLUDED.type,
                   capacity_b = EXCLUDED.capacity_b, free_b = EXCLUDED.free_b, accessible = EXCLUDED.accessible,
                   vms = EXCLUDED.vms, last_seen = now(), gone_at = NULL""", dict(d, vc=vc_id))
    conn.execute("""UPDATE datastores SET gone_at = now() WHERE vcenter_id = %s AND gone_at IS NULL
                     AND NOT (moref = ANY(%s))""", (vc_id, [d["moref"] for d in dss]))


VM_UPSERT = """
INSERT INTO vms (vcenter_id, moref, uuid, name, kind, kind_reason, guest_full, guest_id, guest_family, product,
                 host_moref, host_name, cluster, num_cpu, memory_mb, power, tools, ip, boot_time, annotation,
                 snapshots, oldest_snapshot, cpu_pct, mem_pct, ready_pct, disk_pct, drives_reported, net_kbps,
                 disk_kbps, disk_lat_ms, balloon_mb, swap_mb, state, last_seen, gone_at)
VALUES (%(vc)s, %(moref)s, %(uuid)s, %(name)s, %(kind)s, %(kind_reason)s, %(guest_full)s, %(guest_id)s, %(guest_family)s,
        %(product)s, %(host_moref)s, %(host_name)s, %(cluster)s, %(num_cpu)s, %(memory_mb)s, %(power)s, %(tools)s, %(ip)s,
        %(boot_time)s, %(annotation)s, %(snapshots)s, %(oldest_snapshot)s, %(cpu_pct)s, %(mem_pct)s, %(ready_pct)s,
        %(disk_pct)s, %(drives_reported)s, %(net_kbps)s, %(disk_kbps)s, %(disk_lat_ms)s, %(balloon_mb)s, %(swap_mb)s,
        %(state)s, now(), NULL)
ON CONFLICT (vcenter_id, moref) DO UPDATE SET
    uuid = EXCLUDED.uuid, name = EXCLUDED.name,
    kind = CASE WHEN vms.kind_override IS NOT NULL THEN vms.kind_override ELSE EXCLUDED.kind END,
    kind_reason = CASE WHEN vms.kind_override IS NOT NULL THEN 'set by an admin' ELSE EXCLUDED.kind_reason END,
    guest_full = EXCLUDED.guest_full, guest_id = EXCLUDED.guest_id, guest_family = EXCLUDED.guest_family,
    product = EXCLUDED.product, host_moref = EXCLUDED.host_moref, host_name = EXCLUDED.host_name, cluster = EXCLUDED.cluster,
    num_cpu = EXCLUDED.num_cpu, memory_mb = EXCLUDED.memory_mb, power = EXCLUDED.power, tools = EXCLUDED.tools,
    ip = EXCLUDED.ip, boot_time = EXCLUDED.boot_time, annotation = EXCLUDED.annotation, snapshots = EXCLUDED.snapshots,
    oldest_snapshot = EXCLUDED.oldest_snapshot, cpu_pct = EXCLUDED.cpu_pct, mem_pct = EXCLUDED.mem_pct,
    ready_pct = EXCLUDED.ready_pct, disk_pct = EXCLUDED.disk_pct, drives_reported = EXCLUDED.drives_reported,
    net_kbps = EXCLUDED.net_kbps, disk_kbps = EXCLUDED.disk_kbps, disk_lat_ms = EXCLUDED.disk_lat_ms,
    balloon_mb = EXCLUDED.balloon_mb, swap_mb = EXCLUDED.swap_mb, state = EXCLUDED.state, last_seen = now(), gone_at = NULL
RETURNING id, kind_override"""

VM_KEYS = ("moref", "uuid", "name", "guest_full", "guest_id", "guest_family", "product", "host_moref", "host_name",
           "cluster", "num_cpu", "memory_mb", "power", "tools", "ip", "boot_time", "annotation", "snapshots",
           "oldest_snapshot", "cpu_pct", "mem_pct", "ready_pct", "net_kbps", "disk_kbps", "disk_lat_ms",
           "balloon_mb", "swap_mb")


def prepare_vm(v, overrides, st):
    """A VM read from vCenter -> the row to store, with its drives, kind and state."""
    th = st["thresholds"]
    drv = model.drives(v.get("disks"), st["drives_ignore"]) if v.get("power") == "on" else []
    row = {k: v.get(k) for k in VM_KEYS}
    row["kind_override"] = overrides.get(v["moref"])
    row["kind"], row["kind_reason"] = model.classify(row, st)
    row["disk_pct"] = max((d["used_pct"] for d in drv), default=None)
    row["drives_reported"] = len(drv)
    if v.get("power") != "on":
        for k in ("cpu_pct", "mem_pct", "ready_pct", "net_kbps", "disk_kbps", "disk_lat_ms"):
            row[k] = None
    row["state"] = model.state(row, th)
    return row, drv


def store(conn, vc_id, data, st, ts):
    """Everything read from one vCenter, and the alerts it opens or clears. Returns counts."""
    th = st["thresholds"]
    _upsert_hosts(conn, vc_id, data["hosts"])
    _upsert_datastores(conn, vc_id, data["datastores"])
    overrides = {r["moref"]: r["kind_override"] for r in conn.execute(
        "SELECT moref, kind_override FROM vms WHERE vcenter_id = %s AND kind_override IS NOT NULL", (vc_id,))}
    seen, samples, rows = [], [], {}
    for v in data["vms"]:
        row, drv = prepare_vm(v, overrides, st)
        vm_id = conn.execute(VM_UPSERT, dict(row, vc=vc_id)).fetchone()["id"]
        seen.append(v["moref"])
        rows[vm_id] = (row, drv)
        conn.execute("DELETE FROM vm_drives WHERE vm_id = %s", (vm_id,))
        for d in drv:
            conn.execute("INSERT INTO vm_drives (vm_id, path, capacity_b, free_b, used_pct) VALUES (%s, %s, %s, %s, %s)",
                         (vm_id, d["path"], d["capacity_b"], d["free_b"], d["used_pct"]))
        if row["power"] == "on":
            samples.append((vm_id, ts, row["cpu_pct"], row["mem_pct"], row["ready_pct"], row["disk_pct"], row["net_kbps"]))
    if samples:
        with conn.cursor() as cur:
            cur.executemany("""INSERT INTO vm_samples (vm_id, ts, cpu_pct, mem_pct, ready_pct, disk_pct, net_kbps)
                               VALUES (%s, %s, %s, %s, %s, %s, %s) ON CONFLICT DO NOTHING""", samples)
    gone = [r["id"] for r in conn.execute(
        """UPDATE vms SET gone_at = now(), state = 'off' WHERE vcenter_id = %s AND gone_at IS NULL AND NOT (moref = ANY(%s))
           RETURNING id""", (vc_id, seen))]
    if gone:
        conn.execute("UPDATE alerts SET cleared_at = now() WHERE cleared_at IS NULL AND vm_id = ANY(%s)", (gone,))
    opened, cleared = apply_alerts(conn, rows, th, ts)
    return {"vms": len(seen), "hosts": len(data["hosts"]), "datastores": len(data["datastores"]),
            "gone": len(gone), "opened": opened, "cleared": cleared}


def apply_alerts(conn, rows, th, ts):
    ids = list(rows)
    if not ids:
        return 0, 0
    need = model.sustain_seconds(th, config.COLLECT_SECONDS)
    # Per figure: its lowest value and how far back its readings reach in the sustain window (plus
    # a reading and a half, so slow cycles still count). Readings without that figure do not count.
    win = {r["vm_id"]: r for r in conn.execute(
        """SELECT vm_id,
                  count(cpu_pct) AS cpu_n, min(cpu_pct) AS cpu_min,
                  extract(epoch FROM %s - min(ts) FILTER (WHERE cpu_pct IS NOT NULL))::float AS cpu_span,
                  count(mem_pct) AS mem_n, min(mem_pct) AS mem_min,
                  extract(epoch FROM %s - min(ts) FILTER (WHERE mem_pct IS NOT NULL))::float AS mem_span,
                  count(ready_pct) AS ready_n, min(ready_pct) AS ready_min,
                  extract(epoch FROM %s - min(ts) FILTER (WHERE ready_pct IS NOT NULL))::float AS ready_span
             FROM vm_samples WHERE vm_id = ANY(%s) AND ts > %s - make_interval(secs => %s) AND ts <= %s
            GROUP BY vm_id""", (ts, ts, ts, ids, ts, th["sustain_min"] * 60 + config.COLLECT_SECONDS * 1.5, ts))}
    open_ = {}
    for a in conn.execute("SELECT id, vm_id, rule, item, value, peak FROM alerts WHERE cleared_at IS NULL AND vm_id = ANY(%s)",
                          (ids,)):
        open_.setdefault(a["vm_id"], {})[(a["rule"], a["item"])] = a
    opened = cleared = 0
    for vm_id, (row, drv) in rows.items():
        act = model.evaluate(row, drv, win.get(vm_id), open_.get(vm_id, {}), th, need)
        for rule, item, value, line in act["open"]:
            conn.execute("""INSERT INTO alerts (vm_id, rule, item, level, value, threshold, peak, opened_at, last_seen_at)
                            VALUES (%s, %s, %s, 'crit', %s, %s, %s, %s, %s) ON CONFLICT DO NOTHING""",
                         (vm_id, rule, item, value, line, value, ts, ts))
            opened += 1
        for aid, value in act["update"]:
            conn.execute("UPDATE alerts SET value = %s, peak = GREATEST(peak, %s), last_seen_at = %s WHERE id = %s",
                         (value, value, ts, aid))
        if act["clear"]:
            conn.execute("UPDATE alerts SET cleared_at = %s WHERE id = ANY(%s) AND cleared_at IS NULL", (ts, act["clear"]))
            cleared += len(act["clear"])
    return opened, cleared


def reclassify(conn):
    """After an admin changes the appliance rules: every VM's kind again, from what is stored."""
    st = settings(conn)
    n = 0
    for r in conn.execute("""SELECT id, name, guest_full, guest_id, guest_family, product, kind_override, kind, kind_reason
                               FROM vms""").fetchall():
        kind, why = model.classify(r, st)
        if (kind, why) != (r["kind"], r["kind_reason"]):
            conn.execute("UPDATE vms SET kind = %s, kind_reason = %s WHERE id = %s", (kind, why, r["id"]))
            n += 1
    return n


def housekeeping(conn, hours_back=3):
    conn.execute(
        """INSERT INTO vm_hourly (vm_id, ts, cpu_avg, cpu_max, mem_avg, mem_max, ready_avg, ready_max, disk_max, net_avg, n)
           SELECT vm_id, date_trunc('hour', ts), avg(cpu_pct), max(cpu_pct), avg(mem_pct), max(mem_pct),
                  avg(ready_pct), max(ready_pct), max(disk_pct), avg(net_kbps), count(*)
             FROM vm_samples
            WHERE ts >= date_trunc('hour', now()) - make_interval(hours => %s) AND ts < date_trunc('hour', now())
            GROUP BY vm_id, date_trunc('hour', ts)
           ON CONFLICT (vm_id, ts) DO UPDATE SET cpu_avg = EXCLUDED.cpu_avg, cpu_max = EXCLUDED.cpu_max,
               mem_avg = EXCLUDED.mem_avg, mem_max = EXCLUDED.mem_max, ready_avg = EXCLUDED.ready_avg,
               ready_max = EXCLUDED.ready_max, disk_max = EXCLUDED.disk_max, net_avg = EXCLUDED.net_avg, n = EXCLUDED.n""",
                 (hours_back,))
    conn.execute("DELETE FROM vm_samples WHERE ts < now() - make_interval(days => %s)", (config.RAW_DAYS,))
    conn.execute("DELETE FROM vm_hourly WHERE ts < now() - make_interval(days => %s)", (config.HOURLY_DAYS,))
    conn.execute("DELETE FROM alerts WHERE cleared_at < now() - interval '90 days'")
    conn.execute("DELETE FROM vms WHERE gone_at < now() - interval '30 days'")
    conn.execute("DELETE FROM hosts WHERE gone_at < now() - interval '30 days'")
    conn.execute("DELETE FROM datastores WHERE gone_at < now() - interval '30 days'")
    conn.execute("DELETE FROM audit WHERE at < now() - interval '400 days'")
    conn.execute("DELETE FROM sessions WHERE expires_at < now() - interval '1 day'")


def one_vcenter(vc):
    t0 = time.monotonic()
    ts = datetime.now(timezone.utc).replace(microsecond=0)
    try:
        password = crypto.decrypt(vc["password_enc"])
        data = vcenter.read_all(vc, password)              # network, no transaction open
    except Exception as e:  # noqa: BLE001
        msg = str(e) if isinstance(e, (vcenter.VcError, crypto.KeyError_, vcenter.net.NetError)) else vcenter.why(e)
        log.warning("vCenter %s not read: %s", vc["name"], msg)
        with db() as conn:
            conn.execute("UPDATE vcenters SET last_run_at = now(), last_error = %s, last_ms = %s WHERE id = %s",
                         (msg[:500], int((time.monotonic() - t0) * 1000), vc["id"]))
        return
    try:
        with db() as conn:
            before = conn.execute("SELECT count(*) AS n FROM vms WHERE vcenter_id = %s AND gone_at IS NULL",
                                  (vc["id"],)).fetchone()["n"]
            if not data["vms"] and before:
                raise vcenter.VcError("vCenter returned no VM at all (it had %d): the account may have lost its "
                                      "read permission. Nothing was changed." % before)
            counts = store(conn, vc["id"], data, settings(conn), ts)
    except Exception as e:  # noqa: BLE001 - the next vCenter is still read
        msg = str(e) if isinstance(e, vcenter.VcError) else "storing the figures failed: " + type(e).__name__
        log.exception("vCenter %s: %s", vc["name"], msg)
        with db() as conn:
            conn.execute("UPDATE vcenters SET last_run_at = now(), last_error = %s WHERE id = %s", (msg[:500], vc["id"]))
        return
    with db() as conn:
        conn.execute("""UPDATE vcenters SET last_run_at = now(), last_ok_at = now(), last_error = NULL, last_ms = %s,
                               counts = %s::jsonb WHERE id = %s""",
                     (int((time.monotonic() - t0) * 1000), json.dumps(counts), vc["id"]))
    log.info("vCenter %s: %s", vc["name"], counts)


def cycle():
    with db() as conn:
        vcs = conn.execute("SELECT * FROM vcenters WHERE enabled ORDER BY id").fetchall()
        conn.execute("UPDATE collector_status SET beat_at = now() WHERE id = 1")
    t0 = time.monotonic()
    for vc in vcs:
        if STOP:
            return
        one_vcenter(vc)
    with db() as conn:
        conn.execute("UPDATE collector_status SET beat_at = now(), last_cycle = now(), cycle_ms = %s, note = %s WHERE id = 1",
                     (int((time.monotonic() - t0) * 1000), f"{len(vcs)} vCenter(s)"))


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    def stop(*_):
        global STOP
        STOP = True
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    last_house = 0.0
    log.info("collector started: every %d s", config.COLLECT_SECONDS)
    while not STOP:
        start = time.monotonic()
        try:
            cycle()
            if time.monotonic() - last_house > 600:
                with db() as conn:
                    housekeeping(conn)
                last_house = time.monotonic()
        except Exception:  # noqa: BLE001 - keep going; the heartbeat shows the gap
            log.exception("collector cycle failed")
        wait = max(5.0, config.COLLECT_SECONDS - (time.monotonic() - start))
        while wait > 0 and not STOP:
            time.sleep(min(1.0, wait))
            wait -= 1.0


if __name__ == "__main__":
    main()
