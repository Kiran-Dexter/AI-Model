"""MONITOR-01: talking to other servers safely (vCenter, PATCH-01).

  * a host is a plain host name or a full IP address: no URL tricks, never this machine,
    link-local (cloud metadata), multicast or reserved addresses, checked again after DNS
  * TLS 1.2 or newer, and the far end must present the exact certificate an admin trusted
    (its SHA-256 fingerprint), checked right after the handshake, before a byte is sent
  * answers are size-limited and errors are told in plain words, never echoed from the far end
"""
import hashlib
import hmac
import http.client
import ipaddress
import json
import re
import socket
import ssl
import urllib.parse

TIMEOUT = 20
MAX_BODY = 8 * 2 ** 20
PIN_RE = re.compile(r"^[0-9a-f]{64}$")


class NetError(RuntimeError):
    """A problem worth showing to the admin as it is."""


def blocked(ip):
    ip = getattr(ip, "ipv4_mapped", None) or ip
    return ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_unspecified or ip.is_reserved


def clean_host(host):
    """A host name, a dotted IPv4 address or an IPv6 address; returned lower-case."""
    h = (host or "").strip().lower()
    if h.startswith("[") and h.endswith("]"):
        h = h[1:-1]
    if not h or len(h) > 253:
        raise NetError("Enter the server's name or address.")
    if ":" in h:
        try:
            ip = ipaddress.IPv6Address(h)
        except ValueError:
            raise NetError("That IPv6 address is not valid.")
        if blocked(ip):
            raise NetError("That address cannot be used (this machine, link-local or reserved).")
        return h
    if re.fullmatch(r"[0-9.]+|0x[0-9a-fx.]+", h):
        try:
            ip = ipaddress.IPv4Address(h)
        except ValueError:
            raise NetError("Write the address in full, for example 10.20.30.40.")
        if blocked(ip):
            raise NetError("That address cannot be used (this machine, link-local or reserved).")
        return h
    if h.endswith(".") or ".." in h or h in ("localhost", "localhost.localdomain") or h.endswith(".localhost") \
            or not all(re.fullmatch(r"[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?", lab) for lab in h.split(".")) \
            or h.split(".")[-1].isdigit():
        raise NetError("That host name is not valid.")
    return h


def clean_port(port):
    try:
        p = int(port)
    except (TypeError, ValueError):
        raise NetError("The port must be a number.")
    if not 1 <= p <= 65535:
        raise NetError("The port must be between 1 and 65535.")
    return p


def clean_pin(v):
    v = re.sub(r"[\s:]", "", (v or "")).lower()
    if not PIN_RE.match(v):
        raise NetError("The certificate fingerprint must be a SHA-256 value (64 hexadecimal characters).")
    return v


def fingerprint_text(hexstr):
    return ":".join(hexstr[i:i + 2] for i in range(0, len(hexstr), 2)).upper()


def resolve(host, port):
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except (socket.gaierror, UnicodeError):
        raise NetError(f"The name {host} does not resolve from MONITOR-01: check it, or use the address.")
    ips = []
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if blocked(ip):
            raise NetError(f"{host} resolves to an address that cannot be used.")
        if ip not in ips:
            ips.append(ip)
    if not ips:
        raise NetError(f"The name {host} does not resolve from MONITOR-01.")
    return ips


def pinned_context():
    """The chain and name are not used: the exact certificate is checked by its fingerprint."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    return ctx


def fail_text(e, what="the server"):
    if isinstance(e, NetError):
        return str(e)
    if isinstance(e, ssl.SSLError):
        return f"The TLS connection to {what} failed (it must offer TLS 1.2 or newer on this port)."
    if isinstance(e, (socket.timeout, TimeoutError)):
        return f"{what[0].upper() + what[1:]} did not answer in time: check the address, port and firewall from MONITOR-01."
    if isinstance(e, ConnectionRefusedError):
        return f"{what[0].upper() + what[1:]} refused the connection on this port: check the port."
    if isinstance(e, OSError):
        return f"Cannot reach {what}: check the address, port and firewall from MONITOR-01."
    return f"The answer from {what} could not be read."


class PinnedHTTPS(http.client.HTTPSConnection):
    """HTTPS to an address already checked, to one exact certificate (pin="" only reads it)."""

    def __init__(self, host, port, pin, timeout=TIMEOUT):
        super().__init__(host, port, context=pinned_context(), timeout=timeout)
        self._ip = str(resolve(host, port)[0])
        self._pin = pin
        self.peer_der = b""

    def connect(self):
        sock = socket.create_connection((self._ip, self.port), self.timeout)
        self.sock = self._context.wrap_socket(sock, server_hostname=self.host)
        self.peer_der = self.sock.getpeercert(binary_form=True) or b""
        if self._pin is not None and self._pin != "":
            got = hashlib.sha256(self.peer_der).hexdigest()
            if not hmac.compare_digest(got, self._pin):
                self.sock.close()
                raise NetError("The server's certificate has changed since it was trusted (SHA-256 now "
                               + fingerprint_text(got) + "). Check it, then trust the new certificate.")


def certificate(host, port):
    """The certificate a server presents, for an admin to compare and trust. Only the TLS
    handshake happens: nothing is sent."""
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    host, port = clean_host(host), clean_port(port)
    conn = PinnedHTTPS(host, port, pin="")
    try:
        conn.connect()
        der = conn.peer_der
    except NetError:
        raise
    except Exception as e:  # noqa: BLE001
        raise NetError(fail_text(e))
    finally:
        conn.close()
    if not der:
        raise NetError("The server presented no certificate.")
    c = x509.load_der_x509_certificate(der)

    def name(n):
        cn = n.get_attributes_for_oid(NameOID.COMMON_NAME)
        return (cn[0].value if cn else n.rfc4514_string())[:200]
    try:
        sans = c.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
        names = [str(x) for x in sans.get_values_for_type(x509.DNSName)] + \
                [str(x) for x in sans.get_values_for_type(x509.IPAddress)]
    except x509.ExtensionNotFound:
        names = []
    na = c.not_valid_after_utc if hasattr(c, "not_valid_after_utc") else c.not_valid_after
    sha = hashlib.sha256(der).hexdigest()
    return {"host": host, "port": port, "sha256": sha, "sha256_text": fingerprint_text(sha),
            "subject": name(c.subject), "issuer": name(c.issuer), "self_signed": c.subject == c.issuer,
            "names": names[:20], "not_after": na.isoformat()}


def request_json(base_url, pin, method, path, body=None, headers=None, timeout=TIMEOUT):
    """One HTTPS request to a pinned server. Returns (status, parsed JSON or None)."""
    u = urllib.parse.urlsplit(base_url)
    if u.scheme != "https" or not u.hostname or u.path not in ("", "/") or u.query or u.username:
        raise NetError("The URL must be https://host or https://host:port.")
    conn = PinnedHTTPS(clean_host(u.hostname), clean_port(u.port or 443), pin=clean_pin(pin), timeout=timeout)
    data = json.dumps(body).encode() if body is not None else None
    h = {"Accept": "application/json", "User-Agent": "monitor01"}
    if data is not None:
        h["Content-Type"] = "application/json"
    h.update(headers or {})
    try:
        conn.request(method, path, body=data, headers=h)
        r = conn.getresponse()
        raw = r.read(MAX_BODY + 1)
        if len(raw) > MAX_BODY:
            raise NetError("The answer was too large.")
        try:
            doc = json.loads(raw) if raw else None
        except ValueError:
            doc = None
        return r.status, doc
    except NetError:
        raise
    except Exception as e:  # noqa: BLE001
        raise NetError(fail_text(e))
    finally:
        conn.close()
