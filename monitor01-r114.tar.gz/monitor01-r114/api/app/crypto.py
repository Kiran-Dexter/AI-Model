"""MONITOR-01: secrets at rest (vCenter passwords), encrypted with monitor.key (Fernet).
The key is made by monitor01.sh on the server, readable by the API only, and never in the database."""
from . import config


class KeyError_(RuntimeError):
    pass


def _fernet():
    from cryptography.fernet import Fernet
    try:
        with open(config.KEY_FILE, "rb") as fh:
            return Fernet(fh.read().strip())
    except FileNotFoundError:
        raise KeyError_("monitor.key is missing on MONITOR-01: re-run monitor01.sh install.")
    except ValueError:
        raise KeyError_("monitor.key is not a valid key. Restore it from the backup of /etc/monitor01, "
                        "or make a new one and enter the vCenter passwords again.")


def encrypt(secret):
    return _fernet().encrypt(secret.encode()).decode()


def decrypt(token):
    from cryptography.fernet import InvalidToken
    try:
        return _fernet().decrypt(token.encode()).decode()
    except InvalidToken:
        raise KeyError_("A saved vCenter password cannot be read with this monitor.key: enter it again "
                        "in Admin, vCenter.")
