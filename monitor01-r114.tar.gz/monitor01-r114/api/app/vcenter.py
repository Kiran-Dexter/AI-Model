"""MONITOR-01 reads vCenter, and only reads it.

Read-only three times over:
  1. the vCenter account should hold the built-in Read-only role (monitor01.sh says how);
  2. every connection is fitted with an allow-list: only the handful of vCenter calls that read
     (log in, read properties, read performance figures, log out) can leave MONITOR-01; anything
     else is refused before it is sent, whatever the account may do;
  3. nothing in this code asks for a change.
The certificate is trusted by its SHA-256 fingerprint, checked by pyVmomi on every connection.
Nothing is installed in the VMs: CPU, memory, CPU ready, disk and network come from the hosts;
drive free space from VMware Tools (guest.disk), which every VM with Tools reports.
"""
import logging
import socket
import ssl
import time

from . import net

log = logging.getLogger("monitor01.vcenter")

ALLOWED_CALLS = frozenset({
    "RetrieveServiceContent", "Login", "Logout", "SessionIsActive", "CurrentTime",
    "Fetch",                        # pyVmomi's read of one property of an object (obj.name, perfManager.perfCounter)
    "CreateContainerView", "DestroyView",
    "RetrieveProperties", "RetrievePropertiesEx", "ContinueRetrievePropertiesEx", "CancelRetrievePropertiesEx",
    "QueryPerf", "QueryPerfCounter", "QueryPerfCounterByLevel", "QueryPerfProviderSummary", "QueryAvailablePerfMetric",
})
BATCH = 500
PERF_BATCH = 120
PERF_INTERVAL = 20         # vCenter's real-time interval, seconds

VM_PROPS = ["name", "config.instanceUuid", "config.template", "config.guestFullName", "config.guestId",
            "config.hardware.numCPU", "config.hardware.memoryMB", "config.annotation",
            "summary.config.product", "runtime.powerState", "runtime.host", "runtime.bootTime",
            "guest.guestFamily", "guest.guestFullName", "guest.hostName", "guest.ipAddress", "guest.disk",
            "guest.toolsRunningStatus", "summary.quickStats.overallCpuUsage", "summary.quickStats.guestMemoryUsage",
            "summary.quickStats.balloonedMemory", "summary.quickStats.swappedMemory",
            "summary.runtime.maxCpuUsage", "snapshot"]
HOST_PROPS = ["name", "parent", "runtime.connectionState", "runtime.inMaintenanceMode",
              "summary.hardware.cpuMhz", "summary.hardware.numCpuCores", "summary.hardware.memorySize",
              "summary.quickStats.overallCpuUsage", "summary.quickStats.overallMemoryUsage"]
DS_PROPS = ["name", "summary.type", "summary.capacity", "summary.freeSpace", "summary.accessible", "vm"]
COUNTERS = {"cpu.usage.average": "cpu", "cpu.ready.summation": "ready", "mem.usage.average": "mem",
            "net.usage.average": "net", "disk.usage.average": "disk", "disk.maxTotalLatency.latest": "lat"}


class Refused(RuntimeError):
    """A vCenter call not on the read-only list was refused before it was sent."""


class VcError(RuntimeError):
    """A problem worth showing to the admin as it is."""


def guard(si):
    """Only reading calls leave MONITOR-01 (pyVmomi sends every call through stub.InvokeMethod)."""
    stub = getattr(si, "_stub", None)
    real = getattr(stub, "InvokeMethod", None)
    if real is None:
        raise VcError("This pyVmomi cannot be fitted with the read-only guard: not connecting.")
    if getattr(real, "_mon_guard", False):
        return si

    def invoke(mo, info, args, *more, **kw):
        name = getattr(info, "wsdlName", None) or getattr(info, "name", None) or ""
        if name not in ALLOWED_CALLS:
            log.error("vCenter call refused (MONITOR-01 only reads): %s", name)
            raise Refused(f"MONITOR-01 refused to send {name} to vCenter: it only reads.")
        return real(mo, info, args, *more, **kw)
    invoke._mon_guard = True
    stub.InvokeMethod = invoke
    return si


def connect(vc, password):
    """A guarded, pinned connection. vc: {host, port, username, pin_sha256}."""
    from pyVim.connect import SmartConnect
    host, port, pin = net.clean_host(vc["host"]), net.clean_port(vc["port"]), net.clean_pin(vc["pin_sha256"])
    net.resolve(host, port)                       # refuses loopback, link-local, metadata addresses
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE   # the exact certificate is checked instead:
    socket.setdefaulttimeout(60)
    try:
        si = SmartConnect(host=host, port=port, user=vc["username"], pwd=password, sslContext=ctx,
                          thumbprint=pin, connectionPoolTimeout=60, disableSslCertValidation=False)
    except TypeError:
        si = SmartConnect(host=host, port=port, user=vc["username"], pwd=password, sslContext=ctx, thumbprint=pin)
    except Exception as e:  # noqa: BLE001
        raise VcError(why(e))
    return guard(si)


def why(e):
    t = type(e).__name__.rsplit(".", 1)[-1]          # pyVmomi names faults in full: vim.fault.NoPermission
    msg = str(getattr(e, "msg", "") or e)
    if isinstance(e, Refused):
        return str(e)
    if "Thumbprint" in t or "thumbprint" in msg.lower():
        return ("vCenter's certificate is not the one trusted (fingerprint differs). If vCenter's certificate "
                "was renewed, check the new fingerprint and trust it again in Admin, vCenter.")
    if t == "InvalidLogin" or "incorrect user name or password" in msg.lower():
        return "vCenter did not accept the user name or password."
    if t == "NoPermission":
        return "The vCenter account lacks a read permission (give it the Read-only role at the vCenter level)."
    return net.fail_text(e, "vCenter")


def disconnect(si):
    try:
        from pyVim.connect import Disconnect
        Disconnect(si)
    except Exception:  # noqa: BLE001
        pass


def collect(si, vimtype, props):
    from pyVmomi import vim, vmodl
    content = si.RetrieveContent()
    view = content.viewManager.CreateContainerView(content.rootFolder, [vimtype], True)
    try:
        ts = vmodl.query.PropertyCollector.TraversalSpec(name="traverse", path="view", skip=False,
                                                          type=vim.view.ContainerView)
        obj = vmodl.query.PropertyCollector.ObjectSpec(obj=view, skip=True, selectSet=[ts])
        prop = vmodl.query.PropertyCollector.PropertySpec(type=vimtype, pathSet=props, all=False)
        spec = vmodl.query.PropertyCollector.FilterSpec(objectSet=[obj], propSet=[prop])
        pc = content.propertyCollector
        res = pc.RetrievePropertiesEx([spec], vmodl.query.PropertyCollector.RetrieveOptions(maxObjects=BATCH))
        out = []
        while res:
            for o in res.objects or []:
                out.append((o.obj, {p.name: p.val for p in (o.propSet or [])}))
            if not res.token:
                break
            res = pc.ContinueRetrievePropertiesEx(res.token)
        return out
    finally:
        view.Destroy()


# ---- plain data from vCenter's objects (testable without vCenter) ------------------------------

def moid(o):
    return getattr(o, "_moId", None) or (o if isinstance(o, str) else None)


def _snapshots(info):
    n, oldest, stack = 0, None, list(getattr(info, "rootSnapshotList", None) or [])
    while stack:
        s = stack.pop()
        n += 1
        ct = getattr(s, "createTime", None)
        if ct and (oldest is None or ct < oldest):
            oldest = ct
        stack.extend(getattr(s, "childSnapshotList", None) or [])
    return n, oldest


def _power(v):
    s = str(v or "")
    return {"poweredOn": "on", "poweredOff": "off", "suspended": "suspended"}.get(s, "unknown")


def vm_row(obj, p):
    """One VM's properties as plain data, or None for a template."""
    if p.get("config.template"):
        return None
    prod = p.get("summary.config.product")
    product = " ".join(x for x in (getattr(prod, "vendor", None), getattr(prod, "name", None)) if x) if prod else ""
    n, oldest = _snapshots(p.get("snapshot"))
    disks = [{"path": getattr(d, "diskPath", None), "capacity": getattr(d, "capacity", 0) or 0,
              "free": getattr(d, "freeSpace", 0) or 0} for d in (p.get("guest.disk") or [])]
    mem_mb = p.get("config.hardware.memoryMB") or 0
    gmu = p.get("summary.quickStats.guestMemoryUsage")
    max_cpu = p.get("summary.runtime.maxCpuUsage") or 0
    cpu_mhz = p.get("summary.quickStats.overallCpuUsage")
    tools = str(p.get("guest.toolsRunningStatus") or "")
    return {
        "moref": moid(obj), "name": str(p.get("name") or moid(obj))[:200],
        "uuid": p.get("config.instanceUuid"),
        "guest_full": (p.get("guest.guestFullName") or p.get("config.guestFullName") or "")[:200],
        "guest_id": (p.get("config.guestId") or "")[:80], "guest_family": (p.get("guest.guestFamily") or "")[:40],
        "product": product[:120], "host_moref": moid(p.get("runtime.host")),
        "num_cpu": p.get("config.hardware.numCPU"), "memory_mb": mem_mb,
        "power": _power(p.get("runtime.powerState")),
        "tools": {"guestToolsRunning": "running", "guestToolsNotRunning": "not running",
                  "guestToolsExecutingScripts": "starting"}.get(tools, tools or None),
        "ip": (p.get("guest.ipAddress") or None), "guest_host": p.get("guest.hostName"),
        "boot_time": p.get("runtime.bootTime"), "annotation": (p.get("config.annotation") or "")[:500] or None,
        "snapshots": n, "oldest_snapshot": oldest, "disks": disks,
        # quick figures, replaced by the performance counters when vCenter has them
        "cpu_pct": round(100.0 * cpu_mhz / max_cpu, 1) if cpu_mhz is not None and max_cpu else None,
        "mem_pct": round(100.0 * gmu / mem_mb, 1) if gmu is not None and mem_mb else None,
        "balloon_mb": p.get("summary.quickStats.balloonedMemory"), "swap_mb": p.get("summary.quickStats.swappedMemory"),
    }


def host_row(obj, p):
    parent = p.get("parent")
    cluster = getattr(parent, "name", None) if parent is not None and "ClusterComputeResource" in type(parent).__name__ else None
    mhz, cores = p.get("summary.hardware.cpuMhz") or 0, p.get("summary.hardware.numCpuCores") or 0
    return {"moref": moid(obj), "name": str(p.get("name") or moid(obj))[:200], "cluster": cluster,
            "connection": str(p.get("runtime.connectionState") or "connected"),
            "maintenance": bool(p.get("runtime.inMaintenanceMode")),
            "cpu_mhz_total": mhz * cores or None, "cpu_mhz_used": p.get("summary.quickStats.overallCpuUsage"),
            "mem_mb_total": int((p.get("summary.hardware.memorySize") or 0) / 1048576) or None,
            "mem_mb_used": p.get("summary.quickStats.overallMemoryUsage")}


def ds_row(obj, p):
    return {"moref": moid(obj), "name": str(p.get("name") or moid(obj))[:200], "type": p.get("summary.type"),
            "capacity_b": p.get("summary.capacity"), "free_b": p.get("summary.freeSpace"),
            "accessible": bool(p.get("summary.accessible", True)), "vms": len(p.get("vm") or [])}


def perf_values(series, num_cpu):
    """Real-time counter series of one VM -> {cpu, mem, ready, net, disk, lat}, averaged over
    the samples returned (the last minute)."""
    out = {}
    for key, vals in series.items():
        vals = [v for v in vals if v is not None and v >= 0]
        if not vals:
            continue
        avg = sum(vals) / len(vals)
        if key in ("cpu", "mem"):
            out[key] = round(avg / 100.0, 1)             # vCenter gives hundredths of a percent
        elif key == "ready":
            from .model import ready_pct
            out[key] = ready_pct(avg, num_cpu, PERF_INTERVAL)
        elif key == "lat":
            out[key] = float(max(vals))
        else:
            out[key] = round(avg, 1)                     # KBps
    return out


def fetch_perf(si, vms):
    """CPU, memory, CPU ready, network and disk for every powered-on VM: one QueryPerf call per
    PERF_BATCH VMs, three real-time samples (one minute) each."""
    from pyVmomi import vim
    content = si.RetrieveContent()
    pm = content.perfManager
    ids = {}
    for c in pm.perfCounter:
        k = f"{c.groupInfo.key}.{c.nameInfo.key}.{c.rollupType}"
        if k in COUNTERS:
            ids[c.key] = COUNTERS[k]
    if not ids:
        return {}
    metric = [vim.PerformanceManager.MetricId(counterId=i, instance="") for i in ids]
    out = {}
    on = [(obj, v) for obj, v in vms if v["power"] == "on"]
    for i in range(0, len(on), PERF_BATCH):
        part = on[i:i + PERF_BATCH]
        specs = [vim.PerformanceManager.QuerySpec(entity=obj, metricId=metric, intervalId=PERF_INTERVAL, maxSample=3)
                 for obj, _ in part]
        try:
            res = pm.QueryPerf(querySpec=specs) or []
        except Exception as e:  # noqa: BLE001 - quick figures are kept for this batch
            log.warning("performance figures not read for %d VMs: %s", len(part), type(e).__name__)
            continue
        cpus = {moid(obj): v.get("num_cpu") for obj, v in part}
        for em in res:
            series = {}
            for s in em.value or []:
                key = ids.get(s.id.counterId)
                if key:
                    series.setdefault(key, []).extend(list(s.value or []))
            out[moid(em.entity)] = perf_values(series, cpus.get(moid(em.entity)))
    return out


def read_all(vc, password):
    """Everything MONITOR-01 shows, for one vCenter, as plain data."""
    t0 = time.monotonic()
    si = connect(vc, password)
    try:
        hosts = [host_row(o, p) for o, p in collect(si, _vim().HostSystem, HOST_PROPS)]
        dss = [ds_row(o, p) for o, p in collect(si, _vim().Datastore, DS_PROPS)]
        raw = [(o, vm_row(o, p)) for o, p in collect(si, _vim().VirtualMachine, VM_PROPS)]
        raw = [(o, v) for o, v in raw if v]
        perf = fetch_perf(si, raw)
    finally:
        disconnect(si)
    names = {h["moref"]: h for h in hosts}
    vms = []
    for _, v in raw:
        h = names.get(v["host_moref"]) or {}
        v["host_name"], v["cluster"] = h.get("name"), h.get("cluster")
        p = perf.get(v["moref"]) or {}
        for k, col in (("cpu", "cpu_pct"), ("mem", "mem_pct"), ("ready", "ready_pct")):
            if p.get(k) is not None:
                v[col] = p[k]
        v["ready_pct"] = v.get("ready_pct") if "ready" in p else None
        v["net_kbps"], v["disk_kbps"], v["disk_lat_ms"] = p.get("net"), p.get("disk"), p.get("lat")
        vms.append(v)
    for h in hosts:
        h["vms"] = sum(1 for v in vms if v["host_moref"] == h["moref"])
    return {"hosts": hosts, "datastores": dss, "vms": vms, "ms": int((time.monotonic() - t0) * 1000)}


def _vim():
    from pyVmomi import vim
    return vim


def test(vc, password):
    """Log in, count what can be read, log out. Nothing else."""
    si = connect(vc, password)
    try:
        about = si.RetrieveContent().about
        n = len(collect(si, _vim().VirtualMachine, ["name"]))
        return {"version": f"{getattr(about, 'fullName', '')}"[:120], "vms": n}
    finally:
        disconnect(si)
