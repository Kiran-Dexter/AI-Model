"""MONITOR-01 signs people in with their PATCH-01 account, over HTTPS to PATCH-01's certificate.

The password goes to PATCH-01 only: MONITOR-01 never stores it. PATCH-01 checks it (and the
two-factor code), counts failures and locks accounts as it always does. MONITOR-01 then reads the
role and modules, ends the PATCH-01 session at once, and opens its own session.

Who may open MONITOR-01: PATCH-01 admins, and users with one of MON_ALLOWED_MODULES (default:
inventory or patch). Roles carry over: viewer sees, operator also acknowledges alerts, admin also
manages vCenter and thresholds.

When MONITOR-01 moves to its own server nothing here changes but PATCH01_URL.
"""
import base64
import logging
import urllib.parse

from . import config, net

log = logging.getLogger("monitor01.patch01")
HDR = {"X-Requested-With": "patch01-dashboard"}       # PATCH-01 then sends no Basic challenge


class AuthError(Exception):
    def __init__(self, msg, status=401):
        super().__init__(msg)
        self.status = status


def configured():
    return bool(config.PATCH01_URL and net.PIN_RE.match(config.PATCH01_PIN or ""))


def _call(method, path, body=None, token=None, basic=None):
    h = dict(HDR)
    if token:
        h["Authorization"] = "Bearer " + token
    if basic:
        h["Authorization"] = "Basic " + base64.b64encode(f"{basic[0]}:{basic[1]}".encode()).decode()
    try:
        return net.request_json(config.PATCH01_URL, config.PATCH01_PIN, method, path, body, h)
    except net.NetError as e:
        log.warning("PATCH-01 unreachable: %s", e)
        raise AuthError("PATCH-01 cannot be reached to check your password right now. Try again, or use the "
                        "local admin account. (Details are in MONITOR-01's log.)", 503)


def _detail(doc, fallback):
    d = (doc or {}).get("detail") if isinstance(doc, dict) else None
    return d[:300] if isinstance(d, str) and d else fallback


def _finish(token):
    """Read who this is, then end the PATCH-01 session straight away."""
    try:
        st, me = _call("GET", "/api/v1/auth/me", token=token)
    finally:
        try:
            _call("POST", "/api/v1/auth/logout", body={}, token=token)
        except AuthError:
            pass
    if st != 200 or not isinstance(me, dict):
        raise AuthError("PATCH-01 accepted the password but did not say who you are. Try again.", 502)
    return access(me)


def access(me):
    """The MONITOR-01 user from PATCH-01's /auth/me, or AuthError saying why not."""
    role = me.get("role")
    if role not in ("viewer", "operator", "admin"):
        raise AuthError("Your PATCH-01 account has no role that MONITOR-01 knows.", 403)
    if me.get("must_change_password"):
        raise AuthError("Change your password in the PATCH-01 console first, then sign in here.", 403)
    if me.get("must_setup_2fa"):
        raise AuthError("Set up two-factor sign-in in the PATCH-01 console first, then sign in here.", 403)
    mods = set(me.get("modules") or [])
    if role != "admin" and not (mods & config.ALLOWED_MODULES):
        raise AuthError("Your PATCH-01 account does not include MONITOR-01. An admin can give you the "
                        + " or ".join(sorted(config.ALLOWED_MODULES)) + " module in PATCH-01.", 403)
    return {"username": str(me.get("username") or "")[:64], "role": role,
            "display_name": str(me.get("display_name") or "")[:120] or None}


def login(username, password):
    """('ok', user) or ('mfa', ticket); AuthError otherwise."""
    if not configured():
        raise AuthError("Sign-in through PATCH-01 is not set up on this MONITOR-01 (PATCH01_URL).", 503)
    st, doc = _call("POST", "/api/v1/auth/login", {"username": username, "password": password})
    if st == 200 and isinstance(doc, dict) and doc.get("mfa_required") and doc.get("mfa_ticket"):
        return "mfa", str(doc["mfa_ticket"])[:100]
    if st == 200 and isinstance(doc, dict) and doc.get("token"):
        return "ok", _finish(str(doc["token"]))
    if st in (400, 401, 403, 422, 429):
        raise AuthError(_detail(doc, "That username and password were not accepted."), 401)
    raise AuthError("PATCH-01 could not check the password right now. Try again.", 502)


def login_second_factor(ticket, code):
    if not configured():
        raise AuthError("Sign-in through PATCH-01 is not set up on this MONITOR-01.", 503)
    st, doc = _call("POST", "/api/v1/auth/login/2fa", {"mfa_ticket": ticket, "code": code})
    if st == 200 and isinstance(doc, dict) and doc.get("token"):
        return _finish(str(doc["token"]))
    if st in (400, 401, 403, 422, 429):
        raise AuthError(_detail(doc, "That code was not accepted."), 401)
    raise AuthError("PATCH-01 could not check the code right now. Try again.", 502)


# ---- a VM's patch status (optional, read-only service account) ----------------------------------

def _svc():
    if not (configured() and config.PATCH01_SVC_USER):
        return None
    try:
        with open(config.PATCH01_SVC_PASSWORD_FILE) as fh:
            pw = fh.read().strip()
    except OSError:
        return None
    return (config.PATCH01_SVC_USER, pw) if pw else None


def short(n):
    return (n or "").strip().lower().split(".")[0]


def patch_status(vm_name, guest_host=None):
    """What PATCH-01 knows about the server in this VM, or None when not linked/not found."""
    cred = _svc()
    if not cred:
        return None
    names = {short(vm_name), short(guest_host)} - {""}
    if not names:
        return None
    for q in names:
        st, doc = _call("GET", "/api/v1/servers?" + urllib.parse.urlencode({"q": q}), basic=cred)
        if st != 200 or not isinstance(doc, dict):
            return {"error": "PATCH-01 did not answer the lookup."}
        for r in doc.get("rows") or []:
            if short(r.get("hostname")) in names or short(r.get("fqdn")) in names:
                return {"hostname": r.get("hostname"), "to_install": r.get("to_install"),
                        "reboot": bool(r.get("reboot_required") or r.get("pending_reboot")),
                        "last_patch_at": r.get("last_patch_at"), "last_patch_state": r.get("last_patch_state"),
                        "agent": r.get("agent"), "console": config.PATCH01_URL + "/"}
    return {"not_found": True, "console": config.PATCH01_URL + "/"}
