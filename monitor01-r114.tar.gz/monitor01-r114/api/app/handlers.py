"""MONITOR-01 API: what each request does. main.py only wires these to URLs, so the same code
runs in the tests. Every function gets a database connection (one transaction) or opens its own
when it must call another server first (sign-in through PATCH-01, testing a vCenter)."""
import json
import re
from datetime import datetime, timezone

from . import config, crypto, model, net, patch01, security
from . import db as dbm


class HandlerError(Exception):
    def __init__(self, status, msg):
        super().__init__(msg)
        self.status = status


RANGES = {   # range -> (table, span, bin for sparklines, bin for charts)
    "1h": ("raw", "1 hour", "5 minutes", "1 minute"),
    "6h": ("raw", "6 hours", "15 minutes", "5 minutes"),
    "24h": ("raw", "24 hours", "1 hour", "15 minutes"),
    "7d": ("hourly", "7 days", "6 hours", "2 hours"),
    "30d": ("hourly", "30 days", "1 day", "6 hours"),
}


def clean_range(r):
    return r if r in RANGES else "24h"


def now():
    return datetime.now(timezone.utc)


def settings(conn):
    row = conn.execute("SELECT value FROM settings WHERE key = 'rules'").fetchone()
    return model.merged(row["value"] if row else None)


# ---- history -------------------------------------------------------------------------------------

SERIES_RAW = """
SELECT vm_id, date_bin(%(bin)s::interval, ts, timestamptz '2000-01-01') AS t,
       avg(cpu_pct) AS cpu, avg(mem_pct) AS mem, avg(ready_pct) AS ready, max(disk_pct) AS disk
  FROM vm_samples
 WHERE vm_id = ANY(%(ids)s::bigint[]) AND ts > now() - %(span)s::interval
 GROUP BY 1, 2 ORDER BY 1, 2"""
SERIES_HOURLY = """
SELECT vm_id, date_bin(%(bin)s::interval, ts, timestamptz '2000-01-01') AS t,
       avg(cpu_avg) AS cpu, avg(mem_avg) AS mem, avg(ready_avg) AS ready, max(disk_max) AS disk
  FROM vm_hourly
 WHERE vm_id = ANY(%(ids)s::bigint[]) AND ts > now() - %(span)s::interval
 GROUP BY 1, 2 ORDER BY 1, 2"""


def series(conn, ids, rng, kind="spark"):
    """{vm_id: [{t, cpu, mem, ready, disk}]} for the time range, binned for a sparkline or a chart."""
    ids = [int(i) for i in ids][:500]
    if not ids:
        return {}
    table, span, sbin, cbin = RANGES[clean_range(rng)]
    out = {}
    for r in conn.execute(SERIES_RAW if table == "raw" else SERIES_HOURLY,
                          {"ids": ids, "span": span, "bin": sbin if kind == "spark" else cbin}):
        out.setdefault(r["vm_id"], []).append(
            {"t": r["t"], **{k: None if r[k] is None else round(float(r[k]), 1) for k in ("cpu", "mem", "ready", "disk")}})
    return out


# ---- the overview ---------------------------------------------------------------------------------

VM_COLS = """v.id, v.name, v.kind, v.kind_reason, v.state, v.power, v.cpu_pct, v.mem_pct, v.ready_pct, v.disk_pct,
             v.drives_reported, v.host_name, v.cluster, v.guest_full, v.num_cpu, v.memory_mb, v.ip, v.boot_time,
             v.net_kbps, v.tools, v.snapshots, v.last_seen, vc.name AS vcenter"""
LIVE_VMS = "SELECT " + VM_COLS + " FROM vms v JOIN vcenters vc ON vc.id = v.vcenter_id WHERE v.gone_at IS NULL"
LIVE_HOSTS = """SELECT h.*, vc.name AS vcenter FROM hosts h JOIN vcenters vc ON vc.id = h.vcenter_id
                 WHERE h.gone_at IS NULL ORDER BY h.name"""
LIVE_DS = """SELECT d.*, vc.name AS vcenter FROM datastores d JOIN vcenters vc ON vc.id = d.vcenter_id
              WHERE d.gone_at IS NULL ORDER BY d.name"""
OPEN_ALERTS = """SELECT a.id, a.vm_id, a.rule, a.item, a.level, a.value, a.threshold, a.peak, a.opened_at, a.last_seen_at,
                        a.acked_at, a.acked_by, v.name AS vm, v.kind
                   FROM alerts a JOIN vms v ON v.id = a.vm_id
                  WHERE a.cleared_at IS NULL AND v.gone_at IS NULL
                  ORDER BY a.opened_at DESC, a.id DESC"""
TOP_DRIVES = """SELECT d.vm_id, d.path, d.capacity_b, d.free_b, d.used_pct, v.name, v.kind
                  FROM vm_drives d JOIN vms v ON v.id = d.vm_id
                 WHERE v.gone_at IS NULL AND v.power = 'on'
                 ORDER BY d.used_pct DESC, v.name LIMIT %(n)s"""


def _num(x):
    return None if x is None else round(float(x), 1)


def vm_brief(v):
    return {"id": v["id"], "name": v["name"], "kind": v["kind"], "state": v["state"], "power": v["power"],
            "cpu": _num(v["cpu_pct"]), "mem": _num(v["mem_pct"]), "ready": _num(v["ready_pct"]),
            "disk": _num(v["disk_pct"]), "drives": v["drives_reported"], "host": v["host_name"],
            "os": v["guest_full"], "net": _num(v["net_kbps"]), "boot": v["boot_time"], "why": v["kind_reason"],
            "vcenter": v["vcenter"]}


def alert_brief(a):
    t = now()
    return {"id": a["id"], "vm_id": a["vm_id"], "vm": a["vm"], "kind": a["kind"], "rule": a["rule"], "item": a["item"],
            "value": _num(a["value"]), "peak": _num(a["peak"]), "threshold": _num(a["threshold"]),
            "text": model.alert_text(a["rule"], a["item"], a["value"]),
            "opened_at": a["opened_at"], "minutes": max(0, int((t - a["opened_at"]).total_seconds() // 60)),
            "acked_at": a["acked_at"], "acked_by": a["acked_by"]}


def status(conn):
    c = conn.execute("SELECT beat_at, last_cycle, cycle_ms FROM collector_status WHERE id = 1").fetchone() or {}
    vcs = conn.execute("""SELECT id, name, enabled, last_ok_at, last_run_at, last_error, last_ms, counts
                            FROM vcenters ORDER BY name""").fetchall()
    ok = [v["last_ok_at"] for v in vcs if v["enabled"] and v["last_ok_at"]]
    t = now()
    return {"now": t, "collector_beat": c.get("beat_at"), "last_read": max(ok) if ok else None,
            "every_s": config.COLLECT_SECONDS,
            "collector_ok": bool(c.get("beat_at")) and (t - c["beat_at"]).total_seconds() < config.COLLECT_SECONDS * 3 + 60,
            "vcenters": [{"name": v["name"], "enabled": v["enabled"], "last_ok_at": v["last_ok_at"],
                          "error": v["last_error"] if v["last_error"] and (not v["last_ok_at"] or
                                   (v["last_run_at"] and v["last_run_at"] > v["last_ok_at"])) else None}
                         for v in vcs]}


def overview(conn, rng="24h"):
    rng = clean_range(rng)
    st = settings(conn)
    th = st["thresholds"]
    vms = conn.execute(LIVE_VMS + " ORDER BY lower(v.name)").fetchall()
    hosts = conn.execute(LIVE_HOSTS).fetchall()
    dss = conn.execute(LIVE_DS).fetchall()
    alerts = conn.execute(OPEN_ALERTS).fetchall()
    on = [v for v in vms if v["power"] == "on"]
    busiest = sorted([v for v in on if v["cpu_pct"] is not None], key=lambda v: -v["cpu_pct"])[:6]
    waiting = sorted([v for v in on if v["ready_pct"] is not None], key=lambda v: -v["ready_pct"])[:6]
    attention = {k: sorted([v for v in vms if v["kind"] == k and v["state"] in ("crit", "warn")], key=model.worst_first)[:40]
                 for k in model.KINDS}
    appliances = sorted([v for v in vms if v["kind"] == "appliance"], key=model.worst_first)[:200]
    spark_ids = {v["id"] for v in busiest} | {v["id"] for k in attention for v in attention[k]} | \
                {v["id"] for v in appliances[:60]}
    sp = series(conn, spark_ids, rng, "spark")

    def with_spark(v):
        b = vm_brief(v)
        b["spark"] = [p["cpu"] for p in sp.get(v["id"], [])]
        return b
    return {
        "range": rng, "thresholds": th, "status": status(conn),
        "kpis": model.kpis(vms, hosts, alerts, th),
        "rings": model.rings(hosts, dss, th),
        "groups": {k: [[v["id"], v["name"], v["state"], model.tip(v)] for v in vms if v["kind"] == k] for k in model.KINDS},
        "drives": [{"vm_id": d["vm_id"], "vm": d["name"], "kind": d["kind"], "path": d["path"], "used": _num(d["used_pct"]),
                    "capacity_b": d["capacity_b"], "free_b": d["free_b"]} for d in conn.execute(TOP_DRIVES, {"n": 8})],
        "busiest": [with_spark(v) for v in busiest],
        "waiting": [vm_brief(v) for v in waiting],
        "attention": {k: [with_spark(v) for v in attention[k]] for k in model.KINDS},
        "attention_total": {k: sum(1 for v in vms if v["kind"] == k and v["state"] in ("crit", "warn")) for k in model.KINDS},
        "appliances": [with_spark(v) for v in appliances],
        "alerts": len(alerts),
        "patch01": {"linked": bool(config.PATCH01_SVC_USER and patch01.configured()), "url": config.PATCH01_URL or None},
    }


def live(conn):
    """What the alert strip needs, polled every 15 seconds."""
    alerts = conn.execute(OPEN_ALERTS).fetchall()
    top = conn.execute("SELECT coalesce(max(id), 0) AS m FROM alerts").fetchone()["m"]
    return {"alerts": [alert_brief(a) for a in alerts if not a["acked_at"]][:60],
            "unacked": sum(1 for a in alerts if not a["acked_at"]), "acked": sum(1 for a in alerts if a["acked_at"]),
            "max_id": top, "status": status(conn)}


# ---- lists and one VM --------------------------------------------------------------------------------

SORTS = {"name": "lower(v.name)", "cpu": "v.cpu_pct DESC NULLS LAST, lower(v.name)",
         "mem": "v.mem_pct DESC NULLS LAST, lower(v.name)", "disk": "v.disk_pct DESC NULLS LAST, lower(v.name)",
         "ready": "v.ready_pct DESC NULLS LAST, lower(v.name)",
         "state": "CASE v.state WHEN 'crit' THEN 0 WHEN 'warn' THEN 1 WHEN 'unknown' THEN 2 WHEN 'ok' THEN 3 ELSE 4 END, "
                  "greatest(coalesce(v.cpu_pct,0), coalesce(v.mem_pct,0), coalesce(v.disk_pct,0)) DESC, lower(v.name)"}
PAGE = 50


def vm_list(conn, kind=None, state=None, q=None, sort="state", page=1, rng="24h"):
    where, args = ["v.gone_at IS NULL"], {}
    if kind in model.KINDS:
        where.append("v.kind = %(kind)s")
        args["kind"] = kind
    if state in ("crit", "warn", "ok", "off", "unknown"):
        where.append("v.state = %(state)s")
        args["state"] = state
    q = (q or "").strip()[:80]
    if q:
        where.append("(v.name ILIKE %(q)s OR v.host_name ILIKE %(q)s OR v.guest_full ILIKE %(q)s OR v.ip ILIKE %(q)s)")
        args["q"] = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    base = " FROM vms v JOIN vcenters vc ON vc.id = v.vcenter_id WHERE " + " AND ".join(where)
    total = conn.execute("SELECT count(*) AS n" + base, args).fetchone()["n"]
    page = max(1, min(int(page or 1), max(1, (total + PAGE - 1) // PAGE)))
    rows = conn.execute("SELECT " + VM_COLS + base + " ORDER BY " + SORTS.get(sort, SORTS["state"])
                        + " LIMIT %(lim)s OFFSET %(off)s", dict(args, lim=PAGE, off=(page - 1) * PAGE)).fetchall()
    sp = series(conn, [r["id"] for r in rows], rng, "spark")
    counts = {r["kind"]: r["n"] for r in conn.execute(
        "SELECT kind, count(*) AS n FROM vms WHERE gone_at IS NULL GROUP BY kind")}
    return {"total": total, "page": page, "pages": max(1, (total + PAGE - 1) // PAGE), "counts": counts,
            "rows": [dict(vm_brief(r), spark=[p["cpu"] for p in sp.get(r["id"], [])]) for r in rows]}


def vm_detail(conn, vm_id, rng="24h"):
    v = conn.execute("""SELECT v.*, vc.name AS vcenter FROM vms v JOIN vcenters vc ON vc.id = v.vcenter_id
                         WHERE v.id = %s""", (int(vm_id),)).fetchone()
    if not v:
        raise HandlerError(404, "That VM is not known (it may have been removed from vCenter).")
    th = settings(conn)["thresholds"]
    drives = conn.execute("SELECT path, capacity_b, free_b, used_pct FROM vm_drives WHERE vm_id = %s ORDER BY path",
                          (v["id"],)).fetchall()
    hist = conn.execute("""SELECT a.id, a.vm_id, a.rule, a.item, a.level, a.value, a.threshold, a.peak, a.opened_at,
                                  a.last_seen_at, a.acked_at, a.acked_by, a.cleared_at, %s::text AS vm, %s::text AS kind
                             FROM alerts a WHERE a.vm_id = %s ORDER BY a.opened_at DESC LIMIT 20""",
                        (v["name"], v["kind"], v["id"])).fetchall()
    out = vm_brief(v)
    out.update({"num_cpu": v["num_cpu"], "memory_mb": v["memory_mb"], "ip": v["ip"], "tools": v["tools"],
                "cluster": v["cluster"], "snapshots": v["snapshots"], "oldest_snapshot": v["oldest_snapshot"],
                "disk_lat_ms": _num(v["disk_lat_ms"]), "disk_kbps": _num(v["disk_kbps"]), "balloon_mb": v["balloon_mb"],
                "swap_mb": v["swap_mb"], "annotation": v["annotation"], "kind_override": v["kind_override"],
                "gone_at": v["gone_at"], "last_seen": v["last_seen"], "range": clean_range(rng), "thresholds": th,
                "drives": [{"path": d["path"], "capacity_b": d["capacity_b"], "free_b": d["free_b"], "used": _num(d["used_pct"])}
                           for d in drives],
                "series": series(conn, [v["id"]], rng, "chart").get(v["id"], []),
                "alerts": [dict(alert_brief(a), cleared_at=a["cleared_at"]) for a in hist]})
    return out


def hosts(conn):
    th = settings(conn)["thresholds"]
    rows = conn.execute(LIVE_HOSTS).fetchall()
    bad = {r["host_moref"]: r for r in conn.execute(
        """SELECT host_moref, count(*) FILTER (WHERE state = 'crit') AS crit, count(*) FILTER (WHERE state = 'warn') AS warn,
                  count(*) FILTER (WHERE power = 'on') AS on_
             FROM vms WHERE gone_at IS NULL GROUP BY host_moref""")}
    out = []
    for h in rows:
        cpu = None if not h["cpu_mhz_total"] else round(100.0 * (h["cpu_mhz_used"] or 0) / h["cpu_mhz_total"], 1)
        mem = None if not h["mem_mb_total"] else round(100.0 * (h["mem_mb_used"] or 0) / h["mem_mb_total"], 1)
        b = bad.get(h["moref"]) or {}
        out.append({"id": h["id"], "name": h["name"], "cluster": h["cluster"], "vcenter": h["vcenter"],
                    "connection": h["connection"], "maintenance": h["maintenance"], "cpu": cpu, "mem": mem,
                    "cpu_ghz": round((h["cpu_mhz_total"] or 0) / 1000, 1), "mem_gb": round((h["mem_mb_total"] or 0) / 1024),
                    "vms": h["vms"], "vms_on": b.get("on_", 0), "vm_crit": b.get("crit", 0), "vm_warn": b.get("warn", 0),
                    "state": "off" if h["connection"] != "connected" else
                             model.level(max(x for x in (cpu, mem, 0) if x is not None), th)})
    return {"rows": out, "thresholds": th}


def datastores(conn):
    th = settings(conn)["thresholds"]
    out = []
    for d in conn.execute(LIVE_DS):
        used = None if not d["capacity_b"] else round(100.0 * (d["capacity_b"] - (d["free_b"] or 0)) / d["capacity_b"], 1)
        out.append({"id": d["id"], "name": d["name"], "type": d["type"], "vcenter": d["vcenter"],
                    "capacity_b": d["capacity_b"], "free_b": d["free_b"], "used": used, "vms": d["vms"],
                    "accessible": d["accessible"], "state": "crit" if not d["accessible"] else model.level(used, th)})
    return {"rows": out, "thresholds": th}


def alerts(conn, which="open", page=1):
    where = {"open": "a.cleared_at IS NULL", "cleared": "a.cleared_at IS NOT NULL", "all": "true"}.get(which, "a.cleared_at IS NULL")
    total = conn.execute("SELECT count(*) AS n FROM alerts a WHERE " + where).fetchone()["n"]
    page = max(1, min(int(page or 1), max(1, (total + PAGE - 1) // PAGE)))
    rows = conn.execute("""SELECT a.*, v.name AS vm, v.kind FROM alerts a JOIN vms v ON v.id = a.vm_id
                            WHERE """ + where + " ORDER BY a.opened_at DESC, a.id DESC LIMIT %s OFFSET %s",
                        (PAGE, (page - 1) * PAGE)).fetchall()
    return {"total": total, "page": page, "pages": max(1, (total + PAGE - 1) // PAGE),
            "rows": [dict(alert_brief(a), cleared_at=a["cleared_at"]) for a in rows]}


def ack(conn, user, ids=None, all_=False, ip=None):
    if all_:
        r = conn.execute("""UPDATE alerts SET acked_at = now(), acked_by = %s
                             WHERE cleared_at IS NULL AND acked_at IS NULL RETURNING id""", (user["username"],)).fetchall()
    else:
        ids = [int(i) for i in (ids or [])][:500]
        if not ids:
            raise HandlerError(400, "Say which alerts to acknowledge.")
        r = conn.execute("""UPDATE alerts SET acked_at = now(), acked_by = %s
                             WHERE id = ANY(%s::bigint[]) AND cleared_at IS NULL AND acked_at IS NULL RETURNING id""",
                         (user["username"], ids)).fetchall()
    dbm.audit(conn, user["username"], "alerts_ack", {"ids": [x["id"] for x in r][:500], "all": bool(all_)}, ip)
    return {"acked": len(r)}


# ---- admin ---------------------------------------------------------------------------------------------

def get_settings(conn):
    return {"settings": settings(conn), "defaults": model.DEFAULTS}


def put_settings(conn, user, doc, ip=None):
    try:
        clean = model.clean_settings(doc)
    except model.SettingsError as e:
        raise HandlerError(400, str(e))
    conn.execute("""INSERT INTO settings (key, value, updated_at, updated_by) VALUES ('rules', %s::jsonb, now(), %s)
                    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now(), updated_by = EXCLUDED.updated_by""",
                 (json.dumps(clean), user["username"]))
    from .collector import reclassify
    n = reclassify(conn)
    dbm.audit(conn, user["username"], "settings_saved", clean, ip)
    return {"settings": clean, "reclassified": n}


def set_kind(conn, user, vm_id, kind, ip=None):
    if kind not in model.KINDS and kind is not None:
        raise HandlerError(400, "The kind must be windows, linux or appliance (or none to work it out).")
    r = conn.execute("UPDATE vms SET kind_override = %s WHERE id = %s RETURNING id, name", (kind, int(vm_id))).fetchone()
    if not r:
        raise HandlerError(404, "That VM is not known.")
    from .collector import reclassify
    reclassify(conn)
    dbm.audit(conn, user["username"], "vm_kind_set", {"vm": r["name"], "kind": kind}, ip)
    return {"ok": True}


VC_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._()-]{0,59}$")


def vcenter_list(conn):
    rows = conn.execute("""SELECT id, name, host, port, username, pin_sha256, enabled, created_at, created_by, last_run_at,
                                  last_ok_at, last_ms, last_error, counts FROM vcenters ORDER BY name""").fetchall()
    return {"rows": [dict(r, pin_text=net.fingerprint_text(r["pin_sha256"])) for r in rows]}


def vcenter_certificate(host, port):
    try:
        return net.certificate(host, port)
    except net.NetError as e:
        raise HandlerError(400, str(e))


def vcenter_clean(body, existing=None):
    name = str(body.get("name") or "").strip()
    if not VC_NAME_RE.match(name):
        raise HandlerError(400, "Give the vCenter a short name (letters, digits, space . _ - ( )).")
    try:
        host, port = net.clean_host(body.get("host")), net.clean_port(body.get("port") or 443)
        pin = net.clean_pin(body.get("pin_sha256"))
    except net.NetError as e:
        raise HandlerError(400, str(e))
    user = str(body.get("username") or "").strip()
    if not user or len(user) > 120 or any(c in user for c in "\r\n\t"):
        raise HandlerError(400, "Enter the vCenter account (for example monitor-ro@vsphere.local).")
    pw = body.get("password") or ""
    if not pw and not existing:
        raise HandlerError(400, "Enter the account's password.")
    if len(pw) > 256:
        raise HandlerError(400, "That password is too long.")
    return {"name": name, "host": host, "port": port, "username": user, "pin_sha256": pin, "password": pw,
            "enabled": bool(body.get("enabled", True))}


def vcenter_save(conn, user, vc, vc_id=None, ip=None):
    """vc is vcenter_clean()'s result, already tested against vCenter by the caller."""
    try:
        enc = crypto.encrypt(vc["password"]) if vc["password"] else None
    except crypto.KeyError_ as e:
        raise HandlerError(500, str(e))
    if vc_id:
        r = conn.execute("""UPDATE vcenters SET name = %s, host = %s, port = %s, username = %s, pin_sha256 = %s,
                                   password_enc = coalesce(%s, password_enc), enabled = %s, last_error = NULL
                             WHERE id = %s RETURNING id""",
                         (vc["name"], vc["host"], vc["port"], vc["username"], vc["pin_sha256"], enc, vc["enabled"],
                          int(vc_id))).fetchone()
        if not r:
            raise HandlerError(404, "That vCenter is not known.")
    else:
        if conn.execute("SELECT 1 FROM vcenters WHERE name = %s", (vc["name"],)).fetchone():
            raise HandlerError(409, "A vCenter with that name exists already.")
        r = conn.execute("""INSERT INTO vcenters (name, host, port, username, password_enc, pin_sha256, enabled, created_by)
                            VALUES (%s, %s, %s, %s, %s, %s, %s, %s) RETURNING id""",
                         (vc["name"], vc["host"], vc["port"], vc["username"], enc, vc["pin_sha256"], vc["enabled"],
                          user["username"])).fetchone()
    dbm.audit(conn, user["username"], "vcenter_saved",
              {k: vc[k] for k in ("name", "host", "port", "username", "pin_sha256", "enabled")}, ip)
    return {"id": r["id"]}


def vcenter_delete(conn, user, vc_id, ip=None):
    r = conn.execute("DELETE FROM vcenters WHERE id = %s RETURNING name", (int(vc_id),)).fetchone()
    if not r:
        raise HandlerError(404, "That vCenter is not known.")
    dbm.audit(conn, user["username"], "vcenter_deleted", {"name": r["name"]}, ip)
    return {"ok": True}


def audit_list(conn, page=1):
    rows = conn.execute("SELECT id, at, actor, action, detail, host(source_ip) AS ip FROM audit ORDER BY id DESC LIMIT 200 OFFSET %s",
                        ((max(1, int(page or 1)) - 1) * 200,)).fetchall()
    return {"rows": rows}


# ---- sign-in -------------------------------------------------------------------------------------------

def _user_out(u, source):
    return {"username": u["username"], "role": u["role"], "display_name": u.get("display_name"), "source": source}


def login(username, password, ip, ua):
    username = (username or "").strip().lower()
    if not security.USERNAME_RE.match(username) or not password or len(password) > 256:
        raise HandlerError(401, "That username and password were not accepted.")
    with dbm.db() as conn:
        if security.ip_blocked(conn, ip):
            raise HandlerError(429, "Too many failed sign-ins from this address. Wait 15 minutes.")
        try:
            local = security.local_authenticate(conn, username, password)
        except security.LoginError as e:
            security.count_ip_failure(conn, ip)
            dbm.audit(conn, username, "login_failed", {"source": "local"}, ip)
            conn.commit()
            raise HandlerError(401, str(e))
        if local:
            token = security.new_session(conn, local, "local", ip, ua)
            dbm.audit(conn, username, "login", {"source": "local", "role": local["role"]}, ip)
            return {"token": token, "user": _user_out(local, "local")}
    try:
        kind, res = patch01.login(username, password)               # network: no transaction open
    except patch01.AuthError as e:
        with dbm.db() as conn:
            if e.status == 401:
                security.count_ip_failure(conn, ip)
            dbm.audit(conn, username, "login_failed", {"source": "patch01", "why": str(e)[:200]}, ip)
        raise HandlerError(e.status, str(e))
    if kind == "mfa":
        return {"mfa_required": True, "mfa_ticket": res}
    return _open(res, ip, ua)


def login_second_factor(ticket, code, ip, ua):
    ticket, code = str(ticket or "")[:100], re.sub(r"\s", "", str(code or ""))[:20]
    if len(ticket) < 20 or len(code) < 6:
        raise HandlerError(401, "Enter the code from your authenticator app.")
    with dbm.db() as conn:
        if security.ip_blocked(conn, ip):
            raise HandlerError(429, "Too many failed sign-ins from this address. Wait 15 minutes.")
    try:
        res = patch01.login_second_factor(ticket, code)
    except patch01.AuthError as e:
        with dbm.db() as conn:
            if e.status == 401:
                security.count_ip_failure(conn, ip)
            dbm.audit(conn, "unknown", "login_failed", {"source": "patch01", "second_factor": True}, ip)
        raise HandlerError(e.status, str(e))
    return _open(res, ip, ua)


def _open(u, ip, ua):
    with dbm.db() as conn:
        token = security.new_session(conn, u, "patch01", ip, ua)
        dbm.audit(conn, u["username"], "login", {"source": "patch01", "role": u["role"]}, ip)
    return {"token": token, "user": _user_out(u, "patch01")}


def me(conn, user):
    st = settings(conn)
    return {"user": _user_out(user, user["source"]), "thresholds": st["thresholds"], "version": config.VERSION,
            "patch01_url": config.PATCH01_URL or None, "every_s": config.COLLECT_SECONDS,
            "vcenters": conn.execute("SELECT count(*) AS n FROM vcenters").fetchone()["n"]}
