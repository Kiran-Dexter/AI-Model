"""MONITOR-01 commands run on the server by monitor01.sh (inside the API container):

    python -m app.cli local-admin NAME     make or reset the local break-glass admin (password on stdin)
    python -m app.cli local-disable NAME   switch a local account off
    python -m app.cli status               the collector and each vCenter, as JSON (monitor01.sh --check)
    python -m app.cli beat                 exit 0 when the collector ran in the last 5 minutes (health check)
"""
import json
import sys

from . import security
from .db import db


def local_admin(name):
    name = (name or "").strip().lower()
    if not security.USERNAME_RE.match(name):
        sys.exit("The name must be 2-63 characters: lowercase letters, digits, . _ -")
    pw = sys.stdin.readline().rstrip("\n")
    why = security.password_problem(pw, name)
    if why:
        sys.exit("Password not accepted: " + why)
    with db() as conn:
        conn.execute("""INSERT INTO local_users (username, password_hash, role) VALUES (%s, %s, 'admin')
                        ON CONFLICT (username) DO UPDATE SET password_hash = EXCLUDED.password_hash, active = true,
                               failed_logins = 0, locked_until = NULL""", (name, security.hash_password(pw)))
        conn.execute("DELETE FROM sessions WHERE username = %s AND source = 'local'", (name,))
        conn.execute("INSERT INTO audit (actor, action, detail) VALUES ('root', 'local_admin_set', %s::jsonb)",
                     (json.dumps({"username": name}),))
    print(f"Local admin {name} is ready. Keep its password in the safe: it opens MONITOR-01 even when PATCH-01 is down.")


def local_disable(name):
    with db() as conn:
        r = conn.execute("UPDATE local_users SET active = false WHERE username = %s RETURNING id", (name,)).fetchone()
        conn.execute("DELETE FROM sessions WHERE username = %s AND source = 'local'", (name,))
        conn.execute("INSERT INTO audit (actor, action, detail) VALUES ('root', 'local_admin_disabled', %s::jsonb)",
                     (json.dumps({"username": name}),))
    print("Switched off." if r else "No such local account.")


def status():
    with db() as conn:
        c = conn.execute("""SELECT beat_at, last_cycle, cycle_ms, extract(epoch FROM now() - beat_at)::int AS beat_age
                              FROM collector_status WHERE id = 1""").fetchone()
        vcs = conn.execute("""SELECT name, enabled, last_ok_at, last_error, counts,
                                     extract(epoch FROM now() - last_ok_at)::int AS ok_age FROM vcenters ORDER BY name""").fetchall()
        n = conn.execute("""SELECT count(*) FILTER (WHERE gone_at IS NULL) AS vms,
                                   (SELECT count(*) FROM alerts WHERE cleared_at IS NULL) AS alerts,
                                   (SELECT max(version) FROM schema_version) AS schema FROM vms""").fetchone()
    print(json.dumps({"collector": c, "vcenters": vcs, "totals": n}, default=str, indent=1))


def main(argv):
    if len(argv) >= 2 and argv[0] == "local-admin":
        local_admin(argv[1])
    elif len(argv) >= 2 and argv[0] == "local-disable":
        local_disable(argv[1])
    elif argv[:1] == ["beat"]:
        with db() as conn:
            r = conn.execute("SELECT beat_at > now() - interval '5 minutes' AS ok FROM collector_status WHERE id = 1").fetchone()
        sys.exit(0 if r and r["ok"] else 1)
    elif argv[:1] == ["status"]:
        status()
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main(sys.argv[1:])
