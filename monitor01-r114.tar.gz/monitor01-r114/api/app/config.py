"""MONITOR-01 settings that come from the server (environment), not from the console.

Everything MONITOR-01 needs is its own: its database, its key, its certificate, its address.
The only link to PATCH-01 is a URL and a certificate fingerprint (sign-in, and optionally the
patch status of a VM), so the whole system moves to its own server by copying /etc/monitor01
and the database, and pointing PATCH01_URL at PATCH-01 from there.
"""
import os
import re


def _int(name, default, lo, hi):
    try:
        v = int(os.environ.get(name, default))
    except ValueError:
        v = default
    return max(lo, min(hi, v))


VERSION = os.environ.get("MON_VERSION", "dev")

# Database (its own PostgreSQL, container mon01-db)
DB_HOST = os.environ.get("MON_DB_HOST", "mon01-db")
DB_PORT = _int("MON_DB_PORT", 5432, 1, 65535)
DB_NAME = os.environ.get("MON_DB_NAME", "monitor")
DB_USER = os.environ.get("MON_DB_USER", "monitor")
DB_PASSWORD = os.environ.get("MON_DB_PASSWORD", "")

# Fernet key for vCenter passwords
KEY_FILE = os.environ.get("MON_KEY_FILE", "/etc/monitor01/monitor.key")

# Sign-in through PATCH-01: its URL and the SHA-256 fingerprint of its certificate
PATCH01_URL = os.environ.get("PATCH01_URL", "").strip().rstrip("/")
PATCH01_PIN = re.sub(r"[\s:]", "", os.environ.get("PATCH01_PIN", "")).lower()
# A PATCH-01 viewer account (patch module) used only to read a VM's patch status; optional
PATCH01_SVC_USER = os.environ.get("PATCH01_SVC_USER", "").strip()
PATCH01_SVC_PASSWORD_FILE = os.environ.get("PATCH01_SVC_PASSWORD_FILE", "/etc/monitor01/patch01-svc.pass")
# PATCH-01 modules that give access to MONITOR-01 (admins always have access)
ALLOWED_MODULES = {m.strip() for m in os.environ.get("MON_ALLOWED_MODULES", "inventory,patch").split(",") if m.strip()}

SESSION_HOURS = _int("MON_SESSION_HOURS", 12, 1, 72)
COLLECT_SECONDS = _int("MON_COLLECT_SECONDS", 60, 20, 600)
RAW_DAYS = _int("MON_RAW_DAYS", 2, 1, 14)
HOURLY_DAYS = _int("MON_HOURLY_DAYS", 35, 7, 400)

# The address people open, for links (e.g. https://monitor.example.local:9443)
PUBLIC_URL = os.environ.get("MON_PUBLIC_URL", "").strip().rstrip("/")
