"""MONITOR-01: the rules, as plain functions (no database, no vCenter), so they can be tested.

  * what kind of VM it is: Windows, Linux or appliance
  * its state: critical, warning, fine, powered off, or not known yet
  * when an alert opens, stays open and clears

The thresholds are the ones agreed for the screen (an admin can change them in Admin, Rules):
  critical: a drive 89% used or more, CPU 89% or more, memory 89% or more, CPU ready 10% or more
  warning:  80% (drives, CPU, memory), CPU ready 5%
CPU, memory and CPU ready must stay over the line for `sustain_min` minutes before an alert opens
(a 30-second spike is not an alert); a drive alerts at once. An alert clears when the figure is
`clear_margin` points under the line, so a value hovering at 89/88 does not flap.
"""
import copy
import fnmatch
import re

KINDS = ("windows", "linux", "appliance")
RULES = ("drive", "cpu", "mem", "ready")
LINUX_HINTS = ("linux", "red hat", "rhel", "centos", "oracle", "ubuntu", "debian", "suse", "rocky", "alma", "fedora",
               "amazon")

DEFAULTS = {
    "thresholds": {"crit": 89, "warn": 80, "ready_crit": 10, "ready_warn": 5, "sustain_min": 5, "clear_margin": 2},
    # An appliance is a VM that is not a server we run ourselves: vCenter, NSX, backup proxies,
    # virtual firewalls, load balancers. Recognised by name (regular expressions, case ignored),
    # by guest OS text, or because vCenter lists it as a packaged product (OVA). An admin can also
    # set any VM's kind by hand, which always wins.
    "appliances": {
        "names": [r"^(vcsa|vcenter|vc\d)", r"^nsx", r"veeam|^vbr", r"^(pa-|panos|palo)", r"infoblox|^nios",
                  r"^(f5|bigip)", r"avamar|^ddve|datadomain", r"rubrik|cohesity|zerto", r"^(vrops|vrli|vrni|aria|hcx|srm)"],
        "guests": ["photon", "freebsd", "pan-os", "nios", "big-ip", "other 2.6", "other 3.x", "other 4.x",
                   "other 5.x", "other (32-bit)", "other (64-bit)"],
        "products": True,
    },
    # Drives never alerted on (shell-style patterns)
    "drives_ignore": ["/snap/*", "/run/*", "/dev/*"],
}


class SettingsError(ValueError):
    pass


def merged(stored):
    """The settings in force: the defaults with what an admin saved on top."""
    out = copy.deepcopy(DEFAULTS)
    for k, v in (stored or {}).items():
        if isinstance(out.get(k), dict) and isinstance(v, dict):
            out[k].update(v)
        elif k in out:
            out[k] = v
    return out


def _num(v, lo, hi, what):
    try:
        f = float(v)
    except (TypeError, ValueError):
        raise SettingsError(f"{what} must be a number.")
    if not lo <= f <= hi:
        raise SettingsError(f"{what} must be between {lo} and {hi}.")
    return round(f, 1)


def _strs(v, n, size, what):
    if not isinstance(v, list) or len(v) > n:
        raise SettingsError(f"{what}: at most {n} entries.")
    out = []
    for s in v:
        s = str(s).strip()
        if not s:
            continue
        if len(s) > size:
            raise SettingsError(f"{what}: each entry at most {size} characters.")
        out.append(s)
    return out


def clean_settings(doc):
    """Check what an admin sends. Returns the cleaned settings; SettingsError says what is wrong."""
    if not isinstance(doc, dict) or any(k in doc and not isinstance(doc[k], dict) for k in ("thresholds", "appliances")):
        raise SettingsError("Settings must be an object, with thresholds and appliances as objects.")
    cur = merged(doc)
    t = cur["thresholds"]
    th = {"crit": _num(t.get("crit"), 50, 99, "Critical at"),
          "warn": _num(t.get("warn"), 30, 98, "Warning at"),
          "ready_crit": _num(t.get("ready_crit"), 1, 50, "CPU ready critical at"),
          "ready_warn": _num(t.get("ready_warn"), 0.5, 49, "CPU ready warning at"),
          "sustain_min": int(_num(t.get("sustain_min"), 1, 30, "Minutes over the line")),
          "clear_margin": _num(t.get("clear_margin"), 0, 10, "Clears when under the line by")}
    if th["warn"] >= th["crit"]:
        raise SettingsError("The warning line must be under the critical line.")
    if th["ready_warn"] >= th["ready_crit"]:
        raise SettingsError("The CPU ready warning must be under the CPU ready critical line.")
    a = cur["appliances"]
    names = _strs(a.get("names"), 40, 80, "Appliance names")
    for n in names:
        try:
            re.compile(n)
        except re.error:
            raise SettingsError(f"Appliance name pattern {n!r} is not a valid regular expression.")
    return {"thresholds": th,
            "appliances": {"names": names, "guests": [g.lower() for g in _strs(a.get("guests"), 40, 60, "Appliance guest OS")],
                           "products": bool(a.get("products", True))},
            "drives_ignore": _strs(cur.get("drives_ignore"), 40, 120, "Drives not watched")}


# ---- what a VM is ---------------------------------------------------------------------------

def classify(vm, settings):
    """(kind, reason). An admin's choice wins; then appliance rules; then the guest OS."""
    if vm.get("kind_override") in KINDS:
        return vm["kind_override"], "set by an admin"
    a = settings["appliances"]
    name = (vm.get("name") or "").lower()
    for pat in a.get("names") or []:
        try:
            if re.search(pat, name, re.I):
                return "appliance", "name matches " + pat
        except re.error:
            continue
    full = (vm.get("guest_full") or "").lower()
    for g in a.get("guests") or []:
        if g and g in full:
            return "appliance", "guest OS " + (vm.get("guest_full") or "")
    if a.get("products", True) and (vm.get("product") or "").strip():
        return "appliance", "packaged product: " + vm["product"].strip()[:80]
    fam, gid = (vm.get("guest_family") or "").lower(), (vm.get("guest_id") or "").lower()
    if fam == "windowsguest" or gid.startswith("win") or "windows" in full:
        return "windows", "guest OS"
    if fam == "linuxguest" or any(h in full for h in LINUX_HINTS) or any(h in gid for h in ("rhel", "centos", "ubuntu",
                                                                                              "debian", "sles", "linux")):
        return "linux", "guest OS"
    if not full and not gid:
        return "linux", "guest OS not reported yet"
    return "appliance", "neither Windows nor Linux: " + (vm.get("guest_full") or vm.get("guest_id") or "")[:80]


def drive_label(path):
    p = (path or "").strip()
    if re.fullmatch(r"[A-Za-z]:\\?", p):
        return p[0].upper() + ":"
    return p.rstrip("\\") or p


def drives(guest_disks, ignore):
    """The drives VMware Tools reports, with % used; ignored and empty ones left out."""
    out, seen = [], set()
    for d in guest_disks or []:
        cap, free = int(d.get("capacity") or 0), int(d.get("free") or 0)
        path = drive_label(d.get("path"))
        if cap <= 0 or not path or path in seen or any(fnmatch.fnmatch(path, pat) for pat in ignore or []):
            continue
        seen.add(path)
        free = max(0, min(cap, free))
        out.append({"path": path[:200], "capacity_b": cap, "free_b": free, "used_pct": round(100 * (cap - free) / cap, 1)})
    return out


def ready_pct(ready_ms, num_cpu, interval_s=20):
    """vCenter's cpu.ready.summation (ms in one sampling interval, all vCPUs) as % per vCPU."""
    if ready_ms is None or not num_cpu:
        return None
    return round(max(0.0, 100.0 * ready_ms / (interval_s * 1000.0) / max(1, num_cpu)), 1)


def state(vm, th):
    """'off', 'unknown', 'crit', 'warn' or 'ok', from the latest figures."""
    if vm.get("power") != "on":
        return "off"
    vals = [vm.get("cpu_pct"), vm.get("mem_pct"), vm.get("disk_pct")]
    rdy = vm.get("ready_pct")
    if all(v is None for v in vals) and rdy is None:
        return "unknown"
    if any(v is not None and v >= th["crit"] for v in vals) or (rdy is not None and rdy >= th["ready_crit"]):
        return "crit"
    if any(v is not None and v >= th["warn"] for v in vals) or (rdy is not None and rdy >= th["ready_warn"]):
        return "warn"
    return "ok"


# ---- alerts ---------------------------------------------------------------------------------------

def sustain_seconds(th, collect_s):
    """How far back a figure's readings must reach to count as sustained: the sustain time,
    less half a reading (a reading a few seconds late still counts)."""
    return max(0.0, th["sustain_min"] * 60 - collect_s / 2)


def evaluate(vm, vm_drives, window, open_alerts, th, need):
    """What changes for one VM's alerts.

    vm          latest figures (power, cpu_pct, mem_pct, ready_pct)
    vm_drives   [{path, used_pct}] reported now
    window      per figure (cpu, mem, ready): <f>_n readings, <f>_min lowest, <f>_span seconds back to the
                oldest reading in the sustain window
    need        seconds the readings must reach back (sustain_seconds)
    open_alerts {(rule, item): {id, value, peak}}
    Returns {"open": [(rule, item, value, threshold)], "update": [(id, value)], "clear": [id]}.
    """
    out = {"open": [], "update": [], "clear": []}
    if vm.get("power") != "on":
        out["clear"] = [a["id"] for a in open_alerts.values()]
        return out
    m = th["clear_margin"]
    w = window or {}

    def sustained(rule, line):
        return ((w.get(rule + "_n") or 0) >= 2 and (w.get(rule + "_span") or 0) >= need
                and w.get(rule + "_min") is not None and w[rule + "_min"] >= line)
    lines = {"cpu": th["crit"], "mem": th["crit"], "ready": th["ready_crit"]}
    now_val = {"cpu": vm.get("cpu_pct"), "mem": vm.get("mem_pct"), "ready": vm.get("ready_pct")}
    for rule, line in lines.items():
        cur = now_val[rule]
        a = open_alerts.get((rule, ""))
        if a:
            if cur is None:
                continue
            if cur >= line - m:
                out["update"].append((a["id"], cur))
            else:
                out["clear"].append(a["id"])
        elif sustained(rule, line) and cur is not None and cur >= line:
            out["open"].append((rule, "", cur, line))
    reported = {d["path"]: d["used_pct"] for d in vm_drives or []}
    for (rule, item), a in open_alerts.items():
        if rule != "drive":
            continue
        cur = reported.get(item)
        if not reported:
            continue                  # VMware Tools reports no drive right now: not a reason to clear
        if cur is None or cur < th["crit"] - m:
            out["clear"].append(a["id"])
        else:
            out["update"].append((a["id"], cur))
    for path, used in reported.items():
        if used >= th["crit"] and ("drive", path) not in open_alerts:
            out["open"].append(("drive", path, used, th["crit"]))
    return out


def alert_text(rule, item, value):
    v = "?" if value is None else (f"{value:.1f}" if rule == "ready" else f"{value:.0f}")
    return {"drive": f"drive {item} {v}% used", "cpu": f"CPU {v}%", "mem": f"memory {v}%",
            "ready": f"CPU ready {v}%"}.get(rule, rule)


# ---- the estate at a glance -----------------------------------------------------------------------

def level(pct, th):
    if pct is None:
        return "unknown"
    return "crit" if pct >= th["crit"] else "warn" if pct >= th["warn"] else "ok"


SEG = {"ok": "done", "warn": "run", "crit": "failed", "unknown": "wait"}


def rings(hosts, datastores, th):
    """CPU, memory and storage of the estate, one segment per host or datastore in its state."""
    live = [h for h in hosts if (h.get("connection") or "connected") == "connected" and not h.get("maintenance")]

    def pct(used, total):
        return None if not total else round(100.0 * used / total, 1)

    def ring(key, title, used_k, total_k, unit_fn):
        segs, hot = [], []
        for h in hosts:
            p = pct(h.get(used_k) or 0, h.get(total_k) or 0)
            if (h.get("connection") or "connected") != "connected" or h.get("maintenance"):
                segs.append({"k": "wait", "title": f"{h['name']}: " + ("maintenance" if h.get("maintenance") else
                                                                      (h.get("connection") or "not connected"))})
                continue
            lv = level(p, th)
            if lv in ("warn", "crit"):
                hot.append(h["name"])
            segs.append({"k": SEG[lv], "title": f"{h['name']}: {p if p is not None else '?'}%"})
        u = sum(h.get(used_k) or 0 for h in live)
        t = sum(h.get(total_k) or 0 for h in live)
        note = (f"{len(hot)} host{'s' if len(hot) != 1 else ''} at {th['warn']:.0f}% or more: " + ", ".join(hot[:3])
                + ("…" if len(hot) > 3 else "")) if hot else (f"every host under {th['warn']:.0f}%" if live else "no host connected")
        return {"key": key, "title": title, "pct": pct(u, t), "sub": unit_fn(u, t, len(live)), "segs": segs, "note": note}

    cpu = ring("cpu", "CPU", "cpu_mhz_used", "cpu_mhz_total",
               lambda u, t, n: f"{n} hosts · {t / 1000:.0f} GHz")
    mem = ring("mem", "MEMORY", "mem_mb_used", "mem_mb_total",
               lambda u, t, n: f"{u / 1048576:.1f} of {t / 1048576:.1f} TB")
    ds = [d for d in datastores if d.get("accessible", True) and d.get("capacity_b")]
    segs, hot = [], []
    for d in datastores:
        if not d.get("accessible", True) or not d.get("capacity_b"):
            segs.append({"k": "failed" if not d.get("accessible", True) else "wait",
                         "title": f"{d['name']}: " + ("not accessible" if not d.get("accessible", True) else "no size")})
            continue
        p = round(100.0 * (d["capacity_b"] - (d.get("free_b") or 0)) / d["capacity_b"], 1)
        lv = level(p, th)
        if lv != "ok":
            hot.append(d["name"])
        segs.append({"k": SEG[lv], "title": f"{d['name']}: {p}% used"})
    cap = sum(d["capacity_b"] for d in ds)
    used = sum(d["capacity_b"] - (d.get("free_b") or 0) for d in ds)
    store = {"key": "store", "title": "STORAGE", "pct": None if not cap else round(100.0 * used / cap, 1),
             "sub": f"{len(ds)} datastores · {cap / 1e12:.1f} TB", "segs": segs,
             "note": (f"{len(hot)} datastore{'s' if len(hot) != 1 else ''} at {th['warn']:.0f}% or more: " + ", ".join(hot[:3])
                      + ("…" if len(hot) > 3 else "")) if hot else
                     (f"every datastore under {th['warn']:.0f}%" if ds else "no datastore read yet")}
    return [cpu, mem, store]


def tip(v):
    if v.get("power") != "on":
        return f"{v['name']} · powered off"
    def f(x, suffix="%"):
        return "?" if x is None else f"{x:.0f}{suffix}"
    drv = "drives not reported" if not v.get("drives_reported") else f"fullest drive {f(v.get('disk_pct'))} used"
    rdy = "?" if v.get("ready_pct") is None else f"{v['ready_pct']:.1f}%"
    return f"{v['name']} · CPU {f(v.get('cpu_pct'))} · memory {f(v.get('mem_pct'))} · {drv} · ready {rdy}"


def kpis(vms, hosts, alerts_open, th):
    by = {k: [v for v in vms if v["kind"] == k] for k in KINDS}
    crit_vms = {a["vm_id"] for a in alerts_open}
    connected = [h for h in hosts if (h.get("connection") or "connected") == "connected"]
    return {
        "vms": len(vms), "windows": len(by["windows"]), "linux": len(by["linux"]), "appliances": len(by["appliance"]),
        "powered_off": sum(1 for v in vms if v.get("power") != "on"),
        "hosts": len(hosts), "hosts_connected": len(connected),
        "hosts_maintenance": sum(1 for h in hosts if h.get("maintenance")),
        "alerts": len(alerts_open), "alert_vms": len(crit_vms),
        "unacked": sum(1 for a in alerts_open if not a.get("acked_at")),
        "crit": sum(1 for v in vms if v["state"] == "crit"),
        "warn": sum(1 for v in vms if v["state"] == "warn"),
        "drives_crit": sum(1 for v in vms if v.get("power") == "on" and v.get("disk_pct") is not None
                           and v["disk_pct"] >= th["crit"]),
        "ready_warn": sum(1 for v in vms if v.get("power") == "on" and v.get("ready_pct") is not None
                          and v["ready_pct"] >= th["ready_warn"]),
        "no_drives": sum(1 for v in vms if v.get("power") == "on" and not v.get("drives_reported")),
    }


STATE_ORDER = {"crit": 0, "warn": 1, "unknown": 2, "ok": 3, "off": 4}


def worst_first(v):
    return (STATE_ORDER.get(v["state"], 5), -(max(x for x in (v.get("cpu_pct"), v.get("mem_pct"), v.get("disk_pct"),
                                                                0) if x is not None)), v["name"].lower())
