"""MONITOR-01: sessions, the local break-glass account, and slowing down guessing.

Roles, as in PATCH-01:  viewer < operator (acknowledges alerts) < admin (vCenter, thresholds).
Session tokens are random, shown to the browser once and stored only as SHA-256.
"""
import hashlib
import hmac
import re
import secrets
from datetime import datetime, timedelta, timezone

from . import config

ROLES = ("viewer", "operator", "admin")
RANK = {r: i for i, r in enumerate(ROLES)}
USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{1,62}$")
MAX_FAILED = 5
LOCK_MINUTES = 15
IP_WINDOW_MIN = 15
IP_MAX_FAILS = 20
MIN_PASSWORD = 14
SCRYPT_N, SCRYPT_R, SCRYPT_P = 2 ** 14, 8, 1
DUMMY_HASH = "scrypt$16384$8$1$" + "00" * 16 + "$" + "00" * 32


def role_at_least(role, needed):
    return RANK.get(role, -1) >= RANK[needed]


def hash_password(password):
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, dklen=32)
    return f"scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${salt.hex()}${dk.hex()}"


def verify_password(password, stored):
    try:
        algo, n, r, p, salt_hex, dk_hex = stored.split("$")
        if algo != "scrypt":
            return False
        dk = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex), n=int(n), r=int(r), p=int(p),
                            dklen=len(dk_hex) // 2)
        return hmac.compare_digest(dk.hex(), dk_hex)
    except (ValueError, TypeError):
        return False


def password_problem(password, username=None):
    if not password or len(password) < MIN_PASSWORD:
        return f"Use at least {MIN_PASSWORD} characters."
    if username and username.lower() in password.lower():
        return "The password must not contain the username."
    if sum(bool(re.search(p, password)) for p in (r"[a-z]", r"[A-Z]", r"\d", r"[^A-Za-z0-9]")) < 3:
        return "Mix at least three of: lowercase, uppercase, digits, symbols."
    return None


def token_hash(token):
    return hashlib.sha256(token.encode()).hexdigest()


# ---- sessions -------------------------------------------------------------------------------

def new_session(conn, user, source, ip, user_agent):
    token = secrets.token_urlsafe(32)
    conn.execute("""INSERT INTO sessions (token_hash, username, display_name, role, source, expires_at, source_ip, user_agent)
                    VALUES (%s, %s, %s, %s, %s, now() + make_interval(hours => %s), %s::inet, %s)""",
                 (token_hash(token), user["username"], (user.get("display_name") or "")[:120] or None, user["role"],
                  source, config.SESSION_HOURS, ip, (user_agent or "")[:300]))
    conn.execute("DELETE FROM sessions WHERE expires_at < now() - interval '1 day'")
    return token


def session_user(conn, token, extend=True):
    """The user behind a token, or None. Background polls (extend=False) never keep an
    unattended screen signed in."""
    if not token or len(token) > 200:
        return None
    if extend:
        row = conn.execute(
            """UPDATE sessions SET last_seen_at = now(),
                      expires_at = GREATEST(expires_at, now() + make_interval(hours => %s))
                WHERE token_hash = %s AND expires_at > now() AND created_at > now() - interval '24 hours'
            RETURNING username, display_name, role, source, expires_at""",
            (config.SESSION_HOURS, token_hash(token))).fetchone()
    else:
        row = conn.execute("""SELECT username, display_name, role, source, expires_at FROM sessions
                               WHERE token_hash = %s AND expires_at > now()
                                 AND created_at > now() - interval '24 hours'""", (token_hash(token),)).fetchone()
    return dict(row) if row else None


def end_session(conn, token):
    conn.execute("DELETE FROM sessions WHERE token_hash = %s", (token_hash(token),))


# ---- guessing ---------------------------------------------------------------------------------

def ip_blocked(conn, ip):
    if not ip:
        return False
    n = conn.execute("""SELECT count(*) AS n FROM login_failures
                         WHERE source_ip = %s::inet AND at > now() - make_interval(mins => %s)""",
                     (ip, IP_WINDOW_MIN)).fetchone()["n"]
    return n >= IP_MAX_FAILS


def count_ip_failure(conn, ip):
    if ip:
        conn.execute("INSERT INTO login_failures (source_ip) VALUES (%s::inet)", (ip,))
    conn.execute("DELETE FROM login_failures WHERE at < now() - interval '1 day'")


# ---- local break-glass account ------------------------------------------------------------------

class LoginError(Exception):
    pass


def local_authenticate(conn, username, password):
    """The local account, or LoginError. None when no local account has this name (then
    PATCH-01 is asked). Same timing either way."""
    row = conn.execute("""SELECT id, username, role, password_hash, active, failed_logins, locked_until
                            FROM local_users WHERE username = %s""", (username,)).fetchone()
    ok = verify_password(password or "", row["password_hash"] if row else DUMMY_HASH)
    if not row:
        return None
    if row["locked_until"] and row["locked_until"] > datetime.now(timezone.utc):
        raise LoginError("This account is temporarily locked after repeated failed sign-ins. Try again later.")
    if not ok or not row["active"]:
        fails = row["failed_logins"] + 1
        lock = datetime.now(timezone.utc) + timedelta(minutes=LOCK_MINUTES) if fails >= MAX_FAILED else None
        conn.execute("UPDATE local_users SET failed_logins=%s, locked_until=%s WHERE id=%s",
                     (0 if lock else fails, lock, row["id"]))
        raise LoginError("That username and password were not accepted.")
    conn.execute("UPDATE local_users SET failed_logins=0, locked_until=NULL, last_login_at=now() WHERE id=%s", (row["id"],))
    return {"username": row["username"], "role": row["role"], "display_name": row["username"] + " (local)"}
