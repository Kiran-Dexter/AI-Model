"""MONITOR-01: its own database. One pool per process; a `with db() as conn:` block is one
transaction, committed when the block ends without an error."""
import contextlib
import threading

from . import config

_pool = None
_lock = threading.Lock()


def _conninfo():
    from psycopg.conninfo import make_conninfo
    return make_conninfo(host=config.DB_HOST, port=config.DB_PORT, dbname=config.DB_NAME,
                         user=config.DB_USER, password=config.DB_PASSWORD,
                         application_name="monitor01", connect_timeout=10)


def pool():
    global _pool
    with _lock:
        if _pool is None:
            from psycopg.rows import dict_row
            from psycopg_pool import ConnectionPool
            _pool = ConnectionPool(_conninfo(), min_size=1, max_size=8, open=True,
                                   kwargs={"row_factory": dict_row, "autocommit": False})
    return _pool


@contextlib.contextmanager
def db():
    with pool().connection() as conn:
        yield conn


def audit(conn, actor, action, detail=None, source_ip=None):
    import json
    conn.execute("INSERT INTO audit (actor, action, detail, source_ip) VALUES (%s, %s, %s::jsonb, %s::inet)",
                 ((actor or "unknown")[:64], action[:64], json.dumps(detail or {}, default=str)[:20000], source_ip))
