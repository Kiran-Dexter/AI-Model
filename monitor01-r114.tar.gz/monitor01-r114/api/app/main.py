"""MONITOR-01 API (FastAPI). Every route here is a thin wrapper over handlers.py.

Served only to its own NGINX (mon01-web) on the monitor network; nothing else reaches it.
Roles: viewer reads; operator also acknowledges alerts; admin also manages vCenter and the rules.
"""
import ipaddress
import logging
from typing import List, Optional

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from . import config, handlers, security
from .db import db

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
app = FastAPI(title="MONITOR-01", version=config.VERSION, docs_url=None, redoc_url=None, openapi_url=None)


@app.exception_handler(handlers.HandlerError)
def _handler_error(request: Request, e: handlers.HandlerError):
    return JSONResponse(status_code=e.status, content={"detail": str(e)})


def client_ip(request: Request) -> Optional[str]:
    """The address NGINX saw (it overwrites X-Real-IP); never the client's own X-Forwarded-For."""
    for v in (request.headers.get("x-real-ip"), request.client.host if request.client else None):
        try:
            return str(ipaddress.ip_address((v or "").strip())) if v else None
        except ValueError:
            continue
    return None


def _token(request: Request):
    h = request.headers.get("authorization") or ""
    return h[7:].strip() if h.lower().startswith("bearer ") else None


def need(role):
    def dep(request: Request):
        tok = _token(request)
        background = request.headers.get("x-background") == "1"
        with db() as conn:
            u = security.session_user(conn, tok, extend=not background) if tok else None
        if not u:
            raise HTTPException(status_code=401, detail="Your session has ended. Sign in again.")
        if not security.role_at_least(u["role"], role):
            raise HTTPException(status_code=403, detail=f"This needs the {role} role.")
        request.state.user = u
        return u
    return dep


viewer, operator, admin = need("viewer"), need("operator"), need("admin")


@app.get("/api/health")
def health():
    with db() as conn:
        conn.execute("SELECT 1")
    return {"ok": True, "version": config.VERSION}


# ---- sign-in -------------------------------------------------------------------------------------

class LoginIn(BaseModel):
    username: str = Field(..., max_length=64)
    password: str = Field(..., max_length=256)


class MfaIn(BaseModel):
    mfa_ticket: str = Field(..., min_length=20, max_length=100)
    code: str = Field(..., min_length=6, max_length=20)


@app.post("/api/auth/login")
def login(body: LoginIn, request: Request):
    return handlers.login(body.username, body.password, client_ip(request), request.headers.get("user-agent"))


@app.post("/api/auth/login/2fa")
def login_2fa(body: MfaIn, request: Request):
    return handlers.login_second_factor(body.mfa_ticket, body.code, client_ip(request), request.headers.get("user-agent"))


@app.post("/api/auth/logout")
def logout(request: Request, user=Depends(viewer)):
    from . import db as dbm
    with db() as conn:
        security.end_session(conn, _token(request))
        dbm.audit(conn, user["username"], "logout", {}, client_ip(request))
    return {"ok": True}


@app.get("/api/auth/me")
def me(user=Depends(viewer)):
    with db() as conn:
        return handlers.me(conn, user)


# ---- what everyone sees -----------------------------------------------------------------------------

@app.get("/api/overview")
def overview(range: str = "24h", user=Depends(viewer)):  # noqa: A002 - the query parameter's name
    with db() as conn:
        return handlers.overview(conn, range)


@app.get("/api/live")
def live(user=Depends(viewer)):
    with db() as conn:
        return handlers.live(conn)


@app.get("/api/vms")
def vms(kind: Optional[str] = None, state: Optional[str] = None, q: Optional[str] = None, sort: str = "state",
        page: int = 1, range: str = "24h", user=Depends(viewer)):  # noqa: A002
    with db() as conn:
        return handlers.vm_list(conn, kind, state, q, sort, page, range)


@app.get("/api/vms/{vm_id}")
def vm(vm_id: int, range: str = "24h", user=Depends(viewer)):  # noqa: A002
    with db() as conn:
        return handlers.vm_detail(conn, vm_id, range)


@app.get("/api/vms/{vm_id}/patch")
def vm_patch(vm_id: int, user=Depends(viewer)):
    from . import patch01
    with db() as conn:
        v = conn.execute("SELECT name FROM vms WHERE id = %s", (vm_id,)).fetchone()
    if not v:
        raise HTTPException(404, "That VM is not known.")
    try:
        return {"patch": patch01.patch_status(v["name"])}                  # network: no transaction open
    except patch01.AuthError as e:
        return {"patch": {"error": str(e)}}


@app.get("/api/hosts")
def hosts(user=Depends(viewer)):
    with db() as conn:
        return handlers.hosts(conn)


@app.get("/api/datastores")
def datastores(user=Depends(viewer)):
    with db() as conn:
        return handlers.datastores(conn)


@app.get("/api/alerts")
def alerts(which: str = "open", page: int = 1, user=Depends(viewer)):
    with db() as conn:
        return handlers.alerts(conn, which, page)


class AckIn(BaseModel):
    ids: List[int] = Field(default_factory=list, max_length=500)
    all: bool = False


@app.post("/api/alerts/ack")
def ack(body: AckIn, request: Request, user=Depends(operator)):
    with db() as conn:
        return handlers.ack(conn, user, body.ids, body.all, client_ip(request))


# ---- admin -------------------------------------------------------------------------------------------

@app.get("/api/admin/settings")
def settings_get(user=Depends(admin)):
    with db() as conn:
        return handlers.get_settings(conn)


@app.put("/api/admin/settings")
def settings_put(body: dict, request: Request, user=Depends(admin)):
    with db() as conn:
        return handlers.put_settings(conn, user, body, client_ip(request))


class KindIn(BaseModel):
    kind: Optional[str] = Field(default=None, max_length=12)


@app.put("/api/admin/vms/{vm_id}/kind")
def vm_kind(vm_id: int, body: KindIn, request: Request, user=Depends(admin)):
    with db() as conn:
        return handlers.set_kind(conn, user, vm_id, body.kind or None, client_ip(request))


@app.get("/api/admin/vcenters")
def vcenters(user=Depends(admin)):
    with db() as conn:
        return handlers.vcenter_list(conn)


class CertIn(BaseModel):
    host: str = Field(..., max_length=253)
    port: int = 443


@app.post("/api/admin/vcenters/certificate")
def vcenter_cert(body: CertIn, user=Depends(admin)):
    return handlers.vcenter_certificate(body.host, body.port)


class VcIn(BaseModel):
    name: str = Field(..., max_length=60)
    host: str = Field(..., max_length=253)
    port: int = 443
    username: str = Field(..., max_length=120)
    password: str = Field(default="", max_length=256)
    pin_sha256: str = Field(..., max_length=100)
    enabled: bool = True


def _test_then_save(body: VcIn, request: Request, user, vc_id=None):
    from . import crypto, vcenter
    existing = None
    if vc_id:
        with db() as conn:
            existing = conn.execute("SELECT host, port, username, pin_sha256, password_enc FROM vcenters WHERE id = %s",
                                    (vc_id,)).fetchone()
        if not existing:
            raise HTTPException(404, "That vCenter is not known.")
    vc = handlers.vcenter_clean(body.model_dump(), existing)
    if existing and not vc["password"] and any(vc[k] != existing[k] for k in ("host", "port", "username", "pin_sha256")):
        # the saved password is only ever sent to the vCenter it was saved for
        raise HTTPException(400, "The address, port, account or certificate changed: enter the password again.")
    try:
        pw = vc["password"] or crypto.decrypt(existing["password_enc"])
    except crypto.KeyError_ as e:
        raise HTTPException(400, str(e) + " Enter the password again.")
    try:
        found = vcenter.test(vc, pw)                                       # network: no transaction open
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, "Not saved: " + (str(e) if isinstance(e, (vcenter.VcError, vcenter.net.NetError))
                                                   else vcenter.why(e)))
    with db() as conn:
        out = handlers.vcenter_save(conn, user, vc, vc_id, client_ip(request))
    out["found"] = found
    return out


@app.post("/api/admin/vcenters")
def vcenter_add(body: VcIn, request: Request, user=Depends(admin)):
    return _test_then_save(body, request, user)


@app.put("/api/admin/vcenters/{vc_id}")
def vcenter_update(vc_id: int, body: VcIn, request: Request, user=Depends(admin)):
    return _test_then_save(body, request, user, vc_id)


@app.delete("/api/admin/vcenters/{vc_id}")
def vcenter_delete(vc_id: int, request: Request, user=Depends(admin)):
    with db() as conn:
        return handlers.vcenter_delete(conn, user, vc_id, client_ip(request))


@app.get("/api/admin/audit")
def audit(page: int = 1, user=Depends(admin)):
    with db() as conn:
        return handlers.audit_list(conn, page)
