# MONITOR-01

Every VM in vCenter (CPU, memory, CPU ready, drives, network, uptime, snapshots) with **nothing
installed in the VMs**, split into Windows VMs, Linux VMs and appliances, with critical alerts that
stay on the screen until acknowledged or cleared.

MONITOR-01 is a **system of its own**: its own containers, database, encryption key, certificate,
port and address. It shares nothing with PATCH-01 except:

* **sign-in**: people use their PATCH-01 account (PATCH-01 checks the password and two-factor code;
  MONITOR-01 never stores the password). A local break-glass admin works when PATCH-01 is down.
* optionally, a PATCH-01 **viewer account** to show each VM's patch status.

Both go to PATCH-01's URL over HTTPS, to PATCH-01's certificate only. So MONITOR-01 can run on the
PATCH-01 server today and move to its own server later without changes ("Moving to its own server").

## What it shows

| Where | What |
|---|---|
| Overview | CPU, memory and storage rings (one segment per ESXi host / datastore), the counts, every VM as a cell coloured by its worst figure, drives almost full, busiest CPU, waiting for CPU, the VMs needing attention, the appliances, one VM's history |
| VMs | every VM, search, filter by kind and state, sort |
| VM | CPU, memory and CPU ready charts (1 h to 30 days), its drives, snapshots, Tools, its alerts, its patch status from PATCH-01; admins can set its kind |
| Hosts, Datastores | each ESXi host's CPU and memory; each datastore's space |
| Alerts | open, cleared, all; acknowledge (operators and admins) |
| Admin | vCenter connections, the rules, the audit |

**Critical** (alert on the screen: red strip, bell, a toast and a sound for each new one):
a drive 89% used or more · CPU 89% or more · memory 89% or more · CPU ready 10% or more.
**Warning** (colour only): 80% · CPU ready 5%.
CPU, memory and CPU ready must stay over the line for 5 minutes (a short spike is not an alert); a
drive alerts at once. An alert clears by itself 2 points under the line. All of this is in Admin, Rules.

Drives come from VMware Tools. A VM without Tools (many appliances) shows its drives as
"not reported", never as fine. Memory is the guest's active memory as vCenter sees it.

## Install (on the PATCH-01 server, or any RHEL server with Docker)

    tar -xzf monitor01-r114.tar.gz
    cd monitor01-r114
    sudo ./install.sh
    cd /opt/monitor01/scripts
    sudo ./monitor01.sh install --port 9443 --name monitor.corp.local

On a PATCH-01 server it uses the images PATCH-01 already has (PostgreSQL, NGINX, UBI Python). On
another server, write `/etc/monitor01/images.env` first:

    IMG_POSTGRES="registry.example/postgres:16"
    IMG_NGINX="registry.example/ubi9/nginx-124"
    IMG_PYTHON="registry.access.redhat.com/ubi9/python-311"

Then:

    sudo ./monitor01.sh --link-patch01 https://patch01.corp.local
    sudo ./monitor01.sh --local-admin monadmin

Open `https://monitor.corp.local:9443/`, sign in as a PATCH-01 admin, Admin > vCenter > add vCenter:
address, read-only account, **Get certificate**, compare the fingerprint, **Test and save**.
Figures appear within a minute.

Who may sign in: PATCH-01 admins, and users with the **inventory** or **patch** module
(`MON_ALLOWED_MODULES` in `/etc/monitor01/monitor.env`). Roles carry over: viewer sees, operator
also acknowledges alerts, admin also manages vCenter and the rules.

### The vCenter account

Make a vCenter user (for example `monitor-ro@vsphere.local`) and give it the built-in **Read-only**
role at the top of the inventory (vCenter), with "Propagate to children". That is all it needs.
MONITOR-01 also refuses, on its own side, every vCenter call that is not a read (an allow-list of
the read calls; anything else is never sent).

### Optional: patch status from PATCH-01

In PATCH-01 make a viewer account with only the patch module, then:

    sudo ./monitor01.sh --patch01-service monitor-svc

### Your own certificate

    sudo ./monitor01.sh --cert monitor.crt --key monitor.key

## Running it

    sudo ./monitor01.sh --check          containers, collector, each vCenter
    sudo ./monitor01.sh --logs collector  (api | collector | web | db)
    sudo ./monitor01.sh --down           stop (data kept)
    sudo ./monitor01.sh install          start again / after an upgrade (re-run safe)

Files: settings and secrets `/etc/monitor01` (keep `monitor.key` with the backups: it decrypts the
vCenter passwords), data `/srv/monitor01`, logs `/var/log/monitor01`, program `/opt/monitor01`.
History: a figure a minute for 2 days, then hourly for 35 days.

## Upgrading

    tar -xzf monitor01-rNNN.tar.gz && cd monitor01-rNNN && sudo ./install.sh
    cd /opt/monitor01/scripts && sudo ./monitor01.sh install

## Moving to its own server

On the old server:

    sudo ./monitor01.sh --backup /root

On the new server (Docker, the images, `/etc/monitor01/images.env`):

    sudo ./install.sh                       (the package)
    sudo ./monitor01.sh install --name monitor.corp.local
    sudo ./monitor01.sh --restore /root/monitor01-YYYYMMDD-HHMMSS.tar.gz
    sudo ./monitor01.sh install

Point the DNS name at the new server, open the port, and stop the old one (`--down`). Sign-in
still goes to PATCH-01 (`PATCH01_URL` came with the backup). The new server must reach PATCH-01
on 443 and each vCenter on 443.

## Network

| From | To | Port | Why |
|---|---|---|---|
| people | MONITOR-01 | 9443 (or `--port`) | the page |
| MONITOR-01 | vCenter | 443 | read-only figures |
| MONITOR-01 | PATCH-01 | 443 | sign-in, patch status |
