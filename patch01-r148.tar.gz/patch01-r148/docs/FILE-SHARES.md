# File shares: setting up the scanner (r146)

Vulnerabilities > File shares shows who owns each share and folder on your file servers, and who can reach it.
A small read-only scanner, `access-scan.ps1`, runs on each file server. The PATCH-01 agent already installed there
starts it when you press **Scan now**. **The agent itself is not updated.**

The scanner only reads: shares, share permissions, NTFS permissions of folders (never files), and group members
from Active Directory. It never changes a permission, a file or a share.

## 1. Sign the scanner (if your agents are signed)

A signed agent starts only a signed scanner. In the folder that holds the agent's files (`client\windows`):

```powershell
.\Sign-Agent.ps1
```

It signs every `.ps1` in the folder, `access-scan.ps1` included, with the certificate you sign the agent with.

## 2. Copy it to each file server

Copy `access-scan.ps1` next to `patch-agent.ps1`, in the agent's folder (normally `C:\Program Files\PatchAgent\`).
Replace any older `access-scan.ps1` there: the one from r120–r128 (version 1.x) sends to an address PATCH-01 no
longer has. The new one's first lines say **2.0.1** (2.0.0 stopped at the end of a scan: copy 2.0.1 over it).

## 3. Try it once, by hand (sends nothing)

As administrator, on the file server:

```powershell
& "C:\Program Files\PatchAgent\access-scan.ps1" -DryRun -MaxFolders 5000
```

It reads the shares (at most 5,000 folders with `-MaxFolders`; leave it out to read everything) and prints what it
found: shares, folders read, folders listed, unreadable folders, links skipped, accounts, memberships, whether
Active Directory answered, and the time it took. It sends nothing. The figures and the first 200 accounts are also
written to `%TEMP%\access-scan-dryrun.json`. One share only: `-Share Finance`.

## 4. Scan from the page

Vulnerabilities > File shares: **Add to the audit** for each file server, then **Scan now**. The page follows the
scan. A big server can take a while. Its log on the server is `C:\ProgramData\PatchAgent\access-scan.log`.

## 5. Upload the ownership workbook

**Upload ownership workbook** (.xlsx, one sheet per server). For each sheet, check its server and the column of
each field (full path, share, folder, department, owner, e-mail). Then press **Use the workbook**. Rows that match
a folder exactly are used. The others wait in Review:

- **To confirm:** found by name only, or written slightly differently.
- **Not found:** the folder is not on the server.
- **No owner:** a share or folder that no row covers.

## What is left out

- The administrative shares (C$, ADMIN$, IPC$), print$, SYSVOL and NETLOGON.
- Every share on the system drive.
- Windows' own folders at the root of a volume (System Volume Information, $RECYCLE.BIN), and DFS Replication's
  hidden DfsrPrivate folders.
- Links (junctions, mount points), which are not followed. A folder whose attributes Windows will not give is not
  opened either (it could be a link), and is counted.
- A share inside another share is read once, as itself, not twice.
- Two shares on the same folder (`Data` and `Data$`) are read once, as the first. The summary names the second:
  its own share permissions are not counted in the rights shown, so check them on the server.
- Folders more than 64 levels down, and folders whose path is longer than 4,000 characters (with what is below).
- Files: only folders are read.
- A scan stops walking after 10 hours and sends what it read.

Every one of these that happened is counted, and the summary (page, PDF and Excel) says so under **What the last
scan could not cover**.

## Check by hand on your servers

The scanner was tested against PATCH-01 here, but not on a Windows file server. These points can only be checked on
yours, once, with the dry run (step 3):

1. **The shares and figures.** The dry run's `shares` must be the number of shares you expect to audit. Compare a
   few folders' permissions with the folder's Security tab.
2. **Long paths.** If you have paths longer than 260 characters, run the dry run on that share (`-Share <name>`)
   and check the log has no "could not be read" for them.
3. **Folders that refuse SYSTEM.** The agent runs as SYSTEM, which cannot read a folder whose permissions leave
   SYSTEM and Administrators out. Those folders are listed under **Could not be read**: that is the real state of
   the folder, not a fault of the scan.
4. **Volumes mounted in a folder** on C: are not read (C: is left out). If a data volume is mounted that way rather
   than with a drive letter, tell us.
5. **A very big server.** If the agent's task settings stop a task after a time limit, a long scan can be stopped
   with it. The page then shows the scan as stalled. Its log is `C:\ProgramData\PatchAgent\access-scan.log`.
6. **Active Directory.** `ad` in the dry run must say `read`. `not reached` means the server could not reach a
   domain controller, so group members are missing.
7. **Local groups.** Pick a local group of the server that holds domain groups (in a folder's permissions) and
   check, on the page's Permissions tab, that its people are the ones Computer Management shows.
8. **An account of a trusted domain that is out of reach** may show as an orphaned SID rather than "not looked
   up". Check any orphaned SID on the page before removing it. In a forest with more than one tree, check that
   an account of the other tree shows its name.
9. **A scan stopped halfway** (the server restarted, say): the next Scan now must start normally. If the page
   says "another scan is running" with none running, tell us.
