"""Access review (r119): file and folder permissions, and which application and team owns them.

An admin uploads a permissions report as CSV, from whichever tool made it (NTFS Permissions
Reporter, Netwrix, Varonis, ManageEngine, PowerShell Get-Acl, ...). Then:

  1. Reading:  the worker reads it as it is: its encoding (UTF-8, UTF-16, Windows-1252), its
               separator, and where the header row is (a title above it is skipped).
  2. Columns:  rules that know these tools' column names, then AI-01 for the rest, propose which
               column is the path, the account, the permissions, and so on. The admin confirms.
  3. Rows:     each row is made plain by rules, never by AI-01: server, share, folder, account,
               the kind of account, the access level (from words, letters or an access mask),
               allow or deny, inherited or not.
  4. Tagging:  AI-01 proposes the application and owning team of each folder (from its path,
               the groups on it, its sub-folders, and what the admin confirmed before). Nothing
               it proposes counts as confirmed until an admin says so; confirmed tags are kept
               for the next upload. A tag covers the folder and everything under it.
  5. Reports:  AI-01 recommends which reports fit this file; the admin chooses step by step;
               every figure is counted by PostgreSQL from the rows. AI-01 then writes a short
               summary from those figures only.

AI-01 only ever sees column names, a few sample values, folder names and group names: never the
whole file, and it never counts.
"""
import codecs
import csv
import io
import json
import logging
import re

log = logging.getLogger("patchapi.perm")

MAX_BYTES = 1024 * 2 ** 20          # 1 GB
MAX_ROWS = 3_000_000
MAX_COLS = 80
MAX_CELL = 2000
CHUNK = 16 * 2 ** 20
CHUNK_MAX = 32 * 2 ** 20
csv.field_size_limit(4 * 2 ** 20)

# ---- 1. reading ------------------------------------------------------------------------------------

def detect_encoding(head):
    """The encoding of a file from its first bytes: a byte-order mark, else UTF-16 by its zero
    bytes, else UTF-8 if it decodes, else Windows-1252 (which decodes anything)."""
    if head.startswith(codecs.BOM_UTF8):
        return "utf-8-sig"
    if head.startswith(codecs.BOM_UTF16_LE):
        return "utf-16-le-bom"
    if head.startswith(codecs.BOM_UTF16_BE):
        return "utf-16-be-bom"
    sample = head[:4096]
    if len(sample) >= 4:
        odd_zero = sum(1 for b in sample[1::2] if b == 0) / max(1, len(sample[1::2]))
        even_zero = sum(1 for b in sample[0::2] if b == 0) / max(1, len(sample[0::2]))
        if odd_zero > 0.4 and even_zero < 0.05:
            return "utf-16-le"
        if even_zero > 0.4 and odd_zero < 0.05:
            return "utf-16-be"
    try:
        head.decode("utf-8")
        return "utf-8"
    except UnicodeDecodeError as e:
        # a multi-byte character cut at the end of the sample is still UTF-8
        if e.reason == "unexpected end of data" and e.start >= len(head) - 3:
            try:
                head[:e.start].decode("utf-8")
                return "utf-8"
            except UnicodeDecodeError:
                pass
        return "cp1252"


def decoder_for(encoding):
    """An incremental decoder; a BOM is skipped."""
    name = {"utf-16-le-bom": "utf-16", "utf-16-be-bom": "utf-16"}.get(encoding, encoding)
    return codecs.getincrementaldecoder(name)(errors="replace")


def sniff_delimiter(text):
    """The separator that splits the first lines into the same number of fields, most often."""
    lines = [ln for ln in text.splitlines()[:60] if ln.strip()]
    best, best_score = ",", -1
    for d in (",", ";", "\t", "|"):
        counts = []
        for row in csv.reader(lines, delimiter=d):
            counts.append(len(row))
        if not counts:
            continue
        common = max(set(counts), key=counts.count)
        if common < 2:
            continue
        score = counts.count(common) * common
        if score > best_score:
            best, best_score = d, score
    return best


def find_header(rows):
    """Which of the first rows is the header: the first with the number of fields most rows have,
    every field filled in, and not all numbers. A title or 'Report generated on ...' above it is skipped."""
    if not rows:
        return 0
    lens = [len([c for c in r if c.strip()]) for r in rows]
    common = max(set(lens), key=lens.count)
    for i, r in enumerate(rows[:40]):
        cells = [c.strip() for c in r]
        filled = [c for c in cells if c]
        if len(filled) >= max(2, common) and len(filled) == len(cells[:len(filled)]) and \
                not all(re.fullmatch(r"[\d.,:/ -]+", c) for c in filled):
            return i
    return 0


def lines_from(pieces):
    """Lines (with their line ends) from decoded text pieces of any size; a line split between two
    pieces is joined, and so is a \\r\\n split between them."""
    rest = ""
    for t in pieces:
        if not t:
            continue
        rest += t
        parts = rest.splitlines(keepends=True)
        rest = ""
        if parts and not parts[-1].endswith(("\n", "\r")):
            rest = parts.pop()
        elif parts and parts[-1].endswith("\r"):
            rest = parts.pop()                     # maybe half of a \r\n
        for p in parts:
            yield p
    if rest:
        yield rest


def clean_cell(v):
    v = (v or "").replace("\x00", "").strip()
    return v[:MAX_CELL]


# ---- 2. columns ----------------------------------------------------------------------------------------

ROLES = [
    ("path", "Folder or file path", True),
    ("identity", "Account or group", True),
    ("rights", "Permissions", True),
    ("access_type", "Allow or deny", False),
    ("inherited", "Inherited", False),
    ("owner", "Owner of the folder", False),
    ("server", "Server", False),
    ("share", "Share", False),
    ("account_type", "Kind of account (user, group)", False),
    ("application", "Application (when the file has it)", False),
    ("team", "Owning team (when the file has it)", False),
]
ROLE_KEYS = [r[0] for r in ROLES]
REQUIRED = [r[0] for r in ROLES if r[2]]

# Column names as these tools write them (lower case, letters and digits only)
SYNONYMS = {
    "path": ["path", "folderpath", "objectpath", "fullpath", "folder", "directory", "directorypath", "dir", "resource",
             "resourcepath", "location", "filepath", "sharepath", "uncpath", "object", "objectname", "foldername", "item",
             "itempath", "fullname", "filesystempath"],
    "identity": ["account", "accountname", "identity", "identityreference", "trustee", "trusteename", "user", "username",
                 "principal", "principalname", "securityprincipal", "group", "groupname", "member", "accountdisplayname",
                 "samaccountname", "who", "name", "useraccount", "userorgroup", "usergroup", "accountorgroup"],
    "rights": ["permissions", "permission", "rights", "accessrights", "filesystemrights", "access", "accessmask",
               "permissionlevel", "effectivepermissions", "accesslevel", "perms", "ntfspermissions", "folderpermissions",
               "permissionsgranted", "accesspermissions"],
    "access_type": ["accesscontroltype", "accesstype", "permissiontype", "allowdeny", "acetype", "type", "accesscontrol",
                    "allowordeny", "grantdeny"],
    "inherited": ["inherited", "isinherited", "inheritance", "inheritedfrom", "inherit", "inheritedpermission",
                  "explicitorinherited", "inheritancetype"],
    "owner": ["owner", "folderowner", "objectowner", "fileowner"],
    "server": ["server", "servername", "host", "hostname", "computer", "computername", "fileserver", "machine", "device",
               "devicename", "nasname", "filer"],
    "share": ["share", "sharename", "sharedfolder"],
    "account_type": ["accounttype", "objecttype", "objectclass", "principaltype", "trusteetype", "accountclass",
                     "identitytype", "usertype", "type"],
    "application": ["application", "app", "appname", "applicationname", "system", "service", "businessapplication"],
    "team": ["team", "ownerteam", "owningteam", "appowner", "applicationowner", "department", "businessowner",
             "dataowner", "supportteam", "resolvergroup"],
}


def _norm_header(h):
    return re.sub(r"[^a-z0-9]", "", (h or "").lower())


def _value_score(role, values):
    """How well a column's values fit a role: 0 none .. 3 sure."""
    vals = [v for v in values if v][:40]
    if not vals:
        return 0
    def share(pred):
        return sum(1 for v in vals if pred(v)) / len(vals)
    if role == "path":
        s = share(lambda v: bool(re.match(r"^(\\\\[^\\]+\\|[A-Za-z]:\\|/)", v)))
        return 3 if s > 0.8 else 1 if s > 0.3 else 0
    if role == "identity":
        s = share(lambda v: bool(re.match(r"^([\w.\- ]+\\[\w.\-$ ]+|[\w.\-]+@[\w.\-]+|S-1-[\d-]+|everyone|authenticated users|"
                                          r"creator owner|system|[\w.\- $]{2,64})$", v, re.I)) and not re.match(r"^(\\\\|[A-Za-z]:\\)", v))
        return 2 if s > 0.8 else 0
    if role == "rights":
        s = share(lambda v: level_of(v) not in ("special", "none") or v.lower() in ("special", "special permissions"))
        return 3 if s > 0.7 else 1 if s > 0.3 else 0
    if role == "access_type":
        s = share(lambda v: v.strip().lower() in ("allow", "deny", "allowed", "denied", "grant", "granted"))
        return 3 if s > 0.9 else 0
    if role == "inherited":
        s = share(lambda v: bool_of(v) is not None)
        return 2 if s > 0.9 else 0
    if role == "account_type":
        s = share(lambda v: any(w in v.lower() for w in ("user", "group", "computer", "well-known", "wellknown", "alias")))
        return 2 if s > 0.8 else 0
    return 1


def rule_mapping(headers, rows):
    """Which column is which, by the names these tools use and by what the values look like.
    {role: {"col": index, "score": n, "why": text}}; each column is used for one role at most."""
    cols = {i: [r[i] if i < len(r) else "" for r in rows] for i in range(len(headers))}
    cand = []
    for role in ROLE_KEYS:
        for i, h in enumerate(headers):
            n = _norm_header(h)
            name = 3 if n in SYNONYMS[role] else 2 if any(n.endswith(s) or n.startswith(s) for s in SYNONYMS[role] if len(s) > 3) else 0
            vs = _value_score(role, cols[i])
            if role in ("path", "rights", "access_type", "inherited") and name and not vs:
                name = 0                              # a name alone is not enough when the values say otherwise
            score = name * 2 + vs
            if score >= 3:
                cand.append((score, role, i, f"column \"{h}\": " + ("its name" if name else "") +
                             (" and " if name and vs else "") + ("its values" if vs else "")))
    out, used = {}, set()
    for score, role, i, why in sorted(cand, key=lambda x: -x[0]):
        if role in out or i in used:
            continue
        out[role] = {"col": i, "score": score, "why": why}
        used.add(i)
    return out


def mapping_messages(headers, rows):
    """What AI-01 is shown to map the columns: each column's name and five sample values."""
    cols = []
    for i, h in enumerate(headers[:MAX_COLS]):
        vals = []
        for r in rows:
            v = (r[i] if i < len(r) else "").strip()
            if v and v not in vals:
                vals.append(v[:60])
            if len(vals) >= 5:
                break
        cols.append({"column": h[:80], "samples": vals})
    roles = {k: label for k, label, _ in ROLES}
    return [
        {"role": "system", "content": "You map the columns of a file and folder permissions report (CSV) to fields. "
         "Answer only with JSON. For each field give the exact column name that holds it, or an empty string when no "
         "column does. Never invent a column name. Use a column for one field at most."},
        {"role": "user", "content": "Fields: " + json.dumps(roles) + "\nColumns with sample values: " + json.dumps(cols)},
    ]


def mapping_schema(headers):
    names = [h[:80] for h in headers[:MAX_COLS]] + [""]
    return {"type": "object", "properties": {k: {"type": "string", "enum": names} for k in ROLE_KEYS},
            "required": ROLE_KEYS}


def merge_mapping(headers, rule, ai):
    """The proposal: a sure rule wins; AI-01 fills what the rules could not tell, only with a
    column that exists and is not used yet. {role: {"col", "by", "why"}}."""
    out, used = {}, set()
    for role, r in rule.items():
        if r["score"] >= 5:
            out[role] = {"col": r["col"], "by": "rules", "why": r["why"]}
            used.add(r["col"])
    idx = {h[:80]: i for i, h in enumerate(headers)}
    for role in ROLE_KEYS:
        if role in out:
            continue
        name = (ai if isinstance(ai, dict) else {}).get(role) or ""
        name = name if isinstance(name, str) else ""
        if name in idx and idx[name] not in used:
            out[role] = {"col": idx[name], "by": "AI-01", "why": f"AI-01 read column \"{name}\" as {role.replace('_', ' ')}"}
            used.add(idx[name])
        elif role in rule and rule[role]["col"] not in used:
            out[role] = {"col": rule[role]["col"], "by": "rules", "why": rule[role]["why"]}
            used.add(rule[role]["col"])
    return out


def check_mapping(mapping, headers):
    """An admin's mapping: {role: column index or None}. Returns the clean mapping, or ValueError."""
    if not isinstance(mapping, dict):
        raise PermError("The mapping must say which column holds what.")
    out, used = {}, {}
    for role in ROLE_KEYS:
        v = mapping.get(role)
        if v is None or v == "":
            continue
        try:
            i = int(v)
        except (TypeError, ValueError):
            raise PermError(f"{role}: not a column.")
        if not 0 <= i < len(headers):
            raise PermError(f"{role}: there is no column {i + 1}.")
        if i in used:
            raise PermError(f"Column \"{headers[i]}\" is chosen for both {used[i]} and {role}: one field per column.")
        used[i] = role
        out[role] = i
    missing = [label for k, label, req in ROLES if req and k not in out]
    if missing:
        raise PermError("Choose the column for: " + ", ".join(missing) + ".")
    return out


# ---- 3. rows made plain -----------------------------------------------------------------------------------

LEVELS = ["none", "special", "list", "read", "read_execute", "write", "modify", "full"]
RANK = {lv: i for i, lv in enumerate(LEVELS)}
LEVEL_TEXT = {"full": "Full control", "modify": "Modify", "write": "Write", "read_execute": "Read & execute",
              "read": "Read", "list": "List folder", "special": "Special", "none": "None"}
WRITE_LEVELS = ("write", "modify", "full")

WORDS = [  # (pattern on the squeezed text, level); the highest found wins
    (r"fullcontrol|^full$|^fc$|genericall|changepermissions|takeownership|writedac|writeowner", "full"),
    (r"modify|^change$", "modify"),
    (r"write|createfiles|createdirectories|appenddata|writedata|genericwrite|^delete", "write"),
    (r"readandexecute|read&execute|readexecute|executefile|traverse|genericexecute", "read_execute"),
    (r"read|genericread|readdata|readattributes|readpermissions", "read"),
    (r"list|listdirectory|listfolder", "list"),
    (r"special|synchronize", "special"),
]
LETTERS = {"f": "full", "m": "modify", "w": "write", "x": "read_execute", "r": "read", "l": "list"}


def level_of_mask(m):
    if m & 0x10000000 or (m & 0x1F01FF) == 0x1F01FF or m & 0x40000 or m & 0x80000:
        return "full"                                  # all rights, or can change permissions or take ownership
    if m & 0x10000 and m & 0x2 and m & 0x1:
        return "modify"
    if m & (0x2 | 0x4 | 0x40000000):
        return "write"
    if (m & 0x20 and m & 0x1) or m & 0x20000000:
        return "read_execute"
    if m & (0x1 | 0x80000000):
        return "read"
    if m & 0x20:
        return "list"
    return "special" if m else "none"


def level_of(text):
    """The access level of one entry, from the words, letters or access mask a tool writes."""
    t = (text or "").strip()
    if not t:
        return "none"
    if re.fullmatch(r"-?\d{1,10}", t):
        return level_of_mask(int(t) & 0xFFFFFFFF)
    if re.fullmatch(r"0x[0-9a-fA-F]{1,8}", t):
        return level_of_mask(int(t, 16))
    if re.fullmatch(r"[FMRWXLfmrwxl]{1,6}", t) and t.isupper():
        return max((LETTERS[c.lower()] for c in t), key=lambda lv: RANK[lv])
    best = None
    for part in re.split(r"[,;|/+]", t):
        sq = re.sub(r"[\s_\-()]", "", part.lower())
        if not sq:
            continue
        for pat, lv in WORDS:
            if re.search(pat, sq):
                if best is None or RANK[lv] > RANK[best]:
                    best = lv
                break
    return best or "special"


def bool_of(v):
    t = (v or "").strip().lower()
    if t in ("true", "yes", "y", "1", "inherited", "inherit", "parent") or t.startswith("inherited from") or t.startswith("yes"):
        return True
    if t in ("false", "no", "n", "0", "explicit", "direct", "not inherited", "this folder only", "none", "explicitly assigned",
             "explicit permission"):
        return False
    if t.startswith("\\\\") or re.match(r"^[a-z]:\\", t):
        return True                                    # "inherited from" written as the parent's path
    return None


def allow_of(v):
    t = (v or "").strip().lower()
    if t.startswith("deny") or t.startswith("denied"):
        return False
    return True


SYSTEM_NAMES = {"system", "nt authority\\system", "creator owner", "creator group", "local system", "trustedinstaller",
                "nt service\\trustedinstaller", "owner rights", "nt authority\\local service", "nt authority\\network service"}
ADMIN_NAMES = {"administrators", "builtin\\administrators", "domain admins", "enterprise admins", "backup operators",
               "builtin\\backup operators", "server operators", "builtin\\server operators", "schema admins"}
BROAD_NAMES = {"everyone", "authenticated users", "nt authority\\authenticated users", "users", "builtin\\users",
               "domain users", "domain computers", "guests", "builtin\\guests", "domain guests", "anonymous logon",
               "nt authority\\anonymous logon", "network", "nt authority\\network", "interactive",
               "nt authority\\interactive", "all users", "world"}
GROUP_NAME_RE = re.compile(r"^(grp|gg|sg|dl|lg|ug|gs|gl|acl|fs|role|sec|app)[_\-. ]|[_\-. ](rw|ro|mod|modify|read|write|"
                           r"readonly|readwrite|full|fc|owners?|members?|users|admins|group|grp|team|editors|readers|viewers)$|"
                           r"\bgroup\b", re.I)


def norm_identity(v):
    t = re.sub(r"\s+", " ", (v or "").strip())
    return t[:300]


def identity_kind(identity, account_type=None):
    """(kind, how it was told). Known built-in names first; then the file's own account type
    column; then a group's usual name; else 'unknown' (never a guess)."""
    low = identity.lower()
    short = low.split("\\", 1)[1] if "\\" in low else low
    if re.fullmatch(r"s-1-5-21(-\d+){3,5}", low) or "account unknown" in low or "unknown account" in low or \
            "(unresolved)" in low or "deleted account" in low:
        return "orphan", "rule"
    if low in SYSTEM_NAMES or low.startswith("nt service\\") or short in ("system", "creator owner", "creator group"):
        return "system", "rule"
    if low in ADMIN_NAMES or short in ADMIN_NAMES:
        return "admin", "rule"
    if low in BROAD_NAMES or short in ("everyone", "authenticated users", "domain users", "domain computers", "users",
                                       "guests", "domain guests", "anonymous logon"):
        return "broad", "rule"
    at = (account_type or "").strip().lower()
    if at:
        if "computer" in at or "machine" in at:
            return "computer", "column"
        if "group" in at or "alias" in at or "well" in at:
            return "group", "column"
        if "user" in at or "person" in at or "account" == at:
            return "user", "column"
    if low.endswith("$"):
        return "computer", "rule"
    if GROUP_NAME_RE.search(short):
        return "group", "name"
    return "unknown", "rule"


def split_path(path, server_col=None, share_col=None):
    """(server, share, parts below the share, display path, style). UNC \\\\server\\share\\a\\b,
    a drive path D:\\a\\b (server from its column), or a Linux path /srv/a/b."""
    p = (path or "").strip().strip('"').replace("/", "\\") if not (path or "").strip().startswith("/") else (path or "").strip()
    server, share = (server_col or "").strip() or None, (share_col or "").strip() or None
    if p.startswith("\\\\?\\UNC\\"):
        p = "\\\\" + p[8:]
    elif p.startswith("\\\\?\\"):
        p = p[4:]
    if p.startswith("\\\\"):
        bits = [b for b in p[2:].split("\\") if b]
        server = bits[0] if bits else server
        share = bits[1] if len(bits) > 1 else share
        parts = bits[2:]
        disp = "\\\\" + "\\".join(bits)
        style = "unc"
    elif re.match(r"^[A-Za-z]:\\?", p):
        bits = [b for b in p.split("\\") if b]
        share = bits[0].upper().rstrip("\\")
        parts = bits[1:]
        disp = ((server + " ") if server else "") + "\\".join([share] + parts)
        style = "drive"
    elif p.startswith("/"):
        bits = [b for b in p.split("/") if b]
        share = "/" + bits[0] if bits else "/"
        parts = bits[1:]
        disp = ((server + ":") if server else "") + p
        style = "posix"
    else:
        bits = [b for b in p.split("\\") if b]
        parts = bits
        disp = ((server + " ") if server else "") + p
        style = "plain"
    return server, share, parts, disp, style


def folder_key(server, share, parts, depth, style="unc"):
    """The unit tagged with an application: the share (or drive) and `depth` folder levels below
    it. (key in lower case, label as written). A tag on it covers everything under it."""
    below = list(parts[:depth])
    if style == "unc" and server:
        label = "\\\\" + "\\".join([server] + ([share] if share else []) + below)
    elif style == "drive":
        label = ((server + " ") if server else "") + "\\".join([share] + below) + ("" if below else "\\")
    elif style == "posix":
        label = ((server + ":") if server else "") + share + "".join("/" + b for b in below)
    else:
        label = ((server + " ") if server else "") + "\\".join(below or ["(no folder)"])
    return label.lower(), label


def entry_from(cells, m, depth):
    """One raw row -> a plain entry, or None (no path or no account: not an entry)."""
    def get(role):
        i = m.get(role)
        return clean_cell(cells[i]) if i is not None and i < len(cells) else ""
    path, ident = get("path"), norm_identity(get("identity"))
    if not path or not ident:
        return None
    server, share, parts, disp, style = split_path(path, get("server"), get("share"))
    key, label = folder_key(server, share, parts, depth, style)
    kind, src = identity_kind(ident, get("account_type"))
    rights = get("rights")
    return {"server": server, "share": share, "path": disp[:1000], "folder_key": key[:600], "folder_label": label[:600],
            "depth": len(parts), "identity": ident, "identity_kind": kind, "kind_source": src, "rights_raw": rights[:300],
            "level": level_of(rights), "allow": allow_of(get("access_type")) if m.get("access_type") is not None else
            (False if re.search(r"\bdeny\b", rights, re.I) else True),
            "inherited": bool_of(get("inherited")) if m.get("inherited") is not None else None,
            "owner": get("owner")[:300] or None, "application": get("application")[:120] or None,
            "team": get("team")[:120] or None}


# ---- the upload (in pieces, as Deployment's) ------------------------------------------------------------

NAME_RE = re.compile(r"^[^\x00-\x1f<>]{1,120}$")


class PermError(ValueError):
    """Shown to the admin as it is."""


def start_upload(conn, user, file_name, size, name=None):
    fn = (file_name or "").replace("\\", "/").split("/")[-1].strip()[:200]
    if not fn or not re.search(r"\.(csv|txt|tsv)$", fn, re.I):
        raise PermError("Upload the report as a .csv (or .txt / .tsv) file.")
    try:
        size = int(size)
    except (TypeError, ValueError):
        raise PermError("The file size is missing.")
    if size <= 0:
        raise PermError("The file is empty.")
    if size > MAX_BYTES:
        raise PermError(f"The file is larger than {MAX_BYTES // 2 ** 20} MB: export it in parts (for example per server).")
    nm = (name or fn.rsplit(".", 1)[0]).strip()[:120]
    if not NAME_RE.match(nm):
        raise PermError("Give the upload a name without control characters.")
    r = conn.execute("""INSERT INTO perm_datasets (name, file_name, size_bytes, uploaded_by) VALUES (%s, %s, %s, %s)
                        RETURNING id::text AS id""", (nm, fn, size, user)).fetchone()
    return {"dataset_id": r["id"], "chunk_bytes": CHUNK, "size": size}


def remove(conn, ds_id):
    r = conn.execute("DELETE FROM perm_datasets WHERE id = %s RETURNING name", (ds_id,)).fetchone()
    if not r:
        raise PermError("That upload is not known.")
    return r["name"]


def put_chunk(conn, upload_id, offset, data):
    ds = conn.execute("SELECT state, size_bytes, received FROM perm_datasets WHERE id = %s FOR UPDATE",
                      (upload_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known (it may have been removed).")
    if ds["state"] != "uploading":
        raise PermError("That upload is finished already.")
    if len(data) > CHUNK_MAX or not data:
        raise PermError("A piece of the file is empty or too large.")
    if offset != ds["received"]:
        raise PermError(f"Piece out of order: expected the bytes from {ds['received']}.")
    if offset + len(data) > ds["size_bytes"]:
        raise PermError("The file is larger than announced.")
    seq = conn.execute("SELECT coalesce(max(seq), -1) + 1 AS n FROM perm_chunks WHERE dataset_id = %s", (upload_id,)).fetchone()["n"]
    conn.execute("INSERT INTO perm_chunks (dataset_id, seq, offset_b, data) VALUES (%s, %s, %s, %s)",
                 (upload_id, seq, offset, bytes(data)))
    conn.execute("UPDATE perm_datasets SET received = received + %s, updated_at = now() WHERE id = %s", (len(data), upload_id))
    return {"received": offset + len(data)}


def finish_upload(conn, upload_id):
    ds = conn.execute("SELECT state, size_bytes, received FROM perm_datasets WHERE id = %s FOR UPDATE", (upload_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known.")
    if ds["state"] != "uploading":
        raise PermError("That upload is finished already.")
    if ds["received"] != ds["size_bytes"]:
        raise PermError(f"Only {ds['received']} of {ds['size_bytes']} bytes arrived: upload it again.")
    conn.execute("UPDATE perm_datasets SET state = 'uploaded', progress = %s::jsonb, updated_at = now() WHERE id = %s",
                 (json.dumps({"step": "waiting", "note": "the worker reads it within a few seconds"}), upload_id))
    return {"ok": True}


# ---- reading the file (worker) ----------------------------------------------------------------------------

def _progress(conn, ds_id, **p):
    conn.execute("UPDATE perm_datasets SET progress = %s::jsonb, updated_at = now() WHERE id = %s", (json.dumps(p), ds_id))
    conn.commit()


def _pieces(conn, ds_id):
    n = conn.execute("SELECT count(*) AS n FROM perm_chunks WHERE dataset_id = %s", (ds_id,)).fetchone()["n"]
    for seq in range(n):
        r = conn.execute("SELECT data FROM perm_chunks WHERE dataset_id = %s AND seq = %s", (ds_id, seq)).fetchone()
        if r:
            yield bytes(r["data"])


def bulk_insert(conn, table, cols, rows, types=None):
    """COPY when the driver has it (psycopg 3), else plain inserts."""
    rows = list(rows)
    if not rows:
        return
    cur = conn.cursor()
    if hasattr(cur, "copy"):
        # text format: the server reads each value as its column's type (no binary type names needed)
        with cur.copy(f"COPY {table} ({', '.join(cols)}) FROM STDIN") as cp:
            for r in rows:
                cp.write_row(r)
    else:
        cur.executemany(f"INSERT INTO {table} ({', '.join(cols)}) VALUES ({', '.join(['%s'] * len(cols))})", rows)


def read_file(conn, ds_id, stop=lambda: False):
    """The uploaded bytes -> perm_raw rows; the header, encoding, separator and a sample saved."""
    conn.execute("UPDATE perm_datasets SET state = 'reading', error = NULL WHERE id = %s", (ds_id,))
    conn.execute("DELETE FROM perm_raw WHERE dataset_id = %s", (ds_id,))
    conn.commit()
    pieces = _pieces(conn, ds_id)
    first = b""
    for b in pieces:                           # enough of the start to tell the encoding and the separator
        first += b
        if len(first) >= 262144:
            break
    enc = detect_encoding(first[:65536])
    dec = decoder_for(enc)
    head_text = dec.decode(first[:262144]) if len(first) > 0 else ""
    dec = decoder_for(enc)                     # start again: the sample was only to look at
    m = re.match(r"^\s*sep=(.)\s*$", head_text.splitlines()[0] if head_text else "")   # Excel's "sep=;" line
    delim = m.group(1) if m else sniff_delimiter(head_text)
    probe = list(csv.reader(head_text.splitlines()[:60], delimiter=delim))
    hdr_i = find_header(probe[1:]) + 1 if m else find_header(probe)

    def text():
        yield dec.decode(first)
        for b in pieces:
            yield dec.decode(b)
        yield dec.decode(b"", final=True)
    reader = csv.reader(lines_from(text()), delimiter=delim)
    headers, batch, rn, skipped, sample = None, [], 0, 0, []
    for i, row in enumerate(reader):
        if i < hdr_i:
            continue
        if headers is None:
            headers = [clean_cell(c) or f"Column {j + 1}" for j, c in enumerate(row[:MAX_COLS])]
            if len(headers) < 2:
                raise PermError("The file has fewer than two columns: is it a CSV permissions report?")
            continue
        cells = [clean_cell(c) for c in row[:MAX_COLS]]
        if not any(cells):
            continue
        if len(cells) < 2:
            skipped += 1
            continue
        rn += 1
        if rn > MAX_ROWS:
            raise PermError(f"More than {MAX_ROWS:,} rows: export the report in parts (for example per server).")
        if len(sample) < 25:
            sample.append(cells)
        batch.append((ds_id, rn, cells))
        if len(batch) >= 5000:
            bulk_insert(conn, "perm_raw", ("dataset_id", "rn", "cells"), batch, ["uuid", "int4", "text[]"])
            batch = []
            if rn % 50000 == 0:
                _progress(conn, ds_id, step="reading", rows=rn)
                if stop():
                    raise PermError("Stopped: the worker was restarted. Upload the file again.")
    bulk_insert(conn, "perm_raw", ("dataset_id", "rn", "cells"), batch, ["uuid", "int4", "text[]"])
    if headers is None or rn == 0:
        raise PermError("No rows found under the header: is it the right file?")
    conn.execute("""UPDATE perm_datasets SET encoding = %s, delimiter = %s, header_row = %s, headers = %s, sample = %s::jsonb,
                           row_count = %s, skipped = %s, state = 'mapping', progress = NULL WHERE id = %s""",
                 (enc, {"\t": "tab"}.get(delim, delim), hdr_i + 1, headers, json.dumps(sample), rn, skipped, ds_id))
    conn.execute("DELETE FROM perm_chunks WHERE dataset_id = %s", (ds_id,))
    conn.commit()
    return {"rows": rn, "headers": headers, "encoding": enc, "delimiter": delim}


def propose(conn, ds_id, ai=None):
    """The rules' and AI-01's proposal of which column is which; the admin confirms it."""
    ds = conn.execute("SELECT headers, sample FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    headers, sample = ds["headers"], ds["sample"] or []
    rule = rule_mapping(headers, sample)
    ai_raw, note = None, None
    if ai:
        try:
            ai_raw = _json(ai(mapping_messages(headers, sample), mapping_schema(headers)))
        except Exception as e:  # noqa: BLE001 - the rules' proposal stands alone
            note = "AI-01 did not answer (" + str(e)[:120] + "): the proposal is from the rules only."
    prop = merge_mapping(headers, rule, ai_raw)
    conn.execute("UPDATE perm_datasets SET proposal = %s::jsonb WHERE id = %s",
                 (json.dumps({"roles": prop, "note": note, "ai": bool(ai_raw)}), ds_id))
    conn.commit()
    return prop


# ---- making rows plain, folders, tags (worker) ----------------------------------------------------------

ENTRY_COLS = ("dataset_id", "rn", "server", "share", "path", "folder_key", "depth", "identity", "identity_kind", "kind_source",
              "rights_raw", "level", "allow", "inherited", "owner")
ENTRY_TYPES = ["uuid", "int4", "text", "text", "text", "text", "int4", "text", "text", "text", "text", "text", "bool", "bool", "text"]


def normalise(conn, ds_id, stop=lambda: False):
    ds = conn.execute("SELECT mapping, tag_depth, row_count FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    m = {k: int(v) for k, v in (ds["mapping"] or {}).items()}
    depth = ds["tag_depth"]
    conn.execute("UPDATE perm_datasets SET state = 'normalising', error = NULL WHERE id = %s", (ds_id,))
    conn.execute("DELETE FROM perm_entries WHERE dataset_id = %s", (ds_id,))
    conn.execute("DELETE FROM perm_folders WHERE dataset_id = %s", (ds_id,))
    conn.commit()
    labels, file_tags, skipped, last = {}, {}, 0, 0
    total = ds["row_count"] or 0
    while True:
        rows = conn.execute("SELECT rn, cells FROM perm_raw WHERE dataset_id = %s AND rn > %s ORDER BY rn LIMIT 20000",
                            (ds_id, last)).fetchall()
        if not rows:
            break
        out = []
        for r in rows:
            last = r["rn"]
            e = entry_from(r["cells"], m, depth)
            if not e:
                skipped += 1
                continue
            labels.setdefault(e["folder_key"], e["folder_label"])
            if e["application"] or e["team"]:
                t = file_tags.setdefault(e["folder_key"], {})
                t[(e["application"], e["team"])] = t.get((e["application"], e["team"]), 0) + 1
            out.append((ds_id, r["rn"], e["server"], e["share"], e["path"], e["folder_key"], e["depth"], e["identity"],
                        e["identity_kind"], e["kind_source"], e["rights_raw"], e["level"], e["allow"], e["inherited"], e["owner"]))
        bulk_insert(conn, "perm_entries", ENTRY_COLS, out, ENTRY_TYPES)
        conn.commit()
        _progress(conn, ds_id, step="normalising", rows=last, total=total)
        if stop():
            raise PermError("Stopped: the worker was restarted. Confirm the columns again to go on.")
    conn.execute("""INSERT INTO perm_folders (dataset_id, folder_key, label, server, entries, paths, identities)
                    SELECT dataset_id, folder_key, '', min(server), count(*), count(DISTINCT lower(path)), count(DISTINCT lower(identity))
                      FROM perm_entries WHERE dataset_id = %s GROUP BY dataset_id, folder_key""", (ds_id,))
    for k, lab in labels.items():
        conn.execute("UPDATE perm_folders SET label = %s WHERE dataset_id = %s AND folder_key = %s", (lab, ds_id, k))
    # Application / team columns in the file itself: proposed as suggestions (an admin confirms them)
    for k, counts in file_tags.items():
        (app, team), n = max(counts.items(), key=lambda x: x[1])
        conn.execute("""INSERT INTO perm_tags (key_l, label, application, team, state, confidence, reason, suggested_by, suggested_at)
                        VALUES (%s, %s, %s, %s, 'suggested', 90, %s, 'file', now())
                        ON CONFLICT (key_l) DO UPDATE SET application = EXCLUDED.application, team = EXCLUDED.team,
                            confidence = 90, reason = EXCLUDED.reason, suggested_by = 'file', suggested_at = now()
                        WHERE perm_tags.state = 'suggested'""",
                     (k, labels.get(k, k), app, team, f"from the file's own columns ({n} rows say so)"))
    resolve_tags(conn, ds_id)
    conn.execute("UPDATE perm_datasets SET state = 'ready', skipped = skipped + %s, progress = NULL, profile = %s::jsonb WHERE id = %s",
                 (skipped, json.dumps(profile(conn, ds_id)), ds_id))
    conn.commit()


def parents(key):
    """A folder key and every parent of it that can carry a tag, longest first."""
    out = [key]
    k = key
    while True:
        cut = max(k.rfind("\\"), k.rfind("/"))
        if cut <= 2:
            break
        k = k[:cut]
        if k.endswith(":"):
            out.append(k + "\\")                     # a drive's root: "srv d:\\"
            break
        if k in ("\\", ""):
            break
        out.append(k)
    return out


def resolve_tags(conn, ds_id=None):
    """Each folder's tag in force: its own, else its nearest tagged parent; confirmed before suggested.
    For one upload, or (ds_id None) every upload (after an admin decides)."""
    tags = {r["key_l"]: r for r in conn.execute("""SELECT key_l, application, team, state FROM perm_tags
                                                     WHERE state <> 'rejected' AND (application IS NOT NULL OR team IS NOT NULL)""")}
    where, args = ("WHERE dataset_id = %s", (ds_id,)) if ds_id else ("", ())
    folders = conn.execute("SELECT dataset_id, folder_key, tag_key, application, team, tag_state FROM perm_folders " + where, args).fetchall()
    for f in folders:
        best = None
        for k in parents(f["folder_key"]):
            t = tags.get(k)
            if t and t["state"] == "confirmed":
                best = (k, t)
                break
            if t and best is None:
                best = (k, t)
        now = (best[0], best[1]["application"], best[1]["team"], best[1]["state"]) if best else (None, None, None, None)
        if now == (f["tag_key"], f["application"], f["team"], f["tag_state"]):
            continue                                       # unchanged: nothing written
        if best:
            k, t = best
            conn.execute("""UPDATE perm_folders SET tag_key = %s, application = %s, team = %s, tag_state = %s
                             WHERE dataset_id = %s AND folder_key = %s""",
                         (k, t["application"], t["team"], t["state"], f["dataset_id"], f["folder_key"]))
        else:
            conn.execute("""UPDATE perm_folders SET tag_key = NULL, application = NULL, team = NULL, tag_state = NULL
                             WHERE dataset_id = %s AND folder_key = %s AND tag_key IS NOT NULL""",
                         (f["dataset_id"], f["folder_key"]))
    conn.commit()


def profile(conn, ds_id):
    """What the file holds, counted: the facts AI-01 recommends reports from."""
    r = conn.execute("""SELECT count(*) AS entries, count(DISTINCT lower(path)) AS paths, count(DISTINCT lower(identity)) AS identities,
                               count(DISTINCT lower(server)) AS servers, count(DISTINCT lower(coalesce(server, '') || '\\' || coalesce(share, ''))) AS shares,
                               count(*) FILTER (WHERE identity_kind = 'broad' AND allow AND level IN ('write', 'modify', 'full')) AS broad_write,
                               count(*) FILTER (WHERE identity_kind = 'broad' AND allow) AS broad_any,
                               count(*) FILTER (WHERE identity_kind = 'user' AND allow AND inherited IS FALSE) AS explicit_users,
                               count(*) FILTER (WHERE identity_kind = 'user') AS users,
                               count(*) FILTER (WHERE identity_kind = 'unknown') AS kind_unknown,
                               count(*) FILTER (WHERE identity_kind = 'orphan') AS orphans,
                               count(*) FILTER (WHERE NOT allow) AS denies,
                               count(*) FILTER (WHERE level = 'full' AND allow AND identity_kind NOT IN ('admin', 'system')) AS full_nonadmin,
                               count(*) FILTER (WHERE inherited IS NULL) AS inherit_unknown,
                               count(*) FILTER (WHERE level = 'special') AS special
                          FROM perm_entries WHERE dataset_id = %s""", (ds_id,)).fetchone()
    return dict(r, **folder_counts(conn, ds_id))


def folder_counts(conn, ds_id):
    """The tag counts, always as they are now (tags change after the rows are read)."""
    return conn.execute("""SELECT count(*) AS folders, count(*) FILTER (WHERE tag_state = 'confirmed') AS tagged,
                               count(*) FILTER (WHERE tag_state = 'suggested') AS suggested,
                               count(DISTINCT application) FILTER (WHERE tag_state = 'confirmed') AS applications,
                               count(DISTINCT team) FILTER (WHERE tag_state = 'confirmed') AS teams
                          FROM perm_folders WHERE dataset_id = %s""", (ds_id,)).fetchone()


# ---- tagging with AI-01 (worker) ------------------------------------------------------------------------

TAG_BATCH = 12


def folder_hints(conn, ds_id, key):
    """What AI-01 is shown about one folder: groups on it with their level, and sub-folder names."""
    groups = conn.execute("""SELECT identity, max(CASE level WHEN 'full' THEN 7 WHEN 'modify' THEN 6 WHEN 'write' THEN 5
                                    WHEN 'read_execute' THEN 4 WHEN 'read' THEN 3 WHEN 'list' THEN 2 ELSE 1 END) AS lv, count(*) AS n
                               FROM perm_entries WHERE dataset_id = %s AND folder_key = %s
                                AND identity_kind NOT IN ('system', 'admin', 'orphan')
                              GROUP BY identity ORDER BY count(*) DESC LIMIT 10""", (ds_id, key)).fetchall()
    subs = conn.execute("""SELECT DISTINCT path FROM perm_entries WHERE dataset_id = %s AND folder_key = %s LIMIT 400""",
                        (ds_id, key)).fetchall()
    names = []
    for s in subs:
        p = s["path"]
        rest = p[len(key):] if p.lower().startswith(key) else p
        bit = [b for b in re.split(r"[\\/]", rest) if b]
        if bit and bit[0] not in names:
            names.append(bit[0][:40])
        if len(names) >= 8:
            break
    return {"groups": [{"name": g["identity"][:80], "level": LEVELS[g["lv"]] if g["lv"] < len(LEVELS) else "special"} for g in groups],
            "subfolders": names}


TAG_SYSTEM = """You tag file shares with the business application and the owning team they belong to, for an access review.
You are given folders (with the groups that have access and some sub-folder names) and examples an administrator confirmed.
For each folder answer: the application (a short name, e.g. "SAP Finance", "HR Records"), the owning team (e.g. "Finance IT",
"HR Systems"), a confidence from 0 to 100, and the reason in a few words from the evidence given.
Reuse the exact application and team names of the confirmed examples when they fit. When the evidence does not show the
application, answer an empty application with a low confidence: never guess from nothing. Answer only with JSON."""

TAG_SCHEMA = {"type": "object", "properties": {"items": {"type": "array", "items": {"type": "object", "properties": {
    "folder": {"type": "string"}, "application": {"type": "string"}, "team": {"type": "string"},
    "confidence": {"type": "integer"}, "reason": {"type": "string"}},
    "required": ["folder", "application", "team", "confidence", "reason"]}}}, "required": ["items"]}


def tag_messages(folders, examples):
    data = {"confirmed_examples": examples[:15], "folders": folders}
    return [{"role": "system", "content": TAG_SYSTEM}, {"role": "user", "content": json.dumps(data)[:12000]}]


def clean_tag_text(v, limit=80):
    t = re.sub(r"[\x00-\x1f<>]", " ", str(v or "")).strip()
    return re.sub(r"\s+", " ", t)[:limit]


def suggest_batch(conn, ds_id, ai, by="AI-01"):
    """One batch of folders without a tag (biggest first) -> AI-01's suggestions. Returns how many."""
    rows = conn.execute("""SELECT f.folder_key, f.label, f.entries FROM perm_folders f
                            WHERE f.dataset_id = %s AND f.tag_key IS NULL
                              AND NOT EXISTS (SELECT 1 FROM perm_tags t WHERE t.key_l = f.folder_key)
                            ORDER BY f.entries DESC, f.folder_key LIMIT %s""", (ds_id, TAG_BATCH)).fetchall()
    if not rows:
        return 0
    examples = [{"folder": r["label"], "application": r["application"], "team": r["team"]} for r in conn.execute(
        """SELECT label, application, team FROM perm_tags WHERE state = 'confirmed' ORDER BY decided_at DESC LIMIT 15""")]
    folders = [dict({"folder": r["label"]}, **folder_hints(conn, ds_id, r["folder_key"])) for r in rows]
    conn.commit()                                          # nothing held open while AI-01 thinks
    out = ai(tag_messages(folders, examples), TAG_SCHEMA)
    by_label = {r["label"].lower(): r for r in rows}
    n = 0
    for it in (out or {}).get("items") or []:
        r = by_label.get(str(it.get("folder") or "").strip().lower())
        if not r:
            continue                                       # a folder AI-01 made up, or renamed: ignored
        app, team = clean_tag_text(it.get("application")), clean_tag_text(it.get("team"))
        try:
            conf = max(0, min(100, int(it.get("confidence") or 0)))
        except (TypeError, ValueError):
            conf = 0
        if not app and not team:
            conf = min(conf, 20)
        conn.execute("""INSERT INTO perm_tags (key_l, label, application, team, state, confidence, reason, suggested_by, suggested_at)
                        VALUES (%s, %s, %s, %s, 'suggested', %s, %s, %s, now()) ON CONFLICT (key_l) DO NOTHING""",
                     (r["folder_key"], r["label"], app or None, team or None, conf, clean_tag_text(it.get("reason"), 200) or None, by))
        n += 1
    # folders AI-01 skipped get an empty suggestion, so the next batch moves on
    for r in rows:
        conn.execute("""INSERT INTO perm_tags (key_l, label, state, confidence, reason, suggested_by, suggested_at)
                        VALUES (%s, %s, 'suggested', 0, 'AI-01 gave no answer for it', %s, now()) ON CONFLICT (key_l) DO NOTHING""",
                     (r["folder_key"], r["label"], by))
    resolve_tags(conn, ds_id)
    return len(rows)


def decide(conn, user, items):
    """An admin's decisions on tags: confirm (as proposed or edited), or reject. items:
    [{key, decision: confirm|reject|clear, application, team}]"""
    done = 0
    for it in items[:2000]:
        key = str(it.get("key") or "").strip().lower()[:600]
        if not key:
            continue
        d = it.get("decision")
        app, team = clean_tag_text(it.get("application")) or None, clean_tag_text(it.get("team")) or None
        if d == "confirm":
            if not app and not team:
                raise PermError(f"{key}: give the application or the team before confirming.")
            label = clean_tag_text(it.get("label"), 600) or key
            conn.execute("""INSERT INTO perm_tags (key_l, label, application, team, state, decided_by, decided_at)
                            VALUES (%s, %s, %s, %s, 'confirmed', %s, now())
                            ON CONFLICT (key_l) DO UPDATE SET application = EXCLUDED.application, team = EXCLUDED.team,
                                state = 'confirmed', decided_by = EXCLUDED.decided_by, decided_at = now()""",
                         (key, label, app, team, user))
        elif d == "reject":
            conn.execute("""UPDATE perm_tags SET state = 'rejected', decided_by = %s, decided_at = now() WHERE key_l = %s""",
                         (user, key))
        elif d == "clear":
            conn.execute("DELETE FROM perm_tags WHERE key_l = %s", (key,))
        else:
            raise PermError("Each decision is confirm, reject or clear.")
        done += 1
    resolve_tags(conn)
    return done


# ---- 5. reports ---------------------------------------------------------------------------------------------

KINDS = {
    "risk": ("Risky access overview", "Every kind of risky access in one view: open to everyone, people given rights "
             "directly, orphaned accounts, full control outside the admin groups, deny entries."),
    "by_app": ("Access by application and owning team", "For each application and team: their folders, who has access, "
               "and what is risky there."),
    "team_review": ("Access review pack per owning team", "What each owning team must confirm: their folders and every "
                    "account with write access or more, to keep or remove."),
    "broad": ("Folders open to everyone", "Folders where Everyone, Authenticated Users, Domain Users or similar broad "
              "groups can change or read data."),
    "explicit_users": ("People given rights directly", "Accounts of people added to folders directly instead of through "
                       "a group: hard to review and to remove when they leave."),
    "orphans": ("Orphaned accounts", "Deleted users or groups still listed on folders (shown as a SID): clean-up candidates."),
    "full_control": ("Full control outside the admin groups", "Accounts other than the admin and system accounts that can "
                     "change permissions and take ownership."),
    "untagged": ("Folders without an application or owner", "What still needs an application and an owning team before "
                 "it can be reviewed by its owner."),
    "by_server": ("Summary by server and share", "For each server and share: how many folders and entries, and what is risky."),
}
CATS = {   # each finding's kind; an entry can be in more than one
    "broad_write": ("Open to everyone (change)", "e.identity_kind = 'broad' AND e.allow AND e.level = ANY(%(risky)s)"),
    "broad_read": ("Open to everyone (read)", "e.identity_kind = 'broad' AND e.allow AND NOT (e.level = ANY(%(risky)s)) AND e.level <> 'none'"),
    "explicit_user": ("Person given rights directly", "e.identity_kind = 'user' AND e.allow AND e.inherited IS FALSE"),
    "orphan": ("Orphaned account", "e.identity_kind = 'orphan'"),
    "full_nonadmin": ("Full control outside admins", "e.allow AND e.level = 'full' AND e.identity_kind NOT IN ('admin', 'system')"),
    "deny": ("Deny entry", "NOT e.allow"),
}
KIND_CATS = {"risk": ["broad_write", "explicit_user", "orphan", "full_nonadmin", "deny"], "broad": ["broad_write", "broad_read"],
             "explicit_users": ["explicit_user"], "orphans": ["orphan"], "full_control": ["full_nonadmin"],
             "by_app": ["broad_write", "explicit_user", "orphan", "full_nonadmin"], "team_review": ["broad_write", "explicit_user", "orphan", "full_nonadmin"],
             "by_server": ["broad_write", "explicit_user", "orphan", "full_nonadmin"], "untagged": ["broad_write", "explicit_user", "orphan", "full_nonadmin"]}
KIND_TEXT = {"user": "Person", "group": "Group", "computer": "Computer", "broad": "Everyone-type group", "admin": "Admin group",
             "system": "System account", "orphan": "Orphaned (SID)", "unknown": "Not stated in the file"}
TOP = 7


def clean_spec(conn, ds_id, spec):
    """An admin's choices, checked. Returns the clean spec."""
    if not isinstance(spec, dict):
        raise PermError("Say which report.")
    kind = spec.get("kind")
    if kind not in KINDS:
        raise PermError("Choose one of the reports.")
    sc = spec.get("scope") or {}
    op = spec.get("options") or {}
    def strs(v, n=500):
        return [clean_tag_text(x, 200) for x in (v or []) if clean_tag_text(x, 200)][:n] if isinstance(v, list) else []
    risky = [lv for lv in (op.get("risky_levels") or list(WRITE_LEVELS)) if lv in LEVELS]
    if not risky:
        raise PermError("Choose at least one access level that counts as risky.")
    tags = op.get("tags") if op.get("tags") in ("confirmed", "with_suggested") else "confirmed"
    title = clean_tag_text(spec.get("title"), 120) or KINDS[kind][0]
    return {"kind": kind, "title": title,
            "scope": {"servers": strs(sc.get("servers")), "applications": strs(sc.get("applications")), "teams": strs(sc.get("teams")),
                      "untagged": bool(sc.get("untagged", True))},
            "options": {"risky_levels": risky, "include_inherited": bool(op.get("include_inherited", True)), "tags": tags}}


def _base(spec):
    """The FROM and WHERE every figure of a report shares, and its parameters."""
    sc, op = spec["scope"], spec["options"]
    tagok = "f.tag_state = 'confirmed'" if op["tags"] == "confirmed" else "f.tag_state IS NOT NULL"
    app = f"CASE WHEN {tagok} THEN f.application END"
    team = f"CASE WHEN {tagok} THEN f.team END"
    where = ["e.dataset_id = %(ds)s"]
    if not op["include_inherited"]:
        where.append("e.inherited IS NOT TRUE")
    if sc["servers"]:
        where.append("lower(coalesce(e.server, '')) = ANY(%(servers)s)")
    tag_or = []
    if sc["applications"]:
        tag_or.append(f"{app} = ANY(%(apps)s)")
    if sc["teams"]:
        tag_or.append(f"{team} = ANY(%(teams)s)")
    if tag_or:
        if sc["untagged"]:
            tag_or.append(f"{app} IS NULL AND {team} IS NULL")
        where.append("(" + " OR ".join(tag_or) + ")")
    elif not sc["untagged"]:
        where.append(f"({app} IS NOT NULL OR {team} IS NOT NULL)")
    frm = " FROM perm_entries e JOIN perm_folders f ON f.dataset_id = e.dataset_id AND f.folder_key = e.folder_key "
    args = {"servers": [x.lower() for x in sc["servers"]], "apps": sc["applications"], "teams": sc["teams"],
            "risky": op["risky_levels"]}
    return frm + " WHERE " + " AND ".join(where), args, app, team


def compute(conn, ds_id, spec):
    """Every figure of a report, counted from the rows."""
    base, args, app, team = _base(spec)
    args["ds"] = ds_id
    cats = KIND_CATS[spec["kind"]]
    anycat = "(" + " OR ".join("(" + CATS[c][1] + ")" for c in cats) + ")"
    if spec["kind"] == "untagged":
        anycat = f"({app} IS NULL AND {team} IS NULL)"
    q = lambda sql: conn.execute(sql, args).fetchall()      # noqa: E731
    k = q(f"""SELECT count(*) AS entries, count(DISTINCT e.folder_key) AS folders, count(DISTINCT lower(e.path)) AS paths,
                     count(DISTINCT lower(e.identity)) AS identities, count(*) FILTER (WHERE {anycat}) AS findings,
                     count(DISTINCT e.folder_key) FILTER (WHERE {anycat}) AS folders_with,
                     count(DISTINCT {app}) AS applications, count(DISTINCT {team}) AS teams,
                     count(*) FILTER (WHERE e.identity_kind = 'unknown') AS kind_unknown,
                     count(*) FILTER (WHERE e.inherited IS NULL) AS inherit_unknown
                {base}""")[0]
    cat_counts = q("SELECT " + ", ".join(f"count(*) FILTER (WHERE {CATS[c][1]}) AS {c}" for c in CATS) + base)[0]
    levels = {r["level"]: r["n"] for r in q(f"SELECT e.level, count(*) AS n {base} AND e.allow GROUP BY e.level")}
    kinds = {r["identity_kind"]: r["n"] for r in q(f"SELECT e.identity_kind, count(*) AS n {base} GROUP BY e.identity_kind")}

    def by(expr, label_null):
        rows = q(f"""SELECT {expr} AS name, count(*) AS entries, count(*) FILTER (WHERE {anycat}) AS findings,
                            count(DISTINCT e.folder_key) AS folders, count(DISTINCT lower(e.identity)) AS identities,
                            """ + ", ".join(f"count(*) FILTER (WHERE {CATS[c][1]}) AS {c}" for c in CATS) +
                 f" {base} GROUP BY 1 ORDER BY count(*) FILTER (WHERE {anycat}) DESC, count(*) DESC")
        for r in rows:
            r["name"] = r["name"] if r["name"] is not None else label_null
        return rows
    apps = by(app, "Not tagged")
    teams = by(team, "Not tagged")
    servers = by("coalesce(e.server, '(not in the file)') || CASE WHEN e.share IS NOT NULL THEN ' · ' || e.share ELSE '' END",
                 "(not in the file)")
    folders = q(f"""SELECT f.label AS folder, {app} AS application, {team} AS team, f.tag_state AS tag_state,
                           count(*) AS entries, count(*) FILTER (WHERE {anycat}) AS findings,
                           """ + ", ".join(f"count(*) FILTER (WHERE {CATS[c][1]}) AS {c}" for c in CATS) + f"""
                      {base} GROUP BY f.label, 2, 3, f.tag_state
                      ORDER BY count(*) FILTER (WHERE {anycat}) DESC, count(*) DESC, f.label LIMIT 200""")
    who = q(f"""SELECT e.identity, e.identity_kind, count(*) AS findings, count(DISTINCT e.folder_key) AS folders,
                       max(CASE e.level WHEN 'full' THEN 7 WHEN 'modify' THEN 6 WHEN 'write' THEN 5 WHEN 'read_execute' THEN 4
                           WHEN 'read' THEN 3 WHEN 'list' THEN 2 WHEN 'special' THEN 1 ELSE 0 END) AS worst
                  {base} AND {anycat} GROUP BY e.identity, e.identity_kind
                  ORDER BY count(*) DESC, e.identity LIMIT 100""")
    for w in who:
        w["worst"] = LEVELS[w["worst"]]
    _, find_sql, _ = compute_sql_only(ds_id, spec)
    findings = conn.execute(find_sql + " LIMIT 500", args).fetchall()
    for f in findings:
        f["why"] = [CATS[c][0] for c in CATS if f.pop(c)]
    team_sections = []
    if spec["kind"] == "team_review":
        for t in teams[:40]:
            cond = f"{team} IS NULL" if t["name"] == "Not tagged" else f"{team} = %(t)s"
            rows = conn.execute(f"""SELECT f.label AS folder, e.identity, e.identity_kind, max(e.level) AS level_any,
                                           max(CASE e.level WHEN 'full' THEN 7 WHEN 'modify' THEN 6 WHEN 'write' THEN 5 ELSE 0 END) AS lv,
                                           bool_or({anycat}) AS risky
                                      {base} AND {cond} AND e.allow AND e.level IN ('write', 'modify', 'full')
                                       AND e.identity_kind NOT IN ('system', 'admin')
                                     GROUP BY f.label, e.identity, e.identity_kind ORDER BY f.label, lv DESC, e.identity LIMIT 400""",
                                dict(args, t=t["name"])).fetchall()
            team_sections.append({"team": t["name"], "rows": [{"folder": r["folder"], "identity": r["identity"],
                                  "kind": r["identity_kind"], "level": LEVELS[r["lv"]], "risky": r["risky"]} for r in rows]})

    def donut_of(rows, key="findings"):
        rows = [r for r in rows if r[key]]
        named = [r for r in rows if r["name"] != "Not tagged"]
        top, rest = named[:TOP], named[TOP:]
        segs = [{"label": r["name"], "value": r[key]} for r in top]
        if rest:
            segs.append({"label": f"Other ({len(rest)})", "value": sum(r[key] for r in rest), "other": True})
        nt = [r for r in rows if r["name"] == "Not tagged"]
        if nt:
            segs.append({"label": "Not tagged", "value": nt[0][key], "untagged": True})
        return segs
    measure = "entries" if spec["kind"] in ("untagged", "by_server") else "findings"
    return {
        "kpis": k, "categories": {c: {"label": CATS[c][0], "n": cat_counts[c], "in_report": c in cats} for c in CATS},
        "levels": [{"level": lv, "label": LEVEL_TEXT[lv], "n": levels.get(lv, 0)} for lv in reversed(LEVELS) if levels.get(lv)],
        "kinds": [{"kind": kd, "label": KIND_TEXT[kd], "n": n} for kd, n in sorted(kinds.items(), key=lambda x: -x[1])],
        "donuts": {"applications": donut_of(apps, measure), "teams": donut_of(teams, measure),
                   "servers": [{"label": r["name"], "value": r[measure]} for r in servers[:TOP] if r[measure]] +
                              ([{"label": f"Other ({len(servers) - TOP})", "value": sum(r[measure] for r in servers[TOP:]), "other": True}]
                               if len(servers) > TOP and sum(r[measure] for r in servers[TOP:]) else [])},
        "measure": measure,
        "applications": apps[:200], "teams": teams[:200], "servers": servers[:200], "folders": folders, "who": who,
        "findings": findings, "findings_total": k["findings"], "team_sections": team_sections,
    }, find_sql, args


def make_report(conn, ds_id, spec, user):
    ds = conn.execute("SELECT state FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known.")
    if ds["state"] != "ready":
        raise PermError("The rows are not ready yet: confirm the columns first.")
    spec = clean_spec(conn, ds_id, spec)
    r = conn.execute("""INSERT INTO perm_reports (dataset_id, kind, title, spec, created_by)
                        VALUES (%s, %s, %s, %s::jsonb, %s) RETURNING id::text AS id""",
                     (ds_id, spec["kind"], spec["title"], json.dumps(spec), user)).fetchone()
    return r["id"]


def build_report(conn, report_id):
    """The worker counts a report's figures (a million rows take a few seconds: not in the web request)."""
    r = conn.execute("SELECT dataset_id::text AS ds, spec FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
    conn.execute("UPDATE perm_reports SET state = 'computing' WHERE id = %s", (report_id,))
    conn.commit()
    result, _, _ = compute(conn, r["ds"], r["spec"])
    conn.execute("UPDATE perm_reports SET result = %s::jsonb, state = 'ready', error = NULL WHERE id = %s",
                 (json.dumps(result, default=str), report_id))
    conn.commit()


CSV_COLS = ["Folder", "Path", "Account", "Kind of account", "Access level", "Rights as in the file", "Allow or deny", "Inherited",
            "Application", "Owning team", "Why it is in the report"]


def safe_csv(v):
    """A cell a spreadsheet will never run as a formula."""
    t = "" if v is None else str(v)
    return "'" + t if t[:1] in ("=", "+", "-", "@", "\t", "\r") else t


def findings_csv(conn, report_id):
    """Every finding of a report (not only the first 500), as CSV text, counted again from the rows."""
    rep = conn.execute("SELECT dataset_id::text AS ds, spec, state FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
    if not rep:
        raise PermError("That report is not known.")
    if rep["state"] != "ready":
        raise PermError("The report is still being counted.")
    spec = rep["spec"] if isinstance(rep["spec"], dict) else json.loads(rep["spec"])
    _, sql, args = compute_sql_only(rep["ds"], spec)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(CSV_COLS)
    for f in conn.execute(sql, args):
        why = [CATS[c][0] for c in CATS if f.get(c)]
        w.writerow([safe_csv(x) for x in (f["folder"], f["path"], f["identity"], KIND_TEXT.get(f["identity_kind"], f["identity_kind"]),
                                          LEVEL_TEXT.get(f["level"], f["level"]), f["rights_raw"], "Allow" if f["allow"] else "Deny",
                                          {True: "Yes", False: "No"}.get(f["inherited"], "Not in the file"),
                                          f["application"] or "", f["team"] or "", "; ".join(why) or "Not tagged")])
    return "﻿" + buf.getvalue()


def compute_sql_only(ds_id, spec):
    base, args, app, team = _base(spec)
    args["ds"] = ds_id
    cats = KIND_CATS[spec["kind"]]
    anycat = "(" + " OR ".join("(" + CATS[c][1] + ")" for c in cats) + ")"
    if spec["kind"] == "untagged":
        anycat = f"({app} IS NULL AND {team} IS NULL)"
    sql = (f"""SELECT e.path, e.identity, e.identity_kind, e.kind_source, e.level, e.rights_raw, e.allow, e.inherited,
                      {app} AS application, {team} AS team, f.label AS folder, """ +
           ", ".join(f"({CATS[c][1]}) AS {c}" for c in CATS) +
           f" {base} AND {anycat} ORDER BY CASE e.level WHEN 'full' THEN 0 WHEN 'modify' THEN 1 WHEN 'write' THEN 2 ELSE 3 END,"
           " lower(e.path), lower(e.identity), e.rn")
    return None, sql, args


# ---- AI-01: which reports fit, and the summary ----------------------------------------------------------------

ADVICE_SYSTEM = """You help an administrator choose access-review reports for a file and folder permissions export.
You are given counts from the file. Recommend up to four reports from the list, the most useful first, each with one
sentence of why, quoting only counts you were given. Never invent a count. Answer only with JSON."""


def advice_messages(prof):
    kinds = {k: v[0] for k, v in KINDS.items()}
    return [{"role": "system", "content": ADVICE_SYSTEM},
            {"role": "user", "content": "Reports: " + json.dumps(kinds) + "\nCounts from the file: " + json.dumps(prof, default=str)}]


ADVICE_SCHEMA = {"type": "object", "properties": {"recommended": {"type": "array", "items": {"type": "object", "properties": {
    "report": {"type": "string", "enum": list(KINDS)}, "why": {"type": "string"}}, "required": ["report", "why"]}}},
    "required": ["recommended"]}


def rule_advice(prof):
    """What the rules recommend from the counts (also when AI-01 cannot be asked)."""
    p = prof or {}
    out = []
    if p.get("broad_write"):
        out.append(("broad", f"{p['broad_write']} entries let Everyone-type groups change data."))
    if p.get("orphans"):
        out.append(("orphans", f"{p['orphans']} entries name accounts that no longer exist."))
    if p.get("explicit_users"):
        out.append(("explicit_users", f"{p['explicit_users']} entries give people rights directly, not through a group."))
    if p.get("full_nonadmin"):
        out.append(("full_control", f"{p['full_nonadmin']} entries give full control outside the admin groups."))
    if p.get("tagged"):
        out.append(("by_app", f"{p['tagged']} folders have a confirmed application and team."))
    if p.get("folders") and (p.get("tagged") or 0) < p["folders"]:
        out.append(("untagged", f"{p['folders'] - (p.get('tagged') or 0)} of {p['folders']} folders have no confirmed application yet."))
    out.append(("risk", "One view of every kind of risky access in the file."))
    seen, res = set(), []
    for k, why in out:
        if k not in seen:
            seen.add(k)
            res.append({"report": k, "why": why, "by": "rules"})
    return res[:4]


NUM_RE = re.compile(r"\d[\d,]*")


def numbers_in(doc):
    """Every number a report holds (counts, as integers), to check AI-01's text against."""
    out = set()
    def walk(x):
        if isinstance(x, bool):
            return
        if isinstance(x, (int, float)):
            out.add(int(x))
        elif isinstance(x, dict):
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
    walk(doc)
    return out


def grounded(text, allowed):
    """Keep only the sentences whose numbers are all figures of the report (AI-01 never counts)."""
    keep = []
    for sent in re.split(r"(?<=[.!?])\s+", (text or "").strip()):
        nums = [int(n.replace(",", "")) for n in NUM_RE.findall(sent) if n.replace(",", "").isdigit()]
        if all(n in allowed for n in nums):
            keep.append(sent)
    return " ".join(keep).strip()


SUMMARY_SYSTEM = """You write the summary of an access-review report for the owners of the data. You are given the report's
figures. Write a headline (one sentence), three to five key points, and up to three first actions. Quote only figures you are
given, exactly as given; never compute percentages or new totals; never name an account, folder or team that is not in the
figures. Plain words, no jargon. Answer only with JSON."""
SUMMARY_SCHEMA = {"type": "object", "properties": {"headline": {"type": "string"}, "points": {"type": "array", "items": {"type": "string"}},
                                                   "actions": {"type": "array", "items": {"type": "string"}}},
                  "required": ["headline", "points", "actions"]}


def summary_facts(title, result):
    k = result["kpis"]
    return {"report": title, "entries_in_scope": k["entries"], "folders": k["folders"], "accounts": k["identities"],
            "findings": k["findings"], "folders_with_findings": k["folders_with"],
            "by_kind_of_risk": {v["label"]: v["n"] for v in result["categories"].values() if v["in_report"]},
            "top_applications": [{"application": r["name"], "findings": r["findings"], "entries": r["entries"]} for r in result["applications"][:6]],
            "top_teams": [{"team": r["name"], "findings": r["findings"]} for r in result["teams"][:6]],
            "top_folders": [{"folder": r["folder"], "findings": r["findings"]} for r in result["folders"][:5]],
            "top_accounts": [{"account": r["identity"], "findings": r["findings"], "folders": r["folders"]} for r in result["who"][:5]]}


def summary_messages(facts):
    return [{"role": "system", "content": SUMMARY_SYSTEM}, {"role": "user", "content": json.dumps(facts, default=str)[:9000]}]


def clean_summary(doc, facts):
    allowed = numbers_in(facts)
    head = grounded(clean_tag_text((doc or {}).get("headline"), 300), allowed)
    pts = [grounded(clean_tag_text(x, 300), allowed) for x in ((doc or {}).get("points") or [])[:5]]
    acts = [grounded(clean_tag_text(x, 300), allowed) for x in ((doc or {}).get("actions") or [])[:3]]
    pts, acts = [x for x in pts if x], [x for x in acts if x]
    if not head and not pts:
        return None
    return {"headline": head, "points": pts, "actions": acts}


# ---- what the console shows ----------------------------------------------------------------------------------

DS_COLS = """id::text AS id, name, file_name, size_bytes, received, uploaded_by, uploaded_at, state, error, encoding, delimiter,
             header_row, row_count, skipped, tag_depth, tag_ai, tag_ai_note, progress, mapping_by, mapping_at, updated_at"""


def datasets(conn):
    try:
        with conn.transaction():
            rows = conn.execute(f"""SELECT {DS_COLS}, (SELECT count(*) FROM perm_reports r WHERE r.dataset_id = d.id) AS reports
                                      FROM perm_datasets d ORDER BY uploaded_at DESC LIMIT 100""").fetchall()
    except Exception:  # noqa: BLE001 - schema 060 not applied yet
        return None
    return {"items": rows, "max_mb": MAX_BYTES // 2 ** 20, "max_rows": MAX_ROWS, "chunk_bytes": CHUNK,
            "roles": [{"key": k, "label": lab, "required": req} for k, lab, req in ROLES],
            "kinds": [{"key": k, "title": v[0], "about": v[1]} for k, v in KINDS.items()],
            "levels": [{"key": lv, "label": LEVEL_TEXT[lv]} for lv in reversed(LEVELS)]}


def dataset(conn, ds_id):
    d = conn.execute(f"""SELECT {DS_COLS}, headers, sample, mapping, proposal, profile, advice, advice_at
                           FROM perm_datasets WHERE id = %s""", (ds_id,)).fetchone()
    if not d:
        raise PermError("That upload is not known (it may have been removed).")
    if d["profile"]:
        d["profile"] = dict(d["profile"], **folder_counts(conn, ds_id))
    d["roles"] = [{"key": k, "label": lab, "required": req} for k, lab, req in ROLES]
    d["kinds"] = [{"key": k, "title": v[0], "about": v[1]} for k, v in KINDS.items()]
    d["reports"] = conn.execute("""SELECT id::text AS id, kind, title, created_by, created_at, summary_state, state,
                                          (result->'kpis'->>'findings')::int AS findings
                                     FROM perm_reports WHERE dataset_id = %s ORDER BY created_at DESC LIMIT 50""", (ds_id,)).fetchall()
    if d["state"] == "ready":
        d["choices"] = {
            "servers": [r["s"] for r in conn.execute("""SELECT DISTINCT server AS s FROM perm_entries WHERE dataset_id = %s
                                                          AND server IS NOT NULL ORDER BY 1 LIMIT 300""", (ds_id,))],
            "applications": [r["a"] for r in conn.execute("""SELECT DISTINCT application AS a FROM perm_folders WHERE dataset_id = %s
                                                               AND application IS NOT NULL ORDER BY 1 LIMIT 500""", (ds_id,))],
            "teams": [r["t"] for r in conn.execute("""SELECT DISTINCT team AS t FROM perm_folders WHERE dataset_id = %s
                                                        AND team IS NOT NULL ORDER BY 1 LIMIT 500""", (ds_id,))],
            "confirmed_only_apps": [r["a"] for r in conn.execute("""SELECT DISTINCT application AS a FROM perm_folders
                                     WHERE dataset_id = %s AND tag_state = 'confirmed' AND application IS NOT NULL ORDER BY 1 LIMIT 500""", (ds_id,))],
        }
    return d


def set_mapping(conn, ds_id, user, mapping, tag_depth):
    """An admin confirms which column is which (and how deep folders are tagged): the rows are made plain again."""
    ds = conn.execute("SELECT state, headers FROM perm_datasets WHERE id = %s FOR UPDATE", (ds_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known.")
    if ds["state"] not in ("mapping", "ready", "failed") or not ds["headers"]:
        raise PermError("The file is still being read: wait a moment." if ds["state"] in ("uploaded", "reading", "normalising")
                        else "The file was not read: upload it again.")
    m = check_mapping(mapping, ds["headers"])
    try:
        tag_depth = int(tag_depth)
    except (TypeError, ValueError):
        raise PermError("The tag depth is a number from 0 to 4.")
    if not 0 <= tag_depth <= 4:
        raise PermError("The tag depth is a number from 0 to 4.")
    conn.execute("""UPDATE perm_datasets SET mapping = %s::jsonb, mapping_by = %s, mapping_at = now(), tag_depth = %s,
                           state = 'normalising', error = NULL, advice = NULL, advice_at = NULL,
                           progress = %s::jsonb, updated_at = now() WHERE id = %s""",
                 (json.dumps(m), user, tag_depth, json.dumps({"step": "normalising", "rows": 0}), ds_id))
    return m


def depth_preview(conn, ds_id, mapping, tag_depth):
    """The folders a depth gives, from the sample and first rows (before anything is saved)."""
    ds = conn.execute("SELECT headers FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()
    if not ds or not ds["headers"]:
        raise PermError("The file is still being read.")
    m = check_mapping(mapping, ds["headers"])
    rows = conn.execute("SELECT cells FROM perm_raw WHERE dataset_id = %s ORDER BY rn LIMIT 5000", (ds_id,)).fetchall()
    out = []
    for d in range(5):
        seen = {}
        for r in rows:
            e = entry_from(r["cells"], m, d)
            if e:
                seen[e["folder_key"]] = e["folder_label"]
        out.append({"depth": d, "folders": len(seen), "examples": sorted(seen.values())[:6]})
    return {"rows_looked_at": len(rows), "depths": out, "chosen": int(tag_depth) if str(tag_depth).isdigit() else 1}


def tags_view(conn, ds_id, state=None, q=None, limit=500):
    """This upload's folders with the tag in force, and the suggestion waiting (biggest first)."""
    where, args = ["f.dataset_id = %s"], [ds_id]
    if state == "suggested":
        where.append("t.state = 'suggested' AND (t.application IS NOT NULL OR t.team IS NOT NULL)")
    elif state == "confirmed":
        where.append("f.tag_state = 'confirmed'")
    elif state == "untagged":
        where.append("f.tag_key IS NULL")
    elif state == "inherited":
        where.append("f.tag_key IS NOT NULL AND f.tag_key <> f.folder_key")
    if q:
        where.append("(f.label ILIKE %s OR f.application ILIKE %s OR f.team ILIKE %s)")
        args += ["%" + q.replace("%", "") + "%"] * 3
    rows = conn.execute(f"""SELECT f.folder_key AS key, f.label, f.server, f.entries, f.paths, f.identities,
                                   f.application, f.team, f.tag_state, f.tag_key,
                                   t.state AS own_state, t.application AS s_application, t.team AS s_team, t.confidence,
                                   t.reason, t.suggested_by, t.decided_by, t.decided_at
                              FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key
                             WHERE {' AND '.join(where)}
                             ORDER BY f.entries DESC, f.folder_key LIMIT %s""", args + [min(int(limit), 2000)]).fetchall()
    c = conn.execute("""SELECT count(*) AS folders, count(*) FILTER (WHERE f.tag_state = 'confirmed') AS confirmed,
                               count(*) FILTER (WHERE t.state = 'suggested' AND (t.application IS NOT NULL OR t.team IS NOT NULL)) AS suggested,
                               count(*) FILTER (WHERE f.tag_key IS NULL) AS untagged,
                               count(*) FILTER (WHERE t.state = 'rejected') AS rejected,
                               count(*) FILTER (WHERE t.key_l IS NULL) AS not_asked
                          FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key WHERE f.dataset_id = %s""",
                     (ds_id,)).fetchone()
    names = conn.execute("""SELECT array(SELECT DISTINCT application FROM perm_tags WHERE state = 'confirmed' AND application IS NOT NULL ORDER BY 1) AS apps,
                                   array(SELECT DISTINCT team FROM perm_tags WHERE state = 'confirmed' AND team IS NOT NULL ORDER BY 1) AS teams""").fetchone()
    st = conn.execute("SELECT tag_ai, tag_ai_note, progress FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone() or {}
    return {"items": rows, "counts": c, "known_applications": names["apps"] or [], "known_teams": names["teams"] or [],
            "tag_ai": st.get("tag_ai"), "tag_ai_note": st.get("tag_ai_note")}


def ask_tags(conn, ds_id, again=False):
    ds = conn.execute("SELECT state FROM perm_datasets WHERE id = %s FOR UPDATE", (ds_id,)).fetchone()
    if not ds:
        raise PermError("That upload is not known.")
    if ds["state"] != "ready":
        raise PermError("Confirm the columns first: AI-01 tags the folders once the rows are ready.")
    if again:     # suggestions nobody decided yet are asked again (confirmed and rejected stay)
        conn.execute("""DELETE FROM perm_tags t USING perm_folders f WHERE f.dataset_id = %s AND t.key_l = f.folder_key
                         AND t.state = 'suggested'""", (ds_id,))
        resolve_tags(conn, ds_id)
    conn.execute("UPDATE perm_datasets SET tag_ai = 'queued', tag_ai_note = NULL WHERE id = %s", (ds_id,))


def report_view(conn, report_id):
    r = conn.execute("""SELECT r.id::text AS id, r.dataset_id::text AS dataset_id, r.kind, r.title, r.spec, r.result, r.summary,
                               r.state, r.error,
                               r.summary_state, r.created_by, r.created_at, d.name AS dataset, d.file_name, d.uploaded_at
                          FROM perm_reports r JOIN perm_datasets d ON d.id = r.dataset_id WHERE r.id = %s""", (report_id,)).fetchone()
    if not r:
        raise PermError("That report is not known.")
    r["kind_title"], r["kind_about"] = KINDS.get(r["kind"], ("", ""))
    return r


# ---- the worker: one pass ---------------------------------------------------------------------------------------

def _json(text):
    """AI-01's answer as JSON (it may wrap it in words or a <think> block)."""
    if isinstance(text, dict):
        return text
    t = re.sub(r"<think>.*?</think>", "", str(text or ""), flags=re.S)
    a, b = t.find("{"), t.rfind("}")
    if a < 0 or b < a:
        raise ValueError("AI-01 gave no JSON")
    return json.loads(t[a:b + 1])


def make_advice(conn, ds_id, ai=None):
    prof = conn.execute("SELECT profile FROM perm_datasets WHERE id = %s", (ds_id,)).fetchone()["profile"] or {}
    rules = rule_advice(prof)
    items, by, note = [], "rules", None
    if ai:
        try:
            got = _json(ai(advice_messages(prof), ADVICE_SCHEMA))
            allowed = numbers_in(prof)
            for it in (got.get("recommended") or [])[:4]:
                k = it.get("report")
                why = grounded(clean_tag_text(it.get("why"), 300), allowed)
                if k in KINDS and k not in {x["report"] for x in items}:
                    items.append({"report": k, "why": why or next((r["why"] for r in rules if r["report"] == k), KINDS[k][1]),
                                  "by": "AI-01"})
            by = "AI-01" if items else "rules"
        except Exception as e:  # noqa: BLE001 - the rules' advice stands alone
            note = "AI-01 did not answer (" + str(e)[:100] + "): recommended by the rules from the counts."
    for r in rules:                                   # the rules fill in what AI-01 left out
        if len(items) >= 4:
            break
        if r["report"] not in {x["report"] for x in items}:
            items.append(r)
    conn.execute("UPDATE perm_datasets SET advice = %s::jsonb, advice_at = now() WHERE id = %s",
                 (json.dumps({"items": items, "by": by, "note": note}), ds_id))
    conn.commit()
    return items


def summarise(conn, report_id, ai):
    r = conn.execute("SELECT title, result FROM perm_reports WHERE id = %s", (report_id,)).fetchone()
    facts = summary_facts(r["title"], r["result"])
    conn.execute("UPDATE perm_reports SET summary_state = 'running' WHERE id = %s", (report_id,))
    conn.commit()
    doc = clean_summary(_json(ai(summary_messages(facts), SUMMARY_SCHEMA)), facts)
    conn.execute("UPDATE perm_reports SET summary = %s::jsonb, summary_state = %s WHERE id = %s",
                 (json.dumps(doc) if doc else None, "done" if doc else "failed", report_id))
    conn.commit()


def _fail(conn, ds_id, msg):
    conn.rollback()
    conn.execute("UPDATE perm_datasets SET state = 'failed', error = %s, progress = NULL, updated_at = now() WHERE id = %s",
                 (str(msg)[:500], ds_id))
    conn.commit()


def run_once(conn, ai_for, stop=lambda: False, background_ok=lambda: True):
    """One pass of everything waiting. ai_for(kind) gives a function (messages, schema) -> dict, or None
    when AI-01 is not configured. Returns what it did (for the heartbeat and the tests)."""
    did = []
    # 1. files uploaded (or cut short while being read): read them, then propose the columns
    for d in conn.execute("SELECT id::text AS id, state FROM perm_datasets WHERE state IN ('uploaded', 'reading') ORDER BY uploaded_at").fetchall():
        if stop():
            return did
        try:
            read_file(conn, d["id"], stop)
        except Exception as e:  # noqa: BLE001
            if stop():
                return did             # left as it is: read again after the restart
            log.warning("access review: reading %s failed: %s", d["id"], e)
            _fail(conn, d["id"], e if isinstance(e, PermError) else
                  "The file could not be read as CSV (" + type(e).__name__ + ": " + str(e)[:160] + ").")
            continue
        did.append(("read", d["id"]))
    for d in conn.execute("SELECT id::text AS id FROM perm_datasets WHERE state = 'mapping' AND proposal IS NULL").fetchall():
        propose(conn, d["id"], ai_for("mapping"))
        did.append(("proposed", d["id"]))
    # 2. columns confirmed: make the rows plain, then recommend reports
    for d in conn.execute("SELECT id::text AS id FROM perm_datasets WHERE state = 'normalising' ORDER BY mapping_at").fetchall():
        if stop():
            return did
        try:
            normalise(conn, d["id"], stop)
        except Exception as e:  # noqa: BLE001
            if stop():
                return did
            log.warning("access review: rows of %s failed: %s", d["id"], e)
            _fail(conn, d["id"], e if isinstance(e, PermError) else "The rows could not be read with these columns (" + str(e)[:160] + ").")
            continue
        did.append(("normalised", d["id"]))
    for d in conn.execute("SELECT id::text AS id FROM perm_datasets WHERE state = 'ready' AND advice IS NULL").fetchall():
        make_advice(conn, d["id"], ai_for("advice"))
        did.append(("advice", d["id"]))
    # 3. tags asked of AI-01: a batch at a time, yielding to people using AI-01
    for d in conn.execute("""SELECT id::text AS id FROM perm_datasets WHERE state = 'ready' AND tag_ai IN ('queued', 'running')
                              ORDER BY updated_at""").fetchall():
        ai = ai_for("tags")
        if not ai:
            conn.execute("UPDATE perm_datasets SET tag_ai = 'failed', tag_ai_note = 'AI-01 is not configured on PATCH-01' WHERE id = %s", (d["id"],))
            conn.commit()
            continue
        conn.execute("UPDATE perm_datasets SET tag_ai = 'running' WHERE id = %s", (d["id"],))
        conn.commit()
        fails = batches = 0
        while not stop() and background_ok() and batches < 5:      # then the others get a turn; the next pass goes on
            batches += 1
            if conn.execute("SELECT tag_ai FROM perm_datasets WHERE id = %s", (d["id"],)).fetchone()["tag_ai"] != "running":
                break                                                # an admin pressed Stop
            try:
                n = suggest_batch(conn, d["id"], lambda msgs, sch: _json(ai(msgs, sch)))
            except Exception as e:  # noqa: BLE001 - AI-01 busy or slow: try again next pass, give up after 3 in a row
                conn.rollback()
                fails += 1
                log.info("access review: tag batch failed: %s", e)
                if fails >= 3:
                    conn.execute("UPDATE perm_datasets SET tag_ai = 'failed', tag_ai_note = %s WHERE id = %s",
                                 ("AI-01 did not answer three times (" + str(e)[:120] + "). Ask again later.", d["id"]))
                    conn.commit()
                    break
                continue
            fails = 0
            if not n:
                left = conn.execute("""SELECT count(*) FILTER (WHERE t.application IS NOT NULL OR t.team IS NOT NULL) AS s
                                         FROM perm_folders f JOIN perm_tags t ON t.key_l = f.folder_key
                                        WHERE f.dataset_id = %s AND t.state = 'suggested'""", (d["id"],)).fetchone()["s"]
                conn.execute("""UPDATE perm_datasets SET tag_ai = 'done', tag_ai_note = %s,
                                       profile = %s::jsonb WHERE id = %s""",
                             (f"{left} suggestions are waiting for your decision", json.dumps(profile(conn, d["id"])), d["id"]))
                conn.commit()
                did.append(("tagged", d["id"]))
                break
            c = conn.execute("""SELECT count(*) AS n, count(t.key_l) AS asked FROM perm_folders f LEFT JOIN perm_tags t ON t.key_l = f.folder_key
                                 WHERE f.dataset_id = %s""", (d["id"],)).fetchone()
            conn.execute("UPDATE perm_datasets SET tag_ai_note = %s WHERE id = %s AND tag_ai = 'running'",
                         (f"AI-01 has looked at {c['asked']} of {c['n']} folders (biggest first)", d["id"]))
            conn.commit()
            did.append(("tag_batch", d["id"]))
    # 4. reports asked for: count them, then AI-01's summary
    for r in conn.execute("SELECT id::text AS id FROM perm_reports WHERE state IN ('queued', 'computing') ORDER BY created_at").fetchall():
        if stop():
            return did
        try:
            build_report(conn, r["id"])
            did.append(("report", r["id"]))
        except Exception as e:  # noqa: BLE001
            log.warning("access review: report %s failed: %s", r["id"], e)
            conn.rollback()
            conn.execute("UPDATE perm_reports SET state = 'failed', error = %s, summary_state = 'off' WHERE id = %s",
                         ("The figures could not be counted (" + type(e).__name__ + ": " + str(e)[:160] + ").", r["id"]))
            conn.commit()
    for r in conn.execute("""SELECT id::text AS id FROM perm_reports WHERE state = 'ready' AND summary_state IN ('queued', 'running')
                              ORDER BY created_at""").fetchall():
        if stop() or not background_ok():
            break
        ai = ai_for("summary")
        if not ai:
            conn.execute("UPDATE perm_reports SET summary_state = 'off' WHERE id = %s", (r["id"],))
            conn.commit()
            continue
        try:
            summarise(conn, r["id"], ai)
            did.append(("summary", r["id"]))
        except Exception as e:  # noqa: BLE001
            conn.rollback()
            log.info("access review: summary failed: %s", e)
            conn.execute("UPDATE perm_reports SET summary_state = 'failed' WHERE id = %s", (r["id"],))
            conn.commit()
    return did
