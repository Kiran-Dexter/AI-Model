"""
PATCH-01 : VMware vCenter inventory (read-only)

Reads every configured vCenter, records its VMs and their snapshots, and
links each VM to the PATCH-01 server running inside it.

Read-only by construction: this module calls no method that changes a VM.
It only retrieves properties. Snapshot creation arrives with patch jobs, in
separate code, and needs extra vCenter permissions the read-only account
does not have.

Configuration: one pair of files per vCenter in /etc/vcenter (mounted
read-only from /patch/secrets/vcenter):

    <name>.env   VC_HOST, VC_PORT, VC_USER, VC_PASSWORD_B64
    <name>.crt   the certificate chain vCenter presented, pinned at setup

Run inside the API image, on the patchnet network:
    python -m app.vmware --list
    python -m app.vmware --test NAME
    python -m app.vmware --sync [NAME]
"""

import argparse
import base64
import glob
import json
import logging
import os
import re
import socket
import ssl
import sys
import time
from datetime import datetime, timezone

log = logging.getLogger("patchapi.vmware")

CONFIG_DIR = os.environ.get("VCENTER_CONFIG_DIR", "/etc/vcenter")
BATCH = 500
NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,39}$")

LINUX_HINTS = ("linux", "red hat", "rhel", "centos", "oracle", "ubuntu",
               "debian", "suse", "rocky", "alma")

VM_PROPS = [
    "name", "config.uuid", "config.instanceUuid", "config.template",
    "config.guestFullName", "config.hardware.numCPU", "config.hardware.memoryMB",
    "runtime.powerState", "runtime.host",
    "guest.hostName", "guest.ipAddress", "guest.net", "guest.guestFamily",
    "guest.toolsRunningStatus", "guest.toolsVersionStatus2",
    "snapshot",
]


# ---------------------------------------------------------------------------
# Pure functions: no network, no pyVmomi. These decide correctness.
# ---------------------------------------------------------------------------

def norm_uuid(u):
    """Canonical lowercase 8-4-4-4-12 form, or None if it is not a UUID."""
    if not u:
        return None
    h = re.sub(r"[^0-9a-fA-F]", "", str(u)).lower()
    if len(h) != 32 or h == "0" * 32 or h == "f" * 32:
        return None
    return f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"


def swap_uuid(u):
    """The same UUID with its first three fields byte-reversed.

    SMBIOS stores the first three fields little-endian, and not every layer
    agrees on whether to swap them back. So the UUID a Linux guest reads can
    be the byte-swapped form of the one vCenter reports. Matching accepts
    either, which is safe: the two forms of one UUID cannot collide with a
    different machine's UUID except by the same chance as any UUID clash.
    """
    n = norm_uuid(u)
    if not n:
        return None
    a, b, c, d, e = n.split("-")
    rev = lambda x: "".join(reversed([x[i:i + 2] for i in range(0, len(x), 2)]))
    return f"{rev(a)}-{rev(b)}-{rev(c)}-{d}-{e}"


def uuid_forms(u):
    n = norm_uuid(u)
    return {x for x in (n, swap_uuid(n)) if x}


def is_linux_guest(family, full_name):
    if (family or "").lower() == "linuxguest":
        return True
    fn = (full_name or "").lower()
    return any(h in fn for h in LINUX_HINTS) and "windows" not in fn


def short_name(n):
    return (n or "").strip().lower().split(".")[0] or None


def flatten_snapshots(info):
    """Turn vCenter's snapshot tree into a flat list, oldest first.

    Works on anything shaped like pyVmomi's VirtualMachineSnapshotInfo,
    which is what makes it testable without a vCenter.
    """
    out = []
    if not info:
        return out
    cur = getattr(getattr(info, "currentSnapshot", None), "_moId", None)

    def walk(nodes, depth):
        for s in nodes or []:
            ref = getattr(getattr(s, "snapshot", None), "_moId", None)
            created = getattr(s, "createTime", None)
            out.append({
                "name": (getattr(s, "name", "") or "")[:200],
                "description": (getattr(s, "description", "") or "")[:500],
                "created": created.isoformat() if created else None,
                "moref": ref,
                "current": ref is not None and ref == cur,
                "depth": depth,
                "quiesced": bool(getattr(s, "quiesced", False)),
            })
            walk(getattr(s, "childSnapshotList", None), depth + 1)

    walk(getattr(info, "rootSnapshotList", None), 0)
    out.sort(key=lambda x: x["created"] or "")
    return out


def match_vms(vms, hosts):
    """Link VMs to PATCH-01 servers. Returns {vm_key: (host_id, method)}.

    Order of trust: hardware UUID, then guest hostname, then IP address.
    A hardware UUID shared by several VMs (a clone that kept its UUID) is
    treated as ambiguous rather than guessed, unless the hostname settles it.
    """
    by_uuid, by_name, by_ip = {}, {}, {}
    for h in hosts:
        for f in uuid_forms(h.get("hardware_uuid")):
            by_uuid.setdefault(f, []).append(h)
        n = short_name(h.get("hostname"))
        if n:
            by_name.setdefault(n, []).append(h)
        if h.get("agent_ip"):
            by_ip.setdefault(str(h["agent_ip"]), []).append(h)

    # How many VMs claim each UUID, to detect clones
    uuid_claims = {}
    for v in vms:
        for f in uuid_forms(v.get("bios_uuid")):
            uuid_claims[f] = uuid_claims.get(f, 0) + 1

    result = {}
    for v in vms:
        key = v["key"]
        cands = []
        for f in uuid_forms(v.get("bios_uuid")):
            cands.extend(by_uuid.get(f, []))
        cands = list({c["id"]: c for c in cands}.values())
        vname = short_name(v.get("guest_hostname")) or short_name(v.get("name"))

        if len(cands) == 1:
            clones = max((uuid_claims.get(f, 0) for f in uuid_forms(v.get("bios_uuid"))), default=0)
            if clones > 1:
                # Several VMs share this UUID; only accept if the name agrees
                if vname and short_name(cands[0]["hostname"]) == vname:
                    result[key] = (cands[0]["id"], "hardware_uuid+hostname")
                else:
                    result[key] = (None, "ambiguous")
            else:
                result[key] = (cands[0]["id"], "hardware_uuid")
            continue
        if len(cands) > 1:
            named = [c for c in cands if short_name(c["hostname"]) == vname]
            result[key] = (named[0]["id"], "hardware_uuid+hostname") if len(named) == 1 \
                else (None, "ambiguous")
            continue

        # No UUID match: fall back, but only on a unique hit
        if vname and len(by_name.get(vname, [])) == 1:
            result[key] = (by_name[vname][0]["id"], "hostname")
            continue
        ip_hits = {c["id"]: c for ip in (v.get("guest_ips") or []) for c in by_ip.get(ip, [])}
        if len(ip_hits) == 1:
            result[key] = (next(iter(ip_hits)), "ip")
            continue
        result[key] = (None, None)
    return result


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

def _read_env(path):
    out = {}
    with open(path) as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            out[k.strip()] = v.strip()
    return out


def load_vcenters():
    vcs = []
    for env in sorted(glob.glob(os.path.join(CONFIG_DIR, "*.env"))):
        name = os.path.basename(env)[:-4]
        if not NAME_RE.match(name):
            log.warning("skipping %s: invalid name", env)
            continue
        e = _read_env(env)
        try:
            pw = base64.b64decode(e.get("VC_PASSWORD_B64", "")).decode()
        except Exception:
            pw = ""
        vcs.append({
            "name": name,
            "host": e.get("VC_HOST", ""),
            "port": int(e.get("VC_PORT", "443") or 443),
            "user": e.get("VC_USER", ""),
            "password": pw,
            "cert": os.path.join(CONFIG_DIR, name + ".crt"),
        })
    return vcs


def ssl_context(certfile):
    """Trust only the certificate chain pinned at setup.

    PARTIAL_CHAIN lets a pinned leaf or intermediate act as the trust anchor,
    so pinning works whether vCenter presents its whole chain or only its own
    certificate. The hostname is still checked.
    """
    if not os.path.exists(certfile):
        raise RuntimeError(f"no pinned certificate at {certfile}")
    ctx = ssl.create_default_context(cafile=certfile)
    ctx.verify_flags |= ssl.VERIFY_X509_PARTIAL_CHAIN
    return ctx


# ---------------------------------------------------------------------------
# vCenter access
# ---------------------------------------------------------------------------

def connect(vc):
    from pyVim.connect import SmartConnect
    socket.setdefaulttimeout(60)
    return SmartConnect(host=vc["host"], user=vc["user"], pwd=vc["password"],
                        port=vc["port"], sslContext=ssl_context(vc["cert"]),
                        connectionPoolTimeout=60)


def disconnect(si):
    try:
        from pyVim.connect import Disconnect
        Disconnect(si)
    except Exception:  # noqa: BLE001
        pass


def collect(si, vimtype, props):
    """Fetch one set of properties for every object of a type, in batches.

    A single PropertyCollector pass rather than walking objects one by one,
    so thousands of VMs cost a handful of round trips.
    """
    from pyVmomi import vim, vmodl
    content = si.RetrieveContent()
    view = content.viewManager.CreateContainerView(content.rootFolder, [vimtype], True)
    try:
        ts = vmodl.query.PropertyCollector.TraversalSpec(
            name="traverse", path="view", skip=False, type=vim.view.ContainerView)
        obj = vmodl.query.PropertyCollector.ObjectSpec(obj=view, skip=True, selectSet=[ts])
        prop = vmodl.query.PropertyCollector.PropertySpec(type=vimtype, pathSet=props, all=False)
        spec = vmodl.query.PropertyCollector.FilterSpec(objectSet=[obj], propSet=[prop])
        pc = content.propertyCollector
        res = pc.RetrievePropertiesEx([spec], vmodl.query.PropertyCollector.RetrieveOptions(maxObjects=BATCH))
        out = []
        while res:
            for o in res.objects or []:
                out.append((o.obj, {p.name: p.val for p in (o.propSet or [])}))
            if not res.token:
                break
            res = pc.ContinueRetrievePropertiesEx(res.token)
        return out
    finally:
        view.Destroy()


def fetch_inventory(si):
    """Every VM with its placement, guest facts and snapshots."""
    from pyVmomi import vim

    # Placement: host -> cluster -> datacenter, resolved through parents
    nodes = {}
    for t in (vim.HostSystem, vim.ClusterComputeResource, vim.ComputeResource,
              vim.Folder, vim.Datacenter):
        props = ["name"] if t is vim.Datacenter else ["name", "parent"]
        for o, d in collect(si, t, props):
            nodes[o._moId] = {"type": type(o).__name__, "name": d.get("name"),
                              "parent": getattr(d.get("parent"), "_moId", None)}

    def ancestor(moid, typenames):
        seen = 0
        while moid and seen < 50:
            n = nodes.get(moid)
            if not n:
                return None
            if any(t in n["type"] for t in typenames):
                return n["name"]
            moid = n["parent"]
            seen += 1
        return None

    vms = []
    for o, d in collect(si, vim.VirtualMachine, VM_PROPS):
        if d.get("config.template"):
            continue
        host_moid = getattr(d.get("runtime.host"), "_moId", None)
        ips = set()
        if d.get("guest.ipAddress"):
            ips.add(d["guest.ipAddress"])
        for nic in d.get("guest.net") or []:
            for ip in getattr(nic, "ipAddress", None) or []:
                if ip and ":" not in ip and not ip.startswith("169.254."):
                    ips.add(ip)
        snaps = flatten_snapshots(d.get("snapshot"))
        vms.append({
            "key": o._moId,
            "moref": o._moId,
            "name": d.get("name"),
            "bios_uuid": norm_uuid(d.get("config.uuid")),
            "instance_uuid": norm_uuid(d.get("config.instanceUuid")),
            "power_state": str(d.get("runtime.powerState") or ""),
            "guest_os": d.get("config.guestFullName"),
            "guest_family": d.get("guest.guestFamily"),
            "is_linux": is_linux_guest(d.get("guest.guestFamily"), d.get("config.guestFullName")),
            "guest_hostname": d.get("guest.hostName"),
            "guest_ips": sorted(ips),
            "tools_running": d.get("guest.toolsRunningStatus"),
            "tools_version_status": d.get("guest.toolsVersionStatus2"),
            "esxi_host": nodes.get(host_moid, {}).get("name"),
            "cluster": ancestor(host_moid, ("ClusterComputeResource",)),
            "datacenter": ancestor(host_moid, ("Datacenter",)),
            "num_cpu": d.get("config.hardware.numCPU"),
            "memory_mb": d.get("config.hardware.memoryMB"),
            "snapshots": snaps,
            "snapshot_count": len(snaps),
            "oldest_snapshot_at": snaps[0]["created"] if snaps else None,
        })
    return vms


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

def _db():
    import psycopg
    from psycopg.rows import dict_row
    return psycopg.connect(
        host=os.environ.get("PATCHDB_HOST", "postgres"),
        port=int(os.environ.get("PATCHDB_PORT", "5432")),
        dbname=os.environ.get("PATCHDB_NAME", "patchdb"),
        user=os.environ.get("PATCHDB_USER", "patchapi"),
        password=os.environ.get("PATCHDB_PASSWORD", ""),
        row_factory=dict_row, connect_timeout=15,
    )


def sync_one(conn, vc):
    started = time.time()
    conn.execute(
        """INSERT INTO vcenters (name, host) VALUES (%s,%s)
           ON CONFLICT (name) DO UPDATE SET host=EXCLUDED.host, updated_at=now()""",
        (vc["name"], vc["host"]))
    sync_id = conn.execute(
        "INSERT INTO vcenter_syncs (vcenter) VALUES (%s) RETURNING id",
        (vc["name"],)).fetchone()["id"]
    conn.commit()

    si = None
    try:
        si = connect(vc)
        about = si.content.about
        version = f"{about.version} build {about.build}"
        vms = fetch_inventory(si)
    except Exception as e:  # noqa: BLE001 - recorded per vCenter
        msg = str(e).replace(vc["password"], "***") if vc["password"] else str(e)
        conn.execute(
            """UPDATE vcenter_syncs SET finished_at=now(), ok=FALSE, error=%s,
                      duration_ms=%s WHERE id=%s""",
            (msg[:1000], int((time.time() - started) * 1000), sync_id))
        conn.execute(
            """UPDATE vcenters SET last_sync_at=now(), last_ok=FALSE, last_error=%s,
                      updated_at=now() WHERE name=%s""",
            (msg[:1000], vc["name"]))
        conn.commit()
        return {"vcenter": vc["name"], "ok": False, "error": msg[:300]}
    finally:
        if si:
            disconnect(si)

    hosts = conn.execute(
        """SELECT id, hostname, hardware_uuid, host(agent_ip) AS agent_ip
             FROM hosts WHERE status <> 'decommissioned'""").fetchall()
    links = match_vms(vms, hosts)

    rows = []
    for v in vms:
        hid, method = links.get(v["key"], (None, None))
        rows.append((vc["name"], v["moref"], v["name"], v["bios_uuid"], v["instance_uuid"],
                     v["power_state"], v["guest_os"], v["guest_family"], v["is_linux"],
                     v["guest_hostname"], v["guest_ips"], v["tools_running"],
                     v["tools_version_status"], v["esxi_host"], v["cluster"], v["datacenter"],
                     v["num_cpu"], v["memory_mb"], v["snapshot_count"], v["oldest_snapshot_at"],
                     json.dumps(v["snapshots"]), hid, method))

    with conn.transaction():
        with conn.cursor() as cur:
            cur.executemany(
                """INSERT INTO vm_inventory
                     (vcenter, moref, name, bios_uuid, instance_uuid, power_state,
                      guest_os, guest_family, is_linux, guest_hostname, guest_ips,
                      tools_running, tools_version_status, esxi_host, cluster,
                      datacenter, num_cpu, memory_mb, snapshot_count,
                      oldest_snapshot_at, snapshots, host_id, match_method, synced_at)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,now())
                   ON CONFLICT (vcenter, moref) DO UPDATE SET
                     name=EXCLUDED.name, bios_uuid=EXCLUDED.bios_uuid,
                     instance_uuid=EXCLUDED.instance_uuid, power_state=EXCLUDED.power_state,
                     guest_os=EXCLUDED.guest_os, guest_family=EXCLUDED.guest_family,
                     is_linux=EXCLUDED.is_linux, guest_hostname=EXCLUDED.guest_hostname,
                     guest_ips=EXCLUDED.guest_ips, tools_running=EXCLUDED.tools_running,
                     tools_version_status=EXCLUDED.tools_version_status,
                     esxi_host=EXCLUDED.esxi_host, cluster=EXCLUDED.cluster,
                     datacenter=EXCLUDED.datacenter, num_cpu=EXCLUDED.num_cpu,
                     memory_mb=EXCLUDED.memory_mb, snapshot_count=EXCLUDED.snapshot_count,
                     oldest_snapshot_at=EXCLUDED.oldest_snapshot_at,
                     snapshots=EXCLUDED.snapshots, host_id=EXCLUDED.host_id,
                     match_method=EXCLUDED.match_method, synced_at=now()""",
                rows)
        # VMs gone from this vCenter since the last sync
        seen = [v["moref"] for v in vms]
        conn.execute("DELETE FROM vm_inventory WHERE vcenter=%s AND NOT (moref = ANY(%s))",
                     (vc["name"], seen))
        linux = sum(1 for v in vms if v["is_linux"])
        matched = sum(1 for k, (hid, _) in links.items() if hid)
        conn.execute(
            """UPDATE vcenter_syncs SET finished_at=now(), ok=TRUE, vms=%s, linux_vms=%s,
                      matched=%s, duration_ms=%s WHERE id=%s""",
            (len(vms), linux, matched, int((time.time() - started) * 1000), sync_id))
        conn.execute(
            """UPDATE vcenters SET last_sync_at=now(), last_ok=TRUE, last_error=NULL,
                      vm_count=%s, version=%s, updated_at=now() WHERE name=%s""",
            (len(vms), version, vc["name"]))
    return {"vcenter": vc["name"], "ok": True, "version": version, "vms": len(vms),
            "linux": linux, "matched": matched,
            "seconds": round(time.time() - started, 1)}


def sync(only=None):
    vcs = [v for v in load_vcenters() if not only or v["name"] == only]
    if not vcs:
        print("no vCenters configured" + (f" named {only}" if only else ""))
        return False
    ok = True
    with _db() as conn:
        for vc in vcs:
            # One vCenter failing never stops the others
            r = sync_one(conn, vc)
            ok = ok and r["ok"]
            print(json.dumps(r))
    return ok


def test(name):
    vc = next((v for v in load_vcenters() if v["name"] == name), None)
    if not vc:
        print(json.dumps({"ok": False, "error": f"no vCenter named {name}"}))
        return False
    si = None
    try:
        si = connect(vc)
        a = si.content.about
        from pyVmomi import vim
        n = len(collect(si, vim.VirtualMachine, ["name"]))
        print(json.dumps({"ok": True, "vcenter": name, "product": a.fullName,
                          "version": a.version, "build": a.build, "vms_visible": n,
                          "tls": "verified against pinned certificate"}))
        return True
    except ssl.SSLCertVerificationError as e:
        print(json.dumps({"ok": False, "error": f"certificate does not match the pin: {e}"}))
    except Exception as e:  # noqa: BLE001
        msg = str(e).replace(vc["password"], "***") if vc["password"] else str(e)
        print(json.dumps({"ok": False, "error": msg[:400]}))
    finally:
        if si:
            disconnect(si)
    return False


def main():
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--test", metavar="NAME")
    ap.add_argument("--sync", nargs="?", const="", metavar="NAME")
    a = ap.parse_args()
    if a.list:
        for v in load_vcenters():
            print(json.dumps({"name": v["name"], "host": v["host"], "user": v["user"],
                              "pinned": os.path.exists(v["cert"])}))
        return
    if a.test:
        sys.exit(0 if test(a.test) else 1)
    if a.sync is not None:
        sys.exit(0 if sync(a.sync or None) else 1)
    ap.print_help()


if __name__ == "__main__":
    main()
