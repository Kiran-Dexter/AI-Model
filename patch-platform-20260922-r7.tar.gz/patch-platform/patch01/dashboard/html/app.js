/* PATCH-01 console
 *
 * No framework and no build step: this is served on an air-gapped network.
 *
 * Every value from the API is inserted as text, never as HTML. Advisory
 * titles come from vendor feeds and hostnames from agents, so none of it is
 * trusted. The h() helper below only ever uses textContent.
 */
"use strict";

/* ---- state labels, in the words an operator uses ------------------------ */

const STATES = {
  affected:             { label: "Needs patch",    desc: "Installed version is older than the fix" },
  fixed_pending_reboot: { label: "Needs reboot",   desc: "Fix installed, old version still running" },
  fixed_active:         { label: "Patched",        desc: "Fix installed and running" },
  unknown:              { label: "No recent data", desc: "Host has not reported in 24 hours" },
};
const STATE_ORDER = ["affected", "fixed_pending_reboot", "fixed_active", "unknown"];

const HOST_STATUS = {
  active: "Reporting",
  stale: "Silent",
  pending: "Enrolled, no data yet",
  decommissioned: "Retired",
};

const AGENT_STATES = {
  online:        { label: "Online",        desc: "Checked in recently" },
  offline:       { label: "Offline",       desc: "Missed several check-ins" },
  not_reporting: { label: "Not reporting", desc: "Silent for over 24 hours; its verdicts are unknown" },
  no_data:       { label: "No data yet",   desc: "Enrolled but never checked in" },
};
const AGENT_ORDER = ["online", "offline", "not_reporting", "no_data"];

function agentMark(state) {
  const a = AGENT_STATES[state] || { label: state || "unknown" };
  return h("span", { class: "agent ag-" + (state || "unknown") }, a.label);
}

function fmtUptime(sec) {
  if (sec === null || sec === undefined || sec === "") return h("span", { class: "muted" }, "not reported");
  const s = Number(sec);
  if (s < 3600) return Math.max(1, Math.round(s / 60)) + " min";
  if (s < 86400) {
    const hrs = Math.floor(s / 3600), m = Math.round((s % 3600) / 60);
    return hrs + " h" + (m ? " " + m + " min" : "");
  }
  const d = Math.floor(s / 86400), hrs = Math.round((s % 86400) / 3600);
  return d + (d === 1 ? " day" : " days") + (hrs ? " " + hrs + " h" : "");
}

/* ---- DOM helper: text only, never innerHTML ----------------------------- */

function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v === null || v === undefined || v === false) continue;
      if (k === "class") el.className = v;
      else if (k === "on") for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
      else if (k === "style") for (const [p, val] of Object.entries(v)) el.style.setProperty(p, val);
      else el.setAttribute(k, v === true ? "" : String(v));
    }
  }
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}

/* ---- formatting --------------------------------------------------------- */

function timeAgo(iso) {
  if (!iso) return "never";
  const t = new Date(iso).getTime();
  if (isNaN(t)) return "unknown";
  const s = Math.round((Date.now() - t) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return Math.round(s / 60) + " min ago";
  if (s < 86400) return Math.round(s / 3600) + " h ago";
  return Math.round(s / 86400) + " days ago";
}

function fmtDateTime(iso) {
  if (!iso) return "never";
  const d = new Date(iso);
  if (isNaN(d)) return String(iso);
  return d.toLocaleString(undefined, {
    year: "numeric", month: "short", day: "numeric",
    hour: "2-digit", minute: "2-digit",
  });
}

function fmtDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d)) return String(iso);
  return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function osLabel(osId, ver) {
  const names = { rhel: "RHEL", ol: "Oracle Linux", ubuntu: "Ubuntu" };
  return (names[osId] || osId || "") + (ver ? " " + ver : "");
}

function count(n, state) {
  const v = Number(n) || 0;
  return h("span", { class: "count " + (v === 0 ? "zero" : "st-" + state) }, v);
}

/* A host that has stopped reporting has no trustworthy counts. Showing 0
   would read as "clean", which is the exact failure the unknown state
   exists to prevent. */
function hostCount(r, field, state) {
  if (r.host_status === "stale") return h("span", { class: "count unknown-val" }, "unknown");
  return count(r[field], state);
}

function stateMark(state) {
  const s = STATES[state] || { label: state };
  return h("span", { class: "state st-" + state }, s.label);
}

function sevLabel(sev) {
  if (!sev) return h("span", { class: "muted" }, "unrated");
  return h("span", { class: "sev sev-" + sev }, sev.charAt(0).toUpperCase() + sev.slice(1));
}

/* ---- auth --------------------------------------------------------------- */

const AUTH_KEY = "patch01.auth";

function getAuth() {
  try { return JSON.parse(sessionStorage.getItem(AUTH_KEY)); } catch (e) { return null; }
}
function setAuth(user, pass) {
  sessionStorage.setItem(AUTH_KEY, JSON.stringify({ user, token: btoa(user + ":" + pass) }));
}
function clearAuth() { sessionStorage.removeItem(AUTH_KEY); }

class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

async function api(path) {
  const auth = getAuth();
  const res = await fetch("/api/v1" + path, {
    headers: {
      "Accept": "application/json",
      "X-Requested-With": "patch01-dashboard",
      ...(auth ? { "Authorization": "Basic " + auth.token } : {}),
    },
    cache: "no-store",
  });
  if (res.status === 401) {
    clearAuth();
    throw new ApiError(401, "Your session has ended. Sign in again.");
  }
  if (!res.ok) {
    let detail = "";
    try { detail = (await res.json()).detail || ""; } catch (e) { /* not JSON */ }
    throw new ApiError(res.status, detail || res.statusText);
  }
  return res.json();
}

async function apiPost(path, body) {
  const auth = getAuth();
  const res = await fetch("/api/v1" + path, {
    method: "POST",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "X-Requested-With": "patch01-dashboard",
      ...(auth ? { "Authorization": "Basic " + auth.token } : {}),
    },
    body: JSON.stringify(body || {}),
    cache: "no-store",
  });
  if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
  if (!res.ok) {
    let detail = "";
    try { detail = (await res.json()).detail || ""; } catch (e) { /* not JSON */ }
    throw new ApiError(res.status, detail || res.statusText);
  }
  return res.json();
}

/* ---- explanations from AI-01 --------------------------------------------- */

const EXPLAINABLE = new Set(["affected", "fixed_pending_reboot"]);

function explainError(err) {
  if (err.status === 429) return "AI-01 is busy with another explanation. Try again in a moment.";
  if (err.status === 503) return "AI-01 is not available: " + (err.message || "not configured or unreachable") + ".";
  if (err.status === 404) return "This verdict no longer exists. Refresh the page.";
  return "Could not get an explanation (HTTP " + (err.status || "error") + ").";
}

async function toggleExplain(btn, hostId, advisoryId, colspan) {
  const tr = btn.closest("tr");
  const next = tr.nextElementSibling;
  if (next && next.classList.contains("explain-row")) {
    next.remove();
    btn.setAttribute("aria-expanded", "false");
    btn.textContent = "Explain";
    return;
  }
  const body = h("div", { class: "explain", role: "status" },
    h("p", { class: "explain-wait" }, "Asking AI-01. On a CPU-only server this can take up to a minute."));
  const row = h("tr", { class: "explain-row" }, h("td", { colspan: String(colspan) }, body));
  tr.after(row);
  btn.setAttribute("aria-expanded", "true");
  btn.textContent = "Hide";
  btn.disabled = true;
  try {
    const r = await apiPost("/admin/hosts/" + encodeURIComponent(hostId) +
                            "/advisories/" + encodeURIComponent(advisoryId) + "/explain");
    const meta = r.cached
      ? "From cache"
      : "Generated in " + Math.round((r.duration_ms || 0) / 1000) + "s";
    body.replaceChildren(
      h("p", { class: "explain-note" },
        "AI explanation, advisory only. The verdict comes from the version check, not the model."),
      // Plain text only: the model's output is never treated as HTML
      h("p", { class: "explain-text" }, r.text),
      h("p", { class: "explain-meta" }, meta + (r.model ? ", " + r.model : "")),
    );
  } catch (err) {
    if (err.status === 401) return renderSignIn(err.message);
    body.replaceChildren(h("p", { class: "explain-error" }, explainError(err)));
  } finally {
    btn.disabled = false;
  }
}

/* ---- rendering scaffolding ---------------------------------------------- */

const view = () => document.getElementById("view");

function render(...nodes) {
  const v = view();
  // replaceChildren would turn null into the text "null"
  v.replaceChildren(...nodes.flat().filter(n => n !== null && n !== undefined && n !== false));
  v.focus({ preventScroll: true });
}

function showError(err) {
  if (err.status === 401) return renderSignIn(err.message);
  const hints = {
    502: ["The API container is not answering. Check it with ", h("code", null, "./scripts/phase3b-api.sh --check"), "."],
    503: ["The API is up but cannot reach the database. Check ", h("code", null, "./scripts/phase1b-data.sh --check"), "."],
    404: ["This endpoint does not exist. The API image may be older than the dashboard; rebuild it with ", h("code", null, "./scripts/phase3b-api.sh"), "."],
  };
  render(
    h("div", { class: "error", role: "alert" },
      h("h2", null, "Could not load this page"),
      h("p", null, "The API returned HTTP " + (err.status || "error") + (err.message ? ": " + err.message : ".")),
      hints[err.status] ? h("p", null, hints[err.status]) : null,
    )
  );
}

function setNav(name) {
  document.querySelectorAll("nav a").forEach(a => {
    if (a.dataset.nav === name) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
  });
}

function table(columns, rows, opts = {}) {
  const thead = h("thead", null, h("tr", null,
    columns.map(c => h("th", { class: c.num ? "num" : null, scope: "col" }, c.label))));
  const tbody = h("tbody", null, rows.map(r => {
    const tr = h("tr", { class: opts.onRow ? "clickable" : null },
      columns.map(c => h("td", { class: [c.num ? "num" : "", c.mono ? "mono" : "",
                                         c.nowrap ? "nowrap" : ""].join(" ").trim() || null },
        c.cell(r))));
    if (opts.onRow) {
      tr.addEventListener("click", e => {
        if (e.target.closest("a")) return;
        opts.onRow(r);
      });
    }
    return tr;
  }));
  return h("div", { class: "table-wrap" }, h("table", null, thead, tbody));
}

/* ---- theme picker ------------------------------------------------------- */

function fillThemeSelect(sel) {
  const T = window.PatchTheme;
  if (!T) return sel;
  sel.replaceChildren(...T.options.map(([v, label]) => h("option", { value: v }, label)));
  sel.value = T.get();
  sel.addEventListener("change", () => {
    T.set(sel.value);
    // keep any other picker on the page in step
    document.querySelectorAll("select[data-theme-select]").forEach(o => { o.value = sel.value; });
  });
  sel.setAttribute("data-theme-select", "");
  return sel;
}

function themePicker() {
  const sel = fillThemeSelect(h("select", { "aria-label": "Theme" }));
  return h("label", { class: "theme-pick" }, h("span", null, "Theme"), sel);
}

/* ---- sign in ------------------------------------------------------------ */

function renderSignIn(message) {
  document.getElementById("top").hidden = true;
  const fab = document.getElementById("chat-open");
  if (fab) fab.hidden = true;
  const cp = document.getElementById("chat");
  if (cp) cp.hidden = true;
  const err = message ? h("div", { class: "error", role: "alert" }, message) : null;
  const user = h("input", { type: "text", name: "user", autocomplete: "username", required: true, value: "admin" });
  const pass = h("input", { type: "password", name: "pass", autocomplete: "current-password", required: true });
  const btn = h("button", { type: "submit" }, "Sign in");

  const form = h("form", {
    class: "signin",
    on: {
      submit: async e => {
        e.preventDefault();
        btn.disabled = true;
        btn.textContent = "Signing in";
        setAuth(user.value.trim(), pass.value);
        try {
          await api("/admin/fleet-summary");
          start();
        } catch (ex) {
          clearAuth();
          renderSignIn(ex.status === 401
            ? "That username and password were not accepted."
            : "Could not reach the API (HTTP " + (ex.status || "error") + ").");
        }
      },
    },
  },
    themePicker(),
    h("h1", { "data-cmd": "patchctl login" }, "PATCH-01"),
    h("p", { class: "muted" }, "Patch and vulnerability status for your Linux fleet."),
    err,
    h("label", null, h("span", null, "Username"), user),
    h("label", null, h("span", null, "Password"), pass),
    btn,
    h("p", { class: "muted small" },
      "Use the admin password from ", h("code", null, "/patch/secrets/api.env"), " on PATCH-01."),
  );
  view().replaceChildren(form);
  pass.focus();
}

/* ---- overview ----------------------------------------------------------- */

async function renderOverview() {
  setNav("overview");
  const [fleet, app, comp] = await Promise.all([
    api("/admin/fleet-summary"),
    api("/admin/applicability/summary"),
    api("/admin/compliance"),
  ]);

  const t = fleet.totals || {};
  if (!t.hosts) {
    return render(
      h("div", { class: "page-head" }, h("h1", { "data-cmd": "patchctl status" }, "Overview")),
      h("div", { class: "empty" },
        h("h2", null, "No servers have enrolled yet"),
        h("p", null, "Issue a token on PATCH-01 with ", h("code", null, "./scripts/phase3b-api.sh --token"),
          ", then run ", h("code", null, "install-agent.sh"), " on a server with that token."),
      )
    );
  }

  // The exposure strip
  const byState = {};
  (app.by_state || []).forEach(r => { byState[r.state] = r; });
  const total = STATE_ORDER.reduce((a, s) => a + (byState[s] ? Number(byState[s].n) : 0), 0);

  const segs = STATE_ORDER.map(s =>
    h("span", { class: "st-" + s + (byState[s] && Number(byState[s].n) ? " nonzero" : ""), title: STATES[s].label + ": " + (byState[s] ? byState[s].n : 0),
                style: { "flex-grow": "0" }, "data-grow": byState[s] ? byState[s].n : 0 }));
  const strip = h("div", { class: "strip", role: "img",
    "aria-label": STATE_ORDER.map(s => STATES[s].label + " " + (byState[s] ? byState[s].n : 0)).join(", ") },
    segs);

  const legend = h("div", { class: "legend" }, STATE_ORDER.map(s => {
    const r = byState[s];
    const hosts = r ? Number(r.hosts) : 0;
    return h("a", { class: "st-" + s, href: "#/advisories?state=" + s },
      h("span", { class: "n" }, r ? r.n : 0),
      h("span", { class: "l" }, STATES[s].label),
      h("span", { class: "d" }, hosts === 1 ? "on 1 server" : "on " + hosts + " servers"));
  }));

  const exposure = h("section", { class: "exposure", "aria-labelledby": "exp-h" },
    h("div", { class: "page-head" },
      h("h1", { id: "exp-h", "data-cmd": "patchctl exposure --fleet" }, "Fleet exposure"),
      h("span", { class: "muted small" },
        total ? "Checked " + timeAgo(app.computed_at) : "The CVE engine has not run yet")),
    total ? strip : h("div", { class: "empty" },
      h("p", null, "No verdicts yet. Run ", h("code", null, "./scripts/phase4-cve.sh"), " on PATCH-01.")),
    total ? legend : null,
  );

  // Grow the strip once, after it is in the document
  requestAnimationFrame(() => requestAnimationFrame(() => {
    segs.forEach(sg => { sg.style.flexGrow = sg.dataset.grow; });
  }));

  const attention = (comp.hosts || [])
    .filter(r => Number(r.affected) || Number(r.pending_reboot) || r.host_status === "stale")
    .slice(0, 10);

  const attnSection = h("section", null,
    h("h2", null, "Servers needing attention"),
    attention.length ? table([
      { label: "Server", cell: r => h("a", { href: "#/host/" + r.host_id }, r.hostname) },
      { label: "OS", cell: r => osLabel(r.os_id, r.os_version) },
      { label: "Needs patch", num: true, cell: r => hostCount(r, "affected", "affected") },
      { label: "Needs reboot", num: true, cell: r => hostCount(r, "pending_reboot", "fixed_pending_reboot") },
      { label: "Last report", cell: r => h("span", { class: r.host_status === "stale" ? "host-silent" : null },
          timeAgo(r.last_checkin)) },
    ], attention, { onRow: r => { location.hash = "#/host/" + r.host_id; } })
    : h("div", { class: "empty" }, h("p", null, "Every reporting server is fully patched.")),
  );

  const top = (app.top_affected || []).slice(0, 8);
  const advSection = h("section", null,
    h("h2", null, "Most urgent advisories"),
    top.length ? table([
      { label: "Advisory", nowrap: true, cell: r => h("a", { href: "#/advisories?state=affected" }, r.advisory_id) },
      { label: "Severity", cell: r => sevLabel(r.severity) },
      { label: "Servers", num: true, cell: r => count(r.hosts_affected, "affected") },
    ], top)
    : h("div", { class: "empty" }, h("p", null, "No outstanding advisories.")),
  );

  const osTable = h("section", null,
    h("h2", null, "Fleet by operating system"),
    table([
      { label: "OS", cell: r => osLabel(r.os_id, r.os_major) },
      { label: "Status", cell: r => HOST_STATUS[r.status] || r.status },
      { label: "Servers", num: true, cell: r => r.hosts },
      { label: "Awaiting reboot", num: true, cell: r => count(r.awaiting_reboot, "fixed_pending_reboot") },
    ], fleet.by_os || []),
  );

  const ag = {};
  (comp.hosts || []).forEach(r => { ag[r.agent_state] = (ag[r.agent_state] || 0) + 1; });
  const agentLine = h("a", { class: "agent-line", href: "#/agents" },
    AGENT_ORDER.filter(s => ag[s]).map(s =>
      h("span", { class: "agent-count" }, agentMark(s), " ", h("strong", null, ag[s]))));

  render(agentLine, exposure, h("div", { class: "two-col" }, attnSection, advSection), osTable);
}

/* ---- hosts -------------------------------------------------------------- */

async function renderHosts(params) {
  setNav("hosts");
  const comp = await api("/admin/compliance");
  const all = comp.hosts || [];
  let q = params.get("q") || "";
  let filter = params.get("show") || "all";

  const body = h("div");
  const search = h("input", { type: "search", placeholder: "Filter by server name", value: q,
    "aria-label": "Filter by server name" });

  const filters = [
    ["all", "All servers"],
    ["attention", "Needs attention"],
    ["silent", "Silent"],
  ];
  const btns = filters.map(([k, label]) =>
    h("button", { type: "button", "aria-pressed": String(k === filter), "data-k": k }, label));

  function draw() {
    const needle = q.toLowerCase();
    const rows = all.filter(r => {
      if (needle && !r.hostname.toLowerCase().includes(needle)) return false;
      if (filter === "attention") return Number(r.affected) || Number(r.pending_reboot);
      if (filter === "silent") return r.host_status === "stale";
      return true;
    });
    btns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === filter)));
    body.replaceChildren(rows.length ? table([
      { label: "Server", cell: r => h("a", { href: "#/host/" + r.host_id }, r.hostname) },
      { label: "OS", cell: r => osLabel(r.os_id, r.os_version) },
      { label: "Agent", nowrap: true, cell: r => agentMark(r.agent_state) },
      { label: "Running kernel", mono: true, cell: r => r.kernel_running || "" },
      { label: "Needs patch", num: true, cell: r => hostCount(r, "affected", "affected") },
      { label: "Needs reboot", num: true, cell: r => hostCount(r, "pending_reboot", "fixed_pending_reboot") },
      { label: "Patched", num: true, cell: r => r.host_status === "stale" ? h("span", { class: "count unknown-val" }, "unknown") : r.remediated },
      { label: "Last report", cell: r => timeAgo(r.last_checkin) },
    ], rows, { onRow: r => { location.hash = "#/host/" + r.host_id; } })
    : h("div", { class: "empty" }, h("p", null,
        all.length ? "No servers match this filter." : "No servers have enrolled yet.")));
  }

  search.addEventListener("input", () => { q = search.value; draw(); });
  btns.forEach(b => b.addEventListener("click", () => { filter = b.dataset.k; draw(); }));

  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl servers ls" }, "Servers"),
      h("span", { class: "muted small" }, all.length + (all.length === 1 ? " server" : " servers"))),
    h("div", { class: "controls" }, search, h("div", { class: "filters", role: "group", "aria-label": "Show" }, btns)),
    body,
  );
  draw();
}

/* ---- host detail -------------------------------------------------------- */
/*
 * Two panes: the advisory list on the left stays still, and the selected
 * advisory's details and explanation open on the right. Nothing in the list
 * moves when an explanation loads. On narrow screens the panel becomes a
 * sheet over the bottom of the page.
 */

const explainCache = new Map();   // advisory id -> result, for this page view

function wideScreen() { return window.matchMedia("(min-width: 1100px)").matches; }

async function renderHost(id, params) {
  setNav("hosts");
  const [detail, advs, vmres] = await Promise.all([
    api("/admin/hosts/" + encodeURIComponent(id)),
    api("/admin/hosts/" + encodeURIComponent(id) + "/advisories"),
    api("/admin/hosts/" + encodeURIComponent(id) + "/vm").catch(() => null),
  ]);
  const host = detail.host;
  const rows = advs.advisories || [];
  const vm = vmres && vmres.vm;
  const oldDays = (vmres && vmres.snapshot_old_days) || 7;
  explainCache.clear();

  const counts = {};
  rows.forEach(r => { counts[r.state] = (counts[r.state] || 0) + 1; });
  let show = params.get("state") || (counts.affected ? "affected"
    : counts.fixed_pending_reboot ? "fixed_pending_reboot" : "all");
  let selected = null;

  /* -- summary line: the four facts that matter, reboot folded in -------- */
  const stale = host.status === "stale";
  const kernelDiffers = host.kernel_latest && host.kernel_running &&
    !host.kernel_running.startsWith(host.kernel_latest.replace(/\.(x86_64|aarch64)$/, ""));
  const summary = h("div", { class: "host-summary" },
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "OS"),
      osLabel(host.os_id, host.os_version) + " " + (host.arch || "")),
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Running"),
      h("span", { class: "mono" }, host.kernel_running || "unknown")),
    h("span", { class: "hs-item" + (stale ? " host-silent" : "") }, h("span", { class: "hs-k" }, "Reported"),
      timeAgo(host.last_checkin)),
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Up"),
      host.boot_time ? fmtUptime((Date.now() - new Date(host.boot_time).getTime()) / 1000) : fmtUptime(null)),
    h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "Packages"), detail.package_count),
    vm ? h("span", { class: "hs-item" }, h("span", { class: "hs-k" }, "VM"),
           h("a", { href: "#/vmware?view=linux" }, vm.name),
           vm.cluster ? h("span", { class: "muted" }, " on " + vm.cluster) : null) : null,
  );

  const alerts = [];
  if (host.reboot_required) {
    alerts.push(h("div", { class: "hs-alert st-fixed_pending_reboot" },
      h("strong", null, "Needs reboot"),
      kernelDiffers
        ? h("span", null, " to run the installed kernel ", h("span", { class: "mono" }, host.kernel_latest))
        : h("span", null, host.reboot_reason ? ": " + host.reboot_reason : ""),
    ));
  }
  if (vm && vm.snapshot_count > 0) {
    const age = daysSince(vm.oldest_snapshot_at);
    const oldOnes = age !== null && age >= oldDays;
    alerts.push(h("div", { class: "hs-alert " + (oldOnes ? "vm-alert-old" : "vm-alert") },
      h("strong", null, vm.snapshot_count + (vm.snapshot_count === 1 ? " VM snapshot" : " VM snapshots")),
      h("span", null, ", oldest " + ageLabel(age) +
        (oldOnes ? ". Old snapshots grow and slow the VM; remove them in vCenter once they are no longer needed." : ".")),
    ));
  }
  if (stale) {
    alerts.push(h("div", { class: "hs-alert st-unknown" },
      h("strong", null, "Not reporting"),
      h("span", null, " since " + fmtDateTime(host.last_checkin) +
        ". Verdicts are shown as no recent data until it checks in."),
    ));
  }

  const more = h("details", { class: "host-more" },
    h("summary", null, "Details"),
    h("dl", { class: "facts" }, [
      ["Newest installed kernel", h("span", { class: "mono" }, host.kernel_latest || "unknown")],
      ["Last report", fmtDateTime(host.last_checkin)],
      ["Last inventory", fmtDateTime(host.last_inventory)],
      ["Status", HOST_STATUS[host.status] || host.status],
      ["Host group", host.host_group || "default"],
      ["Agent", host.agent_version || "unknown"],
      ["Enrolled", fmtDate(host.enrolled_at)],
    ].concat(vm ? [
      ["vCenter", vm.vcenter],
      ["ESXi host", vm.esxi_host || "unknown"],
      ["Cluster", vm.cluster || "none"],
      ["VM size", (vm.num_cpu || "?") + " vCPU, " + (vm.memory_mb ? Math.round(vm.memory_mb / 1024) + " GB" : "?")],
      ["VMware Tools", vm.tools_running === "guestToolsRunning" ? "Running" : (vm.tools_running || "unknown")],
      ["Linked by", MATCH_LABEL[vm.match_method] || vm.match_method || "unknown"],
    ] : []).map(([k, v]) => h("div", null, h("dt", null, k), h("dd", null, v)))),
  );

  /* -- filters ------------------------------------------------------------- */
  const filterDefs = [["all", "All (" + rows.length + ")", null]].concat(
    STATE_ORDER.filter(s => counts[s]).map(s => [s, STATES[s].label + " (" + counts[s] + ")", s]));
  const btns = filterDefs.map(([k, label, st]) =>
    h("button", { type: "button", class: st ? "st-" + st : null, "data-k": k,
                  "aria-pressed": String(k === show) }, label));

  /* -- list and panel ------------------------------------------------------ */
  const listBox = h("div", { class: "pane-list" });
  const panel = h("aside", { class: "pane-detail", "aria-live": "polite", "aria-label": "Selected advisory" });
  const sheetClose = () => { panel.classList.remove("open"); document.body.classList.remove("sheet-open"); };

  function cveList(r) {
    const c = r.cves || [];
    if (!c.length) return h("span", { class: "muted" }, "none");
    return c[0] + (c.length > 1 ? " +" + (c.length - 1) : "");
  }

  function drawPanel() {
    if (!selected) {
      panel.replaceChildren(h("p", { class: "pane-empty" },
        rows.length ? "Select an advisory to see its details and an explanation."
                    : "No advisories apply to this server."));
      return;
    }
    const r = selected;
    const cached = explainCache.get(r.advisory_id);
    const explainBox = h("div", { class: "pd-explain" });

    const fill = res => {
      explainBox.replaceChildren(
        h("p", { class: "explain-note" }, "AI explanation, advisory only. The verdict comes from the version check."),
        h("p", { class: "explain-text" }, res.text),
        h("p", { class: "explain-meta" },
          (res.cached ? "From cache" : "Generated in " + Math.round((res.duration_ms || 0) / 1000) + "s") +
          (res.model ? ", " + res.model : "")));
    };

    if (cached) fill(cached);
    else if (EXPLAINABLE.has(r.state)) {
      const b = h("button", { type: "button", class: "explain-btn" }, "Explain with AI-01");
      b.addEventListener("click", async () => {
        b.disabled = true;
        explainBox.replaceChildren(h("p", { class: "explain-wait" },
          "Asking AI-01. On a CPU-only server this can take up to a minute."));
        try {
          const res = await apiPost("/admin/hosts/" + encodeURIComponent(id) +
                                    "/advisories/" + encodeURIComponent(r.advisory_id) + "/explain");
          explainCache.set(r.advisory_id, res);
          if (selected === r) fill(res);
        } catch (err) {
          if (err.status === 401) return renderSignIn(err.message);
          explainBox.replaceChildren(h("p", { class: "explain-error" }, explainError(err)), b);
          b.disabled = false;
        }
      });
      explainBox.replaceChildren(b);
    }

    const cveBox = h("div", { class: "pd-cvedetail" });
    if ((r.cves || []).length) {
      const btn = h("button", { type: "button", class: "explain-btn" },
        "CVE details (" + r.cves.length + ")");
      btn.addEventListener("click", async () => {
        btn.disabled = true;
        cveBox.replaceChildren(h("p", { class: "muted" }, "Loading"));
        try {
          const res = await api("/admin/advisories/" + encodeURIComponent(r.advisory_id) + "/cves");
          const items = (res.cves || []).map(cveBlock);
          cveBox.replaceChildren(h("h3", { class: "pd-sub" }, "Published CVE data"), ...items);
        } catch (err) {
          if (err.status === 401) return renderSignIn(err.message);
          cveBox.replaceChildren(h("p", { class: "explain-error" },
            err.status === 404 ? "The API is older than this feature; rebuild it."
                               : "Could not load CVE data (HTTP " + err.status + ")."));
          btn.disabled = false;
        }
      });
      cveBox.replaceChildren(btn);
    }

    panel.replaceChildren(
      h("div", { class: "pd-head" },
        h("h2", null, r.advisory_id),
        h("button", { type: "button", class: "pd-close", "aria-label": "Close", on: { click: sheetClose } }, "Close")),
      h("div", { class: "pd-badges" }, stateMark(r.state), sevLabel(r.severity)),
      r.title ? h("p", { class: "pd-title" }, r.title) : null,
      h("dl", { class: "pd-facts" },
        h("div", null, h("dt", null, "Package"), h("dd", null, r.package_name)),
        h("div", null, h("dt", null, "Installed"),
          h("dd", { class: "mono" + (r.state === "affected" ? " ver-old" : "") }, r.installed_evr)),
        h("div", null, h("dt", null, "Fixed in"),
          h("dd", { class: "mono" + (r.state === "affected" ? " ver-new" : "") }, r.fixed_evr)),
        h("div", null, h("dt", null, "CVEs"),
          // Each ID is unbreakable; lines wrap only between IDs. A browser
          // otherwise breaks at the hyphens inside CVE-2026-31338.
          h("dd", { class: "pd-cves" }, (r.cves || []).length
            ? (r.cves || []).flatMap((c, i) => [i ? ", " : null, h("span", { class: "cve" }, c)])
            : "none listed")),
        r.max_cvss !== null && r.max_cvss !== undefined
          ? h("div", null, h("dt", null, "Worst CVSS"),
              h("dd", null, cvssCell(r.max_cvss), r.any_kev ? " " : null,
                r.any_kev ? kevBadge() : null)) : null,
        r.reason ? h("div", null, h("dt", null, "Why"), h("dd", null, r.reason)) : null,
      ),
      cveBox,
      explainBox,
    );
  }

  function select(r, tr) {
    selected = r;
    listBox.querySelectorAll("tr.selected").forEach(x => x.classList.remove("selected"));
    if (tr) tr.classList.add("selected");
    drawPanel();
    if (!wideScreen()) {
      panel.classList.add("open");
      document.body.classList.add("sheet-open");
    }
  }

  function draw() {
    btns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === show)));
    const list = show === "all" ? rows : rows.filter(r => r.state === show);
    if (!list.length) {
      listBox.replaceChildren(h("div", { class: "empty" }, h("p", null,
        rows.length ? "Nothing in this category." :
        "No advisories apply to this server yet. If it has just enrolled, run ./scripts/phase4-cve.sh --compute on PATCH-01.")));
      return;
    }
    const tbl = table([
      { label: "State", nowrap: true, cell: r => stateMark(r.state) },
      { label: "Advisory", nowrap: true, cell: r => [r.advisory_id, r.any_kev ? " " : null,
          r.any_kev ? kevBadge() : null] },
      // CVSS replaces the vendor severity here: it carries more information
      // and the vendor rating is shown in the panel.
      { label: "CVSS", num: true, nowrap: true, cell: r => cvssCell(r.max_cvss) },
      { label: "Package", nowrap: true, cell: r => r.package_name },
      { label: "Installed", mono: true, cell: r =>
          h("span", { class: r.state === "affected" ? "ver-old" : null }, r.installed_evr) },
      { label: "Fixed in", mono: true, cell: r =>
          h("span", { class: r.state === "affected" ? "ver-new" : null }, r.fixed_evr) },
    ], list, { onRow: r => {} });   // CVEs are listed in full in the panel
    // Row selection needs the <tr>, so wire it here rather than via onRow
    tbl.querySelectorAll("tbody tr").forEach((tr, i) => {
      const r = list[i];
      tr.tabIndex = 0;
      tr.setAttribute("aria-label", r.advisory_id + ", " + (STATES[r.state] || {}).label);
      const pick = () => select(r, tr);
      tr.addEventListener("click", pick);
      tr.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); pick(); } });
      if (selected && selected.advisory_id === r.advisory_id) tr.classList.add("selected");
    });
    listBox.replaceChildren(tbl);

    // On a wide screen, open the first item so the panel is never idle
    if (wideScreen() && (!selected || !list.includes(selected))) {
      select(list[0], tbl.querySelector("tbody tr"));
    }
  }
  btns.forEach(b => b.addEventListener("click", () => { show = b.dataset.k; draw(); }));

  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl host show " + host.hostname }, host.hostname),
      h("a", { href: "#/hosts", class: "small" }, "All servers")),
    summary,
    alerts,
    more,
    h("div", { class: "controls" }, h("div", { class: "filters", role: "group", "aria-label": "Show" }, btns)),
    h("div", { class: "panes" }, listBox, panel),
  );
  draw();
  drawPanel();
}

/* ---- agents ------------------------------------------------------------- */

async function renderAgents(params) {
  setNav("agents");
  const res = await api("/admin/agents");
  const all = res.agents || [];
  const by = res.by_state || {};
  let show = params.get("state") || "all";

  const tiles = h("div", { class: "agent-tiles" }, AGENT_ORDER.map(s =>
    h("button", { type: "button", class: "agent-tile ag-" + s, "data-k": s,
                  "aria-pressed": String(show === s) },
      h("span", { class: "at-n" }, by[s] || 0),
      h("span", { class: "at-l" }, AGENT_STATES[s].label),
      h("span", { class: "at-d" }, AGENT_STATES[s].desc))));

  // Agents older than 1.1.0 do not report boot time
  const old = all.filter(r => !r.agent_version || r.agent_version < "1.1.0").length;
  const verLine = h("p", { class: "muted small" },
    "Agent versions: " + (res.versions || []).map(v => v.version + " on " + v.n).join(", ") +
    ". Online means a check-in within the last " + res.online_minutes + " minutes.");
  const notice = old ? h("div", { class: "hs-alert st-unknown" },
    h("strong", null, old + (old === 1 ? " server runs" : " servers run") + " an agent older than 1.1.0"),
    h("span", null, ", which does not report uptime. Re-run install-agent.sh on them to update.")) : null;

  const body = h("div");
  const tileBtns = tiles.querySelectorAll("button");
  function draw() {
    tileBtns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === show)));
    const rows = show === "all" ? all : all.filter(r => r.agent_state === show);
    body.replaceChildren(rows.length ? table([
      { label: "Server", nowrap: true, cell: r => h("a", { href: "#/host/" + r.host_id }, r.hostname) },
      { label: "Agent", nowrap: true, cell: r => agentMark(r.agent_state) },
      { label: "Last seen", nowrap: true, cell: r => timeAgo(r.last_checkin) },
      { label: "Uptime", nowrap: true, cell: r => fmtUptime(r.uptime_seconds) },
      { label: "Booted", nowrap: true, cell: r => r.boot_time ? fmtDateTime(r.boot_time) : "" },
      { label: "Version", nowrap: true, cell: r => r.agent_version || "unknown" },
      { label: "Address", mono: true, cell: r => r.agent_ip || "" },
      { label: "OS", nowrap: true, cell: r => osLabel(r.os_id, r.os_version) },
    ], rows, { onRow: r => { location.hash = "#/host/" + r.host_id; } })
    : h("div", { class: "empty" }, h("p", null,
        all.length ? "No agents in this state." : "No servers have enrolled yet.")));
  }
  tileBtns.forEach(b => b.addEventListener("click", () => {
    show = (show === b.dataset.k) ? "all" : b.dataset.k;   // click again to clear
    draw();
  }));

  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl agents status" }, "Agents"),
      h("span", { class: "muted small" }, all.length + (all.length === 1 ? " agent" : " agents"))),
    tiles, verLine, notice, body,
  );
  draw();
}

/* ---- CVE facts ---------------------------------------------------------- */

const AV_WORDS = { NETWORK: "over the network", ADJACENT_NETWORK: "from the local network",
                   LOCAL: "local access", PHYSICAL: "physical access" };
const PR_WORDS = { NONE: "no login", LOW: "user login", HIGH: "admin login" };

function cvssCell(score, severity) {
  if (score === null || score === undefined) return h("span", { class: "muted" }, "-");
  return h("span", { class: "cvss", title: (severity || "").toLowerCase() }, Number(score).toFixed(1));
}

/* "Exploited" is deliberately not red or amber: those mean patch states.
   High-contrast inverse type makes it stand out without borrowing a meaning. */
function kevBadge(extra) {
  return h("span", { class: "kev", title: "Listed in CISA's Known Exploited Vulnerabilities catalogue" },
    "Exploited" + (extra ? " " + extra : ""));
}

function pctLabel(e) {
  if (e === null || e === undefined) return null;
  const v = Number(e) * 100;
  return v >= 10 ? Math.round(v) + "%" : v >= 1 ? v.toFixed(1) + "%" : "<1%";
}

function reachLine(c) {
  const bits = [];
  if (c.attack_vector) bits.push(AV_WORDS[c.attack_vector] || c.attack_vector.toLowerCase());
  if (c.privileges_required) bits.push(PR_WORDS[c.privileges_required] || c.privileges_required.toLowerCase());
  if ((c.user_interaction || "") === "REQUIRED") bits.push("needs a user action");
  if (c.attack_complexity) bits.push((c.attack_complexity || "").toLowerCase() + " complexity");
  return bits.join(", ");
}

function cveBlock(c) {
  if (!c.nvd_fetched_at && !c.cvss_score) {
    return h("div", { class: "cve-item" },
      h("div", { class: "cve-head" }, h("span", { class: "cve-id" }, c.cve_id)),
      h("p", { class: "muted small" }, c.fetch_error
        ? "No published data: " + c.fetch_error
        : "Published data not collected yet. Run ./scripts/phase4-cve.sh --intel on PATCH-01."));
  }
  const pct = pctLabel(c.epss);
  return h("div", { class: "cve-item" },
    h("div", { class: "cve-head" },
      h("span", { class: "cve-id" }, c.cve_id),
      cvssCell(c.cvss_score, c.cvss_severity),
      c.kev ? kevBadge(c.kev_ransomware === "Known" ? "and used in ransomware" : "") : null),
    c.attack_class ? h("p", { class: "cve-class" }, c.attack_class) : null,
    reachLine(c) ? h("p", { class: "cve-reach" }, reachLine(c)) : null,
    pct ? h("p", { class: "cve-epss" }, pct + " chance of exploitation in the next 30 days") : null,
    c.description ? h("p", { class: "cve-desc" }, c.description) : null,
    h("p", { class: "cve-src" },
      [c.cvss_version ? "CVSS " + c.cvss_version : null,
       c.cvss_source ? "scored by " + c.cvss_source : null,
       c.rh_severity ? "Red Hat: " + c.rh_severity : null,
       c.attack_class_basis ? "attack type from " + c.attack_class_basis : null,
      ].filter(Boolean).join(" | ")),
  );
}

/* ---- CVE assessment ----------------------------------------------------- */

const ASSESS_STATUS = {
  affected:       { label: "Needs patch",    desc: "At least one server needs the fix" },
  pending_reboot: { label: "Needs reboot",   desc: "Installed everywhere, a reboot is due" },
  patched:        { label: "Patched",        desc: "Every server with the package is fixed" },
  unknown:        { label: "Unknown",        desc: "Only servers with stale inventory involved" },
  not_applicable: { label: "Not applicable", desc: "We hold an advisory, but no server has the package" },
  no_vendor_data: { label: "Cannot assess",  desc: "No advisory in the mirrors mentions this CVE" },
};
const ASSESS_ORDER = ["affected", "pending_reboot", "unknown", "no_vendor_data",
                      "patched", "not_applicable"];

function assessMark(st) {
  const a = ASSESS_STATUS[st] || { label: st };
  const cls = { affected: "st-affected", pending_reboot: "st-fixed_pending_reboot",
                patched: "st-fixed_active", unknown: "st-unknown" }[st] || "st-plain";
  return h("span", { class: "state " + cls, title: (ASSESS_STATUS[st] || {}).desc || "" }, a.label);
}

async function downloadCsv(id, name) {
  const auth = getAuth();
  const res = await fetch("/api/v1/admin/assessments/" + encodeURIComponent(id) + "/export.csv", {
    headers: { "X-Requested-With": "patch01-dashboard",
               ...(auth ? { Authorization: "Basic " + auth.token } : {}) },
  });
  if (!res.ok) throw new ApiError(res.status, res.statusText);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = h("a", { href: url, download: (name || "assessment").replace(/[^A-Za-z0-9_-]+/g, "-") + ".csv" });
  document.body.append(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}

function assessResult(res) {
  const s = res.summary || {};
  const by = s.by_status || {};
  const tiles = h("div", { class: "agent-tiles" }, ASSESS_ORDER.filter(k => by[k]).map(k =>
    h("div", { class: "agent-tile" },
      h("span", { class: "at-n" }, by[k]),
      h("span", { class: "at-l" }, ASSESS_STATUS[k].label),
      h("span", { class: "at-d" }, ASSESS_STATUS[k].desc))));

  const lead = h("p", null,
    s.cves + " CVEs assessed against " + res.hosts_in_scope + " servers. ",
    h("strong", null, s.cves_needing_action + " need action"),
    " on " + s.servers_needing_action + (s.servers_needing_action === 1 ? " server" : " servers") + ".",
    s.exploited_and_affected
      ? h("span", null, " ", kevBadge(), " " + s.exploited_and_affected +
          " of them are exploited in the wild.")
      : null);

  const body = h("div");
  let show = "affected";
  const filters = ASSESS_ORDER.filter(k => by[k]).map(k =>
    h("button", { type: "button", "data-k": k, "aria-pressed": String(k === show) },
      ASSESS_STATUS[k].label + " (" + by[k] + ")"));
  if (!by[show]) show = (ASSESS_ORDER.filter(k => by[k])[0] || "affected");

  function draw() {
    filters.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === show)));
    const rows = (res.items || []).filter(i => i.status === show);
    body.replaceChildren(rows.length ? table([
      { label: "CVE", nowrap: true, mono: true, cell: i => i.cve_id },
      { label: "CVSS", num: true, nowrap: true, cell: i => cvssCell(i.cvss_score) },
      { label: "", nowrap: true, cell: i => i.kev ? kevBadge() : "" },
      { label: "Attack type", cell: i => i.attack_class || "" },
      { label: "Servers", num: true, nowrap: true, cell: i =>
          i.status === "affected" ? i.affected
          : i.status === "pending_reboot" ? i.pending_reboot
          : i.status === "patched" ? i.patched : i.unknown || 0 },
      { label: "Packages", cell: i => (i.packages || []).slice(0, 3).join(", ") },
      { label: "Affected servers", cell: i => (i.affected_hosts || [])
          .filter(x => x.state === "affected").slice(0, 6).map(x => x.hostname).join(", ")
          + ((i.affected_hosts || []).filter(x => x.state === "affected").length > 6 ? " and more" : "") },
    ], rows) : h("div", { class: "empty" }, h("p", null, "Nothing in this category.")));
  }
  filters.forEach(b => b.addEventListener("click", () => { show = b.dataset.k; draw(); }));

  const out = h("div", null,
    h("div", { class: "page-head" },
      h("h2", null, "Result: " + res.name),
      h("button", { type: "button", class: "quiet",
                    on: { click: () => downloadCsv(res.id, res.name).catch(e => alert("Export failed")) } },
        "Export CSV")),
    lead, tiles,
    res.rejected && res.rejected.length
      ? h("p", { class: "muted small" },
          "Not understood in the input: " + res.rejected.join(" | ")) : null,
    h("div", { class: "controls" }, h("div", { class: "filters", role: "group", "aria-label": "Show" }, filters)),
    body);
  draw();
  return out;
}

async function renderAssess(params) {
  setNav("assess");
  const list = await api("/admin/assessments");
  const resultBox = h("div");

  const name = h("input", { type: "text", required: true, placeholder: "SOC bulletin, September" });
  const source = h("input", { type: "text", placeholder: "SOC, auditor, vendor notice" });
  const textarea = h("textarea", { rows: "6", placeholder:
    "Paste the CVE list here, in any format:\nCVE-2026-31337, CVE-2026-31338\nCVE-2026-29001" });
  const fileIn = h("input", { type: "file", accept: ".txt,.csv,.text,text/plain,text/csv" });
  const submit = h("button", { type: "submit" }, "Assess");
  const err = h("p", { class: "explain-error", hidden: true });

  const form = h("form", { class: "assess-form", on: { submit: async e => {
    e.preventDefault();
    err.hidden = true;
    if (!name.value.trim()) { err.textContent = "Give the assessment a name."; err.hidden = false; return; }
    if (!textarea.value.trim() && !fileIn.files.length) {
      err.textContent = "Paste a CVE list or choose a file."; err.hidden = false; return;
    }
    submit.disabled = true; submit.textContent = "Assessing";
    const fd = new FormData();
    fd.append("name", name.value.trim());
    if (source.value.trim()) fd.append("source", source.value.trim());
    if (textarea.value.trim()) fd.append("text", textarea.value);
    if (fileIn.files.length) fd.append("file", fileIn.files[0]);
    try {
      const auth = getAuth();
      const res = await fetch("/api/v1/admin/assessments", {
        method: "POST",
        headers: { "X-Requested-With": "patch01-dashboard",
                   ...(auth ? { Authorization: "Basic " + auth.token } : {}) },
        body: fd,
      });
      if (res.status === 401) { clearAuth(); return renderSignIn("Your session has ended."); }
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new ApiError(res.status, data.detail || res.statusText);
      resultBox.replaceChildren(assessResult({ ...data, name: name.value.trim() }));
      resultBox.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (ex) {
      err.textContent = ex.message || "Assessment failed.";
      err.hidden = false;
    } finally {
      submit.disabled = false; submit.textContent = "Assess";
    }
  } } },
    h("div", { class: "af-row" },
      h("label", null, h("span", null, "Name"), name),
      h("label", null, h("span", null, "Where it came from"), source)),
    h("label", null, h("span", null, "CVE list"), textarea),
    h("label", null, h("span", null, "or upload a file"), fileIn,
      h("span", { class: "muted small" },
        "Text or CSV. Save a spreadsheet as CSV, or paste the column in above.")),
    err, submit);

  const past = (list.assessments || []);
  const history = h("section", null,
    h("h2", null, "Previous assessments"),
    past.length ? table([
      { label: "Name", cell: a => h("a", { href: "#/assess?id=" + a.id }, a.name) },
      { label: "From", nowrap: true, cell: a => a.source || "" },
      { label: "When", nowrap: true, cell: a => fmtDateTime(a.created_at) },
      { label: "CVEs", num: true, cell: a => a.cve_count },
      { label: "Needs patch", num: true, cell: a => count(a.affected, "affected") },
      { label: "Exploited", num: true, cell: a => a.exploited_affected
          ? h("span", null, a.exploited_affected, " ", kevBadge()) : "0" },
      { label: "Cannot assess", num: true, cell: a => a.no_vendor_data },
      { label: "By", nowrap: true, cell: a => a.created_by },
    ], past, { onRow: a => { location.hash = "#/assess?id=" + a.id; } })
      : h("div", { class: "empty" }, h("p", null, "No assessment has been run yet.")));

  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl assess --cve-list" }, "Assess a CVE list"),
      h("span", { class: "muted small" }, "For lists from a SOC, an auditor or a vendor")),
    h("p", { class: "muted" },
      "Paste or upload a list of CVEs. Each one is checked against the fleet's "
      + "installed packages, using verdicts already computed by the CVE engine."),
    form, resultBox, history);

  // Opening a saved assessment
  const id = params.get("id");
  if (id) {
    try {
      const d = await api("/admin/assessments/" + encodeURIComponent(id));
      const a = d.assessment || {};
      const items = (d.items || []).map(i => ({ ...i }));
      const by = {};
      items.forEach(i => { by[i.status] = (by[i.status] || 0) + 1; });
      const servers = new Set();
      items.forEach(i => (i.affected_hosts || []).forEach(x => {
        if (x.state === "affected" || x.state === "fixed_pending_reboot") servers.add(x.hostname);
      }));
      resultBox.replaceChildren(assessResult({
        id: a.id, name: a.name, hosts_in_scope: a.hosts_in_scope, rejected: a.rejected,
        items,
        summary: { by_status: by, cves: items.length,
                   cves_needing_action: (by.affected || 0) + (by.pending_reboot || 0),
                   servers_needing_action: servers.size,
                   exploited_and_affected: items.filter(i => i.kev && i.status === "affected").length },
      }));
    } catch (e) { /* the list above still shows */ }
  }
}

/* ---- VMware ------------------------------------------------------------- */

const MATCH_LABEL = {
  "hardware_uuid": "Hardware ID",
  "hardware_uuid+hostname": "Hardware ID and hostname",
  "hostname": "Hostname only",
  "ip": "IP address only",
  "ambiguous": "Ambiguous",
};

function daysSince(iso) {
  if (!iso) return null;
  const t = new Date(iso).getTime();
  return isNaN(t) ? null : Math.floor((Date.now() - t) / 86400000);
}
function ageLabel(d) {
  if (d === null) return "unknown";
  if (d < 1) return "today";
  return d === 1 ? "1 day" : d + " days";
}

const POWER = { poweredOn: "On", poweredOff: "Off", suspended: "Suspended" };

async function renderVmware(params) {
  setNav("vmware");
  let res;
  try { res = await api("/admin/vmware/summary"); }
  catch (e) {
    if (e.status === 404) {
      return render(h("div", { class: "page-head" }, h("h1", null, "VMware")),
        h("div", { class: "empty" }, h("p", null,
          "The API is older than the VMware integration. Rebuild it with ",
          h("code", null, "./scripts/phase3b-api.sh"), ".")));
    }
    throw e;
  }
  const vcs = res.vcenters || [];
  const c = res.counts || {};
  const oldDays = res.snapshot_old_days || 7;

  const head = h("div", { class: "page-head" },
    h("h1", { "data-cmd": "patchctl vmware status" }, "VMware"),
    h("span", { class: "muted small" },
      vcs.length + (vcs.length === 1 ? " vCenter" : " vCenters") + ", " + (c.vms || 0) + " VMs"));

  if (!vcs.length) {
    return render(head, h("div", { class: "empty" },
      h("h2", null, "No vCenter is configured"),
      h("p", null, "On PATCH-01, add one with ",
        h("code", null, "./scripts/phase7-vmware.sh --add <name> --host <vcenter address>"),
        ", then run ", h("code", null, "--sync"), ".")));
  }

  const vcCards = h("div", { class: "vc-cards" }, vcs.map(v =>
    h("div", { class: "vc-card" + (v.last_ok === false ? " vc-failed" : "") },
      h("div", { class: "vc-name" }, v.name),
      h("div", { class: "muted small" }, v.host),
      h("div", { class: "small" }, v.version || ""),
      v.last_ok === false
        ? h("div", { class: "vc-error" }, "Last sync failed " + timeAgo(v.last_sync_at) + ": " + (v.last_error || ""))
        : h("div", { class: "small" }, (v.vm_count || 0) + " VMs, synced " + timeAgo(v.last_sync_at)))));

  let view = params.get("view") || (c.unmanaged ? "unmanaged" : "linux");
  const tabs = [
    ["unmanaged", "Linux VMs without an agent", c.unmanaged],
    ["snapshots", "VMs with snapshots", null],
    ["ambiguous", "Ambiguous matches", c.ambiguous],
    ["linux", "All Linux VMs", c.linux],
  ];
  const tabBtns = tabs.map(([k, label, n]) =>
    h("button", { type: "button", "data-k": k, "aria-pressed": String(k === view) },
      label + (n !== null && n !== undefined ? " (" + n + ")" : "")));

  const note = h("p", { class: "muted small" },
    (c.matched || 0) + " VMs are linked to a server. " +
    (res.servers_without_vm ? res.servers_without_vm +
      " servers have no VM linked: physical machines, a vCenter not yet synced, or agents older than 1.2.0. " : "") +
    "Snapshots older than " + oldDays + " days are flagged.");

  const body = h("div");
  async function draw() {
    tabBtns.forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === view)));
    body.replaceChildren(h("p", { class: "muted" }, "Loading"));
    const r = await api("/admin/vmware/vms?view=" + encodeURIComponent(view));
    const vms = r.vms || [];
    const vmCell = v => v.host_id ? h("a", { href: "#/host/" + v.host_id }, v.name) : v.name;
    const cols = {
      unmanaged: [
        { label: "VM", nowrap: true, cell: v => v.name },
        { label: "Guest OS", cell: v => v.guest_os || "" },
        { label: "Hostname", nowrap: true, cell: v => v.guest_hostname || h("span", { class: "muted" }, "unknown") },
        { label: "Addresses", mono: true, cell: v => (v.guest_ips || []).join(", ") },
        { label: "Cluster", nowrap: true, cell: v => v.cluster || "" },
        { label: "vCenter", nowrap: true, cell: v => v.vcenter },
      ],
      snapshots: [
        { label: "VM", nowrap: true, cell: vmCell },
        { label: "Snapshots", num: true, cell: v => v.snapshot_count },
        { label: "Oldest", nowrap: true, cell: v => {
            const d = daysSince(v.oldest_snapshot_at);
            return h("span", { class: d !== null && d >= oldDays ? "snap-old" : null }, ageLabel(d));
          } },
        { label: "Names", cell: v => (v.snapshots || []).map(x => x.name).join(", ") },
        { label: "vCenter", nowrap: true, cell: v => v.vcenter },
      ],
      ambiguous: [
        { label: "VM", nowrap: true, cell: v => v.name },
        { label: "Hostname", nowrap: true, cell: v => v.guest_hostname || "" },
        { label: "Why", cell: () => "Shares its hardware ID with another VM, usually a clone. Not linked, to avoid guessing." },
        { label: "vCenter", nowrap: true, cell: v => v.vcenter },
      ],
      linux: [
        { label: "VM", nowrap: true, cell: vmCell },
        { label: "Server", nowrap: true, cell: v => v.server || h("span", { class: "muted" }, "no agent") },
        { label: "Power", nowrap: true, cell: v => POWER[v.power_state] || v.power_state },
        { label: "Cluster", nowrap: true, cell: v => v.cluster || "" },
        { label: "Snapshots", num: true, cell: v => v.snapshot_count },
        { label: "Linked by", nowrap: true, cell: v => MATCH_LABEL[v.match_method] || "" },
      ],
    }[view];
    const empty = {
      unmanaged: "Every running Linux VM has an agent.",
      snapshots: "No VM has a snapshot.",
      ambiguous: "No ambiguous matches.",
      linux: "No Linux VMs found.",
    }[view];
    body.replaceChildren(vms.length ? table(cols, vms) : h("div", { class: "empty" }, h("p", null, empty)));
  }
  tabBtns.forEach(b => b.addEventListener("click", () => { view = b.dataset.k; draw().catch(showError); }));

  render(head, vcCards, note,
    h("div", { class: "controls" }, h("div", { class: "filters", role: "group", "aria-label": "Show" }, tabBtns)),
    body);
  await draw();
}

/* ---- advisories --------------------------------------------------------- */

async function renderAdvisories() {
  setNav("advisories");
  const app = await api("/admin/applicability/summary");
  const top = app.top_affected || [];
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl advisories --affected --sort severity" }, "Advisories"),
      h("span", { class: "muted small" }, "Ordered by severity, then by how many servers need the fix")),
    top.length ? table([
      { label: "Advisory", nowrap: true, cell: r => r.advisory_id },
      { label: "Severity", cell: r => sevLabel(r.severity) },
      { label: "Servers affected", num: true, cell: r => count(r.hosts_affected, "affected") },
      { label: "Issued", cell: r => fmtDate(r.issued_at) },
      { label: "Summary", cell: r => r.title || "" },
      { label: "CVEs", cell: r => (r.cves || []).slice(0, 3).join(", ") +
          ((r.cves || []).length > 3 ? " and " + (r.cves.length - 3) + " more" : "") },
    ], top)
    : h("div", { class: "empty" },
        h("p", null, "No server needs a patch right now."),
        h("p", { class: "muted small" }, "If this is unexpected, check the CVE engine last ran with ",
          h("code", null, "./scripts/phase4-cve.sh --report"), ".")),
  );
}

/* ---- activity ----------------------------------------------------------- */

const ACTIONS = {
  enroll: "Server enrolled",
  re_enroll: "Server re-enrolled",
  inventory: "Inventory received",
  inventory_rejected: "Inventory rejected",
  create_enrollment_token: "Enrollment token issued",
  decommission: "Server retired",
  mark_stale: "Silent servers marked",
};

async function renderActivity() {
  setNav("activity");
  const res = await api("/admin/audit?limit=200");
  const rows = res.events || [];
  render(
    h("div", { class: "page-head" },
      h("h1", { "data-cmd": "patchctl audit tail -n 200" }, "Activity"),
      h("span", { class: "muted small" }, "Permanent record; entries cannot be edited or removed")),
    rows.length ? table([
      { label: "When", cell: r => fmtDateTime(r.occurred_at) },
      { label: "What", cell: r => ACTIONS[r.action] || r.action },
      { label: "By", cell: r => r.actor },
      { label: "From", mono: true, cell: r => r.source_ip || "" },
      { label: "Detail", cell: r => {
          const d = r.detail || {};
          const parts = [];
          if (d.packages !== undefined) parts.push(d.packages + " packages" + (d.unchanged ? ", unchanged" : ""));
          if (d.os) parts.push(d.os);
          if (d.host_group) parts.push("group " + d.host_group);
          if (d.reboot_required) parts.push("reboot required");
          if (d.package_count !== undefined) parts.push(d.package_count + " packages reported");
          return parts.join(", ");
        } },
    ], rows)
    : h("div", { class: "empty" }, h("p", null, "Nothing recorded yet.")),
  );
}

/* ---- routing ------------------------------------------------------------ */

async function route() {
  if (!getAuth()) return renderSignIn();
  document.getElementById("top").hidden = false;
  document.getElementById("chat-open").hidden = false;
  document.getElementById("whoami").textContent = "Signed in as " + getAuth().user;

  const raw = location.hash.replace(/^#\/?/, "");
  const [path, query] = raw.split("?");
  const params = new URLSearchParams(query || "");
  const parts = path.split("/").filter(Boolean);

  try {
    if (parts[0] === "hosts") await renderHosts(params);
    else if (parts[0] === "host" && parts[1]) await renderHost(parts[1], params);
    else if (parts[0] === "agents") await renderAgents(params);
    else if (parts[0] === "vmware") await renderVmware(params);
    else if (parts[0] === "assess") await renderAssess(params);
    else if (parts[0] === "advisories") await renderAdvisories(params);
    else if (parts[0] === "activity") await renderActivity(params);
    else await renderOverview();
  } catch (err) {
    showError(err);
  }
}

function start() {
  route();
}

/* ---- admin chat --------------------------------------------------------- */
/*
 * Read-only by design. It answers questions and shows the rows behind every
 * answer; it cannot patch, snapshot or power anything. Those go through the
 * approval flow.
 */

const CHAT_EXAMPLES = [
  "Which servers are affected by CVE-2026-31337?",
  "Which rhel servers need patches?",
  "What CVEs are exploited in the wild?",
  "Which agents are offline?",
  "VMs with snapshots older than 30 days",
];

let chatHistoryEl = null;

function chatBubble(role, nodes) {
  return h("div", { class: "cm cm-" + role }, nodes);
}

function chatTable(res) {
  if (!res.rows || !res.rows.length) return null;
  const cols = (res.columns || []).map(c => ({
    label: c.replace(/_/g, " "),
    cell: r => {
      const v = r[c];
      if (v === null || v === undefined) return "";
      if (typeof v === "boolean") return v ? "yes" : "no";
      if (Array.isArray(v)) return v.join(", ");
      if (typeof v === "string" && /^\d{4}-\d{2}-\d{2}T/.test(v)) return timeAgo(v);
      return String(v);
    },
  }));
  return h("div", { class: "cm-table" }, table(cols, res.rows));
}

async function chatAsk(question) {
  const hist = chatHistoryEl;
  hist.append(chatBubble("you", question));
  const thinking = chatBubble("bot", h("span", { class: "cm-wait" }, "Looking"));
  hist.append(thinking);
  hist.scrollTop = hist.scrollHeight;
  try {
    const res = await apiPost("/admin/chat", { question });
    const meta = [];
    if (res.tool) meta.push("query: " + res.tool.replace(/_/g, " "));
    if (res.how) meta.push(res.how === "model" ? "chosen by AI-01" : "chosen by keywords");
    if (res.truncated) meta.push("first " + (res.rows || []).length + " rows");
    thinking.replaceWith(chatBubble("bot", [
      h("p", null, res.answer),
      chatTable(res),
      meta.length ? h("p", { class: "cm-meta" }, meta.join(" | ")) : null,
      res.tools ? h("ul", { class: "cm-tools" },
        res.tools.slice(0, 6).map(t => h("li", null, t.what))) : null,
    ]));
  } catch (err) {
    if (err.status === 401) { closeChat(); return renderSignIn(err.message); }
    thinking.replaceWith(chatBubble("bot",
      h("p", { class: "explain-error" },
        err.status === 404 ? "The API is older than the chat; rebuild it with phase3b-api.sh."
        : err.status === 429 ? "AI-01 is busy. Try again in a moment."
        : "Could not answer (HTTP " + (err.status || "error") + ").")));
  }
  hist.scrollTop = hist.scrollHeight;
}

function closeChat() {
  const p = document.getElementById("chat");
  const b = document.getElementById("chat-open");
  p.hidden = true;
  b.setAttribute("aria-expanded", "false");
  b.focus();
}

function buildChat() {
  const panel = document.getElementById("chat");
  chatHistoryEl = h("div", { class: "cm-history" },
    chatBubble("bot", [
      h("p", null, "Ask about servers, CVEs, agents or VMs. I read the data and show "
                 + "the rows behind every answer."),
      h("p", { class: "cm-meta" }, "Read-only: patching and VMware actions go through approval."),
      h("div", { class: "cm-examples" }, CHAT_EXAMPLES.map(q =>
        h("button", { type: "button", on: { click: () => { input.value = q; form.requestSubmit(); } } }, q))),
    ]));
  const input = h("input", { type: "text", placeholder: "Ask a question", autocomplete: "off",
                             "aria-label": "Your question", maxlength: "400" });
  const form = h("form", { class: "cm-form", on: { submit: e => {
    e.preventDefault();
    const q = input.value.trim();
    if (!q) return;
    input.value = "";
    chatAsk(q);
  } } }, input, h("button", { type: "submit" }, "Ask"));

  panel.replaceChildren(
    h("div", { class: "cm-head" },
      h("strong", null, "Ask about the fleet"),
      h("button", { type: "button", class: "quiet", on: { click: closeChat } }, "Close")),
    chatHistoryEl, form);
  panel.dataset.built = "1";
  return input;
}

function openChat() {
  const panel = document.getElementById("chat");
  const input = panel.dataset.built ? panel.querySelector(".cm-form input") : buildChat();
  panel.hidden = false;
  document.getElementById("chat-open").setAttribute("aria-expanded", "true");
  input.focus();
}

document.addEventListener("keydown", e => {
  if (e.key === "Escape" && !document.getElementById("chat").hidden) closeChat();
});

document.addEventListener("DOMContentLoaded", () => {
  const fab = document.getElementById("chat-open");
  fab.addEventListener("click", () => {
    document.getElementById("chat").hidden ? openChat() : closeChat();
  });
  fillThemeSelect(document.getElementById("theme"));
  window.addEventListener("hashchange", route);
  document.getElementById("refresh").addEventListener("click", route);
  document.getElementById("signout").addEventListener("click", () => {
    clearAuth();
    location.hash = "#/";
    renderSignIn();
  });
  start();
});
