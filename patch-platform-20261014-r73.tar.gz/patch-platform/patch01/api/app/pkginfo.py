"""What an uploaded Windows installer says about itself, read on PATCH-01.

Nothing here runs the file. It only reads:
  - EXE: the version resource (company, product, version, description), the
    installer technology (Inno Setup, NSIS, InstallShield, WiX Burn) from
    marker strings, and whether it carries an Authenticode signature (the
    signature itself is verified on each server before anything runs);
  - MSI: the summary information (title, subject, author) and the Property
    table (ProductName, ProductVersion, ProductCode, Manufacturer).

Every reader is bounded and defensive: a malformed file gives fewer facts,
never an exception the caller has to handle (read() catches everything).
"""

import re
import struct

MAX_RESOURCE_BYTES = 64 * 2 ** 20
MARKER_SCAN_BYTES = 16 * 2 ** 20

# Installer technology -> its documented silent install options
SILENT = {
    "inno": ("Inno Setup", "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-"),
    "nsis": ("Nullsoft (NSIS)", "/S"),
    "installshield": ("InstallShield", '/s /v"/qn REBOOT=ReallySuppress"'),
    "burn": ("WiX bundle (Burn)", "/quiet /norestart"),
}
_MARKERS = [
    ("inno", (b"Inno Setup Setup Data", b"JR.Inno.Setup", b"<description>Inno Setup")),
    ("nsis", (b"Nullsoft.NSIS", b"NullsoftInst", b"Nullsoft Install System")),
    ("installshield", (b"InstallShield", b"ISSetupStream")),
    ("burn", (b".wixburn", b"WixBundleManifest", b"WixBurn")),
]
_PRINTABLE = re.compile(r"[^\x20-\x7e -ɏ]")


def _clean(v, limit=200):
    v = _PRINTABLE.sub(" ", str(v or "")).strip()
    return re.sub(r"\s+", " ", v)[:limit]


# ---------------------------------------------------------------------------
# EXE (PE)
# ---------------------------------------------------------------------------

def _align4(n):
    return (n + 3) & ~3


def _vs_block(b, off, base, depth=0):
    """One VS_VERSIONINFO-style block: (key, value, children, end)."""
    if depth > 6 or off + 6 > len(b):
        raise ValueError("bad block")
    length, vlen, typ = struct.unpack_from("<HHH", b, off)
    if length < 6:
        raise ValueError("bad block length")
    end = min(off + length, len(b))
    p = off + 6
    k = p
    while k + 1 < end and b[k:k + 2] != b"\0\0":
        k += 2
    key = b[p:k].decode("utf-16-le", "replace")
    p = base + _align4(k + 2 - base)
    value = None
    children = []
    if typ == 1 and key not in ("StringFileInfo", "VarFileInfo") and depth >= 3:
        # A String: its text runs to the end of the block (wValueLength is not reliable)
        value = b[p:end].decode("utf-16-le", "replace").split("\0")[0]
        return key, value, children, end
    if typ == 0 and vlen:
        value = b[p:p + vlen]
        p = base + _align4(p + vlen - base)
    while p + 6 <= end:
        ck, cv, cc, cend = _vs_block(b, p, base, depth + 1)
        children.append((ck, cv, cc))
        if cend <= p:
            break
        p = base + _align4(cend - base)
    return key, value, children, end


def _version_strings(res):
    """{CompanyName: ..., ProductName: ...} and the fixed versions from a version resource."""
    out = {}
    key, value, children, _ = _vs_block(res, 0, 0)
    if key != "VS_VERSION_INFO":
        return out
    if value and len(value) >= 52 and struct.unpack_from("<I", value, 0)[0] == 0xFEEF04BD:
        fms, fls, pms, pls = struct.unpack_from("<IIII", value, 8)
        out["FileVersionFixed"] = f"{fms >> 16}.{fms & 0xffff}.{fls >> 16}.{fls & 0xffff}"
        out["ProductVersionFixed"] = f"{pms >> 16}.{pms & 0xffff}.{pls >> 16}.{pls & 0xffff}"
    for ck, _cv, cc in children:
        if ck != "StringFileInfo":
            continue
        for _table, _tv, strings in cc:
            for sk, sv, _sc in strings:
                if isinstance(sv, str) and sk and sk not in out:
                    out[sk] = _clean(sv)
    return out


def _pe(f, size):
    f.seek(0)
    head = f.read(4096)
    if head[:2] != b"MZ" or len(head) < 64:
        raise ValueError("not a Windows program (no MZ header)")
    pe = struct.unpack_from("<I", head, 0x3C)[0]
    if pe <= 0 or pe > size - 24 or pe > 0x100000:
        raise ValueError("not a Windows program (bad PE offset)")
    f.seek(pe)
    head2 = f.read(4096)
    base_off = pe
    if head2[:4] != b"PE\0\0":
        raise ValueError("not a Windows program (no PE header)")
    nsec, = struct.unpack_from("<H", head2, 6)
    opt_size, = struct.unpack_from("<H", head2, 20)
    opt = 24
    magic, = struct.unpack_from("<H", head2, opt)
    if magic == 0x10B:
        ndirs_at, dirs_at = opt + 92, opt + 96
    elif magic == 0x20B:
        ndirs_at, dirs_at = opt + 108, opt + 112
    else:
        raise ValueError("unknown PE optional header")
    ndirs, = struct.unpack_from("<I", head2, ndirs_at)
    dirs = []
    for i in range(min(ndirs, 16)):
        dirs.append(struct.unpack_from("<II", head2, dirs_at + 8 * i))
    sec_at = opt + opt_size
    sections = []
    for i in range(min(nsec, 96)):
        o = sec_at + 40 * i
        if o + 40 > len(head2):
            f.seek(base_off + o)
            raw = f.read(40)
        else:
            raw = head2[o:o + 40]
        if len(raw) < 40:
            break
        name = raw[:8].rstrip(b"\0").decode("ascii", "replace")
        vsize, va, rsize, rptr = struct.unpack_from("<IIII", raw, 8)
        sections.append({"name": name, "va": va, "vsize": vsize, "rsize": rsize, "rptr": rptr})
    info = {"machine": "x64" if magic == 0x20B else "x86", "sections": [s["name"] for s in sections]}
    # Authenticode: the security directory (index 4) holds a file offset, not an RVA
    if len(dirs) > 4 and dirs[4][1] > 0 and dirs[4][0] + dirs[4][1] <= size:
        info["signed"] = True
    else:
        info["signed"] = False

    def rva_to_off(rva):
        for s in sections:
            span = max(s["vsize"], s["rsize"])
            if s["va"] <= rva < s["va"] + span:
                return rva - s["va"] + s["rptr"]
        return None

    if len(dirs) > 2 and dirs[2][0] and dirs[2][1]:
        rsrc_rva, rsrc_size = dirs[2]
        rsrc_off = rva_to_off(rsrc_rva)
        if rsrc_off is not None and rsrc_size <= MAX_RESOURCE_BYTES:
            f.seek(rsrc_off)
            rs = f.read(rsrc_size)
            data = _find_version_resource(rs, rsrc_rva)
            if data is not None:
                off, ln = data
                f.seek(rva_to_off(off) or 0)
                try:
                    info["version_info"] = _version_strings(f.read(min(ln, 65536)))
                except (ValueError, struct.error):
                    pass
    return info


def _find_version_resource(rs, rsrc_rva):
    """(RVA, size) of the first RT_VERSION resource, or None."""
    def entries(off):
        if off + 16 > len(rs):
            return []
        named, ids = struct.unpack_from("<HH", rs, off + 12)
        out = []
        for i in range(min(named + ids, 512)):
            e = off + 16 + 8 * i
            if e + 8 > len(rs):
                break
            out.append(struct.unpack_from("<II", rs, e))
        return out
    for name, ptr in entries(0):
        if name & 0x80000000 or name != 16 or not ptr & 0x80000000:
            continue
        for _n2, p2 in entries(ptr & 0x7FFFFFFF):
            if not p2 & 0x80000000:
                continue
            for _n3, p3 in entries(p2 & 0x7FFFFFFF):
                if p3 & 0x80000000 or p3 + 16 > len(rs):
                    continue
                rva, size = struct.unpack_from("<II", rs, p3)
                if 0 < size <= 65536:
                    return rva, size
    return None


def _markers(f, size):
    f.seek(0)
    blob = f.read(min(size, MARKER_SCAN_BYTES))
    for tech, marks in _MARKERS:
        if any(m in blob for m in marks):
            return tech
    return None


# ---------------------------------------------------------------------------
# MSI (OLE compound file)
# ---------------------------------------------------------------------------

ENDOFCHAIN = 0xFFFFFFFE
FREESECT = 0xFFFFFFFF
_MIME = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz._"


def msi_stream_name(name):
    """An MSI stream name as stored: tables start with U+4840, then two
    characters packed into one where possible (the same as msitools/Wine)."""
    out = []
    i = 0
    while i < len(name):
        c = name[i]
        if c in _MIME:
            a = _MIME.index(c)
            if i + 1 < len(name) and name[i + 1] in _MIME:
                out.append(chr(0x3800 + a + (_MIME.index(name[i + 1]) << 6)))
                i += 2
                continue
            out.append(chr(0x4800 + a))
        else:
            out.append(c)
        i += 1
    return "䡀" + "".join(out)


READ_BUDGET = 96 * 2 ** 20          # all streams read from one MSI, together


class _Cfb:
    def __init__(self, f, size):
        self.f, self.size = f, size
        self.budget = READ_BUDGET
        f.seek(0)
        h = f.read(512)
        if h[:8] != bytes.fromhex("D0CF11E0A1B11AE1"):
            raise ValueError("not an MSI (no compound-file header)")
        shift, mshift = struct.unpack_from("<HH", h, 0x1E)
        if shift not in (9, 12) or mshift != 6:
            raise ValueError("unsupported compound-file sector size")
        self.ss = 1 << shift
        self.mss = 1 << mshift
        self.nsec = max(1, (size + self.ss - 1) // self.ss - 1)      # sectors in the file after the header
        nfat, first_dir, _tx, self.cutoff, first_mfat, nmfat, first_difat, ndifat = struct.unpack_from("<IIIIIIII", h, 0x2C)
        # A real file has at most one FAT sector per (sector size / 4) sectors: anything more is forged
        max_fat = self.nsec // (self.ss // 4) + 1
        if nfat > max_fat or ndifat > max_fat:
            raise ValueError("the compound file's tables are larger than the file")
        difat = list(struct.unpack_from("<109I", h, 0x4C))
        sec = first_difat
        per = self.ss // 4 - 1
        seen = set()
        for _ in range(ndifat):
            if sec in (ENDOFCHAIN, FREESECT):
                break
            if sec in seen or sec >= self.nsec:
                raise ValueError("the compound file's sector table loops or points outside the file")
            seen.add(sec)
            d = self._sector(sec)
            vals = struct.unpack_from(f"<{per + 1}I", d)
            difat.extend(vals[:per])
            sec = vals[per]
        fat_secs = [s for s in difat if s not in (FREESECT, ENDOFCHAIN)][:nfat]
        if len(set(fat_secs)) != len(fat_secs) or any(s >= self.nsec for s in fat_secs):
            raise ValueError("the compound file's sector table is not valid")
        self.fat = []
        for s in fat_secs:
            self.fat.extend(struct.unpack(f"<{self.ss // 4}I", self._sector(s)))
        dir_bytes = self._chain_bytes(first_dir, None)
        self.entries = []
        for i in range(0, len(dir_bytes) - 127, 128):
            e = dir_bytes[i:i + 128]
            nlen, = struct.unpack_from("<H", e, 64)
            name = e[:max(0, min(nlen, 64) - 2)].decode("utf-16-le", "replace")
            typ = e[66]
            start, = struct.unpack_from("<I", e, 116)
            sz, = struct.unpack_from("<Q", e, 120)
            if self.ss == 512:
                sz &= 0xFFFFFFFF
            self.entries.append({"name": name, "type": typ, "start": start, "size": sz})
        root = self.entries[0] if self.entries else None
        if not root or root["type"] != 5:
            raise ValueError("compound file without a root entry")
        self.mini = self._chain_bytes(root["start"], root["size"]) if root["size"] else b""
        self.mfat = []
        if nmfat and first_mfat not in (ENDOFCHAIN, FREESECT):
            mb = self._chain_bytes(first_mfat, None)
            self.mfat = list(struct.unpack(f"<{len(mb) // 4}I", mb[:len(mb) // 4 * 4]))

    def _sector(self, n):
        off = (n + 1) * self.ss
        if n >= self.nsec:
            raise ValueError("sector outside the file")
        self.f.seek(off)
        return self.f.read(self.ss).ljust(self.ss, b"\0")

    def _chain_bytes(self, start, size, limit=64 * 2 ** 20):
        out = bytearray()
        sec = start
        visited = set()
        while sec not in (ENDOFCHAIN, FREESECT) and sec < len(self.fat):
            if sec in visited:
                raise ValueError("a stream's sector chain loops")
            visited.add(sec)
            out += self._sector(sec)
            self.budget -= self.ss
            if len(out) > limit or self.budget < 0:
                raise ValueError("stream too large")
            sec = self.fat[sec]
            if size is not None and len(out) >= size:
                break
        return bytes(out[:size]) if size is not None else bytes(out)

    def stream(self, name):
        for e in self.entries:
            if e["type"] == 2 and e["name"] == name:
                if e["size"] < self.cutoff:
                    out = bytearray()
                    sec = e["start"]
                    visited = set()
                    while sec not in (ENDOFCHAIN, FREESECT) and sec < len(self.mfat) and len(out) < e["size"]:
                        if sec in visited:
                            raise ValueError("a small stream's chain loops")
                        visited.add(sec)
                        out += self.mini[sec * self.mss:(sec + 1) * self.mss]
                        sec = self.mfat[sec]
                    return bytes(out[:e["size"]])
                return self._chain_bytes(e["start"], e["size"])
        return None


def _summary(data):
    """The summary information property set: {title, subject, author, ...}."""
    names = {2: "title", 3: "subject", 4: "author", 5: "keywords", 6: "comments", 7: "template",
             9: "package_code", 18: "creating_application"}
    out = {}
    if not data or len(data) < 48 or data[:2] != b"\xfe\xff":
        return out
    nsec, = struct.unpack_from("<I", data, 24)
    if nsec < 1:
        return out
    off, = struct.unpack_from("<I", data, 44)
    if off + 8 > len(data):
        return out
    _size, nprops = struct.unpack_from("<II", data, off)
    codepage = 1252
    props = []
    for i in range(min(nprops, 64)):
        p = off + 8 + 8 * i
        if p + 8 > len(data):
            break
        props.append(struct.unpack_from("<II", data, p))
    for pid, poff in props:
        at = off + poff
        if at + 8 > len(data):
            continue
        vt, = struct.unpack_from("<I", data, at)
        if pid == 1 and vt == 2:
            codepage = struct.unpack_from("<h", data, at + 4)[0] & 0xFFFF
    enc = _codec(codepage)
    for pid, poff in props:
        at = off + poff
        if pid not in names or at + 8 > len(data):
            continue
        vt, = struct.unpack_from("<I", data, at)
        if vt == 30:
            ln, = struct.unpack_from("<I", data, at + 4)
            raw = data[at + 8:at + 8 + min(ln, 4096)]
            out[names[pid]] = _clean(raw.split(b"\0")[0].decode(enc, "replace"))
    return out


def _codec(cp):
    cp = int(cp or 0) & 0xFFFF
    if cp == 65001:
        return "utf-8"
    if cp in (0, 0xFFFF):
        return "latin-1"
    try:
        "".encode(f"cp{cp}")
        return f"cp{cp}"
    except LookupError:
        return "latin-1"


def _msi_properties(cfb, wanted=("ProductName", "ProductVersion", "ProductCode", "Manufacturer", "UpgradeCode", "ALLUSERS")):
    pool = cfb.stream(msi_stream_name("_StringPool"))
    sdata = cfb.stream(msi_stream_name("_StringData"))
    table = cfb.stream(msi_stream_name("Property"))
    if not pool or sdata is None or not table or len(pool) < 4:
        return {}
    words = struct.unpack(f"<{len(pool) // 2}H", pool[:len(pool) // 2 * 2])
    codepage = words[0] | (words[1] << 16)
    ref_bytes = 3 if codepage & 0x80000000 else 2
    enc = _codec(codepage & 0xFFFF)
    strings = {0: ""}
    count = len(words) // 2
    i, n, offset = 1, 1, 0
    while i < count:
        ln, refs = words[i * 2], words[i * 2 + 1]
        if ln == 0 and refs == 0:
            i += 1
            n += 1
            continue
        if ln == 0:
            if (i + 1) * 2 + 1 >= len(words):
                break
            ln = (words[i * 2 + 3] << 16) + words[i * 2 + 2]
            i += 2
        else:
            i += 1
        strings[n] = sdata[offset:offset + ln].decode(enc, "replace")
        offset += ln
        n += 1
        if n > 500000:
            break
    rows = len(table) // (2 * ref_bytes)

    def ref(col, row):
        at = (col * rows + row) * ref_bytes
        v = int.from_bytes(table[at:at + ref_bytes], "little")
        return strings.get(v, "")
    out = {}
    for r in range(rows):
        k = ref(0, r)
        if k in wanted:
            out[k] = _clean(ref(1, r))
    return out


# ---------------------------------------------------------------------------

def read(path, kind, size):
    """Facts about the installer at path. Never raises."""
    facts = {"kind": kind}
    try:
        with open(path, "rb") as f:
            if kind == "exe":
                pe = _pe(f, size)
                facts.update({k: v for k, v in pe.items() if k != "sections"})
                tech = _markers(f, size)
                if not tech and any(s == ".wixburn" for s in pe.get("sections", [])):
                    tech = "burn"
                if tech:
                    facts["installer"] = tech
                    facts["installer_label"], facts["silent_args"] = SILENT[tech]
            else:
                cfb = _Cfb(f, size)
                facts["summary"] = _summary(cfb.stream("\x05SummaryInformation"))
                try:
                    facts["properties"] = _msi_properties(cfb)
                except (ValueError, struct.error, IndexError) as e:
                    facts["properties_error"] = str(e)[:200]
                facts["installer"] = "msi"
                facts["installer_label"] = "Windows Installer (MSI)"
                facts["silent_args"] = "/qn /norestart"
    except (OSError, ValueError, struct.error, IndexError, MemoryError, RecursionError, OverflowError) as e:
        facts.pop("properties", None)
        facts["error"] = (str(e) or type(e).__name__)[:300]
    return facts


def suggestions(facts, file_name):
    """Defaults for the review form, from the file's own facts (AI-01 adds to these)."""
    vi = facts.get("version_info") or {}
    pr = facts.get("properties") or {}
    sm = facts.get("summary") or {}
    if facts.get("kind") == "msi":
        name = pr.get("ProductName") or sm.get("subject") or ""
        version = pr.get("ProductVersion") or ""
        vendor = pr.get("Manufacturer") or sm.get("author") or ""
    else:
        name = vi.get("ProductName") or vi.get("FileDescription") or ""
        version = ""
        for cand in (vi.get("ProductVersion"), vi.get("FileVersion"), vi.get("ProductVersionFixed")):
            m = re.match(r"\s*(\d+(?:\s*[.,]\s*\d+){0,3})", cand or "")
            if m:
                version = re.sub(r"\s*[.,]\s*", ".", m.group(1))
                break
        vendor = vi.get("CompanyName") or ""
    if not name:
        name = re.sub(r"[-_ ]?(setup|installer|install|x64|x86|win64|win32)?\.(msi|exe)$", "", file_name, flags=re.I)
    return {"name": _clean(name, 80), "version": _clean(version, 40), "vendor": _clean(vendor, 120),
            "detect_name": _clean(name, 120), "product_code": pr.get("ProductCode") or "",
            "install_args": (facts.get("silent_args") or "") if facts.get("kind") == "exe" else ""}
