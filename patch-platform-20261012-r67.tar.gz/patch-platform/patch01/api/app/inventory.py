"""Asset and software inventory, merged from every source PATCH-01 has.

Assets come from six places, merged by machine name:
  agents     the servers PATCH-01 manages (exact OS, agent state)
  vCenter    every VM (guest OS, power, cluster) and every ESXi host
  WSUS       every Windows computer WSUS knows (OS, last report)
  vCenters   the vCenter appliances themselves
  Apex       every antivirus agent Apex Central lists (OS where it says)
  manual     rows from a sheet an admin uploaded (Excel or CSV)

The OS shown: agent, then WSUS, then vCenter, then Apex, then the sheet;
except laptops and desktops, where Apex's Windows 10/11 is used first (WSUS
can report the wrong desktop version; servers are right in vCenter and WSUS).

Each asset gets one device type, with the reason, so a wrong guess can be
seen and questioned: server, client (laptop/desktop), esxi, appliance,
network, firewall, or unknown. The type is decided in this order: a person's
choice, vCenter's facts (ESXi host, vCenter), the operating system, the
uploaded sheet's device column, the machine's name, then AI-01. Software
comes only from agents: vCenter and WSUS report machines, not what is
installed on them.

The functions here are pure (no database), so the merging can be tested.
"""

import ipaddress
import re

CATEGORIES = ("server", "client", "esxi", "appliance", "network", "firewall", "unknown")
EXPECTED_PATCHED = ("server", "client")            # the only types expected in WSUS and Apex
STATUSES = ("new", "approved", "decommissioned")
KEY_RE = re.compile(r"^[a-z0-9:._-]{1,255}$")
# Where each kind of record came from, as the page labels it
SOURCE_LABEL = {"agent": "Agent", "virtual": "Virtual", "vcenter": "vCenter", "wsus": "WSUS", "apex": "Apex", "manual": "Manual"}
LIVE_SOURCES = ("agent", "virtual", "vcenter", "wsus", "apex")      # everything but the uploaded sheet

_LINUX_SERVER = re.compile(r"red hat|rhel|oracle linux|\bol ?\d|centos|rocky|alma|ubuntu|debian|suse|sles|amazon linux|fedora")
_FIREWALL = re.compile(r"fortios|fortigate|pan-os|palo alto networks|check ?point gaia|\bgaia r\d|cisco asa|adaptive security appliance|"
                       r"sophos (?:xg|utm|sfos|firewall)|\bsfos\b|sonicos|pfsense|opnsense|watchguard fireware|junos srx|"
                       r"firepower threat defense|forcepoint ngfw|stormshield|barracuda cloudgen")
_NETWORK = re.compile(r"\bios[- ]?xe\b|\bios[- ]?xr\b|cisco ios|\bnx-?os\b|\bjunos\b|arista eos|arubaos|aos-cx|procurve|comware|"
                      r"mikrotik|routeros|cumulus linux|extremexos|brocade fos|meraki|edgeos|wireless lan controller|"
                      r"dell (?:emc )?os10|\bvyos\b|huawei vrp")
_APPLIANCE = re.compile(r"photon|vcenter|appliance|freebsd|netscaler|citrix adc|\bf5\b|big-ip|nsx|ontap|data domain|"
                        r"isilon|onefs|purity|nimble|\bdsm\b|synology|qnap|printer|\bups\b|idrac|\bilo\b|"
                        r"other \S* ?linux|other \(|other 3|other 4|other 5|other 6")
_WINDOWS_CLIENT = re.compile(r"windows (10|11|8|7|xp|vista)\b")
WEAK = ("Linux (distribution not stated)", "generic guest OS", "no operating system reported", "unrecognised OS")


def classify(os_text, kind=None):
    """(type, reason) for one machine from its OS. kind is "esxi" or
    "vcenter" for VMware's own systems, which vCenter states as facts."""
    if kind == "esxi":
        return "esxi", "ESXi host in vCenter"
    if kind == "vcenter":
        return "appliance", "vCenter appliance"
    t = (os_text or "").strip().lower()
    if not t:
        return "unknown", "no operating system reported"
    if "windows" in t and "server" in t:
        return "server", "Windows Server"
    if _WINDOWS_CLIENT.search(t) or ("windows" in t and "server" not in t and "microsoft" in t and re.search(r"\b(10|11)\b", t)):
        return "client", "Windows desktop edition"
    if "mac os" in t or "macos" in t:
        return "client", "macOS"
    if "esxi" in t or "vmkernel" in t:
        return "esxi", "VMware ESXi"
    if _LINUX_SERVER.search(t):                       # a named distribution is a server, whatever else the text says
        return "server", "Linux server distribution"
    if _FIREWALL.search(t):
        return "firewall", "firewall OS (" + os_text.strip()[:40] + ")"
    if _NETWORK.search(t):
        return "network", "network OS (" + os_text.strip()[:40] + ")"
    if _APPLIANCE.search(t):
        generic = re.search(r"other \S* ?linux|other \(|other \d|freebsd", t)
        return "appliance", ("generic guest OS" if generic else "appliance OS") + " (" + os_text.strip()[:40] + ")"
    if _LINUX_SERVER.search(t):
        return "server", "Linux server distribution"
    if "windows" in t:
        return "server", "Windows (edition not stated)"
    if "linux" in t:
        return "server", "Linux (distribution not stated)"
    return "unknown", "unrecognised OS (" + os_text.strip()[:40] + ")"


def weak(reason):
    """Is this OS-based type only a weak guess (a better source may override it)?"""
    return any((reason or "").startswith(w) for w in WEAK)


# Name hints, used only when nothing better says: fw-01, sg-core-sw01, ltp-0042...
_NAME_HINTS = (
    (re.compile(r"(?:^|[-_.])(?:fw|fwl|firewall|fgt|fortigate|palo|asa|srx)\d*(?:[-_.]|$)"), "firewall"),
    (re.compile(r"(?:^|[-_.])(?:sw|swi|switch|core|dist|rtr|router|wlc|leaf|spine|nexus|n[3579]k)\d*(?:[-_.]|$)"), "network"),
    (re.compile(r"(?:^|[-_.])(?:esx|esxi)\d*(?:[-_.]|$)"), "esxi"),
    (re.compile(r"(?:^|[-_.])(?:nas|san|ups|prn|printer|lb|ilo|idrac|bmc)\d*(?:[-_.]|$)"), "appliance"),
    (re.compile(r"(?:^|[-_.])(?:lt|ltp|lap|laptop|nb|dt|dsk|desk|desktop|wks|pc)\d*(?:[-_.]|$)"), "client"),
)


def name_hint(name):
    n = (name or "").lower()
    for rx, dev in _NAME_HINTS:
        if rx.search(n):
            return dev
    return None


JUNK_NAMES = {"", "localhost", "localhost.localdomain", "localdomain", "unknown", "none", "-"}


def short_name(name):
    """The machine's short name, lower case, as the merge key. Always a key
    the database accepts (KEY_RE): "DOM\\PC-1" gives "pc-1", "web server 01"
    gives "web-server-01"; a placeholder name such as localhost gives ""."""
    n = (name or "").strip().lower().rstrip(".")
    if "\\" in n:
        n = n.rsplit("\\", 1)[1]                  # DOMAIN\name
    if n in JUNK_NAMES:
        return ""
    try:
        return str(ipaddress.ip_address(n.split("%")[0]))      # an address is kept whole (no IPv6 scope)
    except ValueError:
        pass
    n = n.split(".")[0]
    k = re.sub(r"[^a-z0-9_-]+", "-", n).strip("-")[:200]
    if not k or (k != n and not re.fullmatch(r"[a-z0-9 _-]+", n)):
        # Letters a key cannot hold (non-ASCII, symbols): a short hash keeps such names apart
        import hashlib
        k = (k + "-" if k else "h-") + hashlib.sha256(n.encode()).hexdigest()[:8]
    return k


_OS_NAMES = {"rhel": "RHEL", "ol": "Oracle Linux", "ubuntu": "Ubuntu", "windows": "Windows Server"}


def _agent_os(h):
    if h.get("os_edition"):
        return h["os_edition"]
    base = _OS_NAMES.get(h.get("os_id") or "", h.get("os_id") or "")
    return (base + " " + (h.get("os_version") or "")).strip()


def clean_ips(value):
    """Addresses from any source as a plain list: a list, a "{a,b}" array
    text, "['a', 'b']", or "a, b" all give ["a", "b"]. Only real addresses
    are kept; loopback, link-local and unspecified ones are dropped."""
    items = value if isinstance(value, (list, tuple, set)) else [value]
    out = []
    for item in items:
        for x in re.split(r"[,;\s]+", re.sub(r"[\[\]{}()'\"]", " ", str(item or ""))):
            x = x.strip()
            if not x:
                continue
            try:
                ip = ipaddress.ip_address(x.split("%")[0].split("/")[0])
            except ValueError:
                continue
            if ip.is_loopback or ip.is_link_local or ip.is_unspecified or ip.is_multicast:
                continue
            t = str(ip)
            if t not in out:
                out.append(t)
    return out


def _os_family(text):
    t = (text or "").lower()
    if "windows" in t:
        return "windows"
    if _LINUX_SERVER.search(t) or "linux" in t:
        return "linux"
    return None


def merge(hosts, vms, wsus, esxi, vcenters, manual=(), records=None, ai_types=None, apex=(), overrides=None, ai_class=None):
    """One record per machine, from all sources. Each argument is a list of
    rows (dicts) as read from the database. records: asset_key -> status row;
    ai_types: OS text (lower case) -> device type AI-01 chose."""
    assets = {}
    by_host_id = {}
    records = records or {}
    ai_types = ai_types or {}
    overrides = overrides or {}
    ai_class = ai_class or {}
    vc_host = {c.get("name"): c.get("host") or c.get("name") for c in vcenters}

    def get(key, name):
        if key not in assets:
            assets[key] = {"name": name, "key": key, "sources": [], "os": None, "os_from": None, "ips": [],
                           "os_by": {}, "agent": None, "vm": None, "wsus": None, "esxi": None, "vcenter": None,
                           "apex": None, "manual": None, "last_seen": None}
        return assets[key]

    def seen(a, when):
        if when and (a["last_seen"] is None or str(when) > str(a["last_seen"])):
            a["last_seen"] = when

    def add_ip(a, ip):
        for x in clean_ips(ip):
            if x not in a["ips"]:
                a["ips"].append(x)

    def set_os(a, text, src, rank):
        # Precedence: agent (exact) > WSUS > vCenter's configured guest OS > the uploaded sheet
        order = {"agent": 5, "wsus": 4, "vcenter": 3, "virtual": 3, "apex": 2, "manual": 1}
        if text:
            a["os_by"][src] = text
        if text and (a["os"] is None or order.get(src, 0) > order.get(a["os_from"], 0)):
            a["os"], a["os_from"] = text, src

    for h in hosts:
        key = short_name(h.get("hostname"))
        if not key:
            continue
        a = get(key, h.get("hostname"))
        a["sources"].append("agent")
        a["agent"] = {"host_id": str(h["id"]), "version": h.get("agent_version"), "status": h.get("status"),
                      "last_checkin": h.get("last_checkin"), "os_id": h.get("os_id")}
        set_os(a, _agent_os(h), "agent", 3)
        add_ip(a, h.get("agent_ip"))
        seen(a, h.get("last_checkin"))
        by_host_id[str(h["id"])] = a

    # Powered-on VMs first: when a running VM and a powered-off copy share a name, the running one describes the machine
    vms = sorted(vms, key=lambda v: str(v.get("power_state") or "").lower() != "poweredon")
    for v in vms:
        a = by_host_id.get(str(v.get("host_id"))) if v.get("host_id") else None
        if a is None:
            key = short_name(v.get("guest_hostname")) or short_name(v.get("name"))     # a placeholder guest name falls back to the VM name
            if not key:
                continue
            a = get(key, v.get("guest_hostname") if short_name(v.get("guest_hostname")) else v.get("name"))
        if a["vm"] is not None:
            continue                                  # already described by a powered-on VM of the same name
        if "virtual" not in a["sources"]:
            a["sources"].append("virtual")
        a["vm"] = {"vcenter": v.get("vcenter"), "vcenter_host": vc_host.get(v.get("vcenter")) or v.get("vcenter"),
                   "vm_name": v.get("name"), "cluster": v.get("cluster"),
                   "esxi_host": v.get("esxi_host"), "power": v.get("power_state"), "cpu": v.get("num_cpu"),
                   "memory_mb": v.get("memory_mb"), "tools": v.get("tools_running"), "folder": v.get("folder_path"),
                   "created": v.get("create_date")}
        set_os(a, v.get("guest_os"), "virtual", 1)
        add_ip(a, v.get("guest_ips"))
        seen(a, v.get("synced_at"))

    for w in wsus:
        key = short_name(w.get("name"))
        if not key:
            continue
        a = get(key, w.get("name"))
        if "wsus" not in a["sources"]:
            a["sources"].append("wsus")
        prev = a["wsus"] or {}
        a["wsus"] = {"source": ", ".join(sorted({x for x in (prev.get("source"), w.get("source")) if x})),
                     "groups": w.get("groups") or [], "last_reported": w.get("last_reported"),
                     "needed": w.get("needed"), "failed": w.get("failed")}
        set_os(a, w.get("os"), "wsus", 2)
        add_ip(a, w.get("ip"))
        seen(a, w.get("last_reported"))

    for e in esxi:
        key = short_name(e.get("name"))
        if not key:
            continue
        a = get(key, e.get("name"))
        a["sources"].append("vcenter")
        a["esxi"] = {"vcenter": e.get("vcenter"), "vcenter_host": vc_host.get(e.get("vcenter")) or e.get("vcenter"),
                     "vendor": e.get("vendor"), "model_only": e.get("model"),
                     "cpu": " ".join(str(x) for x in (e.get("cpu_model"), f"({e.get('cpu_sockets')}x{e.get('cpu_cores') // max(1, e.get('cpu_sockets') or 1)} cores)"
                                                       if e.get("cpu_cores") and e.get("cpu_sockets") else None) if x) or None,
                     "memory_gb": round(e["memory_mb"] / 1024) if e.get("memory_mb") else None,
                     "cluster": e.get("cluster"), "model": " ".join(
            x for x in (e.get("vendor"), e.get("model")) if x), "version": e.get("esxi_full_name") or e.get("esxi_version"),
            "state": e.get("connection_state"), "vm_count": e.get("vm_count"), "maintenance": e.get("maintenance_mode")}
        a["os"] = a["os"] or (e.get("esxi_full_name") or "VMware ESXi")
        a["os_from"] = a["os_from"] or "vcenter"
        seen(a, e.get("synced_at"))

    for c in vcenters:
        key = short_name(c.get("host")) or short_name(c.get("name"))
        if not key:
            continue
        a = get(key, c.get("host") or c.get("name"))
        a["sources"].append("vcenter")
        a["vcenter"] = {"name": c.get("name"), "version": c.get("version"), "last_ok": c.get("last_ok")}
        a["os"] = a["os"] or ("VMware vCenter " + (c.get("version") or "")).strip()
        a["os_from"] = a["os_from"] or "vcenter"
        seen(a, c.get("last_sync_at"))

    for x in apex:
        key = short_name(x.get("host_name"))
        if not key:
            continue
        a = get(key, x.get("host_name"))
        if "apex" not in a["sources"]:
            a["sources"].append("apex")
        prev = a["apex"]
        # One machine in two consoles: the one that reports, or the latest
        if prev is None or (prev.get("not_reported") and not x.get("not_reported")):
            a["apex"] = {"console": x.get("console"), "product": x.get("product"), "os": x.get("os"),
                         "not_reported": bool(x.get("not_reported")), "last_connected": x.get("last_connected"),
                         "listed_at": x.get("last_seen")}
        set_os(a, x.get("os"), "apex", 2)
        add_ip(a, x.get("ip_addresses"))
        seen(a, x.get("last_connected"))

    # The uploaded sheet joins by name only: it never moves another source's data
    for m in manual:
        key = m.get("asset_key") or short_name(m.get("name"))
        if not key:
            continue
        a = get(key, m.get("name"))
        a["sources"].append("manual")
        a["manual"] = {"location": m.get("location"), "device": m.get("device"), "serial": m.get("serial"),
                       "manufacturer": m.get("manufacturer"), "model": m.get("model"),
                       "owner": m.get("owner"), "notes": m.get("notes"), "updated_at": m.get("updated_at"),
                       "updated_by": m.get("updated_by")}
        set_os(a, m.get("os"), "manual", 0)
        add_ip(a, m.get("ips"))

    out = []
    for a in assets.values():
        # Laptops and desktops: Apex tells Windows 10 from 11 better than WSUS (no agent on these)
        ax = a["os_by"].get("apex")
        # Never for a machine vCenter or WSUS report as a server: those are right as they are
        if ax and a["os_from"] not in ("agent", "apex") and classify(ax)[0] == "client" \
                and all(classify(t)[0] != "server" for k, t in a["os_by"].items() if k in ("wsus", "virtual")):
            a["os"], a["os_from"] = ax, "apex"
        a["sources"] = sorted(set(a["sources"]), key=lambda x: list(SOURCE_LABEL).index(x))
        a["hardware"] = hardware(a)
        a["category"], a["category_reason"], a["device_from"] = decide_type(a, overrides, ai_class, ai_types)
        a["managed"] = a["agent"] is not None
        a["gone"] = False
        a["powered_off"] = powered_off(a)
        a["location"], a["location_kind"] = _location(a)
        r = records.get(key_of(a)) or {}
        a["status"] = r.get("status") or "new"
        a["approved_by"], a["approved_at"] = r.get("approved_by"), r.get("approved_at")
        a["decom_by"], a["decom_at"], a["decom_reason"] = r.get("decom_by"), r.get("decom_at"), r.get("decom_reason")
        out.append(a)
    out.sort(key=lambda x: (CATEGORIES.index(x["category"]), x["name"].lower()))
    return out


SNAPSHOT_FIELDS = ("name", "category", "category_reason", "os", "ips", "location", "location_kind", "sources", "last_seen", "managed",
                   "hardware")


def snapshot(a):
    """What an asset looked like when it was approved or decommissioned, so it
    can still be shown when no source reports it any more."""
    return {k: (str(a.get(k)) if k == "last_seen" and a.get(k) is not None else a.get(k)) for k in SNAPSHOT_FIELDS}


def gone(records, present):
    """Approved and decommissioned machines that no source reports now,
    rebuilt from their snapshot."""
    out = []
    for k, r in records.items():
        snap = r.get("snapshot") or {}
        # approved, decommissioned, or taken back to New after a decision (it has a snapshot)
        if k in present or not (r.get("status") in ("approved", "decommissioned") or (r.get("status") == "new" and snap)):
            continue
        if isinstance(snap, str):
            import json as _json
            try:
                snap = _json.loads(snap)
            except ValueError:
                snap = {}
        cat = snap.get("category") if snap.get("category") in CATEGORIES else "unknown"
        out.append({"name": snap.get("name") or r.get("name") or k, "key": k, "sources": [], "os": snap.get("os"),
                    "os_from": None, "os_by": {}, "ips": clean_ips(snap.get("ips") or []), "agent": None, "vm": None,
                    "wsus": None, "esxi": None, "vcenter": None, "manual": None, "last_seen": snap.get("last_seen"),
                    "category": cat, "category_reason": snap.get("category_reason") or "as it was when last recorded",
                    "device_from": "snapshot", "managed": False, "location": snap.get("location") or "",
                    "location_kind": snap.get("location_kind") or "", "gone": True, "hardware": snap.get("hardware") or {},
                    "powered_off": False,
                    "status": r["status"], "approved_by": r.get("approved_by"), "approved_at": r.get("approved_at"),
                    "decom_by": r.get("decom_by"), "decom_at": r.get("decom_at"), "decom_reason": r.get("decom_reason")})
    return out


def decide_type(a, overrides=None, ai_class=None, ai_types=None):
    """(type, reason, from) for one merged machine. In order: a person's
    choice, vCenter's facts, the OS (unless only a weak guess), the sheet's
    device column, the name, AI-01. A sheet saying firewall, network, ESXi or
    appliance beats an OS-based "server" unless our agent runs on it or it
    runs Windows (an agent or Windows is proof it is a server)."""
    k = key_of(a)
    ov = (overrides or {}).get(k)
    if ov in CATEGORIES:
        return ov, "set by a person", "person"
    kind = "esxi" if a["esxi"] else "vcenter" if a["vcenter"] else None
    cat, why = classify(a["os"], kind)
    if kind:
        return cat, why, "vcenter"
    sheet = (a.get("manual") or {}).get("device")
    # Proof it is a server or PC: our agent runs on it, or WSUS, Apex or its OS says Windows.
    # With proof, the sheet, the name and AI-01 can only choose between server and laptop/desktop.
    proof = a.get("agent") is not None or bool(a.get("wsus")) or bool(a.get("apex")) or "windows" in (a.get("os") or "").lower()
    allowed = EXPECTED_PATCHED if proof else CATEGORIES
    if cat != "unknown" and not weak(why):
        if sheet in ("firewall", "network", "esxi", "appliance") and cat == "server" and not proof:
            return sheet, "as given in the uploaded sheet (the OS alone does not show it is a server)", "manual"
        return cat, why, "rules"
    if sheet in allowed and sheet != "unknown":
        return sheet, "as given in the uploaded sheet", "manual"
    if cat == "unknown":                              # a name is a hint only when nothing else says anything
        hint = name_hint(a.get("name"))
        if hint in allowed:
            return hint, "from the name (" + (a.get("name") or "")[:40] + ")", "name"
    ai = (ai_class or {}).get(k) or {}
    if ai.get("device") in allowed and ai["device"] != "unknown" and ai.get("features") == ai_features_hash(a):
        return ai["device"], "AI-01: " + (ai.get("reason") or "from the name, OS and sources")[:120], "ai"
    old = (ai_types or {}).get((a.get("os") or "").strip().lower())
    if old in allowed and old != "unknown":
        return old, "AI-01, from the OS name (" + (a.get("os") or "")[:40] + ")", "ai"
    if cat not in allowed or (cat == "unknown" and a.get("agent") is not None):
        # Proof says server or PC but the OS text is generic: our agent only runs on servers
        return ("server", "our agent runs on it", "rules") if a.get("agent") is not None else ("unknown", why, "rules")
    return cat, why, "rules"


def ai_features(a):
    """What AI-01 is shown about one machine (cleaned and cut to size), and
    whose hash tells when to ask again."""
    def clean(v, n):
        t = re.sub(r"[\x00-\x1f\x7f]", " ", str(v or "")).replace('"""', "'''")
        return re.sub(r"\s+", " ", t).strip()[:n]
    hw = a.get("hardware") or {}
    return "; ".join([f"name {clean(a.get('name'), 60)}",
                      f"OS {clean(a.get('os') or 'none', 80)}",
                      f"sheet type {clean((a.get('manual') or {}).get('device') or 'none', 20)}",
                      f"make/model {clean(' '.join(x for x in (hw.get('manufacturer'), hw.get('model')) if x) or 'none', 80)}",
                      "virtual machine" if a.get("vm") else "not a VM in vCenter",
                      "seen by " + ", ".join(SOURCE_LABEL.get(x, x) for x in sorted(set(a.get("sources") or [])))])


def ai_features_hash(a):
    import hashlib
    return hashlib.sha256(ai_features(a).encode()).hexdigest()


def powered_off(a, now=None):
    """A VM that vCenter reports powered off or suspended, and that our agent
    has not reported from in the last 7 days. Kept apart from the master list."""
    import datetime as _dt
    vm = a.get("vm") or {}
    if str(vm.get("power") or "").lower() not in ("poweredoff", "suspended"):
        return False
    seen = (a.get("agent") or {}).get("last_checkin")
    if seen:
        try:
            t = seen if isinstance(seen, _dt.datetime) else _dt.datetime.fromisoformat(str(seen).replace("Z", "+00:00"))
            t = t if t.tzinfo else t.replace(tzinfo=_dt.timezone.utc)
            if ((now or _dt.datetime.now(_dt.timezone.utc)) - t).days < 7:
                return False
        except ValueError:
            pass
    return True


def hardware(a):
    """What is known about the physical machine: vCenter for ESXi hosts, the
    uploaded sheet for anything else."""
    es, ma = a.get("esxi") or {}, a.get("manual") or {}
    return {"manufacturer": ma.get("manufacturer") or es.get("vendor") or None,
            "model": ma.get("model") or es.get("model_only") or None,
            "serial": ma.get("serial") or None, "cpu": es.get("cpu"), "memory_gb": es.get("memory_gb"),
            "physical": not a.get("vm") and not a.get("vcenter")}


def key_of(a):
    """The asset's key when it is safe to store, else None."""
    k = (a.get("key") or "").lower()
    return k if KEY_RE.match(k) else None


def _location(a):
    """(text, kind). A VM is where its vCenter is; anything else is told
    apart by its type: Windows 10/11 and macOS are laptops or desktops."""
    if a["vm"]:
        return a["vm"].get("vcenter_host") or a["vm"].get("vcenter") or "vCenter", "virtual"
    if a["esxi"]:
        return "ESXi host · " + (a["esxi"].get("vcenter_host") or a["esxi"].get("vcenter") or ""), "esxi"
    if a["vcenter"]:
        return "vCenter appliance", "vcenter"
    given = ((a["manual"] or {}).get("location") or "").strip()
    if given:
        return given, "manual"
    return {"client": "Laptop/Desktop", "server": "Physical server", "appliance": "Appliance"}.get(a["category"], ""), "physical"


def findings(assets, now=None, stale_days=30):
    """What does not add up across the sources. Pure: no changes are made.
    Each finding names the assets it is about, so it can be checked."""
    import datetime as _dt
    now = now or _dt.datetime.now(_dt.timezone.utc)
    out = []

    def ts(v):
        if v is None:
            return None
        if isinstance(v, _dt.datetime):
            return v if v.tzinfo else v.replace(tzinfo=_dt.timezone.utc)
        try:
            d = _dt.datetime.fromisoformat(str(v).replace("Z", "+00:00"))
            return d if d.tzinfo else d.replace(tzinfo=_dt.timezone.utc)
        except ValueError:
            return None

    active = [a for a in assets if a["status"] != "decommissioned"]
    by_ip = {}
    for a in active:
        for ip in a["ips"]:
            by_ip.setdefault(ip, []).append(a["name"])
    dup = {ip: names for ip, names in by_ip.items() if len(set(n.lower() for n in names)) > 1}
    if dup:
        out.append({"kind": "shared_ip", "level": "warn", "title": "One address, several names",
                    "text": f"{len(dup)} address{'es are' if len(dup) != 1 else ' is'} used by more than one name: "
                            "the same machine under two names, or an address that moved.",
                    "items": [f"{ip}: {', '.join(sorted(set(n)))}" for ip, n in sorted(dup.items())][:50]})
    os_clash = []
    for a in active:
        fams = {src: _os_family(t) for src, t in a["os_by"].items() if _os_family(t)}
        if len(set(fams.values())) > 1:
            os_clash.append(f"{a['name']}: " + ", ".join(f"{SOURCE_LABEL.get(s, s)} says {a['os_by'][s]}" for s in fams))
    if os_clash:
        out.append({"kind": "os_conflict", "level": "warn", "title": "Sources disagree on the OS",
                    "text": f"{len(os_clash)} machine{'s' if len(os_clash) != 1 else ''}: one source reports Windows, another Linux.",
                    "items": os_clash[:50]})
    only_sheet = [a["name"] for a in active if a["sources"] == ["manual"]]
    if only_sheet:
        out.append({"kind": "sheet_only", "level": "info", "title": "Only in the uploaded sheet",
                    "text": f"{len(only_sheet)} machine{'s are' if len(only_sheet) != 1 else ' is'} in the sheet but no agent, "
                            "vCenter or WSUS reports {0}: check the name, or whether {0} still exist{1}."
                            .format("them" if len(only_sheet) != 1 else "it", "" if len(only_sheet) != 1 else "s"),
                    "items": sorted(only_sheet)[:50]})
    stale = []
    for a in active:
        if a["status"] != "approved":
            continue
        t = ts(a["last_seen"])
        if a.get("gone"):
            stale.append(f"{a['name']}: no source reports it any more" + (f" (last detected {t.date().isoformat()})" if t else ""))
        elif any(s in LIVE_SOURCES for s in a["sources"]) and t and (now - t).days >= stale_days:
            stale.append(f"{a['name']}: last detected {t.date().isoformat()}")
    if stale:
        out.append({"kind": "stale", "level": "info", "title": f"Approved, not detected for {stale_days} days",
                    "text": f"{len(stale)} approved machine{'s have' if len(stale) != 1 else ' has'} not been reported by any source "
                            f"for {stale_days} days or more, or at all now: candidates to decommission.",
                    "items": stale[:50]})
    back = []
    for a in assets:
        if a["status"] == "decommissioned":
            t, d = ts(a["last_seen"]), ts(a["decom_at"])
            if t and d and t > d and any(s in LIVE_SOURCES for s in a["sources"]):
                back.append(f"{a['name']}: decommissioned {d.date().isoformat()}, detected again {t.date().isoformat()}")
    if back:
        out.append({"kind": "seen_again", "level": "bad", "title": "Decommissioned, but still detected",
                    "text": f"{len(back)} decommissioned machine{'s are' if len(back) != 1 else ' is'} still reported by a source "
                            "after the decommission date: still running, or the name was reused.",
                    "items": back[:50]})
    unk = [a["name"] + (" (" + a["os"] + ")" if a["os"] else "") for a in active if a["category"] == "unknown"]
    if unk:
        out.append({"kind": "unknown_type", "level": "info", "title": "Device type unknown",
                    "text": f"{len(unk)} machine{'s' if len(unk) != 1 else ''} with no OS, or one that neither the rules nor AI-01 could place.",
                    "items": sorted(unk)[:50]})
    return out


def optional_q(conn, sql, fallback):
    """A query with a column a later schema adds, falling back to the older shape."""
    try:
        with conn.transaction():
            return conn.execute(sql).fetchall()
    except Exception as e:  # noqa: BLE001
        if type(e).__name__ not in ("UndefinedColumn", "UndefinedTable"):
            raise
    return conn.execute(fallback).fetchall()


def load_assets(conn):
    """Read every source and merge. Read-only. Decommissioned machines are
    included, marked; the pages filter them."""
    hosts = conn.execute(
        """SELECT id, hostname, os_id, os_version, os_edition, agent_version, status::text AS status,
                  last_checkin, host(agent_ip) AS agent_ip
             FROM hosts WHERE status <> 'decommissioned'""").fetchall()
    vms = optional_q(conn,
        """SELECT vcenter, name, guest_hostname, guest_os, guest_ips, power_state, cluster, esxi_host,
                  num_cpu, memory_mb, tools_running, folder_path, host_id, synced_at, create_date FROM vm_inventory""",
        """SELECT vcenter, name, guest_hostname, guest_os, guest_ips, power_state, cluster, esxi_host,
                  num_cpu, memory_mb, tools_running, folder_path, host_id, synced_at FROM vm_inventory""")
    wsus = conn.execute(
        "SELECT source, name, ip, os, groups, last_reported, needed, failed FROM wsus_computers").fetchall()
    esxi = conn.execute(
        """SELECT name, vcenter, cluster, vendor, model, esxi_version, esxi_full_name, connection_state,
                  maintenance_mode, vm_count, synced_at, cpu_model, cpu_sockets, cpu_cores, memory_mb FROM esxi_hosts""").fetchall()
    vcs = conn.execute("SELECT name, host, version, last_ok, last_sync_at FROM vcenters").fetchall()
    apex = _apex_rows(conn)
    def optional(sql, fallback=None):
        """A query on tables a later schema adds: an older database gives nothing (or the fallback)."""
        for q in ([sql] + ([fallback] if fallback else [])):
            try:
                with conn.transaction():
                    return conn.execute(q).fetchall()
            except Exception as e:  # noqa: BLE001
                if type(e).__name__ not in ("UndefinedTable", "UndefinedColumn"):
                    raise
        return []

    manual = optional("""SELECT asset_key, name, ips, os, device, location, serial, owner, notes, manufacturer, model,
                                updated_at, updated_by FROM manual_assets""",
                      """SELECT asset_key, name, ips, os, device, location, serial, owner, notes, updated_at, updated_by
                           FROM manual_assets""")
    records = {r["asset_key"]: dict(r) for r in optional(
        """SELECT asset_key, name, status, approved_by, approved_at, decom_by, decom_at, decom_reason, snapshot
             FROM asset_records""")}
    ai = {r["os_key"]: r["device"] for r in optional("SELECT os_key, device FROM asset_ai_types")}
    overrides = {r["asset_key"]: r["device"] for r in optional("SELECT asset_key, device FROM asset_type_overrides")}
    ai_class = {r["asset_key"]: dict(r) for r in optional("SELECT asset_key, device, reason, features FROM asset_ai_class")}
    assets = merge(hosts, vms, wsus, esxi, vcs, manual, records, ai, apex, overrides, ai_class)
    assets += gone(records, {a["key"] for a in assets})
    vc_host = {c["name"]: c["host"] for c in vcs}
    templates = [dict(t, vcenter_host=vc_host.get(t["vcenter"]) or t["vcenter"]) for t in optional(
        """SELECT vcenter, moref, name, guest_os, folder_path, datacenter, cluster, esxi_host, num_cpu, memory_mb,
                  storage_mb, hardware_version, annotation, create_date, synced_at FROM vm_templates ORDER BY lower(name)""")]
    return {"assets": assets, "templates": templates,
            "summary": summarise([a for a in assets if a["status"] != "decommissioned" and not a.get("powered_off")]),
            "sources": {"agents": len(hosts), "vms": len(vms), "wsus": len(wsus), "esxi": len(esxi), "vcenters": len(vcs),
                        "manual": len(manual), "apex": len(apex)}}


APEX_SQL = """
SELECT a.host_name, a.ip_addresses, a.product, {os} AS os, a.last_connected, a.last_seen, c.name AS console,
       (NOT c.enabled OR a.last_seen < now() - interval '48 hours'
        OR coalesce(c.last_sync_ok AND a.last_seen < c.last_sync_at - interval '1 minute', false)
        OR a.online IS FALSE
        OR coalesce(a.last_connected < now() - interval '48 hours', false)) AS not_reported
  FROM av_agents a JOIN av_consoles c ON c.id = a.console_id
  {join}
 WHERE coalesce(a.host_name, '') <> ''"""
APEX_JOIN = """LEFT JOIN LATERAL (SELECT p.os FROM av_pattern_status p
                    WHERE p.console_id = a.console_id AND p.os IS NOT NULL
                      AND lower(split_part(p.host_name, '.', 1)) = lower(split_part(a.host_name, '.', 1))
                    ORDER BY p.seen_at DESC LIMIT 1) ps ON true"""


def _apex_rows(conn):
    """Apex Central's agents, with the OS from the agent list (schema 031) or
    the Pattern Update Status log (schema 029), whichever is there."""
    for os_expr, join in (("coalesce(a.os, ps.os)", APEX_JOIN), ("ps.os", APEX_JOIN), ("NULL::text", "")):
        try:
            with conn.transaction():
                return [dict(r) for r in conn.execute(APEX_SQL.format(os=os_expr, join=join)).fetchall()]
        except Exception as e:  # noqa: BLE001
            if type(e).__name__ not in ("UndefinedTable", "UndefinedColumn"):
                raise
    return []


def summarise(assets):
    """Counts per category: total, with an agent, without."""
    s = {c: {"total": 0, "managed": 0, "unmanaged": 0} for c in CATEGORIES}
    for a in assets:
        c = s[a["category"]]
        c["total"] += 1
        c["managed" if a["managed"] else "unmanaged"] += 1
    return s
