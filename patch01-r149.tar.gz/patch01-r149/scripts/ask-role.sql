-- The agent's own login (r147), applied by phase3a-schema.sh after the migrations, and by the tests.
-- patch_ask may read the views of schema ask (sql/zz-ask-views.sql) and nothing else: no table of schema public, no
-- function of its own, no other role. Read-only by default; each of its queries is also checked (app/ask_sql.py).
-- Its password is set by phase3a-schema.sh, from ask-db.env. psql -v api_role=<the API's login> (default patchapi).
\if :{?api_role}
\else
  \set api_role patchapi
\endif
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'patch_ask') THEN
    CREATE ROLE patch_ask LOGIN;
  END IF;
END $$;
ALTER ROLE patch_ask LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT CONNECTION LIMIT 4;
ALTER ROLE patch_ask SET default_transaction_read_only = on;
ALTER ROLE patch_ask SET statement_timeout = '8s';
ALTER ROLE patch_ask SET idle_in_transaction_session_timeout = '30s';
ALTER ROLE patch_ask SET search_path = ask;
-- what one query may use on the database server: memory per sort or hash, and temporary files
ALTER ROLE patch_ask SET work_mem = '16MB';
ALTER ROLE patch_ask SET temp_file_limit = '256MB';
-- no role of its own to become
DO $$
DECLARE r record;
BEGIN
  FOR r IN SELECT g.rolname FROM pg_auth_members m JOIN pg_roles g ON g.oid = m.roleid
            JOIN pg_roles u ON u.oid = m.member WHERE u.rolname = 'patch_ask' LOOP
    EXECUTE format('REVOKE %I FROM patch_ask', r.rolname);
  END LOOP;
END $$;
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM patch_ask;
GRANT USAGE ON SCHEMA ask TO patch_ask;
GRANT SELECT ON ALL TABLES IN SCHEMA ask TO patch_ask;
REVOKE ALL ON ask.catalog FROM patch_ask;
-- the API reads what each view holds, to tell the agent
GRANT USAGE ON SCHEMA ask TO :"api_role";
GRANT SELECT ON ask.catalog TO :"api_role";
