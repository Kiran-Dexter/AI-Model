# File shares: setting up the scanner and the access review (r146, r149)

Vulnerabilities > File shares shows who owns each share and folder on your file servers, and who can reach it.
A small read-only scanner, `access-scan.ps1`, runs on each file server. The PATCH-01 agent already installed there
starts it when you press **Scan now**. **The agent itself is not updated.**

The scanner only reads: shares, share permissions, NTFS permissions of folders (never files), and group members
from Active Directory. It never changes a permission, a file or a share.

## 1. Sign the scanner (if your agents are signed)

A signed agent starts only a signed scanner. In the folder that holds the agent's files (`client\windows`):

```powershell
.\Sign-Agent.ps1
```

It signs every `.ps1` in the folder, `access-scan.ps1` included, with the certificate you sign the agent with.

## 2. Copy it to each file server

Copy `access-scan.ps1` next to `patch-agent.ps1`, in the agent's folder (normally `C:\Program Files\PatchAgent\`).
Replace any older `access-scan.ps1` there: the one from r120–r128 (version 1.x) sends to an address PATCH-01 no
longer has. The new one's first lines say **2.0.1** (2.0.0 stopped at the end of a scan: copy 2.0.1 over it).

## 3. Try it once, by hand (sends nothing)

As administrator, on the file server:

```powershell
& "C:\Program Files\PatchAgent\access-scan.ps1" -DryRun -MaxFolders 5000
```

It reads the shares (at most 5,000 folders with `-MaxFolders`; leave it out to read everything) and prints what it
found: shares, folders read, folders listed, unreadable folders, links skipped, accounts, memberships, whether
Active Directory answered, and the time it took. It sends nothing. The figures and the first 200 accounts are also
written to `%TEMP%\access-scan-dryrun.json`. One share only: `-Share Finance`.

## 4. Scan from the page

Vulnerabilities > File shares: **Add to the audit** for each file server, then **Scan now**. The page follows the
scan. A big server can take a while. Its log on the server is `C:\ProgramData\PatchAgent\access-scan.log`.

## 5. Tick the drives to review

Each server's line, at the top of the page, shows the drives the scan read (D:, E:…), each with a tick. Untick a
drive to leave it out of the review: its folders are not compared and its rows leave the lists and the reports.

## 6. Upload the access review workbook (r149)

**Upload access review workbook** (.xlsx). Its three sheets:

- **Folder:** one row per account per folder: Path, Relative Path, Account Type, Account, Display Name, Type
  (Allow or Deny), Permission (simple), Department, and the four columns you fill: Recommended Change to, Feedback
  from Users, Status, Remarks. The columns are found by their headers, even written with small typos; a drop-down
  is shown only for a header that was not recognised.
- **Member Listing:** Group, Account Type, Member (names split on `,` `;` or a new line), Members Name.
- **Description:** not read.

Choose the server it is for, or **All servers** (together), then **Use the workbook**. Each Folder row is matched to a
scanned folder by its **Path** (with the drive letter) and, when that is not found, by its **Relative Path** (without
it). Then each is compared with what the scan found on that folder for that account:

| Result | Means |
|---|---|
| Same | The folder gives the account what the sheet says. |
| Changed | The account is on the folder, with another permission. |
| Gone | The sheet lists the account; the folder no longer gives it anything. |
| New | On the folder, and not in the sheet (SYSTEM and Administrators too). |
| Folder not found | No scanned share holds that folder. |
| Not scanned yet | The folder is below what the scan lists: the next scan reads it (press **Scan now**). |
| Found twice | On two servers (All servers): choose which one in the row's panel. |

**Access** lists what needs you (Changed, Gone, New, Folder not found, Found twice), or all of it. Click a row: the
panel shows the folder's permissions, what the account really gets (share, NTFS, effective), and the four columns,
saved as you type. A new upload of the workbook keeps what was filled for the rows it has again, on the same
server; what users wrote in the workbook you sent back to them wins over the page, column by column. **Groups** shows each
group of Member Listing beside the same group in Active Directory, member by member; pair by hand the names written
differently, or mark one "not in AD". **Report**: the figures, and **Export Excel** (your Folder sheet back, the four
columns filled, with the result of each row; then New access, Groups and a Summary) or **Export PDF**.

The ownership workbook of r146 is no longer used on the page: an upload without a Folder sheet is said to be one.

## What is left out

- The administrative shares (C$, ADMIN$, IPC$), print$, SYSVOL and NETLOGON.
- Every share on the system drive.
- Windows' own folders at the root of a volume (System Volume Information, $RECYCLE.BIN), and DFS Replication's
  hidden DfsrPrivate folders.
- Links (junctions, mount points), which are not followed. A folder whose attributes Windows will not give is not
  opened either (it could be a link), and is counted.
- A share inside another share is read once, as itself, not twice.
- Two shares on the same folder (`Data` and `Data$`) are read once, as the first. The summary names the second:
  its own share permissions are not counted in the rights shown, so check them on the server.
- Folders more than 64 levels down, and folders whose path is longer than 4,000 characters (with what is below).
- Files: only folders are read.
- A scan stops walking after 10 hours and sends what it read.

Every one of these that happened is counted, and the summary (page, PDF and Excel) says so under **What the last
scan could not cover**.

## Check by hand on your servers

The scanner was tested against PATCH-01 here, but not on a Windows file server. These points can only be checked on
yours, once, with the dry run (step 3):

1. **The shares and figures.** The dry run's `shares` must be the number of shares you expect to audit. Compare a
   few folders' permissions with the folder's Security tab.
2. **Long paths.** If you have paths longer than 260 characters, run the dry run on that share (`-Share <name>`)
   and check the log has no "could not be read" for them.
3. **Folders that refuse SYSTEM.** The agent runs as SYSTEM, which cannot read a folder whose permissions leave
   SYSTEM and Administrators out. Those folders are listed under **Could not be read**: that is the real state of
   the folder, not a fault of the scan.
4. **Volumes mounted in a folder** on C: are not read (C: is left out). If a data volume is mounted that way rather
   than with a drive letter, tell us.
5. **A very big server.** If the agent's task settings stop a task after a time limit, a long scan can be stopped
   with it. The page then shows the scan as stalled. Its log is `C:\ProgramData\PatchAgent\access-scan.log`.
6. **Active Directory.** `ad` in the dry run must say `read`. `not reached` means the server could not reach a
   domain controller, so group members are missing.
7. **Local groups.** Pick a local group of the server that holds domain groups (in a folder's permissions) and
   check, on the page's Permissions tab, that its people are the ones Computer Management shows.
8. **An account of a trusted domain that is out of reach** may show as an orphaned SID rather than "not looked
   up". Check any orphaned SID on the page before removing it. In a forest with more than one tree, check that
   an account of the other tree shows its name.
9. **A scan stopped halfway** (the server restarted, say): the next Scan now must start normally. If the page
   says "another scan is running" with none running, tell us.
