# The assistant's agent (r147)

The Cyber-Secure assistant (the round button at the bottom right of every page) now answers questions in **steps**.
It runs one of the assistant's prepared questions or writes a read-only query of its own, looks at the result, and
takes the next step: at most 4 steps, then it answers. Each step is shown as it is taken, with its query and its
rows, under **How it found this**.

It only **reads**. It cannot patch, restart, change, send mail or open tickets: it has no way to. "Export that" and
"mail it" work as before (Export CSV, and an e-mail draft that is sent only when you press Send).

## What it can read

Everything in PATCH-01's database except secrets, through views made for it (schema `ask`, `sql/zz-ask-views.sql`):

- **Never:** passwords and their hashes, two-factor keys, sign-in sessions, agent and enrolment tokens, the keys of
  Nessus, the antivirus consoles, Carbon Black, the mail relay and the proxy, uploaded files, and the data of the
  Access review removed in r129.
- **Only what you can see in the console:** the rows of your modules (Patch, Inventory, Lifecycle), changes of the
  kinds your modules may see, and the audit log as the Audit page shows it to you. What only admins see in the
  console (users, settings, mail, repositories, uploaded asset workbooks, the CVE feeds' watch words) is for admins
  only here too; Deployment uploads, which each person sees only their own of, are not shown at all.

Its own queries run under a database login of their own, `patch_ask`, which can read those views and nothing else.
Before a query runs, PostgreSQL itself is asked what it uses: any table that is not one of your views, and any
function that could change something, stops it. A query runs at most 8 seconds and returns at most 200 rows, none
over 64 KB; a long value is cut to 2,000 characters.

## Its answers

AI-01 writes the answer from the results. It is shown only if every number, server name, CVE, KB and change number
in it appears in the results. Otherwise PATCH-01 says what was found, in its own words, and says so under the answer.
The tables are always shown.

Text from the servers (host names, program names, log lines) reaches AI-01 marked as data to read, never as
instructions.

## Setting it up

Nothing to do beyond the usual install steps, in order:

```bash
./scripts/phase3a-schema.sh
```
```bash
./scripts/phase3b-api.sh
```

`phase3a-schema.sh` makes the agent's login and its password (`/patch/secrets/ask-db.env`, kept in Vault with the
other secrets when Vault is on). It proves that the login reads the views and **cannot** read the tables themselves,
and stops if it can. `phase3b-api.sh` gives the password to the API, and stops if `phase3a-schema.sh` has not run.

Without AI-01, the assistant answers as before, from the prepared questions, by keywords.

## AI-01

The agent uses AI-01's current model (Qwen3-8B). A bigger model later needs no change on PATCH-01: copy it to AI-01
and run its setup again.

Each request to AI-01 holds 4,096 tokens by default. The agent works within that, but longer chains of steps fit
better with 8,192. On AI-01, if it has about 2.5 GB of RAM to spare:

```bash
./ai01-setup.sh --ctx 16384
```

## Limits

- At most 4 steps, then it answers from what it has. An answer can take a minute or two on a CPU.
- One question at a time per person, at most 60 in 10 minutes (the assistant's limit).
- Questions and their steps are kept 30 days, each visible only to the person who asked.
- An 8-billion-parameter model gets simple questions right, two or three steps usually, long chains less often. When
  it cannot answer, it says so; it never makes a figure up (see Its answers).

## Check by hand, once

1. Ask "how many servers do we have?" and open **How it found this**: the query and its rows are there.
2. Ask, as an operator, "list the console users": the step says the view is not one you may see.
3. Admin > Audit: each question is logged (`chat_query` when asked, `chat_agent` with its steps and queries).

The agent's queries were tested here against PostgreSQL 16 through psql, not through the API's own driver (psycopg),
which this test environment does not have. If the driver behaved differently, a query would fail and say so in its
step; it would not run with fewer checks. Question 1 above shows it works.
