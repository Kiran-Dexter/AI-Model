"""File shares (r149): the access review workbook, compared with the scan.

The workbook has three sheets. Folder: one row per account per folder (Path, Relative Path, Account Type, Account,
Display Name, Type, Permission (simple), Department, and four columns the person fills: Recommended Change to,
Feedback from Users, Status, Remarks). Member Listing: each group's members. Description: not read.

Each Folder row is found on the server by its Path (the drive letter included) and, when that finds nothing, by its
Relative Path (without the letter); then its account is compared with the folder's permissions as the last scan read
them:
  same         the account has that access
  changed      it has access, at another level (found says which)
  gone         it has no entry on that folder any more
  new          (rows the scan adds) an account on the folder the sheet does not list
  not_found    no such folder on the server (the scanner looked and it is not there)
  not_scanned  the folder was not read yet: the next scan looks for it
  twice        the Relative Path is on two drives or two servers: the person chooses
Only folders on the drives the person ticked count. Nothing here changes a server.
"""

import difflib
import json
import re

from . import file_shares as fs

RESULTS = ("same", "changed", "gone", "new", "not_found", "not_scanned", "twice")
LEFT_OUT = "left_out"                      # on a drive that is not ticked: in no list or count, only in the Excel given back
NEEDS_YOU = ("changed", "gone", "new", "not_found", "twice")
RESULT_LABEL = {"left_out": "Left out (drive not ticked)", "same": "Same", "changed": "Changed", "gone": "Gone", "new": "New", "not_found": "Folder not found",
                "not_scanned": "Not scanned yet", "twice": "Found twice"}
FILL = ("recommended", "feedback", "status", "remarks")
FILL_LABEL = {"recommended": "Recommended Change to", "feedback": "Feedback from Users", "status": "Status",
              "remarks": "Remarks"}

# ---------------------------------------------------------------------------
# The sheets and their columns, by their headers (forgiving a typo)
# ---------------------------------------------------------------------------
FOLDER_FIELDS = ("path", "rel", "account_type", "account", "display", "ace_type", "permission", "department") + FILL
FOLDER_LABEL = {"path": "Path", "rel": "Relative Path", "account_type": "Account Type", "account": "Account",
                "display": "Display Name", "ace_type": "Type", "permission": "Permission (simple)",
                "department": "Department", **FILL_LABEL}
FOLDER_SYN = {
    "path": ["path", "full path", "folder path"],
    "rel": ["relative path", "rel path", "relativepath"],
    "account_type": ["account type", "trustee type", "principal type", "object type"],
    "account": ["account", "account name", "trustee", "identity", "principal", "user or group"],
    "display": ["display name", "displayname", "full name"],
    "ace_type": ["type", "access type", "ace type", "allow deny"],
    "permission": ["permission simple", "permission", "permissions", "rights", "access", "access rights"],
    "department": ["department", "dept", "division"],
    "recommended": ["recommended change to", "recommended change", "recommendation", "change to"],
    "feedback": ["feedback from users", "user feedback", "feedback"],
    "status": ["status"],
    "remarks": ["remarks", "remark", "comments", "comment", "notes"],
}
LIST_FIELDS = ("group", "account_type", "member", "members_name")
LIST_LABEL = {"group": "Group", "account_type": "Account Type", "member": "Member", "members_name": "Members Name"}
LIST_SYN = {
    "group": ["group", "group name", "groups"],
    "account_type": ["account type", "type"],
    "member": ["member", "members", "member account", "account"],
    "members_name": ["members name", "member name", "members names", "member names", "name", "display name"],
}
REQUIRED_FOLDER = ("account",)            # and path or rel


def norm(h):
    return re.sub(r"[^a-z0-9]+", " ", (h or "").lower()).strip()


def sheet_role(name):
    n = norm(name)
    if n.startswith("folder"):
        return "folder"
    if "member" in n:
        return "members"
    if n.startswith("descr") or n.startswith("disc"):
        return "ignored"
    return None


def guess(headers, fields, syn):
    """field -> column index: an exact header first, then one within a typo of it (difflib 0.85)."""
    heads = [norm(h) for h in headers]
    out, used = {}, set()
    # the longer names first, so "account type" is not taken by "type", nor "relative path" by "path"
    order = sorted(((f, s) for f in fields for s in syn.get(f, [])), key=lambda x: -len(x[1]))
    for exact in (True, False):
        for f, s in order:
            if f in out:
                continue
            for i, h in enumerate(heads):
                if i in used or not h:
                    continue
                if (h == s) if exact else (len(s) > 4 and difflib.SequenceMatcher(None, h, s).ratio() >= 0.85):
                    out[f] = i
                    used.add(i)
                    break
    return out


def header_index(rows, fields, syn):
    """Among the first 15 rows, the one whose cells name the most fields."""
    best, score = 0, -1
    for i, r in enumerate(rows[:15]):
        n = len(guess(r, fields, syn))
        if n > score:
            best, score = i, n
    return best


def cell(cells, mapping, f):
    i = mapping.get(f)
    return (cells[i] if i is not None and i < len(cells) else "").strip()[:2000]


# ---------------------------------------------------------------------------
# Permissions as the sheet writes them, and as the scan found them
# ---------------------------------------------------------------------------
LEVEL_WORDS = {
    "full control": "Full control", "full": "Full control", "fullcontrol": "Full control", "fc": "Full control",
    "modify": "Modify", "change": "Modify", "m": "Modify",
    "read execute": "Read & execute", "read and execute": "Read & execute", "readandexecute": "Read & execute",
    "rx": "Read & execute", "list folder contents": "Read & execute", "list": "Read & execute",
    "read": "Read", "r": "Read", "write": "Write", "w": "Write",
    "special": "Special", "special permissions": "Special",
}


def level_word(text):
    """The sheet's permission as one of the levels Windows' Security tab shows (or the text, cleaned, when it is none)."""
    n = norm(text)
    return LEVEL_WORDS.get(n) or LEVEL_WORDS.get(n.replace(" ", "")) or (text or "").strip()


def ace_word(text):
    n = norm(text)
    return "Deny" if n.startswith("deny") else "Allow"


def account_keys(text):
    """How an account may be written: DOMAIN\\name, name@domain, name; all lower case."""
    t = (text or "").strip().lower()
    out = {t} if t else set()
    if "\\" in t:
        out.add(t.rsplit("\\", 1)[1])
    if "@" in t:
        out.add(t.split("@", 1)[0])
    return {x for x in out if x}


def split_names(text):
    return [x.strip() for x in re.split(r"[,;\n]+", text or "") if x.strip()]


def drive_of(key):
    m = re.match(r"^([a-z]):", key or "")
    return m.group(1) + ":" if m else None


def rel_of(key):
    """d:\\dept\\group -> \\dept\\group (d:\\ -> \\)."""
    k = fs.key_of(key)
    return k[2:] if re.match(r"^[a-z]:", k) else (k if k.startswith("\\") else "\\" + k)


def rel_text(path):
    """D:\\Dept\\Group -> \\Dept\\Group, as the server writes it."""
    p = (path or "").replace("/", "\\")
    p = p[2:] if re.match(r"^[A-Za-z]:", p) else p
    return p if p.startswith("\\") else "\\" + p


def rel_key(text):
    t = fs.key_of(text)
    if re.match(r"^[a-z]:", t):
        t = t[2:]
    if not t.startswith("\\"):
        t = "\\" + t
    return t.rstrip("\\") or "\\"


# ---------------------------------------------------------------------------
# The scans, as the comparison needs them
# ---------------------------------------------------------------------------
# Everyone, NT AUTHORITY\SYSTEM (and SYSTEM), BUILTIN\Administrators (and Administrators)...
WELL_KNOWN_BY_NAME = {}
for _sid, _name in fs.WELL_KNOWN.items():
    for _k in account_keys(_name):
        WELL_KNOWN_BY_NAME.setdefault(_k, _sid)


class Scan:
    """One server's last scan: its folders by key and by path without the drive letter, its accounts by name."""

    def __init__(self, host, scan, folders, principals, shares, audited):
        self.host, self.scan = host, scan
        self.audited = audited                    # drive -> bool
        self.drives = {d for d in (drive_of(f["path_key"]) for f in folders) if d}
        self.folders = {f["path_key"]: f for f in folders if self.drive_on(f["path_key"])}
        self.by_rel = {}
        for k in self.folders:
            self.by_rel.setdefault(rel_key(k), []).append(k)
        self.principals = principals
        self.by_name, self.by_display = {}, {}
        for sid, p in principals.items():
            for k in account_keys(p.get("name") or ""):
                self.by_name.setdefault(k, set()).add(sid)
            d = (p.get("display") or "").strip().lower()
            if d:
                self.by_display.setdefault(d, set()).add(sid)
        self.missing = {fs.key_of(m) for m in ((scan or {}).get("totals") or {}).get("missing") or [] if isinstance(m, str)}
        self.share_roots = [fs.key_of(s["path"]) for s in shares if s.get("path")]

    def drive_on(self, key):
        d = drive_of(key)
        return d is None or self.audited.get(d, True)

    def sid_of(self, account, display=""):
        """The account's SID among those this scan met in permissions: by its name (DOMAIN\\name, name), else its
        display name; None when it is not there or the name fits two."""
        if fs.SID_RE.match((account or "").strip().upper()):
            return account.strip().upper()
        for k in sorted(account_keys(account), key=len, reverse=True):
            hit = self.by_name.get(k)
            if hit and len(hit) == 1:
                return next(iter(hit))
        d = (display or "").strip().lower()
        hit = self.by_display.get(d) if d else None
        if hit and len(hit) == 1:
            return next(iter(hit))
        for k in account_keys(account):                   # a built-in account by its known name: Everyone, SYSTEM
            if k in WELL_KNOWN_BY_NAME:
                return WELL_KNOWN_BY_NAME[k]
        return None

    def under_share(self, key):
        return any(key == r or key.startswith(r.rstrip("\\") + "\\") for r in self.share_roots)


def entries(folder, sid):
    """What the folder's entries for this SID give it here: (allow mask, deny mask), None when it has none."""
    allow = deny = 0
    seen = False
    for a in folder.get("acl") or []:
        if a.get("sid") != sid or not a.get("here", True):
            continue
        seen = True
        m = fs.mask_of(a.get("mask", 0))
        if a.get("allow", True):
            allow |= m
        else:
            deny |= m
    return (allow, deny) if seen else None


def find_folder(row, scans):
    """Where the row's folder is: [(scan, key, how)], one when found, several when twice, none when not."""
    path = fs.key_of(row.get("path_text") or "")
    rel = rel_key(row.get("rel_text") or "") if (row.get("rel_text") or "").strip() else (rel_key(path) if path else "")
    if row.get("chosen_key") and row.get("chosen_host"):
        for s in scans:
            if s.host["id"] == str(row["chosen_host"]) and row["chosen_key"] in s.folders:
                return [(s, row["chosen_key"], "chosen on the page")]
    if re.match(r"^[a-z]:\\", path):
        hits = [(s, path, "its Path") for s in scans if path in s.folders]
        if hits:
            return hits
    if rel and rel != "\\":
        hits = [(s, k, "its Relative Path") for s in scans for k in s.by_rel.get(rel, [])]
        if hits:
            return hits
    return []


def left_out(row, scans):
    """The row's Path is on a drive that is not ticked on a server of the review that has that drive: it is left out
    (never compared by its Relative Path on another drive or server instead)."""
    path = fs.key_of(row.get("path_text") or "")
    d = drive_of(path) if re.match(r"^[a-z]:\\", path) else None
    if not d or any(path in s.folders for s in scans):
        return False
    return any(d in s.drives and not s.audited.get(d, True) for s in scans)


def why_not(row, scans):
    """A folder not found: not_scanned (under a share scanned, not reached or not listed: the next scan looks for
    it) or not_found (the scanner looked, or no share scanned holds it). Returns (result, how, the paths to ask)."""
    path = fs.key_of(row.get("path_text") or "")
    rel = rel_key(row.get("rel_text") or "") if (row.get("rel_text") or "").strip() else (rel_key(path) if path else "")
    keys = []
    if re.match(r"^[a-z]:\\", path):
        keys.append(path)
    for s in scans:
        for root in s.share_roots:
            d = drive_of(root)
            if d and rel and rel != "\\" and s.drive_on(root):
                keys.append(d + rel)
    asked, looked = [], False
    for s in scans:
        for k in keys:
            if not s.drive_on(k):
                continue
            if k in s.missing:
                looked = True
            elif s.under_share(k):
                asked.append(k)
    if asked:
        return "not_scanned", "not read yet: the next scan looks for it", sorted(set(asked))
    if looked:
        return "not_found", "the scanner looked: there is no such folder", []
    return "not_found", "no share that was scanned holds it", []


def compare(row, scan, key):
    """(result, found level, sid, how) for a sheet row whose folder is found."""
    f = scan.folders[key]
    sid = scan.sid_of(row.get("account"), row.get("display_name"))
    if not sid:
        return "gone", None, None, "the account is not in the folder's permissions"
    e = entries(f, sid)
    want = level_word(row.get("permission"))
    deny = ace_word(row.get("ace_type")) == "Deny"
    if not e or not (e[1] if deny else e[0]):
        return "gone", None, sid, "no " + ("deny" if deny else "allow") + " entry for it on the folder"
    found = fs.level_of(e[1] if deny else e[0])
    if found == want or (want == "Special" and found not in dict(fs.LEVELS)):
        return "same", found, sid, None
    return "changed", found, sid, None


def sig(row):
    """The same row in the next workbook, whatever server it is used for: its Path (with the drive letter), its
    Relative Path, account, type and permission. apply() adds #n for a row the workbook has more than once."""
    path = fs.key_of(row.get("path_text") or "")
    return "|".join((path if re.match(r"^[a-z]:\\", path) else "", rel_key(row.get("rel_text") or row.get("path_text") or ""),
                     (row.get("account") or "").strip().lower(), ace_word(row.get("ace_type")),
                     level_word(row.get("permission")).lower()))


KEEP_DISCARDED = 10        # workbooks replaced, kept so what was filled on them comes back with the same rows


def _lock(conn):
    """One comparison at a time (two scans that finish together, a drive ticked meanwhile)."""
    conn.execute("SELECT pg_advisory_xact_lock(hashtext('patch01.file_share_access'))").fetchone()


def dumps(v):
    return json.dumps(v, default=str)


# ---------------------------------------------------------------------------
# The database: drives, the workbook, the comparison, the page's lists
# ---------------------------------------------------------------------------
ROW_MAX = 5000            # rows the page's list gives at once
CELL_MAX = 2000


def like(q):
    """Text searched for as it is: \\ (the escape of LIKE), % and _ are written as themselves."""
    return q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


class AccessError(ValueError):
    """Said to the person as it is."""


def _store():
    from . import file_share_store as st
    return st


def audited_drives(conn, host_id):
    return {r["drive"]: r["audited"] for r in conn.execute(
        "SELECT drive, audited FROM file_share_drives WHERE host_id = %s", (host_id,)).fetchall()}


def drives(conn, host_id):
    """The drives the last scan read on this server, each with its shares and folders, and whether it is audited
    (ticked; a drive never chosen is)."""
    st = _store()
    scan = st.last_scan(conn, host_id)
    if not scan:
        return []
    marks = audited_drives(conn, host_id)
    out = {}
    for r in conn.execute("""SELECT lower(substr(path_key, 1, 2)) AS drive, count(*) AS folders,
                                    sum(below)::bigint AS below, count(*) FILTER (WHERE depth = 0) AS shares
                               FROM file_share_folders WHERE scan_id = %s AND path_key ~ '^[a-z]:'
                              GROUP BY 1 ORDER BY 1""", (scan["id"],)).fetchall():
        out[r["drive"]] = {"drive": r["drive"], "shares": r["shares"], "folders": r["folders"] + int(r["below"] or 0),
                           "listed": r["folders"], "audited": marks.get(r["drive"], True)}
    return list(out.values())


def set_drive(conn, host_id, drive, audited, user):
    d = (drive or "").strip().lower().rstrip("\\")
    if not re.fullmatch(r"[a-z]:", d):
        raise AccessError("A drive is a letter and a colon, such as D:.")
    if d not in {x["drive"] for x in drives(conn, host_id)}:
        raise AccessError(f"The last scan read nothing on {d.upper()}.")
    conn.execute("""INSERT INTO file_share_drives (host_id, drive, audited, changed_by) VALUES (%s, %s, %s, %s)
                    ON CONFLICT (host_id, drive) DO UPDATE SET audited = EXCLUDED.audited, changed_by = EXCLUDED.changed_by,
                                                               changed_at = now()""", (host_id, d, bool(audited), user))
    rematch(conn, host_id=host_id)


def _scans(conn, host_ids):
    st = _store()
    out = []
    for h in st.hosts(conn):
        if h["id"] not in host_ids or not h["done"]:
            continue
        d = st.load(conn, h["done"]["id"])
        out.append(Scan(h, h["done"], d["folders"], d["principals"], d["shares"], audited_drives(conn, h["id"])))
    return out


def active(conn):
    """The workbooks in use (applied): each with the servers it is for."""
    st = _store()
    every = [h["id"] for h in st.hosts(conn)]
    out = []
    for r in conn.execute("""SELECT id, file_name, uploaded_by, applied_by, applied_at, scope, all_servers
                               FROM file_share_imports WHERE kind = 'access' AND state = 'applied'
                              ORDER BY applied_at""").fetchall():
        r = dict(r, id=str(r["id"]), scope=str(r["scope"]) if r["scope"] else None)
        r["hosts"] = every if r["all_servers"] else [h for h in every if h == r["scope"]]
        out.append(r)
    return out


# --- the workbook ----------------------------------------------------------

def is_access_workbook(sheets):
    return any(sheet_role(n) == "folder" for n, _rows in sheets)


def preview(conn, file_name, sheets, user):
    """The workbook's sheets as read: the Folder and Member Listing sheets with the columns found by their headers;
    Description and the others are not read."""
    out = []
    for name, rows in sheets:
        role = sheet_role(name)
        if role not in ("folder", "members"):
            out.append({"name": name, "role": "ignored", "header": [], "rows": [], "columns": {}})
            continue
        fields, syn = (FOLDER_FIELDS, FOLDER_SYN) if role == "folder" else (LIST_FIELDS, LIST_SYN)
        hi = header_index(rows, fields, syn)
        head = rows[hi] if rows else []
        body = [r for r in rows[hi + 1:] if any((c or "").strip() for c in r)]
        out.append({"name": name, "role": role, "header": head, "rows": body, "columns": guess(head, fields, syn),
                    "above": rows[:hi]})              # a title above the headers: given back in the export
    if not any(s["role"] == "folder" and s["rows"] for s in out):
        raise AccessError("The Folder sheet has no rows under its headers.")
    iid = str(conn.execute("INSERT INTO file_share_imports (file_name, uploaded_by, sheets, kind) VALUES (%s, %s, %s, 'access') "
                           "RETURNING id", ((file_name or "workbook")[:200], user, dumps(out))).fetchone()["id"])
    return get_preview(conn, iid)


def missing_columns(s):
    if s["role"] == "folder":
        need = [f for f in REQUIRED_FOLDER if f not in s["columns"]]
        if "path" not in s["columns"] and "rel" not in s["columns"]:
            need.insert(0, "path")
        return need
    if s["role"] == "members":
        return [f for f in ("group",) if f not in s["columns"]] + ([] if {"member", "members_name"} & set(s["columns"]) else ["member"])
    return []


def get_preview(conn, iid):
    r = conn.execute("SELECT id, file_name, uploaded_by, uploaded_at, state, sheets, kind FROM file_share_imports WHERE id = %s",
                     (iid,)).fetchone()
    if not r or r["kind"] != "access":
        raise AccessError("No such upload.")
    sheets = []
    for s in r["sheets"]:
        lab = FOLDER_LABEL if s["role"] == "folder" else LIST_LABEL
        sheets.append({"name": s["name"], "role": s["role"], "count": len(s["rows"]), "header": s["header"],
                       "columns": {f: {"index": i, "header": s["header"][i], "label": lab[f]} for f, i in s["columns"].items()},
                       "missing": [{"field": f, "label": lab[f]} for f in missing_columns(s)],
                       "sample": s["rows"][:3]})
    return {"id": str(r["id"]), "file_name": r["file_name"], "state": r["state"], "kind": "access", "sheets": sheets,
            "uploaded_by": r["uploaded_by"], "uploaded_at": r["uploaded_at"]}


def apply(conn, iid, host_id, user, columns=None):
    """Use the workbook for one server (host_id) or every audited one (host_id None). It replaces the workbooks in
    use for those servers (one for all servers is replaced whole). What was filled on a row, on this workbook or one
    used before it, comes back with the same row, whatever server it was used for."""
    st = _store()
    _lock(conn)
    r = conn.execute("SELECT state, sheets, kind FROM file_share_imports WHERE id = %s FOR UPDATE", (iid,)).fetchone()
    if not r or r["kind"] != "access":
        raise AccessError("No such upload.")
    if r["state"] != "preview":
        raise AccessError("This upload was already " + r["state"] + ".")
    every = {h["id"] for h in st.hosts(conn)}
    if host_id is not None and host_id not in every:
        raise AccessError("Choose an audited server, or all of them.")
    if not every:
        raise AccessError("No file server is audited yet.")
    sheets = r["sheets"]
    for s in sheets:                                   # columns the person chose where a header was not recognised
        for f, i in ((columns or {}).get(s["role"]) or {}).items():
            fields = FOLDER_FIELDS if s["role"] == "folder" else LIST_FIELDS
            if f not in fields:
                continue
            if i is None or i == "":
                s["columns"].pop(f, None)
                continue
            i = int(i)
            if not 0 <= i < len(s["header"]):
                raise AccessError(f"The sheet '{s['name']}': that column is not in the sheet.")
            s["columns"][f] = i
        miss = missing_columns(s)
        if miss:
            lab = FOLDER_LABEL if s["role"] == "folder" else LIST_LABEL
            raise AccessError(f"The sheet '{s['name']}': choose the column with the " + " and the ".join(lab[f] for f in miss) + ".")
    folder = next((s for s in sheets if s["role"] == "folder"), None)
    if not folder:
        raise AccessError("The workbook has no Folder sheet.")
    # what was filled: the latest of each row on the same server, over every workbook used (one replaced is kept for
    # this): a server's rows come back filled after a workbook for another one, never with another server's values,
    # and a row cleared on the page stays cleared
    kept, fills, chosen = {}, {}, {}
    for o in conn.execute("""SELECT a.sig, a.origin, a.host_id, a.folder_key, a.sid, a.ace_type, a.recommended, a.feedback,
                                    a.status, a.remarks, a.updated_by, a.updated_at, a.chosen_key, a.chosen_host, i.all_servers,
                                    a.cells, a.import_id
                               FROM file_share_access a JOIN file_share_imports i ON i.id = a.import_id
                              WHERE i.kind = 'access' AND i.state IN ('applied', 'discarded') AND i.applied_at IS NOT NULL
                              ORDER BY i.applied_at, a.id""").fetchall():
        if o["origin"] == "scan":
            kept[("scan", str(o["host_id"]), o["folder_key"], o["sid"], o["ace_type"])] = o
        elif o["sig"]:
            fills[(str(o["host_id"]) if o["host_id"] else None, o["sig"])] = o
            if o["all_servers"]:                       # a folder chosen (found twice) is a choice among all servers
                chosen[o["sig"]] = o
    gone = [a["id"] for a in active(conn) if a["all_servers"] or host_id is None or a["scope"] == host_id]
    if gone:
        # hand pairings of Member Listing come with the workbook that replaces them (the latest of each)
        conn.execute("""INSERT INTO file_share_pairs (import_id, kind, group_name, sheet_value, sid, paired_by, paired_at)
                        SELECT DISTINCT ON (kind, group_name, sheet_value) %s, kind, group_name, sheet_value, sid, paired_by,
                               paired_at
                          FROM file_share_pairs WHERE import_id = ANY(%s::uuid[])
                         ORDER BY kind, group_name, sheet_value, paired_at DESC
                        ON CONFLICT DO NOTHING""", (iid, gone))
        conn.execute("UPDATE file_share_imports SET state = 'discarded' WHERE id = ANY(%s::uuid[])", (gone,))
    scope = host_id
    m = folder["columns"]
    seen = {}
    for n, cells in enumerate(folder["rows"], 1):
        row = {"path_text": cell(cells, m, "path"), "rel_text": cell(cells, m, "rel"), "account_type": cell(cells, m, "account_type"),
               "account": cell(cells, m, "account"), "display_name": cell(cells, m, "display"),
               "ace_type": cell(cells, m, "ace_type"), "permission": cell(cells, m, "permission"),
               "department": cell(cells, m, "department")}
        if not (row["path_text"] or row["rel_text"]) and not row["account"]:
            continue
        base = sig(row)
        seen[base] = seen.get(base, 0) + 1
        sg = base + "#" + str(seen[base])                 # the same row twice in a workbook: each keeps its own
        ch = chosen.get(sg) if host_id is None else None
        fill = {f: cell(cells, m, f) for f in FILL}       # the sheet's own; the page's come after the comparison
        conn.execute(
            """INSERT INTO file_share_access (import_id, origin, row_no, cells, path_text, rel_text, account_type, account,
                                              display_name, ace_type, permission, department, host_id, recommended, feedback,
                                              status, remarks, updated_by, updated_at, chosen_key, chosen_host, sig)
               VALUES (%s, 'sheet', %s, %s::jsonb, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (iid, n, dumps([(c or "")[:CELL_MAX] for c in cells]), row["path_text"], row["rel_text"], row["account_type"],
             row["account"], row["display_name"], row["ace_type"], row["permission"], row["department"], scope,
             fill["recommended"], fill["feedback"], fill["status"], fill["remarks"], None, None,
             ch["chosen_key"] if ch else None, ch["chosen_host"] if ch else None, sg))
    listing = next((s for s in sheets if s["role"] == "members"), None)
    if listing:
        lm = listing["columns"]
        for n, cells in enumerate(listing["rows"], 1):
            g = cell(cells, lm, "group")
            if not g:
                continue
            conn.execute("""INSERT INTO file_share_listing (import_id, row_no, group_name, account_type, member, members_name)
                            VALUES (%s, %s, %s, %s, %s, %s)""",
                         (iid, n, g, cell(cells, lm, "account_type"), cell(cells, lm, "member"), cell(cells, lm, "members_name")))
    conn.execute("""UPDATE file_share_imports SET state = 'applied', applied_by = %s, applied_at = now(), sheets = %s::jsonb,
                           scope = %s, all_servers = %s WHERE id = %s""", (user, dumps(sheets), scope, host_id is None, iid))
    conn.execute("UPDATE file_share_imports SET state = 'discarded' WHERE state = 'preview' AND id <> %s", (iid,))
    # replaced workbooks beyond the last few go, with their rows
    conn.execute("""DELETE FROM file_share_imports WHERE id IN (
                      SELECT id FROM file_share_imports WHERE kind = 'access' AND state = 'discarded'
                       ORDER BY applied_at DESC NULLS LAST, uploaded_at DESC OFFSET %s)""", (KEEP_DISCARDED,))
    _rematch_one(conn, next(a for a in active(conn) if a["id"] == iid), kept)
    # now each row knows its server: what was filled on the page for it there comes back, column by column. Where
    # the sheet's cell changed since the workbook that row came from (users wrote their feedback in the workbook
    # sent back to them), the sheet's wins; where it is as it was, the page's (a value cleared on the page included)
    cols = {}
    for imp in {str(o["import_id"]) for o in fills.values() if o["updated_at"]}:
        x = conn.execute("SELECT sheets FROM file_share_imports WHERE id = %s", (imp,)).fetchone()
        f0 = next((sh for sh in (x["sheets"] if x else []) if sh.get("role") == "folder"), None)
        cols[imp] = (f0 or {}).get("columns") or {}
    back = []
    for r in conn.execute("SELECT id, host_id, sig, recommended, feedback, status, remarks FROM file_share_access "
                          "WHERE import_id = %s AND origin = 'sheet'", (iid,)).fetchall():
        prev = fills.get((str(r["host_id"]) if r["host_id"] else None, r["sig"]))
        if not (prev and prev["updated_at"]):
            continue
        was = cols.get(str(prev["import_id"])) or {}
        old = prev["cells"] or []
        val = {}
        for f in FILL:
            i = was.get(f)
            before = (old[i] or "").strip() if isinstance(i, int) and 0 <= i < len(old) else ""
            val[f] = r[f] if r[f] != before else prev[f]
        if any(val[f] != r[f] for f in FILL):
            back.append(tuple(val[f] for f in FILL) + (prev["updated_by"], prev["updated_at"], r["id"]))
    if back:
        with conn.cursor() as cur:
            cur.executemany("""UPDATE file_share_access SET recommended = %s, feedback = %s, status = %s, remarks = %s,
                                      updated_by = %s, updated_at = %s WHERE id = %s""", back)
    return conn.execute("SELECT count(*) AS n FROM file_share_access WHERE import_id = %s AND origin = 'sheet'",
                        (iid,)).fetchone()["n"]


def replaces(conn, host_id):
    """What using a workbook for this server (None: all of them) replaces, said before it is used."""
    st = _store()
    names = {h["id"]: h["hostname"] for h in st.hosts(conn)}
    act = active(conn)
    if host_id is None:
        per = [names.get(a["scope"]) for a in act if not a["all_servers"] and a["scope"]]
        return ("It replaces the workbooks in use for " + ", ".join(n for n in per if n) + ".") if per else None
    whole = [a for a in act if a["all_servers"]]
    if whole:
        others = sorted(n for h, n in names.items() if h != host_id)
        return ("The workbook in use is for all servers: it is replaced, and " + ", ".join(others)
                + (" has" if len(others) == 1 else " have") + " no workbook until you use one for "
                + ("it" if len(others) == 1 else "them") + ". What was filled comes back with the same rows.") if others else None
    return None


# --- the comparison --------------------------------------------------------

def rematch(conn, import_id=None, kept=None, host_id=None):
    """Every row of the workbooks in use (one, or those of one server) compared with the last scans again: after a
    scan is done, a drive is ticked, or a folder is chosen."""
    _lock(conn)
    for imp in active(conn):
        if import_id and imp["id"] != import_id:
            continue
        if host_id and host_id not in imp["hosts"]:
            continue
        _rematch_one(conn, imp, kept or {})


def _rematch_one(conn, imp, kept):
    scans = _scans(conn, set(imp["hosts"]))
    by_host = {s.host["id"]: s for s in scans}
    rows = [dict(r) for r in conn.execute(
        """SELECT id, path_text, rel_text, account, display_name, ace_type, permission, chosen_key, chosen_host,
                  recommended, feedback, status, remarks
             FROM file_share_access WHERE import_id = %s AND origin = 'sheet'""", (imp["id"],)).fetchall()]
    updates, covered = [], {}
    for r in rows:
        if left_out(r, scans):
            updates.append((imp["scope"], None, None, LEFT_OUT, None, "on a drive that is not ticked", "[]", r["id"]))
            continue
        hits = find_folder(r, scans)
        if len(hits) == 1:
            s, key, how = hits[0]
            res, found, sid, why = compare(r, s, key)
            updates.append((s.host["id"], key, sid, res, found, why or ("found by " + how), "[]", r["id"]))
            covered.setdefault((s.host["id"], key), {})
            if sid:
                covered[(s.host["id"], key)].setdefault((sid, ace_word(r["ace_type"])), r)
        elif len(hits) > 1:
            cand = [{"host_id": s.host["id"], "server": s.host["hostname"], "key": k, "path": s.folders[k]["path"]} for s, k, _ in hits]
            updates.append((imp["scope"], None, None, "twice", None, "found by " + hits[0][2] + " in " + str(len(hits)) + " places",
                            dumps(cand), r["id"]))
        else:
            res, how, asked = why_not(r, scans)
            updates.append((imp["scope"], None, None, res, None, how, dumps(asked), r["id"]))
    with conn.cursor() as cur:
        cur.executemany("""UPDATE file_share_access SET host_id = %s, folder_key = %s, sid = %s, result = %s, found = %s,
                                  how = %s, candidates = %s::jsonb WHERE id = %s""", updates)
    # the accesses on those folders that no row of the sheet lists: new
    want = {}
    for (hid, key), have in covered.items():
        s = by_host[hid]
        f = s.folders[key]
        masks = {}
        for a in f.get("acl") or []:
            if not a.get("here", True) or a.get("sid") in (fs.CREATOR_OWNER,):
                continue
            t = "Allow" if a.get("allow", True) else "Deny"
            if (a.get("sid"), t) in have:
                continue
            masks[(a.get("sid"), t)] = masks.get((a.get("sid"), t), 0) | fs.mask_of(a.get("mask", 0))
        for (sid, t), m in masks.items():
            p = s.principals.get(sid) or {}
            kind = p.get("kind") or fs.kind_of_sid(sid)
            want[(hid, key, sid, t)] = {"path": f["path"], "rel": rel_text(f["path"]), "account": p.get("name") or fs.WELL_KNOWN.get(sid) or sid,
                                        "display": p.get("display") or "", "type": {"user": "User", "group": "Group",
                                        "local_group": "Group", "well_known": "Built-in", "computer": "Computer"}.get(kind, "Unknown"),
                                        "level": fs.level_of(m)}
    have_rows = {(str(r["host_id"]), r["folder_key"], r["sid"], r["ace_type"]): dict(r) for r in conn.execute(
        """SELECT id, host_id, folder_key, sid, ace_type, recommended, feedback, status, remarks, updated_by, updated_at
             FROM file_share_access WHERE import_id = %s AND origin = 'scan'""", (imp["id"],)).fetchall()}
    for k, w in want.items():
        hid, key, sid, t = k
        if k in have_rows:
            conn.execute("""UPDATE file_share_access SET result = 'new', found = %s, permission = %s, account = %s,
                                   display_name = %s, account_type = %s, how = 'on the folder, not in the sheet' WHERE id = %s""",
                         (w["level"], w["level"], w["account"], w["display"], w["type"], have_rows[k]["id"]))
            continue
        prev = kept.get(("scan", hid, key, sid, t)) or {}
        conn.execute(
            """INSERT INTO file_share_access (import_id, origin, path_text, rel_text, account_type, account, display_name, ace_type,
                                              permission, host_id, folder_key, sid, result, found, how, recommended, feedback,
                                              status, remarks, updated_by, updated_at)
               VALUES (%s, 'scan', %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'new', %s, 'on the folder, not in the sheet',
                       %s, %s, %s, %s, %s, %s)
               ON CONFLICT (import_id, host_id, folder_key, sid, ace_type) WHERE origin = 'scan' DO NOTHING""",
            (imp["id"], w["path"], w["rel"], w["type"], w["account"], w["display"], t, w["level"], hid, key, sid, w["level"],
             prev.get("recommended") or "", prev.get("feedback") or "", prev.get("status") or "", prev.get("remarks") or "",
             prev.get("updated_by"), prev.get("updated_at")))
    for k, r in have_rows.items():
        if k in want:
            continue
        hid, key, sid, t = k
        filled = any(r[f] for f in FILL)
        sheet = (covered.get((hid, key)) or {}).get((sid, t))
        s = by_host.get(hid)
        if sheet is not None:
            # the sheet lists it now (a folder chosen, a new workbook): what was filled goes to that row
            if filled:
                give = {f: r[f] for f in FILL if r[f] and not sheet[f]}
                if give:
                    conn.execute("UPDATE file_share_access SET " + ", ".join(f + " = %s" for f in give)
                                 + ", updated_by = %s, updated_at = %s WHERE id = %s",
                                 list(give.values()) + [r["updated_by"], r["updated_at"], sheet["id"]])
            conn.execute("DELETE FROM file_share_access WHERE id = %s", (r["id"],))
        elif s is not None and not s.drive_on(key) and filled:
            conn.execute("UPDATE file_share_access SET result = %s, how = 'on a drive that is not ticked' WHERE id = %s",
                         (LEFT_OUT, r["id"]))
        elif filled:                                   # filled in: kept, said to be gone from the folder since
            conn.execute("UPDATE file_share_access SET result = 'gone', how = 'no longer on the folder' WHERE id = %s", (r["id"],))
        else:
            conn.execute("DELETE FROM file_share_access WHERE id = %s", (r["id"],))


def asked_paths(conn, host_id):
    """Folders the workbook names that the last scan did not read: the next scan looks for each one."""
    out = []
    for r in conn.execute("""SELECT a.candidates FROM file_share_access a JOIN file_share_imports i ON i.id = a.import_id
                              WHERE i.state = 'applied' AND i.kind = 'access' AND a.result = 'not_scanned'
                                AND (i.all_servers OR i.scope = %s)""", (host_id,)).fetchall():
        for k in r["candidates"] or []:
            if isinstance(k, str) and re.fullmatch(r'[a-z]:\\[^*?"<>|]{0,250}', k) and k not in out:
                out.append(k)
    return out


# --- what the page shows ---------------------------------------------------

ROW_COLS = """a.id, a.origin, a.row_no, a.path_text, a.rel_text, a.account_type, a.account, a.display_name, a.ace_type,
              a.permission, a.department, a.host_id, a.folder_key, a.sid, a.result, a.found, a.how, a.candidates,
              a.recommended, a.feedback, a.status, a.remarks, a.updated_by, a.updated_at, a.import_id"""


def row_out(r, names):
    out = {k: r[k] for k in ("id", "origin", "row_no", "path_text", "rel_text", "account_type", "account", "display_name",
                             "ace_type", "permission", "department", "folder_key", "sid", "result", "found", "how",
                             "candidates", "recommended", "feedback", "status", "remarks", "updated_by", "updated_at")}
    out["host_id"] = str(r["host_id"]) if r["host_id"] else None
    out["server"] = names.get(out["host_id"])
    out["result_label"] = RESULT_LABEL[r["result"]]
    out["needs_you"] = r["result"] in NEEDS_YOU
    out["level"] = level_word(r["permission"]) if r["origin"] == "sheet" else r["found"]
    return out


def rows(conn, host_id=None, show="needs", q=None, result=None, limit=ROW_MAX, left_out_too=False):
    st = _store()
    names = {h["id"]: h["hostname"] for h in st.hosts(conn)}
    sql = ("SELECT " + ROW_COLS + " FROM file_share_access a JOIN file_share_imports i ON i.id = a.import_id "
           "WHERE i.state = 'applied' AND i.kind = 'access'")
    args = []
    if not left_out_too:
        sql += " AND a.result <> %s"
        args.append(LEFT_OUT)
    if host_id:
        sql += " AND (a.host_id = %s OR (a.host_id IS NULL AND i.all_servers))"
        args.append(host_id)
    if result in RESULTS:
        sql += " AND a.result = %s"
        args.append(result)
    elif show == "needs":
        sql += " AND a.result = ANY(%s)"
        args.append(list(NEEDS_YOU))
    if q:
        sql += " AND (a.path_text ILIKE %s OR a.rel_text ILIKE %s OR a.account ILIKE %s OR a.display_name ILIKE %s)"
        args += ["%" + like(q) + "%"] * 4
    sql += " ORDER BY a.origin = 'scan', a.row_no NULLS LAST, a.path_text, a.account, a.id"       # the sheet's rows, in its order, then new
    got = conn.execute(sql, args).fetchall()
    return {"rows": [row_out(r, names) for r in got[:limit]], "total": len(got), "more": len(got) > limit}


def counts(conn, host_id=None):
    sql = ("SELECT a.result, count(*) AS n FROM file_share_access a JOIN file_share_imports i ON i.id = a.import_id "
           "WHERE i.state = 'applied' AND i.kind = 'access' AND a.result <> %s")
    args = [LEFT_OUT]
    if host_id:
        sql += " AND (a.host_id = %s OR (a.host_id IS NULL AND i.all_servers))"
        args.append(host_id)
    c = {k: 0 for k in RESULTS}
    for r in conn.execute(sql + " GROUP BY a.result", args).fetchall():
        c[r["result"]] += r["n"]
    c["needs_you"] = sum(c[k] for k in NEEDS_YOU)
    c["total"] = sum(c[k] for k in RESULTS)
    return c


def update(conn, row_id, fields, user, choose=None):
    r = conn.execute("""SELECT a.id, a.result, a.candidates, a.import_id FROM file_share_access a
                          JOIN file_share_imports i ON i.id = a.import_id WHERE a.id = %s AND i.state = 'applied'""",
                     (row_id,)).fetchone()
    if not r:
        raise AccessError("No such row in the workbook in use.")
    sets, args = [], []
    for f in FILL:
        if f in (fields or {}):
            v = (fields[f] or "").strip()
            if len(v) > CELL_MAX:
                raise AccessError(f"{FILL_LABEL[f]} is longer than {CELL_MAX} characters.")
            sets.append(f + " = %s")
            args.append(v)
    if choose is not None:
        ok = [c for c in r["candidates"] or [] if isinstance(c, dict) and c.get("key") == choose.get("key")
              and c.get("host_id") == choose.get("host_id")]
        if r["result"] != "twice" or not ok:
            raise AccessError("Choose one of the folders it was found in.")
        sets += ["chosen_key = %s", "chosen_host = %s"]
        args += [ok[0]["key"], ok[0]["host_id"]]
    if not sets:
        raise AccessError("Nothing to save.")
    if choose is not None:
        _lock(conn)                                    # before the row: the comparison that follows takes it too
    conn.execute("UPDATE file_share_access SET " + ", ".join(sets) + ", updated_by = %s, updated_at = now() WHERE id = %s",
                 args + [user, row_id])
    if choose is not None:
        rematch(conn, str(r["import_id"]))
    row = conn.execute("SELECT " + ROW_COLS + " FROM file_share_access a WHERE a.id = %s", (row_id,)).fetchone()
    names = {h["id"]: h["hostname"] for h in _store().hosts(conn)}
    return row_out(row, names)


# --- Member Listing, beside Active Directory --------------------------------

def _members_of(conn, scans):
    """group SID -> its members [{sid, name, display}], from the scans' Active Directory reads; and every account."""
    groups, accounts = {}, {}
    for s in scans:
        for sid, p in s.principals.items():
            accounts.setdefault(sid, p)
        for r in conn.execute("SELECT group_sid, user_sid FROM file_share_members WHERE scan_id = %s", (s.scan["id"],)).fetchall():
            groups.setdefault(r["group_sid"], set()).add(r["user_sid"])
    return groups, accounts


def groups(conn, host_id=None):
    """Each group of the Member Listing sheet beside the same group in Active Directory, member by member."""
    st = _store()
    imps = [a for a in active(conn) if not host_id or host_id in a["hosts"]]
    out = []
    for imp in imps:
        scans = _scans(conn, set(imp["hosts"]) if not host_id else {host_id})
        members, accounts = _members_of(conn, scans)
        pairs = {(r["kind"], r["group_name"], r["sheet_value"]): r["sid"] for r in conn.execute(
            "SELECT kind, group_name, sheet_value, sid FROM file_share_pairs WHERE import_id = %s", (imp["id"],)).fetchall()}
        by_name = {}
        for sid, p in accounts.items():
            for k in account_keys(p.get("name") or ""):
                by_name.setdefault(k, set()).add(sid)
            d = (p.get("display") or "").strip().lower()
            if d:
                by_name.setdefault(d, set()).add(sid)
        listing = {}
        for r in conn.execute("""SELECT row_no, group_name, account_type, member, members_name FROM file_share_listing
                                  WHERE import_id = %s ORDER BY row_no""", (imp["id"],)).fetchall():
            g = listing.setdefault(r["group_name"].strip(), {"rows": [], "names": []})
            g["rows"].append({"row_no": r["row_no"], "account_type": r["account_type"], "member": r["member"],
                              "members_name": r["members_name"]})
            names = split_names(r["member"]) or split_names(r["members_name"])
            for nme in names:
                if nme.lower() not in [x.lower() for x in g["names"]]:
                    g["names"].append(nme)
        for gname, g in sorted(listing.items(), key=lambda x: x[0].lower()):
            gl = gname.lower()
            how = "paired on the page"
            gsid = pairs.get(("group", "", gl), "unset")
            if gsid == "unset":
                hit = [s for s in by_name.get(gl, set()) | by_name.get(gl.rsplit("\\", 1)[-1], set())
                       if (accounts.get(s) or {}).get("kind") in ("group", "local_group")]
                gsid, how = (hit[0], "same name") if len(hit) == 1 else (None, "no group of that name in the scan")
            ad = [{"sid": u, "name": (accounts.get(u) or {}).get("name") or u, "display": (accounts.get(u) or {}).get("display") or ""}
                  for u in sorted(members.get(gsid, set()))] if gsid else []
            gp = accounts.get(gsid) or {}
            used, lines = set(), []
            for nme in g["names"]:
                nl = nme.lower()
                psid = pairs.get(("member", gl, nl), "unset")
                if psid == "unset":
                    cand = [a for a in ad if nl in account_keys(a["name"]) or nl == (a["display"] or "").lower()]
                    psid, mhow = (cand[0]["sid"], "same name") if len(cand) == 1 else (None, None)
                else:
                    mhow = "paired on the page" if psid else "marked: not in AD"
                hit = next((a for a in ad if a["sid"] == psid), None) if psid else None
                if hit:
                    used.add(hit["sid"])
                    state = "both"
                elif psid:                             # paired with an account that is not a member of the group in AD
                    p = accounts.get(psid) or {}
                    hit = {"sid": psid, "name": p.get("name") or psid, "display": p.get("display") or ""}
                    state = "not_member"
                else:
                    state = "not_in_ad" if mhow == "marked: not in AD" else "sheet_only"
                lines.append({"sheet": nme, "ad": hit, "how": mhow if hit or mhow else None, "state": state})
            for a in ad:
                if a["sid"] not in used:
                    lines.append({"sheet": None, "ad": a, "how": None, "state": "ad_only"})
            out.append({"import_id": imp["id"], "group": gname, "rows": g["rows"], "ad_group": {"sid": gsid, "name": gp.get("name"),
                        "members": gp.get("members"), "how": how} if gsid else None, "group_how": how,
                        "members": lines, "differences": sum(1 for x in lines if x["state"] != "both")})
    del st
    return out


def pair(conn, import_id, kind, group_name, sheet_value, sid, user):
    if kind not in ("group", "member"):
        raise AccessError("Pair a group or a member.")
    if not any(a["id"] == import_id for a in active(conn)):
        raise AccessError("That workbook is not in use.")
    if sid is not None and not fs.SID_RE.match(sid or ""):
        raise AccessError("Choose an account the scan read.")
    g = "" if kind == "group" else (group_name or "").strip().lower()
    v = (sheet_value or "").strip().lower()
    if not v:
        raise AccessError("Name what to pair.")
    conn.execute("""INSERT INTO file_share_pairs (import_id, kind, group_name, sheet_value, sid, paired_by) VALUES (%s, %s, %s, %s, %s, %s)
                    ON CONFLICT (import_id, kind, group_name, sheet_value) DO UPDATE SET sid = EXCLUDED.sid,
                        paired_by = EXCLUDED.paired_by, paired_at = now()""", (import_id, kind, g, v, sid, user))


def unpair(conn, import_id, kind, group_name, sheet_value):
    conn.execute("DELETE FROM file_share_pairs WHERE import_id = %s AND kind = %s AND group_name = %s AND sheet_value = %s",
                 (import_id, kind, "" if kind == "group" else (group_name or "").strip().lower(), (sheet_value or "").strip().lower()))


def accounts(conn, host_id=None, q="", kind=None, limit=20):
    """Accounts the scans read, for pairing by hand."""
    st = _store()
    ids = [h["id"] for h in st.hosts(conn) if not host_id or h["id"] == host_id]
    scans = [h["done"]["id"] for h in st.hosts(conn) if h["id"] in ids and h["done"]]
    if not scans:
        return []
    sql = ("SELECT DISTINCT ON (sid) sid, name, display, kind FROM file_share_principals WHERE scan_id = ANY(%s::uuid[]) "
           "AND (name ILIKE %s OR display ILIKE %s)")
    pat = "%" + like(q or "") + "%"
    args = [scans, pat, pat]
    if kind == "group":
        sql += " AND kind IN ('group', 'local_group')"
    elif kind == "user":
        sql += " AND kind = 'user'"
    sql += " ORDER BY sid LIMIT %s"
    return [dict(r) for r in conn.execute(sql, args + [limit]).fetchall()]


# --- the next step ---------------------------------------------------------

def next_step(conn, host_id=None):
    """The one thing to do now, for the banner."""
    st = _store()
    hs = [h for h in st.hosts(conn) if not host_id or h["id"] == host_id]
    if not hs:
        return {"step": "add", "text": "Add a file server to the audit."}
    if not any(h["done"] for h in hs):
        busy = any(h["scan"] and h["scan"]["state"] in ("queued", "running") for h in hs)
        return {"step": "scan", "text": "The scan is running: the page follows it." if busy else "Scan the server: press Scan now."}
    if not [a for a in active(conn) if not host_id or host_id in a["hosts"]]:
        return {"step": "upload", "text": "Upload the access review workbook."}
    c = counts(conn, host_id)
    if c["not_scanned"]:
        n = c["not_scanned"]
        return {"step": "rescan", "text": f"{n} access{'' if n == 1 else 'es'} of the workbook {'is' if n == 1 else 'are'} on folders the "
                "last scan did not read: press Scan now and the scan reads them."}
    if c["needs_you"]:
        n = c["needs_you"]
        return {"step": "review", "text": f"{n} access{'' if n == 1 else 'es'} need{'s' if n == 1 else ''} you.", "count": n}
    return {"step": "report", "text": "Every access is checked: export the report."}
