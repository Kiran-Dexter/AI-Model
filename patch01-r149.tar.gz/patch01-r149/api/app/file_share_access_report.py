"""File shares (r149): the access review's export, with the logo and colour of Admin > Branding.

Excel: the workbook's own Folder sheet back, its columns and rows as they were, with the four columns the person
filled (Recommended Change to, Feedback from Users, Status, Remarks) and three more: Result, Found on the server,
Server; New access (what the scan found that the sheet does not list, with what was filled for it); Groups (Member
Listing beside Active Directory); Summary. PDF: the figures, and what needs you.

Every value from a scan or a workbook is written as plain text: never markup, never a formula."""

import io
from xml.sax.saxutils import escape

from . import exports as ex
from . import file_share_access as fa
from . import file_share_report as base

TITLE = "File share access review"
COLOR = {"left_out": base.MUTED, "same": base.OK, "changed": base.WARN, "gone": base.MUTED, "new": base.BAD, "not_found": base.MOD,
         "not_scanned": base.MUTED, "twice": base.WARN}
PDF_ROWS_MAX = 500


def collect(conn, host_id=None):
    rows = fa.rows(conn, host_id, "all", limit=10 ** 7, left_out_too=True)["rows"]       # the Excel gives every row back
    c = fa.counts(conn, host_id)
    imps = [a for a in fa.active(conn) if not host_id or host_id in a["hosts"]]
    sheets = {}
    for a in imps:
        r = conn.execute("SELECT sheets FROM file_share_imports WHERE id = %s", (a["id"],)).fetchone()
        sheets[a["id"]] = next((s for s in r["sheets"] if s["role"] == "folder"), None) if r else None
    by_id = {}
    for r in conn.execute("SELECT id, import_id, cells FROM file_share_access WHERE import_id = ANY(%s::uuid[]) AND origin = 'sheet'",
                          ([a["id"] for a in imps],)).fetchall():
        by_id[r["id"]] = (str(r["import_id"]), r["cells"])
    from . import file_share_store as st
    servers = ", ".join(h["hostname"] for h in st.hosts(conn) if not host_id or h["id"] == host_id) or "none"
    return {"rows": rows, "counts": c, "imports": imps, "sheets": sheets, "cells": by_id,
            "groups": fa.groups(conn, host_id), "servers": servers}


def render(conn, fmt, user, host_id=None):
    d = collect(conn, host_id)
    logo, cls, accent = ex.brand_bits(conn)
    m = ex.meta(TITLE, user, "Servers: " + d["servers"], len(d["rows"]), ex.company_name(conn))
    if fmt == "xlsx":
        return xlsx(m, d, logo, accent), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx"
    return pdf(m, d, logo, cls, accent), "application/pdf", "pdf"


# ---------------------------------------------------------------------------
# Excel
# ---------------------------------------------------------------------------

def xlsx(m, d, logo_png, accent):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    head_fill = PatternFill("solid", fgColor=(accent or "#0B1F3A").lstrip("#")[:6] or "0B1F3A")
    head_font = Font(bold=True, color="FFFFFF")

    def sv(v):
        return ex.safe_cell(base._t(v))

    def header(ws, row, names):
        for i, n in enumerate(names, 1):
            c = ws.cell(row, i, sv(n))
            c.fill, c.font = head_fill, head_font
            c.alignment = Alignment(vertical="top", wrap_text=True)
        ws.freeze_panes = ws.cell(row + 1, 1)
        ws.auto_filter.ref = f"A{row}:{get_column_letter(len(names))}{row}"

    def widths(ws, n, w=22):
        for i in range(1, n + 1):
            ws.column_dimensions[get_column_letter(i)].width = w

    # Summary
    ws = wb.active
    ws.title = "Summary"
    ws.cell(1, 1, sv(TITLE)).font = Font(bold=True, size=16, color=(accent or "#0B1F3A").lstrip("#")[:6])
    ws.cell(2, 1, sv(" · ".join(x for x in (m.get("company"), "Servers: " + d["servers"], "Generated " + m["generated"],
                                           "by " + m["by"]) if x)))
    ws.cell(4, 1, "Result").font = Font(bold=True)
    ws.cell(4, 2, "Accesses").font = Font(bold=True)
    for i, k in enumerate(fa.RESULTS, 5):
        ws.cell(i, 1, fa.RESULT_LABEL[k]).font = Font(color=COLOR[k].lstrip("#"), bold=True)
        ws.cell(i, 2, d["counts"][k])
    ws.cell(5 + len(fa.RESULTS), 1, "Need you").font = Font(bold=True)
    ws.cell(5 + len(fa.RESULTS), 2, d["counts"]["needs_you"]).font = Font(bold=True)
    widths(ws, 2, 26)

    # The Folder sheet back, filled
    rows_by_import = {}
    for r in d["rows"]:
        if r["origin"] == "sheet":
            imp = d["cells"].get(r["id"], (None, None))[0]
            rows_by_import.setdefault(imp, []).append(r)
    for n, imp in enumerate(d["imports"]):
        sh = d["sheets"].get(imp["id"]) or {"header": [], "columns": {}}
        hdr = list(sh["header"])
        cols = dict(sh["columns"])
        for f in fa.FILL:                              # a fill column the sheet did not have: added at its end
            if f not in cols:
                cols[f] = len(hdr)
                hdr.append(fa.FILL_LABEL[f])
        extra = ["Result", "Found on the server", "Server"]
        ws = wb.create_sheet(("Folder" if len(d["imports"]) == 1 else f"Folder {n + 1}")[:31])
        above = sh.get("above") or []                  # a title the sheet had above its headers, as it was
        for i, cells in enumerate(above, 1):
            for j, v in enumerate(cells, 1):
                ws.cell(i, j, sv(v))
        top = len(above) + 1
        header(ws, top, hdr + extra)
        for i, r in enumerate(sorted(rows_by_import.get(imp["id"], []), key=lambda x: x["row_no"] or 0), top + 1):
            cells = list(d["cells"].get(r["id"], (None, []))[1] or [])
            cells += [""] * (len(hdr) - len(cells))
            for f in fa.FILL:
                cells[cols[f]] = r[f]
            for j, v in enumerate(cells[:len(hdr)], 1):
                ws.cell(i, j, sv(v))
            res = ws.cell(i, len(hdr) + 1, r["result_label"])
            res.font = Font(bold=True, color=COLOR[r["result"]].lstrip("#"))
            ws.cell(i, len(hdr) + 2, sv(r["found"] or ""))
            ws.cell(i, len(hdr) + 3, sv(r["server"] or ""))
        widths(ws, len(hdr) + len(extra))

    # New access
    ws = wb.create_sheet("New access")
    names = ["Server", "Path", "Relative Path", "Account Type", "Account", "Display Name", "Type", "Permission found"] + \
        [fa.FILL_LABEL[f] for f in fa.FILL] + ["Result"]
    header(ws, 1, names)
    for i, r in enumerate([x for x in d["rows"] if x["origin"] == "scan" and x["result"] != fa.LEFT_OUT], 2):
        vals = [r["server"], r["path_text"], r["rel_text"], r["account_type"], r["account"], r["display_name"], r["ace_type"],
                r["found"]] + [r[f] for f in fa.FILL] + [r["result_label"]]
        for j, v in enumerate(vals, 1):
            ws.cell(i, j, sv(v))
    widths(ws, len(names))

    # Groups
    ws = wb.create_sheet("Groups")
    names = ["Group (sheet)", "Group (Active Directory)", "Member (sheet)", "Member (Active Directory)", "Where", "How"]
    header(ws, 1, names)
    where = {"both": "In both", "sheet_only": "In the sheet only", "ad_only": "In AD only", "not_in_ad": "Marked: not in AD",
             "not_member": "In AD, not in the group"}
    i = 2
    for g in d["groups"]:
        adg = (g["ad_group"] or {}).get("name") or ("not found: " + g["group_how"])
        for mb in g["members"] or [{"sheet": None, "ad": None, "state": None, "how": None}]:
            vals = [g["group"], adg, mb["sheet"] or "", ((mb["ad"] or {}).get("name") or ""),
                    where.get(mb["state"], ""), mb["how"] or ""]
            for j, v in enumerate(vals, 1):
                ws.cell(i, j, sv(v))
            i += 1
    widths(ws, len(names), 28)

    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


# ---------------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------------

def pdf(m, d, logo_png, classification, accent):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import Image, LongTable, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    W, H = landscape(A4)
    margin = 14 * mm
    usable = W - 2 * margin
    C = colors.HexColor
    try:
        acc = C(accent)
    except ValueError:
        acc = C("#0B1F3A")
    basest = ParagraphStyle("b", fontName="Helvetica", fontSize=9, leading=12, textColor=C(base.INK))
    small = ParagraphStyle("s", parent=basest, fontSize=7.6, leading=9.6, textColor=C(base.INK2))
    cell = ParagraphStyle("c", parent=basest, fontSize=7.4, leading=9.2)
    head = ParagraphStyle("h", parent=cell, fontName="Helvetica-Bold", textColor=colors.white)
    h1 = ParagraphStyle("h1", parent=basest, fontName="Helvetica-Bold", fontSize=20, leading=24, textColor=acc)
    h2 = ParagraphStyle("h2", parent=basest, fontName="Helvetica-Bold", fontSize=13, leading=16, textColor=acc, spaceBefore=6,
                        spaceAfter=4)

    def p(text, style=basest):
        return Paragraph(escape(base._t(text))[:base.CELL_MAX], style)

    story = []
    if logo_png and ex._png_size(logo_png):
        w, h = ex._png_size(logo_png)
        lh = 14 * mm
        lw = min(60 * mm, w * lh / max(1, h))
        story += [Image(io.BytesIO(logo_png), width=lw, height=h * lw / max(1, w), hAlign="LEFT"), Spacer(1, 3 * mm)]
    story += [p(TITLE, h1), p(" · ".join(x for x in (m.get("company"), "Servers: " + d["servers"], "Generated " + m["generated"],
                                                     "by " + m["by"], classification) if x), small), Spacer(1, 5 * mm)]
    c = d["counts"]
    tiles = [(fa.RESULT_LABEL[k], c[k], COLOR[k]) for k in fa.RESULTS]
    tw = usable / len(tiles)
    t = Table([[p(str(v), ParagraphStyle("v", parent=basest, fontName="Helvetica-Bold", fontSize=16, leading=19,
                                         textColor=C(col))) for _l, v, col in tiles],
               [p(lab, small) for lab, _v, _c in tiles]], colWidths=[tw] * len(tiles))
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), C(base.BAND)), ("BOX", (0, 0), (-1, -1), 0.5, C(base.RULE)),
                           ("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 6)]))
    story += [t, Spacer(1, 4 * mm),
              p(f"{c['total']} accesses compared with the scan; {c['needs_you']} need you "
                "(changed, gone, new, folder not found, found twice).")]
    need = [r for r in d["rows"] if r["needs_you"]]
    story.append(p("What needs you", h2))
    if not need:
        story.append(p("Nothing: every access is as the workbook says."))
    else:
        widths = [0.08, 0.30, 0.18, 0.10, 0.11, 0.10, 0.13]
        data = [[p(x, head) for x in ("Server", "Path", "Account", "Sheet says", "Found", "Result", "Recommended")]]
        for r in need[:PDF_ROWS_MAX]:
            data.append([p(r["server"] or "", cell), p(r["path_text"] or r["rel_text"], cell),
                         p((r["account"] or "") + (f" ({r['display_name']})" if r["display_name"] else ""), cell),
                         p(r["level"] if r["origin"] == "sheet" else "(not listed)", cell), p(r["found"] or "–", cell),
                         p(r["result_label"], ParagraphStyle("r", parent=cell, textColor=C(COLOR[r["result"]]),
                                                             fontName="Helvetica-Bold")),
                         p(r["recommended"], cell)])
        lt = LongTable(data, colWidths=[usable * w for w in widths], repeatRows=1)
        lt.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), acc), ("GRID", (0, 0), (-1, -1), 0.3, C(base.RULE)),
                                ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        story.append(lt)
        if len(need) > PDF_ROWS_MAX:
            story.append(p(f"The first {PDF_ROWS_MAX} of {len(need)}: the Excel export has every row.", small))
    out = io.BytesIO()
    SimpleDocTemplate(out, pagesize=landscape(A4), leftMargin=margin, rightMargin=margin, topMargin=margin,
                      bottomMargin=margin, title=TITLE).build(story)
    return out.getvalue()
