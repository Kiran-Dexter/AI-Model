"""Vulnerabilities > File shares (r146): the scanner's reports, and the page. The work is in file_share_store.py and
the rules in file_shares.py."""

import re
from typing import Annotated, Any, Dict, List, Literal, Optional

from fastapi import Depends, File, HTTPException, Request, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel, Field

from .core import (AgentIdentity, app, audit, client_ip, db, jsonable, require_agent, require_operator, require_viewer,
                   uuid_or_404)
from . import file_share_access as fa
from . import file_share_store as st
from . import file_shares as fs

BASE = "/api/v1/file-shares"
SID = r"^S-1-[0-9]+(-[0-9]+){1,15}$"
MAX_UPLOAD = 5 * 1024 * 1024


def _call(fn):
    try:
        return fn()
    except (st.FsError, fa.AccessError) as e:
        raise HTTPException(400, str(e))
    except st.NotFound as e:
        raise HTTPException(404, str(e))


def _can_edit(request):
    from . import auth
    return auth.role_at_least((request.state.user or {}).get("role") or "viewer", "operator")


def _audit(conn, user, request, action, detail, host_id=None):
    audit(conn, actor=user, actor_type="user", action=action, object_type="file_shares", host_id=host_id, detail=detail,
          source_ip=client_ip(request))


def _host(v):
    return uuid_or_404(v, "No such server.")


# ---------------------------------------------------------------------------
# The scanner (access-scan.ps1 2.x on the file server, with its agent's token)
# ---------------------------------------------------------------------------

class ShareAceIn(BaseModel):
    sid: str = Field(..., pattern=SID, max_length=200)
    name: Optional[str] = Field(default=None, max_length=300)
    allow: bool = True
    right: Literal["Full", "Change", "Read", "Custom"]


class ShareIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=80)
    path: str = Field(..., min_length=2, max_length=2000)
    description: Optional[str] = Field(default=None, max_length=500)
    acl: List[ShareAceIn] = Field(default_factory=list, max_length=200)
    error: Optional[str] = Field(default=None, max_length=1000)


class AceIn(BaseModel):
    sid: str = Field(..., pattern=SID, max_length=200)
    mask: int = Field(..., ge=-2147483648, le=4294967295)
    allow: bool = True
    inh: bool = False
    here: bool = True
    kids: bool = True


class FolderIn(BaseModel):
    path: str = Field(..., min_length=2, max_length=4000)
    share: str = Field(..., min_length=1, max_length=80)
    depth: int = Field(..., ge=0, le=64)
    why: Literal["level", "own", "protected", "asked"]
    protected: bool = False
    explicit: bool = False
    owner_sid: Optional[str] = Field(default=None, pattern=SID, max_length=200)
    acl: List[AceIn] = Field(default_factory=list, max_length=1000)
    below: int = Field(default=0, ge=0)
    error: Optional[str] = Field(default=None, max_length=1000)
    partial: bool = False                      # read, but only its first 1,000 entries are kept


class PrincipalIn(BaseModel):
    sid: str = Field(..., pattern=SID, max_length=200)
    name: Optional[str] = Field(default=None, max_length=300)
    kind: Literal["user", "group", "local_group", "well_known", "computer", "unknown"]
    display: Optional[str] = Field(default=None, max_length=300)
    email: Optional[str] = Field(default=None, max_length=300)
    department: Optional[str] = Field(default=None, max_length=300)
    enabled: Optional[bool] = None
    members: Optional[Literal["read", "all_domain_users", "not_read", "too_many"]] = None
    lookup_failed: Optional[bool] = None       # the name could not be looked up (not "no such account")


class MemberIn(BaseModel):
    group: str = Field(..., pattern=SID, max_length=200)
    user: str = Field(..., pattern=SID, max_length=200)


class PartIn(BaseModel):
    seq: int = Field(..., ge=0, le=1000000)
    shares: List[ShareIn] = Field(default_factory=list, max_length=2000)
    folders: List[FolderIn] = Field(default_factory=list, max_length=5000)
    principals: List[PrincipalIn] = Field(default_factory=list, max_length=5000)
    members: List[MemberIn] = Field(default_factory=list, max_length=50000)
    below: Dict[str, Annotated[int, Field(ge=0, le=10 ** 9)]] = Field(default_factory=dict, max_length=20000)


class StartIn(BaseModel):
    scanner_version: str = Field(..., max_length=40, pattern=r"^[0-9]+\.[0-9]+\.[0-9]+[A-Za-z0-9.-]*$")


class DoneIn(BaseModel):
    ok: bool
    error: Optional[str] = Field(default=None, max_length=2000)
    totals: Dict[str, Any] = Field(default_factory=dict, max_length=50)


def _scan_id(v):
    return uuid_or_404(v, "No such scan for this server.")


@app.post("/api/v1/agent/file-shares/{scan_id}/start")
def fs_agent_start(scan_id: str, body: StartIn, agent: AgentIdentity = Depends(require_agent)):
    sid = _scan_id(scan_id)
    with db() as conn:
        with conn.transaction():
            _call(lambda: st.start(conn, sid, agent.host_id, body.scanner_version))
    return {"ok": True}


@app.post("/api/v1/agent/file-shares/{scan_id}/part")
def fs_agent_part(scan_id: str, body: PartIn, agent: AgentIdentity = Depends(require_agent)):
    sid = _scan_id(scan_id)
    part = body.model_dump()
    for k in part["below"]:
        if len(k) > 4000:
            raise HTTPException(422, "below: a path is too long")
    with db() as conn:
        with conn.transaction():
            taken = _call(lambda: st.store_part(conn, sid, agent.host_id, part))
    return {"ok": True, "taken": taken}


@app.post("/api/v1/agent/file-shares/{scan_id}/done")
def fs_agent_done(scan_id: str, body: DoneIn, agent: AgentIdentity = Depends(require_agent)):
    sid = _scan_id(scan_id)
    totals = {k: v for k, v in body.totals.items() if re.fullmatch(r"[a-z_]{1,40}", k)}
    miss = totals.get("missing")
    totals["missing"] = [str(x)[:300] for x in miss][:5000] if isinstance(miss, list) else []
    with db() as conn:
        with conn.transaction():
            _call(lambda: st.finish(conn, sid, agent.host_id, body.ok, body.error, totals))
    return {"ok": True}


# ---------------------------------------------------------------------------
# The page
# ---------------------------------------------------------------------------

@app.get(BASE)
def fs_home(request: Request, user: str = Depends(require_viewer)):
    with db() as conn:
        vs = st.views(conn)
        servers = st.hosts(conn)
        for h in servers:
            if h["scan"] and h["scan"]["stalled"]:
                h["scan"]["stalled_why"] = st.stalled_why(h["scan"])
        return jsonable({"can_edit": _can_edit(request), "servers": servers, "candidates": st.candidates(conn),
                         "workbook": st.last_import(conn), "pending": st.pending_import(conn), "summary": st.summary(vs),
                         "risk_labels": [{"key": k, "label": l} for k, l, _ in fs.RISKS],
                         # r149: the access review workbook
                         "access": {"workbooks": fa.active(conn), "counts": fa.counts(conn),
                                    "next": fa.next_step(conn),
                                    "next_by_server": {h["id"]: fa.next_step(conn, h["id"]) for h in servers},
                                    "counts_by_server": {h["id"]: fa.counts(conn, h["id"]) for h in servers},
                                    # said under the upload's choice of server, before the workbook is used
                                    "replaces": dict({h["id"]: fa.replaces(conn, h["id"]) for h in servers},
                                                     all=fa.replaces(conn, None)),
                                    "drives": {h["id"]: fa.drives(conn, h["id"]) for h in servers},
                                    "results": [{"key": k, "label": fa.RESULT_LABEL[k], "needs_you": k in fa.NEEDS_YOU}
                                                for k in fa.RESULTS],
                                    "fill": [{"key": k, "label": fa.FILL_LABEL[k]} for k in fa.FILL]}})


class ServerIn(BaseModel):
    host_id: str


@app.post(BASE + "/servers")
def fs_add_server(body: ServerIn, request: Request, user: str = Depends(require_operator)):
    hid = _host(body.host_id)
    with db() as conn:
        with conn.transaction():
            name = _call(lambda: st.add_server(conn, hid, user))
            _audit(conn, user, request, "file_shares.server_added", {"server": name}, hid)
    return {"ok": True}


@app.delete(BASE + "/servers/{host_id}")
def fs_remove_server(host_id: str, request: Request, user: str = Depends(require_operator)):
    hid = _host(host_id)
    with db() as conn:
        with conn.transaction():
            _call(lambda: st.remove_server(conn, hid))
            _audit(conn, user, request, "file_shares.server_removed", {}, hid)
    return {"ok": True}


@app.post(BASE + "/scan")
def fs_scan(body: ServerIn, request: Request, user: str = Depends(require_operator)):
    hid = _host(body.host_id)
    with db() as conn:
        with conn.transaction():
            sid = _call(lambda: st.queue_scan(conn, hid, user))
            _audit(conn, user, request, "file_shares.scan", {"scan_id": sid}, hid)
    return {"ok": True, "scan_id": sid}


@app.post(BASE + "/scans/{scan_id}/cancel")
def fs_cancel(scan_id: str, request: Request, user: str = Depends(require_operator)):
    sid = uuid_or_404(scan_id, "No such scan.")
    with db() as conn:
        with conn.transaction():
            _call(lambda: st.cancel_scan(conn, sid))
            _audit(conn, user, request, "file_shares.scan_cancelled", {"scan_id": sid})
    return {"ok": True}


@app.post(BASE + "/workbook")
def fs_upload(request: Request, file: UploadFile = File(...), user: str = Depends(require_operator)):
    # a plain def: FastAPI runs it in a thread, so reading the workbook and the database work never hold the event loop
    data = file.file.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD:
        raise HTTPException(413, "The file is over 5 MB.")
    with db() as conn:
        with conn.transaction():
            r = _call(lambda: st.preview(conn, file.filename or "", data, user))
            _audit(conn, user, request, "file_shares.workbook_read", {"file": r["file_name"], "id": r["id"]})
    return jsonable(r)


@app.get(BASE + "/workbook/{iid}")
def fs_upload_get(iid: str, user: str = Depends(require_viewer)):
    i = uuid_or_404(iid, "No such upload.")
    with db() as conn:
        return jsonable(_call(lambda: st.get_import(conn, i)))


class SheetChoice(BaseModel):
    name: str = Field(..., max_length=60)
    use: bool = True
    host_id: Optional[str] = Field(default=None, max_length=40)
    columns: Dict[str, Optional[int]] = Field(default_factory=dict, max_length=10)


class ApplyIn(BaseModel):
    sheets: List[SheetChoice] = Field(..., max_length=50)


@app.post(BASE + "/workbook/{iid}/apply")
def fs_upload_apply(iid: str, body: ApplyIn, request: Request, user: str = Depends(require_operator)):
    i = uuid_or_404(iid, "No such upload.")
    with db() as conn:
        with conn.transaction():
            n = _call(lambda: st.apply(conn, i, [c.model_dump() for c in body.sheets], user))
            _audit(conn, user, request, "file_shares.workbook_used", {"id": i, "rows": n})
        mine = {}
        for v in st.views(conn):
            for r in v["rows"]:
                if r["import_id"] and str(r["import_id"]) == i:
                    mine[r["state"]] = mine.get(r["state"], 0) + 1
    return jsonable({"ok": True, "rows": n, "workbook": mine})


@app.delete(BASE + "/workbook/{iid}")
def fs_upload_discard(iid: str, request: Request, user: str = Depends(require_operator)):
    i = uuid_or_404(iid, "No such upload.")
    with db() as conn:
        with conn.transaction():
            _call(lambda: st.discard(conn, i))
    return {"ok": True}


@app.get(BASE + "/review")
def fs_review(kind: str, host_id: Optional[str] = None, user: str = Depends(require_viewer)):
    if kind not in ("doubt", "orphan", "missing", "matched", "rejected"):
        raise HTTPException(400, "kind is doubt, orphan, missing, matched or rejected")
    hid = _host(host_id) if host_id else None
    with db() as conn:
        return jsonable({"kind": kind, "items": st.review(st.views(conn, hid), kind)})


class DecideIn(BaseModel):
    action: Literal["approve", "reject", "edit", "undo"]
    folder_key: Optional[str] = Field(default=None, max_length=4000)
    department: Optional[str] = Field(default=None, max_length=300)
    owner: Optional[str] = Field(default=None, max_length=300)
    email: Optional[str] = Field(default=None, max_length=300)


@app.post(BASE + "/rows/{row_id}")
def fs_decide(row_id: int, body: DecideIn, request: Request, user: str = Depends(require_operator)):
    with db() as conn:
        with conn.transaction():
            r = _call(lambda: st.decide(conn, row_id, body.action, user, body.folder_key,
                                        {k: v for k, v in body.model_dump().items() if k in ("department", "owner", "email") and v is not None}))
            _audit(conn, user, request, "file_shares.row_" + body.action,
                   {"row": row_id, "folder": r["decided_key"] or r["folder_key"], "owner": r["owner"], "department": r["department"]},
                   str(r["host_id"]) if r["host_id"] else None)
    return {"ok": True}


class OwnerIn(BaseModel):
    host_id: str
    folder_key: str = Field(..., max_length=4000)
    department: Optional[str] = Field(default=None, max_length=300)
    owner: Optional[str] = Field(default=None, max_length=300)
    email: Optional[str] = Field(default=None, max_length=300)


@app.post(BASE + "/owners")
def fs_add_owner(body: OwnerIn, request: Request, user: str = Depends(require_operator)):
    hid = _host(body.host_id)
    with db() as conn:
        with conn.transaction():
            rid = _call(lambda: st.add_owner(conn, hid, body.folder_key, body.model_dump(), user))
            _audit(conn, user, request, "file_shares.owner_added",
                   {"row": rid, "folder": fs.key_of(body.folder_key), "owner": body.owner, "department": body.department}, hid)
    return {"ok": True, "id": rid}


@app.get(BASE + "/folders")
def fs_folders(host_id: str, share: Optional[str] = None, q: Optional[str] = None, risk: Optional[str] = None,
               state: Optional[str] = None, user: str = Depends(require_viewer)):
    hid = _host(host_id)
    if risk and risk not in fs.RISK_LABEL:
        raise HTTPException(400, "Unknown risk.")
    if state and state not in ("owned", "missing", "split"):
        raise HTTPException(400, "state is owned, missing or split")
    with db() as conn:
        v = st.view(conn, hid)
        items = st.folders(v, share, (q or "")[:200], risk, state)
        return jsonable({"server": v["host"]["hostname"] if v["host"] else None, "scan": v["scan"],
                         "shares": [{"name": s["name"], "path": s["path"]} for s in v["shares"]],
                         "items": items, "more": len(items) >= 500})


@app.get(BASE + "/folder")
def fs_folder(host_id: str, key: str, user: str = Depends(require_viewer)):
    hid = _host(host_id)
    with db() as conn:
        return jsonable(_call(lambda: st.folder_detail(conn, hid, key[:4000])))


@app.get(BASE + "/effective")
def fs_effective(host_id: str, key: str, sid: str, user: str = Depends(require_viewer)):
    hid = _host(host_id)
    with db() as conn:
        return jsonable(_call(lambda: st.effective(conn, hid, key[:4000], sid[:200])))


@app.get(BASE + "/people")
def fs_people(host_id: str, q: str = "", user: str = Depends(require_viewer)):
    hid = _host(host_id)
    with db() as conn:
        return jsonable({"items": st.people(conn, hid, q[:100])})


@app.get(BASE + "/export")
def fs_export(request: Request, format: str = "pdf", host_id: Optional[str] = None, user: str = Depends(require_viewer)):
    if format not in ("pdf", "xlsx"):
        raise HTTPException(400, "format is pdf or xlsx")
    hid = _host(host_id) if host_id else None
    from . import exports as ex
    from . import file_share_report as rep
    with db() as conn:
        vs = st.views(conn, hid)
        data, media, ext = rep.render(conn, format, user, vs)
        _audit(conn, user, request, "file_shares.export", {"format": format, "servers": len(vs)})
    name = ex.file_name("file-shares", ext)
    return Response(content=data, media_type=media, headers={"Content-Disposition": f'attachment; filename="{name}"'})


# ---------------------------------------------------------------------------
# r149: the access review workbook (Folder, Member Listing), compared with the scan
# ---------------------------------------------------------------------------

class UseIn(BaseModel):
    host_id: Optional[str] = Field(default=None, max_length=40)          # None: every audited server, together
    columns: Dict[Literal["folder", "members"], Dict[str, Optional[Annotated[int, Field(ge=0, le=500)]]]] = \
        Field(default_factory=dict)


@app.post(BASE + "/workbook/{iid}/use")
def fs_access_use(iid: str, body: UseIn, request: Request, user: str = Depends(require_operator)):
    i = uuid_or_404(iid, "No such upload.")
    hid = _host(body.host_id) if body.host_id else None
    with db() as conn:
        with conn.transaction():
            n = _call(lambda: fa.apply(conn, i, hid, user, body.columns))
            _audit(conn, user, request, "file_shares.access_workbook_used", {"id": i, "rows": n, "server": hid or "all"}, hid)
        return jsonable({"ok": True, "rows": n, "counts": fa.counts(conn, hid), "next": fa.next_step(conn, hid)})


@app.get(BASE + "/access")
def fs_access_rows(host_id: Optional[str] = None, show: Literal["needs", "all"] = "needs", q: Optional[str] = None,
                   result: Optional[str] = None, user: str = Depends(require_viewer)):
    hid = _host(host_id) if host_id else None
    with db() as conn:
        out = fa.rows(conn, hid, show, (q or "")[:100] or None, result if result in fa.RESULTS else None)
        out["counts"] = fa.counts(conn, hid)
        out["next"] = fa.next_step(conn, hid)
        return jsonable(out)


class ChooseIn(BaseModel):
    host_id: str = Field(..., max_length=40)
    key: str = Field(..., max_length=4000)


class AccessRowIn(BaseModel):
    recommended: Optional[str] = Field(default=None, max_length=2000)
    feedback: Optional[str] = Field(default=None, max_length=2000)
    status: Optional[str] = Field(default=None, max_length=2000)
    remarks: Optional[str] = Field(default=None, max_length=2000)
    choose: Optional[ChooseIn] = None


@app.post(BASE + "/access/{row_id}")
def fs_access_save(row_id: int, body: AccessRowIn, request: Request, user: str = Depends(require_operator)):
    fields = {k: v for k, v in body.model_dump().items() if k in fa.FILL and v is not None}
    choose = body.choose.model_dump() if body.choose else None
    with db() as conn:
        with conn.transaction():
            r = _call(lambda: fa.update(conn, row_id, fields, user, choose))
            _audit(conn, user, request, "file_shares.access_row", {"row": row_id, "fields": sorted(fields),
                                                                   "chose": bool(choose)})
        return jsonable({"ok": True, "row": r, "counts": fa.counts(conn)})


class DriveIn(BaseModel):
    host_id: str = Field(..., max_length=40)
    drive: str = Field(..., max_length=3)
    audited: bool


@app.get(BASE + "/drives")
def fs_drives(host_id: str, user: str = Depends(require_viewer)):
    hid = _host(host_id)
    with db() as conn:
        return jsonable({"drives": fa.drives(conn, hid)})


@app.post(BASE + "/drives")
def fs_drive_set(body: DriveIn, request: Request, user: str = Depends(require_operator)):
    hid = _host(body.host_id)
    with db() as conn:
        with conn.transaction():
            _call(lambda: fa.set_drive(conn, hid, body.drive, body.audited, user))
            _audit(conn, user, request, "file_shares.drive", {"drive": body.drive.upper(), "audited": body.audited}, hid)
        return jsonable({"ok": True, "drives": fa.drives(conn, hid), "counts": fa.counts(conn)})


@app.get(BASE + "/groups")
def fs_groups(host_id: Optional[str] = None, user: str = Depends(require_viewer)):
    hid = _host(host_id) if host_id else None
    with db() as conn:
        return jsonable({"groups": fa.groups(conn, hid)})


class PairIn(BaseModel):
    import_id: str = Field(..., max_length=40)
    kind: Literal["group", "member"]
    group: str = Field(default="", max_length=300)
    value: str = Field(..., min_length=1, max_length=300)
    sid: Optional[str] = Field(default=None, pattern=SID)            # None: "not in AD"
    clear: bool = False


@app.post(BASE + "/groups/pair")
def fs_pair(body: PairIn, request: Request, user: str = Depends(require_operator)):
    iid = uuid_or_404(body.import_id, "No such workbook.")
    with db() as conn:
        with conn.transaction():
            if body.clear:
                fa.unpair(conn, iid, body.kind, body.group, body.value)
            else:
                _call(lambda: fa.pair(conn, iid, body.kind, body.group, body.value, body.sid, user))
            _audit(conn, user, request, "file_shares.pair", {"kind": body.kind, "group": body.group[:100],
                                                             "value": body.value[:100], "sid": body.sid, "clear": body.clear})
        return {"ok": True}


@app.get(BASE + "/accounts")
def fs_accounts(host_id: Optional[str] = None, q: str = "", kind: Optional[Literal["group", "user"]] = None,
                user: str = Depends(require_viewer)):
    hid = _host(host_id) if host_id else None
    with db() as conn:
        return jsonable({"items": fa.accounts(conn, hid, q[:100], kind)})


@app.get(BASE + "/access/export")
def fs_access_export(request: Request, format: str = "xlsx", host_id: Optional[str] = None,
                     user: str = Depends(require_viewer)):
    if format not in ("pdf", "xlsx"):
        raise HTTPException(400, "format is pdf or xlsx")
    hid = _host(host_id) if host_id else None
    from . import exports as ex
    from . import file_share_access_report as rep
    with db() as conn:
        data, media, ext = rep.render(conn, format, user, hid)
        _audit(conn, user, request, "file_shares.access_export", {"format": format, "server": hid or "all"}, hid)
    return Response(content=data, media_type=media,
                    headers={"Content-Disposition": f'attachment; filename="{ex.file_name("file-share-access", ext)}"'})
