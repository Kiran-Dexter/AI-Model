"""File shares (r146): what is stored, and the views of it the page and the reports use. The rules themselves are
in file_shares.py."""

import json
import re

from . import file_shares as fs

KEEP_SCANS = 3                 # done scans kept per server (r147 compares the last two)
STALE_MINUTES = 45             # a running scan that sent nothing for this long has stopped
LIST_DEPTH = 3                 # folders listed down to this depth below each share
WALK_DEPTH = 64
ASK_MAX = 2000                 # workbook paths the scanner is asked to look for


class FsError(Exception):
    """Shown to the user as it is (400)."""


class NotFound(Exception):
    pass


def _j(v):
    return json.dumps(v, default=str)


# ---------------------------------------------------------------------------
# Servers and scans
# ---------------------------------------------------------------------------

def hosts(conn):
    """The audited servers, each with its last scan."""
    rows = conn.execute(
        """SELECT h.id, h.hostname, h.fqdn, h.os_version, h.status, h.last_checkin, s.added_by, s.added_at
             FROM file_share_servers s JOIN hosts h ON h.id = s.host_id
            ORDER BY lower(h.hostname)""").fetchall()
    out = []
    for r in rows:
        r = dict(r)
        r["id"] = str(r["id"])
        r["scan"] = last_scan(conn, r["id"], any_state=True)
        r["done"] = last_scan(conn, r["id"])
        out.append(r)
    return out


def candidates(conn):
    """Windows servers that could be added."""
    return [dict(r, id=str(r["id"])) for r in conn.execute(
        """SELECT h.id, h.hostname, h.fqdn FROM hosts h
            WHERE h.os_id = 'windows' AND h.status <> 'decommissioned'
              AND NOT EXISTS (SELECT 1 FROM file_share_servers s WHERE s.host_id = h.id)
            ORDER BY lower(h.hostname)""").fetchall()]


def add_server(conn, host_id, user):
    h = conn.execute("SELECT id, os_id, status, hostname FROM hosts WHERE id = %s", (host_id,)).fetchone()
    if not h:
        raise NotFound("No such server.")
    if h["os_id"] != "windows" or h["status"] == "decommissioned":
        raise FsError(f"{h['hostname']} is not a Windows server in use: only those can be audited.")
    conn.execute("INSERT INTO file_share_servers (host_id, added_by) VALUES (%s, %s) ON CONFLICT DO NOTHING", (host_id, user))
    return h["hostname"]


def remove_server(conn, host_id):
    r = conn.execute("DELETE FROM file_share_servers WHERE host_id = %s RETURNING host_id", (host_id,)).fetchone()
    if not r:
        raise NotFound("That server is not audited.")


def last_scan(conn, host_id, any_state=False):
    r = conn.execute(
        """SELECT id, state, requested_by, created_at, picked_at, started_at, last_part_at, finished_at, scanner_version, parts,
                  totals, error,
                  (state IN ('queued', 'running')
                   AND coalesce(last_part_at, started_at, created_at) < now() - make_interval(mins => %s)) AS stalled
             FROM file_share_scans WHERE host_id = %s""" + ("" if any_state else " AND state = 'done'") + """
            ORDER BY created_at DESC LIMIT 1""", (STALE_MINUTES, host_id)).fetchone()
    if not r:
        return None
    r = dict(r)
    r["id"] = str(r["id"])
    return r


def queue_scan(conn, host_id, user):
    if not conn.execute("SELECT 1 FROM file_share_servers WHERE host_id = %s FOR UPDATE", (host_id,)).fetchone():
        raise FsError("Add the server to the audit first.")
    cur = last_scan(conn, host_id, any_state=True)
    if cur and cur["state"] in ("queued", "running") and not cur["stalled"]:
        raise FsError("A scan of this server is already " + cur["state"] + ".")
    if cur and cur["stalled"]:
        conn.execute("UPDATE file_share_scans SET state = 'cancelled', finished_at = now(), error = %s WHERE id = %s",
                     (stalled_why(cur), cur["id"]))
    sid = str(conn.execute("INSERT INTO file_share_scans (host_id, requested_by) VALUES (%s, %s) RETURNING id",
                           (host_id, user)).fetchone()["id"])
    conn.execute(
        """INSERT INTO agent_commands (host_id, verb, params, expires_at)
           VALUES (%s, 'access_scan', %s, now() + interval '24 hours')""",
        (host_id, _j({"scan_id": sid, "shares": [], "paths": asked_paths(conn, host_id), "depth": LIST_DEPTH,
                      "max_depth": WALK_DEPTH, "members": True})))
    return sid


def stalled_why(s):
    if not s["picked_at"]:
        return (f"The server's agent did not pick the scan up within {STALE_MINUTES} minutes: is the agent running and "
                "checking in (Servers page)?")
    if not s["started_at"]:
        return ("The agent started the scanner, but the scanner never reported. Check that access-scan.ps1 on the server "
                "is version 2 (its first lines say 2.0.0): an older one sends to an address PATCH-01 no longer has. "
                "Its log is C:\\ProgramData\\PatchAgent\\access-scan.log.")
    return f"Nothing arrived from the scanner for {STALE_MINUTES} minutes (its log: C:\\ProgramData\\PatchAgent\\access-scan.log)."


def agent_answered(conn, host_id, scan_id, ok, message):
    """The agent's answer to the access_scan command: it started the scanner, or it could not."""
    if ok:
        conn.execute("UPDATE file_share_scans SET picked_at = now() WHERE id = %s AND host_id = %s AND state IN ('queued', 'running')",
                     (scan_id, host_id))
    else:
        conn.execute("""UPDATE file_share_scans SET state = 'failed', finished_at = now(), error = %s
                         WHERE id = %s AND host_id = %s AND state IN ('queued', 'running')""",
                     (("The agent could not start the scanner: " + (message or "no reason given"))[:2000], scan_id, host_id))


def pending_import(conn):
    r = conn.execute("SELECT id FROM file_share_imports WHERE state = 'preview' ORDER BY uploaded_at DESC LIMIT 1").fetchone()
    return get_import(conn, str(r["id"])) if r else None


def cancel_scan(conn, scan_id):
    r = conn.execute("""UPDATE file_share_scans SET state = 'cancelled', finished_at = now(), error = 'Cancelled on the page.'
                         WHERE id = %s AND state IN ('queued', 'running') RETURNING host_id""", (scan_id,)).fetchone()
    if not r:
        raise FsError("That scan is not queued or running.")
    conn.execute("""DELETE FROM agent_commands WHERE host_id = %s AND verb = 'access_scan' AND claimed_at IS NULL
                      AND params->>'scan_id' = %s""", (r["host_id"], scan_id))


def asked_paths(conn, host_id):
    """Paths the workbook names that the last scan did not list: the scanner looks for each one."""
    out = []
    for r in conn.execute("""SELECT candidates FROM file_share_rows WHERE host_id = %s AND outcome = 'orphan'
                               AND decision IS NULL ORDER BY id""", (host_id,)).fetchall():
        for k in r["candidates"] or []:
            if isinstance(k, str) and re.fullmatch(r'[a-z]:\\[^*?"<>|]{0,250}', k) and k not in out:
                out.append(k)
    from . import file_share_access as fa
    out += [k for k in fa.asked_paths(conn, host_id) if k not in out]
    return out[:ASK_MAX]


# ---------------------------------------------------------------------------
# What the scanner sends
# ---------------------------------------------------------------------------

def _scan_for(conn, scan_id, host_id, states):
    r = conn.execute("SELECT id, state FROM file_share_scans WHERE id = %s AND host_id = %s FOR UPDATE", (scan_id, host_id)).fetchone()
    if not r:
        raise NotFound("No such scan for this server.")
    if r["state"] not in states:
        raise FsError("This scan is " + r["state"] + ": nothing more is taken for it.")
    return r


def start(conn, scan_id, host_id, version):
    _scan_for(conn, scan_id, host_id, ("queued", "running"))
    for t in ("file_share_shares", "file_share_folders", "file_share_principals", "file_share_members"):
        conn.execute(f"DELETE FROM {t} WHERE scan_id = %s", (scan_id,))          # a scan started again starts clean
    conn.execute("""UPDATE file_share_scans SET state = 'running', started_at = now(), last_part_at = now(), parts = 0, seqs = '{}',
                           scanner_version = %s, error = NULL WHERE id = %s""", (version, scan_id))


def store_part(conn, scan_id, host_id, part):
    """One part of a scan. A part sent twice (the scanner retries one whose answer it did not get) is taken once."""
    _scan_for(conn, scan_id, host_id, ("running",))
    if conn.execute("SELECT 1 FROM file_share_scans WHERE id = %s AND %s = ANY(seqs)", (scan_id, int(part["seq"]))).fetchone():
        return False
    with conn.cursor() as cur:
        if part.get("shares"):
            cur.executemany(
                """INSERT INTO file_share_shares (scan_id, name, path, description, acl, error) VALUES (%s,%s,%s,%s,%s,%s)
                   ON CONFLICT (scan_id, name) DO UPDATE SET path = EXCLUDED.path, description = EXCLUDED.description,
                          acl = EXCLUDED.acl, error = EXCLUDED.error""",
                [(scan_id, s["name"], s["path"], s.get("description"), _j(s.get("acl") or []), s.get("error"))
                 for s in part["shares"]])
        if part.get("folders"):
            cur.executemany(
                """INSERT INTO file_share_folders (scan_id, path_key, path, share, depth, why, protected, explicit, owner_sid,
                                                   acl, below, error, partial)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                   ON CONFLICT (scan_id, path_key) DO UPDATE SET below = file_share_folders.below + EXCLUDED.below,
                          why = CASE WHEN file_share_folders.why = 'asked' THEN EXCLUDED.why ELSE file_share_folders.why END,
                          share = CASE WHEN EXCLUDED.depth = 0 THEN EXCLUDED.share ELSE file_share_folders.share END,
                          depth = LEAST(file_share_folders.depth, EXCLUDED.depth)""",
                [(scan_id, fs.key_of(f["path"]), f["path"], f["share"], f["depth"], f["why"], bool(f.get("protected")),
                  bool(f.get("explicit")), f.get("owner_sid"), _j(f.get("acl") or []), f.get("below") or 0, f.get("error"),
                  bool(f.get("partial")))
                 for f in part["folders"]])
        if part.get("principals"):
            cur.executemany(
                """INSERT INTO file_share_principals (scan_id, sid, name, kind, display, email, department, enabled, members,
                                                      lookup_failed)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                   ON CONFLICT (scan_id, sid) DO UPDATE SET name = coalesce(EXCLUDED.name, file_share_principals.name),
                          kind = EXCLUDED.kind, display = coalesce(EXCLUDED.display, file_share_principals.display),
                          email = coalesce(EXCLUDED.email, file_share_principals.email),
                          department = coalesce(EXCLUDED.department, file_share_principals.department),
                          enabled = coalesce(EXCLUDED.enabled, file_share_principals.enabled),
                          members = coalesce(EXCLUDED.members, file_share_principals.members),
                          lookup_failed = EXCLUDED.lookup_failed AND file_share_principals.name IS NULL""",
                [(scan_id, p["sid"], p.get("name"), p["kind"], p.get("display"), p.get("email"), p.get("department"),
                  p.get("enabled"), p.get("members"), bool(p.get("lookup_failed"))) for p in part["principals"]])
        if part.get("members"):
            cur.executemany(
                """INSERT INTO file_share_members (scan_id, group_sid, user_sid) VALUES (%s,%s,%s) ON CONFLICT DO NOTHING""",
                [(scan_id, m["group"], m["user"]) for m in part["members"]])
        if part.get("below"):                 # folders that only inherit, counted on a folder already sent
            cur.executemany(
                """UPDATE file_share_folders SET below = below + %s WHERE scan_id = %s AND path_key = %s""",
                [(int(n), scan_id, fs.key_of(p)) for p, n in part["below"].items()])
    conn.execute("UPDATE file_share_scans SET parts = parts + 1, seqs = array_append(seqs, %s), last_part_at = now() WHERE id = %s",
                 (int(part["seq"]), scan_id))
    return True


def finish(conn, scan_id, host_id, ok, error, totals):
    if _scan_for(conn, scan_id, host_id, ("running", "done"))["state"] == "done":
        return                                    # sent again (the first answer was lost): it is done already
    conn.execute("""UPDATE file_share_scans SET state = %s, finished_at = now(), error = %s, totals = %s WHERE id = %s AND state = 'running'""",
                 ("done" if ok else "failed", None if ok else (error or "The scanner gave no reason.")[:2000],
                  _j(totals or {}), scan_id))
    if not ok:
        return
    compute_risks(conn, scan_id)
    rematch(conn, host_id)
    from . import file_share_access as fa
    fa.rematch(conn, host_id=host_id)                 # the access review workbooks of this server against the new scan
    old = [r["id"] for r in conn.execute(
        """SELECT id FROM file_share_scans WHERE host_id = %s AND state <> 'running' AND id NOT IN
             (SELECT id FROM file_share_scans WHERE host_id = %s AND state = 'done' ORDER BY created_at DESC LIMIT %s)
            AND created_at < (SELECT created_at FROM file_share_scans WHERE id = %s)""",
        (host_id, host_id, KEEP_SCANS, scan_id)).fetchall()]
    for i in old:
        conn.execute("DELETE FROM file_share_scans WHERE id = %s", (i,))


# ---------------------------------------------------------------------------
# One scan, as the rules need it
# ---------------------------------------------------------------------------

def load(conn, scan_id, acl=True):
    shares = [dict(r) for r in conn.execute(
        "SELECT name, path, description, acl, error FROM file_share_shares WHERE scan_id = %s ORDER BY lower(name)",
        (scan_id,)).fetchall()]
    folders = [dict(r) for r in conn.execute(
        "SELECT path_key, path, share, depth, why, protected, explicit, owner_sid, below, error, partial, risks"
        + (", acl" if acl else "") + " FROM file_share_folders WHERE scan_id = %s ORDER BY path_key", (scan_id,)).fetchall()]
    princ = {r["sid"]: dict(r) for r in conn.execute(
        "SELECT sid, name, kind, display, email, department, enabled, members, lookup_failed FROM file_share_principals WHERE scan_id = %s",
        (scan_id,)).fetchall()}
    return {"shares": shares, "folders": folders, "principals": princ}


def groups_of(conn, scan_id, user_sid):
    return {r["group_sid"] for r in conn.execute(
        "SELECT group_sid FROM file_share_members WHERE scan_id = %s AND user_sid = %s", (scan_id, user_sid)).fetchall()}


def all_domain_groups(principals):
    return {s for s, p in principals.items() if p.get("members") == "all_domain_users"}


def wide_sids(principals):
    return {fs.EVERYONE, fs.AUTH_USERS, fs.NETWORK, fs.BUILTIN_USERS} | all_domain_groups(principals)


def compute_risks(conn, scan_id):
    d = load(conn, scan_id)
    share_acl = {s["name"]: s["acl"] for s in d["shares"]}
    wide = wide_sids(d["principals"])
    rows = []
    for f in d["folders"]:
        r = fs.risks(f, share_acl.get(f["share"]) or [], d["principals"], [wide])
        if r != (f.get("risks") or []):
            rows.append((r, scan_id, f["path_key"]))
    if rows:
        with conn.cursor() as cur:
            cur.executemany("UPDATE file_share_folders SET risks = %s WHERE scan_id = %s AND path_key = %s", rows)


# ---------------------------------------------------------------------------
# The ownership register
# ---------------------------------------------------------------------------

ROW_COLS = """id, import_id, sheet, row_no, host_id, path_text, share_text, folder_text, department, owner, email, details,
              set_key, outcome, how, folder_key, candidates, decision, decided_key, decided_by, decided_at, edited, sig"""


def _host_of(conn, host_id):
    h = conn.execute("SELECT id, hostname, fqdn FROM hosts WHERE id = %s", (host_id,)).fetchone()
    return dict(h, id=str(h["id"])) if h else None


def rematch(conn, host_id, row_id=None):
    """Match every row of this server (or the one row) to its last scan again."""
    scan = last_scan(conn, host_id)
    rows = conn.execute(f"SELECT {ROW_COLS} FROM file_share_rows WHERE host_id = %s" + (" AND id = %s" if row_id else ""),
                        (host_id, row_id) if row_id else (host_id,)).fetchall()
    if not rows:
        return
    if not scan:
        upd = [("orphan", "The server has not been scanned yet", None, "[]", r["id"]) for r in rows]
    else:
        d = load(conn, scan["id"], acl=False)
        idx = fs.scan_index(_host_of(conn, host_id), d["shares"], d["folders"], (scan["totals"] or {}).get("missing") or [])
        upd = []
        for r in rows:
            o, how, k, cands = fs.resolve(dict(r), idx)
            upd.append((o, how, k, _j(cands), r["id"]))
    with conn.cursor() as cur:
        cur.executemany("UPDATE file_share_rows SET outcome = %s, how = %s, folder_key = %s, candidates = %s WHERE id = %s", upd)


def state_of(r, keys):
    """What a row is now: owner, doubt, orphan, rejected or empty (keys: the folders of the last scan)."""
    if r["decision"] == "rejected":
        return "rejected"
    if r["decision"] == "approved":
        return "owner" if r["decided_key"] in keys else "orphan"
    return {"mapped": "owner", "doubt": "doubt", "empty": "empty"}.get(r["outcome"], "orphan")


def owner_key(r):
    return r["decided_key"] if r["decision"] == "approved" else r["folder_key"]


def _norm(t):
    return re.sub(r"\s+", " ", (t or "").strip().lower())


def owners(rows, keys):
    """{folder key: the row that owns it}, and the rows in conflict: two rows giving one folder different owners,
    neither decided on the page."""
    by = {}
    for r in rows:
        if state_of(r, keys) == "owner":
            by.setdefault(owner_key(r), []).append(r)
    out, conflict = {}, set()
    for k, rs in by.items():
        decided = [r for r in rs if r["decision"] == "approved"]
        pool = decided or rs
        if len({(_norm(r["owner"]), _norm(r["department"])) for r in pool}) > 1:
            conflict.update(r["id"] for r in pool)
            continue
        out[k] = sorted(pool, key=lambda r: r["id"])[-1]
    return out, conflict


def view(conn, host_id):
    """One server as the page and the reports show it."""
    h = _host_of(conn, host_id)
    scan = last_scan(conn, host_id)
    rows = [dict(r, id=r["id"], host_id=str(r["host_id"]) if r["host_id"] else None) for r in conn.execute(
        f"SELECT {ROW_COLS} FROM file_share_rows WHERE host_id = %s ORDER BY sheet, row_no NULLS LAST, id", (host_id,)).fetchall()]
    d = load(conn, scan["id"], acl=False) if scan else {"shares": [], "folders": [], "principals": {}}
    keys = {f["path_key"] for f in d["folders"]}
    own, conflict = owners(rows, keys)
    for r in rows:
        r["state"] = "doubt" if r["id"] in conflict else state_of(r, keys)
        if r["id"] in conflict:
            r["how"] = "Two rows give this folder different owners: reject the wrong one, or edit it"
    states = fs.ownership(d["folders"], set(own)) if scan else {}
    return {"host": h, "scan": scan, "shares": d["shares"], "folders": d["folders"], "principals": d["principals"],
            "rows": rows, "owners": own, "own_state": states, "keys": keys,
            "paths": {f["path_key"]: f["path"] for f in d["folders"]}, "by_key": {f["path_key"]: f for f in d["folders"]}}


def folder_owner(v, key):
    row, at = fs.owner_of(key, v["owners"], v["keys"])
    if not row:
        return None
    return {"owner": row["owner"], "department": row["department"], "email": row["email"], "row_id": row["id"],
            "from": at, "from_path": v["paths"].get(at, at), "inherited": at != key}


# ---------------------------------------------------------------------------
# Decisions on rows
# ---------------------------------------------------------------------------

def _row(conn, row_id):
    r = conn.execute(f"SELECT {ROW_COLS} FROM file_share_rows WHERE id = %s", (row_id,)).fetchone()
    if not r:
        raise NotFound("No such row.")
    return dict(r)


def _folder_in_scan(conn, host_id, key):
    scan = last_scan(conn, host_id)
    if not scan or not conn.execute("SELECT 1 FROM file_share_folders WHERE scan_id = %s AND path_key = %s",
                                    (scan["id"], key)).fetchone():
        raise FsError("That folder is not in the last scan of the server.")


def decide(conn, row_id, action, user, folder_key=None, fields=None):
    r = _row(conn, row_id)
    if not r["host_id"]:
        raise FsError("This row names no audited server: choose the sheet's server and upload the workbook again.")
    fields = fields or {}
    if action == "approve":
        k = fs.key_of(folder_key) if folder_key else r["folder_key"]
        if not k:
            raise FsError("Choose the folder this row is for.")
        _folder_in_scan(conn, r["host_id"], k)
        conn.execute("""UPDATE file_share_rows SET decision = 'approved', decided_key = %s, decided_by = %s, decided_at = now()
                         WHERE id = %s""", (k, user, row_id))
    elif action == "reject":
        conn.execute("""UPDATE file_share_rows SET decision = 'rejected', decided_key = NULL, decided_by = %s, decided_at = now()
                         WHERE id = %s""", (user, row_id))
    elif action == "undo":
        conn.execute("""UPDATE file_share_rows SET decision = NULL, decided_key = NULL, set_key = NULL, decided_by = %s,
                               decided_at = now() WHERE id = %s""", (user, row_id))
        rematch(conn, str(r["host_id"]), row_id)
    elif action == "edit":
        k = fs.key_of(folder_key) if folder_key else (r["decided_key"] or r["folder_key"])
        if not k:
            raise FsError("Choose the folder this row is for.")
        _folder_in_scan(conn, r["host_id"], k)
        vals = {f: (str(fields.get(f, r[f]) or "").strip())[:300] for f in ("department", "owner", "email")}
        if not vals["owner"] and not vals["department"]:
            raise FsError("Give the owner or the department.")
        conn.execute("""UPDATE file_share_rows SET department = %s, owner = %s, email = %s, set_key = %s, decision = 'approved',
                               decided_key = %s, decided_by = %s, decided_at = now(), edited = true WHERE id = %s""",
                     (vals["department"], vals["owner"], vals["email"], k, k, user, row_id))
        rematch(conn, str(r["host_id"]), row_id)
    else:
        raise FsError("Unknown action.")
    return _row(conn, row_id)


def add_owner(conn, host_id, folder_key, fields, user):
    k = fs.key_of(folder_key)
    _folder_in_scan(conn, host_id, k)
    vals = {f: (str(fields.get(f) or "").strip())[:300] for f in ("department", "owner", "email")}
    if not vals["owner"] and not vals["department"]:
        raise FsError("Give the owner or the department.")
    rid = conn.execute(
        """INSERT INTO file_share_rows (sheet, host_id, path_text, department, owner, email, set_key, outcome, how, folder_key,
                                        decision, decided_key, decided_by, decided_at)
           VALUES ('Added on the page', %s, %s, %s, %s, %s, %s, 'mapped', 'Chosen on the page', %s, 'approved', %s, %s, now())
           RETURNING id""", (host_id, k, vals["department"], vals["owner"], vals["email"], k, k, k, user)).fetchone()["id"]
    return rid


# ---------------------------------------------------------------------------
# The workbook
# ---------------------------------------------------------------------------

def preview(conn, file_name, data, user):
    from . import asset_import as ai
    try:
        sheets = ai.read_all(file_name, data)
    except ai.SheetError as e:
        raise FsError(str(e))
    from . import file_share_access as fa
    if fa.is_access_workbook(sheets):                # r149: the access review workbook (Folder, Member Listing, Description)
        try:
            return fa.preview(conn, file_name, sheets, user)
        except fa.AccessError as e:
            raise FsError(str(e))
    audited = [dict(h) for h in hosts(conn)]
    out = []
    for name, rows in sheets:
        hi = fs.header_row(rows)
        head = rows[hi]
        body = [r for r in rows[hi + 1:] if any(c.strip() for c in r)]
        if not body:
            continue
        cols = fs.guess_columns(head)
        cells = [r[cols["server"]] for r in body if "server" in cols and cols["server"] < len(r)] + \
                [r[cols["path"]] for r in body if "path" in cols and cols["path"] < len(r)]
        hid, why = fs.guess_server(name, cells, audited)
        out.append({"name": name, "header": head, "rows": body, "columns": cols, "host_id": hid, "host_why": why,
                    "use": True})
    if not out:
        raise FsError("No sheet of the workbook has a header and rows under it.")
    iid = str(conn.execute("INSERT INTO file_share_imports (file_name, uploaded_by, sheets) VALUES (%s, %s, %s) RETURNING id",
                           ((file_name or "workbook")[:200], user, _j(out))).fetchone()["id"])
    return get_import(conn, iid)


def get_import(conn, iid):
    r = conn.execute("SELECT id, file_name, uploaded_by, uploaded_at, state, sheets, applied_by, applied_at, kind "
                     "FROM file_share_imports WHERE id = %s", (iid,)).fetchone()
    if not r:
        raise NotFound("No such upload.")
    if r["kind"] == "access":
        from . import file_share_access as fa
        return fa.get_preview(conn, iid)
    r = dict(r)
    r["id"] = str(r["id"])
    r["sheets"] = [{k: v for k, v in s.items() if k != "rows"} | {"count": len(s["rows"]), "sample": s["rows"][:5]}
                   for s in r["sheets"]]
    r["fields"] = [{"key": f, "label": fs.FIELD_LABEL[f]} for f in fs.FIELDS]
    return r


def discard(conn, iid):
    if not conn.execute("UPDATE file_share_imports SET state = 'discarded' WHERE id = %s AND state = 'preview' RETURNING id",
                        (iid,)).fetchone():
        raise FsError("Only an upload not used yet can be discarded.")


def apply(conn, iid, choices, user):
    """Use the workbook: its rows replace the last workbook's (rows added on the page stay); a decision made on a
    row is kept when the new workbook has the same row."""
    r = conn.execute("SELECT state, sheets, kind FROM file_share_imports WHERE id = %s FOR UPDATE", (iid,)).fetchone()
    if not r:
        raise NotFound("No such upload.")
    if r["kind"] == "access":
        raise FsError("This is an access review workbook: use it from the page's Use the workbook.")
    if r["state"] != "preview":
        raise FsError("This upload was already " + r["state"] + ".")
    audited = {h["id"] for h in hosts(conn)}
    by_name = {s["name"]: s for s in r["sheets"]}
    take = []
    for c in choices:
        s = by_name.get(c.get("name"))
        if not s or not c.get("use"):
            continue
        hid = c.get("host_id")
        if hid not in audited:
            raise FsError(f"Choose the server of the sheet '{s['name']}' (an audited server).")
        cols = {}
        for f in fs.FIELDS:
            i = (c.get("columns") or {}).get(f)
            if i is None or i == "":
                continue
            i = int(i)
            if not 0 <= i < len(s["header"]):
                raise FsError(f"The sheet '{s['name']}': a column chosen for {fs.FIELD_LABEL[f]} is not in the sheet.")
            if i in cols.values():
                raise FsError(f"The sheet '{s['name']}': one column is chosen for two fields.")
            cols[f] = i
        if not ({"path", "share", "folder"} & set(cols)):
            raise FsError(f"The sheet '{s['name']}': choose the column with the path, the share or the folder.")
        if not ({"owner", "department"} & set(cols)):
            raise FsError(f"The sheet '{s['name']}': choose the column with the owner or the department.")
        take.append((s, hid, cols))
    if not take:
        raise FsError("Choose at least one sheet to use.")
    hosts_in = sorted({hid for _s, hid, _c in take})
    old = {o["sig"]: o for o in conn.execute(
        f"""SELECT {ROW_COLS} FROM file_share_rows WHERE import_id IS NOT NULL AND decision IS NOT NULL AND sig IS NOT NULL
             AND host_id = ANY(%s::uuid[])""", (hosts_in,)).fetchall()}
    conn.execute("DELETE FROM file_share_rows WHERE import_id IS NOT NULL AND host_id = ANY(%s::uuid[])", (hosts_in,))
    n = 0
    for s, hid, cols in take:
        hi = s["rows"]
        for i, cells in enumerate(hi):
            f = fs.row_fields(cells, cols, s["header"])
            sig = _row_sig(hid, f)
            prev = old.get(sig)
            keep = prev if prev and prev["edited"] else f          # what was changed on the page stays changed
            conn.execute(
                """INSERT INTO file_share_rows (import_id, sheet, row_no, host_id, path_text, share_text, folder_text,
                                                department, owner, email, details, set_key, decision, decided_key, decided_by,
                                                decided_at, edited, sig)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (iid, s["name"], i + 1, hid, f["path"], f["share"], f["folder"], keep["department"], keep["owner"], keep["email"],
                 _j(f["details"]), prev["set_key"] if prev else None, prev["decision"] if prev else None,
                 prev["decided_key"] if prev else None, prev["decided_by"] if prev else None,
                 prev["decided_at"] if prev else None, bool(prev and prev["edited"]), sig))
            n += 1
    conn.execute("UPDATE file_share_imports SET state = 'applied', applied_by = %s, applied_at = now() WHERE id = %s", (user, iid))
    conn.execute("UPDATE file_share_imports SET state = 'discarded' WHERE state = 'preview' AND id <> %s", (iid,))
    for h in hosts_in:
        rematch(conn, h)
    return n


def _row_sig(host_id, f):
    """A workbook row in one form: the same row in the next workbook is recognised by it."""
    return "|".join((str(host_id), fs.key_of(f["path"]), _norm(f["share"]), _norm(f["folder"]), _norm(f["owner"]),
                     _norm(f["department"])))


def last_import(conn):
    r = conn.execute("""SELECT id, file_name, uploaded_by, applied_by, applied_at FROM file_share_imports
                         WHERE state = 'applied' ORDER BY applied_at DESC LIMIT 1""").fetchone()
    return dict(r, id=str(r["id"])) if r else None


# ---------------------------------------------------------------------------
# What the page and the reports show
# ---------------------------------------------------------------------------

def views(conn, host_id=None):
    return [view(conn, h["id"]) for h in hosts(conn) if not host_id or h["id"] == host_id]


def _plural(n, one, many=None):
    return f"{n:,} {one if n == 1 else (many or one + 's')}"


def _count(t, k):
    try:
        return max(0, int(t.get(k) or 0))
    except (TypeError, ValueError):
        return 0


def _gaps(p):
    """One server's blind spots, as the scanner counted them (scanner 2.0.0): '' when it read everything."""
    t = (p["scan"] or {}).get("totals") or {}
    bits = []
    if t.get("truncated") is True:
        bits.append("the scan stopped after 10 hours, so the folders it had not reached yet are not in this report")
    if _count(t, "too_long"):
        bits.append(f"{_plural(_count(t, 'too_long'), 'folder')} with a path longer than 4,000 characters "
                    "left out, with the folders below")
    if _count(t, "attributes_unread"):
        bits.append(f"{_plural(_count(t, 'attributes_unread'), 'folder')} not opened: Windows did not say whether "
                    + ("it is a link" if _count(t, "attributes_unread") == 1 else "they are links"))
    if _count(t, "deeper_than_max"):
        bits.append(f"{_plural(_count(t, 'deeper_than_max'), 'folder')} more than 64 levels down not read")
    if _count(t, "accounts_not_looked_up"):
        bits.append(f"{_plural(_count(t, 'accounts_not_looked_up'), 'account')} whose name could not be looked up "
                    "(a domain controller did not answer)")
    same = [x for x in (t.get("same_path") or []) if isinstance(x, str) and " = " in x][:20]
    for x in same:
        second, first = x.split(" = ", 1)
        bits.append(f"the share {second[:80]} opens the same folder as {first[:80]}: its folders are shown under "
                    f"{first[:80]}, and {second[:80]}'s own share permissions are not counted in the rights shown")
    ad = t.get("ad")
    if isinstance(ad, str) and ad.startswith("not reached"):
        bits.append("Active Directory did not answer, so the people in groups were not read")
    elif isinstance(ad, str) and ad.startswith("partly"):
        bits.append("some Active Directory lookups failed, so some groups' people may be missing")
    if not bits:
        return ""
    return p["host"]["hostname"] + ": " + "; ".join(bits) + "."


def summary(vs):
    """The figures, per server and in all, and the words that go with them."""
    per, tot = [], {}
    deps, risk_n = {}, {k: 0 for k, _, _ in fs.RISKS}
    for v in vs:
        t = (v["scan"] or {}).get("totals") or {}
        st = v["own_state"]
        rows = v["rows"]
        n = {"shares": len(v["shares"]), "walked": int(t.get("walked") or 0), "listed": len(v["folders"]),
             "own_perms": sum(1 for f in v["folders"] if f["explicit"] or f["protected"]),
             "unreadable": sum(1 for f in v["folders"] if f.get("error") and not f.get("partial")) + int(t.get("unreadable_below") or 0),
             "owned": sum(1 for s in st.values() if s == "owned"), "missing": sum(1 for s in st.values() if s == "missing"),
             "rows": len([r for r in rows if r["state"] != "empty"]),
             "matched": sum(1 for r in rows if r["state"] == "owner"), "doubt": sum(1 for r in rows if r["state"] == "doubt"),
             "orphan": sum(1 for r in rows if r["state"] == "orphan"), "rejected": sum(1 for r in rows if r["state"] == "rejected")}
        n["with_risk"] = sum(1 for f in v["folders"] if f.get("risks"))
        for f in v["folders"]:
            for k in f.get("risks") or []:
                risk_n[k] = risk_n.get(k, 0) + 1
        for k, s in st.items():
            if s != "owned":
                continue
            o = folder_owner(v, k)
            d = ((o or {}).get("department") or "").strip() or "No department given"
            deps[d] = deps.get(d, 0) + 1
        per.append({"host": v["host"], "scan": v["scan"], "n": n})
        for k, x in n.items():
            tot[k] = tot.get(k, 0) + x
    need = tot.get("owned", 0) + tot.get("missing", 0)
    pct = round(100 * tot.get("owned", 0) / need) if need else None
    words = []
    scanned = [p for p in per if p["scan"]]
    if not per:
        words.append("No file server is being audited yet.")
    elif not scanned:
        words.append("None of the audited servers has been scanned yet.")
    else:
        words.append(f"{_plural(len(scanned), 'file server')} scanned: {_plural(tot.get('shares', 0), 'share')}, "
                     f"{_plural(tot.get('walked', 0), 'folder')} read, of which {tot.get('own_perms', 0):,} carry "
                     "permissions of their own; the others take theirs from the folder above.")
        if need:
            words.append(f"Ownership: {tot.get('owned', 0):,} of {need:,} shares and folders that need an owner have one "
                         f"({pct}%)." + (f" {_plural(tot['missing'], 'folder')} still need one." if tot.get("missing") else
                                         " Every one is accounted for."))
        if tot.get("rows"):
            words.append(f"The ownership workbook: {tot.get('matched', 0):,} of {tot['rows']:,} rows matched a folder"
                         + (f"; {_plural(tot['doubt'], 'row')} wait for you to confirm" if tot.get("doubt") else "")
                         + (f"; {_plural(tot['orphan'], 'row')} name a folder that is not on the server" if tot.get("orphan") else "")
                         + (f"; {tot['rejected']:,} rejected" if tot.get("rejected") else "") + ".")
        else:
            words.append("No ownership workbook has been used yet: upload it to tag each folder's department and owner.")
        top = [(k, risk_n[k]) for k, _, _ in fs.RISKS if risk_n.get(k) and k != "unreadable"]
        if top:
            words.append("Worth a look: " + "; ".join(f"{fs.RISK_LABEL[k][0].lower() + fs.RISK_LABEL[k][1:]} on {_plural(n, 'folder')}"
                                                      for k, n in top) + ".")
        else:
            words.append("No folder shows any of the risks checked.")
        if tot.get("unreadable"):
            words.append(f"{_plural(tot['unreadable'], 'folder')} could not be read by the scanner: "
                         + ("it is" if tot["unreadable"] == 1 else "they are") + " listed under Could not be read.")
        gaps = [g for g in (_gaps(p) for p in scanned) if g]
        if gaps:
            words.append("What the last scan could not cover: " + " ".join(gaps))
    return {"servers": per, "total": tot, "owned_pct": pct, "departments": sorted(deps.items(), key=lambda x: (-x[1], x[0])),
            "risks": [{"key": k, "label": l, "why": w, "n": risk_n.get(k, 0)} for k, l, w in fs.RISKS], "words": words}


def _row_out(r, v):
    keys, paths = v["keys"], v["paths"]
    k = r["decided_key"] if r["decision"] == "approved" else r["folder_key"]
    return {"id": r["id"], "sheet": r["sheet"], "row_no": r["row_no"], "server": v["host"]["hostname"],
            "host_id": v["host"]["id"], "path_text": r["path_text"], "share_text": r["share_text"],
            "folder_text": r["folder_text"], "department": r["department"], "owner": r["owner"], "email": r["email"],
            "details": r["details"], "state": r["state"], "how": r["how"], "decision": r["decision"],
            "decided_by": r["decided_by"], "decided_at": r["decided_at"],
            "folder_key": k, "folder": paths.get(k) if k in keys else None,
            "candidates": [{"key": c, "path": paths.get(c) or c, "found": c in keys} for c in r["candidates"] or []]}


def review(vs, kind):
    """The rows or folders of one kind: doubt, orphan, missing, matched, rejected."""
    out = []
    for v in vs:
        if kind == "missing":
            fo = v["by_key"]
            for k, s in sorted(v["own_state"].items()):
                if s == "missing":
                    f = fo[k]
                    out.append({"server": v["host"]["hostname"], "host_id": v["host"]["id"], "folder_key": k, "folder": f["path"],
                                "share": f["share"], "depth": f["depth"], "below": f["below"], "risks": f.get("risks") or []})
            continue
        want = {"doubt": ("doubt",), "orphan": ("orphan",), "matched": ("owner",), "rejected": ("rejected",)}[kind]
        out += [_row_out(r, v) for r in v["rows"] if r["state"] in want]
    return out


def folders(v, share=None, q=None, risk=None, state=None, limit=500):
    out = []
    ql = (q or "").strip().lower()
    for f in v["folders"]:
        if share and f["share"] != share:
            continue
        if ql and ql not in f["path_key"]:
            continue
        if risk and risk not in (f.get("risks") or []):
            continue
        st = v["own_state"].get(f["path_key"])
        if state and st != state:
            continue
        o = folder_owner(v, f["path_key"])
        out.append({"key": f["path_key"], "path": f["path"], "share": f["share"], "depth": f["depth"], "explicit": f["explicit"],
                    "protected": f["protected"], "below": f["below"], "risks": f.get("risks") or [], "error": f.get("error"),
                    "state": st, "owner": o})
        if len(out) >= limit:
            break
    return out


def _named(p, sid):
    if p and p.get("name"):
        return p["name"]
    if p and p.get("lookup_failed"):
        return "SID not looked up " + sid
    return fs.WELL_KNOWN.get(sid) or ("Orphaned SID " + sid if sid.startswith("S-1-5-21-") else sid)


def _applies(a):
    here, kids = a.get("here", True), a.get("kids", True)
    if here and kids:
        return "This folder and below"
    if here:
        return "This folder only"
    return "Below only"


def who_has(f, share_acl, pr, groups, dom):
    """Every account and group named on the folder or its share, with what each gets through the share, NTFS and
    both (effective). groups: sid -> the groups a person is in."""
    sids = []
    for a in (share_acl or []) + (f["acl"] or []):
        s = a.get("sid")
        if s and s not in sids and s != fs.CREATOR_OWNER:
            sids.append(s)
    who = []
    for s in sids:
        p = pr.get(s) or {}
        kind = p.get("kind") or fs.kind_of_sid(s)
        callers = fs.caller_sids(s, kind, groups(s) if kind == "user" else [], dom)
        sm, nm = fs.share_rights(share_acl, callers), fs.evaluate(f["acl"], callers, f["owner_sid"])
        who.append({"sid": s, "name": _named(p, s), "kind": kind,
                    "orphan": not p.get("name") and not p.get("lookup_failed") and s.startswith("S-1-5-21-"),
                    "admin": fs.is_admin_sid(s), "share": fs.level_of(sm), "ntfs": fs.level_of(nm), "effective": fs.level_of(sm & nm),
                    "write": bool(sm & nm & fs.WRITE_BITS), "control": bool(sm & nm & fs.CONTROL_BITS),
                    "display": p.get("display"), "email": p.get("email")})
    who.sort(key=lambda w: (w["admin"], not w["write"], w["name"].lower()))
    return who


def memberships(conn, scan_id):
    out = {}
    for r in conn.execute("SELECT group_sid, user_sid FROM file_share_members WHERE scan_id = %s", (scan_id,)).fetchall():
        out.setdefault(r["user_sid"], set()).add(r["group_sid"])
    return out


def access(conn, v, limit=None):
    """Who can reach each share root and each folder with permissions of its own (the folders that only inherit get
    the same as the folder above)."""
    if not v["scan"]:
        return []
    rows = conn.execute("""SELECT path_key, path, share, depth, protected, explicit, owner_sid, acl, error, risks
                             FROM file_share_folders WHERE scan_id = %s AND (depth = 0 OR explicit OR protected)
                            ORDER BY path_key""" + (" LIMIT %s" % int(limit) if limit else ""), (v["scan"]["id"],)).fetchall()
    share_acl = {s["name"]: s["acl"] for s in v["shares"]}
    pr = v["principals"]
    mem = memberships(conn, v["scan"]["id"])
    dom = all_domain_groups(pr)
    out = []
    for f in rows:
        out.append({"path": f["path"], "key": f["path_key"], "share": f["share"], "depth": f["depth"], "protected": f["protected"],
                    "risks": f["risks"] or [], "owner": folder_owner(v, f["path_key"]),
                    "who": who_has(dict(f), share_acl.get(f["share"]) or [], pr, lambda sid: mem.get(sid, set()), dom)})
    return out


def folder_detail(conn, host_id, key):
    v = view(conn, host_id)
    if not v["scan"]:
        raise NotFound("The server has not been scanned yet.")
    f = conn.execute("""SELECT path_key, path, share, depth, why, protected, explicit, owner_sid, acl, below, error, partial, risks
                          FROM file_share_folders WHERE scan_id = %s AND path_key = %s""", (v["scan"]["id"], fs.key_of(key))).fetchone()
    if not f:
        raise NotFound("That folder is not in the last scan.")
    f = dict(f)
    share = next((s for s in v["shares"] if s["name"] == f["share"]), {"acl": [], "name": f["share"], "path": ""})
    pr = v["principals"]
    scan_id = v["scan"]["id"]
    who = who_has(f, share["acl"], pr, lambda sid: groups_of(conn, scan_id, sid), all_domain_groups(pr))
    entries = [{"name": _named(pr.get(a["sid"]), a["sid"]), "sid": a["sid"], "allow": a.get("allow", True),
                "level": fs.level_of(fs.mask_of(a.get("mask", 0))), "inherited": bool(a.get("inh")), "applies": _applies(a)}
               for a in f["acl"] or []]
    shares = [{"name": _named(pr.get(a["sid"]), a["sid"]), "sid": a["sid"], "allow": a.get("allow", True), "right": a.get("right")}
              for a in share["acl"] or []]
    return {"server": v["host"]["hostname"], "host_id": host_id, "folder": {k: f[k] for k in f if k != "acl"},
            "owner": folder_owner(v, f["path_key"]), "state": v["own_state"].get(f["path_key"]),
            "ntfs_owner": _named(pr.get(f["owner_sid"]), f["owner_sid"]) if f["owner_sid"] else None,
            "share": {"name": share["name"], "path": share.get("path"), "acl": shares}, "entries": entries, "who": who,
            "risks": [{"key": k, "label": fs.RISK_LABEL[k]} for k in f["risks"] or []], "scanned": v["scan"]["finished_at"]}


def effective(conn, host_id, key, sid):
    scan = last_scan(conn, host_id)
    if not scan:
        raise NotFound("The server has not been scanned yet.")
    f = conn.execute("SELECT path, share, acl, owner_sid FROM file_share_folders WHERE scan_id = %s AND path_key = %s",
                     (scan["id"], fs.key_of(key))).fetchone()
    if not f:
        raise NotFound("That folder is not in the last scan.")
    sh = conn.execute("SELECT acl FROM file_share_shares WHERE scan_id = %s AND name = %s", (scan["id"], f["share"])).fetchone()
    share_acl = (sh or {}).get("acl") or []
    pr = {r["sid"]: dict(r) for r in conn.execute(
        "SELECT sid, name, kind, display, email, department, enabled, members, lookup_failed FROM file_share_principals WHERE scan_id = %s",
        (scan["id"],)).fetchall()}
    if not fs.SID_RE.match(sid or ""):
        raise FsError("Not an account or group.")
    p = pr.get(sid) or {}
    kind = p.get("kind") or fs.kind_of_sid(sid)
    groups = groups_of(conn, scan["id"], sid) if kind == "user" else set()
    callers = fs.caller_sids(sid, kind, groups, all_domain_groups(pr))
    sm, nm = fs.share_rights(share_acl, callers), fs.evaluate(f["acl"], callers, f["owner_sid"])
    through_share = [{"name": _named(pr.get(a["sid"]), a["sid"]), "right": a.get("right"), "allow": a.get("allow", True)}
                     for a in share_acl if a.get("sid") in callers]
    through_ntfs = [{"name": _named(pr.get(a["sid"]), a["sid"]), "level": fs.level_of(fs.mask_of(a.get("mask", 0))),
                     "allow": a.get("allow", True), "inherited": bool(a.get("inh"))}
                    for a in f["acl"] or [] if a.get("sid") in callers and a.get("here", True)]
    return {"folder": f["path"], "share": f["share"], "who": {"sid": sid, "name": _named(p, sid), "kind": kind,
            "display": p.get("display"), "email": p.get("email"), "department": p.get("department"), "enabled": p.get("enabled"),
            "groups": len(groups)},
            "share_level": fs.level_of(sm), "ntfs_level": fs.level_of(nm), "effective_level": fs.level_of(sm & nm),
            "grid": fs.grid(sm, nm), "through_share": through_share, "through_ntfs": through_ntfs,
            "note": None if kind == "user" else "For a group: what the group itself is given, with Everyone-type groups. "
                    "Its members may get more through other groups: pick a person to see everything they get."}


def people(conn, host_id, q, limit=20):
    scan = last_scan(conn, host_id)
    q = (q or "").strip()
    if not scan or len(q) < 2:
        return []
    like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    return [dict(r) for r in conn.execute(
        """SELECT sid, name, kind, display, email, department, enabled FROM file_share_principals
            WHERE scan_id = %s AND kind IN ('user', 'group', 'local_group', 'well_known')
              AND (name ILIKE %s OR display ILIKE %s OR email ILIKE %s)
            ORDER BY (kind = 'user') DESC, lower(coalesce(display, name)) LIMIT %s""",
        (scan["id"], like, like, like, limit)).fetchall()]
