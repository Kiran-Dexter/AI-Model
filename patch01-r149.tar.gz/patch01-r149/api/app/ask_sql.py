"""The agent's own queries (r147): checked, then run read-only, as the asker may see the data.

The agent may write a query of its own when no prepared question fits. Nothing here trusts that query:

  * It runs under patch_ask, a login of its own (phase3a-schema.sh) that may read the views of schema ask and nothing
    else: no table of schema public, no secret column, no file (sql/zz-ask-views.sql). Never SET ROLE from patchapi: a query
    could switch back to it.
  * ask.modules and ask.role, which decide the rows each view gives, are set here for each query (set_config, local to
    the transaction), before the query runs.
  * Before it runs, PostgreSQL itself says what the query uses: it is made into a temporary view in a transaction that
    is rolled back, and every function, operator and table in the query tree PostgreSQL stored for it is looked up. It may use views of schema ask only, and
    functions that change nothing (immutable or stable, aggregates, window functions) of pg_catalog or ask, minus the
    few that run a query given to them as text. So set_config (to change ask.modules), pg_sleep, pg_read_file,
    lo_import and the like are refused, however they are spelled.
  * One statement (no ';'), SELECT or WITH, at most MAX_SQL characters; it runs as a subquery in a READ ONLY
    transaction, at most ROW_CAP rows, at most TIMEOUT_MS.
"""

import os
import re
import threading

MAX_SQL = 4000
ROW_CAP = 200
ROW_BYTES = 65536                   # a larger row stops the query in the database, before it is sent
CELL_MAX = 2000                     # characters of one value kept (stored, shown, given to the model)
TIMEOUT_MS = 8000
# Functions that run a query given to them as text, or read files and server state: refused whatever their volatility
# Also refused, though they change nothing: what writes a transaction id (txid_current), and the server's settings
# and the source of its objects, which no question about PATCH-01 needs
REFUSED_FUNCS = re.compile(r"(_to_xml|to_xmlschema|^ts_stat$|^ts_rewrite$|^query_to|^cursor_to|^pg_read|^pg_ls_|^pg_stat_|"
                           r"^lo_|^dblink|^pg_file|^pg_logdir|^pg_current_logfile|^set_config$|^pg_sleep|^txid_|"
                           r"^pg_current_xact|^pg_snapshot|^current_setting$|^pg_show_all_settings$|^pg_settings|"
                           r"^pg_get_\w*def$|^pg_get_viewdef$|^pg_blocking_pids$|^pg_advisory|^pg_try_advisory)")
PROBE = "ask_probe"


class Refused(Exception):
    """The query is not one the agent may run; the message says why, in words the agent and the person can read."""


class _Done(Exception):
    def __init__(self, deps):
        self.deps = deps


def wrap(sql):
    # a row over ROW_BYTES stops the query in the database (ask.too_big raises), so it is never sent to the API
    return (f"SELECT * FROM (\n{sql}\n) AS ask_q\n"
            f"WHERE CASE WHEN pg_column_size(ask_q.*) > {ROW_BYTES} THEN ask.too_big() ELSE true END LIMIT {ROW_CAP + 1}")


def check_text(sql):
    q = (sql or "").strip()
    while q.endswith(";"):
        q = q[:-1].rstrip()
    if not q:
        raise Refused("The query is empty.")
    if len(q) > MAX_SQL:
        raise Refused(f"The query is longer than {MAX_SQL} characters.")
    if ";" in q:
        raise Refused("Only one statement may be run (no ';').")
    head = re.sub(r"^(\s|--[^\n]*\n|/\*.*?\*/)+", "", q, flags=re.S)[:8].lower()
    if not (head.startswith("select") or head.startswith("with")):
        raise Refused("Only a SELECT (or WITH ... SELECT) may be run.")
    return q


# In the query tree PostgreSQL stores for a view (pg_rewrite.ev_action), every function, operator and table it uses,
# as an OID. pg_depend cannot be used: PostgreSQL records no dependency on its own built-in objects (set_config,
# pg_class), only on the others.
TREE_FUNCS = re.compile(r":(?:funcid|aggfnoid|winfnoid|opfuncid|hashfuncid|negfuncid|tsmhandler) (\d+)")
TREE_OPS = re.compile(r":(?:opno|sortop|eqop) (\d+)")
TREE_OPLISTS = re.compile(r":opnos \(o ([\d ]+)\)")
TREE_RELS = re.compile(r":relid (\d+)")


def dependencies(conn, sql):
    """What the query uses, as PostgreSQL parsed it: [(kind, schema, name, volatility, prokind)]."""
    try:
        with conn.transaction():
            conn.execute("SET TRANSACTION READ WRITE")              # patch_ask is read-only by default; temp only
            # the query alone must be one whole SELECT too: text that closes the wrapper's parenthesis to put in an
            # ask_q of its own (and so dodge its size check) is unbalanced on its own, and PostgreSQL refuses it
            conn.execute(f"CREATE TEMP VIEW {PROBE}_alone AS\n{sql}\n")
            conn.execute(f"CREATE TEMP VIEW {PROBE} AS " + wrap(sql))
            t = conn.execute("SELECT r.ev_action::text AS tree, c.oid::bigint AS self FROM pg_rewrite r "
                             "JOIN pg_class c ON c.oid = r.ev_class WHERE r.ev_class = %s::regclass "
                             "AND r.rulename = '_RETURN'", (PROBE,)).fetchone()
            tree, me = t["tree"], int(t["self"])
            funcs = sorted({int(x) for x in TREE_FUNCS.findall(tree)} - {0})
            ops = {int(x) for x in TREE_OPS.findall(tree)}
            for group in TREE_OPLISTS.findall(tree):
                ops |= {int(x) for x in group.split()}
            ops = sorted(ops - {0})
            rels = sorted({int(x) for x in TREE_RELS.findall(tree)} - {0, me})
            rows = conn.execute(
                """SELECT 'function' AS kind, n.nspname AS schema, p.proname AS name, p.provolatile AS volatile,
                          p.prokind AS prokind, p.oid::bigint AS oid
                     FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
                    WHERE p.oid = ANY(%s::oid[])
                   UNION ALL
                   SELECT 'function', n.nspname, p.proname, p.provolatile, p.prokind, -1
                     FROM pg_operator o JOIN pg_proc p ON p.oid = o.oprcode JOIN pg_namespace n ON n.oid = p.pronamespace
                    WHERE o.oid = ANY(%s::oid[])
                   UNION ALL
                   SELECT 'operator', n.nspname, o.oprname, NULL, NULL, o.oid::bigint
                     FROM pg_operator o JOIN pg_namespace n ON n.oid = o.oprnamespace
                    WHERE o.oid = ANY(%s::oid[])
                   UNION ALL
                   SELECT 'relation', n.nspname, c.relname, NULL, NULL, c.oid::bigint
                     FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
                    WHERE c.oid = ANY(%s::oid[])""", (funcs, ops, ops, rels)).fetchall()
            raise _Done((rows, funcs, ops, rels))                   # rolls the probe back
    except _Done as d:
        rows, funcs, ops, rels = d.deps
    found = {(r["kind"], int(r["oid"])) for r in rows}
    if any(("function", f) not in found for f in funcs) or any(("operator", o) not in found for o in ops) \
            or any(("relation", x) not in found for x in rels):
        raise Refused("The query uses something PostgreSQL could not name, so it is not run.")
    return [(r["kind"], r["schema"], r["name"], r["volatile"], r["prokind"]) for r in rows]


def check(conn, sql, views):
    """Refused unless the query uses only the views given (those the asker's modules and role may read) and functions
    that change nothing. Returns the query, tidied, and the views it reads."""
    q = check_text(sql)
    try:
        deps = dependencies(conn, q)
    except Refused:
        raise
    except Exception as e:  # noqa: BLE001 - PostgreSQL's own words: a wrong column, a syntax error
        raise Refused("PostgreSQL did not accept the query: " + _pg_words(e)) from None
    used = set()
    for kind, schema, name, vol, prokind in deps:
        if kind == "relation":
            if schema != "ask" or name == "catalog" or name not in views:
                raise Refused(f"The query reads {schema}.{name}, which the agent may not read for you."
                              if schema != "ask" or name == "catalog" else
                              f"The query reads ask.{name}, which your account may not see.")
            used.add(name)
        elif kind == "function":
            if schema not in ("pg_catalog", "ask") or REFUSED_FUNCS.search(name or ""):
                raise Refused(f"The query calls {schema}.{name}(), which the agent may not call.")
            if prokind not in ("a", "w") and vol not in ("i", "s"):
                raise Refused(f"The query calls {name}(), which can change something; only reading is allowed.")
        elif kind == "operator":
            if schema not in ("pg_catalog", "ask"):
                raise Refused(f"The query uses {schema}.{name}, which the agent may not use.")
        else:
            raise Refused(f"The query uses a {kind}, which the agent may not use.")
    return q, sorted(used)


def run(conn, sql, views, modules, role):
    """Checks the query, then runs it as the asker: {"columns", "rows" (at most ROW_CAP), "more" (cut), "views"}."""
    q, used = check(conn, sql, views)
    mods = ",".join(sorted(m for m in modules if re.fullmatch(r"[a-z]{1,20}", m or "")))
    try:
        with conn.transaction():
            conn.execute("SET TRANSACTION READ ONLY")
            conn.execute("SELECT set_config('ask.modules', %s, true), set_config('ask.role', %s, true), "
                         "set_config('statement_timeout', %s, true)", (mods, "admin" if role == "admin" else "operator",
                                                                      str(TIMEOUT_MS)))
            rows = conn.execute(wrap(q)).fetchall()
    except Refused:
        raise
    except Exception as e:  # noqa: BLE001
        w = _pg_words(e)
        if "statement timeout" in w.lower() or "canceling statement" in w.lower():
            raise Refused(f"The query took longer than {TIMEOUT_MS // 1000} seconds and was stopped.") from None
        raise Refused("PostgreSQL did not accept the query: " + w) from None
    more = len(rows) > ROW_CAP
    rows = [trim_row(r) for r in rows[:ROW_CAP]]
    return {"columns": list(rows[0].keys()) if rows else [], "rows": rows, "more": more, "views": used, "sql": q}


_QUOTED = re.compile(r'"([^"]*)"')
_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_.$]{0,62}|[^\w\s\"]{1,2}")    # a name, or the ')' a syntax error points at


def _pg_words(e):
    """The first line of PostgreSQL's error, without the driver's noise. What it quotes may be data (a host name, a log
    line: written on a server, and PostgreSQL does not escape a quote inside it), so the message is cut where a value
    begins (': "') and at the first quoted part that is not the name of a column, view or function."""
    t = str(e).strip()
    m = re.search(r"ERROR:\s*(.+)", t)
    t = (m.group(1) if m else t).splitlines()[0] if t else type(e).__name__
    # PostgreSQL gives a value after ': "' (for type integer: "<value>"): all of it is data, whatever quotes it holds
    if ': "' in t:
        t = t[:t.index(': "')] + ': "…"'
    pos = 0
    for q in _QUOTED.finditer(t):
        if not _NAME.fullmatch(q.group(1)):
            t = t[:q.start()] + '"…"'
            break
        pos = q.end()
    else:
        if '"' in t[pos:]:                           # a quote left open: what follows it is cut too
            t = t[:pos + t[pos:].index('"')] + '"…"'
    t = re.sub(r"[^\w\s.,:;()\"'*=<>!?/…+-]", " ", t)
    from .llm import _clean_untrusted
    return _clean_untrusted(t, 300)


def trim_value(v):
    """A value as the agent keeps it: text cut to CELL_MAX characters; a number that JSON cannot hold (NaN, infinity)
    as nothing."""
    if isinstance(v, float) and (v != v or v in (float("inf"), float("-inf"))):
        return None
    if isinstance(v, str) and len(v) > CELL_MAX:
        return v[:CELL_MAX] + "…"
    if isinstance(v, (list, tuple)):
        return [trim_value(x) for x in list(v)[:50]]
    if isinstance(v, dict):
        return {str(k)[:80]: trim_value(x) for k, x in list(v.items())[:50]}
    return v


def trim_row(r):
    return {k: trim_value(v) for k, v in dict(r).items()}


# ---------------------------------------------------------------------------
# patch_ask's own connections (never the API's pool, which logs in as patchapi)
# ---------------------------------------------------------------------------
_pool = None
_pool_lock = threading.Lock()


def configured():
    return bool(os.environ.get("PATCHASK_DB_PASSWORD"))


def connect():
    """A connection logged in as patch_ask, from a pool of its own: use it as `with ask_sql.connect() as conn`."""
    global _pool
    if not configured():
        raise Refused("The agent's read-only database login is not set up (run phase3a-schema.sh, then phase3b-api.sh).")
    with _pool_lock:
        if _pool is None:
            from psycopg.rows import dict_row
            from psycopg_pool import ConnectionPool

            from . import core
            user = os.environ.get("PATCHASK_DB_USER", "patch_ask")
            if not re.fullmatch(r"[a-z_][a-z0-9_]{0,62}", user) or user == core.DB_USER:
                raise Refused("PATCHASK_DB_USER must name the agent's own login, not the API's.")
            info = (f"host={core.DB_HOST} port={core.DB_PORT} dbname={core.DB_NAME} user={user} "
                    f"password={os.environ['PATCHASK_DB_PASSWORD']} connect_timeout=10 application_name=patch-agent")
            _pool = ConnectionPool(info, min_size=0, max_size=2, open=True, kwargs={"row_factory": dict_row})
    return _pool.connection()
