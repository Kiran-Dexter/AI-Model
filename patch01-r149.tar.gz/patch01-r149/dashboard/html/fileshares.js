/* ---- Vulnerabilities > File shares (r146, simplified in r149) -----------------------------------------------
 * The access review: the workbook's Folder sheet (one row per account per folder) compared with what the scan read.
 *   top line   the server (one, or all of them together), its scan and Scan now, the drives audited (ticks)
 *   banner     the one thing to do next
 *   Access     Needs you / All: click a row, the panel beside it shows the folder's permissions, what the account
 *              can do, and the four columns to fill (saved as you type); Folders: the folders the scan read
 *   Groups     each group of Member Listing beside the same group in Active Directory; pair names by hand
 *   Report     the figures; Excel (your workbook back, filled) or PDF
 * Nothing here changes a server. */

const FS_BASE = "/file-shares";
const FS_TABS = [["access", "Access"], ["groups", "Groups"], ["report", "Report"]];
const FS_SHOW = [["needs", "Needs you"], ["all", "All"], ["folders", "Folders"]];
const FS_KEYS = ["tab", "host", "show", "find", "row", "share", "q", "key", "who"];
const FS_KIND = { user: "person", group: "group", local_group: "group of the server", well_known: "built-in group", computer: "computer", unknown: "unknown" };
const FS_CHIP = { same: "chip-ok", changed: "chip-warn", gone: "", new: "chip-bad", not_found: "chip-bad", not_scanned: "", twice: "chip-warn" };
const FS_RING = { same: "c-ok", changed: "c-warn", gone: "c-muted", new: "c-bad", not_found: "c-mod", not_scanned: "c-muted", twice: "c-warn" };
const FS_MEANS = {
  same: "The folder gives the account what the sheet says.",
  changed: "The account is on the folder, with another permission than the sheet says.",
  gone: "The sheet lists the account; the folder no longer gives it anything.",
  new: "On the folder, and not in the sheet.",
  not_found: "The sheet names a folder that is not on the server.",
  not_scanned: "The folder was not read yet: the next scan reads it.",
  twice: "The folder is on more than one server: choose which one.",
};

/* What was typed in a row's four columns and not saved yet (a save that failed): kept by row, shown and sent again
 * when the row is opened, and a reload or leaving the page asks first. */
const FS_UNSAVED = new Map();
let fsLeaveGuard = false;
function fsGuardLeave() {
  if (fsLeaveGuard) return;
  fsLeaveGuard = true;
  window.addEventListener("beforeunload", e => {
    const p = document.querySelector(".fs .pane-detail");
    if (FS_UNSAVED.size || (p && p._dirty && p._dirty())) { e.preventDefault(); e.returnValue = ""; }
  });
}

function fsHash(st) {
  const p = new URLSearchParams();
  for (const k of FS_KEYS) if (st[k]) p.set(k, st[k]);
  const q = p.toString();
  return "#/file-shares" + (q ? "?" + q : "");
}

function fsNum(n) { return Number(n || 0).toLocaleString(); }

function fsRiskChips(keys, labels) {
  return (keys || []).map(k => h("span", { class: "chip " + (k === "wide_write" || k === "control" ? "chip-bad" : "chip-warn") }, labels[k] || k));
}

function fsResult(r) { return h("span", { class: ("chip " + (FS_CHIP[r.result] || "")).trim() }, r.result_label); }

/* A box that is drawn by an answer the page waits for: a newer draw of the same box wins, an older answer that
 * comes back last is dropped (in-page redraws do not change the route, so api() cannot tell). */
function fsTurn(box) {
  box._fsTurn = (box._fsTurn || 0) + 1;
  const mine = box._fsTurn;
  return () => box.isConnected && box._fsTurn === mine;
}

/* replaceChildren writes null as text, and takes no arrays: this one skips the nulls and flattens. */
function fsFill(box, ...kids) {
  box.replaceChildren(...kids.flat(Infinity).filter(k => k !== null && k !== undefined && k !== false));
}

function fsFailIn(box, e) {
  if (e instanceof StaleRoute) return;
  box.replaceChildren(h("p", { class: "hd-failed" }, (e && e.message) || "This could not be read."));
}

async function renderFileShares(params) {
  setNav("file-shares");
  const home = await api(FS_BASE);
  const st = {};
  for (const k of FS_KEYS) if (params.get(k)) st[k] = params.get(k);
  if (!FS_TABS.some(t => t[0] === st.tab)) st.tab = "access";
  if (!FS_SHOW.some(t => t[0] === st.show)) st.show = "needs";
  const page = h("div", { class: "fs" });
  render(page);
  fsDraw(page, home, st);
}

function fsDraw(page, home, st) {
  const edit = !!home.can_edit;
  const acc = home.access || {};
  const servers = home.servers || [];
  const labels = Object.fromEntries((home.risk_labels || []).map(r => [r.key, r.label]));
  document.body.classList.remove("sheet-open");
  // the server: one, or all of them together (the workbook in use for all of them opens on All)
  if (st.host !== "all" && !servers.some(s => s.id === st.host)) {
    st.host = servers.length > 1 && (acc.workbooks || []).some(w => w.all_servers) ? "all" : (servers[0] ? servers[0].id : null);
  }
  if (servers.length < 2 && st.host === "all") st.host = servers[0] ? servers[0].id : null;
  const hid = st.host === "all" ? null : st.host;
  const say = h("p", { class: "cm-meta fs-msg", role: "status", "aria-live": "polite" });
  const tell = (t, bad) => { say.textContent = t || ""; say.classList.toggle("hd-failed", !!bad); };
  const keep = () => history.replaceState(null, "", fsHash(st));
  const again = async msg => {
    const mine = fsTurn(page);
    let fresh;
    try { fresh = await api(FS_BASE); } catch (e) { if (!(e instanceof StaleRoute)) tell(e.message, true); return; }
    if (!mine()) return;
    fsDraw(page, fresh, st);
    if (msg) { const m = page.querySelector(".fs-msg"); if (m) m.textContent = msg; }
  };
  const go = (tab, extra) => {
    st.tab = tab;
    for (const k of ["find", "row", "share", "q", "key", "who"]) delete st[k];
    Object.assign(st, extra || {});
    keep();
    fsDraw(page, home, st);
  };
  const pickHost = id => { st.host = id; for (const k of ["row", "share", "q", "key", "who"]) delete st[k]; keep(); fsDraw(page, home, st); };
  const ctx = { home, st, hid, edit, tell, keep, again, go, labels };
  const scanned = servers.some(s => s.done);
  const inUse = (acc.workbooks || []).filter(w => !hid || (w.hosts || []).includes(hid));
  const top = fresh => fsTop(fresh, st, edit, tell, again, pickHost);
  const head = h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure vulns --file-shares" }, "File shares"),
    h("div", { class: "head-actions" }, scanned ? fsExport(st, hid, inUse.length > 0, tell) : null,
      edit && servers.length ? h("button", { type: "button", class: "btn", on: { click: e => fsPickFile(e.currentTarget, tell, again) } },
        "Upload access review workbook") : null));
  const intro = h("p", { class: "muted small fs-intro" }, "The access review: your workbook's Folder sheet, one row per account per folder, "
    + "compared with what the scan read on the server. Read-only: nothing on the servers is changed.");
  if (!servers.length) {
    page.replaceChildren(head, intro, fsServers(home, edit, tell, again), say);
    return;
  }
  const next = (hid ? (acc.next_by_server || {})[hid] : acc.next) || null;
  const tabs = h("div", { class: "filters fs-tabs", role: "tablist", "aria-label": "Show" },
    FS_TABS.map(([k, label]) => h("button", { type: "button", role: "tab", class: "fbtn", "aria-selected": String(st.tab === k),
      "aria-pressed": String(st.tab === k), on: { click: () => go(k) } }, label)));
  const body = h("div", { class: "fs-body" });
  page.replaceChildren(...[head, intro, top(home),
    home.pending ? fsUse(home, home.pending, st, edit, tell, again) : null,
    next ? fsNext(next, ctx) : null,
    scanned ? tabs : null, say, scanned ? body : null].filter(Boolean));         // (replaceChildren would write null as text)
  fsPoll(page, home, top, tell, again);
  if (!scanned) return;
  if (st.tab === "groups") fsGroups(body, ctx, inUse).catch(e => fsFailIn(body, e));
  else if (st.tab === "report") fsReport(body, ctx, inUse);
  else fsAccess(body, ctx, inUse).catch(e => fsFailIn(body, e));
}

/* One Export control, as every page has: the access review (Excel: the workbook back, filled; PDF) and the
 * permissions of every folder (PDF, Excel). */
function fsExport(st, hid, review, tell) {
  const menu = h("div", { class: "exp-menu", role: "menu", hidden: true });
  const btn = h("button", { type: "button", class: "btn btn-quiet exp-btn", "aria-haspopup": "menu", "aria-expanded": "false" }, "Export ▾");
  const close = () => { menu.hidden = true; btn.setAttribute("aria-expanded", "false"); };
  const run = async (path, fmt, what) => {
    close();
    btn.disabled = true;
    await fsDownload(path, fmt, what, hid, tell);
    btn.disabled = false;
  };
  const item = (path, fmt, title, sub) => h("button", { type: "button", role: "menuitem", on: { click: () => run(path, fmt, title) } },
    h("strong", null, title), h("span", null, sub));
  menu.append(...[
    review ? item("/access/export", "xlsx", "Access review, Excel", "Your workbook back: the Folder sheet filled, with the result of each row") : null,
    review ? item("/access/export", "pdf", "Access review, PDF", "With the logo: the figures and what needs you") : null,
    item("/export", "pdf", "Permissions report, PDF", "Every share and folder: owners, who can reach each share"),
    item("/export", "xlsx", "Permissions report, Excel", "Every sheet: access, risks, owners")].filter(Boolean));
  btn.addEventListener("click", e => {
    e.stopPropagation();
    const open = menu.hidden;
    menu.hidden = !open; btn.setAttribute("aria-expanded", String(open));
    if (open) menu.querySelector("button").focus();
  });
  const wrap = h("span", { class: "exp", "data-own-export": "1" }, btn, menu);
  wrap._close = close;
  wrap.addEventListener("keydown", e => { if (e.key === "Escape") { close(); btn.focus(); } });
  return wrap;
}

async function fsDownload(path, fmt, what, hid, tell) {
  tell("Building the " + what + "…");
  try {
    await downloadFile(FS_BASE + path + "?format=" + fmt + (hid ? "&host_id=" + encodeURIComponent(hid) : ""), "file-shares." + fmt);
    tell("Downloaded: the " + what + (hid ? " (this server)." : " (every audited server)."));
  } catch (err) { tell(err.message, true); }
}

/* While a scan is queued or running, look again every 10 seconds. A new part only updates the top line; a scan
 * that starts, ends or stops redraws the page, unless the workbook is being checked (then it is said). */
function fsPoll(page, home, top, tell, again) {
  const busy = s => s.scan && ["queued", "running"].includes(s.scan.state) && !s.scan.stalled;
  if (!(home.servers || []).some(busy)) { clearPageTimer(); return; }
  const states = list => JSON.stringify((list || []).map(s => s.scan && [s.scan.id, s.scan.state, !!s.scan.picked_at, !!s.scan.stalled]));
  const was = states(home.servers);
  setPageTimer(async () => {
    if (!page.isConnected || !location.hash.startsWith("#/file-shares")) return clearPageTimer();
    let fresh;
    try { fresh = await api(FS_BASE); } catch (e) { return; }
    if (!page.isConnected) return;
    const swap = () => { const box = page.querySelector(".fs-top"); if (box) box.replaceWith(top(fresh)); };
    if (states(fresh.servers) === was) { swap(); return; }
    clearPageTimer();
    if (page.querySelector(".fs-preview, .fs-fill textarea:focus")) {
      swap();
      tell("A scan has moved on: its results show when the page is drawn again.");
      return;
    }
    again();
  }, 10000);
}

/* ---- the top line: the server, its scan, its drives ---------------------------------------------- */

function fsScanState(s) {
  const sc = s.scan;
  if (!sc) return [h("span", { class: "chip" }, "never scanned")];
  if (sc.stalled) return [h("span", { class: "chip chip-bad" }, "stopped"), " ", h("span", { class: "small" }, sc.stalled_why || "")];
  if (sc.state === "queued") return [h("span", { class: "chip chip-warn" }, sc.picked_at ? "starting" : "waiting for the agent"), " ",
    h("span", { class: "muted small" }, sc.picked_at ? "the scanner was started " + timeAgo(sc.picked_at) : "asked " + timeAgo(sc.created_at))];
  if (sc.state === "running") return [h("span", { class: "chip chip-warn" }, "scanning"), " ",
    h("span", { class: "muted small" }, sc.parts + " part" + (sc.parts === 1 ? "" : "s") + " received, the last " + timeAgo(sc.last_part_at))];
  if (sc.state === "failed" || sc.state === "cancelled") return [h("span", { class: "chip chip-bad" }, sc.state), " ", h("span", { class: "small" }, sc.error || "")];
  return [h("span", { class: "chip chip-ok" }, "scanned"), " ", h("span", { class: "muted small" }, timeAgo(sc.finished_at))];
}

function fsBusy(s) { return !!(s.scan && ["queued", "running"].includes(s.scan.state) && !s.scan.stalled); }

async function fsScan(b, list, tell, again) {
  b.disabled = true;
  try {
    for (const s of list) if (!fsBusy(s)) await apiPost(FS_BASE + "/scan", { host_id: s.id });
    await again("Scan asked of " + list.map(s => s.hostname).join(", ") + ": the agent starts it within a few minutes.");
  } catch (e) { tell(e.message, true); b.disabled = false; }
}

function fsTop(home, st, edit, tell, again, pickHost) {
  const servers = home.servers || [];
  const drives = (home.access || {}).drives || {};
  const pick = servers.length > 1 ? h("div", { class: "filters", role: "group", "aria-label": "Server" },
    servers.map(s => [s.id, s.hostname]).concat([["all", "All servers"]]).map(([id, label]) =>
      h("button", { type: "button", class: "fbtn", "aria-pressed": String(st.host === id), on: { click: () => pickHost(id) } }, label))) : null;
  const shown = st.host === "all" ? servers : servers.filter(s => s.id === st.host);
  const line = s => {
    const ticks = (drives[s.id] || []).map(d => {
      const box = h("input", { type: "checkbox", checked: !!d.audited, disabled: !edit });
      box.addEventListener("change", async () => {
        box.disabled = true;
        try {
          await apiPost(FS_BASE + "/drives", { host_id: s.id, drive: d.drive, audited: box.checked });
          await again(d.drive.toUpperCase() + " on " + s.hostname + (box.checked ? " is audited." : " is left out of the review."));
        } catch (err) { box.checked = !box.checked; box.disabled = false; tell(err.message, true); }
      });
      return h("label", { class: "fs-drive" }, box, h("strong", null, d.drive.toUpperCase()),
        h("span", { class: "muted small" }, fsNum(d.shares) + " share" + (d.shares === 1 ? "" : "s")));
    });
    return h("div", { class: "fs-srv" }, h("strong", null, s.hostname), h("span", null, fsScanState(s)),
      ticks.length ? h("span", { class: "fs-drives", role: "group", "aria-label": "Drives audited on " + s.hostname },
        h("span", { class: "muted small" }, "Drives:"), ticks) : null,
      edit ? (fsBusy(s)
        ? h("button", { type: "button", class: "btn-link", on: { click: async e => {
            const b = e.currentTarget; b.disabled = true;
            try { await apiPost(FS_BASE + "/scans/" + encodeURIComponent(s.scan.id) + "/cancel", {}); await again("The scan of " + s.hostname + " is cancelled."); }
            catch (err) { tell(err.message, true); b.disabled = false; } } } }, "Cancel the scan")
        : h("button", { type: "button", class: "btn btn-quiet", on: { click: e => fsScan(e.currentTarget, [s], tell, again) } }, "Scan now")) : null);
  };
  return h("section", { class: "fs-top no-enh" }, pick, shown.map(line),
    h("details", { class: "host-more fs-manage" }, h("summary", null, "Audited servers"), fsManage(home, edit, tell, again)));
}

function fsAdd(home, edit, tell, again) {
  const cands = home.candidates || [];
  if (!edit) return null;
  if (!cands.length) return h("p", { class: "muted small" }, (home.servers || []).length ? "Every Windows server with the agent is audited."
    : "No Windows server with the PATCH-01 agent is known yet: enrol the file servers' agents first (Servers).");
  const sel = h("select", { "aria-label": "Windows server to add" }, h("option", { value: "" }, "Choose a Windows server…"),
    cands.map(c => h("option", { value: c.id }, c.hostname)));
  return h("div", { class: "cm-actions" }, sel, h("button", { type: "button", class: "btn btn-quiet", on: { click: async e => {
    const b = e.currentTarget;
    if (!sel.value) { tell("Choose the server to add.", true); return; }
    const name = sel.selectedOptions[0].textContent;
    b.disabled = true;
    try { await apiPost(FS_BASE + "/servers", { host_id: sel.value }); await again(name + " is audited now: scan it to read its shares."); }
    catch (err) { tell(err.message, true); b.disabled = false; }
  } } }, "Add to the audit"));
}

function fsManage(home, edit, tell, again) {
  return h("div", { class: "fs-by" },
    h("ul", { class: "fs-plain" }, (home.servers || []).map(s => h("li", null, h("strong", null, s.hostname), " ",
      edit ? h("button", { type: "button", class: "btn-link", on: { click: async e => {
        const b = e.currentTarget; b.disabled = true;
        try { await apiSend("DELETE", FS_BASE + "/servers/" + encodeURIComponent(s.id)); await again(s.hostname + " is no longer audited (its scans are kept)."); }
        catch (err) { tell(err.message, true); b.disabled = false; } } } }, "Remove") : null))),
    fsAdd(home, edit, tell, again));
}

function fsServers(home, edit, tell, again) {
  return h("div", { class: "empty fs-empty" }, h("h3", null, "No file server is audited yet"),
    h("ol", { class: "rm-steps" },
      h("li", null, h("strong", null, "Add"), " the file servers (Windows servers with the PATCH-01 agent)."),
      h("li", null, h("strong", null, "Copy the scanner"), " access-scan.ps1 (signed, like the agent) next to patch-agent.ps1 on each of them, "
        + "and try it once as administrator: access-scan.ps1 -DryRun (it sends nothing)."),
      h("li", null, h("strong", null, "Scan"), " each server, then tick the drives to review."),
      h("li", null, h("strong", null, "Upload the access review workbook"), " (Folder, Member Listing, Description): each row is compared with the scan.")),
    edit ? fsAdd(home, edit, tell, again) : h("p", { class: "muted" }, "An operator adds the servers."));
}

/* ---- the banner: the one thing to do now --------------------------------------------------------- */

function fsNext(next, ctx) {
  const servers = (ctx.home.servers || []).filter(s => !ctx.hid || s.id === ctx.hid);
  let act = null;
  if ((next.step === "scan" || next.step === "rescan") && ctx.edit && servers.some(s => !fsBusy(s))) {
    act = h("button", { type: "button", class: "btn btn-quiet", on: { click: e => fsScan(e.currentTarget, servers, ctx.tell, ctx.again) } }, "Scan now");
  } else if (next.step === "upload" && ctx.edit) {
    act = h("button", { type: "button", class: "btn btn-quiet", on: { click: e => fsPickFile(e.currentTarget, ctx.tell, ctx.again) } }, "Upload access review workbook");
  } else if (next.step === "review" && !(ctx.st.tab === "access" && ctx.st.show === "needs")) {
    act = h("button", { type: "button", class: "btn btn-quiet", on: { click: () => ctx.go("access", { show: "needs" }) } }, "Show them");
  } else if (next.step === "report" && ctx.st.tab !== "report") {
    act = h("button", { type: "button", class: "btn btn-quiet", on: { click: () => ctx.go("report") } }, "Open the report");
  }
  if (next.step === "add") return null;
  return h("div", { class: "hs-alert st-running fs-next" }, h("strong", null, "Next: "), next.text, act);
}

/* ---- the workbook: upload, then use it for one server or all of them ---------------------------- */

function fsPickFile(btn, tell, again) {
  document.querySelectorAll("input.fs-file").forEach(x => x.remove());
  const input = h("input", { type: "file", class: "fs-file", accept: ".xlsx,.csv", hidden: true });
  document.body.append(input);
  input.addEventListener("change", async () => {
    const f = input.files[0];
    input.remove();
    if (!f) return;
    if (!/\.(xlsx|csv)$/i.test(f.name)) {
      tell(/\.xls$/i.test(f.name) ? "Old .xls files cannot be read: open it in Excel and save it as .xlsx, then upload that."
        : "Upload the access review workbook as .xlsx.", true);
      return;
    }
    btn.disabled = true; tell("Reading " + f.name + "…");
    try {
      const fd = new FormData();
      fd.append("file", f);
      const res = await fetch("/api/v1" + FS_BASE + "/workbook", { method: "POST", body: fd, cache: "no-store",
        headers: { "X-Requested-With": "patch01-dashboard", ...authHeaders() } });
      if (res.status === 401) { clearAuth(); throw new ApiError(401, "Your session has ended. Sign in again."); }
      if (!res.ok) { let d = ""; try { d = detailText((await res.json()).detail); } catch (e) { /* not JSON */ } throw new ApiError(res.status, d || httpReason(res)); }
      await again("Read. Choose which server it is for, then press Use the workbook.");
    } catch (e) { tell(e.message, true); btn.disabled = false; }
  });
  input.click();
}

function fsUse(home, u, st, edit, tell, again) {
  const drop = h("button", { type: "button", class: "btn btn-quiet", disabled: !edit, on: { click: async e => {
    const b = e.currentTarget;
    b.disabled = true;
    try { await apiSend("DELETE", FS_BASE + "/workbook/" + encodeURIComponent(u.id)); await again("The upload is discarded."); }
    catch (err) { tell(err.message, true); b.disabled = false; }
  } } }, "Discard");
  if (u.kind !== "access") {
    return h("section", { class: "fs-preview no-enh" }, h("h2", null, u.file_name),
      h("p", null, "This is not the access review workbook: it has no Folder sheet. The access review workbook has the sheets "
        + "Folder, Member Listing and Description."), edit ? h("div", { class: "cm-actions" }, drop) : null);
  }
  const servers = home.servers || [];
  const sheets = u.sheets || [];
  const word = s => s.role === "ignored" ? "not read" : fsNum(s.count) + " row" + (s.count === 1 ? "" : "s");
  // a column is asked for only when its header was not recognised
  const asks = [];
  const fix = sheets.filter(s => (s.missing || []).length).map(s => h("div", { class: "fs-cols" }, s.missing.map(m => {
    const sel = h("select", { "aria-label": m.label + " column of the sheet " + s.name, disabled: !edit },
      h("option", { value: "" }, "Choose the column…"),
      (s.header || []).map((hd, i) => h("option", { value: String(i) }, hd || "Column " + (i + 1))));
    asks.push({ role: s.role, field: m.field, sel });
    return h("label", null, h("span", { class: "small" }, "Sheet " + s.name + ": " + m.label), sel);
  })));
  const name = "fs-use-" + u.id;
  const where = (servers.length > 1 ? servers.map(s => [s.id, s.hostname]).concat([["all", "All servers"]]) : servers.map(s => [s.id, s.hostname]))
    .map(([id, label]) => h("label", { class: "fs-drive" }, h("input", { type: "radio", name, value: id, disabled: !edit,
      checked: id === (st.host || (servers[0] || {}).id) }), label));
  const replaces = (home.access || {}).replaces || {};
  const warn = h("div", { class: "hs-alert st-unknown fs-warn", hidden: true });
  const said = () => {
    const pick = warn.closest("section") && warn.closest("section").querySelector("input[name='" + name + "']:checked");
    const t = pick ? replaces[pick.value] : null;
    warn.hidden = !t; warn.replaceChildren(...(t ? [h("strong", null, "Before you use it: "), t] : []));
  };
  const use = h("button", { type: "button", class: "btn", disabled: !edit, on: { click: async e => {
    const b = e.currentTarget;
    const pick = b.closest("section").querySelector("input[name='" + name + "']:checked");
    if (!pick) { tell("Choose the server the workbook is for.", true); return; }
    const columns = {};
    for (const a of asks) {
      if (a.sel.value === "") { tell("Choose the column with the " + a.sel.getAttribute("aria-label").replace(/ column of the sheet .*/, "") + ".", true); return; }
      (columns[a.role] = columns[a.role] || {})[a.field] = Number(a.sel.value);
    }
    b.disabled = true; tell("Comparing each row with the scan…");
    try {
      const r = await apiPost(FS_BASE + "/workbook/" + encodeURIComponent(u.id) + "/use", { host_id: pick.value === "all" ? null : pick.value, columns });
      FS_UNSAVED.clear();                                         // the rows are the new workbook's now
      st.host = pick.value; st.tab = "access"; st.show = "needs";
      for (const k of ["row", "find"]) delete st[k];
      history.replaceState(null, "", fsHash(st));
      await again(fsNum(r.rows) + " rows compared with the scan: " + fsNum((r.counts || {}).needs_you) + " need you.");
    } catch (err) { tell(err.message, true); b.disabled = false; }
  } } }, "Use the workbook");
  const box = h("section", { class: "fs-preview no-enh" },
    h("h2", null, "Use the workbook: " + u.file_name),
    h("p", { class: "small" }, sheets.map((s, i) => [i ? " · " : "", h("strong", null, s.name), ": " + word(s)])),
    fix.length ? [h("p", { class: "small" }, "Some headers were not recognised: choose their columns."), fix] : null,
    h("p", { class: "fs-where", role: "radiogroup", "aria-label": "The server the workbook is for", on: { change: () => said() } },
      h("span", { class: "small" }, "It is for: "), where),
    warn,
    h("p", { class: "muted small" }, "It replaces the workbook in use for that server. What you filled on this page for a row the new workbook "
      + "has again is kept, whichever server it was filled for."),
    edit ? h("div", { class: "cm-actions" }, use, drop) : h("p", { class: "muted" }, "An operator uses the workbook."));
  said();
  return box;
}

/* ---- Access ----------------------------------------------------------------------------------- */

async function fsAccess(box, ctx, inUse) {
  const { st, edit } = ctx;
  const mine = fsTurn(box);
  if (!inUse.length) st.show = "folders";
  const bar = inUse.length ? h("div", { class: "filters", role: "group", "aria-label": "Rows" }) : null;
  const find = h("input", { type: "search", value: st.find || "", placeholder: "Find a folder or an account", "aria-label": "Find a folder or an account", maxlength: "100" });
  const head = h("div", { class: "cm-actions fs-filter" }, bar, st.show !== "folders" ? find : null);
  const list = h("div", { class: "pane-list" }, h("p", { class: "muted small" }, "Loading…"));
  if (st.show === "folders") {
    if (bar) bar.append(...fsShowButtons(st, null, ctx, box, inUse));
    box.replaceChildren(head, list);
    if (!ctx.hid) { list.replaceChildren(h("div", { class: "empty" }, h("p", null, "Choose a server above to see its folders."))); return; }
    return fsFolders(list, ctx);
  }
  const panel = h("aside", { class: "pane-detail", "aria-live": "polite", "aria-label": "Selected access" });
  box.replaceChildren(head, h("div", { class: "panes" }, list, panel));
  let timer = null;
  find.addEventListener("input", () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      if ((find.value.trim() || null) === (st.find || null)) return;
      st.find = find.value.trim() || null; delete st.row; ctx.keep();
      fsAccess(box, ctx, inUse).then(() => { const f = box.querySelector("input[type=search]"); if (f) { f.focus(); f.setSelectionRange(f.value.length, f.value.length); } })
        .catch(e => fsFailIn(box, e));
    }, 350);
  });
  const r = await api(FS_BASE + "/access?show=" + st.show + (ctx.hid ? "&host_id=" + encodeURIComponent(ctx.hid) : "")
    + (st.find ? "&q=" + encodeURIComponent(st.find) : ""));
  if (!mine()) return;
  bar.append(...fsShowButtons(st, r.counts || {}, ctx, box, inUse));
  const rows = r.rows || [];
  if (!rows.length) {
    list.replaceChildren(h("div", { class: "empty" }, h("p", null, st.find ? "Nothing matches." : st.show === "needs"
      ? "Nothing needs you: every access is as the workbook says." : "The workbook in use has no rows here.")));
    panel.replaceChildren(h("p", { class: "pane-empty" }, "Select a row to see its folder and fill its columns."));
    return;
  }
  const all = !ctx.hid;
  const tbl = table([
    { label: "Result", nowrap: true, cell: x => fsResult(x) },
    all ? { label: "Server", nowrap: true, cell: x => x.server || h("span", { class: "muted" }, "–") } : null,
    { label: "Folder", mono: true, cell: x => x.rel_text || x.path_text },
    { label: "Account", cell: x => [x.account, x.display_name ? h("span", { class: "muted small" }, " " + x.display_name) : null] },
    { label: "Sheet says", cell: x => x.origin === "sheet" ? [x.ace_type && x.ace_type.toLowerCase() === "deny" ? "Deny " : "", x.level || x.permission || "–"]
        : h("span", { class: "muted" }, "not listed") },
    { label: "Found", cell: x => x.found || h("span", { class: "muted" }, "–") },
    { label: "Status", cell: x => h("span", { class: "fs-status" }, x.status || "") },
  ].filter(Boolean), rows);
  tbl.querySelector("table").dataset.noSelect = "1";            // sorted and paged as every table; no tick boxes: a click opens the row
  const select = (x, tr, picked) => {                         // picked: the person chose it (a sheet opens only then)
    if (panel._flush) panel._flush();
    st.row = String(x.id); ctx.keep();
    list.querySelectorAll("tr.selected").forEach(t => t.classList.remove("selected"));
    if (tr) tr.classList.add("selected");
    fsPanel(panel, x, ctx, tr);
    if (picked && !wideScreen()) { panel.classList.add("open"); document.body.classList.add("sheet-open"); }
  };
  tbl.querySelectorAll("tbody tr").forEach((tr, i) => {
    const x = rows[i];
    tr.tabIndex = 0;
    tr.dataset.row = String(x.id);
    tr.setAttribute("aria-label", x.account + ", " + (x.rel_text || x.path_text) + ", " + x.result_label);
    tr.addEventListener("click", () => select(x, tr, true));
    tr.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); select(x, tr, true); } });
  });
  fsFill(list, tbl, r.more ? h("p", { class: "muted small" }, "The first " + fsNum(rows.length) + " of " + fsNum(r.total)
    + " are shown: find a folder or an account to see the others.") : null);
  const want = rows.findIndex(x => String(x.id) === st.row);
  // on a wide screen a row is always open (the one in the address, or the first); on a narrow one only when picked
  if (wideScreen()) select(want >= 0 ? rows[want] : rows[0], tbl.querySelectorAll("tbody tr")[Math.max(want, 0)]);
  else panel.replaceChildren(h("p", { class: "pane-empty" }, "Select a row to see its folder and fill its columns."));
}

function fsShowButtons(st, counts, ctx, box, inUse) {
  return FS_SHOW.map(([k, label]) => h("button", { type: "button", class: "fbtn", "aria-pressed": String(st.show === k), on: { click: () => {
    st.show = k; for (const x of ["row", "share", "q", "key", "who"]) delete st[x]; ctx.keep();
    fsAccess(box, ctx, inUse).catch(e => fsFailIn(box, e));
  } } }, label + (counts && k === "needs" ? " (" + fsNum(counts.needs_you) + ")" : counts && k === "all" ? " (" + fsNum(counts.total) + ")" : "")));
}

/* The panel beside the list: the row, the four columns to fill (saved as you type), the folder's permissions. */
function fsPanel(panel, x, ctx, tr) {
  const { edit } = ctx;
  const fill = (ctx.home.access || {}).fill || [];
  const note = h("p", { class: "muted small fs-saved" }, x.updated_by ? "Saved by " + x.updated_by + " " + timeAgo(x.updated_at) + "." : "");
  const unsaved = FS_UNSAVED.get(x.id);
  let pending = Object.assign({}, unsaved || {}), timer = null, chain = Promise.resolve();
  fsGuardLeave();
  const flush = () => {
    clearTimeout(timer); timer = null;
    const body = pending; pending = {};
    if (!Object.keys(body).length) return chain;
    note.textContent = "Saving…"; note.classList.remove("hd-failed", "hd-good");
    chain = chain.then(async () => {
      try {
        const res = await apiPost(FS_BASE + "/access/" + encodeURIComponent(x.id), body);
        Object.assign(x, res.row || {});
        const left = Object.assign({}, FS_UNSAVED.get(x.id) || {});
        for (const k of Object.keys(body)) delete left[k];          // what was just saved is newer than anything kept
        if (Object.keys(left).length) FS_UNSAVED.set(x.id, left); else FS_UNSAVED.delete(x.id);
        const cell = tr && tr.isConnected ? tr.querySelector(".fs-status") : null;
        if (cell) cell.textContent = x.status || "";
        if (note.isConnected) { note.textContent = "Saved."; note.classList.add("hd-good"); }
      } catch (e) {
        if (e && e.status >= 400 && e.status < 500) {               // refused (the row is gone, the text too long): never sent again
          FS_UNSAVED.delete(x.id);
          if (note.isConnected) { note.textContent = "Not saved: " + e.message; note.classList.add("hd-failed"); }
          ctx.tell("Not saved for " + (x.account || "the row") + ": " + e.message, true);
          return;
        }
        pending = Object.assign({}, body, pending);
        FS_UNSAVED.set(x.id, Object.assign({}, FS_UNSAVED.get(x.id) || {}, body));
        const why = (e && e.message) || "the server did not answer";
        if (note.isConnected) { note.textContent = "Not saved: " + why; note.classList.add("hd-failed"); }
        ctx.tell("Not saved for " + (x.account || "the row") + ": " + why + ". What you typed is kept: it is sent again when you open the row.", true);
      }
    });
    return chain;
  };
  panel._flush = flush;
  panel._dirty = () => !!(timer || Object.keys(pending).length);
  const fields = fill.map(f => {
    const ta = h("textarea", { rows: "2", maxlength: "2000", readonly: !edit, "aria-label": f.label },
      unsaved && f.key in unsaved ? unsaved[f.key] : (x[f.key] || ""));
    if (edit) {
      ta.addEventListener("input", () => { pending[f.key] = ta.value; clearTimeout(timer); timer = setTimeout(flush, 800); });
      ta.addEventListener("blur", () => { if (Object.keys(pending).length) flush(); });
    }
    return h("label", null, h("span", { class: "small" }, f.label), ta);
  });
  const fact = (k, v) => v ? h("div", null, h("dt", null, k), h("dd", null, v)) : null;
  const close = h("button", { type: "button", class: "pd-close", "aria-label": "Close", on: { click: () => {
    flush(); panel.classList.remove("open"); document.body.classList.remove("sheet-open"); } } }, "Close");
  const twice = x.result === "twice" ? h("section", { class: "fs-twice" }, h("h3", { class: "pd-sub" }, "Which folder is it?"),
    h("ul", { class: "fs-plain" }, (x.candidates || []).filter(c => c && c.key).map(c => h("li", null,
      h("span", { class: "mono small" }, c.server + ": " + c.path), " ",
      edit ? h("button", { type: "button", class: "btn btn-quiet", on: { click: async e => {
        const b = e.currentTarget; b.disabled = true;
        try { await apiPost(FS_BASE + "/access/" + encodeURIComponent(x.id), { choose: { host_id: c.host_id, key: c.key } });
              await ctx.again("Compared with " + c.path + " on " + c.server + "."); }
        catch (err) { ctx.tell(err.message, true); b.disabled = false; } } } }, "This one") : null)))) : null;
  const perms = h("div", { class: "fs-perm" });
  fsFill(panel,
    h("div", { class: "pd-head" }, h("h2", null, x.account || "–"), close),
    h("div", { class: "pd-badges" }, fsResult(x), h("span", { class: "muted small" }, x.how || "")),
    x.display_name ? h("p", { class: "pd-title" }, x.display_name) : null,
    h("dl", { class: "pd-facts" },
      fact("Server", x.server),
      fact("Folder", x.path_text ? h("span", { class: "mono" }, x.path_text) : null),
      fact("Relative", x.rel_text ? h("span", { class: "mono" }, x.rel_text) : null),
      fact("Sheet says", x.origin === "sheet" ? [x.ace_type || "Allow", " · ", x.permission || "–",
        x.level && x.level !== x.permission ? h("span", { class: "muted small" }, " (" + x.level + ")") : null] : "not listed: found on the folder"),
      fact("Found", x.found || "nothing for this account"),
      fact("Department", x.department),
      fact("Row", x.origin === "sheet" && x.row_no ? "Folder sheet: row " + fsNum(x.row_no) + " under the headers" : null)),
    twice,
    h("section", { class: "fs-fill" }, h("h3", { class: "pd-sub" }, "Your review"), fields, note,
      edit ? null : h("p", { class: "muted small" }, "An operator fills these.")),
    perms);
  if (x.host_id && x.folder_key) fsPerms(perms, x);
  if (unsaved && edit) { note.textContent = "Not saved yet: sending it again…"; timer = setTimeout(flush, 50); }
}

/* The folder's permissions in the panel: what the row's account can do (share, NTFS, effective), and everyone else. */
function fsPerms(box, x) {
  const ps = { host: x.host_id, key: x.folder_key, who: x.sid };
  const eff = h("div", { class: "fs-eff" });
  const everyone = h("div");
  const more = h("button", { type: "button", class: "btn-link", on: { click: () => {
    more.remove(); fsFolder(everyone, ps, () => {}, {}).catch(e => fsFailIn(everyone, e)); } } },
    "Everyone with access to this folder");
  box.replaceChildren(eff, h("p", null, more), everyone);
  if (x.sid) fsEffective(eff, ps).catch(e => fsFailIn(eff, e));
}

/* ---- Folders: what the scan read on one server (before a workbook, and any time) ------------- */

async function fsFolders(box, ctx) {
  const { st, keep, labels } = ctx;
  const mine = fsTurn(box);
  st.host = ctx.hid;
  const r = await api(FS_BASE + "/folders?host_id=" + encodeURIComponent(ctx.hid) + (st.share ? "&share=" + encodeURIComponent(st.share) : "")
    + (st.q ? "&q=" + encodeURIComponent(st.q.toLowerCase().replace(/\//g, "\\")) : ""));
  if (!mine()) return;
  const redraw = () => { keep(); fsFolders(box, ctx).catch(e => fsFailIn(box, e)); };
  const pick = (k, v) => { st[k] = v || null; delete st.key; delete st.who; redraw(); };
  const sh = h("select", { "aria-label": "Share", on: { change: e => pick("share", e.target.value) } },
    h("option", { value: "" }, "Every share"), (r.shares || []).map(s => h("option", { value: s.name, selected: s.name === st.share }, s.name)));
  const q = h("input", { type: "search", value: st.q || "", placeholder: "Find a folder", "aria-label": "Find a folder", maxlength: "200" });
  let timer = null;
  q.addEventListener("input", () => {
    clearTimeout(timer);
    timer = setTimeout(() => { if ((q.value.trim() || null) !== (st.q || null)) pick("q", q.value.trim()); }, 350);
  });
  const detail = h("div", { class: "fs-detail" });
  const open = f => { st.key = f.key; delete st.who; keep(); fsFolder(detail, st, keep, labels).catch(e => fsFailIn(detail, e)); };
  const hadFocus = document.activeElement && document.activeElement.getAttribute("aria-label") === "Find a folder";
  box.replaceChildren(...[
    h("div", { class: "cm-actions fs-filter" }, sh, q),
    h("p", { class: "muted small" }, "Each share and each folder the scan lists, on the drives ticked above. Pick one to see who can reach it."),
    (r.items || []).length ? h("div", { class: "fs-by no-enh fs-folders" }, table([
      { label: "Folder", mono: true, cell: f => h("button", { type: "button", class: "btn-link", "aria-pressed": String(f.key === st.key),
          on: { click: () => open(f) } }, f.path) },
      { label: "Permissions", cell: f => f.error ? "" : f.protected ? "its own (inheritance turned off)" : f.explicit ? "its own, and inherited" : "inherited" },
      { label: "Risks", cell: f => fsRiskChips(f.risks, labels) },
      { label: "Folders below", num: true, cell: f => f.below ? fsNum(f.below) : "" },
    ], r.items)) : h("div", { class: "empty" }, h("p", null, "No folder matches.")),
    r.more ? h("p", { class: "muted small" }, "The first 500 folders are shown: choose a share or find a folder to see others.") : null,
    detail].filter(Boolean));
  if (hadFocus) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); }
  if (st.key) fsFolder(detail, st, keep, labels).catch(e => fsFailIn(detail, e));
}

async function fsFolder(box, st, keep, labels) {
  const mine = fsTurn(box);
  box.replaceChildren(h("p", { class: "muted small" }, "Loading the folder…"));
  const d = await api(FS_BASE + "/folder?host_id=" + encodeURIComponent(st.host) + "&key=" + encodeURIComponent(st.key));
  if (!mine()) return;
  const eff = h("div", { class: "fs-eff" });
  const show = sid => { st.who = sid; keep(); fsEffective(eff, st).catch(e => fsFailIn(eff, e)); };
  const person = h("input", { type: "search", list: "fs-people", placeholder: "A person's name, account or e-mail", "aria-label": "Check one person", maxlength: "100" });
  const plist = h("datalist", { id: "fs-people" });
  let found = [], timer = null, asked = 0;
  person.addEventListener("input", () => {
    clearTimeout(timer);
    const v = person.value.trim();
    const hit = found.find(p => p.label === v);
    if (hit) { show(hit.sid); return; }
    if (v.length < 2) return;
    timer = setTimeout(async () => {
      const n = ++asked;
      try {
        const r = await api(FS_BASE + "/people?host_id=" + encodeURIComponent(st.host) + "&q=" + encodeURIComponent(v));
        if (n !== asked || !person.isConnected) return;
        found = (r.items || []).map(p => ({ sid: p.sid, label: (p.display ? p.display + " · " : "") + (p.name || p.sid) }));
        plist.replaceChildren(...found.map(p => h("option", { value: p.label })));
      } catch (e) { /* the list stays as it was */ }
    }, 250);
  });
  const f = d.folder;
  box.replaceChildren(h("section", { class: "fs-by fs-folder no-enh" },
    h("h3", null, d.server + "  ·  " + f.path),
    h("p", null, "Share ", h("strong", null, d.share.name), d.ntfs_owner ? " · NTFS owner (Windows): " + d.ntfs_owner : "",
      f.protected ? " · inheritance turned off" : ""),
    d.risks.length ? h("p", null, d.risks.map(r => h("span", { class: "chip " + (r.key === "wide_write" || r.key === "control" ? "chip-bad" : "chip-warn") }, r.label))) : null,
    f.error ? h("p", { class: "hd-failed" }, f.error) : null,
    h("h4", null, "Who has access"),
    h("p", { class: "muted small" }, "Every account and group on the folder or its share. Effective: what each gets over the network, the stricter of the "
      + "share and NTFS. Pick one to see each right."),
    table([
      { label: "Account or group", cell: w => h("button", { type: "button", class: "btn-link", "aria-pressed": String(w.sid === st.who), on: { click: () => show(w.sid) } },
          w.name + (w.display ? " (" + w.display + ")" : "")) },
      { label: "Kind", cell: w => w.orphan ? h("span", { class: "chip chip-warn" }, "Orphaned SID") : (FS_KIND[w.kind] || w.kind) + (w.admin ? ", administrator" : "") },
      { label: "Share", cell: w => w.share },
      { label: "NTFS", cell: w => w.ntfs },
      { label: "Effective", cell: w => h("span", { class: "chip " + (w.control ? "chip-bad" : w.write ? "chip-warn" : w.effective === "No access" ? "" : "chip-ok") }, w.effective) },
    ], d.who),
    h("div", { class: "cm-actions" }, h("label", null, h("span", { class: "small" }, "Check one person: "), person, plist)),
    eff));
  if (st.who) fsEffective(eff, st).catch(e => fsFailIn(eff, e));
}

async function fsEffective(box, st) {
  const mine = fsTurn(box);
  box.replaceChildren(h("p", { class: "muted small" }, "Working it out…"));
  const e = await api(FS_BASE + "/effective?host_id=" + encodeURIComponent(st.host) + "&key=" + encodeURIComponent(st.key) + "&sid=" + encodeURIComponent(st.who));
  if (!mine()) return;
  const g = e.grid || [];
  const n = g.filter(r => r.key !== "full" && r.effective).length;
  const col = (title, k) => h("div", { class: "fs-ladder" }, h("p", { class: "small" }, h("strong", null, title)),
    h("ul", null, g.filter(r => r.key !== "full").map(r => h("li", { class: r[k] ? "fs-on" : "fs-off" },
      h("span", { class: "fs-mark", "aria-hidden": "true" }, r[k] ? "✓" : "–"), r.label, h("span", { class: "fs-sr" }, r[k] ? ": yes" : ": no")))));
  const yes = v => v ? h("span", { class: "chip chip-ok" }, "Yes") : h("span", { class: "muted" }, "No");
  box.replaceChildren(h("section", { class: "fs-by fs-who no-enh" },
    h("h4", null, "What " + e.who.name + (e.who.display ? " (" + e.who.display + ")" : "") + " can do in " + e.folder),
    h("p", null, "Share: ", h("strong", null, e.share_level), " · NTFS: ", h("strong", null, e.ntfs_level), " → Effective: ", h("strong", null, e.effective_level),
      e.who.kind === "user" ? h("span", { class: "muted small" }, " · in " + fsNum(e.who.groups) + " group" + (e.who.groups === 1 ? "" : "s")
        + (e.who.enabled === false ? " · the account is disabled" : "")) : null),
    e.note ? h("p", { class: "muted small" }, e.note) : null,
    h("div", { class: "fs-graph", "aria-label": "Share permissions plus NTFS permissions give the effective permissions" },
      col("Share permissions", "share"), h("span", { class: "fs-sign", "aria-hidden": "true" }, "+"), col("NTFS permissions", "ntfs"),
      h("span", { class: "fs-sign", "aria-hidden": "true" }, "="),
      donut("Effective permissions", [{ label: "Allowed", value: n, cls: "c-ok" }, { label: "Not allowed", value: 13 - n, cls: "c-muted" }],
        { centre: n + "/13", centreLabel: "rights" })),
    table([
      { label: "Permission", cell: r => r.label },
      { label: "Share", cell: r => yes(r.share) },
      { label: "NTFS", cell: r => yes(r.ntfs) },
      { label: "Effective", cell: r => yes(r.effective) },
    ], g),
    h("p", { class: "small" }, h("strong", null, "Through the share: "), (e.through_share || []).length
      ? e.through_share.map(x => x.name + " (" + (x.allow ? "" : "deny ") + x.right + ")").join("; ") : "nothing: no share permission names it or a group it is in."),
    h("p", { class: "small" }, h("strong", null, "Through NTFS: "), (e.through_ntfs || []).length
      ? e.through_ntfs.map(x => x.name + " (" + (x.allow ? "" : "deny ") + x.level + (x.inherited ? ", inherited" : "") + ")").join("; ")
      : "nothing: no NTFS entry on the folder names it or a group it is in.")));
}

/* ---- Groups: Member Listing beside Active Directory ---------------------------------------------- */

const FS_WHERE = { both: ["chip-ok", "In both"], sheet_only: ["chip-warn", "Only in the sheet"], ad_only: ["chip-bad", "Only in AD"],
                   not_in_ad: ["", "Marked: not in AD"], not_member: ["chip-bad", "In AD, not in the group"] };

async function fsGroups(box, ctx, inUse) {
  const mine = fsTurn(box);
  if (!inUse.length) {
    box.replaceChildren(h("div", { class: "empty" }, h("p", null, "Use the access review workbook first: its Member Listing sheet is shown here "
      + "beside Active Directory.")));
    return;
  }
  box.replaceChildren(h("p", { class: "muted small" }, "Loading…"));
  const r = await api(FS_BASE + "/groups" + (ctx.hid ? "?host_id=" + encodeURIComponent(ctx.hid) : ""));
  if (!mine()) return;
  const gs = (r.groups || []).slice().sort((a, b) => (b.differences > 0) - (a.differences > 0) || a.group.localeCompare(b.group));
  if (!gs.length) {
    box.replaceChildren(h("div", { class: "empty" }, h("p", null, "The workbook in use has no Member Listing sheet, or it lists no group.")));
    return;
  }
  const n = gs.filter(g => g.differences || !g.ad_group).length;
  const send = async (b, body, msg) => {
    b.disabled = true;
    try { await apiPost(FS_BASE + "/groups/pair", body); ctx.tell(msg); await fsGroups(box, ctx, inUse); }
    catch (e) { ctx.tell(e.message, true); b.disabled = false; }
  };
  fsFill(box,
    h("p", { class: "muted small" }, "Each group of the Member Listing sheet beside the same group in Active Directory (AD), as the last scan read it. "
      + "Names are paired when they are the same; pair the others by hand. " + fsNum(n) + " of " + fsNum(gs.length) + " groups differ."),
    gs.map(g => {
      const ad = g.ad_group;
      const lines = g.members || [];
      const act = m => {
        if (!ctx.edit || !m.sheet) return null;
        if (m.how === "paired on the page" || m.state === "not_in_ad") {
          return h("button", { type: "button", class: "btn-link", on: { click: e => send(e.currentTarget,
            { import_id: g.import_id, kind: "member", group: g.group, value: m.sheet, clear: true }, "Undone: " + m.sheet + " is paired by its name again.") } }, "Undo");
        }
        if (m.state !== "sheet_only") return null;
        return h("span", { class: "cm-actions" },
          h("button", { type: "button", class: "btn-link", on: { click: e => fsPairForm(e.currentTarget, g, m, lines, ctx, send) } }, "Pair…"),
          h("button", { type: "button", class: "btn-link", on: { click: e => send(e.currentTarget,
            { import_id: g.import_id, kind: "member", group: g.group, value: m.sheet, sid: null }, m.sheet + " is marked: not in AD.") } }, "Not in AD"));
      };
      return h("details", { class: "fs-group no-enh", open: g.differences || !ad ? true : null },
        h("summary", null, h("strong", null, g.group), h("span", { class: "muted" }, " ↔ "),
          ad ? h("span", null, ad.name || ad.sid) : h("span", { class: "chip chip-warn" }, "not found in the scan"),
          ad && g.group_how === "paired on the page" ? h("span", { class: "muted small" }, " (paired on the page)") : null, " ",
          g.differences ? h("span", { class: "chip chip-warn" }, fsNum(g.differences) + " difference" + (g.differences === 1 ? "" : "s"))
            : ad ? h("span", { class: "chip chip-ok" }, "the same") : null),
        !ad && ctx.edit ? h("p", { class: "small" }, h("button", { type: "button", class: "btn btn-quiet",
          on: { click: e => fsPairForm(e.currentTarget, g, null, [], ctx, send) } }, "Pair with a group of AD…")) : null,
        ad && g.group_how === "paired on the page" && ctx.edit ? h("p", { class: "small" }, h("button", { type: "button", class: "btn-link",
          on: { click: e => send(e.currentTarget, { import_id: g.import_id, kind: "group", value: g.group, clear: true },
            "Undone: " + g.group + " is paired by its name again.") } }, "Undo the group's pairing")) : null,
        lines.length ? table([
          { label: "In the sheet", cell: m => m.sheet || h("span", { class: "muted" }, "–") },
          { label: "In AD", cell: m => m.ad ? [m.ad.name, m.ad.display ? h("span", { class: "muted small" }, " " + m.ad.display) : null]
              : h("span", { class: "muted" }, "–") },
          { label: "", cell: m => { const w = FS_WHERE[m.state] || ["", m.state]; return [h("span", { class: ("chip " + w[0]).trim() }, w[1]),
              m.how === "paired on the page" ? h("span", { class: "muted small" }, " paired on the page") : null]; } },
          { label: "", cell: m => act(m) },
        ], lines) : h("p", { class: "muted small" }, "No member on either side."));
    }));
}

/* Pair one name of the sheet with an account the scan read: a member with a person, a group with a group. */
function fsPairForm(btn, g, m, lines, ctx, send) {
  const host = btn.closest(m ? "td" : "p");
  const old = document.querySelector(".fs-pair");
  if (old) old.remove();
  const kind = m ? "user" : "group";
  const id = "fs-pair-list";
  const input = h("input", { type: "search", list: id, placeholder: m ? "A person of AD" : "A group of AD", "aria-label": "Pair " + (m ? m.sheet : g.group) + " with",
    maxlength: "100" });
  const dl = h("datalist", { id });
  let known = (lines || []).filter(x => x.state === "ad_only" && x.ad).map(x => ({ sid: x.ad.sid, label: x.ad.name + (x.ad.display ? " · " + x.ad.display : "") }));
  const fill = () => dl.replaceChildren(...known.map(k => h("option", { value: k.label })));
  fill();
  let timer = null, asked = 0;
  input.addEventListener("input", () => {
    clearTimeout(timer);
    const v = input.value.trim();
    if (v.length < 2 || known.some(k => k.label === v)) return;
    timer = setTimeout(async () => {
      const n = ++asked;
      try {
        const r = await api(FS_BASE + "/accounts?kind=" + kind + "&q=" + encodeURIComponent(v) + (ctx.hid ? "&host_id=" + encodeURIComponent(ctx.hid) : ""));
        if (n !== asked || !input.isConnected) return;
        known = (r.items || []).map(a => ({ sid: a.sid, label: a.name + (a.display ? " · " + a.display : "") }));
        fill();
      } catch (e) { /* the list stays as it was */ }
    }, 250);
  });
  const ok = h("button", { type: "button", class: "btn btn-quiet", on: { click: e => {
    const hit = known.find(k => k.label === input.value.trim());
    if (!hit) { ctx.tell("Choose an account from the list.", true); return; }
    send(e.currentTarget, { import_id: g.import_id, kind: m ? "member" : "group", group: g.group, value: m ? m.sheet : g.group, sid: hit.sid },
      "Paired: " + (m ? m.sheet : g.group) + " is " + hit.label + ".");
  } } }, "Pair");
  const form = h("div", { class: "fs-pair" }, input, dl, ok, h("button", { type: "button", class: "btn-link", on: { click: () => form.remove() } }, "Cancel"));
  host.append(form);
  input.focus();
}

/* ---- Report ----------------------------------------------------------------------------------- */

function fsReport(box, ctx, inUse) {
  const acc = ctx.home.access || {};
  if (!inUse.length) {
    box.replaceChildren(h("div", { class: "empty" }, h("p", null, "Use the access review workbook first: the report compares it with the scan. "
      + "The permissions report of every folder is in Export.")));
    return;
  }
  const c = (ctx.hid ? (acc.counts_by_server || {})[ctx.hid] : acc.counts) || {};
  const results = acc.results || [];
  const xl = h("button", { type: "button", class: "btn", on: { click: async e => {
    const b = e.currentTarget; b.disabled = true;
    await fsDownload("/access/export", "xlsx", "access review, Excel", ctx.hid, ctx.tell); b.disabled = false; } } }, "Export Excel");
  const pdf = h("button", { type: "button", class: "btn btn-quiet", on: { click: async e => {
    const b = e.currentTarget; b.disabled = true;
    await fsDownload("/access/export", "pdf", "access review, PDF", ctx.hid, ctx.tell); b.disabled = false; } } }, "Export PDF");
  box.replaceChildren(
    h("div", { class: "cy-grid" },
      donut("The accesses compared", results.map(r => ({ label: r.label, value: c[r.key] || 0, cls: FS_RING[r.key] || "c-muted",
        href: r.needs_you ? fsHash(Object.assign({}, ctx.st, { tab: "access", show: "needs", row: null, find: null })) : null })),
        { caption: fsNum(c.needs_you) + " need you", centre: fsNum(c.total), centreLabel: "accesses" })),
    h("section", { class: "fs-by no-enh" }, h("h3", null, "Each result"), table([
      { label: "Result", cell: r => h("span", { class: ("chip " + (FS_CHIP[r.key] || "")).trim() }, r.label) },
      { label: "Accesses", num: true, cell: r => fsNum(c[r.key]) },
      { label: "What it means", cell: r => h("span", { class: "muted small" }, FS_MEANS[r.key] || "") },
    ], results)),
    h("section", { class: "fs-by" }, h("h3", null, "Export"),
      h("p", { class: "muted small" }, "Excel gives your workbook back: the Folder sheet as it was, with Recommended Change to, Feedback from Users, "
        + "Status and Remarks filled in, and the result of each row; then the new accesses, the groups side by side, and a summary. "
        + "PDF: the figures and what needs you, with the logo."),
      h("div", { class: "cm-actions" }, xl, pdf)));
}
