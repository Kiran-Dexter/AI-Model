-- ---------------------------------------------------------------------------
-- 077 (r147) The agent's runs: one question of one person, and the steps taken to answer it
--
-- The agent answers in the background (an answer can take several of AI-01's turns, longer than a web request may
-- wait); the assistant shows each step as it is saved here. Only the person who asked sees a run
-- (api_assistant.py). The agent's own views (zz-ask-views.sql) do not show this table.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS agent_runs (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username     TEXT NOT NULL,
    question     TEXT NOT NULL,
    page         JSONB,                                  -- the page and item the person was looking at
    state        TEXT NOT NULL DEFAULT 'running' CHECK (state IN ('running', 'done', 'failed')),
    steps        JSONB NOT NULL DEFAULT '[]',            -- each step: what was run, its rows, or why it failed
    answer       JSONB,                                  -- the reply, as the assistant shows it
    error        TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at  TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_agent_runs_user ON agent_runs (username, created_at DESC);
-- one question at a time per person, kept by the database itself (two requests at once cannot both start one)
CREATE UNIQUE INDEX IF NOT EXISTS idx_agent_runs_one_running ON agent_runs (username) WHERE state = 'running';

INSERT INTO schema_version (version, description)
VALUES (77, 'The agent''s runs: questions and the steps taken to answer them')
ON CONFLICT (version) DO NOTHING;
