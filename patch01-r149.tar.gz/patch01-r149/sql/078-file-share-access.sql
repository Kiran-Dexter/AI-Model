-- ---------------------------------------------------------------------------
-- 078 (r149) File shares: the access review workbook, compared with the scan
--
-- The workbook's Folder sheet lists, per folder, each account and its permission; each row is compared with what
-- the last scan found on that folder (same, changed, gone), and the accesses the scan found that the sheet does not
-- list are added (new). The person fills four columns per row on the page. Member Listing (each group's members)
-- is shown beside the members Active Directory gives the scan, paired by name, or by hand. Description is not read.
--
-- file_share_drives    the drives of each server and whether they are audited (ticked on the page)
-- file_share_access    one row per account per folder: the sheet's (origin sheet) or one the scan found (origin scan)
-- file_share_listing   the Member Listing sheet's rows
-- file_share_pairs     what the person paired by hand: a sheet group to an AD group, a sheet member to an AD account
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS file_share_drives (
    host_id     UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    drive       TEXT NOT NULL CHECK (drive ~ '^[a-z]:$'),
    audited     BOOLEAN NOT NULL DEFAULT true,
    changed_by  TEXT,
    changed_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (host_id, drive)
);

ALTER TABLE file_share_imports ADD COLUMN IF NOT EXISTS kind TEXT NOT NULL DEFAULT 'owners';
ALTER TABLE file_share_imports DROP CONSTRAINT IF EXISTS file_share_imports_kind_check;
ALTER TABLE file_share_imports ADD CONSTRAINT file_share_imports_kind_check CHECK (kind IN ('owners', 'access'));
-- the server the workbook is for; NULL: every audited server (consolidated)
ALTER TABLE file_share_imports ADD COLUMN IF NOT EXISTS scope UUID REFERENCES hosts(id) ON DELETE SET NULL;
ALTER TABLE file_share_imports ADD COLUMN IF NOT EXISTS all_servers BOOLEAN NOT NULL DEFAULT false;

CREATE TABLE IF NOT EXISTS file_share_access (
    id            BIGSERIAL PRIMARY KEY,
    import_id     UUID NOT NULL REFERENCES file_share_imports(id) ON DELETE CASCADE,
    origin        TEXT NOT NULL CHECK (origin IN ('sheet', 'scan')),
    row_no        INTEGER,                              -- its row in the Folder sheet (origin sheet)
    cells         JSONB NOT NULL DEFAULT '[]',          -- the row as the sheet has it: the export gives it back
    path_text     TEXT NOT NULL DEFAULT '',
    rel_text      TEXT NOT NULL DEFAULT '',
    account_type  TEXT NOT NULL DEFAULT '',
    account       TEXT NOT NULL DEFAULT '',
    display_name  TEXT NOT NULL DEFAULT '',
    ace_type      TEXT NOT NULL DEFAULT '',             -- Allow or Deny
    permission    TEXT NOT NULL DEFAULT '',             -- as the sheet writes it (or the level the scan found: origin scan)
    department    TEXT NOT NULL DEFAULT '',
    host_id       UUID REFERENCES hosts(id) ON DELETE CASCADE,
    folder_key    TEXT,                                 -- the scanned folder it is (key_of), when found
    sid           TEXT,
    result        TEXT NOT NULL DEFAULT 'not_found'
                  CHECK (result IN ('same', 'changed', 'gone', 'new', 'not_found', 'twice', 'not_scanned', 'left_out')),
    found         TEXT,                                 -- what the scan found for the account: its level, e.g. Modify
    how           TEXT,                                 -- how the folder was found, or why not
    candidates    JSONB NOT NULL DEFAULT '[]',          -- twice: the folders it could be [{host_id, key, path}]
    chosen_key    TEXT,                                 -- twice: the one the person chose
    chosen_host   UUID,
    recommended   TEXT NOT NULL DEFAULT '',             -- the four columns the person fills
    feedback      TEXT NOT NULL DEFAULT '',
    status        TEXT NOT NULL DEFAULT '',
    remarks       TEXT NOT NULL DEFAULT '',
    updated_by    TEXT,
    updated_at    TIMESTAMPTZ,
    sig           TEXT,                                 -- the same row in the next workbook keeps what was filled
                                                        -- (rows of a replaced workbook are kept, the last few, for this)
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_fs_access_import ON file_share_access (import_id, origin);
CREATE INDEX IF NOT EXISTS idx_fs_access_folder ON file_share_access (host_id, folder_key);
CREATE INDEX IF NOT EXISTS idx_fs_access_sig ON file_share_access (sig);
-- one row per access the scan found that the sheet does not list
CREATE UNIQUE INDEX IF NOT EXISTS idx_fs_access_scan_one ON file_share_access (import_id, host_id, folder_key, sid, ace_type)
    WHERE origin = 'scan';

CREATE TABLE IF NOT EXISTS file_share_listing (
    id            BIGSERIAL PRIMARY KEY,
    import_id     UUID NOT NULL REFERENCES file_share_imports(id) ON DELETE CASCADE,
    row_no        INTEGER NOT NULL,
    group_name    TEXT NOT NULL DEFAULT '',
    account_type  TEXT NOT NULL DEFAULT '',
    member        TEXT NOT NULL DEFAULT '',
    members_name  TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_fs_listing_import ON file_share_listing (import_id);

CREATE TABLE IF NOT EXISTS file_share_pairs (
    import_id     UUID NOT NULL REFERENCES file_share_imports(id) ON DELETE CASCADE,
    kind          TEXT NOT NULL CHECK (kind IN ('group', 'member')),
    group_name    TEXT NOT NULL DEFAULT '',             -- the sheet's group (member pairs)
    sheet_value   TEXT NOT NULL,                        -- the sheet's group (group pairs) or member (member pairs), lower case
    sid           TEXT,                                 -- the AD group or account; NULL: "not in AD"
    paired_by     TEXT,
    paired_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (import_id, kind, group_name, sheet_value)
);

INSERT INTO schema_version (version, description)
VALUES (78, 'File shares: the access review workbook compared with the scan, groups side by side, audited drives')
ON CONFLICT (version) DO NOTHING;
