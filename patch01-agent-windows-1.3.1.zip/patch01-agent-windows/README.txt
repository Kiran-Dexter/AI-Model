PATCH-01 agent for Windows Server (agent 1.3.1-win)
===================================================

Extract this folder on the server, open PowerShell as administrator in it, and run:

    powershell -ExecutionPolicy Bypass -File .\Setup-Agent.ps1 -CaFile C:\temp\corp-chain.pem

An existing agent is upgraded in place (identity kept, no token needed).

1.3.1: commands from PATCH-01 are no longer skipped on PowerShell 5.1 (the
list of commands arrived as one object). The agent now logs how many commands
it received, and reports any it cannot read instead of skipping them.

Unattended:  .\Setup-Agent.ps1 -Server https://<patch01 name> -CaFile C:\temp\corp-chain.pem -Token <token> -Yes
