PATCH-01 agent for Windows Server (agent 1.3.0-win)
===================================================

Extract this folder on the server, open PowerShell as administrator in it, and run:

    powershell -ExecutionPolicy Bypass -File .\Setup-Agent.ps1 -CaFile C:\temp\corp-chain.pem

It sets the execution policy to RemoteSigned for the current user, unblocks
these scripts, finds any existing agent and upgrades it (keeping its identity,
no token), or runs the self-test and then installs a new one (it asks for a
token). It checks PATCH-01's certificate chains to the root in your PEM file
(or uses Windows' own trust if it already trusts it). It ends with a check-in.

New in 1.3.0: the agent sends its log lines to PATCH-01 (see ">_ Log" in the
console), retries sending a result, and runs a job's steps one after another
without waiting 5 minutes between them.

Unattended:  .\Setup-Agent.ps1 -Server https://<patch01 name> -CaFile C:\temp\corp-chain.pem -Token <token> -Yes
