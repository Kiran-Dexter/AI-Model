<#
.SYNOPSIS
  PATCH-01 agent for Windows Server (PowerShell 5.1, built in to Windows Server 2016 and later).

.DESCRIPTION
  Runs every 5 minutes as SYSTEM from a scheduled task. Patch jobs from
  PATCH-01 run through it: a precheck, installing the WSUS-approved updates
  the job names, a reboot when the job says so, and a postcheck. Each run checks in and
  picks up commands. Every 4 hours, or when PATCH-01 asks, it also reports:
    - the OS build (10.0.17763.6414), which PATCH-01 compares with Microsoft's
      Security Update Guide to know which CVEs are still open;
    - installed updates (KBs);
    - updates Windows Update says are missing, searched against the server's
      own WSUS, so they reflect your approvals;
    - whether a reboot is pending, uptime, and the hardware ID that links the
      server to its VM in vCenter.

  Read-only in this version: it installs nothing and changes no settings.

  patch-agent.ps1 -SelfTest -Server https://patch01.example -Pin <sha256>
      checks every step and reports ok or failed; enrols nothing
  patch-agent.ps1 -Enroll -Server <url> -Token <token> -Pin <sha256>
  patch-agent.ps1 -Run            (what the scheduled task runs)
  patch-agent.ps1 -Inventory      (report now)
#>
[CmdletBinding(DefaultParameterSetName = "Run")]
param(
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)][switch]$Enroll,
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][switch]$SelfTest,
    [Parameter(ParameterSetName = "Run")][switch]$Run,
    [Parameter(ParameterSetName = "Inventory", Mandatory = $true)][switch]$Inventory,
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)]
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][string]$Server,
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)][string]$Token,
    [Parameter(ParameterSetName = "Enroll", Mandatory = $true)]
    [Parameter(ParameterSetName = "SelfTest", Mandatory = $true)][string]$Pin
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$AgentVersion = "1.3.0-win"
$DataDir = Join-Path $env:ProgramData "PatchAgent"
$ConfigFile = Join-Path $DataDir "agent.json"
$TokenFile = Join-Path $DataDir "token.bin"
$StateFile = Join-Path $DataDir "state.json"
$LogFile = Join-Path $DataDir "agent.log"
$InventoryEveryHours = 4
$SearchTimeoutSec = 1800
# Script-wide state, declared up front: strict mode refuses to read a variable
# that has never been set, and Get-Config checks this before anything sets it
$script:Cfg = $null

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
function Write-Log([string]$Message, [string]$Level = "INFO") {
    $line = "{0} {1} {2}" -f (Get-Date).ToString("yyyy-MM-dd HH:mm:ss"), $Level, $Message
    if (Test-Path $DataDir) {
        if ((Test-Path $LogFile) -and ((Get-Item $LogFile).Length -gt 1MB)) {
            Move-Item -Force $LogFile ($LogFile + ".1")
        }
        Add-Content -Path $LogFile -Value $line -Encoding UTF8
    }
    Write-Verbose $line
}

# ---------------------------------------------------------------------------
# TLS: PATCH-01's certificate is pinned by its SHA-256 fingerprint. Compiled
# once, because a PowerShell script block used as a certificate callback can
# be called on a thread with no PowerShell runspace and fail.
# ---------------------------------------------------------------------------
if (-not ("PatchAgentPin" -as [type])) {
    Add-Type -TypeDefinition @"
using System;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
public static class PatchAgentPin {
    public static string Pin = "";
    public static string Seen = "";
    public static bool Check(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors errors) {
        if (cert == null) { return false; }
        using (SHA256 sha = SHA256.Create()) {
            Seen = BitConverter.ToString(sha.ComputeHash(cert.GetRawCertData())).Replace("-", "").ToLowerInvariant();
        }
        if (Pin == "system") { return errors == SslPolicyErrors.None; }
        // Several fingerprints, comma-separated, while a certificate is being replaced
        foreach (string one in Pin.Split(',')) { if (one.Length > 0 && Seen == one) { return true; } }
        return false;
    }
    public static void Use(string pin) {
        Pin = pin.Trim().ToLowerInvariant().Replace(":", "").Replace(" ", "");
        ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(Check);
    }
}
"@
}

function Initialize-Http([string]$PinValue) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [PatchAgentPin]::Use($PinValue)
    # PATCH-01 is internal: never send it through a proxy configured for the internet
    [Net.WebRequest]::DefaultWebProxy = $null
}

function Invoke-Api([string]$Method, [string]$Path, $Body = $null, [string]$Bearer = $null, [int]$Timeout = 60) {
    $cfg = Get-Config
    $uri = $cfg.server.TrimEnd("/") + $Path
    $headers = @{ "User-Agent" = "patch-agent/$AgentVersion" }
    if ($Bearer) { $headers["Authorization"] = "Bearer " + $Bearer }
    $params = @{ Method = $Method; Uri = $uri; Headers = $headers; TimeoutSec = $Timeout; UseBasicParsing = $true }
    if ($null -ne $Body) {
        # -InputObject, not a pipe: piping unwraps one-element arrays in PowerShell 5.1
        $params["Body"] = [Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $Body -Depth 8 -Compress))
        $params["ContentType"] = "application/json; charset=utf-8"
    }
    try {
        return Invoke-RestMethod @params
    } catch {
        $detail = $_.Exception.Message
        # In PowerShell 5.1 Invoke-RestMethod has already read the error body:
        # it is in ErrorDetails, and the response stream is empty by now
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
            $code = ""
            if ($_.Exception.PSObject.Properties["Response"] -and $_.Exception.Response) { $code = "HTTP " + [int]$_.Exception.Response.StatusCode + ": " }
            $detail = $code + $_.ErrorDetails.Message
        }
        # Only web errors carry a response; asking others for one fails under strict mode
        elseif ($_.Exception.PSObject.Properties["Response"] -and $_.Exception.Response) {
            try {
                $sr = New-Object IO.StreamReader($_.Exception.Response.GetResponseStream())
                $detail = "HTTP " + [int]$_.Exception.Response.StatusCode + ": " + $sr.ReadToEnd()
            } catch { }
        }
        if ([PatchAgentPin]::Seen -and [PatchAgentPin]::Pin -ne "system" -and ([PatchAgentPin]::Pin.Split(",") -notcontains [PatchAgentPin]::Seen)) {
            $detail = "PATCH-01's certificate does not match the pin. It presented " + [PatchAgentPin]::Seen
        }
        throw "$Method $Path failed: $detail"
    }
}

function Get-IsoUtc([datetime]$When = (Get-Date)) {
    # Whole seconds: "o" writes seven decimal places, more than the API accepts
    return $When.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ", [Globalization.CultureInfo]::InvariantCulture)
}

# ---------------------------------------------------------------------------
# Configuration and the agent's token, encrypted for this machine only
# ---------------------------------------------------------------------------
function Get-Config {
    if ($script:Cfg) { return $script:Cfg }
    if (-not (Test-Path $ConfigFile)) { throw "Not enrolled: run install-agent.ps1 first." }
    $script:Cfg = Get-Content -Raw $ConfigFile | ConvertFrom-Json
    return $script:Cfg
}

function Save-Token([string]$Value) {
    Add-Type -AssemblyName System.Security
    $bytes = [Text.Encoding]::UTF8.GetBytes($Value)
    $enc = [Security.Cryptography.ProtectedData]::Protect($bytes, $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
    [IO.File]::WriteAllBytes($TokenFile, $enc)
}

function Get-Token {
    Add-Type -AssemblyName System.Security
    if (-not (Test-Path $TokenFile)) { throw "No agent token: enrol first." }
    $enc = [IO.File]::ReadAllBytes($TokenFile)
    $bytes = [Security.Cryptography.ProtectedData]::Unprotect($enc, $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
    return [Text.Encoding]::UTF8.GetString($bytes)
}

function Get-State {
    if (Test-Path $StateFile) { try { return Get-Content -Raw $StateFile | ConvertFrom-Json } catch { } }
    return [pscustomobject]@{ last_inventory = $null }
}

function Save-State($State) { ConvertTo-Json -InputObject $State | Set-Content -Path $StateFile -Encoding UTF8 }

function Get-Prop($Object, [string]$Name) {
    <# A value that may be missing, without tripping strict mode. Works for
       objects (registry entries, JSON from PATCH-01) and for hashtables (what a
       background job returns): a hashtable's entries are not its properties. #>
    if ($null -eq $Object) { return $null }
    if ($Object -is [Collections.IDictionary]) {
        if ($Object.Contains($Name)) { return $Object[$Name] }
        return $null
    }
    if ($Object.PSObject.Properties[$Name]) { return $Object.$Name }
    return $null
}

# ---------------------------------------------------------------------------
# Facts about this server
# ---------------------------------------------------------------------------
function Get-Build {
    $cv = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion"
    $major = 10; $minor = 0
    if ($cv.PSObject.Properties["CurrentMajorVersionNumber"]) { $major = $cv.CurrentMajorVersionNumber }
    if ($cv.PSObject.Properties["CurrentMinorVersionNumber"]) { $minor = $cv.CurrentMinorVersionNumber }
    $ubr = 0
    if ($cv.PSObject.Properties["UBR"]) { $ubr = $cv.UBR }
    return [pscustomobject]@{
        Build   = "{0}.{1}.{2}.{3}" -f $major, $minor, $cv.CurrentBuildNumber, $ubr
        Number  = [int]$cv.CurrentBuildNumber
        Product = $cv.ProductName
    }
}

function Get-ServerVersion($BuildInfo) {
    # The Windows Server release, from the build number; the product name as a fallback
    switch ($BuildInfo.Number) {
        14393 { return "2016" } 17763 { return "2019" } 20348 { return "2022" } 26100 { return "2025" }
    }
    if ($BuildInfo.Product -match "(20\d\d)") { return $Matches[1] }
    return [string]$BuildInfo.Number
}

function Get-RebootState {
    $reasons = @()
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending") { $reasons += "component servicing" }
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") { $reasons += "Windows Update" }
    try { if ((New-Object -ComObject Microsoft.Update.SystemInfo).RebootRequired) { if ($reasons -notcontains "Windows Update") { $reasons += "Windows Update" } } } catch { }
    return [pscustomobject]@{ Required = ($reasons.Count -gt 0); Reason = ($reasons -join ", ") }
}

function Get-Facts {
    $os = Get-CimInstance Win32_OperatingSystem
    $cs = Get-CimInstance Win32_ComputerSystemProduct
    $b = Get-Build
    $uuid = $null
    if ($cs.UUID -and $cs.UUID -match "^[0-9A-Fa-f-]{32,36}$" -and $cs.UUID -notmatch "^[0F-]+$") { $uuid = $cs.UUID.ToLowerInvariant() }
    return [pscustomobject]@{
        Hostname = $env:COMPUTERNAME.ToLowerInvariant()
        Fqdn     = ([Net.Dns]::GetHostEntry($env:COMPUTERNAME).HostName).ToLowerInvariant()
        Build    = $b.Build
        Version  = Get-ServerVersion $b
        Edition  = $b.Product
        Boot     = Get-IsoUtc $os.LastBootUpTime
        Uuid     = $uuid
        MachineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
    }
}

function Get-WsusSource {
    $wu = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
    $server = $null; $use = 0
    if (Test-Path $wu) {
        $p = Get-ItemProperty $wu
        if ($p.PSObject.Properties["WUServer"]) { $server = $p.WUServer }
        if (Test-Path "$wu\AU") {
            $au = Get-ItemProperty "$wu\AU"
            if ($au.PSObject.Properties["UseWUServer"]) { $use = $au.UseWUServer }
        }
    }
    if ($server -and $use -eq 1) { return [pscustomobject]@{ Source = "wsus"; Server = $server } }
    return [pscustomobject]@{ Source = "microsoft"; Server = $null }
}

function Get-InstalledSoftware {
    <# Programs and Features, from the registry both 64-bit and 32-bit programs
       write to. Updates and hidden system components are left out. #>
    $out = @(); $seen = @{}
    foreach ($src in @(@{ Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"; Arch = "64-bit" },
                       @{ Path = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"; Arch = "32-bit" })) {
        foreach ($e in @(Get-ItemProperty -Path $src.Path -ErrorAction SilentlyContinue)) {
            $name = Get-Prop $e "DisplayName"
            if (-not $name) { continue }
            if ((Get-Prop $e "SystemComponent") -eq 1) { continue }
            if (Get-Prop $e "ParentKeyName") { continue }
            $rt = [string](Get-Prop $e "ReleaseType")
            if ($rt -in @("Update", "Hotfix", "Security Update", "Update Rollup")) { continue }
            $ver = [string](Get-Prop $e "DisplayVersion")
            $key = ($name + "|" + $ver + "|" + $src.Arch).ToLowerInvariant()
            if ($seen.ContainsKey($key)) { continue }
            $seen[$key] = $true
            $size = Get-Prop $e "EstimatedSize"
            $item = @{ name = ([string]$name).Trim(); version = $ver.Trim(); arch = $src.Arch }
            $pub = Get-Prop $e "Publisher"; if ($pub) { $item["publisher"] = ([string]$pub).Trim() }
            $d = [string](Get-Prop $e "InstallDate"); if ($d -match "^\d{8}$") { $item["installed_on"] = $d }
            if ($size) { $item["size_mb"] = [int]([double]$size / 1024) }
            $out += $item
        }
    }
    return ,$out
}

function Search-MissingUpdates {
    <# Asks Windows Update what is not installed. Against WSUS this returns
       what WSUS has approved for this computer. Run as a job so a search that
       hangs is abandoned instead of blocking every later run. #>
    $job = Start-Job -ScriptBlock {
        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = "PATCH-01"
        $searcher = $session.CreateUpdateSearcher()
        $result = $searcher.Search("IsInstalled=0 and IsHidden=0 and Type='Software'")
        $out = @()
        foreach ($u in $result.Updates) {
            $kb = $null
            if ($u.KBArticleIDs.Count -gt 0) { $kb = "KB" + $u.KBArticleIDs.Item(0) }
            $cats = @(); foreach ($c in $u.Categories) { $cats += [string]$c.Name }
            $cves = @(); foreach ($c in $u.CveIDs) { $cves += [string]$c }
            $out += [pscustomobject]@{
                update_id = [string]$u.Identity.UpdateID
                kb = $kb
                title = [string]$u.Title
                severity = [string]$u.MsrcSeverity
                categories = $cats
                cves = $cves
                downloaded = [bool]$u.IsDownloaded
                reboot_behaviour = @("never", "always", "may")[[int]$u.InstallationBehavior.RebootBehavior]
                size_mb = [int]([double]$u.MaxDownloadSize / 1MB)
            }
        }
        return ,$out
    }
    if (-not (Wait-Job $job -Timeout $SearchTimeoutSec)) {
        Stop-Job $job; Remove-Job $job -Force
        throw "Windows Update search did not finish within $([int]($SearchTimeoutSec / 60)) minutes"
    }
    $data = Receive-Job $job -ErrorAction Stop
    Remove-Job $job -Force
    # Results come back deserialised: an empty list can arrive as $null, and
    # extra job properties ride along. Rebuild each update with exactly the
    # fields PATCH-01 expects.
    $clean = @()
    foreach ($u in @($data)) {
        if ($null -eq $u -or -not $u.PSObject.Properties["update_id"]) { continue }
        $sev = $null; if ($u.severity) { $sev = [string]$u.severity }
        $clean += @{
            update_id = [string]$u.update_id; kb = $u.kb; title = [string]$u.title; severity = $sev
            categories = @(@($u.categories) | Where-Object { $_ } | ForEach-Object { [string]$_ })
            cves = @(@($u.cves) | Where-Object { $_ } | ForEach-Object { [string]$_ })
            downloaded = [bool]$u.downloaded; reboot_behaviour = [string]$u.reboot_behaviour; size_mb = [int]$u.size_mb
        }
    }
    return ,$clean
}

# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------
function Send-Checkin($Token) {
    $f = Get-Facts
    $r = Get-RebootState
    $body = @{ agent_version = $AgentVersion; kernel_running = $f.Build; reboot_required = $r.Required; boot_time = $f.Boot }
    if ($f.Uuid) { $body["hardware_uuid"] = $f.Uuid }
    Invoke-Api "POST" "/api/v1/agent/checkin" $body $Token | Out-Null
}

function Send-Inventory($Token) {
    $t0 = Get-Date
    $f = Get-Facts
    $r = Get-RebootState
    $packages = @(@{ name = "windows-os-build"; version = ($f.Build + "-0"); arch = "noarch" })
    foreach ($h in (Get-HotFix -ErrorAction SilentlyContinue)) {
        if ($h.HotFixID -match "^KB\d+$") {
            $packages += @{ name = $h.HotFixID.ToLowerInvariant(); version = "1-0"; arch = "noarch"; from_repo = [string]$h.Description }
        }
    }
    $body = @{
        collected_at = (Get-IsoUtc); kernel_running = $f.Build
        reboot_required = $r.Required; reboot_reason = $r.Reason; os_version = $f.Version
        agent_version = $AgentVersion; boot_time = $f.Boot; packages = $packages
        duration_ms = [int]((Get-Date) - $t0).TotalMilliseconds
    }
    if ($f.Uuid) { $body["hardware_uuid"] = $f.Uuid }
    Invoke-Api "POST" "/api/v1/agent/inventory" $body $Token -Timeout 120 | Out-Null
    Write-Log ("inventory sent: build {0}, {1} updates installed" -f $f.Build, ($packages.Count - 1))

    try {
        $sw = Get-InstalledSoftware
        Invoke-Api "POST" "/api/v1/agent/windows/software" @{ software = $sw } $Token -Timeout 120 | Out-Null
        Write-Log ("software sent: {0} programs" -f $sw.Count)
    } catch { Write-Log ("software inventory failed: " + $_.Exception.Message) }

    $src = Get-WsusSource
    $report = @{ searched_at = (Get-IsoUtc); source = $src.Source; server = $src.Server
                 os_edition = $f.Edition; updates = @() }
    try {
        $report["updates"] = Search-MissingUpdates
        Write-Log ("Windows Update ({0}): {1} missing" -f $src.Source, $report["updates"].Count)
    } catch {
        $report["error"] = [string]$_.Exception.Message
        Write-Log ("Windows Update search failed: " + $report["error"])
    }
    Invoke-Api "POST" "/api/v1/agent/windows/updates" $report $Token -Timeout 120 | Out-Null
}

function Invoke-Precheck($Params) {
    <# Before installing: enough disk, Windows Update usable, and the running
       services, so the postcheck can tell what did not come back. #>
    $errors = @(); $warnings = @()
    $c = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
    $freeGb = [math]::Round($c.FreeSpace / 1GB, 1)
    if ($freeGb -lt 5) { $errors += "only $freeGb GB free on C:, at least 5 GB is needed for a cumulative update" }
    $wu = Get-Service wuauserv -ErrorAction SilentlyContinue
    if (-not $wu) { $errors += "the Windows Update service is missing" }
    elseif ($wu.StartType -eq "Disabled") { $errors += "the Windows Update service is disabled" }
    $r = Get-RebootState
    if ($r.Required) { $warnings += "a reboot was already pending before this change (" + $r.Reason + ")" }
    $running = @(Get-CimInstance Win32_Service -Filter "State='Running' AND StartMode='Auto'" | ForEach-Object { [string]$_.Name } | Sort-Object)
    $res = @{ free_gb_c = $freeGb; running_services = $running; warnings = $warnings; errors = $errors }
    return @{ ok = ($errors.Count -eq 0); result = $res
              message = $(if ($errors.Count) { $errors -join "; " } else { "precheck passed" + $(if ($warnings.Count) { "; " + ($warnings -join "; ") } else { "" }) }) }
}

function Invoke-InstallUpdates($Params) {
    <# Install exactly the updates PATCH-01 named, if they are still missing.
       They come from this server's own WSUS search, so only updates WSUS has
       approved can be installed. Runs as a job so a hang is abandoned. #>
    $wanted = @(Get-Prop $Params "windows_updates")
    if ($wanted.Count -eq 0) { return @{ ok = $false; message = "this job names no Windows updates"; result = @{} } }
    $job = Start-Job -ArgumentList (,$wanted) -ScriptBlock {
        param($ids)
        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = "PATCH-01"
        $found = $session.CreateUpdateSearcher().Search("IsInstalled=0 and Type='Software'")
        $coll = New-Object -ComObject Microsoft.Update.UpdateColl
        foreach ($u in $found.Updates) {
            if ($ids -contains [string]$u.Identity.UpdateID) {
                if (-not $u.EulaAccepted) { $u.AcceptEula() }
                [void]$coll.Add($u)
            }
        }
        if ($coll.Count -eq 0) { return @{ nothing_to_do = $true; installed = @(); failed = @(); reboot_required = $false } }
        $dl = $session.CreateUpdateDownloader(); $dl.Updates = $coll; [void]$dl.Download()
        $inst = $session.CreateUpdateInstaller(); $inst.Updates = $coll
        $res = $inst.Install()
        $ok = @(); $bad = @()
        for ($i = 0; $i -lt $coll.Count; $i++) {
            $u = $coll.Item($i); $r = $res.GetUpdateResult($i)
            $kb = $null; if ($u.KBArticleIDs.Count -gt 0) { $kb = "KB" + $u.KBArticleIDs.Item(0) }
            $entry = @{ kb = $kb; title = [string]$u.Title; code = [int]$r.ResultCode; hresult = ("0x{0:X8}" -f $r.HResult) }
            if ($r.ResultCode -eq 2 -or $r.ResultCode -eq 3) { $ok += $entry } else { $bad += $entry }
        }
        return @{ nothing_to_do = $false; installed = $ok; failed = $bad; reboot_required = [bool]$res.RebootRequired }
    }
    if (-not (Wait-Job $job -Timeout 10200)) {        # 2 h 50 min, under PATCH-01's 3 h limit
        Stop-Job $job; Remove-Job $job -Force
        return @{ ok = $false; message = "the install did not finish within 2 h 50 min"; result = @{} }
    }
    $r = Receive-Job $job -ErrorAction Stop
    Remove-Job $job -Force
    $installed = @(@(Get-Prop $r "installed") | Where-Object { $_ })
    $failed = @(@(Get-Prop $r "failed") | Where-Object { $_ })
    $res = @{ nothing_to_do = [bool](Get-Prop $r "nothing_to_do"); reboot_required = [bool](Get-Prop $r "reboot_required")
              installed = @($installed | ForEach-Object { @{ kb = $_.kb; title = $_.title } })
              errors = @($failed | ForEach-Object { "{0} failed (result {1}, {2})" -f $(if ($_.kb) { $_.kb } else { $_.title }), $_.code, $_.hresult }) }
    if ($res.nothing_to_do) { return @{ ok = $true; message = "the updates were already installed"; result = $res } }
    $msg = "{0} installed" -f $installed.Count
    if ($failed.Count) { $msg += ", {0} failed" -f $failed.Count }
    if ($res.reboot_required) { $msg += "; a reboot is needed" }
    return @{ ok = ($failed.Count -eq 0); message = $msg; result = $res }
}

function Invoke-Reboot($Params) {
    $delay = [int](Get-Prop $Params "delay_seconds"); if ($delay -lt 30) { $delay = 60 }
    # Scheduled, not immediate, so this result reaches PATCH-01 first
    & shutdown.exe /r /t $delay /d p:2:17 /c "PATCH-01 patch job: restarting to complete updates" | Out-Null
    return @{ ok = ($LASTEXITCODE -eq 0); message = "restart in $delay seconds"; result = @{ delay_seconds = $delay } }
}

function Invoke-Postcheck($Params) {
    <# After installing (and rebooting): the services that were running before
       are running again, and Windows no longer waits for a reboot. #>
    $base = @(@(Get-Prop $Params "baseline_services") | Where-Object { $_ })
    $now = @(Get-CimInstance Win32_Service -Filter "State='Running'" | ForEach-Object { [string]$_.Name })
    $missing = @($base | Where-Object { $now -notcontains $_ })
    $errors = @()
    if ($missing.Count) { $errors += "not running any more: " + ($missing -join ", ") }
    $r = Get-RebootState
    $warnings = @(); if ($r.Required) { $warnings += "Windows still reports a reboot pending (" + $r.Reason + ")" }
    return @{ ok = ($errors.Count -eq 0); result = @{ missing_services = $missing; warnings = $warnings; errors = $errors; build = (Get-Build).Build }
              message = $(if ($errors.Count) { $errors -join "; " } else { "postcheck passed, build " + (Get-Build).Build }) }
}

# ---------------------------------------------------------------------------
# Software from the catalog: install, upgrade or remove one approved installer
# ---------------------------------------------------------------------------
$SwUnc = '^\\\\([A-Za-z0-9][A-Za-z0-9.-]{0,252})\\([A-Za-z0-9$_.-]{1,80})((\\[A-Za-z0-9 _.()+-]{1,120}){1,12})$'
$SwArgs = '^[A-Za-z0-9 /\\_.:=,+()\-"]{0,300}$'
$SwGuid = '^\{[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}$'

function Get-InstalledProgram([string]$Name) {
    # Programs and Features entries whose name is, or starts with, the catalog's name
    $hits = @()
    foreach ($root in @("HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
                        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*")) {
        foreach ($e in @(Get-ItemProperty -Path $root -ErrorAction SilentlyContinue)) {
            $dn = [string](Get-Prop $e "DisplayName")
            if ($dn -and ($dn -eq $Name -or $dn.StartsWith($Name, [StringComparison]::OrdinalIgnoreCase))) {
                $hits += [pscustomobject]@{ Name = $dn; Version = [string](Get-Prop $e "DisplayVersion"); Key = [string]$e.PSChildName
                                            Uninstall = [string](Get-Prop $e "UninstallString") }
            }
        }
    }
    return ,$hits
}

function Test-VersionMatch([string]$Have, [string]$Want) {
    if (-not $Have) { return $false }
    if ($Have -eq $Want) { return $true }
    # 23.01 and 23.01.00.0 are the same release
    return ($Have.StartsWith($Want + ".") -or $Want.StartsWith($Have + "."))
}

function Get-ShareCredential($Token, [string]$CommandId) {
    $r = Invoke-Api "GET" ("/api/v1/agent/commands/" + $CommandId + "/credential") $null $Token
    $sec = ConvertTo-SecureString ([string]$r.password) -AsPlainText -Force
    $r.password = $null
    return New-Object Management.Automation.PSCredential([string]$r.username, $sec)
}

function Invoke-SoftwareAction($Params, $Token, [string]$CommandId) {
    $action = [string](Get-Prop $Params "action"); $kind = [string](Get-Prop $Params "kind")
    $unc = [string](Get-Prop $Params "unc_path"); $want = [string](Get-Prop $Params "sha256")
    $detect = [string](Get-Prop $Params "detect_name"); $ver = [string](Get-Prop $Params "version")
    $pcode = [string](Get-Prop $Params "product_code"); $iargs = [string](Get-Prop $Params "install_args")
    $uargs = [string](Get-Prop $Params "uninstall_args"); $pub = [string](Get-Prop $Params "publisher")
    $needSig = [bool](Get-Prop $Params "require_signature")
    # Check again here what PATCH-01 sent: nothing reaches a command line unchecked
    if ($action -notin @("install", "upgrade", "uninstall")) { return @{ ok = $false; message = "unknown action"; result = @{} } }
    if ($kind -notin @("msi", "exe")) { return @{ ok = $false; message = "unknown installer type"; result = @{} } }
    if ($unc -notmatch $SwUnc -or $unc.Contains("..")) { return @{ ok = $false; message = "the share path was refused"; result = @{} } }
    if ($want -notmatch '^[0-9a-f]{64}$') { return @{ ok = $false; message = "the SHA-256 was refused"; result = @{} } }
    if ($kind -eq "msi" -and $pcode -notmatch $SwGuid) { return @{ ok = $false; message = "the product code was refused"; result = @{} } }
    if ($iargs -notmatch $SwArgs -or $uargs -notmatch $SwArgs) { return @{ ok = $false; message = "the installer options were refused"; result = @{} } }
    if (-not $detect) { return @{ ok = $false; message = "no name to recognise the program by"; result = @{} } }

    $before = @(Get-InstalledProgram $detect)
    $have = $null; if ($before.Count -gt 0) { $have = $before[0].Version }
    $res = @{ action = $action; before = $have; reboot_required = $false; nothing_to_do = $false }
    if ($action -eq "install" -and $before.Count -gt 0 -and (Test-VersionMatch $have $ver)) {
        $res.nothing_to_do = $true; return @{ ok = $true; message = ("already installed: " + $have); result = $res } }
    if ($action -eq "upgrade" -and $before.Count -eq 0) {
        return @{ ok = $false; message = ("not installed here, so nothing to upgrade (use install): " + $detect); result = $res } }
    if ($action -eq "upgrade" -and (Test-VersionMatch $have $ver)) {
        $res.nothing_to_do = $true; return @{ ok = $true; message = ("already on " + $have); result = $res } }
    if ($action -eq "uninstall" -and $before.Count -eq 0) {
        $res.nothing_to_do = $true; return @{ ok = $true; message = "not installed: nothing to remove"; result = $res } }

    $work = Join-Path $DataDir ("pkg\" + ($CommandId -replace '[^0-9a-f-]', ''))
    $log = Join-Path $DataDir ("pkg-" + ($CommandId -replace '[^0-9a-f-]', '') + ".log")
    try {
        New-Item -ItemType Directory -Force -Path $work | Out-Null
        $local = $null
        $needFile = -not ($action -eq "uninstall")
        if ($needFile) {
            # The share is reachable only with this job's credential, fetched once, kept in memory
            $null = $unc -match $SwUnc
            $root = "\\" + $Matches[1] + "\" + $Matches[2]; $rest = $Matches[3]
            $cred = Get-ShareCredential $Token $CommandId
            $drv = "PA" + ([guid]::NewGuid().ToString("N").Substring(0, 6))
            try {
                New-PSDrive -Name $drv -PSProvider FileSystem -Root $root -Credential $cred -ErrorAction Stop | Out-Null
                $local = Join-Path $work (Split-Path -Leaf $unc)
                Copy-Item -LiteralPath ($drv + ":" + $rest) -Destination $local -ErrorAction Stop
            } catch {
                return @{ ok = $false; message = ("could not copy the installer from the share: " + $_.Exception.Message); result = $res }
            } finally {
                Remove-PSDrive -Name $drv -Force -ErrorAction SilentlyContinue
                $cred = $null
            }
            $got = (Get-FileHash -Algorithm SHA256 -LiteralPath $local).Hash.ToLowerInvariant()
            if ($got -ne $want) {
                return @{ ok = $false; message = ("the installer's SHA-256 is " + $got + ", not the approved one: nothing was run"); result = $res } }
            if ($needSig) {
                $sig = Get-AuthenticodeSignature -LiteralPath $local
                if ($sig.Status -ne "Valid") {
                    return @{ ok = $false; message = ("the installer's signature is " + $sig.Status + ": nothing was run"); result = $res } }
                if ($sig.SignerCertificate.Subject -ne $pub) {
                    return @{ ok = $false; message = ("signed by '" + $sig.SignerCertificate.Subject + "', not the approved publisher: nothing was run"); result = $res } }
            }
        }
        # Fixed templates; started directly, never through cmd
        if ($kind -eq "msi") {
            $exe = Join-Path $env:SystemRoot "System32\msiexec.exe"
            if ($action -eq "uninstall") { $argline = "/x " + $pcode + " /qn /norestart /l*v `"" + $log + "`"" }
            else { $argline = "/i `"" + $local + "`" /qn /norestart /l*v `"" + $log + "`"" }
        } elseif ($action -eq "uninstall") {
            $u = $before[0].Uninstall
            if ($u -match '^"([^"]+\.exe)"') { $exe = $Matches[1] } elseif ($u -match '^(.+?\.exe)') { $exe = $Matches[1] } else { $exe = "" }
            if (-not $exe -or -not (Test-Path -LiteralPath $exe)) {
                return @{ ok = $false; message = "the program's own uninstaller was not found"; result = $res } }
            if ((Split-Path -Leaf $exe) -ieq "msiexec.exe") {
                $exe = Join-Path $env:SystemRoot "System32\msiexec.exe"
                $argline = "/x " + $before[0].Key + " /qn /norestart /l*v `"" + $log + "`""
                if ($before[0].Key -notmatch $SwGuid) { return @{ ok = $false; message = "the program's MSI code was not recognised"; result = $res } }
            } else { $argline = $uargs }
        } else {
            $exe = $local; $argline = $iargs
        }
        # Start-Process refuses an empty argument list, so options go in only when there are some
        $sp = @{ FilePath = $exe; PassThru = $true; WindowStyle = "Hidden" }
        if ($argline) { $sp["ArgumentList"] = $argline }
        $p = Start-Process @sp
        if (-not $p.WaitForExit(10200000)) {                 # 2 h 50 min, under PATCH-01's 3 h limit
            try { $p.Kill() } catch { }
            return @{ ok = $false; message = "the installer did not finish within 2 h 50 min and was stopped"; result = $res }
        }
        $code = $p.ExitCode; $res.exit_code = $code
        if ($code -eq 3010 -or $code -eq 1641) { $res.reboot_required = $true }
        elseif ($code -ne 0) {
            return @{ ok = $false; message = ("the installer ended with code " + $code + $(if ($kind -eq "msi") { " (MSI log: " + $log + ")" } else { "" })); result = $res } }
        # Prove it: the program is there in the expected version, or gone
        $after = @(Get-InstalledProgram $detect)
        $res.after = $null; if ($after.Count -gt 0) { $res.after = $after[0].Version }
        if ($action -eq "uninstall") {
            if ($after.Count -gt 0 -and -not $res.reboot_required) {
                return @{ ok = $false; message = ("the installer finished but " + $after[0].Name + " is still listed"); result = $res } }
            return @{ ok = $true; message = ("removed " + $detect + $(if ($res.reboot_required) { "; a reboot completes it" } else { "" })); result = $res }
        }
        if ($after.Count -eq 0) { return @{ ok = $false; message = ("the installer finished but " + $detect + " is not listed"); result = $res } }
        if (-not (Test-VersionMatch $after[0].Version $ver)) {
            return @{ ok = $false; message = ("installed, but it reports version " + $after[0].Version + ", not " + $ver); result = $res } }
        return @{ ok = $true; message = ($action + " done: " + $after[0].Name + " " + $after[0].Version + $(if ($res.reboot_required) { "; a reboot is needed" } else { "" })); result = $res }
    } finally {
        Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Send-LogTail($Token) {
    <# Sends the log lines written since the last send, so failures can be read
       in the console. Never lets a problem here break a run, and never logs
       about itself (that would feed its own output). #>
    try {
        if (-not (Test-Path $LogFile)) { return }
        $state = Get-State
        $off = [long]0
        if ($state.PSObject.Properties["log_offset"] -and $state.log_offset) { $off = [long]$state.log_offset }
        $len = (Get-Item $LogFile).Length
        if ($len -lt $off) { $off = 0 }                       # the log was rotated
        if ($len -eq $off) { return }
        if ($len - $off -gt 262144) { $off = $len - 262144 }  # at most the last 256 KB
        $fs = [IO.File]::Open($LogFile, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
        try {
            [void]$fs.Seek($off, [IO.SeekOrigin]::Begin)
            $text = (New-Object IO.StreamReader($fs, [Text.Encoding]::UTF8)).ReadToEnd()
        } finally { $fs.Dispose() }
        $lines = @()
        foreach ($l in ($text -split "`r?`n")) {
            if ($l -match '^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d) (?:(INFO|WARN|ERROR) )?(.+)$') {
                $at = [datetime]::ParseExact($Matches[1], "yyyy-MM-dd HH:mm:ss", [Globalization.CultureInfo]::InvariantCulture)
                $lvl = "INFO"; if ($Matches[2]) { $lvl = $Matches[2] }
                $msg = $Matches[3]; if ($msg.Length -gt 2000) { $msg = $msg.Substring(0, 2000) }
                $lines += @{ at = (Get-IsoUtc $at); level = $lvl; msg = $msg }
            }
        }
        if ($lines.Count -gt 500) { $lines = $lines[($lines.Count - 500)..($lines.Count - 1)] }
        if ($lines.Count -gt 0) { Invoke-Api "POST" "/api/v1/agent/log" @{ lines = $lines } $Token | Out-Null }
        $state = Get-State
        if ($state.PSObject.Properties["log_offset"]) { $state.log_offset = $len } else { $state | Add-Member -NotePropertyName log_offset -NotePropertyValue $len }
        Save-State $state
    } catch { Write-Verbose ("log send failed: " + $_.Exception.Message) }
}

function Send-Result($Token, [string]$CommandId, $Body) {
    # A lost result leaves PATCH-01 waiting: retry, and log if it still fails
    for ($i = 1; $i -le 3; $i++) {
        try { Invoke-Api "POST" ("/api/v1/agent/commands/" + $CommandId + "/result") $Body $Token | Out-Null; return $true }
        catch {
            Write-Log ("sending the result of command " + $CommandId + " failed (try " + $i + " of 3): " + $_.Exception.Message) "ERROR"
            Start-Sleep -Seconds (5 * $i)
        }
    }
    return $false
}

function Invoke-Commands($Token) {
    $cmds = @(Invoke-Api "GET" "/api/v1/agent/commands" $null $Token)
    $ranInventory = $false; $count = 0; $rebooting = $false
    foreach ($c in $cmds) {
        if ($null -eq $c -or -not $c.PSObject.Properties["id"]) { continue }
        $count++
        $ok = $true; $msg = $null; $res = @{}
        $t0 = Get-Date
        Write-Log ("command " + $c.verb + " started (" + $c.id + ")")
        try {
            $params = Get-Prop $c "params"
            $out = $null
            switch ($c.verb) {
                "collect_inventory" { Send-Inventory $Token; $ranInventory = $true; $msg = "inventory sent" }
                "run_precheck"      { $out = Invoke-Precheck $params }
                "install_packages"  { $out = Invoke-InstallUpdates $params }
                "reboot_host"       { $out = Invoke-Reboot $params }
                "run_postcheck"     { $out = Invoke-Postcheck $params }
                "software_action"   { $out = Invoke-SoftwareAction $params $Token ([string]$c.id) }
                default { $ok = $false; $msg = "'" + $c.verb + "' is not supported by the Windows agent" }
            }
            if ($null -ne $out) { $ok = [bool]$out.ok; $msg = [string]$out.message; $res = $out.result }
        } catch {
            $ok = $false
            $msg = [string]$_.Exception.Message
            $where = ""; if ($_.InvocationInfo) { $where = " (line " + $_.InvocationInfo.ScriptLineNumber + ")" }
            Write-Log ("command " + $c.verb + " threw: " + $msg + $where) "ERROR"
        }
        $secs = [int]((Get-Date) - $t0).TotalSeconds
        Write-Log ("command {0} {1} in {2} s: {3}" -f $c.verb, $(if ($ok) { "ok" } else { "failed" }), $secs, $msg) $(if ($ok) { "INFO" } else { "WARN" })
        [void](Send-Result $Token ([string]$c.id) @{ ok = $ok; message = $msg; result = $res })
        Send-LogTail $Token
        if ($c.verb -eq "reboot_host" -and $ok) { $rebooting = $true }
    }
    return @{ inventory = $ranInventory; count = $count; rebooting = $rebooting }
}

# ---------------------------------------------------------------------------
# Modes
# ---------------------------------------------------------------------------
function Start-Run {
    # One run at a time: a slow Windows Update search must not overlap the next
    $mutex = New-Object Threading.Mutex($false, "Global\PatchAgentRun")
    if (-not $mutex.WaitOne(0)) { Write-Log "previous run still busy; skipping"; return }
    $tok = $null
    try {
        $cfg = Get-Config
        Initialize-Http $cfg.pin
        $tok = Get-Token
        Send-Checkin $tok
        # PATCH-01 queues a job's next step as soon as the last one reports, so ask
        # again straight away instead of waiting for the next 5-minute run
        $done = $false
        for ($round = 0; $round -lt 12; $round++) {
            $r = Invoke-Commands $tok
            if ($r.inventory) { $done = $true }
            if ($r.count -eq 0 -or $r.rebooting) { break }
            Start-Sleep -Seconds 10
        }
        $state = Get-State
        if (-not $state.PSObject.Properties["last_inventory"]) { $state | Add-Member -NotePropertyName last_inventory -NotePropertyValue $null }
        $due = $true
        if ($state.last_inventory) {
            $due = ((Get-Date) - [datetime]$state.last_inventory).TotalHours -ge $InventoryEveryHours
        }
        if ($Inventory -or ($due -and -not $done)) { Send-Inventory $tok; $done = $true }
        if ($done) { $state.last_inventory = (Get-Date).ToString("o"); Save-State $state }
    } catch {
        $where = ""; if ($_.InvocationInfo) { $where = " (line " + $_.InvocationInfo.ScriptLineNumber + ")" }
        Write-Log ("run failed: " + $_.Exception.Message + $where) "ERROR"
        throw
    } finally {
        # Whatever happened, the console gets this run's log lines
        try { if ($tok) { Send-LogTail $tok } } catch { }
        $mutex.ReleaseMutex(); $mutex.Dispose()
    }
}

function Start-Enroll {
    if (-not (Test-Path $DataDir)) { New-Item -ItemType Directory -Path $DataDir | Out-Null }
    $script:Cfg = [pscustomobject]@{ server = $Server.TrimEnd("/"); pin = $Pin.Trim().ToLowerInvariant() }
    Initialize-Http $script:Cfg.pin
    $f = Get-Facts
    $body = @{ enrollment_token = $Token; machine_id = $f.MachineId; hostname = $f.Hostname; os_id = "windows"
               os_version = $f.Version; arch = "x86_64"; pkg_manager = "wua"; agent_version = $AgentVersion }
    if ($f.Fqdn -and $f.Fqdn -ne $f.Hostname) { $body["fqdn"] = $f.Fqdn }
    $resp = Invoke-Api "POST" "/api/v1/agent/enroll" $body
    ConvertTo-Json -InputObject @{ server = $script:Cfg.server; pin = $script:Cfg.pin; host_id = $resp.host_id } | Set-Content -Path $ConfigFile -Encoding UTF8
    Save-Token $resp.agent_token
    Write-Log ("enrolled as {0} ({1})" -f $f.Hostname, $resp.host_id)
    Write-Output ("Enrolled {0} with PATCH-01. Host id {1}." -f $f.Hostname, $resp.host_id)
}

function Start-SelfTest {
    $results = New-Object Collections.ArrayList
    function Step([string]$Name, [scriptblock]$Do) {
        try { $d = & $Do; [void]$results.Add([pscustomobject]@{ Step = $Name; Result = "ok"; Detail = [string]$d }) }
        catch { [void]$results.Add([pscustomobject]@{ Step = $Name; Result = "FAILED"; Detail = $_.Exception.Message }) }
    }
    $script:Cfg = [pscustomobject]@{ server = $Server.TrimEnd("/"); pin = $Pin.Trim().ToLowerInvariant() }
    Step "Run as administrator" { $id = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
                                  if (-not $id.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw "run PowerShell as administrator" }; "yes" }
    Step "PowerShell version" { if ($PSVersionTable.PSVersion.Major -lt 5) { throw ("5.1 needed, found " + $PSVersionTable.PSVersion) }; [string]$PSVersionTable.PSVersion }
    Step "Reach PATCH-01, certificate pin" { Initialize-Http $script:Cfg.pin; $h = Invoke-Api "GET" "/api/v1/health"; "reached; certificate " + [PatchAgentPin]::Seen.Substring(0, 16) + "... matches" }
    Step "OS build" { $b = Get-Build; "{0} ({1}), Windows Server {2}" -f $b.Build, $b.Product, (Get-ServerVersion $b) }
    Step "Reboot state" { $r = Get-RebootState; if ($r.Required) { "reboot pending: " + $r.Reason } else { "no reboot pending" } }
    Step "Hardware ID (links the VM)" { $f = Get-Facts; if ($f.Uuid) { $f.Uuid } else { throw "no usable UUID from Win32_ComputerSystemProduct" } }
    Step "Installed updates" { "{0} KBs" -f @(Get-HotFix -ErrorAction SilentlyContinue).Count }
    Step "Update source" { $s = Get-WsusSource; if ($s.Source -eq "wsus") { "WSUS at " + $s.Server } else { "Microsoft Update directly (no WSUS policy found)" } }
    Step "Windows Update search" { $u = Search-MissingUpdates; "{0} updates missing" -f $u.Count }
    $results | Format-Table -AutoSize -Wrap | Out-String -Width 200 | Write-Output
    $failed = @($results | Where-Object { $_.Result -ne "ok" }).Count
    if ($failed) { Write-Output "$failed step(s) failed: fix them before enrolling." } else { Write-Output "All steps passed: this server is ready to enrol." }
}

switch ($PSCmdlet.ParameterSetName) {
    "SelfTest"  { Start-SelfTest }
    "Enroll"    { Start-Enroll }
    "Inventory" { Start-Run }
    default     { Start-Run }
}
