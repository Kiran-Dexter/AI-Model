-- ---------------------------------------------------------------------------
-- PATCH-01 : schema 057 - Carbon Black EDR, the tools cross-checked, a plan per CVE (r111)
--
-- cb_servers       Carbon Black EDR servers (on-premises), added by an admin. Read-only:
--                  PATCH-01 only sends GET requests. The API token is encrypted (av.key)
-- cb_sensors       the machines each server sees, with OS and last check-in
-- cb_binaries      program files of the products the CVEs name: product name, maker,
--                  version, and on which machine each last ran this week, and when
--                  (from Carbon Black's process search, per machine)
-- cve_impact.plan  per CVE: its priority and why, what to do on which machines, and the
--                  cross-check of the tools (which agree, which disagree, and why)
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS cb_servers (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name              TEXT NOT NULL UNIQUE CHECK (name ~ '^[A-Za-z0-9 ._()-]{1,60}$'),
    url               TEXT NOT NULL UNIQUE,
    token_enc         TEXT NOT NULL,
    pin_sha256        TEXT CHECK (pin_sha256 IS NULL OR pin_sha256 ~ '^[0-9a-f]{64}$'),
    pin_subject       TEXT,
    pinned_by         TEXT,
    pinned_at         TIMESTAMPTZ,
    enabled           BOOLEAN NOT NULL DEFAULT true,
    version           TEXT,
    created_by        TEXT NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by        TEXT,
    updated_at        TIMESTAMPTZ,
    last_test_at      TIMESTAMPTZ,
    last_test_ok      BOOLEAN,
    last_test_msg     TEXT,
    last_sync_at      TIMESTAMPTZ,
    last_sync_ok      BOOLEAN,
    last_sync_msg     TEXT,
    sensors           INTEGER,
    sync_requested_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS cb_sensors (
    server_id     UUID NOT NULL REFERENCES cb_servers(id) ON DELETE CASCADE,
    sensor_id     INTEGER NOT NULL,
    hostname      TEXT NOT NULL,
    dns_name      TEXT,
    ips           TEXT[] NOT NULL DEFAULT '{}',
    os            TEXT,
    os_type       TEXT,
    status        TEXT,
    last_checkin  TIMESTAMPTZ,
    PRIMARY KEY (server_id, sensor_id)
);
CREATE INDEX IF NOT EXISTS idx_cb_sensors_name ON cb_sensors (lower(hostname));

CREATE TABLE IF NOT EXISTS cb_binaries (
    server_id        UUID NOT NULL REFERENCES cb_servers(id) ON DELETE CASCADE,
    md5              TEXT NOT NULL CHECK (md5 ~ '^[0-9A-F]{32}$'),
    product_name     TEXT,
    company_name     TEXT,
    product_version  TEXT,
    file_version     TEXT,
    filename         TEXT,
    host_count       INTEGER,
    last_seen        TIMESTAMPTZ,
    host_times       JSONB,                 -- {computer name: when it last ran there this week}
    hosts_at         TIMESTAMPTZ,           -- when host_times was read
    PRIMARY KEY (server_id, md5)
);

ALTER TABLE cve_impact ADD COLUMN IF NOT EXISTS plan JSONB NOT NULL DEFAULT '{}';

-- Every CVE is checked again with the cross-check, and its brief rewritten
UPDATE cve_impact SET inventory_mark = NULL, ai_key = NULL;

INSERT INTO schema_version (version, description)
VALUES (57, 'Carbon Black EDR (read-only), the tools cross-checked, a plan per CVE')
ON CONFLICT (version) DO NOTHING;
