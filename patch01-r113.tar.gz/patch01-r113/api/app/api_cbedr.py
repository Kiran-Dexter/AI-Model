"""Carbon Black EDR servers (Admin > Carbon Black EDR), r111.

Added by an admin with a read-only user's API token; the token is encrypted before it is stored and
never shown again. Before saving, the server is signed in to and its sensors read; a certificate
that is not publicly trusted must be compared and trusted by its fingerprint (never turned off)."""

import psycopg
import re
from typing import Optional
from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field

from .core import app, audit, client_ip, db, jsonable, log, require_admin

CB_CHECKS_PER_10MIN = 20


class CbServerIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=60)
    url: str = Field(..., min_length=9, max_length=300)
    token: Optional[str] = Field(None, max_length=80)          # blank on edit: keep the saved one
    pin_sha256: Optional[str] = Field(None, max_length=120)    # None: keep; "": remove; value: trust this certificate
    enabled: bool = True


class CbTestIn(BaseModel):
    id: Optional[str] = Field(None, max_length=36)
    url: Optional[str] = Field(None, max_length=300)
    token: Optional[str] = Field(None, max_length=80)
    pin_sha256: Optional[str] = Field(None, max_length=120)


class CbCertIn(BaseModel):
    url: str = Field(..., min_length=9, max_length=300)


def _cid(v):
    if not re.fullmatch(r"[0-9a-f-]{36}", v or ""):
        raise HTTPException(404, "No such Carbon Black server.")
    return v


def _server(conn, sid):
    r = conn.execute("SELECT * FROM cb_servers WHERE id = %s", (_cid(sid),)).fetchone()
    if not r:
        raise HTTPException(404, "No such Carbon Black server.")
    return dict(r)


def _limit(conn, user, actions, n=CB_CHECKS_PER_10MIN):
    k = conn.execute("""SELECT count(*) AS n FROM audit_log WHERE actor = %s AND action = ANY(%s)
                          AND occurred_at > now() - interval '10 minutes'""", (user, list(actions))).fetchone()["n"]
    if k >= n:
        raise HTTPException(429, f"At most {n} of these in 10 minutes: try again shortly.")


def _view(conn):
    """The servers (never the token), what each sees, and how many of its machines PATCH-01 knows."""
    from . import cbedr
    rows = [dict(r) for r in conn.execute(
        """SELECT s.id, s.name, s.url, s.enabled, s.version, s.pin_sha256 IS NOT NULL AS pinned, s.pin_subject,
                  s.last_test_at, s.last_test_ok, s.last_test_msg, s.last_sync_at, s.last_sync_ok, s.last_sync_msg,
                  s.sensors, s.created_by, s.created_at,
                  (SELECT count(*) FROM cb_binaries b WHERE b.server_id = s.id) AS binaries,
                  (SELECT count(*) FROM cb_sensors c WHERE c.server_id = s.id AND EXISTS (
                      SELECT 1 FROM hosts h WHERE h.status <> 'decommissioned'
                         AND lower(split_part(h.hostname, '.', 1)) = lower(split_part(c.hostname, '.', 1)))) AS with_agent
             FROM cb_servers s ORDER BY lower(s.name)""").fetchall()]
    for r in rows:
        r["id"] = str(r["id"])
    return {"servers": rows, "sync_minutes": cbedr.SYNC_MINUTES, "seen_days": cbedr.SEEN_DAYS}


@app.get("/api/v1/admin/carbon-black")
def cb_admin(admin: str = Depends(require_admin)):
    with db() as conn:
        try:
            return jsonable(_view(conn))
        except psycopg.errors.UndefinedTable:
            raise HTTPException(409, "Schema 057 is not applied yet: run phase3a-schema.sh.")


@app.post("/api/v1/admin/carbon-black/certificate")
def cb_certificate(body: CbCertIn, request: Request, admin: str = Depends(require_admin)):
    """The certificate the server presents (handshake only: nothing is sent), to compare and trust."""
    from . import cbedr
    with db() as conn:
        _limit(conn, admin, ("cb_certificate_read", "cb_tested"))
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="cb_certificate_read", detail={"url": body.url[:200]},
                  source_ip=client_ip(request))
    try:
        cert = cbedr.certificate(body.url)
        cert["publicly_trusted"] = cbedr.publicly_trusted(body.url)
        return cert
    except cbedr.CbError as e:
        raise HTTPException(422, str(e))


@app.post("/api/v1/admin/carbon-black/test")
def cb_test(body: CbTestIn, request: Request, admin: str = Depends(require_admin)):
    """Sign in with what is typed (or a saved server's token, only for its own address) and read the sensors."""
    from . import cbedr
    with db() as conn:
        _limit(conn, admin, ("cb_certificate_read", "cb_tested"))
        saved = _server(conn, body.id) if body.id else None
        try:
            url = cbedr.clean_url(body.url) if body.url else (saved or {}).get("url")
            if not url:
                raise cbedr.CbError("Enter the Carbon Black EDR server's address, for example https://cb.example.local")
            pin = (saved or {}).get("pin_sha256") if body.pin_sha256 is None else cbedr.clean_pin(body.pin_sha256)
            if saved and url != saved["url"] and body.pin_sha256 is None:
                pin = None                                   # a pinned certificate belongs to its own address
            if body.token:
                token = cbedr.clean_token(body.token)
            elif saved and url == saved["url"] and pin == saved["pin_sha256"]:
                token = None                                 # the saved token, only ever to its own server and certificate
            else:
                raise cbedr.CbError("Enter the API token (a saved token only ever goes to its own address and certificate).")
        except cbedr.CbError as e:
            raise HTTPException(422, str(e))
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="cb_tested", object_id=body.id, detail={"url": url},
                  source_ip=client_ip(request))
    server = dict(saved or {}, url=url, pin_sha256=pin)
    try:
        res = dict(cbedr.test(server, token), ok=True)
    except cbedr.CbError as e:
        res = {"ok": False, "message": str(e)}
    except Exception as e:  # noqa: BLE001 - never a stack trace from a far end's answer
        log.warning("carbon black test: %s", type(e).__name__)
        res = {"ok": False, "message": "Carbon Black's answer could not be read."}
    finally:
        token = None
    if saved and url == saved["url"] and not body.token and pin == saved["pin_sha256"]:
        with db() as conn:
            conn.execute("UPDATE cb_servers SET last_test_at = now(), last_test_ok = %s, last_test_msg = %s WHERE id = %s",
                         (res["ok"], res["message"][:400], saved["id"]))
            conn.commit()
    return res


def _prepare(body, saved=None):
    """(name, url, encrypted token, pin, certificate, test result) for a save; every check made first."""
    from . import cbedr
    name = body.name.strip()
    if not cbedr.NAME_RE.match(name):
        raise cbedr.CbError("The name may use letters, digits, spaces and . _ ( ) -")
    url = cbedr.clean_url(body.url)
    pin_typed = None if body.pin_sha256 is None else cbedr.clean_pin(body.pin_sha256)
    if body.token:
        token = cbedr.clean_token(body.token)
    elif saved and url == saved["url"] and (body.pin_sha256 is None or pin_typed == saved["pin_sha256"]):
        token = None
    else:
        raise cbedr.CbError("Enter the API token" + (" again: the address changed (a saved token only ever goes to its own server)."
                                                      if saved else "."))
    pin = saved["pin_sha256"] if saved and body.pin_sha256 is None and url == saved["url"] else cbedr.clean_pin(body.pin_sha256)
    if not pin and cbedr.publicly_trusted(url) is not True:
        raise cbedr.CbError("The server's certificate is not publicly trusted: use “Get certificate”, compare the fingerprint "
                            "with the one on the Carbon Black server, and trust it. Verification is never turned off.")
    cert = None
    if pin and (not saved or pin != saved["pin_sha256"]):
        cert = cbedr.certificate(url)
        if cert["sha256"] != pin:
            raise cbedr.CbError("The server now presents a different certificate (SHA-256 " + cert["sha256_text"] + "): get it again and compare.")
    res = cbedr.test(dict(saved or {}, url=url, pin_sha256=pin), token)
    enc = cbedr.encrypt(token) if token else saved["token_enc"]
    return name, url, enc, pin, cert, res


def _attempt(admin, request, action, sid, url):
    """Saving signs in to the server: limited and recorded like a test, before any request."""
    with db() as conn:
        _limit(conn, admin, ("cb_certificate_read", "cb_tested", "cb_save_attempted"))
        with conn.transaction():
            audit(conn, actor=admin, actor_type="user", action="cb_save_attempted", object_id=sid,
                  detail={"url": (url or "")[:200], "as": action}, source_ip=client_ip(request))


@app.post("/api/v1/admin/carbon-black")
def cb_add(body: CbServerIn, request: Request, admin: str = Depends(require_admin)):
    from . import cbedr
    _attempt(admin, request, "add", None, body.url)
    try:
        name, url, enc, pin, cert, res = _prepare(body)
    except cbedr.CbError as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        try:
            with conn.transaction():
                if conn.execute("SELECT 1 FROM cb_servers WHERE lower(name) = lower(%s) OR url = %s", (name, url)).fetchone():
                    raise HTTPException(409, "A Carbon Black server with this name or address is already added.")
                r = conn.execute(
                    """INSERT INTO cb_servers (name, url, token_enc, pin_sha256, pin_subject, pinned_by, pinned_at, enabled,
                                               version, created_by, last_test_at, last_test_ok, last_test_msg, sync_requested_at)
                       VALUES (%s,%s,%s,%s,%s,%s, CASE WHEN %s::text IS NULL THEN NULL ELSE now() END, %s,%s,%s, now(), true, %s, now())
                       RETURNING id""",
                    (name, url, enc, pin, (cert or {}).get("subject"), admin if pin else None, pin, body.enabled,
                     res.get("version"), admin, res["message"][:400])).fetchone()
                audit(conn, actor=admin, actor_type="user", action="cb_server_added", object_type="cb_server",
                      object_id=str(r["id"]), detail={"name": name, "url": url, "pinned_sha256": pin}, source_ip=client_ip(request))
        except psycopg.errors.UniqueViolation:
            raise HTTPException(409, "A Carbon Black server with this name or address is already added.")
        return jsonable(_view(conn))


@app.put("/api/v1/admin/carbon-black/{sid}")
def cb_edit(sid: str, body: CbServerIn, request: Request, admin: str = Depends(require_admin)):
    from . import cbedr
    with db() as conn:
        s = _server(conn, sid)
    _attempt(admin, request, "edit", sid, body.url)
    try:
        name, url, enc, pin, cert, res = _prepare(body, s)
    except cbedr.CbError as e:
        raise HTTPException(422, str(e))
    with db() as conn:
        try:
            with conn.transaction():
                if conn.execute("SELECT 1 FROM cb_servers WHERE (lower(name) = lower(%s) OR url = %s) AND id <> %s",
                                (name, url, s["id"])).fetchone():
                    raise HTTPException(409, "Another Carbon Black server has this name or address.")
                conn.execute(
                    """UPDATE cb_servers SET name=%s, url=%s, token_enc=%s,
                              pinned_by = CASE WHEN %s::text IS DISTINCT FROM pin_sha256 THEN %s ELSE pinned_by END,
                              pinned_at = CASE WHEN %s::text IS DISTINCT FROM pin_sha256 THEN now() ELSE pinned_at END,
                              pin_subject = CASE WHEN %s::text IS NULL THEN NULL ELSE coalesce(%s, pin_subject) END,
                              pin_sha256=%s, enabled=%s, version=coalesce(%s, version), updated_by=%s, updated_at=now(),
                              last_test_at=now(), last_test_ok=true, last_test_msg=%s, sync_requested_at=now()
                        WHERE id=%s""",
                    (name, url, enc, pin, admin if pin else None, pin, pin, (cert or {}).get("subject"), pin, body.enabled,
                     res.get("version"), admin, res["message"][:400], s["id"]))
                if body.enabled != s["enabled"] or url != s["url"]:
                    from . import cve_impact
                    cve_impact.inventory_changed(conn)          # its findings go (or come) at the next pass
                audit(conn, actor=admin, actor_type="user", action="cb_server_changed", object_type="cb_server",
                      object_id=str(s["id"]), detail={"name": name, "url": url, "token_changed": enc != s["token_enc"],
                                                      "pinned_sha256": pin}, source_ip=client_ip(request))
        except psycopg.errors.UniqueViolation:
            raise HTTPException(409, "Another Carbon Black server has this name or address.")
        return jsonable(_view(conn))


@app.delete("/api/v1/admin/carbon-black/{sid}")
def cb_remove(sid: str, request: Request, admin: str = Depends(require_admin)):
    """Remove a server from PATCH-01: what it saw goes too; nothing changes in Carbon Black."""
    with db() as conn:
        with conn.transaction():
            r = conn.execute("DELETE FROM cb_servers WHERE id = %s RETURNING name", (_cid(sid),)).fetchone()
            if not r:
                raise HTTPException(404, "No such Carbon Black server.")
            from . import cve_impact
            cve_impact.inventory_changed(conn)
            audit(conn, actor=admin, actor_type="user", action="cb_server_removed", object_type="cb_server",
                  object_id=sid, detail={"name": r["name"]}, source_ip=client_ip(request))
        return jsonable(_view(conn))


@app.post("/api/v1/admin/carbon-black/{sid}/sync")
def cb_sync(sid: str, request: Request, user: str = Depends(require_admin)):
    """Read the server again now (the worker does it within a minute)."""
    with db() as conn:
        _limit(conn, user, ("cb_sync_requested",))
        with conn.transaction():
            s = _server(conn, sid)
            conn.execute("UPDATE cb_servers SET sync_requested_at = now() WHERE id = %s", (s["id"],))
            audit(conn, actor=user, actor_type="user", action="cb_sync_requested", object_type="cb_server",
                  object_id=str(s["id"]), detail={"name": s["name"]}, source_ip=client_ip(request))
        return jsonable(_view(conn))
