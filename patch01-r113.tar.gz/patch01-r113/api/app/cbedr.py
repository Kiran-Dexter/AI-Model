"""Carbon Black EDR (on-premises, formerly CB Response), read-only (r111).

What PATCH-01 reads, with GET requests only (the one request function refuses any other method):

  sensors    /api/v1/sensor: every machine with a Carbon Black sensor, its name, addresses, OS
             and last check-in. Machines without a PATCH-01 agent are seen this way too
  binaries   /api/v1/binary: program files Carbon Black has seen, with the product name, maker
             and version written in the file itself. Searched only for the products (and makers)
             named by the CVEs being checked
  runs       /api/v1/process (process_md5, last_update in the last SEEN_DAYS days): on which machine
             each of those files last ran, and when. A binary's own "seen on" list says only that a
             machine had it once; it is never used as evidence

How it is used (cve_impact.match_carbon_black): a program counts only when it is proven to be
the CVE's product (the same rules as the Windows programs: name and maker, or an admin's word).
On each machine, the version that ran last decides: affected when it is inside the range and no
fixed version ran after it. Carbon Black never proves a machine fixed, and never overrules
PATCH-01's own newer proof of the same product: the newest proof wins.

The API token: Carbon Black EDR tokens carry the full rights of their user and do not expire,
so use a dedicated user with read-only rights (a Viewer on the sensor groups). The token is
encrypted with the secrets key (av.key) before it is stored, decrypted only in memory for a
request, and never returned to the browser or written to a log.
"""
import json
import logging
import re
import time
import urllib.parse
from datetime import datetime, timedelta, timezone

log = logging.getLogger("patchapi.cbedr")

TOKEN_RE = re.compile(r"^[0-9a-f]{40}$")
NAME_RE = re.compile(r"^[A-Za-z0-9 ._()-]{1,60}$")
TERM_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 .+#-]{1,59}$")
MD5_RE = re.compile(r"^[0-9A-F]{32}$")
MAX_JSON = 64 * 2 ** 20
DEADLINE = 120
SYNC_MINUTES = 60
SEEN_DAYS = 7                 # runs looked at: the last week
KEEP_DAYS = 45                # binaries not seen for this long are dropped
MAX_SENSORS = 50000
PER_PAGE = 200                # binaries per page of a search
MAX_PER_TERM = 1000           # binaries per searched word, at most (newest first)
MAX_RUN_LOOKUPS = 600         # per sync: where and when each file last ran
MAX_RUNS = 2000               # runs read per file


class CbError(RuntimeError):
    """A problem worth showing to the admin as it is."""


def _av():
    from . import antivirus
    return antivirus


def _say(e):
    return CbError(str(e).replace("an Apex Central console", "a Carbon Black EDR server").replace("Apex Central", "Carbon Black EDR")
                   .replace("the console's", "the Carbon Black server's").replace("The console's", "The Carbon Black server's")
                   .replace("the console", "the Carbon Black server").replace("The console", "The Carbon Black server")
                   .replace("antivirus key av.key", "secrets key av.key"))


def _wrap(fn, *a):
    av = _av()
    try:
        return fn(*a)
    except av.AvError as e:
        raise _say(e)


def clean_url(url):
    return _wrap(_av().clean_url, url)


def clean_pin(v):
    return _wrap(_av().clean_pin, v)


def encrypt(v):
    return _wrap(_av().encrypt, v)


def decrypt(v):
    return _wrap(_av().decrypt, v)


def clean_token(v):
    v = (v or "").strip().lower()
    if not TOKEN_RE.match(v):
        raise CbError("The API token is 40 hexadecimal characters: in Carbon Black EDR, open the read-only user's "
                      "Profile > API Token and copy it.")
    return v


def certificate(url):
    return _wrap(_av().fetch_certificate, {"url": clean_url(url), "use_proxy": False})


def publicly_trusted(url):
    return _av().trusted_publicly(url)


# ---------------------------------------------------------------------------
# Requests: GET only
# ---------------------------------------------------------------------------

def _get(server, path, token=None):
    """One GET. path is built here from fixed parts and checked values only."""
    av = _av()
    if not path.startswith("/api/") or any(c in path for c in "\r\n "):
        raise CbError("Not a Carbon Black API path.")
    u = urllib.parse.urlsplit(clean_url(server["url"]))
    host, port = u.hostname, u.port or 443
    tok = token or decrypt(server["token_enc"])
    headers = {"X-Auth-Token": tok, "Accept": "application/json", "User-Agent": "PATCH-01 (read-only)", "Host": u.netloc}
    deadline = time.monotonic() + DEADLINE
    try:
        ctx = av._context({"pin_sha256": server.get("pin_sha256"), "ca_pem": None})
        conn = av._connection({"pin_sha256": server.get("pin_sha256"), "use_proxy": False}, host, port, ctx)
        try:
            conn.request("GET", path, headers=headers)
            r = conn.getresponse()
            chunks, size = [], 0
            while True:
                if time.monotonic() > deadline:
                    raise CbError(f"Carbon Black took longer than {DEADLINE} seconds to answer.")
                b = r.read(65536)
                if not b:
                    break
                size += len(b)
                if size > MAX_JSON:
                    raise CbError("Carbon Black's answer is too large.")
                chunks.append(b)
        finally:
            conn.close()
    except CbError:
        raise
    except av.AvError as e:
        raise _say(e)
    except Exception as e:  # noqa: BLE001 - one plain message
        log.info("cbedr: %s: %s", server.get("url"), type(e).__name__)
        raise _say(av.AvError(av._fail_text(e)))
    finally:
        tok = None
        headers = None
    if r.status in (301, 302, 303, 307, 308):
        raise CbError(f"Carbon Black answered with a redirect ({r.status}): use the server's own https address.")
    if r.status == 401:
        raise CbError("Carbon Black refused the API token (401): copy it again from the user's Profile > API Token.")
    if r.status == 403:
        raise CbError("Carbon Black refused the request (403): the API user may not read sensors or binaries.")
    if r.status == 404:
        raise CbError("Carbon Black has no such API here (404): check the address points at the EDR server.")
    if r.status != 200:
        raise CbError(f"Carbon Black answered HTTP {r.status}.")
    try:
        return json.loads(b"".join(chunks).decode("utf-8-sig"))
    except Exception:  # noqa: BLE001
        raise CbError("Carbon Black's answer is not JSON: check the address points at the EDR server.")


# ---------------------------------------------------------------------------
# Sensors
# ---------------------------------------------------------------------------

def _ts(v):
    """'2026-10-30 08:12:01.123456-07:00', '2026-10-30T15:12:01.123Z' -> aware datetime (None if unreadable)."""
    if not v or not isinstance(v, str):
        return None
    m = re.match(r"^(\d{4}-\d\d-\d\d)[ T](\d\d:\d\d:\d\d)(?:\.\d+)?(Z|[+-]\d\d:?\d\d)?$", v.strip())
    if not m:
        return None
    tz = m.group(3) or "Z"
    tz = "+00:00" if tz == "Z" else (tz if ":" in tz else tz[:3] + ":" + tz[3:])
    try:
        return datetime.fromisoformat(m.group(1) + "T" + m.group(2) + tz)
    except ValueError:
        return None


def _txt(v, n):
    return re.sub(r"[\x00-\x1f]", " ", str(v or ""))[:n].strip() or None


def parse_sensors(doc):
    rows = doc if isinstance(doc, list) else []
    out = []
    for s in rows[:MAX_SENSORS]:
        if not isinstance(s, dict) or not isinstance(s.get("id"), int):
            continue
        ips = []
        for part in str(s.get("network_adapters") or "").split("|"):
            ip = part.split(",")[0].strip()
            if re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}|[0-9a-fA-F:]{3,39}", ip) and ip not in ips:
                ips.append(ip)
        out.append({"sensor_id": s["id"], "hostname": _txt(s.get("computer_name"), 120),
                    "dns_name": _txt(s.get("computer_dns_name"), 253), "ips": ips[:8],
                    "os": _txt(s.get("os_environment_display_string"), 160), "os_type": _txt(s.get("os_type"), 20),
                    "status": _txt(s.get("status"), 30), "last_checkin": _ts(s.get("last_checkin_time")),
                    "uninstalled": bool(s.get("uninstalled"))})
    return [s for s in out if s["hostname"] and not s["uninstalled"]]


def test(server, token=None):
    """Sign in and read the sensors. Returns {"message", "sensors", "version"}."""
    doc = _get(server, "/api/v1/sensor", token)
    sensors = parse_sensors(doc)
    version = None
    try:
        info = _get(server, "/api/info", token)
        version = _txt(info.get("version"), 40) if isinstance(info, dict) else None
    except CbError:
        pass
    # Where each program ran comes from the process search: without it, Carbon Black is no evidence
    try:
        _get(server, "/api/v1/process?" + urllib.parse.urlencode({"q": "last_update:-60m", "rows": 1, "cb.urlver": 1}), token)
        runs = True
    except CbError:
        runs = False
    return {"message": f"Signed in. Carbon Black lists {len(sensors)} active sensor(s)"
                       + (f" (server {version})" if version else "") + "."
                       + ("" if runs else " This user may not search processes: Carbon Black can show machines but not where "
                                           "programs ran, so it adds no evidence. Give it Viewer rights on the sensor groups."),
            "sensors": len(sensors), "version": version, "process_search": runs, "sample": [s["hostname"] for s in sensors[:5]]}


# ---------------------------------------------------------------------------
# Binaries: the CVEs' products, as Carbon Black saw them run
# ---------------------------------------------------------------------------

def _term(text):
    from . import cve_match
    w = cve_match.cpe_words(text).replace(".", " ").strip()
    return re.sub(r"\s+", " ", re.sub(r"[^A-Za-z0-9 +#-]", " ", w)).strip()


def search_terms(products):
    """[(vendor, product)] of the CVEs being checked -> the product words searched for (checked text only)."""
    out = []
    for vendor, product in products:
        w = _term(product)
        if len(w) >= 3 and TERM_RE.match(w) and w.lower() not in ("windows", "server", "office") and w not in out:
            out.append(w)
    return out[:150]


def maker_terms(products):
    """The makers searched for too (Oracle's JRE is 'Java(TM) Platform SE' by Oracle): not Microsoft,
    whose files are too many and whose products are checked by Microsoft's own update data."""
    out = []
    for vendor, _ in products:
        w = _term(vendor)
        if len(w) >= 3 and TERM_RE.match(w) and w.lower() != "microsoft" and w not in out:
            out.append(w)
    return out[:60]


def search(server, term, field="product_name"):
    """Windows program files whose product name (or maker) holds the term, newest first, in pages."""
    if field not in ("product_name", "company_name"):
        raise CbError("Not a searchable field.")
    q = field + ':"' + term + '" os_type:windows'
    out = []
    for start in range(0, MAX_PER_TERM, PER_PAGE):
        path = "/api/v1/binary?" + urllib.parse.urlencode({"q": q, "rows": PER_PAGE, "start": start,
                                                           "sort": "server_added_timestamp desc", "cb.urlver": 1})
        doc = _get(server, path)
        page = ((doc or {}).get("results") or []) if isinstance(doc, dict) else []
        for b in page:
            if not isinstance(b, dict) or not MD5_RE.match(str(b.get("md5") or "").upper()):
                continue
            out.append({"md5": str(b["md5"]).upper(), "product_name": _txt(b.get("product_name"), 200),
                        "company_name": _txt(b.get("company_name"), 200),
                        "product_version": _txt(b.get("product_version"), 60), "file_version": _txt(b.get("file_version"), 60),
                        "filename": _txt((b.get("observed_filename") or [None])[0] if isinstance(b.get("observed_filename"), list)
                                         else b.get("observed_filename"), 260),
                        "host_count": b.get("host_count") if isinstance(b.get("host_count"), int) else None,
                        "last_seen": _ts(b.get("last_seen")) or _ts(b.get("server_added_timestamp"))})
        total = doc.get("total_results") if isinstance(doc, dict) else None
        if len(page) < PER_PAGE or (isinstance(total, int) and start + PER_PAGE >= total):
            break
    return [b for b in out if b["product_name"]]


def recent_runs(server, md5, days=SEEN_DAYS):
    """{computer name: when that file last ran there} over the last `days` days (process search)."""
    if not MD5_RE.match(md5 or ""):
        raise CbError("Not an MD5.")
    q = f"process_md5:{md5.lower()} last_update:-{int(days) * 1440}m"
    out = {}
    for start in range(0, MAX_RUNS, 500):
        doc = _get(server, "/api/v1/process?" + urllib.parse.urlencode(
            {"q": q, "rows": 500, "start": start, "sort": "last_update desc", "cb.urlver": 1}))
        page = ((doc or {}).get("results") or []) if isinstance(doc, dict) else []
        for p in page:
            if not isinstance(p, dict):
                continue
            name, at = _txt(p.get("hostname"), 120), _ts(p.get("last_update"))
            if name and at and (name.lower() not in out or at > out[name.lower()][1]):
                out[name.lower()] = (name, at)
        if len(page) < 500:
            break
    return {n: at for n, at in out.values()}


# ---------------------------------------------------------------------------
# The worker: sensors every hour, binaries for the products in the window
# ---------------------------------------------------------------------------

def servers(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM cb_servers WHERE enabled ORDER BY name").fetchall()]


def due(conn):
    return [dict(r) for r in conn.execute(
        """SELECT * FROM cb_servers WHERE enabled AND (sync_requested_at IS NOT NULL OR last_sync_at IS NULL
                  OR last_sync_at < now() - make_interval(mins => %s))""", (SYNC_MINUTES,)).fetchall()]


def window_products(conn, days):
    """The (vendor, product) of the Windows applications NVD names in the CVEs being checked."""
    from . import exposure
    out = []
    for r in conn.execute("""SELECT cpes FROM cve_feed_items WHERE source = 'nist' AND cpes IS NOT NULL
                               AND published >= now() - make_interval(days => %s::int)
                               AND (exploited OR coalesce(cvss, 0) >= 7
                                    OR lower(coalesce(severity, '')) IN ('critical', 'high', 'important'))""",
                          (int(days),)).fetchall():
        cpes = r["cpes"] if isinstance(r["cpes"], list) else json.loads(r["cpes"] or "[]")
        for p in exposure.products_from_cpes([c for c in cpes if isinstance(c, dict)]):
            if p["kind"] == "Application" and (p["vendor"], p["product"]) not in out:
                out.append((p["vendor"], p["product"]))
    return out


def _stopped():
    return CbError("stopped before finishing (the worker is restarting): read again at the next run")


def sync_one(conn, s, days=14, stop=lambda: False):
    """Sensors, the program files of the window's products, and where and when each last ran.
    Everything is read from Carbon Black first (no database transaction is held open meanwhile),
    then written at once. Returns (message, changed: whether what it saw changed)."""
    import hashlib
    products = window_products(conn, days)
    known = {r["md5"]: dict(r) for r in conn.execute(
        "SELECT md5, host_times, hosts_at FROM cb_binaries WHERE server_id = %s", (s["id"],)).fetchall()}
    conn.commit()
    sensors = parse_sensors(_get(s, "/api/v1/sensor"))
    seen = {}
    for field, terms in (("product_name", search_terms(products)), ("company_name", maker_terms(products))):
        for t in terms:
            if stop():
                raise _stopped()
            for b in search(s, t, field):
                seen.setdefault(b["md5"], b)
    now = datetime.now(timezone.utc)
    week = now - timedelta(days=SEEN_DAYS)
    runs, at, lookups, left = {}, {}, 0, 0
    for b in sorted(seen.values(), key=lambda b: b["last_seen"] or datetime.min.replace(tzinfo=timezone.utc), reverse=True):
        if b["last_seen"] and b["last_seen"] < week:
            runs[b["md5"]], at[b["md5"]] = {}, now          # not run anywhere this week
            continue
        k = known.get(b["md5"])
        if k and k.get("hosts_at") and k["hosts_at"] > now - timedelta(minutes=50) and k.get("host_times") is not None:
            runs[b["md5"]], at[b["md5"]] = k["host_times"], k["hosts_at"]
            continue
        if stop():
            raise _stopped()
        if lookups >= MAX_RUN_LOOKUPS:
            left += 1                         # looked up at the next run; until then not evidence
            continue
        runs[b["md5"]] = {n: t.isoformat() for n, t in recent_runs(s, b["md5"]).items()}
        at[b["md5"]] = now
        lookups += 1
    digest = lambda d: hashlib.sha256(json.dumps(sorted((m, json.dumps(v, sort_keys=True, default=str)) for m, v in d.items()),
                                                 default=str).encode()).hexdigest()
    changed = digest({m: k.get("host_times") for m, k in known.items()}) != digest({m: runs.get(m) for m in seen})
    with conn.transaction():
        conn.execute("DELETE FROM cb_sensors WHERE server_id = %s", (s["id"],))
        for x in sensors:
            conn.execute("""INSERT INTO cb_sensors (server_id, sensor_id, hostname, dns_name, ips, os, os_type, status, last_checkin)
                            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT (server_id, sensor_id) DO NOTHING""",
                         (s["id"], x["sensor_id"], x["hostname"], x["dns_name"], x["ips"], x["os"], x["os_type"], x["status"],
                          x["last_checkin"]))
        for md5, b in seen.items():
            ht = runs.get(md5)
            conn.execute("""INSERT INTO cb_binaries (server_id, md5, product_name, company_name, product_version, file_version,
                                                     filename, host_count, last_seen, host_times, hosts_at)
                            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                            ON CONFLICT (server_id, md5) DO UPDATE SET product_name=EXCLUDED.product_name,
                              company_name=EXCLUDED.company_name, product_version=EXCLUDED.product_version,
                              file_version=EXCLUDED.file_version, filename=EXCLUDED.filename, host_count=EXCLUDED.host_count,
                              last_seen=EXCLUDED.last_seen, host_times=EXCLUDED.host_times, hosts_at=EXCLUDED.hosts_at""",
                         (s["id"], md5, b["product_name"], b["company_name"], b["product_version"], b["file_version"],
                          b["filename"], b["host_count"], b["last_seen"], json.dumps(ht) if ht is not None else None, at.get(md5)))
        conn.execute("DELETE FROM cb_binaries WHERE server_id = %s AND NOT (md5 = ANY(%s))", (s["id"], list(seen)))
    msg = (f"{len(sensors)} sensors; {len(seen)} program files of the CVEs' products; where each ran this week: "
           f"{lookups} looked up" + (f", {left} at the next run (not used until then)" if left else ""))
    return msg, changed


def programs(conn):
    """For the CVE check: one row per machine and file version that RAN there this week:
    {hostname (the machine's DNS name when Carbon Black has it), name, publisher, version, seen_at}.
    Only machines with an active sensor."""
    try:
        with conn.transaction():
            rows = conn.execute(
                """SELECT b.product_name, b.company_name, coalesce(b.product_version, b.file_version) AS version,
                          r.value AS ran_at,
                          (SELECT coalesce(c.dns_name, c.hostname) FROM cb_sensors c
                            WHERE c.server_id = b.server_id AND lower(c.hostname) = lower(r.key)
                            ORDER BY c.last_checkin DESC NULLS LAST LIMIT 1) AS machine
                     FROM cb_binaries b JOIN cb_servers s ON s.id = b.server_id AND s.enabled
                     CROSS JOIN LATERAL jsonb_each_text(b.host_times) r
                    WHERE b.host_times IS NOT NULL""").fetchall()
    except Exception as e:  # noqa: BLE001 - schema 057 not applied yet: no Carbon Black data
        log.debug("cb programs: %s", e)
        return []
    week = datetime.now(timezone.utc) - timedelta(days=SEEN_DAYS)
    out = []
    for r in rows:
        try:
            at = datetime.fromisoformat(str(r["ran_at"]))
        except ValueError:
            continue
        if not r["machine"] or at.tzinfo is None or at < week:
            continue                          # sensor gone, or not run this week
        out.append({"hostname": r["machine"], "name": r["product_name"], "publisher": r["company_name"] or "",
                    "version": r["version"] or "", "seen_at": at, "stale": False})
    return out
