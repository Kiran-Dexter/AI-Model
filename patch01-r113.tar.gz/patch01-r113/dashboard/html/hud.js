/* PATCH-01 console: the HUD progress ring (r112).
 *
 * Real progress only. Every lit part stands for something that happened:
 *   outer ticks   the share of the work done (60 ticks, each 1/60 of it)
 *   segment ring  one segment per step or per server, in its state's colour:
 *                 done (green), failed (red), working now (the theme's neon), waiting (dim)
 *   centre        the percentage and what is counted ("41 / 52 servers")
 * Nothing spins for show: while work runs, only the tick at the front glows, and it stops
 * when nothing is happening. With no figure to show (waiting for an agent, Nessus building a
 * report) the centre says so and how long it has waited, never a made-up percentage.
 * A value that changes since the last drawing slides from the old figure to the new one.
 *
 * Colours come from the theme: --hud (the neon of the theme), --patched, --needs-patch,
 * --rule. Nothing is inserted as HTML: text goes in as text nodes.
 */

const HUD_NS = "http://www.w3.org/2000/svg";
const HUD_LAST = new Map();            // key -> the percentage drawn last time (for the slide)
const HUD_STATE_ORDER = ["done", "failed", "run", "wait", "skip"];

function hudEl(tag, attrs, ...kids) {
  const el = document.createElementNS(HUD_NS, tag);
  Object.entries(attrs || {}).forEach(([k, v]) => { if (v !== null && v !== undefined) el.setAttribute(k, String(v)); });
  kids.flat().forEach(k => { if (k) el.append(k instanceof Node ? k : document.createTextNode(String(k))); });
  return el;
}

function hudArc(cx, cy, r, a0, a1) {
  // a0, a1 in degrees, 0 at the top, clockwise
  const p = a => [cx + r * Math.sin(a * Math.PI / 180), cy - r * Math.cos(a * Math.PI / 180)];
  const [x0, y0] = p(a0), [x1, y1] = p(a1);
  return `M${x0.toFixed(2)} ${y0.toFixed(2)} A${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
}

/* The states of many servers as at most `max` segments, in proportion and in a fixed order */
function hudBucket(segs, max) {
  if (segs.length <= max) return segs;
  const by = {};
  segs.forEach(s => { by[s.k] = (by[s.k] || 0) + 1; });
  const out = [];
  let used = 0;
  HUD_STATE_ORDER.forEach((k, i) => {
    if (!by[k]) return;
    const n = i === HUD_STATE_ORDER.length - 1 ? max - used : Math.max(1, Math.round(by[k] * max / segs.length));
    for (let j = 0; j < n && used < max; j++, used++) out.push({ k, title: by[k] + " " + k });
  });
  return out;
}

/* opts:
 *   pct     0..100, or null when there is no figure (then `idle` says why)
 *   title   what runs ("FULL SYNC", "DEPLOYING", "SCANNING")
 *   sub     what is counted ("41 / 52 servers")
 *   idle    the centre text when pct is null ("WAITING")
 *   segs    [{k: done|failed|run|wait|skip, title}] one per step or server
 *   live    true while work runs (the front tick glows)
 *   size    "sm" (table rows) or "lg"
 *   key     a stable id, so a new value slides from the last one drawn
 *   label   the accessible name */
function hudRing(o) {
  const size = o.size === "sm" ? "sm" : "lg";
  const pct = o.pct === null || o.pct === undefined || isNaN(o.pct) ? null : Math.max(0, Math.min(100, Number(o.pct)));
  const failed = (o.segs || []).some(s => s.k === "failed");
  const wrap = document.createElement("div");
  wrap.className = "hud hud-" + size + (o.live ? " hud-live" : "") + (failed ? " hud-has-failed" : "") + (pct === null ? " hud-idle" : "");
  wrap.setAttribute("role", "progressbar");
  wrap.setAttribute("aria-label", o.label || o.title || "Progress");
  wrap.setAttribute("aria-valuemin", "0");
  wrap.setAttribute("aria-valuemax", "100");
  if (pct !== null) wrap.setAttribute("aria-valuenow", String(Math.round(pct)));
  wrap.setAttribute("aria-valuetext", pct === null ? (o.idle || "waiting") + (o.sub ? ", " + o.sub : "")
    : Math.round(pct) + "%" + (o.sub ? ", " + o.sub : ""));
  wrap.title = [o.title, pct === null ? o.idle : Math.round(pct) + "%", o.sub].filter(Boolean).join(" · ");

  const C = 60, svgEl = hudEl("svg", { viewBox: "0 0 120 120", class: "hud-svg", "aria-hidden": "true", focusable: "false" });
  // Frame: two thin rings, notches top and bottom, chevrons
  svgEl.append(
    hudEl("circle", { cx: C, cy: C, r: 57, class: "hud-frame" }),
    hudEl("circle", { cx: C, cy: C, r: 34, class: "hud-frame hud-frame-in" }),
    hudEl("path", { d: hudArc(C, C, 57, -18, 18), class: "hud-notch" }),
    hudEl("path", { d: hudArc(C, C, 57, 162, 198), class: "hud-notch" }),
    hudEl("path", { d: "M56 6.5 L60 2.5 L64 6.5", class: "hud-chev" }),
    hudEl("path", { d: "M56 113.5 L60 117.5 L64 113.5", class: "hud-chev" }));

  // Outer ticks: the share done
  const ticks = hudEl("g", { class: "hud-ticks" });
  const N = 60, lit = pct === null ? 0 : Math.round(pct * N / 100);
  for (let i = 0; i < N; i++) {
    const a = i * 360 / N, inner = i % 5 === 0 ? 47 : 49;
    const s = Math.sin(a * Math.PI / 180), c = Math.cos(a * Math.PI / 180);
    ticks.append(hudEl("line", { x1: (C + inner * s).toFixed(2), y1: (C - inner * c).toFixed(2), x2: (C + 53 * s).toFixed(2), y2: (C - 53 * c).toFixed(2),
      class: "hud-tick" + (i < lit ? " on" : "") + (o.live && i === lit - 1 ? " head" : "") }));
  }
  svgEl.append(ticks);

  // Smooth arc under the ticks: slides from the last value drawn
  const R = 43, LEN = 2 * Math.PI * R;
  const prog = hudEl("circle", { cx: C, cy: C, r: R, class: "hud-arc", transform: `rotate(-90 ${C} ${C})`,
    "stroke-dasharray": LEN.toFixed(1), "stroke-dashoffset": LEN.toFixed(1) });
  svgEl.append(hudEl("circle", { cx: C, cy: C, r: R, class: "hud-arc-bg" }), prog);
  const target = pct === null ? 0 : pct;
  const from = o.key && HUD_LAST.has(o.key) ? HUD_LAST.get(o.key) : target;
  prog.setAttribute("stroke-dashoffset", (LEN * (1 - from / 100)).toFixed(1));
  if (from !== target) requestAnimationFrame(() => requestAnimationFrame(() =>
    prog.setAttribute("stroke-dashoffset", (LEN * (1 - target / 100)).toFixed(1))));
  else prog.setAttribute("stroke-dashoffset", (LEN * (1 - target / 100)).toFixed(1));
  if (o.key) HUD_LAST.set(o.key, target);

  // Segment ring: one per step or server, in its state's colour
  const segs = hudBucket(o.segs || [], 72);
  if (segs.length) {
    const g = hudEl("g", { class: "hud-segs" }), gap = segs.length > 1 ? Math.min(4, 120 / segs.length) : 0;
    const step = 360 / segs.length;
    segs.forEach((s, i) => {
      const a0 = i * step + gap / 2, a1 = (i + 1) * step - gap / 2;
      const p = hudEl("path", { d: segs.length === 1 ? hudArc(C, C, 38, 0.01, 359.99) : hudArc(C, C, 38, a0, Math.max(a0 + 0.5, a1)),
        class: "hud-seg hud-" + (s.k || "wait") });
      if (s.title) p.append(hudEl("title", null, s.title));
      g.append(p);
    });
    svgEl.append(g);
  }

  // Centre: the figure and what it counts
  const big = pct === null ? (o.idle || "WAITING") : Math.round(pct) + "%";
  svgEl.append(
    hudEl("text", { x: C, y: size === "sm" ? 67 : 60, class: "hud-pct" + (pct === null ? " hud-pct-idle" : "") }, big),
    size === "sm" ? null : hudEl("text", { x: C, y: 73, class: "hud-title" }, (o.title || "").toUpperCase().slice(0, 16)));
  wrap.append(svgEl);
  if (size === "lg" && o.sub) {
    const sub = document.createElement("div");
    sub.className = "hud-sub";
    sub.textContent = o.sub;
    wrap.append(sub);
  }
  return wrap;
}

/* ---- What each kind of work counts ---------------------------------------------------- */

// How far one server of a job is, from its state (the steps each server goes through)
const HUD_TARGET = { queued: 0, precheck: .1, snapshot: .2, waiting_credential: .2, install: .45, update: .45, vm_action: .5,
  reboot_wait: .6, reboot: .65, wait_boot: .7, verify: .8, postcheck: .85, inventory: .92, snapshot_cleanup: .96,
  done: 1, done_with_warnings: 1, failed: 1, skipped: 1, cancelled: 1 };
function hudTargetKind(st) {
  if (st === "done" || st === "done_with_warnings") return "done";
  if (st === "failed") return "failed";
  if (st === "skipped" || st === "cancelled") return "skip";
  if (st === "queued") return "wait";
  return "run";
}

/* A job's ring from its servers' states: [{state, label}] */
function hudJob(targets, opts = {}) {
  const t = targets || [];
  const pct = t.length ? 100 * t.reduce((a, x) => a + (HUD_TARGET[x.state] ?? .5), 0) / t.length : null;
  const fin = t.filter(x => ["done", "done_with_warnings", "failed", "skipped", "cancelled"].includes(x.state)).length;
  const bad = t.filter(x => x.state === "failed").length;
  const live = t.some(x => hudTargetKind(x.state) === "run");
  return hudRing(Object.assign({ pct, live, title: opts.title || (live ? "RUNNING" : fin === t.length ? "FINISHED" : "QUEUED"),
    sub: fin + " / " + t.length + " servers finished" + (bad ? ", " + bad + " failed" : ""),
    segs: t.map(x => ({ k: hudTargetKind(x.state), title: (x.label || "") + ": " + String(x.state || "").replace(/_/g, " ") })),
    label: "Job progress" }, opts));
}

/* A job's ring from counts only (the jobs list): targets, done, failed, in_progress */
function hudJobCounts(c, opts = {}) {
  const n = Number(c.targets || 0), done = Number(c.done || 0), failed = Number(c.failed || 0), run = Number(c.in_progress || 0);
  if (!n) return null;
  const waiting = Math.max(0, n - done - failed - run);
  const segs = [].concat(Array(done).fill({ k: "done" }), Array(failed).fill({ k: "failed" }), Array(run).fill({ k: "run" }),
    Array(waiting).fill({ k: "wait" }));
  return hudRing(Object.assign({ pct: 100 * (done + failed + run * .5) / n, live: run > 0, segs, size: "sm",
    sub: done + failed + " / " + n + " servers", label: (done + failed) + " of " + n + " servers finished" }, opts));
}
