PATCH-01 agent 1.6.0 for Windows: installer
===========================================

1. Put this folder where the servers can read it (a share, e.g.
   \\fileserver\PATCH01-Agent-Installer), or copy it to the server.
   Add your CA chain .pem if you use one (optional when you paste the pin).
   Keep only one patch01-agent-windows-*.zip in the folder.

2. On PATCH-01, get the pin and tokens:
       ./scripts/phase10-windows.sh --pin
       ./scripts/phase10-windows.sh --tokens 1 <group>     (one per new server)

3. On each server: right-click Install-PatchAgent.bat, "Run as administrator".
   It asks, in this order:
       Certificate pin   paste it (Enter reuses the one remembered here)
       PATCH-01 address  https://<name> (Enter reuses the one remembered)
       Enrolment token   new servers only, hidden while you paste it
       Go ahead? [Y/n]   Enter
   and ends with SUCCESS or FAILED and the reason.

Started from a mapped drive letter? An administrator window does not see
mapped drives: use the \\server\share path, or copy the folder locally.

Results of every server: deploy-log.csv in this folder (when writable), and
C:\ProgramData\PatchAgent-Deploy on each server. The token is never stored;
deploy-settings.json here keeps only the pin and the address (not secrets).
The server's PowerShell execution policy is not changed: only the installer's
own window runs with RemoteSigned.
