"""Impacted CVEs: which new CVEs from the feeds touch our own machines.

For every critical, high or exploited ("0-day") CVE the feeds collected in
the dashboard's window, the worker looks for the affected products in the
software and hardware inventory:

  confirmed       the CVE engine's package check says a server is affected
  in_range        an installed version lies inside NVD's affected range
                  (Windows programs, ESXi, vCenter)
  release_match   the release matches but the exact build cannot be compared
  present         the product is installed or the OS matches; no version data
                  can decide (Windows editions, Red Hat components)
  not_tracked     a product PATCH-01 does not inventory (network gear)

and gives one verdict per CVE: affected, potentially affected, not found or
not tracked. Products come from NVD's CPE list (NIST items), Microsoft's
product names (MSRC items) and Red Hat's component names.

AI-01 then writes a short brief for the impacted ones, most serious first,
from the same facts the console shows. It never decides the verdict.

The analysis repeats when the inventory changes, and at least daily.
"""

import hashlib
import json
import time
import logging
import re
from functools import cmp_to_key

log = logging.getLogger("patchapi.cve_impact")

BATCH = 150
RULES = "proof-4"     # r137: Nessus out of the analysis; CVE.org; appliances of any maker           # changing it re-analyses every CVE with the current rules (r116: end of support / life)
AI_PER_PASS = 2
REANALYSE_HOURS = 4          # every CVE is checked against the inventory again at least this often
WEAK = ("release_match", "present")

MS_NOISE = re.compile(r"\b(microsoft|for x64-based systems|for x86-based systems|for 32-bit systems|"
                      r"for arm64-based systems|\(server core installation\)|version \w+|\d{2}h\d|"
                      r"64-bit editions?|32-bit editions?|service pack \d|sp\d)\b", re.I)
STOP = {"the", "and", "for", "of", "server", "edition", "editions", "systems", "version", "based"}


# ---------------------------------------------------------------------------
# Inventory fingerprint: when it changes, everything is analysed again
# ---------------------------------------------------------------------------

def inventory_changed(conn):
    """Called when a machine's installed software really changed."""
    try:
        with conn.transaction():
            conn.execute("UPDATE cve_feed_settings SET inventory_changed_at = now() WHERE id = 1")
    except Exception:  # noqa: BLE001 - schema 025 not applied yet; the daily re-analysis still runs
        pass


def inventory_mark(conn):
    """Changes when machines, their OS or their installed versions change, not
    on every check-in (which would make every pass start again from the top)."""
    # Versions, not only counts: a package or program updated in place (curl -29 to -30,
    # Chrome 129 to 130) and an OS upgraded (Windows 10 to 11) change the mark too
    r = conn.execute(
        """SELECT (SELECT md5(coalesce(string_agg(hostname || '|' || coalesce(os_id, '') || '|' || coalesce(os_version, '')
                                                 || '|' || coalesce(os_edition, ''), ',' ORDER BY id), ''))
                     FROM hosts WHERE status <> 'decommissioned') AS h,
                  (SELECT count(*) FROM windows_software) AS w,
                  (SELECT count(*) FROM host_packages) AS p,
                  (SELECT count(*) FROM host_applicability WHERE state IN ('affected', 'fixed_pending_reboot')) AS a,
                  (SELECT count(*) || ':' || string_agg(DISTINCT coalesce(esxi_build, ''), ',') FROM esxi_hosts) AS e,
                  (SELECT md5(coalesce(string_agg(name || '|' || coalesce(os, ''), ',' ORDER BY name), '')) FROM wsus_computers) AS u,
                  (SELECT md5(coalesce(string_agg(name || '|' || coalesce(guest_os, '') || '|' || coalesce(guest_hostname, ''),
                                                  ',' ORDER BY name), '')) FROM vm_inventory) AS v""").fetchone()
    r = dict(r)
    try:
        with conn.transaction():
            c = conn.execute("SELECT inventory_changed_at FROM cve_feed_settings WHERE id = 1").fetchone()
        r["changed"] = c and c["inventory_changed_at"]
    except Exception:  # noqa: BLE001 - schema 025 not applied yet
        pass
    return hashlib.sha256(json.dumps([RULES, r], default=str, sort_keys=True).encode()).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Matching (each returns match dicts like exposure.find_in_inventory)
# ---------------------------------------------------------------------------

MAX_PRODUCTS = 30


class Inventory:
    """The parts of the inventory every CVE is compared with, read once per pass."""

    def __init__(self, conn):
        self.conn = conn
        self._win_sw = self._win_os = self._esxi = self._assets = None
        self._progs = self._decided = self._win_majors = None

    def win_software(self):
        if self._win_sw is None:
            self._win_sw = [dict(r) for r in self.conn.execute(
                """SELECT h.hostname, ws.name, ws.version, ws.publisher,
                          (h.status = 'stale' OR h.last_inventory IS NULL
                           OR h.last_inventory < now() - make_interval(hours => %s::int)) AS stale
                     FROM windows_software ws JOIN hosts h ON h.id = ws.host_id AND h.status <> 'decommissioned'""",
                (_stale_h(),)).fetchall()]
        return self._win_sw

    def programs(self):
        """The programs, each once, and the decisions on which product they are (r110)."""
        from . import cve_match
        if self._progs is None:
            self._progs = cve_match.Programs(self.win_software())
            self._decided = cve_match.decisions(self.conn)
        return self._progs, self._decided

    def cb_programs(self):
        """Programs Carbon Black saw running (r111), each (name, maker) once with where and which version."""
        from . import cbedr, cve_match
        if getattr(self, "_cb", None) is None:
            rows = cbedr.programs(self.conn)
            self._cb = cve_match.Programs(rows)
            self._cb_seen = {}
            for x in rows:
                k = (short(x["hostname"]), x["name"], x["publisher"], x["version"])
                self._cb_seen[k] = max(filter(None, [self._cb_seen.get(k), x.get("seen_at")]), default=None)
        return self._cb, self._cb_seen

    def host_times(self):
        """{short name: when PATCH-01 last had its inventory}. r137: Nessus is not part of the CVE analysis
        (it keeps its own page), so its scan times are not read here."""
        if getattr(self, "_times", None) is None:
            inv, twice = {}, set()
            for r in self.conn.execute("SELECT hostname, last_inventory FROM hosts WHERE status <> 'decommissioned'").fetchall():
                k = short(r["hostname"])
                if k in inv:
                    twice.add(k)                  # two machines, one short name: never cross-checked
                inv[k] = r["last_inventory"]
            for k in twice:
                inv[k] = None
            self._times = inv
        return self._times

    def win_majors(self):
        """The Windows Server versions we run (2016, 2019, ...), from the agents."""
        if self._win_majors is None:
            self._win_majors = {r["os_major"] for r in self.conn.execute(
                """SELECT DISTINCT os_major FROM hosts WHERE os_id = 'windows' AND status <> 'decommissioned'
                     AND os_major IS NOT NULL""").fetchall()}
        return self._win_majors

    def win_os(self):
        if self._win_os is None:
            self._win_os = [dict(r) for r in self.conn.execute(
                """SELECT hostname AS name, coalesce(os_edition, 'Windows') AS os, 'Windows server (agent)' AS where_
                     FROM hosts WHERE os_id = 'windows' AND status <> 'decommissioned'
                   UNION ALL SELECT name, os, 'WSUS computer' FROM wsus_computers
                   UNION ALL SELECT name, guest_os, 'VM guest OS' FROM vm_inventory
                    WHERE guest_os ILIKE '%windows%'""").fetchall()]
        return self._win_os

    def lifecycle(self):
        """End of support / end of life rules (Admin > Software rules, endoflife.date), by platform (r116)."""
        if getattr(self, "_lc", None) is None:
            from . import sw_lifecycle
            rules = sw_lifecycle.rules(self.conn)
            self._lc = {"windows": [r for r in rules if r["platform"] == "windows"],
                        "linux": [r for r in rules if r["platform"] == "linux"]}
        return self._lc

    def assets(self):
        """Every machine we know, from every source, by short name:
        {name, fqdn, ips, os, family, distro, major, sources}. The agent's own
        report of its OS wins over WSUS, and WSUS over the vCenter guest."""
        if self._assets is None:
            self._assets = build_assets(self.conn)
        return self._assets

    def esxi(self):
        if self._esxi is None:
            self._esxi = [dict(r) for r in self.conn.execute(
                "SELECT name, vcenter, vendor, model FROM esxi_hosts").fetchall()]
        return self._esxi


def _stale_h():
    from .assess import _stale_hours
    return _stale_hours()


def _nums(v):
    return [int(x) for x in re.findall(r"\d+", str(v or ""))[:6]]


def comparable(version, ranges):
    """Whether an installed version can be judged against NVD's ranges at all (r110). A version
    written in another scheme (Windows lists Java 8 Update 401 as 8.0.4010.10; NVD has 1.8.0
    update 401) or missing would otherwise be called outside the range: fixed, when it is not."""
    vn = _nums(version)
    if not vn:
        return False
    bounds = []
    for r in ranges or []:
        if str(r.get("update") or "*").lower() not in ("*", "-", ""):
            return False                  # an update qualifier: not expressed in a Windows version
        bounds += [r.get(k) for k in ("start_incl", "start_excl", "end_incl", "end_excl") if r.get(k)]
        if r.get("version") not in (None, "", "*", "-"):
            bounds.append(r["version"])
    bn = [b for b in (_nums(x) for x in bounds) if b]
    if not bn:
        return True                       # every version listed: judged 'present', never fixed
    if any(b[0] == vn[0] for b in bn):
        return True                       # the same major line
    lo, hi = min(b[0] for b in bn), max(b[0] for b in bn)
    if lo < vn[0] < hi:
        return True
    return any(len(b) == len(vn) for b in bn)          # another major line written the same way (Chrome 131 vs 130.0.x)


def _words(text):
    return [w for w in re.findall(r"[a-z0-9][a-z0-9.+#-]*", (text or "").lower()) if w not in STOP]


def match_windows_programs(inv, prod):
    """Windows programs proven to be this CPE product (cve_match), each version compared with
    NVD's affected ranges. Returns (found, set_aside, pairs):
      found      in_range: proven product, version inside an affected range
      set_aside  the machines holding the product that are not a finding, each with why: a
                 version outside every range (fixed), not comparable (unproven), or a program
                 that may be the product and is not confirmed (unproven: never clean)
      pairs      the programs an admin is asked to confirm (with AI-01's suggestion)"""
    from . import cve_match, exposure
    vendor, product = prod.get("vendor") or "", prod.get("product") or ""
    progs, decided = inv.programs()
    proven, confirm, _ = progs.find(vendor, product, decided)
    label = cve_match.cpe_words(product)
    found, aside, pairs = [], [], []
    for p in proven:
        why_id = "; ".join(p["reasons"][:2])
        for host, ver, stale in p["on"]:
            line = f"{p['name']} {ver}".strip()
            if stale:
                aside.append({"name": host, "product": label, "unproven": True, "silent": True,
                              "reason": f"{line}: the server has not sent its inventory for over {_stale_h()} hours"})
                continue
            if prod.get("cna"):
                # r137: the vendor's own versions (its CVE record), compared with the program's version
                cert, why, fx = cna_judge(ver, prod, program=True)
                src = f" (the vendor's CVE record; {why_id})"
                if cert == "in_range":
                    found.append({"product": label, "kind": "Application", "where": "Windows server", "name": host,
                                  "version": line, "certainty": cert, "detail": why + src, "fixed": fx,
                                  "program": p["name"], "pver": ver, "source": "cve.org"})
                elif cert == "outside":
                    aside.append({"name": host, "product": label, "fixed": True, "own": True, "reason": f"{line}: {why}"})
                else:
                    aside.append({"name": host, "product": label, "unproven": True, "reason": f"{line}: {why}"})
                continue
            if not comparable(ver, prod.get("ranges")):
                aside.append({"name": host, "product": label, "unproven": True,
                              "reason": f"{line}: its version cannot be compared with NVD's affected versions "
                                        f"(no version, or written another way)"})
                continue
            cert, why = ("present", "installed; no affected version range to compare")
            if prod.get("ranges"):
                cert, why = exposure.match_versioned(ver, prod["ranges"])
            if cert == "in_range":
                found.append({"product": label, "kind": "Application", "where": "Windows server", "name": host,
                              "version": line, "certainty": cert, "detail": why + " (" + why_id + ")",
                              "fixed": fixed_in(ver, prod["ranges"]), "program": p["name"], "pver": ver})
            elif cert == "outside":
                aside.append({"name": host, "product": label, "fixed": True, "own": True,
                              "reason": f"{line}: outside every affected range"})
            else:
                aside.append({"name": host, "product": label, "unproven": True,
                              "reason": f"{line}: {why}"})
    for p in confirm:
        if len(pairs) < cve_match.MAX_PAIRS:
            pairs.append(cve_match.pair_entry(vendor, product, p))
        tip = (" AI-01 thinks it is" + ("" if p.get("ai") == "same" else " not") + " this product.") if p.get("ai") else ""
        for host, ver, _ in p["on"]:            # every server holding it, whatever the list's length
            aside.append({"name": host, "product": label, "unproven": True, "to_confirm": True,
                          "reason": f"'{p['name']}' ({p['publisher'] or 'publisher not stated'}) may be {label}: "
                                    f"confirm it under 'Programs to confirm'.{tip}"})
    return found, aside, pairs


def ms_app_installed(inv, ms_product):
    """Whether a Microsoft program named like this Microsoft product is installed anywhere
    ('.NET 8.0' -> 'Microsoft .NET Runtime - 8.0.10'). Only to say "no data yet" instead of "not found"."""
    from . import swmatch
    words = {w for w in swmatch.name_key(MS_NOISE.sub(" ", ms_product), "Microsoft") if not w.isdigit()}
    if not words:
        return False
    for r in inv.win_software():
        if "microsoft" in (r.get("publisher") or "").lower() and words & set(swmatch.name_key(r.get("name") or "", "Microsoft")):
            return True
    return False


def match_linux_unjudged(conn, cve_id, products, judged):
    """Linux machines holding a package of an NVD application that no vendor's data judges for
    them (r110): "cannot tell", never clean. NVD's versions are upstream ones; distributions
    backport fixes, so they are never compared with a distribution's build."""
    names = sorted({cve_match_name(p["product"]) for p in products} - {None})[:20]
    if not names:
        return []
    like = [n + "%" for n in names] + ["lib" + n + "%" for n in names]
    rows = conn.execute(
        """SELECT h.hostname, h.os_id, hp.name, hp.version, hp.release
             FROM host_packages hp JOIN hosts h ON h.id = hp.host_id AND h.status <> 'decommissioned'
            WHERE lower(hp.name) LIKE ANY(%s) ORDER BY h.hostname, hp.name LIMIT 3000""", (like,)).fetchall()
    out, seen = [], set()
    for r in rows:
        src = _source_of(r["name"], set(names))
        k = short(r["hostname"])
        if not src or k in judged or (k, src) in seen:
            continue
        seen.add((k, src))
        out.append({"name": r["hostname"], "product": src, "unproven": True,
                    "reason": f"{r['name']} {r['version'] or ''}-{r['release'] or ''} installed; no vendor data judges it "
                              f"for this machine's OS ({(r['os_id'] or 'unknown').upper()}), and NVD's upstream versions "
                              f"do not apply to distribution builds"})
    return out


def cve_match_name(product):
    """An NVD product name as a Linux package name ('http_server' -> None: too vague to be one)."""
    n = str(product or "").lower().replace("\\", "").replace("_", "-")
    return n if re.fullmatch(r"[a-z0-9][a-z0-9.+-]{2,40}", n) and n not in ("http-server", "server", "linux", "kernel-") else None


def fixed_in(version, ranges):
    """The first version outside the affected range this version is in ('130.0.6723.69'), or
    'newer than X' for a range that ends 'up to and including X'; None when NVD gives no end."""
    from . import exposure
    for rg in ranges or []:
        if exposure.in_range(version, rg) is True:
            if rg.get("end_excl"):
                return str(rg["end_excl"])[:40]
            if rg.get("end_incl"):
                return "newer than " + str(rg["end_incl"])[:40]
    return None


PRIORITY = {"P1": "Patch now", "P2": "This week", "P3": "Next patch cycle"}


def _vector(v):
    return dict(x.split(":", 1) for x in str(v or "").split("/") if ":" in x)


def make_plan(conn, cve, kept, lines, cross):
    """The priority of a CVE that affects us, why, and what to do on which machines: worked out from
    the facts, never by AI-01 (r111). None when nothing is affected."""
    if not lines:
        return {"crosscheck": cross}
    try:
        with conn.transaction():
            d = conn.execute("""SELECT cvss_score, cvss_vector, kev, kev_due, kev_ransomware, epss
                                  FROM cve_details WHERE cve_id = %s""", (cve["cve_id"],)).fetchone() or {}
    except Exception:  # noqa: BLE001 - the plan goes on with the feed's facts
        d = {}
    cvss = float(cve.get("cvss") or d.get("cvss_score") or 0)
    sev = str(cve.get("severity") or "").lower()
    if not cvss and sev in ("critical", "high", "important"):
        cvss = 9.0 if sev == "critical" else 7.5          # rated by the vendor, no score published yet
    kev = bool(cve.get("exploited") or d.get("kev"))
    # r137: CISA's assessment in the CVE's record (CVE.org), when the new sources are on
    expl, auto, impact = (str(cve.get(k) or "").lower() for k in ("ssvc_exploitation", "ssvc_automatable", "ssvc_impact"))
    active = expl == "active" and not kev
    kev = kev or expl == "active"
    vec = _vector(d.get("cvss_vector") or cve.get("cvss_vector"))
    epss = float(d.get("epss") or 0)
    net = vec.get("AV") == "N"
    nologin = vec.get("PR") == "N" or vec.get("Au") == "N"          # CVSS 3/4, or CVSS 2
    noclick = vec.get("UI") == "N" or ("Au" in vec and "UI" not in vec)
    why = []
    if active:
        why.append("being exploited in the wild (CISA's assessment in the CVE record)")
    elif kev:
        why.append("being exploited in the wild (CISA's list)" + (", used by ransomware" if str(d.get("kev_ransomware") or "").lower() == "known" else "")
                   + (f"; CISA's deadline {d['kev_due']}" if d.get("kev_due") else ""))
    if expl == "poc" and not kev:
        why.append("a proof of concept is public (CISA)")
    if auto == "yes" and impact == "total":
        why.append("CISA: an attack can be automated and gives total control")
    if cvss >= 9 and net and nologin and noclick:
        why.append(f"CVSS {cvss:g}: reachable over the network without a login or any user action")
    elif net and cvss >= 7:
        why.append(f"CVSS {cvss:g}, reachable over the network" + ("" if nologin else " (a login is needed)"))
    elif cvss:
        why.append((f"CVSS {cvss:g}" if cve.get("cvss") or d.get("cvss_score") else f"rated {sev} by the vendor (no score yet)")
                   + (", local access needed" if vec.get("AV") in ("L", "P") else "")
                   + (", how it is reached is not published yet" if not vec else ""))
    if epss >= 0.1:
        why.append(f"{round(epss * 100)}% chance of exploitation in the next 30 days (EPSS)")
    if kev or (cvss >= 9 and net and nologin and noclick):
        pr = "P1"
    elif cvss >= 7 or epss >= 0.1 or expl == "poc" or (auto == "yes" and impact == "total"):
        pr = "P2"                              # a local privilege escalation is often the second step of an attack
    else:
        pr = "P3"
    # r116: software past end of life gets no more fixes from its vendor: one step more urgent
    sup = support_summary(kept)
    if sup["eol"]:
        names = ", ".join(x["line"] for x in sup["lines"] if x["state"] == "eol")[:160]
        why.append(f"{sup['eol']} machine{'s' if sup['eol'] != 1 else ''} run{'' if sup['eol'] != 1 else 's'} {names}, past end of life: "
                   "the vendor no longer fixes it" + (" (a step more urgent)" if pr != "P1" else ""))
        pr = {"P3": "P2", "P2": "P1"}.get(pr, pr)
    if sup["eos"]:
        why.append(f"{sup['eos']} machine{'s' if sup['eos'] != 1 else ''} past end of mainstream support (security fixes still come)")
    if sup["eol_soon"]:
        why.append(f"{sup['eol_soon']} machine{'s' if sup['eol_soon'] != 1 else ''} reach end of life within 180 days")
    why.append(f"on {len(lines)} of our machines")
    groups = {}
    for m in kept:
        c, prod = m.get("certainty"), m.get("product") or "the product"
        sp = m.get("support") or {}
        if sp.get("state") == "eol" and c != "pending_reboot":
            # Never "update to X" alone for a line its vendor has stopped fixing
            if m.get("fixed"):
                key = (f"Update {prod} to {m['fixed']} or later, and plan the upgrade: {sp['line']} reached end of life on "
                       f"{sp['eol']} (later flaws will not be fixed" + (f"; {sp['paid']}" if sp.get("paid") else "") + ")", "")
            else:
                key = (f"Upgrade {prod} to a supported version: {sp['line']} reached end of life on {sp['eol']} and no fixed "
                       f"version is listed for it" + (f" ({sp['paid']})" if sp.get("paid") else ""), "")
            g = groups.setdefault(key[0], {"do": key[0], "machines": [], "eol": True})
            if m.get("name") and m["name"] not in g["machines"]:
                g["machines"].append(m["name"])
            continue
        if c == "pending_reboot":
            key = ("Restart to finish the fix (it is installed)", "")
        elif c == "no_fix":
            key = (f"No fix from the vendor yet for {prod}: use the vendor's mitigation, and isolate or limit access", "")
        elif m.get("advisory"):
            key = (f"Install {m['advisory']}" + (f" ({prod} {m['fixed']})" if m.get("fixed") else f" ({prod})"), m["advisory"])
        elif m.get("fixed"):
            key = (f"Update {prod} to {m['fixed']} or later", "")
        else:
            key = (f"Update {prod} to a version outside the affected range (the vendor's page has the fixed one)", "")
        g = groups.setdefault(key[0], {"do": key[0], "machines": []})
        if m.get("name") and m["name"] not in g["machines"]:
            g["machines"].append(m["name"])
    actions = sorted(groups.values(), key=lambda g: (not g.get("eol"), -len(g["machines"])))
    for g in actions:
        g["n"] = len(g["machines"])
        g["machines"] = sorted(g["machines"], key=str.lower)[:40]
    return {"priority": pr, "label": PRIORITY[pr], "why": why, "actions": actions[:8], "crosscheck": cross, "support": sup}


def support_summary(kept):
    """Per support state, how many machines (each once, by its worst program), and each product line."""
    worst, lines = {}, {}
    for m in kept:
        sp = m.get("support")
        if not sp or not m.get("name"):
            continue
        k = short(m["name"])
        if SUPPORT_RANK.get(sp["state"], 0) > SUPPORT_RANK.get(worst.get(k), 0):
            worst[k] = sp["state"]
        x = lines.setdefault(sp["line"], {"line": sp["line"], "state": sp["state"], "eos": sp.get("eos"), "eol": sp.get("eol"),
                                          "source": sp.get("source"), "paid": sp.get("paid"), "machines": []})
        if m["name"] not in x["machines"]:
            x["machines"].append(m["name"])
    out = {s: sum(1 for v in worst.values() if v == s) for s in ("eol", "eos", "eol_soon", "supported")}
    out["lines"] = sorted(lines.values(), key=lambda x: (-SUPPORT_RANK.get(x["state"], 0), x["line"].lower()))[:10]
    for x in out["lines"]:
        x["n"] = len(x["machines"])
        x["machines"] = sorted(x["machines"], key=str.lower)[:20]
    return out


def match_carbon_black(inv, prod):
    """Machines where Carbon Black saw this product RUN this week (r111). The program must be proven
    to be the product (cve_match, as for the server's own list). On each machine the version that ran
    last decides: inside an affected range -> found ("seen_running"); a fixed one -> nothing (Carbon
    Black never proves a machine fixed); not comparable -> "cannot tell". Its set-aside entries are
    marked "outside": they never outweigh PATCH-01's own evidence on the same machine.
    Returns (found, set_aside, pairs) like match_windows_programs."""
    from . import cve_match, exposure
    vendor, product = prod.get("vendor") or "", prod.get("product") or ""
    progs, seen = inv.cb_programs()
    if not progs.progs:
        return [], [], []
    _, decided = inv.programs()
    proven, confirm, _ = progs.find(vendor, product, decided)
    label = cve_match.cpe_words(product)
    per = {}
    for p in proven:
        for host, ver, _ in p["on"]:
            t = seen.get((short(host), p["name"], p["publisher"], ver))
            per.setdefault(short(host), {"name": host, "runs": []})["runs"].append((t, p["name"], ver))
    found, aside = [], []
    for k, x in per.items():
        runs = sorted([r for r in x["runs"] if r[0]], key=lambda r: r[0])
        if not runs:
            continue
        last_t = runs[-1][0]
        latest = [r for r in runs if r[0] == last_t]
        words = sorted({f"{n} {v}".strip() for _, n, v in latest})
        res = set()
        for _, _, ver in latest:
            if prod.get("cna"):
                c, _, _ = cna_judge(ver, prod, program=True)
                res.add("affected" if c == "in_range" else "fixed" if c == "outside" else "unknown")
            elif not prod.get("ranges") or not comparable(ver, prod["ranges"]):
                res.add("unknown")
            else:
                c, _ = exposure.match_versioned(ver, prod["ranges"])
                res.add("affected" if c == "in_range" else "fixed" if c == "outside" else "unknown")
        if res == {"affected"}:
            found.append({"product": label, "kind": "Application", "where": "Windows server", "name": x["name"],
                          "version": "; ".join(words[:3]), "certainty": "seen_running", "tool": "carbon_black",
                          "seen_at": last_t, "fixed": fixed_in(latest[0][2], prod.get("ranges")),
                          "program": latest[0][1], "pver": latest[0][2],
                          "detail": f"Carbon Black saw {', '.join(words[:3])} run here this week, and no fixed version "
                                    f"ran after it: inside the affected range"})
        elif res != {"fixed"}:
            aside.append({"name": x["name"], "product": label, "unproven": True, "outside": True,
                          "reason": "Carbon Black saw " + ", ".join(words[:3]) + " run here last: affected and fixed versions "
                                    "at the same time, or a version that cannot be compared"})
    pairs = [cve_match.pair_entry(vendor, product, p) for p in confirm[:cve_match.MAX_PAIRS]]
    for p in confirm:
        for host, _, _ in p["on"]:
            aside.append({"name": host, "product": label, "unproven": True, "to_confirm": True, "outside": True,
                          "reason": f"Carbon Black saw '{p['name']}' ({p['publisher'] or 'maker not stated'}) run here, "
                                    f"which may be {label}: confirm it under 'Programs to confirm'."})
    return found, aside, pairs


TOOL_NAMES = {"own": "PATCH-01's own check", "windows_update": "Windows Update", "carbon_black": "Carbon Black"}
OUTSIDE = ("carbon_black",)           # r137: the one outside tool in the CVE analysis (Nessus keeps its own page)


def _pk(text):
    return re.sub(r"[^a-z0-9]+", " ", str(text or "").lower()).strip()


def crosscheck(inv, cand, excluded):
    """The tools cross-checked (r111; r137: Carbon Black is the one outside tool, Nessus keeps its own page).
    On a machine where PATCH-01's own check proves the fix, Carbon Black (same product, run times per
    machine) having run the affected version before PATCH-01's newer inventory is "fixed since", set
    aside; after it, it stands and is flagged. A machine whose short name is not unique is never
    cross-checked. Returns (kept, record)."""
    inv_at = inv.host_times()
    own_fixed = {}
    for e in excluded:
        if e.get("fixed") and e.get("own"):
            own_fixed.setdefault((short(e.get("name")), _pk(e.get("product"))), e)
    own_hosts = {k for k, _ in own_fixed}
    own_found = {short(m.get("name")) for m, _, _ in cand if (m.get("tool") or "own") not in OUTSIDE}
    keep, cross = [], {"fixed_since": [], "disagree": [], "outside_only": [], "agree": [], "tools": {}}
    when = lambda t: t.strftime("%d %b %H:%M")
    for m, scope, basis in cand:
        t = m.get("tool") or "own"
        k = short(m.get("name"))
        mine, at = inv_at.get(k), m.get("seen_at")
        if t not in OUTSIDE or k in own_found or k not in own_hosts or not mine or not at:
            keep.append((m, scope, basis))
            continue
        proof = own_fixed.get((k, _pk(m.get("product"))))
        if not proof:
            keep.append((m, scope, basis))
        elif mine > at:
            cross["fixed_since"].append({"name": m.get("name"), "tool": t,
                                         "detail": f"Carbon Black saw the affected version run on {when(at)}; PATCH-01's inventory "
                                                   f"of {when(mine)} proves it fixed since: {proof.get('reason') or ''}"})
        else:
            keep.append((m, scope, basis))
            cross["disagree"].append({"name": m.get("name"), "tool": t,
                                      "detail": f"Carbon Black saw the affected version run on {when(at)}, after PATCH-01's "
                                                f"inventory of {when(mine)} showed it fixed: another copy, or it was "
                                                f"rolled back? Check the machine"})
    return keep, cross


def cross_finish(cross, lines, inv):
    """Which tools found each affected machine, and where Carbon Black agrees with PATCH-01."""
    for x in lines:
        tools = x.get("tools") or ["own"]
        for t in tools:
            cross["tools"][t] = cross["tools"].get(t, 0) + 1
        own = any(t not in OUTSIDE for t in tools)
        if own and any(t in OUTSIDE for t in tools):
            cross["agree"].append(x["name"])
        elif not own:
            cross["outside_only"].append({"name": x["name"], "tools": tools})
    for k in ("fixed_since", "outside_only", "agree", "disagree"):
        cross[k] = cross[k][:50]
    return cross


def match_confirmed(conn, cve_id, silent=None):
    """The CVE engine's verdict on each server: the installed build against the vendor's
    fixed build for that server's own release (Linux packages from the vendor advisories,
    Windows Server's OS build from Microsoft's Security Update Guide). A check made on the
    server itself: real, whatever the platform.

    A server that has gone silent (status stale, or an inventory older than the staleness
    window) or whose verdict is 'unknown' proves nothing either way: it is not a finding,
    and when `silent` (a list) is given it is added there, so the CVE is never called clean
    because of it."""
    from .assess import _stale_hours
    rows = conn.execute(
        """SELECT DISTINCT h.hostname, h.os_id, ha.state::text AS state, ha.package_name, ha.installed_evr,
                  ha.fixed_evr, ha.advisory_id::text AS advisory_id,
                  (h.status = 'stale' OR h.last_inventory IS NULL
                   OR h.last_inventory < now() - make_interval(hours => %s::int)) AS stale
             FROM advisory_cves ac
             JOIN host_applicability ha ON ha.advisory_id = ac.advisory_id
             JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'
            WHERE ac.cve_id = %s AND ha.state IN ('affected', 'fixed_pending_reboot', 'unknown')
               OR ac.cve_id = %s AND ha.state = 'fixed_active'
                  AND (h.status = 'stale' OR h.last_inventory IS NULL
                       OR h.last_inventory < now() - make_interval(hours => %s::int))
            LIMIT 500""", (_stale_hours(), cve_id, cve_id, _stale_hours())).fetchall()
    out, quiet = confirmed_matches(rows)
    if silent is not None:
        silent.extend(quiet)
    return out


def _upstream(evr_text):
    """'1:3.0.7-24.el9' -> '3.0.7' (no epoch, no release)."""
    v = str(evr_text or "")
    v = v.split(":", 1)[1] if ":" in v.split("-")[0] else v
    return v.split("-")[0] or None


def confirmed_matches(rows):
    """(matches, silent) from the engine's rows: affected and pending-reboot verdicts of
    reporting servers are findings; any verdict of a silent server, and 'unknown', are not
    (they go to silent, one per server)."""
    out, silent, seen = [], [], set()
    for r in rows:
        win = (r["os_id"] or "") == "windows"
        prod = "Windows (OS build)" if r["package_name"] == "windows-os-build" else r["package_name"]
        if r.get("stale") or r["state"] not in ("affected", "fixed_pending_reboot"):
            if r["hostname"] not in seen:
                seen.add(r["hostname"])
                silent.append({"name": r["hostname"], "product": prod, "unproven": True, "silent": True,
                               "reason": "the server has stopped reporting, so its verdict is unknown"
                                         if r.get("stale") else "the CVE engine could not judge this server (unknown)"})
            continue
        if r["state"] == "affected":
            detail = (f"{r['advisory_id']}: installed {r['installed_evr']} is older than the fixed "
                      f"{r['fixed_evr'] or 'build'}")
        else:
            detail = f"{r['advisory_id']}: the fix {r['fixed_evr'] or ''} is installed; a restart finishes it".replace("  ", " ")
        out.append({"product": prod, "kind": "Operating system" if win else "Application",
                    "where": "Windows server" if win else "Linux server", "name": r["hostname"],
                    "version": r["installed_evr"], "fixed": r["fixed_evr"],
                    "certainty": "confirmed" if r["state"] == "affected" else "pending_reboot", "detail": detail,
                    "advisory": r["advisory_id"],
                    # r116: a Linux package's upstream version, for the end-of-life rules an admin set
                    **({} if win or not r.get("package_name") else
                       {"program": r["package_name"], "pver": _upstream(r.get("installed_evr"))})})
    return out, silent


def match_wsus_missing(conn, cve_id):
    """Windows servers where Windows Update itself reports missing an update that fixes the CVE."""
    try:
        with conn.transaction():
            rows = conn.execute(
                """SELECT h.hostname, h.kernel_running AS build, coalesce(wu.kb, wu.update_id) AS kb, wu.title
                     FROM windows_updates wu JOIN hosts h ON h.id = wu.host_id AND h.status <> 'decommissioned'
                    WHERE %s = ANY(wu.cves) ORDER BY h.hostname LIMIT 500""", (cve_id,)).fetchall()
    except Exception:  # noqa: BLE001 - no Windows tables on an older database
        return []
    return [{"product": "Windows update " + (r["kb"] or ""), "kind": "Operating system", "where": "Windows server",
             "name": r["hostname"], "version": r["build"], "fixed": r["kb"], "certainty": "confirmed",
             "detail": f"Windows Update reports {r['kb']} missing ({(r['title'] or '')[:90]}); it fixes this CVE"}
            for r in rows]


# ---------------------------------------------------------------------------
# Appliances: network devices, firewalls and appliances in the asset inventory
# ---------------------------------------------------------------------------

APPLIANCE_TYPES = ("appliance", "network", "firewall")
# NVD vendor -> words that name it on a device record; NVD product -> words that name the product
VENDOR_WORDS = {"paloaltonetworks": ["palo alto", "paloalto", "pan-os"], "f5": ["f5", "big-ip", "bigip"],
                "checkpoint": ["check point", "checkpoint", "gaia"], "arubanetworks": ["aruba"], "hpe_aruba": ["aruba"],
                "citrix": ["citrix", "netscaler"], "pulsesecure": ["pulse secure", "ivanti"], "a10networks": ["a10"],
                "extremenetworks": ["extreme"], "tp-link": ["tp-link", "tplink"], "dlink": ["d-link", "dlink"],
                "d-link": ["d-link", "dlink"], "sonicwall": ["sonicwall", "sonicos"], "fortinet": ["fortinet", "forti"],
                "juniper": ["juniper", "junos"], "cisco": ["cisco"], "watchguard": ["watchguard", "fireware"]}
PRODUCT_WORDS = {"fortios": ["fortios", "fortigate"], "fortimanager": ["fortimanager"], "fortianalyzer": ["fortianalyzer"],
                 "fortiproxy": ["fortiproxy"], "fortiweb": ["fortiweb"], "pan-os": ["pan-os", "panos", "palo alto"],
                 "adaptive_security_appliance_software": ["asa", "adaptive security"],
                 "firepower_threat_defense": ["firepower", "ftd"], "ios_xe": ["ios xe", "ios-xe", "iosxe"],
                 "ios_xr": ["ios xr", "ios-xr"], "nx-os": ["nx-os", "nxos", "nexus"], "junos": ["junos"],
                 "sonicos": ["sonicos", "sonicwall"], "netscaler_application_delivery_controller": ["netscaler", "adc"],
                 "netscaler_gateway": ["netscaler", "gateway"], "connect_secure": ["connect secure", "pulse"],
                 "fireware": ["fireware", "firebox"], "gaia": ["gaia", "check point"]}
_KEY = re.compile(r"[^a-z0-9]+")
PRODUCT_NORM = {_KEY.sub("", k): v for k, v in PRODUCT_WORDS.items()}      # 'pan_os' and 'pan-os' are one product
VENDOR_NORM = {_KEY.sub("", k): v for k, v in VENDOR_WORDS.items()}


def pkey(product):
    return _KEY.sub("", str(product or "").lower())


VER_IN_TEXT = re.compile(r"(?:(?<![\w.])|(?<=\bv))(\d+(?:\.\d+){1,3}(?:[-_.]?[a-z]+[-_.]?\d*)*)", re.I)
PLAIN_VER = re.compile(r"^\d+(\.\d+){1,3}$")


def _norm(t):
    return re.sub(r"[^a-z0-9]+", " ", str(t or "").lower()).strip()


def _has(text, word, prefix=False):
    """Whether a device's words hold this word (or phrase); prefix: 'forti' finds 'fortigate'."""
    w = _norm(word)
    if not w:
        return False
    if " " in w or not prefix:
        return (" " + w + " ") in text
    return any(tok.startswith(w) for tok in text.split())


_APPL_CACHE = {"at": 0.0, "v": None}


def appliances(conn, max_age=0):
    """Network devices, firewalls and appliances the asset inventory holds (not decommissioned).
    max_age: seconds a list read before may be reused (an assessment of many CVEs reads it once)."""
    import time as _t
    if max_age and _APPL_CACHE["v"] is not None and _t.monotonic() - _APPL_CACHE["at"] < max_age:
        return _APPL_CACHE["v"]
    out = _appliances(conn)
    _APPL_CACHE.update(at=_t.monotonic(), v=out)
    return out


def _appliances(conn):
    try:
        from . import inventory
        data = inventory.load_assets(conn)
    except Exception as e:  # noqa: BLE001 - no asset inventory: no appliance matching
        log.info("impact: asset inventory not read: %s", e)
        return []
    out = []
    for a in data.get("assets") or []:
        if a.get("category") not in APPLIANCE_TYPES or a.get("status") == "decommissioned" or a.get("gone"):
            continue
        hw = a.get("hardware") or {}
        text = " ".join(str(x or "") for x in (hw.get("manufacturer"), hw.get("model"), a.get("os"), a.get("name")))
        d = {"name": a.get("name"), "ip": ", ".join(a.get("ips") or [])[:80] or None, "type": a.get("category"),
             "manufacturer": hw.get("manufacturer"), "model": hw.get("model"), "os": a.get("os"),
             "firmware": a.get("firmware"), "_text": " " + _norm(text) + " "}
        d["model_key"] = model_key(d)
        out.append(d)
    return out


def cna_judge(version, prod, program=False):
    """The vendor's own CVE record on one installed version (cve_org.judge): a program's version is
    compared like any program's, an appliance's by its maker's own numbering (fwver)."""
    from . import cve_org, fwver
    if program:
        return cve_org.judge(version, prod["cna"], cve_org.program_cmp, cve_org.program_eq)
    vk = prod.get("vendor_key") or fwver.vendor_key(prod.get("vendor"))
    return cve_org.judge(version, prod["cna"], cve_org.device_cmp(vk), cve_org.device_eq(vk))


def fw_ranges(version, ranges, vendor):
    """An appliance's firmware against NVD's ranges, by the maker's own numbering (fwver):
    ("in_range" | "outside" | "unknown", detail, fixed). Unknown whenever a bound cannot be
    ordered with the firmware, or NVD lists every version without bounds."""
    from . import fwver
    doubt, out = False, 0
    for r in ranges or []:
        bounds = [(k, r.get(k)) for k in ("start_incl", "start_excl", "end_incl", "end_excl") if r.get(k)]
        if bounds:
            inside = True
            for k, b in bounds:
                c = fwver.compare(version, b, vendor)
                if c is None:
                    doubt, inside = True, False
                    break
                if (k == "start_incl" and c < 0) or (k == "start_excl" and c <= 0) or \
                   (k == "end_incl" and c > 0) or (k == "end_excl" and c >= 0):
                    inside = False
                    break
            else:
                if inside:
                    lo = r.get("start_incl") or r.get("start_excl") or "any"
                    hi = r.get("end_excl") or r.get("end_incl") or "any"
                    fx = str(r["end_excl"]) if r.get("end_excl") else ("newer than " + str(r["end_incl"]) if r.get("end_incl") else None)
                    return "in_range", f"firmware {version} is inside the affected range {lo} to {hi}", fx
            if not inside and not doubt:
                out += 1
            continue
        rv, upd = str(r.get("version") or ""), str(r.get("update") or "*")
        if rv in ("*", ""):
            doubt = True                          # every version listed, no bounds: cannot be told apart
        elif rv == "-":
            continue
        elif upd not in ("*", "-", ""):
            doubt = True                          # a release with an update word: written another way
        elif fwver.same(version, rv, vendor):
            return "in_range", f"firmware {version} is a release NVD lists as affected", None
        else:
            out += 1
    if doubt:
        return "unknown", f"firmware {version} cannot be compared exactly with NVD's affected versions", None
    return ("outside", f"firmware {version} is outside every affected range", None) if out else \
           ("unknown", "NVD gives no affected versions to compare", None)


VERSION_WORD = re.compile(r"(?:version|firmware|fw|ver)\s*[:=]?\s*", re.I)


def device_version(d):
    """The firmware version: the sheet's Firmware column, else a version written in the OS or model text."""
    fw = str(d.get("firmware") or "").strip()
    if fw:
        return VERSION_WORD.sub("", fw)[:60].strip() or None
    m = VER_IN_TEXT.search(str(d.get("os") or "")) or VER_IN_TEXT.search(str(d.get("model") or ""))
    return m.group(1) if m else None


def model_key(d):
    """One device model, the key an admin's decision is kept under ('fortinet fortigate 100f')."""
    k = _norm(" ".join(str(x) for x in (d.get("manufacturer"), d.get("model")) if x))
    return (k or _norm(d.get("os")) or _norm(d.get("name")))[:200]


def match_appliances(devices, products, decisions=None):
    """Each appliance a CVE's product is on (r137: any maker). Returns the lines:
      state affected   the device is proven to be the product and its firmware is an affected version
      state check      proven, but the firmware is not recorded or cannot be compared: to check
      state confirm    the maker matches and the product may be it: an admin decides once per model
                       ("Same product" / "Different"); counted as to check meanwhile, never as clean
    Proven: the maker's and the product's words are both on the device record (known makers), or an
    admin said "Same product" for this model. Only a device's own software (firmware, an OS, hardware,
    or a product on the device list) is asked about; a maker's application never is. A model an admin tied to one of the maker's products is
    not asked about the maker's other products. Firmware is compared by the maker's own numbering
    (fwver), with NVD's ranges or the vendor's own CVE record (cve_org); never guessed."""
    from . import fwver
    # The admins' word, by model and by the maker's and product's names written either way (NVD's
    # 'paloaltonetworks pan-os' and the vendor record's 'palo_alto_networks pan_os' are one)
    decisions = {(mk, fwver.vendor_key(v), pkey(pr)): dec for (mk, v, pr), dec in (decisions or {}).items()}
    same_vendor = {(mk, v) for (mk, v, _), dec in decisions.items() if dec == "same"}
    out = []
    for p in products:
        if p["kind"] not in ("Network device or appliance", "Hardware or firmware"):
            continue
        vk = p.get("vendor_key") or fwver.vendor_key(p["vendor"])
        vwords = VENDOR_WORDS.get(p["vendor"]) or VENDOR_NORM.get(vk) or [p["vendor"].replace("_", " ")]
        pwords = PRODUCT_WORDS.get(p["product"]) or PRODUCT_NORM.get(pkey(p["product"]))
        known = pwords is not None and (p["vendor"] in VENDOR_WORDS or vk in VENDOR_NORM)
        # Asked about only when it is a device's own software: firmware or an OS (CPE part o), hardware
        # (h), or a product on the device list; a maker's application (Webex, a client) is not a device
        device_product = p.get("part") in ("o", "h") or pwords is not None
        if pwords is None:
            pwords = [" ".join(w for w in p["product"].split("_") if len(w) > 2)] if len(p["product"]) > 2 else []
        name = p.get("label") or f"{p['vendor']} {p['product']}".replace("_", " ")
        for d in devices:
            t = d["_text"]
            mk = d.get("model_key") or model_key(d)
            dec = decisions.get((mk, vk, pkey(p["product"])))
            if dec == "different":
                continue
            maker = any(_has(t, w, prefix=True) for w in vwords)
            if not maker and dec != "same":
                continue
            prod_named = bool(pwords) and any(_has(t, w) for w in pwords if w)
            if dec == "same" or (known and prod_named):
                proven = True
            elif (mk, vk) in same_vendor or not device_product:
                continue                          # this model runs another product of this maker (an admin said so)
            else:
                proven = False
            ver = device_version(d)
            line = {"name": d["name"], "ip": d["ip"], "type": d["type"], "device": " ".join(
                x for x in (d.get("manufacturer"), d.get("model")) if x) or None, "os": d.get("os"), "product": name,
                "model_key": mk, "vendor": p["vendor"], "cve_product": p["product"], "version": ver,
                "source": p.get("source") or "nvd"}
            if not proven:
                out.append(dict(line, state="confirm", detail=(
                    f"the maker matches and this may be {name}" + ("" if prod_named else " (the product is not named on the device)")
                    + ": confirm it under 'Devices to confirm' (once for this model)")))
                continue
            if not ver:
                out.append(dict(line, state="check", detail="the device is this product; its firmware version is not recorded "
                                                            "(add a Firmware column to the asset sheet)"))
                continue
            if p.get("cna"):
                cert, why, fx = cna_judge(ver, p)
                why += " (the vendor's CVE record)"
            elif p.get("ranges"):
                cert, why, fx = fw_ranges(ver, p["ranges"], vk)
            else:
                cert, why, fx = "unknown", "no affected versions are listed to compare", None
            if cert == "outside":
                continue                          # its firmware is not an affected version
            out.append(dict(line, state="affected" if cert == "in_range" else "check", detail=why, fixed=fx))
    return out


def device_decisions(conn):
    """{(model_key, vendor, product): 'same' | 'different'}: the admins' word on device models."""
    try:
        with conn.transaction():
            return {(r["model_key"], r["vendor"], r["product"]): r["decision"]
                    for r in conn.execute("SELECT model_key, vendor, product, decision FROM appliance_decisions").fetchall()}
    except Exception:  # noqa: BLE001 - schema 072 not applied: no decisions yet
        return {}


# ---------------------------------------------------------------------------
# Assets: one record per machine, merged from every inventory source
# ---------------------------------------------------------------------------

RPM_DISTROS = {"rhel", "ol", "centos", "rocky", "almalinux", "alma"}       # rebuilds of RHEL: Red Hat's data applies
LINUX_IDS = RPM_DISTROS | {"fedora", "ubuntu", "debian", "sles", "sled", "opensuse", "amzn", "linux"}
DISTRO_NAMES = {"rhel": "RHEL", "ol": "Oracle Linux", "centos": "CentOS", "rocky": "Rocky Linux",
                "almalinux": "AlmaLinux", "alma": "AlmaLinux", "fedora": "Fedora", "ubuntu": "Ubuntu",
                "debian": "Debian", "sles": "SUSE Linux", "sled": "SUSE Linux", "opensuse": "openSUSE",
                "amzn": "Amazon Linux"}
GUEST_DISTROS = ((re.compile(r"red hat enterprise linux|\brhel\b", re.I), "rhel"),
                 (re.compile(r"oracle linux", re.I), "ol"), (re.compile(r"rocky", re.I), "rocky"),
                 (re.compile(r"alma", re.I), "almalinux"), (re.compile(r"centos", re.I), "centos"),
                 (re.compile(r"fedora", re.I), "fedora"), (re.compile(r"ubuntu", re.I), "ubuntu"),
                 (re.compile(r"debian", re.I), "debian"), (re.compile(r"suse", re.I), "sles"))
SOURCE_RANK = {"agent": 3, "ESXi host": 3, "vCenter": 3, "WSUS": 2, "vCenter guest": 1}
WHERE_SOURCE = {"Linux server": "agent", "Windows server": "agent", "Windows server (agent)": "agent",
                "WSUS computer": "WSUS", "VM guest OS": "vCenter guest", "ESXi host": "ESXi host",
                "Server hardware (ESXi host)": "ESXi host", "vCenter": "vCenter"}
JUNK_NAMES = {"", "localhost", "localhost.localdomain", "localdomain", "unknown", "none"}
IP_RE = re.compile(r"^(\d{1,3}(\.\d{1,3}){3}|[0-9a-f:]{3,39})$", re.I)


def short(name):
    """'srv-01.corp.example' -> 'srv-01'; an address stays whole."""
    n = str(name or "").strip().lower().strip(".")
    if IP_RE.match(n):
        return n
    return n.split(".")[0]


def _linux_id(oid):
    oid = (oid or "").lower()
    if oid in LINUX_IDS:
        return oid
    for p in ("opensuse", "sles", "sled", "rhel", "ol", "rocky", "alma", "centos", "ubuntu", "debian", "amzn", "fedora"):
        if oid.startswith(p):
            return {"alma": "almalinux"}.get(p, p)
    return None


def _guest(os_text, family_hint=None, is_linux=None):
    t = os_text or ""
    if re.search(r"windows", t, re.I) or str(family_hint or "").lower().startswith("windows"):
        return "windows", None, None
    if is_linux or re.search(r"linux|ubuntu|debian|centos|rhel|suse|fedora", t, re.I) \
            or str(family_hint or "").lower().startswith("linux"):
        distro = next((d for rx, d in GUEST_DISTROS if rx.search(t)), None)
        m = re.search(r"\b(\d{1,2})(?:\.\d+)*\b(?!-bit)", t)
        return "linux", distro, (int(m.group(1)) if m and distro else None)
    return "unknown", None, None


class Assets:
    """Every machine we know, one record each, merged across the inventory
    sources only on evidence: the same full name, a shared address, or the
    same short name when that is unambiguous and the systems agree. Two
    machines with the same short name in different domains stay apart."""

    def __init__(self):
        self.items = []
        self.by_fqdn, self.by_short, self.by_ip = {}, {}, {}

    def _find(self, fqdn, sn, ips, family):
        if fqdn and fqdn in self.by_fqdn:
            return self.by_fqdn[fqdn]
        for ip in ips:
            if ip in self.by_ip:
                return self.by_ip[ip]
        cands = [a for a in self.by_short.get(sn, [])
                 if not (fqdn and a["fqdn"] and a["fqdn"] != fqdn)                 # different domains
                 and (family == "unknown" or a["family"] in ("unknown", family))]  # systems agree
        return cands[0] if len(cands) == 1 else None

    def add(self, name, src, family, os_label, ips=(), distro=None, major=None, extra=None):
        raw = str(name or "").strip().strip(".")
        if raw.lower() in JUNK_NAMES:
            return None
        fqdn = raw.lower() if "." in raw and not IP_RE.match(raw) else None
        sn = short(raw)
        if not sn:
            return None
        ips = [i for i in (str(x or "").strip() for x in ips or ())
               if IP_RE.match(i) and not i.startswith(("127.", "169.254.", "fe80")) and i != "::1"][:4]
        a = self._find(fqdn, sn, ips, family)
        if a is None:
            a = {"name": raw, "fqdn": fqdn, "ips": [], "os": None, "family": "unknown", "distro": None,
                 "major": None, "sources": [], "_rank": -1, "conflict": None}
            self.items.append(a)
            self.by_short.setdefault(sn, []).append(a)
        if src not in a["sources"]:
            a["sources"].append(src)
        if fqdn and not a["fqdn"]:
            a["fqdn"] = fqdn
        if fqdn:
            self.by_fqdn.setdefault(fqdn, a)
        for ip in ips:
            if ip not in a["ips"] and len(a["ips"]) < 4:
                a["ips"].append(ip)
            self.by_ip.setdefault(ip, a)
        if extra:
            a.update(extra)                  # what each source knows of the machine (seen, power)
        rank = SOURCE_RANK.get(src, 0)
        if family != "unknown" and a["family"] not in ("unknown", family):
            if rank <= a["_rank"]:
                a["conflict"] = f"{src} reports {os_label}"           # the better source is kept
                return a
            a["conflict"] = f"{', '.join(s for s in a['sources'] if s != src)} reported {a['os']}"
        if rank > a["_rank"] and (family != "unknown" or a["os"] is None):
            a.update(family=family, os=os_label or a["os"], distro=distro, major=major, _rank=rank)
            if src == "agent":
                a["name"] = raw
        return a

    def lookup(self, name, where=None):
        """The machine a match names. When a short name is shared, the one
        known from the match's own source is taken; still ambiguous: None."""
        raw = str(name or "").strip().strip(".").lower()
        if not raw:
            return None
        if raw in self.by_fqdn:
            return self.by_fqdn[raw]
        if raw in self.by_ip:
            return self.by_ip[raw]
        cands = self.by_short.get(short(raw), [])
        if len(cands) > 1 and where in WHERE_SOURCE:
            cands = [a for a in cands if WHERE_SOURCE[where] in a["sources"]] or cands
        return cands[0] if len(cands) == 1 else None


def build_assets(conn):
    out = Assets()
    for r in conn.execute(
            """SELECT hostname, fqdn, host(agent_ip) AS ip, os_id, os_version, os_major, os_edition,
                      agent_state(last_checkin, status) AS agent, last_checkin
                 FROM hosts WHERE status <> 'decommissioned'""").fetchall():
        oid, lid = (r["os_id"] or "").lower(), _linux_id(r["os_id"])
        if oid == "windows":
            fam, label, distro = "windows", r["os_edition"] or ("Windows " + (r["os_version"] or "")).strip(), None
        elif lid:
            fam, distro = "linux", lid
            label = f"{DISTRO_NAMES.get(lid, r['os_id'])} {r['os_version'] or ''}".strip()
        else:
            fam, distro = "unknown", None
            label = r["os_edition"] or " ".join(x for x in (r["os_id"], r["os_version"]) if x) or None
        a = out.add(r["fqdn"] or r["hostname"], "agent", fam, label, [r["ip"]], distro, r["os_major"],
                    {"agent": r["agent"], "agent_seen": r["last_checkin"]})
        if a and r["fqdn"] and r["hostname"] and short(r["hostname"]) != short(r["fqdn"]):
            out.by_short.setdefault(short(r["hostname"]), []).append(a)
        if a:
            a["name"] = r["hostname"]
    for r in conn.execute("SELECT name, ip, os, last_reported FROM wsus_computers").fetchall():
        fam, _, _ = _guest(r["os"])
        out.add(r["name"], "WSUS", fam if fam != "unknown" else "windows", r["os"] or "Windows", [r["ip"]],
                extra={"wsus_seen": r["last_reported"]})
    for r in conn.execute(
            """SELECT name, guest_hostname, guest_ips, guest_os, guest_family, is_linux, power_state
                 FROM vm_inventory""").fetchall():
        fam, distro, major = _guest(r["guest_os"], r["guest_family"], r["is_linux"])
        gh = r["guest_hostname"] if str(r["guest_hostname"] or "").strip().lower() not in JUNK_NAMES else None
        a = out.add(gh or r["name"], "vCenter guest", fam, r["guest_os"], r["guest_ips"] or [], distro, major,
                    {"power": r["power_state"]})
        if a and gh and r["name"] and short(r["name"]) != short(gh) and str(r["name"]).strip().lower() not in JUNK_NAMES:
            lst = out.by_short.setdefault(short(r["name"]), [])     # the VM's own name finds it too
            if a not in lst:
                lst.append(a)
    for r in conn.execute("SELECT name, esxi_version FROM esxi_hosts").fetchall():
        out.add(r["name"], "ESXi host", "esxi", ("ESXi " + (r["esxi_version"] or "")).strip(), [r["name"]])
    try:
        with conn.transaction():
            rows = conn.execute("SELECT host, version FROM vcenters").fetchall()
    except Exception:  # noqa: BLE001 - no vCenter table on a fresh install
        rows = []
    for r in rows:
        out.add(r["host"], "vCenter", "vcenter", ("vCenter " + (r["version"] or "")).strip(), [r["host"]])
    return out


def tag(m, asset, basis=None):
    """The machine's own record on the match: address, OS, where it is known from."""
    if asset:
        m["ip"] = ", ".join(asset["ips"]) or None
        m["os"] = asset["os"]
        m["os_family"] = asset["family"]
        m["sources"] = list(asset["sources"])
        if asset.get("conflict"):
            m["os_note"] = asset["conflict"]
    if basis:
        m["basis"] = basis
    return m


# ---------------------------------------------------------------------------
# Platforms: which operating systems a vulnerable product runs on
# ---------------------------------------------------------------------------

PLATFORM_NAMES = {"windows": "Windows", "linux": "Linux", "rpm": "RHEL family", "esxi": "VMware ESXi",
                  "vcenter": "VMware vCenter", "hardware": "Server hardware", "network": "Network devices"}
MS_NOT_OURS = re.compile(r"\b(cbl[- ]?mariner|azure linux|cbl2|azl3|for mac|macos|android|ios|iphone|ipad|xbox)\b", re.I)


def running_on(cpes):
    """For each NVD configuration, the platforms its vulnerable products run
    on ("running on" entries, which NVD marks as not vulnerable themselves):
    {cfg: {'windows'} / {'linux'} / {'other'}}. A configuration without such
    entries is absent: its products run anywhere."""
    from . import exposure
    out = {}
    for c in cpes:
        if c.get("vulnerable", True):
            continue
        p = exposure.parse_cpe(c.get("criteria"))
        if not p or p["part"] != "o":
            continue
        if p["vendor"] == "microsoft" and p["product"].startswith("windows"):
            fam = "windows"
        elif (p["vendor"], p["product"]) in exposure.LINUX_OS or p["product"] in ("linux_kernel", "linux", "debian_linux", "fedora"):
            fam = "linux"
        else:
            fam = "other"
        out.setdefault(c.get("cfg"), set()).add(fam)
    return out


# NVD target_sw values that are operating systems we do not run; any other
# value that is not windows or linux (node.js, python, wordpress, jenkins...)
# is an ecosystem, which runs on either
OTHER_TARGET = re.compile(r"^(mac_?os(_x)?|macos|os_x|iphone_os|ipados|ios|android|chrome_?os|watchos|tvos|"
                          r"visionos|solaris|aix|hp-ux|freebsd|openbsd|netbsd|z\/os|blackberry.*)$", re.I)
OTHER_LINUX_OS = {("debian", "debian_linux"): "debian", ("fedoraproject", "fedora"): "fedora",
                  ("suse", "linux_enterprise_server"): "sles", ("opensuse", "leap"): "opensuse",
                  ("rockylinux", "rocky_linux"): "rocky", ("almalinux", "almalinux"): "almalinux",
                  ("centos", "centos"): "centos", ("amazon", "linux"): "amzn", ("amazon", "linux_2"): "amzn"}
# Microsoft products that also run on Linux (their Linux builds are matched by package)
MS_CROSS = {".net", "dotnet", ".net_core", "asp.net_core", ".net_framework_core", "powershell", "visual_studio_code",
            "sql_server", "odbc_driver_for_sql_server", "ole_db_driver_for_sql_server", "azure_cli", "edge_chromium",
            "teams", "omi", "open_management_infrastructure", "system_center_operations_manager"}


def cpe_scope(p, on):
    """(platforms, why) for one NVD product; platforms None when it is not a
    platform we run (macOS, Android, a phone OS)."""
    from . import exposure
    v, prod, kind = p["vendor"], p["product"], p["kind"]
    name = f"{v} {prod}".replace("_", " ")
    if kind == "Hypervisor (ESXi)":
        return {"esxi"}, "NVD: VMware ESXi"
    if kind == "vCenter":
        return {"vcenter"}, "NVD: VMware vCenter"
    if kind == "Hardware or firmware":
        return {"hardware"}, f"NVD: hardware {name}"
    if kind == "Network device or appliance":
        return {"network"}, f"NVD: network device {name}"
    if p["part"] == "o":
        if v == "microsoft" and prod.startswith("windows"):
            return {"windows"}, f"NVD: {name}"
        if (v, prod) in exposure.LINUX_OS:
            return {"distro:" + exposure.LINUX_OS[(v, prod)]}, f"NVD: {name}"
        if (v, prod) in OTHER_LINUX_OS:
            return {"distro:" + OTHER_LINUX_OS[(v, prod)]}, f"NVD: {name}"
        if prod in ("linux_kernel", "linux"):
            return {"linux"}, "NVD: the Linux kernel"
        return None, f"NVD: {name} is an operating system we do not run"
    # 1. NVD's own platform field on the product's entries
    targets = [str(r.get("target_sw") or "*").lower() for r in p.get("ranges") or []]
    if targets and not any(t in ("*", "-", "") for t in targets):
        mapped, eco = set(), set()
        for t in set(targets):
            if t == "windows":
                mapped.add("windows")
            elif t in ("linux", "linux_kernel"):
                mapped.add("linux")
            elif not OTHER_TARGET.match(t):
                mapped |= {"windows", "linux"}          # an ecosystem (node.js, python...): either
                eco.add(t)
        if not mapped:
            return None, f"NVD: {name} for {', '.join(sorted(set(targets)))} only"
        if eco:
            return mapped, f"NVD: {name} for {', '.join(sorted(eco))} (any operating system)"
        return mapped, f"NVD: {name} for {', '.join(sorted(PLATFORM_NAMES[x] for x in mapped))}"
    # 2. "Running on" entries in the configurations this product is listed in
    cfgs = p.get("cfgs") or [None]
    if all(c in on for c in cfgs):
        fams = set().union(*(on[c] for c in cfgs))
        ours = fams - {"other"}
        if not ours:
            return None, f"NVD: {name} on platforms we do not run"
        return ours, f"NVD: {name} running on {', '.join(sorted(PLATFORM_NAMES[x] for x in ours))}"
    # 3. The vendor
    if v == "microsoft" and prod not in MS_CROSS:
        return {"windows"}, f"NVD: {name} (Microsoft product for Windows)"
    return {"windows", "linux"}, f"NVD: {name} (any platform)"


def fits(scope, asset_family, distro=None):
    if not scope:
        return False
    if asset_family in scope:
        return True
    if asset_family == "linux":
        if "rpm" in scope and distro in RPM_DISTROS:
            return True
        if distro and ("distro:" + distro) in scope:
            return True
    return False


def scope_words(scope):
    return " or ".join(sorted(PLATFORM_NAMES.get(x, x.replace("distro:", "").upper()) for x in scope))


# ---------------------------------------------------------------------------
# Red Hat: installed build against Red Hat's fixed build for that RHEL release
# ---------------------------------------------------------------------------

# Binary packages built from a source package: openssl -> openssl-libs, openssh -> openssh-server,
# curl -> curl-minimal, libcurl, libcurl-minimal; kernel -> kernel-core, kernel-modules...
SUBPKG = r"(-(libs|server|clients?|common|core|devel|minimal|modules(-core|-extra)?|utils|tools|headers|daemon|full|" \
         r"libs-[a-z0-9]+|client-libs|selinux|tui|langpack-[a-z]+))?"


def _source_of(binary, sources):
    """The Red Hat source package an installed binary package comes from, or None."""
    b = binary.lower()
    for src in sorted(sources, key=len, reverse=True):         # longest first: openssl-pkcs11 before openssl
        if re.fullmatch(r"(lib)?" + re.escape(src) + SUBPKG, b):
            return src
    return None


def split_running_kernel(uname_r):
    """'5.14.0-570.12.1.el9_6.x86_64' -> ('5.14.0', '570.12.1.el9_6') (as cve_engine does)."""
    s = re.sub(r"\.(x86_64|aarch64|ppc64le|s390x|i686|noarch)$", "", str(uname_r or "").strip())
    v, _, r = s.partition("-")
    return v, r


def is_kernel_source(src):
    """Red Hat source packages whose fix takes effect only once the new kernel runs."""
    return src in ("kernel", "kernel-rt")


def rh_fixed_state(src, row, best):
    """One installed package against Red Hat's fixed build: 'older' (installed older than
    the fix), 'fixed', or for the kernel, whose fix only counts once it runs:
    'pending_reboot' (fixed kernel installed, an older one running) or 'running_unknown'
    (the running kernel was not reported)."""
    from . import evr
    if evr.rpm_label_compare(row["epoch"], row["version"], row["release"],
                             best["epoch"], best["version"], best["release"]) < 0:
        return "older"
    if not is_kernel_source(src):
        return "fixed"
    run_v, run_r = split_running_kernel(row.get("kernel_running"))
    if not run_v:
        return "running_unknown"
    if evr.rpm_label_compare(0, run_v, run_r, best["epoch"], best["version"], best["release"]) < 0:
        return "pending_reboot"
    return "fixed"


def match_redhat(conn, cve_id, fixed_names, comps):
    """(matches, excluded, notes, decided_hosts). Red Hat's answer for RHEL
    builds: the installed build of each package against Red Hat's fixed build
    for the machine's own release. Until Red Hat's per-release state has been
    read, only packages Red Hat shipped a fix in count, and only as 'present'.
    decided_hosts: the RHEL-family machines Red Hat's answer covers."""
    from . import evr, exposure, rh_state
    st = rh_state.get(conn, cve_id)
    have = bool(st and st.get("found"))
    sources = set()
    for n in list(fixed_names) + (list(comps) if have else []):
        if isinstance(n, str) and re.fullmatch(r"[a-z0-9][a-z0-9._+-]{1,60}", n.lower()):
            sources.add(n.lower())
            sources.update(exposure.PACKAGE_ALIASES.get(n.lower(), []))
    notes = []
    if comps and not have:
        why = ("Red Hat's per-release state could not be read; it is tried again daily" if st and st.get("error")
               else "Red Hat has no per-release state for this CVE" if st
               else "Red Hat's per-release state is being read")
        notes.append("Red Hat names " + ", ".join(sorted(comps)[:5]) + " in its title. " + why
                     + ", so those are not matched on the name alone")
    if have:
        sources.update(x["package"].lower() for x in st["states"] + st["fixed"])
    sources = {x for x in sources if re.fullmatch(r"[a-z0-9][a-z0-9._+-]{0,79}", x)}
    if not sources:
        return [], [], notes, set()
    like = []
    for src in sorted(sources)[:60]:
        like += [src + "%", "lib" + src + "%"]
    rows = conn.execute(
        """SELECT h.hostname, h.os_id, h.os_major, h.kernel_running, hp.name, hp.epoch, hp.version, hp.release
             FROM host_packages hp JOIN hosts h ON h.id = hp.host_id AND h.status <> 'decommissioned'
            WHERE lower(hp.name) LIKE ANY(%s) ORDER BY h.hostname, hp.name LIMIT 5000""", (like,)).fetchall()
    matches, excluded, decided = [], [], set()
    seen = set()
    fixed_set = {n.lower() for n in fixed_names}
    for r in rows:
        src = _source_of(r["name"], sources)
        if not src or (r["hostname"], src) in seen:
            continue                     # one line per machine and source package
        seen.add((r["hostname"], src))
        oid, major, pkg = _linux_id(r["os_id"]) or (r["os_id"] or "").lower(), r["os_major"], r["name"]
        installed = evr.evr_str(r["epoch"], r["version"], r["release"])
        label = pkg if pkg.lower() == src else f"{pkg} (from {src})"
        base = {"product": src, "kind": "Application", "where": "Linux server", "name": r["hostname"],
                "version": f"{label} {installed}", "program": pkg, "pver": r["version"]}
        if oid not in RPM_DISTROS:
            excluded.append({"name": r["hostname"], "product": src, "not_judged": True,
                             "reason": f"not judged by Red Hat's data, which covers RHEL builds only "
                                       f"(this machine runs {DISTRO_NAMES.get(oid, oid or 'an unknown OS')})"})
            continue
        via = "" if oid == "rhel" else f" ({DISTRO_NAMES.get(oid, oid)} follows RHEL {major})"
        if not have:
            if src in fixed_set:
                matches.append(dict(base, certainty="present",
                                    detail=f"Red Hat released a fixed {src}; its fixed build for RHEL {major} "
                                           f"is being read{via}"))
            continue
        decided.add(short(r["hostname"]))
        fx = [f for f in st["fixed"] if f["major"] == major and f["package"].lower() == src]
        sx = [x for x in st["states"] if x["major"] == major and x["package"].lower() == src]
        if fx:
            best = max(fx, key=cmp_to_key(lambda x, y: evr.rpm_label_compare(
                x["epoch"], x["version"], x["release"], y["epoch"], y["version"], y["release"])))
            fixed_s = evr.evr_str(best["epoch"], best["version"], best["release"])
            word = rh_fixed_state(src, r, best)
            if word == "older":
                matches.append(dict(base, certainty="in_range",
                                    detail=f"installed {installed} is older than Red Hat's fixed build {fixed_s}"
                                           + (f" ({best['advisory']})" if best["advisory"] else "") + f" for RHEL {major}{via}"))
            elif word == "pending_reboot":
                # Installed is not effective: the kernel that runs is the one that counts
                matches.append(dict(base, certainty="pending_reboot",
                                    detail=f"Red Hat's fixed kernel {fixed_s} is installed but {r['kernel_running']} is "
                                           f"still running; a restart finishes it{via}"))
            elif word == "running_unknown":
                excluded.append({"name": r["hostname"], "product": src, "unproven": True,
                                 "reason": f"{label} {installed} is at Red Hat's fixed build {fixed_s}, but the "
                                           f"running kernel is not reported"})
            else:
                excluded.append({"name": r["hostname"], "product": src, "fixed": True, "own": True,
                                 "reason": f"{label} {installed} is at Red Hat's fixed build {fixed_s} or newer"})
        elif any(x["state"] == "affected" for x in sx):
            word = next(x["word"] for x in sx if x["state"] == "affected")
            matches.append(dict(base, certainty="no_fix",
                                detail=f"Red Hat: RHEL {major} {word}; no fixed build yet{via}"))
        elif sx:
            excluded.append({"name": r["hostname"], "product": src, "fixed": True, "reason": f"Red Hat: not affected on RHEL {major}"})
        elif src in fixed_set:
            matches.append(dict(base, certainty="present",
                                detail=f"Red Hat fixed {src} for another release but gives no state for RHEL {major}{via}"))
        else:
            excluded.append({"name": r["hostname"], "product": src, "undecided": True,
                             "reason": f"Red Hat gives no state for {src} on RHEL {major}"})
    return matches, excluded, notes, decided


# ---------------------------------------------------------------------------
# One CVE
# ---------------------------------------------------------------------------

RANK = {"confirmed": 6, "in_range": 5, "seen_running": 5, "no_fix": 4, "pending_reboot": 3, "release_match": 2, "present": 1,
        "not_tracked": 0}
# Proven on the machine: a version compared with the vendor's fixed build or NVD's affected range,
# a vendor saying "affected, no fix yet" for the machine's own release, or Windows Update reporting
# the fixing update missing. Anything weaker (the product is merely installed, the OS matches,
# the release matches but the patch level cannot be compared) is not a finding.
REAL = ("confirmed", "in_range", "seen_running", "no_fix", "pending_reboot")
WHERE_FAMILY = {"Linux server": "linux", "Windows server": "windows", "Windows server (agent)": "windows",
                "WSUS computer": "windows", "ESXi host": "esxi", "Server hardware (ESXi host)": "hardware",
                "vCenter": "vcenter"}


SUPPORT_RANK = {"eol": 4, "eos": 3, "eol_soon": 2, "supported": 1}


def support_of(inv, m):
    """The end of support / end of life state of the program a finding is about, with its evidence
    (r116). Only from the program's own name and version as the machine reported it, matched by the
    same rules as Installed software; nothing guessed. None when no rule covers it."""
    from . import sw_lifecycle
    prog, ver = m.get("program"), m.get("pver")
    if not prog:
        return None
    plat = "linux" if (m.get("where") or "").startswith("Linux") else "windows"
    rule = sw_lifecycle.rule_for(inv.lifecycle()[plat], prog, ver)
    st = sw_lifecycle.state(rule)
    if not st:
        return None
    src = "endoflife.date" if rule.get("source") == "endoflife" else "Admin › Software rules"
    line = (rule["name_prefix"] + (" " + rule["version_prefix"] if rule.get("version_prefix") else "")).strip()
    dates = "; ".join(x for x in (f"end of support {st['eos']}" if st.get("eos") else "",
                                    f"end of life {st['eol']}" if st.get("eol") else "") if x)
    paid = ""
    note = rule.get("note") or ""
    if "paid extended support until" in note:
        paid = "paid extended support until " + note.split("paid extended support until", 1)[1].strip()[:10]
    return {"state": st["state"], "text": st["text"], "eos": st.get("eos"), "eol": st.get("eol"), "line": line,
            "program": f"{prog} {ver or ''}".strip()[:160], "source": src, "paid": paid or None,
            "evidence": f"{prog} {ver or ''}".strip()[:120] + f" is in the {line} line: {dates} ({src}"
                        + (f"; {paid}" if paid else "") + ")"}


def _machine_lines(kept):
    """One line per machine: the products found on it, the strongest evidence, the details."""
    by = {}
    for m in kept:
        k = short(m.get("name"))
        x = by.setdefault(k, {"name": m.get("name"), "ip": m.get("ip"), "os": m.get("os"), "where": m.get("where"),
                              "platform": m.get("where"), "products": [], "versions": [], "details": [],
                              "certainty": m["certainty"], "fixed": None, "basis": m.get("basis"),
                              "sources": m.get("sources") or [], "restart": True, "tools": [], "advisories": [],
                              "support": []})
        sp = m.get("support")
        if sp and not any(z["program"] == sp["program"] for z in x["support"]):
            x["support"].append(sp)
        t = m.get("tool") or "own"
        if t not in x["tools"]:
            x["tools"].append(t)
        if m.get("advisory") and m["advisory"] not in x["advisories"]:
            x["advisories"].append(m["advisory"])
        prod = m.get("product") or ""
        if prod and prod not in x["products"]:
            x["products"].append(prod)
        if m.get("version") and m["version"] not in x["versions"]:
            x["versions"].append(str(m["version"]))
        if m.get("detail") and m["detail"] not in x["details"]:
            x["details"].append(m["detail"])
        if m.get("fixed") and not x["fixed"]:
            x["fixed"] = m["fixed"]
        if RANK.get(m["certainty"], 0) > RANK.get(x["certainty"], 0):
            x["certainty"], x["basis"] = m["certainty"], m.get("basis")
        if m["certainty"] != "pending_reboot":
            x["restart"] = False              # something is still to install, not only a restart
        for k2 in ("ip", "os"):
            x[k2] = x[k2] or m.get(k2)
    out = []
    for x in by.values():
        x["support"] = sorted(x["support"], key=lambda z: -SUPPORT_RANK.get(z["state"], 0))[:6]
        x["support_state"] = x["support"][0]["state"] if x["support"] else None
        x["product"] = ", ".join(x["products"][:6])
        x["version"] = "; ".join(x["versions"][:4])
        x["detail"] = "; ".join(x["details"][:4])
        del x["versions"], x["details"]
        out.append(x)
    return sorted(out, key=lambda m: (-RANK.get(m["certainty"], 0), (m.get("name") or "").lower()))


def impact_verdict(lines, fixed, undecided_hosts=()):
    """The CVE's verdict from the proven findings and the machines set aside:
      affected      proven on at least one machine
      unknown       nothing is proven affected, but a machine holds the product and is not proven
                    fixed: it stopped reporting, the engine says unknown, the version could not be
                    compared, or no vendor data judges it. Never called clean on part of the evidence
      not_affected  every machine holding the product is proven at a fixed build
      not_found     no machine holds the product at all"""
    if lines:
        return "affected"
    if undecided_hosts or any(not f.get("fixed") and (f.get("silent") or f.get("unproven") or f.get("undecided"))
                              for f in fixed):
        return "unknown"                   # a machine holds it and nothing proves it either way
    if any(f.get("fixed") for f in fixed):
        return "not_affected"              # the product is on our servers, at the vendor's fixed build
    return "not_found"


def analyse_one(conn, cve, inv=None, devices=None):
    """Where one CVE really applies in our environment. In order: the CVE engine's version
    check on each server (Linux packages, Windows Server's OS build), Windows Update's own list
    of missing updates, NVD's affected version ranges (Windows programs, ESXi, vCenter), Red Hat's
    fixed build for each server's own RHEL release, and the appliances in the asset inventory.
    Only proven findings count; each machine once.

    Returns (verdict, machines, lines, info): verdict 'affected' (proven on at least one server),
    'not_affected' (every server holding the product is at a fixed version), 'unknown' (a server
    holding it cannot be judged) or 'not_found' (see impact_verdict); info holds
    the platforms, the appliances (affected, or to check), the machines checked and found fixed,
    and notes."""
    from . import exposure
    inv = inv or Inventory(conn)
    assets = inv.assets()
    cid = cve["cve_id"]
    cand = []                      # (match, scope, basis); scope None: checked on the machine itself
    excluded, notes, platforms = [], [], set()
    to_confirm = []                # programs that may be a vulnerable product: an admin decides (r110)
    linux_products = []            # NVD applications that run on Linux: held where no vendor judges them

    silent = []                    # servers the engine cannot judge now (stopped reporting, or unknown)
    for m in match_confirmed(conn, cid, silent):
        m.setdefault("tool", "own")
        cand.append((m, None, "vendor advisory, checked on the server"))
    excluded.extend(silent)
    for m in match_wsus_missing(conn, cid):
        m.setdefault("tool", "windows_update")
        cand.append((m, None, "Windows Update on the server"))
        platforms.add("windows")

    cpes = [c for c in (cve.get("cpes") or []) if isinstance(c, dict)]
    on = running_on(cpes)
    products = exposure.products_from_cpes(cpes)[:MAX_PRODUCTS]
    # r137: the vendor's own CVE record (CVE.org): its products and versions, besides NVD's
    cna = [p for p in (cve.get("cna_products") or []) if isinstance(p, dict)][:MAX_PRODUCTS]
    used = []
    if products:
        used.append("NVD: " + ", ".join(sorted({p["vendor"].replace("_", " ") + " " + p["product"].replace("_", " ")
                                                   for p in products})[:4]))
    if cna:
        used.append("CVE.org (the vendor's record" + (", " + cve["cna_assigner"] if cve.get("cna_assigner") else "") + "): "
                    + ", ".join(sorted({p["label"] for p in cna})[:4]))
    appl_products = []
    for p in products + cna:
        if p["kind"] in ("Network device or appliance", "Hardware or firmware"):
            appl_products.append(p)
            # A network maker's program (FortiClient, Secure Client, GlobalProtect) is checked on Windows too
            if not (p.get("also_program") or (p.get("part") == "a" and p["kind"] == "Network device or appliance")):
                continue
        if p.get("source") == "cve.org":
            if p["kind"] in ("Network device or appliance", "Hardware or firmware") and not p.get("also_program"):
                continue
            plat = " ".join(p.get("platforms") or []).lower()
            if plat and "windows" not in plat:
                continue                   # the vendor lists other platforms only (Linux packages are the distributions')
            scope, why = {"windows"}, "the vendor's CVE record"
        else:
            scope, why = cpe_scope(p, on)
        if scope is None:
            if p["kind"] not in ("Network device or appliance", "Hardware or firmware"):
                notes.append(why)
            continue
        if p["kind"] in ("Network device or appliance", "Hardware or firmware") and "windows" not in scope:
            continue
        platforms |= scope
        if p["kind"] in ("Network device or appliance", "Hardware or firmware"):
            found, aside, pairs = match_windows_programs(inv, p)
            excluded.extend(aside)
            to_confirm.extend(pairs)
            for m in found:
                m.setdefault("tool", "own")
                cand.append((m, scope, why))
            continue
        if p["kind"] in ("Hypervisor (ESXi)", "vCenter"):
            found = exposure.find_in_inventory(conn, [p])
        elif p["kind"] == "Application" and "windows" in scope:
            # r110: only a program proven to be this product is compared; one that may be it is asked about
            found, aside, pairs = match_windows_programs(inv, p)
            excluded.extend(aside)
            to_confirm.extend(pairs)
            # r111: what Carbon Black saw running, by the same proof rules
            cb_found, cb_aside, cb_pairs = match_carbon_black(inv, p)
            found = found + cb_found
            excluded.extend(cb_aside)
            to_confirm.extend(x for x in cb_pairs if (x["vendor"], x["product"], x["family"], x["publisher"])
                              not in {(y["vendor"], y["product"], y["family"], y["publisher"]) for y in to_confirm})
        else:
            found = []                     # Windows itself: the OS build check; Linux: the vendors' checks
            if p["kind"] == "Application" and any(x in ("linux", "rpm") or x.startswith("distro:") for x in scope):
                linux_products.append(p)
        for m in found:
            m.setdefault("tool", "own")
            if m.get("certainty") in ("in_range", "seen_running"):
                cand.append((m, scope, why))
            elif m.get("certainty") in ("release_match", "present") and m.get("name"):
                excluded.append({"name": m["name"], "product": m.get("product"), "unproven": True,
                                 "reason": m.get("detail") or "the exact patch level could not be compared"})

    from . import msrc
    ms_ours, ms_apps = set(), set()
    for prod in [x for x in (cve.get("ms_products") or []) if isinstance(x, str)][:MAX_PRODUCTS]:
        if MS_NOT_OURS.search(prod):
            notes.append(f"Microsoft: {prod} is not a platform we run")
            continue
        platforms.add("windows")          # Windows' own fix is found by the OS build and Windows Update checks
        m = msrc.SERVER_RE.match(prod)
        if m and msrc.MAJOR.get(m.group(1)) in inv.win_majors():
            ms_ours.add(prod)
        elif not prod.lower().startswith("windows") and ms_app_installed(inv, prod):
            ms_apps.add(prod)
    # NVD's own Windows Server products count too (when Microsoft's feed item is missing)
    for c in cpes:
        pc = exposure.parse_cpe(c.get("criteria")) if c.get("vulnerable", True) else None
        mm = pc and pc["vendor"] == "microsoft" and re.match(r"^windows_server_(2012|2016|2019|2022|2025)", pc["product"])
        if mm and int(mm.group(1)) in inv.win_majors():
            ms_ours.add("Windows Server " + mm.group(1))
    ms_missing = bool(ms_ours) and not conn.execute(
        """SELECT 1 FROM advisory_cves ac JOIN advisories a ON a.id = ac.advisory_id AND a.os_id = 'windows'
            WHERE ac.cve_id = %s LIMIT 1""", (cid,)).fetchone()
    if ms_missing:
        notes.append("Microsoft lists it for " + ", ".join(sorted(ms_ours)[:3]) + ", which we run, but its update is not "
                     "imported into PATCH-01 yet: the servers' builds cannot be compared until it is (the next sync imports it)")

    not_judged, rh_decided = [], set()
    rh_fixed = [x for x in (cve.get("rh_products") or []) if isinstance(x, str)][:MAX_PRODUCTS]
    rh_comps = [x for x in (cve.get("rh_components") or []) if isinstance(x, str)][:10]
    if rh_fixed or rh_comps:
        rm, rx, rn, rh_decided = match_redhat(conn, cid, rh_fixed, rh_comps)
        if rm or rh_fixed or rx:
            platforms.add("rpm")
        for m in rm:
            m.setdefault("tool", "own")
        cand.extend((m, {"rpm"}, "Red Hat security data") for m in rm if m.get("certainty") in REAL)
        # Installed, but Red Hat's build for that release not read yet: never clean (r110)
        excluded.extend({"name": m["name"], "product": m.get("product"), "unproven": True,
                         "reason": m.get("detail") or "Red Hat's fixed build for this release is not known yet"}
                        for m in rm if m.get("certainty") not in REAL and m.get("name"))
        excluded.extend(x for x in rx if not x.get("not_judged"))
        not_judged = [x for x in rx if x.get("not_judged")]
        notes.extend(rn)

    # Machines the vendor's advisory proves at the fixed build: "checked, not affected" (r110)
    for r in conn.execute(
            """SELECT DISTINCT h.hostname, ha.package_name, ha.installed_evr, ha.fixed_evr, ha.advisory_id::text AS adv
                 FROM advisory_cves ac JOIN host_applicability ha ON ha.advisory_id = ac.advisory_id
                 JOIN hosts h ON h.id = ha.host_id AND h.status <> 'decommissioned'
                WHERE ac.cve_id = %s AND ha.state = 'fixed_active' AND h.status <> 'stale'
                  AND h.last_inventory >= now() - make_interval(hours => %s::int) LIMIT 2000""",
            (cid, _stale_h())).fetchall():
        excluded.append({"name": r["hostname"], "product": r["package_name"], "fixed": True, "own": True,
                         "reason": f"{r['package_name']} {r['installed_evr'] or ''} is at the vendor's fixed build "
                                   f"{r['fixed_evr'] or ''} ({r['adv']})"})
    if linux_products:
        vendor_judged = rh_decided | {short(m.get("name")) for m, _, _ in cand} | {short(x.get("name")) for x in excluded}
        excluded.extend(match_linux_unjudged(conn, cid, linux_products, vendor_judged))

    # r111: the tools cross-checked. A finding of the outside tool (Carbon Black) made before
    # PATCH-01's own newer proof of the fix on that machine is not a finding: the newest proof wins
    cand, cross = crosscheck(inv, cand, excluded)
    # r137: NVD and the vendor's own record (CVE.org) on the same program and machine: when one proves it
    # affected and the other puts it outside its ranges, affected stands and the disagreement is listed
    outside_by = {}
    for e in excluded:
        if e.get("fixed") and e.get("own"):
            outside_by.setdefault((short(e.get("name")), _pk(e.get("product"))), e)
    for m, _, _ in cand:
        src = m.get("source") or "nvd"
        e = outside_by.get((short(m.get("name")), _pk(m.get("product"))))
        if e and m.get("certainty") == "in_range" and m.get("kind") == "Application":
            other = "NVD" if src == "cve.org" else "the vendor's CVE record"
            cross["disagree"].append({"name": m.get("name"), "tool": src,
                                      "detail": f"{'the vendor’s CVE record' if src == 'cve.org' else 'NVD'} puts {m.get('version') or 'the installed version'} "
                                                f"inside its affected range; {other} says {e.get('reason') or 'outside'}: affected stands, check the vendor's page"})

    kept = []
    for m, scope, basis in cand:
        if not m.get("name"):
            continue
        a = assets.lookup(m["name"], m.get("where"))
        tag(m, a, basis)
        if scope is None:
            kept.append(m)                # the server's own check: it stands
            continue
        fam = a["family"] if a else WHERE_FAMILY.get(m.get("where") or "", "unknown")
        if fits(scope, fam, a["distro"] if a else None):
            kept.append(m)
        elif fam != "unknown":
            excluded.append({"name": m["name"], "product": m.get("product"),
                             "reason": f"the vulnerable product runs on {scope_words(scope)}; this machine runs "
                                       f"{m.get('os') or PLATFORM_NAMES.get(fam, fam)}"})
    for m in kept:
        try:
            sp = support_of(inv, m)
        except Exception:  # noqa: BLE001 - before schema 048: no rules, no state
            sp = None
        if sp:
            m["support"] = sp
    lines = _machine_lines(kept)
    found_on = {short(m.get("name")) for m in lines}

    # One line per machine. A machine counts as fixed only when everything found on it is fixed:
    # one product not proven (another program, a kernel whose running build is unknown) makes it
    # "cannot tell", whichever came first (r110)
    by_host = {}
    for e in excluded:
        k = short(e.get("name"))
        if k and k not in found_on:
            by_host.setdefault(k, []).append(e)
    fixed = []
    for k, es in by_host.items():
        mine = [x for x in es if not x.get("outside")]
        es = mine or es                       # Carbon Black's "cannot tell" never outweighs PATCH-01's own evidence
        e = (next((x for x in es if x.get("unproven") or x.get("silent") or x.get("undecided")), None)
             or next((x for x in es if x.get("fixed")), None) or es[0])
        a = assets.lookup(e.get("name"), "Linux server")
        fixed.append({"name": e.get("name"), "ip": ", ".join(a["ips"]) if a and a["ips"] else None,
                      "os": a["os"] if a else None, "product": e.get("product"), "reason": e.get("reason"),
                      "unproven": bool(e.get("unproven")), "fixed": bool(e.get("fixed")),
                      "silent": bool(e.get("silent")), "undecided": bool(e.get("undecided")),
                      "to_confirm": bool(e.get("to_confirm"))})

    devs = devices if devices is not None else (appliances(conn, max_age=600) if appl_products else [])
    decisions = cve.get("_device_decisions")
    if decisions is None and appl_products and devs:
        decisions = device_decisions(conn)
    appl = match_appliances(devs, appl_products, decisions) if appl_products and devs else []
    seen_a, appl_lines = set(), []
    rank = {"affected": 0, "check": 1, "confirm": 2}
    for x in sorted(appl, key=lambda x: (rank.get(x["state"], 3), (x.get("name") or "").lower())):
        # one line per device and product (NVD and the vendor's record may both name it)
        k = (short(x.get("name")), x.get("cve_product") or x.get("product"))
        if k not in seen_a:
            seen_a.add(k)
            appl_lines.append(x)
    if appl_products:
        platforms.add("network")

    undecided_hosts = {short(x.get("name")) for x in not_judged} - found_on - {short(f.get("name")) for f in fixed if f["fixed"]}
    verdict = impact_verdict(lines, fixed, undecided_hosts)
    # r110: "not in our environment" only when there was something to look for. A CVE no source has
    # described the products of yet (NVD's analysis can take days), or one whose Microsoft update is
    # not imported, is "no data yet", never clean
    no_products = not cpes and not cna and not cve.get("ms_products") and not rh_fixed and not rh_comps
    if ms_apps and not cpes:
        notes.append("Microsoft lists it for " + ", ".join(sorted(ms_apps)[:3]) + ", installed here; its versions are "
                     "compared once NVD lists the affected versions (Windows Update's missing updates count before)")
    if verdict == "not_found" and (no_products or ms_missing or (ms_apps and not cpes)):
        verdict = "no_data"
        if no_products:
            notes.insert(0, "No product data yet: NVD has not listed the affected products, the vendor's CVE record "
                            "names none we can compare, and neither Microsoft nor Red Hat lists it. Checked again at every sync")
    plat = sorted(PLATFORM_NAMES.get(x, x.replace("distro:", "").upper()) for x in platforms)
    cross_finish(cross, lines, inv)
    plan = make_plan(conn, cve, kept, lines, cross)
    if cve.get("ms_products"):
        used.append("Microsoft: " + ", ".join([x for x in cve["ms_products"] if isinstance(x, str)][:3]))
    if rh_fixed or rh_comps:
        used.append("Red Hat: " + ", ".join((rh_fixed or rh_comps)[:4]))
    if cve.get("ssvc_exploitation") or cve.get("kev_added"):
        used.append("CISA: exploitation " + str(cve.get("ssvc_exploitation") or "not assessed")
                    + (", automatable " + cve["ssvc_automatable"] if cve.get("ssvc_automatable") else "")
                    + (", technical impact " + cve["ssvc_impact"] if cve.get("ssvc_impact") else "")
                    + (", in KEV since " + str(cve["kev_added"]) if cve.get("kev_added") else ""))
    plan["sources"] = used[:8]
    return verdict, len(lines), lines[:200], {"platforms": plat, "excluded": fixed[:80], "notes": notes[:10],
                                              "appliances": appl_lines[:100], "to_confirm": to_confirm[:60],
                                              "crosscheck": cross, "plan": plan}


# ---------------------------------------------------------------------------
# The worker's pass
# ---------------------------------------------------------------------------

ASSESS_KEEP_DAYS = 90         # r137: an open assessment is checked again with the Detected CVEs this long

# r137: one list of CVEs to check, from the feeds' window and from the open assessments. A CVE is
# analysed the same way, and its one result stored here, whichever brought it in.
CANDIDATES = """
    WITH watched AS (
        SELECT DISTINCT ai.cve_id FROM cve_assessment_items ai JOIN cve_assessments a ON a.id = ai.assessment_id
         WHERE a.closed_at IS NULL AND a.created_at > now() - make_interval(days => %(keep)s::int)),
    feed AS (
        SELECT i.cve_id,
               max(i.cvss) AS cvss,
               (array_agg(i.severity ORDER BY i.cvss DESC NULLS LAST))[1] AS severity,
               -- CISA's list counts for every CVE (r137), not only those an advisory lists
               bool_or(i.exploited) OR coalesce((SELECT d.kev FROM cve_details d WHERE d.cve_id = i.cve_id), false) AS exploited,
               min(i.published) AS published,
               (array_agg(i.title ORDER BY (i.source = 'nist') DESC))[1] AS title,
               (array_agg(i.summary ORDER BY (i.source = 'nist') DESC))[1] AS summary,
               array_agg(DISTINCT i.source) AS sources,
               (array_agg(i.cpes) FILTER (WHERE i.cpes IS NOT NULL))[1] AS cpes,
               (SELECT x.products FROM cve_feed_items x WHERE x.cve_id = i.cve_id AND x.source = 'msrc') AS ms_products,
               (SELECT x.products FROM cve_feed_items x WHERE x.cve_id = i.cve_id AND x.source = 'redhat') AS rh_products,
               (SELECT x.components FROM cve_feed_items x WHERE x.cve_id = i.cve_id AND x.source = 'redhat') AS rh_components
          FROM cve_feed_items i
         WHERE i.published >= now() - make_interval(days => %(days)s::int)
         GROUP BY i.cve_id)
    SELECT f.*, (f.cve_id IN (SELECT cve_id FROM watched)) AS watched
      FROM feed f
     WHERE f.exploited OR coalesce(f.cvss, 0) >= 7 OR lower(coalesce(f.severity, '')) IN ('critical', 'high', 'important')
        OR f.cve_id IN (SELECT cve_id FROM watched)
        OR (%(cveorg)s AND EXISTS (SELECT 1 FROM cve_org o WHERE o.cve_id = f.cve_id
                                     AND (o.cvss >= 7 OR o.ssvc_exploitation = 'active')))
    UNION ALL
    SELECT w.cve_id, d.cvss_score, lower(d.cvss_severity),
           coalesce(d.kev, false) OR EXISTS (SELECT 1 FROM cve_feed_items x WHERE x.cve_id = w.cve_id AND x.exploited),
           d.published, left(d.description, 300), left(d.description, 1500), ARRAY['assessment']::text[],
           coalesce((SELECT x.cpes FROM cve_feed_items x WHERE x.cve_id = w.cve_id AND x.cpes IS NOT NULL LIMIT 1), d.cpes),
           (SELECT x.products FROM cve_feed_items x WHERE x.cve_id = w.cve_id AND x.source = 'msrc'),
           (SELECT x.products FROM cve_feed_items x WHERE x.cve_id = w.cve_id AND x.source = 'redhat'),
           (SELECT x.components FROM cve_feed_items x WHERE x.cve_id = w.cve_id AND x.source = 'redhat'),
           true
      FROM watched w LEFT JOIN cve_details d ON d.cve_id = w.cve_id
     WHERE w.cve_id NOT IN (SELECT cve_id FROM feed)"""


def candidate_params(conn, days):
    """The parameters CANDIDATES takes."""
    return {"days": int(days), "keep": ASSESS_KEEP_DAYS, "cveorg": sources_mode(conn) == "on"}


def sources_mode(conn):
    """The new sources (CVE.org, Oracle's OVAL): 'off', 'shadow' (read, compared, verdicts unchanged)
    or 'on'. 'off' before schema 072."""
    try:
        with conn.transaction():
            r = conn.execute("SELECT new_sources FROM cve_feed_settings WHERE id = 1").fetchone()
        return (r or {}).get("new_sources") or "off"
    except Exception:  # noqa: BLE001 - schema 072 not applied
        return "off"


def _org_rows(conn, ids):
    try:
        with conn.transaction():
            return {r["cve_id"]: dict(r) for r in conn.execute(
                "SELECT * FROM cve_org WHERE cve_id = ANY(%s) AND NOT not_found AND error IS NULL", (list(ids),)).fetchall()}
    except Exception:  # noqa: BLE001 - schema 072 not applied
        return {}


def inputs(c, org, mode):
    """(what the verdict is worked out from, what the new sources would add in shadow or None).
    The vendor's CVE record (CVE.org) adds its products and versions, CISA's assessment, and its
    score where the feeds have none."""
    from . import cve_org
    base = dict(c)
    if isinstance(base.get("cpes"), str):
        base["cpes"] = json.loads(base["cpes"])
    if not isinstance(base.get("cpes"), list):
        base["cpes"] = []
    extra = {}
    if org and mode in ("shadow", "on"):
        prods = cve_org.products(org)
        if prods:
            extra["cna_products"], extra["cna_assigner"] = prods, org.get("assigner")
        for k in ("ssvc_exploitation", "ssvc_automatable", "ssvc_impact", "kev_added"):
            if org.get(k):
                extra[k] = org[k]
        if base.get("cvss") is None and org.get("cvss") is not None:
            extra["cvss"] = float(org["cvss"])
            extra["severity"] = base.get("severity") or org.get("cvss_severity")
            extra["cvss_vector"] = org.get("cvss_vector")
        if org.get("ssvc_exploitation") == "active" or org.get("kev_added"):
            extra["exploited"] = True
    if mode == "on":
        return dict(base, **extra), None
    if mode == "shadow" and extra:
        return base, dict(base, **extra)
    return base, None


def has_product_data(c):
    return bool(c.get("cpes") or c.get("cna_products") or c.get("ms_products") or c.get("rh_products")
                or c.get("rh_components"))


def add_rh_state(conn, c, fetch=False):
    """Red Hat's own answer for this CVE on RHEL 8 and 9 (rh_state: fixed builds, components), added to
    what the feeds say. fetch: read it from Red Hat when not cached (an assessment's first look)."""
    from . import rh_state
    rh_p = [x for x in (c.get("rh_products") or []) if isinstance(x, str)]
    rh_c = [x for x in (c.get("rh_components") or []) if isinstance(x, str)]
    try:
        with conn.transaction():
            st = rh_state.get(conn, c["cve_id"])
            if fetch and (st is None or st.get("error")):
                rh_state.fetch_one(conn, c["cve_id"])
                st = rh_state.get(conn, c["cve_id"])
        if st and st.get("found"):
            rh_p += sorted({f["package"] for f in st["fixed"]} - set(rh_p))
            rh_c += sorted({x["package"] for x in st["states"]} - set(rh_c))
    except Exception as e:  # noqa: BLE001 - the other sources still decide
        log.info("Red Hat state for %s: %s", c.get("cve_id"), e)
    c["rh_products"], c["rh_components"] = rh_p, rh_c
    return c


def shadow_of(verdict, machines, lines, info):
    appl = info.get("appliances") or []
    return {"verdict": verdict, "machines": machines,
            "names": sorted({m.get("name") for m in lines if m.get("name")})[:50],
            "appliance_state": "affected" if any(x["state"] == "affected" for x in appl) else ("check" if appl else None),
            "appliances": sorted({x.get("name") for x in appl if x.get("state") == "affected" and x.get("name")})[:30],
            "priority": (info.get("plan") or {}).get("priority"),
            "sources": (info.get("plan") or {}).get("sources") or []}


def analyse_store(conn, c, inv, devices, mark, mode, org=None):
    """One CVE analysed and its one result stored (the pass and an assessment's first look both call
    this). In shadow, the new sources' result is stored beside it. Returns (verdict, machines, lines,
    info, has_data)."""
    base, extra = inputs(c, org, mode)
    try:
        with conn.transaction():          # one bad CVE must not stop the others
            verdict, machines, matches, info = analyse_one(conn, base, inv, devices)
    except Exception as e:  # noqa: BLE001 - recorded, and retried at the next pass
        log.warning("impact: %s could not be analysed: %s", c.get("cve_id"), e)
        verdict, machines, matches, info = failed_result(e)
    appl = info.get("appliances") or []
    astate = "affected" if any(x["state"] == "affected" for x in appl) else ("check" if appl else None)
    # A failed analysis keeps no inventory mark, so the next pass takes it again
    row_mark = None if info.get("failed") else mark
    try:
        with conn.transaction():
            _store_impact(conn, base, verdict, machines, matches, info, appl, astate, row_mark)
    except Exception as e:  # noqa: BLE001 - one CVE that cannot be stored never stops the others (r140)
        # Before r140 this raised, and the pass stopped at that CVE: it was never stored, so it came first
        # again at every pass and no CVE after it was ever analysed (the page emptied as the window moved on)
        PASS["store_errors"] += 1
        PASS["error"] = f"{c.get('cve_id')}: its result could not be stored: {str(e)[:200]}"
        log.warning("impact: %s: result not stored: %s", c.get("cve_id"), e)
        verdict, machines, matches, info = failed_result(e)
        appl, astate = [], None
        try:
            with conn.transaction():
                _store_impact(conn, base, verdict, machines, matches, info, appl, astate, None)
        except Exception:  # noqa: BLE001 - schema 050/056 not applied: 'unknown' not allowed yet
            # Never left showing an older, cleaner answer: no row is "not analysed yet"
            with conn.transaction():
                conn.execute("DELETE FROM cve_impact WHERE cve_id = %s", (c["cve_id"],))
    sh = None
    if extra is not None:
        try:
            with conn.transaction():
                sh = shadow_of(*analyse_one(conn, extra, inv, devices))
        except Exception as e:  # noqa: BLE001 - the shadow never stops the real result
            log.info("impact: %s shadow: %s", c.get("cve_id"), e)
    try:
        with conn.transaction():
            conn.execute("UPDATE cve_impact SET shadow = %s WHERE cve_id = %s",
                         (json.dumps(sh, default=str) if sh else None, c["cve_id"]))
    except Exception:  # noqa: BLE001 - schema 072 not applied
        pass
    return verdict, machines, matches, info, has_product_data(base)


# The last pass, for the page (r140): when, how many, and what went wrong
PASS = {"store_errors": 0, "cve_errors": 0, "error": None}


def analyse_pass(conn, limit=BATCH):
    """Analyse CVEs never analysed first, then those analysed before the
    inventory changed or more than a day ago, oldest first, so every CVE is
    reached. A CVE in an open assessment updates that assessment too (r137).
    Returns how many were analysed."""
    from . import assess, cve_feeds
    s = cve_feeds.settings(conn)
    days = int(s.get("days_back") or 14)
    mark = inventory_mark(conn)
    mode = sources_mode(conn)
    rows = conn.execute(
        f"""SELECT c.* FROM ({CANDIDATES}) c LEFT JOIN cve_impact x ON x.cve_id = c.cve_id
             WHERE x.cve_id IS NULL OR x.inventory_mark IS DISTINCT FROM %(mark)s
                OR x.analysed_at < now() - make_interval(hours => %(hours)s::int)
             ORDER BY (x.cve_id IS NULL) DESC, x.analysed_at NULLS FIRST,
                      c.exploited DESC, c.cvss DESC NULLS LAST, c.published DESC NULLS LAST
             LIMIT %(limit)s::int""",
        dict(candidate_params(conn, days), mark=mark, hours=REANALYSE_HOURS, limit=int(limit))).fetchall()
    conn.commit()
    inv = Inventory(conn)
    devices = appliances(conn) if rows else []        # the asset inventory, read once a pass
    decisions = device_decisions(conn) if rows else {}
    orgs = _org_rows(conn, [r["cve_id"] for r in rows]) if rows and mode != "off" else {}
    conn.commit()
    n = 0
    PASS.update(store_errors=0, cve_errors=0, error=None)
    for c in rows:
        c = dict(c, _device_decisions=decisions)
        if c.get("watched") and "assessment" in (c.get("sources") or []):
            add_rh_state(conn, c)
        try:
            # its own savepoint: what failed is undone, the CVEs before it (not committed yet) are kept
            with conn.transaction():
                verdict, machines, matches, info, has_data = analyse_store(conn, c, inv, devices, mark, mode, orgs.get(c["cve_id"]))
        except Exception as e:  # noqa: BLE001 - one CVE never stops the others (r140)
            PASS["cve_errors"] += 1
            PASS["error"] = f"{c.get('cve_id')}: {str(e)[:200]}"
            log.warning("impact: %s skipped: %s", c.get("cve_id"), e)
            n += 1
            continue
        if c.get("watched"):
            try:
                with conn.transaction():
                    assess.refresh_cve(conn, c["cve_id"], verdict, matches, info, has_data)
            except Exception as e:  # noqa: BLE001 - the assessment is brought up to date at the next pass
                log.warning("impact: assessments of %s not updated: %s", c["cve_id"], e)
        n += 1
        if n % 25 == 0:
            conn.commit()
    # Old CVEs leave, unless an open assessment still follows them
    conn.execute("""DELETE FROM cve_impact WHERE coalesce(published, analysed_at) < now() - interval '120 days'
                      AND cve_id NOT IN (SELECT ai.cve_id FROM cve_assessment_items ai JOIN cve_assessments a ON a.id = ai.assessment_id
                                          WHERE a.closed_at IS NULL AND a.created_at > now() - make_interval(days => %s::int))""",
                 (ASSESS_KEEP_DAYS,))
    conn.commit()
    snapshot_day(conn, days)
    return n


PRI_ORDER = {"P1": 1, "P2": 2, "P3": 3}


def shadow_report(conn, days):
    """What the new sources would change if they were on (r137): CVE by CVE, from the shadow results the
    pass stored beside the real ones, and the Oracle Linux servers checked with Oracle's OVAL advisories.
    Nothing here changes a verdict."""
    rows = conn.execute(
        """SELECT cve_id, verdict, machines, appliance_state, plan->>'priority' AS priority, matches, shadow
             FROM cve_impact
            WHERE shadow IS NOT NULL
              AND ((published >= now() - make_interval(days => %(days)s::int)
                    AND EXISTS (SELECT 1 FROM cve_feed_items f WHERE f.cve_id = cve_impact.cve_id))
                   OR cve_id IN (SELECT ai.cve_id FROM cve_assessment_items ai JOIN cve_assessments a ON a.id = ai.assessment_id
                                  WHERE a.closed_at IS NULL AND a.created_at > now() - make_interval(days => %(keep)s::int)))
            ORDER BY cve_id""", {"days": int(days), "keep": ASSESS_KEEP_DAYS}).fetchall()
    t = {"cves_read": len(rows), "to_affected": 0, "to_not_affected": 0, "to_cannot_tell": 0, "more_machines": 0,
         "fewer_machines": 0, "appliances_affected": 0, "priority_up": 0}
    changes = []
    for r in rows:
        sh = r["shadow"] if isinstance(r["shadow"], dict) else json.loads(r["shadow"])
        now_names = {m.get("name") for m in (r["matches"] or []) if m.get("name")}
        added = sorted(set(sh.get("names") or []) - now_names)
        why = []
        if sh.get("verdict") != r["verdict"]:
            k = {"affected": "to_affected", "not_affected": "to_not_affected"}.get(sh.get("verdict"), "to_cannot_tell")
            if sh.get("verdict") in ("affected", "not_affected", "unknown", "no_data"):
                t[k] += 1
            why.append(f"{r['verdict']} → {sh.get('verdict')}")
        elif (sh.get("machines") or 0) != (r["machines"] or 0):
            t["more_machines" if (sh.get("machines") or 0) > (r["machines"] or 0) else "fewer_machines"] += 1
            why.append(f"machines {r['machines'] or 0} → {sh.get('machines') or 0}")
        if sh.get("appliance_state") == "affected" and r["appliance_state"] != "affected":
            t["appliances_affected"] += 1
            why.append("appliance affected: " + ", ".join(sh.get("appliances") or [])[:120])
        if sh.get("priority") and PRI_ORDER.get(sh["priority"], 9) < PRI_ORDER.get(r["priority"] or "", 9):
            t["priority_up"] += 1
            why.append(f"priority {r['priority'] or '-'} → {sh['priority']}")
        if why:
            changes.append({"cve_id": r["cve_id"], "change": "; ".join(why), "added": added[:10],
                            "sources": (sh.get("sources") or [])[:3]})
    more = conn.execute(
        f"""SELECT count(*) AS n FROM cve_org o
             WHERE (o.cvss >= 7 OR o.ssvc_exploitation = 'active')
               AND o.cve_id IN (SELECT cve_id FROM cve_feed_items WHERE published >= now() - make_interval(days => %(days)s::int))
               AND o.cve_id NOT IN (SELECT c.cve_id FROM ({CANDIDATES}) c)""",
        {"days": int(days), "keep": ASSESS_KEEP_DAYS, "cveorg": False}).fetchone()
    from . import cve_engine
    return {"tally": t, "more_cves": int(more["n"] or 0), "changes": changes[:100], "changes_total": len(changes),
            "oracle": cve_engine.oval_preview(conn)}


def request_scan(conn, actor, reason="on-demand vulnerability scan"):
    """Every server whose agent reported in the last day sends its inventory now (an agent
    command), vCenter is read again, and every CVE is checked again as the answers come in.
    Returns the servers asked: [{host_id}] (new commands and those still waiting)."""
    conn.execute(
        """INSERT INTO agent_commands (host_id, verb, params, expires_at)
           SELECT h.id, 'collect_inventory', jsonb_build_object('reason', %s::text), now() + interval '3 hours'
             FROM hosts h
            WHERE h.status <> 'decommissioned' AND h.last_checkin > now() - interval '1 day'
              AND NOT EXISTS (SELECT 1 FROM agent_commands c WHERE c.host_id = h.id AND c.verb = 'collect_inventory'
                                AND c.claimed_at IS NULL AND c.expires_at > now())""", (reason[:100],))
    n = conn.execute("""SELECT DISTINCT host_id FROM agent_commands WHERE verb = 'collect_inventory'
                           AND claimed_at IS NULL AND expires_at > now()""").fetchall()
    conn.execute("UPDATE vcenters SET sync_requested_at = now()")
    conn.execute("""UPDATE cve_feed_settings SET scan_requested_at = now(), scan_requested_by = %s, scan_servers = %s,
                           impact_requested_at = now(), inventory_changed_at = now() WHERE id = 1""", (actor, len(n)))
    return n


def failed_result(e):
    """(verdict, machines, matches, info) for a CVE whose analysis raised: unknown, never
    clean, marked failed so it is not taken as done."""
    return "unknown", 0, [], {"platforms": [], "excluded": [], "appliances": [], "failed": True,
                              "notes": ["could not be analysed (tried again at the next pass): " + str(e)[:160]]}


def _clean(v):
    """A NUL character taken out (r140): PostgreSQL's text and jsonb refuse it, and some programs'
    registry names and vendors' texts carry one."""
    if isinstance(v, str):
        return v.replace("\x00", "")
    if isinstance(v, dict):
        return {(_clean(k) if isinstance(k, str) else k): _clean(x) for k, x in v.items()}
    if isinstance(v, list):
        return [_clean(x) for x in v]
    if isinstance(v, tuple):
        return tuple(_clean(x) for x in v)
    return v


def _store_impact(conn, c, verdict, machines, matches, info, appl, astate, mark):
    c = dict(c, **{k: _clean(c.get(k)) for k in ("title", "severity", "sources")})
    matches, info, appl = _clean(matches), _clean(info), _clean(appl)
    conn.execute(
        """INSERT INTO cve_impact (cve_id, verdict, machines, matches, title, severity, cvss, exploited, sources,
                                   published, inventory_mark, platforms, excluded, appliances, appliance_state, analysed_at,
                                   to_confirm, plan)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, now(), %s, %s)
           ON CONFLICT (cve_id) DO UPDATE SET verdict=EXCLUDED.verdict, machines=EXCLUDED.machines,
             appliances=EXCLUDED.appliances, appliance_state=EXCLUDED.appliance_state,
             matches=EXCLUDED.matches, title=EXCLUDED.title, severity=EXCLUDED.severity, cvss=EXCLUDED.cvss,
             exploited=EXCLUDED.exploited, sources=EXCLUDED.sources, published=EXCLUDED.published,
             inventory_mark=EXCLUDED.inventory_mark, platforms=EXCLUDED.platforms, excluded=EXCLUDED.excluded,
             to_confirm=EXCLUDED.to_confirm, plan=EXCLUDED.plan,
             -- a brief written from other findings is withdrawn until AI-01 rewrites it
             ai_summary = CASE WHEN cve_impact.verdict = EXCLUDED.verdict AND cve_impact.matches = EXCLUDED.matches
                               THEN cve_impact.ai_summary END,
             ai_key = CASE WHEN cve_impact.verdict = EXCLUDED.verdict AND cve_impact.matches = EXCLUDED.matches
                           THEN cve_impact.ai_key END,
             analysed_at=now()""",
        (c["cve_id"], verdict, machines, json.dumps(matches, default=str), (c.get("title") or "")[:300],
         c.get("severity"), c.get("cvss"), bool(c.get("exploited")), c.get("sources") or [],
         c.get("published"), mark, info["platforms"],
         json.dumps({"machines": info["excluded"], "notes": info["notes"]}, default=str),
         json.dumps(appl, default=str), astate, json.dumps(info.get("to_confirm") or [], default=str),
         json.dumps(info.get("plan") or {}, default=str)))


def snapshot_day(conn, days):
    """Today's figures, for the graphs (kept a year)."""
    try:
        with conn.transaction():
            r = conn.execute(
                """WITH w AS (SELECT * FROM cve_impact WHERE published >= now() - make_interval(days => %s::int)
                                AND EXISTS (SELECT 1 FROM cve_feed_items f WHERE f.cve_id = cve_impact.cve_id))
                   SELECT count(*) FILTER (WHERE verdict = 'affected') AS affected,
                          count(*) FILTER (WHERE verdict = 'affected' AND exploited) AS exploited,
                          count(*) FILTER (WHERE verdict = 'affected' AND (lower(coalesce(severity, '')) = 'critical'
                                                                          OR coalesce(cvss, 0) >= 9)) AS critical,
                          -- r136: high is high (or important, or CVSS 7 to 8.9), as the page's severity graph;
                          -- before it was every affected CVE that was not critical, medium and low included
                          count(*) FILTER (WHERE verdict = 'affected' AND NOT (lower(coalesce(severity, '')) = 'critical'
                                                                              OR coalesce(cvss, 0) >= 9)
                                                  AND (lower(coalesce(severity, '')) IN ('high', 'important')
                                                       OR coalesce(cvss, 0) >= 7)) AS high,
                          (SELECT count(DISTINCT lower(split_part(m->>'name', '.', 1)))
                             FROM w, jsonb_array_elements(w.matches) m WHERE w.verdict = 'affected') AS machines,
                          count(*) FILTER (WHERE appliance_state IS NOT NULL) AS appliances,
                          count(*) AS checked
                     FROM w""", (int(days),)).fetchone()
            conn.execute(
                """INSERT INTO cve_impact_daily (day, affected, exploited, critical, high, machines, appliances, checked, updated_at)
                   VALUES (current_date, %s, %s, %s, %s, %s, %s, %s, now())
                   ON CONFLICT (day) DO UPDATE SET affected=EXCLUDED.affected, exploited=EXCLUDED.exploited,
                     critical=EXCLUDED.critical, high=EXCLUDED.high, machines=EXCLUDED.machines,
                     appliances=EXCLUDED.appliances, checked=EXCLUDED.checked, updated_at=now()""",
                (r["affected"], r["exploited"], r["critical"], r["high"], r["machines"], r["appliances"], r["checked"]))
            conn.execute("DELETE FROM cve_impact_daily WHERE day < current_date - 400")
        conn.commit()
    except Exception as e:  # noqa: BLE001 - schema 045 not applied yet: no history, the page still works
        conn.rollback()
        log.info("impact: daily figures not kept: %s", e)


def exposure_word(status, verdict, lines, appliances, has_data):
    """One word for a CVE in an assessment, by the page's rules: affected only when proven
    (on a server, or an appliance's recorded firmware); a restart still to finish a fix counts
    as affected; never "possibly"."""
    if verdict == "affected" or lines or status in ("affected", "pending_reboot") \
            or any(a.get("state") == "affected" for a in appliances):
        return "affected"
    # A server that cannot be judged (silent, or the engine says unknown) is never "not affected"
    if status == "unknown" or verdict in ("unknown", "no_data"):
        return "no_data"
    if appliances:
        return "appliance_check"           # r137: an appliance still to check is never hidden behind "not affected"
    if verdict == "not_affected" or status in ("patched", "not_applicable"):
        return "not_affected"
    if not has_data and status in (None, "", "no_vendor_data", "unknown"):
        return "no_data"
    return "not_found"


def match_lines(matches, n=12):
    """What AI-01 is told about each match: where, machine, its OS, what was found, how sure."""
    return [f"{m.get('where') or m.get('kind')} {m.get('name') or ''}"
            + (f" [{m['os']}]" if m.get("os") else "")
            + f" {m.get('version') or ''} ({str(m.get('certainty')).replace('_', ' ')})"
            for m in matches if m.get("certainty") != "not_tracked"][:n]


VECTOR_WORDS = {"AV": {"N": "over the network", "A": "from the local network", "L": "with local access", "P": "with physical access"},
                "PR": {"N": "without a login", "L": "with an ordinary login", "H": "with an administrator login"},
                "UI": {"N": "with no user action", "R": "only if a user does something", "P": "only if a user does something",
                       "A": "only if a user does something"}}
CERT_WORDS = {"confirmed": "the vendor's fixed build is missing", "in_range": "its version is in the affected range",
              "seen_running": "Carbon Black saw the affected version running", "no_fix": "affected, no fix from the vendor yet",
              "pending_reboot": "fixed, waiting for a restart"}


def _ai_facts(conn, row):
    """What AI-01 is given for a brief (r111): the facts, the plan worked out from them, each machine
    (name, group, OS, what is installed, which tools found it) and what the tools disagree about."""
    from . import llm
    d = conn.execute("SELECT * FROM cve_details WHERE cve_id = %s", (row["cve_id"],)).fetchone() or {}
    f = conn.execute(
        """SELECT summary, title FROM cve_feed_items WHERE cve_id = %s
            ORDER BY (source = 'nist') DESC LIMIT 1""", (row["cve_id"],)).fetchone() or {}
    matches = row["matches"] if isinstance(row["matches"], list) else json.loads(row["matches"] or "[]")
    plan = row.get("plan") if isinstance(row.get("plan"), dict) else json.loads(row.get("plan") or "{}")
    names = [m.get("name") for m in matches if m.get("name")][:12]
    groups = {short(r["hostname"]): r["host_group"] for r in conn.execute(
        "SELECT hostname, host_group FROM hosts WHERE lower(split_part(hostname, '.', 1)) = ANY(%s)",
        ([short(n) for n in names],)).fetchall()} if names else {}
    vec = _vector(d.get("cvss_vector"))
    words = [VECTOR_WORDS[k][vec[k]] for k in ("AV", "PR", "UI") if vec.get(k) in VECTOR_WORDS[k]]
    cross = plan.get("crosscheck") or {}
    disagree = [x.get("detail") for k in ("disagree", "missed_by_outside", "fixed_since") for x in cross.get(k) or [] if x.get("detail")]
    disagree += [f"only {', '.join(TOOL_NAMES.get(t, t) for t in x.get('tools') or [])} found it on {x.get('name')}"
                 for x in cross.get("outside_only") or []]
    return {"cve_id": row["cve_id"], "cvss": row.get("cvss") or d.get("cvss_score"), "vector_words": ", ".join(words) or None,
            "weakness": ", ".join(filter(None, [d.get("attack_class")] + list(d.get("cwes") or [])[:2])) or None,
            "exploited": bool(row.get("exploited") or d.get("kev")),
            "ransomware": str(d.get("kev_ransomware") or "").lower() == "known",
            "epss_band": llm.epss_band(d.get("epss")) if d.get("epss") is not None else None,
            "priority": plan.get("label"), "priority_why": plan.get("why"),
            "actions": [{"do": a.get("do"), "machines": a.get("n")} for a in (plan.get("actions") or [])[:5]],
            "platforms": row.get("platforms"),
            "machines": [{"name": m.get("name"), "group": groups.get(short(m.get("name"))), "os": m.get("os"),
                          "installed": m.get("version"), "product": m.get("product"), "fixed_in": m.get("fixed"),
                          "found_by": [TOOL_NAMES.get(t, t) for t in (m.get("tools") or ["own"])],
                          "evidence": CERT_WORDS.get(m.get("certainty"), m.get("certainty")),
                          "support": [z.get("evidence") for z in (m.get("support") or [])][:3]} for m in matches[:12]],
            "disagree": disagree[:6],
            "products": sorted({m.get("product") or "" for m in matches if m.get("product")})[:6],
            "description": f.get("summary") or f.get("title") or row.get("title") or ""}


_BRIEF_FAILED = {}
BRIEF_RETRY = 6 * 3600


def ai_pass(conn, limit=AI_PER_PASS):
    """AI-01 briefs for impacted CVEs, most serious first (P1 first). A brief is redone only when
    the facts it was written from change."""
    from . import llm
    if not llm.configured():
        return 0
    rows = conn.execute(
        """SELECT * FROM cve_impact WHERE verdict = 'affected'
            ORDER BY (plan->>'priority') NULLS LAST, exploited DESC, cvss DESC NULLS LAST, published DESC
            LIMIT 60""").fetchall()
    done = 0
    for r in rows:
        if done >= limit:
            break
        f = _ai_facts(conn, dict(r))
        conn.commit()                         # no transaction held open while AI-01 writes
        key = hashlib.sha256(json.dumps(f, sort_keys=True, default=str).encode()).hexdigest()[:24]
        if r.get("ai_key") == key and r.get("ai_summary"):
            continue
        if not llm.background_allowed(conn):
            break                             # a person is using AI-01: the briefs continue on the next round
        if time.time() - _BRIEF_FAILED.get((r["cve_id"], key), 0) < BRIEF_RETRY:
            continue                          # it failed lately with these facts: the others go first
        try:
            text, model = llm.brief_cve(conn, f, wait=30)
        except llm.LLMBusy:
            conn.rollback()
            break                             # AI-01 is busy: the next round
        except Exception as e:  # noqa: BLE001 - the verdict stands without the brief; the next CVE is tried
            log.info("impact: no AI brief for %s: %s", r["cve_id"], e)
            conn.rollback()
            _BRIEF_FAILED[(r["cve_id"], key)] = time.time()
            continue
        conn.execute("UPDATE cve_impact SET ai_summary=%s, ai_model=%s, ai_key=%s, ai_at=now() WHERE cve_id=%s",
                     (text, model, key, r["cve_id"]))
        conn.commit()
        done += 1
    return done

# ---------------------------------------------------------------------------
# Reading, for the console
# ---------------------------------------------------------------------------

# r137: which CVEs a page shows: the feeds' window (the Detected CVEs) or the open assessments'
SCOPES = {
    "feeds": """published >= now() - make_interval(days => %(days)s::int)
                AND EXISTS (SELECT 1 FROM cve_feed_items f WHERE f.cve_id = cve_impact.cve_id)""",
    "assessments": """cve_id IN (SELECT ai.cve_id FROM cve_assessment_items ai JOIN cve_assessments a ON a.id = ai.assessment_id
                                  WHERE a.closed_at IS NULL AND a.created_at > now() - make_interval(days => %(keep)s::int))""",
}


def _scope(scope):
    if scope not in SCOPES:
        raise ValueError("scope is feeds or assessments")
    return SCOPES[scope]


def counts(conn, days, scope="feeds"):
    return conn.execute(
        """SELECT count(*) FILTER (WHERE verdict = 'affected') AS affected,
                  count(*) FILTER (WHERE verdict = 'not_affected') AS not_affected,
                  -- r143: on no server and no appliance (a CVE on an appliance alone is not "not in our environment")
                  count(*) FILTER (WHERE verdict = 'not_found' AND appliance_state IS NULL) AS not_found,
                  count(*) FILTER (WHERE verdict = 'not_found' AND appliance_state IS NOT NULL) AS appliance_only,
                  -- held by a server that cannot be judged, or the analysis failed: never clean
                  count(*) FILTER (WHERE verdict = 'unknown') AS unknown,
                  -- no source has described its products yet (r110)
                  count(*) FILTER (WHERE verdict = 'no_data') AS no_data,
                  count(*) FILTER (WHERE jsonb_array_length(to_confirm) > 0) AS waiting_confirm,
                  -- r111: the tools cross-checked, machine by machine, over the window
                  coalesce(sum(jsonb_array_length(coalesce(plan->'crosscheck'->'agree', '[]'))), 0) AS x_agree,
                  coalesce(sum(jsonb_array_length(coalesce(plan->'crosscheck'->'outside_only', '[]'))), 0) AS x_outside_only,
                  coalesce(sum(jsonb_array_length(coalesce(plan->'crosscheck'->'fixed_since', '[]'))), 0) AS x_fixed_since,
                  coalesce(sum(jsonb_array_length(coalesce(plan->'crosscheck'->'disagree', '[]'))), 0) AS x_disagree,
                  count(*) FILTER (WHERE verdict = 'affected' AND plan->>'priority' = 'P1') AS p1,
                  count(*) FILTER (WHERE appliance_state = 'affected') AS appliances_affected,
                  count(*) FILTER (WHERE appliance_state = 'check') AS appliances_check,
                  count(*) FILTER (WHERE verdict = 'affected' AND exploited) AS exploited_impacting,
                  -- r116: affected CVEs on software past end of life (no more fixes from its vendor)
                  count(*) FILTER (WHERE verdict = 'affected' AND coalesce((plan->'support'->>'eol')::int, 0) > 0) AS eol_impacting,
                  count(*) AS checked,
                  max(analysed_at) AS analysed_at,
                  count(*) FILTER (WHERE ai_summary IS NOT NULL) AS ai_briefs
             FROM cve_impact WHERE """ + _scope(scope), {"days": int(days), "keep": ASSESS_KEEP_DAYS}).fetchone()


LIST_SQL = """SELECT cve_id, verdict, machines, matches, title, severity, cvss, exploited, sources, published,
                     analysed_at, ai_summary, ai_model, ai_at, platforms, excluded, appliances, appliance_state, to_confirm,
                     plan
                FROM cve_impact
               WHERE {scope} AND {where}
               ORDER BY exploited DESC, cvss DESC NULLS LAST, published DESC NULLS LAST
               LIMIT %(limit)s"""


def _lim(limit):
    """None is every row (LIMIT NULL); exports and reports pass it, the page a cap."""
    return None if limit is None else int(limit)


def _list(conn, days, where, limit, scope):
    return conn.execute(LIST_SQL.format(scope=_scope(scope), where=where),
                        {"days": int(days), "keep": ASSESS_KEEP_DAYS, "limit": _lim(limit)}).fetchall()


def listing(conn, days, verdict=None, limit=500, scope="feeds"):
    """The CVEs that affect our servers (only those: proven on at least one machine)."""
    return _list(conn, days, "verdict = 'affected'", limit, scope)


def check_listing(conn, days, limit=500, scope="feeds"):
    """The CVEs we cannot tell about (r110): a server holding the product is silent or not comparable,
    a program may be the product and is not confirmed, or no source has described the products yet."""
    return _list(conn, days, "verdict IN ('unknown', 'no_data')", limit, scope)


def appliance_listing(conn, days, limit=500, scope="feeds"):
    """The CVEs that name an appliance in the asset inventory."""
    return _list(conn, days, "appliance_state IS NOT NULL", limit, scope)


GRAPH_SQL = """SELECT severity, cvss, exploited, machines, matches FROM cve_impact WHERE verdict = 'affected' AND {scope}"""


def _sev(i):
    s = (i.get("severity") or "").lower()
    if i.get("exploited"):
        return "0-day"
    if s == "critical" or float(i.get("cvss") or 0) >= 9:
        return "Critical"
    if s in ("high", "important") or float(i.get("cvss") or 0) >= 7:
        return "High"
    return "Medium or lower"


def graphs(conn, days, items=None, scope="feeds"):
    """What the page's graphs show, from every affected CVE in the window (r136: not only the
    rows the page lists): by severity, the machines by platform, the products most often found,
    and the daily history. A CVE keeps its first 200 machines' lines, so when one has more the
    machine figures are a floor: machines_at_least says so."""
    items = [dict(r) for r in conn.execute(GRAPH_SQL.format(scope=_scope(scope)),
                                           {"days": int(days), "keep": ASSESS_KEEP_DAYS}).fetchall()]
    sev = {k: 0 for k in ("0-day", "Critical", "High", "Medium or lower")}
    plat, prod, machines = {}, {}, {}
    at_least = False
    for i in items:
        sev[_sev(i)] += 1
        if int(i.get("machines") or 0) > len(i.get("matches") or []):
            at_least = True
        for m in i.get("matches") or []:
            k = short(m.get("name"))
            if not k:
                continue
            machines.setdefault(k, m.get("platform") or m.get("where") or "Other")
            for p in (m.get("products") or [m.get("product")]):
                if p:
                    prod.setdefault(p, set()).add(k)
    for k, p in machines.items():
        plat[p] = plat.get(p, 0) + 1
    hist = []
    try:
        if scope == "feeds":                      # the daily history is the feeds' window's
            with conn.transaction():
                hist = [dict(r) for r in conn.execute(
                    """SELECT day, affected, exploited, critical, high, machines, appliances FROM cve_impact_daily
                        WHERE day > current_date - 31 ORDER BY day""").fetchall()]
    except Exception:  # noqa: BLE001 - schema 045 not applied
        hist = []
    return {"severity": [{"label": k, "n": v} for k, v in sev.items()],
            "platforms": [{"label": k, "n": v} for k, v in sorted(plat.items(), key=lambda x: (-x[1], x[0]))],
            "products": [{"label": k, "n": len(v)} for k, v in sorted(prod.items(), key=lambda x: (-len(x[1]), x[0]))[:8]],
            "history": hist, "machines": len(machines), "machines_at_least": at_least, "affected": len(items)}
