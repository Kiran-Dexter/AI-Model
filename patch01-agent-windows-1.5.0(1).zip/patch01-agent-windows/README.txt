PATCH-01 agent for Windows Server 1.5.0-win: deployment kit
===========================================================

One folder, one script per server, for new installs and upgrades alike.

ONCE: sign the scripts (on the PC that has your code-signing certificate)
-------------------------------------------------------------------------
  1. Extract this zip. Put your CA chain (.pem, the one that issued
     PATCH-01's certificate) in the same folder.
  2. PowerShell in that folder:
         .\Sign-Agent.ps1
     Pick your code-signing certificate, give a timestamp server or press
     Enter to skip. It signs every .ps1 (SHA-256), checks them, and saves
     publisher-xxxxxxxx.cer (public part only) for the servers to trust.
     (If that PC itself is AllSigned, sign Sign-Agent.ps1 by hand once:
      see the top of Sign-Agent.ps1.)
  3. Optional, for new servers: on PATCH-01 run
         ./scripts/phase10-windows.sh --tokens 50 <group> > tokens.txt
     and put tokens.txt in the folder. Each new server takes the next
     unused token by itself (tokens are valid 72 hours, one per server).
     Without tokens.txt the script asks you to paste one.
  4. Copy the folder to a share only administrators can read, or to each
     server.

ON EACH SERVER (PowerShell as administrator, in the folder)
-----------------------------------------------------------
         .\Deploy-Agent.ps1

  The first time on a server, Windows may ask whether to run software from
  your publisher: answer R (Run once). The script then offers to trust the
  publisher for the computer, which the agent's SYSTEM task needs.

  It checks the server, the signatures and the execution policy, finds an
  existing agent (UPGRADE, identity kept, no token) or not (NEW), asks for
  PATCH-01's address once (remembered in deploy-settings.json), picks the
  .pem, shows a summary and waits for Y before changing anything. Then it
  installs or upgrades and proves it by running the agent's task as SYSTEM.
  It never changes the execution policy (it only offers to remove a
  CurrentUser override on your own account).

  Do not run it while a patch job is installing on that server (it checks).

RECORDS
-------
  deploy-log.csv     one line per server: when, action, from/to version, result
  tokens-used.csv    which server took which token (a fingerprint only,
                     never the token itself)
  C:\ProgramData\PatchAgent-Deploy\   the full log of each run on that server
  When done, delete tokens.txt from the share.

WHAT 1.5.0 FIXES
----------------
- Precheck crashed on every server with more than 5 GB free ("cannot
  convert ... GB free on C: to type System.Double").
- The install never found the job's updates (the update list reached the
  install step wrapped twice), so nothing was patched.
- More than 1 GB free on C: is enough to go ahead (under 5 GB warns).
- Windows Update service restarted before searching; a failed search is
  retried once after another restart.
- Updates fetched by a fresh search of this server's WSUS at job time
  (optional/preview updates excluded), matched by update ID, then KB.
- Installed one by one; one failed update does not stop the others or fail
  the server. Only "nothing could be installed" fails.
- After the restart each update is checked again; any rolled back is
  reported. A reboot still pending is reported.
- Services running before are compared after; late starters are waited
  for, any still down is started once; one that will not start is a
  warning, not a patch failure.
- No -ExecutionPolicy Bypass anywhere; the task follows the server's policy.
