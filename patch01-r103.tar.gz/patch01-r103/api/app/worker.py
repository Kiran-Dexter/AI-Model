"""
PATCH-01 : the worker

Carries out changes and does the slow work of CVE assessments, in the
background, so nothing waits on a browser request.

Two threads, each with its own database connection:

  changes     starts changes when their window opens, moves each target
              through its steps, and records every step as an event
  enrichment  looks up assessed CVEs in NVD, matches their products against
              the inventory, and asks AI-01 for a brief on each

vCenter calls made for a change (snapshots, their removal, VM actions) run
in short-lived background threads, so a 30-minute vCenter task never stalls
the other changes or the changes heartbeat (see _vc_start).

Only one worker acts at a time, guarded by a PostgreSQL advisory lock, so a
second copy started by mistake waits instead of doubling every action.

A patch target moves through:

  queued -> precheck -> [snapshot] -> install -> [reboot_wait] -> [reboot -> wait_boot]
         -> postcheck -> inventory -> [snapshot_cleanup] -> done

reboot_wait: the job set a restart time of its own (params.reboot_at): the
server has installed and waits for that time. It takes no "at a time" slot
while it waits, so the other servers carry on installing; at the restart time
the waiting servers restart, at most max_parallel at once.

Any failure stops that server at the failing step, keeps its snapshot for
rollback, and leaves the other servers in the change to carry on.

Run:  python -m app.worker
"""

import json
import re
import logging
import os
import signal
import sys
import threading
import time
import traceback
from datetime import datetime, timedelta, timezone

from . import changes as ch

log = logging.getLogger("patchapi.worker")

TICK = int(os.environ.get("WORKER_TICK", "10"))
LOCK_ID = 7_310_442                       # advisory lock: one worker at a time
CLAIM_TIMEOUT = timedelta(minutes=int(os.environ.get("AGENT_CLAIM_MINUTES", "30")))
RUN_TIMEOUT = {"install_packages": timedelta(hours=2), "download_packages": timedelta(hours=1)}
DEFAULT_RUN_TIMEOUT = timedelta(minutes=30)
RUN_ENDED_GRACE = timedelta(seconds=45)


def _agent_tail(conn, host_id, since):
    """The agent's last log lines since a moment, for a failure message."""
    rows = conn.execute(
        """SELECT level, line FROM agent_logs WHERE host_id=%s AND at >= %s - interval '10 seconds'
            ORDER BY id DESC LIMIT 5""", (host_id, since)).fetchall()
    if not rows:
        return "No agent log lines arrived: see the agent's log on the server."
    return "Agent log: " + " | ".join(f"{r['level']} {r['line'][:240]}" for r in reversed(rows))
WINDOWS_INSTALL_TIMEOUT = timedelta(hours=3)
# A long Windows install is not a failure while the agent is still working on it: the agent sends
# its log every 30 s during the install (and "still working" lines when Windows is quiet), so a
# step past its usual limit is waited for as long as that contact keeps coming, up to these caps.
# The agent's own cap is below them (it never stops a busy install before), so its answer arrives.
LIVE_MAX = {"install_packages": timedelta(hours=8)}
LIVE_WITHIN = timedelta(minutes=10)
WINDOWS_PRECHECK_TIMEOUT = timedelta(minutes=130)     # restart, WSUS search (retried once) and the download
WINDOWS_STEP_TIMEOUT = timedelta(minutes=45)          # postcheck (waits for late services) and inventory (a WSUS search)
BOOT_TIMEOUT = timedelta(minutes=int(os.environ.get("BOOT_TIMEOUT_MINUTES", "30")))
# Windows finishes installing cumulative updates during the restart ("Working on updates"): it gets longer
WINDOWS_BOOT_TIMEOUT = timedelta(minutes=int(os.environ.get("WINDOWS_BOOT_TIMEOUT_MINUTES", "75")))

TERMINAL = {"done", "done_with_warnings", "failed", "skipped", "cancelled"}
# States that take no "at a time" slot: not started, finished, or waiting for the job's restart time
BUSY_EXCLUDED = "('queued', 'done', 'done_with_warnings', 'failed', 'skipped', 'cancelled', 'reboot_wait')"

_stop = threading.Event()


# ---------------------------------------------------------------------------
# The patching sequence, as a pure function
# ---------------------------------------------------------------------------

def next_patch_state(state, params, result, has_snapshot):
    """The state after `state` finished successfully with `result`.

    Pure, so the whole sequence can be tested without servers or a database.
    """
    result = result or {}
    if state == "queued":
        return "precheck"
    if state == "precheck":
        if params.get("restart_only"):
            return "reboot"                     # a restart-only job: nothing is installed
        return "snapshot" if params.get("snapshot", "none") != "none" else "install"
    if state == "snapshot":
        return "install"
    if state == "install":
        if result.get("nothing_to_do"):
            return "inventory"
        reboot = params.get("reboot", "if_required")
        if reboot == "always" or (reboot == "if_required" and result.get("reboot_required")):
            return "reboot_wait" if params.get("reboot_at") else "reboot"
        return "postcheck"
    if state == "reboot_wait":
        return "reboot"
    if state == "reboot":
        return "wait_boot"
    if state == "wait_boot":
        return "postcheck"
    if state == "postcheck":
        return "inventory"
    if state == "inventory":
        if params.get("snapshot") == "remove_on_success" and has_snapshot:
            return "snapshot_cleanup"
        return "done"
    if state == "snapshot_cleanup":
        return "done"
    raise ValueError(f"no successor for state {state}")


_SVC_LINUX_RE = re.compile(r"^(?:post-check failed: )?(service [\w@.:-]+ is [\w-]+)(?:; service [\w@.:-]+ is [\w-]+)*$")


def service_only_problem(result):
    """The services that did not come back, when that is the postcheck's only
    problem; otherwise None. Windows agents list them as missing_services and
    "not running any more: ..."; Linux agents as "service X is Y"."""
    errs = [str(e) for e in (result.get("errors") or [])]
    missing = [str(x) for x in (result.get("missing_services") or []) if x]
    if missing and errs and all(e.startswith("not running any more:") for e in errs):
        return missing
    msg = str(result.get("message") or "").strip()
    if _SVC_LINUX_RE.match(msg):
        return re.findall(r"service ([\w@.:-]+) is", msg)
    if errs and all(re.fullmatch(r"service [\w@.:-]+ is [\w-]+", e) for e in errs):
        return [re.match(r"service (\S+)", e).group(1) for e in errs]
    return None


def unchanged_note(params, result):
    """Why a software job changed nothing on a server, in words, with what to do about it."""
    msg = str((result or {}).get("message") or "the agent found nothing to do").strip()
    note = f"nothing was changed: {msg}"
    if (params or {}).get("action") == "upgrade" and "nothing to upgrade" in msg:
        note += (". If the program is installed there, the package's 'name in Programs and Features' does not "
                 "match what the server lists (see Software on the server's page); to put it on servers that do "
                 "not have it, deploy with Install instead of Upgrade")
    elif msg.startswith("already installed"):
        note += ". The package's version is the one already installed: upload the newer version to upgrade"
    return note


def install_did_nothing(params, result):
    """Why an install or upgrade the agent called done did not change the program, or None.
    The agent's 'done' is checked against what it reported before and after: exit code 0 with
    the same (or an older) version afterwards is not an install. A restart that completes it,
    a portable copy, and versions without numbers are left to the agent's own warnings."""
    from . import deploy
    r = result or {}
    if (r.get("nothing_to_do") or r.get("mode") == "portable" or r.get("reboot_required")
            or r.get("action") not in ("install", "upgrade")):
        return None
    before, after = r.get("before"), r.get("after")
    if not after:
        return None              # not listed afterwards: the agent fails that itself
    want = r.get("target_version") or ((params or {}).get("package") or {}).get("version")
    code = r.get("exit_code")
    ran = f"the installer finished (exit code {code})" if code is not None else "the installer finished"
    hint = (". For an EXE, its silent install options may be wrong, or it handed over to another "
            "program and returned at once: see the agent log, and check Software on the server's page")
    if before and deploy.compare_versions(after, before) == 0 and \
            not (want and deploy.compare_versions(after, want) == 0):
        return f"{ran} but nothing changed: the program is still version {after}" + \
               (f", not {want}" if want else "") + hint
    if want and deploy.compare_versions(after, want) == -1:
        return f"{ran} but the program reports version {after}, older than {want}: it was not upgraded" + hint
    return None


def change_outcome(target_states):
    """The final state of a change from the states of its targets."""
    # Patched, but a service did not come back: the patch itself succeeded
    done = sum(1 for s in target_states if s in ("done", "done_with_warnings"))
    failed = sum(1 for s in target_states if s == "failed")
    # A server skipped because the window closed was never patched. Calling
    # the change a success would hide it.
    skipped = sum(1 for s in target_states if s == "skipped")
    # Cancelled servers were not patched either: a job cancelled part way is not a success
    cancelled = sum(1 for s in target_states if s == "cancelled")
    if done and not failed and not skipped and not cancelled:
        return "succeeded"
    if done and (failed or skipped or cancelled):
        return "partially_succeeded"
    if failed:
        return "failed"
    return "cancelled"


def choose_fixed_versions(rows, pkg_manager):
    """One version per package: the highest fixed version any advisory needs.

    Several advisories can fix the same package at different versions;
    installing the newest satisfies all of them.
    """
    from .evr import rpm_label_compare, deb_compare
    cmp = deb_compare if pkg_manager == "apt" else rpm_label_compare

    def split(evr):
        e, _, rest = evr.partition(":") if ":" in evr else ("0", "", evr)
        v, _, r = rest.rpartition("-") if "-" in rest else (rest, "", "")
        return (e or "0", v, r)

    best = {}
    for r in rows:
        name, fixed = r["package_name"], r["fixed_evr"]
        if not name or not fixed:
            continue
        if name not in best or cmp(*split(fixed), *split(best[name])) > 0:
            best[name] = fixed
    return [{"name": n, "version": v} for n, v in sorted(best.items())]


def _linux_security_updates(conn, host_id):
    """The package manager's security updates for this server as install rows, or None
    when its agent has not reported the list (older than 1.8.2: the job falls back)."""
    h = conn.execute("SELECT updates_checked_at FROM hosts WHERE id=%s", (host_id,)).fetchone()
    if not h or not h["updates_checked_at"]:
        return None
    return [dict(r) for r in conn.execute(
        """SELECT name AS package_name, available AS fixed_evr, advisory, severity FROM linux_updates
            WHERE host_id=%s AND security IS NOT FALSE""", (host_id,)).fetchall()]


def _notice_names(rows):
    """package -> the repository's own update notices ("ELSA-2026-1234 (Important)"), for Patch Reports."""
    out = {}
    for r in rows:
        if r.get("advisory"):
            label = r["advisory"] + (f" ({r['severity']})" if r.get("severity") else "")
            out.setdefault(r["package_name"], [])
            if label not in out[r["package_name"]]:
                out[r["package_name"]].append(label)
    return out


def _advisory_names(conn, rows):
    """package -> the advisories it fixes ("RHSA-2026:1234 (important)"), for Patch Reports."""
    ids = sorted({r.get("advisory_id") for r in rows if r.get("advisory_id")})
    if not ids:
        return {}
    sev = {a["id"]: a["severity"] for a in conn.execute(
        "SELECT id, severity FROM advisories WHERE id = ANY(%s)", (ids,)).fetchall()}
    out = {}
    for r in rows:
        a, n = r.get("advisory_id"), r.get("package_name")
        if not a or not n:
            continue
        label = a + (f" ({sev[a]})" if sev.get(a) else "")
        if label not in out.setdefault(n, []):
            out[n].append(label)
    return {k: v[:10] for k, v in out.items()}


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

def _db():
    import psycopg
    from psycopg.rows import dict_row
    return psycopg.connect(
        host=os.environ.get("PATCHDB_HOST", "postgres"),
        port=int(os.environ.get("PATCHDB_PORT", "5432")),
        dbname=os.environ.get("PATCHDB_NAME", "patchdb"),
        user=os.environ.get("PATCHDB_USER", "patchapi"),
        password=os.environ.get("PATCHDB_PASSWORD", ""),
        row_factory=dict_row, connect_timeout=15)


def beat(conn, name, **detail):
    conn.execute(
        """INSERT INTO worker_heartbeat (name, beat_at, detail) VALUES (%s, now(), %s)
           ON CONFLICT (name) DO UPDATE SET beat_at=now(), detail=EXCLUDED.detail""",
        (name, json.dumps(detail, default=str)))
    conn.commit()


# ---------------------------------------------------------------------------
# vCenter work, off the changes thread
#
# A snapshot, its removal or a VM action can take up to 30 minutes per vCenter task. Done inline it
# stalled every other change and the "changes" heartbeat (unhealthy after 180 s). Each call runs in a
# daemon thread of its own instead (at most VCENTER_PARALLEL at once); the changes thread starts it with
# nothing held open, and on later ticks picks up its result and records it. The calls take no database
# connection. Jobs live in this process only: after a worker restart a step left with no job is found by
# its age (SNAPSHOT_STUCK), as before.
# ---------------------------------------------------------------------------

VCENTER_PARALLEL = max(1, int(os.environ.get("VCENTER_PARALLEL", "4") or 4))
_vc_slots = threading.BoundedSemaphore(VCENTER_PARALLEL)
_vc_jobs = {}                      # key -> _VcJob; read and written by the changes thread only
_vc_stop = {}                      # key -> threading.Event: asks a running snapshot removal to stop


class _VcJob:
    def __init__(self):
        self.done = threading.Event()
        self.result = None
        self.error = None


def _vc_start(key, fn, *args):
    """Run fn(*args) in the background. The same key never runs twice at once."""
    job = _vc_jobs.get(key)
    if job is not None and not job.done.is_set():
        return job
    job = _VcJob()

    def run():
        with _vc_slots:
            try:
                job.result = fn(*args)
            except Exception as e:  # noqa: BLE001 - handed to the changes thread
                job.error = e
            finally:
                job.done.set()
    _vc_jobs[key] = job
    threading.Thread(target=run, name=f"vcenter-{key[0]}", daemon=True).start()
    return job


def _vc_finished(key):
    """The job under key once it has finished (and forgets it); None while it runs or when there is none."""
    job = _vc_jobs.get(key)
    if job is None or not job.done.is_set():
        return None
    return _vc_jobs.pop(key)


def _vc_resync(vcenter):
    """Reflect a VM change in the inventory without waiting for the next sync (in the background)."""
    from . import vmware

    def go():
        try:
            vmware.sync(vcenter)
        except Exception as e:  # noqa: BLE001
            log.warning("resync after VM action failed: %s", e)
    for k in [k for k, j in _vc_jobs.items() if k[0] == "sync" and j.done.is_set()]:
        _vc_jobs.pop(k, None)
    _vc_start(("sync", vcenter), go)


def _set(conn, change_id, key, **fields):
    cols = ", ".join(f"{k}=%s" for k in fields)
    conn.execute(f"UPDATE change_targets SET {cols}, updated_at=now() "
                 f"WHERE change_id=%s AND target_key=%s",
                 list(fields.values()) + [change_id, key])


def _detail(conn, change_id, key, **more):
    conn.execute("""UPDATE change_targets SET detail = detail || %s::jsonb, updated_at=now()
                     WHERE change_id=%s AND target_key=%s""",
                 (json.dumps(more, default=str), change_id, key))


def _queue(conn, change, t, verb, params, hours=4):
    row = conn.execute(
        """INSERT INTO agent_commands (host_id, change_id, target_key, verb, params, expires_at)
           VALUES (%s, %s, %s, %s::agent_verb, %s, now() + make_interval(hours => %s))
           RETURNING id""",
        (t["host_id"], change["id"], t["target_key"], verb, json.dumps(params), hours)).fetchone()
    return row["id"]


# ---------------------------------------------------------------------------
# Starting and finishing changes
# ---------------------------------------------------------------------------

def start_due(conn):
    missed = conn.execute(
        """UPDATE changes SET state='cancelled', finished_at=now(),
                  summary = summary || '{"reason": "window missed"}'::jsonb
            WHERE state='scheduled' AND run_before IS NOT NULL AND run_before < now()
        RETURNING id, number""").fetchall()
    for m in missed:
        ch.event(conn, m["id"], None, "worker", "cancelled", False,
                 "The window closed before the change could start.")
        conn.execute("UPDATE change_targets SET state='cancelled' WHERE change_id=%s", (m["id"],))
    started = conn.execute(
        """UPDATE changes SET state='running', started_at=now()
            WHERE id IN (SELECT id FROM changes WHERE state='scheduled' AND run_after <= now()
                          ORDER BY run_after FOR UPDATE SKIP LOCKED LIMIT 20)
        RETURNING id, number, kind""").fetchall()
    for s in started:
        ch.event(conn, s["id"], None, "worker", "started", True, f"{ch.ref(s['number'])} started")
    conn.commit()


def finish_if_done(conn, change):
    states = [r["state"] for r in conn.execute(
        "SELECT state FROM change_targets WHERE change_id=%s", (change["id"],)).fetchall()]
    if not states or any(s not in TERMINAL for s in states):
        return False
    outcome = change_outcome(states)
    summary = {s: states.count(s) for s in set(states)}
    unchanged = 0
    if change.get("kind") == "software":
        unchanged = conn.execute("""SELECT count(*) AS n FROM change_targets WHERE change_id=%s
                                     AND state IN ('done', 'done_with_warnings')
                                     AND (detail->>'nothing_to_do')::boolean IS TRUE""",
                                 (change["id"],)).fetchone()["n"]
        summary["unchanged"] = unchanged
    conn.execute("UPDATE changes SET state=%s, finished_at=now(), summary=summary || %s::jsonb "
                 "WHERE id=%s", (outcome, json.dumps(summary), change["id"]))
    done = summary.get("done", 0) + summary.get("done_with_warnings", 0)
    words = outcome.replace("_", " ")
    if unchanged and unchanged >= done:
        words += f", but nothing was changed on any server ({unchanged} of {len(states)}): see each server's reason"
    elif unchanged:
        words += f"; nothing was changed on {unchanged} of {len(states)} server(s)"
    ch.event(conn, change["id"], None, "worker", "finished",
             outcome == "succeeded" and not (unchanged and unchanged >= done),
             f"{ch.ref(change['number'])} {words}", summary)
    return True


# ---------------------------------------------------------------------------
# Patch changes
# ---------------------------------------------------------------------------

def _fail(conn, change, t, reason, detail=None):
    _set(conn, change["id"], t["target_key"], state="failed", error=reason[:2000],
         current_command=None)
    keep = f" Snapshot {t['snapshot_moref']} was kept for rollback." if t.get("snapshot_moref") else ""
    ch.event(conn, change["id"], t["target_key"], "worker", "failed", False,
             f"{t['label']}: {reason}{keep}", detail or {})


def windows_updates_for(rows, mode, advisory_ids, advisory_cves):
    """Which WSUS-approved missing updates a change installs on a Windows server.

    mode "all": every approved update the server still lacks.
    mode "advisories": updates whose KB was chosen, or that fix any CVE of the
    chosen advisories. Windows updates are cumulative, so the update WSUS has
    approved this month fixes last month's CVEs too, even under another KB.
    Pure, for testing.
    """
    if mode != "advisories":
        return [r for r in rows]
    kbs = {a.upper() for a in advisory_ids or []}
    cves = set(advisory_cves or [])
    return [r for r in rows if (r.get("kb") or "").upper() in kbs or cves & set(r.get("cves") or [])]


def _windows_chosen(conn, t, p):
    """The WSUS-approved missing updates this job installs on this server."""
    rows = conn.execute("SELECT update_id, kb, title, cves FROM windows_updates WHERE host_id=%s",
                        (t["host_id"],)).fetchall()
    cves = []
    if p.get("mode") == "advisories":
        cves = [r["cve_id"] for r in conn.execute(
            "SELECT cve_id FROM advisory_cves WHERE advisory_id = ANY(%s)", (p.get("advisories") or [],)).fetchall()]
    return windows_updates_for(rows, p.get("mode"), p.get("advisories"), cves)


def _windows_params(conn, p, chosen):
    """What the Windows agent needs to pick the job's updates from its own
    fresh WSUS search: the IDs PATCH-01 last saw, their KBs, and the job's
    mode (every approved update, or the chosen advisories' KBs and CVEs)."""
    mode = "advisories" if p.get("mode") == "advisories" else "all"
    kbs = sorted({(r.get("kb") or "").upper() for r in chosen if r.get("kb")}
                 | ({a.upper() for a in (p.get("advisories") or []) if re.fullmatch(r"(?i)KB\d{5,8}", a or "")}
                    if mode == "advisories" else set()))
    cves = []
    if mode == "advisories":
        cves = [r["cve_id"] for r in conn.execute(
            "SELECT cve_id FROM advisory_cves WHERE advisory_id = ANY(%s)", (p.get("advisories") or [],)).fetchall()][:2000]
    return {"windows_updates": [r["update_id"] for r in chosen], "windows_kbs": kbs[:500], "windows_cves": cves,
            "windows_mode": mode, "restart_windows_update": True}


def _is_windows(conn, host_id):
    return bool(conn.execute("SELECT 1 FROM hosts WHERE id=%s AND pkg_manager='wua'", (host_id,)).fetchone())


def _enter_windows_install(conn, change, t, p):
    cid, key = change["id"], t["target_key"]
    chosen = _windows_chosen(conn, t, p)
    wp = _windows_params(conn, p, chosen)
    # "Every approved update": the agent searches WSUS itself at install time, so
    # an out-of-date list here (an old or failed inventory search) never skips a server
    if not chosen and not (wp["windows_mode"] == "all" or wp["windows_cves"] or wp["windows_kbs"]):
        why = ("nothing approved in WSUS is missing" if p.get("mode") != "advisories" else
               "WSUS has not approved an update that fixes the chosen advisories")
        ch.event(conn, cid, key, "worker", "install", True, f"{t['label']}: nothing to install, {why}")
        _detail(conn, cid, key, nothing_to_do=True, windows_note=why)
        return _enter(conn, change, t, next_patch_state("install", p, {"nothing_to_do": True},
                                                        bool(t.get("snapshot_moref"))))
    ids = wp["windows_updates"]
    _detail(conn, cid, key, windows_updates=[{"kb": r["kb"], "title": r["title"]} for r in chosen])
    cmd = _queue(conn, change, t, "install_packages", wp, hours=6)
    _set(conn, cid, key, current_command=cmd)
    ch.event(conn, cid, key, "worker", "install", None,
             f"{t['label']}: installing the Windows updates WSUS offers for this job"
             + (f" ({len(ids)} known: " + ", ".join(r["kb"] or r["title"][:40] for r in chosen[:4])
                + (" and more" if len(ids) > 4 else "") + ")" if ids else ""))


SNAPSHOT_STUCK = timedelta(minutes=45)           # a snapshot (or VM action) still "in progress" after this: the worker restarted mid-way


def _enter_software(conn, change, t, p):
    """Install or upgrade a Deployment package, or remove a listed tool already installed."""
    if p.get("source") == "package":
        return _enter_package(conn, change, t, p)
    if p.get("source") == "installed":
        return _enter_installed(conn, change, t, p)
    # Installers on a share are retired (r90): a job booked before then installs nothing
    return _fail(conn, change, t, "not installed: installers on a share are retired; deploy it from Deployment instead")


def _enter_installed(conn, change, t, p):
    """Remove a listed tool already installed on this server, by its exact Programs and Features
    key. The removable tools list is checked again now (it may have changed since booking)."""
    from . import sw_policy
    cid, key = change["id"], t["target_key"]
    prog = p.get("program") or {}
    # This server's own entry as it is now (the inventory may have changed since booking)
    k = conn.execute("""SELECT publisher, uninstall_key AS key, uninstall_how AS how FROM windows_software
                         WHERE host_id = %s AND name = %s AND version = %s AND arch = %s""",
                     (t["host_id"], prog.get("name"), prog.get("version") or "", prog.get("arch"))).fetchone()
    if not k:
        return _fail(conn, change, t, "not removed: the server no longer reports this program and version (already removed or updated?)")
    try:
        allowed = sw_policy.check(conn, prog.get("name"), k["publisher"])
    except sw_policy.Refused as e:
        return _fail(conn, change, t, f"not removed: {e}")
    if not k["key"] or k["how"] not in sw_policy.HOW:
        return _fail(conn, change, t, "not removed: no silent uninstaller is known for it on this server")
    plan = {"source": "installed", "action": "uninstall", "name": prog.get("name"), "version": prog.get("version") or "",
            "arch": prog.get("arch"), "key": k["key"], "how": k["how"], "allowed": allowed}
    cmd = _queue(conn, change, t, "software_action", plan, hours=6)
    _set(conn, cid, key, current_command=cmd)
    ch.event(conn, cid, key, "worker", "install", None,
             f"{t['label']}: removing {prog.get('name')} {prog.get('version') or ''} with "
             f"{sw_policy.HOW_TEXT.get(k['how'], k['how'])}".rstrip())


def _enter_package(conn, change, t, p):
    """Install or upgrade a package uploaded to PATCH-01 (Deployment). The agent
    downloads it from PATCH-01 itself: no share, no credential."""
    from . import deploy
    cid, key = change["id"], t["target_key"]
    try:
        pkg = deploy.get(conn, p.get("package_id"))
    except deploy.NotFound:
        return _fail(conn, change, t, "its package was removed from PATCH-01 before this server's turn")
    why = deploy.deploy_blocker(deploy.view(pkg), p["action"])
    if why:
        return _fail(conn, change, t, f"the package cannot be deployed: {why}")
    if p["action"] == "uninstall":
        from . import sw_policy
        try:
            sw_policy.check(conn, pkg.get("detect_name") or pkg.get("name"), pkg.get("vendor"))
        except sw_policy.Refused as e:
            return _fail(conn, change, t, f"not removed: {e}")
    try:
        plan = deploy.command_plan(deploy.view(pkg), p["action"], p.get("package"))
    except deploy.Invalid as e:
        return _fail(conn, change, t, f"the package cannot be deployed: {e}")
    cmd = _queue(conn, change, t, "software_action", plan, hours=6)
    _set(conn, cid, key, current_command=cmd)
    if p["action"] == "uninstall":
        what = f"removing {plan['name']} (with its own uninstaller; nothing is downloaded)"
    else:
        what = (f"downloading {pkg['file_name']} ({round(int(pkg['size_bytes']) / 2 ** 20, 1)} MB) from PATCH-01, then "
                + ("copying the portable program to Program Files\\PATCH01-Apps" if plan["install_mode"] == "portable"
                   else f"{p['action']} {plan['name']} {plan['version']}"))
    ch.event(conn, cid, key, "worker", "install", None, f"{t['label']}: {what}")


def _cancel_requested_now(conn, change):
    """cancel_requested as committed now, not as read at the start of the tick (a cancel can arrive
    while a snapshot or a long pre-check runs). Kept on `change` for the rest of the tick."""
    row = conn.execute("SELECT cancel_requested FROM changes WHERE id=%s", (change["id"],)).fetchone()
    change["cancel_requested"] = bool(row and row["cancel_requested"])
    return change["cancel_requested"]


def _cancel_before_install(conn, change, t):
    cid, key = change["id"], t["target_key"]
    _set(conn, cid, key, state="cancelled", current_command=None)
    keep = (f"; snapshot {t['snapshot_moref']} was kept on the VM (remove it in vCenter if it is not needed)"
            if t.get("snapshot_moref") else "")
    return ch.event(conn, cid, key, "worker", "cancelled", None, f"{t['label']}: cancelled before installing{keep}")


def _enter(conn, change, t, state):
    """Move a target into `state` and start whatever that state does."""
    p = change["params"]
    cid, key = change["id"], t["target_key"]
    if state in ("snapshot", "install") and _cancel_requested_now(conn, change):
        return _cancel_before_install(conn, change, t)
    _set(conn, cid, key, state=state, step_started_at=datetime.now(timezone.utc), current_command=None)
    t["state"] = state

    if state == "precheck":
        params = {"checks": ["disk", "locks", "history"], "capture_services": bool(p.get("check_services", True))}
        if p.get("restart_only"):
            # A restart needs no update source: no WSUS test, no Windows Update restart
            params.update(restart_only=True, restart_windows_update=False)
        if change.get("kind") == "patch" and _is_windows(conn, t["host_id"]):
            # Windows: the precheck gets the job's updates, tests where their
            # files come from and downloads them, so the install only installs
            chosen = _windows_chosen(conn, t, p)
            params.update(_windows_params(conn, p, chosen), stall_minutes=10)
            _detail(conn, cid, key, windows_updates=[{"kb": r["kb"], "title": r["title"]} for r in chosen])
            ch.event(conn, cid, key, "worker", "precheck", None,
                     f"{t['label']}: pre-check, then download of {len(chosen)} update(s) before the install window")
        cmd = _queue(conn, change, t, "run_precheck", params, hours=3)
        _set(conn, cid, key, current_command=cmd)

    elif state == "snapshot":
        from . import vmware, changes as chg
        # The VM as it is linked now (powered on, with the agent's address), not as it was at booking
        now = conn.execute(f"""SELECT v.vcenter, v.moref, v.name, v.power_state FROM vm_inventory v
                                 JOIN hosts h ON h.id = v.host_id WHERE v.host_id = %s {chg.VM_PICK} LIMIT 1""",
                           (t["host_id"],)).fetchone()
        if now and (now["vcenter"], now["moref"]) != (t.get("vcenter"), t.get("vm_moref")):
            ch.event(conn, cid, key, "worker", "snapshot", None,
                     f"{t['label']}: linked VM is now {now['name']} (powered {str(now['power_state'] or '').replace('powered', '').lower()}); using it")
            _set(conn, cid, key, vcenter=now["vcenter"], vm_moref=now["moref"])
            t["vcenter"], t["vm_moref"] = now["vcenter"], now["moref"]
        if now and now["power_state"] != "poweredOn":
            return _fail(conn, change, t, f"its linked VM {now['name']} is not powered on, so the snapshot would not be "
                                          f"of this server. Nothing was installed. Check the VM link (Servers page).")
        # Nothing is held open while vCenter works (up to 30 minutes): the state and the link are saved
        # first, and the snapshot is taken in the background (_snapshot_progress picks up the result)
        conn.commit()
        _vc_start(("snapshot", str(cid), key), vmware.snapshot_for_patch, t["vcenter"], t["vm_moref"],
                  ch.ref(change["number"]))

    elif state == "install" and change.get("kind") == "software":
        return _enter_software(conn, change, t, p)

    elif state == "install":
        host = conn.execute("SELECT pkg_manager FROM hosts WHERE id=%s", (t["host_id"],)).fetchone()
        if (host or {}).get("pkg_manager") == "wua":
            return _enter_windows_install(conn, change, t, p)
        lu = _linux_security_updates(conn, t["host_id"]) if p.get("mode") != "advisories" else None
        if lu is not None:
            # The package manager's own security updates (agent 1.8.2+): what the Servers page shows
            rows, source = lu, "package manager"
        else:
            # Chosen advisories, or an agent too old to report its package manager's list
            sql = """SELECT package_name, fixed_evr, advisory_id::text AS advisory_id FROM host_applicability
                      WHERE host_id=%s AND state='affected' AND fixed_evr IS NOT NULL"""
            args = [t["host_id"]]
            if p.get("mode") == "advisories":
                sql += " AND advisory_id = ANY(%s)"
                args.append(p.get("advisories") or [])
            rows, source = conn.execute(sql, args).fetchall(), "advisories"
        pkgs = choose_fixed_versions(rows, (host or {}).get("pkg_manager"))
        if not pkgs:
            ch.event(conn, cid, key, "worker", "install", True,
                     f"{t['label']}: nothing to install, already up to date for this change")
            _detail(conn, cid, key, nothing_to_do=True)
            return _enter(conn, change, t, next_patch_state("install", p, {"nothing_to_do": True},
                                                            bool(t.get("snapshot_moref"))))
        _detail(conn, cid, key, packages=pkgs, packages_source=source,
                package_advisories=(_notice_names(rows) if source == "package manager" else _advisory_names(conn, rows)))
        cmd = _queue(conn, change, t, "install_packages", {"packages": pkgs, "mode": "exact"})
        _set(conn, cid, key, current_command=cmd)
        ch.event(conn, cid, key, "worker", "install", None,
                 f"{t['label']}: installing {len(pkgs)} package(s)")

    elif state == "reboot":
        # The boot time the agent reports now, so its return is judged on its own clock (see came_back)
        h = conn.execute("SELECT boot_time FROM hosts WHERE id=%s", (t["host_id"],)).fetchone()
        bt = (h or {}).get("boot_time")
        _detail(conn, cid, key, reboot_requested_at=datetime.now(timezone.utc).isoformat(),
                boot_time_before=bt.isoformat() if isinstance(bt, datetime) else bt)
        cmd = _queue(conn, change, t, "reboot_host", {"delay_seconds": 60})
        _set(conn, cid, key, current_command=cmd)

    elif state == "wait_boot":
        pass                          # checked each tick in _advance

    elif state == "reboot_wait":
        at = p.get("reboot_at")
        ch.event(conn, cid, key, "worker", "reboot_wait", None,
                 f"{t['label']}: installed; restarts at the job's restart time ({at})")

    elif state == "postcheck":
        base = (t.get("detail") or {}).get("baseline_services") or []
        pc = {"baseline_services": base}
        inst = ((t.get("detail") or {}).get("install") or {}).get("installed") or []
        if inst:
            # Windows: each update installed before the restart is checked again after it
            pc["windows_installed"] = [{"id": x.get("id"), "kb": x.get("kb"), "title": x.get("title")}
                                       for x in inst if isinstance(x, dict)][:200]
        cmd = _queue(conn, change, t, "run_postcheck", pc)
        _set(conn, cid, key, current_command=cmd)

    elif state == "inventory":
        cmd = _queue(conn, change, t, "collect_inventory", {})
        if _is_windows(conn, t["host_id"]):
            # The agent sends its report right after the postcheck; a Windows report includes a full WSUS
            # search (minutes), and the server is already patched and checked: the job does not wait for it
            ch.event(conn, cid, key, "worker", "inventory", True, f"{t['label']}: inventory report queued; the job does not wait for it")
            return _enter(conn, change, t, next_patch_state("inventory", p, {}, bool(t.get("snapshot_moref"))
                                                            and not _keep_snapshot(t)))
        _set(conn, cid, key, current_command=cmd)

    elif state == "snapshot_cleanup":
        from . import vmware
        # Committed before vCenter is asked (no row locks held while it works, and a restart finds the
        # step, not an "inventory" step to repeat); the removal runs in the background (_cleanup_progress)
        conn.commit()
        _vc_start(("cleanup", str(cid), key), vmware.remove_snapshot, t["vcenter"], t["vm_moref"],
                  t["snapshot_moref"], f"PATCH-01 {ch.ref(change['number'])} before patching")

    elif state == "done":
        if p.get("snapshot") == "remove_on_success" and t.get("snapshot_moref") and _keep_snapshot(t):
            ch.event(conn, cid, key, "worker", "snapshot", None,
                     f"{t['label']}: snapshot kept for rollback (not removed) because of the warnings below; remove it in vCenter once checked")
        _recompute(conn, t["host_id"])
        row = conn.execute("SELECT detail FROM change_targets WHERE change_id=%s AND target_key=%s", (cid, key)).fetchone()
        warn = ((row or {}).get("detail") or {}).get("warnings") or (t.get("detail") or {}).get("warnings")
        if warn:
            _set(conn, cid, key, state="done_with_warnings", error="; ".join(warn)[:1000])
            ch.event(conn, cid, key, "worker", "done", True, f"{t['label']}: complete, with warnings: " + "; ".join(warn)[:400])
        else:
            ch.event(conn, cid, key, "worker", "done", True, f"{t['label']}: complete")


def _recompute(conn, host_id):
    """Fresh verdicts for a server straight after patching it."""
    try:
        from . import cve_engine
        host = conn.execute("SELECT * FROM hosts WHERE id=%s", (host_id,)).fetchone()
        if host:
            cve_engine.compute_host(conn, host)
    except Exception as e:  # noqa: BLE001 - the nightly run will catch up
        log.warning("recompute for %s failed: %s", host_id, e)


def _windows_after_install(conn, host_id, result):
    """The Servers page at once, without waiting for the agent's next
    inventory (a WSUS search): the updates just installed are no longer
    listed as missing, and a restart is shown as pending when one is."""
    inst = [x for x in (result.get("installed") or []) if isinstance(x, dict)]
    ids = [str(x.get("id")) for x in inst if x.get("id")]
    kbs = [str(x.get("kb")).upper() for x in inst if x.get("kb")]
    if ids or kbs:
        conn.execute("""DELETE FROM windows_updates WHERE host_id = %s
                          AND (update_id = ANY(%s) OR upper(coalesce(kb, '')) = ANY(%s))""", (host_id, ids, kbs))
    if result.get("reboot_required"):
        conn.execute("""UPDATE hosts SET reboot_required = true,
                               reboot_reason = 'updates installed by a patch job' WHERE id = %s""", (host_id,))


def _windows_after_postcheck(conn, host_id, result):
    """After the restart: a restart still pending only if Windows says so."""
    pending = any("reboot pending" in str(w) for w in (result.get("warnings") or []))
    conn.execute("UPDATE hosts SET reboot_required = %s, reboot_reason = %s WHERE id = %s",
                 (pending, "Windows still reports a restart pending" if pending else None, host_id))


def _add_warnings(conn, cid, key, t, notes, keep_snapshot=True):
    """Add warnings to a target, keeping the earlier ones. keep_snapshot: the
    warning is about the patch itself (an update that did not install, a
    service down), so a "remove on success" snapshot is kept for rollback."""
    if not notes:
        return
    have = list((t.get("detail") or {}).get("warnings") or [])
    have += [n for n in notes if n not in have]
    more = {"warnings": have[:40]}
    if keep_snapshot:
        more["keep_snapshot"] = True
    _detail(conn, cid, key, **more)
    t.setdefault("detail", {}).update(more)


def _keep_snapshot(t):
    return bool((t.get("detail") or {}).get("keep_snapshot"))


def _inventory_warning(conn, change, t, why):
    """The inventory after patching is a report, not part of the patch: if it
    fails, the server is still patched (the next scheduled report catches up)."""
    note = f"patched, but the inventory report afterwards did not complete: {why}"
    _add_warnings(conn, change["id"], t["target_key"], t, [note], keep_snapshot=False)
    ch.event(conn, change["id"], t["target_key"], "worker", "inventory", None, f"{t['label']}: {note}")
    return _enter(conn, change, t, next_patch_state("inventory", change["params"], {},
                                                    bool(t.get("snapshot_moref")) and not _keep_snapshot(t)))


def _snapshot_progress(conn, change, t, now):
    """The snapshot step: wait for the background job, then record what vCenter answered."""
    cid, key = change["id"], t["target_key"]
    jkey = ("snapshot", str(cid), key)
    if jkey not in _vc_jobs:
        # No job in this process: the worker restarted while vCenter worked. Nothing will resume it,
        # so after the longest a snapshot can take it is reported, never left hanging.
        if t.get("step_started_at") and now - t["step_started_at"] > SNAPSHOT_STUCK:
            return _fail(conn, change, t, "PATCH-01 restarted while the VM snapshot was being taken, so nothing was installed. "
                                          "Check the VM for a PATCH-01 snapshot (remove it if you do not need it), then run the job again.")
        return
    job = _vc_finished(jkey)
    if job is None:
        return                                   # vCenter is still working
    if job.error is not None:
        e = job.error
        sid = getattr(e, "snapshot_moref", None)
        if sid:
            # Created but not confirmed: recorded on the target so it is reported as kept, not lost
            _set(conn, cid, key, snapshot_moref=sid)
            t["snapshot_moref"] = sid
            conn.commit()
        return _fail(conn, change, t, f"could not take the VM snapshot, so nothing was installed: {e}"
                                      + (f" (vCenter's snapshot id {sid} is left on the VM for you to check)" if sid else ""))
    snap = job.result
    _set(conn, cid, key, snapshot_moref=snap["snapshot_moref"])
    t["snapshot_moref"] = snap["snapshot_moref"]
    conn.commit()                                # recorded at once, so a restart never takes a second snapshot
    ch.event(conn, cid, key, "worker", "snapshot", True,
             f"{t['label']}: snapshot '{snap['snapshot_name']}' taken on VM {snap['vm']} and found in its snapshot list",
             {"moref": snap["snapshot_moref"], "vm": snap["vm"], "vcenter": t["vcenter"], "vm_moref": t["vm_moref"]})
    # _enter re-reads cancel_requested before the install is queued
    return _enter(conn, change, t, next_patch_state("snapshot", change["params"], {}, True))


def _snapshot_gone(conn, t, since):
    """True / False when a vCenter read after `since` shows whether the target's snapshot is still on
    its VM; None when no such read exists yet."""
    r = conn.execute("SELECT snapshots, synced_at FROM vm_inventory WHERE vcenter=%s AND moref=%s",
                     (t.get("vcenter"), t.get("vm_moref"))).fetchone()
    if not r or not r["synced_at"] or not since or r["synced_at"] <= since:
        return None
    snaps = r["snapshots"] or []
    if isinstance(snaps, str):
        snaps = json.loads(snaps)
    return not any(isinstance(s, dict) and s.get("moref") == t.get("snapshot_moref") for s in snaps)


def _cleanup_progress(conn, change, t, now):
    """The snapshot clean-up step: wait for the background removal, record it at once, then finish."""
    cid, key = change["id"], t["target_key"]
    jkey = ("cleanup", str(cid), key)
    if jkey in _vc_jobs:
        job = _vc_finished(jkey)
        if job is None:
            return                               # vCenter is still removing it
        err = job.error
    else:
        # The worker restarted during the removal: vCenter may have finished it. Once the longest a
        # removal takes has passed, the inventory read since then says whether it is gone.
        if t.get("step_started_at") and now - t["step_started_at"] <= SNAPSHOT_STUCK:
            return
        gone = _snapshot_gone(conn, t, t.get("step_started_at"))
        err = None if gone else RuntimeError(
            "PATCH-01 restarted while it was being removed, and vCenter's inventory does not confirm the removal"
            if gone is None else "PATCH-01 restarted while it was being removed, and the VM still lists it")
    if err is None:
        d = t.get("detail") or {}
        nothing = bool(d.get("nothing_to_do") or (d.get("install") or {}).get("nothing_to_do"))
        _set(conn, cid, key, snapshot_moref=None)
        ch.event(conn, cid, key, "worker", "snapshot_removed", True,
                 f"{t['label']}: " + ("nothing needed installing, so the snapshot taken before was removed"
                                      if nothing else "patched successfully, snapshot removed (as the job asked)"))
        conn.commit()                            # recorded at once: a restart never removes it twice
    else:
        # The patch succeeded; a snapshot left behind is a warning, not a failure
        _add_warnings(conn, cid, key, t, [f"the snapshot {t.get('snapshot_moref')} could not be removed and is still on the VM: {err}"], keep_snapshot=False)
        ch.event(conn, cid, key, "worker", "snapshot_removed", False,
                 f"{t['label']}: patched, but the snapshot could not be removed: {err}")
    return _enter(conn, change, t, "done")


REBOOT_BOOT_MOVE = timedelta(seconds=60)


def came_back(boot_time, last_checkin, asked, detail):
    """Has the server restarted since PATCH-01 asked at `asked`?

    Each clock is compared only with itself: last_checkin (set by PATCH-01) with `asked` (PATCH-01),
    and the boot time the agent reports with the one it reported when the restart was queued
    (detail["boot_time_before"], the agent's clock), so a server whose clock is behind still counts.
    A restart queued before boot_time_before was kept falls back to comparing boot_time with `asked`.
    Pure, for testing."""
    if not boot_time or not last_checkin or last_checkin <= asked:
        return False
    before = (detail or {}).get("boot_time_before")
    if before:
        before = datetime.fromisoformat(before) if isinstance(before, str) else before
        return boot_time > before + REBOOT_BOOT_MOVE
    return boot_time > asked


def _params(change):
    p = change.get("params") or {}
    return json.loads(p) if isinstance(p, str) else p


def restart_held(change, nxt):
    """Is a restart about to happen (nxt "reboot") or to be waited for (nxt "reboot_wait") too late
    for the job's window? A restart after the window is held, except one the job deliberately set
    for after its window (reboot_at later than run_before): that one keeps its time."""
    if nxt not in ("reboot", "reboot_wait") or not _window_closed(change):
        return False
    if nxt == "reboot":
        return True
    at = _params(change).get("reboot_at")
    return not at or _utc(at) <= _utc(change["run_before"])


def _hold_restart(conn, change, t, why):
    """The server is not restarted outside the job's window: it is checked as it is, and the job
    says it needs a restart."""
    cid, key = change["id"], t["target_key"]
    note = (f"restart held: {why} ({_utc(change['run_before']):%d %b %H:%M} UTC), so the server was not restarted. "
            "Restart it when convenient (Servers > Restart…).")
    _add_warnings(conn, cid, key, t, [note], keep_snapshot=False)
    _detail(conn, cid, key, restart_held=True)
    ch.event(conn, cid, key, "worker", "reboot", None, f"{t['label']}: {note}")


def _advance(conn, change, t):
    p = change["params"]
    cid, key, state = change["id"], t["target_key"], t["state"]
    now = datetime.now(timezone.utc)

    if state == "waiting_credential":
        # A job from before r90 waiting for a share credential: installers on a share are retired
        if change.get("cancel_requested"):
            _set(conn, cid, key, state="cancelled", current_command=None)
            return ch.event(conn, cid, key, "worker", "cancelled", None, f"{t['label']}: cancelled; nothing was installed")
        return _fail(conn, change, t, "not installed: installers on a share are retired; deploy it from Deployment instead")

    if state == "reboot_wait":
        p = change.get("params") or {}
        if isinstance(p, str):
            p = json.loads(p)
        if change.get("cancel_requested"):
            _add_warnings(conn, cid, key, t, ["the job was cancelled before the restart time: updates are installed, "
                                              "but the server has not restarted and still needs a restart"])
            ch.event(conn, cid, key, "worker", "reboot", False, f"{t['label']}: restart not done (the job was cancelled)")
            return _enter(conn, change, t, "postcheck")
        at = p.get("reboot_at")
        due = datetime.fromisoformat(at) if at else now
        if now < due:
            return
        if restart_held(change, "reboot_wait"):
            # Its turn came only after the job's window closed (it installed late, or waited behind the others)
            _hold_restart(conn, change, t, "its turn to restart came after the job's window closed")
            return _enter(conn, change, t, "postcheck")
        # Restart time: as many at once as the job allows (a cluster restarts one node at a time)
        busy = conn.execute(f"""SELECT count(*) AS n FROM change_targets WHERE change_id=%s
                                  AND state NOT IN {BUSY_EXCLUDED}""", (cid,)).fetchone()["n"]
        if busy >= int(change.get("max_parallel") or 1):
            return
        late = now - due
        if late > timedelta(minutes=30):
            # About timing, not the patch: a "remove on success" snapshot is still removed
            _add_warnings(conn, cid, key, t, [f"restarted {int(late.total_seconds() // 60)} minutes after the job's restart time "
                                              "(it installed late, or waited its turn behind the other servers)"], keep_snapshot=False)
        return _enter(conn, change, t, "reboot")

    if state == "wait_boot":
        asked = (t.get("detail") or {}).get("reboot_requested_at")
        asked = datetime.fromisoformat(asked) if asked else t["step_started_at"]
        h = conn.execute("SELECT boot_time, last_checkin FROM hosts WHERE id=%s",
                         (t["host_id"],)).fetchone()
        if h and came_back(h["boot_time"], h["last_checkin"], asked, t.get("detail")):
            ch.event(conn, cid, key, "worker", "rebooted", True, f"{t['label']}: back up after reboot")
            return _enter(conn, change, t, "postcheck")
        limit = WINDOWS_BOOT_TIMEOUT if _is_windows(conn, t["host_id"]) else BOOT_TIMEOUT
        if now - t["step_started_at"] > limit:
            return _fail(conn, change, t, f"did not come back within {int(limit.total_seconds() // 60)} "
                                          f"minutes of the reboot. Check its console.")
        return

    cmd_id = t.get("current_command")
    if not cmd_id:
        # vCenter steps have no agent command: their background job is checked instead
        if state == "snapshot":
            return _snapshot_progress(conn, change, t, now)
        if state == "snapshot_cleanup":
            return _cleanup_progress(conn, change, t, now)
        return
    cmd = conn.execute("SELECT verb::text AS verb, claimed_at, completed_at, ok, result, created_at, "
                       "(expires_at <= now() AND params->>'withdrawn' = 'tools_list') AS withdrawn "
                       "FROM agent_commands WHERE id=%s", (cmd_id,)).fetchone()
    if not cmd:
        return _fail(conn, change, t, "its command disappeared")
    if cmd["completed_at"] is None:
        if cmd["claimed_at"] is None and change.get("cancel_requested") and state == "install":
            # Cancelled before the agent took the install: withdraw it, nothing is installed
            withdrawn = conn.execute("UPDATE agent_commands SET expires_at = now() WHERE id = %s AND claimed_at IS NULL RETURNING id",
                                     (cmd_id,)).fetchone()
            if withdrawn:
                _set(conn, cid, key, state="cancelled", current_command=None)
                return ch.event(conn, cid, key, "worker", "cancelled", None, f"{t['label']}: cancelled before the install started; nothing was installed")
        if cmd["claimed_at"] is None and cmd.get("withdrawn"):
            # Taken off the removable tools list before the server started it (Software › Removable tools)
            return _fail(conn, change, t, "not removed: the program was taken off the removable tools list before this server started")
        if cmd["claimed_at"] is None and now - cmd["created_at"] > CLAIM_TIMEOUT:
            return _fail(conn, change, t, f"the agent did not pick up the {state} step within "
                                          f"{int(CLAIM_TIMEOUT.total_seconds() // 60)} minutes. Is it online?")
        limit = RUN_TIMEOUT.get(cmd["verb"], DEFAULT_RUN_TIMEOUT)
        if cmd["verb"] == "software_action":
            limit = WINDOWS_INSTALL_TIMEOUT
        elif cmd["verb"] == "install_packages" and _is_windows(conn, t["host_id"]):
            limit = WINDOWS_INSTALL_TIMEOUT
        elif cmd["verb"] == "run_precheck" and _is_windows(conn, t["host_id"]):
            limit = WINDOWS_PRECHECK_TIMEOUT    # includes the download; the agent stops a stalled one itself
        elif cmd["verb"] in ("run_postcheck", "collect_inventory") and _is_windows(conn, t["host_id"]):
            limit = WINDOWS_STEP_TIMEOUT
        if cmd["claimed_at"]:
            # Agents never check in while running a command (one run at a time),
            # so a check-in after the claim means that run ended without
            # answering: say so now, with the agent's own last words, instead
            # of waiting out the time limit
            # last_run_at: only a check-in (the start of a run) sets it; an
            # inventory report mid-run does not
            h = conn.execute("SELECT last_run_at FROM hosts WHERE id=%s", (t["host_id"],)).fetchone()
            if h and h["last_run_at"] and h["last_run_at"] > cmd["claimed_at"] + RUN_ENDED_GRACE:
                if state == "inventory":
                    return _inventory_warning(conn, change, t, "the agent's run ended before it reported")
                return _fail(conn, change, t, f"the agent took the {state} step, but its run ended without "
                                              f"reporting it. {_agent_tail(conn, t['host_id'], cmd['claimed_at'])}")
        if cmd["claimed_at"] and now - cmd["claimed_at"] > limit:
            cap = LIVE_MAX.get(cmd["verb"])
            if cap and now - cmd["claimed_at"] < cap and state != "inventory":
                h = conn.execute("SELECT last_checkin FROM hosts WHERE id=%s", (t["host_id"],)).fetchone()
                if h and h["last_checkin"] and now - h["last_checkin"] < LIVE_WITHIN:
                    # Still working and still in contact: keep waiting (said once, on the job's page)
                    if not (t.get("detail") or {}).get("long_step_noted"):
                        _detail(conn, cid, key, long_step_noted=now.isoformat())
                        ch.event(conn, cid, key, "worker", state, None,
                                 f"{t['label']}: the {state} step is taking longer than {int(limit.total_seconds() // 60)} minutes; "
                                 f"the agent is still working on it and in contact, so PATCH-01 keeps waiting "
                                 f"(up to {int(cap.total_seconds() // 3600)} hours)")
                    return
            if state == "inventory":
                return _inventory_warning(conn, change, t, f"it did not report within {int(limit.total_seconds() // 60)} minutes")
            tail = _agent_tail(conn, t["host_id"], cmd["claimed_at"])
            mins = int((now - cmd["claimed_at"]).total_seconds() // 60)
            why = (" (it stopped reporting progress)" if cap and now - cmd["claimed_at"] < cap
                   else f" (the longest PATCH-01 waits for it)" if cap else "")
            # Remembered, so an answer that still arrives later is recorded (late_results)
            _detail(conn, cid, key, timed_out_command=str(cmd_id))
            return _fail(conn, change, t, f"the {state} step did not report back within {mins} minutes{why}. "
                                          f"If the agent still answers, its result is added to this job. {tail}")
        return

    result = cmd["result"] or {}
    if state == "postcheck" and isinstance(result, dict):
        # For Patch Reports: which of the job's updates were not found after the restart
        _detail(conn, cid, key, postcheck={k: result.get(k) for k in ("updates_not_installed", "build", "uptime_minutes")
                                           if result.get(k) is not None})
    if state == "install" and not cmd["ok"] and isinstance(result, dict):
        # Kept on the target, so Patch Reports can list what failed to install
        _detail(conn, cid, key, install={k: v for k, v in result.items() if k != "output"})
    if state in ("install", "postcheck") and result.get("warnings"):
        # Some updates did not install, or did not stick after the restart: the
        # server carries on and ends "done, with warnings" naming them
        _add_warnings(conn, cid, key, t, [f"{state}: {w}" for w in result["warnings"] if w][:20])
    if state == "precheck" and cmd["ok"] and result.get("job_warnings"):
        _add_warnings(conn, cid, key, t, [f"precheck: {w}" for w in result["job_warnings"] if w][:20], keep_snapshot=False)
    if state == "inventory" and not cmd["ok"]:
        return _inventory_warning(conn, change, t, str(result.get("message") or result.get("error") or "it failed")[:300])
    if not cmd["ok"] and state == "postcheck":
        svcs = service_only_problem(result)
        if svcs:
            # The updates are in; only services did not come back. That is for
            # the operator to start, not a failed patch.
            note = "patched, but these services did not come back and need starting: " + ", ".join(svcs[:20])
            _add_warnings(conn, cid, key, t, [note])
            _detail(conn, cid, key, services_not_running=svcs[:50])
            if _is_windows(conn, t["host_id"]):
                _windows_after_postcheck(conn, t["host_id"], result)
            ch.event(conn, cid, key, "worker", "postcheck", None, f"{t['label']}: {note}", {"services": svcs[:50]})
            return _enter(conn, change, t, next_patch_state(state, p, result, bool(t.get("snapshot_moref"))))
    if not cmd["ok"]:
        msg = result.get("message") or result.get("error") or "the agent reported a failure"
        errs = result.get("errors")
        return _fail(conn, change, t, f"{state} failed: " + ("; ".join(errs) if errs else str(msg)[:600]),
                     {"result": result})

    if state == "install" and change.get("kind") == "software" and p.get("source") == "package":
        why = install_did_nothing(p, result)
        if why:
            # Reported done by the agent, but the program did not change: a failure, not a success
            _detail(conn, cid, key, install={k: v for k, v in result.items() if k != "output"})
            return _fail(conn, change, t, f"install failed: {why}", {"result": result})
    if state == "install" and change.get("kind") == "software" and result.get("nothing_to_do"):
        # The agent changed nothing (already installed, a newer one there, or nothing to upgrade):
        # never shown as a plain success, and the reason is on the server's line
        note = unchanged_note(p, result)
        _detail(conn, cid, key, nothing_to_do=True)
        t.setdefault("detail", {})["nothing_to_do"] = True
        _add_warnings(conn, cid, key, t, [note], keep_snapshot=False)
        ch.event(conn, cid, key, "worker", state, None, f"{t['label']}: {note}",
                 {k: v for k, v in result.items() if k != "output"})
    else:
        ch.event(conn, cid, key, "worker", state, True, f"{t['label']}: {state} passed",
                 {k: v for k, v in result.items() if k != "output"})
    if state == "precheck" and result.get("running_services"):
        _detail(conn, cid, key, baseline_services=result["running_services"][:300])
        t.setdefault("detail", {})["baseline_services"] = result["running_services"][:300]
    if state == "install":
        _detail(conn, cid, key, install=result)
        t.setdefault("detail", {})["install"] = result          # the postcheck may be queued straight away
        if _is_windows(conn, t["host_id"]):
            _windows_after_install(conn, t["host_id"], result)
    if state == "postcheck" and _is_windows(conn, t["host_id"]):
        _windows_after_postcheck(conn, t["host_id"], result)
    if state == "precheck":
        if _cancel_requested_now(conn, change):
            _set(conn, cid, key, state="cancelled", current_command=None)
            return ch.event(conn, cid, key, "worker", "cancelled", None,
                            f"{t['label']}: cancelled before installing")
        if _window_closed(change):
            # A long pre-check (a Windows download can take two hours) that ends after the window:
            # nothing is installed or restarted outside it
            what = "restart" if p.get("restart_only") else "install"
            _set(conn, cid, key, state="skipped", current_command=None)
            return ch.event(conn, cid, key, "worker", "skipped", None,
                            f"{t['label']}: window closed before {what}; nothing was changed")
    keep = _keep_snapshot(t)     # with a warning about the patch itself, the snapshot is kept
    nxt = next_patch_state(state, p, result, bool(t.get("snapshot_moref")) and not keep)
    if state == "install" and restart_held(change, nxt):
        # A long install that finished after the job's window must not restart the server in working
        # hours, now or at the job's restart time: the restart is held, the server is checked as it is,
        # and the job says it needs one
        _hold_restart(conn, change, t, "the install finished after the job's window closed")
        nxt = "postcheck"
    _enter(conn, change, t, nxt)


def _utc(v):
    v = datetime.fromisoformat(v) if isinstance(v, str) else v
    return v.astimezone(timezone.utc)


def _window_closed(change):
    rb = change.get("run_before")
    if isinstance(rb, str):
        rb = datetime.fromisoformat(rb)
    return bool(rb) and datetime.now(timezone.utc) > rb


TARGET_SQL = """SELECT target_key, host_id::text AS host_id, vcenter, vm_moref, label, state,
                       step_started_at, current_command, snapshot_moref, detail
                  FROM change_targets WHERE change_id=%s"""


def run_patch(conn, change):
    targets = conn.execute(TARGET_SQL + " ORDER BY label", (change["id"],)).fetchall()
    active = [t for t in targets if t["state"] not in TERMINAL and t["state"] != "queued"]
    # Servers waiting to restart go last: a server finishing in this pass frees its slot for them
    # at once (new installs never take that slot while a restart is due: see below)
    active.sort(key=lambda t: 1 if t["state"] == "reboot_wait" else 0)
    for t in active:
        try:
            _advance(conn, change, dict(t))
        except Exception as e:  # noqa: BLE001 - one server must never stall the rest
            log.error("target %s: %s", t["label"], traceback.format_exc())
            conn.rollback()                      # an aborted transaction cannot record anything
            fresh = conn.execute(TARGET_SQL + " AND target_key=%s", (change["id"], t["target_key"])).fetchone()
            _fail(conn, change, dict(fresh or t), f"internal error: {e}")
        conn.commit()

    queued = [t for t in targets if t["state"] == "queued"]
    if not queued:
        return
    window_closed = change["run_before"] and datetime.now(timezone.utc) > change["run_before"]
    if change["cancel_requested"] or window_closed:
        why = "cancelled" if change["cancel_requested"] else "the window closed before it started"
        for t in queued:
            _set(conn, change["id"], t["target_key"], state="cancelled" if change["cancel_requested"] else "skipped")
            ch.event(conn, change["id"], t["target_key"], "worker", "skipped", None, f"{t['label']}: {why}")
        conn.commit()
        return
    running_now = conn.execute(
        f"""SELECT count(*) AS n FROM change_targets WHERE change_id=%s
            AND state NOT IN {BUSY_EXCLUDED}""",
        (change["id"],)).fetchone()["n"]
    # A server whose restart time has come and is waiting for a slot comes before a new install
    reboot_at = (change.get("params") or {}).get("reboot_at") if isinstance(change.get("params"), dict) else None
    if reboot_at and datetime.now(timezone.utc) >= datetime.fromisoformat(reboot_at) and conn.execute(
            "SELECT 1 FROM change_targets WHERE change_id=%s AND state='reboot_wait' LIMIT 1", (change["id"],)).fetchone():
        return
    room = max(0, change["max_parallel"] - running_now)
    if not room:
        return
    # A server whose agent is being replaced starts after the new agent is confirmed (and takes no slot):
    # one query for all the queued servers
    ids = sorted({t["host_id"] for t in queued if t["host_id"]})
    updating = {r["host_id"] for r in conn.execute(AGENT_UPDATING_SQL, (ids,)).fetchall()} if ids else set()
    startable = [t for t in queued if not (t["host_id"] and t["host_id"] in updating)]
    for t in startable[:room]:
        try:
            _enter(conn, change, dict(t), "precheck")
        except Exception as e:  # noqa: BLE001
            conn.rollback()
            _fail(conn, change, dict(t), f"could not start: {e}")
        conn.commit()


# ---------------------------------------------------------------------------
# Agent updates
# ---------------------------------------------------------------------------

# The agent's update step: download (a few hundred KB), checks, a test run, the swap. Only a
# backstop: a run that ends without reporting is noticed at its next check-in
AGENT_UPDATE_RUN = timedelta(hours=3)
# After the swap the new version must check in and read its commands within its window (10
# minutes on Windows; on Linux the timer's interval plus 5): this long, at least, is allowed
AGENT_UPDATE_VERIFY = timedelta(minutes=int(os.environ.get("AGENT_UPDATE_VERIFY_MINUTES", "20")))
# Of these servers (host ids as text), those whose agent is being replaced right now
AGENT_UPDATING_SQL = """
SELECT DISTINCT ct.host_id::text AS host_id FROM change_targets ct JOIN changes c ON c.id = ct.change_id
 WHERE ct.host_id = ANY(%s::uuid[]) AND c.kind = 'agent_update' AND c.state = 'running' AND ct.state IN ('update', 'verify')"""
AGENT_BUSY_SQL = """
SELECT 1 FROM change_targets ct JOIN changes c ON c.id = ct.change_id
 WHERE ct.host_id = %s AND c.id <> %s AND c.state = 'running'
   AND ct.state NOT IN ('queued', 'done', 'done_with_warnings', 'failed', 'skipped', 'cancelled')
 LIMIT 1"""


def _agent_host(conn, host_id):
    return conn.execute("""SELECT os_id, pkg_manager::text AS pkg_manager, agent_version, last_run_at, status::text AS status
                             FROM hosts WHERE id = %s""", (host_id,)).fetchone()


def _withdraw(conn, cmd_id):
    """An update step not yet picked up never runs later, unsupervised."""
    if cmd_id:
        conn.execute("UPDATE agent_commands SET expires_at = now() WHERE id = %s AND claimed_at IS NULL", (cmd_id,))


def _au_fail(conn, change, t, reason, detail=None):
    _withdraw(conn, t.get("current_command"))
    _fail(conn, change, t, reason, detail)


def _enter_agent_update(conn, change, t):
    """Starts one server. True when an update step was queued (it counts against max_parallel)."""
    from . import agent_updates as au
    cid, key = change["id"], t["target_key"]
    h = _agent_host(conn, t["host_id"])
    if not h or h["status"] == "decommissioned":
        _fail(conn, change, t, "the server was retired before its turn")
        return False
    plat = au.platform_of(h["os_id"], h["pkg_manager"])
    try:
        plan = au.command_plan(change["params"], plat)
    except au.Invalid as e:
        _fail(conn, change, t, str(e))
        return False
    have, want = au.version_tuple(h["agent_version"]), au.version_tuple(plan["version"])
    _set(conn, cid, key, state="update", step_started_at=datetime.now(timezone.utc), current_command=None)
    if have and have == want:
        _set(conn, cid, key, state="done")
        _detail(conn, cid, key, agent_update={"from": h["agent_version"], "to": plan["version"], "nothing_to_do": True})
        ch.event(conn, cid, key, "worker", "done", True, f"{t['label']}: already runs agent {plan['version']}; nothing to do")
        return False
    if have and have > want:
        _set(conn, cid, key, state="done_with_warnings",
             error=f"it runs agent {h['agent_version']}, newer than {plan['version']}: not downgraded")
        ch.event(conn, cid, key, "worker", "done", True,
                 f"{t['label']}: runs agent {h['agent_version']}, newer than {plan['version']}; left as it is")
        return False
    if not au.can_self_update(h["agent_version"]):
        _fail(conn, change, t, f"its agent {h['agent_version'] or '(unknown version)'} cannot update itself: "
                               f"install agent {plan['version']} on it once by hand")
        return False
    _detail(conn, cid, key, agent_update={"from": h["agent_version"], "to": plan["version"], "platform": plat})
    cmd = _queue(conn, change, t, "update_agent", plan, hours=2)
    _set(conn, cid, key, current_command=cmd)
    ch.event(conn, cid, key, "worker", "update", None,
             f"{t['label']}: updating the agent {h['agent_version']} -> {plan['version']} "
             f"(downloaded from PATCH-01, SHA-256 {plan['sha256'][:12]}..., checked and tested before the swap)")
    return True


def _au_command(conn, change, t, what):
    """The state of the target's current command: None while it runs, else the row. Fails the
    target (and returns False) when it was never picked up or its run ended without a result."""
    now = datetime.now(timezone.utc)
    cmd = conn.execute("SELECT claimed_at, completed_at, ok, result, created_at FROM agent_commands WHERE id=%s",
                       (t.get("current_command"),)).fetchone()
    if not cmd:
        _au_fail(conn, change, t, "its command disappeared")
        return False
    if cmd["completed_at"] is not None:
        return cmd
    if cmd["claimed_at"] is None:
        if now - cmd["created_at"] > CLAIM_TIMEOUT:
            _au_fail(conn, change, t, f"the agent did not pick up the {what} within "
                                      f"{int(CLAIM_TIMEOUT.total_seconds() // 60)} minutes (it is withdrawn). Is it online?")
            return False
        return None
    h = conn.execute("SELECT last_run_at FROM hosts WHERE id=%s", (t["host_id"],)).fetchone()
    if h and h["last_run_at"] and h["last_run_at"] > cmd["claimed_at"] + RUN_ENDED_GRACE:
        _au_fail(conn, change, t, f"the agent took the {what}, but its run ended without reporting it. "
                                  f"{_agent_tail(conn, t['host_id'], cmd['claimed_at'])}")
        return False
    if now - cmd["claimed_at"] > (AGENT_UPDATE_RUN if t.get("state") == "update" else timedelta(minutes=30)):
        _au_fail(conn, change, t, f"the {what} did not report back in time. "
                                  f"{_agent_tail(conn, t['host_id'], cmd['claimed_at'])}")
        return False
    return None


def _advance_agent_update(conn, change, t):
    """update: the agent checks, tests and swaps itself. verify: the check job sent at once after
    the swap, which only the new version can answer ("already runs this version"); answering it
    is also what confirms the update on the server, so the previous version stops watching."""
    from . import agent_updates as au
    cid, key, state = change["id"], t["target_key"], t["state"]
    now = datetime.now(timezone.utc)
    d = (t.get("detail") or {}).get("agent_update") or {}

    if state == "verify":
        limit = max(AGENT_UPDATE_VERIFY, timedelta(minutes=int(d.get("confirm_minutes") or 10) + 10))
        row = conn.execute("SELECT claimed_at, completed_at FROM agent_commands WHERE id=%s",
                           (t.get("current_command"),)).fetchone()
        if row and row["claimed_at"] is None and now - t["step_started_at"] > limit:
            h = _agent_host(conn, t["host_id"])
            return _au_fail(conn, change, t, f"agent {d.get('to')} did not check in and answer within "
                                             f"{int(limit.total_seconds() // 60)} minutes of the swap "
                                             f"(the server reports {(h or {}).get('agent_version') or 'nothing'}). "
                                             f"If the new version does not work, the previous one puts itself back.")
        if row and row["claimed_at"] is None:
            return
    cmd = _au_command(conn, change, t, "update step" if state == "update" else "check of the new agent")
    if not cmd:
        return
    result = cmd["result"] or {}
    if state == "verify":
        h = _agent_host(conn, t["host_id"])
        if cmd["ok"] and result.get("probe") and result.get("version") == d.get("to"):
            ch.event(conn, cid, key, "worker", "done", True,
                     f"{t['label']}: agent {d.get('to')} is running and answers jobs (was {d.get('from')})")
            return _set(conn, cid, key, state="done", current_command=None)
        if h and h["agent_version"] == d.get("from"):
            return _au_fail(conn, change, t, f"agent {d.get('from')} answered instead of {d.get('to')}: the new version "
                                             f"did not work, and the previous one was put back. "
                                             f"{_agent_tail(conn, t['host_id'], datetime.fromisoformat(d['swapped_at']) if d.get('swapped_at') else t['step_started_at'])}")
        msg = result.get("message") or result.get("error") or "an unexpected answer"
        return _au_fail(conn, change, t, f"agent {d.get('to')} did not answer PATCH-01's check job: {str(msg)[:600]}",
                        {"result": result})
    if not cmd["ok"]:
        msg = result.get("message") or result.get("error") or "the agent reported a failure"
        return _au_fail(conn, change, t, f"the agent was not updated: {str(msg)[:800]}", {"result": result})
    if result.get("nothing_to_do"):
        ch.event(conn, cid, key, "worker", "done", True, f"{t['label']}: {result.get('message') or 'already up to date'}")
        return _set(conn, cid, key, state="done", current_command=None)
    d.update(swapped_at=cmd["completed_at"].isoformat(), checks=result.get("checks"),
             confirm_minutes=result.get("confirm_minutes"))
    _detail(conn, cid, key, agent_update=d)
    t.setdefault("detail", {})["agent_update"] = d
    h = _agent_host(conn, t["host_id"])
    plan = dict(au.command_plan(change["params"], d.get("platform") or au.platform_of(h["os_id"], h["pkg_manager"])), probe=True)
    probe = _queue(conn, change, t, "update_agent", plan, hours=2)
    _set(conn, cid, key, state="verify", step_started_at=now, current_command=probe)
    ch.event(conn, cid, key, "worker", "update", True,
             f"{t['label']}: new agent in place ({'; '.join(str(x) for x in (result.get('checks') or [])[:6])}); "
             f"waiting for it to check in and answer a check job")


def run_agent_update(conn, change):
    targets = conn.execute(
        """SELECT target_key, host_id::text AS host_id, label, state, step_started_at, current_command::text AS current_command, detail
             FROM change_targets WHERE change_id=%s ORDER BY label""", (change["id"],)).fetchall()
    for t in [t for t in targets if t["state"] not in TERMINAL and t["state"] != "queued"]:
        t = dict(t)
        try:
            if change["cancel_requested"] and t["state"] == "update":
                # Cancelled: a step not yet picked up is withdrawn; one already running finishes and is followed
                row = conn.execute("SELECT claimed_at FROM agent_commands WHERE id=%s", (t["current_command"],)).fetchone()
                if row and row["claimed_at"] is None:
                    _withdraw(conn, t["current_command"])
                    _set(conn, change["id"], t["target_key"], state="cancelled", current_command=None)
                    ch.event(conn, change["id"], t["target_key"], "worker", "cancelled", None,
                             f"{t['label']}: cancelled before its agent picked up the update")
                    conn.commit()
                    continue
            _advance_agent_update(conn, change, t)
        except Exception as e:  # noqa: BLE001 - one server must never stall the rest
            log.error("agent update %s: %s", t["label"], traceback.format_exc())
            conn.rollback()
            _au_fail(conn, change, t, f"internal error: {e}")
        conn.commit()
    queued = [t for t in targets if t["state"] == "queued"]
    if not queued:
        return
    window_closed = change["run_before"] and datetime.now(timezone.utc) > change["run_before"]
    if change["cancel_requested"] or window_closed:
        why = "cancelled" if change["cancel_requested"] else "the window closed before it started"
        for t in queued:
            _set(conn, change["id"], t["target_key"], state="cancelled" if change["cancel_requested"] else "skipped")
            ch.event(conn, change["id"], t["target_key"], "worker", "skipped", None, f"{t['label']}: {why}")
        conn.commit()
        return
    running_now = conn.execute(
        """SELECT count(*) AS n FROM change_targets WHERE change_id=%s
            AND state NOT IN ('queued','done','done_with_warnings','failed','skipped','cancelled')""",
        (change["id"],)).fetchone()["n"]
    room = max(0, change["max_parallel"] - running_now)
    for t in queued:
        if room <= 0:
            break
        t = dict(t)
        # Never swapped in the middle of another job on the same server (a patch job between steps):
        # the server waits its turn
        if conn.execute(AGENT_BUSY_SQL, (t["host_id"], change["id"])).fetchone():
            d = t.get("detail") or {}
            if not d.get("waiting_noted"):
                _detail(conn, change["id"], t["target_key"], waiting_noted=True)
                ch.event(conn, change["id"], t["target_key"], "worker", "waiting", None,
                         f"{t['label']}: another job is running on this server; its agent is updated after it")
                conn.commit()
            continue
        try:
            if _enter_agent_update(conn, change, t):
                room -= 1
        except Exception as e:  # noqa: BLE001
            conn.rollback()
            _fail(conn, change, t, f"could not start: {e}")
        conn.commit()


# ---------------------------------------------------------------------------
# VMware changes
# ---------------------------------------------------------------------------

def run_vm(conn, change):
    """One VM action at a time per change, each in the background (see _vc_start): this thread
    starts it, and records its result on a later tick."""
    from . import vmware
    busy = False
    for s_ in conn.execute("""SELECT target_key, vcenter, vm_moref, label, state, step_started_at FROM change_targets
                               WHERE change_id=%s AND state='vm_action'""", (change["id"],)).fetchall():
        t = dict(s_)
        jkey = ("vm", str(change["id"]), t["target_key"])
        if jkey not in _vc_jobs:
            # A VM action left "in progress" by a worker restart: reported, never left running for ever
            if t["step_started_at"] and datetime.now(timezone.utc) - t["step_started_at"] > SNAPSHOT_STUCK:
                _fail(conn, change, t, f"PATCH-01 restarted while vCenter was doing this ({change['kind']}); check the VM's state in vCenter")
            continue
        job = _vc_finished(jkey)
        if job is None:
            busy = True                          # vCenter is still working on it
            ev = _vc_stop.get(jkey)
            if ev is not None and not ev.is_set() and (
                    change["cancel_requested"]
                    or (change.get("run_before") and datetime.now(timezone.utc) > change["run_before"])):
                ev.set()                         # stops before its next snapshot
            continue
        _vc_stop.pop(jkey, None)
        if job.error is None:
            result = job.result
            state, ok = "done", True
            msg = {"vm_snapshot_revert": f"reverted to '{result.get('reverted_to')}'. To undo, revert to "
                                         f"'{result.get('safety_snapshot_name')}'."}.get(change["kind"], "done")
            if change["kind"] == "vm_snapshot_cleanup":
                from . import snapshot_cleanup
                state, msg = snapshot_cleanup.outcome(result)
                ok = not result.get("failed")         # one failed removal is not a success
            _set(conn, change["id"], t["target_key"], state=state, detail=json.dumps(result),
                 **({"error": msg[:1000]} if not ok else {}))
            ch.event(conn, change["id"], t["target_key"], "worker", change["kind"], ok,
                     f"{t['label']}: {msg}", result)
        else:
            _fail(conn, change, t, str(job.error))
        conn.commit()
        # Reflect the change in the inventory without waiting for the next sync
        _vc_resync(t["vcenter"])
    conn.commit()
    if busy:
        return
    t = conn.execute(
        """SELECT target_key, vcenter, vm_moref, label, state FROM change_targets
            WHERE change_id=%s AND state='queued' ORDER BY label LIMIT 1""",
        (change["id"],)).fetchone()
    if not t:
        return
    if change["cancel_requested"]:
        conn.execute("UPDATE change_targets SET state='cancelled' WHERE change_id=%s AND state='queued'",
                     (change["id"],))
        conn.commit()
        return
    if change.get("run_before") and datetime.now(timezone.utc) > change["run_before"]:
        # Same rule as patch jobs: nothing new starts after the window
        for q in conn.execute("""SELECT target_key, label FROM change_targets
                                  WHERE change_id=%s AND state='queued'""", (change["id"],)).fetchall():
            _set(conn, change["id"], q["target_key"], state="skipped")
            ch.event(conn, change["id"], q["target_key"], "worker", "skipped", None,
                     f"{q['label']}: the window closed before it started")
        conn.commit()
        return
    _set(conn, change["id"], t["target_key"], state="vm_action", step_started_at=datetime.now(timezone.utc))
    conn.commit()
    params = change["params"]
    if change["kind"] == "vm_snapshot_cleanup":
        from . import snapshot_cleanup
        params = snapshot_cleanup.target_params(params, t["target_key"])   # this VM's snapshots only
        ev = threading.Event()
        _vc_stop[("vm", str(change["id"]), t["target_key"])] = ev
        params = dict(params, _stop=ev, deadline=change.get("run_before"))
    _vc_start(("vm", str(change["id"]), t["target_key"]), vmware.vm_action, t["vcenter"], t["vm_moref"],
              change["kind"], params)


LATE_SQL = """
SELECT ct.change_id, ct.target_key, ct.label, ct.detail, ct.host_id::text AS host_id,
       ac.ok, ac.result, ac.completed_at, ac.verb::text AS verb
  FROM change_targets ct
  JOIN agent_commands ac ON ac.id = (ct.detail->>'timed_out_command')::uuid
 WHERE ct.state = 'failed' AND ct.detail ? 'timed_out_command' AND NOT (ct.detail ? 'late_result')
   AND ac.completed_at IS NOT NULL AND ct.updated_at > now() - interval '3 days'
 LIMIT 50"""


def late_results(conn):
    """An agent that answered after PATCH-01 stopped waiting (a very long install,
    a lost connection): its answer is added to the failed server's record, so the
    job page and Patch Reports show what was really installed, and that the server
    still needs its restart and checks. The server stays failed: nothing more is run."""
    for r in conn.execute(LATE_SQL).fetchall():
        res = r["result"] if isinstance(r["result"], dict) else {}
        inst = [x for x in (res.get("installed") or []) if isinstance(x, dict)]
        bad = [x for x in (res.get("failed") or []) if isinstance(x, dict)]
        more = {"late_result": {"at": r["completed_at"], "ok": r["ok"], "installed": len(inst), "failed": len(bad),
                                "reboot_required": bool(res.get("reboot_required"))}}
        if r["verb"] == "install_packages" and (inst or bad or res.get("nothing_to_do")):
            more["install"] = {k: v for k, v in res.items() if k != "output"}
        _detail(conn, r["change_id"], r["target_key"], **more)
        if r["verb"] == "install_packages":
            msg = (f"{r['label']}: the install finished after PATCH-01 stopped waiting: {len(inst)} installed"
                   + (f", {len(bad)} failed" if bad else "")
                   + ("; the server needs a restart (Servers: restart it, or run the job again)" if res.get("reboot_required") else "")
                   + ". It was not restarted or checked by this job.")
        else:
            msg = f"{r['label']}: the agent answered the {r['verb']} step after PATCH-01 stopped waiting (" \
                  + ("passed" if r["ok"] else "failed") + "). Nothing more was run."
        ch.event(conn, r["change_id"], r["target_key"], "worker", "late_result", r["ok"], msg,
                 {"installed": [x.get("kb") or x.get("title") for x in inst][:50]})
    conn.commit()


def changes_loop():
    conn = _db()
    last_late = 0.0
    while not _stop.is_set():
        try:
            start_due(conn)
            running = conn.execute(
                """SELECT id, number, kind::text AS kind, params, run_before, max_parallel,
                          cancel_requested FROM changes WHERE state='running' ORDER BY started_at"""
            ).fetchall()
            for c in running:
                c = dict(c)
                (run_patch if c["kind"] in ("patch", "software", "restart")
                 else run_agent_update if c["kind"] == "agent_update" else run_vm)(conn, c)
                finish_if_done(conn, c)
                conn.commit()
            if time.monotonic() - last_late > 60:
                last_late = time.monotonic()
                try:
                    late_results(conn)
                except Exception:  # noqa: BLE001 - must never stop the change loop
                    conn.rollback()
                    log.exception("late results failed")
            beat(conn, "changes", running=len(running))
        except Exception:  # noqa: BLE001 - keep the loop alive; log and retry
            log.error("changes loop: %s", traceback.format_exc())
            try:
                conn.rollback()
            except Exception:  # noqa: BLE001
                conn = _db()
        _stop.wait(TICK)


# ---------------------------------------------------------------------------
# Assessment enrichment
# ---------------------------------------------------------------------------

def enrich_item(conn, assessment_id, item):
    from . import cve_intel, exposure, llm
    cid = item["cve_id"]
    d = conn.execute("SELECT * FROM cve_details WHERE cve_id=%s", (cid,)).fetchone()
    # Fetch from NVD when we have nothing, or only an older record without products
    if not d or not d.get("nvd_fetched_at") or (not d.get("cpes") and not d.get("fetch_error")):
        try:
            cve_intel.fetch_one(conn, cid)
            conn.commit()
        except Exception as e:  # noqa: BLE001
            log.warning("NVD lookup for %s failed: %s", cid, e)
            conn.rollback()
        time.sleep(cve_intel.NVD_PAUSE)
        d = conn.execute("SELECT * FROM cve_details WHERE cve_id=%s", (cid,)).fetchone()
    d = d or {}

    # In order: the CVE database (the NVD record above, and what Microsoft and
    # Red Hat published in the feeds), the software inventory (Linux packages,
    # Windows programs with version ranges), the machines' operating systems
    # (agents, WSUS computers and vCenter guests, so a Windows 10 Pro desktop
    # or a Server 2019 box counts even without an agent), hardware and
    # VMware, and the servers' package verdicts (item["status"]).
    from . import cve_impact
    cpes = d.get("cpes") or []
    if isinstance(cpes, str):
        cpes = json.loads(cpes)
    ms_products, rh_products, rh_components = [], [], []
    try:
        with conn.transaction():
            for f in conn.execute("SELECT source, products, components FROM cve_feed_items WHERE cve_id = %s",
                                  (cid,)).fetchall():
                if f["source"] == "msrc":
                    ms_products.extend(f["products"] or [])
                elif f["source"] == "redhat":
                    rh_products.extend(f["products"] or [])
                    rh_components.extend(f["components"] or [])
    except Exception:  # noqa: BLE001 - feeds (schema 022/025) not installed
        pass
    # Red Hat's own answer for this CVE on RHEL 8 and 9 (fixed build, affected, not affected)
    from . import rh_state
    try:
        st = rh_state.get(conn, cid)
        if st is None or st.get("error"):
            rh_state.fetch_one(conn, cid)
            st = rh_state.get(conn, cid)
        if st and st.get("found"):
            rh_products.extend(sorted({f["package"] for f in st["fixed"]} - set(rh_products)))
            rh_components.extend(sorted({x["package"] for x in st["states"]} - set(rh_components)))
    except Exception as e:  # noqa: BLE001 - the other sources still decide
        conn.rollback()
        log.info("Red Hat state for %s: %s", cid, e)
    products = exposure.products_from_cpes(cpes)
    # The same mapping as the Vulnerabilities page: proven findings only, appliances apart
    verdict, _, found, info = cve_impact.analyse_one(conn, {"cve_id": cid, "cpes": cpes, "ms_products": ms_products,
                                                            "rh_products": rh_products, "rh_components": rh_components})
    appl = [dict(x, where="Appliance", certainty="in_range" if x["state"] == "affected" else "check")
            for x in info.get("appliances") or []]
    matches = found + appl
    word = cve_impact.exposure_word(item["status"], verdict, found, appl,
                                    bool(products or ms_products or rh_products or rh_components))
    match_lines = cve_impact.match_lines(matches)

    summary = model = None
    try:
        summary, model = llm.summarise_cve(conn, {
            "cve_id": cid, "cvss_score": d.get("cvss_score"), "cvss_severity": d.get("cvss_severity"),
            "cvss_vector": d.get("cvss_vector"), "attack_class": d.get("attack_class"),
            "attack_class_basis": d.get("attack_class_basis"), "kev": d.get("kev"),
            "epss": d.get("epss"), "description": d.get("description"), "exposure": word,
            "product_list": [f"{p['vendor']} {p['product']} ({p['kind']})" for p in products],
            "match_lines": match_lines})
    except Exception as e:  # noqa: BLE001 - the facts stand without the brief
        log.info("no AI brief for %s: %s", cid, e)

    conn.execute(
        """UPDATE cve_assessment_items SET
             description=%s, cvss_score=%s, cvss_vector=%s, cvss_severity=%s, kev=%s, epss=%s,
             attack_class=%s, published=%s, products=%s, product_classes=%s,
             inventory_matches=%s, exposure=%s, ai_summary=%s, ai_model=%s,
             platforms=%s, excluded=%s, enriched_at=now()
           WHERE assessment_id=%s AND cve_id=%s""",
        (d.get("description"), d.get("cvss_score"), d.get("cvss_vector"), d.get("cvss_severity"),
         bool(d.get("kev")), d.get("epss"), d.get("attack_class"), d.get("published"),
         json.dumps(products), sorted({p["kind"] for p in products}),
         json.dumps(matches[:60], default=str), word, summary, model,
         info["platforms"], json.dumps({"machines": info["excluded"], "notes": info["notes"]}, default=str),
         assessment_id, cid))


def enrich_loop():
    from . import cve_intel
    conn = _db()
    while not _stop.is_set():
        try:
            a = conn.execute("""SELECT id, progress FROM cve_assessments WHERE state='enriching'
                                 ORDER BY created_at LIMIT 1""").fetchone()
            if not a:
                beat(conn, "enrichment", idle=True)
                _stop.wait(15)
                continue
            if a["progress"] == 0:
                ids = [r["cve_id"] for r in conn.execute(
                    "SELECT cve_id FROM cve_assessment_items WHERE assessment_id=%s",
                    (a["id"],)).fetchall()]
                for cid in ids:
                    conn.execute("INSERT INTO cve_details (cve_id) VALUES (%s) ON CONFLICT DO NOTHING", (cid,))
                cve_intel.fetch_kev_epss_for(conn, ids)
                conn.commit()
            items = conn.execute(
                """SELECT cve_id, status FROM cve_assessment_items
                    WHERE assessment_id=%s AND enriched_at IS NULL ORDER BY cve_id LIMIT 3""",
                (a["id"],)).fetchall()
            if not items:
                conn.execute("UPDATE cve_assessments SET state='done' WHERE id=%s", (a["id"],))
                conn.commit()
                continue
            for it in items:
                try:
                    enrich_item(conn, a["id"], it)
                except Exception as e:  # noqa: BLE001 - mark it done with what we have
                    log.error("enrich %s: %s", it["cve_id"], traceback.format_exc())
                    conn.rollback()
                    conn.execute("""UPDATE cve_assessment_items SET enriched_at=now(),
                                           exposure=coalesce(exposure,'not_found')
                                     WHERE assessment_id=%s AND cve_id=%s""", (a["id"], it["cve_id"]))
                conn.execute("UPDATE cve_assessments SET progress=progress+1 WHERE id=%s", (a["id"],))
                conn.commit()
            beat(conn, "enrichment", assessment=str(a["id"]))
        except Exception:  # noqa: BLE001
            log.error("enrichment loop: %s", traceback.format_exc())
            try:
                conn.rollback()
            except Exception:  # noqa: BLE001
                conn = _db()
            _stop.wait(15)


# ---------------------------------------------------------------------------
# VMware live watcher: one thread per vCenter, reconnecting on failure
# ---------------------------------------------------------------------------

RESYNC_MIN_SECONDS = 600       # a full sync at most every 10 min per vCenter
CHANGE_KEEP_DAYS = 7


def _watch_vc(vc):
    from . import vmware
    last_resync = {"t": 0.0}

    def resync(name):
        # A VM appeared or vanished: pick up everything about it, rate-limited
        if time.time() - last_resync["t"] < RESYNC_MIN_SECONDS:
            return
        last_resync["t"] = time.time()
        try:
            vmware.sync(only=name)
        except Exception as e:  # noqa: BLE001
            log.warning("resync of %s failed: %s", name, e)

    backoff = 10
    while not _stop.is_set():
        try:
            vmware.watch(vc, _stop, _db, on_structural=resync)
            backoff = 10
        except Exception as e:  # noqa: BLE001 - keep watching whatever happens
            log.warning("watcher %s: %s; retrying in %ss", vc["name"], e, backoff)
            try:
                with _db() as conn:
                    conn.execute(
                        """INSERT INTO vmware_live (vcenter, connected, error, updated_at)
                           VALUES (%s, FALSE, %s, now())
                           ON CONFLICT (vcenter) DO UPDATE SET connected=FALSE,
                                  error=EXCLUDED.error, updated_at=now()""",
                        (vc["name"], str(e)[:500]))
            except Exception:  # noqa: BLE001
                pass
            _stop.wait(backoff)
            backoff = min(backoff * 2, 300)


VMWARE_SYNC_MINUTES = max(2, int(os.environ.get("VMWARE_SYNC_MINUTES", "5") or 5))


def vmware_sync_loop():
    """Read every vCenter's inventory every VMWARE_SYNC_MINUTES (default 5),
    and at once when a patch job asks (a new VM not linked to its server yet).
    New VMs, moves and links to servers show within minutes."""
    _stop.wait(60)
    pruned = 0.0
    while not _stop.is_set():
        try:
            from . import vmware
            import pyVmomi  # noqa: F401 - installed only once a vCenter is added
            vcs = vmware.load_vcenters()
        except ImportError:
            vcs = []
        except Exception as e:  # noqa: BLE001
            log.warning("vmware sync: %s", e)
            vcs = []
        if vcs:
            try:
                with _db() as conn:
                    try:
                        with conn.transaction():
                            rows = {r["name"]: r for r in conn.execute(
                                """SELECT name, (last_sync_at IS NULL OR last_sync_at < now() - make_interval(mins => %s)) AS due,
                                          sync_requested_at IS NOT NULL AS asked FROM vcenters""",
                                (VMWARE_SYNC_MINUTES,)).fetchall()}
                    except Exception:  # noqa: BLE001 - schema 035 not applied yet: by age only
                        conn.rollback()
                        rows = {r["name"]: dict(r, asked=False) for r in conn.execute(
                            """SELECT name, (last_sync_at IS NULL OR last_sync_at < now() - make_interval(mins => %s)) AS due
                                 FROM vcenters""", (VMWARE_SYNC_MINUTES,)).fetchall()}
                    conn.commit()
                    for vc in vcs:
                        if _stop.is_set():
                            break
                        r = rows.get(vc["name"])
                        if r is None or r["due"] or r["asked"]:
                            res = vmware.sync_locked(conn, vc)
                            if not res.get("ok"):
                                log.warning("vmware sync %s: %s", vc["name"], res.get("error"))
                    beat(conn, "vmware_sync", vcenters=len(vcs), every_minutes=VMWARE_SYNC_MINUTES)
                    if time.time() - pruned > 3600:
                        # A read every 5 minutes is 288 history rows a day per vCenter: keep 30 days
                        pruned = time.time()
                        with conn.transaction():
                            conn.execute("DELETE FROM vcenter_syncs WHERE started_at < now() - interval '30 days'")
            except Exception as e:  # noqa: BLE001 - must never stop the worker
                log.warning("vmware sync: %s", type(e).__name__)
        _stop.wait(30)


def deploy_loop():
    """Deployment packages: ClamAV scans (when set up) and AI-01's description;
    then failed servers explained (errhelp). One thing at a time, so none holds
    up the change loop."""
    from . import deploy, llm
    _stop.wait(20)
    last_error = None
    while not _stop.is_set():
        busy = False
        try:
            with _db() as conn:
                p = conn.execute("""SELECT * FROM deploy_packages WHERE deleted_at IS NULL AND scan_state = 'pending'
                                     ORDER BY uploaded_at LIMIT 1""").fetchone()
                conn.commit()
                if p and deploy.CLAMAV_HOST:
                    busy = True
                    state, result = deploy.scan(dict(p))
                    with conn.transaction():
                        conn.execute("""UPDATE deploy_packages SET scan_state=%s, scan_result=%s, scanned_at=now()
                                         WHERE id=%s AND scan_state='pending'""", (state, result, p["id"]))
                    log.info("deploy: %s scanned: %s", p["file_name"], state)
                elif p:
                    with conn.transaction():
                        conn.execute("UPDATE deploy_packages SET scan_state='off' WHERE id=%s", (p["id"],))
                q = conn.execute("""SELECT * FROM deploy_packages WHERE deleted_at IS NULL AND ai_state = 'pending'
                                     ORDER BY uploaded_at LIMIT 1""").fetchone()
                conn.commit()
                if q and llm.configured():
                    busy = True
                    try:
                        got, err, st = deploy.describe(dict(q)), None, "done"
                    except llm.LLMBusy:
                        got, err, st = None, None, "pending"          # tried again on the next round
                    except llm.LLMUnavailable as e:
                        got, err, st = None, str(e)[:300], "failed"
                    if st != "pending":
                        with conn.transaction():
                            conn.execute("""UPDATE deploy_packages SET ai=%s, ai_state=%s, ai_error=%s, ai_at=now()
                                             WHERE id=%s AND ai_state='pending'""",
                                         (json.dumps(got) if got else None, st, err, q["id"]))
                elif q:
                    with conn.transaction():
                        conn.execute("UPDATE deploy_packages SET ai_state='off' WHERE id=%s", (q["id"],))
                # Failed and warned servers of patch jobs and deployments: known codes, then AI-01's reading
                if not busy:
                    from . import errhelp
                    busy = errhelp.work_one(conn)
                beat(conn, "deploy")
        except Exception as e:  # noqa: BLE001 - schema 036 not applied yet, or a database hiccup
            msg = str(e)[:200]
            if msg != last_error:                 # said once, not every 20 seconds
                log.warning("deploy loop: %s", msg)
                last_error = msg
        _stop.wait(5 if busy else 20)


def vmware_loop():
    """Start and supervise watchers. Never raises: the worker exits if a
    top-level thread dies, and a vCenter problem must not stop patching."""
    watchers = {}
    last_prune = 0.0
    while not _stop.is_set():
        try:
            try:
                from . import vmware
                import pyVmomi  # noqa: F401 - installed only once a vCenter is added
                vcs = vmware.load_vcenters()
            except ImportError:
                vcs = []
            for vc in vcs:
                th = watchers.get(vc["name"])
                if th is None or not th.is_alive():
                    th = threading.Thread(target=_watch_vc, args=(vc,), name="watch-" + vc["name"],
                                          daemon=True)
                    th.start()
                    watchers[vc["name"]] = th
            with _db() as conn:
                if time.time() - last_prune > 3600:
                    conn.execute("DELETE FROM vmware_changes WHERE at < now() - make_interval(days => %s)",
                                 (CHANGE_KEEP_DAYS,))
                    conn.execute("DELETE FROM vmware_events WHERE created_at < now() - interval '90 days'")
                    last_prune = time.time()
                beat(conn, "vmware_live", watchers=sorted(n for n, t in watchers.items() if t.is_alive()))
        except Exception as e:  # noqa: BLE001
            log.warning("vmware loop: %s", e)
        _stop.wait(30)


# ---------------------------------------------------------------------------
# Hardening schedule: a CIS Level 1 scan per server every N days
# ---------------------------------------------------------------------------

HARDENING_SCAN_DAYS = int(os.environ.get("HARDENING_SCAN_DAYS", "7") or 0)


def hardening_loop():
    """Queue due scans hourly, at most 50 at a time, so a fleet is spread
    across the day. HARDENING_SCAN_DAYS=0 turns the schedule off."""
    from . import hardening as hd
    while not _stop.is_set():
        try:
            with _db() as conn:
                queued = []
                if HARDENING_SCAN_DAYS > 0:
                    with conn.transaction():
                        queued = [r for r in hd.queue_due(conn, "l1", HARDENING_SCAN_DAYS) if r[1]]
                    if queued:
                        log.info("hardening: queued %d scheduled scans", len(queued))
                beat(conn, "hardening", every_days=HARDENING_SCAN_DAYS, queued=len(queued))
        except Exception as e:  # noqa: BLE001 - the schedule must never stop the worker
            log.warning("hardening schedule: %s", e)
        _stop.wait(3600)


# ---------------------------------------------------------------------------
# Mail alerts: detect every minute, digests on schedule, send the queue
# ---------------------------------------------------------------------------

def notify_loop():
    from . import notify as nt
    while not _stop.is_set():
        try:
            with _db() as conn:
                cfg = nt.config(conn)
                detail = {"enabled": cfg["enabled"]}
                if cfg["enabled"]:
                    detail.update(nt.cycle(conn, cfg))
                    detail["digests"] = nt.maybe_digests(conn, cfg)
                    sent, failed = nt.send_queued(conn, cfg)
                    detail.update(sent=sent, failed=failed)
                beat(conn, "mail", **detail)
        except Exception as e:  # noqa: BLE001 - mail must never stop the worker
            log.warning("mail alerts: %s", e)
        _stop.wait(60)


def reports_loop():
    """Scheduled reports, in their own loop: a report waiting on AI-01 for a summary
    never holds up security alerts (their mails are sent by notify_loop)."""
    from . import notify as nt, report_jobs
    _stop.wait(30)
    while not _stop.is_set():
        try:
            with _db() as conn:
                cfg = nt.config(conn)
                done = report_jobs.run_due(conn, cfg) if cfg["enabled"] else []
                beat(conn, "reports", ran=done)
        except Exception as e:  # noqa: BLE001 - must never stop the worker
            log.warning("scheduled reports: %s", type(e).__name__ if "report_schedules" not in str(e) else "schema 027 not applied yet")
        _stop.wait(60)


def feeds_loop():
    """CVE news from NIST, Microsoft and Red Hat, at the interval set in the
    console (Admin > CVE feeds), or at once when an admin asks."""
    from . import cve_feeds, cve_intel
    key = bool(cve_intel.NVD_KEY)
    while not _stop.is_set():
        try:
            with _db() as conn:
                if cve_feeds.due(conn):
                    beat(conn, "feeds", running=True, nvd_key=key)
                    done = cve_feeds.sync_all(conn, stop=_stop.is_set)
                    beat(conn, "feeds", last=done, nvd_key=key)
                else:
                    beat(conn, "feeds", idle=True, nvd_key=key)
        except Exception as e:  # noqa: BLE001 - feeds must never stop the worker
            log.warning("CVE feeds: %s", e)
        _stop.wait(60)


def impact_loop():
    """Match new serious CVEs against the inventory, then have AI-01 brief the
    impacted ones. Repeats when the inventory changes and at least daily."""
    from . import cve_impact
    while not _stop.is_set():
        try:
            with _db() as conn:
                try:                                   # Red Hat's per-release answer, read before matching
                    from . import cve_feeds, rh_state
                    rh_state.refresh_pass(conn, int(cve_feeds.settings(conn).get("days_back") or 14))
                except Exception as e:  # noqa: BLE001 - matching goes on with what is cached
                    conn.rollback()
                    log.info("Red Hat state: %s", e)
                n = cve_impact.analyse_pass(conn)
                beat(conn, "impact", analysed=n, briefing=True)
                ai = cve_impact.ai_pass(conn)
                beat(conn, "impact", analysed=n, ai_briefs=ai)
        except Exception as e:  # noqa: BLE001 - must never stop the worker
            log.warning("CVE impact: %s", e)
        _stop.wait(120)


def antivirus_loop():
    """Read each antivirus console's agents every hour, and at once on "Sync now"."""
    from . import antivirus
    while not _stop.is_set():
        try:
            with _db() as conn:
                ids = antivirus.due(conn)
                conn.commit()
                n = 0
                for cid in ids:
                    if _stop.is_set():
                        break
                    try:                            # product servers listed again once a day (schema 034)
                        from . import av_products
                        if av_products.rediscover_due(conn, cid):
                            conn.commit()
                            av_products.discover(conn, cid)
                        conn.commit()
                    except Exception as e:  # noqa: BLE001 - the agents are still read
                        conn.rollback()
                        log.info("antivirus products: %s", type(e).__name__)
                    n += antivirus.sync_one(conn, cid)
                    try:                            # pattern status and detections (schema 029)
                        from . import av_logs
                        av_logs.sync_logs(conn, cid)
                    except Exception as e:  # noqa: BLE001 - the agent list still stands
                        conn.rollback()
                        log.info("antivirus logs: %s", type(e).__name__)
                # Deep Security Managers read directly (schema 034): with their console, or at once on "Sync now"
                from . import av_products
                pids = []
                try:
                    for cid in ids:
                        pids += av_products.dsm_due(conn, cid)
                    pids += [p for p in av_products.dsm_requested(conn) if p not in pids]
                    conn.commit()
                except Exception as e:  # noqa: BLE001
                    conn.rollback()
                    log.info("deep security: %s", type(e).__name__)
                for pid in pids:
                    if _stop.is_set():
                        break
                    try:
                        n += av_products.dsm_sync(conn, pid)
                    except Exception as e:  # noqa: BLE001 - one Manager never stops the others
                        conn.rollback()
                        log.warning("deep security sync: %s", type(e).__name__)
                beat(conn, "antivirus", consoles=len(ids), managers=len(pids), agents=n)
        except Exception as e:  # noqa: BLE001 - must never stop the worker
            msg = str(e)
            if "av_consoles" in msg and "does not exist" in msg:
                msg = "schema 026 not applied yet"
            log.warning("antivirus: %s", msg)
        _stop.wait(60)


def nessus_loop():
    """Read each Nessus server's scans every 15 minutes (at once on "Refresh"), and import the
    newest finished run of each scan (at once on "Import now")."""
    from . import nessus
    while not _stop.is_set():
        servers = scans = imported = 0
        try:
            with _db() as conn:
                due = nessus.servers_due(conn)
                conn.commit()
                for srv in due:
                    if _stop.is_set():
                        break
                    servers += 1
                    try:
                        scans += nessus.sync_server(conn, srv)
                        ok, msg = True, None
                    except nessus.NessusError as e:
                        conn.rollback()
                        ok, msg = False, str(e)[:400]
                    except Exception as e:  # noqa: BLE001 - one server never stops the others
                        conn.rollback()
                        ok, msg = False, "Nessus's answer could not be read."
                        log.warning("nessus sync: %s", type(e).__name__)
                    conn.execute("""UPDATE nessus_servers SET last_sync_at = now(), last_sync_ok = %s, last_sync_msg = %s
                                     WHERE id = %s""", (ok, msg, srv["id"]))
                    conn.commit()
                    if not ok:
                        continue
                    for sc in nessus.import_due(conn, srv):
                        conn.commit()
                        if _stop.is_set():
                            break
                        try:
                            before = [r["c"] for r in conn.execute(
                                """SELECT DISTINCT unnest(cves) AS c FROM nessus_findings WHERE server_id = %s AND scan_id = %s""",
                                (srv["id"], sc["scan_id"])).fetchall()]
                            conn.commit()
                            res = nessus.import_run(conn, srv, sc, _stop)
                            if res is None:
                                break
                            imported += 1
                            # the CVEs found now, and those found before (perhaps fixed since), are checked again
                            # on the next pass of the Vulnerabilities check
                            conn.execute("""UPDATE cve_impact SET analysed_at = 'epoch' WHERE cve_id = ANY(%s::text[]) OR cve_id IN (
                                              SELECT DISTINCT unnest(cves) FROM nessus_findings
                                               WHERE server_id = %s AND scan_id = %s)""", (before, srv["id"], sc["scan_id"]))
                            conn.commit()
                        except Exception as e:  # noqa: BLE001 - recorded on the scan, shown on the page
                            conn.rollback()
                            msg = str(e)[:400] if isinstance(e, nessus.NessusError) else "The results could not be read."
                            if not isinstance(e, nessus.NessusError):
                                log.warning("nessus import: %s", type(e).__name__)
                            conn.execute("""UPDATE nessus_scans SET import_error = %s, imported_at = now(),
                                                   imported_history_id = last_history_id, import_requested_at = NULL
                                             WHERE server_id = %s AND scan_id = %s""", (msg, srv["id"], sc["scan_id"]))
                            conn.commit()
                beat(conn, "nessus", servers=servers, scans=scans, imported=imported)
        except Exception as e:  # noqa: BLE001 - must never stop the worker
            msg = str(e)
            if "nessus_servers" in msg and "does not exist" in msg:
                msg = "schema 046 not applied yet"
            log.warning("nessus: %s", msg[:300])
        _stop.wait(60)


def assets_loop():
    """Every hour: machines in both WSUS and the uploaded sheet are approved
    (recorded as "auto"), and AI-01 places the OS names the rules cannot (at
    most 30 a run, each asked once). Nothing else about an asset is changed."""
    from . import inventory, asset_import, asset_coverage
    _stop.wait(300)
    while not _stop.is_set():
        try:
            with _db() as conn:
                assets = inventory.load_assets(conn)["assets"]
                conn.commit()
                approved = 0
                try:
                    approved = asset_coverage.auto_approve(conn, assets)
                except Exception as e:  # noqa: BLE001 - the device types still run
                    conn.rollback()
                    log.warning("assets: auto-approval: %s", type(e).__name__)
                r = asset_import.classify_unknown(conn, assets)
                beat(conn, "assets", auto_approved=approved, **{k: v for k, v in r.items() if k in ("asked", "decided")})
        except Exception as e:  # noqa: BLE001 - must never stop the worker
            msg = str(e)
            if "asset_ai_types" in msg and "does not exist" in msg:
                msg = "schema 030 not applied yet"
            log.warning("assets: %s", msg[:200])
        _stop.wait(3600)


def insights_loop():
    """AI-01's analysis of the servers, every 15 minutes."""
    from . import insights
    while not _stop.is_set():
        try:
            with _db() as conn:
                try:                                   # the Overview's history: one row a day
                    from . import overview
                    if not conn.execute("SELECT 1 FROM overview_daily WHERE day = current_date").fetchone():
                        overview.snapshot(conn)
                    conn.commit()
                except Exception as e:  # noqa: BLE001 - schema 042 not applied yet
                    conn.rollback()
                    log.debug("overview snapshot: %s", e)
                if insights.due(conn):
                    src = insights.run(conn)
                    beat(conn, "insights", last=src)
                else:
                    beat(conn, "insights", idle=True)
        except Exception as e:  # noqa: BLE001 - must never stop the worker
            log.warning("insights: %s", e)
        _stop.wait(60)


APPLICABILITY_SQL = """
SELECT h.id, h.hostname, h.os_id, h.os_major, h.status, h.kernel_running, h.reboot_required, h.last_inventory,
       h.packages_changed_at
  FROM hosts h
 WHERE h.status <> 'decommissioned' AND h.packages_changed_at IS NOT NULL
 ORDER BY h.packages_changed_at
 LIMIT 10"""
# Done with this change only: a newer inventory that arrived meanwhile keeps its mark
APPLICABILITY_DONE_SQL = "UPDATE hosts SET packages_changed_at = NULL WHERE id = %s AND packages_changed_at = %s"


def applicability_loop():
    """A server's "to install" follows its package list within a minute: when an
    inventory reports changed packages (patched by hand, by a job, or by
    anything else), its advisories are worked out again, instead of waiting
    for the nightly run."""
    from . import cve_engine
    while not _stop.is_set():
        n = 0
        try:
            with _db() as conn:
                # Silent servers' verdicts become unknown, at most every 15 min (O1)
                cve_engine.periodic_sweep(conn)
                for h in conn.execute(APPLICABILITY_SQL).fetchall():
                    try:
                        if cve_engine.supports(h["os_id"]):   # RHEL, Oracle Linux and Windows builds (O2)
                            cve_engine.compute_host(conn, h)
                        conn.execute(APPLICABILITY_DONE_SQL, (h["id"], h["packages_changed_at"]))
                        conn.commit()
                        n += 1
                    except Exception as e:  # noqa: BLE001 - one server never stops the rest
                        conn.rollback()
                        log.warning("applicability for %s: %s", h["hostname"], e)
                        # Not retried at once: the next inventory change (or the nightly run) tries again
                        conn.execute(APPLICABILITY_DONE_SQL, (h["id"], h["packages_changed_at"]))
                        conn.commit()
                beat(conn, "applicability", recomputed=n)
        except Exception as e:  # noqa: BLE001 - schema 039 not applied yet, or the database restarting
            log.debug("applicability: %s", e)
        _stop.wait(30 if n else 60)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    lock_conn = _db()
    lock_conn.autocommit = True
    while not lock_conn.execute("SELECT pg_try_advisory_lock(%s) AS ok", (LOCK_ID,)).fetchone()["ok"]:
        log.info("another worker holds the lock; waiting")
        time.sleep(30)
    log.info("worker running")

    def stop(*_):
        _stop.set()
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    threads = [threading.Thread(target=changes_loop, name="changes", daemon=True),
               threading.Thread(target=enrich_loop, name="enrichment", daemon=True),
               threading.Thread(target=vmware_loop, name="vmware_live", daemon=True),
               threading.Thread(target=vmware_sync_loop, name="vmware_sync", daemon=True),
               threading.Thread(target=deploy_loop, name="deploy", daemon=True),
               threading.Thread(target=hardening_loop, name="hardening", daemon=True),
               threading.Thread(target=notify_loop, name="mail", daemon=True),
               threading.Thread(target=feeds_loop, name="feeds", daemon=True),
               threading.Thread(target=impact_loop, name="impact", daemon=True),
               threading.Thread(target=insights_loop, name="insights", daemon=True),
               threading.Thread(target=antivirus_loop, name="antivirus", daemon=True),
               threading.Thread(target=assets_loop, name="assets", daemon=True),
               threading.Thread(target=nessus_loop, name="nessus", daemon=True),
               threading.Thread(target=reports_loop, name="reports", daemon=True),
               threading.Thread(target=applicability_loop, name="applicability", daemon=True)]
    for th in threads:
        th.start()
    while not _stop.is_set():
        _stop.wait(5)
        # The single-worker lock lives on lock_conn: if that connection is lost, so is the lock,
        # and a second worker could start. Exit at once; the container restarts and takes it again.
        try:
            lock_conn.execute("SELECT 1")
        except Exception:  # noqa: BLE001
            log.error("lost the database connection that holds the single-worker lock; exiting so the container restarts")
            os._exit(1)
        for th in threads:
            if not th.is_alive():
                log.error("thread %s died; exiting so the container restarts", th.name)
                sys.exit(1)
    log.info("worker stopping")


if __name__ == "__main__":
    main()
