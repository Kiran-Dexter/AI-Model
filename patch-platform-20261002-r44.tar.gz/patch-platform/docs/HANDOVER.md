# PATCH-01 platform: handover

Everything needed to continue this work in a new conversation. It contains no
host names, domain names, IP addresses or credentials: those are written as
placeholders (`<patch01>`, `<ai01>`, `<vcenter>`, `<wsus>`), to be filled from
your own records.

**To continue in a new chat:** upload this file together with the latest
platform bundle (`patch-platform-<date>-r44.tar.gz` or later) and say what you
want to work on next. The "Current state" and "Backlog" sections below are the
place to start.

---

## 1. What it is

A self-hosted platform for an estate of about 300 servers, in one console, in
four pillars:

| Pillar | What it does |
|---|---|
| **Patch & CVE** | Knows which CVEs each server has (from its installed versions and vendor advisories), with KEV and EPSS, and patches through approved, scheduled change jobs: precheck, VM snapshot, install, reboot, postcheck, inventory. |
| **VMware** | Read-only inventory and a live infrastructure map from vCenter (two or more vCenters); snapshot and power actions through the same change engine, using a separate write account. |
| **Hardening** | OpenSCAP scans against CIS Level 1/2 (SCAP Security Guide content) and custom profiles built from an uploaded standard; branded PDF and Word reports. |
| **Assess** | CVE assessment and explanations, with an optional local LLM (AI-01). |

Plus: Windows servers (patching through WSUS approvals, a WSUS view, software
inventory), mail alerts and digests, branding, users and roles, and PATCH-01's
own certificate managed from the console.

**Estate:** RHEL 8 and 9, Oracle Linux 7, 8 and 9, Ubuntu, and Windows Server
2019. Rolling out to about 100 Linux and 150 Windows servers. Three WSUS
servers. VMware vSphere 8.

## 2. Architecture

### PATCH-01 (RHEL 9, air-gapped except proxy-routed feeds)
Docker containers on one network, `patchnet`:

| Layer | Containers | Notes |
|---|---|---|
| data | patch01-postgres, patch01-redis | PostgreSQL 16, database `patchdb` |
| pulp | patch01-pulp-api, -content, -worker, -migrate | Linux package mirror; `-migrate` is a one-shot step that runs and exits 0 |
| api | patch01-api, patch01-worker | FastAPI on port 8000 inside; the worker runs jobs, syncs, mail |
| dashboard | patch01-dashboard | static console |
| ingress | patch01-nginx | the only container published: 443 (and 80, redirect only); runs as uid 1001, gid 0 |

Paths on PATCH-01: `/patch` (base), `/patch/compose` (rendered compose files),
`/patch/secrets` (root-only secrets), `/patch/certs` (TLS certificate and key,
`root:0`, key `0640`), `/patch/certs-staging` (hand-over folder for console
certificate installs), `/patch/backup`, `/etc/patch-platform` (settings such as
`proxy.env`, `images.env`), logs in `/var/log/patch-platform` and `/var/log/patch01*.log`.

Host systemd units: `patch01-cve.timer`, `patch01-vmware.timer` (hourly at :15),
`patch01-mail-watchdog.timer`, `patch01-llm-warm.timer`, `patch01-stack.service`
(ordered start at boot, clean stop at shutdown), `patch01-cert.path` and
`patch01-cert.service` (console certificate installs).

### AI-01 (RHEL 9)
llama.cpp serving a Qwen3-8B GGUF model, under `/llm` (`/llm/config`,
`/llm/certs`). Services `llama-server` (127.0.0.1:8080) and `nginx` (443) with
an allow-list admitting only PATCH-01's IP
(`/etc/nginx/conf.d/ai01-llm.conf`). Self-signed certificate naming AI-01's IP;
PATCH-01 pins it. PATCH-01 calls AI-01 by IP, never through the proxy.

### Agents
- **Linux** (`patch-agent`, Python, runs on Python 3.6 and later): systemd timer every 5 minutes; `/usr/local/bin/patch-agent`, settings `/etc/patch-agent/agent.conf`, enrolment `/etc/patch-agent/token`, CA `/etc/patch-agent/ca.pem`. Bypasses the proxy for PATCH-01.
- **Windows** (`patch-agent.ps1`, PowerShell 5.1): scheduled task "PATCH-01 agent" as SYSTEM every 5 minutes (4-hour limit), `C:\Program Files\PatchAgent`, data `C:\ProgramData\PatchAgent` (token DPAPI-encrypted for the machine). Trusts PATCH-01 by pin (SHA-256 of its certificate, two allowed during a change) or `system` (Windows' own trust store). Bypasses the proxy.
- Agents always connect **to** PATCH-01 on 443; PATCH-01 never connects to them.

### Network
| Direction | Port | Between |
|---|---|---|
| in to PATCH-01 | 443/tcp | all managed servers, the WSUS servers, admin workstations |
| in to PATCH-01 | 22/tcp | admin workstations and jump host |
| out from PATCH-01 | 443/tcp | AI-01; each vCenter |
| out from PATCH-01 | proxy port | the web proxy (NVD, CISA, FIRST/EPSS, Microsoft MSRC, GitHub, repository syncs); see `docs/proxy-allowlist.txt` |
| out from PATCH-01 | 25/tcp (or 587/465) | mail relay (the relay must also allow PATCH-01's IP to send) |
| out from PATCH-01 | 53, 123 | DNS, NTP |
| jump host to Windows | 5985/5986 | WinRM, only for `push-agent.ps1` |

Internal names (the site's domain) must be in any shell `no_proxy` on PATCH-01;
the platform itself never sends internal traffic to the proxy.

## 3. Current versions

| Item | Version |
|---|---|
| Platform bundle | **r44** (`patch-platform-20261002-r44.tar.gz`) |
| Database schema | **20** (`sql/001` to `sql/020`) |
| Linux agent | **1.6.1** |
| Windows agent | **1.2.0-win** |
| `patch01ctl` (start/stop/status) | 1.4 |
| `ai01ctl` | 1.1 |
| `patch01-reip` (IP change and tests) | 1.3 |
| Agent kits | `patch01-agent-linux-1.6.1.tar.gz`, `patch01-agent-windows-1.2.0.zip` |

## 4. Bundle layout

```
patch-platform/
  patch01/scripts/   phase0-bootstrap, phase1a ingress, 1b data, 1c pulp, phase2 repos,
                     3a schema, 3b api, 4 cve, 5 dashboard, 6 llm (AI-01), 7 vmware,
                     8 hardening content, 9 mail, 10 windows; patch01-cert-apply;
                     check-connectivity; resolve-images
  patch01/sql/       001-019, all idempotent; applied by phase3a-schema.sh
  patch01/api/app/   main.py (API), worker.py, changes.py, cve_engine.py, cve_intel.py, msrc.py,
                     vmware.py, blast.py, hardening.py, custom_profiles.py, reports.py,
                     report_mail.py, notify.py, branding.py, certs.py, health.py, llm.py, chat.py,
                     assess.py, exposure.py, auth.py, evr.py
  patch01/dashboard/ app.js, hardening.js, map.js, theme.js, style.css, index.html
  client/            Linux: setup-agent.sh, install-agent.sh, patch-agent.py, push-linux.sh
  client/windows/    Setup-Agent.ps1, install-agent.ps1, patch-agent.ps1, push-agent.ps1, wsus-report.ps1
  ai01/              ai01-setup.sh
  docs/              this file, CHANGE-IP-AND-CERTIFICATE.md, proxy-allowlist.txt
  README.md          release notes (newest first) and instructions
```
Separate tool tars: `patch01ctl`, `ai01ctl`, `patch01-reip`.

## 5. Deploying and upgrading

Every script is idempotent and has `--check`. A new release is usually:
```bash
tar xzf patch-platform-<date>-rNN.tar.gz && cd patch-platform/patch01
./scripts/phase3a-schema.sh        # must end "schema version: <N>"
./scripts/phase3b-api.sh           # rebuilds the API image; installs host helpers and units
./scripts/phase5-dashboard.sh      # console files, stamped so browsers load the new ones
```
The README at the top of each release says which of these that release needs.
A fresh build runs every phase in order (0, 1a, 1b, 1c, 2, 3a, 3b, 4 to 10).

## 6. Operating it

| Task | How |
|---|---|
| Status, start, stop (ordered, health-checked) | `patch01ctl status|start|stop [--force]|restart`; `ai01ctl status|start|stop` |
| Agent: install or upgrade, Linux | `sudo ./setup-agent.sh` (agent kit); many servers: `push-linux.sh --test-only`, then with `-t tokens.txt` |
| Agent: install or upgrade, Windows | `powershell -ExecutionPolicy Bypass -File .\Setup-Agent.ps1`; many servers: `push-agent.ps1 -TestOnly`, then with `-Tokens` |
| Enrolment tokens (single use, 72 h) | `./scripts/phase10-windows.sh --tokens <N> <group>` (groups: default, test, prod, windows) |
| PATCH-01 certificate | Console: **Admin > Certificate** (check, then install; automatic rollback; five kept). CLI fallback: `patch01-reip --cert` |
| Certificate pin for Windows | shown on Admin > Certificate; `phase10-windows.sh --pin [--cert FILE]` |
| vCenter read account | `./scripts/phase7-vmware.sh --add <name> --host <vcenter>`; `--list`, `--test`, `--sync`, `--install-timer` |
| vCenter write account (snapshots, power) | `--add-writer <name>` before the work, `--remove-writer <name>` after; stored root-only, never in the console |
| Microsoft CVE data (Windows) | `./scripts/phase10-windows.sh --msrc [months]` |
| WSUS reporting | `phase10-windows.sh --wsus-token <wsus name>`, then on each WSUS: `wsus-report.ps1 -Test`, then `-Install` |
| Hardening content | `./scripts/phase8-hardening.sh --import-zip <SSG zip>` |
| Mail | console: **Admin > Mail**; CLI: `phase9-mail.sh --status|--check|--test` |
| IP change of PATCH-01 / AI-01 | `patch01-reip --dry-run`, then `patch01-reip`; `--test` any time; see `docs/CHANGE-IP-AND-CERTIFICATE.md` |

Logs: `/var/log/patch01ctl.log`, `/var/log/patch01-reip.log`,
`/var/log/patch01-cert.log`, `docker logs <container> --tail 60`; Linux agent
`journalctl -u patch-agent`; Windows agent `C:\ProgramData\PatchAgent\agent.log`.

## 7. Features in place

- **CVE engine:** advisories from Pulp-synced vendor data (RHEL) and Microsoft's Security Update Guide (Windows, by OS build); verdicts per server; KEV, EPSS, NVD details; Advisories, Assess and Overview pages.
- **Change engine:** patch jobs (all fixes, or chosen advisories), VMware actions; approval, windows, parallelism; precheck, snapshot, install, reboot (never, if required, always), postcheck, inventory, snapshot clean-up. Windows: installs only WSUS-approved updates; chosen advisories map through CVEs to the approved cumulative update.
- **VMware:** inventory, live map with vMotion streaming, blast radius, coverage, ESXi hosts, datastores; VM linked to its server by hardware UUID.
- **Hardening:** CIS L1/L2 for RHEL 8, 9, 10 and Ubuntu 22.04, 24.04; scan progress; custom profiles from txt/csv/docx (CIS number match, then title match, AI suggestions on request, review before use, OpenSCAP tailoring file); reports in Management and Technical styles, PDF and Word, branded; e-mail with a short factual message (AI polish optional).
- **Windows:** agent, WSUS view (sync, unapproved security updates, computers not reporting, not in PATCH-01), software inventory per server and across the fleet.
- **Software from a share (S2):** catalog of approved installers (Windows > Installers; second admin approves), software jobs that always need approval, the share credential entered at run time and held encrypted in memory-backed storage for that job only, SHA-256 and Authenticode checks on every server before anything runs.
- **Mail:** immediate critical alerts, task updates, daily digest at 07:00 Singapore time, weekly summary; settings and recipients in the console; relay password encrypted.
- **Security model:** the API has no Docker access; anything privileged (certificate installs) is done by a root helper on the host, through a watched folder, which re-checks everything. Secrets root-only under `/patch/secrets`. Agents use per-host tokens.

## 8. Decisions made

- Agents on managed servers (decided after initially resisting them).
- Each pillar a tab; no Neo4j; MCP read-only layer wanted later.
- VMware map and blast radius only from vCenter and ESXi data, nothing collected inside VMs.
- VMware snapshots and power actions go through approval.
- Hardening: OpenSCAP; CIS-aligned (not certified) results are acceptable to the auditors; CIS Level 1 Server baseline; focus RHEL 8 and 9 (Oracle Linux treated as the same settings).
- Custom profiles check only what the uploaded document lists; review required before use.
- Reports: Management summary and Technical detail; logo, copyright, page numbers.
- Windows: PATCH-01 installs WSUS-approved updates; a read-only script on each WSUS server; agents deployed by hand or script.
- vCenter write credentials added only for the duration of the work, then removed. (A "one-time credentials in the console" option was offered, not built.)
- High secure coding standards for all code; no sensitive information (names, addresses, credentials) kept in memory or shipped.
- Software deployment: Windows installers from a share, released by a credential entered at run time; Linux packages from the RPM repositories (no share needed); the two-person rule for catalog entries.
- Server certificate renewal: keys made on each server (never uploaded), only signed certificates uploaded; targets IIS, RDP, nginx/Apache, Java keystores, custom paths; WinRM out of scope.
- No site host names in anything shipped.

## 9. Engineering conventions (keep these)

- Every schema file idempotent; **no SQL view built on `*`** (breaks re-runs when a table gains columns); views dropped and recreated with explicit columns.
- Checks run on every build: Python 3.11 f-string problems; imports only from the image's requirements; INSERT/UPDATE columns exist in the schema; no duplicate views; every compose placeholder filled by phase3b; the Linux agent parses as Python 3.6.
- Shell: `set -Eeuo pipefail`; never `cmd | grep -q` on multi-line output (use `gq() { grep "$@" >/dev/null; }`); curl failures give `000` once (`|| true`, then `${code:-000}`), never `|| echo 000`.
- PowerShell: 5.1 only, strict mode, plain ASCII, `Get-Prop` for values that may be missing, `ConvertTo-Json -InputObject` (not a pipe), whole-second UTC timestamps.
- TLS checks must use the same verifier as the agent (Python's, no partial chains), not curl, which accepts an intermediate as an anchor.
- nginx reads its key as uid 1001, gid 0: the key stays `root:0 0640`; overwrite certificate files in place to keep owner, mode and SELinux label.
- Each release: cumulative tar, `MANIFEST.sha256`, verified after packing; README notes newest first.
- Test scripts end to end where possible (stand-in servers, real TLS); say plainly what could not be run (PowerShell has no runtime in the build environment).

## 10. Lessons from recent fixes

- The worker shares the API image, whose built-in health check asks the API's web server: the worker now has its own heartbeat check (`python -m app.health worker`).
- `patch01ctl` waits for real health even for layers already running (right after boot health is still "starting"), reports a failed layer and still starts the rest, and keeps its boot unit active when degraded so the clean stop at shutdown still runs.
- The Linux precheck used to search `dnf history` for "E", which also means Erase: replaced by `dnf check` (1.6.1).
- Console certificate install first failed because the key was written 0600: fixed (r38).
- `phase7-vmware.sh --add-writer`, `--remove-writer` and `--install-timer` had been broken by a misplaced block: fixed (r40); a failed add never leaves credentials behind.
- On PATCH-01 itself, its own name resolves locally (often to an IPv6 link-local address): DNS checks must ask the DNS server.
- After an IP change, when everything outside the subnet fails at once, look at the gateway and the firewall first.

## 11. Current state (where to pick up)

Done recently: IP change of PATCH-01 and AI-01; CA-signed certificate installed
from the console; firewall rules opened (vCenter confirmed live); all layers
healthy; three WSUS servers supported.

In progress, in this order:
1. **Linux patch test** on one RHEL 9 server: upgrade its agent to 1.6.1 (`setup-agent.sh`, CA chain = root, or root + intermediate), then a patch job (snapshot on, reboot if required). The first attempt stopped at the precheck because of the "E" bug.
2. **vCenter write account test:** `--add-writer <vcenter name>` (r40 or later), `--sync`, check the test VM shows on its server's page, then create and remove a snapshot from **Changes > New VMware action**; `--remove-writer` afterwards.
3. **Windows patch test** on one server: `Setup-Agent.ps1` (first real run of that script), confirm 1.1.0-win and missing updates listed, then a patch job.
4. **Rollout:** about 100 Linux (`push-linux.sh`) and 150 Windows (`push-agent.ps1`, `-Pin system` if Windows trusts the CA), in batches of 20 to 30; switch already-enrolled Linux agents from `--insecure` to `--ca`.
5. Confirm the mail relay accepts PATCH-01's new IP (Admin > Mail > test).

## 12. Backlog

- **S3** Server certificate renewal: expiry tracking and alerts; agent makes the key and CSR on the server; signed certificates uploaded in the console; install, bind, restart and verify per target (IIS, RDP, nginx/Apache first, then Java keystores and custom paths); CA certificates into trust stores.
- **S1** Linux packages from the repositories: install, upgrade, remove, with a protected list (kernel, glibc, systemd, openssh, sudo, dnf/rpm, SELinux, the agent) and a preview.

- **H2** Hardening exceptions (operator requests, admin approves, expiry) and drift alerts; scores with and without exceptions; exceptions in reports.
- **H3+** Use the custom document's own values (for example "14 characters").
- **H5** Chosen hardening fixes through the change engine (preview, snapshot, apply, re-scan).
- **H7** ESXi and vCenter hardening checks (read-only, through vCenter).
- **Oracle Linux hardening** (parked; asked to be reminded): SSG has no CIS profile for OL 7/8/9; options are a non-CIS profile (PCI-DSS, STIG) or CIS L1 mapped from RHEL rules.
- Mirror the missing repositories (RHEL 8, Oracle Linux 7 and 9, Ubuntu), nightly sync and CVE timers, mirror freshness on screen.
- Oracle and Ubuntu advisory feeds; unfixed CVEs.
- One-time vCenter credentials entered in the console for a single change.
- MCP read-only query layer; single sign-on; VMware map extras (dependency lines from flow records, performance overlay).
