/* Cyber-Secure: the dashboard, the CVE news boards, the sign-in welcome and
 * the CVE feed settings.
 *
 * Everything shown is text from the API, written with textContent (the h()
 * helper); nothing is inserted as HTML. Links to CVE pages are built by the
 * API, always to the vendor's own site, and open with no referrer.
 */

/* ---- brand ---------------------------------------------------------------- */

const PORTAL = "Cyber-Secure";
let brandInfo = null;

async function loadBrand() {
  if (brandInfo) return brandInfo;
  try {
    const r = await fetch("/api/v1/public/brand", { headers: { Accept: "application/json" } });
    brandInfo = r.ok ? await r.json() : { has_logo: false, has_logo_white: false };
  } catch (e) { brandInfo = { has_logo: false, has_logo_white: false }; }
  return brandInfo;
}

function isDarkTheme() {
  const t = document.documentElement.getAttribute("data-theme");
  return t === "dark" || t === "hacker";
}

/* The logo for a dark background (the top bar is dark in every theme). */
function logoImg(onDark, cls) {
  const b = brandInfo || {};
  if (!b.has_logo && !b.has_logo_white) return null;
  const variant = onDark && b.has_logo_white ? "white" : "main";
  const img = h("img", { class: cls + (onDark && !b.has_logo_white ? " logo-chip" : ""),
                         src: "/api/v1/public/logo?variant=" + variant, alt: "", decoding: "async" });
  img.addEventListener("error", () => img.remove());
  return img;
}

async function applyBrand() {
  await loadBrand();
  document.title = PORTAL;
  const a = document.querySelector(".top .brand");
  if (a && !a.dataset.branded) {
    a.dataset.branded = "1";
    const img = logoImg(true, "brand-logo-top");
    a.replaceChildren(...[img, h("span", { class: "brand-name" }, PORTAL)].filter(Boolean));
    a.classList.toggle("has-logo", !!img);
    a.title = PORTAL;
    a.setAttribute("aria-label", PORTAL + " dashboard");
  }
}

/* ---- donuts --------------------------------------------------------------- */

const SVGNS = "http://www.w3.org/2000/svg";
function svg(tag, attrs, ...kids) {
  const el = document.createElementNS(SVGNS, tag);
  Object.entries(attrs || {}).forEach(([k, v]) => { if (v !== null && v !== undefined) el.setAttribute(k, String(v)); });
  kids.flat().forEach(k => { if (k) el.append(k instanceof Node ? k : document.createTextNode(String(k))); });
  return el;
}

/* segs: [{label, value, cls, href?, note?}]. Each colour comes from a class,
 * so the theme decides it; the legend always names every segment, so colour
 * never carries meaning on its own. */
function donut(title, segs, opts = {}) {
  const total = segs.reduce((a, s) => a + (Number(s.value) || 0), 0);
  const R = 52, SW = 14, C = 2 * Math.PI * R, GAP = total && segs.filter(s => s.value > 0).length > 1 ? 2.5 : 0;
  const ring = svg("g", { transform: "rotate(-90 70 70)" },
    svg("circle", { cx: 70, cy: 70, r: R, class: "dn-track", "stroke-width": SW, fill: "none" }));
  const tip = h("div", { class: "dn-tip", role: "status", "aria-live": "polite" });
  let start = 0;
  const shown = [];
  segs.forEach((s, i) => {
    const v = Number(s.value) || 0;
    if (!total || v <= 0) return;
    const len = Math.max(0.8, (v / total) * C - GAP);
    const pct = Math.round((v / total) * 100);
    const arc = svg("circle", {
      cx: 70, cy: 70, r: R, fill: "none", "stroke-width": SW, class: "dn-seg " + s.cls,
      "stroke-dasharray": "0 " + C, "stroke-dashoffset": -start, "data-len": len, "data-c": C, tabindex: 0,
      role: "img", "aria-label": s.label + ": " + v + " (" + pct + "%)" },
      svg("title", null, s.label + ": " + v + " (" + pct + "%)"));
    const show = () => { tip.textContent = s.label + ": " + v + " (" + pct + "%)" + (s.note ? " · " + s.note : ""); };
    arc.addEventListener("mouseenter", show);
    arc.addEventListener("focus", show);
    arc.addEventListener("mouseleave", () => { tip.textContent = ""; });
    if (s.href) arc.addEventListener("click", () => { location.hash = s.href; });
    if (s.href) arc.classList.add("dn-link");
    ring.append(arc);
    shown.push(arc);
    start += (v / total) * C;
  });
  const centre = svg("text", { x: 70, y: 68, "text-anchor": "middle", class: "dn-total" },
    opts.centre !== undefined ? opts.centre : String(total));
  const sub = svg("text", { x: 70, y: 88, "text-anchor": "middle", class: "dn-sub" },
    opts.centreLabel || (total ? "total" : "no data yet"));
  const pic = svg("svg", { viewBox: "0 0 140 140", class: "dn-svg", "aria-hidden": "true", focusable: "false" }, ring, centre, sub);
  const legend = h("ul", { class: "dn-legend" }, segs.map(s => {
    const v = Number(s.value) || 0;
    const label = h("span", { class: "dn-l", title: s.label }, s.label);
    return h("li", { class: v ? null : "dn-zero" },
      h("span", { class: "dn-key " + s.cls, "aria-hidden": "true" }),
      s.href ? h("a", { href: s.href }, label) : label,
      h("span", { class: "dn-v" }, String(v)),
      h("span", { class: "dn-p" }, total ? Math.round((v / total) * 100) + "%" : ""));
  }));
  // Draw the arcs once they are in the page, so they sweep in
  requestAnimationFrame(() => requestAnimationFrame(() => shown.forEach(a => {
    a.setAttribute("stroke-dasharray", a.dataset.len + " " + (Number(a.dataset.c) - Number(a.dataset.len)));
  })));
  return h("section", { class: "dn-card", "aria-label": title + ": " + segs.map(s => s.label + " " + (s.value || 0)).join(", ") },
    h("h2", { class: "dn-h" }, title),
    opts.caption ? h("p", { class: "dn-cap" }, opts.caption) : null,
    h("div", { class: "dn-body" }, h("div", { class: "dn-pic" }, pic, tip), legend));
}

/* ---- news board ------------------------------------------------------------ */

const FEED_NAME = { nist: "NIST NVD", msrc: "Microsoft", redhat: "Red Hat" };
const SEV_CLASS = { critical: "sv-crit", high: "sv-high", important: "sv-high", medium: "sv-med", moderate: "sv-med", low: "sv-low" };

function sevChip(sev, cvss) {
  const s = (sev || "").toLowerCase();
  return h("span", { class: "sv " + (SEV_CLASS[s] || "sv-low") },
    (s ? s.charAt(0).toUpperCase() + s.slice(1) : "Unrated") + (cvss !== null && cvss !== undefined ? " " + Number(cvss).toFixed(1) : ""));
}

function safeVendorUrl(u) {
  // Only the three vendors' own sites, over HTTPS
  return /^https:\/\/(nvd\.nist\.gov|msrc\.microsoft\.com|access\.redhat\.com)\//.test(u || "") ? u : null;
}

function newsItem(it, opts = {}) {
  const url = safeVendorUrl(it.url);
  const id = url ? h("a", { href: url, target: "_blank", rel: "noopener noreferrer", class: "nw-id" }, it.cve_id)
                 : h("span", { class: "nw-id" }, it.cve_id);
  const when = it.published ? new Date(it.published) : null;
  return h("li", { class: "nw-item" + (it.exploited ? " nw-kev" : "") },
    h("div", { class: "nw-top" },
      sevChip(it.severity, it.cvss), id,
      opts.source ? h("span", { class: "nw-src" }, FEED_NAME[it.source] || it.source) : null,
      it.exploited ? h("span", { class: "nw-flag" }, "Exploited") : null,
      h("time", { class: "nw-when", datetime: it.published || "" }, when ? when.toLocaleDateString(undefined, { day: "numeric", month: "short" }) : "")),
    h("p", { class: "nw-title" }, it.title || ""),
    (it.matched && it.matched.length) || it.servers_affected ? h("div", { class: "nw-tags" },
      (it.matched || []).map(m => h("span", { class: "nw-tag" }, m)),
      it.servers_affected ? h("span", { class: "nw-tag nw-hit" },
        it.servers_affected === 1 ? "1 of your servers" : it.servers_affected + " of your servers") : null) : null);
}

/* ---- the dashboard ---------------------------------------------------------- */

const OS_CLASSES = ["c-cat1", "c-cat2", "c-cat3", "c-cat4", "c-cat5", "c-cat6"];

async function renderCyberDashboard() {
  setNav("overview");
  applyBrand();
  const [d, news] = await Promise.all([
    api("/dashboard/summary"),
    api("/feeds/news?scope=watched").catch(() => null),
  ]);
  const page = h("div", { class: "cy" });
  render(page);
  drawDashboard(page, d, news);
  setPageTimer(async () => {
    if (document.hidden) return;
    try {
      const [d2, n2] = await Promise.all([api("/dashboard/summary"), api("/feeds/news?scope=watched").catch(() => null)]);
      if (!document.body.contains(page)) return;
      const y = window.scrollY;
      drawDashboard(page, d2, n2, true);
      window.scrollTo(0, y);
    } catch (e) { /* keep the last figures; the next tick retries */ }
  }, 60000);
}

function drawDashboard(page, d, news, quiet) {
  const s = d.servers || {}, a = d.advisories || {}, sv = d.severity || {}, ag = d.agents || {};
  const f = (d.feeds && d.feeds.counts) || null;
  const at = d.at ? new Date(d.at) : new Date();
  const hero = (n, label, cls, href) => h(href ? "a" : "div", { class: "cy-hero " + (cls || ""), href: href || null },
    h("span", { class: "cy-n" }, n === null || n === undefined ? "–" : String(n)), h("span", { class: "cy-l" }, label));

  const head = h("div", { class: "page-head cy-head" },
    h("div", null,
      h("h1", { "data-cmd": "cybersecure status" }, PORTAL),
      h("p", { class: "muted small" }, "Live security posture · updated " + at.toLocaleTimeString() + " · refreshes every minute")),
    h("div", { class: "cy-heroes" },
      hero(d.compliance_pct === null ? null : d.compliance_pct + "%", "patch compliance", "cy-ok"),
      hero(s.total || 0, "servers", "", "#/hosts"),
      hero(sv.critical || 0, "critical updates outstanding", sv.critical ? "cy-bad" : "", "#/advisories?state=affected"),
      f ? hero(f.critical || 0, "new critical CVEs, " + d.feeds.days + " days", f.critical ? "cy-bad" : "") : null));

  if (!s.total) {
    page.replaceChildren(head, h("div", { class: "empty" },
      h("h2", null, "No servers have enrolled yet"),
      h("p", null, "Issue a token with ", h("code", null, "./scripts/phase3b-api.sh --token"),
        ", then install the agent on a server. It appears here within a minute.")));
    return;
  }

  const grid = h("div", { class: "cy-grid" },
    donut("Servers", [
      { label: "Patched", value: s.patched, cls: "c-ok", href: "#/hosts" },
      { label: "Needs patches", value: s.needs_patch, cls: "c-bad", href: "#/advisories?state=affected" },
      { label: "Needs a reboot", value: s.needs_reboot, cls: "c-warn", href: "#/advisories?state=fixed_pending_reboot" },
      { label: "Not reporting", value: s.not_reporting, cls: "c-muted", href: "#/agents", note: "status unknown until it reports" },
    ], { caption: "Each server once, by its worst state" }),
    donut("Updates", [
      { label: "To install", value: (a.to_install || 0) + (a.windows_to_install || 0), cls: "c-bad",
        note: (a.to_install || 0) + " Linux advisories, " + (a.windows_to_install || 0) + " Windows updates" },
      { label: "Installed, reboot needed", value: a.awaiting_reboot, cls: "c-warn" },
      { label: "Installed", value: a.installed, cls: "c-ok" },
    ], { caption: "Per server and update" }),
    donut("Outstanding by severity", [
      { label: "Critical", value: sv.critical, cls: "c-bad" },
      { label: "Important", value: sv.important, cls: "c-warn" },
      { label: "Moderate", value: sv.moderate, cls: "c-mod" },
      { label: "Low or unrated", value: sv.low_or_unrated, cls: "c-muted" },
    ], { caption: "Distinct advisories and updates still to install" }),
    donut("Operating systems", (d.os || []).map((o, i) => (
      { label: o.os, value: o.n, cls: o.os === "Other" ? "c-muted" : OS_CLASSES[i] || "c-muted" })),
      { caption: "Servers with an agent" }),
    donut("Agents", [
      { label: "Online", value: ag.online || 0, cls: "c-ok", href: "#/agents" },
      { label: "Offline", value: ag.offline || 0, cls: "c-warn", href: "#/agents" },
      { label: "Not reporting", value: ag.not_reporting || 0, cls: "c-bad", href: "#/agents" },
      { label: "Never reported", value: ag.no_data || 0, cls: "c-muted", href: "#/agents" },
    ]),
    f ? donut("New CVEs (feeds)", [
      { label: "Critical", value: f.critical, cls: "c-bad" },
      { label: "High", value: f.high, cls: "c-warn" },
      { label: "Medium", value: f.medium, cls: "c-mod" },
      { label: "Low", value: f.low, cls: "c-muted" },
    ], { caption: (d.feeds.watch_list ? "Your watched software" : "All software (no watch list yet)")
                 + ", last " + d.feeds.days + " days · " + (f.exploited || 0) + " exploited · "
                 + (f.affecting || 0) + " on your servers" })
      : donut("New CVEs (feeds)", [], { caption: "Feeds are not set up yet: Admin, CVE feeds", centreLabel: "not set up" }));

  page.replaceChildren(head, grid, newsBoard(news));
  if (quiet) page.querySelectorAll(".dn-seg").forEach(x => x.classList.add("dn-noanim"));
}

function newsBoard(news) {
  const items = (news && news.items) || [];
  let tab = "all";
  const list = h("ul", { class: "nw-list" });
  const tabs = h("div", { class: "filters nw-tabs", role: "group", "aria-label": "Feed" });
  const fill = () => {
    const rows = items.filter(i => tab === "all" || i.source === tab).slice(0, 60);
    list.replaceChildren(...(rows.length ? rows.map(i => newsItem(i, { source: tab === "all" })) :
      [h("li", { class: "nw-empty" }, news ? (news.watch_list
        ? "Nothing new for your watched software in this period."
        : "No CVEs collected yet. An admin chooses the software to follow under Admin, CVE feeds.")
        : "The feeds are not available: rebuild the API (phase3b-api.sh).")]));
    tabs.querySelectorAll("button").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === tab)));
  };
  [["all", "All"], ["nist", "NIST"], ["msrc", "Microsoft"], ["redhat", "Red Hat"]].forEach(([k, label]) => {
    const n = k === "all" ? items.length : items.filter(i => i.source === k).length;
    tabs.append(h("button", { type: "button", class: "fbtn", "data-k": k, on: { click: () => { tab = k; fill(); } } },
      label + " (" + n + ")"));
  });
  fill();
  return h("section", { class: "cy-news", "aria-labelledby": "cy-news-h" },
    h("div", { class: "cy-news-head" },
      h("h2", { id: "cy-news-h" }, "CVE news"),
      h("span", { class: "muted small" }, news && news.watch_list
        ? "For the software on your watch list, and anything already on your servers"
        : "Everything collected; choose software to follow under Admin, CVE feeds"),
      can("admin") ? h("a", { href: "#/feeds", class: "small" }, "Choose software") : null),
    tabs, list);
}

/* ---- sign-in page: welcome and news board ----------------------------------- */

let signinNewsTimer = null;

async function signinDecor(formEl) {
  await loadBrand();
  if (!formEl.isConnected) return null;      // the user moved on (signed in) meanwhile
  const prevFocus = document.activeElement;  // moving the form into the layout drops focus
  const logo = logoImg(isDarkTheme(), "signin-logo");
  const welcome = h("div", { class: "signin-welcome" },
    logo,
    h("p", { class: "signin-kicker" }, "Welcome to the"),
    h("h1", { class: "signin-title", "data-cmd": "login" }, PORTAL + " Dashboard portal"),
    h("p", { class: "muted" }, "Patch, vulnerability, hardening and VMware posture in one place."));
  const board = h("section", { class: "signin-news", "aria-labelledby": "sn-h" },
    h("h2", { id: "sn-h" }, "Latest CVE advisories"),
    h("p", { class: "muted small" }, "New, high-severity CVEs published by NIST, Microsoft and Red Hat"),
    h("div", { class: "sn-cols" }, h("p", { class: "muted small" }, "Loading")));
  const wrap = h("div", { class: "signin-page" }, h("div", { class: "signin-left" }, welcome, formEl), board);
  async function loadNews() {
    let d = null;
    try {
      const r = await fetch("/api/v1/public/news", { headers: { Accept: "application/json" } });
      d = r.ok ? await r.json() : null;
    } catch (e) { d = null; }
    if (!board.isConnected) { clearInterval(signinNewsTimer); return; }
    if (!d || !d.enabled) { board.remove(); wrap.classList.add("signin-solo"); return; }
    const cols = Object.entries(d.sources || {});
    board.querySelector(".sn-cols").replaceChildren(...(cols.length ? cols.map(([src, rows]) =>
      h("div", { class: "sn-col" },
        h("h3", null, FEED_NAME[src] || src),
        rows.length ? h("ul", { class: "nw-list" }, rows.map(i => newsItem(i)))
                    : h("p", { class: "muted small" }, "Nothing new in this period."))) :
      [h("p", { class: "muted small" }, "No CVEs collected yet.")]));
  }
  wrap.prevFocus = prevFocus;
  loadNews();
  clearInterval(signinNewsTimer);
  signinNewsTimer = setInterval(loadNews, 120000);
  return wrap;
}

/* ---- admin: CVE feeds ------------------------------------------------------- */

async function renderFeedsAdmin() {
  setNav("admin");
  const d = await api("/admin/feeds");
  const page = h("div", { class: "feeds-admin" });
  render(page);
  drawFeedsAdmin(page, d);
  adminTabs("feeds");
}

function drawFeedsAdmin(page, d) {
  const st = d.settings || {};
  const msg = h("p", { class: "cm-meta", role: "status" });
  const box = (k, label) => h("label", { class: "cm-check" }, h("input", { type: "checkbox", name: k, checked: !!st[k] }), " " + label);
  const num = (k, label, min, max, step) => h("label", null, h("span", null, label),
    h("input", { type: "number", name: k, value: st[k], min, max, step: step || 1, required: true }));
  const form = h("form", { class: "feeds-form", on: { submit: async e => {
    e.preventDefault();
    const fd = new FormData(form);
    const body = { nist: fd.has("nist"), msrc: fd.has("msrc"), redhat: fd.has("redhat"), signin_board: fd.has("signin_board"),
                   days_back: Number(fd.get("days_back")), min_cvss: Number(fd.get("min_cvss")),
                   interval_minutes: Number(fd.get("interval_minutes")), signin_min_cvss: Number(fd.get("signin_min_cvss")) };
    try { const r = await apiSend("PUT", "/admin/feeds/settings", body); drawFeedsAdmin(page, r); }
    catch (err) { msg.textContent = err.message || "Could not save."; }
  } } },
    h("fieldset", null, h("legend", null, "Sources"), box("nist", "NIST NVD"), box("msrc", "Microsoft"), box("redhat", "Red Hat")),
    h("div", { class: "feeds-nums" },
      num("days_back", "Days to show", 1, 90), num("min_cvss", "Lowest CVSS on the dashboard", 0, 10, 0.1),
      num("interval_minutes", "Read every (minutes)", 15, 1440)),
    h("fieldset", null, h("legend", null, "Sign-in page"),
      box("signin_board", "Show the news board before sign-in"),
      num("signin_min_cvss", "Lowest CVSS on the sign-in board", 0, 10, 0.1),
      h("p", { class: "muted small" }, "The sign-in board shows only the general feeds (new critical and high CVEs), "
        + "never your watch list, so it does not reveal what software you run.")),
    h("div", { class: "cm-actions" }, h("button", { type: "submit" }, "Save"), msg));

  const term = h("input", { type: "text", maxlength: "60", placeholder: "for example: openssl, apache tomcat, vmware vcenter",
                            "aria-label": "Software to follow", required: true });
  const kind = h("select", { "aria-label": "Kind" }, ["software", "vendor", "keyword"].map(k => h("option", { value: k }, k)));
  const addMsg = h("p", { class: "cm-meta", role: "status" });
  const add = async (t, k) => {
    try { const r = await apiPost("/admin/feeds/watch", { term: t, kind: k || "software" }); drawFeedsAdmin(page, r); }
    catch (err) { addMsg.textContent = err.message || "Could not add."; }
  };
  const addForm = h("form", { class: "feeds-add", on: { submit: e => { e.preventDefault(); add(term.value.trim(), kind.value); } } },
    term, kind, h("button", { type: "submit" }, "Add"));

  const watch = d.watch || [];
  const watchTable = watch.length ? table([
    { label: "Software", cell: w => w.term },
    { label: "Kind", cell: w => w.kind },
    { label: "Following", cell: w => h("input", { type: "checkbox", checked: !!w.enabled, "aria-label": "Follow " + w.term,
        on: { change: async e => { try { drawFeedsAdmin(page, await apiSend("PATCH", "/admin/feeds/watch/" + w.id, { enabled: e.target.checked })); }
                                   catch (err) { addMsg.textContent = err.message; } } } }) },
    { label: "Added", cell: w => (w.added_by || "") + ", " + timeAgo(w.added_at) },
    { label: "", cell: w => h("button", { type: "button", class: "btn-link", on: { click: async () => {
        try { drawFeedsAdmin(page, await apiSend("DELETE", "/admin/feeds/watch/" + w.id)); } catch (err) { addMsg.textContent = err.message; } } } }, "Remove") },
  ], watch) : h("p", { class: "muted" }, "Nothing on the watch list yet. Until you add software, the dashboard shows every CVE collected.");

  const sugBox = h("div", { class: "feeds-sug" }, h("p", { class: "muted small" }, "Loading what your servers run"));
  api("/admin/feeds/suggestions").then(sg => {
    const group = (title, rows) => rows.length ? h("div", null, h("h3", null, title),
      h("div", { class: "chips" }, rows.slice(0, 40).map(r => h("button", { type: "button", class: "chip",
        title: r.servers ? "On " + r.servers + " server(s): add to the watch list" : "Add to the watch list",
        on: { click: () => add(r.name, r.kind) } }, "+ " + r.name + (r.servers ? " (" + r.servers + ")" : ""))))) : null;
    sugBox.replaceChildren(...[group("Windows software on your servers", sg.windows || []),
      group("Linux software on your servers", sg.linux || []), group("Operating systems", sg.os || [])].filter(Boolean));
    if (!sugBox.childNodes.length) sugBox.replaceChildren(h("p", { class: "muted small" }, "Everything your servers report is already on the list."));
  }).catch(() => sugBox.replaceChildren(h("p", { class: "muted small" }, "Suggestions are not available.")));

  const state = d.state || [];
  const stored = {};
  (d.stored || []).forEach(r => { stored[r.source] = r; });
  const stateTable = table([
    { label: "Source", cell: r => FEED_NAME[r.source] || r.source },
    { label: "Last read", cell: r => r.last_ok ? timeAgo(r.last_ok) : "never" },
    { label: "Read last time", num: true, cell: r => r.items === null || r.items === undefined ? "" : r.items },
    { label: "Kept", num: true, cell: r => stored[r.source] ? stored[r.source].n : 0 },
    { label: "Problem", cell: r => r.error ? h("span", { class: "hd-failed" }, r.error) : "" },
  ], ["nist", "msrc", "redhat"].map(k => Object.assign({ source: k }, state.find(x => x.source === k) || {})));
  const syncMsg = h("span", { class: "cm-meta", role: "status" });
  const syncBtn = h("button", { type: "button", on: { click: async () => {
    syncBtn.disabled = true;
    try { await apiPost("/admin/feeds/sync", {}); syncMsg.textContent = "Asked the worker: it starts within a minute. NIST takes a few minutes"
          + (d.nvd_api_key ? "." : " without an NVD API key."); }
    catch (err) { syncMsg.textContent = err.message; syncBtn.disabled = false; }
  } } }, "Read the feeds now");

  page.replaceChildren(
    h("div", { class: "page-head" }, h("h1", { "data-cmd": "cybersecure feeds" }, "CVE feeds")),
    h("p", { class: "muted" }, "New CVEs from NIST NVD, Microsoft and Red Hat, read through the proxy by PATCH-01's worker. "
      + "Choose the software to follow: the dashboard and its news then show only CVEs naming that software, "
      + "plus any CVE already found on your servers."),
    h("section", null, h("h2", null, "Software to follow"), addForm, addMsg, watchTable, sugBox),
    h("section", null, h("h2", null, "Settings"), form),
    h("section", null, h("h2", null, "Status"), stateTable, h("div", { class: "cm-actions" }, syncBtn, syncMsg),
      d.worker_seen ? null : h("p", { class: "hd-failed" }, "The worker has not started reading feeds yet: rebuild it with phase3b-api.sh."),
      d.nvd_api_key || !d.worker_seen ? null : h("p", { class: "muted small" }, "No NVD API key is set, so NIST is read slowly "
        + "(5 requests every 30 seconds). A free key from NIST raises that tenfold: save it in /patch/secrets/nvd-api-key "
        + "on PATCH-01 and run phase3b-api.sh.")));
}
