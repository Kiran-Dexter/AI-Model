"""Vulnerabilities > Remediation (r131): the quarterly Nessus scan workbook. The work is in remediation.py."""

import re
from typing import Dict, List, Optional

from fastapi import Depends, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field

from .core import app, audit, client_ip, db, jsonable, require_operator, require_viewer
from . import remediation as rm

BASE = "/api/v1/nessus/remediation"
FILTER_KEYS = ("quarter", "sev", "status", "open", "pic", "cat1", "cat2", "env", "kind", "team_type", "host", "overdue",
               "came_back", "new", "q", "group_by", "group")


def _filters(request: Request):
    """The page's filters from the query string. "(blank)" is sent as an empty value of *_blank=1."""
    p = {}
    for k in FILTER_KEYS:
        v = request.query_params.get(k)
        if v is not None:
            if re.search(r"[\x00-\x08\x0b-\x1f\x7f]", v):
                raise HTTPException(400, f"{k}: control characters are not allowed.")
            p[k] = v[:600]
    for k in ("pic", "cat1", "cat2", "env"):
        if request.query_params.get(k + "_blank") == "1":
            p[k] = "\x00"
    return p


def _call(fn):
    try:
        return fn()
    except rm.RemError as e:
        raise HTTPException(400, str(e))
    except rm.NotFound as e:
        raise HTTPException(404, str(e))


def _uid(v):
    v = str(v or "").strip().lower()
    if not re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", v):
        raise HTTPException(404, "No such upload.")
    return v


def _audit(conn, user, request, action, detail):
    audit(conn, actor=user, actor_type="user", action=action, object_type="remediation", detail=detail,
          source_ip=client_ip(request))
    conn.commit()


def _can_edit(request):
    from . import auth
    return auth.role_at_least((request.state.user or {}).get("role") or "viewer", "operator")


@app.get(BASE)
def rem_home(request: Request, user: str = Depends(require_viewer)):
    """The quarters there are, the uploads (the latest first), and what this user may do."""
    with db() as conn:
        return jsonable({"quarters": rm.quarters(conn), "uploads": rm.uploads(conn), "can_edit": _can_edit(request),
                         "statuses": [{"key": k, "label": l} for k, l in rm.STATUSES],
                         "severities": [{"key": k, "label": l} for k, l in rm.SEVERITIES],
                         "kinds": [{"key": k, "label": l} for k, l in rm.KINDS.items()],
                         "groups": [{"key": k, "label": v[1]} for k, v in rm.GROUPS.items()]})


@app.get(BASE + "/summary")
def rem_summary(request: Request, user: str = Depends(require_viewer)):
    p = _filters(request)
    with db() as conn:
        return jsonable(_call(lambda: rm.summary(conn, p)))


@app.get(BASE + "/groups")
def rem_groups(request: Request, user: str = Depends(require_viewer)):
    p = _filters(request)
    with db() as conn:
        return jsonable(_call(lambda: rm.groups(conn, p)))


@app.get(BASE + "/findings")
def rem_findings(request: Request, offset: int = 0, limit: int = 200, user: str = Depends(require_viewer)):
    p = _filters(request)
    with db() as conn:
        return jsonable(_call(lambda: rm.findings(conn, p, offset, limit)))


@app.get(BASE + "/findings/{fid}")
def rem_finding(fid: int, user: str = Depends(require_viewer)):
    with db() as conn:
        return jsonable(_call(lambda: rm.finding(conn, fid)))


class BulkIn(BaseModel):
    ids: Optional[List[int]] = Field(None, max_length=50000)
    all: bool = False                                  # every finding the filters show (the filters are in the query)
    set: Dict[str, Optional[str]] = Field(default_factory=dict)
    note: Optional[str] = Field(None, max_length=500)


@app.post(BASE + "/findings/bulk")
def rem_bulk(body: BulkIn, request: Request, user: str = Depends(require_operator)):
    p = _filters(request)
    if not body.all and not body.ids:
        raise HTTPException(400, "Choose at least one finding.")
    with db() as conn:
        r = _call(lambda: rm.bulk_edit(conn, user, ids=None if body.all else body.ids, params=p if body.all else None,
                                       changes=body.set, note=body.note))
        _audit(conn, user, request, "remediation_edited", {"set": {k: v for k, v in body.set.items()}, "note": body.note,
                                                           "findings": r["findings"], "changed": r["changed"],
                                                           "by_filter": bool(body.all), "quarter": p.get("quarter")})
    return r


@app.get(BASE + "/hosts")
def rem_hosts(request: Request, user: str = Depends(require_viewer)):
    p = _filters(request)
    with db() as conn:
        return jsonable(_call(lambda: rm.hosts(conn, p)))


class HostsIn(BaseModel):
    keys: List[str] = Field(..., min_length=1, max_length=5000)
    team_type: Optional[str] = Field(None, max_length=20)
    team: Optional[str] = Field(None, max_length=120)
    kind: Optional[str] = Field(None, max_length=20)


@app.put(BASE + "/hosts")
def rem_hosts_set(body: HostsIn, request: Request, user: str = Depends(require_operator)):
    keys = [k[:255] for k in body.keys if k]
    with db() as conn:
        n = _call(lambda: rm.set_hosts(conn, user, keys, body.team_type, body.team, body.kind))
        _audit(conn, user, request, "remediation_hosts_set", {"hosts": len(keys), "team_type": body.team_type,
                                                              "team": body.team, "kind": body.kind})
    return {"hosts": n}


@app.post(BASE + "/hosts/refresh")
def rem_hosts_refresh(request: Request, user: str = Depends(require_operator)):
    """Each host's device type looked up in the inventory again (after an asset was added or its type set)."""
    with db() as conn:
        n = _call(lambda: rm.refresh_hosts(conn))
    return {"hosts": n}


# ---- uploads ---------------------------------------------------------------------------------------------------

@app.post(BASE + "/uploads")
async def rem_upload(request: Request, name: str = "scan.xlsx", gz: int = 0, user: str = Depends(require_operator)):
    """The file itself as the request body (xlsx or csv; a big csv gzipped by the browser, gz=1). At most 60 MB."""
    from starlette.concurrency import run_in_threadpool
    data = bytearray()
    async for chunk in request.stream():
        data += chunk
        if len(data) > rm.MAX_BYTES:
            raise HTTPException(413, "The file is larger than 60 MB. Save it as .xlsx (it is much smaller than .csv) and try again.")

    def work():
        with db() as conn:
            uid = _call(lambda: rm.start_upload(conn, user, name, bytes(data), bool(gz)))
            _audit(conn, user, request, "remediation_uploaded", {"upload": uid, "file": name[:200], "bytes": len(data)})
            return uid
    uid = await run_in_threadpool(work)
    rm.run_in_background(rm.read_upload, uid)
    return {"id": uid}


@app.get(BASE + "/uploads")
def rem_uploads(user: str = Depends(require_viewer)):
    with db() as conn:
        return jsonable({"items": rm.uploads(conn, 50)})


@app.get(BASE + "/uploads/{uid}")
def rem_upload_view(uid: str, user: str = Depends(require_viewer)):
    uid = _uid(uid)
    with db() as conn:
        return jsonable(_call(lambda: rm.upload_view(conn, uid)))


@app.post(BASE + "/uploads/{uid}/suggest")
def rem_upload_suggest(uid: str, request: Request, user: str = Depends(require_operator)):
    """AI-01 reads the columns PATCH-01's rules could not place (heading and a few values each)."""
    from . import llm
    uid = _uid(uid)
    if not llm.configured():
        raise HTTPException(503, "AI-01 is not set up: place the columns yourself.")

    def ask(messages, schema):
        return llm.choose(messages, max_tokens=900, timeout=50, schema=schema, temperature=0.1, wait=20)
    with db() as conn:
        llm.mark_interactive(conn)
        try:
            n = _call(lambda: rm.suggest(conn, uid, ask))
        except llm.LLMBusy:
            raise HTTPException(429, "AI-01 is busy: try again in a moment, or place the columns yourself.")
        except llm.LLMUnavailable as e:
            raise HTTPException(503, f"AI-01 could not be reached ({str(e)[:160]}): place the columns yourself.")
        _audit(conn, user, request, "remediation_ai_columns", {"upload": uid, "placed": n})
        return jsonable(dict(rm.upload_view(conn, uid), ai_placed=n))


class ConfirmSheet(BaseModel):
    name: str = Field(..., max_length=200)
    use: bool = True
    quarter: Optional[str] = Field(None, max_length=20)
    columns: Optional[List[Optional[str]]] = Field(None, max_length=rm.MAX_COLS)


class ConfirmIn(BaseModel):
    sheets: List[ConfirmSheet] = Field(..., max_length=100)
    status_words: Dict[str, str] = Field(default_factory=dict)
    date_order: Optional[str] = Field(None, pattern="^(dmy|mdy)$")
    remove_missing: bool = False


@app.post(BASE + "/uploads/{uid}/confirm")
def rem_upload_confirm(uid: str, body: ConfirmIn, request: Request, user: str = Depends(require_operator)):
    uid = _uid(uid)
    if len(body.status_words) > 200:
        raise HTTPException(400, "Too many status words.")
    with db() as conn:
        qs = _call(lambda: rm.confirm(conn, uid, user, body.model_dump()))
        _audit(conn, user, request, "remediation_import_started", {"upload": uid, "quarters": qs,
                                                                   "remove_missing": body.remove_missing})
    rm.run_in_background(rm.run_import, uid)
    return {"ok": True, "quarters": qs}


@app.post(BASE + "/uploads/{uid}/retry")
def rem_upload_retry(uid: str, request: Request, user: str = Depends(require_operator)):
    uid = _uid(uid)
    with db() as conn:
        state = _call(lambda: rm.retry(conn, uid))
        _audit(conn, user, request, "remediation_retried", {"upload": uid, "state": state})
    rm.run_in_background(rm.run_import if state == "importing" else rm.read_upload, uid)
    return {"ok": True, "state": state}


@app.delete(BASE + "/uploads/{uid}")
def rem_upload_discard(uid: str, request: Request, user: str = Depends(require_operator)):
    uid = _uid(uid)
    with db() as conn:
        _call(lambda: rm.discard(conn, uid))
        _audit(conn, user, request, "remediation_discarded", {"upload": uid})
    return {"ok": True}


# ---- export ----------------------------------------------------------------------------------------------------

@app.get(BASE + "/export")
def rem_export(request: Request, user: str = Depends(require_viewer)):
    """The quarter (as filtered) in the file's own columns and headings, with a Summary sheet."""
    from . import exports as ex
    p = _filters(request)
    p.pop("group_by", None)
    p.pop("group", None)
    with db() as conn:
        body, n = _call(lambda: rm.export_xlsx(conn, p, user, ex.company_name(conn)))
        _audit(conn, user, request, "remediation_exported", {"quarter": p.get("quarter"), "rows": n})
    q = rm.short_label(p.get("quarter") or "")
    return Response(body, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={
        "Content-Disposition": f'attachment; filename="{ex.file_name("remediation-" + q, "xlsx")}"',
        "Cache-Control": "no-store", "X-Rows": str(n)})
