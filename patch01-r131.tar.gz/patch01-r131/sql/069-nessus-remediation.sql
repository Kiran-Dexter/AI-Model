-- ---------------------------------------------------------------------------
-- 069 (r131) Vulnerabilities > Remediation: the quarterly Nessus scan workbook
--
-- An operator uploads the scan workbook (xlsx or csv; one sheet per quarter, e.g. "26Q3"). PATCH-01 reads it, says
-- what each column holds and why (its rules, then AI-01 for the columns the rules cannot place), the operator
-- confirms once, and the findings are imported for that quarter. A finding is one plugin on one host and port.
-- Statuses, PIC (engineer), dates, exception and Categorization1/2 are kept per finding with who changed what.
--
-- rem_uploads          one uploaded file: its sheets, columns, the confirmed mapping, progress, the outcome
-- rem_header_memory    a column heading -> the field a person chose for it (used for every later file)
-- rem_status_words     a status word as written in the files -> one of PATCH-01's statuses
-- rem_findings         the findings, per quarter (quarter + plugin + IP/host + port + protocol is unique)
-- rem_history          every change of a finding's tracking fields: who, when, from, to
-- rem_hosts            per host: the device type from the inventory (or a person's choice), Application or Infra,
--                      and the team (blank until a person fills it in)
-- Re-run safe.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS rem_uploads (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    file_name    TEXT NOT NULL,
    size_bytes   BIGINT NOT NULL,
    file_type    TEXT NOT NULL CHECK (file_type IN ('xlsx', 'csv')),
    data         BYTEA,                         -- the file, until it is imported or discarded
    state        TEXT NOT NULL DEFAULT 'reading'
                 CHECK (state IN ('reading', 'review', 'importing', 'imported', 'failed', 'discarded')),
    sheets       JSONB,                         -- per sheet: headers, samples, mapping (with how and why), quarter
    progress     JSONB,                         -- {phase, done, total}
    options      JSONB,                         -- what was confirmed: {remove_missing}
    result       JSONB,                         -- counts per quarter after the import
    error        TEXT,
    created_by   TEXT NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),   -- the reading / import's heartbeat
    imported_by  TEXT,
    imported_at  TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS rem_uploads_created ON rem_uploads (created_at DESC);

CREATE TABLE IF NOT EXISTS rem_header_memory (
    header_norm  TEXT PRIMARY KEY,              -- the heading, lower case, letters and digits only
    field        TEXT NOT NULL,                 -- a field, or 'ignore'
    set_by       TEXT NOT NULL,
    set_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS rem_status_words (
    word_norm    TEXT PRIMARY KEY,
    status       TEXT NOT NULL CHECK (status IN ('open', 'fixed', 'pending_review', 'false_positive',
                                                 'pending_deviation', 'deviation_approved', 'decommission')),
    set_by       TEXT NOT NULL,
    set_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS rem_findings (
    id             BIGSERIAL PRIMARY KEY,
    quarter        TEXT NOT NULL CHECK (quarter ~ '^[0-9]{4} Q[1-4]$'),   -- "2026 Q3"
    fkey           TEXT NOT NULL,               -- plugin | IP or host | port | protocol, lower case
    host_key       TEXT NOT NULL,               -- the host name (short, lower case), or the IP when there is none
    upload_id      UUID REFERENCES rem_uploads(id) ON DELETE SET NULL,
    sheet          TEXT,
    row_no         INT,                         -- the row's number in the sheet, as Excel shows it
    uuid_text      TEXT,
    plugin_id      TEXT,
    plugin_name    TEXT,
    severity       SMALLINT CHECK (severity BETWEEN 0 AND 4),              -- 4 critical .. 0 info; NULL: not given
    severity_text  TEXT,
    ip             TEXT,
    hostname       TEXT,
    env            TEXT,                        -- UAT / Prod, as written
    pic            TEXT,
    port           TEXT,
    protocol       TEXT,
    plugin_output  TEXT,
    synopsis       TEXT,
    description    TEXT,
    solution       TEXT,
    cve            TEXT,
    cvss3          TEXT,
    cvss2          TEXT,
    prev_finding   TEXT,                        -- as the file says
    prev_fixed     TEXT,                        -- as the file says
    exception      TEXT,
    status         TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'fixed', 'pending_review', 'false_positive',
                                                                   'pending_deviation', 'deviation_approved', 'decommission')),
    status_text    TEXT,                        -- the word in the file
    overdue_text   TEXT,                        -- as the file says
    report_shared  DATE,
    completed_on   DATE,
    target_on      DATE,                        -- New Target Completion Date of Remediation
    first_seen     DATE,
    last_seen      DATE,
    vuln_pub       DATE,
    plugin_pub     DATE,
    cat1           TEXT,
    cat2           TEXT,
    er_code        TEXT,                        -- from Categorization2: "ER-2026Q3-M07"
    er_title       TEXT,                        -- from Categorization2: "OS Patch & Core Security"
    extra          JSONB,                       -- the file's other columns, and values that were not dates as written
    carried        TEXT[],                      -- fields taken from the previous quarter (blank in this file)
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by     TEXT,
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (quarter, fkey)
);
CREATE INDEX IF NOT EXISTS rem_findings_q_sev ON rem_findings (quarter, severity);
CREATE INDEX IF NOT EXISTS rem_findings_q_host ON rem_findings (quarter, host_key);
CREATE INDEX IF NOT EXISTS rem_findings_q_status ON rem_findings (quarter, status);
CREATE INDEX IF NOT EXISTS rem_findings_fkey ON rem_findings (fkey, quarter);

CREATE TABLE IF NOT EXISTS rem_history (
    id          BIGSERIAL PRIMARY KEY,
    finding_id  BIGINT NOT NULL REFERENCES rem_findings(id) ON DELETE CASCADE,
    field       TEXT NOT NULL,
    old_value   TEXT,
    new_value   TEXT,
    changed_by  TEXT NOT NULL,
    changed_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    source      TEXT NOT NULL DEFAULT 'edit' CHECK (source IN ('edit', 'import')),
    note        TEXT
);
CREATE INDEX IF NOT EXISTS rem_history_finding ON rem_history (finding_id, changed_at DESC);

CREATE TABLE IF NOT EXISTS rem_hosts (
    host_key     TEXT PRIMARY KEY,
    hostname     TEXT,
    ips          TEXT[] NOT NULL DEFAULT '{}',
    inv_kind     TEXT,                          -- the inventory's device type (server, network, firewall, ...); NULL: not in it
    inv_name     TEXT,
    inv_reason   TEXT,
    checked_at   TIMESTAMPTZ,
    kind         TEXT CHECK (kind IS NULL OR kind IN ('server', 'network', 'appliance')),   -- a person's choice
    team_type    TEXT CHECK (team_type IS NULL OR team_type IN ('application', 'infra')),
    team         TEXT,
    set_by       TEXT,
    set_at       TIMESTAMPTZ
);

INSERT INTO schema_version (version, description)
VALUES (69, 'Remediation: the quarterly Nessus scan workbook')
ON CONFLICT (version) DO NOTHING;
