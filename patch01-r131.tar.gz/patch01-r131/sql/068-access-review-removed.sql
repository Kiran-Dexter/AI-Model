-- ---------------------------------------------------------------------------
-- 068 (r129) Access review removed from PATCH-01
--
-- The page, its API, its worker and the access scanner are gone. Nothing of what was stored is deleted: the
-- perm_* tables stay as they are, so the uploads, scans and decisions are still in the database. Only what would
-- otherwise look broken is tidied:
--   * the access-review worker's heartbeats (it no longer runs: they would show as a stopped worker)
--   * scanner jobs not yet picked up by an agent (no agent should start a scan any more)
--   * scans still shown as waiting or running
-- Re-run safe.
-- ---------------------------------------------------------------------------

DELETE FROM worker_heartbeat WHERE name IN ('perm', 'perm_error');

DO $$
BEGIN
    IF to_regclass('agent_commands') IS NOT NULL THEN
        DELETE FROM agent_commands WHERE verb::text = 'access_scan' AND claimed_at IS NULL;
    END IF;
    IF to_regclass('perm_scans') IS NOT NULL THEN
        UPDATE perm_scans SET state = 'cancelled', note = 'Access review was removed from PATCH-01 (r129)', updated_at = now()
         WHERE state IN ('queued', 'started', 'running', 'uploading', 'importing');
    END IF;
END $$;

INSERT INTO schema_version (version, description)
VALUES (68, 'Access review removed (its data kept)')
ON CONFLICT (version) DO NOTHING;
