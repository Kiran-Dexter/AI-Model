#!/usr/bin/env bash
# ===========================================================================
# PATCH-01 : phase 8 - hardening content (SCAP Security Guide)
#
# Downloads one pinned release of the SCAP Security Guide (ComplianceAsCode),
# verifies it, and imports the data streams this fleet needs. Every agent is
# then judged against exactly this release.
#
#   ./phase8-hardening.sh --fetch 0.1.76          download through the proxy
#   ./phase8-hardening.sh --import-zip FILE.zip   offline: a zip copied here
#   ./phase8-hardening.sh --status                what is imported and active
#   ./phase8-hardening.sh --scan [l1|l2] [HOST..] queue scans now
#
# Proxy allow-list for --fetch: github.com, objects.githubusercontent.com and
# release-assets.githubusercontent.com (GitHub serves release files from the
# last two).
# ===========================================================================
set -Eeuo pipefail

PATCH_BASE="${PATCH_BASE:-/patch}"
HARDENING_DIR="$PATCH_BASE/data/hardening"
ETC_DIR="/etc/patch-platform"
LOG_DIR="/var/log/patch-platform"
API_CONTAINER="${API_CONTAINER:-patch01-api}"
RELEASES="https://github.com/ComplianceAsCode/content/releases/download"

mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/phase8-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG_FILE") 2>&1

say()  { printf '%s\n' "$*"; }
step() { printf '\n==> %s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }
die()  { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

usage() { sed -n '4,17p' "$0" | sed 's/^# \{0,1\}//'; exit "${1:-0}"; }

[[ $EUID -eq 0 ]] || die "Run as root."
command -v docker >/dev/null || die "docker not found."
docker inspect "$API_CONTAINER" >/dev/null 2>&1 || die "$API_CONTAINER is not running. Run phase3b-api.sh first."

in_api() { docker exec -i "$API_CONTAINER" python -m app.hardening "$@"; }

import_dir() {
  local ver="$1" dir="$2"
  step "Importing release $ver"
  chown -R 1001:0 "$HARDENING_DIR"; chmod -R u+rwX,g+rwX,o-rwx "$HARDENING_DIR"
  in_api import --dir "/hardening/content/$ver" --version "$ver" \
    || die "Import failed; see $LOG_FILE"
  say ""
  say "Release $ver is now active. Products without a CIS profile at a level show"
  say "'not available' for that level in the console rather than a score."
}

unpack() {
  local zip="$1" ver="$2" dest="$HARDENING_DIR/content/$ver"
  command -v unzip >/dev/null || die "unzip not found: dnf install -y unzip"
  rm -rf "$dest.tmp"; mkdir -p "$dest.tmp"
  # Only the data streams are needed: a release holds far more
  unzip -q -j "$zip" '*/ssg-*-ds.xml' -d "$dest.tmp" || die "No ssg-*-ds.xml in $zip"
  rm -rf "$dest"; mv "$dest.tmp" "$dest"
  say "Unpacked $(ls "$dest" | wc -l) data streams into $dest"
}

fetch() {
  local ver="$1"
  [[ "$ver" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || die "Give a release version such as 0.1.76"
  [[ -f "$ETC_DIR/proxy.env" ]] && { set -a; . "$ETC_DIR/proxy.env"; set +a; }
  local name="scap-security-guide-$ver.zip" tmp; tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  step "Downloading $name"
  curl -fL --retry 3 --connect-timeout 20 -o "$tmp/$name" "$RELEASES/v$ver/$name" \
    || die "Download failed. Check the proxy allow-list (see the header of this script)."
  curl -fL --retry 3 --connect-timeout 20 -o "$tmp/$name.sha512" "$RELEASES/v$ver/$name.sha512" \
    || die "Could not download the checksum file; refusing to import an unverified release."
  step "Verifying"
  local want got
  want="$(awk '{print $1}' "$tmp/$name.sha512")"
  got="$(sha512sum "$tmp/$name" | awk '{print $1}')"
  [[ -n "$want" && "$want" == "$got" ]] || die "SHA-512 mismatch: the download is corrupt or not the published release."
  say "SHA-512 matches the published checksum."
  mkdir -p "$HARDENING_DIR/releases"
  cp -f "$tmp/$name" "$tmp/$name.sha512" "$HARDENING_DIR/releases/"
  unpack "$HARDENING_DIR/releases/$name" "$ver"
  import_dir "$ver"
}

import_zip() {
  local zip="$1" ver="${2:-}"
  [[ -f "$zip" ]] || die "No such file: $zip"
  [[ -n "$ver" ]] || ver="$(basename "$zip" | sed -nE 's/^scap-security-guide-([0-9]+\.[0-9]+\.[0-9]+)\.zip$/\1/p')"
  [[ -n "$ver" ]] || die "Cannot tell the version from the name; add it: --import-zip FILE 0.1.76"
  if [[ -f "$zip.sha512" ]]; then
    [[ "$(awk '{print $1}' "$zip.sha512")" == "$(sha512sum "$zip" | awk '{print $1}')" ]] \
      || die "SHA-512 mismatch against $zip.sha512"
    say "SHA-512 matches $zip.sha512."
  else
    warn "No $zip.sha512 beside the zip: it cannot be verified. Copy the .sha512 file too."
  fi
  mkdir -p "$HARDENING_DIR/releases"
  # Keep a copy with the other releases, unless this is that copy already
  if [[ "$(realpath "$zip")" != "$(realpath "$HARDENING_DIR/releases")/$(basename "$zip")" ]]; then
    cp -f "$zip" "$HARDENING_DIR/releases/"
    [[ -f "$zip.sha512" ]] && cp -f "$zip.sha512" "$HARDENING_DIR/releases/"
  fi
  unpack "$zip" "$ver"
  import_dir "$ver"
}

[[ $# -ge 1 ]] || usage 1
case "$1" in
  --fetch)       [[ $# -ge 2 ]] || usage 1; fetch "$2" ;;
  --import-zip)  [[ $# -ge 2 ]] || usage 1; import_zip "$2" "${3:-}" ;;
  --status)      step "Hardening content"; in_api status ;;
  --scan)
    shift; lvl="l1"
    [[ "${1:-}" =~ ^l[12]$ ]] && { lvl="$1"; shift; }
    args=(scan --level "$lvl"); for h in "$@"; do args+=(--host "$h"); done
    step "Queuing CIS ${lvl^^} scans"; in_api "${args[@]}"
    say ""; say "Agents pick scans up on their next check-in; results appear in Hardening." ;;
  -h|--help)     usage 0 ;;
  *)             usage 1 ;;
esac
