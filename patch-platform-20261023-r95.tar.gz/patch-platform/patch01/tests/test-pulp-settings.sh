#!/usr/bin/env bash
# Tests patch01-start.sh's fix_pulp_settings (TELEMETRY -> ANALYTICS) on copies
# of settings.py in a temporary folder. Nothing outside it is touched.
#   ./tests/test-pulp-settings.sh
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
START="$HERE/../scripts/patch01-start.sh"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
FUNCS="$(awk '/^PULP_SETTINGS=/{f=1} f{print} f && /^}$/ && ++n==2 {exit}' "$START")"
[[ -n "$FUNCS" ]] || { echo "functions not found in patch01-start.sh"; exit 1; }
N=0; F=0
ok()  { N=$((N+1)); printf '  ok    %s\n' "$1"; }
bad() { N=$((N+1)); F=$((F+1)); printf '  FAIL  %s\n' "$1"; }
run() {   # run <file>: rc of fix_pulp_settings on it
  PATCH_BASE="$T/p" bash -c "say(){ echo \"\$*\"; }; warn(){ echo \"WARN \$*\"; }; PATCH_BASE=$T/p; $FUNCS
fix_pulp_settings" >"$T/out" 2>&1
}
setfile() { mkdir -p "$T/p/config/pulp"; rm -f "$T"/p/config/pulp/*; printf '%b' "$1" >"$T/p/config/pulp/settings.py"; chmod 0640 "$T/p/config/pulp/settings.py"; }
S="$T/p/config/pulp/settings.py"

setfile 'CONTENT_ORIGIN = "https://patch01"\nTELEMETRY = False\nKEEP = 3\n'
run; rc=$?
[[ $rc == 0 ]] && ok "old TELEMETRY = False: changed" || bad "old file not changed"
grep -qx 'ANALYTICS = False' "$S" && ok "ANALYTICS = False written" || bad "ANALYTICS missing"
! grep -q '^TELEMETRY' "$S" && ok "TELEMETRY removed" || bad "TELEMETRY still there"
grep -qx 'KEEP = 3' "$S" && grep -q CONTENT_ORIGIN "$S" && ok "other settings kept" || bad "other settings lost"
[[ "$(stat -c %a "$S")" == 640 ]] && ok "file mode kept (0640)" || bad "mode changed: $(stat -c %a "$S")"
ls "$S".*.bak >/dev/null 2>&1 && grep -q TELEMETRY "$S".*.bak && ok "backup of the old file kept" || bad "no backup"
cp "$S" "$T/after1"; run; rc=$?
[[ $rc == 1 ]] && cmp -s "$S" "$T/after1" && ok "second run: nothing to do, file unchanged" || bad "second run changed the file"

setfile 'A = 1\nANALYTICS = False\n'
cp "$S" "$T/good"; run; rc=$?
[[ $rc == 1 ]] && cmp -s "$S" "$T/good" && ok "already right: untouched, no restart" || bad "a correct file was changed"
! ls "$S".*.bak >/dev/null 2>&1 && ok "no backup when nothing changes" || bad "backup made for nothing"

setfile 'ANALYTICS = True\n'
run; [[ $? == 0 ]] && grep -qx 'ANALYTICS = False' "$S" && ! grep -q 'True' "$S" && ok "ANALYTICS = True: switched off" || bad "ANALYTICS = True not fixed"

setfile 'TELEMETRY = False\nANALYTICS = False\n'
run; [[ $? == 0 ]] && [[ "$(grep -c '^ANALYTICS' "$S")" == 1 ]] && ! grep -q '^TELEMETRY' "$S" && ok "both names: one ANALYTICS line left" || bad "both names not cleaned"

setfile 'X = 1\n'
run; [[ $? == 0 ]] && grep -qx 'ANALYTICS = False' "$S" && ok "no setting at all: ANALYTICS = False added" || bad "missing setting not added"

rm -rf "$T/p"; run; [[ $? == 1 ]] && ok "no settings.py (Pulp not installed): nothing done" || bad "missing file handled wrongly"

printf '\n%d checks, %d failed\n' "$N" "$F"; (( F == 0 ))
