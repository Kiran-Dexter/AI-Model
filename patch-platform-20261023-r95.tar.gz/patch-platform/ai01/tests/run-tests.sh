#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Test suite for ai01-harden.sh, ai01-client.sh (PATCH-01), ai01-setup.sh's
# hardening hooks and llm.py's client certificate.
#
# Runs anywhere with bash, python3, curl, openssl and nft (for syntax checks):
# NOT on AI-01 or PATCH-01. Each scenario builds a throw-away AI-01 in a
# temporary folder:
#   - fake_llama.py   stands in for llama-server (flags, keys, mlock, logs)
#   - fake_front.py   stands in for nginx: it reads the real generated config
#                     (from ai01-setup.sh's own template) and applies it with
#                     real TLS and real client-certificate checks
#   - stubs/          systemctl, nft (real "nft -c"), chattr, docker, ...
# Nothing outside the temporary folder is touched; nothing is loaded into the
# kernel's firewall.
#
#   ./run-tests.sh            all scenarios
#   ./run-tests.sh -k mtls    scenarios whose name contains "mtls"
#   ./run-tests.sh -v         show each command's output
# ---------------------------------------------------------------------------

set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AI01_DIR="$(dirname "$HERE")"
ROOT="$(dirname "$AI01_DIR")"
HARDEN="$AI01_DIR/ai01-harden.sh"
SETUP="$AI01_DIR/ai01-setup.sh"
CLIENT="$ROOT/patch01/scripts/ai01-client.sh"
FILTER=""; VERBOSE=no
while (($#)); do case "$1" in -k) FILTER="$2"; shift ;; -v) VERBOSE=yes ;; esac; shift; done

for c in python3 curl openssl nft; do command -v "$c" >/dev/null || { echo "missing: $c"; exit 2; }; done

export LLAMA_PORT=18080 FRONT_PORT=18443
TOTAL=0; FAILED=0; FAILED_NAMES=(); CUR=""

# ---------------------------------------------------------------------------
# Assertions
# ---------------------------------------------------------------------------
ok()   { TOTAL=$((TOTAL + 1)); printf '    ok    %s\n' "$1"; }
nok()  { TOTAL=$((TOTAL + 1)); FAILED=$((FAILED + 1)); FAILED_NAMES+=("$CUR: $1"); printf '    FAIL  %s\n' "$1"; }
check() { local d="$1"; shift; if "$@" >/dev/null 2>&1; then ok "$d"; else nok "$d"; fi; }
check_not() { local d="$1"; shift; if "$@" >/dev/null 2>&1; then nok "$d"; else ok "$d"; fi; }
has()   { grep -qE -- "$2" "$1"; }
same()  { cmp -s "$1" "$2"; }
mode_is() { [[ "$(stat -c %a "$1")" == "$2" ]]; }

# ---------------------------------------------------------------------------
# A throw-away AI-01
# ---------------------------------------------------------------------------
SB=""
stop_fakes() {
  [[ -n "$SB" ]] || return 0
  local f; for f in "$SB/state/llama.pid" "$SB/state/front.pid"; do
    [[ -f "$f" ]] && kill "$(cat "$f")" 2>/dev/null
  done
  pkill -f "fake_llama.py.*--port $LLAMA_PORT" 2>/dev/null || true
  sleep 0.3
}
cleanup() { stop_fakes; [[ -n "$SB" && -d "$SB" ]] && rm -rf "$SB"; SB=""; }
trap cleanup EXIT

render_setup_nginx() {   # the server block exactly as ai01-setup.sh writes it
  local CERT_DIR="$1" TLS_PROTOCOLS="TLSv1.2 TLSv1.3" NGINX_SNIP_DIR="$2" PATCH01_IP="10.20.1.5" LISTEN_PORT="$LLAMA_PORT"
  local tmpl; tmpl="$(awk '/^cat > \/etc\/nginx\/conf.d\/ai01-llm.conf <<EOF/{f=1; next} f && /^EOF$/{exit} f' "$SETUP")"
  [[ -n "$tmpl" ]] || { echo "could not find the nginx template in ai01-setup.sh" >&2; return 1; }
  eval "cat <<EOF
$tmpl
EOF"
}

new_ai01() {   # new_ai01 [old]: "old" = deployed by a setup without the include line
  cleanup
  SB="$(mktemp -d)"
  local L="$SB/llm"
  mkdir -p "$L"/{config,certs,logs,models,cache,bin} "$SB"/etc/nginx/conf.d "$SB/var/log/nginx" \
           "$SB/run" "$SB/state" "$SB/systemd" "$SB/patch/secrets/ai01" "$SB/patch/compose" "$SB/plog"
  export AI01_BASE="$L" AI01_NGINX_CONF="$SB/etc/nginx/conf.d/ai01-llm.conf" \
    AI01_NGINX_HTTP_SNIPPET="$SB/etc/nginx/conf.d/ai01-00-hardening.conf" \
    AI01_NGINX_SNIP_DIR="$SB/etc/nginx/ai01-hardening.d" AI01_NGINX_LOG_DIR="$SB/var/log/nginx" \
    AI01_SYSTEMD_DIR="$SB/systemd" AI01_NFT_FILE="$SB/etc/nftables/ai01-harden.nft" \
    AI01_NFT_MAIN="$SB/etc/sysconfig/nftables.conf" AI01_LOGROTATE_FILE="$SB/etc/logrotate.d/ai01-llm" \
    AI01_LOCK_DIR="$SB/run" AI01_FRONT_URL="https://127.0.0.1:$FRONT_PORT" AI01_LISTEN_PORT="$LLAMA_PORT" \
    AI01_LLAMA_WAIT=20 AI01_CHAT_TIMEOUT=20 AI01_SVC_USER=root AI01_CONFIRM_WAIT=25 \
    AI01_INET_PROBE="https://127.0.0.1:1/" AI01_PATCH01_PROBE="https://127.0.0.1:$FRONT_PORT/health" \
    FAKE_STATE="$SB/state" FAKE_TESTS="$HERE" FAKE_FRONT_PORT="$FRONT_PORT" FAKE_PATCH01_IP=10.20.1.5 \
    PATCH01_BASE="$SB/patch" PATCH01_LOG_DIR="$SB/plog" FAKE_API_DIR="$ROOT/patch01/api"
  export PATH="$HERE/stubs:$PATH"
  unset FAKE_LLAMA_FLAGS FAKE_LLAMA_FAIL_ON FAKE_LLAMA_MULTIKEY FAKE_LLAMA_LOG_PROMPTS FAKE_NGINX_T_FAIL \
        FAKE_UNDO_FIRED FAKE_PEERS FAKE_SWAP FAKE_LSBLK_TYPE AI01_INPUT_FILE SSH_CONNECTION

  # model, key, certificates, as ai01-setup.sh leaves them
  { printf 'GGUF'; head -c 4096 /dev/urandom; } >"$L/models/qwen3-8b-q4_k_m.gguf"
  (cd "$L/models" && sha256sum ./*.gguf >SHA256SUMS)
  openssl rand -hex 32 >"$L/config/api-key"; chmod 0640 "$L/config/api-key"
  openssl req -x509 -nodes -newkey rsa:2048 -days 825 -keyout "$L/certs/ai01.key" -out "$L/certs/ai01.crt" \
    -subj "/CN=ai01.test" -addext "subjectAltName=DNS:ai01.test,IP:127.0.0.1" >/dev/null 2>&1
  chmod 0600 "$L/certs/ai01.key"
  printf '#!/usr/bin/env bash\nexec python3 %q "$@"\n' "$HERE/fake_llama.py" >"$L/bin/llama-server"
  chmod +x "$L/bin/llama-server"
  printf '%s\n' -m "$L/models/qwen3-8b-q4_k_m.gguf" --host 127.0.0.1 --port "$LLAMA_PORT" -c 4096 -t 2 -np 2 \
    --api-key-file "$L/config/api-key" --jinja --no-webui --metrics --slot-save-path "$L/cache" >"$L/config/llama-server.args"
  cat >"$L/config/run-llama-server.sh" <<EOF
#!/usr/bin/env bash
# Generated by ai01-setup.sh. Reads one argument per line.
mapfile -t A < "$L/config/llama-server.args"
export LD_LIBRARY_PATH="$L/bin"
exec "$L/bin/llama-server" "\${A[@]}"
EOF
  chmod 0750 "$L/config/run-llama-server.sh"
  render_setup_nginx "$L/certs" "$AI01_NGINX_SNIP_DIR" >"$AI01_NGINX_CONF" || return 1
  [[ "${1:-}" == old ]] && sed -i '/include .*ai01-hardening.d/d' "$AI01_NGINX_CONF"
  cp "$AI01_NGINX_CONF" "$SB/nginx.orig"; cp "$L/config/llama-server.args" "$SB/args.orig"
  cp "$L/config/api-key" "$SB/key.orig"
  echo "saved slot with an old prompt" >"$L/cache/slot0.bin"

  # PATCH-01's side: api.env, pinned AI-01 certificate (as phase6-llm.sh leaves them)
  printf 'AI01_URL=https://127.0.0.1:%s\nAI01_API_KEY=%s\nAI01_CA_FILE=/etc/ai01/ca.crt\n' \
    "$((FRONT_PORT + 1))" "$(cat "$L/config/api-key")" >"$SB/patch/secrets/api.env"
  cp "$L/certs/ai01.crt" "$SB/patch/secrets/ai01/ca.crt"

  start_fakes
}
start_fakes() {
  systemctl start llama-server
  python3 "$HERE/fake_front.py" serve >>"$SB/state/front.log" 2>&1 &
  local i; for i in $(seq 1 50); do
    curl -sk --noproxy '*' -o /dev/null "https://127.0.0.1:$FRONT_PORT/health" 2>/dev/null \
      && curl -sf --noproxy '*' -o /dev/null "http://127.0.0.1:$LLAMA_PORT/health" 2>/dev/null && return 0
    sleep 0.2
  done
  echo "fakes did not start"; cat "$SB/state/front.log" "$AI01_BASE/logs/llama-server.log" 2>/dev/null | tail -5
  return 1
}
restart_llama() { systemctl restart llama-server; local i; for i in $(seq 1 50); do curl -sf --noproxy '*' -o /dev/null "http://127.0.0.1:$LLAMA_PORT/health" 2>/dev/null && return 0; sleep 0.2; done; return 1; }

OUT=""
H() {   # H "answer1|answer2|..." args... : run ai01-harden.sh with these answers
  local answers="$1"; shift
  printf '%s\n' "${answers//|/$'\n'}" >"$SB/answers"
  OUT="$SB/out.$RANDOM"
  AI01_INPUT_FILE="$SB/answers" bash "$HARDEN" "$@" >"$OUT" 2>&1 </dev/null
  local rc=$?
  [[ "$VERBOSE" == yes ]] && sed 's/^/      | /' "$OUT"
  return "$rc"
}
C() {   # C "answers" args... : run ai01-client.sh (PATCH-01) with these answers
  local answers="$1"; shift
  printf '%s\n' "${answers//|/$'\n'}" >"$SB/answers"
  OUT="$SB/out.$RANDOM"
  AI01_INPUT_FILE="$SB/answers" bash "$CLIENT" "$@" >"$OUT" 2>&1 </dev/null
  local rc=$?
  [[ "$VERBOSE" == yes ]] && sed 's/^/      | /' "$OUT"
  return "$rc"
}
out_has() { grep -qE -- "$1" "$OUT"; }
args_has() { grep -qxF -- "$1" "$AI01_BASE/config/llama-server.args"; }
key() { awk 'NF{print;exit}' "$AI01_BASE/config/api-key"; }
chat() {   # chat <key> [port]: HTTP code of a portal-style request
  curl -sk --noproxy '*' -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $1" -H 'Content-Type: application/json' \
    -d '{"messages":[{"role":"user","content":"hi"}],"max_tokens":2}' "https://127.0.0.1:${2:-$FRONT_PORT}/v1/chat/completions"
}
as_patch01() {   # as_patch01 [curl options]: a /health request seen as coming from PATCH-01
  curl -sk --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 5 "$@" "https://127.0.0.1:$((FRONT_PORT + 1))/health" 2>/dev/null || true
}
local_code() { curl -sk --noproxy '*' -o /dev/null -w '%{http_code}' --max-time 5 "$@" "https://127.0.0.1:$FRONT_PORT/health" 2>/dev/null || true; }
patch01_soon() {   # PATCH-01 runs ai01-client.sh --test in a few seconds (while a step waits for it)
  ( sleep "${1:-3}"; AI01_INPUT_FILE=/dev/null bash "$CLIENT" --test >"$SB/bg.$RANDOM" 2>&1 ) &
}
patch01_import() {   # client certificate from step mtls into PATCH-01, answers: match=y, rebuild=n, shred=n
  cp "$AI01_BASE/hardening/export/patch01-client.tar" "$SB/patch01-client.tar"
  C "y|n|n" --import "$SB/patch01-client.tar"
}

scenario() {   # scenario <name>: runs function t_<name>
  local name="$1"
  [[ -z "$FILTER" || "$name" == *"$FILTER"* ]] || return 0
  CUR="$name"; printf '\n== %s\n' "$name"
  "t_${name//-/_}"
  cleanup
}

# ===========================================================================
# Scenarios
# ===========================================================================
t_baseline_check() {
  new_ai01
  H "" --check; local rc=$?
  check "--check passes on a fresh AI-01 (no FAIL)" test "$rc" = 0
  check "T04 portal path passes" out_has 'PASS  T04'
  check "T05 no key refused" out_has 'PASS  T05'
  check "T07 /slots closed" out_has 'PASS  T07'
  check "T16 TLS 1.0/1.1 refused" out_has 'PASS  T16'
  check "T17 TLS 1.2 still allowed: a warning, not a failure" out_has 'warn  T17'
  check "T12 --slot-save-path reported" out_has 'warn  T12'
  check "T33 prompt not in logs" out_has 'PASS  T33'
  check "T37 setup keeps hardening (marker present)" out_has 'PASS  T37'
  check "nothing changed by --check" same "$AI01_NGINX_CONF" "$SB/nginx.orig"
}

t_refuses_without_terminal() {
  new_ai01
  bash "$HARDEN" --step observe </dev/null >"$SB/o" 2>&1; local rc=$?
  check "a step without a terminal refuses" test "$rc" != 0
  check "it says why" grep -q 'Not a terminal' "$SB/o"
  check "nothing changed" same "$AI01_NGINX_CONF" "$SB/nginx.orig"
}

t_locks() {
  new_ai01
  exec 9>"$SB/run/ai01-update.lock"; flock -n 9
  H "y" --step observe; local rc=$?
  check "refuses while ai01-update.sh runs" test "$rc" != 0
  check "says so" out_has 'ai01-update.sh is running'
  exec 9>&-
  exec 9>"$SB/run/ai01-harden.lock"; flock -n 9
  H "y" --step observe; rc=$?
  check "refuses a second copy of itself" test "$rc" != 0
  exec 9>&-
}

t_observe() {
  new_ai01 old
  H "n" --step observe
  check "answering no changes nothing" same "$AI01_NGINX_CONF" "$SB/nginx.orig"
  H "y" --step observe; local rc=$?
  check "step succeeds" test "$rc" = 0
  check "include line added once" test "$(grep -c 'ai01-hardening.d/\*.conf' "$AI01_NGINX_CONF")" = 1
  check "the normal access log is kept as well" has "$AI01_NGINX_SNIP_DIR/10-observe.conf" 'access\.log combined;'
  check "security log written" test -s "$AI01_NGINX_LOG_DIR/ai01-security.log"
  check "security log records TLS version" has "$AI01_NGINX_LOG_DIR/ai01-security.log" 'TLSv1\.[23]'
  check_not "security log holds no request body" grep -q 'messages' "$AI01_NGINX_LOG_DIR/ai01-security.log"
  H "y" --step observe
  check "second run: already in place" out_has 'Already in place'
  check "still exactly one include" test "$(grep -c 'ai01-hardening.d/\*.conf' "$AI01_NGINX_CONF")" = 1
  new_ai01
  H "y" --step observe
  check "with the new setup template (include already there): one include" test "$(grep -c 'ai01-hardening.d/\*.conf' "$AI01_NGINX_CONF")" = 1
}

t_llama() {
  new_ai01
  sed -i "\$a -lv\n3" "$AI01_BASE/config/llama-server.args"
  restart_llama
  H "y|y" --step llama; local rc=$?
  check "step succeeds" test "$rc" = 0
  check_not "--slot-save-path removed" args_has --slot-save-path
  check_not "its value removed too" args_has "$AI01_BASE/cache"
  check_not "-lv removed" args_has -lv
  check_not "-lv's value removed too" args_has 3
  check "--mlock added" args_has --mlock
  check "--no-slots added" args_has --no-slots
  check "API key flag kept" args_has --api-key-file
  check "LimitMEMLOCK drop-in" has "$AI01_SYSTEMD_DIR/llama-server.service.d/50-hardening.conf" 'LimitMEMLOCK=infinity'
  local pid; pid="$(cat "$SB/state/llama.pid")"
  check "running process locks memory (VmLck > 0)" awk '/VmLck/ {exit !($2 > 0)}' "/proc/$pid/status"
  check "old saved slot shredded" test -z "$(ls -A "$AI01_BASE/cache")"
  check "remembered for ai01-setup.sh" has "$AI01_BASE/config/hardening.env" 'LLAMA_ADD_FLAGS="--mlock --no-slots"'
  check "portal path still works" test "$(chat "$(key)")" = 200
  H "" --check
  check "--check: T12 T14 now pass" bash -c "grep -q 'PASS  T12' $OUT && grep -q 'PASS  T14' $OUT"
}

t_llama_build_without_flags() {
  new_ai01
  export FAKE_LLAMA_FLAGS="-m --host --port -c -t -np --api-key-file --jinja --no-webui --metrics --slot-save-path"
  H "y|n" --step llama; local rc=$?
  check "succeeds on a build without --mlock and --no-slots" test "$rc" = 0
  check_not "does not add an unknown flag" args_has --no-slots
  check_not "does not add --mlock" args_has --mlock
  check_not "--slot-save-path still removed" args_has --slot-save-path
  check "portal path works" test "$(chat "$(key)")" = 200
}

t_llama_auto_rollback() {
  new_ai01
  export FAKE_LLAMA_FAIL_ON=--mlock
  H "y|n" --step llama; local rc=$?
  check "step reports failure" test "$rc" != 0
  check "says it was undone" out_has "was undone"
  check "args file restored byte for byte" same "$AI01_BASE/config/llama-server.args" "$SB/args.orig"
  check_not "drop-in removed" test -e "$AI01_SYSTEMD_DIR/llama-server.service.d/50-hardening.conf"
  check_not "no LLAMA_ settings left in hardening.env" grep -q '^LLAMA_' "$AI01_BASE/config/hardening.env"
  check_not "not marked done" test -e "$AI01_BASE/hardening/steps/llama"
  unset FAKE_LLAMA_FAIL_ON; restart_llama
  check "portal path works after the undo" test "$(chat "$(key)")" = 200
}

t_nginx_test_failure_rolls_back() {
  new_ai01
  H "y" --step observe
  cp "$AI01_NGINX_CONF" "$SB/nginx.after-observe"
  export FAKE_NGINX_T_FAIL=1
  H "y" --step ratelimit; local rc=$?
  unset FAKE_NGINX_T_FAIL
  check "step fails when nginx -t fails" test "$rc" != 0
  check_not "rate-limit snippet removed" test -e "$AI01_NGINX_SNIP_DIR/20-ratelimit.conf"
  check "server block unchanged" same "$AI01_NGINX_CONF" "$SB/nginx.after-observe"
  check "portal path works" test "$(chat "$(key)")" = 200
}

t_tls13() {
  new_ai01
  H "y" --step tls13; local rc=$?
  check "refuses before observe (no change)" out_has "Run step 'observe' first"
  check "conf unchanged" same "$AI01_NGINX_CONF" "$SB/nginx.orig"
  H "y" --step observe
  H "y" --step tls13
  check "refuses with no PATCH-01 requests recorded" out_has 'Not yet'
  as_patch01 --tls-max 1.2 >/dev/null; as_patch01 --tls-max 1.2 >/dev/null; as_patch01 --tls-max 1.2 >/dev/null
  H "y" --step tls13
  check "refuses when PATCH-01 used TLS 1.2" out_has 'Not safe'
  check "conf still allows 1.2" has "$AI01_NGINX_CONF" 'ssl_protocols +TLSv1.2 TLSv1.3;'
  for _ in $(seq 1 50); do as_patch01 >/dev/null; done
  patch01_soon
  H "y" --step tls13; rc=$?
  check "kept only after PATCH-01's own requests succeeded" out_has 'successful requests from PATCH-01 under the new setting'
  check "applies once PATCH-01 is seen on TLS 1.3" test "$rc" = 0
  check "ssl_protocols TLSv1.3 only" has "$AI01_NGINX_CONF" 'ssl_protocols +TLSv1.3;'
  check "remembered for ai01-setup.sh" has "$AI01_BASE/config/hardening.env" 'TLS_PROTOCOLS="TLSv1.3"'
  check "TLS 1.2 refused now" test "$(local_code --tls-max 1.2)" = 000
  check "TLS 1.3 works" test "$(local_code)" = 200
  check "portal path works" test "$(chat "$(key)")" = 200
}

t_ratelimit() {
  new_ai01
  H "y" --step observe
  H "y" --step ratelimit; local rc=$?
  check "step succeeds (its own burst test saw 429)" test "$rc" = 0
  check "burst result reported" out_has 'answered 429'
  sleep 4
  check "a normal request still works" test "$(chat "$(key)")" = 200
  H "" --check --deep
  check "--check --deep: T27 passes" out_has 'PASS  T27'
}

t_mtls_and_enforce() {
  new_ai01
  H "y" --step observe
  H "y" --step mtls; local rc=$?
  local C_="$AI01_BASE/certs"
  check "step succeeds" test "$rc" = 0
  check "client CA key is 0600" mode_is "$C_/client-ca/ca.key" 600
  check "client key is 0600" mode_is "$C_/clients/patch01.key" 600
  check "client cert chains to the CA" openssl verify -CAfile "$C_/client-ca/ca.crt" "$C_/clients/patch01.crt"
  check "client cert is for client authentication" bash -c "openssl x509 -noout -ext extendedKeyUsage -in $C_/clients/patch01.crt | grep -q 'Client Authentication'"
  check "client cert is not a CA" bash -c "openssl x509 -noout -ext basicConstraints -in $C_/clients/patch01.crt | grep -q 'CA:FALSE'"
  local tar="$AI01_BASE/hardening/export/patch01-client.tar"
  check "bundle for PATCH-01 is 0600" mode_is "$tar" 600
  check "bundle holds exactly client.crt and client.key" test "$(tar -tf "$tar" | sort | tr '\n' ' ')" = "client.crt client.key "
  check "a certificate from another CA is not trusted" out_has 'another CA is not trusted'
  check "nothing refused yet: PATCH-01 without cert gets 200" test "$(as_patch01)" = 200

  H "y" --step mtls-enforce
  check "enforce refuses while PATCH-01 shows no certificate" out_has 'Not (yet|safe)'
  check_not "not enforced" test -e "$AI01_NGINX_SNIP_DIR/31-mtls-enforce.conf"

  patch01_import; rc=$?
  check "PATCH-01 imports the bundle and its test passes" test "$rc" = 0
  check "import installed the key 0640" mode_is "$SB/patch/secrets/ai01/client.key" 640
  check "client test: API presents the certificate" out_has 'PASS  the API presents'
  check "client test: real answer" out_has 'PASS  the portal gets a real answer'

  patch01_soon
  H "y" --step mtls-enforce; rc=$?
  check "enforce applies once PATCH-01 presents the certificate" test "$rc" = 0
  check "kept only after PATCH-01 succeeded under it" out_has 'successful requests from PATCH-01'
  check "its undo timer was stopped" test ! -e "$SB/state/timer-ai01-harden-undo-mtls-enforce"
  check "PATCH-01's address WITHOUT the certificate: 403" test "$(as_patch01)" = 403
  check "PATCH-01's address WITH the certificate: 200" test "$(as_patch01 --cert "$C_/clients/patch01.crt" --key "$C_/clients/patch01.key")" = 200
  check "AI-01's own checks (127.0.0.1) still work without it" test "$(local_code)" = 200
  C "" --test; rc=$?
  check "PATCH-01 --test passes after enforcement" test "$rc" = 0
  check "PATCH-01 --test proves the refusal without certificate" out_has 'PASS  a request WITHOUT the client certificate is refused'
  H "" --check
  check "--check: T19 T20 T21 pass" bash -c "grep -q 'PASS  T19' $OUT && grep -q 'PASS  T20' $OUT && grep -q 'PASS  T21' $OUT"
  check "--check warns the key bundle is still on AI-01" out_has 'warn  T26'
}

t_client_import_rejects() {
  new_ai01
  H "y" --step observe; H "y" --step mtls
  local tar="$AI01_BASE/hardening/export/patch01-client.tar" d="$SB/bad"
  mkdir -p "$d"; tar -xf "$tar" -C "$d"
  # extra file in the tar
  echo x >"$d/evil.sh"; tar -cf "$SB/extra.tar" -C "$d" client.crt client.key evil.sh
  C "y|n|n" --import "$SB/extra.tar"; local rc=$?
  check "rejects a bundle with extra files" test "$rc" != 0
  # key that does not match
  openssl ecparam -name prime256v1 -genkey -noout -out "$d/client.key" 2>/dev/null
  tar -cf "$SB/mismatch.tar" -C "$d" client.crt client.key
  C "y|n|n" --import "$SB/mismatch.tar"; rc=$?
  check "rejects a key that does not belong to the certificate" test "$rc" != 0
  check "says so" out_has 'does not belong'
  # a server certificate instead of a client certificate
  cp "$AI01_BASE/certs/ai01.crt" "$d/client.crt"; cp "$AI01_BASE/certs/ai01.key" "$d/client.key"
  tar -cf "$SB/server.tar" -C "$d" client.crt client.key
  C "y|n|n" --import "$SB/server.tar"; rc=$?
  check "rejects a certificate that is not for client authentication" test "$rc" != 0
  # fingerprint not confirmed
  C "n" --import "$tar"; rc=$?
  check "stops when the fingerprint is not confirmed" test "$rc" != 0
  check_not "nothing installed" test -e "$SB/patch/secrets/ai01/client.crt"
}

t_firewall() {
  new_ai01
  # admin SSH, extra out, extra in, ports, load?, CONFIRM
  H "y|10.9.9.9|10.50.0.7|10.60.0.0/24|9100|y|CONFIRM" --step firewall; local rc=$?
  check "step succeeds when confirmed" test "$rc" = 0
  check "real nft accepted the ruleset (nft -c)" grep -q '^nft -c -f' "$SB/state/calls"
  check "automatic undo armed before loading" bash -c "grep -n 'systemd-run' $SB/state/calls | head -1 | cut -d: -f1 | xargs -I{} test {} -lt \$(grep -n '^nft -f' $SB/state/calls | head -1 | cut -d: -f1)"
  check "undo timer stopped after CONFIRM" test ! -e "$SB/state/undo-timer"
  check "ruleset saved for boot" test -s "$AI01_NFT_FILE"
  check "ruleset file 0600" mode_is "$AI01_NFT_FILE" 600
  check "included from nftables.conf" has "$AI01_NFT_MAIN" "include \"$AI01_NFT_FILE\""
  check "PATCH-01 allowed in on 443" has "$AI01_NFT_FILE" 'ip saddr 10\.20\.1\.5 tcp dport 443 accept'
  check "SSH only from the admin address" has "$AI01_NFT_FILE" 'elements = \{ 10\.9\.9\.9 \}'
  check "extra inbound port" has "$AI01_NFT_FILE" 'dport \{ 9100 \}'
  check "PATCH-01 allowed out on 443 (OS updates)" has "$AI01_NFT_FILE" 'ip daddr 10\.20\.1\.5 tcp dport 443 accept'
  check "default drop in" has "$AI01_NFT_FILE" 'hook input priority filter; policy drop'
  check "default drop out" has "$AI01_NFT_FILE" 'hook output priority filter; policy drop'
  check "existing sessions kept" has "$AI01_NFT_FILE" 'ct state established,related accept'
  check "saved file passes nft -c" /usr/sbin/nft -c -f "$AI01_NFT_FILE"
  H "" --check
  check "--check: T28 T29 T30 pass" bash -c "grep -q 'PASS  T28' $OUT && grep -q 'PASS  T29' $OUT && grep -q 'PASS  T30' $OUT"
}

t_firewall_not_confirmed() {
  new_ai01
  H "y|10.9.9.9|||y|no" --step firewall; local rc=$?
  check "not confirmed: step fails" test "$rc" != 0
  check_not "table removed" test -e "$SB/state/nft-loaded"
  check_not "nothing saved for boot" test -e "$AI01_NFT_FILE"
  check_not "nftables.conf not created" test -e "$AI01_NFT_MAIN"
}

t_firewall_undo_already_fired() {
  new_ai01
  export FAKE_UNDO_FIRED=1
  H "y|10.9.9.9|||y|CONFIRM" --step firewall; local rc=$?
  check "too late: step fails, nothing kept" test "$rc" != 0
  check_not "nothing saved for boot" test -e "$AI01_NFT_FILE"
}

t_firewall_internet_still_open() {
  new_ai01
  export AI01_INET_PROBE="https://127.0.0.1:$FRONT_PORT/health"
  H "y|10.9.9.9|||y|CONFIRM" --step firewall; local rc=$?
  check "verification catches open internet and undoes" test "$rc" != 0
  check "says so" out_has 'can still reach the internet'
  check_not "table removed" test -e "$SB/state/nft-loaded"
}

t_firewall_bad_input() {
  new_ai01
  H "y|not-an-ip|||n" --step firewall
  check "an invalid address is left out with a warning" out_has 'Not an IPv4 address: not-an-ip'
  H "y|10.9.9.9||10.1.1.1|22;rm -rf /" --step firewall; local rc=$?
  check "an invalid port list is refused" test "$rc" != 0
  check_not "nothing loaded" test -e "$SB/state/nft-loaded"
}

t_model() {
  new_ai01
  H "y|0000000000000000000000000000000000000000000000000000000000000000" --step model; local rc=$?
  check "a wrong publisher checksum fails" test "$rc" != 0
  check_not "file not locked" grep -q gguf "$SB/state/immutable"
  local sum; sum="$(sha256sum "$AI01_BASE/models/qwen3-8b-q4_k_m.gguf" | awk '{print $1}')"
  H "y|${sum^^}" --step model; rc=$?
  check "the right checksum (any case) succeeds" test "$rc" = 0
  check "model immutable" grep -q 'qwen3-8b-q4_k_m.gguf' "$SB/state/immutable"
  check "SHA256SUMS immutable" grep -q 'SHA256SUMS' "$SB/state/immutable"
  H "y" --rollback model
  check_not "rollback lifts the mark" grep -q gguf "$SB/state/immutable"
}

t_logs() {
  new_ai01
  H "y" --step logs; local rc=$?
  check "step succeeds" test "$rc" = 0
  check "canary not found in logs" out_has 'prompt text is in no log'
  check "logrotate file" has "$AI01_LOGROTATE_FILE" 'llama-server.log'
  check "log folder 0750" mode_is "$AI01_BASE/logs" 750
  new_ai01
  export FAKE_LLAMA_LOG_PROMPTS=1; restart_llama
  H "y" --step logs; rc=$?
  check "a build that logs prompts is caught" test "$rc" != 0
  check "names the file" out_has 'llama-server.log'
  check_not "rotation file removed by the undo" test -e "$AI01_LOGROTATE_FILE"
  H "" --check
  check "--check T33 fails too" out_has 'FAIL  T33'
}

t_key_rotate() {
  new_ai01
  local old; old="$(key)"
  H "y" --step key-rotate; local rc=$?
  check "first half succeeds" test "$rc" = 0
  local new; new="$(cat "$AI01_BASE/hardening/key-rotate.pending")"
  check "pending key file is 0600" mode_is "$AI01_BASE/hardening/key-rotate.pending" 600
  check "two keys in the key file" test "$(grep -c . "$AI01_BASE/config/api-key")" = 2
  check "key file still 0640" mode_is "$AI01_BASE/config/api-key" 640
  check "old key works" test "$(chat "$old")" = 200
  check "new key works" test "$(chat "$new")" = 200
  H "" --status
  check "status shows the half-done rotation" out_has 'HALF DONE'
  # PATCH-01 switches
  C "$new|y" --rotate-key; rc=$?
  check "PATCH-01 switches to the new key" test "$rc" = 0
  check "api.env holds the new key" grep -q "^AI01_API_KEY=$new\$" "$SB/patch/secrets/api.env"
  H "n" --step key-rotate
  check "second half waits for confirmation" out_has 'do that first'
  check "both keys still work meanwhile" test "$(grep -c . "$AI01_BASE/config/api-key")" = 2
  H "y|y" --step key-rotate; rc=$?
  check "second half succeeds" test "$rc" = 0
  check "old key refused" test "$(chat "$old")" = 401
  check "new key works" test "$(chat "$new")" = 200
  check_not "pending file removed" test -e "$AI01_BASE/hardening/key-rotate.pending"
  C "" --test; rc=$?
  check "PATCH-01 still works end to end" test "$rc" = 0
}

t_key_rotate_single_key_build() {
  new_ai01
  export FAKE_LLAMA_MULTIKEY=0; restart_llama
  H "y" --step key-rotate; local rc=$?
  check "a build that reads one key: first half undone" test "$rc" != 0
  check "key file restored" same "$AI01_BASE/config/api-key" "$SB/key.orig"
  check_not "no pending key left" test -e "$AI01_BASE/hardening/key-rotate.pending"
  check "portal works with the old key" test "$(chat "$(key)")" = 200
}

t_client_rotate_bad_key() {
  new_ai01
  cp "$SB/patch/secrets/api.env" "$SB/api.env.orig"
  C "$(openssl rand -hex 32)|y" --rotate-key; local rc=$?
  check "a key AI-01 does not know is refused before any change" test "$rc" != 0
  check "api.env unchanged" same "$SB/patch/secrets/api.env" "$SB/api.env.orig"
  C "not-hex|y" --rotate-key; rc=$?
  check "a malformed key is refused" test "$rc" != 0
}

t_rollback_all() {
  new_ai01 old
  H "y" --step observe; H "y|y" --step llama; H "y" --step ratelimit; H "y" --step mtls; H "y" --step logs
  H "y" --rollback-all; local rc=$?
  check "rollback-all succeeds" test "$rc" = 0
  check "server block back to the original" same "$AI01_NGINX_CONF" "$SB/nginx.orig"
  check "args back to the original" same "$AI01_BASE/config/llama-server.args" "$SB/args.orig"
  check_not "http snippet removed" test -e "$AI01_NGINX_HTTP_SNIPPET"
  check "no hardening snippets left" test -z "$(ls -A "$AI01_NGINX_SNIP_DIR" 2>/dev/null)"
  check_not "drop-in removed" test -e "$AI01_SYSTEMD_DIR/llama-server.service.d/50-hardening.conf"
  check "client CA kept (a new one would invalidate PATCH-01's certificate)" test -e "$AI01_BASE/certs/client-ca/ca.key"
  check_not "logrotate removed" test -e "$AI01_LOGROTATE_FILE"
  check "portal path works" test "$(chat "$(key)")" = 200
}

t_rollback_one() {
  new_ai01
  H "y" --step observe; H "y" --step ratelimit
  H "y" --rollback ratelimit; local rc=$?
  check "single rollback succeeds" test "$rc" = 0
  check_not "rate limit removed" test -e "$AI01_NGINX_SNIP_DIR/20-ratelimit.conf"
  check "observe kept" test -e "$AI01_NGINX_SNIP_DIR/10-observe.conf"
  H "" --status
  check "status: ratelimit not done" bash -c "grep -E '^ +4\) ratelimit' $OUT | grep -q ' -\$'"
}

t_full_hardening_check() {
  new_ai01
  H "y" --step observe; H "y|y" --step llama; H "y" --step ratelimit; H "y" --step mtls
  patch01_import
  for _ in $(seq 1 5); do C "" --test >/dev/null; done
  patch01_soon; H "y" --step tls13
  patch01_soon; H "y" --step mtls-enforce
  patch01_soon 1; H "y|10.9.9.9|||y|CONFIRM" --step firewall
  local sum; sum="$(sha256sum "$AI01_BASE/models/qwen3-8b-q4_k_m.gguf" | awk '{print $1}')"
  H "y|$sum" --step model; H "y" --step logs
  rm -f "$AI01_BASE/hardening/export/patch01-client.tar"
  H "" --check --deep; local rc=$?
  check "--check after every step: no FAIL" test "$rc" = 0
  local t; for t in T04 T12 T14 T17 T19 T20 T21 T27 T28 T29 T32 T33 T34; do
    check "$t passes" out_has "PASS  $t"
  done
  check_not "no warning about the key bundle" out_has 'T26'
  C "" --test; rc=$?
  check "PATCH-01 --test passes with everything on" test "$rc" = 0
}

t_setup_keeps_hardening() {
  # The argument filter ai01-setup.sh runs, fed the arguments it builds
  local d; d="$(mktemp -d)"
  printf 'LLAMA_REMOVE_FLAGS="--slot-save-path -lv --verbosity --log-verbosity -v --verbose --log-verbose --verbose-prompt"\nLLAMA_ADD_FLAGS="--mlock --no-slots"\nTLS_PROTOCOLS="TLSv1.3"\n' >"$d/h.env"
  local block; block="$(awk '/^# Hardening from ai01-harden.sh/{f=1} f{print} f && /^done$/{exit}' "$SETUP")"
  local getter; getter="$(grep '^harden_get()' "$SETUP")"
  local res
  res="$(HARDEN_ENV="$d/h.env" bash -c "
    warn() { echo \"WARN \$*\" >&2; }
    HELP='--mlock --api-key-file -v --jinja'
    has_flag() { printf '%s' \"\$HELP\" | grep -qE -- \"(^|[ ,])\$1([ ,=]|\$)\"; }
    $getter
    ARGS=(-m /m.gguf --api-key-file /k -v --jinja --slot-save-path /cache -lv 3)
    $block
    printf '%s\n' \"\${ARGS[@]}\"" 2>"$d/err")"
  check "setup keeps --slot-save-path out" bash -c "! grep -qx -- '--slot-save-path' <<<'$res'"
  check "setup drops a removed flag's value too" bash -c "! grep -qx -- '/cache' <<<'$res' && ! grep -qx 3 <<<'$res'"
  check "setup drops -v" bash -c "! grep -qx -- '-v' <<<'$res'"
  check "setup re-adds --mlock" bash -c "grep -qx -- '--mlock' <<<'$res'"
  check "setup skips --no-slots on a build without it, with a warning" grep -q 'no --no-slots' "$d/err"
  check "setup keeps the API key flag" bash -c "grep -qx -- '--api-key-file' <<<'$res'"
  local tls; tls="$(HARDEN_ENV="$d/h.env" bash -c "$getter; TLS_PROTOCOLS=\"\$(harden_get TLS_PROTOCOLS)\"; $(grep -F '"$TLS_PROTOCOLS" =~' "$SETUP"); echo \"\$TLS_PROTOCOLS\"")"
  check "setup reads TLS 1.3 from hardening.env" test "$tls" = TLSv1.3
  printf 'TLS_PROTOCOLS="SSLv3; evil"\n' >"$d/h.env"
  tls="$(HARDEN_ENV="$d/h.env" bash -c "$getter; TLS_PROTOCOLS=\"\$(harden_get TLS_PROTOCOLS)\"; $(grep -F '"$TLS_PROTOCOLS" =~' "$SETUP"); echo \"\$TLS_PROTOCOLS\"")"
  check "setup ignores a bad TLS value" test "$tls" = "TLSv1.2 TLSv1.3"
  check "setup's nginx template includes the hardening folder" grep -q 'include \$NGINX_SNIP_DIR/\*.conf;' "$SETUP"
  check "setup no longer adds --slot-save-path" bash -c "! grep -q 'ARGS+=(--slot-save-path' '$SETUP'"
  check "setup's api_key reads the first line only" grep -q "api_key() { awk 'NF {print; exit}'" "$SETUP"
  check "setup refuses to run during ai01-harden.sh" grep -q 'ai01-harden.sh is running' "$SETUP"
  rm -rf "$d"
}

t_static() {
  local f
  for f in "$HARDEN" "$SETUP" "$CLIENT" "$HERE/run-tests.sh" "$HERE"/stubs/*; do
    check "bash -n $(basename "$f")" bash -n "$f"
  done
  if command -v shellcheck >/dev/null; then
    check "shellcheck ai01-harden.sh (errors)" shellcheck -S error "$HARDEN"
    check "shellcheck ai01-client.sh (errors)" shellcheck -S error "$CLIENT"
  else
    printf '    skip  shellcheck not installed\n'
  fi
  check "python compiles llm.py and the fakes" python3 -m py_compile "$ROOT/patch01/api/app/llm.py" "$HERE/fake_llama.py" "$HERE/fake_front.py"
}

t_llm_unit() {
  if (cd "$ROOT/patch01" && python3 -m unittest -v tests.test_llm_mtls >"/tmp/llm-unit.$$" 2>&1); then
    ok "llm.py unit tests ($(grep -oE 'Ran [0-9]+ tests' "/tmp/llm-unit.$$"))"
  else
    nok "llm.py unit tests"; sed 's/^/      /' "/tmp/llm-unit.$$" | tail -30
  fi
  rm -f "/tmp/llm-unit.$$"
}

t_confirm_timeout_undoes() {
  new_ai01
  export AI01_CONFIRM_WAIT=6
  H "y" --step observe
  for _ in 1 2 3 4; do as_patch01 >/dev/null; done
  H "y" --step tls13; local rc=$?
  check "no request from PATCH-01 after tls13: undone" test "$rc" != 0
  check "says why" out_has 'no successful request from PATCH-01'
  check "TLS 1.2 allowed again" has "$AI01_NGINX_CONF" 'ssl_protocols +TLSv1.2 TLSv1.3;'
  check_not "TLS_PROTOCOLS removed from hardening.env" grep -q TLS_PROTOCOLS "$AI01_BASE/config/hardening.env"
  check "undo timer armed during the wait" grep -q 'systemd-run --unit=ai01-harden-undo-tls13' "$SB/state/calls"
  check "undo timer stopped" test ! -e "$SB/state/timer-ai01-harden-undo-tls13"
  check_not "not marked done" test -e "$AI01_BASE/hardening/steps/tls13"
}

t_enforce_undone_when_patch01_fails() {
  new_ai01
  H "y" --step observe; H "y" --step mtls; patch01_import
  # PATCH-01 then loses its certificate (deleted, expired...)
  rm -f "$SB/patch/secrets/ai01/client.crt" "$SB/patch/secrets/ai01/client.key"
  for _ in 1 2 3 4 5; do as_patch01 --cert "$AI01_BASE/certs/clients/patch01.crt" --key "$AI01_BASE/certs/clients/patch01.key" >/dev/null; done
  export AI01_CONFIRM_WAIT=12
  patch01_soon 2
  H "y" --step mtls-enforce; local rc=$?
  check "PATCH-01 refused under enforcement: step undone" test "$rc" != 0
  check_not "enforcement removed" test -e "$AI01_NGINX_SNIP_DIR/31-mtls-enforce.conf"
  check "PATCH-01 without certificate works again" test "$(as_patch01)" = 200
}

t_auto_undo_from_timer() {
  new_ai01
  H "y" --step observe; H "y" --step ratelimit
  local bk; bk="$(ls -d "$AI01_BASE"/hardening/backups/*-ratelimit | tail -1)"
  rm -f "$AI01_BASE/hardening/steps/ratelimit"   # as if the session was lost before the step was kept
  bash "$HARDEN" --auto-undo ratelimit "$bk" </dev/null >"$SB/o" 2>&1; local rc=$?
  check "the timer's undo runs without a terminal" test "$rc" = 0
  check_not "and removes the change" test -e "$AI01_NGINX_SNIP_DIR/20-ratelimit.conf"
  bash "$HARDEN" --auto-undo ratelimit "/etc" </dev/null >"$SB/o" 2>&1; rc=$?
  check "refuses a backup folder outside its own" test "$rc" != 0
}

t_rollback_dependencies() {
  new_ai01
  H "y" --step observe; H "y" --step mtls; H "y" --step ratelimit
  H "y" --rollback observe; local rc=$?
  check "observe cannot be rolled back under steps that need it" test "$rc" != 0
  check "names the step to roll back first" out_has "roll back '(mtls|ratelimit)' first"
  check "observe's files untouched" test -e "$AI01_NGINX_HTTP_SNIPPET"
  H "y" --rollback ratelimit; H "y" --rollback mtls; H "y" --rollback observe; rc=$?
  check "in the right order it works" test "$rc" = 0
  check "portal path works" test "$(chat "$(key)")" = 200
}

t_mtls_keeps_ca() {
  new_ai01
  H "y" --step observe; H "y" --step mtls
  local fp1; fp1="$(openssl x509 -noout -fingerprint -in "$AI01_BASE/certs/client-ca/ca.crt")"
  local cfp1; cfp1="$(openssl x509 -noout -fingerprint -in "$AI01_BASE/certs/clients/patch01.crt")"
  H "y" --rollback mtls
  check "rollback keeps the client CA" test -s "$AI01_BASE/certs/client-ca/ca.key"
  check "rollback keeps PATCH-01's certificate" test -s "$AI01_BASE/certs/clients/patch01.crt"
  H "y" --step mtls
  check "re-apply reuses the same CA" test "$(openssl x509 -noout -fingerprint -in "$AI01_BASE/certs/client-ca/ca.crt")" = "$fp1"
  check "and the same PATCH-01 certificate" test "$(openssl x509 -noout -fingerprint -in "$AI01_BASE/certs/clients/patch01.crt")" = "$cfp1"
  check "nginx does not refuse unverifiable certificates before enforcement" has "$AI01_NGINX_SNIP_DIR/30-mtls.conf" 'ssl_verify_client optional_no_ca;'
}

t_import_failure_restores() {
  new_ai01
  H "y" --step observe; H "y" --step mtls; patch01_import
  cp "$SB/patch/secrets/ai01/client.crt" "$SB/good.crt"
  # a bundle from another CA (e.g. an old AI-01): passes the file checks, fails the test once enforced
  patch01_soon 1; H "y" --step mtls-enforce
  local d="$SB/other"; mkdir -p "$d"
  openssl ecparam -name prime256v1 -genkey -noout -out "$d/ca.key" 2>/dev/null
  openssl req -x509 -new -key "$d/ca.key" -days 30 -subj "/CN=old CA" -out "$d/ca.crt" 2>/dev/null
  openssl ecparam -name prime256v1 -genkey -noout -out "$d/client.key" 2>/dev/null
  openssl req -new -key "$d/client.key" -subj "/CN=old" -out "$d/c.csr" 2>/dev/null
  printf 'extendedKeyUsage=clientAuth\n' >"$d/ext"
  openssl x509 -req -in "$d/c.csr" -CA "$d/ca.crt" -CAkey "$d/ca.key" -CAcreateserial -days 60 -extfile "$d/ext" -out "$d/client.crt" 2>/dev/null
  tar -cf "$SB/old.tar" -C "$d" client.crt client.key
  C "y|n|n" --import "$SB/old.tar"; local rc=$?
  check "importing a certificate AI-01 does not trust fails" test "$rc" != 0
  check "the previous certificate is back" same "$SB/patch/secrets/ai01/client.crt" "$SB/good.crt"
  C "" --test; rc=$?
  check "PATCH-01 still works end to end" test "$rc" = 0
}

t_rollback_all_keeps_key() {
  new_ai01
  H "y" --step observe; H "y" --step key-rotate
  local two; two="$(cat "$AI01_BASE/config/api-key")"
  H "y" --rollback-all
  check "rollback-all leaves the API key file as it is" test "$(cat "$AI01_BASE/config/api-key")" = "$two"
  check_not "and clears a half-done rotation" test -e "$AI01_BASE/hardening/key-rotate.pending"
}

t_key_rotate_refuses_two_keys() {
  new_ai01
  printf '%s\n%s\n' "$(key)" "$(openssl rand -hex 32)" >"$AI01_BASE/config/api-key"; restart_llama
  cp "$AI01_BASE/config/api-key" "$SB/two"
  H "y" --step key-rotate
  check "refuses to start a rotation over two keys" out_has 'no rotation is under way'
  check "key file untouched" same "$AI01_BASE/config/api-key" "$SB/two"
}

t_env_per_key_rollback() {
  new_ai01
  H "y" --step observe; H "y|y" --step llama
  for _ in $(seq 1 5); do as_patch01 >/dev/null; done
  patch01_soon; H "y" --step tls13
  H "y" --rollback llama
  check "rolling back llama keeps tls13's setting" grep -q '^TLS_PROTOCOLS="TLSv1.3"' "$AI01_BASE/config/hardening.env"
  check "and removes llama's" bash -c "! grep -q '^LLAMA_' '$AI01_BASE/config/hardening.env'"
}

t_changed_file_not_overwritten() {
  new_ai01
  H "y" --step observe; H "y|y" --step llama
  # ai01-setup.sh is re-run later and rewrites the arguments (say, a new model)
  printf '%s\n' "# changed later by ai01-setup.sh" >>"$AI01_BASE/config/llama-server.args"
  cp "$AI01_BASE/config/llama-server.args" "$SB/args.later"
  H "y" --rollback llama; local rc=$?
  check "rollback reports a problem" test "$rc" != 0
  check "says the file changed since" out_has 'changed after this step was applied'
  check "the later version is not overwritten" same "$AI01_BASE/config/llama-server.args" "$SB/args.later"
}

t_model_uses_running_model() {
  new_ai01
  { printf 'GGUF'; head -c 100 /dev/urandom; } >"$AI01_BASE/models/aaa-old.gguf"
  local sum; sum="$(sha256sum "$AI01_BASE/models/qwen3-8b-q4_k_m.gguf" | awk '{print $1}')"
  (cd "$AI01_BASE/models" && sha256sum ./*.gguf >SHA256SUMS)
  H "y|$sum" --step model; local rc=$?
  check "checks the model given to -m, not the first file found" test "$rc" = 0
  check "locks that model" grep -q 'qwen3-8b-q4_k_m.gguf' "$SB/state/immutable"
  check_not "not the other file" grep -q 'aaa-old.gguf' "$SB/state/immutable"
}

t_pulp_settings() {
  if "$ROOT/patch01/tests/test-pulp-settings.sh" >"/tmp/pulp-set.$$" 2>&1; then
    ok "PATCH-01 Pulp settings fix ($(tail -1 "/tmp/pulp-set.$$"))"
  else nok "PATCH-01 Pulp settings fix"; sed 's/^/      /' "/tmp/pulp-set.$$"; fi
  rm -f "/tmp/pulp-set.$$"
}

t_tls_old_versions_check() {
  new_ai01
  sed -i -E 's/(ssl_protocols +)[^;]*;/\1TLSv1.1 TLSv1.2 TLSv1.3;/' "$AI01_NGINX_CONF"
  H "" --check
  check "T16 fails when nginx enables TLS 1.1" out_has 'FAIL  T16'
}

ALL=(static setup-keeps-hardening llm-unit pulp-settings baseline-check refuses-without-terminal locks observe llama
     llama-build-without-flags llama-auto-rollback nginx-test-failure-rolls-back tls13 ratelimit
     mtls-and-enforce client-import-rejects firewall firewall-not-confirmed firewall-undo-already-fired
     firewall-internet-still-open firewall-bad-input model logs key-rotate key-rotate-single-key-build
     client-rotate-bad-key rollback-one rollback-all confirm-timeout-undoes enforce-undone-when-patch01-fails
     auto-undo-from-timer rollback-dependencies mtls-keeps-ca import-failure-restores rollback-all-keeps-key
     key-rotate-refuses-two-keys env-per-key-rollback changed-file-not-overwritten model-uses-running-model
     tls-old-versions-check full-hardening-check)
for s in "${ALL[@]}"; do scenario "$s"; done

printf '\n%d checks, %d failed\n' "$TOTAL" "$FAILED"
if ((FAILED)); then printf '  %s\n' "${FAILED_NAMES[@]}"; exit 1; fi
