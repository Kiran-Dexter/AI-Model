# Patch Platform: PATCH-01

A self-hosted patch and vulnerability management platform for an estate of
about 200 Linux servers running RHEL 8/9, Oracle Linux 8 and Ubuntu.

It mirrors vendor patches, tracks which servers are exposed to which
security advisories, explains each verdict in plain language using a local
language model, and shows it all on a web console.

Nothing here reaches the internet except PATCH-01's repository syncs, which go
through the corporate proxy. AI-01 has no internet access at all.


This is the PATCH-01 package. AI-01, the local language model server, has its
own package (`ai01-rNN.tar.gz`) and README.


## Architecture

```
                vendor repos (Red Hat CDN, Oracle, Ubuntu)
                               |
                         corporate proxy
                               |
+----------------------------- | -------------------------------------+
| PATCH-01  (RHEL 9, Docker)   v                                       |
|                                                                      |
|  NGINX :443  ── the only port open on this host                      |
|    /                 -> dashboard     static web console             |
|    /api/             -> patch-api     FastAPI: agents, admin, CVEs   |
|    /pulp/api/v3/     -> pulp-api      repository management          |
|    /pulp/content/    -> pulp-content  package downloads              |
|                                                                      |
|  pulp-worker   syncs and publishes repositories                      |
|  postgres      two databases: pulp, patchdb                          |
|  redis         job queue and cache                                   |
|                                                                      |
|  Every service except NGINX publishes NO host port. They talk over   |
|  the internal Docker network "patchnet" by container name.           |
+---------------------------|-----------------------------|------------+
                            | HTTPS 443                   | HTTPS 443
                            v                             v
        ~200 managed servers (agents)          AI-01 (RHEL 9, no internet)
        pull-only: check in, send               NGINX :443, allows PATCH-01 only
        inventory, poll for commands            llama-server on 127.0.0.1:8080
                                                Qwen3-8B Q4_K_M
```

Design rules that run through everything:

- **The verdict comes from a version check, never from the model.** The CVE
  engine decides; AI-01 only explains. Every explanation is labelled as
  advisory in the console.
- **Five applicability states**, stored as a database enum so every screen and
  report reads the same values: `affected`, `fixed_pending_reboot`,
  `fixed_active`, `unknown`, and `not_affected` (implied by absence). Only
  `fixed_active` counts as remediated. A server with the fixed kernel
  installed but not yet booted is **not** remediated.
- **A server that stops reporting shows as "unknown", never as zero.** Silence
  fails toward attention.
- **Agents accept a closed set of commands** (Linux 10, Windows 7). None takes
  a shell string, and package names can never be read as options. Two of them
  can run new code: `update_agent` and Windows `software_action`. Once the
  release key is pinned on the servers (see "Signed agent updates"), they only
  run what was signed on a machine that is not PATCH-01, so a compromised
  PATCH-01 still cannot run its own code as root across the fleet. Until the
  key is pinned, agents log a warning on every unsigned update.
- **The audit trail cannot be edited.** Database triggers reject UPDATE, DELETE
  and TRUNCATE on the audit log, job events and change events, for every role,
  and the API's database role owns nothing, so it cannot drop them either.
- **Scripts discover what is installed rather than assuming it.** Image names,
  user IDs, data paths, binary locations and supported options are all
  detected at run time.


## This package

```
patch01-rNN/
├── README.md, CHANGELOG.md, VERSION, MANIFEST.sha256
├── install.sh            installs to /opt/patch01 (previous kept in /opt/patch01.prev)
├── scripts/              run these, in the order below
├── compose/              templates; filled in by the scripts
├── nginx/                ingress configuration
├── sql/                  database schema, applied in order
├── api/                  patch API, CVE engine, AI-01 client
├── dashboard/            web console
├── config/repos.conf     which repositories to mirror
├── agent/                the agents PATCH-01 serves for "Update agents"
├── client/               the agents, to roll out (Linux: setup-agent.sh; Windows: windows/)
└── docs/proxy-allowlist.txt   for the network team
```

All commands below run as root from `/opt/patch01`.


## Installing or upgrading this package

```bash
tar -xzf patch01-rNN.tar.gz
cd patch01-rNN
sudo ./install.sh                  # checks every file, installs to /opt/patch01
cd /opt/patch01
```

Then the deploy commands of the release in CHANGELOG.md (newest entry). If a
release needs nothing special, this is the usual set:

```bash
./scripts/phase1a-ingress.sh
./scripts/phase3a-schema.sh
./scripts/phase3b-api.sh
./scripts/phase5-dashboard.sh
./scripts/patch01-update.sh        # health check
```

To go back: `sudo /opt/patch01/install.sh --rollback`, then the deploy
commands again. Take a VM snapshot before a release that changes the database
schema.


## AI-01 from PATCH-01's side

AI-01 is installed from its own package. On PATCH-01 only two things concern it:
`./scripts/phase6-llm.sh --ai01 <AI-01 address>` connects the API to it (step 6
of the build order), and `./scripts/ai01-client.sh` (`--test`, `--import`,
`--rotate-key`) is PATCH-01's half of AI-01's hardening; AI-01's README says
when to run it.


## PATCH-01: build order

Run as root from `patch01/`. Each script has `--dry-run`, and most have
`--check`, which you should run after each step.

| Step | Command | What it does |
|------|---------|--------------|
| 0 | `scripts/phase0-bootstrap.sh` | Packages, LVM volumes, `/patch` tree |
| 1 | `scripts/resolve-images.sh` | Finds which local images fill each role |
| 1a | `scripts/phase1a-ingress.sh` | NGINX and TLS on 443 |
| 1b | `scripts/phase1b-data.sh` | PostgreSQL and Redis |
| 1c | `scripts/phase1c-pulp.sh` | Pulp api, content, worker |
| 2 | `scripts/phase2-repos.py --setup`, `--sync`, `--publish` | Mirror the repositories |
| 3a | `scripts/phase3a-schema.sh` | Patch platform database schema |
| 3b | `scripts/phase3b-api.sh` | Build and run the patch API |
| 4 | `scripts/phase4-cve.sh` | Import advisories, compute verdicts |
| 5 | `scripts/phase5-dashboard.sh` | Web console |
| 6 | `scripts/phase6-llm.sh --ai01 <AI-01 IP>` | Connect to AI-01 |
| 7 | `scripts/phase7-vmware.sh --add <name> --host <vcenter>` | Read VM inventory from each vCenter |
| 8 | `scripts/phase4-cve.sh --set-nvd-key` then `--intel` | Fetch published CVE data |
| 9 | `scripts/phase7-vmware.sh --add-writer <name>` | Optional: write account for snapshots and power |
| 11 | `scripts/phase11-clamav.sh` | Optional: ClamAV scans packages uploaded in Deployment |
| 12 | `scripts/phase12-agents.sh` | Agent versions for "Update agents" (phase3b-api.sh publishes the package's) |

Step 3b runs two containers from the same image: the API, and the **worker**
that carries out scheduled changes and fills in CVE assessments. On its first
start the API creates the user `admin` from the `ADMIN_PASSWORD` already in
`/patch/secrets/api.env`, so the password you used before still signs in.

The **Assess** page and the chat need no setup beyond the API rebuild: they use
data the platform already holds.

Later schema changes are new files in `sql/` (`001`, `002`, `003`, ...).
Re-running `phase3a-schema.sh` applies any that are missing; it is safe to
run again at any time.

Before step 2, the corporate proxy must be recorded in
`/etc/patch-platform/proxy.env` (`HTTP_PROXY`, `HTTPS_PROXY`, `NO_PROXY`).
Step 2 reads it from there, not from your shell.

**Note on phase 0:** it was written when the plan was Podman, before Docker was
chosen. It installs Podman and moves Podman's image store onto `/patch`, which
is harmless but does not apply to Docker. Docker's own storage location is not
handled by phase 0; phase 1a detects if Docker is still storing images on the
root filesystem and prints the steps to move it.


## Upgrading from r11

```bash
./scripts/phase3a-schema.sh            # schema 009: users, sessions, changes
./scripts/phase3b-api.sh               # API and the new worker; creates 'admin'
./scripts/phase3b-api.sh --check       # confirms the worker is beating
./scripts/phase5-dashboard.sh          # sign-in page, Changes, Users
./scripts/phase7-vmware.sh --add-writer vc-uat   # only for snapshots and power
```

From r15, also run `./scripts/phase8-hardening.sh --fetch <version>` and
update agents to 1.4.0 for hardening scans.

From r14, also run `./scripts/phase7-vmware.sh --sync` once after
`phase3b-api.sh`, so health, alarms and application groups are filled in
before the map is first opened.

Then sign in as `admin` with the old password, open **Users** and create an
account for each person. Update the agents to 1.3.0 before scheduling the
first patch job (see Updating agents). Hard-refresh the browser once
(Ctrl+F5) so it loads the new console.


## The live VMware map

**VMware > Live map** draws the whole estate from vCenter: port groups on the
left, clusters with their ESXi hosts and VMs in the middle, datastores on the
right. Switch to **Applications** to group VMs by application instead.

| Colour | Means |
|--------|-------|
| Neon red | Host down or not responding; datastore 90%+ full or inaccessible; red vCenter alarm; exploited CVEs to patch; host CPU or memory 95%+ |
| Amber | Patches or a reboot due; maintenance mode; yellow alarm; VMware Tools not running; snapshot 7+ days old; datastore 80%+ full or over-provisioned; HA off |
| Green | Running, nothing to act on |
| Grey | Powered off |

A dashed ring round a VM means no patch agent, so its patch state is unknown.

**Blast radius.** Click a host, datastore or port group:

- **Host:** every VM on it, and whether HA restarts it. A VM stays down if the
  cluster has HA off, the host is standalone, a disk is on storage only that
  host sees, or the other hosts lack the memory. VMs are placed largest
  first, the way capacity actually runs out.
- **Datastore:** every VM with any disk on it goes down. HA cannot help.
- **Port group:** VMs with no other network are isolated; the rest degraded.

Each shows the applications hit. Click a VM to trace its host, datastores and
networks.

**Live updates.** The worker holds a change stream open to each vCenter with
the read-only account, and records vMotions, power changes, host failures,
maintenance mode and alarms as they happen. The page checks every 5 seconds;
changed objects ripple, and the side panel shows a live feed. The LIVE light
is green while every vCenter is streaming, amber if one is reconnecting.

**Application groups** come from a vSphere tag in a category called
Application (or App, Service, Workload, System), else the VM's folder. The
**Coverage** tab lists what is ungrouped, and which VMs are on standard
switches only (which cannot export flow records for dependency lines later).

The hourly `phase7-vmware.sh` sync still runs: it refreshes everything the
stream does not carry, such as disks, performance and tags.


## Hardening

Each server is compared with the CIS benchmark as published in the SCAP
Security Guide (ComplianceAsCode): CIS-aligned, not the licensed CIS-CAT
tool. One release is pinned on PATCH-01 and served to every agent, so every
server is judged by exactly the same rules.

**Setting up**

```bash
./scripts/phase8-hardening.sh --fetch 0.1.NN      # release number from the ComplianceAsCode
                                                  # GitHub releases page
./scripts/phase8-hardening.sh --status            # products, rules, CIS levels found
```

The proxy must allow github.com, objects.githubusercontent.com and
release-assets.githubusercontent.com. Without internet on PATCH-01, download
`scap-security-guide-0.1.NN.zip` and its `.sha512` elsewhere, copy both over,
and run `--import-zip scap-security-guide-0.1.NN.zip`.

On every server: agent 1.4.0 (`client/install-agent.sh`) and the OpenSCAP
scanner, from a mirrored repository:

| OS | Package |
|----|---------|
| RHEL 8/9, Oracle Linux 8/9 | `openscap-scanner` (AppStream) |
| Oracle Linux 7 | `openscap-scanner` (`yum`) |
| Ubuntu 24.04 | `openscap-scanner` (universe) |
| Ubuntu 20.04, 22.04 | `libopenscap8` (universe) |

A server without the scanner shows "last scan failed" with the install
command. Then scan from the console, or `./scripts/phase8-hardening.sh --scan`.

**What is scored.** Score = passed rules / (passed + failed). Not applicable
and not checked rules do not count either way. A product whose content has
no CIS profile at the chosen level shows "no L1 profile" rather than a score:
nothing is labelled CIS that is not.

**Evidence.** Every scan's full result file is kept in
`/patch/data/hardening/evidence`, with its SHA-256 shown in the console.

**Custom profiles.** A profile built from your own document checks only
the settings it lists. On the Hardening page, open the profile list and
choose *New or manage custom profiles*: name it, choose the benchmark its CIS
numbers follow (CIS numbering differs between RHEL 8, RHEL 9 and Ubuntu),
and upload the file or paste the list. Every line is shown with the check it
matched and how (CIS number, title, AI-01, or chosen by you). Lines marked
**?** matched by number but read differently, often a sign the document
follows another benchmark version; confirm them. Process items (access
reviews, backups) stay as manual checks and appear in reports as such. Scans
with a custom profile need agent 1.6.0.

**Risky rules** (SSH, PAM and passwords, firewall, sudo, audit, mount
options, boot loader, kernel modules) are marked: fixing them can cut off
access or stop services. Fixes arrive in increment 5, one server first.


## Rolling out agents

**Linux**, from PATCH-01 or a jump host with SSH keys to the servers:
```bash
cd client
./push-linux.sh -H servers.txt -s https://patch01.example --ca corp-ca.pem -u root --test-only
../patch01/scripts/phase10-windows.sh --tokens <N> <group> > tokens.txt     # N from the test run
./push-linux.sh -H servers.txt -s https://patch01.example --ca corp-ca.pem -u root -t tokens.txt
```
**Windows**, from a jump host with WinRM:
```powershell
.\push-agent.ps1 -Computers servers.txt -Server https://patch01.example -Pin system -TestOnly
.\push-agent.ps1 -Computers servers.txt -Tokens tokens.txt -Server https://patch01.example -Pin system
```
`-Pin system` trusts PATCH-01 through Windows' own certificate store, which
needs your CA there (usually by Group Policy); certificate renewals then need
no re-pin. Otherwise use the pin from Admin › Certificate.
Tokens last 72 hours: make them per batch.


## Windows servers

On PATCH-01:
```bash
./scripts/phase10-windows.sh --msrc          # Microsoft's CVE data, 24 months (proxy: api.msrc.microsoft.com)
./scripts/phase10-windows.sh --pin           # the certificate pin for the agents
./scripts/phase10-windows.sh --tokens 1      # one enrolment token (or 50 for push-agent.ps1)
```

On a Windows server, as administrator, from `client/windows`:
```powershell
.\install-agent.ps1 -Server https://patch01.example -Pin <pin> -SelfTest     # checks every step, installs nothing
.\install-agent.ps1 -Server https://patch01.example -Pin <pin> -Token <token>
```
For many servers, from a jump host with WinRM access (each server runs the
self-test first and is only enrolled if it passes):
```powershell
.\push-agent.ps1 -Computers servers.txt -Server https://patch01.example -Pin <pin> -TestOnly
.\push-agent.ps1 -Computers servers.txt -Tokens tokens.txt -Server https://patch01.example -Pin <pin>
```
The pin changes when PATCH-01's certificate is replaced (for example by the
CA-signed one): re-run `install-agent.ps1 -Update` after setting the new pin,
or reinstall. With a CA-signed certificate the pin can be `system`.

**Two views of what is missing.** The advisories come from the OS build and
Microsoft's data, so they include fixes WSUS has not approved. The Windows
Update section shows what WSUS has approved but the server has not installed.
Fixes that are not part of the OS build (.NET, SQL Server) appear only in the
second.


## Reports and branding

**Logo.** Copy a PNG to `/patch/data/branding/logo.png` on PATCH-01 (any
size; a transparent background looks best). Optionally add
`logo-white.png` for dark backgrounds. There is nothing to configure:
PATCH-01 trims, sizes and caches it, and uses the new file as soon as it
changes. **Admin › Branding** shows what it made of it, and any advice (for
example, if the logo is too small to print sharply).

**Company details** on the same page: name, the copyright line for every
footer, and the classification (CONFIDENTIAL, INTERNAL, RESTRICTED, PUBLIC).

**Making a report.** Hardening › **Export report**: choose the report type
(*Management summary*, or *Technical detail* with how to fix each finding),
the scope, an optional cover title, then **PDF** or **Word**. It is built
from each server's latest scan, downloads at once, and stays in the
**Reports** list below with its SHA-256, so a copy given to an auditor can
be matched to the original. Files are kept in `/patch/data/hardening/reports`.

**E-mailing it.** **Email this report** (or **Email** in the Reports list)
opens a window with the report's key figures and a draft from AI-01, which
takes up to a minute on AI-01's hardware. Edit it, add recipients, and send:
the report goes as an attachment, with the signature from Admin › Mail.
Mail must be set up under Admin › Mail first.

The Word version opens with an offer to update fields: say yes, and the
contents gain their page numbers.


## Mail alerts

Set up on the admin **Mail** page:

1. **Relay:** host, port and encryption (STARTTLS on 587 or 25, TLS on 465, or
   none for a plain internal relay). For a mailbox, give its login and
   password. If the relay's certificate comes from an internal CA, paste
   that CA under *Certificate checks*.
2. **Sender:** the mailbox address, and the name recipients see.
3. **Test connection.** Each step is shown, and a failure says what to fix.
4. **What to send** and **when**, then **Save settings**.
5. **Recipients:** add addresses and tick the kinds of mail each receives;
   use **Test** beside each. Then tick *Send mail alerts* and save.

SMTP goes straight from PATCH-01 to the relay, not through the web proxy:
the firewall must allow PATCH-01 to reach the relay's port.

| Mail | When |
|------|------|
| Critical | Within a minute: exploited CVE on a server, ESXi host not connected, vCenter unreachable, datastore at 90% (cleared below 85%), failed change, high-severity hardening drift, worker stopped |
| Task | A change starts or finishes; a scan someone requested completes |
| Daily digest | At the chosen time (Singapore): fleet state and the last 24 hours |
| Weekly summary | The chosen day: the week, and the servers with most to patch |

The relay password is write-only: the console can replace it but never shows
it. It is stored encrypted with `/patch/secrets/mail.key`, which exists only
on PATCH-01. If that key is lost, enter the password again.

From PATCH-01 itself: `./scripts/phase9-mail.sh --status`, `--check`,
`--test ADDRESS`, `--off`, `--on`.


## Users and roles

Everyone signs in with their own account, so the Activity log and every
change record name a person rather than a shared login.

| Role | Can |
|------|-----|
| Viewer | See every dashboard, server, advisory, VMware page, past assessment and change record. Changes nothing. |
| Operator | Everything a viewer can, plus schedule patch jobs and VMware actions, cancel them, run CVE assessments, use the chat and AI explanations. |
| Admin | Everything, plus users, enrolment tokens, decommissioning, and the B-Mode theme. |

Viewers and operators choose between Default and Dark. B-Mode is the
admin's theme only.

Accounts are created on the **Users** page with a temporary password; the
person must choose their own at first sign-in. Passwords need 12 or more
characters from at least three of: lower case, upper case, digits, symbols,
and may not contain the username. Five wrong passwords lock an account for 15
minutes; an admin can unlock it sooner. Sessions last 12 hours of activity and
end when the browser tab closes. The last active admin cannot be disabled or
demoted, so the platform can never be left without one.

Enforcement is in the API, not the console: hiding a button is convenience,
and a viewer calling an operator endpoint directly is refused.


## Patch jobs and VMware actions

Every action that changes something goes through **Changes**. Each change
has a number (`CHG-000042`), a required reason, a window, and a timeline of
every step with who did it. The record cannot be edited afterwards.

Operators do not need approval. If your change process later requires it, set
`REQUIRE_APPROVAL=true` in `/patch/secrets/api.env` and re-run
`phase3b-api.sh`; every change then waits until an admin other than the
requester approves it: **Approve** or **Reject** on the change's page (r90).

**A patch job** is created from **Changes > New patch job**, or from a
server's page with **Patch this server**. For each job you choose:

- What to install: all outstanding security fixes, or only named advisories.
- Reboot: never (the server is flagged instead), only if required, or always.
- VM snapshot: none, take one and keep it, or take one and remove it if
  patching succeeds. Needs the server to be linked to its VM and a write
  account for that vCenter.
- Whether services running before must still be running afterwards.
- The window, and how many servers run at once.

**Preview** shows the exact packages each server will install before anything
is scheduled. Each server then goes through the same steps, and stops at the
first failure without touching the rest:

pre-check (disk space, repositories, running services), snapshot, install,
reboot and wait for it to return, post-check, fresh inventory, snapshot
clean-up. Verdicts are recomputed straight after, so the dashboard reflects
the result at once. A server that fails keeps its snapshot for rollback.

**Cancelling** stops servers that have not started. A server part way through
finishes its current step and stops before installing.

**VMware actions**: take, remove or revert a snapshot; power on; shut down or
restart the guest cleanly through VMware Tools. There is no hard power-off:
PATCH-01 never pulls the power. Only actions valid for the VM's state are
offered.

**Reverting** discards everything since the snapshot. It requires typing the
VM's name, and PATCH-01 first takes a snapshot of the current state, so a
revert can itself be undone.

**Removing snapshots by name or age** (r99): **Changes > Remove snapshots
by name or age**. Filter by name (contains, starts with, exact, or a pattern
such as `Before patch*`) and/or by age (only snapshots older than N days, for
example 10), optionally narrowed to one vCenter or VM name. **Find
snapshots** lists every match across all VMs; tick the ones to remove (all
are ticked to start with). A snapshot that another open change is using, or on
a vCenter without a write account, is shown greyed and cannot be ticked.
Give a reason, type the number of snapshots to confirm, and schedule it.

The change page shows each VM's list, and as it runs, how many were removed,
skipped or failed. Just before each removal the snapshot is checked again on
the VM: it is skipped if it was already removed, renamed, or no longer
matches the filter. Only the snapshot itself is removed, never its children.
**Cancel** or the end of the window stops it before the next snapshot (one
already being removed in vCenter finishes); the rest are listed as skipped.
While a change that has not finished uses a snapshot (a patch job's own
snapshot, a single removal or revert, or another clean-up), it is greyed here,
and a single remove or revert of a snapshot held by a clean-up is refused. A
patch job's "kept for rollback" snapshot is free again once that job ends, so
check the name before ticking it. A pattern of only `*` needs an age as well.
Limits: 1000 snapshots per change, 100 per VM. Removal cannot be undone. To
make these changes wait for an admin's approval even when other changes do
not, set `SNAPSHOT_CLEANUP_REQUIRE_APPROVAL=true` in `/patch/secrets/api.env`
and re-run `phase3b-api.sh`.

**Write account.** Syncing uses the read-only account. Snapshots and power use
a separate account per vCenter, added with `--add-writer`, which prints the
exact privileges its role needs and tests the login. Without one, the console
shows VMware actions as unavailable for that vCenter.

**Banned actions** (r100). PATCH-01 never deletes or unregisters a VM, never
hard powers off, resets or suspends one, never changes its hardware, disks or
location, never runs a program or touches a file inside a VM, and never touches
ESXi hosts, datastores, permissions or roles. This is enforced in PATCH-01
itself: every vCenter connection it opens refuses these calls before they are
sent (`api/app/vc_guard.py`), whatever rights the account has, and a test fails
the build if any code tries to call one. Nothing in the console turns it off.
The only changes PATCH-01 makes in vCenter are: take, remove or revert a
snapshot, power on, and ask the guest OS to shut down or restart.

Tighten the account too, so its password alone cannot do more:
`./scripts/phase7-vmware.sh --check-writer vc01` lists any dangerous rights it
holds (delete VMs, delete datastore files, run programs in VMs, change
permissions...). `--add-writer` runs the same check.

Agents are closed in the same way: they accept a fixed list of jobs, never a
command line, and never remove software during patching (Linux agent 1.8.4+
uses apt's `--no-remove`; dnf never removes without `--allowerasing`, which is
not used). Windows programs can be removed only from the removable tools list,
and critical software (databases, security, backup, drivers...) never.

The worker must be running for anything to start. The Changes page shows a
warning if it has stopped; `phase3b-api.sh --check` reports it.


## Client servers

Copy `client/` to the server, then as root:

```bash
# On PATCH-01, get a single-use token
./scripts/phase3b-api.sh --token

# On the server
./install-agent.sh --server https://patch01.example --token <token> --insecure
```

The installer checks it can reach PATCH-01, tests inventory collection before
contacting it, enrolls, and installs a systemd timer that checks in every five
minutes. `--insecure` is only for while PATCH-01 has its self-signed
placeholder certificate; use `--ca <file>` once the CA-signed certificate is in
place.

Works on RHEL 8 (it uses the system Python 3.6), RHEL 9, Oracle Linux and
Ubuntu. The agent never routes its traffic to PATCH-01 through a proxy, even
if one is set in the environment.


## VMware vCenter

Read-only. PATCH-01 reads each vCenter's VMs and snapshots and links every
server to the VM it runs in. Nothing is changed in vCenter.

**Account.** Create a dedicated account, for example
`svc-patch01@vsphere.local`, in each vCenter, and give it the built-in
**Read-only** role at the top of the inventory with **Propagate to children**
ticked. That is all this needs. Snapshot rights are added only later, when
patch jobs take snapshots before patching.

**Add each vCenter** from `patch01/`:

```bash
./scripts/phase7-vmware.sh --add vc-sg01 --host vcenter01.corp.local
./scripts/phase7-vmware.sh --add vc-sg02 --host vcenter02.corp.local
./scripts/phase7-vmware.sh --install-timer        # sync every hour
```

`--add` shows vCenter's certificate thumbprint. Compare it with the one in
the vSphere Client under **Administration > Certificates > Certificate
Management > Machine SSL Certificate** before confirming. Use the vCenter's
name as it appears in its certificate, normally its FQDN, or the connection
is refused. The first `--add` also applies schema 004 and rebuilds the API
with VMware's Python library, which it downloads through the proxy.

**How servers are linked to VMs.** By hardware ID, which VMware sets as the
VM's BIOS UUID and the server reads from its firmware. That needs agent 1.2.0
or later. Older agents are linked by hostname or IP address instead, which is
weaker, and the console shows which method linked each one. A VM that shares
its hardware ID with another, usually a clone, is marked ambiguous rather
than guessed.

**Infrastructure and the map.** The VMware page has a **Map** tab showing
vCenter > datacenter > cluster > ESXi host > VM as an expandable tree, with
each VM marked by its patch and agent state, and a datastore summary. Separate
tabs list ESXi hosts (hardware, CPU model, ESXi version and build, connection
state, maintenance mode, uptime, CPU and memory load, VM count), datastores
(type, capacity, used, free, provisioned beyond capacity, hosts, VMs),
networks and clusters (DRS, HA, totals). Each VM also records its ESXi host,
folder path, datastores, networks, disks with sizes and thin provisioning,
hardware version, Tools version, boot time and provisioned storage.

**What the VMware page shows:** every VM across all vCenters, Windows
included, with a filter box for name, server, cluster or OS; Linux VMs running
without an agent; VMs with snapshots and their age; and ambiguous links.
Windows VMs appear as "not managed", since the Linux agent does not cover
them. Each server page
shows its VM, cluster, ESXi host, size and any snapshots.


## CVE intelligence

Advisories say which package to update; they rarely say what the flaw is.
These four sources fill that in, and every fact is shown with its source:

| Source | What it gives |
|--------|---------------|
| NIST NVD | Description, CVSS score and vector, weakness type (CWE) |
| CISA KEV | Whether the CVE is being exploited in the wild |
| FIRST EPSS | Probability of exploitation in the next 30 days |
| Red Hat | Red Hat's own severity, score and statement for RHEL |

**Get a free NVD API key** first. It raises the limit from 5 to 50 requests
every 30 seconds, and the first import is one request per CVE:

```bash
./scripts/phase4-cve.sh --set-nvd-key      # from nvd.nist.gov/developers/request-an-api-key
./scripts/phase4-cve.sh --estimate         # how long the first import will take
./scripts/phase4-cve.sh --intel
```

A few thousand CVEs takes roughly 30 to 40 minutes with a key, and several
hours without. Afterwards only new and changed CVEs are fetched, so the
nightly run is quick. This is the only part of the platform that reaches the
internet besides repository syncs; it needs four proxy allowlist entries,
listed in `docs/proxy-allowlist.txt`.

**Attack types are derived, not claimed.** "Remote code execution, no login
needed" comes from combining the weakness type with the CVSS vector, and the
console always shows what it was derived from, for example "CWE-362; attack
vector network, no login". Where the published data does not support a
label, it says "Unclassified" rather than guessing.

**This is what makes explanations specific.** Before, every CVE produced
roughly the same answer, because the model was only given an advisory title
such as "kernel security update". It now receives the score, how the flaw is
reached, whether it is exploited in the wild, and the CVE description.
Cached explanations are regenerated automatically when NVD rescores a CVE or
CISA adds it to the exploited list.


## Vulnerabilities

**Vulnerabilities** is one page with three tabs, so a CVE is looked at in one
place whether it came from the feeds, from outside or from a vendor advisory:

| Tab | What it shows |
|---|---|
| **Detected CVEs** | New critical, high and 0-day CVEs from NIST, Microsoft and Red Hat, already matched to our machines by the worker |
| **Advisories** | Vendor advisories (Red Hat, Oracle, Ubuntu...) and Windows updates still to install, with the servers waiting for each |
| **Assess CVEs** | A list given by a SOC, an auditor or a vendor: paste it or upload a text or CSV file |

Every row opens with **+**: for a CVE, the machines it was found on, where
(Linux package, Windows program, operating system, hardware), how certain the
match is and why, and AI-01's brief; for an advisory, its servers and CVEs and
a **Patch these servers** button that opens a patch job already filled in.
Each tab has a search, filters and 20 rows a page.

Every CVE, from any of the three, is checked in the same order:

1. **The CVE database**: what is vulnerable and on which platform.
   - NIST NVD: the affected products, their version ranges, and the platform
     each runs on (NVD's "for Windows" field and its "running on" entries),
     plus description, CVSS, attack type, CISA KEV and EPSS.
   - Microsoft: the products it lists as affected (not those it lists as not
     affected). Its Azure Linux and CBL-Mariner entries are not our platforms.
   - Red Hat: the packages it shipped a fix in, and its own answer per RHEL
     release (fixed in build X, affected with the fix deferred, not affected),
     read once a day per CVE. A component only named in Red Hat's title is
     never matched on its own: Red Hat also lists CVEs RHEL is not affected by.
2. **The assets**: every machine as one record, merged from the agents, WSUS
   and the vCenter guests (and ESXi hosts and vCenters): host name, address,
   operating system and where it is known from. The agent's own report of
   its OS wins over WSUS, and WSUS over the vCenter guest.
3. **Software**: Linux packages, and Windows programs against NVD's version
   ranges. On RHEL, Oracle Linux, Rocky and Alma the installed build is
   compared with Red Hat's fixed build for that machine's release.
4. **Operating systems**: a CVE for Windows 10 or Server 2019 finds a Windows
   10 Pro desktop or a Server 2019 box even without an agent; the edition
   does not hide it.
5. **Hardware and VMware**: server models, ESXi and vCenter versions.
6. **The platform check**: a match counts only when the machine runs a
   platform the vulnerable product runs on. A Windows-only CVE is never put
   on a Red Hat server because a package there has the same name (Windows
   OpenSSH and the openssh package, Git for Windows and git). The machines
   ruled out are listed under the CVE with the reason; a machine whose OS is
   not known is kept, marked so, and never counted as confirmed.
7. **AI-01** writes the brief from those facts, each machine with its OS. It
   never decides the verdict, and a brief written from earlier findings is
   withdrawn when the findings change.

Each machine a CVE is found on is shown with its address, operating system,
what was found, how certain, why, and the source of the match.

**Where the results appear.** The same results feed the Detected CVEs tab,
the Impacted CVEs donut on the Patch Dashboard, AI-01's 15-minute analysis,
each server's "Detected CVEs" on the Servers page, the assistant, and every
export. They are re-checked when a machine's installed versions or OS change
(a patch, an upgrade, a new machine), when Red Hat's per-release answer
arrives, and at least daily. A patched server drops off a CVE at the next
pass, within a few minutes of its agent reporting.

Saved assessments are the exception: each is a record of the answer on the
day it was run, kept as evidence. Run it again for today's answer.

| Verdict | Meaning |
|---|---|
| Affected | A version check confirms it: a package needs the fix, or a version is inside the affected range |
| Possibly affected | The product or OS is present but its exact patch level could not be compared (a Windows build, an ESXi build) |
| Needs reboot | Fixed, awaiting a reboot |
| Not in our inventory | Network devices and firmware: check with their owners |
| Not found | Nothing matching is in the inventory |
| Patched / Not affected | Found and already fixed, or present at a safe version |

"Possibly affected" is deliberately not "affected": it asks a person to
confirm. Each assessment is saved, so the answer can be reopened later and
exported to send back to whoever asked.


## Sorting, selecting, exporting and e-mailing (every page)

- **Sorting:** every table's column headings sort the rows (click again to
  reverse, a third time to undo). Paged lists sort the whole list before
  paging: Assets, Coverage, Antivirus, Detected CVEs, Advisories. Dates sort
  by time and severities by risk.
- **Selecting:** every table has tick boxes. Paged lists remember ticks
  across pages and filters; a filter hides ticked rows without dropping them
  ("+N hidden by the filter"), and actions and exports use only the visible
  ticked rows.
- **Export ▾** offers the whole table as PDF or CSV, and **PDF / CSV,
  selected rows** when rows are ticked.
- **E-mail…** (operators) offers:
  - the reports PATCH-01 builds itself for that page;
  - **This table, as shown**;
  - **Selected rows only**.

  Rows sent from a page are marked "as shown on <page> by <user>". As with
  the other report mails, they go only to the recipients in Admin > Mail,
  count in the 10-an-hour limit and are recorded in Activity before they are
  built.

**E-mail wording.** Every mail opens with "Dear Security Team," and a
security summary, states the **Required action** when there is one, and ends
with "Regards, Cyber-Secure Security Operations" (or the signature set in
Admin > Mail). It carries the line "Classification: INTERNAL – security
information about your environment. Do not forward outside the
organisation." Alerts, digests, reports, hardening and assistant mails all
use this tone.


## Exports

Every page with data has one **Export** button. It offers:

- **PDF report**: landscape A4 with the logo, the report name, organisation,
  date and time (SGT), who made it, the filter in use and the row count; the
  table repeats its heading on every page and each page is numbered.
- **CSV**: for Excel, starting with the same heading lines (a CSV is plain
  text and cannot hold a picture, so the logo is in the PDF).

What is exported is what the page shows with its filters, and every row, not
just the current page (Servers and the Vulnerabilities tabs export all
matching rows). Text that a spreadsheet would run as a formula is neutralised.
Hardening keeps its own formal CIS report (PDF or Word) under the same Export
button, plus CSV. Each export is recorded in Activity.


## Antivirus (Trend Micro Apex Central)

**Admin > Antivirus** holds one entry per Apex Central console: a name, the
console URL (`https://host` or `https://host:port`), the Application ID and
the API key. To get the ID and key, in Apex Central go to Administration >
Settings > Automation API Access Settings > Add, tick "Enable application
integration using Apex Central Automation APIs", and copy both values. Use
an account with a read-only role.

- **Test connection** signs in and lists the agents without saving anything,
  and shows the count, the products and a few names. Test works from the form
  before saving, and on a saved console with its saved key.
- **Read-only by construction.** PATCH-01 only sends GET requests: the
  agent list and the logs (definition status, detections). The code has no
  way to isolate, scan, update, move or uninstall.
- **The key.** It is encrypted with `av.key` (made by `phase3b-api.sh` in the
  secrets folder, kept with the other secrets in backups). It is decrypted
  only in memory to sign a request, never shown again, never logged, and
  never sent to Apex Central either: each request carries a short-lived
  token signed with it, as Trend Micro specifies.
- **The key stays with its console.** Changing a console's URL needs the
  key typed again, so a saved key never signs for another address.
- **Addresses.** The console must be a host name or a full address. Names
  are resolved and checked before connecting, and the connection goes to
  the address that was checked. This machine, link-local and cloud-metadata
  addresses are refused.
- **Self-signed certificate on Apex Central** (usual on IIS). Open
  "Certificate and network" and press **Get certificate**: PATCH-01 makes
  the TLS handshake only, sending nothing, and shows the certificate with
  its SHA-256 and SHA-1 fingerprints. SHA-1 is what Windows calls the
  Thumbprint. Compare it on the Apex Central server, either in IIS Manager >
  Server Certificates > the certificate > Details > Thumbprint, or with:

  ```powershell
  Get-ChildItem Cert:\LocalMachine\My | Select Subject, Thumbprint
  ```

  Then tick "trust exactly this certificate", test and save.
  - Every connection checks that exact fingerprint right after the
    handshake, before anything is sent.
  - If the certificate is renewed or replaced, the connection stops and
    shows the new fingerprint, so you can check it and trust it again.
  - This works even when the certificate is issued to the server's short
    name or lists no names.
  - Changing the console's URL removes the trust; it has to be given again.
- **Certificates.** These are always verified, with no switch to turn that
  off. If the console uses a certificate from your own CA (or IIS's
  self-signed one), paste the CA certificate (PEM) under "Certificate and
  network". Redirects are refused. Internal consoles are reached directly,
  not through the web proxy.
- **Firewall.** PATCH-01 needs HTTPS (443, or the console's port) to each
  Apex Central server.
- **Reading.** Every hour, and at once on **Sync now**. Agents a console no
  longer lists are kept for a week, marked "not listed".

The **Antivirus** page (Asset & Inventory and Patch modules) shows:
- the consoles and when each was last read;
- small tiles: Agents, Outdated definitions, Detections (24 h),
  Ransomware (24 h), No antivirus, Isolated, Not in inventory;
- every agent with its address, product, console, definition status ("up to
  date", "3 versions old"), isolation state, and the machine it is in our
  inventory (matched by address, then full name, then short name). **+**
  opens the domain, folder, MAC addresses, managing server and inventory
  sources;
- **Detections**: the latest AI-01 threat summary, then every detection of
  the last 24 hours or 7 days, filtered by type (virus/malware, ransomware,
  spyware/grayware, behaviour monitoring, machine learning, C&C callback,
  web threat) and "not cleaned only". **+** opens the file, SHA-1, user,
  result and console.

**No antivirus** lists the machines in the inventory (agents, WSUS, vCenter
guests) that no console reports. Each server's **+** on the Servers page
shows its antivirus console. Every view exports as PDF or CSV.

### Antivirus logs and the daily threat summary

Each hourly read also fetches two kinds of Apex Central log (read-only):

- **Pattern Update Status.** Apex Central's own judgement of how many
  versions behind each endpoint's pattern is (0 = up to date, up to 7 = seven
  or more). This is what "Outdated definitions" uses.
- **Detections.** Virus/malware, and where the console offers them:
  spyware/grayware, behaviour monitoring, predictive machine learning, C&C
  callback and web threat logs. Each detection is tagged by type.
  **Ransomware** is recognised by the threat name (Ransom, LockBit and so
  on) and by behaviour monitoring's "unauthorized file encryption".
  **Not cleaned** means the action failed or the file was only passed or
  logged.

Notes:
- Log types are discovered per console. A type the console does not offer is
  shown as unavailable in Admin > Antivirus (Logs column) and tried again
  daily.
- The first read goes back 7 days. Later reads continue from the last log
  read. Detections are kept for 90 days.

**Antivirus threats, daily summary** (Admin > Scheduled reports, 08:05 SGT,
on by default) mails the figures for the last day (or N days): detections,
machines, ransomware, not cleaned, outdated, offline, with the top threats,
the machines with most detections, the not-cleaned list and the full PDF.

- AI-01 writes a short summary from those figures.
- Every number in the summary must be one of the figures it was given.
  Otherwise the summary is dropped and the figures are written out as plain
  sentences instead.
- Threat and machine names come from the antivirus logs and are passed to
  AI-01 as fenced data, never as instructions.
- Each summary is kept with the figures it was written from.

The **AI-01 assistant** answers, from the same data:
- "which machines have outdated antivirus definitions";
- "antivirus agents offline";
- "which servers have no antivirus";
- "any ransomware today?";
- "malware not cleaned this week";
- "antivirus threat summary for 7 days".

**Pushing a definition update from the console is not available.** Trend
Micro's published Apex Central Automation API has no "update now" action
for agents. The only update-related action changes where agents download
updates from. Start the update from the Apex One server console's agent
management (select the agents, then update now), or let the scheduled update
run. PATCH-01 shows which agents are behind so you know where to start.

### Product servers under Apex Central (r69)

One Apex Central can manage several product servers: more Apex One servers,
Deep Security Managers, email security (IMSVA, DDEI, ScanMail) and others.

- **Discover.** Admin > Antivirus > *Products under <console>* > **Discover
  products** asks Apex Central for its product servers (one GET) and lists
  each with its type, address and how many agents it reports. Nothing changes
  until you choose.
- **Choose which to sync.** Tick the servers you want and **Save which to
  sync**. From then on only the ticked servers' agents are kept; agents under
  an unticked server are removed at once and skipped on every read. A server
  that appears later stays off until ticked (shown "new: not chosen yet"). The
  list is read again once a day; a server Apex Central no longer lists is
  shown "no longer listed" and leaves the inventory. Until a choice is saved,
  every agent is synced as before.
- **Deep Security Manager, read directly (optional).** Apex Central shows
  only part of what a Manager knows. **Add API key** on a Manager's row:
  - URL, usually `https://<manager>:4119`.
  - An API key from Deep Security > Administration > User Management > API
    Keys, with a role that can only view computers. Encrypted with `av.key`,
    never shown again, and only ever sent to the URL it was saved with.
  - **Get certificate** reads the Manager's certificate (handshake only) and
    says what it is: signed by a CA PATCH-01 already trusts (nothing to do),
    signed by your own CA (paste that CA, or trust the certificate by its
    fingerprint), self-signed (compare and trust it by its SHA-256
    fingerprint), or expired.
  - **Test** signs in and counts the computers; **Save** starts reading it
    every hour with its console (**Sync now** for at once).
  - Only GET requests are made. The Manager's computers then replace Apex
    Central's copies, with their status, OS, last contact and pattern version,
    but only while the direct read works: if it fails (key, certificate),
    Apex Central's list counts again, so no machine looks unprotected because
    of a settings problem. **Remove key** goes back to Apex Central's list.
- **Antivirus page > Product servers synced** tile and tab: every product
  server, whether it is synced, its agents and how it is read.
- **Inventory.** Ticked product servers join the asset list as seen by
  Apex: Apex One servers and Deep Security Managers as servers, email
  security as appliances (unless the OS or a person says otherwise).
- **Assistant.** "List the Deep Security Managers", "which Apex One servers
  are synced", "email security servers".
- Every discovery, choice, key save, test, certificate read and removal is in
  the audit log; tests and certificate reads count toward the 20 checks per
  10 minutes.


## Reports by e-mail

Every main report can be e-mailed in the branded mail, with a summary, the
first rows and the full report attached as PDF or CSV:

| Report | From the page |
|---|---|
| Antivirus threats, AI summary (malware, ransomware) | Antivirus |
| Antivirus health (outdated definitions, offline, no antivirus) | Antivirus |
| Antivirus agents; machines with no antivirus | Antivirus |
| Servers (with the page's filters) | Servers |
| Detected CVEs | Vulnerabilities |
| Advisories to install | Vulnerabilities > Advisories |
| Activity (admins) | Activity |

- **At once:** Export > **E-mail…** on the page (operators and admins).
  Choose the report, PDF or CSV, and the recipients.
- **On a schedule:** **Admin > Scheduled reports**, or **Schedule…** in the
  same panel (admins). Every day, week or month at a set time (SGT).
  Schedules can be turned on and off, sent now, edited and removed.
- **Antivirus health, daily** (08:00) and **Antivirus threats, daily
  summary** (08:05) are set up for the daily-digest recipients. Mail must be
  on (Admin > Mail).

Safeguards:
- Each report is built on PATCH-01 when it is sent, never from what a
  browser sends.
- Reports go only to the recipients set in Admin > Mail.
- At most ten e-mailed reports an hour per user. Each one is in Activity.
- The attachment is removed from the database once the mail is delivered.
- Failed sends are retried, like every other mail.

**Antivirus health** judges each agent:
- **Definitions outdated:** Apex Central's Pattern Update Status says the
  pattern is 2 or more versions old. If that log is not available, the
  version is compared instead: more than N releases (default 4) behind the
  newest version seen for that product.
- **Offline:** Apex Central's last-connected time is older than N hours
  (default 24), or Apex reports it offline.
- **No connection data from Apex:** the agent counts as offline when its
  machine has not been seen by our agent or WSUS for N hours, or is powered
  off in vCenter. The mail says which rule was used.
- **No longer listed:** Apex Central has stopped listing the agent.

Definition versions and connection times appear in Apex Central's agent
list only on some versions; they are not in Trend Micro's published API
reference. Admin > Antivirus shows, for each console, whether they are
present ("definitions ✓", "connection ✓") and the fields it sends. If they
are missing, the mail says so instead of guessing.


## Asset inventory

**Asset & Inventory > Assets** is the **master asset list**, one list with
tabs that are views of it, so they always agree:

- **Master:** every machine.
- **Servers**, **Laptop/Desktop**, **ESXi**, **Appliances**, **Network**,
  **Firewalls**, and **Unknown** (shown only when there are any).
- **Powered off:** VMs that vCenter reports powered off or suspended (and our
  agent has not reported from for 7 days). The tab shows power, vCenter,
  folder and the VM's created date. They are kept out of Master, the type
  tabs, the type counts and WSUS/Apex coverage. When a VM is switched back
  on, it returns to Master on the next vCenter read.
- **Templates:** vCenter VM templates, with OS, vCenter, folder, CPU,
  memory, disk, created date and notes. Templates are not machines: they
  never appear in Master, the VMware actions, patching or coverage. Export
  works; approve, decom and Set type do not apply.
- **Hardware:** only physical machines that a source actually describes
  (make, model, serial, CPU or memory), one row per physical box. Two names
  with the same serial number are shown once ("also <name>"). ESXi hosts get
  these details from vCenter; other machines from the sheet's Make, Model
  and Serial columns.

**VM created date:** vCenter's own creation date for each VM (vSphere 6.7
and later), shown as "VM created" on Master and the Powered off tab, in each
VM's **+**, and in exports.

At the top, four small charts:
- assets by type (click a type to open its tab);
- the share approved;
- the share of Windows machines in WSUS;
- the share of Windows machines in Apex. The last two open the Coverage page.

**How the type is decided, in this order:**
1. A person's choice: **Set type…** on ticked machines (Approve permission).
   Choosing "Automatic" hands them back.
2. vCenter's facts: ESXi hosts, and the vCenter appliance.
3. The OS: Windows Server or a Linux distribution is a Server; Windows 10/11
   or macOS is a Laptop/Desktop. FortiOS, PAN-OS, Check Point, Sophos or ASA
   is a Firewall. IOS, NX-OS, Junos, Arista EOS or ArubaOS is Network.
   Storage, load balancers, UPS and similar are Appliances.
4. The sheet's device column (Firewall, Switch, Laptop, Storage...).
5. The name (fw-, sw-, core-, ups-, ltp-...), only when nothing else says
   anything.
6. AI-01, for the machines still uncertain. It is shown the name, OS,
   sheet type, make/model, whether it is a VM and which sources see it, and
   must answer with one of the types and a short reason (shown on hover,
   marked "AI"). Each machine is asked once, and again only when those
   details change.

**Safeguards:**
- A machine with our agent, or one that WSUS or Apex sees, or that runs
  Windows, can only be a Server or Laptop/Desktop by rules, sheet, name or
  AI-01.
- Only a person can type it otherwise, with a reason, and it is still checked
  for WSUS and Apex.
- ESXi hosts, appliances, network devices and firewalls are never expected in
  WSUS or Apex.

**Export selected:** tick machines (on any tab, or "Select all matching") and
press PDF or CSV. Only the ticked rows are exported, with the logo, date and
your name, in that tab's columns. The page's **Export** still exports the
whole filtered list.

**Asset & Inventory > Assets** lists every machine, merged by host name from:
agents, vCenter (VMs, ESXi hosts, the vCenters), WSUS, Apex Central (every
antivirus agent), and the asset sheet an admin uploads. Decommissioned
machines move to their own page.

**Which OS is shown.** Servers: the agent's, then WSUS, then vCenter (these
are accurate for servers). Laptops and desktops: Apex Central's Windows 10/11
comes first, because WSUS can report the wrong desktop version. Apex's OS
never replaces one that vCenter or WSUS reports as a server. Apex's OS comes
from its agent list when the console sends it, or from its Pattern Update
Status log. **+** shows every source's OS.

**Approved automatically.** A New machine found in both WSUS and the uploaded
sheet is approved at once when a sheet is applied, and hourly after that. It
is recorded as approved by "auto", with the reason, in its history and in
Activity. A machine a person has revoked or decommissioned is never approved
automatically again.

Columns:
- **Hostname**.
- **Device:** Server, Laptop/Desktop, Appliance or Unknown, from the OS
  (hover for the reason). An OS name the rules cannot place is given to AI-01,
  marked "AI".
- **Operating system**.
- **IP:** clean addresses only, no brackets or quotes.
- **Detected:** Agent, Virtual (a vCenter VM), vCenter (ESXi host or
  appliance), WSUS, Apex, Manual (the uploaded sheet).
- **Location:**
  - a VM: the vCenter that runs it;
  - an ESXi host: its vCenter;
  - anything else: the sheet's location if given, otherwise Laptop/Desktop
    (Windows 10/11, macOS) or Physical server (not in any vCenter PATCH-01
    reads).
- **Status:** New (awaiting approval), Approved.
- **Last detected**.

20 machines a page. Tiles count Servers, Laptop/Desktop, Appliances,
Unknown, Awaiting approval, Approved and Decommissioned; clicking one filters.
**+** shows what each source reports (OS per source, vCenter, cluster, ESXi,
WSUS groups, the sheet's serial and owner) and the machine's history.

**Approve, Decom, Revoke.** Tick machines (or "Select all N matching"), then:
- **Approve:** the machine is confirmed as an asset (New → Approved).
- **Decom:** it moves to **Decommissioned** with who, when and a reason
  (required).
- **Revoke:** takes the last decision back. On Assets an approval goes back to
  New. On Decommissioned the machine returns to Assets with the status it had.

Who may do what is set per user in **Admin > Access** (Approve, Decom,
Revoke). Admins can always do all three. Each decision is kept in the asset's
history and in Activity, with the user, the time and the reason. The server
checks the permission on every request, whatever the browser shows.

**Decommissioned** lists each machine with who decommissioned it, the date
and time, the reason, and who approved it. A machine still detected by a
source after its decommission date is flagged ("still detected"). It is also
kept on the Antivirus "No antivirus" list while anything still shows it
running.

**Uploading a sheet** (admins: **Upload sheet**):
- **Files:** Excel `.xlsx` or CSV, up to 5 MB and 5,000 rows. Older `.xls`
  and macro workbooks: save as `.xlsx` or CSV.
- **Columns:** AI-01 is shown the headings and five rows, and says which
  column is the host name, IP, OS, device type, location, serial, owner and
  notes. Each choice is checked against the cells: a host-name column must
  hold host names, an IP column addresses. A choice that fails, or no
  answer, falls back to the heading rules. You can change any column in the
  preview.
- **Rows:** each row is checked and tidied before anything is saved:
  - "PC-002 (old)" is read as PC-002; a name with other spaces is refused;
  - addresses are split and checked; an invalid one is left out;
  - shorthand OS names are written out ("win10", "rhel 9", "2019");
  - device words are mapped (Laptop, Notebook → Laptop/Desktop; Switch,
    Firewall → Appliance);
  - duplicates keep the later row.
- **Preview:** each row shows what happens (New, Already found by a source,
  Update, Skipped) with every fix, problem, and difference from what the
  sources report (another OS, another address, decommissioned).
- **Apply** saves the rows as Manual assets. New machines wait for approval.
  "Also remove Manual assets from earlier sheets that are not in this one"
  names what it would remove first, and is refused when fewer than half the
  rows passed the checks.
- **Safety:** the file is read on PATCH-01 only, never by AI-01. Workbooks
  with DTDs or entities, UTF-16 parts, password protection, or that expand
  past 60 MB are refused. Excel is parsed with defusedxml. Cell text reaches
  AI-01 only as fenced data, never as instructions. At most 20 uploads an hour
  per admin. Each upload and apply is in Activity. The sheet's cells are
  dropped once it is applied or discarded.

**Check with AI-01** (anyone with an asset permission; also every 6 hours on
its own):
- AI-01 places the OS names the rules cannot (server, laptop/desktop,
  appliance, or unknown). Any other answer counts as unknown, and each name is
  asked once.
- The sources are then checked against each other, and the findings listed:
  - one address used by several names;
  - Windows on one source and Linux on another;
  - machines only in the sheet;
  - approved machines not detected for 30 days, or not at all now;
  - decommissioned machines still detected;
  - unknown device types.
- Findings are shown for a person to act on. Nothing is merged, approved or
  decommissioned automatically.

### Coverage: missing in WSUS or Apex

**Asset & Inventory > Coverage** lists every machine that should be in WSUS
or Apex Central but is not, with why and what to do.

**What is expected:**
- A Windows machine should be in both WSUS and Apex.
- A Linux machine should be in Apex, once Apex covers any Linux machine.
- Appliances, ESXi hosts, vCenters and decommissioned machines are left out.
- The machine's type comes from the OS the inventory trusts, so a wrong OS
  from one source does not create a gap.

**The reason** is taken from what the other sources show:

| Reason | Priority |
|---|---|
| Running (seen by our agent, vCenter powered on, WSUS or Apex) but not in it | High for Apex, medium for WSUS |
| Listed in Apex but not reporting for 2 days | High if running, else medium |
| The same address is known there under another name | Medium |
| Powered off in vCenter | Low |
| Only in the uploaded sheet | Low |
| Not seen recently | Low |

Each row says what to do. Examples: check the Windows Update policy points at
WSUS; install the Apex One agent, or Deep Security on Linux servers; check the
agent service; decommission the machine if it is gone.

**Tiles** show:
- the share of Windows machines in WSUS and in Apex;
- Missing in WSUS, Missing in Apex, Apex not reporting;
- High priority.

Filters: priority and reason. 20 a page. Export, and E-mail
("Asset coverage gaps"), which can also be scheduled in Admin > Scheduled
reports.

**Analyse with AI-01** (anyone with an asset permission; also on each
scheduled send of the report):
- AI-01 writes the coverage, the main patterns and what to fix first, from
  the counts.
- Every number it writes must be one of those figures. Names are not counted
  as figures, numbers written as words are refused, and if the check fails
  the figures are shown instead.
- Machine and location names reach AI-01 only as fenced data.
- Each summary is kept with its figures.
- The same check now also protects the antivirus threat summary.

The assistant answers "which machines are missing in Apex",
"WSUS coverage gaps" and "high-priority inventory gaps".


## Servers

**Servers** is one page for the servers and their agents (the old Agents page
opens it too):

- a green light is an agent online (checked in within 15 minutes), red is
  offline, not reporting or never reported; hover for when it was last seen;
- **+** opens a server's details in place (agent, last seen, uptime, reboot,
  what is still to install, worst CVSS, hardening score, VMware placement),
  with a link to the full server page;
- filters for name or address, operating system, agent state, patches, group
  and agent version, and a sort; the tiles filter on online or offline;
- 20 servers a page, computed on the server, so it stays fast with hundreds;
- **Export** (PDF report or CSV, see Exports) covers every server matching
  the filters, not just the page.
- **AI-01 analysis**: every 15 minutes the worker gathers the figures (agent
  states, patch backlog, reboots, impacted CVEs, and what changed since the
  last time) and AI-01 writes a short note: the state of the estate, what
  changed, what to do first. Each note is stored with its figures; if AI-01 is
  unavailable the figures are written as plain sentences instead, marked so.

Every other CSV the console exports (assessments, the assistant, inventory)
now starts with the same heading.


## Modules and access

The console has three modules, shown as glowing buttons on the welcome page
and on the home page after sign-in:

| Module | Opens | Pages |
|---|---|---|
| Patch Dashboard | `#/dashboard` | Dashboard, Servers, Vulnerabilities (Detected CVEs, Advisories, Assess), Hardening, Windows, patch changes |
| Asset & Inventory | `#/assets` | Inventory (assets, software), VMware |
| Software Lifecycle | `#/deployment` | Windows software, Linux packages, Deployment, software changes |

**Admin > Access** chooses which modules each user may open. A user's own
modules glow on the home page; the others are greyed out, their menu entries
are hidden, and the API refuses their data and actions on every request,
whatever the browser does (VMware changes need Patch or Inventory; software
changes need Lifecycle; patch changes need Patch). Admins always have all
three. Existing users keep all three when r54 is applied; **new users start
with none** until an admin grants them, and an admin who is made a viewer or
operator loses all three until granted again. The assistant answers only from
the modules the user has, and so do its exports and e-mails. Activity hides
other users' sign-ins, assistant questions and account changes from
non-admins.


## Impacted CVEs

Every new critical, high or 0-day (exploited) CVE from the feeds is matched
against the inventory by the worker: Linux packages and the CVE engine's
verdicts, Windows programs (with NVD's version ranges where given), Windows
editions (agents, WSUS, VM guests), ESXi and vCenter versions, and server
hardware models. Each gets a verdict (affected, fixed but reboot needed,
possibly affected, not in inventory, not inventoried) and the list of machines.
AI-01 then writes a short brief for the impacted ones, most serious first; it
never decides the verdict. The analysis repeats when the inventory changes and
at least daily; **Analyse again now** on Vulnerabilities > Detected CVEs redoes
all of them. The **Impacted CVEs** donut leads the Patch Dashboard.


## Cyber-Secure dashboard and CVE feeds

The console opens on the **Cyber-Secure** dashboard. Every figure is computed
live from the database and the page refreshes itself every minute, so a server
enrolled a minute ago is already counted. Six donuts, each with a legend that
names every slice (hover or tab to a slice for its count):

- **Servers**: patched, needs patches, needs a reboot, not reporting (each
  server once, by its worst state).
- **Updates**: per server and update, to install (Linux advisories and Windows
  updates), installed but waiting for a reboot, installed.
- **Outstanding by severity**: distinct advisories and Windows updates still
  to install.
- **Operating systems**, **Agents**, and **New CVEs (feeds)**.

Under them, **CVE news** lists new CVEs from **NIST NVD, Microsoft and Red Hat**
for the software you follow, and any CVE already linked to one of your servers.

**Admin > CVE feeds** chooses that software: type a name, or click one of the
suggestions taken from what your servers run (Windows programs, notable Linux
packages, your operating systems). There you also switch sources on or off,
set how many days to show, the lowest CVSS, how often to read, and press
**Read the feeds now**. The worker reads the feeds through the proxy
(services.nvd.nist.gov, api.msrc.microsoft.com, access.redhat.com, already in
docs/proxy-allowlist.txt). Without an NVD API key NIST is read slowly; save a
free key in `/patch/secrets/nvd-api-key` and run `phase3b-api.sh`.

The **sign-in page** shows the logo (the same one the mails use, from
`/patch/data/branding`), "Welcome to the Cyber-Secure Dashboard portal", and a
news board of the latest critical and high CVEs from NIST, Microsoft and Red
Hat. Before sign-in only the general feeds are shown, never your watch list,
so the page does not reveal what software runs here; it can be switched off
in Admin > CVE feeds. These unauthenticated answers are built at most every
two minutes, whoever asks.


## The assistant

The icon at the bottom right of the console opens the assistant. It is a
floating window: drag it by its title bar, resize it from the bottom-right
corner, enlarge it (⤢) or send it back to the corner (↵). Its place and size
are remembered in this browser.

**⧉ Pop out** lifts it into its own small window that stays **on top of every
other application** (Chrome and Edge 116 or later), so it can sit over Outlook,
vCenter or a remote desktop while you work. **Back to page**, or closing that
window, returns it. It is the same session in the same tab: nothing new is
signed in or stored.

Ask in plain words about servers, patches pending or installed on a server,
CVEs, Windows updates and KBs, WSUS, changes (CHG numbers), hardening scores,
VMs, ESXi hosts, datastores, installed software, agents, and the asset
inventory, including any operating system version or edition ("Windows 10 Pro
list", "how many Windows 11", "Windows Server 2019 without an agent", "RHEL 8").
Every answer shows the rows it came from.

- **Export**: add "export" or "csv" to a question, say "export that" after an
  answer, or press **Export CSV**. The server re-runs the same query with up to
  5000 rows; formula-like cells are neutralised.
- **E-mail**: add "email to ops team" or an address, or press **E-mail**. The
  assistant shows a draft (to, cc, subject, message, CSV attached) and
  **nothing is sent until you press Send**. It may mail only the configured
  mail recipients and addresses at their mail domains (and the sender's), at
  most ten mails an hour per user; each mail is in the audit log and the mail
  history. The server re-reads the data itself: the browser cannot change
  what is attached.
- **Speaking**: tick **Read answers aloud**, or press **Read** on an answer.
  Only the computer's offline voices are offered (on Windows, the installed
  Windows voices); voices that would send text to an online service are never
  used. Typing is the only input: browser voice input sends audio to an
  online service, so it is not offered.

It is **read-only**. Patching, snapshots, power and software actions go
through the approval flow, never from a sentence typed into the assistant.

How it answers, and why it can be trusted:

- AI-01 only chooses **which prepared query to run**, from a fixed list. It
  never writes database queries, never sees a row of data, and never supplies
  a figure that appears in an answer. Text stored in the database (a server
  name, a program name, a CVE description) therefore cannot instruct it.
- Parameters are rebuilt against a type and range before use, so a confused or
  manipulated model cannot widen a query.
- Export and e-mail are recognised by PATCH-01's own code, not by the model.
- If AI-01 is unreachable, keywords choose the query and it still works.

Operators and admins.


## Keeping the dashboard truthful

The console can only be as current as the last repository sync. If the mirror
is behind, the platform will report a server as patched because the newer
advisory is not in the mirror yet, while `dnf` talking to the vendor directly
sees it. Sync, import, then compute, in that order:

```bash
./scripts/phase2-repos.py --sync --publish
./scripts/phase4-cve.sh --import
./scripts/phase4-cve.sh --compute
```

`phase4-cve.sh --install-timer` runs the import and compute nightly; schedule
the repository sync a couple of hours earlier so the engine has fresh
advisories to read.


## Everyday operations

| Task | Where | Command |
|------|-------|---------|
| Open the console | browser | `https://patch01.example/` |
| Issue an enrollment token | PATCH-01 | `scripts/phase3b-api.sh --token` |
| Sync repositories | PATCH-01 | `scripts/phase2-repos.py --sync` then `--publish` |
| Recompute verdicts now | PATCH-01 | `scripts/phase4-cve.sh` |
| Verdicts for one server | PATCH-01 | `scripts/phase4-cve.sh --host <name>` |
| Fleet report in the terminal | PATCH-01 | `scripts/phase4-cve.sh --report` |
| Pre-generate explanations | PATCH-01 | `scripts/phase6-llm.sh --warm 20` |
| Nightly CVE run and explanations | PATCH-01 | `phase4-cve.sh --install-timer`, `phase6-llm.sh --install-timer` |
| After a Red Hat certificate refresh | PATCH-01 | `subscription-manager refresh`, then `phase2-repos.py --update-remotes` |
| Health of the whole stack | PATCH-01 | each script's `--check` |
| Agent status, one server | client | `install-agent.sh --status` |
| Agent status, whole fleet | browser | **Agents** page |
| Model server status and speed | AI-01 | `ai01-setup.sh --check`, `--bench` |
| vCenter status | PATCH-01 | `scripts/phase7-vmware.sh --check` |
| Start (or repair) everything, then health check | PATCH-01 | `scripts/patch01-start.sh` (`--install-boot`: at every boot) |
| Start (or repair) the model server and nginx | AI-01 | `ai01-start.sh` (`--install-boot`: at every boot) |
| Update PATCH-01 itself, then health check | PATCH-01 | `scripts/patch01-update.sh --all --reboot` (no option: health check only) |
| Update AI-01 itself, then health check | AI-01 | `ai01-update.sh --os --reboot` (no option: health check only) |
| Refresh CVE data | PATCH-01 | `scripts/phase4-cve.sh --intel` |
| What is exploited in the wild | PATCH-01 | `scripts/phase4-cve.sh --report` |
| Sync vCenters now | PATCH-01 | `scripts/phase7-vmware.sh --sync` |


## Updating agents

Re-run the installer on the server with the new `client/` files. It keeps the
server's existing identity, so no new token is needed:

```bash
./install-agent.sh --server https://patch01.example --insecure
```

The **Agents** page lists any server still on an older version. The current
agent is **1.5.0**, which patch jobs need: it installs exact versions,
records running services before patching so they can be checked afterwards,
and carries out a job's steps in sequence.

Agent states:

| State | Meaning |
|-------|---------|
| Online | Checked in within 15 minutes |
| Offline | Missed several check-ins, but under 24 hours |
| Not reporting | Silent over 24 hours; its verdicts show as unknown |
| No data yet | Enrolled but never checked in |

Agent 1.1.0 and later report boot time, from which uptime is shown. Older
agents keep working but show uptime as "not reported".

### Signed agent updates (r97; Linux agent 1.8.3, Windows 1.9.5-win)

Agent updates and Windows installers can be signed with a key that never
lives on PATCH-01. Agents with the public key pinned refuse anything unsigned.
Without a pinned key, nothing changes except a warning in the agent's log.

One time, on an offline machine (not PATCH-01). Keep `release-signing.key` and
its passphrase offline, with a backup:

```bash
./scripts/sign-agent-release.sh --new-key /secure/agent-signing
```

Each release, on that machine (Windows: run Sign-Agent.ps1 first):

```bash
./scripts/sign-agent-release.sh --key /secure/agent-signing/release-signing.key patch-agent.py patch-agent.ps1
```

Copy each file with its `.sig` to PATCH-01 and publish it; the `.sig` goes with it:

```bash
./scripts/phase12-agents.sh --linux patch-agent.py
./scripts/phase12-agents.sh --windows patch-agent.ps1
```

Pin the public key on the servers (compare the fingerprint it prints with
the one from `--new-key`):

```bash
# Linux, each server (or put release-signing.pub beside push-linux.sh)
./setup-agent.sh --release-key release-signing.pub
patch-agent release-key
```

```powershell
# Windows: put release-signing.pub (and optionally allowed-publishers.txt)
# in the agent folder or the Install-PatchAgent.bat share, then
.\install-agent.ps1 -Update
```


## Starting everything, and keeping it started

After a restart, an update, or whenever something is down, one command starts every part in the right order, repairs what does not come up,
and runs the full health check:
```bash
sudo /opt/patch01/scripts/patch01-start.sh
```
Make it happen at every boot (recommended, once):
```bash
sudo /opt/patch01/scripts/patch01-start.sh --install-boot
```
PATCH-01's order is docker, ingress (nginx and the shared network), data
(PostgreSQL, Redis), pulp, API and worker, dashboard, then ClamAV if
installed; each part must be healthy before the next starts. A part that does
not come up is repaired once by re-running its own phase script; if it is
still down, the start stops there and names the part, with its last log lines
in `/var/log/patch-platform/patch01-start-*.log`. Docker is started (or
restarted once if it does not answer) and enabled at boot. The
update scripts below call these automatically after updating and after a
restart.


## Updating PATCH-01 itself

The update script, with no option, it only checks health
and changes nothing; it exits 0 when healthy and 1 when not, so it can also be
run from monitoring.

From `/opt/patch01`:
```bash
sudo ./scripts/patch01-update.sh                         # health check only
sudo ./scripts/patch01-update.sh --dry-run --all         # what would be updated
sudo ./scripts/patch01-update.sh --all --reboot          # OS and images, restart if needed
sudo ./scripts/patch01-update.sh --os --security --yes   # security updates only, no questions
```

What they do: refuse to run twice at once; on PATCH-01, refuse while patch jobs
are running; check health **before** (no update starts on a broken system);
back up (PATCH-01: every database, the image and package lists; AI-01: nginx's
configuration and the llama-server unit) to a root-only folder, keeping the
last 5; update; check health **after**. With `--reboot`, a restart happens
only if needed and only when healthy, and a one-shot service checks health
again after boot. The last result is in `update-last.txt` in each server's log
folder (`/var/log/patch-platform/`, `/llm/logs/`).

The health check covers disk, failed services, the clock, every
container (running and healthy), the API and console through the ingress, the
worker's heartbeat, the certificate's expiry and each phase script's own
`--check`.

Images: `--images` re-pulls each image by its current tag and redeploys only
the stacks whose image changed. A PostgreSQL **major** version change is
refused (that needs a dump and restore). AI-01 has its own package and update script (see its README); update it
after PATCH-01, because its packages come from PATCH-01's mirrors.


## Change log

See CHANGELOG.md in this package.


## Back these up, off both servers

These cannot be recreated. Losing them loses the data they protect.

| File | Why |
|------|-----|
| `/patch/secrets/postgres.env` | Database passwords. Pulp's 600 GB of packages are unnamed files without the database that maps them. |
| `/patch/config/pulp/certs/database_fields.symmetric.key` | Encrypts sensitive database fields. Without it they are unreadable. |
| `/patch/secrets/pulp-admin.txt` | Pulp admin password. |
| `/patch/secrets/api.env` | Console admin password and the AI-01 key. |
| `/etc/patch-platform/images.env` | Exact image digests this build was made from. |
| `/llm/config/api-key` on AI-01 | The key PATCH-01 uses. |
| `/patch/secrets/vcenter/` | vCenter accounts and pinned certificates. |


## Lessons already built into the scripts

Problems met during the first build, each now detected or prevented by the
script that caused it:

- A config value containing a space broke when the file was sourced. All
  generated values are quoted and the file is test-sourced before use.
- Containers running as non-root users could not read certificates, init
  scripts or keys in `0700` directories. Scripts now set the group to match
  each image's own user and prove access from inside a throwaway container
  before starting the real one.
- `lvcreate` waited forever on a hidden prompt. Commands now run with no
  input, so anything that prompts fails at once with a visible error.
- Pulp would not start without a database encryption key. It is generated,
  validated and mounted before migrations run.
- A build under a hardened `umask 077` left llama-server runnable by root
  only. The AI-01 script fixes permissions and runs the binary as the
  service user before starting the service.
- Pulp rejects keeping old package versions with a "mirror" sync. Syncs are
  additive, which also preserves the ability to downgrade.


## Not built yet

- **Reports** with your logo, exported to PDF.
- **Hardening dashboard** using OpenSCAP with CIS-aligned profiles.
- **Windows Server**: WSUS reporting, CVE assessment by build number, then a
  PowerShell agent and hardening.
- **Oracle Linux and Ubuntu advisories.** Verdicts currently come from Red Hat
  advisories synced into Pulp. Oracle's public repositories often omit errata
  data, so Oracle servers need the Oracle OVAL feed; Ubuntu needs the USN feed.
  Until then those servers show no advisories, and the engine's log says so.
- **RHEL 8 modular packages** are skipped and counted rather than compared, to
  avoid false results across module streams.
- **CA-signed certificates and agent mTLS.** PATCH-01 and AI-01 still use
  self-signed placeholders. Replace PATCH-01's before enrolling the full fleet,
  since agents trust the certificate present when they enroll.
- **Single sign-on** (Active Directory or SAML) in place of local accounts.
- **Hardening fixes through the change engine**, once the OpenSCAP dashboard
  exists.
- **Trend Micro.** Apex One protects Windows and macOS, so it adds little to a
  Linux platform. Worth integrating only if the Linux servers appear in Apex
  Central, or if Trend's server product (Server & Workload Protection) is in use.
- **Read-only MCP query layer.** (Step 12.)
